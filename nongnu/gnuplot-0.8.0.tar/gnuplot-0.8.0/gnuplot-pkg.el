;; Generated package description from gnuplot.el  -*- no-byte-compile: t -*-
(define-package "gnuplot" "0.8.0" "Major-mode and interactive frontend for gnuplot" '((emacs "24.3")) :keywords '("data" "gnuplot" "plotting") :authors '(("Jon Oddie") ("Bruce Ravel") ("Phil Type")) :maintainer '("Bruce Ravel" . "bruceravel1@gmail.com") :url "https://github.com/emacsorphanage/gnuplot")
