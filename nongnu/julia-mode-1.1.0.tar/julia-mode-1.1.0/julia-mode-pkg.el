;; Generated package description from julia-mode.el  -*- no-byte-compile: t -*-
(define-package "julia-mode" "1.1.0" "Major mode for editing Julia source code" '((emacs "26.1")) :commit "555106175a226993364d1290790fba564e7ebe7a" :keywords '("languages") :url "https://github.com/JuliaEditorSupport/julia-emacs")
