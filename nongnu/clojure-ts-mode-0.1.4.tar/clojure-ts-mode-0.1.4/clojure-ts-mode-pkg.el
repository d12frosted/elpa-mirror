;; Generated package description from clojure-ts-mode.el  -*- no-byte-compile: t -*-
(define-package "clojure-ts-mode" "0.1.4" "Major mode for Clojure code" '((emacs "29")) :commit "3e4c55fab14e0885a411f6018fb8aedb04afc49d" :maintainer '("Danny Freeman" . "danny@dfreeman.email") :keywords '("languages" "clojure" "clojurescript" "lisp") :url "http://github.com/clojure-emacs/clojure-ts-mode")
