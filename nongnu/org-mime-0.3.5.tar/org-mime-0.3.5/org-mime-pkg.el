;; Generated package description from org-mime.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "org-mime" "0.3.5" "org html export for text/html MIME emails" '((emacs "29.1")) :commit "18b421f9a73428a49d9a534d3920e63ca21bea5b" :maintainer '("Chen Bin" . "chb_shAThotmailDOTcom") :keywords '("mime" "mail" "email" "html") :url "http://github.com/org-mime/org-mime")
