;; Generated package description from emacsql.el  -*- no-byte-compile: t -*-
(define-package "emacsql" "4.0.2" "High-level SQL database front-end" '((emacs "25.1")) :commit "07699353a43f629848c66c0949e7170e8f29e299" :authors '(("Christopher Wellons" . "wellons@nullprogram.com")) :maintainer '("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev") :url "https://github.com/magit/emacsql")
