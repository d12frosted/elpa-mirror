;; Generated package description from hyperdrive.el  -*- no-byte-compile: t -*-
(define-package "hyperdrive" "0.1.0" "P2P filesystem" '((emacs "27.1") (map "3.0") (compat "29.1.4.0") (plz "0.7") (persist "0.5")) :commit "91ea0fac623dfee497644d7f105180dc737ee749" :maintainer '("Joseph Turner" . "joseph@ushin.org") :url "https://git.sr.ht/~ushin/hyperdrive.el")
