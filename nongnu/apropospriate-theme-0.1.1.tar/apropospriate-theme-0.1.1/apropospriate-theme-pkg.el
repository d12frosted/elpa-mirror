;; Generated package description from apropospriate-theme.el  -*- no-byte-compile: t -*-
(define-package "apropospriate-theme" "0.1.1" "A light & dark theme set for Emacs." 'nil :authors '(("Justin Talbott" . "justin@waymondo.com")) :maintainer '("Justin Talbott" . "justin@waymondo.com") :url "http://github.com/waymondo/apropospriate-theme")
