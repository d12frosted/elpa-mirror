;; Generated package description from devil.el  -*- no-byte-compile: t -*-
(define-package "devil" "0.4.0" "Minor mode for translating key sequences" '((emacs "24.4")) :commit "c87075a0cd087165f8528de6952263b4ef26858b" :authors '(("Susam Pal" . "susam@susam.net")) :maintainer '("Susam Pal" . "susam@susam.net") :keywords '("convenience" "abbrev") :url "https://github.com/susam/devil")
