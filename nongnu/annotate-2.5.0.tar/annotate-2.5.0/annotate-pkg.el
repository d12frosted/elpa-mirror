;; Generated package description from annotate.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "annotate" "2.5.0" "annotate files without changing them" '((emacs "27.1")) :commit "9a7f8f1d0e19fb905a6f8d7c1347991d1e7b0d03" :maintainer '(("Bastian Bechtold" . "bastibe.dev@mailbox.org") ("cage" . "cage-dev@twistfold.it")) :url "https://github.com/bastibe/annotate.el")
