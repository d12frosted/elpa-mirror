;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.3" "A major mode for editing subtitles" '((emacs "25.1")) :commit "3b265af572d7e9032d20213264f9fa635cefd8db" :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/rndusr/subed")
