;; Generated package description from emacsql.el  -*- no-byte-compile: t -*-
(define-package "emacsql" "4.0.1" "High-level SQL database front-end" '((emacs "25.1")) :commit "e5f0928a047dba8e3a00b6333400422b301bac35" :authors '(("Christopher Wellons" . "wellons@nullprogram.com")) :maintainer '("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev") :url "https://github.com/magit/emacsql")
