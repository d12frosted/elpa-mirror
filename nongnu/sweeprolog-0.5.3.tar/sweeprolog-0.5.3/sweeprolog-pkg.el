;; Generated package description from sweeprolog.el  -*- no-byte-compile: t -*-
(define-package "sweeprolog" "0.5.3" "Embedded SWI-Prolog" '((emacs "28")) :commit "f996c4dcbf6271d0bbdcccac35a4ff64106ce77a" :authors '(("Eshel Yaron" . "me@eshelyaron.com")) :maintainer '("Eshel Yaron" . "~eshel/dev@lists.sr.ht") :keywords '("prolog" "languages" "extensions") :url "https://git.sr.ht/~eshel/sweep")
