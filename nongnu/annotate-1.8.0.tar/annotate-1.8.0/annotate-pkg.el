;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.8.0" "annotate files without changing them" 'nil :commit "c210a75a2582bfd8e28f177747d3a9ec89fc2f3e" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
