;; Generated package description from geiser-mit.el  -*- no-byte-compile: t -*-
(define-package "geiser-mit" "0.13" "MIT/GNU Scheme's implementation of the geiser protocols" '((emacs "24.4") (geiser "0.12")) :keywords '("languages" "mit" "scheme" "geiser") :authors '(("Peter" . "craven@gmx.net")) :maintainer '("Jose A Ortega Ruiz" . "jao@gnu.org") :url "https://gitlab.com/emacs-geiser/mit")
