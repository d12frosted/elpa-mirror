;; Generated package description from inf-clojure.el  -*- no-byte-compile: t -*-
(define-package "inf-clojure" "3.1.0" "Run an external Clojure process in an Emacs buffer" '((emacs "25.1") (clojure-mode "5.11")) :keywords '("processes" "clojure") :url "http://github.com/clojure-emacs/inf-clojure")
