;; Generated package description from elpher.el  -*- no-byte-compile: t -*-
(define-package "elpher" "3.2.2" "A friendly gopher and gemini client" '((emacs "27.1")) :commit "7b52709ddf798fe53db3855eef52ca8862e7700d" :authors '(("Tim Vaughan" . "plugd@thelambdalab.xyz")) :maintainer '("Tim Vaughan" . "plugd@thelambdalab.xyz") :keywords '("comm" "gopher") :url "https://thelambdalab.xyz/elpher")
