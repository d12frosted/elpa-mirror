;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.5.1" "annotate files without changing them" 'nil :commit "aa3c0540ee644e0e205644545d659a6ba16d76ac" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold") :url "https://github.com/bastibe/annotate.el")
