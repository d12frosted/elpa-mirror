;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.5.4" "annotate files without changing them" 'nil :commit "c00b6f49f779dc5caac7b37d1e35f87891e015d4" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
