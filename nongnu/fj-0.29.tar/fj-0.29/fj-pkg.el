;; Generated package description from fj.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "fj" "0.29" "Client for Forgejo instances" 'nil :commit "bc00bbf226e561af14bf05b4be35669957fe59c4" :authors '(("Marty Hiatt" . "mousebot@disroot.org")) :maintainer '("Marty Hiatt" . "mousebot@disroot.org") :keywords '("git" "convenience") :url "https://codeberg.org/martianh/fj.el")
