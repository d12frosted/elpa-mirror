;; Generated package description from undo-fu.el  -*- no-byte-compile: t -*-
(define-package "undo-fu" "0.4" "Undo helper with redo" '((emacs "25.1")) :commit "46de023b5f8ddb989eeff7665feeec2877d8eda8" :authors '(("Campbell Barton" . "ideasman42@gmail.com")) :maintainer '("Campbell Barton" . "ideasman42@gmail.com") :url "https://codeberg.com/ideasman42/emacs-undo-fu")
