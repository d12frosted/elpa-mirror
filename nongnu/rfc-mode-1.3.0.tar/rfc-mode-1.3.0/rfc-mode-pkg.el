;; Generated package description from rfc-mode.el  -*- no-byte-compile: t -*-
(define-package "rfc-mode" "1.3.0" "RFC document browser and viewer" '((emacs "25.1")) :commit "02546beecf4c495940885e7b7b911d84b12646ef" :authors '(("Nicolas Martyanoff" . "khaelin@gmail.com")) :maintainer '("Nicolas Martyanoff" . "khaelin@gmail.com") :url "https://github.com/galdor/rfc-mode")
