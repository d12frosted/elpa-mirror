;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.24" "A major mode for editing subtitles" '((emacs "25.1")) :commit "7842bb9f15f08ea3d223f98bf7be98d6d01be522" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
