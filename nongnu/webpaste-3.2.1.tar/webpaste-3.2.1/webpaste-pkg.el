;; Generated package description from webpaste.el  -*- no-byte-compile: t -*-
(define-package "webpaste" "3.2.1" "Paste to pastebin-like services" '((emacs "24.4") (request "0.2.0") (cl-lib "0.5")) :authors '(("Elis \"etu\" Hirwing")) :maintainer '("Elis \"etu\" Hirwing") :keywords '("convenience" "comm" "paste") :url "https://github.com/etu/webpaste.el")
