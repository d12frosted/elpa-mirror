;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.21" "A major mode for editing subtitles" '((emacs "25.1")) :commit "7a90fd74d3e1b16b17eb4e46a223b1afb1448625" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
