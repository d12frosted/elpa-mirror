;; Generated package description from mpv.el  -*- no-byte-compile: t -*-
(define-package "mpv" "0.1.0" "control mpv for easy note-taking" '((cl-lib "0.5") (emacs "25.1") (json "1.3") (org "8.0")) :authors '(("Johann Klähn" . "kljohann@gmail.com")) :maintainer '("Johann Klähn" . "kljohann@gmail.com") :keywords '("tools" "multimedia") :url "https://github.com/kljohann/mpv.el")
