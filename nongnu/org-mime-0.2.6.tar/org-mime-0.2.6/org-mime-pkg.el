;; Generated package description from org-mime.el  -*- no-byte-compile: t -*-
(define-package "org-mime" "0.2.6" "org html export for text/html MIME emails" '((emacs "25.1")) :commit "3f1f3a38429da17811f61a7a5685224d79de9594" :authors '(("Eric Schulte")) :maintainer '("Chen Bin (redguardtoo)") :keywords '("mime" "mail" "email" "html") :url "http://github.com/org-mime/org-mime")
