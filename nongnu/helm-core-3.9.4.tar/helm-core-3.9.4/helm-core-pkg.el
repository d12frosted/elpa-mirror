;; Generated package description from helm-core.el  -*- no-byte-compile: t -*-
(define-package "helm-core" "3.9.4" "Development files for Helm" '((emacs "25.1") (async "1.9.7")) :commit "497f479ec113583c2570c03a526c999e3d410f95" :authors '(("Thierry Volpiatto" . "thievol@posteo.net")) :maintainer '("Thierry Volpiatto" . "thievol@posteo.net") :url "https://emacs-helm.github.io/helm/")
