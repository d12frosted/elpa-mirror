;; Generated package description from buttercup.el  -*- no-byte-compile: t -*-
(define-package "buttercup" "1.25" "Behavior-Driven Emacs Lisp Testing" '((emacs "24.3")) :commit "ba62f80555d46faf49dc451c0ad20f39f6a170ab" :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de")) :maintainer '("Ola Nilsson" . "ola.nilsson@gmail.com") :url "https://github.com/jorgenschaefer/emacs-buttercup")
