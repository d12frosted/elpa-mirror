;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.12" "A major mode for editing subtitles" '((emacs "25.1")) :commit "e528c001d98fcd526fd04ff49caef5c475d74f3b" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
