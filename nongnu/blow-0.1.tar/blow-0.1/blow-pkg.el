;; Generated package description from blow.el  -*- no-byte-compile: t -*-
(define-package "blow" "0.1" "Blow away mode lighters" '((emacs "24.1")) :commit "d6320770612110cec1ca243003254e8e1ea1fcab" :authors '(("Akib Azmain Turja" . "akib@disroot.org")) :maintainer '("Akib Azmain Turja" . "akib@disroot.org") :keywords '("convenience") :url "https://codeberg.org/akib/emacs-blow")
