;; Generated package description from flx-ido.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "flx-ido" "0.6.4" "Flx integration for ido" '((emacs "24.3") (flx "0.6.4")) :commit "be738f439fa779c5a5def44569202d2d7c6b0547" :url "https://github.com/lewang/flx")
