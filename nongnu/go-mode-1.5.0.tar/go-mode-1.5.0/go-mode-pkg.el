;; Generated package description from go-mode.el  -*- no-byte-compile: t -*-
(define-package "go-mode" "1.5.0" "Major mode for the Go programming language" 'nil :keywords '("languages" "go") :authors '(("The go-mode Authors")) :maintainer '("The go-mode Authors") :url "https://github.com/dominikh/go-mode.el")
