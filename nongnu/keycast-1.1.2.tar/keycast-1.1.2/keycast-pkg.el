;; Generated package description from keycast.el  -*- no-byte-compile: t -*-
(define-package "keycast" "1.1.2" "Show current command and its key in the mode line" '((emacs "25.3")) :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :url "https://github.com/tarsius/keycast")
