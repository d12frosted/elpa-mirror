;; Generated package description from shellcop.el  -*- no-byte-compile: t -*-
(define-package "shellcop" "0.0.8" "Analyze info&error in shell-mode" '((emacs "25.1")) :commit "f6060cc292d0143c925252b27d5db21de03ce7f0" :authors '(("Chen Bin" . "chenbin.sh@gmail.com")) :maintainer '("Chen Bin" . "chenbin.sh@gmail.com") :keywords '("unix" "tools") :url "https://github.com/redguardtoo/shellcop")
