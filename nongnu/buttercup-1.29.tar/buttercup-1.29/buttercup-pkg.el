;; Generated package description from buttercup.el  -*- no-byte-compile: t -*-
(define-package "buttercup" "1.29" "Behavior-Driven Emacs Lisp Testing" '((emacs "24.3")) :commit "b3ea11826e2ca5d648d677c4ae27974ce8e7c7e3" :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de")) :maintainer '("Ola Nilsson" . "ola.nilsson@gmail.com") :url "https://github.com/jorgenschaefer/emacs-buttercup")
