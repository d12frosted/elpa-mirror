;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "0.0.4" "A major mode for editing subtitles" '((emacs "25.1")) :commit "f69c3e09f21403722dd5294b0b640a15201afbf5" :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/rndusr/subed")
