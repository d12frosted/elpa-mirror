;; Generated package description from clojure-mode.el  -*- no-byte-compile: t -*-
(define-package "clojure-mode" "5.18.0" "Major mode for Clojure code" '((emacs "25.1")) :commit "525fc1b131b1fc537aa82d83d9eb2ea833cface6" :maintainer '("Bozhidar Batsov" . "bozhidar@batsov.dev") :keywords '("languages" "clojure" "clojurescript" "lisp") :url "https://github.com/clojure-emacs/clojure-mode")
