;; Generated package description from racket-mode.el  -*- no-byte-compile: t -*-
(define-package "racket-mode" "1.0.20221201.102945" "Racket editing, REPL, and more" '((emacs "25.1")) :commit "HEAD" :authors '(("Greg Hendershott")) :maintainer '("Greg Hendershott") :url "https://www.racket-mode.com/")
