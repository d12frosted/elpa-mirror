;; Generated package description from vc-fossil.el  -*- no-byte-compile: t -*-
(define-package "vc-fossil" "20220528" "VC backend for the fossil sofware configuraiton management system" 'nil :commit "88e2e164c0f547497b92b5b0b68ba214bff22c6a" :url "https://elpa.nongnu.org/nongnu/vc-fossil.html" :authors '(("Venkat Iyer" . "venkat@comit.com")) :maintainer '("Alfred M. Szmidt" . "ams@gnu.org"))
