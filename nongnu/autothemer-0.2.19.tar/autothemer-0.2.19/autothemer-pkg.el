;; Generated package description from autothemer.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "autothemer" "0.2.19" "Conveniently define themes" '((dash "2.10.0") (emacs "26.1")) :commit "d5917521c1a0431d59431bbf1e8296affd7ddddb" :maintainer '("Jason Milkins" . "jasonm23@gmail.com") :url "https://github.com/jasonm23/autothemer")
