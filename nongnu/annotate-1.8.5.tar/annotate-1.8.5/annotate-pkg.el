;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.8.5" "annotate files without changing them" 'nil :commit "fb8e51da6ab37b6df2ac2b6a8555f3aa6b589fd6" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
