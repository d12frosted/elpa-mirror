;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.7.1" "annotate files without changing them" 'nil :commit "7aadf4b9838ad83da9f4e6128aa9a450c66220ad" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
