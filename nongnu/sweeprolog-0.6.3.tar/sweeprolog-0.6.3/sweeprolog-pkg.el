;; Generated package description from sweeprolog.el  -*- no-byte-compile: t -*-
(define-package "sweeprolog" "0.6.3" "Embedded SWI-Prolog" '((emacs "28")) :commit "87e98628e5e6e73d016afbc09480d8bf1f0a70ee" :authors '(("Eshel Yaron" . "me@eshelyaron.com")) :maintainer '("Eshel Yaron" . "~eshel/dev@lists.sr.ht") :keywords '("prolog" "languages" "extensions") :url "https://git.sr.ht/~eshel/sweep")
