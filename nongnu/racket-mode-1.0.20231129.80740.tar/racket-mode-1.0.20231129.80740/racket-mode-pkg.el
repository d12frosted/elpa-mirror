;; Generated package description from racket-mode.el  -*- no-byte-compile: t -*-
(define-package "racket-mode" "1.0.20231129.80740" "Racket editing, REPL, and more" '((emacs "25.1")) :commit "HEAD" :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")) :url "https://www.racket-mode.com/")
