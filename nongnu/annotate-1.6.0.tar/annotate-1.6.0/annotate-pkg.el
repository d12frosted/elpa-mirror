;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.6.0" "annotate files without changing them" 'nil :commit "4e90910a2cc383446e610bfc4c110720ffbd70b5" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
