;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.2" "A major mode for editing subtitles" '((emacs "25.1")) :commit "be52d53bf2ccb583f881e5663ad5a6fc28221396" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
