;; Generated package description from autothemer.el  -*- no-byte-compile: t -*-
(define-package "autothemer" "0.2.10" "Conveniently define themes" '((dash "2.10.0") (emacs "26.1")) :commit "a528436677a54572849e404882f51a65ad166549" :maintainer '("Jason Milkins" . "jasonm23@gmail.com") :url "https://github.com/jasonm23/autothemer")
