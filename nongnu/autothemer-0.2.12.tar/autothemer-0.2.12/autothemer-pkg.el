;; Generated package description from autothemer.el  -*- no-byte-compile: t -*-
(define-package "autothemer" "0.2.12" "Conveniently define themes" '((dash "2.10.0") (emacs "26.1")) :commit "64d855aee8b0a98183ac3cb2ec70857447dd6497" :maintainer '("Jason Milkins" . "jasonm23@gmail.com") :url "https://github.com/jasonm23/autothemer")
