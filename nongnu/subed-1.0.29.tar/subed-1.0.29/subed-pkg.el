;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.29" "A major mode for editing subtitles" '((emacs "25.1")) :commit "28a75a6f6803e5c5d121c4d36ef403e8832fbf1f" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
