;; Generated package description from sweeprolog.el  -*- no-byte-compile: t -*-
(define-package "sweeprolog" "0.9.4" "Embedded SWI-Prolog" '((emacs "28.1")) :commit "0e324b3216ff031104fefbdb23e081d88ed1e7f6" :authors '(("Eshel Yaron" . "me@eshelyaron.com")) :maintainer '("Eshel Yaron" . "~eshel/dev@lists.sr.ht") :keywords '("prolog" "languages" "extensions") :url "https://git.sr.ht/~eshel/sweep")
