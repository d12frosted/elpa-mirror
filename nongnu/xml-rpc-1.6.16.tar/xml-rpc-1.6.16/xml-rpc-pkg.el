;; Generated package description from xml-rpc.el  -*- no-byte-compile: t -*-
(define-package "xml-rpc" "1.6.16" "An elisp implementation of clientside XML-RPC" 'nil :commit "fc0c82eb5c8a5d5d837a21bca50f7c8169165f03" :maintainer '("Mark A. Hershberger" . "mah@everybody.org") :keywords '("xml" "rpc" "network") :url "http://github.com/xml-rpc-el/xml-rpc-el")
