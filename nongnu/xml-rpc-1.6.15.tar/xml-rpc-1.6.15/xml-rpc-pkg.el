;; Generated package description from xml-rpc.el  -*- no-byte-compile: t -*-
(define-package "xml-rpc" "1.6.15" "An elisp implementation of clientside XML-RPC" 'nil :maintainer '("Mark A. Hershberger" . "mah@everybody.org") :keywords '("xml" "rpc" "network") :url "http://github.com/xml-rpc-el/xml-rpc-el")
