;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.2.5" "A major mode for editing subtitles" '((emacs "25.1")) :commit "de7ee929613a9c5430d5f8927f3beab7af002659" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
