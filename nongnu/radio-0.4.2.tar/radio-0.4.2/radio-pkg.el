;; Generated package description from radio.el  -*- mode: lisp-data; no-byte-compile: t -*-
(define-package "radio" "0.4.2" "Listen to Internet radio" '((emacs "29.1")) :commit "cd443edbef40d8b282566d402a571ce745386811" :authors '(("Roi Martin" . "jroi.martin@gmail.com")) :maintainer '("Roi Martin" . "jroi.martin@gmail.com") :keywords '("multimedia") :url "https://github.com/jroimartin/radio")
