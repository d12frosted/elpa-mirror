;; Generated package description from buttercup.el  -*- no-byte-compile: t -*-
(define-package "buttercup" "1.24" "Behavior-Driven Emacs Lisp Testing" '((emacs "24.3")) :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de")) :maintainer '("Jorgen Schaefer" . "contact@jorgenschaefer.de") :url "https://github.com/jorgenschaefer/emacs-buttercup")
