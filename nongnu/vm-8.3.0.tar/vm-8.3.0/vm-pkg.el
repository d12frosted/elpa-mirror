;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t -*-
(define-package "vm" "8.3.0" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "fc2b356cb58aca2c9f7bc8eef32e8f8e883bd660" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
