;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.2.1" "A major mode for editing subtitles" '((emacs "25.1")) :commit "0519eb16ad618880fbc9cfd272ebb13e2ceab619" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
