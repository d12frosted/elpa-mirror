;; Generated package description from geiser.el  -*- no-byte-compile: t -*-
(define-package "geiser" "0.16" "GNU Emacs and Scheme talk to each other" '((emacs "24.4")) :keywords '("languages" "scheme" "geiser") :authors '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org")) :maintainer '("Jose Antonio Ortega Ruiz" . "jao@gnu.org") :url "https://gitlab.com/emacs-geiser/")
