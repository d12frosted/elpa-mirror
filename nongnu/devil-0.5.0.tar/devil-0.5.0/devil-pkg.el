;; Generated package description from devil.el  -*- no-byte-compile: t -*-
(define-package "devil" "0.5.0" "Minor mode for translating key sequences" '((emacs "24.4")) :commit "20b44174c3c0f5c46ea15b463dc67c14e6f57681" :authors '(("Susam Pal" . "susam@susam.net")) :maintainer '("Susam Pal" . "susam@susam.net") :keywords '("convenience" "abbrev") :url "https://github.com/susam/devil")
