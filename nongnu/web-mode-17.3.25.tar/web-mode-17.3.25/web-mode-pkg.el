;; Generated package description from web-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "web-mode" "17.3.25" "major mode for editing web templates" '((emacs "24.3.1")) :commit "f008a28f156452b212a62274d0ef5a9e25074698" :maintainer '("François-Xavier Bois" . "fxbois@gmail.com") :keywords '("languages") :url "https://web-mode.org")
