;; Generated package description from with-editor.el  -*- no-byte-compile: t -*-
(define-package "with-editor" "3.0.4" "Use the Emacsclient as $EDITOR" '((emacs "24.4")) :keywords '("tools") :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :url "https://github.com/magit/with-editor")
