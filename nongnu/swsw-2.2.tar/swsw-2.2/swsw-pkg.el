;; Generated package description from swsw.el  -*- no-byte-compile: t -*-
(define-package "swsw" "2.2" "Simple window switching" '((emacs "27.1")) :commit "5faeffc16329a4a4946780c880c343a9fb95deb4" :authors '(("Daniel Semyonov" . "daniel@dsemy.com")) :maintainer '("swsw Mailing List" . "~dsemy/swsw-devel@lists.sr.ht") :keywords '("convenience") :url "https://dsemy.com/projects/swsw")
