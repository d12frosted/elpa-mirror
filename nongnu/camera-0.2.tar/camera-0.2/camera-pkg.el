;; Generated package description from camera.el  -*- no-byte-compile: t -*-
(define-package "camera" "0.2" "Take picture with your camera" '((emacs "25.1")) :commit "99ced5db8d59004edd90b12f88a5dd1a6044ac45" :authors '(("Akib Azmain Turja" . "akib@disroot.org")) :maintainer '("Akib Azmain Turja" . "akib@disroot.org") :keywords '("comm") :url "https://codeberg.org/akib/emacs-camera")
