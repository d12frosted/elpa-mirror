;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.5" "A major mode for editing subtitles" '((emacs "25.1")) :commit "d500bc3c1f663719bfc9bf116914b06ababb850e" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
