;; Generated package description from geiser.el  -*- no-byte-compile: t -*-
(define-package "geiser" "0.22" "GNU Emacs and Scheme talk to each other" '((emacs "25.1") (transient "0.3")) :authors '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org")) :maintainer '("Jose Antonio Ortega Ruiz" . "jao@gnu.org") :keywords '("languages" "scheme" "geiser") :url "https://gitlab.com/emacs-geiser/")
