;;; crux.el --- A Collection of Ridiculously Useful eXtensions -*- lexical-binding: t -*-
;;
;; Copyright © 2015-2026 Bozhidar Batsov
;;
;; Author: Bozhidar Batsov <bozhidar@batsov.dev>
;; URL: https://github.com/bbatsov/crux
;; Version: 0.6.0
;; Keywords: convenience
;; Package-Requires: ((emacs "28.1"))

;; This file is not part of GNU Emacs.

;;; Commentary:

;; A cornucopia of useful interactive commands to make your Emacs
;; experience more enjoyable.

;;; License:

;; This program is free software; you can redistribute it and/or
;; modify it under the terms of the GNU General Public License
;; as published by the Free Software Foundation; either version 3
;; of the License, or (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs; see the file COPYING.  If not, write to the
;; Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
;; Boston, MA 02110-1301, USA.

;;; Code:

(require 'thingatpt)
(require 'seq)
(require 'subr-x)

(declare-function dired-get-file-for-visit "dired")
(declare-function org-element-property "org-element")
(declare-function org-element-context "org-element")
(defvar recentf-list)
(defvar recentf-mode)

(defgroup crux nil
  "A Collection of Ridiculously Useful eXtensions."
  :prefix "crux-"
  :group 'convenience)

(defcustom crux-indent-sensitive-modes
  '(conf-mode coffee-mode haml-mode python-mode python-ts-mode slim-mode
    yaml-mode yaml-ts-mode)
  "Modes for which auto-indenting is suppressed.
Modes derived from these are covered as well."
  :type '(repeat symbol)
  :group 'crux
  :package-version '(crux . "0.6.0"))

(defcustom crux-untabify-sensitive-modes
  '(makefile-bsdmake-mode)
  "Modes for which untabify is suppressed.
Modes derived from these are covered as well."
  :type '(repeat symbol)
  :group 'crux)

(defcustom crux-line-start-regex-alist
  '((term-mode . "^[^#$%>\n]*[#$%>] ")
    (eshell-mode . "^[^$\n]*\\$ ")
    (org-mode . "^[*[:space:]]* ")
    (default . "^[[:space:]]*"))
  "Alist of major modes and line starts.

The key is a major mode.  The value is a regular expression
matching the characters to be skipped over.  If no major mode is
found, use the regex specified by the default key.

Used by crux functions like `crux-move-beginning-of-line' to skip
over whitespace, prompts, and markup at the beginning of the line."
  :type '(repeat (cons symbol regexp))
  :group 'crux)


(defcustom crux-shell (getenv "SHELL")
  "The default shell to run with `crux-ansi-term'."
  :type 'string
  :group 'crux)

(defcustom crux-shell-zsh-init-files
  '("$HOME/.zshrc" "$HOME/.zlogin" "$HOME/.zprofile" "$HOME/.zshenv"
    "$HOME/.zlogout" "/etc/zshenv" "/etc/zprofile" "/etc/zshrc" "/etc/zlogin"
    "/etc/zlogout" "$ZDOTDIR/.zshrc" "$ZDOTDIR/.zlogin" "$ZDOTDIR/.zprofile"
    "$ZDOTDIR/.zshenv" "$ZDOTDIR/.zlogout")
  "The default init files of zsh."
  :type '(repeat string)
  :group 'crux)

(defcustom crux-shell-bash-init-files
  '("$BASH_ENV" "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.bash_login"
    "$HOME/.profile" "$HOME/.bash_logout" "/etc/bashrc" "/etc/bash_profile"
    "/etc/bash_login" "/etc/profile" "/etc/bash_logout")
  "The default init files of bash."
  :type '(repeat string)
  :group 'crux)

(defcustom crux-shell-tcsh-init-files
  '("$HOME/.login" "$HOME/.cshrc" "$HOME/.tcshrc" "$HOME/.logout"
    "/etc/csh.cshrc" "/etc/csh.login" "/etc/csh.logout")
  "The default init files of tcsh."
  :type '(repeat string)
  :group 'crux)

(defcustom crux-shell-fish-init-files
  '("$HOME/.config/fish/config.fish" "$XDG_CONFIG_HOME/fish/config.fish")
  "The default init files of fish."
  :type '(repeat string)
  :group 'crux)

(defcustom crux-shell-ksh-init-files
  '("$HOME/.profile" "$ENV" "/etc/profile")
  "The default init files of ksh."
  :type '(repeat string)
  :group 'crux)


(defcustom crux-term-func
  #'crux-ansi-term
  "The function used to start the term buffer if it's not already running.

It will be called with one argument: the expected name of the
term buffer."
  :type 'function
  :group 'crux)

(defcustom crux-shell-func
  #'crux-eshell
  "The function used to start the shell buffer if it's not already running.

It will be called with one argument: the expected name of the
shell buffer."
  :type 'function
  :group 'crux)

(defcustom crux-move-visually
  nil
  "Whether move-related commands should take visual lines into account or not."
  :type 'boolean
  :group 'crux
  :package-version '(crux . "0.4.0"))

(defun crux-ansi-term (buffer-name)
  "Start `ansi-term' with `crux-shell' in a buffer named BUFFER-NAME.
The default value of `crux-term-func'."
  (ansi-term crux-shell buffer-name))

(defvar eshell-buffer-name)

(defun crux-eshell (buffer-name)
  "Start `eshell' in a buffer named after BUFFER-NAME.
The default value of `crux-shell-func'."
  (let ((eshell-buffer-name (format "*%s*" buffer-name)))
    (eshell buffer-name)))

(defun crux-shell (buffer-name)
  "Start `shell' in a buffer named after BUFFER-NAME.
An alternative value for `crux-shell-func'."
  (shell (format "*%s*" buffer-name)))

;; TODO: When Emacs 30.1 is the minimum, open files from Dired with
;; `dired-do-open', which also handles marked files.  On 31.1+
;; `shell-command-do-open' could replace the per-OS program lookup.
;;;###autoload
(defun crux-open-with (arg)
  "Open visited file in default external program.
When in Dired mode, open file under the cursor.

With a prefix ARG always prompt for command to use."
  (interactive "P")
  (let ((file (if (derived-mode-p 'dired-mode)
                  (dired-get-file-for-visit)
                buffer-file-name))
        (open (pcase system-type
                (`darwin "open")
                ((or `gnu `gnu/linux `gnu/kfreebsd) "xdg-open"))))
    (unless file
      (user-error "Buffer is not visiting a file"))
    (if (and open (not arg))
        (call-process open nil 0 nil file)
      (call-process-shell-command
       (concat (read-shell-command "Open current file with: ")
               " "
               (shell-quote-argument file))
       nil 0))))

(defun crux-buffer-mode (buffer-or-name)
  "Retrieve the `major-mode' of BUFFER-OR-NAME."
  (with-current-buffer buffer-or-name
    major-mode))

(defvar crux-term-buffer-name "ansi-term"
  "The default buffer name used by `crux-visit-term-buffer'.
This variable can be set via .dir-locals.el to provide multi-term support.")
;;;###autoload
(put 'crux-term-buffer-name 'safe-local-variable #'stringp)

(defvar crux-shell-buffer-name "shell"
  "The default buffer name used by `crux-visit-shell-buffer'.
This variable can be set via .dir-locals.el to provide multi-term support.")
;;;###autoload
(put 'crux-shell-buffer-name 'safe-local-variable #'stringp)

(defun crux-start-or-switch-to (function buffer-name)
  "Invoke FUNCTION if there is no buffer with BUFFER-NAME.
Otherwise switch to the buffer named BUFFER-NAME.  Don't clobber
the current buffer."
  (if (not (get-buffer buffer-name))
      (progn
        (split-window-sensibly (selected-window))
        (other-window 1)
        (funcall function))
    (switch-to-buffer-other-window buffer-name)))

;;;###autoload
(defun crux-visit-term-buffer ()
  "Create or visit a terminal buffer.
If the process in that buffer died, ask to restart.

The buffer is named after `crux-term-buffer-name' and started with
`crux-term-func'."
  (interactive)
  (crux-start-or-switch-to (lambda ()
                             (funcall crux-term-func crux-term-buffer-name))
                           (format "*%s*" crux-term-buffer-name))
  (when (and (null (get-buffer-process (current-buffer)))
             (y-or-n-p "The process has died.  Do you want to restart it? "))
    (kill-buffer-and-window)
    (crux-visit-term-buffer)))

;;;###autoload
(defun crux-visit-shell-buffer ()
  "Create or visit a shell buffer.
If the process in that buffer died, ask to restart.

The buffer is named after `crux-shell-buffer-name' and started with
`crux-shell-func'."
  (interactive)
  (crux-start-or-switch-to (lambda ()
                             (funcall crux-shell-func crux-shell-buffer-name))
                           (format "*%s*" crux-shell-buffer-name))
  (when (and (null (get-buffer-process (current-buffer)))
             (not (derived-mode-p 'eshell-mode)) ; eshell has no process
             (y-or-n-p "The process has died.  Do you want to restart it? "))
    (kill-buffer-and-window)
    (crux-visit-shell-buffer)))

;;;###autoload
(defun crux-indent-rigidly-and-copy-to-clipboard (begin end arg)
  "Indent region between BEGIN and END by ARG columns and copy to clipboard."
  (interactive "r\nP")
  (let ((arg (or arg 4))
        (buffer (current-buffer)))
    (with-temp-buffer
      (insert-buffer-substring-no-properties buffer begin end)
      (indent-rigidly (point-min) (point-max) arg)
      (clipboard-kill-ring-save (point-min) (point-max)))))

;;;###autoload
(defun crux-smart-open-line-above ()
  "Insert an empty line above the current line.
Position the cursor at its beginning, according to the current mode."
  (interactive)
  (move-beginning-of-line nil)
  (insert "\n")
  (if electric-indent-inhibit
      ;; We can't use `indent-according-to-mode' in languages like Python,
      ;; as there are multiple possible indentations with different meanings.
      (let* ((indent-end (progn (crux-move-to-mode-line-start) (point)))
             (indent-start (progn (move-beginning-of-line nil) (point)))
             (indent-chars (buffer-substring indent-start indent-end)))
        (forward-line -1)
        ;; This new line should be indented with the same characters as
        ;; the current line.
        (insert indent-chars))
    ;; Just use the current major-mode's indent facility.
    (forward-line -1)
    (indent-according-to-mode)))

;;;###autoload
(defun crux-smart-open-line (arg)
  "Insert an empty line after the current line.
Position the cursor at its beginning, according to the current mode.

With a prefix ARG open line above the current line."
  (interactive "P")
  (if arg
      (crux-smart-open-line-above)
    (move-end-of-line nil)
    (newline-and-indent)))

;;;###autoload
(defun crux-smart-kill-line ()
  "Kill to the end of the line and kill whole line on the next call."
  (interactive)
  (let ((orig-point (point)))
    (move-end-of-line 1)
    (if (= orig-point (point))
        (crux-kill-whole-line)
      (goto-char orig-point)
      (kill-line))))

;;;###autoload
(defun crux-top-join-line ()
  "Join the current line with the line beneath it."
  (interactive)
  (delete-indentation 1))

;;;###autoload
(defun crux-kill-whole-line (&optional arg)
  "A simple wrapper around command `kill-whole-line' that respects indentation.
Passes ARG to command `kill-whole-line' when provided."
  (interactive "p")
  (kill-whole-line arg)
  (crux-move-to-mode-line-start))

;;;###autoload
(defun crux-kill-line-backwards ()
  "Kill line backwards and adjust the indentation."
  (interactive)
  (kill-line 0)
  (indent-according-to-mode))

;;;###autoload
(defun crux-kill-and-join-forward (&optional arg)
  "If at end of line, join with following; otherwise kill line.
Passes ARG to command `kill-line' when provided.
Deletes whitespace at join."
  (interactive "P")
  (if (and (eolp) (not (bolp)))
      (delete-indentation 1)
    (kill-line arg)))

;;;###autoload
(defun crux-move-to-mode-line-start ()
  "Move to the beginning, skipping mode specific line start regex."
  (interactive)

  (if crux-move-visually
      (beginning-of-visual-line nil)
    (move-beginning-of-line nil))

  (let ((line-start-regex (cdr (seq-find
                                (lambda (e) (derived-mode-p (car e)))
                                crux-line-start-regex-alist
                                (assoc 'default crux-line-start-regex-alist)))))
    (search-forward-regexp line-start-regex (line-end-position) t)))

;;;###autoload
(defun crux-move-beginning-of-line (arg)
  "Move point back to indentation of beginning of line.

Move point to the first non-whitespace character on this line.
If point is already there, move to the beginning of the line.
Effectively toggle between the first non-whitespace character and
the beginning of the line.

If ARG is not nil or 1, move forward ARG - 1 lines first.  If
point reaches the beginning or end of the buffer, stop there."
  (interactive "^p")
  (setq arg (or arg 1))

  ;; Move lines first
  (when (/= arg 1)
    (let ((line-move-visual nil))
      (forward-line (1- arg))))

  (let ((orig-point (point)))
    (crux-move-to-mode-line-start)
    (when (= orig-point (point))
      (move-beginning-of-line 1))))

;; TODO: When Emacs 30.1 is the minimum, consider making this obsolete in
;; favor of `prog-fill-reindent-defun' (bound to M-q in `prog-mode').
;;;###autoload
(defun crux-indent-defun ()
  "Indent the current defun."
  (interactive)
  (save-mark-and-excursion
    (mark-defun)
    (indent-region (region-beginning) (region-end))))

(defun crux--active-region-bounds ()
  "Return the bounds of the active region as a list, or nil."
  (when (use-region-p)
    (list (region-beginning) (region-end))))

(defun crux-get-positions-of-line-or-region ()
  "Return positions (beg . end) of the current line or region.
With an active region, cover all the lines it touches.  A region
ending at the very beginning of a line doesn't include that line."
  (if (use-region-p)
      (let ((beg (region-beginning))
            (end (region-end)))
        (save-excursion
          (goto-char end)
          (when (and (bolp) (> end beg))
            (backward-char))
          (setq end (line-end-position))
          (goto-char beg)
          (cons (line-beginning-position) end)))
    (cons (line-beginning-position) (line-end-position))))

(defun crux--duplicate-line-or-region (arg &optional comment)
  "Duplicate the current line or region ARG times.
When COMMENT is non-nil, comment out the original text.  Point ends
up in the last copy, at the same relative position."
  (pcase-let* ((origin (point))
               (`(,beg . ,end) (crux-get-positions-of-line-or-region))
               (text (buffer-substring-no-properties beg end))
               (offset (min (- origin beg) (length text))))
    (when (> arg 0)
      (when comment
        (setq end (copy-marker end t))
        (comment-region beg end))
      (goto-char end)
      (dotimes (_ arg)
        (insert "\n" text))
      (goto-char (+ (- (point) (length text)) offset)))))

;; TODO: When Emacs 29.1 is the minimum, make this obsolete in favor of
;; `duplicate-dwim'.  The comment variant below has no upstream
;; counterpart, so it stays.
;;;###autoload
(defun crux-duplicate-current-line-or-region (arg)
  "Duplicate the current line or region ARG times.
If there's no region, the current line will be duplicated.  However, if
there's a region, all lines that region covers will be duplicated."
  (interactive "p")
  (crux--duplicate-line-or-region arg))

;;;###autoload
(defun crux-duplicate-and-comment-current-line-or-region (arg)
  "Duplicate the current line or region ARG times, commenting out the original.
If there's no region, the current line will be duplicated.  However, if
there's a region, all lines that region covers will be duplicated."
  (interactive "p")
  (crux--duplicate-line-or-region arg t))

;; TODO: When Emacs 29.1 is the minimum, consider building on
;; `rename-visited-file', keeping only the VC handling on top of it.
;;;###autoload
(defun crux-rename-file-and-buffer ()
  "Rename the current buffer and the file it is visiting.
If the new name is a directory, move the file there, keeping its
name.  Files under version control are renamed with `vc-rename-file'.
In a buffer that is not visiting a file, just rename the buffer."
  (interactive)
  (if-let* ((filename (buffer-file-name)))
      (let ((new-name (read-file-name "New name: " (file-name-directory filename) nil 'confirm)))
        (when (or (directory-name-p new-name) (file-directory-p new-name))
          (setq new-name (expand-file-name (file-name-nondirectory filename) new-name)))
        ;; make sure the current buffer is saved and backed by some file
        (when (or (buffer-modified-p) (not (file-exists-p filename)))
          (if (y-or-n-p "Can't move file before saving it.  Would you like to save it now? ")
              (save-buffer)
            (user-error "Rename aborted")))
        (when (get-file-buffer new-name)
          (user-error "There already exists a buffer visiting %s" new-name))
        (make-directory (file-name-directory new-name) t)
        (if (vc-backend filename)
            ;; vc-rename-file seems not able to cope with remote filenames?
            (vc-rename-file (file-local-name filename) (file-local-name new-name))
          (rename-file filename new-name t)
          (set-visited-file-name new-name t t)))
    (call-interactively #'rename-buffer)))

(defalias 'crux-rename-buffer-and-file #'crux-rename-file-and-buffer)

;;;###autoload
(defun crux-delete-file-and-buffer ()
  "Kill the current buffer and delete the file it is visiting."
  (interactive)
  (let ((filename (buffer-file-name)))
    (when filename
      (if (vc-backend filename)
          (vc-delete-file filename)
        (when (y-or-n-p (format "Are you sure you want to delete %s? " filename))
          (delete-file filename delete-by-moving-to-trash)
          (message "Deleted file %s" filename)
          (kill-buffer))))))

(defalias 'crux-delete-buffer-and-file #'crux-delete-file-and-buffer)

;;;###autoload
(defun crux-copy-file-preserve-attributes (visit)
  "Copy the current file-visiting buffer's file to a destination.

This function prompts for the new file's location and copies it
similar to cp -p.  If the new location is a directory, and the
directory does not exist, this function confirms with the user
whether it should be created.  A directory must end in a slash
like `copy-file' expects.  If the destination is a directory and
already has a file named as the origin file, offers to
overwrite.

If the current buffer is not a file-visiting file or the
destination is a non-existent directory but the user has elected
to not create it, nothing will be done.

With a prefix argument VISIT, visit the new file in another window."
  (interactive "P")
  (when-let* ((current-file (buffer-file-name)))
    (let* ((input-dest (expand-file-name (read-file-name "Copy file to: ")))
           (input-dest-is-dir? (or (file-directory-p input-dest)
                                   (directory-name-p input-dest)))
           (dest-file (if input-dest-is-dir?
                          (expand-file-name (file-name-nondirectory current-file) input-dest)
                        input-dest))
           (dest-dir (file-name-directory dest-file))
           (dest-dir-missing? (not (file-directory-p dest-dir)))
           (create-dir? (and dest-dir-missing?
                             (y-or-n-p
                              (format "%s is a non-existent directory, create it? " dest-dir))))
           (dest-file-exists? (file-regular-p dest-file))
           (overwrite-dest-file? (and dest-file-exists?
                                      (y-or-n-p
                                       (format "%s already exists, overwrite? " dest-file)))))
      (unless (or (and dest-dir-missing? (not create-dir?))
                  (and dest-file-exists? (not overwrite-dest-file?)))
        (when (and dest-dir-missing? create-dir?)
          (make-directory dest-dir t))
        (copy-file current-file dest-file overwrite-dest-file? t t t)
        (message "Wrote %s" dest-file)
        (when visit
          (find-file-other-window dest-file))))))

;;;###autoload
(defun crux-view-url ()
  "Open a new buffer containing the contents of URL."
  (interactive)
  (let* ((default (if (derived-mode-p 'org-mode)
                      (org-element-property :raw-link (org-element-context))
                    (thing-at-point-url-at-point)))
         (url (read-from-minibuffer "URL: " default))
         (buffer (or (url-retrieve-synchronously url)
                     (user-error "Couldn't retrieve %s" url))))
    (switch-to-buffer buffer)
    (rename-buffer url t)
    ;; drop the HTTP headers; other protocols don't have any
    (when (bound-and-true-p url-http-end-of-headers)
      ;; the marker sits right before the blank line ending the headers
      (delete-region (point-min) (1+ url-http-end-of-headers)))
    (goto-char (point-min))
    (set-auto-mode)))

;;;###autoload
(defun crux-cleanup-buffer-or-region ()
  "Cleanup a region if selected, otherwise the whole buffer.
Untabify and reindent the text, then run `whitespace-cleanup'.
Modes listed in `crux-untabify-sensitive-modes' and
`crux-indent-sensitive-modes' (and modes derived from them) skip
the respective step."
  (interactive)
  (let* ((region (use-region-p))
         (beg (if region (region-beginning) (point-min)))
         (end (copy-marker (if region (region-end) (point-max)))))
    ;; TODO: When Emacs 30.1 is the minimum, pass the lists straight to
    ;; `derived-mode-p', which accepts a list of modes there.
    (unless (seq-some #'derived-mode-p crux-untabify-sensitive-modes)
      (untabify beg end))
    (unless (seq-some #'derived-mode-p crux-indent-sensitive-modes)
      (indent-region beg end))
    (if region
        (whitespace-cleanup-region beg end)
      ;; `whitespace-cleanup' would restrict itself to an empty active region
      (let ((mark-active nil))
        (whitespace-cleanup)))
    (set-marker end nil)))

;;;###autoload
(defun crux-eval-and-replace ()
  "Replace the preceding sexp with its value."
  (interactive)
  (let ((value (eval (elisp--preceding-sexp) lexical-binding)))
    (backward-kill-sexp)
    (insert (format "%S" value))))

;;;###autoload
(defun crux-recompile-init ()
  "Byte-compile all your dotfiles again."
  (declare (obsolete "use `byte-compile-file' on the files that need it."
                     "0.6.0"))
  (interactive)
  (byte-recompile-directory user-emacs-directory 0))

(defun crux-file-owner-uid (filename)
  "Return the UID of the FILENAME as an integer.

See `file-attributes' for more info."
  (file-attribute-user-id (file-attributes filename 'integer)))

(defun crux-file-owned-by-user-p (filename)
  "Return t if file FILENAME is owned by the currently logged in user."
  (equal (crux-file-owner-uid filename)
         (user-uid)))

(defun crux-already-root-p (&optional filename)
  "Return non-nil if FILENAME is already being accessed as root.
FILENAME defaults to `default-directory'."
  (let* ((filename (or filename default-directory))
         (method (file-remote-p filename 'method)))
    (and method
         (or (member method '("sudo" "su" "ksu" "doas"))
             (equal (file-remote-p filename 'user) "root")))))

;; TODO: When Emacs 30.1 is the minimum, drop this fallback, as
;; `tramp-file-name-with-sudo' is always available.
(defun crux--sudo-hop-file-name (filename)
  "Return remote FILENAME with an extra sudo hop on the same host.
Used when `tramp-file-name-with-sudo' isn't available."
  (let ((host (car (split-string (or (file-remote-p filename 'host) "") "#"))))
    (format "%s|sudo:root@%s:%s"
            (string-remove-suffix ":" (file-remote-p filename))
            ;; IPv6 addresses need brackets; the port belongs to the outer hop only
            (if (string-search ":" host) (format "[%s]" host) host)
            (file-local-name filename))))

(defvar tramp-file-name-with-method)

;; TODO: When Emacs 30.1 is the minimum, consider dropping the doas
;; detection and pointing doas users at `tramp-file-name-with-method',
;; so that local files can go through `tramp-file-name-with-sudo' too.
(defun crux--local-root-method ()
  "Return the TRAMP method for opening local files as root.
Honor `tramp-file-name-with-method' when it's set to something other
than its default, and otherwise use doas if it's available and sudo
if it isn't."
  (if (and (boundp 'tramp-file-name-with-method)
           (not (equal tramp-file-name-with-method "sudo")))
      tramp-file-name-with-method
    (if (executable-find "doas") "doas" "sudo")))

(defun crux--root-file-name (filename)
  "Return a TRAMP file name for editing FILENAME as root.
Local files use the method from `crux--local-root-method'.  Remote
files get an extra sudo hop on the same host, built by
`tramp-file-name-with-sudo' when it's available (Emacs 30.1+)."
  (let ((filename (expand-file-name filename)))
    (cond
     ((not (file-remote-p filename))
      (format "/%s:root@localhost:%s" (crux--local-root-method) filename))
     ((and (require 'tramp-cmds nil t)
           (fboundp 'tramp-file-name-with-sudo))
      (tramp-file-name-with-sudo filename))
     (t (crux--sudo-hop-file-name filename)))))

(defun crux-find-alternate-file-as-root (filename)
  "Wrap `find-alternate-file' to open FILENAME as root."
  (find-alternate-file (crux--root-file-name filename)))

;;;###autoload
(defun crux-sudo-edit (&optional arg)
  "Edit currently visited file as root.

With a prefix ARG prompt for a file to visit.
Will also prompt for a file to visit if current
buffer is not visiting a file."
  (interactive "P")
  (if (or arg (not buffer-file-name))
      (let ((file (read-file-name "Find file (as root): ")))
        (find-file (if (crux-already-root-p file)
                       file
                     (crux--root-file-name file))))
    (if (crux-already-root-p buffer-file-name)
        (message "Already editing this file as root.")
      (let ((place (point)))
        (crux-find-alternate-file-as-root buffer-file-name)
        (goto-char place)))))

(defun crux--emacs-file-p (filename)
  "Return non-nil if FILENAME belongs to Emacs or a package on `load-path'.
That covers the Lisp and C sources `find-function' and friends visit,
also when they're reached through a symlink."
  (let ((roots (list
                ;; the installation directory, which holds lisp/ and etc/
                (file-name-directory (directory-file-name data-directory))
                source-directory))
        (lisp-dirs (mapcar #'file-name-as-directory
                           (seq-filter (lambda (dir)
                                         (and dir (file-name-absolute-p dir)))
                                       load-path))))
    (seq-some
     (lambda (file)
       (let ((dir (file-name-directory file)))
         (or (seq-some (lambda (root)
                         (and root (string-prefix-p
                                    (file-name-as-directory (expand-file-name root))
                                    dir)))
                       roots)
             (seq-some (lambda (lisp-dir)
                         (string= dir (expand-file-name lisp-dir)))
                       lisp-dirs))))
     (list (expand-file-name filename) (file-truename filename)))))

;;;###autoload
(defun crux-reopen-as-root ()
  "Find file as root if necessary.

Files belonging to Emacs itself or to packages on `load-path' are
left alone, as they're usually visited just to read them.

Meant to be used as `find-file-hook'.
See also `crux-reopen-as-root-mode'."
  (unless (or (file-remote-p buffer-file-name)
              (derived-mode-p 'dired-mode)
              (not (file-exists-p (file-name-directory buffer-file-name)))
              (file-writable-p buffer-file-name)
              (crux-file-owned-by-user-p buffer-file-name)
              (crux--emacs-file-p buffer-file-name))
    (crux-find-alternate-file-as-root buffer-file-name)))

;;;###autoload
(define-minor-mode crux-reopen-as-root-mode
  "Automatically reopen files as root when they aren't writable.
Files that the current user can't write to, and doesn't own, get
reopened through sudo (or doas) when visited.  Files belonging to
Emacs itself or to packages on `load-path' are left alone."
  :global t
  :group 'crux
  (if crux-reopen-as-root-mode
      (add-hook 'find-file-hook #'crux-reopen-as-root)
    (remove-hook 'find-file-hook #'crux-reopen-as-root)))

;;;###autoload
(defun crux-insert-date ()
  "Insert a timestamp according to locale's date and time format."
  (interactive)
  (insert (format-time-string "%c")))

;;;###autoload
(defun crux-keyboard-quit-dwim ()
  "Do-What-I-Mean behaviour for a general `keyboard-quit'.

The generic `keyboard-quit' does not do the expected thing when
the minibuffer is open.  Whereas we want it to close the
minibuffer, even without explicitly focusing it.

The DWIM behaviour of this command is as follows:

- When the region is active, disable it.
- When a minibuffer is open, but not focused, close the minibuffer.
- When the Completions buffer is selected, close it.
- In every other case use the regular `keyboard-quit'."
  (interactive)
  (cond
   ((region-active-p)
    (keyboard-quit))
   ((derived-mode-p 'completion-list-mode)
    (delete-completion-window))
   ((> (minibuffer-depth) 0)
    (abort-recursive-edit))
   (t
    (keyboard-quit))))

;; TODO: When Emacs 29.1 is the minimum, make this obsolete in favor of
;; `recentf-open'.  `crux-recentf-find-directory' has no upstream
;; counterpart, so it would need its own completion code.
;;;###autoload
(defun crux-recentf-find-file (&optional filter)
  "Find a recent file using `completing-read'.
When optional argument FILTER is a function, it is used to
transform recent files before completion.
Enable `recentf-mode' if it isn't already."
  (interactive)
  (require 'recentf)
  (unless recentf-mode
    (recentf-mode 1))
  (let* ((filter (if (functionp filter) filter #'abbreviate-file-name))
         (file (completing-read "Choose recent file: "
                                (delete-dups (mapcar filter recentf-list))
                                nil t)))
    (when file
      (find-file file))))

(define-obsolete-function-alias 'crux-recentf-ido-find-file #'crux-recentf-find-file "0.4.0")

;;;###autoload
(defun crux-recentf-find-directory ()
  "Find a recent directory using `completing-read'."
  (interactive)
  (crux-recentf-find-file (lambda (file) (abbreviate-file-name (file-name-directory file)))))

;;;###autoload
(defun crux-transpose-windows (arg)
  "Swap the current window with another one.
The other window is the one `other-window' would select with ARG, so
a negative ARG swaps with a previous window.  The current buffer moves
into the other window, together with point, and stays selected."
  (interactive "p")
  (let ((this-win (selected-window)))
    (other-window arg)
    (let ((other-win (selected-window)))
      (window-swap-states this-win other-win)
      (select-window other-win))))

(defalias 'crux-swap-windows #'crux-transpose-windows)

;;;###autoload
(defun crux-switch-to-previous-buffer ()
  "Switch to previously open buffer.
Repeated invocations toggle between the two most recently open buffers."
  (interactive)
  (switch-to-buffer (other-buffer (current-buffer) 1)))

;;;###autoload
(defun crux-other-window-or-switch-buffer ()
  "Call `other-window' if more than one window is visible.
Switch to most recent buffer otherwise."
  (interactive)
  (if (one-window-p)
      (switch-to-buffer nil)
    (other-window 1)))

;;;###autoload
(defun crux-kill-other-buffers ()
  "Kill all file-visiting buffers but the current one.
Doesn't mess with special buffers."
  (interactive)
  (when (y-or-n-p "Are you sure you want to kill all buffers but the current one? ")
    (seq-each
     #'kill-buffer
     (delete (current-buffer) (seq-filter #'buffer-file-name (buffer-list))))))

;;;###autoload
(defun crux-kill-buffer-truename ()
  "Kill absolute path of file visited in current buffer."
  (interactive)
  (if buffer-file-name
      (let ((truename (file-truename buffer-file-name)))
        (kill-new truename)
        (message "Added %s to kill ring." truename))
    (message "Buffer is not visiting a file.")))

;;;###autoload
(defun crux-create-scratch-buffer ()
  "Create a new scratch buffer."
  (interactive)
  (let ((buf (generate-new-buffer "*scratch*")))
    (switch-to-buffer buf)
    (funcall initial-major-mode)))

;;;###autoload
(defun crux-find-user-init-file ()
  "Edit the `user-init-file', in another window."
  (interactive)
  (unless user-init-file
    (user-error "No init file was loaded in this session"))
  (find-file-other-window user-init-file))

;;;###autoload
(defun crux-find-user-custom-file ()
  "Edit the `custom-file', in another window."
  (interactive)
  (if custom-file
      (find-file-other-window custom-file)
    (message "No custom file found.")))

;;;###autoload
(defun crux-find-shell-init-file ()
  "Edit the shell init file in another window."
  (interactive)
  (let* ((shell (file-name-nondirectory (or (getenv "SHELL")
                                             (user-error "SHELL is not set"))))
         (shell-init-file (cond
                           ((string= "zsh" shell) crux-shell-zsh-init-files)
                           ((string= "bash" shell) crux-shell-bash-init-files)
                           ((string= "tcsh" shell) crux-shell-tcsh-init-files)
                           ((string= "fish" shell) crux-shell-fish-init-files)
                           ((string-prefix-p "ksh" shell) crux-shell-ksh-init-files)
                           (t (user-error "Unknown shell: %s" shell))))
         (candidates (seq-filter #'file-exists-p
                                 (mapcar #'substitute-in-file-name shell-init-file))))
    (pcase candidates
      ('() (user-error "No %s init files found" shell))
      (`(,file) (find-file-other-window file))
      (_ (find-file-other-window
          (completing-read "Choose shell init file: " candidates nil t))))))

;;;###autoload
(defun crux-find-current-directory-dir-locals-file (find-2)
  "Edit the `.dir-locals.el' file for the current buffer in another window.
If prefix arg FIND-2 is set then edit the `.dir-locals-2.el' file instead
of `.dir-locals.el'.

Scans parent directories if the file does not exist in
the default directory of the current buffer.  If not found, create a new,
empty buffer in the current buffer's default directory, or if there is no
such directory, in the user's home directory."
  (interactive "P")
  (let* ((file (if find-2
                   (concat (file-name-sans-extension dir-locals-file) "-2.el")
                 dir-locals-file))
         (starting-dir (or (when (and default-directory
                                      (file-readable-p default-directory))
                             default-directory)
                           (file-truename "~/")))
         (found-dir (or (locate-dominating-file starting-dir file) starting-dir))
         (found-file (concat found-dir file)))
    (find-file-other-window found-file)
    (if (file-exists-p found-file)
        (message "Editing existing file %s" found-file)
      (message "Editing new file %s" found-file))))

;;;###autoload
(defun crux-upcase-region (&optional beg end)
  "Upcase the text between BEG and END if the region is active.
Unlike `upcase-region', do nothing without an active region, so it
is safe to bind to keys that are easy to hit by accident."
  (interactive (crux--active-region-bounds))
  (when (and beg end (use-region-p))
    (upcase-region beg end)))

;;;###autoload
(defun crux-downcase-region (&optional beg end)
  "Downcase the text between BEG and END if the region is active.
Unlike `downcase-region', do nothing without an active region, so it
is safe to bind to keys that are easy to hit by accident."
  (interactive (crux--active-region-bounds))
  (when (and beg end (use-region-p))
    (downcase-region beg end)))

;;;###autoload
(defun crux-capitalize-region (&optional beg end)
  "Capitalize the text between BEG and END if the region is active.
Unlike `capitalize-region', do nothing without an active region, so
it is safe to bind to keys that are easy to hit by accident."
  (interactive (crux--active-region-bounds))
  (when (and beg end (use-region-p))
    (capitalize-region beg end)))

;; http://endlessparentheses.com/ispell-and-abbrev-the-perfect-auto-correct.html
;;;###autoload
(defun crux-ispell-word-then-abbrev (p)
  "Call `ispell-word', then create an abbrev for it.
With prefix P, create local abbrev.  Otherwise it will
be global.
If there's nothing wrong with the word at point, keep
looking for a typo until the beginning of buffer.  You can
skip typos you don't want to fix with `SPC', and you can
abort completely with `C-g'."
  (interactive "P")
  (let (bef aft)
    (save-excursion
      (while (if (setq bef (thing-at-point 'word))
                 ;; Word was corrected or used quit.
                 (if (ispell-word nil 'quiet)
                     nil ; End the loop.
                   ;; Also end if we reach `bob'.
                   (not (bobp)))
               ;; If there's no word at point, keep looking
               ;; until `bob'.
               (not (bobp)))
        (backward-word))
      (setq aft (thing-at-point 'word)))
    (if (and aft bef (not (equal aft bef)))
        (let ((aft (downcase aft))
              (bef (downcase bef)))
          (define-abbrev
            (if p local-abbrev-table global-abbrev-table)
            bef aft)
          (message "\"%s\" now expands to \"%s\" %sally"
                   bef aft (if p "loc" "glob")))
      (user-error "No typo at or before point"))))

(defmacro crux--advise-with-fallback-region (func suffix bounds)
  "Advise FUNC to act on the region, or on BOUNDS without one.
BOUNDS is a form evaluated at call time that returns a list of the
start and end positions to use.  The advice is named after FUNC
and SUFFIX, so that it can be removed with `advice-remove'."
  (let ((advice-name (intern (format "crux-%s-%s" func suffix))))
    `(progn
       (defun ,advice-name (orig-fn &rest args)
         (interactive
          (if (use-region-p)
              (list (region-beginning) (region-end))
            ,bounds))
         (apply orig-fn args))
       (advice-add #',func :around #',advice-name))))

(defmacro crux-with-region-or-buffer (func)
  "When called with no active region, call FUNC on current buffer.

Use to make commands like `indent-region' work on both the region
and the entire buffer (in the absence of a region)."
  `(crux--advise-with-fallback-region
    ,func "region-or-buffer"
    (list (point-min) (point-max))))

(defmacro crux-with-region-or-line (func)
  "When called with no active region, call FUNC on current line."
  `(crux--advise-with-fallback-region
    ,func "region-or-line"
    (list (line-beginning-position) (line-beginning-position 2))))

(defmacro crux-with-region-or-sexp-or-line (func)
  "When called with no active region, call FUNC on current sexp/string, or line."
  `(crux--advise-with-fallback-region
    ,func "region-or-sexp-or-line"
    (cond
     ((nth 3 (syntax-ppss)) (flatten-list (bounds-of-thing-at-point 'string)))
     ((thing-at-point 'list) (flatten-list (bounds-of-thing-at-point 'list)))
     (t (list (line-beginning-position) (line-beginning-position 2))))))

(defmacro crux-with-region-or-point-to-eol (func)
  "When called with no active region, call FUNC from the point to the end of line."
  `(crux--advise-with-fallback-region
    ,func "region-or-point-to-eol"
    (list (point) (line-end-position))))

(provide 'crux)
;;; crux.el ends here
