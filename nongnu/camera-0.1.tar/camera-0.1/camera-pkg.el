;; Generated package description from camera.el  -*- no-byte-compile: t -*-
(define-package "camera" "0.1" "Take picture with your camera" '((emacs "25.1")) :commit "81484db26b0317e8df6ce3dc3cb1000c3a727e1e" :authors '(("Akib Azmain Turja" . "akib@disroot.org")) :maintainer '("Akib Azmain Turja" . "akib@disroot.org") :keywords '("comm") :url "https://codeberg.org/akib/emacs-camera")
