;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.2.7" "A major mode for editing subtitles" '((emacs "25.1")) :commit "c9e3ec9963fcc95050fe8a73ce978bebe2ac41ac" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
