;; Generated package description from helm-core.el  -*- no-byte-compile: t -*-
(define-package "helm-core" "3.9.6" "Development files for Helm" '((emacs "25.1") (async "1.9.7")) :commit "d1f10e5a998254a763304a925963dc6d54e934b1" :authors '(("Thierry Volpiatto" . "thievol@posteo.net")) :maintainer '("Thierry Volpiatto" . "thievol@posteo.net") :url "https://emacs-helm.github.io/helm/")
