;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.8.3" "annotate files without changing them" 'nil :commit "6c6946c6a59492eb94bcf680b2db6b144d441115" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
