;; Generated package description from keycast.el  -*- no-byte-compile: t -*-
(define-package "keycast" "1.1.3" "Show current command and its key in the mode line" '((emacs "25.3")) :commit "b4965ff5db0e913e58c906c228042921b22335a0" :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :url "https://github.com/tarsius/keycast")
