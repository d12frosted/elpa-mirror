;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.26" "A major mode for editing subtitles" '((emacs "25.1")) :commit "7563c61b7e152e0c7e06387edf98809c08cb134f" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
