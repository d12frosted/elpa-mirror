;;; au-aurum-night-theme.el --- Warm dark theme with a low blue-light share -*- lexical-binding:t -*-

;; Copyright (C) 2026  Szymon Wilczek

;; Author: Szymon Wilczek <swilczek.lx@gmail.com>
;; URL: https://github.com/szymonwilczek/au-themes
;; Keywords: faces, themes, accessibility, autism, neurodivergence

;; This file is not part of GNU Emacs.

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Dark theme with amber and gold tones on deep background.
;; Calibrated for nocturnal light sensitivity and low melanopic excitation
;; to protect evening melatonin.
;; Part of the `au-themes' collection.

;;; Code:

(require 'modus-themes)
(require 'au-themes)

(defconst au-themes-aurum-night-palette-partial
  '(;; Canvas & Chrome
    (cursor "#dca032")                    ; Point / cursor indicator
    (bg-main "#12100e")                   ; Primary canvas background
    (bg-dim "#1c1815")                    ; Inactive windows, dim canvas
    (bg-alt "#28221e")                    ; Subtle borders, alternating stripes
    (fg-main "#a9a18d")                   ; Default buffer text
    (fg-dim "#61584a")                    ; Comments, metadata
    (fg-alt "#87917a")                    ; Struct properties
    (fg-var "#aa8f55")                    ; Variable definitions
    (bg-active "#3e3228")                 ; Active modeline frame, focused bars
    (bg-inactive "#1c1815")               ; Inactive modeline
    (border "#44382e")                    ; Window dividers

    ;; Basic Chromatic Scale
    (red "#bc4c41")                       ; Errors, critical warnings
    (red-warmer "#9e5467")                ; String literals
    (red-cooler "#a44638")                ; Diff deletions, removal markers
    (red-faint "#84786a")                 ; Structural brackets

    (green "#d29165")                     ; Primitive types
    (green-warmer "#a14d27")              ; Constant values and macros
    (green-cooler "#aa762b")              ; Control keywords
    (green-faint "#61584a")               ; Documentation strings, inline comments

    (yellow "#a97a3a")                    ; Keyword alias
    (yellow-warmer "#caa042")             ; Numeric literals
    (yellow-cooler "#af7d65")             ; Preprocessor directives
    (yellow-faint "#7a6e5c")              ; Informational tooltips, fringe markers

    (blue "#98683c")                      ; Function definitions
    (blue-warmer "#b86965")               ; Function calls
    (blue-cooler "#847a6c")               ; Binary and unary operators
    (blue-faint "#6b7c5a")                ; Built-in functions

    (magenta "#d2956a")                   ; Composite types: struct, union, enum
    (magenta-warmer "#b26457")            ; Extended library types
    (magenta-cooler "#af7d65")            ; Rare syntax nodes, special escapes
    (magenta-faint "#61584a")             ; Inactive conditional blocks

    (cyan "#a97a3a")                      ; Keyword fallback
    (cyan-warmer "#af7d65")               ; Preprocessor alias
    (cyan-cooler "#847a6c")               ; Operator alias
    (cyan-faint "#7b7061")                ; Punctuation delimiters

    ;; Panels, Diffs and Structural Highlights
    (bg-red-intense "#6a1c16")            ; Blocking errors, fatal assertion panel
    (bg-green-intense "#342e14")          ; Success banner
    (bg-yellow-intense "#583e10")         ; Warning banner, review request
    (bg-blue-intense "#483018")           ; Info banner, active selections
    (bg-magenta-intense "#422018")        ; Special prompt background
    (bg-cyan-intense "#483614")           ; Incsearch current match target

    (bg-red-subtle "#341612")             ; Diff context deletion background
    (bg-green-subtle "#221e10")           ; Diff context addition background
    (bg-yellow-subtle "#2e2210")          ; Diff whitespace/context change
    (bg-blue-subtle "#2e2216")            ; Mode-line subtle indicators
    (bg-magenta-subtle "#2c1c16")         ; Matching paren context background
    (bg-cyan-subtle "#262012")            ; Structural block highlight

    (bg-added "#1e3412")                  ; Diff added line baseline
    (bg-added-faint "#12260a")            ; Diff added unchanged context
    (bg-added-refine "#2c481a")           ; Diff added word-level highlight
    (fg-added "#a0c57a")                  ; Diff added foreground text

    (bg-changed "#362e08")                ; Diff changed line baseline
    (bg-changed-faint "#262004")          ; Diff changed unchanged context
    (bg-changed-refine "#4a420e")         ; Diff changed word-level highlight
    (fg-changed "#d5b759")                ; Diff changed foreground text

    (bg-removed "#46140e")                ; Diff removed line baseline
    (bg-removed-faint "#320c08")          ; Diff removed unchanged context
    (bg-removed-refine "#641c14")         ; Diff removed word-level highlight
    (fg-removed "#eba69e")                ; Diff removed foreground text

    (bg-mode-line-active "#221c18")       ; Active modeline surface
    (fg-mode-line-active "#b2a47e")       ; Active modeline primary text
    (bg-completion "#26201a")             ; Minibuffer completion selected row
    (bg-popup "#181412")                  ; Autocomplete tooltip surface
    (bg-hover "#342a22")                  ; Mouse hover overlay
    (bg-hover-secondary "#3e2e38")        ; Secondary hover overlay
    (bg-hl-line "#1e1915")                ; Current line indicator
    (bg-paren-match "#3c3822")            ; Matching delimiter highlight
    (bg-err "#3a1410")                    ; Flymake error inline box
    (bg-warning "#34260a")                ; Flymake warning inline box
    (bg-info "#1e2c14")                   ; Flymake info inline box
    (bg-region "#403222")                 ; Marked region
    (fg-line-number-inactive "#62584c"))) ; Inactive line numbers margin

(defconst au-themes-aurum-night-palette-mappings-partial
  '((err red)
    (warning yellow-warmer)
    (info green)

    (fg-link blue-warmer)
    (fg-link-visited blue)
    (name blue)
    (keybind red)
    (identifier fg-alt)
    (fg-prompt yellow-warmer)

    ;; Syntax Mappings:
    (keyword green-cooler)
    (builtin blue-faint)
    (type green)
    (preprocessor yellow-cooler)
    (constant green-warmer)
    (number yellow-warmer)
    (fnname blue)
    (fnname-call blue-warmer)
    (string red-warmer)
    (property fg-alt)
    (variable fg-var)
    (variable-use fg-main)
    (operator blue-cooler)
    (bracket red-faint)
    (delimiter cyan-faint)
    (comment green-faint)
    (docstring green-faint)
    (rx-backslash yellow-cooler)
    (rx-construct red)

    (accent-0 yellow-warmer)
    (accent-1 green)
    (accent-2 blue)
    (accent-3 green-warmer)))

(defconst au-themes-aurum-night-palette
  (modus-themes-generate-palette
   au-themes-aurum-night-palette-partial
   nil
   nil
   (append au-themes-aurum-night-palette-mappings-partial au-themes-palette-common)))

;;;###theme-autoload
(modus-themes-theme
 'au-aurum-night
 'au-themes
 "Warm dark theme with a low blue-light share, calibrated for nocturnal photophobia."
 'dark
 'au-themes-aurum-night-palette
 nil
 nil)

(provide 'au-aurum-night-theme)
;;; au-aurum-night-theme.el ends here
