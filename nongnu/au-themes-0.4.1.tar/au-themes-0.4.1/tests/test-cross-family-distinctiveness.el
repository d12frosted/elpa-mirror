;;; test-cross-family-distinctiveness.el --- Cross-package theme divergence and anti-cloning gate -*- lexical-binding: t -*-

;; Copyright (C) 2026  Szymon Wilczek

;; Author: Szymon Wilczek <swilczek.lx@gmail.com>
;; URL: https://github.com/szymonwilczek/au-themes

;; This file is not part of GNU Emacs.

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Verification of chromatic divergence and anti-cloning separation
;; between theme families (aurum, herbarium, mysterium, parchment,
;; perseida, pluvia, salina, whispergrove, yerba).  Each theme is
;; compared with every theme of the same polarity in the other
;; families, and must also hold its own family's chromatic signature:
;; the hue envelope of the selection region, plus the chroma ceiling
;; for parchment, the non-green data type for aurum's light variant,
;; the optically black canvas of perseida's dark variant, the cool
;; pearl canvas of its light variant, the dry leaf canvas of yerba,
;; the grey text and fogged pane region of pluvia and the teal
;; keywords of mysterium.
;;
;; Pairs listed in `au-cross-family-exemptions' are skipped, each with
;; its reason.
;;
;; The 10 dE00 per-role and 18 dE00 mean separations are informational:
;; a pair under them is reported as NOTE and does not fail the module.
;; Each family is built from its own named objects, and two families may
;; legitimately share one (a carrot is orange in any of them).
;;
;; Basis: CIEDE2000 (CIE 142-2001).  The 10 and 18 dE00 separations and
;; every family signature are au-themes heuristics; they keep the
;; families from converging, they do not model perception.
;;
;; This test is tailored specifically for au-themes, it will not serve
;; any good purpose in any other package/themes.

;;; Code:

(require 'test-palette-extractor)

(defconst au-cross-family-exemptions nil
  "Declared (THEME . FAMILY) pairs that are not compared with each other.
Each entry needs a reason in this docstring.  There are none: every
theme is compared with every other family.")

(defun au-cross-family-exempt-p (theme other)
  "Return non-nil when THEME and OTHER form a declared exemption."
  (or (member (cons theme (au-theme-family other)) au-cross-family-exemptions)
      (member (cons other (au-theme-family theme)) au-cross-family-exemptions)))

(defun au-theme-counterparts (theme)
  "Return the counterpart themes in other families for THEME."
  (let ((this-family (au-theme-family theme))
        (this-polarity (rf-theme-polarity theme)))
    (cl-remove-if-not
     (lambda (th)
       (and (not (eq (au-theme-family th) this-family))
            (eq (rf-theme-polarity th) this-polarity)
            (not (au-cross-family-exempt-p theme th))))
     (au-test-discover-themes))))

(defun test-cross-family-distinctiveness-run ()
  "Evaluate that themes from different families do not clone each other.
Checks shared hex codes, per-role and mean CIEDE2000 separation, and the
family's own chromatic signature."
  (let* ((theme (or rf-active-theme (car (au-test-discover-themes))))
         (pal (au-extract-active-palette theme))
         (family (au-theme-family theme))
         (polarity (rf-theme-polarity theme))
         (passes 0)
         (fails 0)
         (counterparts (au-theme-counterparts theme)))

    (princ (format "\n.~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~.\n"))
    (princ (format "| Cross-Family Distinctiveness and Palette Anti-Cloning Suite\n"))
    (princ (format "| Theme: %s (Family: %s, Polarity: %s)\n" theme family polarity))
    (princ (format "| Cross-Family Counterparts Evaluated:\n"))
    (if counterparts
        (dolist (c counterparts)
          (princ (format "|\t* %s\n" c)))
      (princ "|\t* (none)\n"))
    (princ (format "'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'\n"))

    (if (null counterparts)
        (princ "[SKIP]  No cross-family counterpart of the same polarity found for comparison.\n")

      (dolist (c-theme counterparts)
        (let ((c-pal (au-extract-active-palette c-theme)))

          (princ (format "\nCross-Family Hex Collision Check (%s vs %s):\n" theme c-theme))
          (princ (format "---------------------------------------------------------------------------------------------------------\n"))
          (let ((checked-keys '(:keyword :type :builtin :constant :number :fnname
                                         :fnname-call :string :property :bg-region :cursor
                                         :bg-main :fg-main
                                         :bg-red-intense :bg-green-intense :bg-yellow-intense
                                         :bg-blue-intense :bg-magenta-intense :bg-cyan-intense
                                         :bg-red-subtle :bg-green-subtle :bg-yellow-subtle
                                         :bg-blue-subtle :bg-magenta-subtle :bg-cyan-subtle
                                         :fg-line-number-inactive))
                (collisions nil))
            (dolist (k checked-keys)
              (let ((h1 (plist-get pal k))
                    (h2 (plist-get c-pal k)))
                (when (and h1 h2 (string= (downcase h1) (downcase h2)))
                  (push (list k h1) collisions))))
            (if (null collisions)
                (progn
                  (princ (format "[PASS]  0 shared hex codes between %s and %s.\n" theme c-theme))
                  (setq passes (1+ passes)))
              (princ (format "[FAIL]  Cross-family color collision detected: %S\n" collisions))
              (setq fails (1+ fails))))

          (princ (format "\nExpressive Roles Minimum Separation (%s vs %s, min dE00 10.0, informational):\n"
                         theme c-theme))
          (princ (format "---------------------------------------------------------------------------------------------------------\n"))
          (princ (format "+------------------------------+-------------------------+-------------------------+----------+---------+\n"))
          (princ (format "| %-28s | %-23s | %-23s | %-8s | %-7s |\n"
                         "Role" (symbol-name theme) (symbol-name c-theme) "dE00" "Status"))
          (princ (format "+------------------------------+-------------------------+-------------------------+----------+---------+\n"))
          (let ((key-roles '((:type         "Data Type (type)")
                             (:builtin      "Builtin functions (builtin)")
                             (:fnname       "Function name (fnname)")
                             (:fnname-call  "Function call (fnname-call)")
                             (:bg-region    "Selection region (bg-region)")
                             (:cursor       "Cursor point (cursor)"))))
            (dolist (r key-roles)
              (let* ((k (car r))
                     (label (cadr r))
                     (h1 (plist-get pal k))
                     (h2 (plist-get c-pal k))
                     (dist (rf-delta-e-2000 h1 h2))
                     (ok (>= dist 10.0)))
                (when ok
                  (setq passes (1+ passes)))
                (princ (format "| %-28s | %-23s | %-23s | %8.2f | %s    |\n"
                               label h1 h2 dist (if ok "PASS" "NOTE (< 10.0)"))))))
          (princ (format "+------------------------------+-------------------------+-------------------------+----------+---------+\n"))

          (princ (format "\nGlobal Palette Profile Divergence (%s vs %s):\n" theme c-theme))
          (princ (format "---------------------------------------------------------------------------------------------------------\n"))
          (let* ((syntax-keys '(:keyword :type :builtin :constant :number :fnname
                                         :fnname-call :string :property :bg-region))
                 (distances (mapcar (lambda (k)
                                      (rf-delta-e-2000 (plist-get pal k) (plist-get c-pal k)))
                                    syntax-keys))
                 (mean-dist (/ (apply #'+ distances) (float (length distances))))
                 (mean-ok (>= mean-dist 18.0)))
            (if mean-ok
                (progn
                  (princ (format "[PASS]  Mean cross-family syntax separation = %.2f >= 18.0\n" mean-dist))
                  (setq passes (1+ passes)))
              (princ (format "[NOTE]  Palette clone alert: Mean separation = %.2f < 18.0\n" mean-dist)))))))

    (princ (format "\nChromatic Identity Purity Gate (%s family signature):\n" family))
    (princ (format "---------------------------------------------------------------------------------------------------------\n"))
    (cond
     ((eq family 'aurum)
      ;; Aurum requirements:
      ;; Selection region: h in [40deg..110deg]
      ;; and NEVER h in [115deg..175deg])
      (let* ((reg-hex (plist-get pal :bg-region))
             (reg-okl (rf-hex-to-oklch reg-hex))
             (reg-h   (nth 2 reg-okl))
             (reg-ok  (and (>= reg-h 40.0) (<= reg-h 110.0))))
        (if reg-ok
            (progn
              (princ (format "[PASS]  Aurum Selection Region (%s, hue %.1fdeg).\n"
                             reg-hex reg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Aurum Selection Region (%s, hue %.1fdeg): expected [40deg..110deg].\n"
                         reg-hex reg-h))
          (setq fails (1+ fails))))

      ;; For aurum-day, Data Type: h not in [120deg..175deg]
      (when (eq polarity 'light)
        (let* ((type-hex (plist-get pal :type))
               (type-okl (rf-hex-to-oklch type-hex))
               (type-h   (nth 2 type-okl))
               (type-not-green (not (and (>= type-h 120.0) (<= type-h 175.0)))))
          (if type-not-green
              (progn
                (princ (format "[PASS]  Aurum Daylight Data Type (%s, hue %.1fdeg).\n"
                               type-hex type-h))
                (setq passes (1+ passes)))
            (princ (format "[FAIL]  Aurum Daylight Data Type (%s, hue %.1fdeg): Green hue stolen.\n"
                           type-hex type-h))
            (setq fails (1+ fails))))))

     ((eq family 'whispergrove)
      ;; Whispergrove requirements:
      ;; Selection region: h in [115deg..175deg]
      (let* ((reg-hex (plist-get pal :bg-region))
             (reg-okl (rf-hex-to-oklch reg-hex))
             (reg-h   (nth 2 reg-okl))
             (reg-ok  (and (>= reg-h 115.0) (<= reg-h 175.0))))
        (if reg-ok
            (progn
              (princ (format "[PASS]  Whispergrove Selection Region (%s, hue %.1fdeg).\n"
                             reg-hex reg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Whispergrove Selection Region (%s, hue %.1fdeg): Not in forest moss envelope.\n"
                         reg-hex reg-h))
          (setq fails (1+ fails)))))

     ((eq family 'parchment)
      ;; Parchment requirements:
      ;; All syntax code tokens must maintain Oklab C < 0.042
      (let* ((syntax-tokens '(:keyword :type :builtin :constant :number :fnname
                                       :fnname-call :string :property))
             (excess-chroma nil))
        (dolist (tok syntax-tokens)
          (let* ((hex (plist-get pal tok))
                 (c (nth 1 (rf-hex-to-oklch hex))))
            (when (> c 0.042)
              (push (list tok hex c) excess-chroma))))
        (if (null excess-chroma)
            (progn
              (princ "[PASS]  All syntax tokens maintain Oklab C <= 0.042\n")
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Tokens exceed sensory-safe ceiling C=0.042: %S\n"
                         excess-chroma))
          (setq fails (1+ fails))))

      ;; Selection region: h in [25deg..110deg]
      ;; and NEVER in [120deg..280deg]
      (let* ((reg-hex (plist-get pal :bg-region))
             (reg-okl (rf-hex-to-oklch reg-hex))
             (reg-h   (nth 2 reg-okl))
             (reg-ok  (and (>= reg-h 25.0) (<= reg-h 110.0))))
        (if reg-ok
            (progn
              (princ (format "[PASS]  Parchment Selection Region (%s, hue %.1fdeg).\n"
                             reg-hex reg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Parchment Selection Region (%s, hue %.1fdeg): Expected [25deg..110deg].\n"
                         reg-hex reg-h))
          (setq fails (1+ fails)))))

     ((eq family 'herbarium)
      ;; Herbarium requirements:
      ;; Selection region: h in [290deg..340deg] (pressed-petal mauve)
      (let* ((reg-hex (plist-get pal :bg-region))
             (reg-okl (rf-hex-to-oklch reg-hex))
             (reg-h   (nth 2 reg-okl))
             (reg-ok  (and (>= reg-h 290.0) (<= reg-h 340.0))))
        (if reg-ok
            (progn
              (princ (format "[PASS]  Herbarium Selection Region (%s, hue %.1fdeg).\n"
                             reg-hex reg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Herbarium Selection Region (%s, hue %.1fdeg): expected [290deg..340deg].\n"
                         reg-hex reg-h))
          (setq fails (1+ fails)))))

     ((eq family 'salina)
      ;; Salina requirements:
      ;; Selection region: h in [195deg..265deg] (brine blue)
      (let* ((reg-hex (plist-get pal :bg-region))
             (reg-okl (rf-hex-to-oklch reg-hex))
             (reg-h   (nth 2 reg-okl))
             (reg-ok  (and (>= reg-h 195.0) (<= reg-h 265.0))))
        (if reg-ok
            (progn
              (princ (format "[PASS]  Salina Selection Region (%s, hue %.1fdeg).\n"
                             reg-hex reg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Salina Selection Region (%s, hue %.1fdeg): expected [195deg..265deg].\n"
                         reg-hex reg-h))
          (setq fails (1+ fails)))))

     ((eq family 'perseida)
      ;; Perseida requirements:
      ;; Selection region: h in [265deg..295deg] (the radiant in Perseus)
      (let* ((reg-hex (plist-get pal :bg-region))
             (reg-okl (rf-hex-to-oklch reg-hex))
             (reg-h   (nth 2 reg-okl))
             (reg-ok  (and (>= reg-h 265.0) (<= reg-h 295.0))))
        (if reg-ok
            (progn
              (princ (format "[PASS]  Perseida Selection Region (%s, hue %.1fdeg).\n"
                             reg-hex reg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Perseida Selection Region (%s, hue %.1fdeg): expected [265deg..295deg].\n"
                         reg-hex reg-h))
          (setq fails (1+ fails))))

      ;; For perseida-night, canvas: optically black, i.e. neutral
      ;; (Oklab C <= 0.005) and adding at most half again the light the
      ;; panel shows at black (IPS black level + reflected ambient),
      ;; which keeps it darker than every other family's night canvas
      (when (eq polarity 'dark)
        (let* ((bg-hex (plist-get pal :bg-main))
               (bg-y (rf-luminance-y bg-hex))
               (bg-c (nth 1 (rf-hex-to-oklch bg-hex)))
               (floor-y (* rf-optically-black-floor-factor (rf-display-physical-floor-y))))
          (if (rf-optically-black-p bg-hex)
              (progn
                (princ (format "[PASS]  Perseida Night Canvas (%s, Y %.5f <= 1.5x panel floor %.5f, C %.3f).\n"
                               bg-hex bg-y floor-y bg-c))
                (setq passes (1+ passes)))
            (princ (format "[FAIL]  Perseida Night Canvas (%s, Y %.5f, C %.3f): expected neutral, Y <= 1.5x panel floor %.5f.\n"
                           bg-hex bg-y bg-c floor-y))
            (setq fails (1+ fails)))))

      ;; For perseida-day, canvas: a cool pearl, the sky at nautical
      ;; dawn, i.e. near-neutral (Oklab C <= 0.012) on the blue side
      ;; (h in [220deg..290deg]), where every other light family keeps
      ;; a warm paper or sand canvas
      (when (eq polarity 'light)
        (let* ((bg-hex (plist-get pal :bg-main))
               (bg-okl (rf-hex-to-oklch bg-hex))
               (bg-c (nth 1 bg-okl))
               (bg-h (nth 2 bg-okl)))
          (if (and (<= bg-c 0.012) (>= bg-h 220.0) (<= bg-h 290.0))
              (progn
                (princ (format "[PASS]  Perseida Dawn Canvas (%s, C %.3f, hue %.1fdeg).\n"
                               bg-hex bg-c bg-h))
                (setq passes (1+ passes)))
            (princ (format "[FAIL]  Perseida Dawn Canvas (%s, C %.3f, hue %.1fdeg): expected C <= 0.012, hue [220deg..290deg].\n"
                           bg-hex bg-c bg-h))
            (setq fails (1+ fails))))))

     ((eq family 'pluvia)
      ;; Pluvia requirements:
      ;; Base text: C <= 0.004, the plain grey light of a rainy day,
      ;; where every other family tints its text
      ;; Selection region: C <= 0.025 with h in [220deg..250deg],
      ;; a fogged window pane, where other families colour the region
      (let* ((fg-hex  (plist-get pal :fg-main))
             (fg-c    (nth 1 (rf-hex-to-oklch fg-hex)))
             (fg-ok   (<= fg-c 0.004))
             (reg-hex (plist-get pal :bg-region))
             (reg-okl (rf-hex-to-oklch reg-hex))
             (reg-c   (nth 1 reg-okl))
             (reg-h   (nth 2 reg-okl))
             (reg-ok  (and (<= reg-c 0.025) (>= reg-h 220.0) (<= reg-h 250.0))))
        (if fg-ok
            (progn
              (princ (format "[PASS]  Pluvia Grey Light Text (%s, C %.3f).\n"
                             fg-hex fg-c))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Pluvia Grey Light Text (%s, C %.3f): expected C <= 0.004.\n"
                         fg-hex fg-c))
          (setq fails (1+ fails)))
        (if reg-ok
            (progn
              (princ (format "[PASS]  Pluvia Fogged Pane Region (%s, C %.3f, hue %.1fdeg).\n"
                             reg-hex reg-c reg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Pluvia Fogged Pane Region (%s, C %.3f, hue %.1fdeg): expected C <= 0.025, hue [220deg..250deg].\n"
                         reg-hex reg-c reg-h))
          (setq fails (1+ fails)))))

     ((eq family 'mysterium)
      ;; Mysterium requirements:
      ;; Selection region: h in [295deg..315deg], a violet dusk
      ;; Keywords: h in [185deg..205deg], the teal bodywork of the
      ;; old van
      (let* ((reg-hex (plist-get pal :bg-region))
             (reg-h   (nth 2 (rf-hex-to-oklch reg-hex)))
             (reg-ok  (and (>= reg-h 295.0) (<= reg-h 315.0)))
             (kw-hex  (plist-get pal :keyword))
             (kw-h    (nth 2 (rf-hex-to-oklch kw-hex)))
             (kw-ok   (and (>= kw-h 185.0) (<= kw-h 205.0))))
        (if reg-ok
            (progn
              (princ (format "[PASS]  Mysterium Violet Region (%s, hue %.1fdeg).\n"
                             reg-hex reg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Mysterium Violet Region (%s, hue %.1fdeg): expected [295deg..315deg].\n"
                         reg-hex reg-h))
          (setq fails (1+ fails)))
        (if kw-ok
            (progn
              (princ (format "[PASS]  Mysterium Teal Keywords (%s, hue %.1fdeg).\n"
                             kw-hex kw-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Mysterium Teal Keywords (%s, hue %.1fdeg): expected [185deg..205deg].\n"
                         kw-hex kw-h))
          (setq fails (1+ fails)))))

     ((eq family 'yerba)
      ;; Yerba requirements:
      ;; Selection region: h in [100deg..135deg] (dried yerba leaf)
      ;; Canvas: h in [90deg..125deg] with C <= 0.03, the dry yellowish
      ;; side of green, never the wet blue-green side
      (let* ((reg-hex (plist-get pal :bg-region))
             (reg-h   (nth 2 (rf-hex-to-oklch reg-hex)))
             (reg-ok  (and (>= reg-h 100.0) (<= reg-h 135.0)))
             (bg-hex  (plist-get pal :bg-main))
             (bg-okl  (rf-hex-to-oklch bg-hex))
             (bg-c    (nth 1 bg-okl))
             (bg-h    (nth 2 bg-okl))
             (bg-ok   (and (<= bg-c 0.03) (>= bg-h 90.0) (<= bg-h 125.0))))
        (if reg-ok
            (progn
              (princ (format "[PASS]  Yerba Selection Region (%s, hue %.1fdeg).\n"
                             reg-hex reg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Yerba Selection Region (%s, hue %.1fdeg): expected [100deg..135deg].\n"
                         reg-hex reg-h))
          (setq fails (1+ fails)))
        (if bg-ok
            (progn
              (princ (format "[PASS]  Yerba Dry Leaf Canvas (%s, C %.3f, hue %.1fdeg).\n"
                             bg-hex bg-c bg-h))
              (setq passes (1+ passes)))
          (princ (format "[FAIL]  Yerba Dry Leaf Canvas (%s, C %.3f, hue %.1fdeg): expected C <= 0.03, hue [90deg..125deg].\n"
                         bg-hex bg-c bg-h))
          (setq fails (1+ fails)))))

     (t
      (princ (format "[FAIL]  No chromatic identity signature defined for the %s family.\n" family))
      (setq fails (1+ fails))))

    (princ (format "\n=========================================================================================================\n"))
    (princ (format "Cross-Family Distinctiveness Summary: %d Passed, %d Failed.\n\n" passes fails))
    (zerop fails)))

(when (and noninteractive (not (bound-and-true-p rf-running-all-tests)))
  (unless (test-cross-family-distinctiveness-run)
    (kill-emacs 1)))

(provide 'test-cross-family-distinctiveness)
;;; test-cross-family-distinctiveness.el ends here
