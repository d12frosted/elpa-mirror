;;; test-oklab-perceptual.el --- Oklab / Oklch lightness bands and chroma ceilings -*- lexical-binding: t -*-

;; Copyright (C) 2026  Szymon Wilczek

;; Author: Szymon Wilczek <swilczek.lx@gmail.com>
;; URL: https://github.com/szymonwilczek/au-themes

;; This file is not part of GNU Emacs.

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Evaluate Oklch perceptual parameters [L C h].
;;
;; Variables may be drawn as body text or as a syntax role, so their
;; envelope is the hull of the base-text and keyword envelopes.
;;
;; There is deliberately no chroma floor.  The themes aim for low chroma,
;; and whether two roles can be told apart is gated by CIEDE2000 in the
;; determinism and CVD suites, not by how saturated each one is.
;;
;; Basis: Oklab is Ottosson (2020); the per-role bands are au-themes
;; calibrations.
;;
;; Ref:
;; Ottosson (2020) A perceptual color space for image processing.

;;; Code:

(require 'test-palette-extractor)

(defun test-oklab-perceptual-run ()
  "Evaluate Oklch perceptual parameters [L C h]."
  (let* ((pal (au-extract-active-palette))
         (theme (plist-get pal :theme))
         (bg (plist-get pal :bg-main))
         (polarity (rf-theme-polarity theme))
         (bg-oklch (rf-hex-to-oklch bg))
         (passes 0)
         (fails 0)
         (tokens
          (if (eq polarity 'light)
              '(("Base text"            :fg-main      0.20 0.35 0.08)
                ("Comments"             :comment      0.40 0.55 0.08)
                ("Cursor"               :cursor       0.35 0.60 0.20)
                ("Preprocessor"         :preprocessor 0.30 0.50 0.20)
                ("Keywords"             :keyword      0.34 0.50 0.22)
                ("Data types"           :type         0.35 0.50 0.22)
                ("Constants"            :constant     0.30 0.50 0.22)
                ("Numbers"              :number       0.34 0.50 0.22)
                ("Builtins"             :builtin      0.30 0.50 0.20)
                ("Function definitions" :fnname       0.34 0.50 0.20)
                ("Function calls"       :fnname-call  0.34 0.50 0.20)
                ("Strings"              :string       0.30 0.50 0.20)
                ("Struct fields"        :property     0.30 0.50 0.16)
                ("Variables"            :variable     0.20 0.50 0.22)
                ("Operators"            :operator     0.30 0.50 0.10)
                ("Brackets"             :bracket      0.30 0.50 0.10)
                ("Alerts / Errors (!)"  :err          0.35 0.55 0.25))
            '(("Base text"              :fg-main      0.60 0.85 0.08)
              ("Comments"               :comment      0.30 0.55 0.08)
              ("Cursor"                 :cursor       0.50 0.75 0.20)
              ("Preprocessor"           :preprocessor 0.48 0.75 0.22)
              ("Keywords"               :keyword      0.40 0.65 0.25)
              ("Data types"             :type         0.50 0.75 0.25)
              ("Constants"              :constant     0.40 0.80 0.25)
              ("Numbers"                :number       0.55 0.78 0.25)
              ("Builtins"               :builtin      0.45 0.68 0.20)
              ("Function definitions"   :fnname       0.40 0.65 0.18)
              ("Function calls"         :fnname-call  0.50 0.75 0.20)
              ("Strings"                :string       0.48 0.72 0.25)
              ("Struct fields"          :property     0.50 0.72 0.16)
              ("Variables"              :variable     0.40 0.85 0.25)
              ("Operators"              :operator     0.42 0.65 0.08)
              ("Brackets"               :bracket      0.35 0.58 0.08)
              ("Alerts / Errors (!)"    :err          0.40 0.65 0.28)))))
    (princ (format "\n.~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~.\n"))
    (princ (format " Oklab / Oklch Lightness Band and Chroma Ceiling Suite\n"))
    (princ (format " Theme: %s (%s) | Background: %s (Oklab L: %.3f)\n" theme polarity bg (nth 0 bg-oklch)))
    (princ (format "'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'\n"))
    (princ (format "+----------------------+---------+---------+--------+----------+--------+--------------+\n"))
    (princ (format "| %-20s | %-7s | %-6s | %-6s | %-6s | %-6s |  %-12s|\n"
                   "Token Role" "Hex" "Oklab-L" "Chroma" "Hue(deg)" "C/L" "Diagnosis"))
    (princ (format "+----------------------+---------+---------+--------+----------+--------+--------------+\n"))
    (dolist (tok tokens)
      (let* ((name (nth 0 tok))
             (key  (nth 1 tok))
             (min-l (nth 2 tok))
             (max-l (nth 3 tok))
             (max-c (nth 4 tok))
             (hex (plist-get pal key))
             (oklch (rf-hex-to-oklch hex))
             (l (nth 0 oklch))
             (c (nth 1 oklch))
             (h (nth 2 oklch))
             (c-over-l (if (> l 0.001) (/ c l) 0.0))
             (status "OPTIMAL"))

        ;; Lightness must sit in the role's band and chroma under its ceiling.
        (cond
         ((< l min-l)
          (setq status "TOO DARK")
          (setq fails (1+ fails)))
         ((> l max-l)
          (setq status "TOO LIGHT")
          (setq fails (1+ fails)))
         ((> c max-c)
          (setq status "OVER-SAT")
          (setq fails (1+ fails)))
         (t
          (setq passes (1+ passes))))

        (princ (format "| %-20s | %-7s | %7.3f | %6.3f | %5.1fdeg | %6.3f | %-10s   |\n"
                       name hex l c h c-over-l status))))
    (princ (format "+----------------------+---------+---------+--------+----------+--------+--------------+\n"))
    (princ (format "\n========================================================================================\n"))
    (princ (format "Oklab Diagnosis Summary: %d Optimal, %d Failed.\n\n"
                   passes fails))
    (zerop fails)))

(when (and noninteractive (not (bound-and-true-p rf-running-all-tests)))
  (unless (test-oklab-perceptual-run)
    (kill-emacs 1)))

(provide 'test-oklab-perceptual)
;;; test-oklab-perceptual.el ends here
