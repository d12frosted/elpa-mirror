;;; test-lca-chromatic.el --- Longitudinal Chromatic Aberration and Common Focal Plane -*- lexical-binding: t -*-

;; Copyright (C) 2026  Szymon Wilczek

;; Author: Szymon Wilczek <swilczek.lx@gmail.com>
;; URL: https://github.com/szymonwilczek/au-themes

;; This file is not part of GNU Emacs.

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Evaluate Longitudinal Chromatic Aberration (LCA) chromatic dispersion.
;;
;; Each role is reduced to an effective wavelength, its refraction is
;; read from the chromatic eye model, and its focus must lie within
;; 0.25 D of body text so every role is sharp at the same focal plane.
;;
;; Basis: the refraction curve is the chromatic eye of Thibos et al.
;; (1992).  Collapsing a spectrum to one effective wavelength and the
;; 0.25 D tolerance, chosen inside the eye's depth of focus, are
;; au-themes heuristics.
;;
;; Ref:
;; Thibos et al. (1992) Applied Optics 31(19), DOI: 10.1364/AO.31.003594.

;;; Code:

(require 'test-palette-extractor)

(defun test-lca-chromatic-run ()
  "Evaluate LCA chromatic dispersion."
  (let* ((pal (au-extract-active-palette))
         (theme (plist-get pal :theme))
         (base (plist-get pal :fg-main))
         (base-d (rf-thibos-diopters base))
         (base-wave (rf-effective-wavelength base))
         (passes 0)
         (fails 0)
         (tokens '(("Preprocessor"         :preprocessor)
                   ("Keywords"             :keyword)
                   ("Data types"           :type)
                   ("Constants"            :constant)
                   ("Numbers"              :number)
                   ("Builtins"             :builtin)
                   ("Function definitions" :fnname)
                   ("Function calls"       :fnname-call)
                   ("Strings"              :string)
                   ("Struct fields"        :property)
                   ("Variables"            :variable)
                   ("Operators"            :operator)
                   ("Brackets"             :bracket)
                   ("Comments"             :comment)
                   ("Alerts / Errors (!)"  :err))))
    (princ (format "\n.~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~.\n"))
    (princ (format "| Longitudinal Chromatic Aberration (LCA) and Common Focal Plane Suite\n"))
    (princ (format "| Theme: %s | Base Text: %s\n|\t (Eff Wave: %.1fnm, Refraction: %.3fD)\n"
                   theme base base-wave base-d))
    (princ (format "'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'\n"))
    (princ (format "+----------------------+---------+----------+-----------+----------+--------+\n"))
    (princ (format "| %-20s | %-7s | %-7s | %-8s |  %-7s | %-7s|\n"
                   "Token Role" "Hex" "Eff Wave" "D(lambda)" "Delta-D" "Status"))
    (princ (format "+----------------------+---------+----------+-----------+----------+--------+\n"))
    (dolist (tok tokens)
      (let* ((name (nth 0 tok))
             (key  (nth 1 tok))
             (hex (plist-get pal key))
             (wave (rf-effective-wavelength hex))
             (d (rf-thibos-diopters hex))
             (delta-d (rf-lca-disparity hex base))
             (ok (<= delta-d 0.250)))
        (if ok
            (setq passes (1+ passes))
          (setq fails (1+ fails)))
        (princ (format "| %-20s | %-7s | %6.1fnm | %+7.3fD  | %6.3fD  |  %s  |\n"
                       name hex wave d delta-d
                       (if ok "PASS" "FAIL (>0.25D)")))))
    (princ (format "+----------------------+---------+----------+-----------+----------+--------+\n"))
    (princ (format "\n=============================================================================\n"))
    (princ (format "LCA Common Focal Plane Summary: %d Passed, %d Failed.\n\n" passes fails))
    (zerop fails)))

(when (and noninteractive (not (bound-and-true-p rf-running-all-tests)))
  (unless (test-lca-chromatic-run)
    (kill-emacs 1)))

(provide 'test-lca-chromatic)
;;; test-lca-chromatic.el ends here
