;;; test-photophobia-glare.el --- Photophobia, Discomfort Glare and CIE S 026 Melanopic Irradiance -*- lexical-binding: t -*-

;; Copyright (C) 2026  Szymon Wilczek

;; Author: Szymon Wilczek <swilczek.lx@gmail.com>
;; URL: https://github.com/szymonwilczek/au-themes

;; This file is not part of GNU Emacs.

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Evaluate clinical photophobia risk, CIE Discomfort Glare Index (DGI),
;; CIE S 026 melanopic irradiance, and photoreceptor saturation/bleaching
;; glare.
;;
;; The corneal melanopic EDI of the display is its mel-DER-weighted mean
;; viewport luminance times its projected solid angle.  On dark themes it
;; must stay at or under the 10 lx evening limit of Brown et al. (2022);
;; light themes are daytime themes, so the value is only reported.  The
;; display is the only source counted: room lighting adds to it.
;;
;; Basis: melanopic EDI is CIE S 026:2018 and the 10 lx evening limit is
;; Brown et al. (2022).  Everything else is an au-themes heuristic: the
;; Hopkinson glare constant and DGI were defined for luminaires and are
;; applied here to glyphs as a relative measure, and the per-token
;; glare, melanopic and mel-DER caps, the rod-protection canvas ceiling
;; and the dynamic-range limits are calibrations, not published limits.
;;
;; Ref:
;; - Hopkinson (1972) Glare from daylighting in buildings
;; - CIE S 026:2018
;; - Brown et al. (2022) PLoS Biol 20(3):e3001571
;; - Noseda et al. (2010) Nat. Neurosci. 13:239-245; (2016) Brain 139:1971-1986

;;; Code:

(require 'test-palette-extractor)

(defun test-photophobia-glare-run ()
  "Evaluate clinical photophobia risk, CIE Discomfort Glare Index (DGI),
CIE S 026 melanopic irradiance, and photoreceptor saturation/bleaching glare."
  (let* ((pal (au-extract-active-palette))
         (theme (plist-get pal :theme))
         (polarity (rf-theme-polarity theme))
         (bg (plist-get pal :bg-main))
         (bg-y (rf-luminance-y bg))
         (passes 0)
         (fails 0)
         (tokens-to-test
          '(("Base text"            :fg-main)
            ("Comments"             :comment)
            ("Cursor"               :cursor)
            ("Preprocessor"         :preprocessor)
            ("Keywords"             :keyword)
            ("Data types"           :type)
            ("Constants"            :constant)
            ("Numbers"              :number)
            ("Builtins"             :builtin)
            ("Function definitions" :fnname)
            ("Function calls"       :fnname-call)
            ("Strings"              :string)
            ("Struct fields"        :property)
            ("Operators"            :operator)
            ("Brackets"             :bracket)
            ("Alerts / Errors (!)"              :err)))
         (tok-hexes (mapcar (lambda (item) (plist-get pal (cadr item))) tokens-to-test))
         (buffer-tokens (append tok-hexes tok-hexes tok-hexes tok-hexes))
         (cumulative-dgi (rf-hopkinson-dgi buffer-tokens bg))
         (y-vals (mapcar #'rf-luminance-y tok-hexes))
         (y-max (apply #'max y-vals))
         (y-min (apply #'min y-vals)))

    (princ (format "\n.~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~.\n"))
    (princ (format "| Clinical Photophobia, Discomfort Glare & CIE S 026 Irradiance Suite\n"))
    (princ (format "| Theme: %s (%s) | Background: %s (Y_bg: %.6f)\n" theme polarity bg bg-y))
    (princ (format "'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'\n"))

    (princ "\nHopkinson/Cornell Discomfort Glare Index (DGI) & Token Glare Hotspots:\n")
    (princ (format "+----------------------+---------+-----------+----------+-----------+--------+\n"))
    (princ (format "| %-20s | %-7s |  %-8s | %-9s | %-8s | %-7s|\n"
                   "Token Role" "Hex" "Lum (Y)" "Glare (G)" "Max G" "Status"))
    (princ (format "+----------------------+---------+-----------+----------+-----------+--------+\n"))
    (dolist (item tokens-to-test)
      (let* ((label (car item))
             (key   (cadr item))
             (hex   (plist-get pal key))
             (y-val (rf-luminance-y hex))
             (g-val (rf-hopkinson-glare-constant hex bg))
             (max-g (if (eq polarity 'light) 0.10 0.35))
             (ok    (<= g-val max-g)))
        (if ok
            (setq passes (1+ passes))
          (setq fails (1+ fails)))
        (princ (format "| %-20s | %-7s | %9.4f | %9.5f | <= %5.2f |  %s  |\n"
                       label hex y-val g-val max-g (if ok "PASS" "FAIL")))))
    (princ (format "+----------------------+---------+-----------+----------+-----------+--------+\n"))

    (let* ((max-dgi 16.0)
           (dgi-ok (<= cumulative-dgi max-dgi)))
      (if dgi-ok
          (setq passes (1+ passes))
        (setq fails (1+ fails)))
      (princ (format "\nCumulative Buffer DGI:\n\t%.2f dB (Hopkinson Imperceptible Limit <= %.1f dB) -> %s\n"
                     cumulative-dgi max-dgi (if dgi-ok "PASS" "FAIL"))))

    (princ "\nCIE S 026 ipRGC Melanopic Irradiance and Circadian Load:\n")
    (princ (format "+----------------------+---------+-----------+----------+-----------+--------+\n"))
    (princ (format "| %-20s | %-7s | %-9s | %-8s | %-9s | %-7s|\n"
                   "Token Role" "Hex" "Melanopic" "M/P Rat" "Threshold" "Status"))
    (princ (format "+----------------------+---------+-----------+----------+-----------+--------+\n"))
    (dolist (item tokens-to-test)
      (let* ((label (car item))
             (key   (cadr item))
             (hex   (plist-get pal key))
             (m-val (rf-melanopic-irradiance hex))
             (mp    (or (rf-melanopic-photopic-ratio hex) 0.0))
             (max-m (if (eq polarity 'light)
                        0.25
                      (cond
                       ;; strictly subdued melanopic excitation
                       ((memq key '(:string :number :builtin :err :comment :preprocessor)) 0.35)
                       ;; safe neuro threshold
                       (t 0.65))))
             (max-mp 2.00)
             (ok (and (<= m-val max-m) (<= mp max-mp))))
        (if ok
            (setq passes (1+ passes))
          (setq fails (1+ fails)))
        (princ (format "| %-20s | %-7s | %9.4f | %6.2fx  | M <= %4.2f |  %s  |\n"
                       label hex m-val mp max-m (if ok "PASS" "FAIL")))))
    (princ (format "+----------------------+---------+-----------+----------+-----------+--------+\n"))

    ;; Whole-viewport corneal melanopic EDI.  The display is a Lambertian
    ;; panel, so corneal illuminance is its mean luminance times its
    ;; projected solid angle; weighting that luminance by mel-DER instead of
    ;; V(lambda) gives melanopic EDI directly (CIE S 026:2018).
    (let* ((omega-p (rf-display-projected-solid-angle))
           (view-mel (rf-viewport-mean pal #'rf-melanopic-irradiance))
           (corneal-mel-edi (* view-mel rf-display-white-luminance omega-p))
           (max-corneal 10.0))
      (princ (format "\nCorneal Melanopic EDI (display only, %.3f sr projected):\n" omega-p))
      (if (eq polarity 'dark)
          (let ((edi-ok (<= corneal-mel-edi max-corneal)))
            (if edi-ok
                (setq passes (1+ passes))
              (setq fails (1+ fails)))
            (princ (format "\t%.2f lx (Brown et al. 2022 evening limit <= %.1f lx) -> %s\n"
                           corneal-mel-edi max-corneal (if edi-ok "PASS" "FAIL"))))
        (princ (format "\t%.2f lx (light theme: daytime use, evening limit not applied)\n"
                       corneal-mel-edi))))

    (princ "\nPhotoreceptor Bleaching & Scotopic/Mesopic Saturation Glare:\n")
    (princ (format "------------------------------------------------------------------------------\n"))
    (if (eq polarity 'dark)
        (progn
          ;; Rod Saturation and Scotopic Bleaching Avoidance
          (let ((rod-ok (and (<= bg-y 0.020) (>= bg-y 0.0010))))
            (if rod-ok
                (progn
                  (princ (format "[PASS]  Background Y_bg = %.6f <= 0.020:\n\tRod photoreceptors protected from bleaching.\n" bg-y))
                  (setq passes (1+ passes)))
              (princ (format "[FAIL]  Background Y_bg = %.6f:\n\tExceeds scotopic rhodopsin saturation threshold.\n" bg-y))
              (setq fails (1+ fails))))

          ;; Saccadic Contrast Dynamic Range
          (let* ((cr (/ y-max (max 0.0001 bg-y)))
                 (cr-ok (<= cr 200.0)))
            (if cr-ok
                (progn
                  (princ (format "[PASS]  Peak Luminance Dynamic Range Y_max/Y_bg = %.2f <= 200.0:\n\tPrevents bleaching afterimages.\n" cr))
                  (setq passes (1+ passes)))
              (princ (format "[FAIL]  Dynamic Range Y_max/Y_bg = %.2f > 200.0:\n\tHigh risk of persistent afterimages.\n" cr))
              (setq fails (1+ fails)))))

      ;; Light Mode
      (progn
        ;; Daylight Canopy Cornea Comfort
        (let ((cornea-ok (and (<= bg-y 0.850) (>= bg-y 0.300))))
          (if cornea-ok
              (progn
                (princ (format "[PASS]  Background Y_bg = %.6f in [0.30..0.85]:\n\tMuted canopy daylight avoids corneal glare.\n" bg-y))
                (setq passes (1+ passes)))
            (princ (format "[FAIL]  Background Y_bg = %.6f outside [0.30..0.85]:\n\tHarsh blinding white or gloomy dark.\n" bg-y))
            (setq fails (1+ fails))))

        ;; Non-Saturating Daylight Dynamic Range
        (let* ((cr (/ bg-y (max 0.0001 y-min)))
               (cr-ok (<= cr 60.0)))
          (if cr-ok
              (progn
                (princ (format "[PASS]  Light Dynamic Range Y_bg/Y_min = %.2f <= 60.0:\n\tOptimal reading contrast without blinding glare.\n" cr))
                (setq passes (1+ passes)))
            (princ (format "[FAIL]  Dynamic Range Y_bg/Y_min = %.2f > 60.0:\n\tExtreme contrast saturation.\n" cr))
            (setq fails (1+ fails))))))

    (princ (format "\n==============================================================================\n"))
    (princ (format "Photophobia & Glare Summary: %d Passed, %d Failed.\n\n" passes fails))
    (zerop fails)))

(when (and noninteractive (not (bound-and-true-p rf-running-all-tests)))
  (unless (test-photophobia-glare-run)
    (kill-emacs 1)))

(provide 'test-photophobia-glare)
;;; test-photophobia-glare.el ends here
