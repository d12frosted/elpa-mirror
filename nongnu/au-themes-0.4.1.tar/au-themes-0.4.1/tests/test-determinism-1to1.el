;;; test-determinism-1to1.el --- 1:1 Keyface determinism and pairwise perceptual distance -*- lexical-binding: t -*-

;; Copyright (C) 2026  Szymon Wilczek

;; Author: Szymon Wilczek <swilczek.lx@gmail.com>
;; URL: https://github.com/szymonwilczek/au-themes

;; This file is not part of GNU Emacs.

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Evaluate 1:1 keyface uniqueness and pairwise CIEDE2000 separation (min 8.0).
;; Colour separation is measured with CIEDE2000, not with Emacs' `color-distance',
;; which is an unpublished sRGB heuristic that is not perceptually uniform:
;; the same numeric gate of 8000 corresponded to dE00 between 9.7 and 19.7
;; depending on the hue pair.
;;
;; Roles must differ in category: by Oklch hue, or by lightness when hue
;; cannot carry the difference.  Hue is undefined near grey, so it is only
;; compared when both colours are at least one Oklab just-noticeable difference
;; (0.02, as used by CSS Color 4 gamut mapping) away from the neutral axis;
;; a neutral colour against a clearly chromatic one (two JNDs) counts as
;; a different category.
;;
;; Families in `au-test-strict-families' are checked on every pair of
;; roles, not only on the curated `au-test-role-pairs': a pair left off
;; the list can collide unnoticed.  The neutral roles in
;; `au-test-receding-roles' form one grey ladder and are not compared
;; with each other here; their steps are held by the crowding, triplet
;; and isoluminance modules.
;;
;; The floor is 8.0.0.  Palettes built from named objects need
;; neighbouring shades of one material (stone and smoke,cocoa and bark),
;; and the categorical check below, together with the CVD, crowding and
;; isoluminance modules, already keeps roles apart in kind.
;; dE00 8.0 sits several times above the difference seen at a glance
;; (about 2 to 3).
;;
;; Basis: CIEDE2000 is a CIE standard; the 8.0 floor, the per-pair hue
;; minimums, the 0.08 lightness step and the receding-role exemption
;; are au-themes heuristics.
;;
;; Ref:
;; CIE 142:2001 / ISO-CIE 11664-6:2014 (CIEDE2000).
;; Ottosson (2020) A perceptual color space for image processing (Oklab).
;; W3C CSS Color Module Level 4, gamut mapping (deltaEOK JND = 0.02).

;;; Code:

(require 'test-palette-extractor)

(defun test-determinism-1to1-run ()
  "Evaluate 1:1 keyface uniqueness and pairwise CIEDE2000 separation (min 8.0)"
  (let* ((theme (or rf-active-theme (car (au-test-discover-themes))))
         (pal (au-extract-active-palette theme))
         (passes 0)
         (fails 0)
         (tokens-to-check '(:preprocessor :keyword :type :constant :number
                                          :builtin :fnname :fnname-call :string :property
                                          :operator :bracket :delimiter :err :comment :fg-main))
         (strict (au-test-strict-family-p theme))
         (critical-pairs (if strict
                             (au-test-all-role-pairs (append tokens-to-check '(:variable)))
                           au-test-role-pairs)))

    (princ (format "\n.~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~.\n"))
    (princ (format "| 1:1 Keyface Determinism & Pairwise CIEDE2000 Suite (min. dE00 8.0)\n"))
    (princ (format "| Theme: %s\n" theme))
    (princ (format "'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'\n"))

    (princ "\nKeyface Color Uniqueness (No shared hex across keyfaces):\n")
    (let ((seen (make-hash-table :test 'equal))
          (collisions nil))
      (dolist (key tokens-to-check)
        (let* ((hex (plist-get pal key))
               (prior (gethash hex seen)))
          (if (and prior (not (and (memq key '(:bracket :delimiter))
                                   (memq prior '(:bracket :delimiter)))))
              (push (cons key prior) collisions)
            (puthash hex key seen))))
      (if collisions
          (progn
            (princ (format "[FAIL]  Color collision detected: %S\n" collisions))
            (setq fails (1+ fails)))
        (princ "[PASS]  100% Deterministic: Each syntax role has a unique dedicated color.\n")
        (setq passes (1+ passes))))

    (princ (format "-------------------------------------------------------------------------------------------\n"))
    (princ (format "\nPairwise Separation Check (CIEDE2000 dE00 >= 8.0, %s):\n"
                   (if strict "every pair of roles" "curated pairs")))
    (princ (format "+--------------------------------------+-------------+-------------+-----------+----------+\n"))
    (princ (format "| %-31s      |   %-10s|   %-10s|  %-6s   |  %-6s  |\n"
                   "Role Comparison" "Color 1" "Color 2" " dE00" "Status"))
    (princ (format "+--------------------------------------+-------------+-------------+-----------+----------+\n"))
    (dolist (pair critical-pairs)
      (let* ((name (nth 0 pair))
             (k1   (nth 1 pair))
             (k2   (nth 2 pair))
             (min-dist (or (nth 3 pair) 8.0))
             (h1   (plist-get pal k1))
             (h2   (plist-get pal k2))
             (dist (rf-delta-e-2000 h1 h2))
             (ok   (>= dist min-dist)))
        (if ok
            (setq passes (1+ passes))
          (setq fails (1+ fails)))
        (princ (format "| %-31s      |   %-10s|   %-10s|%8.2f   |   %s   |\n"
                       name h1 h2 dist
                       (if ok "PASS" (format "FAIL (<%.1f)" min-dist))))))
    (princ (format "+--------------------------------------+-------------+-------------+-----------+----------+\n"))


    (princ "\nCategorical Role Disparity Check (Oklch hue Delta-h >= per-pair minimum, or Delta-L >= 0.08):\n")
    (princ "Hue is only trusted when both colours have C >= 0.02 (one Oklab JND from grey).\n")
    (princ "A neutral colour (C < 0.02) against a chromatic one (C >= 0.04) is a separate category.\n")
    (princ (format "+--------------------------------------+--------+----------+-----------+---------+--------+\n"))
    (princ (format "| %-36s | %-7s | %-7s | %-9s | %-7s | %-7s|\n"
                   "Role Comparison" "Color 1" "Color 2" " Delta-h" "Delta-L" "Status"))
    (princ (format "+--------------------------------------+---------+---------+-----------+---------+--------+\n"))
    (let* ((hue-pairs '(("struct (keyword) vs int (type)"         :keyword      :type        40.0)
                        ("struct (keyword) vs sizeof (builtin)"   :keyword      :builtin     40.0)
                        ("int (type) vs sizeof (builtin)"         :type         :builtin     15.0)
                        ("struct (keyword) vs constant"           :keyword      :constant    40.0)
                        ("struct (keyword) vs bpf_ (call)"        :keyword      :fnname-call 40.0)
                        ("constant vs bpf_ (call)"                :constant     :fnname-call 40.0)
                        ("preprocessor vs property"               :preprocessor :property    40.0)
                        ("constant vs property"                   :constant     :property    25.0)
                        ("bpf_ (call) vs property"                :fnname-call  :property    40.0)
                        ("bpf_ (call) vs base text"               :fnname-call  :fg-main     40.0)
                        ("preprocessor vs base text"              :preprocessor :fg-main     40.0)
                        ("0 (number) vs \"string\""               :number       :string      20.0)
                        ("preprocessor vs string"                 :preprocessor :string      25.0)
                        ("preprocessor vs constant"               :preprocessor :constant    40.0)
                        ("preprocessor vs builtin"                :preprocessor :builtin     40.0)
                        ("bpf_ (call) vs int (type)"              :fnname-call  :type        40.0)
                        ("property vs struct (keyword)"           :property     :keyword     40.0)
                        ("builtin vs constant"                    :builtin      :constant    25.0))))
      (dolist (hp hue-pairs)
        (let* ((name (nth 0 hp))
               (k1 (nth 1 hp))
               (k2 (nth 2 hp))
               (min-dh (nth 3 hp))
               (h1 (plist-get pal k1))
               (h2 (plist-get pal k2))
               (okl1 (rf-hex-to-oklch h1))
               (okl2 (rf-hex-to-oklch h2))
               (l1 (nth 0 okl1))
               (l2 (nth 0 okl2))
               (dl (abs (- l1 l2)))
               (hue1 (nth 2 okl1))
               (hue2 (nth 2 okl2))
               (raw-dh (abs (- hue1 hue2)))
               (dh (min raw-dh (- 360.0 raw-dh)))
               (c-lo (min (nth 1 okl1) (nth 1 okl2)))
               (c-hi (max (nth 1 okl1) (nth 1 okl2)))
               (ok (cond ((>= dl 0.08) t)
                         ((>= c-lo 0.02) (>= dh min-dh))
                         (t (>= c-hi 0.04)))))
          (if ok
              (setq passes (1+ passes))
            (setq fails (1+ fails)))
          (princ (format "| %-36s | %-7s | %-7s | %5.1fdeg  |  %5.3f  |  %s  |\n"
                         name h1 h2 dh dl
                         (if ok "PASS" "FAIL"))))))
    (princ (format "+--------------------------------------+---------+---------+-----------+---------+--------+\n"))


    (princ (format "\n===========================================================================================\n"))
    (princ (format "Determinism and Distance Summary: %d Passed, %d Failed.\n\n" passes fails))
    (zerop fails)))

(when (and noninteractive (not (bound-and-true-p rf-running-all-tests)))
  (unless (test-determinism-1to1-run)
    (kill-emacs 1)))

(provide 'test-determinism-1to1)
;;; test-determinism-1to1.el ends here
