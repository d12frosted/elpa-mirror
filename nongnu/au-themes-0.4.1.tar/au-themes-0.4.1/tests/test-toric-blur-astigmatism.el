;;; test-toric-blur-astigmatism.el --- Toric Blur PSF and Astigmatic Glyph Legibility -*- lexical-binding: t -*-

;; Copyright (C) 2026  Szymon Wilczek

;; Author: Szymon Wilczek <swilczek.lx@gmail.com>
;; URL: https://github.com/szymonwilczek/au-themes

;; This file is not part of GNU Emacs.

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Evaluate blurred edge Michelson contrast under 1.25D toric astigmatic
;; defocus.
;; A 1.25 D cylinder through a 4.3 mm pupil blurs a 1.6 arcmin stroke to
;; about 0.22 of its contrast; each role's blurred Michelson contrast must
;; stay above its floor (0.10 body text and 0.08 other roles on light
;; themes, 0.70 and 0.45 on dark themes).
;;
;; Basis: the geometric blur width beta = d C / 2 is standard defocus
;; optics (Charman 2005), and the 0.015 contrast threshold near 6 c/deg
;; that the floors are compared with is Campbell & Robson (1968).  The
;; 4.3 mm pupil, 1.6 arcmin stroke and the four floors are au-themes
;; heuristics.
;;
;; Ref:
;; - Legras et al. (2004) Ophthalmic Physiol Opt
;; - Charman (2005) Clin Exp Optom.

;;; Code:

(require 'test-palette-extractor)

(defun test-toric-blur-astigmatism-run ()
  "Evaluate blurred edge Michelson contrast under 1.25D toric astigmatic defocus."
  (let* ((pal (au-extract-active-palette))
         (theme (plist-get pal :theme))
         (bg (plist-get pal :bg-main))
         (polarity (rf-theme-polarity theme))
         ;; Geometric optics:
         ;; beta = d*C/2; for d=4.3mm, C=1.25D, w=1.6', eta = 4w/(pi*beta) ~= 0.22
         (blur-factor 0.22)
         (passes 0)
         (fails 0)
         (tokens '(("Base text"            :fg-main)
                   ("Keywords"             :keyword)
                   ("Data types"           :type)
                   ("Preprocessor"         :preprocessor)
                   ("Function definitions" :fnname)
                   ("Numbers"              :number)
                   ("Builtins"             :builtin)
                   ("Brackets"             :bracket)
                   ("Comments"             :comment))))
    (princ (format "\n.~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~.\n"))
    (princ (format "| Toric Blur Astigmatism PSF Suite (1.25D Cylinder Defocus)\n"))
    (princ (format "| Theme: %s (%s) | Background: %s (Lum: %.6f)\n" theme polarity bg (rf-luminance-y bg)))
    (princ (format "'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'\n"))
    (princ (format "\n+----------------------+---------+---------+--------------+---------+--------+\n"))
    (princ (format "| %-20s | %-7s | %-7s | %-12s | %-7s | %-7s|\n"
                   "Glyph Role" "Hex" "Y_token" "Cm (Blurred)" "Min Req" "Status"))
    (princ (format "+----------------------+---------+---------+--------------+---------+--------+\n"))
    (dolist (tok tokens)
      (let* ((label   (nth 0 tok))
             (key     (nth 1 tok))
             (min-cm  (if (eq polarity 'light)
                          ;; For dark strokes on light background, maximum
                          ;; theoretical Cm is eta/(2-eta) ~= 0.1236.
                          ;; Detection threshold at 6 cpd is mt = 0.015;
                          ;; Cm >= 0.08 is >5x suprathreshold
                          (if (eq key :fg-main) 0.10 0.08)
                        (if (eq key :fg-main) 0.70 0.45)))
             (hex     (plist-get pal key))
             (y-tok   (rf-luminance-y hex))
             (cm      (rf-toric-blur-michelson hex bg blur-factor))
             (ok      (>= cm min-cm)))
        (if ok
            (setq passes (1+ passes))
          (setq fails (1+ fails)))
        (princ (format "| %-20s | %-7s | %7.4f | %12.4f | %7.2f |  %s  |\n"
                       label hex y-tok cm min-cm
                       (if ok "PASS" "FAIL")))))
    (princ (format "+----------------------+---------+---------+--------------+---------+--------+\n"))
    (princ (format "\n==============================================================================\n"))
    (princ (format "Toric Blur Astigmatism Summary: %d Passed, %d Failed.\n\n" passes fails))
    (zerop fails)))

(when (and noninteractive (not (bound-and-true-p rf-running-all-tests)))
  (unless (test-toric-blur-astigmatism-run)
    (kill-emacs 1)))

(provide 'test-toric-blur-astigmatism)
;;; test-toric-blur-astigmatism.el ends here
