;;; test-magnocellular-parvocellular-balance.el --- Magnocellular vs Parvocellular Pathway Balance -*- lexical-binding: t -*-

;; Copyright (C) 2026  Szymon Wilczek

;; Author: Szymon Wilczek <swilczek.lx@gmail.com>
;; URL: https://github.com/szymonwilczek/au-themes

;; This file is not part of GNU Emacs.

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Evaluate visual pathway balance between Magnocellular (M) and
;; Parvocellular (P) systems.
;; In ASD, the M-pathway (sensitive to rapid motion, flicker, low spatial
;; frequency luminance jumps) is fragile and triggers involuntary saccadic
;; micro-jitters when background surfaces pop.
;; Backgrounds (hl-line, region) must have minimal luminance contrast
;; (Lc < 12.0), leaving all semantic differentiation to the slow, detailed,
;; color-sensitive P-pathway.
;; Syntax roles keep at least Lc 20, and the hl-line luminance step may
;; be at most 0.35 of the body-text step.
;;
;; The Michelson contrast of the hl-line is taken over the light that
;; reaches the eye: the emitted luminance plus the panel's physical floor
;; (LCD black level and diffusely reflected ambient light,
;; `rf-display-physical-floor-y').  On an optically black canvas the
;; emitted luminances alone are near zero, so their Michelson ratio
;; would treat a step the eye cannot resolve against the floor as a
;; large one.
;;
;; Basis: the M and P pathway properties are Livingstone & Hubel (1988)
;; and Merigan & Maunsell (1993); Michelson contrast is Michelson
;; (1927), and the panel floor follows IEC 61966-2-1 ambient conditions.
;; The Lc 12 and Michelson 0.35 chrome limits, the Lc 20 role floor and
;; the 0.35 gain ratio are au-themes heuristics.
;;
;; Ref:
;; - Livingstone & Hubel (1988) Science
;; - Milne et al. (2002) NeuroReport
;; - Merigan & Maunsell (1993)
;; - Michelson (1927) Studies in Optics, University of Chicago Press
;; - IEC 61966-2-1:1999 sRGB, reference viewing environment

;;; Code:

(require 'test-palette-extractor)

(defun test-magnocellular-parvocellular-balance-run ()
  "Evaluate visual pathway balance between Magnocellular (M) and Parvocellular (P) systems."
  (let* ((pal (au-extract-active-palette))
         (theme (plist-get pal :theme))
         (polarity (rf-theme-polarity theme))
         (bg (plist-get pal :bg-main))
         (hl (plist-get pal :bg-hl-line))
         (bg-y (rf-luminance-y bg))
         (hl-y (rf-luminance-y hl))
         (floor-y (rf-display-physical-floor-y))
         (passes 0)
         (fails 0))

    (princ (format "\n======================================================================\n"))
    (princ (format " Magnocellular (M) vs Parvocellular (P) Visual Pathway Balance Suite\n"))
    (princ (format " Theme: %s (%s) | Background: %s (Y_bg: %.6f)\n" theme polarity bg bg-y))
    (princ (format "======================================================================\n"))

    ;; Michelson <= 0.35
    ;; Lc < 12.0
    (princ "\nBackground UI Surfaces vs Canvas Luminance Shock:\n")
    (princ (format "-----------------------------------------------------------------------\n"))
    (let* ((lc-hl (abs (rf-apca-contrast hl bg)))
           (m-hl (/ (abs (- hl-y bg-y)) (+ hl-y bg-y (* 2.0 floor-y))))
           (hl-ok (and (< lc-hl 12.0) (<= m-hl 0.35))))
      (if hl-ok
          (progn
            (princ (format "[PASS]  bg-hl-line (%s) vs bg-main (%s):\n\tMichelson=%.4f <= 0.35, |Lc|=%.2f: Suppresses M-pathway jerk.\n"
                           hl bg m-hl lc-hl))
            (setq passes (1+ passes)))
        (princ (format "[FAIL]  bg-hl-line (%s) vs bg-main (%s): Michelson=%.4f, |Lc|=%.2f: Triggers M-pathway saccadic distractibility.\n"
                       hl bg m-hl lc-hl))
        (setq fails (1+ fails))))

    (princ "\nP-Pathway High-Frequency Semantic Syntax Encoding (|Lc| >= 20.0):\n")
    (princ (format "-----------------------------------------------------------------------\n"))
    (let ((syntax-tokens '((:fg-main     . "Base text")
                           (:keyword     . "Keywords")
                           (:type        . "Data types")
                           (:constant    . "Constants")
                           (:number      . "Numbers")
                           (:fnname-call . "Function calls"))))
      (dolist (item syntax-tokens)
        (let* ((key (car item))
               (label (cdr item))
               (hex (plist-get pal key))
               (lc (abs (rf-apca-contrast hex bg)))
               (ok (>= lc 20.0)))
          (if ok
              (setq passes (1+ passes))
            (setq fails (1+ fails)))
          (princ (format "%-18s (%s): APCA |Lc| = %5.1f >= 20.0 -> %s\n"
                         label hex lc (if ok "PASS" "FAIL"))))))

    (princ "\nM/P Luminance Gain Ratio Check:\n")
    (princ (format "-----------------------------------------------------------------------\n"))
    (let* ((delta-bg-y (abs (- hl-y bg-y)))
           (delta-fg-y (abs (- (rf-luminance-y (plist-get pal :fg-main)) bg-y)))
           (mp-gain-ratio (/ delta-bg-y (max 0.001 delta-fg-y)))
           ;; hl-line luminance change must be less than 35% of text luminance step
           (gain-ok (<= mp-gain-ratio 0.35)))
      (if gain-ok
          (progn
            (princ (format "[PASS]  M/P Luminance Gain Ratio = %.3f <= 0.350:\n\tBackground stays quiet, text drives perception.\n"
                           mp-gain-ratio))
            (setq passes (1+ passes)))
        (princ (format "[FAIL]  M/P Luminance Gain Ratio = %.3f > 0.350:\n\tBackground competes with text for attention.\n"
                       mp-gain-ratio))
        (setq fails (1+ fails))))

    (princ (format "\n=======================================================================\n"))
    (princ (format "M/P Visual Pathway Balance Summary: %d Passed, %d Failed.\n\n" passes fails))
    (zerop fails)))

(when (and noninteractive (not (bound-and-true-p rf-running-all-tests)))
  (unless (test-magnocellular-parvocellular-balance-run)
    (kill-emacs 1)))

(provide 'test-magnocellular-parvocellular-balance)
;;; test-magnocellular-parvocellular-balance.el ends here
