;; Generated package description from pcre2el.el  -*- no-byte-compile: t -*-
(define-package "pcre2el" "1.9" "regexp syntax converter" '((emacs "25.1") (cl-lib "0.3") (a "1.0.0")) :commit "ffa53a7c78c55bfb068cdfb68ca8b1705c119f82" :authors '(("joddie <jonxfield at gmail.com>")) :maintainer '("joddie <jonxfield at gmail.com>") :url "https://github.com/joddie/pcre2el")
