;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.1" "A major mode for editing subtitles" '((emacs "25.1")) :commit "94c28993b77f79ec04db495ed4166212a55f9cb5" :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/rndusr/subed")
