;; Generated package description from highlight-parentheses.el  -*- no-byte-compile: t -*-
(define-package "highlight-parentheses" "2.1.0" "Highlight surrounding parentheses" '((emacs "24.3")) :keywords '("faces" "matching") :authors '(("Nikolaj Schumacher <bugs * nschum de>")) :maintainer '("Tassilo Horn" . "tsdh@gnu.org") :url "https://sr.ht/~tsdh/highlight-parentheses.el/")
