;; Generated package description from hl-block-mode.el  -*- no-byte-compile: t -*-
(define-package "hl-block-mode" "0.1" "Highlighting nested blocks" '((emacs "26.1")) :commit "877e14c0645397aa8c1a45eb34ea70f3ecd21280" :authors '(("Campbell Barton" . "ideasman42@gmail.com")) :maintainer '("Campbell Barton" . "ideasman42@gmail.com") :url "https://codeberg.com/ideasman42/emacs-hl-block-mode")
