;; Generated package description from goto-chg.el  -*- no-byte-compile: t -*-
(define-package "goto-chg" "1.7.4" "Go to last change" '((emacs "24.1")) :keywords '("convenience" "matching") :authors '(("David Andersson <l.david.andersson(at)sverige.nu>")) :maintainer '("Vasilij Schneidermann" . "mail@vasilij.de") :url "https://github.com/emacs-evil/goto-chg")
