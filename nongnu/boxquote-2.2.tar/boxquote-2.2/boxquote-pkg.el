;; Generated package description from boxquote.el  -*- no-byte-compile: t -*-
(define-package "boxquote" "2.2" "Quote text with a semi-box." '((cl-lib "0.5")) :authors '(("Dave Pearson" . "davep@davep.org")) :maintainer '("Dave Pearson" . "davep@davep.org") :keywords '("quoting") :url "https://github.com/davep/boxquote.el")
