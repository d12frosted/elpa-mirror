;; Generated package description from pinyin-isearch.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "pinyin-isearch" "1.7.0" "Pinyin mode for isearch" '((emacs "28.1")) :commit "9e9b97ad9c1b927e462cd012a27351f8d595baa8" :keywords '("chinese" "pinyin" "matching" "convenience") :url "https://github.com/Anoncheg1/pinyin-isearch")
