;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.8.4" "annotate files without changing them" 'nil :commit "65c47283462667baa5e4c284f0cb2b314ebf3ec1" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
