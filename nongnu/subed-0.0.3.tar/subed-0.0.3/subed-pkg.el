;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "0.0.3" "A major mode for editing subtitles" '((emacs "25.1")) :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/rndusr/subed")
