;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.10" "A major mode for editing subtitles" '((emacs "25.1")) :commit "b10ab60a4e567a1fb7d7702d146ed7055b203113" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
