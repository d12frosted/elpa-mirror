;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.4" "A major mode for editing subtitles" '((emacs "25.1")) :commit "7472d62d1efc2ea785760ec702a1efef11e63e54" :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/rndusr/subed")
