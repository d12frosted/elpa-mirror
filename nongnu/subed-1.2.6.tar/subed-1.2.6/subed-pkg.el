;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.2.6" "A major mode for editing subtitles" '((emacs "25.1")) :commit "2598656c5d62cb1a082ff5c49658246805443c60" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
