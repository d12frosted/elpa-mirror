;; Generated package description from web-mode.el  -*- no-byte-compile: t -*-
(define-package "web-mode" "17.1.4" "major mode for editing web templates" '((emacs "23.1")) :commit "1662f1f762e59d197ef61604cd1ad71fe053e517" :authors '(("François-Xavier Bois <fxbois AT Google Mail Service>")) :maintainer '("François-Xavier Bois") :keywords '("languages") :url "https://web-mode.org")
