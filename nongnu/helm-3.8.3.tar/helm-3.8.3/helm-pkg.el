;; Generated package description from helm.el  -*- no-byte-compile: t -*-
(define-package "helm" "3.8.3" "Emacs incremental and narrowing framework" 'nil :commit "129cf538a00b99913abc7fb258c474de3ec897ee" :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")) :maintainer '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com") :url "https://github.com/emacs-helm/helm")
