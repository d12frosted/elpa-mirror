;;; project-nix-store-tests.el --- Test project-nix-store  -*- lexical-binding: t; -*-

;; SPDX-FileCopyrightText: 2026 Lin Jian <me@linj.tech>
;; SPDX-License-Identifier: GPL-3.0-or-later

;;; Commentary:

;;; Code:

(require 'project-nix-store)
(require 'ert)
(require 'subr-x)
(eval-when-compile (require 'cl-lib))

(ert-deftest project-nix-store-try ()
  (let ((project-nix-store-dirs '("/nix/store/" "/another/store/"))
        (project-to-dirs
         '(nil
           ("/" "/nix" "/nix/store/"
            "/home/" "/home/me/" "/home/me/project/" "/home/me/project/nixpkgs/"
            "/root/" "/var/" "/var/lib/" "/tmp/")
           (nix-store "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/" 11)
           ("/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/"
            "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/share/"
            "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/share/emacs/"
            "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/share/emacs/site-lisp/"
            "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/share/emacs/site-lisp/elpa/"
            "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/share/emacs/site-lisp/elpa/project-0.11.2/")
           (nix-store "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/" 11)
           ("/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/"
            "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/share/"
            "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/share/emacs/"
            "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/share/emacs/30.2/"
            "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/share/emacs/30.2/lisp/"
            "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/share/emacs/30.2/lisp/progmodes/")
           (nix-store "/another/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/" 15)
           ("/another/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/"
            "/another/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/share/"
            "/another/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/share/emacs/"))))
    (cl-loop
     for (project dirs) on project-to-dirs by #'cddr
     do (ert-info ((format "%S" project) :prefix "project = ")
          (cl-loop
           for dir in dirs
           do (ert-info ((format "%S" dir) :prefix "dir = ")
                (let ((project-nix-store--cached-projects (make-hash-table :test 'equal)))
                  (ert-info ("run without cache")
                    (should (equal (project-nix-store-try dir)
                                   project)))
                  (ert-info ("cache is created")
                    (ert-info ((format "%S" project-nix-store--cached-projects)
                               :prefix "cache = ")
                      (should (equal (gethash dir project-nix-store--cached-projects)
                                     (or project 'not-found)))))
                  (ert-info ("run with cache")
                    (should (equal (project-nix-store-try dir)
                                   project))))))))))

(ert-deftest project-nix-store-root ()
  "Test `project-root' called with a project-nix-store instance."
  (let ((project-and-roots
         '((nix-store "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/" 11)
           "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/"
           (nix-store "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/" 11)
           "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/"
           (nix-store "/another/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/" 15)
           "/another/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/")))
    (cl-loop for (project project-root) on project-and-roots by #'cddr
             do (ert-info ((format "%S" project) :prefix "project = ")
                  (should (equal (project-root project)
                                 project-root))))))

(ert-deftest project-nix-store-name ()
  "Test `project-name' called with a project-nix-store instance."
  (let ((project-and-name-suffixes
         '((nix-store "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/" 11)
           "emacs-packages-deps"
           (nix-store "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/" 11)
           "emacs-30.2"
           (nix-store "/another/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/" 15)
           "emacs-30.2")))
    (cl-loop
     for (project project-name-suffix) on project-and-name-suffixes by #'cddr
     do (ert-info ((format "%S" project) :prefix "project = ")
          (cl-loop
           for project-nix-store-name-prefix in '("/NS/" "/nix-store/" "<nix-store>")
           do (ert-info ((format "%S" project-nix-store-name-prefix)
                         :prefix "project-nix-store-name-prefix = ")
                (let ((project-nix-store--cached-project-names (make-hash-table :test 'equal))
                      (project-name (concat project-nix-store-name-prefix
                                            project-name-suffix)))
                  (ert-info ("run without cache")
                    (should (equal (project-name project)
                                   project-name)))
                  (ert-info ("cache is created")
                    (ert-info ((format "%S" project-nix-store--cached-project-names)
                               :prefix "cache = ")
                      (should (equal (gethash (project-root project)
                                              project-nix-store--cached-project-names)
                                     project-name))))
                  (ert-info ("run with cache")
                    (should (equal (project-name project)
                                   project-name))))))))))

(cl-defstruct project-nix-store-tests--dummy-project-type
  "A dummy project type for test."
  root)

(ert-deftest project-nix-store-p ()
  (cl-loop for nix-store-project in
           '((nix-store "/nix/store/jnhsnfz13w8ailk2lfs2pvamwa35mxzs-emacs-packages-deps/" 11)
             (nix-store "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/" 11)
             (nix-store "/another/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/" 15))
           do (should (project-nix-store-p nix-store-project)))
  (cl-loop for non-nix-store-project in
           '((vc Git "~/code/fork/nixpkgs/")
             (transient . "~/code/fork/nixpkgs/")
             `(make-project-nix-store-tests--dummy-project-type :root "~/code/fork/nixpkgs/"))
           do (should-not (project-nix-store-p non-nix-store-project))))

(defmacro project-nix-store-tests-save-value (symbol &rest body)
  "Record SYMBOL's value; evaluate BODY in `progn'; restore SYMBOL's value.
SYMBOL should evaluate to a symbol,
representing a special variable.
The value cell of that symbol can be void."
  (declare (indent 1) (debug t))
  (cl-with-gensyms (is-bound original-value)
    (cl-once-only (symbol)
      `(progn
         (cl-check-type ,symbol symbol)
         (cl-assert (special-variable-p ,symbol) t)
         (let* ((,is-bound (boundp ,symbol))
                (,original-value (when ,is-bound
                                   (symbol-value ,symbol))))
           (unwind-protect
               (progn ,@body)
             (if ,is-bound
                 (if (custom-variable-p ,symbol)
                     (setopt--set ,symbol ,original-value)
                   (set ,symbol ,original-value))
               (makunbound ,symbol))))))))

(ert-deftest project-nix-store-unload-function ()
  (require 'project)
  (project-nix-store-tests-save-value 'project-find-functions
    (project-nix-store-tests-save-value 'project-list-exclude
      (add-hook 'project-find-functions #'project-nix-store-try -20)
      (add-hook 'project-list-exclude #'project-nix-store-p)
      (defvar project-find-functions)
      (defvar project-list-exclude)
      (ert-info ("hook functions are added")
        (should (memq #'project-nix-store-try project-find-functions))
        (should (memq #'project-nix-store-p project-list-exclude)))
      (ert-info ("return nil so that the standard unloading proceeds")
        ;; `project-nix-store-unload-function' is only called after 'loadhist is loaded
        (require 'loadhist)
        (should-not (project-nix-store-unload-function)))
      (ert-info ("hook functions are removed")
        (should-not (memq #'project-nix-store-try project-find-functions))
        (should-not (memq #'project-nix-store-p project-list-exclude))))))

(ert-deftest project-nix-store-dirs-change-clear-cache ()
  "Test that cache is cleared after `project-nix-store-dirs' is changed."
  (project-nix-store-tests-save-value 'project-nix-store-dirs
    (let ((project-nix-store-dirs '("/another/store/" "/nix/store/"))
          (project-nix-store--cached-projects (make-hash-table :test 'equal))
          (project-nix-store--cached-project-names (make-hash-table :test 'equal)))
      (should
       (project-name
        (should
         (project-nix-store-try "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/"))))
      (ert-info ("cache is created")
        (should-not (hash-table-empty-p project-nix-store--cached-projects))
        (should-not (hash-table-empty-p project-nix-store--cached-project-names)))
      (setopt project-nix-store-dirs '("/tmp/store/"))
      (ert-info ("cache is cleared")
        (should (hash-table-empty-p project-nix-store--cached-projects))
        (should (hash-table-empty-p project-nix-store--cached-project-names))))))

(ert-deftest project-nix-store-name-prefix-change-clear-cache ()
  "Test cache is cleared after `project-nix-store-name-prefix' is changed."
  (project-nix-store-tests-save-value 'project-nix-store-name-prefix
    (let ((project-nix-store--cached-project-names (make-hash-table :test 'equal)))
      (should
       (project-name
        '(nix-store "/nix/store/xxywqayx584zfal9d3h0smk5k2slyk44-emacs-30.2/" 11)))
      (ert-info ("cache is created")
        (should-not (hash-table-empty-p project-nix-store--cached-project-names)))
      (setopt project-nix-store-name-prefix "<store>")
      (ert-info ("cache is cleared")
        (should (hash-table-empty-p project-nix-store--cached-project-names))))))

(ert-deftest project-nix-store-dirs-change-value ()
  "Test that `project-nix-store-dirs' can be changed by `setopt'."
  (project-nix-store-tests-save-value 'project-nix-store-dirs
    (let ((new-value '("/project/store/tests-0/" "/project/store/tests-1/")))
      (ert-info ("before change")
        (should-not (equal project-nix-store-dirs
                           new-value)))
      (setopt project-nix-store-dirs new-value)
      (ert-info ("after change")
        (should (equal project-nix-store-dirs
                       new-value))))))

(ert-deftest project-nix-store-name-prefix-change-value ()
  "Test that `project-nix-store-name-prefix' can be changed by `setopt'."
  (project-nix-store-tests-save-value 'project-nix-store-name-prefix
    (let ((new-value "/project/store/tests/"))
      (ert-info ("before change")
        (should-not (equal project-nix-store-name-prefix
                           new-value)))
      (setopt project-nix-store-name-prefix new-value)
      (ert-info ("after change")
        (should (equal project-nix-store-name-prefix
                       new-value))))))

(ert-deftest project-nix-store-dirs-are-directory-names ()
  "Test `project-nix-store-dirs' set by `setopt' are dirs, not files."
  (project-nix-store-tests-save-value 'project-nix-store-dirs
    (dolist (new-value '(("/nix/store" "/another/store")
                         ("/nix/store/" "/another/store")
                         ("/nix/store" "/another/store/")
                         ("/nix/store/" "/another/store/")))
      (ert-info ((format "%S" new-value) :prefix "project-nix-store-dirs = ")
        (setopt project-nix-store-dirs new-value)
        (dolist (project-nix-store-dir project-nix-store-dirs)
          (should (directory-name-p project-nix-store-dir)))))))

(provide 'project-nix-store-tests)

;;; project-nix-store-tests.el ends here

;; Local Variables:
;; package-lint-main-file: "project-nix-store.el"
;; End:
