;; Generated package description from inf-clojure.el  -*- no-byte-compile: t -*-
(define-package "inf-clojure" "3.2.0" "Run an external Clojure process in an Emacs buffer" '((emacs "25.1") (clojure-mode "5.11")) :commit "67b0403aa183d521e36545266100f1f62a34e783" :keywords '("processes" "comint" "clojure") :url "http://github.com/clojure-emacs/inf-clojure")
