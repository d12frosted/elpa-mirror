;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.1.0" "A major mode for editing subtitles" '((emacs "25.1")) :commit "43fcde0c3aad7e897f1fdb9be46b320e2d2335bf" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
