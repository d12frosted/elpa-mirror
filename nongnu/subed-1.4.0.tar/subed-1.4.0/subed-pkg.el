;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.4.0" "A major mode for editing subtitles" '((emacs "25.1")) :commit "b39cae3fadfda5daafb963afb82cc1ff81d8ff3d" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
