;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.7.2" "annotate files without changing them" 'nil :commit "145719fe7b31ede66d656261103d829a0ed695af" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
