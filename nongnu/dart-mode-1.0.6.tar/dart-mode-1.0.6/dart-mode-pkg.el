;; Generated package description from dart-mode.el  -*- no-byte-compile: t -*-
(define-package "dart-mode" "1.0.6" "Major mode for editing Dart files" '((emacs "24.3")) :keywords '("languages") :authors '(("Brady Trainor" . "dart-mode_maintainer@tangential.info")) :maintainer '("Brady Trainor" . "dart-mode_maintainer@tangential.info") :url "https://github.com/bradyt/dart-mode")
