;; Generated package description from autothemer.el  -*- no-byte-compile: t -*-
(define-package "autothemer" "0.2.8" "Conveniently define themes" '((dash "2.10.0") (emacs "26.1")) :commit "07c4d891cc8b824b391831e73b8dd44d3a7b17c5" :authors '(("Sebastian Sturm")) :maintainer '("Jason Milkins" . "jasonm23@gmail.com") :url "https://github.com/jasonm23/autothemer")
