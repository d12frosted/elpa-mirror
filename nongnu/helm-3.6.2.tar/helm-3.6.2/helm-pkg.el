;; Generated package description from helm.el  -*- no-byte-compile: t -*-
(define-package "helm" "3.6.2" "Emacs incremental and narrowing framework" 'nil :commit "4ff354efb6b24044fd38b725b61d470bd5423265" :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")) :maintainer '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com") :url "https://github.com/emacs-helm/helm")
