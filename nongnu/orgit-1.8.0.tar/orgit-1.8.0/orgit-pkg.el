;; Generated package description from orgit.el  -*- no-byte-compile: t -*-
(define-package "orgit" "1.8.0" "support for Org links to Magit buffers" '((emacs "25.1") (magit "3.0") (org "9.4")) :commit "0b49d7a869b8fef3537a75df4db693ca3e3935a3" :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :url "https://github.com/magit/orgit")
