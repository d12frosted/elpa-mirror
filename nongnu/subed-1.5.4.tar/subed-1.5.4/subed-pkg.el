;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.4" "A major mode for editing subtitles" '((emacs "25.1")) :commit "d9317d1de190601384528ae01468688107725c8d" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
