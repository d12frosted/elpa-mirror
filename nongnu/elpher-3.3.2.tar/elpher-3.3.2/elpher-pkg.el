;; Generated package description from elpher.el  -*- no-byte-compile: t -*-
(define-package "elpher" "3.3.2" "A friendly gopher and gemini client" '((emacs "27.1")) :commit "6e3a8ef5af192eddcd834efac49866f84e2c73dd" :authors '(("Tim Vaughan" . "plugd@thelambdalab.xyz")) :maintainer '("Tim Vaughan" . "plugd@thelambdalab.xyz") :keywords '("comm" "gopher") :url "https://thelambdalab.xyz/elpher")
