;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.0" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "4ca2ebdb1f5165181e487bff5db9059592f58d85" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
