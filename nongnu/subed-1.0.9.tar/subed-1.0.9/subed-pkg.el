;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.9" "A major mode for editing subtitles" '((emacs "25.1")) :commit "82e3f57f954091ef3d23e0072da9f70819ab3dec" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
