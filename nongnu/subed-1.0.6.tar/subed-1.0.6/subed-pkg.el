;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.6" "A major mode for editing subtitles" '((emacs "25.1")) :commit "badbfb7d2088efb1f8032ca6eb6f67b83f1af76a" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
