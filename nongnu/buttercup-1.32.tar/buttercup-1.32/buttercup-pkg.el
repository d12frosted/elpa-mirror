;; Generated package description from buttercup.el  -*- no-byte-compile: t -*-
(define-package "buttercup" "1.32" "Behavior-Driven Emacs Lisp Testing" '((emacs "24.3")) :commit "3780eb081913d1aeef2bc5950891a3fbe3b3771d" :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de")) :maintainer '("Ola Nilsson" . "ola.nilsson@gmail.com") :url "https://github.com/jorgenschaefer/emacs-buttercup")
