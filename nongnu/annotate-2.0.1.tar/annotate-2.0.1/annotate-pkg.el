;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "2.0.1" "annotate files without changing them" 'nil :commit "93c4e36e7e62e5d82b9b3e659e59331b7df48f58" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
