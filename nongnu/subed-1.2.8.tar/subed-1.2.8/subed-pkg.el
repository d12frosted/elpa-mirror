;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.2.8" "A major mode for editing subtitles" '((emacs "25.1")) :commit "a5668700a5bab2d7426667c515582e7dade46919" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
