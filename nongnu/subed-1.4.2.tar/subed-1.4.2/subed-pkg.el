;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.4.2" "A major mode for editing subtitles" '((emacs "25.1")) :commit "ebf9dc981c65a94982dc92b7f3bc0560b2f579aa" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
