;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.5" "A major mode for editing subtitles" '((emacs "25.1")) :commit "7a0c36c808e107b5851ba48ec3825dfa3c1a902e" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
