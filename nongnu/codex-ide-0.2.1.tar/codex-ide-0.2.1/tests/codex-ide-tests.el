;;; codex-ide-tests.el --- ERT tests for codex-ide  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Thanos Apollo

;; This file is not part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;;; Commentary:

;; ERT tests for `codex-ide'.  These run under `emacs -Q --batch' with no
;; network and no live Codex process.

;;; Code:

(require 'ert)
(require 'codex-ide)
(require 'eat)
(require 'codex-ide-term-eat)
(require 'codex-ide-term)
(require 'codex-ide-menu)

(defun codex-ide-test--completion-candidates (table)
  "Read TABLE's public completions with their registered session records."
  (if (not (functionp table)) table
    (mapcar (lambda (name)
              (if-let* ((session (codex-ide--session-by-buffer (get-buffer name))))
                  (cons name session)
                name))
            (all-completions "" table))))

(defun codex-ide-test--with-vars (body)
  "Run BODY with controlled `codex-ide' variables, then restore them."
  (let ((codex-ide-cli-path "codex")
        (codex-ide-terminal-backend 'eat)
        (codex-ide-config-overrides nil)
        (codex-ide-ask-for-approval nil)
        (codex-ide-yolo nil)
        (codex-ide-no-alt-screen nil)
        (codex-ide-display-buffer-function #'pop-to-buffer-same-window)
        (codex-ide-cli-extra-args nil))
    (funcall body)))

(defun codex-ide-test--make-buffer-process (buffer name)
  "Return a live test process named NAME attached to BUFFER."
  (unless (executable-find "sleep")
    (ert-skip "sleep executable not found"))
  (start-process name buffer "sleep" "60"))

(defun codex-ide-test--make-recoverable-buffer (root name process-name
                                                     session-id)
  "Return (BUFFER PROCESS) for a live orphan Codex buffer.
The buffer carries ROOT and SESSION-ID as buffer-locals with
`codex-ide-mode' enabled, simulating a session whose record was lost."
  (let ((buffer (get-buffer-create name))
        process)
    (with-current-buffer buffer
      (setq default-directory root)
      (setq-local codex-ide--session-root root)
      (setq-local codex-ide--session-id session-id)
      (codex-ide-mode 1))
    (setq process
          (codex-ide-test--make-buffer-process buffer process-name))
    (set-process-query-on-exit-flag process nil)
    (list buffer process)))

(defun codex-ide-test--kill-buffer-process (buffer process)
  "Kill BUFFER and PROCESS when they are live."
  (when (and process (process-live-p process))
    (delete-process process))
  (when (buffer-live-p buffer)
    (kill-buffer buffer)))

(defun codex-ide-test--call-with-project (body)
  "Call BODY with a temporary project root."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-project-" t)))
         (default-directory root))
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root))
          (funcall body root))
      (delete-directory root t))))

(defun codex-ide-test--call-with-buffer-process (body)
  "Call BODY with a temp buffer and live process."
  (unless (executable-find "sleep")
    (ert-skip "sleep executable not found"))
  (let ((buffer (generate-new-buffer " *codex-ide-process-test*"))
        process)
    (unwind-protect
        (progn
          (setq process (start-process "codex-ide-test-process"
                                       buffer "sleep" "60"))
          (funcall body buffer process))
      (when (and process (process-live-p process))
        (delete-process process))
      (when (buffer-live-p buffer)
        (kill-buffer buffer)))))

(defun codex-ide-test--wait-for (predicate &optional timeout)
  "Wait until PREDICATE returns non-nil or TIMEOUT seconds pass.
Returns the final PREDICATE value.  TIMEOUT defaults to 5 seconds."
  (let ((deadline (+ (float-time) (or timeout 5))))
    (while (and (not (funcall predicate))
                (< (float-time) deadline))
      (accept-process-output nil 0.05)
      (sit-for 0.05))
    (funcall predicate)))

(defun codex-ide-test--call-with-eat-process (script body &optional env)
  "Run SCRIPT through sh in a Codex eat buffer and call BODY.
BODY receives the eat buffer and its process.  ENV is passed through
to the session.  The session is torn down afterwards."
  (when (getenv "CODEX_IDE_SKIP_PTY_TESTS")
    (ert-skip "PTY unavailable in the Nix build sandbox"))
  (unless (executable-find "sh")
    (ert-skip "sh executable not found"))
  (let ((buffer nil)
        (process nil))
    (unwind-protect
        (save-window-excursion
          (setq buffer
                (codex-ide-term--prepare-buffer
                 (generate-new-buffer-name " *codex-ide-eat-test*")
                 temporary-file-directory))
          (switch-to-buffer buffer)
          (setq process (codex-ide-term--make-process
                         buffer "sh" (list "-c" script) env))
          (funcall body buffer process))
      (when (and process (process-live-p process))
        (delete-process process))
      (when (buffer-live-p buffer)
        (kill-buffer buffer)))))

(defun codex-ide-test--make-session (root id)
  "Return a live test session for ROOT and ID."
  (let* ((buffer (get-buffer-create (codex-ide--get-buffer-name root id)))
         (process (codex-ide-test--make-buffer-process
                   buffer (format "codex-ide-test-%d" id)))
         (session (codex-ide--make-session root id buffer process)))
    (set-process-query-on-exit-flag process nil)
    (with-current-buffer buffer
      (setq-local codex-ide--session-root root)
      (setq-local codex-ide--session-id id))
    session))

(defun codex-ide-test--store-session (session)
  "Store SESSION in `codex-ide--sessions'."
  (let ((root (plist-get session :root)))
    (puthash root (cons session (gethash root codex-ide--sessions))
             codex-ide--sessions)
    (codex-ide--activate-session session)))

(defun codex-ide-test--kill-session (session)
  "Kill SESSION's process and buffer."
  (let ((process (plist-get session :process))
        (buffer (plist-get session :buffer)))
    (when (and process (process-live-p process))
      (delete-process process))
    (when (buffer-live-p buffer)
      (kill-buffer buffer))))

(defun codex-ide-test--session-by-id (sessions id)
  "Return the session with ID from SESSIONS."
  (cl-find id sessions
           :key (lambda (session) (plist-get session :id))
           :test #'=))

(defun codex-ide-test--session-by-root (sessions root)
  "Return the session for ROOT from SESSIONS."
  (cl-find root sessions
           :key (lambda (session) (plist-get session :root))
           :test #'equal))

(defun codex-ide-test--session-visible-p (session)
  "Return non-nil when SESSION's buffer is visible."
  (get-buffer-window (plist-get session :buffer) t))

(defun codex-ide-test--call-with-toggle-stubs (body)
  "Call BODY with noisy toggle collaborators muted."
  (cl-letf (((symbol-function 'codex-ide-context-record-source-buffer)
             (lambda (&rest _args) nil))
            ((symbol-function 'codex-ide-term--sync-dimensions)
             (lambda (&rest _args) nil))
            ((symbol-function 'codex-ide-debug)
             (lambda (&rest _args) nil)))
	   (funcall body)))

(defun codex-ide-test--toggle-in-root (root)
  "Call `codex-ide-toggle' for ROOT with same-window display."
  (codex-ide-test--call-with-toggle-stubs
   (lambda ()
     (let ((default-directory root)
           (codex-ide-display-buffer-function #'pop-to-buffer-same-window))
       (codex-ide-cycle-session)))))

(defun codex-ide-test--call-with-sessions (root-ids body)
  "Call BODY with live sessions for ROOT-IDS.
ROOT-IDS is a list of (ROOT ID) pairs.  BODY receives the session records."
  (let ((codex-ide--sessions (make-hash-table :test 'equal))
        (codex-ide--active-session-ids (make-hash-table :test 'equal))
        sessions)
    (unwind-protect
        (progn
          (dolist (root (delete-dups (mapcar #'car root-ids)))
            (let ((git-dir (expand-file-name ".git" root)))
              (unless (file-exists-p git-dir)
                (make-directory git-dir))))
          (setq sessions
                (mapcar (lambda (root-id)
                          (pcase-let ((`(,root ,id) root-id))
                            (let ((session
                                   (codex-ide-test--make-session root id)))
                              (codex-ide-test--store-session session)
                              session)))
                        root-ids))
          (funcall body sessions))
      (mapc #'codex-ide-test--kill-session sessions))))

(ert-deftest codex-ide-build-command-default ()
  "Default command is just the program with no args."
  (codex-ide-test--with-vars
   (lambda ()
     (should (equal (codex-ide--build-command)
                    (cons "codex" nil))))))

(ert-deftest codex-ide-build-command-resume-last ()
  "RESUME-LAST adds \"resume --last\"."
  (codex-ide-test--with-vars
   (lambda ()
     (should (equal (codex-ide--build-command t)
                    (cons "codex" '("resume" "--last")))))))

(ert-deftest codex-ide-build-command-session-id ()
  "SESSION-ID adds \"resume <id>\" as positional args."
  (codex-ide-test--with-vars
   (lambda ()
     (should (equal (codex-ide--build-command nil "abc-123")
                    (cons "codex" '("resume" "abc-123")))))))

(ert-deftest codex-ide-build-command-session-id-wins ()
  "SESSION-ID takes precedence over RESUME-LAST."
  (codex-ide-test--with-vars
   (lambda ()
     (should (equal (codex-ide--build-command t "abc-123")
                    (cons "codex" '("resume" "abc-123")))))))

(ert-deftest codex-ide-build-command-config-overrides ()
  "Config overrides fold as alternating \"-c\" \"key=value\" pairs."
  (codex-ide-test--with-vars
   (lambda ()
     (let ((codex-ide-config-overrides '(("model" . "o3"))))
       (should (equal (codex-ide--build-command)
                      (cons "codex" '("-c" "model=o3"))))))))

(ert-deftest codex-ide-build-command-config-overrides-multiple ()
  "Multiple overrides each emit their own \"-c\" pair."
  (codex-ide-test--with-vars
   (lambda ()
     (let ((codex-ide-config-overrides
            '(("model" . "o3")
              ("sandbox_permissions" . "[\"disk-full-read-access\"]"))))
       (should (equal (codex-ide--build-command)
                      (cons
                       "codex"
                       '("-c" "model=o3"
                         "-c" "sandbox_permissions=[\"disk-full-read-access\"]"))))))))

(ert-deftest codex-ide-build-command-ask-for-approval-nil ()
  "Nil approval omits the flag."
  (codex-ide-test--with-vars
   (lambda ()
     (let ((codex-ide-ask-for-approval nil))
       (should (equal (codex-ide--build-command)
                      (cons "codex" nil)))))))

(ert-deftest codex-ide-build-command-ask-for-approval-on-request ()
  "Non-nil approval includes the flag and value."
  (codex-ide-test--with-vars
   (lambda ()
     (let ((codex-ide-ask-for-approval 'on-request))
       (should (equal (codex-ide--build-command)
                      (cons "codex" '("--ask-for-approval" "on-request"))))))))

(ert-deftest codex-ide-build-command-no-alt-screen ()
  "`codex-ide-no-alt-screen' adds the flag."
  (codex-ide-test--with-vars
   (lambda ()
     (let ((codex-ide-no-alt-screen t))
       (should (equal (codex-ide--build-command)
                      (cons "codex" '("--no-alt-screen"))))))))

(ert-deftest codex-ide-build-command-yolo ()
  "`codex-ide-yolo' adds Codex's full-control alias."
  (codex-ide-test--with-vars
   (lambda ()
     (let ((codex-ide-yolo t))
       (should (equal (codex-ide--build-command)
                      (cons "codex" '("--yolo"))))))))

(ert-deftest codex-ide-build-command-extra-args ()
  "Extra args are appended verbatim."
  (codex-ide-test--with-vars
   (lambda ()
     (let ((codex-ide-cli-extra-args '("--search")))
       (should (equal (codex-ide--build-command)
                      (cons "codex" '("--search"))))))))

(ert-deftest codex-ide-build-command-combined ()
  "All modeled flags combine in the documented order."
  (codex-ide-test--with-vars
   (lambda ()
     (let ((codex-ide-config-overrides '(("model" . "o3")))
           (codex-ide-ask-for-approval 'never)
           (codex-ide-no-alt-screen t)
           (codex-ide-cli-extra-args '("--search")))
       (should (equal (codex-ide--build-command t)
                      (cons
                       "codex"
                       '("-c" "model=o3"
                         "resume" "--last"
                         "--ask-for-approval" "never"
                         "--no-alt-screen"
                         "--search"))))))))

(ert-deftest codex-ide-term-send-string-delegates-to-eat ()
  "String input goes directly to the eat terminal."
  (with-temp-buffer
    (setq-local eat-terminal 'dummy)
    (let (sent)
      (cl-letf (((symbol-function 'eat-term-send-string)
                 (lambda (terminal string)
                   (setq sent (list terminal string)))))
        (codex-ide-term--send-string "hello"))
      (should (equal sent '(dummy "hello"))))))

(ert-deftest codex-ide-term-send-return-sends-cr ()
  "Return input reaches the eat terminal as a carriage return."
  (with-temp-buffer
    (setq-local eat-terminal 'dummy)
    (let (sent)
      (cl-letf (((symbol-function 'eat-term-send-string)
                 (lambda (_terminal string)
                   (setq sent string))))
        (codex-ide-term--send-return))
      (should (equal sent "\r")))))

(ert-deftest codex-ide-term-send-escape-sends-esc ()
  "Escape input reaches the eat terminal as an ESC character."
  (with-temp-buffer
    (setq-local eat-terminal 'dummy)
    (let (sent)
      (cl-letf (((symbol-function 'eat-term-send-string)
                 (lambda (_terminal string)
                   (setq sent string))))
        (codex-ide-term--send-escape))
      (should (equal sent "\e")))))

(ert-deftest codex-ide-term-send-ops-require-terminal ()
  "Send operations do nothing without a live eat terminal."
  (with-temp-buffer
    (setq-local eat-terminal nil)
    (let (sent)
      (cl-letf (((symbol-function 'eat-term-send-string)
                 (lambda (_terminal string)
                   (setq sent string))))
        (codex-ide-term--send-string "hello")
        (codex-ide-term--send-return)
        (codex-ide-term--send-escape))
      (should-not sent))))

(ert-deftest codex-ide-term-normalize-cursor-state ()
  "Cursor normalization steadies blinking states and preserves others."
  (dolist (case '((:blinking-block . :block)
                  (:blinking-bar . :bar)
                  (:blinking-underline . :underline)
                  (:block . :block)
                  (:bar . :bar)
                  (:underline . :underline)
                  (:invisible . :invisible)
                  (:unknown . :unknown)))
    (should (eq (codex-ide-term-eat--normalize-cursor-state (car case) nil)
                (cdr case)))
    (should (eq (codex-ide-term-eat--normalize-cursor-state (car case) t)
                (car case)))))

(ert-deftest codex-ide-term-configure-buffer-installs-sync-and-hook ()
  "Buffer setup installs point and window synchronization."
  (with-temp-buffer
    (eat-mode)
    (codex-ide-term--configure-buffer)
    (should (eq eat--synchronize-scroll-function
                #'codex-ide-term-eat--synchronize-scroll))
    (should (local-variable-p 'eat--synchronize-scroll-function))
    (should (memq #'codex-ide-term-eat--synchronize-window
                  (buffer-local-value 'window-buffer-change-functions
                                      (current-buffer))))))

(ert-deftest codex-ide-term-cursor-adapter-installs-idempotently ()
  "Cursor setup retains Eat's callback, applies state, and avoids wrapping."
  (with-temp-buffer
    (eat-mode)
    (setq eat-terminal (eat-term-make (current-buffer) (point)))
    (let* ((states nil)
           (original (lambda (_terminal state) (push state states))))
      (setf (eat-term-parameter eat-terminal 'set-cursor-function) original)
      (cl-letf (((symbol-function 'eat-term-cursor-type)
                 (lambda (_terminal) :blinking-bar)))
        (codex-ide-term--configure-buffer)
        (codex-ide-term--configure-buffer))
      (should (eq (eat-term-parameter eat-terminal 'set-cursor-function)
                  #'codex-ide-term-eat--set-cursor))
      (should (eq (eat-term-parameter
                   eat-terminal
                   'codex-ide-term-eat--original-set-cursor-function)
                  original))
      (should (equal states '(:bar :bar))))))

(ert-deftest codex-ide-term-cursor-adapter-honors-blink-option ()
  "The cursor adapter passes blinking states through when enabled."
  (with-temp-buffer
    (eat-mode)
    (setq eat-terminal (eat-term-make (current-buffer) (point)))
    (let ((codex-ide-term-blink-cursor t)
          state)
      (setf (eat-term-parameter eat-terminal 'set-cursor-function)
            (lambda (_terminal cursor-state) (setq state cursor-state)))
      (cl-letf (((symbol-function 'eat-term-cursor-type)
                 (lambda (_terminal) :blinking-underline)))
        (codex-ide-term--configure-buffer))
      (should (eq state :blinking-underline)))))

(defun codex-ide-test--sync-scroll (park snapshot-p &optional emacs-mode-p)
  "Run the scroll sync override with point parked at PARK.
The stubbed terminal display region begins at buffer position 5.  When
SNAPSHOT-P, pass eat's would-be pre-output snapshot (buffer plus the
selected window); otherwise pass nil.  EMACS-MODE-P selects Eat's
Emacs input mode instead of semi-char mode.  Return (SYNCED . WINDOW),
the list forwarded to `eat--synchronize-scroll' and the selected window."
  (let ((buffer (generate-new-buffer " *codex-ide-sync-test*"))
        synced window)
    (unwind-protect
        (cl-letf (((symbol-function 'eat--synchronize-scroll)
                   (lambda (windows)
                     (setq synced windows)))
                  ((symbol-function 'eat-term-display-beginning)
                   (lambda (_terminal) 5)))
          (save-window-excursion
            (switch-to-buffer buffer)
            (insert "scrollback and display text")
            (setq-local eat-terminal 'dummy)
            (if emacs-mode-p
                (eat-emacs-mode)
              (eat-semi-char-mode))
            (goto-char park)
            (setq window (selected-window))
            (codex-ide-term-eat--synchronize-scroll
             (and snapshot-p (list 'buffer window)))))
      (kill-buffer buffer))
    (cons synced window)))

(ert-deftest codex-ide-term-synchronize-scroll-rescues-display-point ()
  "Off-snapshot points inside the display region snap to the cursor."
  (pcase-let ((`(,synced . ,window) (codex-ide-test--sync-scroll 7 nil)))
    (should (equal synced (list 'buffer window)))))

(ert-deftest codex-ide-term-synchronize-scroll-leaves-scrollback-alone ()
  "Points parked above the display region are not yanked to the cursor."
  (pcase-let ((`(,synced . ,_window) (codex-ide-test--sync-scroll 2 nil)))
    (should-not synced)))

(ert-deftest codex-ide-term-synchronize-scroll-rescues-collapsed-point ()
  "Points collapsed to `point-min' by a scrollback purge re-sync."
  (pcase-let ((`(,synced . ,window) (codex-ide-test--sync-scroll 1 nil)))
    (should (equal synced (list 'buffer window)))))

(ert-deftest codex-ide-term-synchronize-scroll-honors-eat-snapshot ()
  "Positions eat saw on the cursor before output always sync."
  (pcase-let ((`(,synced . ,window) (codex-ide-test--sync-scroll 2 t)))
    (should (equal synced (list 'buffer window)))))

(ert-deftest codex-ide-term-synchronize-scroll-leaves-emacs-mode-free ()
  "Off-snapshot display positions stay free in Eat Emacs mode."
  (pcase-let ((`(,synced . ,_window)
               (codex-ide-test--sync-scroll 7 nil t)))
    (should-not synced)))

(ert-deftest codex-ide-term-synchronize-scroll-honors-emacs-snapshot ()
  "Eat snapshots remain authoritative in Eat Emacs mode."
  (pcase-let ((`(,synced . ,window)
               (codex-ide-test--sync-scroll 7 t t)))
    (should (equal synced (list 'buffer window)))))

(ert-deftest codex-ide-return-live-restores-terminal-following ()
  "Returning live restores input, point, window, and recentering."
  (with-temp-buffer
    (eat-mode)
    (let ((inhibit-read-only t))
      (insert "0123456789abcdef"))
    (setq-local eat-terminal 'dummy)
    (goto-char 2)
    (let ((buffer (current-buffer))
          recentered)
      (save-window-excursion
        (switch-to-buffer buffer)
        (cl-letf (((symbol-function 'eat-term-display-cursor)
                   (lambda (_terminal) 10))
                  ((symbol-function 'eat-term-display-beginning)
                   (lambda (_terminal) 5))
                  ((symbol-function 'eat-term-size)
                   (lambda (_terminal) '(80 . 24)))
                  ((symbol-function 'recenter)
                   (lambda (&rest args)
                     (setq recentered args))))
          (codex-ide-return-live))
        (should eat--semi-char-mode)
        (should-not eat--char-mode)
        (should-not eat--line-mode)
        (should-not buffer-read-only)
        (should (= (point) 10))
        (should (= (window-point (selected-window)) 10))
        (should recentered)))))

(ert-deftest codex-ide-term-synchronize-window-syncs-window ()
  "The window hook delegates the window to Eat's scroll sync."
  (let ((buffer (generate-new-buffer " *codex-ide-snap-test*"))
        synced)
    (unwind-protect
        (with-current-buffer buffer
          (setq-local eat-terminal 'dummy)
          (save-window-excursion
            (switch-to-buffer buffer)
            (cl-letf (((symbol-function 'eat--synchronize-scroll)
                       (lambda (windows)
                         (setq synced windows))))
              (codex-ide-term-eat--synchronize-window (selected-window)))
            (should (equal synced (list (selected-window))))))
      (kill-buffer buffer))))

(ert-deftest codex-ide-term-synchronize-window-ignores-non-eat-buffers ()
  "The window hook leaves windows on non-Eat buffers alone."
  (let ((buffer (generate-new-buffer " *codex-ide-snap-plain*"))
        synced)
    (unwind-protect
        (save-window-excursion
          (switch-to-buffer buffer)
          (cl-letf (((symbol-function 'eat--synchronize-scroll)
                     (lambda (windows)
                       (setq synced windows))))
            (codex-ide-term-eat--synchronize-window (selected-window)))
          (should-not synced))
      (kill-buffer buffer))))

(ert-deftest codex-ide-term-sync-dimensions-delegates ()
  "Display sync delegates to eat's window size adjustment function."
  (codex-ide-test--call-with-buffer-process
   (lambda (buffer process)
     (let (called)
       (process-put
        process 'adjust-window-size-function
        (lambda (sync-process windows)
          (setq called (list sync-process windows))))
       (save-window-excursion
         (switch-to-buffer buffer)
         (let ((window (selected-window)))
           (codex-ide-term--sync-dimensions buffer window)
           (should (equal called (list process (list window))))))))))

(ert-deftest codex-ide-term-sync-dimensions-does-not-resize-process ()
  "Display sync does not manually resize terminal processes."
  (codex-ide-test--call-with-buffer-process
   (lambda (buffer process)
     (let (resized)
       (process-put process 'adjust-window-size-function
                    (lambda (&rest _args) nil))
       (save-window-excursion
         (switch-to-buffer buffer)
         (cl-letf (((symbol-function 'set-process-window-size)
                    (lambda (&rest _args)
                      (setq resized t))))
           (codex-ide-term--sync-dimensions buffer (selected-window))
           (should-not resized)))))))

(ert-deftest codex-ide-term-make-process-starts-eat-session ()
  "Session creation yields a live eat process with argv and env intact."
  (codex-ide-test--call-with-eat-process
   "printf '%s' \"$CODEX_IDE_TEST_VAR\"; sleep 60"
   (lambda (buffer process)
     (should (process-live-p process))
     (with-current-buffer buffer
       (should (eq major-mode 'eat-mode))
       ;; Session recovery matches the program inside `process-command';
       ;; eat's stty wrapper must keep the real argv visible.
       (should (member "sh" (process-command process)))
       (should (codex-ide-test--wait-for
                (lambda ()
                  (string-match-p "codex-env-ok" (buffer-string)))))))
   '("CODEX_IDE_TEST_VAR=codex-env-ok")))

(ert-deftest codex-ide-term-process-starts-at-visible-window-size ()
  "The child process sees the displayed window size on its first output."
  (save-window-excursion
    (delete-other-windows)
    (codex-ide-test--call-with-eat-process
     "stty size; sleep 60"
     (lambda (buffer _process)
       (with-current-buffer buffer
         (pcase-let ((`(,columns . ,rows) (eat-term-size eat-terminal)))
           (should
            (codex-ide-test--wait-for
             (lambda ()
               (string-match-p
                (format "\\b%d %d\\b" rows columns)
                (buffer-string)))))))))))

(ert-deftest codex-ide-term-point-survives-erase-display ()
  "Point tracks the cursor across full-screen redraws.
Regression test for the bug that forced the switch to vterm: an
erase-display sequence collapsed off-cursor points to `point-min' and
eat never restored them."
  (codex-ide-test--call-with-eat-process
   "printf 'one\\r\\ntwo\\r\\nthree\\r\\n'; read x; printf '\\033[H\\033[2Jredrawn'; read y"
   (lambda (buffer process)
     (with-current-buffer buffer
       (should (codex-ide-test--wait-for
                (lambda ()
                  (string-match-p "three" (buffer-string)))))
       ;; Park point away from the cursor, as a stale window switch or a
       ;; user click would, then let the TUI redraw everything.
       (goto-char (point-min))
       (process-send-string process "\n")
       (should (codex-ide-test--wait-for
                (lambda ()
                  (string-match-p "redrawn" (buffer-string)))))
       (should (= (point) (eat-term-display-cursor eat-terminal)))))))

(ert-deftest codex-ide-term-scrollback-point-survives-output ()
  "A point parked in the scrollback stays put while output streams."
  (codex-ide-test--call-with-eat-process
   "i=1; while [ $i -le 80 ]; do printf 'line-%s\\r\\n' $i; i=$((i+1)); done; read x; printf 'tail\\r\\n'; read y"
   (lambda (buffer process)
     (with-current-buffer buffer
       (should (codex-ide-test--wait-for
                (lambda ()
                  (string-match-p "line-80" (buffer-string)))))
       ;; Park point above the display region, as scrolling back does.
       ;; Not at `point-min': that position re-syncs by design, since
       ;; scrollback purges collapse dragged points there.
       (goto-char (+ (point-min) 10))
       (should (< (point) (eat-term-display-beginning eat-terminal)))
       (process-send-string process "\n")
       (should (codex-ide-test--wait-for
                (lambda ()
                  (string-match-p "tail" (buffer-string)))))
       (should (= (point) (+ (point-min) 10)))))))

(ert-deftest codex-ide-term-point-survives-scrollback-purge ()
  "Point re-syncs when a resize-style redraw purges the scrollback.
Codex resize reflows emit ESC [2J and ESC [3J, deleting the whole
buffer and collapsing every point and marker to `point-min'.  Once the
transcript is re-emitted the collapsed point sits below the display
region, where the scrollback-browsing rule alone would strand it."
  (codex-ide-test--call-with-eat-process
   (concat
    "i=1; while [ $i -le 80 ]; do printf 'line-%s\\r\\n' $i; i=$((i+1)); done;"
    " read x; printf '\\033[H\\033[2J\\033[3J';"
    " i=1; while [ $i -le 80 ]; do printf 'again-%s\\r\\n' $i; i=$((i+1)); done;"
    " printf 'redrawn\\r\\n'; read y")
   (lambda (buffer process)
     (with-current-buffer buffer
       (should (codex-ide-test--wait-for
                (lambda ()
                  (string-match-p "line-80" (buffer-string)))))
       ;; Park point mid-scrollback, then let the purge and reflow run.
       (goto-char (+ (point-min) 40))
       (process-send-string process "\n")
       (should (codex-ide-test--wait-for
                (lambda ()
                  (string-match-p "redrawn" (buffer-string)))))
       (should (= (point) (eat-term-display-cursor eat-terminal)))))))

(ert-deftest codex-ide-default-buffer-name ()
  "Buffer name uses the project basename."
  (should (equal (codex-ide--default-buffer-name "/tmp/foo")
                 "*codex[foo]*"))
  (should (equal (codex-ide--default-buffer-name "/tmp/foo/")
                 (codex-ide--default-buffer-name "/tmp/foo"))))

(ert-deftest codex-ide-indexed-buffer-name ()
  "Additional same-project sessions get indexed buffer names."
  (let ((base (codex-ide--get-buffer-name "/tmp/foo" 1)))
    (should (equal base (codex-ide--default-buffer-name "/tmp/foo")))
    (should (equal (codex-ide--get-buffer-name "/tmp/foo" 2)
                   (concat (substring base 0 -1) "<2>*")))))

(ert-deftest codex-ide-display-buffer-function-default ()
  "Codex pops the terminal buffer to another window by default."
  (should (eq codex-ide-display-buffer-function #'pop-to-buffer)))

(ert-deftest codex-ide-display-buffer-calls-custom-function ()
  "Display helper delegates buffer placement to the configured function."
  (let ((buffer (get-buffer-create " *codex-ide-display-test*"))
        (main (get-buffer-create " *codex-ide-main-test*"))
        called synced)
    (unwind-protect
        (save-window-excursion
          (delete-other-windows)
          (switch-to-buffer main)
          (cl-letf (((symbol-function 'codex-ide-term--sync-dimensions)
                     (lambda (sync-buffer sync-window)
                       (setq synced (list sync-buffer sync-window)))))
            (let ((codex-ide-display-buffer-function
                   (lambda (buf)
                     (setq called buf)
                     (pop-to-buffer-same-window buf)
                     (selected-window))))
              (let ((window (codex-ide--display-buffer buffer)))
                (should (eq called buffer))
                (should (eq window (selected-window)))
                (should (eq (window-buffer window) buffer))
                (should (equal synced (list buffer window)))))))
      (when (buffer-live-p buffer)
        (kill-buffer buffer))
      (when (buffer-live-p main)
        (kill-buffer main)))))

(ert-deftest codex-ide-display-buffer-uses-buffer-result-window ()
  "A display function may return the displayed buffer instead of a window."
  (let ((buffer (get-buffer-create " *codex-ide-buffer-result-test*"))
        (main (get-buffer-create " *codex-ide-buffer-result-main-test*"))
        synced)
    (unwind-protect
        (save-window-excursion
          (delete-other-windows)
          (switch-to-buffer main)
          (cl-letf (((symbol-function 'codex-ide-term--sync-dimensions)
                     (lambda (sync-buffer sync-window)
                       (setq synced (list sync-buffer sync-window)))))
            (let ((codex-ide-display-buffer-function
                   (lambda (buf)
                     (switch-to-buffer buf)
                     buf)))
              (let ((window (codex-ide--display-buffer buffer)))
                (should (window-live-p window))
                (should (eq (window-buffer window) buffer))
                (should (equal synced (list buffer window)))))))
      (when (buffer-live-p buffer)
        (kill-buffer buffer))
      (when (buffer-live-p main)
        (kill-buffer main)))))

(ert-deftest codex-ide-display-buffer-selects-existing-window ()
  "Displaying an already visible Codex buffer selects its window."
  (let ((buffer (get-buffer-create " *codex-ide-existing-test*"))
        (main (get-buffer-create " *codex-ide-existing-main-test*"))
        (other (get-buffer-create " *codex-ide-existing-other-test*"))
        called synced)
    (unwind-protect
        (save-window-excursion
          (delete-other-windows)
          (switch-to-buffer main)
          (split-window-right)
          (other-window 1)
          (switch-to-buffer buffer)
          (let ((codex-window (selected-window)))
            (other-window 1)
            (switch-to-buffer other)
            (cl-letf (((symbol-function 'codex-ide-term--sync-dimensions)
                       (lambda (sync-buffer sync-window)
                         (setq synced (list sync-buffer sync-window)))))
              (let ((codex-ide-display-buffer-function
                     (lambda (_buffer)
                       (setq called t)
                       (selected-window))))
                (let ((window (codex-ide--display-buffer buffer)))
                  (should-not called)
                  (should (eq window codex-window))
                  (should (eq (selected-window) codex-window))
                  (should (equal synced (list buffer codex-window)))
                  (should (= (length (get-buffer-window-list buffer nil t))
                             1)))))))
      (when (buffer-live-p buffer)
        (kill-buffer buffer))
      (when (buffer-live-p main)
        (kill-buffer main))
      (when (buffer-live-p other)
        (kill-buffer other)))))

(ert-deftest codex-ide-display-buffer-syncs-visible-buffer-on-nil-result ()
  "Display sync still runs when a nil result leaves the buffer visible."
  (let ((buffer (get-buffer-create " *codex-ide-nil-result-test*"))
        (main (get-buffer-create " *codex-ide-nil-result-main-test*"))
        synced)
    (unwind-protect
        (save-window-excursion
          (delete-other-windows)
          (switch-to-buffer main)
          (cl-letf (((symbol-function 'codex-ide-term--sync-dimensions)
                     (lambda (sync-buffer sync-window)
                       (setq synced (list sync-buffer sync-window)))))
            (let ((codex-ide-display-buffer-function
                   (lambda (buf)
                     (switch-to-buffer buf)
                     nil)))
              (let ((window (codex-ide--display-buffer buffer)))
                (should (window-live-p window))
                (should (equal synced (list buffer window)))))))
      (when (buffer-live-p buffer)
        (kill-buffer buffer))
      (when (buffer-live-p main)
        (kill-buffer main)))))

(ert-deftest codex-ide-display-buffer-skips-sync-when-not-visible ()
  "Display sync is skipped when the configured function shows no window."
  (let ((buffer (get-buffer-create " *codex-ide-no-window-test*"))
        called)
    (unwind-protect
        (save-window-excursion
          (cl-letf (((symbol-function 'codex-ide-term--sync-dimensions)
                     (lambda (&rest _args)
                       (setq called t))))
            (let ((codex-ide-display-buffer-function
                   (lambda (_buffer) nil)))
              (should-not (codex-ide--display-buffer buffer))
              (should-not called))))
      (when (buffer-live-p buffer)
        (kill-buffer buffer)))))

(ert-deftest codex-ide-toggle-hides-window-without-killing-buffer ()
  "Toggling a visible Codex window hides it and leaves the buffer alive."
  (let ((buffer (get-buffer-create " *codex-ide-toggle-window-test*"))
        (main (get-buffer-create " *codex-ide-toggle-main-test*"))
        (codex-ide-display-buffer-function #'pop-to-buffer-same-window))
    (unwind-protect
        (save-window-excursion
          (delete-other-windows)
          (switch-to-buffer main)
          (should (window-live-p (codex-ide--display-buffer buffer)))
          (should (get-buffer-window buffer t))
          (codex-ide--toggle-existing-window buffer)
          (should (buffer-live-p buffer))
          (should-not (get-buffer-window buffer t)))
      (when (buffer-live-p buffer)
        (kill-buffer buffer))
      (when (buffer-live-p main)
        (kill-buffer main)))))

(ert-deftest codex-ide-get-working-directory-default ()
  "Without a project, working directory falls back to `default-directory'."
  (let ((default-directory "/tmp/"))
    (should (equal (codex-ide--get-working-directory)
                   (expand-file-name "/tmp/")))))

(ert-deftest codex-ide-get-working-directory-project-root ()
  "Inside a project, working directory is the project root."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-project-" t)))
         (subdir (expand-file-name "sub/" root)))
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root))
          (make-directory subdir)
          (let ((default-directory subdir))
            (should (equal (file-truename (codex-ide--get-working-directory))
                           (file-truename root)))))
      (delete-directory root t))))

(ert-deftest codex-ide-session-candidates-empty ()
  "Empty session table produces no session candidates."
  (let ((codex-ide--sessions (make-hash-table :test 'equal))
        (codex-ide--active-session-ids (make-hash-table :test 'equal)))
    (should-not (codex-ide--session-candidates))))

(ert-deftest codex-ide-session-candidates-live ()
  "Live session table entries produce buffer-name candidates."
  (let* ((dir-a (file-name-as-directory
                 (make-temp-file "codex-ide-alpha-" t)))
         (dir-b (file-name-as-directory
                 (make-temp-file "codex-ide-beta-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,dir-a 1) (,dir-b 1))
         (lambda (_sessions)
           (let ((candidates (codex-ide--session-candidates)))
             (should (equal (mapcar #'car candidates)
                            (sort (list (codex-ide--get-buffer-name dir-a)
                                        (codex-ide--get-buffer-name dir-b))
                                  #'string<)))
             (should (equal (sort (mapcar (lambda (candidate)
                                            (plist-get (cdr candidate) :root))
                                          candidates)
                                  #'string<)
                            (sort (list dir-a dir-b) #'string<))))))
      (delete-directory dir-a t)
      (delete-directory dir-b t))))

(ert-deftest codex-ide-session-candidates-filter-dead-and-missing-buffers ()
  "Only live session entries with live buffers become candidates."
  (let ((live-dir (file-name-as-directory
                   (make-temp-file "codex-ide-live-" t)))
        (dead-dir (file-name-as-directory
                   (make-temp-file "codex-ide-dead-" t)))
        (missing-dir (file-name-as-directory
                      (make-temp-file "codex-ide-missing-" t)))
        (codex-ide--sessions (make-hash-table :test 'equal))
        (codex-ide--active-session-ids (make-hash-table :test 'equal))
        live-process
        dead-process
        missing-process
        dead-buffer
        live-buffer
        missing-buffer)
    (unwind-protect
        (progn
          (setq live-buffer (get-buffer-create
                             (codex-ide--get-buffer-name live-dir)))
          (setq dead-buffer (get-buffer-create
                             (codex-ide--get-buffer-name dead-dir)))
          (setq missing-buffer (get-buffer-create
                                (codex-ide--get-buffer-name missing-dir)))
          (setq live-process (codex-ide-test--make-buffer-process
                              live-buffer "codex-ide-live"))
          (setq dead-process (codex-ide-test--make-buffer-process
                              dead-buffer "codex-ide-dead"))
          (setq missing-process (codex-ide-test--make-buffer-process
                                 missing-buffer "codex-ide-missing"))
          (set-process-query-on-exit-flag live-process nil)
          (set-process-query-on-exit-flag dead-process nil)
          (set-process-query-on-exit-flag missing-process nil)
          (puthash live-dir
                   (list (codex-ide--make-session live-dir 1
                                                  live-buffer live-process))
                   codex-ide--sessions)
          (puthash dead-dir
                   (list (codex-ide--make-session
                          dead-dir 1 dead-buffer dead-process))
                   codex-ide--sessions)
          (puthash missing-dir
                   (list (codex-ide--make-session missing-dir 1
                                                  missing-buffer
                                                  missing-process))
                   codex-ide--sessions)
          (delete-process dead-process)
          (kill-buffer missing-buffer)
          (let ((candidates (codex-ide--session-candidates)))
            (should (equal candidates
                           (list (cons (buffer-name live-buffer)
                                       (codex-ide--make-session
                                        live-dir 1 live-buffer
                                        live-process)))))
            (should-not (gethash dead-dir codex-ide--sessions))
            (should-not (gethash missing-dir codex-ide--sessions))))
      (when (and live-process (process-live-p live-process))
        (delete-process live-process))
      (when (and dead-process (process-live-p dead-process))
        (delete-process dead-process))
      (when (and missing-process (process-live-p missing-process))
        (delete-process missing-process))
      (when (buffer-live-p live-buffer)
        (kill-buffer live-buffer))
      (when (buffer-live-p dead-buffer)
        (kill-buffer dead-buffer))
      (when (buffer-live-p missing-buffer)
        (kill-buffer missing-buffer))
      (delete-directory live-dir t)
      (delete-directory dead-dir t)
      (delete-directory missing-dir t))))

(ert-deftest codex-ide-session-annotation-shows-directory ()
  "Session completion annotations show the abbreviated directory."
  (let* ((directory (file-name-as-directory
                     (make-temp-file "codex-ide-annotation-" t)))
         (session (codex-ide--make-session directory 1 nil nil))
         (candidates `(("buffer" . ,session)))
         (annotation (funcall (codex-ide--session-annotation-function
                               candidates)
                              "buffer")))
    (unwind-protect
        (should (equal (substring-no-properties annotation)
                       (concat "  " (abbreviate-file-name directory))))
      (delete-directory directory t))))

(ert-deftest codex-ide-read-session-uses-annotated-completion ()
  "Session reader uses completing-read with an annotation function."
  (let* ((directory (file-name-as-directory
                     (make-temp-file "codex-ide-read-" t)))
         (codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         session)
    (unwind-protect
        (progn
          (setq session (codex-ide-test--make-session directory 1))
          (codex-ide-test--store-session session)
          (cl-letf (((symbol-function 'completing-read)
                     (lambda (prompt collection _predicate require-match
                                     &rest _args)
                       (setq collection (codex-ide-test--completion-candidates collection))
                       (should (equal prompt "Codex session: "))
                       (should (equal collection
                                      (list (cons
                                             (buffer-name
                                              (plist-get session :buffer))
                                             session))))
                       (should require-match)
                       (should (functionp
                                (plist-get completion-extra-properties
                                           :annotation-function)))
                       (buffer-name (plist-get session :buffer)))))
            (should (eq (codex-ide--read-session) session))))
      (when session
        (codex-ide-test--kill-session session))
      (delete-directory directory t))))

(ert-deftest codex-ide-read-session-uses-default-session ()
  "Session reader supplies DEFAULT-SESSION as completion default."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-read-default-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((default (cl-find 2 sessions
                                   :key (lambda (session)
                                          (plist-get session :id))))
                 seen-default)
             (cl-letf (((symbol-function 'completing-read)
                        (lambda (_prompt _collection _predicate _require-match
                                         _initial-input _hist def
                                         &rest _args)
                          (setq seen-default def)
                          def)))
               (should (eq (codex-ide--read-session root default)
                           default)))
             (should (equal seen-default
                            (buffer-name (plist-get default :buffer)))))))
      (delete-directory root t))))

(ert-deftest codex-ide-target-session-single-session-does-not-prompt ()
  "Single project session is selected without completion."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-target-single-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1))
         (lambda (sessions)
           (cl-letf (((symbol-function 'completing-read)
                      (lambda (&rest _args)
                        (error "Unexpected session prompt"))))
             (let ((session (let ((default-directory root))
                              (codex-ide--target-session))))
               (should (eq session (car sessions)))
               (should (= (gethash root codex-ide--active-session-ids)
                          1))))))
      (delete-directory root t))))

(ert-deftest codex-ide-target-session-multiple-sessions-prompts ()
  "Multiple project sessions are selected with project-filtered completion."
  (let ((root-a (file-name-as-directory
                 (make-temp-file "codex-ide-target-a-" t)))
        (root-b (file-name-as-directory
                 (make-temp-file "codex-ide-target-b-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root-a 1) (,root-a 2) (,root-b 1))
         (lambda (_sessions)
           (let (seen)
             (cl-letf (((symbol-function 'completing-read)
                        (lambda (_prompt collection _predicate _require-match
                                         &rest _args)
                          (setq collection (codex-ide-test--completion-candidates collection))
                          (setq seen collection)
                          (car (cl-find 1 collection
                                        :key (lambda (candidate)
                                               (plist-get (cdr candidate)
                                                          :id))
                                        :test #'=)))))
               (let ((session (let ((default-directory root-a))
                                (codex-ide--target-session))))
                 (should (= (plist-get session :id) 1))))
             (should (equal (delete-dups
                             (mapcar (lambda (candidate)
                                       (plist-get (cdr candidate) :root))
                                     seen))
                            (list root-a)))
             (should (= (gethash root-a codex-ide--active-session-ids)
                        1)))))
      (delete-directory root-a t)
      (delete-directory root-b t))))

(ert-deftest codex-ide-create-session-uses-process-buffer ()
  "Session creation records the actual process buffer."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let* ((requested-buffer (get-buffer-create
                               (codex-ide--get-buffer-name root)))
            (actual-buffer (generate-new-buffer
                            (format "%s<2>"
                                    (codex-ide--get-buffer-name root))))
            requested-name
            process)
       (unwind-protect
           (cl-letf (((symbol-function 'codex-ide--display-buffer)
                      (lambda (_buffer &optional _select) (selected-window)))
                     ((symbol-function 'codex-ide-term--make-process)
                      (lambda (buffer _program _args _env)
                        (setq requested-name (buffer-name buffer))
                        (setq process
                              (codex-ide-test--make-buffer-process
                               actual-buffer
                               "codex-ide-process-buffer"))
                        process)))
             (let ((default-directory root))
               (let ((session (codex-ide--create-session 1)))
                 (should (equal requested-name
                                (codex-ide--get-buffer-name root)))
                 (should (eq (plist-get session :buffer) actual-buffer))
                 (should-not
                  (eq (plist-get session :buffer) requested-buffer)))))
         (codex-ide-test--kill-buffer-process actual-buffer process)
         (when (buffer-live-p requested-buffer)
           (kill-buffer requested-buffer)))))))

(ert-deftest codex-ide-create-session-displays-before-process-start ()
  "Session creation prepares and displays the buffer before process start."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let (events process buffer)
       (unwind-protect
           (cl-letf (((symbol-function 'codex-ide-term--prepare-buffer)
                      (lambda (name directory)
                        (push (list 'prepare name directory) events)
                        (setq buffer (get-buffer-create name))))
                     ((symbol-function 'codex-ide--display-buffer)
                      (lambda (display-buffer &optional _select)
                        (push (list 'display display-buffer) events)
                        (selected-window)))
                     ((symbol-function 'codex-ide-term--make-process)
                      (lambda (process-buffer _program _args _env)
                        (push (list 'process process-buffer) events)
                        (setq process
                              (codex-ide-test--make-buffer-process
                               process-buffer "codex-ide-order")))))
             (let ((default-directory root))
               (codex-ide--create-session 1))
             (should (equal (mapcar #'car (nreverse events))
                            '(prepare display process))))
         (codex-ide-test--kill-buffer-process buffer process))))))

(ert-deftest codex-ide-create-session-cleans-up-display-failure ()
  "A display failure kills the prepared buffer before registration."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let (buffer process-started)
       (cl-letf (((symbol-function 'codex-ide-term--prepare-buffer)
                  (lambda (name _directory)
                    (setq buffer (get-buffer-create name))))
                 ((symbol-function 'codex-ide--display-buffer)
                  (lambda (_buffer &optional _select) nil))
                 ((symbol-function 'codex-ide-term--make-process)
                  (lambda (&rest _args) (setq process-started t))))
         (let ((default-directory root))
           (should-error (codex-ide--create-session 1) :type 'error))
         (should-not process-started)
         (should-not (buffer-live-p buffer)))))))

(ert-deftest codex-ide-create-session-cleans-up-process-failure ()
  "A process failure kills the displayed but incomplete buffer."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let (buffer)
       (cl-letf (((symbol-function 'codex-ide-term--prepare-buffer)
                  (lambda (name _directory)
                    (setq buffer (get-buffer-create name))))
                 ((symbol-function 'codex-ide--display-buffer)
                  (lambda (_buffer &optional _select) (selected-window)))
                 ((symbol-function 'codex-ide-term--make-process)
                  (lambda (&rest _args) (error "Process failed"))))
         (let ((default-directory root))
           (should-error (codex-ide--create-session 1) :type 'error))
         (should-not (buffer-live-p buffer)))))))

(ert-deftest codex-ide-recover-live-session-registers-orphan-buffer ()
  "Recovery registers an orphan live Codex buffer without renaming it."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-recover-" t)))
         (codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         (codex-ide-cli-path "sleep")
         (buffer-name (format "%s<2>" (codex-ide--get-buffer-name root)))
         pair buffer process)
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root))
          (setq pair
                (codex-ide-test--make-recoverable-buffer
                 root buffer-name "codex-ide-recover" 2))
          (setq buffer (car pair))
          (setq process (cadr pair))
          (codex-ide--recover-live-sessions)
          (codex-ide--recover-live-sessions)
          (let* ((sessions (codex-ide--project-sessions root))
                 (session (car sessions)))
            (should (= (length sessions) 1))
            (should (eq (plist-get session :buffer) buffer))
            (should (eq (plist-get session :process) process))
            (should (= (plist-get session :id) 2))
            (should (equal (buffer-name buffer) buffer-name))
            (should-not (process-query-on-exit-flag process))
            (should (functionp (process-sentinel process)))
            (with-current-buffer buffer
              (should codex-ide-mode)
              (should (equal codex-ide--session-root root))
              (should (= codex-ide--session-id 2))
              (should (eq (cdr (assq 'codex-ide-mode
                                     (minor-mode-key-binding
                                      (kbd "S-<return>"))))
                          #'codex-ide-insert-newline))
              (should (eq (cdr (assq 'codex-ide-mode
                                     (minor-mode-key-binding
                                      (kbd "C-c C-k"))))
                          #'codex-ide-send-escape)))
            (should (assoc buffer-name
                           (codex-ide--session-candidates root)))
            (should (assoc buffer-name
                           (codex-ide--session-candidates)))))
      (when pair
        (codex-ide-test--kill-buffer-process (car pair) (cadr pair)))
      (delete-directory root t))))

(ert-deftest codex-ide-mode-map-leaves-eat-maps-alone ()
  "Codex bindings live in the minor mode map, not in eat's keymaps."
  (should (eq (lookup-key codex-ide-mode-map (kbd "S-<return>"))
              #'codex-ide-insert-newline))
  (should (eq (lookup-key codex-ide-mode-map (kbd "C-c C-k"))
              #'codex-ide-send-escape))
  (should (eq (lookup-key codex-ide-mode-map (kbd "C-c C-j"))
              #'codex-ide-return-live))
  (should (eq (lookup-key eat-mode-map (kbd "C-c C-j"))
              #'eat-semi-char-mode))
  (dolist (map (list eat-mode-map eat-semi-char-mode-map))
    (should-not (eq (lookup-key map (kbd "S-<return>"))
                    #'codex-ide-insert-newline))
    (should-not (eq (lookup-key map (kbd "C-c C-k"))
                    #'codex-ide-send-escape))
    (should-not (eq (lookup-key map (kbd "C-c C-j"))
                    #'codex-ide-return-live)))
  (with-temp-buffer
    (eat-mode)
    (should (eq (key-binding (kbd "C-c C-j"))
                #'eat-semi-char-mode))
    (codex-ide-mode 1)
    (should (eq (key-binding (kbd "C-c C-j"))
                #'codex-ide-return-live))
    (should (eq (cdr (assq 'codex-ide-mode
                           (minor-mode-key-binding (kbd "S-<return>"))))
                #'codex-ide-insert-newline))
    (should (eq (cdr (assq 'codex-ide-mode
                           (minor-mode-key-binding (kbd "C-c C-j"))))
                #'codex-ide-return-live))))

(ert-deftest codex-ide-mode-manages-cleanup-hook ()
  "Enabling the mode installs the cleanup hook once; disabling removes it."
  (with-temp-buffer
    (codex-ide-mode 1)
    (codex-ide-mode 1)
    (should (= (cl-count #'codex-ide--cleanup-current-buffer-session
                         kill-buffer-hook)
               1))
    (codex-ide-mode -1)
    (should-not (memq #'codex-ide--cleanup-current-buffer-session
                      kill-buffer-hook))))

(ert-deftest codex-ide-recovery-ignores-noncodex-processes ()
  "Recovery ignores Codex-named buffers whose command is not Codex."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-ignore-" t)))
         (codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         (codex-ide-cli-path "codex")
         pair)
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root))
          (setq pair
                (codex-ide-test--make-recoverable-buffer
                 root (codex-ide--get-buffer-name root)
                 "codex-ide-ignore" 1))
          (codex-ide--recover-live-sessions)
          (should-not (codex-ide--project-sessions root)))
      (when pair
        (codex-ide-test--kill-buffer-process (car pair) (cadr pair)))
      (delete-directory root t))))

(ert-deftest codex-ide-recovery-ignores-mode-off-buffers ()
  "Recovery ignores Codex-named buffers without `codex-ide-mode'."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-mode-off-" t)))
         (codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         (codex-ide-cli-path "sleep")
         buffer process)
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root))
          (setq buffer (get-buffer-create (codex-ide--get-buffer-name root)))
          (with-current-buffer buffer
            (setq default-directory root))
          (setq process (codex-ide-test--make-buffer-process
                         buffer "codex-ide-mode-off"))
          (set-process-query-on-exit-flag process nil)
          (codex-ide--recover-live-sessions)
          (should-not (codex-ide--project-sessions root)))
      (codex-ide-test--kill-buffer-process buffer process)
      (delete-directory root t))))

(ert-deftest codex-ide-recovered-session-commands-target-buffer ()
  "Active-session commands target a recovered Codex buffer."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-recovered-commands-" t)))
         (codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         (codex-ide-cli-path "sleep")
         pair buffer process displayed sent returned escaped)
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root))
          (setq pair
                (codex-ide-test--make-recoverable-buffer
                 root (format "%s<2>" (codex-ide--get-buffer-name root))
                 "codex-ide-recovered-commands" 2))
          (setq buffer (car pair))
          (setq process (cadr pair))
          (with-current-buffer buffer (setq major-mode 'eat-mode))
          (codex-ide--recover-live-sessions)
          (cl-letf (((symbol-function 'codex-ide--display-buffer)
                     (lambda (display-buffer &optional _select)
                       (setq displayed display-buffer)))
                    ((symbol-function 'codex-ide-context-record-source-buffer)
                     (lambda (&rest _args) nil))
                    ((symbol-function 'codex-ide-term--paste-draft)
                     (lambda (_process string)
                       (setq sent (append sent (list (list string (current-buffer)))))))
                    ((symbol-function 'codex-ide-term--send-string)
                     (lambda (string)
                       (setq sent
                             (append sent
                                     (list (list string
                                                 (current-buffer)))))))
                    ((symbol-function 'codex-ide-term--send-return)
                     (lambda ()
                       (setq returned
                             (append returned (list (current-buffer))))))
                    ((symbol-function 'codex-ide-term--send-escape)
                     (lambda ()
                       (setq escaped (current-buffer))))
                    ((symbol-function 'sit-for)
                     (lambda (&rest _args) nil))
                    ((symbol-function 'codex-ide-debug)
                     (lambda (&rest _args) nil)))
            (let ((default-directory root))
              (codex-ide-switch-to-buffer)
              (codex-ide-send-prompt "hello")
              (codex-ide-send-escape)
              (codex-ide-insert-newline)))
          (should (eq displayed buffer))
          (should (equal sent (list (list "hello" buffer)
                                    (list "\n" buffer))))
          (should (equal returned (list buffer)))
          (should (eq escaped buffer)))
      (codex-ide-test--kill-buffer-process buffer process)
      (delete-directory root t))))

(ert-deftest codex-ide-stop-targets-recovered-session ()
  "`codex-ide-stop' kills the active recovered session only."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-recovered-stop-" t)))
         (codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         (codex-ide-cli-path "sleep")
         first second)
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root))
          (setq first
                (codex-ide-test--make-recoverable-buffer
                 root (codex-ide--get-buffer-name root)
                 "codex-ide-stop-1" 1))
          (setq second
                (codex-ide-test--make-recoverable-buffer
                 root (format "%s<2>" (codex-ide--get-buffer-name root))
                 "codex-ide-stop-2" 2))
          (codex-ide--recover-live-sessions)
          (codex-ide--activate-session
           (codex-ide--session-by-id root 2))
          (cl-letf (((symbol-function 'codex-ide-log)
                     (lambda (&rest _args) nil)))
            (let ((default-directory root))
              (codex-ide-stop)))
          (should (buffer-live-p (car first)))
          (should-not (buffer-live-p (car second)))
          (should (equal (mapcar (lambda (session)
                                   (plist-get session :id))
                                 (codex-ide--project-sessions root))
                         '(1))))
      (when first
        (codex-ide-test--kill-buffer-process (car first) (cadr first)))
      (when second
        (codex-ide-test--kill-buffer-process (car second) (cadr second)))
      (delete-directory root t))))

(ert-deftest codex-ide-cleanup-recovered-session-preserves-siblings ()
  "Cleanup removes one recovered session and keeps live siblings."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-recovered-cleanup-" t)))
         (codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         (codex-ide-cli-path "sleep")
         first second)
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root))
          (setq first
                (codex-ide-test--make-recoverable-buffer
                 root (codex-ide--get-buffer-name root)
                 "codex-ide-cleanup-1" 1))
          (setq second
                (codex-ide-test--make-recoverable-buffer
                 root (format "%s<2>" (codex-ide--get-buffer-name root))
                 "codex-ide-cleanup-2" 2))
          (codex-ide--recover-live-sessions)
          (codex-ide--cleanup-on-exit root 2)
          (should (buffer-live-p (car first)))
          (should-not (buffer-live-p (car second)))
          (should (equal (mapcar (lambda (session)
                                   (plist-get session :id))
                                 (codex-ide--project-sessions root))
                         '(1))))
      (when first
        (codex-ide-test--kill-buffer-process (car first) (cadr first)))
      (when second
        (codex-ide-test--kill-buffer-process (car second) (cadr second)))
      (delete-directory root t))))

(ert-deftest codex-ide-next-session-id-avoids-recovered-ids ()
  "New live session ids skip ids assigned during recovery."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-recovered-next-" t)))
         (codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         (codex-ide-cli-path "sleep")
         first second)
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root))
          (setq first
                (codex-ide-test--make-recoverable-buffer
                 root (codex-ide--get-buffer-name root)
                 "codex-ide-next-1" 1))
          (setq second
                (codex-ide-test--make-recoverable-buffer
                 root (format "%s<2>" (codex-ide--get-buffer-name root))
                 "codex-ide-next-2" 2))
          (codex-ide--recover-live-sessions)
          (should (equal (sort (mapcar (lambda (session)
                                         (plist-get session :id))
                                       (codex-ide--project-sessions root))
                               #'<)
                         '(1 2)))
          (should (= (codex-ide--next-session-id root) 3)))
      (when first
        (codex-ide-test--kill-buffer-process (car first) (cadr first)))
      (when second
        (codex-ide-test--kill-buffer-process (car second) (cadr second)))
      (delete-directory root t))))

(ert-deftest codex-ide-prefix-and-new-session-create-indexed-sessions ()
  "`C-u M-x codex-ide' and `codex-ide-new-session' create siblings."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let ((codex-ide--sessions (make-hash-table :test 'equal))
           (codex-ide--active-session-ids (make-hash-table :test 'equal))
           (codex-ide-context-auto-start nil)
           created)
       (unwind-protect
           (cl-letf (((symbol-function 'codex-ide--ensure-cli)
                      (lambda () t))
                     ((symbol-function 'codex-ide--create-session)
                      (lambda (emacs-session-id &rest _args)
                        (let ((session
                               (codex-ide-test--make-session
                                root emacs-session-id)))
                          (push session created)
                          session)))
                     ((symbol-function 'codex-ide--display-buffer)
                      (lambda (_buffer &optional _select) nil))
                     ((symbol-function 'codex-ide-context-record-source-buffer)
                      (lambda (&rest _args) nil))
                     ((symbol-function 'codex-ide-log)
                      (lambda (&rest _args) nil))
                     ((symbol-function 'codex-ide-debug)
                      (lambda (&rest _args) nil)))
             (let ((default-directory root))
               (codex-ide)
               (codex-ide '(4))
               (codex-ide-new-session))
             (should (equal (sort (mapcar (lambda (session)
                                            (buffer-name
                                             (plist-get session :buffer)))
                                          (codex-ide--project-sessions root))
                                  #'string<)
                            (sort (list (codex-ide--get-buffer-name root 1)
                                        (codex-ide--get-buffer-name root 2)
                                        (codex-ide--get-buffer-name root 3))
                                  #'string<)))
             (should (= (gethash root codex-ide--active-session-ids) 3)))
         (mapc #'codex-ide-test--kill-session created))))))

(ert-deftest codex-ide-without-prefix-toggles-active-session ()
  "`codex-ide' without prefix toggles the active project session."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-toggle-active-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((active (cl-find 2 sessions
                                  :key (lambda (session)
                                         (plist-get session :id))))
                 created toggled)
             (cl-letf (((symbol-function 'codex-ide--ensure-cli)
                        (lambda () t))
                       ((symbol-function 'codex-ide--create-session)
                        (lambda (&rest _args)
                          (setq created t)))
                       ((symbol-function 'codex-ide--toggle-existing-window)
                        (lambda (buffer)
                          (setq toggled buffer)))
                       ((symbol-function 'codex-ide-context-record-source-buffer)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root))
                 (codex-ide)))
             (should-not created)
             (should (eq toggled (plist-get active :buffer))))))
      (delete-directory root t))))

(ert-deftest codex-ide-toggle-shows-active-session-when-hidden ()
  "`codex-ide-toggle' shows the active project session when none is visible."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-cycle-hidden-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((main (generate-new-buffer " *codex-ide-cycle-main*"))
                 (active (codex-ide-test--session-by-id sessions 2)))
             (unwind-protect
                 (save-window-excursion
                   (delete-other-windows)
                   (switch-to-buffer main)
                   (codex-ide-test--toggle-in-root root)
                   (should (eq (window-buffer) (plist-get active :buffer)))
                   (should (= (gethash root codex-ide--active-session-ids) 2)))
               (when (buffer-live-p main)
                 (kill-buffer main))))))
      (delete-directory root t))))

(ert-deftest codex-ide-toggle-hidden-state-falls-back-to-first-session ()
  "`codex-ide-toggle' uses the first sorted session when no active id exists."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-cycle-fallback-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((main (generate-new-buffer " *codex-ide-cycle-fallback*"))
                 (first (codex-ide-test--session-by-id sessions 1)))
             (remhash root codex-ide--active-session-ids)
             (unwind-protect
                 (save-window-excursion
                   (delete-other-windows)
                   (switch-to-buffer main)
                   (codex-ide-test--toggle-in-root root)
                   (should (eq (window-buffer) (plist-get first :buffer)))
                   (should (= (gethash root codex-ide--active-session-ids) 1)))
               (when (buffer-live-p main)
                 (kill-buffer main))))))
      (delete-directory root t))))

(ert-deftest codex-ide-toggle-cycles-visible-session-to-next ()
  "`codex-ide-toggle' cycles a visible project session to the next id."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-cycle-next-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((first (codex-ide-test--session-by-id sessions 1))
                 (second (codex-ide-test--session-by-id sessions 2)))
             (save-window-excursion
               (delete-other-windows)
               (switch-to-buffer (plist-get first :buffer))
               (codex-ide-test--toggle-in-root root)
               (should (eq (window-buffer) (plist-get second :buffer)))
               (should-not (codex-ide-test--session-visible-p first))
               (should (= (gethash root codex-ide--active-session-ids) 2))))))
      (delete-directory root t))))

(ert-deftest codex-ide-toggle-hides-last-session-then-shows-first ()
  "`codex-ide-toggle' hides after the last session and next shows the first."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-cycle-wrap-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((first (codex-ide-test--session-by-id sessions 1))
                 (second (codex-ide-test--session-by-id sessions 2)))
             (save-window-excursion
               (delete-other-windows)
               (switch-to-buffer (plist-get second :buffer))
               (codex-ide-test--call-with-toggle-stubs
                (lambda ()
                  (let ((default-directory root)
                        (codex-ide-display-buffer-function
                         #'pop-to-buffer-same-window))
                    (codex-ide-test--toggle-in-root root)
                    (should-not (cl-some #'codex-ide-test--session-visible-p
                                         sessions))
                    (dolist (session sessions)
                      (should (buffer-live-p (plist-get session :buffer)))
                      (should (process-live-p (plist-get session :process))))
                    (should (= (gethash root codex-ide--active-session-ids) 1))
                    (codex-ide-test--toggle-in-root root))))
               (should (eq (window-buffer) (plist-get first :buffer)))
               (should (= (gethash root codex-ide--active-session-ids) 1))))))
      (delete-directory root t))))

(ert-deftest codex-ide-toggle-ignores-visible-sessions-from-other-roots ()
  "`codex-ide-toggle' ignores visible Codex windows from other projects."
  (let ((root-a (file-name-as-directory
                 (make-temp-file "codex-ide-cycle-a-" t)))
        (root-b (file-name-as-directory
                 (make-temp-file "codex-ide-cycle-b-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root-a 1) (,root-b 1))
         (lambda (sessions)
           (let ((main (generate-new-buffer " *codex-ide-cycle-other*"))
                 (session-a (codex-ide-test--session-by-root sessions root-a))
                 (session-b (codex-ide-test--session-by-root sessions root-b)))
             (unwind-protect
                 (save-window-excursion
                   (delete-other-windows)
                   (switch-to-buffer main)
                   (split-window-right)
                   (other-window 1)
                   (switch-to-buffer (plist-get session-b :buffer))
                   (let ((other-window (selected-window)))
                     (other-window -1)
                     (codex-ide-test--toggle-in-root root-a)
                     (should (eq (window-buffer)
                                 (plist-get session-a :buffer)))
                     (should (eq (window-buffer other-window)
                                 (plist-get session-b :buffer)))))
               (when (buffer-live-p main)
                 (kill-buffer main))))))
      (delete-directory root-a t)
      (delete-directory root-b t))))

(ert-deftest codex-ide-toggle-without-project-sessions-errors ()
  "`codex-ide-toggle' preserves the no-session user error."
  (let ((root-a (file-name-as-directory
                 (make-temp-file "codex-ide-cycle-empty-a-" t)))
        (root-b (file-name-as-directory
                 (make-temp-file "codex-ide-cycle-empty-b-" t))))
    (unwind-protect
        (progn
          (make-directory (expand-file-name ".git" root-a))
          (codex-ide-test--call-with-sessions
           `((,root-b 1))
           (lambda (_sessions)
             (condition-case err
                 (progn
                   (codex-ide-test--toggle-in-root root-a)
                   (ert-fail "Expected user-error"))
               (user-error
                (should (equal (cadr err)
                               "No Codex session for this project")))))))
      (delete-directory root-a t)
      (delete-directory root-b t))))

(ert-deftest codex-ide-list-project-sessions-filters-current-root ()
  "Project session listing offers only sessions for the current root."
  (let ((root-a (file-name-as-directory
                 (make-temp-file "codex-ide-project-a-" t)))
        (root-b (file-name-as-directory
                 (make-temp-file "codex-ide-project-b-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root-a 1) (,root-a 2) (,root-b 1))
         (lambda (_sessions)
           (let (seen)
             (cl-letf (((symbol-function 'completing-read)
                        (lambda (_prompt collection _predicate _require-match
                                         &rest _args)
                          (setq collection (codex-ide-test--completion-candidates collection))
                          (setq seen collection)
                          (car (cl-find 2 collection
                                        :key (lambda (candidate)
                                               (plist-get (cdr candidate)
                                                          :id))
                                        :test #'=))))
                       ((symbol-function 'codex-ide--display-buffer)
                        (lambda (_buffer &optional _select) nil))
                       ((symbol-function 'codex-ide-context-record-source-buffer)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root-a))
                 (codex-ide-switch-project-session)))
             (should (equal (delete-dups
                             (mapcar (lambda (candidate)
                                       (plist-get (cdr candidate) :root))
                                     seen))
                            (list root-a)))
             (should (= (gethash root-a codex-ide--active-session-ids) 2)))))
      (delete-directory root-a t)
      (delete-directory root-b t))))

(ert-deftest codex-ide-list-sessions-offers-all-roots ()
  "All-session listing offers live sessions from every root."
  (let ((root-a (file-name-as-directory
                 (make-temp-file "codex-ide-all-a-" t)))
        (root-b (file-name-as-directory
                 (make-temp-file "codex-ide-all-b-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root-a 1) (,root-b 1))
         (lambda (_sessions)
           (let (seen)
             (cl-letf (((symbol-function 'completing-read)
                        (lambda (_prompt collection _predicate _require-match
                                         &rest _args)
                          (setq collection (codex-ide-test--completion-candidates collection))
                          (setq seen collection)
                          (car (cl-find root-b collection
                                        :key (lambda (candidate)
                                               (plist-get (cdr candidate)
                                                          :root))
                                        :test #'equal))))
                       ((symbol-function 'codex-ide--display-buffer)
                        (lambda (_buffer &optional _select) nil))
                       ((symbol-function 'codex-ide-context-record-source-buffer)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root-a))
                 (codex-ide-switch-session)))
             (should (equal (sort (mapcar (lambda (candidate)
                                            (plist-get (cdr candidate)
                                                       :root))
                                          seen)
                                  #'string<)
                            (sort (list root-a root-b) #'string<)))
             (should (= (gethash root-b codex-ide--active-session-ids) 1)))))
      (delete-directory root-a t)
      (delete-directory root-b t))))

(ert-deftest codex-ide-send-prompt-prompts-for-multiple-sessions ()
  "Prompt sending writes to the selected project session."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-prompt-target-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((target (cl-find 1 sessions
                                  :key (lambda (session)
                                         (plist-get session :id))))
                 sent returned)
             (with-current-buffer (plist-get target :buffer)
               (setq major-mode 'eat-mode)
               (codex-ide-mode 1))
             (cl-letf (((symbol-function 'codex-ide-context-record-source-buffer)
                        (lambda (&rest _args) nil))
                       ((symbol-function 'completing-read)
                        (lambda (_prompt collection _predicate _require-match
                                         &rest _args)
                          (setq collection (codex-ide-test--completion-candidates collection))
                          (car (cl-find 1 collection
                                        :key (lambda (candidate)
                                               (plist-get (cdr candidate)
                                                          :id))
                                        :test #'=))))
                       ((symbol-function 'codex-ide-term--paste-draft)
                        (lambda (_process string)
                          (setq sent (list string (current-buffer)))))
                       ((symbol-function 'codex-ide-term--send-return)
                        (lambda ()
                          (setq returned (current-buffer))))
                       ((symbol-function 'sit-for)
                        (lambda (&rest _args) nil))
                       ((symbol-function 'codex-ide-debug)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root))
                 (codex-ide-send-prompt "active")))
             (should (equal sent (list "active"
                                       (plist-get target :buffer))))
             (should (eq returned (plist-get target :buffer)))
             (should (= (gethash root codex-ide--active-session-ids)
                        1)))))
      (delete-directory root t))))

(ert-deftest codex-ide-terminal-input-prompts-for-multiple-sessions ()
  "Escape and newline commands write to the selected project session."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-input-target-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((target (cl-find 1 sessions
                                  :key (lambda (session)
                                         (plist-get session :id))))
                 sent returned escaped)
             (with-current-buffer (plist-get target :buffer)
               (setq major-mode 'eat-mode)
               (codex-ide-mode 1))
             (cl-letf (((symbol-function 'completing-read)
                        (lambda (_prompt collection _predicate _require-match
                                         &rest _args)
                          (setq collection (codex-ide-test--completion-candidates collection))
                          (car (cl-find 1 collection
                                        :key (lambda (candidate)
                                               (plist-get (cdr candidate)
                                                          :id))
                                        :test #'=))))
                       ((symbol-function 'codex-ide-term--send-string)
                        (lambda (string)
                          (setq sent
                                (append sent
                                        (list (list string
                                                    (current-buffer)))))))
                       ((symbol-function 'codex-ide-term--send-return)
                        (lambda ()
                          (setq returned
                                (append returned
                                        (list (current-buffer))))))
                       ((symbol-function 'codex-ide-term--send-escape)
                        (lambda ()
                          (setq escaped (current-buffer))))
                       ((symbol-function 'sit-for)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root))
                 (codex-ide-send-escape)
                 (codex-ide-insert-newline)))
             (should (eq escaped (plist-get target :buffer)))
             (should (equal sent
                            (list (list "\n" (plist-get target :buffer)))))
             (should-not returned)
             (should (= (gethash root codex-ide--active-session-ids)
                        1)))))
      (delete-directory root t))))

(ert-deftest codex-ide-terminal-input-targets-own-session ()
  "Escape from a session buffer targets it without prompting."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-input-own-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((by-id (lambda (id)
                          (cl-find id sessions
                                   :key (lambda (session)
                                          (plist-get session :id))
                                   :test #'=)))
                 escaped)
             (codex-ide--activate-session (funcall by-id 1))
             (cl-letf (((symbol-function 'completing-read)
                        (lambda (&rest _args)
                          (error "Unexpected session prompt")))
                       ((symbol-function 'codex-ide-term--send-escape)
                        (lambda ()
                          (setq escaped (current-buffer)))))
               (with-current-buffer (plist-get (funcall by-id 2) :buffer)
                 (let ((default-directory root))
                   (codex-ide-send-escape))))
             (should (eq escaped (plist-get (funcall by-id 2) :buffer)))
             (should (= (gethash root codex-ide--active-session-ids)
                        2)))))
      (delete-directory root t))))

(ert-deftest codex-ide-stop-targets-active-session ()
  "`codex-ide-stop' kills only the active project session buffer."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-stop-active-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((inactive (cl-find 1 sessions
                                    :key (lambda (session)
                                           (plist-get session :id))))
                 (active (cl-find 2 sessions
                                  :key (lambda (session)
                                         (plist-get session :id)))))
             (cl-letf (((symbol-function 'codex-ide-log)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root))
                 (codex-ide-stop)))
             (should (buffer-live-p (plist-get inactive :buffer)))
             (should-not (buffer-live-p (plist-get active :buffer))))))
      (delete-directory root t))))

(ert-deftest codex-ide-stop-leaves-context-provider-running ()
  "`codex-ide-stop' does not stop the user-wide context provider."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-stop-context-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1))
         (lambda (_sessions)
           (let ((codex-ide-context-mode t)
                 stopped-provider)
             (cl-letf (((symbol-function 'codex-ide-context-stop)
                        (lambda ()
                          (setq stopped-provider t)))
                       ((symbol-function 'codex-ide-log)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root))
                 (codex-ide-stop)))
             (should codex-ide-context-mode)
             (should-not stopped-provider))))
      (delete-directory root t))))

(ert-deftest codex-ide-cleanup-removes-only-dead-session ()
  "Cleanup removes one dead session and preserves live siblings."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-cleanup-active-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let ((kept (cl-find 1 sessions
                                :key (lambda (session)
                                       (plist-get session :id)))))
             (codex-ide--cleanup-on-exit root 2)
             (should (equal (mapcar (lambda (session)
                                      (plist-get session :id))
                                    (codex-ide--project-sessions root))
                            '(1)))
             (should (buffer-live-p (plist-get kept :buffer)))
             (should (= (gethash root codex-ide--active-session-ids) 1)))))
      (delete-directory root t))))

(ert-deftest codex-ide-cleanup-accepts-buffer-argument ()
  "Cleanup tolerates hook-style calls with the session buffer."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-cleanup-buffer-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1))
         (lambda (sessions)
           (let ((session (car sessions)))
             (codex-ide--cleanup-on-exit (plist-get session :buffer))
             (should-not (buffer-live-p (plist-get session :buffer)))
             (should-not (codex-ide--project-sessions root)))))
      (delete-directory root t))))

(ert-deftest codex-ide-cleanup-accepts-process-argument ()
  "Cleanup tolerates sentinel-style calls with only the process."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-cleanup-process-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1))
         (lambda (sessions)
           (let ((session (car sessions)))
             (codex-ide--cleanup-on-exit (plist-get session :process))
             (should-not (buffer-live-p (plist-get session :buffer)))
             (should-not (codex-ide--project-sessions root)))))
      (delete-directory root t))))

(ert-deftest codex-ide-make-process-sentinel-chains-original ()
  "The Codex sentinel runs the replaced sentinel before cleaning up."
  (let (chained cleaned)
    (cl-letf (((symbol-function 'process-exit-status) (lambda (_) 0))
              ((symbol-function 'process-status) (lambda (_) 'exit))
              ((symbol-function 'codex-ide--finish-session)
               (lambda (&rest args)
                 (setq cleaned args))))
      (funcall (codex-ide--make-process-sentinel
                "/tmp/root" 1
                (lambda (proc event)
                  (setq chained (list proc event))))
               'fake-proc "finished\n"))
    (should (equal chained '(fake-proc "finished\n")))
    (should (equal cleaned '("/tmp/root" 1 nil fake-proc t "finished\n")))))

(ert-deftest codex-ide-make-process-sentinel-chains-on-non-exit-events ()
  "Non-exit events reach the chained sentinel without triggering cleanup."
  (let (chained cleaned)
    (cl-letf (((symbol-function 'process-exit-status) (lambda (_) 0))
              ((symbol-function 'process-status) (lambda (_) 'run))
              ((symbol-function 'codex-ide--finish-session)
               (lambda (&rest args)
                 (setq cleaned args))))
      (funcall (codex-ide--make-process-sentinel
                "/tmp/root" 1
                (lambda (proc event)
                  (setq chained (list proc event))))
               'fake-proc "open\n"))
    (should (equal chained '(fake-proc "open\n")))
    (should-not cleaned)))

(ert-deftest codex-ide-make-process-sentinel-cleans-up-when-original-errors ()
  "A failing chained sentinel cannot block Codex session cleanup."
  (let (cleaned)
    (cl-letf (((symbol-function 'process-exit-status) (lambda (_) 0))
              ((symbol-function 'process-status) (lambda (_) 'signal))
              ((symbol-function 'codex-ide--finish-session)
               (lambda (&rest args)
                 (setq cleaned args))))
      (funcall (codex-ide--make-process-sentinel
                "/tmp/root" 1
                (lambda (_proc _event)
                  (error "Boom")))
               'fake-proc "killed\n"))
    (should (equal cleaned '("/tmp/root" 1 nil fake-proc nil "killed\n")))))

(ert-deftest codex-ide-setup-session-enables-mode ()
  "Session setup enables `codex-ide-mode' with the cleanup hook."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-setup-mode-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1))
         (lambda (sessions)
           (let* ((session (car sessions))
                  (buffer (plist-get session :buffer))
                  (configured 0))
             (cl-letf (((symbol-function 'codex-ide-term--configure-buffer)
                        (lambda () (cl-incf configured))))
               (codex-ide--setup-session session)
               (codex-ide--setup-session session))
             (with-current-buffer buffer
               (should codex-ide-mode)
               (should (= configured 2))
               (should (= (cl-count
                           #'codex-ide--cleanup-current-buffer-session
                           kill-buffer-hook)
                          1))))))
      (delete-directory root t))))

;;; Native IDE context

(ert-deftest codex-ide-start-session-enables-context-provider-for-new-session ()
  "New sessions enable the IDE context provider when auto-start is enabled."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let* ((codex-ide--sessions (make-hash-table :test 'equal))
            (codex-ide--active-session-ids (make-hash-table :test 'equal))
            (codex-ide-context-auto-start t)
            (buffer (get-buffer-create (codex-ide--get-buffer-name root)))
            (process nil)
            (enabled 0))
       (unwind-protect
           (progn
             (setq process
                   (codex-ide-test--make-buffer-process
                    buffer "codex-ide-context-start"))
             (cl-letf (((symbol-function 'codex-ide--ensure-cli)
                        (lambda () t))
                       ((symbol-function 'codex-ide-context-mode)
                        (lambda (arg)
                          (when (> (prefix-numeric-value arg) 0)
                            (setq enabled (1+ enabled)))))
                       ((symbol-function 'codex-ide--create-session)
                        (lambda (emacs-session-id &rest _args)
                          (codex-ide--make-session
                           root emacs-session-id buffer process)))
                       ((symbol-function 'codex-ide--display-buffer)
                        (lambda (_buffer &optional _select) nil))
                       ((symbol-function 'codex-ide-context-record-source-buffer)
                        (lambda (&rest _args) nil))
                       ((symbol-function 'codex-ide-log)
                        (lambda (&rest _args) nil))
                       ((symbol-function 'codex-ide-debug)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root))
                 (codex-ide--start-session)))
             (should (= enabled 1)))
         (when (and process (process-live-p process))
           (delete-process process))
         (when (buffer-live-p buffer)
           (kill-buffer buffer)))))))

(ert-deftest codex-ide-start-session-enables-context-provider-once-for-active-session ()
  "Auto-start does not re-enable context when toggling an existing session."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let* ((codex-ide--sessions (make-hash-table :test 'equal))
            (codex-ide--active-session-ids (make-hash-table :test 'equal))
            (codex-ide-context-auto-start t)
            (buffer (get-buffer-create (codex-ide--get-buffer-name root)))
            (process nil)
            (enabled 0)
            (created 0)
            (recoveries 0))
       (unwind-protect
           (progn
             (setq process
                   (codex-ide-test--make-buffer-process
                    buffer "codex-ide-context-existing"))
             (cl-letf (((symbol-function 'codex-ide--ensure-cli)
                        (lambda () t))
                       ((symbol-function 'codex-ide-context-mode)
                        (lambda (arg)
                          (when (> (prefix-numeric-value arg) 0)
                            (setq enabled (1+ enabled)))))
                       ((symbol-function 'codex-ide--recover-live-sessions)
                        (lambda ()
                          (setq recoveries (1+ recoveries))))
                       ((symbol-function 'codex-ide--create-session)
                        (lambda (emacs-session-id &rest _args)
                          (setq created (1+ created))
                          (codex-ide--make-session
                           root emacs-session-id buffer process)))
                       ((symbol-function 'codex-ide--display-buffer)
                        (lambda (_buffer &optional _select) nil))
                       ((symbol-function 'codex-ide--toggle-existing-window)
                        (lambda (_buffer) nil))
                       ((symbol-function 'codex-ide-context-record-source-buffer)
                        (lambda (&rest _args) nil))
                       ((symbol-function 'codex-ide-log)
                        (lambda (&rest _args) nil))
                       ((symbol-function 'codex-ide-debug)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root))
                 (codex-ide--start-session)
                 (codex-ide--start-session)))
             (should (= enabled 1))
             (should (= created 1))
             (should (= recoveries 2)))
         (when (and process (process-live-p process))
           (delete-process process))
         (when (buffer-live-p buffer)
           (kill-buffer buffer)))))))

(ert-deftest codex-ide-start-session-does-not-send-ide-command ()
  "New sessions do not schedule `/ide on'; users enable it in Codex."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let* ((codex-ide--sessions (make-hash-table :test 'equal))
            (codex-ide--active-session-ids (make-hash-table :test 'equal))
            (codex-ide-context-auto-start nil)
            (buffer (get-buffer-create (codex-ide--get-buffer-name root)))
            (process nil)
            (scheduled nil)
            (sent nil)
            (created 0))
       (unwind-protect
           (progn
             (setq process
                   (codex-ide-test--make-buffer-process
                    buffer "codex-ide-context-schedule"))
             (cl-letf (((symbol-function 'codex-ide--ensure-cli)
                        (lambda () t))
                       ((symbol-function 'codex-ide--create-session)
                        (lambda (emacs-session-id &rest _args)
                          (setq created (1+ created))
                          (codex-ide--make-session
                           root emacs-session-id buffer process)))
                       ((symbol-function 'codex-ide--display-buffer)
                        (lambda (_buffer &optional _select) nil))
                       ((symbol-function 'codex-ide--toggle-existing-window)
                        (lambda (_buffer) nil))
                       ((symbol-function 'codex-ide-context-record-source-buffer)
                        (lambda (&rest _args) nil))
                       ((symbol-function 'run-at-time)
                        (lambda (&rest args)
                          (push args scheduled)
                          'timer))
                       ((symbol-function 'codex-ide-term--send-string)
                        (lambda (string)
                          (push string sent)))
                       ((symbol-function 'codex-ide-term--send-return)
                        (lambda ()
                          (push :return sent)))
                       ((symbol-function 'codex-ide-log)
                        (lambda (&rest _args) nil))
                       ((symbol-function 'codex-ide-debug)
                        (lambda (&rest _args) nil)))
               (let ((default-directory root))
                 (codex-ide--start-session)
                 (codex-ide--start-session)))
             (should-not scheduled)
             (should-not sent)
             (should (= created 1)))
         (when (and process (process-live-p process))
           (delete-process process))
         (when (buffer-live-p buffer)
           (kill-buffer buffer)))))))

(ert-deftest codex-ide-send-prompt-records-caller-source-buffer ()
  "`codex-ide-send-prompt' records the source before terminal input."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let* ((source-file (expand-file-name "source.el" root))
            (codex-ide--sessions (make-hash-table :test 'equal))
            (codex-ide--active-session-ids (make-hash-table :test 'equal))
            (source-buffer nil)
            (codex-buffer (get-buffer-create
                           (codex-ide--get-buffer-name root)))
            (process nil)
            (session nil)
            recorded sent returned)
       (write-region "(message \"hi\")\n" nil source-file)
       (unwind-protect
           (progn
             (setq process
                   (codex-ide-test--make-buffer-process
                    codex-buffer "codex-ide-prompt"))
             (setq session (codex-ide--make-session
                            root 1 codex-buffer process))
             (with-current-buffer codex-buffer
               (setq major-mode 'eat-mode)
               (setq-local codex-ide--session-root root)
               (setq-local codex-ide--session-id 1)
               (codex-ide-mode 1))
             (codex-ide-test--store-session session)
             (setq source-buffer (find-file-noselect source-file))
             (with-current-buffer source-buffer
               (let ((default-directory root))
                 (cl-letf (((symbol-function 'codex-ide-context-record-source-buffer)
                            (lambda (directory buffer)
                              (setq recorded (list directory buffer))))
                           ((symbol-function 'codex-ide-term--paste-draft)
                            (lambda (_process string)
                              (setq sent (list string (current-buffer)))))
                           ((symbol-function 'codex-ide-term--send-return)
                            (lambda ()
                              (setq returned (current-buffer))))
                           ((symbol-function 'sit-for)
                            (lambda (&rest _args) nil))
                           ((symbol-function 'codex-ide-debug)
                            (lambda (&rest _args) nil)))
                   (codex-ide-send-prompt "hello"))))
             (should (equal recorded (list root source-buffer)))
             (should (equal sent (list "hello" codex-buffer)))
             (should (eq returned codex-buffer)))
         (when (buffer-live-p source-buffer)
           (kill-buffer source-buffer))
         (when (and process (process-live-p process))
           (delete-process process))
         (when (buffer-live-p codex-buffer)
           (kill-buffer codex-buffer))
         (delete-file source-file))))))

;;; Menu

(defun codex-ide-test--popup-entries (keymap)
  "Return popup metadata entries for KEYMAP."
  (let ((rows (keymap-popup--meta keymap 'descriptions)))
    (cl-loop for row in rows
             append (cl-loop for group in row
                             append (plist-get group :entries)))))

(defun codex-ide-test--popup-entry-by-command (keymap command)
  "Return the popup entry for COMMAND in KEYMAP."
  (cl-find command (codex-ide-test--popup-entries keymap)
           :key (lambda (entry) (plist-get entry :command))
           :test #'eq))

(defun codex-ide-test--popup-entry-by-variable (keymap variable)
  "Return the popup switch entry for VARIABLE in KEYMAP."
  (cl-find variable (codex-ide-test--popup-entries keymap)
           :key (lambda (entry) (plist-get entry :variable))
           :test #'eq))

(defun codex-ide-test--command-bound-p (keymap command)
  "Return non-nil when COMMAND is reachable in KEYMAP."
  (where-is-internal command (list keymap) t))

(ert-deftest codex-ide-menu-reserves-popup-exit ()
  "Exit keys never name a destructive source-map action."
  (dolist (map (list codex-ide-map codex-ide-mcp-map))
    (should-not (lookup-key map (kbd "q"))))
  (should (eq (lookup-key codex-ide-map (kbd "k")) #'codex-ide-stop))
  (should (eq (lookup-key codex-ide-mcp-map (kbd "K")) #'codex-ide-mcp-stop)))

(ert-deftest codex-ide-menu-main-commands ()
  "Main menu exposes the core session/navigation/interaction commands."
  (dolist (command '(codex-ide
                     codex-ide-resume-last
                     codex-ide-resume
                     codex-ide-stop
                     codex-ide-switch-to-buffer
                     codex-ide-switch-project-session
                     codex-ide-switch-session
                     codex-ide-list-sessions
                     codex-ide-cycle-session
                     codex-ide-send-prompt
                     codex-ide-send-escape))
    (should (codex-ide-test--command-bound-p codex-ide-map command))))

(ert-deftest codex-ide-menu-config-commands ()
  "Config menu exposes package configuration commands."
  (dolist (command '(codex-ide-menu--set-cli-path
                     codex-ide-menu--set-terminal-backend
                     codex-ide-menu--set-approval
                     codex-ide-menu--save-config))
    (should (codex-ide-test--command-bound-p codex-ide-config-map command))))

(ert-deftest codex-ide-menu-approval-policies-match-current-cli ()
  "Approval picker offers only policies accepted by current Codex."
  (let (offered)
    (cl-letf (((symbol-function 'completing-read)
               (lambda (_prompt collection &rest _)
                 (setq collection (codex-ide-test--completion-candidates collection))
                 (setq offered collection)
                 "nil"))
              ((symbol-function 'codex-ide-log)
               (lambda (&rest _) nil)))
      (call-interactively #'codex-ide-menu--set-approval))
    (should (equal offered '("nil" "on-request" "never")))))

(ert-deftest codex-ide-menu-mcp-commands ()
  "MCP menu exposes start/stop/status/install commands."
  (dolist (command '(codex-ide-mcp-start
                     codex-ide-mcp-stop
                     codex-ide-mcp-status
                     codex-ide-mcp-install-codex-config))
    (should (codex-ide-test--command-bound-p codex-ide-mcp-map command))))

(ert-deftest codex-ide-menu-save-config-saves-only-nondefaults ()
  "Save config compares current values with evaluated standard values."
  (let ((codex-ide-menu--saved-config-symbols
         '(codex-ide-cli-path codex-ide-no-alt-screen codex-ide-cli-extra-args))
        (codex-ide-cli-path (eval (car (get 'codex-ide-cli-path 'standard-value)) t))
        (codex-ide-no-alt-screen t)
        (codex-ide-cli-extra-args '("--example"))
        saved)
    (cl-letf (((symbol-function 'customize-save-variable)
               (lambda (symbol value) (push (cons symbol value) saved)))
              ((symbol-function 'codex-ide-log) #'ignore))
      (codex-ide-menu--save-config))
    (should (equal (reverse saved)
                   '((codex-ide-no-alt-screen . t)
                     (codex-ide-cli-extra-args "--example"))))))

(ert-deftest codex-ide-menu-save-config-removes-restored-defaults ()
  "Restored defaults survive reload without erasing unrelated settings."
  (let* ((directory (make-temp-file "codex-custom-" t))
         (custom-file (expand-file-name "custom.el" directory))
         (user-init-file (expand-file-name "init.el" directory))
         (symbols '(codex-ide-yolo codex-ide-no-alt-screen codex-ide-debug user))
         (properties (mapcar (lambda (symbol) (copy-tree (symbol-plist symbol)))
                             symbols))
         (codex-ide-menu--saved-config-symbols
          '(codex-ide-yolo codex-ide-no-alt-screen))
         (codex-ide-yolo t)
         (codex-ide-no-alt-screen t)
         (codex-ide-debug t))
    (unwind-protect
        (progn
          (customize-save-variable 'codex-ide-debug t)
          (codex-ide-menu--save-config)
          (setq codex-ide-yolo nil codex-ide-no-alt-screen nil)
          (codex-ide-menu--save-config)
          (with-temp-buffer
            (insert-file-contents custom-file)
            (should-not (search-forward "(codex-ide-yolo" nil t))
            (goto-char (point-min))
            (should-not (search-forward "(codex-ide-no-alt-screen" nil t)))
          (with-temp-buffer
            (should
             (zerop
              (call-process
               (expand-file-name invocation-name invocation-directory) nil t nil
               "-Q" "--batch" "--eval"
               (prin1-to-string
                `(progn
                   (defcustom codex-ide-yolo nil "Test option." :type 'boolean)
                   (defcustom codex-ide-no-alt-screen nil "Test option." :type 'boolean)
                   (defcustom codex-ide-debug nil "Test option." :type 'boolean)
                   (load ,custom-file nil t)
                   (princ (list codex-ide-yolo codex-ide-no-alt-screen
                                codex-ide-debug)))))))
            (should (equal (buffer-string) "(nil nil t)"))))
      (cl-mapc #'setplist symbols properties)
      (when-let* ((buffer (get-file-buffer custom-file))) (kill-buffer buffer))
      (delete-directory directory t))))

(ert-deftest codex-ide-menu-save-default-preserves-explicit-backend ()
  "Saving an explicit default preserves the current terminal choice."
  (let ((codex-ide-menu--saved-config-symbols '(codex-ide-terminal-backend))
        (codex-ide-terminal-backend 'eat)
        (features (cons 'neomacs features))
        (properties (copy-tree (symbol-plist 'codex-ide-terminal-backend)))
        (user-properties (copy-tree (symbol-plist 'user))))
    (unwind-protect
        (progn
          (put 'codex-ide-terminal-backend 'saved-value (list (list 'quote 'eat)))
          (put 'codex-ide-terminal-backend 'customized-value nil)
          (should (eq (codex-ide-term--selected-backend) 'eat))
          (cl-letf (((symbol-function 'custom-file) (lambda (&optional _) nil)))
            (codex-ide-menu--save-config))
          (should (eq (codex-ide-term--selected-backend) 'eat))
          (should (get 'codex-ide-terminal-backend 'saved-value)))
      (setplist 'codex-ide-terminal-backend properties)
      (setplist 'user user-properties))))

(ert-deftest codex-ide-menu-cli-path-allows-bare-command ()
  "CLI path completion supplies an executable default without must-match."
  (let ((codex-ide-cli-path "missing") args)
    (cl-letf (((symbol-function 'executable-find) (lambda (_) "/bin/codex"))
              ((symbol-function 'read-file-name)
               (lambda (&rest arguments) (setq args arguments) "other-codex"))
              ((symbol-function 'codex-ide--invalidate-cli-cache) #'ignore)
              ((symbol-function 'codex-ide-log) #'ignore))
      (call-interactively #'codex-ide-menu--set-cli-path))
    (should (equal (nth 2 args) "/bin/codex"))
    (should-not (nth 3 args))
    (should (equal codex-ide-cli-path "other-codex"))))

(ert-deftest codex-ide-menu-exit-key-dismisses-without-stopping ()
  "Real transient-map dispatch of q dismisses and backs out safely."
  (let ((stopped 0) (keymap-popup-backend #'keymap-popup-backend-side-window))
    (save-window-excursion
      (with-temp-buffer
        (switch-to-buffer (current-buffer))
        (local-set-key (kbd "<f6>") #'codex-ide-menu)
        (cl-letf (((symbol-function 'codex-ide-stop)
                   (lambda () (interactive) (cl-incf stopped)))
                  ((symbol-function 'codex-ide-mcp-stop)
                   (lambda () (interactive) (cl-incf stopped))))
          (unwind-protect
              (progn
                (execute-kbd-macro (kbd "<f6> q"))
                (should-not (get-buffer keymap-popup--buffer-name))
                (execute-kbd-macro (kbd "<f6> m q"))
                (should (get-buffer keymap-popup--buffer-name))
                (execute-kbd-macro (kbd "q"))
                (should-not (get-buffer keymap-popup--buffer-name))
                (should (= stopped 0)))
            (keymap-popup-dismiss)))))))

(ert-deftest codex-ide-menu-layout-and-availability ()
  "Root groups occupy explicit two-column rows with meaningful predicates."
  (let ((rows (keymap-popup--meta codex-ide-map 'descriptions)))
    (should (equal (mapcar (lambda (row) (mapcar (lambda (group)
                                                (plist-get group :name)) row)) rows)
                   '(("Session" "Switch") ("Send" "Context") ("Config"))))
    (dolist (row rows)
      (dolist (group row)
        (should (<= (length (plist-get group :entries)) 6)))))
  (should (eq (lookup-key codex-ide-map "l") #'codex-ide-switch-project-session))
  (should (eq (lookup-key codex-ide-map "L") #'codex-ide-switch-session))
  (should-not (lookup-key codex-ide-map (kbd "C-l")))
  (should-not (codex-ide-test--command-bound-p codex-ide-map
                                             #'codex-ide-insert-newline))
  (cl-letf (((symbol-function 'codex-ide--get-working-directory)
             (lambda () "/example/"))
            ((symbol-function 'codex-ide--project-sessions) (lambda (_) nil)))
    (should (funcall (plist-get (codex-ide-test--popup-entry-by-command
                                codex-ide-map #'codex-ide-send-prompt) :inapt-if))))
  (cl-letf (((symbol-function 'codex-ide--project-sessions) (lambda (_) '(live))))
    (should-not (codex-ide-menu--no-project-session-p))))

(ert-deftest codex-ide-menu-descriptions-show-values ()
  "Configuration entries render current values with semantic faces and help."
  (let ((codex-ide-terminal-backend 'vterm)
        (codex-ide-ask-for-approval 'on-request)
        (codex-ide-yolo nil)
        (codex-ide-config-overrides '(("sandbox_mode" . "workspace-write"))))
    (dolist (pair '((codex-ide-menu--set-terminal-backend . "vterm")
                    (codex-ide-menu--set-approval . "on-request")
                    (codex-ide-menu--configure-sandbox . "workspace-write")))
      (let* ((entry (codex-ide-test--popup-entry-by-command codex-ide-config-map
                                                          (car pair)))
             (text (funcall (plist-get entry :description)))
             (start (string-match (cdr pair) text)))
        (should start)
        (should (eq (get-text-property start 'face text) 'keymap-popup-value))
        (should (equal (get-text-property start 'help-echo text) (cdr pair)))))
    (let* ((full (make-string 100 ?x))
           (short (codex-ide-menu--value "Value" full)))
      (should (< (string-width short) 40))
      (should (equal (get-text-property 7 'help-echo short) full)))))

(ert-deftest codex-ide-switch-obsolete-aliases ()
  "Old cycle and project-picker commands retain their meanings."
  (should (eq (indirect-function 'codex-ide-toggle)
              (indirect-function 'codex-ide-cycle-session)))
  (should (eq (indirect-function 'codex-ide-list-project-sessions)
              (indirect-function 'codex-ide-switch-project-session))))

(ert-deftest codex-ide-menu-debug-commands ()
  "Debug menu exposes status and log commands."
  (dolist (command '(codex-ide-check-status
                     codex-ide-show-debug
                     codex-ide-clear-debug))
    (should (codex-ide-test--command-bound-p codex-ide-debug-map command))))

(ert-deftest codex-ide-menu-submenus-exist ()
  "Config, MCP, and debug submenus are defined keymaps."
  (should (keymapp codex-ide-config-map))
  (should (keymapp codex-ide-mcp-map))
  (should (keymapp codex-ide-debug-map)))

(ert-deftest codex-ide-menu-booleans-use-popup-switches ()
  "Boolean options use keymap-popup's native switch entries."
  (dolist (pair `((,codex-ide-config-map . codex-ide-yolo)
                  (,codex-ide-config-map . codex-ide-no-alt-screen)
                  (,codex-ide-debug-map . codex-ide-debug)))
    (let ((entry (codex-ide-test--popup-entry-by-variable
                  (car pair) (cdr pair))))
      (should (eq (plist-get entry :type) 'switch)))))

(ert-deftest codex-ide-default-buffer-name-distinguishes-equal-basenames ()
  "Live project collisions add a stable root identity."
  (let* ((parent-a (make-temp-file "codex-root-a-" t))
         (parent-b (make-temp-file "codex-root-b-" t))
         (root-a (file-name-as-directory (expand-file-name "same" parent-a)))
         (root-b (file-name-as-directory (expand-file-name "same" parent-b)))
         buffer-a buffer-b root-b-name)
    (unwind-protect
        (progn
          (make-directory root-a)
          (make-directory root-b)
          (setq buffer-a
                (get-buffer-create (codex-ide--get-buffer-name root-a)))
          (with-current-buffer buffer-a
            (setq-local codex-ide--session-root root-a)
            (setq-local codex-ide--session-id 1))
          (should (equal (codex-ide--get-buffer-name root-a)
                         "*codex[same]*"))
          (setq root-b-name (codex-ide--get-buffer-name root-b))
          (should (string-match-p
                   (rx string-start "*codex[same:"
                       (= 8 hex-digit) "]*" string-end)
                   root-b-name))
          (setq buffer-b (get-buffer-create root-b-name))
          (with-current-buffer buffer-b
            (setq-local codex-ide--session-root root-b)
            (setq-local codex-ide--session-id 1))
          (kill-buffer buffer-a)
          (setq buffer-a nil)
          (should (equal (codex-ide--get-buffer-name root-b 2)
                         (concat (substring root-b-name 0 -1) "<2>*"))))
      (when (buffer-live-p buffer-a)
        (kill-buffer buffer-a))
      (when (buffer-live-p buffer-b)
        (kill-buffer buffer-b))
      (delete-directory parent-a t)
      (delete-directory parent-b t))))

(ert-deftest codex-ide-custom-buffer-name-disambiguates-collisions ()
  "Custom base names retain root-safe collision handling."
  (let* ((codex-ide-buffer-name-function (lambda (_directory) "*my-codex*"))
         (root-a (file-name-as-directory
                  (make-temp-file "codex-custom-root-a-" t)))
         (root-b (file-name-as-directory
                  (make-temp-file "codex-custom-root-b-" t)))
         (buffer (get-buffer-create (codex-ide--get-buffer-name root-a))))
    (unwind-protect
        (progn
          (with-current-buffer buffer
            (setq-local codex-ide--session-root root-a)
            (setq-local codex-ide--session-id 1))
          (should (equal (codex-ide--get-buffer-name root-a) "*my-codex*"))
          (should (string-match-p
                   (rx string-start "*my-codex:"
                       (= 8 hex-digit) "*" string-end)
                   (codex-ide--get-buffer-name root-b))))
      (kill-buffer buffer)
      (delete-directory root-a t)
      (delete-directory root-b t))))

(ert-deftest codex-ide-cleanup-finds-identified-buffer-without-record ()
  "Cleanup finds an identified session after the original collision ends."
  (let* ((codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         (parent-a (make-temp-file "codex-cleanup-root-a-" t))
         (parent-b (make-temp-file "codex-cleanup-root-b-" t))
         (root-a (file-name-as-directory (expand-file-name "same" parent-a)))
         (root-b (file-name-as-directory (expand-file-name "same" parent-b)))
         buffer-a buffer-b)
    (unwind-protect
        (progn
          (make-directory root-a)
          (make-directory root-b)
          (setq buffer-a
                (get-buffer-create (codex-ide--get-buffer-name root-a)))
          (with-current-buffer buffer-a
            (setq-local codex-ide--session-root root-a)
            (setq-local codex-ide--session-id 1))
          (setq buffer-b
                (get-buffer-create (codex-ide--get-buffer-name root-b)))
          (with-current-buffer buffer-b
            (setq-local codex-ide--session-root root-b)
            (setq-local codex-ide--session-id 1))
          (kill-buffer buffer-a)
          (setq buffer-a nil)
          (codex-ide--cleanup-on-exit root-b 1)
          (should-not (buffer-live-p buffer-b)))
      (when (buffer-live-p buffer-a)
        (kill-buffer buffer-a))
      (when (buffer-live-p buffer-b)
        (kill-buffer buffer-b))
      (delete-directory parent-a t)
      (delete-directory parent-b t))))

(ert-deftest codex-ide-cleanup-finds-recovered-arbitrary-name ()
  "Cleanup uses session ownership when a recovered name cannot be derived."
  (let* ((codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         (root (file-name-as-directory
                (make-temp-file "codex-cleanup-recovered-" t)))
         (buffer (generate-new-buffer " *codex-recovered-session*"))
         process)
    (unwind-protect
        (progn
          (setq process
                (codex-ide-test--make-buffer-process
                 buffer "codex-cleanup-recovered"))
          (with-current-buffer buffer
            (setq-local codex-ide--session-root root)
            (setq-local codex-ide--session-id 2))
          (codex-ide--cleanup-on-exit root 2 buffer process)
          (should-not (process-live-p process))
          (should-not (buffer-live-p buffer)))
      (when (process-live-p process)
        (delete-process process))
      (when (buffer-live-p buffer)
        (kill-buffer buffer))
      (delete-directory root t))))

(ert-deftest codex-ide-rename-session-preserves-identity-and-recovery ()
  "Labels survive recovery without becoming the next session's base name."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1) (,root 2))
      (lambda (sessions)
        (let* ((session (cadr sessions))
               (buffer (plist-get session :buffer))
               (original (buffer-name buffer))
               (third (codex-ide--get-buffer-name root 3)))
          (with-current-buffer buffer
            (codex-ide-rename-session "review"))
          (should (string-match-p "review" (buffer-name buffer)))
          (should (eq session (codex-ide--session-by-id root 2)))
          (should (equal third (codex-ide--get-buffer-name root 3)))
          (should (assq session
                        (mapcar (lambda (entry) (cons (cdr entry) (car entry)))
                                (codex-ide--session-candidates root))))
          (remhash root codex-ide--sessions)
          (cl-letf (((symbol-function 'codex-ide-term--configure-buffer) #'ignore))
            (codex-ide--recover-live-session buffer))
          (should (string-match-p "review" (buffer-name buffer)))
          (with-current-buffer buffer
            (codex-ide-rename-session ""))
          (should (equal original (buffer-name buffer)))
          (codex-ide--cleanup-on-exit root 2)
          (should-not (buffer-live-p buffer))
          (should (buffer-live-p (plist-get (car sessions) :buffer)))))))))

(ert-deftest codex-ide-rename-session-rejects-duplicates-and-controls ()
  "A rejected label leaves both names and processes unchanged."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1) (,root 2))
      (lambda (sessions)
        (let ((first (plist-get (car sessions) :buffer))
              (second (plist-get (cadr sessions) :buffer)))
          (with-current-buffer first (codex-ide-rename-session "review"))
          (with-current-buffer second
            (let ((name (buffer-name)))
              (should-error (codex-ide-rename-session "review") :type 'user-error)
              (should-error (codex-ide-rename-session "bad\nname") :type 'user-error)
              (should (equal name (buffer-name)))))
          (should (cl-every #'codex-ide--session-live-p sessions))))))))

(ert-deftest codex-ide-rename-session-scopes-labels-and-rejects-stale-owner ()
  "Different projects may reuse labels; replaced owners cannot rename."
  (codex-ide-test--call-with-project
   (lambda (root-a)
     (codex-ide-test--call-with-project
      (lambda (root-b)
        (codex-ide-test--call-with-sessions
         `((,root-a 1) (,root-b 1))
         (lambda (sessions)
           (dolist (session sessions)
             (codex-ide--set-session-label session "review"))
           (let* ((old (car sessions))
                  (buffer (plist-get old :buffer))
                  (name (buffer-name buffer)))
             (puthash root-a (list (copy-sequence old)) codex-ide--sessions)
             (should-error (codex-ide--set-session-label old "stale")
                           :type 'user-error)
             (should (equal name (buffer-name buffer)))))))))))

(ert-deftest codex-ide-rename-session-rechecks-vacated-name-collisions ()
  "A label must not let a same-basename project steal later buffers."
  (codex-ide-test--call-with-project
   (lambda (parent)
     (let ((root-a (expand-file-name "a/project/" parent))
           (root-b (expand-file-name "b/project/" parent)))
       (make-directory root-a t)
       (make-directory root-b t)
       (codex-ide-test--call-with-sessions
        `((,root-a 1))
        (lambda (sessions)
          (let ((first (car sessions)) second-a first-b second-b)
            (unwind-protect
                (progn
                  (codex-ide--set-session-label first "review")
                  (setq first-b (codex-ide-test--make-session root-b 1))
                  (codex-ide-test--store-session first-b)
                  (setq second-b (codex-ide-test--make-session root-b 2))
                  (codex-ide-test--store-session second-b)
                  (setq second-a (codex-ide-test--make-session root-a 2))
                  (codex-ide-test--store-session second-a)
                  (should-not (eq (plist-get second-a :buffer)
                                  (plist-get second-b :buffer)))
                  (should (equal root-b
                                 (buffer-local-value 'codex-ide--session-root
                                                     (plist-get second-b :buffer))))
                  (should (eq second-b (codex-ide--session-by-id root-b 2)))
                  (codex-ide--set-session-label first "")
                  (should (string-match-p
                           (substring (secure-hash 'sha1 root-a) 0 8)
                           (buffer-name (plist-get first :buffer))))
                  (should (cl-every #'codex-ide--session-live-p
                                    (list first first-b second-a second-b))))
              (mapc (lambda (session)
                      (when session (codex-ide-test--kill-session session)))
                    (list first-b second-a second-b))))))))))

(defun codex-ide-test--call-with-panel-tabs (body)
  "Call BODY with disposable tab and window state."
  (require 'tab-bar)
  (let ((tabs (frame-parameter nil 'tabs))
        (tab-bar-mode tab-bar-mode)
        (tab-bar-new-tab-choice "*scratch*")
        (tab-bar-closed-tabs nil))
    (unwind-protect
        (save-window-excursion
          (delete-other-windows)
          (set-frame-parameter nil 'tabs nil)
          (cl-letf (((symbol-function 'codex-ide-term--sync-dimensions) #'ignore))
            (funcall body)))
      (set-frame-parameter nil 'tabs tabs))))

(ert-deftest codex-ide-panel-honors-display-buffer-alist ()
  "User display rules override panel fallback placement without selecting."
  (dolist (action '(display-buffer-in-side-window display-buffer-same-window))
    (codex-ide-test--call-with-project
     (lambda (root)
       (codex-ide-test--call-with-sessions
	`((,root 1))
	(lambda (sessions)
          (codex-ide-test--call-with-panel-tabs
           (lambda ()
             (let* ((source (selected-window))
                    (buffer (plist-get (car sessions) :buffer))
                    (codex-ide-display-buffer-function #'display-buffer)
                    (display-buffer-alist
                     `((,(regexp-quote (buffer-name buffer))
			,action (side . left)))))
               (codex-ide--show-panel-session (car sessions))
               (should (eq source (selected-window)))
               (if (eq action 'display-buffer-same-window)
                   (should (eq source (get-buffer-window buffer)))
		 (should (eq (window-parameter (get-buffer-window buffer) 'window-side)
                             'left))))))))))))

(ert-deftest codex-ide-panel-restores-live-set-and-preserves-other-project ()
  "Hiding one project preserves others and never restores stopped sessions."
  (codex-ide-test--call-with-project
   (lambda (parent)
     (let ((root (expand-file-name "project/" parent))
           (other (expand-file-name "other/" parent)))
       (make-directory root t)
       (make-directory other t)
       (codex-ide-test--call-with-sessions
        `((,root 1) (,root 2) (,other 1))
        (lambda (sessions)
          (codex-ide-test--call-with-panel-tabs
           (lambda ()
             (cl-letf (((symbol-function 'codex-ide--get-working-directory)
                        (lambda () root)))
               (codex-ide-show-project-sessions)
               (codex-ide--show-panel-session (nth 2 sessions))
               (should (cl-every #'codex-ide--panel-windows sessions))
               (codex-ide-toggle-panel)
               (should-not (codex-ide--panel-windows (car sessions)))
               (should-not (codex-ide--panel-windows (cadr sessions)))
               (should (codex-ide--panel-windows (nth 2 sessions)))
               (codex-ide--cleanup-on-exit root 2)
               (codex-ide-toggle-panel)
               (should (codex-ide--panel-windows (car sessions)))
               (should (codex-ide--panel-windows (nth 2 sessions)))
               (should-not (assoc root (codex-ide--panel-state))))))))))))

(ert-deftest codex-ide-panel-state-follows-tabs-through-rename-and-close ()
  "Each tab remembers its own set independently of the displayed name."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1) (,root 2))
      (lambda (sessions)
        (codex-ide-test--call-with-panel-tabs
         (lambda ()
           (cl-letf (((symbol-function 'codex-ide--get-working-directory)
                      (lambda () root)))
             (codex-ide-show-project-sessions)
             (codex-ide-toggle-panel)
             (tab-bar-new-tab)
             (should-not (assoc root (codex-ide--panel-state)))
             (codex-ide--show-panel-session (car sessions))
             (codex-ide-toggle-panel)
             (tab-bar-rename-tab "renamed")
             (should (= 1 (length (cdr (assoc root (codex-ide--panel-state))))))
             (tab-bar-select-tab 1)
             (should (= 2 (length (cdr (assoc root (codex-ide--panel-state))))))
             (codex-ide-toggle-panel)
             (should (cl-every #'codex-ide--panel-windows sessions))
             (tab-bar-select-tab 2)
             (codex-ide-toggle-panel)
             (should (codex-ide--panel-windows (car sessions)))
             (should-not (codex-ide--panel-windows (cadr sessions)))
             (tab-bar-close-tab)
             (tab-bar-new-tab)
             (should-not (assoc root (codex-ide--panel-state)))))))))))

(ert-deftest codex-ide-panel-capacity-preserves-existing-window ()
  "An exhausted side-window limit cannot replace an already visible session."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1) (,root 2))
      (lambda (sessions)
        (codex-ide-test--call-with-panel-tabs
         (lambda ()
           (let ((window-sides-slots '(nil nil 1 nil)))
             (cl-letf (((symbol-function 'codex-ide--get-working-directory)
                        (lambda () root)))
               (codex-ide--show-panel-session (car sessions))
               (should-error (codex-ide-show-project-sessions) :type 'user-error)
               (should (codex-ide--panel-windows (car sessions)))
               (should-not (codex-ide--panel-windows (cadr sessions))))))))))))

(ert-deftest codex-ide-cleanup-keeps-buffer-live-for-backend-hooks ()
  "The session kill hook leaves the dying buffer to its remaining hooks."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1))
      (lambda (sessions)
        (let* ((session (car sessions))
               (buffer (plist-get session :buffer))
               (backend-ran nil))
          (with-current-buffer buffer
            (add-hook 'kill-buffer-hook
                      (lambda ()
                        (setq backend-ran t)
                        (should (buffer-live-p buffer))) nil t)
            (add-hook 'kill-buffer-hook
                      #'codex-ide--cleanup-current-buffer-session nil t))
          (kill-buffer buffer)
          (should backend-ran)
          (should-not (process-live-p (plist-get session :process)))
          (should-not (codex-ide--session-by-id root 1))))))))

(ert-deftest codex-ide-cleanup-allows-reentrant-sibling-cleanup ()
  "A process exit during cleanup can tear down a different session."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1) (,root 2))
      (lambda (sessions)
        (let* ((first (car sessions))
               (second (cadr sessions))
               (process (plist-get first :process))
               (delete (symbol-function 'delete-process)))
          (cl-letf (((symbol-function 'delete-process)
                     (lambda (target)
                       (when (eq target process)
                         (codex-ide--cleanup-on-exit
                          root (plist-get second :id)))
                       (funcall delete target))))
            (codex-ide--cleanup-on-exit root (plist-get first :id)))
          (dolist (session sessions)
            (should-not (buffer-live-p (plist-get session :buffer)))
            (should-not (process-live-p (plist-get session :process)))
            (should-not (codex-ide--session-by-id
                         root (plist-get session :id))))))))))

(ert-deftest codex-ide-stale-sentinel-preserves-replacement-session ()
  "An old process sentinel cannot clean up a replacement owner."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-stale-sentinel-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1))
         (lambda (sessions)
           (let* ((old (car sessions))
                  (old-process (plist-get old :process))
                  stale replacement)
             (cl-letf (((symbol-function 'codex-ide-term--configure-buffer)
                        (lambda () nil)))
               (codex-ide--setup-session old))
             (setq stale (process-sentinel old-process))
             (codex-ide--cleanup-on-exit root 1)
             (setq replacement (codex-ide-test--make-session root 1))
             (codex-ide-test--store-session replacement)
             (unwind-protect
                 (progn
                   (funcall stale old-process "finished\n")
                   (should (buffer-live-p (plist-get replacement :buffer)))
                   (should (eq (codex-ide--session-by-id root 1) replacement)))
               (codex-ide-test--kill-session replacement)))))
      (delete-directory root t))))

(ert-deftest codex-ide-start-session-rolls-back-setup-failure ()
  "Failed terminal setup leaves no live or registered partial session."
  (let* ((root (file-name-as-directory
                (make-temp-file "codex-ide-setup-failure-" t)))
         (codex-ide--sessions (make-hash-table :test 'equal))
         (codex-ide--active-session-ids (make-hash-table :test 'equal))
         session)
    (unwind-protect
        (cl-letf (((symbol-function 'codex-ide--ensure-cli) (lambda () t))
                  ((symbol-function 'codex-ide--get-working-directory)
                   (lambda () root))
                  ((symbol-function 'codex-ide--create-session)
                   (lambda (&rest _)
                     (setq session (codex-ide-test--make-session root 1))))
                  ((symbol-function 'codex-ide-term--configure-buffer)
                   (lambda () (error "configure failed")))
                  ((symbol-function 'codex-ide-context-record-source-buffer)
                   (lambda (&rest _) nil))
                  ((symbol-function 'codex-ide--maybe-ensure-context-server)
                   (lambda () nil)))
          (should-error (codex-ide--start-session) :type 'error)
          (should-not (process-live-p (plist-get session :process)))
          (should-not (buffer-live-p (plist-get session :buffer)))
          (should-not (codex-ide--session-by-id root 1)))
      (when session (codex-ide-test--kill-session session))
      (delete-directory root t))))

(ert-deftest codex-ide-major-mode-change-cleans-session ()
  "Changing major mode tears down the exact terminal session."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-major-mode-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1))
         (lambda (sessions)
           (let* ((session (car sessions))
                  (buffer (plist-get session :buffer))
                  (process (plist-get session :process)))
             (cl-letf (((symbol-function 'codex-ide-term--configure-buffer)
                        (lambda () nil)))
               (codex-ide--setup-session session))
             (with-current-buffer buffer (fundamental-mode))
             (should-not (process-live-p process))
             (should-not (codex-ide--session-by-id root 1)))))
      (delete-directory root t))))

(ert-deftest codex-ide-setup-session-sentinel-idempotent ()
  "Repeated setup installs one process sentinel cleanup path."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-setup-sentinel-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1))
         (lambda (sessions)
           (let* ((session (car sessions))
                  (process (plist-get session :process))
                  (cleanup-calls 0)
                  (original (lambda (&rest _) nil)))
             (set-process-sentinel process original)
             (cl-letf (((symbol-function 'codex-ide--cleanup-on-exit)
                        (lambda (&rest _)
                          (setq cleanup-calls (1+ cleanup-calls))))
                       ((symbol-function 'codex-ide-term--configure-buffer)
                        (lambda () nil)))
               (codex-ide--setup-session session)
               (codex-ide--setup-session session)
               (codex-ide--setup-session session)
               (should (process-get process 'codex-ide--sentinel-installed))
               (delete-process process)
               (should (= cleanup-calls 1))))))
      (delete-directory root t))))

(ert-deftest codex-ide-ensure-cli-redetects-after-path-change ()
  "CLI availability cache is invalidated when the path changes."
  (let ((codex-ide--cli-available t)
        (codex-ide-cli-path "true")
        (detected 0))
    (cl-letf (((symbol-function 'codex-ide--detect-cli)
               (lambda ()
                 (setq detected (1+ detected)
                       codex-ide--cli-available nil))))
      (codex-ide-menu--set-cli-path "/no/such/codex-binary")
      (should-not codex-ide--cli-available)
      (should-not (codex-ide--ensure-cli))
      (should (= detected 1))
      (should (equal codex-ide-cli-path "/no/such/codex-binary")))))

(ert-deftest codex-ide-saved-session-candidates-from-rollout ()
  "Saved-session scanner reads rollout session_meta ids."
  (let* ((dir (make-temp-file "codex-ide-sessions-" t))
         (project (file-name-as-directory
                   (make-temp-file "codex-ide-project-" t)))
         (other (file-name-as-directory
                 (make-temp-file "codex-ide-other-" t)))
         (file (expand-file-name "rollout.jsonl" dir))
         (id "019fc273-afc7-7543-85ee-9f7725df777f"))
    (unwind-protect
        (let ((codex-ide-sessions-directory dir)
              (codex-ide-resume-session-scan-limit 50))
          (with-temp-file file
            (insert (format
                     "{\"type\":\"session_meta\",\"payload\":{\"session_id\":%s,\"cwd\":%s}}\n"
                     (json-encode id)
                     (json-encode project))))
          (should (equal (mapcar #'car
                                 (codex-ide--saved-session-candidates project))
                         (list id)))
          (should-not (codex-ide--saved-session-candidates other))
          (should (equal (mapcar #'car
                                 (codex-ide--saved-session-candidates nil))
                         (list id)))
          (cl-letf (((symbol-function 'completing-read)
                     (lambda (&rest _)
                       id)))
            (should (equal (codex-ide--read-saved-session-id project) id)))
          (should (equal (codex-ide--build-command nil id)
                         (cons "codex" (list "resume" id)))))
      (delete-directory dir t)
      (delete-directory project t)
      (delete-directory other t))))

(ert-deftest codex-ide-saved-session-sort-reads-each-timestamp-once ()
  "Sorting rollout files does not repeatedly query their timestamps."
  (let ((directory (make-temp-file "codex-ide-rollouts-" t))
        (attributes (symbol-function 'file-attributes))
        (calls (make-hash-table :test 'equal)))
    (unwind-protect
        (let ((files (cl-loop for n from 1 to 5
                              for file = (expand-file-name
                                          (format "%d.jsonl" n) directory)
                              do (write-region "" nil file nil 'silent)
                              do (set-file-times file (seconds-to-time n))
                              collect file)))
          (cl-letf (((symbol-function 'file-attributes)
                     (lambda (file &rest args)
                       (when (member file files)
                         (puthash file (1+ (gethash file calls 0)) calls))
                       (apply attributes file args))))
            (should (equal (codex-ide--newest-rollout-files directory 2)
                           (reverse (last files 2)))))
          (dolist (file files)
            (should (= (gethash file calls 0) 1))))
      (delete-directory directory t))))

(ert-deftest codex-ide-saved-session-large-metadata ()
  "Read complete UTF-8 metadata across chunks and ignore later events."
  (let ((file (make-temp-file "codex-ide-rollout-")))
    (unwind-protect
        (dolist (ending '("" "\n{broken later event"))
          (with-temp-file file
            (insert (json-encode
                     `((type . "session_meta")
                       (payload . ((id . "large")
                                   (cwd . "/tmp/δοκιμή")
                                   (instructions . ,(make-string 9000 ?λ))))))
                    ending))
          (should (equal (codex-ide--json-field
                          (codex-ide--rollout-session-meta file) "cwd")
                         "/tmp/δοκιμή")))
      (delete-file file))))

(ert-deftest codex-ide-saved-session-metadata-boundaries ()
  "Accept complete metadata at chunk and size boundaries."
  (let ((file (make-temp-file "codex-ide-rollout-"))
        (line "{\"type\":\"session_meta\",\"payload\":{\"id\":\"boundary\"}}"))
    (unwind-protect
        (progn
          (dolist (size (list 8191 8192 8193 (* 1024 1024)))
            (dolist (ending '("" "\n"))
              (with-temp-file file
                (insert line (make-string (- size (length line)) ?\s) ending))
              (should (equal (codex-ide--json-field
                              (codex-ide--rollout-session-meta file) "id")
                             "boundary"))))
          (dolist (invalid '("" "   " "{broken" "{\"type\":\"event\"}"))
            (with-temp-file file (insert invalid))
            (should-not (codex-ide--rollout-session-meta file))))
      (delete-file file))))

(ert-deftest codex-ide-saved-session-oversized-metadata ()
  "Report metadata exceeding the size bound instead of silently skipping."
  (let ((file (make-temp-file "codex-ide-rollout-")))
    (unwind-protect
        (progn
          (with-temp-file file (insert (make-string (1+ (* 1024 1024)) ?x)))
          (should-error (codex-ide--rollout-session-meta file)
                        :type 'user-error))
      (delete-file file))))

(ert-deftest codex-ide-saved-session-project-limit ()
  "Count matching unique sessions, preserving newest order and fallback."
  (let* ((dir (make-temp-file "codex-ide-rollouts-" t))
         (codex-ide-sessions-directory dir)
         (codex-ide-resume-session-scan-limit 2))
    (unwind-protect
        (progn
          (cl-loop for (id cwd) in '(("old" "/tmp/project")
                                     ("middle" "/tmp/project")
                                     ("middle" "/tmp/project")
                                     ("new" "/tmp/other")
                                     ("newest" "/tmp/other"))
                   for n from 1
                   for file = (expand-file-name (format "%s.jsonl" n) dir)
                   do (with-temp-file file
                        (insert (json-encode
                                 `((type . "session_meta")
                                   (payload . ((id . ,id) (cwd . ,cwd)))))))
                   do (set-file-times file (seconds-to-time n)))
          (should (equal (mapcar #'car (codex-ide--saved-session-candidates
                                        "/tmp/project"))
                         '("middle" "old")))
          (should (equal (mapcar #'car (codex-ide--saved-session-candidates))
                         '("newest" "new")))
          (cl-letf (((symbol-function 'completing-read)
                     (lambda (_prompt collection &rest _) (car (all-completions "" collection)))))
            (should (equal (codex-ide--read-saved-session-id "/tmp/absent")
                           "newest"))))
      (delete-directory dir t))))

(ert-deftest codex-ide-stop-active-only-contract ()
  "Stop kills only the active session buffer for a project root."
  (let ((root (file-name-as-directory
               (make-temp-file "codex-ide-stop-" t))))
    (unwind-protect
        (codex-ide-test--call-with-sessions
         `((,root 1) (,root 2))
         (lambda (sessions)
           (let* ((first (car sessions))
                  (second (cadr sessions))
                  (logs nil))
             (codex-ide--activate-session first)
             (cl-letf (((symbol-function 'codex-ide-log)
                        (lambda (fmt &rest args)
                          (push (apply #'format fmt args) logs)))
                       ((symbol-function 'codex-ide--get-working-directory)
                        (lambda () root)))
               (codex-ide-stop))
             (should-not (buffer-live-p (plist-get first :buffer)))
             (should (buffer-live-p (plist-get second :buffer)))
             (should (cl-some (lambda (line)
                                (string-match-p "active Codex session" line))
                              logs)))))
      (delete-directory root t))))

(ert-deftest codex-ide-attach-source-snapshots-before-targeting ()
  "Changing source during completion cannot change the attached draft."
  (codex-ide-test--call-with-buffer-process
   (lambda (target process)
     (let* ((root temporary-file-directory)
            (session (codex-ide--make-session root 1 target process))
            (codex-ide--sessions (make-hash-table :test 'equal))
            (kill-ring '("untouched")) writes)
       (puthash root (list session) codex-ide--sessions)
       (with-current-buffer target
         (setq-local codex-ide-mode t codex-ide--session-root root
                     codex-ide--session-id 1 codex-ide-term--backend 'eat))
       (with-temp-buffer
         (rename-buffer "source-test" t)
         (insert "first\nλ\tsecond\nthird")
         (goto-char 7)
         (push-mark (point-max) t t)
         (let ((transient-mark-mode t))
           (cl-letf (((symbol-function 'codex-ide--target-session)
                      (lambda (&optional _root)
                        (erase-buffer) (insert "changed") session))
                     ((symbol-function 'process-send-string)
                      (lambda (proc text) (push (cons proc text) writes))))
             (codex-ide-attach-source)))
         (should (equal (mapcar #'cdr writes)
                        '("\e[200~Source: source-test (lines 2-3)\nλ\tsecond\nthird\e[201~")))
         (should (eq (caar writes) process))
         (should (equal kill-ring '("untouched"))))))))

(ert-deftest codex-ide-attach-source-targets-one-labelled-session ()
  "The real target picker routes a current-line snapshot to one labelled owner."
  (codex-ide-test--call-with-buffer-process
   (lambda (first first-process)
     (codex-ide-test--call-with-buffer-process
      (lambda (second second-process)
        (let* ((root temporary-file-directory)
               (a (codex-ide--make-session root 1 first first-process))
               (b (codex-ide--make-session root 2 second second-process))
               (codex-ide--sessions (make-hash-table :test 'equal))
               (codex-ide--active-session-ids (make-hash-table :test 'equal))
               writes)
          (puthash root (list a b) codex-ide--sessions)
          (dolist (session (list a b))
            (with-current-buffer (plist-get session :buffer)
              (setq-local codex-ide-mode t codex-ide--session-root root
                          codex-ide--session-id (plist-get session :id)
                          codex-ide-term--backend 'eat)))
          (with-current-buffer second (rename-buffer "*codex:test-review*" t))
          (with-temp-buffer
            (setq buffer-file-name "/tmp/source.el")
            (insert "before\nchosen line\nafter")
            (goto-char 10)
            (cl-letf (((symbol-function 'codex-ide--get-working-directory)
                       (lambda (&optional _) root))
                      ((symbol-function 'codex-ide--recover-live-sessions) #'ignore)
                      ((symbol-function 'completing-read)
                       (lambda (_prompt choices &rest _)
                         (setq choices (codex-ide-test--completion-candidates choices))
                         (should (= (length choices) 2))
                         (should (assoc (buffer-name second) choices))
                         (erase-buffer) (insert "picker changed source")
                         (buffer-name second)))
                      ((symbol-function 'process-send-string)
                       (lambda (proc text) (push (cons proc text) writes))))
              (codex-ide-attach-source))
            (should (equal writes
                           (list (cons second-process
                                       (format "\e[200~Source: %s (lines 2-2)\nchosen line\e[201~" (file-relative-name "/tmp/source.el" root)))))))))))))

(ert-deftest codex-ide-attach-source-rejects-controls-and-size ()
  "Unsafe content and metadata fail before targeting or changing drafts."
  (dolist (text '("bad\r" "bad\e[201~\r" "bad\0" "bad\177" "bad\u0085"))
    (dolist (metadata '(nil t))
      (with-temp-buffer
        (let ((kill-ring '("untouched")))
          (if metadata (setq buffer-file-name text) (insert text))
          (cl-letf (((symbol-function 'codex-ide--target-session)
                     (lambda (&rest _) (ert-fail "Unsafe input reached picker"))))
            (should-error (codex-ide-attach-source) :type 'user-error))
          (should (equal kill-ring '("untouched")))))))
  (with-temp-buffer
    (insert (make-string (1+ (* 1024 1024)) ?x))
    (cl-letf (((symbol-function 'codex-ide--target-session)
               (lambda (&rest _) (ert-fail "Oversize input reached picker"))))
      (should-error (codex-ide-attach-source) :type 'user-error))))

(ert-deftest codex-ide-attach-source-rejects-replaced-session ()
  "A stale selection cannot send to a replacement or the previous owner."
  (codex-ide-test--call-with-buffer-process
   (lambda (buffer process)
     (let* ((session (codex-ide--make-session temporary-file-directory
                                              1 buffer process))
            (codex-ide--sessions (make-hash-table :test 'equal)))
       (puthash temporary-file-directory (list (copy-sequence session))
                codex-ide--sessions)
       (with-current-buffer buffer
         (setq-local codex-ide-mode t
                     codex-ide--session-root temporary-file-directory
                     codex-ide--session-id 1 codex-ide-term--backend 'eat))
       (with-temp-buffer
         (insert "draft")
         (cl-letf (((symbol-function 'codex-ide--target-session)
                    (lambda (&optional _) session))
                   ((symbol-function 'process-send-string)
                    (lambda (&rest _) (ert-fail "Stale owner received input"))))
           (should-error (codex-ide-attach-source) :type 'user-error)))))))

(ert-deftest codex-ide-prompt-is-one-literal-paste ()
  "Complete prompts use validated framing followed by one submit."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1))
      (lambda (sessions)
        (let* ((session (car sessions))
               (buffer (plist-get session :buffer))
               writes)
          (with-current-buffer buffer
            (setq major-mode 'eat-mode)
            (codex-ide-mode 1)
            (cl-letf (((symbol-function 'process-send-string)
                       (lambda (process text) (push (list process text) writes)))
                      ((symbol-function 'codex-ide-term--send-return)
                       (lambda () (push 'return writes)))
                      ((symbol-function 'sit-for) (lambda (&rest _) nil)))
              (codex-ide-send-prompt "λ\ttext\nnext")
              (should (equal (reverse writes)
                             (list (list (plist-get session :process)
                                         "\e[200~λ\ttext\nnext\e[201~")
                                   'return)))
              (setq writes nil)
              (should-error (codex-ide-send-prompt "unsafe\e[201~")
                            :type 'user-error)
              (should-not writes)))))))))

(ert-deftest codex-ide-input-rejects-owner-loss-across-yields ()
  "Minibuffer, input and pause cannot redirect submission to a successor."
  (dolist (backend '(eat vterm))
    (dolist (mutation '(id root mode backend record process buffer))
      (dolist (command '(codex-ide-send-prompt))
	(dolist (boundary '(read send pause))
	  (unless (and (eq command 'codex-ide-insert-newline) (eq boundary 'read))
            (codex-ide-test--call-with-project
             (lambda (root)
               (codex-ide-test--call-with-sessions
		`((,root 1) (,root 2))
		(lambda (sessions)
		  (let* ((owner (car sessions))
			 (buffer (plist-get owner :buffer))
			 (sibling (plist-get (cadr sessions) :buffer))
			 (invalidate (lambda ()
                                       (pcase mutation
					 ('id (with-current-buffer buffer
						(setq codex-ide--session-id 99)))
					 ('root (with-current-buffer buffer
						  (setq codex-ide--session-root "/changed/")))
					 ('mode (with-current-buffer buffer
						  (setq major-mode 'fundamental-mode)))
					 ('backend (with-current-buffer buffer
                                                     (setq codex-ide-term--backend 'changed)))
					 ('record
					  (puthash root
						   (mapcar (lambda (s)
                                                             (if (eq s owner)
								 (copy-sequence s) s))
							   (gethash root codex-ide--sessions))
						   codex-ide--sessions))
					 ('process
					  (delete-process (plist-get owner :process))
					  (setf (plist-get owner :process)
						(codex-ide-test--make-buffer-process
						 buffer "codex-replacement")))
					 ('buffer (kill-buffer buffer)))
                                       (set-buffer sibling)))
			 writes returned)
                    (with-current-buffer buffer
                      (setq major-mode (if (eq backend 'eat) 'eat-mode 'vterm-mode))
                      (setq-local codex-ide-term--backend backend)
                      (codex-ide-mode 1)
                      (cl-letf (((symbol-function 'read-string)
				 (lambda (&rest _) (funcall invalidate) "hello"))
				((symbol-function 'codex-ide-term--paste-draft)
				 (lambda (&rest _)
				   (push 'paste writes)
				   (when (eq boundary 'send) (funcall invalidate))))
				((symbol-function 'codex-ide-term--send-string)
				 (lambda (&rest _)
				   (push 'string writes)
				   (when (eq boundary 'send) (funcall invalidate))))
				((symbol-function 'sit-for)
				 (lambda (&rest _)
				   (when (eq boundary 'pause) (funcall invalidate))))
				((symbol-function 'codex-ide-term--send-return)
				 (lambda () (setq returned (current-buffer)))))
			(should-error
			 (if (eq command 'codex-ide-send-prompt)
                             (funcall command (unless (eq boundary 'read) "hello"))
			   (funcall command))
			 :type 'user-error))
                      (should-not returned)
                      (when (eq boundary 'read) (should-not writes)))
                    (should (process-live-p (plist-get (cadr sessions) :process))))))))))))))

(ert-deftest codex-ide-sentinel-uses-process-status-not-event-text ()
  "Hangup cleans up; live stop and continue events do not."
  (dolist (status '(signal exit stop run))
    (let (cleaned chained)
      (cl-letf (((symbol-function 'process-exit-status) (lambda (_) 0))
                ((symbol-function 'process-status) (lambda (_) status))
                ((symbol-function 'codex-ide--finish-session)
                 (lambda (&rest _) (setq cleaned t))))
        (funcall (codex-ide--make-process-sentinel
                  "/tmp/root" 1 (lambda (&rest _) (setq chained t)))
                 'fake-proc "hangup\n"))
      (should chained)
      (should (eq cleaned (and (memq status '(signal exit)) t))))))

(ert-deftest codex-ide-resume-preserves-running-session ()
  "Public resume commands add live sessions without replacing existing ones."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1))
      (lambda (sessions)
        (let (created)
          (unwind-protect
              (cl-letf (((symbol-function 'codex-ide--ensure-cli) (lambda () t))
                        ((symbol-function 'codex-ide--maybe-ensure-context-server) #'ignore)
                        ((symbol-function 'codex-ide--record-source-buffer) #'ignore)
                        ((symbol-function 'codex-ide-term--configure-buffer) #'ignore)
                        ((symbol-function 'codex-ide--create-session)
                         (lambda (id last saved)
                           (let ((session (codex-ide-test--make-session root id)))
                             (push (list id last saved session) created)
                             session)))
                        ((symbol-function 'codex-ide--read-saved-session-id)
                         (lambda (&rest _) (list :id "saved" :cwd root))))
                (call-interactively #'codex-ide-resume-last)
                (call-interactively #'codex-ide-resume)
                (should (equal (mapcar (lambda (entry) (seq-take entry 3)) created)
                               '((3 nil "saved") (2 t nil))))
                (should (= (length (codex-ide--project-sessions root)) 3))
                (should (eq (codex-ide--session-by-id root 1) (car sessions)))
                (dolist (session (codex-ide--project-sessions root))
                  (should (process-live-p (plist-get session :process)))))
            (dolist (entry created)
              (codex-ide-test--kill-session (nth 3 entry))))))))))

(ert-deftest codex-ide-newline-sends-only-lf ()
  "Newline is a single LF write without waiting or submitting."
  (let (writes)
    (cl-letf (((symbol-function 'codex-ide--target-session) #'ignore)
              ((symbol-function 'codex-ide--input-owner) #'ignore)
              ((symbol-function 'codex-ide--validate-input-owner)
               (lambda (_) (current-buffer)))
              ((symbol-function 'codex-ide-term--send-string)
               (lambda (text) (push text writes)))
              ((symbol-function 'codex-ide-term--send-return)
               (lambda () (push 'return writes)))
              ((symbol-function 'sit-for)
               (lambda (&rest _) (push 'wait writes))))
      (codex-ide-insert-newline)
      (should (equal writes '("\n"))))))

(ert-deftest codex-ide-cli-caches-failure-and-version-by-path ()
  "Failures are cached, path changes retry, and status probes only once."
  (let ((codex-ide--cli-available nil)
        (codex-ide--cli-cache nil)
        (codex-ide-cli-path "/absent/codex")
        calls)
    (cl-letf (((symbol-function 'call-process)
               (lambda (program _in destination &rest _)
                 (push program calls)
                 (when destination (insert "codex test-version\n"))
                 (if (equal program "/absent/codex") 1 0))))
      (should-not (codex-ide--ensure-cli))
      (should-not (codex-ide--ensure-cli))
      (setq codex-ide-cli-path "/present/codex")
      (should (codex-ide--ensure-cli))
      (codex-ide-check-status)
      (should (= (length calls) 3))
      (should (equal (plist-get codex-ide--cli-cache :version)
                     "codex test-version")))))

(ert-deftest codex-ide-hide-restores-created-split ()
  "Hiding a display-created window restores the original layout."
  (let ((buffer (generate-new-buffer " *codex hide*"))
        (codex-ide-display-buffer-function #'display-buffer))
    (unwind-protect
        (save-window-excursion
          (delete-other-windows)
          (let ((display-buffer-alist
                 `((,(regexp-quote (buffer-name buffer))
                    (display-buffer-below-selected)))))
            (codex-ide--display-buffer buffer)
            (should (= (length (window-list)) 2))
            (codex-ide--hide-displayed-buffer buffer)
            (should (= (length (window-list)) 1))
            (should (buffer-live-p buffer))))
      (kill-buffer buffer))))

(ert-deftest codex-ide-start-continues-after-context-failure ()
  "An optional context failure is logged without preventing session startup."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1))
      (lambda (sessions)
        (let (setup logs)
          (cl-letf (((symbol-function 'codex-ide--ensure-cli) (lambda () t))
                    ((symbol-function 'codex-ide--record-source-buffer) #'ignore)
                    ((symbol-function 'codex-ide--maybe-ensure-context-server)
                     (lambda () (user-error "Socket owned elsewhere")))
                    ((symbol-function 'codex-ide--create-session)
                     (lambda (&rest _) (car sessions)))
                    ((symbol-function 'codex-ide--remember-session) #'ignore)
                    ((symbol-function 'codex-ide--setup-session)
                     (lambda (_) (setq setup t)))
                    ((symbol-function 'codex-ide-log)
                     (lambda (format &rest args)
                       (push (apply #'format format args) logs))))
            (codex-ide-new-session))
          (should setup)
          (should (seq-some (lambda (text)
                              (string-match-p "Socket owned elsewhere" text)) logs))))))))

(ert-deftest codex-ide-exit-policy-retains-output ()
  "Exit policies preserve diagnostics, unregister owners and ignore repeats."
  (dolist (backend '(eat vterm))
    (dolist (policy '(nil t success))
      (dolist (status '(exit signal))
        (dolist (code '(0 9))
          (codex-ide-test--call-with-project
           (lambda (root)
             (codex-ide-test--call-with-sessions
              `((,root 1) (,root 2))
              (lambda (sessions)
                (let* ((session (car sessions))
                       (buffer (plist-get session :buffer))
                       (process (plist-get session :process))
                       (codex-ide-kill-buffer-on-exit policy)
                       (success (and (eq status 'exit) (= code 0)))
                       (keep (not (or (eq policy t) (and (eq policy 'success) success))))
                       (sentinel (codex-ide--make-process-sentinel
                                  root 1 (lambda (&rest _) (codex-ide--all-sessions))
                                  buffer)))
                  (with-current-buffer buffer
                    (insert "diagnostic output"))
                  (cl-letf (((symbol-function 'codex-ide-term--configure-buffer)
                             #'ignore))
                    (codex-ide--setup-session session))
                  (with-current-buffer buffer
                    (setq-local codex-ide-term--backend backend))
                  ;; Stub status only: cleanup still stops the actual fixture process.
                  (cl-letf (((symbol-function 'process-status) (lambda (_) status))
                            ((symbol-function 'process-exit-status) (lambda (_) code)))
                    (funcall sentinel process "test exit\n"))
                  (should-not (codex-ide--session-by-id root 1))
                  (should (codex-ide--session-live-p (cadr sessions)))
                  (should (eq (buffer-live-p buffer) keep))
                  (when keep
                    (with-current-buffer buffer
                      (should-not codex-ide-mode)
                      (should buffer-read-only)
                      (should (string-match-p "diagnostic output" (buffer-string)))
                      (should (string-match-p "\\[Codex exited: test exit\\]" (buffer-string)))
                      (goto-char (point-max))
                      (should (eq (get-text-property (- (point) 2) 'face)
                                  (if success 'success 'error)))))
                  (let ((before (and keep (with-current-buffer buffer (buffer-string)))))
                    (codex-ide--finish-session root 1 buffer process nil "late")
                    (when keep (should (equal before (with-current-buffer buffer
                                                       (buffer-string))))))))))))))))

(ert-deftest codex-ide-resume-fallback-metadata-and-cwd ()
  "Fallback discovers once, preserves order, annotates IDs and resumes at cwd."
  (let ((records '((:id "z-new" :cwd "/tmp/other/" :date "2026-10-11")
                   (:id "a-old" :cwd "/tmp/old/" :date "2026-10-10")))
        (codex-ide-resume-session-scan-limit 200)
        (calls 0) started)
    (cl-letf (((symbol-function 'codex-ide--get-working-directory)
               (lambda () (or codex-ide--working-directory "/tmp/current/")))
              ((symbol-function 'codex-ide--saved-sessions)
               (lambda () (cl-incf calls) records))
              ((symbol-function 'completing-read)
               (lambda (prompt table &rest _)
                 (should (string-match-p "all projects" prompt))
                 (should (equal (all-completions "" table) '("z-new" "a-old")))
                 (let ((meta (completion-metadata "" table nil)))
                   (should (eq (completion-metadata-get meta 'display-sort-function) #'identity))
                   (should (eq (completion-metadata-get meta 'cycle-sort-function) #'identity))
                   (should (equal (funcall (completion-metadata-get meta 'annotation-function)
                                           "z-new") "  2026-10-11  /tmp/other/")))
                 "z-new"))
              ((symbol-function 'codex-ide--start-session)
               (lambda (last id new)
                 (setq started (list last id new (codex-ide--get-working-directory))))))
      (codex-ide-resume)
      (should (= calls 1))
      (should (equal started '(nil "z-new" t "/tmp/other/"))))))

(ert-deftest codex-ide-rollout-cache-invalidates-on-time-or-size ()
  "Unchanged files, including invalid JSON, are parsed only once."
  (let ((file (make-temp-file "codex-rollout-cache-"))
        (codex-ide--rollout-cache (make-hash-table :test 'equal))
        (parse (symbol-function 'codex-ide--parse-rollout-session-meta))
        (calls 0))
    (unwind-protect
        (cl-letf (((symbol-function 'codex-ide--parse-rollout-session-meta)
                   (lambda (path) (cl-incf calls) (funcall parse path))))
          (with-temp-file file (insert "invalid"))
          (should-not (codex-ide--rollout-session-meta file))
          (should-not (codex-ide--rollout-session-meta file))
          (should (= calls 1))
          (let ((stamp (file-attribute-modification-time (file-attributes file))))
            (with-temp-file file
              (insert "{\"type\":\"session_meta\",\"payload\":{\"id\":\"new\"}}"))
            (set-file-times file stamp)
            (should (equal (codex-ide--json-field (codex-ide--rollout-session-meta file) "id") "new")))
          (should (= calls 2))
          (set-file-times file (time-add (current-time) 60))
          (codex-ide--rollout-session-meta file)
          (should (= calls 3)))
      (delete-file file))))

(ert-deftest codex-ide-registered-lookups-do-not-recover ()
  "Healthy registry lookups neither scan buffers nor repeat setup."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1))
      (lambda (sessions)
        (let ((codex-ide--recovery-pending nil) calls)
          (cl-letf (((symbol-function 'codex-ide--recover-live-sessions)
                     (lambda () (push 'recovery calls)))
                    ((symbol-function 'codex-ide--setup-session)
                     (lambda (_) (push 'setup calls))))
            (should (eq (codex-ide--active-session root) (car sessions)))
            (should (eq (codex-ide--target-session root) (car sessions)))
            (codex-ide--session-candidates root)
            (codex-ide--all-sessions)
            (codex-ide--recover-live-session (plist-get (car sessions) :buffer))
            (should-not calls))))))))

(ert-deftest codex-ide-stop-interactive-confirmation ()
  "Interactive refusal keeps the session, whereas Lisp calls do not ask."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1))
      (lambda (sessions)
        (let ((buffer (plist-get (car sessions) :buffer)) (asks 0))
          (cl-letf (((symbol-function 'called-interactively-p) (lambda (_) t))
                    ((symbol-function 'y-or-n-p) (lambda (_) (cl-incf asks) nil)))
            (call-interactively #'codex-ide-stop))
          (should (= asks 1))
          (should (buffer-live-p buffer))
          (cl-letf (((symbol-function 'y-or-n-p) (lambda (_) (cl-incf asks) nil)))
            (codex-ide-stop))
          (should (= asks 1))
          (should-not (buffer-live-p buffer))))))))

(ert-deftest codex-ide-session-completion-category ()
  "Session pickers expose the standard buffer category."
  (cl-letf (((symbol-function 'codex-ide--session-candidates)
             (lambda (_) '(("session" :id 1))))
            ((symbol-function 'completing-read)
             (lambda (_ table &rest _args)
               (should (eq (completion-metadata-get
                            (completion-metadata "" table nil) 'category) 'buffer))
               "session")))
    (should (equal (codex-ide--read-session) '(:id 1)))))

(ert-deftest codex-ide-mode-line-session-label-and-backend ()
  "The mode line reports identity and backend using semantic faces."
  (with-temp-buffer
    (setq-local codex-ide--session-id 3 codex-ide-term--backend 'eat)
    (codex-ide-mode 1)
    (let ((text (mapconcat #'identity (codex-ide--mode-line) "")))
      (should (equal text " Codex:3/eat"))
      (should (eq (get-text-property 1 'face text) 'mode-line-emphasis)))
    (setq codex-ide--session-label "review")
    (should (equal (mapconcat #'identity (codex-ide--mode-line) "") " Codex:review/eat"))
    (codex-ide-mode -1)
    (should-not (local-variable-p 'mode-line-process))))

(ert-deftest codex-ide-prompt-uses-history ()
  "Minibuffer prompts use their dedicated history variable."
  (cl-letf (((symbol-function 'codex-ide--record-source-buffer) #'ignore)
            ((symbol-function 'codex-ide--target-session) #'ignore)
            ((symbol-function 'codex-ide--input-owner) #'ignore)
            ((symbol-function 'read-string)
             (lambda (_prompt _initial history &rest _)
               (should (eq history 'codex-ide-prompt-history)) "")))
    (codex-ide-send-prompt)))

(ert-deftest codex-ide-nonselecting-display-preserves-selection ()
  "Even a selecting user display function cannot steal attachment focus."
  (let ((buffer (generate-new-buffer " *codex nonselect*"))
        (codex-ide-display-buffer-function
         (lambda (buffer) (pop-to-buffer buffer '(display-buffer-pop-up-window)))))
    (unwind-protect
        (save-window-excursion
          (delete-other-windows)
          (let ((origin (selected-window)))
            (should (window-live-p (codex-ide--display-buffer buffer nil)))
            (should (eq origin (selected-window)))))
      (kill-buffer buffer))))

(ert-deftest codex-ide-display-and-hide-scope-frame-lookups ()
  "Ordinary lookup and hiding pass the selected frame explicitly."
  (let ((buffer (generate-new-buffer " *codex frame scope*")))
    (unwind-protect
        (cl-letf (((symbol-function 'get-buffer-window)
                   (lambda (_buffer frame)
                     (should (eq frame (selected-frame))) nil))
                  ((symbol-function 'get-buffer-window-list)
                   (lambda (_buffer _minibuffer frame)
                     (should (eq frame (selected-frame))) nil)))
          (let ((codex-ide-display-buffer-function #'ignore))
            (should-not (codex-ide--display-buffer buffer))
            (should-not (codex-ide--session-visible-p (list :buffer buffer)))
            (codex-ide--hide-displayed-buffer buffer)))
      (kill-buffer buffer))))

(ert-deftest codex-ide-display-across-frames ()
  "Existing windows stay frame-local; explicit cross-frame placement focuses."
  (skip-unless (display-graphic-p))
  (let ((origin (selected-frame))
        (buffer (generate-new-buffer " *codex other frame*"))
        other)
    (unwind-protect
        (progn
          (setq other (make-frame '((name . "Codex display test"))))
          (set-window-buffer (frame-selected-window other) buffer)
          (select-frame-set-input-focus origin)
          (let ((codex-ide-display-buffer-function #'display-buffer)
                (display-buffer-alist
                 `((,(regexp-quote (buffer-name buffer))
                    (display-buffer-pop-up-window) (reusable-frames . nil)))))
            (let ((window (codex-ide--display-buffer buffer t)))
              (should (eq (window-frame window) origin))
              (codex-ide--hide-displayed-buffer buffer)
              (should (eq (window-buffer (frame-selected-window other)) buffer))))
          (let ((codex-ide-display-buffer-function
                 (lambda (_) (frame-selected-window other))))
            (should (eq (codex-ide--display-buffer buffer t)
                        (frame-selected-window other)))
            (should (eq (selected-frame) other))))
      (when (frame-live-p origin) (select-frame-set-input-focus origin))
      (when (frame-live-p other) (delete-frame other))
      (kill-buffer buffer))))

(ert-deftest codex-ide-mode-restores-previous-process-mode-line ()
  "Disabling the mode restores a backend's original local process display."
  (with-temp-buffer
    (setq-local mode-line-process '(" Backend"))
    (codex-ide-mode 1)
    (codex-ide-mode 1)
    (codex-ide-mode -1)
    (should (equal mode-line-process '(" Backend")))))

(ert-deftest codex-ide-retained-buffer-does-not-alias-reused-id ()
  "A retained transcript never routes commands to a successor reusing its id."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let ((codex-ide--sessions (make-hash-table :test 'equal))
           (codex-ide--active-session-ids (make-hash-table :test 'equal))
           (codex-ide--recovery-pending nil)
           (codex-ide-kill-buffer-on-exit nil)
           buffers processes)
       (cl-labels ((make (name id)
                     (let* ((buffer (generate-new-buffer name))
                            (process (codex-ide-test--make-buffer-process
                                      buffer name))
                            (session (codex-ide--make-session
                                      root id buffer process)))
                       (push buffer buffers)
                       (push process processes)
                       (set-process-query-on-exit-flag process nil)
                       (with-current-buffer buffer
                         (setq default-directory root)
                         (setq-local codex-ide--session-root root
                                     codex-ide--session-id id)
                         (codex-ide-mode 1))
                       (codex-ide--remember-session session)
                       session)))
         (unwind-protect
             (let* ((a (make "*retained*" 1))
                    (old (plist-get a :buffer))
                    (b (make "*sibling*" 2))
                    c)
               (codex-ide--finish-session root 1 old (plist-get a :process)
                                          nil "failed")
               (setq c (make "*successor*" (codex-ide--next-session-id root)))
               (should (= (plist-get c :id) 1))
               (codex-ide--activate-session b)
               (with-current-buffer old
                 (should-not codex-ide-mode)
                 (should-not (codex-ide--buffer-session))
                 (should (eq b (codex-ide--active-session root)))
                 (codex-ide-stop))
               (should (codex-ide--session-live-p c))
               (should-not (codex-ide--session-live-p b))
               (should (buffer-live-p old)))
           (dolist (process processes)
             (when (process-live-p process) (delete-process process)))
           (dolist (buffer buffers)
             (when (buffer-live-p buffer) (kill-buffer buffer)))))))))

(ert-deftest codex-ide-new-session-preserves-retained-buffer ()
  "Starting again allocates a new buffer without reusing failed output."
  (codex-ide-test--call-with-project
   (lambda (root)
     (let* ((name (codex-ide--get-buffer-name root 1))
            (retained (get-buffer-create name))
            (process nil) (created nil))
       (unwind-protect
           (progn
             (with-current-buffer retained
               (insert "failure evidence")
               (setq-local codex-ide--session-root root codex-ide--session-id 1))
             (cl-letf (((symbol-function 'codex-ide--session-config-overrides) #'ignore)
                       ((symbol-function 'codex-ide--display-buffer)
                        (lambda (&rest _) (selected-window)))
                       ((symbol-function 'codex-ide-term--make-process)
                        (lambda (buffer &rest _)
                          (setq process (codex-ide-test--make-buffer-process buffer "retained-test")))))
               (let ((session (codex-ide--create-session 1)))
                 (setq created (plist-get session :buffer))
                 (should-not (eq created retained))))
             (should (equal (with-current-buffer retained (buffer-string)) "failure evidence")))
         (when (process-live-p process) (delete-process process))
         (when (buffer-live-p created) (kill-buffer created))
         (kill-buffer retained))))))

(ert-deftest codex-ide-resume-normalizes-owner-and-routes-siblings ()
  "Saved cwd determines launch location, while the project owns all routing."
  (codex-ide-test--call-with-project
   (lambda (root)
     (dolist (fixture '((nil nil) (nil t) (t nil) (t t)))
       (let* ((nested (car fixture))
              (sibling (cadr fixture))
              (cwd (if nested (expand-file-name "sub" root)
                     (directory-file-name root)))
              (codex-ide--recovery-pending nil)
              (codex-ide-mcp-enabled nil)
              (codex-ide-display-buffer-function #'pop-to-buffer-same-window)
              launched resumed sent cycled)
         (make-directory cwd t)
         (codex-ide-test--call-with-sessions
          (when sibling `((,root 1)))
          (lambda (sessions)
            (unwind-protect
                (save-window-excursion
                  (cl-letf (((symbol-function 'codex-ide--read-saved-session-id)
                             (lambda (&rest _) (list :cwd cwd :id "saved")))
                            ((symbol-function 'codex-ide--ensure-cli) (lambda () t))
                            ((symbol-function 'codex-ide--maybe-ensure-context-server) #'ignore)
                            ((symbol-function 'codex-ide-term--prepare-buffer)
                             (lambda (name directory)
                               (setq launched directory)
                               (let ((buffer (generate-new-buffer name)))
                                 (with-current-buffer buffer
                                   (setq default-directory directory)
                                   (setq major-mode 'eat-mode)
                                   (setq-local codex-ide-term--backend 'eat))
                                 buffer)))
                            ((symbol-function 'codex-ide-term--make-process)
                             (lambda (buffer &rest _)
                               (codex-ide-test--make-buffer-process buffer "resumed")))
                            ((symbol-function 'codex-ide-term--configure-buffer) #'ignore)
                            ((symbol-function 'codex-ide-term--paste-draft)
                             (lambda (process _text) (setq sent process)))
                            ((symbol-function 'codex-ide--submit-input) #'ignore)
                            ((symbol-function 'codex-ide--cycle-project-session)
                             (lambda (owner candidates active)
                               (setq cycled (list owner (length candidates) active)))))
                    (codex-ide-resume)
                    (setq resumed (codex-ide--buffer-session))
                    (should resumed)
                    (should (equal launched (file-name-as-directory cwd)))
                    (should (equal (plist-get resumed :root) root))
                    (should (= (if sibling 2 1) (length (codex-ide--project-sessions root))))
                    ;; A sibling becoming active must not steal terminal commands.
                    (when sibling (codex-ide--activate-session (car sessions)))
                    (codex-ide-send-prompt "hello")
                    (should (eq sent (plist-get resumed :process)))
                    (codex-ide-cycle-session)
                    (should (equal (car cycled) root))
                    (should (= (cadr cycled) (if sibling 2 1)))
                    (codex-ide-switch-to-buffer)
                    (should (eq (current-buffer) (plist-get resumed :buffer)))
                    (codex-ide-stop)
                    (should-not (buffer-live-p (plist-get resumed :buffer)))
                    (when sibling (should (codex-ide--session-live-p (car sessions))))))
              (when resumed (codex-ide-test--kill-session resumed))))))))))

(ert-deftest codex-ide-exit-revokes-retained-buffer-token ()
  "Retired session tokens are revoked while sibling credentials stay valid."
  (codex-ide-test--call-with-project
   (lambda (root)
     (codex-ide-test--call-with-sessions
      `((,root 1) (,root 2))
      (lambda (sessions)
        (let* ((session (car sessions))
               (buffer (plist-get session :buffer))
               (process (plist-get session :process))
               (codex-ide-kill-buffer-on-exit nil)
               (codex-ide-mcp--tokens (make-hash-table :test 'equal))
               (token (codex-ide-mcp--session-token buffer))
               (other (codex-ide-mcp--session-token (plist-get (cadr sessions) :buffer))))
          (cl-letf (((symbol-function 'codex-ide-term--configure-buffer) #'ignore))
            (codex-ide--setup-session session))
          (delete-process process)
          (should (codex-ide-test--wait-for
                   (lambda () (not (codex-ide--session-by-id root 1)))))
          (should (buffer-live-p buffer))
          (should-not (gethash token codex-ide-mcp--tokens))
          (should (gethash other codex-ide-mcp--tokens))))))))

(ert-deftest codex-ide-menu-explicit-eat-survives-restart ()
  "Saving an explicit default backend retains its effective native meaning."
  (let* ((directory (make-temp-file "codex-backend-custom-" t))
         (custom-file (expand-file-name "custom.el" directory))
         (user-init-file (expand-file-name "init.el" directory))
         (codex-ide-menu--saved-config-symbols '(codex-ide-terminal-backend))
         (codex-ide-terminal-backend 'eat)
         (symbols '(codex-ide-terminal-backend user))
         (properties (mapcar (lambda (symbol) (copy-tree (symbol-plist symbol))) symbols))
         (package-directory (file-name-directory (locate-library "codex-ide-term"))))
    (unwind-protect
        (progn
          (customize-save-variable 'codex-ide-terminal-backend 'eat)
          (customize-set-variable 'codex-ide-terminal-backend 'eat)
          (codex-ide-menu--save-config)
          (with-temp-buffer
            (should
             (= 0 (prog1 (call-process
                   (expand-file-name invocation-name invocation-directory) nil t nil
                   "-Q" "--batch" "-L" package-directory
                   "--eval" (prin1-to-string
                               `(progn
                                  (setq load-path ',load-path)
                                  (require 'codex-ide-term)
                                  (provide 'neomacs)
                                  (load ,custom-file nil t)
                                  (unless (eq (codex-ide-term--selected-backend) 'eat)
                                    (error "Explicit Eat choice was lost")))))
                    (message "Restart probe: %s" (buffer-string)))))))
      (cl-mapc #'setplist symbols properties)
      (when-let* ((buffer (get-file-buffer custom-file))) (kill-buffer buffer))
      (delete-directory directory t))))

(provide 'codex-ide-tests)

;;; codex-ide-tests.el ends here
