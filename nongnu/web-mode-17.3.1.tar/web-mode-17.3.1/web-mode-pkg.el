;; Generated package description from web-mode.el  -*- no-byte-compile: t -*-
(define-package "web-mode" "17.3.1" "major mode for editing web templates" '((emacs "23.1")) :commit "38ed4c575939083487e8abe59240d0ce4f671c93" :authors '(("François-Xavier Bois")) :maintainer '("François-Xavier Bois" . "fxbois@gmail.com") :keywords '("languages") :url "https://web-mode.org")
