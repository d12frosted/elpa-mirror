;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.1" "A major mode for editing subtitles" '((emacs "25.1")) :commit "12386508eab140ee6c7d83654a162dbf52b0bf93" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
