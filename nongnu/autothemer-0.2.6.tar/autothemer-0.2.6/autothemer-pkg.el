;; Generated package description from autothemer.el  -*- no-byte-compile: t -*-
(define-package "autothemer" "0.2.6" "Conveniently define themes." '((dash "2.10.0") (emacs "24") (cl-lib "0.5")) :commit "f1cf7b8d918d5bcc52c2769c774104b5938a6f85" :authors '(("Sebastian Sturm")) :maintainer '("Jason Milkins" . "jasonm23@gmail.com") :url "https://github.com/jasonm23/autothemer")
