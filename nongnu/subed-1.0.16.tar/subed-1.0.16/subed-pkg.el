;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.16" "A major mode for editing subtitles" '((emacs "25.1")) :commit "1215c6821fadd8213bbd39bef1e0538eac38dbfa" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
