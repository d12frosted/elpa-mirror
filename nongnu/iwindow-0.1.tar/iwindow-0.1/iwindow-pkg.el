;; Generated package description from iwindow.el  -*- no-byte-compile: t -*-
(define-package "iwindow" "0.1" "Interactively manipulate windows" '((emacs "26.1")) :commit "285f40ff09ff359034ef151d5d9dd9385fcfb865" :authors '(("Akib Azmain Turja" . "akib@disroot.org")) :maintainer '("Akib Azmain Turja" . "akib@disroot.org") :keywords '("frames") :url "https://codeberg.org/akib/emacs-iwindow")
