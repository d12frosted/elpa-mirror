;; Generated package description from meow.el  -*- no-byte-compile: t -*-
(define-package "meow" "1.4.3" "Yet Another modal editing" '((emacs "27.1")) :commit "023183656e86165c293359969ddf6f2566b4cb65" :authors '(("Shi Tianshu")) :maintainer '("Shi Tianshu") :keywords '("convenience" "modal-editing") :url "https://www.github.com/DogLooksGood/meow")
