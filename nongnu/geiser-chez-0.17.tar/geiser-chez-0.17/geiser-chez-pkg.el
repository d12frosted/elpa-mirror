;; Generated package description from geiser-chez.el  -*- no-byte-compile: t -*-
(define-package "geiser-chez" "0.17" "Chez Scheme's implementation of the geiser protocols" '((emacs "26.1") (geiser "0.19")) :authors '(("Peter" . "craven@gmx.net")) :maintainer '("Jose A Ortega Ruiz" . "jao@gnu.org") :keywords '("languages" "chez" "scheme" "geiser") :url "https://gitlab.com/emacs-geiser/chez")
