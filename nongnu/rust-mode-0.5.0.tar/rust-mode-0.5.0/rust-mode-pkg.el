;; Generated package description from rust-mode.el  -*- no-byte-compile: t -*-
(define-package "rust-mode" "0.5.0" "A major-mode for editing Rust source code" '((emacs "25.1")) :keywords '("languages") :authors '(("Mozilla")) :maintainer '("Mozilla") :url "https://github.com/rust-lang/rust-mode")
