;; Generated package description from zenburn-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "zenburn-theme" "2.9.0" "A low contrast color theme for Emacs." 'nil :commit "1022240b1061369ecb605d55fa074d20d5c84aae" :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com")) :maintainer '("Bozhidar Batsov" . "bozhidar@batsov.com") :url "https://github.com/bbatsov/zenburn-emacs")
