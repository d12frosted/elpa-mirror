# Changelog

## master (unreleased)

## 2.9.0 (2026-03-29)

### New features

* Add `corfu` support (with `corfu-annotations`, `corfu-deprecated`).
* Add `window-tool-bar` support.
* Add `consult` support.
* Add `embark` support.
* Add `forge` support.
* Add `marginalia` support.
* Add `smerge` support.
* Add `transient` support.
* Add `which-key` support.
* Add `eglot` support.
* Add missing modern Emacs faces: `font-lock-number-face`, `font-lock-operator-face`, `font-lock-bracket-face`, `font-lock-delimiter-face`, `font-lock-escape-face`, `font-lock-function-call-face`, `font-lock-property-name-face`, `font-lock-property-use-face`, `font-lock-variable-use-face` (Emacs 29+), `mode-line-active`, `isearch-group-1`, `isearch-group-2`, `completions-group-title`, `completions-group-separator`, `completions-highlight`, `line-number-major-tick`, `line-number-minor-tick`, `tab-bar-tab-group-current`, `tab-bar-tab-group-inactive`, `tab-bar-tab-ungrouped`.
* Expand `doom-modeline` support (from 2 to 50 faces).
* Expand `vertico` support (add `vertico-multiline`, `vertico-group-title`, `vertico-group-separator`).
* Add GitHub Actions CI for byte-compilation and theme loading.

### Bug fixes

* Fix missing colon in `ediff-fine-diff-Ancestor` face `:weight` keyword.
* Fix trailing colon in `ledger-font-pending-face` face `:weight` keyword.
* Fix duplicate `corfu-bar` definition (second one is now `corfu-border`).
* Fix duplicate `:weight bold` in `org-done`, `org-tag`, `org-todo`, and `org-warning`.
* Replace `hover-highlight` inherit (from niche `hl-line+` package) with direct styling in `erc-highlight-face` and `lui-button-face`.
* Fix spurious quotes in `ruler-mode` face `:inherit` values.
* Fix typo in README and upgrade URLs to HTTPS.

## 2.8 (2023-03-15)

### Changes

* Add `helm-ff-file-extension` face.
* Add `rmail` support.
* Add `tab-bar-mode` support.
* Add `tab-line-mode` support.
* Add `adoc-mode` support.
* [#367](https://github.com/bbatsov/zenburn-emacs/pull/367): Brighten org headline levels 7 and 8 to improve contrast and possibly help those with color blindness.
* Add support for `ansi-color` faces.
* Add support for SLY faces.

## 2.7 (2020-11-21)

### New features

* [#347](https://github.com/bbatsov/zenburn-emacs/issues/347): Add support for `highlight-symbol` and `highlight-thing`.
* Add `helm-lxc` support.
* Theme `swiper-line-face` and `swiper-isearch-current-match`.
* [#330](https://github.com/bbatsov/zenburn-emacs/pull/330): Add centaur-tabs, doom-modeline, and solaire-mode support.
* Add `notmuch` support.

### Changes

* [#346](https://github.com/bbatsov/zenburn-emacs/pull/346): Make numbers in `highlight-numbers` blue.
* Make `zenburn-add-font-lock-keywords` customizable.

### Bugs fixed

* [#321](https://github.com/bbatsov/zenburn-emacs/issues/321): Scale `org-document-title` only if `zenburn-scale-org-headlines` is `t`.
* Fix lots of face inheritance issues on Emacs 27.

## 2.6 (2018-10-14)

### New features

* Port scaled headings and variable pitch features from solarized
* Add parenthesis colour for paren-face
* Support for line-numbers-mode (#311)
* Add faces for org-ref (#312)
* Add support for markup-faces (covers adoc-mode) (#310)
* Add diredfl support
* Add some initial cperl custom faces
* Add hackernews support
* Add `go-guru` support
* Add sx support
* Add git-annex support
* Add eww certificate support
* Add missing ivy face ivy-cursor
* Add faces for merlin-mode
* Add hi-lock support
* Add cider-fringe-good-face
* Add realgud settings
* Customize company-quickhelp colors

### Changes

* Use `diff-refine-changed` face name
* Modify diff colors
* Add more colors to palette
* Rename `zenburn-green-1` to `zenburn-green-2`
* Make `zenburn-override-colors-alist` a customizable variable
* Add zenburn red/green for magit diff remove/add blocks
* Add more magit-signature-* faces
* Update hackernews face names
* Update git-commit faces
* Set the foreground color for "font-latex-script-char-face" to "zenburn-orange" (#292)

### Bugs fixed

* Fix widget-field face on 24bit color text terminals
* Try boxed attribute on enable/disable bp face
* Fix background in Gnus (#271)
