;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.5.0" "annotate files without changing them" 'nil :commit "46aa377cfc31fbaa4a0e9e3ada54d5e299018b95" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold") :url "https://github.com/bastibe/annotate.el")
