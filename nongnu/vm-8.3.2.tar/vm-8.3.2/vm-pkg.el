;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t -*-
(define-package "vm" "8.3.2" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "790c95503d8e130f97a68ab502eb5c77f35011c8" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
