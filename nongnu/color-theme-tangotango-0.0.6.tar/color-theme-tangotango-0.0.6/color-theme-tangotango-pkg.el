;; Generated package description from color-theme-tangotango.el  -*- no-byte-compile: t -*-
(define-package "color-theme-tangotango" "0.0.6" "Tango Palette color theme for Emacs." '((color-theme "6.6.1")) :authors '(("Julien Barnier")) :maintainer '("Julien Barnier") :keywords '("tango" "palette" "color" "theme" "emacs") :url "https://github.com/juba/color-theme-tangotango")
