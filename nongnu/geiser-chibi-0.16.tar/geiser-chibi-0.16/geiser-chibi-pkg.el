;; Generated package description from geiser-chibi.el  -*- no-byte-compile: t -*-
(define-package "geiser-chibi" "0.16" "Chibi Scheme's implementation of the geiser protocols" '((emacs "24.4") (geiser "0.16")) :keywords '("languages" "chibi" "scheme" "geiser") :authors '(("Peter" . "craven@gmx.net")) :maintainer '("Jose A Ortega Ruiz" . "jao@gnu.org") :url "https://gitlab.com/emacs-geiser/chibi")
