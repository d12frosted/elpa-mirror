;; Generated package description from devil.el  -*- no-byte-compile: t -*-
(define-package "devil" "0.3.0" "Minor mode for Devil-like command entering" '((emacs "24.4")) :commit "79fd50fe22ce45968779f0e176247ab7988f0905" :authors '(("Susam Pal" . "susam@susam.net")) :maintainer '("Susam Pal" . "susam@susam.net") :keywords '("convenience" "abbrev") :url "https://github.com/susam/devil")
