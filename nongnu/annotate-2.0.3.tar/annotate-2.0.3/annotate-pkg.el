;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "2.0.3" "annotate files without changing them" 'nil :commit "b2767cdba2cd7c4520811d75154b2489ff1e4d9f" :maintainer '(("Bastian Bechtold" . "bastibe.dev@mailbox.org") ("cage" . "cage-dev@twistfold.it")) :url "https://github.com/bastibe/annotate.el")
