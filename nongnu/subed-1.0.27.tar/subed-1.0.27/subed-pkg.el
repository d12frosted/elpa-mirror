;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.27" "A major mode for editing subtitles" '((emacs "25.1")) :commit "d99f7516df82a58171700a9749f4ff0d05e06146" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
