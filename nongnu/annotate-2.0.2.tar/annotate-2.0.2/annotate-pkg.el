;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "2.0.2" "annotate files without changing them" 'nil :commit "bf42792154c003ac34de794b63aa530d9fdbc22f" :maintainer '(("Bastian Bechtold" . "bastibe.dev@mailbox.org") ("cage" . "cage-dev@twistfold.it")) :url "https://github.com/bastibe/annotate.el")
