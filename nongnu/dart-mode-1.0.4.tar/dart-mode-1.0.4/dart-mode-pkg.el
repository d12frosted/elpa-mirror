;; Generated package description from dart-mode.el  -*- no-byte-compile: t -*-
(define-package "dart-mode" "1.0.4" "Major mode for editing Dart files" '((emacs "24.3")) :keywords '("languages") :authors '(("Brady Trainor" . "mail@bradyt.net")) :maintainer '("Brady Trainor" . "mail@bradyt.net") :url "https://github.com/bradyt/dart-mode")
