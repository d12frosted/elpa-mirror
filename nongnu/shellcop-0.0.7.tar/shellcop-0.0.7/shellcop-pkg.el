;; Generated package description from shellcop.el  -*- no-byte-compile: t -*-
(define-package "shellcop" "0.0.7" "Analyze info&error in shell-mode" '((emacs "25.1")) :authors '(("Chen Bin <chenbin DOT sh AT gmail DOT com>")) :maintainer '("Chen Bin <chenbin DOT sh AT gmail DOT com>") :keywords '("unix" "tools") :url "https://github.com/redguardtoo/shellcop")
