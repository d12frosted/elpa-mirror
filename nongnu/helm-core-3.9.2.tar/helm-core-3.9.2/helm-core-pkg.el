;; Generated package description from helm-core.el  -*- no-byte-compile: t -*-
(define-package "helm-core" "3.9.2" "Development files for Helm" '((emacs "25.1") (async "1.9.7")) :commit "c859db76283068a38270cd833d1b84e2fec3683c" :authors '(("Thierry Volpiatto" . "thievol@posteo.net")) :maintainer '("Thierry Volpiatto" . "thievol@posteo.net") :url "https://emacs-helm.github.io/helm/")
