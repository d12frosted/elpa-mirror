;; Generated package description from swsw.el  -*- no-byte-compile: t -*-
(define-package "swsw" "2.3" "Simple window switching" '((emacs "27.1")) :commit "f41a36677737786d0f651f2d0ba5eb23d63c8ab5" :authors '(("Daniel Semyonov" . "daniel@dsemy.com")) :maintainer '("swsw Mailing List" . "~dsemy/swsw-devel@lists.sr.ht") :keywords '("convenience") :url "https://dsemy.com/projects/swsw")
