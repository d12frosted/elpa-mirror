;; Generated package description from emacsql.el  -*- no-byte-compile: t -*-
(define-package "emacsql" "4.0.0" "High-level SQL database front-end" '((emacs "25.1")) :commit "3d9622aabbf3ab925beadd12ce928370d7704573" :authors '(("Christopher Wellons" . "wellons@nullprogram.com")) :maintainer '("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev") :url "https://github.com/magit/emacsql")
