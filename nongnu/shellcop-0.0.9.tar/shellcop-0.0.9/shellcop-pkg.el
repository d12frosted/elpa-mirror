;; Generated package description from shellcop.el  -*- no-byte-compile: t -*-
(define-package "shellcop" "0.0.9" "Analyze info&error in shell-mode" '((emacs "25.1")) :commit "327f5ac43e5d543149a772aef06cdb616477eb43" :authors '(("Chen Bin" . "chenbin.sh@gmail.com")) :maintainer '("Chen Bin" . "chenbin.sh@gmail.com") :keywords '("unix" "tools") :url "https://github.com/redguardtoo/shellcop")
