;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.28" "A major mode for editing subtitles" '((emacs "25.1")) :commit "ba0e4635eec59ad5408d1e913b0daafe4c42b1cd" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
