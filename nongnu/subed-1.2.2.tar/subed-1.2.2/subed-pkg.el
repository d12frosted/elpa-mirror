;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.2.2" "A major mode for editing subtitles" '((emacs "25.1")) :commit "260620850615f694d946415f12801c78237e2205" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
