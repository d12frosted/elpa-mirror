;; Generated package description from subatomic-theme.el  -*- no-byte-compile: t -*-
(define-package "subatomic-theme" "1.8.1" "Low contrast bluish color theme" 'nil :authors '(("John Olsson" . "john@cryon.se")) :maintainer '("John Olsson" . "john@cryon.se") :keywords '("color-theme" "blue" "low contrast") :url "https://github.com/cryon/subatomic")
