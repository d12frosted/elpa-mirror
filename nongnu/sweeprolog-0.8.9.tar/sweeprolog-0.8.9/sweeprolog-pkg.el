;; Generated package description from sweeprolog.el  -*- no-byte-compile: t -*-
(define-package "sweeprolog" "0.8.9" "Embedded SWI-Prolog" '((emacs "28.1")) :commit "7dfb85c88f1ba0360b66a4cb83f2812f3bb0d28c" :authors '(("Eshel Yaron" . "me@eshelyaron.com")) :maintainer '("Eshel Yaron" . "~eshel/dev@lists.sr.ht") :keywords '("prolog" "languages" "extensions") :url "https://git.sr.ht/~eshel/sweep")
