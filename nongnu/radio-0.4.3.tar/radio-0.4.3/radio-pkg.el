;; Generated package description from radio.el  -*- mode: lisp-data; no-byte-compile: t -*-
(define-package "radio" "0.4.3" "Listen to Internet radio" '((emacs "29.1")) :commit "da47fd36af0309f3d782dd49559ae77b234896d2" :authors '(("Roi Martin" . "jroi.martin@gmail.com")) :maintainer '("Roi Martin" . "jroi.martin@gmail.com") :keywords '("multimedia") :url "https://github.com/jroimartin/radio")
