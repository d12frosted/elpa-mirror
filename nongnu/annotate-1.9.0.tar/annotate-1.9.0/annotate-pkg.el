;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.9.0" "annotate files without changing them" 'nil :commit "44349cef8bd8383ff7955c66c3b2f5492b3b8914" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
