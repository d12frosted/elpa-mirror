;; Generated package description from javelin.el  -*- mode: lisp-data; no-byte-compile: t -*-
(define-package "javelin" "0.2.3" "Implementation of harpoon: bookmarks on steroids" '((emacs "28.1")) :commit "e58733d6dfb3282d5b6ad4d295e8c71a8e5abc71" :keywords '("tools" "languages") :url "https://github.com/DamianB-BitFlipper/javelin.el")
