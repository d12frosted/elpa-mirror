;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.8.2" "annotate files without changing them" 'nil :commit "02bc30d041934ce8d6092a7f80325e6e4a875f95" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
