;; Generated package description from flx-ido.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "flx-ido" "0.6.3" "flx integration for ido" '((emacs "24.1") (flx "0.1") (cl-lib "0.3")) :commit "dc6e4cec66ab05d536ec2cc6f5f324c019e8f8c0" :url "https://github.com/lewang/flx")
