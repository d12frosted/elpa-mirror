;; Generated package description from helm-core.el  -*- no-byte-compile: t -*-
(define-package "helm-core" "3.9.3" "Development files for Helm" '((emacs "25.1") (async "1.9.7")) :commit "e347a2c98438e2dbb5b1f681729f00c0e816ffc6" :authors '(("Thierry Volpiatto" . "thievol@posteo.net")) :maintainer '("Thierry Volpiatto" . "thievol@posteo.net") :url "https://emacs-helm.github.io/helm/")
