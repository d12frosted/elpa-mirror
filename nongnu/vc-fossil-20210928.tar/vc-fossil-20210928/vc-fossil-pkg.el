;; Generated package description from vc-fossil.el  -*- no-byte-compile: t -*-
(define-package "vc-fossil" "20210928" "VC backend for the fossil sofware configuraiton management system" 'nil :url "https://elpa.nongnu.org/nongnu/vc-fossil.html" :authors '(("Venkat Iyer" . "venkat@comit.com")) :maintainer '("Alfred M. Szmidt" . "ams@gnu.org"))
