;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.5.3" "annotate files without changing them" 'nil :commit "e694b977cc82887ce722912a2634ae4b0bc4f5ea" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
