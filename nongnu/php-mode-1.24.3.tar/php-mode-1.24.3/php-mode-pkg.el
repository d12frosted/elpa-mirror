;; Generated package description from php-mode.el  -*- no-byte-compile: t -*-
(define-package "php-mode" "1.24.3" "Major mode for editing PHP code" '((emacs "25.2")) :commit "bed4d8ced39ecbfd6ac4961d88cb1ba9ddbaa939" :authors '(("Eric James Michael Ritz")) :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
