;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.2" "A major mode for editing subtitles" '((emacs "25.1")) :commit "9a660ed88600e9aff741051c28a9e638cd5df5f5" :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/rndusr/subed")
