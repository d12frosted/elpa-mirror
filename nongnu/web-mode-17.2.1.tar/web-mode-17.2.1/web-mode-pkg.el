;; Generated package description from web-mode.el  -*- no-byte-compile: t -*-
(define-package "web-mode" "17.2.1" "major mode for editing web templates" '((emacs "23.1")) :commit "036da1327e3ec0749868d078cbc64e207f4c4aba" :authors '(("François-Xavier Bois")) :maintainer '("François-Xavier Bois" . "fxbois@gmail.com") :keywords '("languages") :url "https://web-mode.org")
