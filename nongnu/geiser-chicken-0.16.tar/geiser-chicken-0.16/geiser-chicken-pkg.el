;; Generated package description from geiser-chicken.el  -*- no-byte-compile: t -*-
(define-package "geiser-chicken" "0.16" "Chicken's implementation of the geiser protocols" '((emacs "24.4") (geiser "0.16")) :keywords '("languages" "chicken" "scheme" "geiser") :authors '(("Daniel Leslie")) :maintainer '("Daniel Leslie") :url "https://gitlab.com/emacs-geiser/chicken")
