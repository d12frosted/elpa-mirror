;; Generated package description from evil-visualstar.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "evil-visualstar" "0.2.1" "Starts a * or # search from the visual selection" '((emacs "24.4") (evil "0")) :commit "e9f043361c4fd0ab6b7e7a52801c39f05c1e52c3" :keywords '("evil" "vim" "visualstar") :url "https://github.com/bling/evil-visualstar")
