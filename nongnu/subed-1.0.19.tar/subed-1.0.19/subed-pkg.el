;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.19" "A major mode for editing subtitles" '((emacs "25.1")) :commit "573a137e45feeef001d8ddafc71b5b35b28db3f5" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
