;; Generated package description from flymake-kondor.el  -*- no-byte-compile: t -*-
(define-package "flymake-kondor" "0.1.0" "Linter with clj-kondo" '((emacs "26.1")) :authors '(("https://turbocafe.keybase.pub")) :maintainer '("https://turbocafe.keybase.pub") :url "https://github.com/turbo-cafe/flymake-kondor")
