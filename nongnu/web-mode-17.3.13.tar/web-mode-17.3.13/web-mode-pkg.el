;; Generated package description from web-mode.el  -*- no-byte-compile: t -*-
(define-package "web-mode" "17.3.13" "major mode for editing web templates" '((emacs "23.1")) :commit "90502d9cd2b5bc9a13d2628e48fd66b78243e090" :maintainer '("François-Xavier Bois" . "fxbois@gmail.com") :keywords '("languages") :url "https://web-mode.org")
