;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.3.1" "A major mode for editing subtitles" '((emacs "25.1")) :commit "0e4ed5d14af146da619d8cb6e5a8e1b5bbae168d" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
