;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.7.0" "annotate files without changing them" 'nil :commit "9bfa065a4e14f7e96c8ac487c4e54b084a02133c" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
