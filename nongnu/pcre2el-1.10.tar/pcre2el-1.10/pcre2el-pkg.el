;; Generated package description from pcre2el.el  -*- no-byte-compile: t -*-
(define-package "pcre2el" "1.10" "regexp syntax converter" '((emacs "25.1")) :commit "87622b7c7acf0674dc51014f580c1ab58c74f12a" :authors '(("joddie <jonxfield at gmail.com>")) :maintainer '("joddie <jonxfield at gmail.com>") :url "https://github.com/joddie/pcre2el")
