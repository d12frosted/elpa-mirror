;; Generated package description from opam-switch-mode.el  -*- no-byte-compile: t -*-
(define-package "opam-switch-mode" "1.1" "Select OCaml opam switches via a menu" '((emacs "25.1")) :commit "07a3742449b6572a842de045135e17c0e9993943" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://github.com/ProofGeneral/opam-switch-mode")
