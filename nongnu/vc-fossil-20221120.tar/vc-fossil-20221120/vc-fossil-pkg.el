;; Generated package description from vc-fossil.el  -*- no-byte-compile: t -*-
(define-package "vc-fossil" "20221120" "VC backend for the fossil sofware configuraiton management system" 'nil :commit "e059ca466cc8914757c6bdb26fa9cc6b0820a9c1" :url "https://elpa.nongnu.org/nongnu/vc-fossil.html" :authors '(("Venkat Iyer" . "venkat@comit.com")) :maintainer '("Alfred M. Szmidt" . "ams@gnu.org"))
