;; Generated package description from vc-fossil.el  -*- no-byte-compile: t -*-
(define-package "vc-fossil" "20220707" "VC backend for the fossil sofware configuraiton management system" 'nil :commit "8ce6113aa272583130e5f929fefd67115c8f572a" :url "https://elpa.nongnu.org/nongnu/vc-fossil.html" :authors '(("Venkat Iyer" . "venkat@comit.com")) :maintainer '("Alfred M. Szmidt" . "ams@gnu.org"))
