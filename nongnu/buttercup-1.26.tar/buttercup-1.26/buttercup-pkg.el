;; Generated package description from buttercup.el  -*- no-byte-compile: t -*-
(define-package "buttercup" "1.26" "Behavior-Driven Emacs Lisp Testing" '((emacs "24.3")) :commit "9022546ebf2f492e9f3ce92e02ed893bcecab027" :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de")) :maintainer '("Ola Nilsson" . "ola.nilsson@gmail.com") :url "https://github.com/jorgenschaefer/emacs-buttercup")
