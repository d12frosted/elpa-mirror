;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.7" "A major mode for editing subtitles" '((emacs "25.1")) :commit "eefe94f308d7006a498b17fc9acf01790b793bcd" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
