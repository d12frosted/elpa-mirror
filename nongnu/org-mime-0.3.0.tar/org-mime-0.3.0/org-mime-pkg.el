;; Generated package description from org-mime.el  -*- no-byte-compile: t -*-
(define-package "org-mime" "0.3.0" "org html export for text/html MIME emails" '((emacs "25.1")) :commit "2eede712acc51aaf495984ec457431dbb520038c" :authors '(("Eric Schulte")) :maintainer '("Chen Bin (redguardtoo)") :keywords '("mime" "mail" "email" "html") :url "http://github.com/org-mime/org-mime")
