;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "2.0.0" "annotate files without changing them" 'nil :commit "b8c929994048ed98c2a4fe6510365ece90dad8ec" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
