;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.2.3" "A major mode for editing subtitles" '((emacs "25.1")) :commit "6ce7de37f21e123467ef1191db7a37cd99881c00" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
