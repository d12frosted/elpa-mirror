;; Generated package description from elpher.el  -*- no-byte-compile: t -*-
(define-package "elpher" "3.3.3" "A friendly gopher and gemini client" '((emacs "27.1")) :commit "ab75cffa4572115c3d6b17348b6bfa2f746f4798" :authors '(("Tim Vaughan" . "plugd@thelambdalab.xyz")) :maintainer '("Tim Vaughan" . "plugd@thelambdalab.xyz") :keywords '("comm" "gopher") :url "https://thelambdalab.xyz/elpher")
