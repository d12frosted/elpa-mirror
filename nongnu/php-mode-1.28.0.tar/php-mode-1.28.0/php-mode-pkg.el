;; Generated package description from php-mode.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.28.0" "Major mode for editing PHP code" '((emacs "28.1")) :commit "e31073a5030932da37a72df9b8a5be017189d450" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
