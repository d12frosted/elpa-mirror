;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.22" "A major mode for editing subtitles" '((emacs "25.1")) :commit "a1c61d7d4d303dcc6fe7b7dbd20264cda146b639" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
