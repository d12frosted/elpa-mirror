;; Generated package description from swsw.el  -*- no-byte-compile: t -*-
(define-package "swsw" "2.1.1" "Simple window switching" '((emacs "27.1")) :commit "bbe31e347c794df2753f67520060182745c8f19f" :authors '(("Daniel Semyonov" . "daniel@dsemy.com")) :maintainer '("swsw Mailing List" . "~dsemy/swsw-devel@lists.sr.ht") :keywords '("convenience") :url "https://dsemy.com/projects/swsw")
