;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "2.4.3" "annotate files without changing them" '((emacs "27.1")) :commit "d9acbd91615c2cd3d919b06584ff6825726e3209" :maintainer '(("Bastian Bechtold" . "bastibe.dev@mailbox.org") ("cage" . "cage-dev@twistfold.it")) :url "https://github.com/bastibe/annotate.el")
