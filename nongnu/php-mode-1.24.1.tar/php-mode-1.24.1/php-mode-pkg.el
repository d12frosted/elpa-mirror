;; Generated package description from php-mode.el  -*- no-byte-compile: t -*-
(define-package "php-mode" "1.24.1" "Major mode for editing PHP code" '((emacs "25.2")) :commit "ae3b0b184e096b8bd916516ae7db908dbb27ec1e" :authors '(("Eric James Michael Ritz")) :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
