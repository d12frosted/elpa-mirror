;; Generated package description from evil-numbers.el  -*- no-byte-compile: t -*-
(define-package "evil-numbers" "0.6" "Increment/decrement numbers like in VIM" '((emacs "24.1") (evil "1.2.0")) :authors '(("Michael Markert" . "markert.michael@googlemail.com")) :maintainer '("Julia Path" . "julia@jpath.de") :keywords '("convenience" "tools") :url "http://github.com/juliapath/evil-numbers")
