``master`` (unreleased)
=======================


37.0 (2026-07-18)
=================

- Drop support for Emacs 27; Flycheck now requires Emacs 28.1 or newer.
- The ``dockerfile-hadolint`` checker now parses hadolint's SARIF output
  (``--format sarif``) via ``flycheck-parse-sarif`` instead of matching
  its text output with error patterns, so it no longer breaks when
  hadolint tweaks its human-readable format.
- ``flycheck-parse-sarif`` now treats a zero-width SARIF region (where
  the start and end positions coincide, as some tools emit for
  line-level findings) as spanning the whole line, instead of producing
  an empty highlight.
- Add ``flycheck-parse-sarif``, a ready-made ``:error-parser`` for the
  SARIF output format that many analyzers can emit.  Like the existing
  ``flycheck-parse-checkstyle``, checker definitions can point
  ``:error-parser`` at it instead of matching output text with
  ``:error-patterns``.
- [#1129]: ``javascript-eslint`` no longer probes for a configuration
  file with a blocking ``--print-config`` call before the first check in
  every buffer, which used to freeze Emacs for its duration (the
  interactive ``flycheck-verify-setup`` still probes).  A fatal eslint
  failure (a missing or broken configuration) is now diagnosed from the
  check's own exit status: the checker disables itself in the buffer
  with an echo-area notice naming the reason, and a fallback checker
  takes over on the next automatic check.  Checker authors can use the
  same mechanism by returning ``disable`` or ``(disable . reason)`` from
  ``:handle-suspicious``.
- A new syntax check now interrupts a still-running one and starts
  immediately, instead of waiting for it to finish and displaying its
  stale results in the meantime.  This makes slow checkers (cargo, mypy
  and friends) feel much more responsive.  The new option
  ``flycheck-interrupt-running-checks`` controls this: with the default
  value of ``10``, only checks younger than ten seconds are interrupted,
  so long-running checks still complete and publish their results
  instead of being restarted forever; ``t`` always interrupts and
  ``nil`` (also usable file- or directory-locally) restores the old
  queueing behavior.  Checks triggered on every keystroke (the
  ``new-line`` condition) always coalesce behind a running check, and
  checkers without an ``:interrupt`` function are never interrupted.
  Interactive checks (``C-c ! c``) now also restart a running check
  instead of doing nothing, without the age limit; Lisp calls to
  ``flycheck-buffer`` keep the old do-nothing-while-running behavior.
- The error list pops up in a bottom side window by default, a quarter of
  the frame tall.  Customize the new option
  ``flycheck-error-list-display-buffer-action`` to change that;
  ``display-buffer-alist`` entries still take precedence.  Note that side
  windows are unaffected by ``C-x 1``; dismiss the list with ``q``.
- The error list can now also be filtered by syntax checker (``c``) and
  by a regexp matching the error message or ID (``/``), in addition to
  the existing minimum-level filter (``f``); ``F`` resets all filters.
- The File and ID columns of the error list adapt their width to the
  errors on display instead of truncating at fixed widths.
- Errors at point are now documented through Eldoc by default, composing
  with other Eldoc sources (e.g. Eglot) and honoring Eldoc display
  customizations.  The previous behavior remains available by setting
  ``flycheck-display-errors-function`` to
  ``flycheck-display-error-messages``; custom display functions and
  extensions like flycheck-posframe keep working unchanged.
- The error counts in the mode line are clickable: ``mouse-1`` pops up
  the error list.
- ``flycheck-verify-setup`` and ``flycheck-verify-checker`` now ask
  before saving a modified buffer instead of saving it silently.
- [#1787]: Add the ``:handle-suspicious`` property to command checkers.
  It lets a checker translate a "suspicious state" (a non-zero exit
  status with no parsable errors, e.g. a missing dependency) into
  regular errors shown in the buffer, instead of the generic
  suspicious-state warning.
- Syntax checkers that exceed ``flycheck-checker-error-threshold`` are no
  longer silently disabled.  Flycheck now shows the most severe errors up
  to the threshold and signals the truncation in the mode line (e.g.
  ``FlyC:400|12|3+``) and the error list.  Set the new option
  ``flycheck-checker-error-threshold-action`` to ``disable`` to get the
  old behavior, minus the ``*Warnings*`` popup: the notification is now a
  plain echo-area message that says how to re-enable the checker.  Note
  that with the new default, level-conditioned ``:next-checkers`` see the
  kept errors and behave as they would in any buffer with that many real
  errors; previously they ran unconditionally because the whole result
  was discarded.
- ``flycheck-indication-mode`` defaults to the new value ``auto``, which
  picks the left fringe on graphical displays and the left margin on text
  terminals.  Previously the default was ``left-fringe``, which silently
  displayed nothing in terminal Emacs.  When the chosen margin isn't
  visible, Flycheck now widens it automatically and restores it when the
  mode is disabled.  ``flycheck-set-indication-mode`` no longer overrides
  fringe and margin widths configured by you or other packages.
- [#2161]: Fix the ``org-lint`` checker erroring out on Emacs 31, where
  ``org-lint`` reports line numbers as strings.
- [#2174]: Fix the ``haskell-ghc`` and ``haskell-stack-ghc`` checkers
  passing a broken ``-x`` flag in ``haskell-ts-mode``.
- [#2177]: Avoid ``\N{...}`` character escapes, which break native
  compilation on Emacs 32.
- [#2175]: Compose the error indicator with pre-existing ``wrap-prefix``
  text properties (e.g. from ``visual-wrap-prefix-mode``), so error
  overlays no longer reset the indentation of soft-wrapped lines.
- [#2164]: Recognize unresolved-identifier errors in the
  ``scheme-chicken`` checker.
- [#1946]: Fix ``flycheck-lintr-linters`` being ignored by recent lintr
  versions, which require linters to be passed as a named argument.
- Add ``asciidoc-mode`` support to the ``asciidoctor`` and ``textlint``
  checkers, alongside the existing ``adoc-mode``.
- Add ``neocaml-opam-mode`` support to the ``opam`` checker.
- [#2169]: Parse the severity-tagged output format introduced by Ruff 0.15.7
  in preview mode (e.g. ``error[F401]`` instead of ``F401``).
- [#2166]: Fix ``awk-gawk`` reporting a suspicious checker state for valid
  scripts.
- [#2163]: Disable native compilation in the ``emacs-lisp`` checker subprocess
  so it no longer writes stray ``.eln`` files to the native-comp cache.
- [#2170]: Force English checker output with ``LC_MESSAGES=C`` instead of
  ``LC_ALL=C``, so the character encoding is left untouched.  ``LC_ALL=C``
  broke checkers reading UTF-8 input, such as ``hledger``.
- [#2159]: Properly mitigate CVE-2024-53920 in the ``emacs-lisp`` checker
  by requiring files to be marked as trusted (via ``trusted-content``) on
  Emacs 30+.  Byte-compilation triggers macro expansion which can execute
  arbitrary code, so the checker is now disabled for untrusted files.
  ``emacs-lisp-checkdoc`` doesn't expand macros and stays enabled.

36.0 (2026-02-19)
======================

------------
New Features
------------

- [#2047]: Add ``javascript-oxlint`` checker for JavaScript and TypeScript
  using `oxlint <https://oxc.rs/>`_.
- [#1757]: Add ``org-lint`` checker for Org mode files.
  The checker uses Emacs' built-in ``org-lint`` command to detect issues such
  as invalid links, dead links, and duplicate IDs.
- [#2132]: Add the ``flycheck-shellcheck-infer-shell`` option to the
  ``sh-shellcheck`` checker.
- [#1977]: Add ``flycheck-shellcheck-args`` for passing extra command-line
  arguments to ShellCheck.
- [#1854]: Add ``flycheck-shellcheck-enabled-checks`` option to enable
  optional ShellCheck checks via the ``--enable`` flag.
- [#2139]: Add compatibility with Proselint 0.16.
- [#1574]: Enable ``proselint`` checker for reStructuredText mode and chain
  it after the ``rst`` and ``rst-sphinx`` checkers.
- [#1874]: Add ``flycheck-error-list-after-jump-hook``, run after jumping
  from the error list to an error location.
- [#2137]: Allow ``flycheck-command-map`` to be used as a prefix command
  with ``keymap-set`` and similar functions.
- [#1833]: Automatically re-check the buffer after ``revert-buffer``
  (e.g. when using ``global-auto-revert-mode``).
- [#1134]: Add error explainer for the ``python-ruff`` checker.
- [#1979]: Show pyright rule names (e.g. ``reportGeneralTypeIssues``) as
  error IDs.
- [#2134]: Include info-level errors in the mode-line indicator
  (format: ``errors|warnings|infos``).

-----------
Bugs fixed
-----------

- [#2131]: Mitigate CVE-2024-53920 in the ``emacs-lisp`` checker subprocess
  by disabling local eval directives and restricting local variables to safe
  values during byte-compilation.
- [#2144]: Rewrite ``org-lint`` checker to run in the current Emacs process
  instead of a ``-Q --batch`` subprocess.  This eliminates false "Unknown
  source block language" warnings for languages from external packages.
- [#2043]: Fix ``rust`` checker temp directory error by using
  ``--emit=metadata --out-dir`` instead of ``--emit=mir -o /dev/null``.
  Also fixes the checker on Windows where ``/dev/null`` does not exist.
- [#1859]: Force C locale (``LC_ALL=C``) for checker processes to ensure
  English output.  Fixes error pattern matching in non-English locales.
- [#1919]: Isolate bidi characters in error message snippets using Unicode
  directional isolates to prevent formatting corruption.
- [#1856]: Strictly enforce ``flycheck-navigation-minimum-level``.
  Previously, setting the minimum level would still navigate to lower-severity
  errors when no errors at the minimum level existed.
- [#1918]: Exclude the ``*Flycheck error messages*`` buffer from
  ``global-flycheck-mode``.
- [#1908]: Increase error list File column width from 6 to 12 characters.
- [#1882]: Fix Go build tags to use comma-separated format instead of
  repeated ``-tags`` flags.
- [#2098]: Fix ``tex-chktex`` error parsing with ``--inputfiles``.
- [#2143]: Fix compilation warnings on Emacs 30 (obsolete ``rx-constituents``
  and missing ``defcustom`` type spec).
- [#2089]: Make ``flycheck-protoc-import-path`` buffer-local so different
  protobuf projects can have different import paths.
- [#2032]: Guard Tools menu operations for Emacs configurations that remove
  the Tools menu (e.g. Doom Emacs).
- [#1805]: Preserve match data in idle trigger timer handler.
- [#1170]: Skip error list highlighting when the error list buffer is not
  visible, improving performance on every ``post-command-hook``.
- [#1153]: Handle ``puppet-parser`` errors without line numbers (e.g.
  "Syntax error at end of file").
- [#1886]: Fix continuation indicator appearing on non-wrapped lines by
  using ``wrap-prefix`` instead of ``line-prefix``.
- [#2062]: Fall back to ``python`` executable when ``python3`` is unavailable
  (e.g. Windows with Anaconda/Miniforge).
- [#2127]: Preserve pre-existing ``line-prefix`` text properties
  (e.g. from ``org-indent-mode``) when adding flycheck overlays.
- [#2086]: Fix the name of the PyMarkdown config.
- [#2036]: Fix ``awk-gawk`` checker passing spurious quotes to
  ``gawk --source``.
- [#2092]: Detect parse errors (unbalanced parentheses, invalid read syntax)
  in ``emacs-lisp`` byte compilation.
- [#2090]: Fix ``python-ruff`` checker to use ``concise`` output format instead
  of removed ``text`` format (renamed in ruff 0.2).
- Fix ``python-ruff`` error ID regex and ``invalid-syntax`` error handling.
- Fix ``rpm-rpmlint`` error filter returning unfiltered errors (the
  ``(none)`` filename filter was not applied).
- Add ``php-ts-mode`` to the ``php-phpcs-changed`` checker.
- [#1926]: Fix ``flycheck-cuda-gencodes`` customize type (was ``file``, now
  ``string``).
- Guard ``buffer-file-name`` against nil in ``yaml-actionlint`` predicate,
  ``erlang`` enabled check, and ``flycheck-rebar3-project-root``.
- Fix ``python-pycompile`` to verify ``python3`` actually works instead of
  just checking it exists.
- Fix proselint version detection breaking checker validation.

-------
Removed
-------

- Remove ``typescript-tslint`` checker.  TSLint has been deprecated since 2019
  in favor of `ESLint with typescript-eslint <https://typescript-eslint.io/>`_.
- Remove ``sass`` and ``scss`` checkers.  Ruby Sass reached end-of-life in
  March 2019.  Use ``sass-stylelint`` and ``scss-stylelint`` instead.
- Remove ``sass/scss-sass-lint`` checker.  sass-lint has been abandoned for
  over 4 years.  Use ``sass-stylelint`` or ``scss-stylelint`` instead.
- Remove ``scss-lint`` checker.  scss-lint depends on the dead Ruby Sass engine
  and is no longer maintained.  Use ``scss-stylelint`` instead.
- Remove ``eruby-erubis`` and ``eruby-ruumba`` checkers.  Erubis has been
  abandoned since 2011 and Ruumba since 2020.  ERuby support is removed.
- Remove ``css-csslint`` checker.  CSSLint has been abandoned since ~2017.
  Use ``css-stylelint`` instead.
- Remove ``protobuf-prototool`` checker.  Prototool was archived by Uber in
  March 2022.
- Remove ``nix-linter`` checker.  nix-linter has been abandoned by its author,
  who recommends `statix <https://github.com/nerdypepper/statix>`_ instead.
- Remove ``coffee-coffeelint`` checker.  CoffeeLint has been effectively
  inactive with known security vulnerabilities.
- Remove ``asciidoc`` checker.  The legacy Python AsciiDoc processor is
  superseded by Asciidoctor.  Use ``asciidoctor`` instead.
- Remove ``json-jsonlint`` checker.  The original jsonlint has been abandoned
  since ~2017.  Use ``json-python-json`` or ``json-jq`` instead.
- Remove ``xml-xmlstarlet`` checker.  XMLStarlet has not had a release since
  2014.  Use ``xml-xmllint`` instead.
- Remove ``javascript-jshint`` checker.  JSHint has been largely superseded
  by ESLint.  Use ``javascript-eslint`` instead.
- Remove ``yaml-ruby`` checker.  Ruby's YAML parser provides the same
  functionality as js-yaml.  Use ``yaml-jsyaml`` or ``yaml-yamllint`` instead.
- Remove ``ruby-jruby`` checker.  JRuby is extremely niche for linting.
  Use ``ruby-rubocop`` or ``ruby`` instead.

----------
Changes
----------

- Remove dead code: ``flycheck-option-symbol``,
  ``flycheck-flake8--find-project-root``, ``flycheck-string-or-nil-p``,
  ``flycheck-chunked-process-input`` and associated chunking functions.
- Replace deprecated ``seq-contains`` with ``seq-contains-p``.
- Replace ``flycheck-string-or-nil-p`` with built-in ``string-or-null-p``.
- Use ``json-parse-buffer`` unconditionally (available since Emacs 27.1),
  removing the ``json-read`` fallback and the ``json`` library dependency.
- Use ``libxml-available-p`` (available since Emacs 27.1) instead of
  ``fboundp`` check.
- Use ``seq-sort-by`` (available since Emacs 27.1) instead of workaround.
- Use ``seq-mapcat`` instead of ``(apply #'append (seq-map ...))``.
- Minor code style improvements: ``when (not ...)`` → ``unless``,
  ``reverse`` → ``nreverse`` for locally-built lists.
- [#2152]: Point package ``URL`` header to GitHub repository instead of
  the website.

35.0 (2025-04-23)
======================

------------
New Features
------------

- [#2105]: Add options for configuring the ``jsonnet`` checker.
- [#1975]: Add support for ``--expt-relaxed-constexpr`` flag to ``cuda`` checker.
- [#2055]: Add support for ``--expt-extended-lambda`` flag to ``cuda`` checker.
- [#1987]: Add a flag ``flycheck-auto-display-errors-after-checking`` control whether to display errors automatically after checking.
- [#2035]: Add colors to FlyC mode line and update mode line menu. Introduce ``flycheck-mode-success-indicator``.
- [#2059]: Enable checkers for new AUCTeX 14 modes.
- [#2070]: Add a new syntax checker ``r`` for R with the builtin ``parse`` function.
- [#2073]: Add new syntax checker ``salt-lint`` for the salt infrastructure-as-code language.
- [#2071]: Add a new checker ``perl-perlimports``, for cleaning up Perl import statements.
- [#1972]: New defcustom ``flycheck-clear-displayed-errors-function`` to
  customize how error messages are to be cleared.
- [#2075]: Add the ``flycheck-chktex-extra-flags`` option to the ``tex-chktex`` checker.
- [#2107]: Add ``-Xcompiler`` option for ``cuda-nvcc``.
- Add new ``markdownlint-cli2`` checker.

-----------
Bugs fixed
-----------

- [#2057]: Revert the replacement of ``flycheck-version`` with ``lm-version``.
- [#1972]: Refine flycheck-display-errors lifecycle so error messages can be cleared.
- [#2067]: Handle correctly GHC 9.6 error output format.
- [#2079]: Fix ruff ``error-patterns`` and ``error-filter``.

----------
Changes
----------

- **(Breaking)** [#2066]: Remove support for versions of ``stylelint`` older than v14.
- Update ``error-patterns`` for ghdl 4.1.0.
- [#2078]: ruff: ``--output-format=text`` replaced with ``--output-format=concise`` due to upstream changes in ruff.


34.1 (2024-02-18)
======================

-----------
Bugs fixed
-----------

- [#2054]: Remove explicit dep on the built-in package ``seq.el``.

34.0 (2024-02-14)
======================

------------
New Features
------------

- New syntax checkers

  - [#2015]: PHP with ``phpcs-changed``
  - [#2017]: HAML with ``haml-lint``
  - [#2030]: Add ``yaml-actionlint`` checker for GitHub yaml action workflows.
  - [#2052]: Sass with Stylelint
  - [#2013]: Nix with ``statix``
  - [#1935]: Chef (Ruby) with ``cookstyle``
  - [#1915]: Markdown with ``pymarkdown``

- [#1873]: Add error explainer to ``perl-perlcritic``.
- [#1875]: Add error-explainer to ``css-stylelint``.
- [#1876]: Add error-explainer for ``markdownlint checker``.
- [#2019]: Add support for RELAX NG schema in ``xmllint``.

----------
Bugs Fixed
----------

- [#1793]: Fix ``flycheck-ruby-rubocop`` on buffers with no backing file.

----------
Changes
----------

- [#2026]: Update the possible locations for ``yamllint``'s configuration file.
- **(Breaking)** [#1697]: Remove the ``coq`` checker.
- **(Breaking)** [#1935]: Remove the ``chef-foodcritic`` checker. (it's now replaced by ``ruby-chef-cookstyle``)
- **(Breaking)** [#2018]: Remove the ``golint`` checker.
- **(Breaking)** Remove the ``ruby-rubylint`` checker.
- [#1704]: The ``tslint`` checker is deprecated; it will go away in a future release.

----------------------

33.1 (2024-02-04)
======================

- Bugs Fixed

  - Fixed an usage of the removed ``flycheck--format-message`` function.

33.0 (2024-02-04)
======================

.. note:: The changelog for this release is incomplete.

- New features and improvements

  - The ``flycheck-verify-setup`` UI now includes buttons to re-enable manually
    disabled checkers and to try to re-enable automatically disabled checkers
    (command checkers are automatically disabled when their executable cannot be
    found). [GH-1755]
  - Error explainers can now return URLs (to show a webpage) or functions (to
    use custom formatting).  For example, the Rust checker now renders
    explanations using ``markdown-view-mode``. [GH-1753]
  - Enable checkers in many newer TreeSitter-based major modes (think ``*-ts-mode``).

- New syntax checkers

  - Python with ``ruff``. [GH-2033]

- **Breaking changes**

  - Drop support for Emacs 25.
  - The variable ``flycheck-current-errors`` now contains errors in the order in
    which they were returned by checkers.  In previous versions of Flycheck,
    this list was sorted by error position and severity. [GH-1749]

32 (frozen on May 3rd, 2020, released Mar 28, 2022)
===================================================

- Highlights

  - Many checkers and compiler, such as ``ocaml``, ``rust``, ``eslint``, and
    others, include end-line and end-column information.  Flycheck can now
    highlight the exact region that they report.  Authors of checker definitions
    can use the new ``:end-line`` and ``:end-column`` arguments in
    ``flycheck-error-new``, or the new ``end-line`` and ``end-column`` fields in
    error patterns. [GH-1400]

  - Errors that checkers return for other files will now be displayed on the
    first line of the current buffer instead of begin discarded.  The error list
    indicates which file each error came from, and navigation moves
    automatically moves between files.  This change helps with compiled
    languages, where an error in another file may cause the current file to be
    considered invalid.  Variables ``flycheck-relevant-error-other-file-show``
    and ``flycheck-relevant-error-other-file-minimum-level`` control this
    behavior. [GH-1427]

  - Flycheck can now draw error indicators in margins in addition to fringes.
    Margins can contain arbitrary characters and images, not just monochrome
    bitmaps, allowing for a better experience on high-DPI screens.
    ``flycheck-indication-mode`` controls this behavior, and
    ``flycheck-set-indication-mode`` can be used to automatically adjust the
    fringes and margins.  Additionally, Flycheck's will now use high-resolution
    fringe bitmaps if the fringe is wide enough [GH-1742, GH-1744]

  - Error highlighting is now configurable, using the new
    ``flycheck-highlighting-style`` variable: instead of applying
    level-dependent faces (typically with wavy underlines), Flycheck can now
    insert delimiters around errors, or mix styles depending on how many lines
    an error covers.  Additionally, stipples are added in the fringes to
    indicate errors that span multiple lines. [GH-1743]

- New features and improvements

  - Flycheck can now trigger a syntax check automatically after switching
    buffers, using the ``idle-buffer-switch`` option in
    ``flycheck-check-syntax-automatically``.  This is useful when errors in a
    file are due to problems in a separate file.  Variables
    ``flycheck-idle-buffer-switch-delay`` and
    ``flycheck-buffer-switch-check-intermediate-buffers`` control the
    functionality. [GH-1297]
  - Flycheck will now use Emacs' native XML parsing when libXML fails.  This
    behavior can be changed by customizing ``flycheck-xml-parser``. [GH-1349]
  - ``flycheck-verify-setup`` now shows more clearly which checkers
    will run in the buffer, and which are misconfigured. [GH-1478]
  - Flycheck now locates checker executables using a customizable function,
    ``flycheck-executable-find``.  The default value of this function allows
    relative paths (set e.g. in file or dir-local variables) in addition to
    absolute paths and executable names. [GH-1485]
  - Checkers that report error positions as a single offset from the start of
    the file can use the new ``flycheck-error-new-at-pos`` constructor instead
    of converting that position to a line and a column. [GH-1400]
  - Config-file variables can now be set to a list of file names.  This is
    useful for checkers like mypy which don't run correctly when called from a
    subdirectory without passing an explicit config file. [GH-1711]
  - Thanks to algorithmic improvements in error reporting, Flycheck is now much
    faster in large buffers. [GH-1750]

- New syntax checkers:

  - Awk with ``gawk`` [GH-1708]
  - Bazel with ``buildifier`` [GH-1613]
  - CUDA with ``cuda-nvcc`` [GH-1508]
  - CWL with ``schema-salad-tool`` [GH-1361]
  - Elixir with ``credo`` [GH-1062]
  - JSON with ``json-jq`` [GH-1568]
  - Jsonnet with ``jsonnet`` [GH-1345]
  - MarkdownLint CLI with ``markdownlint`` [GH-1366]
  - mypy with ``python-mypy`` [GH-1354]
  - Nix with ``nix-linter`` [GH-1530]
  - Opam with ``opam lint`` [GH-1532]
  - protobuf-prototool with ``prototool`` [GH-1591]
  - Rust with ``rust-clippy`` [GH-1385]
  - Ruumba with ``eruby-ruumba`` [GH-1616]
  - Staticcheck with ``go-staticcheck`` [GH-1541]
  - terraform with ``terraform fmt``, ``tflint`` [GH-1586]
  - Tcl with ``nagelfar`` [GH-1365]
  - Text prose with ``textlint`` [GH-1534]
  - VHDL with ``ghdl`` [GH-1160]

- Checker improvements:

  - ``python-pylint`` and ``python-flake8`` are now invoked with ``python -c``,
    to make it easier to change between Python 2 and Python 3. [GH-1113]
  - Add ``flycheck-perl-module-list`` to use specified modules when
    syntax checking code with the ``perl`` checker. [GH-1207]
  - ``rust-cargo`` now uses ``cargo check`` and ``cargo test``. [GH-1289]
  - Add ``flycheck-ghc-stack-project-file`` for the
    ``haskell-stack-ghc`` checker. [GH-1316]
  - Add ``flycheck-cppcheck-suppressions-file`` to pass a suppressions
    file to cppcheck. [GH-1329]
  - Add ``--force-exclusion`` flag to ``rubocop`` command. [GH-1348]
  - Flycheck now uses ESLint's JSON output instead of checkstyle XML. [GH-1350]
  - Add ``flycheck-eslint-args`` to pass arguments to ``javascript-eslint``.
    [GH-1360]
  - Flycheck will now execute ``rubocop`` from the directory where a ``Gemfile``
    is located. If a ``Gemfile`` does not exist, the old behaviour of running
    the command from the directory where ``.rubocop.yml`` is found will be
    used. [GH-1368]
  - Add ``flycheck-sh-bash-args`` to pass arguments to ``sh-bash``. [GH-1439]
  - ``haskell-stack-ghc`` will not try to install GHC anymore. [GH-1443]
  - Add ``flycheck-ghdl-ieee-library`` to select which standard IEEE
    library to use for ghdl. [GH-1547]
  - The ``javascript-eslint`` checker now supports ``typescript-mode`` by
    default.
  - Add ``flycheck-erlang-rebar3-profile`` to select which profile to
    use when compiling erlang with rebar3. [GH-1560]
  - Add ``flycheck-relevant-error-other-file-show`` to avoid showing errors
    from other files. [GH-1579]
  - The ``nix-linter`` checker now has an error explainer. [GH-1586]
  - The Emacs Lisp checker can now run in buffers not backed by files. [GH-1695]

- **Breaking changes**

  - Remove the ``javascript-jscs`` checker. [GH-1024]
  - Remove the ``elixir-dogma`` checker. [GH-1450]
  - ``rust-cargo`` now requires Rust 1.17 or newer. [GH-1289]
  - ``rust`` now requires 1.18 or newer. [GH-1501]
  - Rename ``flycheck-cargo-rustc-args`` to ``flycheck-cargo-check-args``.
    [GH-1289]
  - ``rust-cargo`` does not use the variable ``flycheck-rust-args`` anymore.
    [GH-1289]
  - Improve detection of default directory for ``haskell-ghc`` to consider
    ``hpack`` project files. [GH-1435]
  - Replace ``go tool vet`` with ``go vet``. [GH-1548]
  - Remove the deprecated ``go-megacheck`` checker, which is replaced by
    ``go-staticcheck``. [GH-1583]

31 (Oct 07, 2017)
=================

- **Breaking changes**

  - ``rust-cargo`` now requires Rust 1.15 or newer [GH-1201]
  - Remove javascript-gjslint checker

- New syntax checkers:

  - Protobuf with ``protoc`` [GH-1125]
  - systemd-analyze with ``systemd-analyze`` [GH-1135]
  - Nix with ``nix-instantiate`` [GH-1164]
  - Dockerfile with ``hadolint`` [GH-1194]
  - AsciiDoc with ``asciidoctor`` [GH-1167]
  - CSS/SCSS/LESS with ``stylelint`` [GH-903]
  - Ruby with ``reek`` [GH-1244]
  - Go with ``megacheck`` [GH-1290]
  - LLVM IR with ``llc`` [GH-1302]
  - Text prose with ``proselint`` [GH-1304]

- New features:

  - Add ``flycheck-xml-xmlstarlet-xsd-path`` and ``flycheck-xml-xmllint-xsd-path`` to
    specify an XSD schema to validate XML documents against [GH-1272]
  - Add ``flycheck-tslint-args`` to pass additional arguments to tslint [GH-1186]
  - Add an error explainer to the ``rpm-rpmlint`` checker using
    ``rpmlint -I`` [GH-1235]
  - Add ``flycheck-emacs-lisp-check-declare`` to check function declaration in
    the ``emacs-lisp`` checker [GH-1286]
  - Add ``flycheck-shellcheck-follow-sources`` to check included files when
    using the ``sh-shellcheck`` checker [GH-1256]

- Improvements:

  - Use option ``flycheck-go-build-tags`` for ``go-test``,
    ``go-vet`` and ``go-errcheck`` as well.
  - Add a revert function to ``flycheck-verify-setup``, so hitting
    ``g`` reloads the buffer.
  - Make sure the erlang compiler is only run on compilable files.
  - ``flycheck-tslint`` does not crash any more on deprecation notices [GH-1174]
  - ``rust-cargo`` now checks integration tests, examples and benchmarks
    [GH-1206]
  - ``rust-cargo`` does not use ``flycheck-rust-library-path`` anymore, as
    dependencies are taken care of by Cargo [GH-1206]
  - ``c/c++-gcc`` checker now works from GCC 4.4 and up [GH-1226]

30 (Oct 12, 2016)
=================

- **Breaking changes**

  - Flycheck now requires flake8 3.0 or newer
  - Remove ``--config`` option in ``lua-luacheck`` in favour of ``luacheck``'s
    own ``.luacheckrc`` detection. Therefore ``flycheck-luacheckrc`` is
    no longer used [GH-1057]
  - ``:modes`` is now mandatory for syntax checker definitions [GH-1071]
  - Remove jade checker [GH-951] [GH-1084]
  - Remove ``javascript-eslintrc`` and instead rely on eslint's own configuration file
    search [GH-1085]
  - ``C-c ! e`` explains errors now [GH-1122]

- New syntax checkers:

  - Elixir with ``dogma`` [GH-969]
  - sass and scss with ``sass-lint`` [GH-1070]
  - Pug [GH-951] [GH-1084]

- New features:

  - Add ``flycheck-cargo-rustc-args`` to pass multiple arguments to cargo rustc
    subcommand [GH-1079]
  - Add ``:error-explainer`` to ``flycheck-define-checker`` and
    ``flycheck-explain-error-at-point`` to display explanations of errors
    [GH-1122]
  - Add an error explainer to the ``rust`` and ``rust-cargo`` checkers using
    ``rustc --explain`` [GH-1122]
  - Add ``:enabled`` property to ``flycheck-define-checker`` [GH-1089]

- Improvements:

  - Do not use ``javascript-eslint`` if eslint cannot find a valid configuration
    [GH-1085]
  - Automatically disable syntax checkers which are not installed instead of
    checking executable before each syntax check [GH-1116]
  - Add patterns for syntax errors to ``scheme-chicken`` [GH-1123]

29 (Aug 28, 2016)
=================

- **Breaking changes**

  - Change ``flycheck-eslint-rulesdir`` (string) to
    ``flycheck-eslint-rules-directories`` (list of strings) [GH-1016]
  - Require rust 1.7 or newer for ``rust`` and ``rust-cargo`` [GH-1036]

- New syntax checkers:

  - Slim with ``slim-lint`` [GH-1013]
  - CHICKEN Scheme with ``csc`` [GH-987]

- New features:

  - Add ``:working-directory`` option to ``flycheck-define-command-checker``
    [GH-973] [GH-1012]
  - ``flycheck-go-build-install-deps`` turns on dependency installation for ``go test``
    as well as ``go build`` [GH-1003]

- Improvements:

  - Add default directory for ``haskell-stack-ghc`` and ``haskell-ghc`` checkers
    [GH-1007]
  - ``rust`` and ``rust-cargo`` checkers now support the new error format of
    rust 1.12 [GH-1016]
  - ``flycheck-verify-checker`` and ``flycheck-verify-setup`` now include
    information about configuration files of syntax checkers [GH-1021] [GH-1038]

28 (Jun 05, 2016)
=================

- **Breaking changes**:

  - Rename ``luacheck`` to ``lua-luacheck`` to comply with our naming
    conventions
  - Remove ``flycheck-cppcheck-language-standard`` in favour of
    ``flycheck-cppcheck-standards`` which is a list of standards [GH-960]

- New features:

  - Add option to set binary name for ``rust-cargo`` [GH-958]
  - Add ``flycheck-cppcheck-standards`` to pass multiple code standards to
    cppcheck [GH-960]
  - Add ``flycheck-cppcheck-suppressions`` to suppress warnings for cppcheck
    [GH-960]

- Improvements:

  - Check Racket syntax in Geiser Mode [GH-979]

- Bug fixes

  - Do not signal errors when tslint reports no output [GH-981]
  - Do not generate invalid temporary filenames on Windows [GH-983]

27 (May 08, 2016)
=================

- **Breaking changes**

  - Require PHP Code Sniffer 2.6 or newer for ``php-phpcs`` [GH-921]

- New syntax checkers:

  - Go with ``go-unconvert`` [GH-905]
  - Markdown with ``mdl`` [GH-839] [GH-916]
  - TypeScript with ``tslint`` [GH-947] [GH-949]

- Improvements:

  - Pass checkdoc settings from Emacs to `emacs-lisp-checkdoc` [GH-741] [GH-937]

- Bug fixes:

  - Fix parsing of syntax errors in triple-quoted strings for
    ``python-pycompile`` [GH-948]
  - Correctly handle rules based on the current file name in ``php-phpcs``
    [GH-921]

26 (Apr 27, 2016)
=================

Flycheck now has a `Code of Conduct`_ which defines the acceptable behaviour and
the moderation guidelines for the Flycheck community. [GH-819]

Flycheck also provides a `Gitter channel`_ now for questions and discussions
about development. [GH-820]

The native Texinfo manual is again replaced with a Sphinx_ based documentation.
We hope that this change makes the manual easier to edit and to maintain and
more welcoming for new contributors.  The downside is that we can not longer
include a Info manual in Flycheck’s MELPA packages.

From this release onward Flycheck will use a single continuously increasing
version number.  Breaking changes may occur at any point.

.. _Code of Conduct: https://www.flycheck.org/en/latest/community/conduct.html
.. _Gitter channel: https://gitter.im/flycheck/flycheck
.. _Sphinx: https://sphinx-doc.org

- **Breaking changes**:

  - Remove ``flycheck-copy-messages-as-kill``, obsolete since Flycheck
    0.22
  - Remove ``flycheck-perlcritic-verbosity``, obsolete since Flycheck
    0.22
  - Replace ``flycheck-completion-system`` with
    ``flycheck-completing-read-function`` [GH-870]
  - JSON syntax checkers now require ``json-mode`` and do not check in
    Javascript Mode anymore
  - Prefer eslint over jshint for Javascript
  - Obsolete ``flycheck-info`` in favour of the new ``flycheck-manual`` command

- New syntax checkers:

  - Processing [GH-793] [GH-812]
  - Racket [GH-799] [GH-873]

- New features:

  - Add ``flycheck-puppet-lint-rc`` to customise the location of the
    puppetlint configuration file [GH-846]
  - Add ``flycheck-puppet-lint-disabled-checks`` to disable specific
    checks of puppetlint [GH-824]
  - New library ``flycheck-buttercup`` to support writing Buttercup_ specs for
    Flycheck
  - Add ``flycheck-perlcriticrc`` to set a configuration file for
    Perl::Critic [GH-851]
  - Add ``flycheck-jshint-extract-javascript`` to extract Javascript
    from HTML [GH-825]
  - Add ``flycheck-cppcheck-language-standard`` to set the language
    standard for cppcheck [GH-862]
  - Add ``flycheck-mode-line-prefix`` to customise the prefix of
    Flycheck’s mode line lighter [GH-879] [GH-880]
  - Add ``flycheck-go-vet-shadow`` to check for shadowed variables
    with ``go vet`` [GH-765] [GH-897]
  - Add ``flycheck-ghc-stack-use-nix`` to enable Nix support for Stack GHC
    [GH-913]

- Improvements:

  - Map error IDs from flake8-pep257 to Flycheck error levels
  - Explicitly display errors at point with ``C-c ! h`` [GH-834]
  - Merge message and checker columns in the error list to remove redundant
    ellipsis [GH-828]
  - Indicate disabled checkers in verification buffers [GH-749]
  - Do not enable Flycheck Mode in ``fundamental-mode`` buffers [GH-883]
  - Write ``go test`` output to a temporary files [GH-887]
  - Check whether ``lintr`` is actually installed [GH-911]

- Bug fixes:

  - Fix folding of C/C++ errors from included files [GH-783]
  - Fix verification of SCSS-Lint checkstyle reporter
  - Don’t fall back to ``rust`` if ``rust-cargo`` should be used [GH-817]
  - Don’t change current buffer when closing the error message buffer [GH-648]
  - Never display error message buffer in current window [GH-822]
  - Work around a caching issue in Rubocop [GH-844]
  - Fix checkdoc failure with some Emacs Lisp syntax [GH-833] [GH-845] [GH-898]
  - Correctly parse Haskell module name with exports right after the module name
    [GH-848]
  - Don’t hang when sending buffers to node.js processes on Windows
    [GH-794][GH-850]
  - Parse suggestions from ``hlint`` [GH-874]
  - Go errcheck handles multiple ``$GOPATH`` entries correctly now
    [GH-580][GH-906]
  - Properly handle Go build failing in a directory with multiple packages
    [GH-676] [GH-904]
  - Make cppcheck recognise C++ header files [GH-909]
  - Don’t run phpcs on empty buffers [GH-907]

.. _Buttercup: https://github.com/jorgenschaefer/emacs-buttercup
