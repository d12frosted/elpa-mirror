;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.14" "A major mode for editing subtitles" '((emacs "25.1")) :commit "74793f06532d15ea5e1008b5d227dab17ab8f27a" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
