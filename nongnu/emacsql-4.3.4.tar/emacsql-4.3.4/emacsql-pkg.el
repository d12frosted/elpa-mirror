;; Generated package description from emacsql.el  -*- no-byte-compile: t -*-
(define-package "emacsql" "4.3.4" "High-level SQL database front-end" '((emacs "26.1")) :commit "c6a9d2373cc15184e4e34414b8574a896d070323" :authors '(("Christopher Wellons" . "wellons@nullprogram.com")) :maintainer '("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev") :url "https://github.com/magit/emacsql")
