;; Generated package description from sweeprolog.el  -*- no-byte-compile: t -*-
(define-package "sweeprolog" "0.9.6" "Embedded SWI-Prolog" '((emacs "28.1")) :commit "52cfcd1884fdd54cad647023300428d033f1a5a6" :authors '(("Eshel Yaron" . "me@eshelyaron.com")) :maintainer '("Eshel Yaron" . "~eshel/dev@lists.sr.ht") :keywords '("prolog" "languages" "extensions") :url "https://git.sr.ht/~eshel/sweep")
