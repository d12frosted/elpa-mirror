;; Generated package description from pacmacs.el  -*- no-byte-compile: t -*-
(define-package "pacmacs" "0.1" "Pacman for Emacs" '((emacs "24.4") (dash "2.18.0") (cl-lib "0.5") (f "0.18.0")) :authors '(("Codingteam" . "codingteam@conference.jabber.ru")) :maintainer '("Alexey Kutepov" . "reximkut@gmail.com") :url "http://github.com/codingteam/pacmacs.el")
