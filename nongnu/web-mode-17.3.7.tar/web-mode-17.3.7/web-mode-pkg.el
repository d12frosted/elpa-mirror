;; Generated package description from web-mode.el  -*- no-byte-compile: t -*-
(define-package "web-mode" "17.3.7" "major mode for editing web templates" '((emacs "23.1")) :commit "18e4ef2061e12fc4cc96fdc2caf2760a85dec248" :authors '(("François-Xavier Bois")) :maintainer '("François-Xavier Bois" . "fxbois@gmail.com") :keywords '("languages") :url "https://web-mode.org")
