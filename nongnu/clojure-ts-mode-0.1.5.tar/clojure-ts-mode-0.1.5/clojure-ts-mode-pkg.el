;; Generated package description from clojure-ts-mode.el  -*- no-byte-compile: t -*-
(define-package "clojure-ts-mode" "0.1.5" "Major mode for Clojure code" '((emacs "29")) :commit "4e18177a568027b464ea794c166d2eb4ebe080fc" :maintainer '("Danny Freeman" . "danny@dfreeman.email") :keywords '("languages" "clojure" "clojurescript" "lisp") :url "http://github.com/clojure-emacs/clojure-ts-mode")
