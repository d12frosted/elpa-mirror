;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.0" "A major mode for editing subtitles" '((emacs "25.1")) :commit "cac3a94ae14afa1655cbd39a7128d8dc88e4fca6" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
