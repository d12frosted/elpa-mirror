;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.0.18" "A major mode for editing subtitles" '((emacs "25.1")) :commit "fcd2299f365eb37ced4a838bd39aaefd6c6ac576" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
