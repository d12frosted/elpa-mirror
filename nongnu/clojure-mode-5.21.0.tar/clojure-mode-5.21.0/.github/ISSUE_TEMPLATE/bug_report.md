---
name: Bug Report
about: Report an issue with clojure-mode you've discovered.
labels: [bug]
---

*Use the template below when reporting bugs. Please, make sure that
you're running the latest stable clojure-mode and that the problem you're reporting
hasn't been reported (and potentially fixed) already.*

**Please, remove all of the placeholder text (the one in italics) in your final report!**

## Expected behavior

## Actual behavior

## Steps to reproduce the problem

*This is extremely important! Providing us with a reliable way to reproduce
a problem will expedite its solution.*

## Environment & Version information

### clojure-mode version

*Include here the version string displayed by `M-x
clojure-mode-display-version`. Here's an example:*

```
clojure-mode (version 5.20.0)
```

### Emacs version

*E.g. 29.1* (use <kbd>C-h C-a</kbd> to see it)

### Operating system

*E.g. Windows 10*
