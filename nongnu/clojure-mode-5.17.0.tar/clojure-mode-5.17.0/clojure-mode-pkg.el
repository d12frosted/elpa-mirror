;; Generated package description from clojure-mode.el  -*- no-byte-compile: t -*-
(define-package "clojure-mode" "5.17.0" "Major mode for Clojure code" '((emacs "25.1")) :commit "5fab97d0efc1ed932518fba0cb90afe6dcd00191" :maintainer '("Bozhidar Batsov" . "bozhidar@batsov.dev") :keywords '("languages" "clojure" "clojurescript" "lisp") :url "https://github.com/clojure-emacs/clojure-mode")
