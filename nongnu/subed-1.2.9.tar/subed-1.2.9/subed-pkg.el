;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.2.9" "A major mode for editing subtitles" '((emacs "25.1")) :commit "0b4850030ad202bbced992e6fbe4489fd2ebdf77" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
