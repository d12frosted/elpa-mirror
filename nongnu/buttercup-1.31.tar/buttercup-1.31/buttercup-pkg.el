;; Generated package description from buttercup.el  -*- no-byte-compile: t -*-
(define-package "buttercup" "1.31" "Behavior-Driven Emacs Lisp Testing" '((emacs "24.3")) :commit "30c703d215b075aaede936a2c424f65b5f7b6391" :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de")) :maintainer '("Ola Nilsson" . "ola.nilsson@gmail.com") :url "https://github.com/jorgenschaefer/emacs-buttercup")
