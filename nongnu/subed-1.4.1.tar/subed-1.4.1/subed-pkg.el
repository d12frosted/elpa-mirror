;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.4.1" "A major mode for editing subtitles" '((emacs "25.1")) :commit "88a64355523a3bc65790afc7fe6e852183df6df4" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
