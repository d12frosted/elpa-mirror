;; Generated package description from swift-mode.el  -*- no-byte-compile: t -*-
(define-package "swift-mode" "8.4.1" "Major-mode for Apple's Swift programming language" '((emacs "24.4") (seq "2.3")) :keywords '("languages" "swift") :url "https://github.com/swift-emacs/swift-mode")
