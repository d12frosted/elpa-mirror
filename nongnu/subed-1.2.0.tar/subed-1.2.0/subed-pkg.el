;; Generated package description from subed.el  -*- no-byte-compile: t -*-
(define-package "subed" "1.2.0" "A major mode for editing subtitles" '((emacs "25.1")) :commit "089d9f33db9e34512352b1344627cdb20b967409" :authors '(("Random User")) :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
