;; Generated package description from php-mode.el  -*- no-byte-compile: t -*-
(define-package "php-mode" "1.25.0" "Major mode for editing PHP code" '((emacs "26.1")) :commit "28d0a0bc81a8481fd75e5a6477dda394fe04fef3" :authors '(("Eric James Michael Ritz")) :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
