;; Generated package description from clojure-mode.el  -*- no-byte-compile: t -*-
(define-package "clojure-mode" "5.17.1" "Major mode for Clojure code" '((emacs "25.1")) :commit "661c80e3db9fa5990b39aa5277fb27a047c2546c" :maintainer '("Bozhidar Batsov" . "bozhidar@batsov.dev") :keywords '("languages" "clojure" "clojurescript" "lisp") :url "https://github.com/clojure-emacs/clojure-mode")
