;; Generated package description from annotate.el  -*- no-byte-compile: t -*-
(define-package "annotate" "1.5.2" "annotate files without changing them" 'nil :commit "96f1d610f27d00bafd32f5021f36bf6ff588e861" :authors '(("Bastian Bechtold")) :maintainer '("Bastian Bechtold co-maintainer: cage" . "cage-dev@twistfold.it") :url "https://github.com/bastibe/annotate.el")
