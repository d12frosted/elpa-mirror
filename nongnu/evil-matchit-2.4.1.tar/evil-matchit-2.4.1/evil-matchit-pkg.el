;; Generated package description from evil-matchit.el  -*- no-byte-compile: t -*-
(define-package "evil-matchit" "2.4.1" "Vim matchit ported to Evil" '((evil "1.14.0") (emacs "25.1")) :authors '(("Chen Bin <chenbin DOT sh AT gmail DOT com>")) :maintainer '("Chen Bin <chenbin DOT sh AT gmail DOT com>") :keywords '("matchit" "vim" "evil") :url "http://github.com/redguardtoo/evil-matchit")
