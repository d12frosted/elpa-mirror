;; Generated package description from flx.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "flx" "0.6.3" "fuzzy matching with good sorting" '((cl-lib "0.3")) :commit "dc6e4cec66ab05d536ec2cc6f5f324c019e8f8c0" :url "https://github.com/lewang/flx")
