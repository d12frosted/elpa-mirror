(define-package "org-plus-contrib"
  "20201212" "Outline-based notes management and organizer" ( ))
;; Local Variables:
;; no-byte-compile: t
;; End:
