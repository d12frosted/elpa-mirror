(define-package "org"
  "20210531" "Outline-based notes management and organizer" ( ))
;; Local Variables:
;; no-byte-compile: t
;; End:
