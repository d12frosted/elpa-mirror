;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260711.7"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "c917f01f1d208ae96683150a35e9bc1d4f56b93b"
  :revdesc "c917f01f1d20"
  :keywords '("languages" "lisp" "slime"))
