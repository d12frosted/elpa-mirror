;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdffontetc" "20260107.2304"
  "Display `pdffont' and other PDF information."
  '((emacs     "24.4")
    (pdf-tools "1.2.0"))
  :url "https://github.com/emacsomancer/pdffontetc"
  :commit "4adb8a339434f7c485dc38736c7c6461018876d4"
  :revdesc "4adb8a339434"
  :keywords '("files" "multimedia")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
