(define-package "cape" "20221223.1838" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "9b97dbbc7624415ee25f79de9ea357feb1e2e547" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
