(define-package "neil" "20231112.2006" "companion for Babashka Neil"
  '((emacs "27.1"))
  :commit "03cc51e546c2b1dd534cdc17160ffc5ff6e6e81d" :authors
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainer
  '("Ag Ibragimov" . "agzam.ibragimov@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/babashka/neil")
;; Local Variables:
;; no-byte-compile: t
;; End:
