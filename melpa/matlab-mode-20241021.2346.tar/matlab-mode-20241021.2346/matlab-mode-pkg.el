;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241021.2346"
  "Major mode for MATLAB(R) dot-m files."
  ()
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "6a15eb56babcf0c9fc5ce2fa48581d00600436fe"
  :revdesc "6a15eb56babc"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")))
