;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251111.1559"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "7e9a2439487f0a488e3f1670c913480b33863a31"
  :revdesc "7e9a2439487f"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
