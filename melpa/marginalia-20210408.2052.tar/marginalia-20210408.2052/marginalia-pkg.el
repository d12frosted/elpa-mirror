(define-package "marginalia" "20210408.2052" "Enrich existing commands with completion annotations"
  '((emacs "26.1"))
  :commit "06ae3b4c466801962b7611c851e62bf0c749fbbf" :authors
  '(("Omar Antolín Camarena, Daniel Mendler"))
  :maintainer
  '("Omar Antolín Camarena, Daniel Mendler")
  :url "https://github.com/minad/marginalia")
;; Local Variables:
;; no-byte-compile: t
;; End:
