(define-package "zig-ts-mode" "20240928.1140" "Tree Sitter support for Zig"
  '((emacs "29.1"))
  :commit "0c9868cefbe11ee9d04d461d44fe25982b5c2d68" :authors
  '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers
  '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainer
  '("meowking" . "mr.meowking@tutamail.com")
  :keywords
  '("zig" "languages" "tree-sitter")
  :url "https://codeberg.org/meow_king/zig-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
