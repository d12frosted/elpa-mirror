(define-package "cape" "20220819.1710" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "f360464007386b36952b4c3ba0a977f056d0ee19" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
