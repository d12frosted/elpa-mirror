(define-package "eldev" "20231115.1824" "Elisp development tool"
  '((emacs "24.4"))
  :commit "2aefc4d2820d922073917c7f87ea83c80c930ca6" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/emacs-eldev/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
