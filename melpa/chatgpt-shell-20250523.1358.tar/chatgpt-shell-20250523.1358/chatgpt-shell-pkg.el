;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250523.1358"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.77.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "dad8ba7cf5531098713d70e12c577a2a49c55ca2"
  :revdesc "dad8ba7cf553")
