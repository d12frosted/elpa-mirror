;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stan-ts-mode" "20260320.1505"
  "Major mode for editing Stan files."
  '((emacs "30.1"))
  :url "https://github.com/WardBrian/stan-ts-mode"
  :commit "8cc2b9680bf9f3fef7d740eb8115764510803f61"
  :revdesc "8cc2b9680bf9"
  :keywords '("stan" "languages" "tree-sitter")
  :authors '(("Brian Ward" . "bward@flatironinstitute.org"))
  :maintainers '(("Brian Ward" . "bward@flatironinstitute.org")))
