;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260414.734"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "27dcec0cbafa9fd66174bea8f03a58295657685c"
  :revdesc "27dcec0cbafa"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
