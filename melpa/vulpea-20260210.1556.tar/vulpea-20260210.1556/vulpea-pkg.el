;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260210.1556"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "60bfe3959a3a68f4957f83e33bf793d73a34f21b"
  :revdesc "60bfe3959a3a"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
