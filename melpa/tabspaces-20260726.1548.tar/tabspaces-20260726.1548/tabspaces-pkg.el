;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260726.1548"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "3af0f518ebfa78f8cbcd571b8fe0e5a678b811ae"
  :revdesc "3af0f518ebfa"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
