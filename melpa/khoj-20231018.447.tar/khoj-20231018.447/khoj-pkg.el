(define-package "khoj" "20231018.447" "AI copilot for your Second Brain"
  '((emacs "27.1")
    (transient "0.3.0")
    (dash "2.19.1"))
  :commit "51363d280d5eed92eb6bad9b5d5ca03a0b2db953" :authors
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
    ("Saba Imran" . "saba@khoj.dev"))
  :maintainers
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev"))
  :maintainer
  '("Debanjum Singh Solanky" . "debanjum@khoj.dev")
  :keywords
  '("search" "chat" "org-mode" "outlines" "markdown" "pdf" "image")
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
