(define-package "affe" "20220603.548" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.16"))
  :commit "0162da0aab3b30412eee5ebf68427361fc8fc26d" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
