(define-package "cape" "20221126.755" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "7d755a9571783d2ffb07f2b1cbfe4369f1418040" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
