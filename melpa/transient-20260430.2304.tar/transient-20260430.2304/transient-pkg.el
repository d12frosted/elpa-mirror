;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260430.2304"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "30.1")
    (cond-let "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "6dfe4bb767431c97575f199f2e29e59913605cf1"
  :revdesc "6dfe4bb76743"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
