(define-package "lentic" "20160110.1705" "One buffer as a view of another"
  '((emacs "24.4")
    (m-buffer "0.13")
    (dash "2.5.0")
    (f "0.17.2")
    (s "1.9.0"))
  :commit "8655ecd51e189bbdd6a4d8405dc3ea2e689c709a" :authors
  '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
  :maintainer
  '("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
;; Local Variables:
;; no-byte-compile: t
;; End:
