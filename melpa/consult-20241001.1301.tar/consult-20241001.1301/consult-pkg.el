;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20241001.1301"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "8f228cc1d48af9158c9ba71d2f20a9aaaf4daf7e"
  :revdesc "8f228cc1d48a"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
