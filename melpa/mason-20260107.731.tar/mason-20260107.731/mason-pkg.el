;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20260107.731"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/deirn/mason.el"
  :commit "03d950a67301f0436cbf16f22da434e2b4ab14a3"
  :revdesc "03d950a67301"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
