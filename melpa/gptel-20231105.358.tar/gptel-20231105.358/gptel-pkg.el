(define-package "gptel" "20231105.358" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "0192fa07f3f8d2d032b71acd1fae12755207dd76" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
