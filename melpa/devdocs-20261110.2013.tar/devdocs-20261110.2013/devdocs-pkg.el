;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devdocs" "20261110.2013"
  "Emacs viewer for DevDocs."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/astoff/devdocs.el"
  :commit "4b4fa0c97f7bddb1348319bf0fe152211465b189"
  :revdesc "4b4fa0c97f7b"
  :keywords '("help")
  :authors '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers '(("Augusto Stoffel" . "arstoffel@gmail.com")))
