;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260802.1816"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "5fc13f164592c9df6c846cce06874751ef6aad76"
  :revdesc "5fc13f164592"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
