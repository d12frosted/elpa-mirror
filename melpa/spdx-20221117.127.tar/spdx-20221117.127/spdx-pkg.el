(define-package "spdx" "20221117.127" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "9364053159df98809996f3dce622b192638e40ee" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
