;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dmenu" "20190908.44"
  "Simulate the dmenu command line program."
  '((cl-lib "0.5"))
  :url "https://github.com/lujun9972/el-dmenu"
  :commit "e8cc9b27c79d3ecc252267c082ab8e9c82eab264"
  :revdesc "e8cc9b27c79d"
  :keywords '("convenience" "usability")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
