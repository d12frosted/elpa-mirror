;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260825.2124"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "3a06f15a6599679232873e89e043a37ec19e2c5e"
  :revdesc "3a06f15a6599"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
