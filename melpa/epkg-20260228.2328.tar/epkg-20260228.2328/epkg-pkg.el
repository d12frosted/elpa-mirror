;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260228.2328"
  "Browse the Emacsmirror package database."
  '((emacs   "28.1")
    (compat  "30.1")
    (closql  "2.4")
    (emacsql "4.3")
    (llama   "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "ad4b9b6f65fed14a36f1c90d4078f171e4646dd6"
  :revdesc "ad4b9b6f65fe"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
