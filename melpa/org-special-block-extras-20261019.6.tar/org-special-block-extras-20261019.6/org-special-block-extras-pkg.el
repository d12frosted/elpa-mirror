;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20261019.6"
  "46 new custom blocks & 56 link types for Org-mode."
  '((s     "1.13.1")
    (dash  "2.18.1")
    (emacs "28.2")
    (org   "9.8")
    (lf    "26.10.1")
    (seq   "2.0"))
  :url "https://alhassy.com/org-special-block-extras"
  :commit "decc29865a4448e3c317b73e9abad3b9c3b0372c"
  :revdesc "decc29865a44"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
