;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "glue" "20230112.2159"
  "Emacs - Common Lisp interop using SLIME or SLY."
  '((emacs "24.1"))
  :url "https://git.sr.ht/~hajovonta/glue/"
  :commit "dcdf8a69db87acea4fa61d4b4b9b1265c7e025db"
  :revdesc "dcdf8a69db87"
  :keywords '("lisp" "emacs" "common" "lisp" "cl")
  :authors '(("Gabor Poczkodi" . "hajovonta@gmail.com"))
  :maintainers '(("Gabor Poczkodi" . "hajovonta@gmail.com")))
