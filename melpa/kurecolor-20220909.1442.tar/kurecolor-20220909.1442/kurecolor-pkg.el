(define-package "kurecolor" "20220909.1442" "color editing goodies"
  '((emacs "24.4")
    (s "1.12"))
  :commit "8af900180c888b3b6c2137d4e9457991e62bd6ae" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
