;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-vnu" "20230310.440"
  "Flymake extension for the v.Nu HTML validator."
  '((emacs "26.1"))
  :url "https://github.com/theneosloth/flymake-vnu"
  :commit "e9c6038f69ad1523e603026155d9acd5fc3d5aac"
  :revdesc "e9c6038f69ad"
  :keywords '("languages")
  :authors '(("Stefan Kuznetsov" . "skuznetsov@posteo.net"))
  :maintainers '(("Stefan Kuznetsov" . "skuznetsov@posteo.net")))
