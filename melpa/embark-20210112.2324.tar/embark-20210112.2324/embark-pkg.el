(define-package "embark" "20210112.2324" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "501fff203ebecc04025c4d475112de4214714a6d" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
