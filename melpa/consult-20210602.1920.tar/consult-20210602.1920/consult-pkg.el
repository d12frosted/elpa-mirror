(define-package "consult" "20210602.1920" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7b324c597406b77eb18591bb3ce23b2078eb992e" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
