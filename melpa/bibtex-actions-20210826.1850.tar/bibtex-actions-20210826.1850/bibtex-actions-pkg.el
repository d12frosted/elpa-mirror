(define-package "bibtex-actions" "20210826.1850" "Bibliographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0")
    (parsebib "3.0"))
  :commit "edb0baa2c5642958d6876842ca2881224bf37092" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
