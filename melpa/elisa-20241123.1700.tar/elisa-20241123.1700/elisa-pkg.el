;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisa" "20241123.1700"
  "Emacs Lisp Information System Assistant."
  '((emacs  "29.2")
    (ellama "0.11.2")
    (llm    "0.18.1")
    (async  "1.9.8")
    (plz    "0.9"))
  :url "https://github.com/s-kostyaev/elisa"
  :commit "1c1e0f17155a5e6fc8a019403aac5888d7f12dcd"
  :revdesc "1c1e0f17155a"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
