(define-package "lacquer" "20220722.140" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "71bf9e8464ae240db17204dd2b968260a9c4c305" :authors
  '(("zakudriver" . "zy.hua1122@outlook.com"))
  :maintainer
  '("zakudriver" . "zy.hua1122@outlook.com")
  :keywords
  '("tools")
  :url "https://github.com/zakudriver/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
