(define-package "nnreddit" "20210708.43" "Gnus Backend For Reddit"
  '((emacs "25.1")
    (request "0.3.3")
    (anaphora "1.0.4")
    (dash "2.18.1")
    (json-rpc "0.0.1")
    (virtualenvwrapper "20151123")
    (s "1.6.1"))
  :commit "60bf11fdba8ff56b6b4b21f5f0c04953834d8a14" :keywords
  '("news")
  :url "https://github.com/dickmao/nnreddit")
;; Local Variables:
;; no-byte-compile: t
;; End:
