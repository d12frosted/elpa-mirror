;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250512.1403"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "7e8ae9c4dbdd93391a27ede6c41f58331f6e1e40"
  :revdesc "7e8ae9c4dbdd"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
