(define-package "mood-line" "20231125.23" "A minimal mode line inspired by doom-modeline"
  '((emacs "26.1"))
  :commit "19dc4775e5dc6f8c123a3a3ac0718284490a9328" :authors
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainers
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainer
  '("Jessie Hildebrandt <jessieh.net>")
  :keywords
  '("mode-line" "faces")
  :url "https://gitlab.com/jessieh/mood-line")
;; Local Variables:
;; no-byte-compile: t
;; End:
