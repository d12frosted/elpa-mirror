;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "postcss-sorting" "20180211.956"
  "Postcss-sorting interface."
  '((emacs "24"))
  :url "https://github.com/P233/postcss-sorting.el"
  :commit "deb0c935d2904c11a965758a9aee5a0e905f21fc"
  :revdesc "deb0c935d290"
  :authors '(("Peiwen Lu" . "hi@peiwen.lu"))
  :maintainers '(("Peiwen Lu" . "hi@peiwen.lu")))
