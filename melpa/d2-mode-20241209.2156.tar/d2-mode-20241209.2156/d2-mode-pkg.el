;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "d2-mode" "20241209.2156"
  "Major mode for working with d2 graphs."
  '((emacs "26.1"))
  :url "https://github.com/andorsk/d2-mode"
  :commit "e1fc7d6c1915acaf476060c0f79b8bdef6bd1952"
  :revdesc "e1fc7d6c1915"
  :keywords '("d2" "graphs" "tools" "processes")
  :authors '(("Andor Kesselman" . "andor@henosisknot.com"))
  :maintainers '(("Andor Kesselman" . "andor@henosisknot.com")))
