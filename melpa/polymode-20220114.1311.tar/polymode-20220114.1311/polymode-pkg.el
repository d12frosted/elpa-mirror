(define-package "polymode" "20220114.1311" "Extensible framework for multiple major modes"
  '((emacs "25"))
  :commit "53b2a1d7ce34048330808023906e23e5cca66864" :authors
  '(("Vitalie Spinu"))
  :maintainer
  '("Vitalie Spinu")
  :keywords
  '("languages" "multi-modes" "processes")
  :url "https://github.com/polymode/polymode")
;; Local Variables:
;; no-byte-compile: t
;; End:
