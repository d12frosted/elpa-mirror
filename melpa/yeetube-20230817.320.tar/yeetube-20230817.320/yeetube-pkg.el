(define-package "yeetube" "20230817.320" "YouTube & Invidious Front End"
  '((emacs "27.2"))
  :commit "71178bb0bd825456956ed8fe7be5d3ea4bcfe24b" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
