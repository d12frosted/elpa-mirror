;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebdb-mua-sidecar" "20260314.1744"
  "EBDB Integration for Universal Sidecar."
  '((emacs             "28.1")
    (universal-sidecar "1.5.1")
    (ebdb              "0.8.20"))
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar"
  :commit "3b6bd928f7adb840e62a63dd5bf1236ece912b13"
  :revdesc "3b6bd928f7ad"
  :keywords '("mail" "convenience")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
