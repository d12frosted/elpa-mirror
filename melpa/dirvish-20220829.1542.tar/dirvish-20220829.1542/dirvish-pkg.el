(define-package "dirvish" "20220829.1542" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "782fadae0ee9d6314bce5c89dc33e1d327aa63de" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
