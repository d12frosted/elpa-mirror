(define-package "clojure-ts-mode" "20230604.211" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "019298655e0f76e5fb24150149d647bfab546eb8" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
