(define-package "org-contacts" "20240410.351" "Contacts management system for Org mode"
  '((emacs "27.1")
    (org "9.3.4"))
  :commit "6a7145516d3d4aa74bf5163e999777e1054e16cc" :authors
  '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :url "https://repo.or.cz/org-contacts.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
