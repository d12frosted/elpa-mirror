(define-package "lab" "20230805.30" "An interface for GitLab"
  '((emacs "27.1")
    (memoize "1.1")
    (request "0.3.2")
    (s "1.10.0"))
  :commit "01d481ca41cc122899ad94a97153f81fe6e7f65e" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/lab.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
