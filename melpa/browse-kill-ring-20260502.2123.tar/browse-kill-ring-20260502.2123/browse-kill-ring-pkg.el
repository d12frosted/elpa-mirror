;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browse-kill-ring" "20260502.2123"
  "Interactively insert items from kill-ring."
  ()
  :url "https://github.com/browse-kill-ring/browse-kill-ring"
  :commit "b0c65ac7e934f527f1567def2c256dc60169ab97"
  :revdesc "b0c65ac7e934"
  :keywords '("convenience")
  :authors '(("Colin Walters" . "walters@verbum.org"))
  :maintainers '(("browse-kill-ring" . "browse-kill-ring@tonotdo.com")))
