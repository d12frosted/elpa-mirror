;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250619.938"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "37e15feb67be7988fb0214c3407d13698b30361e"
  :revdesc "37e15feb67be"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
