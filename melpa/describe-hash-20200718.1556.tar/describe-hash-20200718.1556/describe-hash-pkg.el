;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "describe-hash" "20200718.1556"
  "Help function for examining a hash map."
  ()
  :url "https://github.com/Junker/describe-hash"
  :commit "20dbbbea630055b2401f13a55fbb21216960dc46"
  :revdesc "20dbbbea6300")
