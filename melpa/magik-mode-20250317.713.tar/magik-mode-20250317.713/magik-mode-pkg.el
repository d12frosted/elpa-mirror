;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250317.713"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "7b32d2fdb171453b6775b4db288970b5a23bb8b6"
  :revdesc "7b32d2fdb171"
  :keywords '("languages"))
