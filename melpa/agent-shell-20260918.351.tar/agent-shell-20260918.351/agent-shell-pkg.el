;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260918.351"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "76c80976067efe5a780c342a7bd6da8a84e8641d"
  :revdesc "76c80976067e")
