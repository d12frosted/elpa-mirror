;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250615.950"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "80cc9e1cd25e3aad72812aa832627762ac436798"
  :revdesc "80cc9e1cd25e"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
