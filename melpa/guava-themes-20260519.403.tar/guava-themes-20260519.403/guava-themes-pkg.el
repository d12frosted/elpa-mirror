;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260519.403"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "945779d3840654c0fa410a2295b37cfaa1fe67c8"
  :revdesc "945779d38406"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
