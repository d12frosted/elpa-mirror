;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260625.210"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "435558c118b0eaf808e2083beb7b785058b51444"
  :revdesc "435558c118b0"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
