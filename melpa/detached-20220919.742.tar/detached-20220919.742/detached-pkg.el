(define-package "detached" "20220919.742" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "087f8f25d995ac3d8eeb0d8885bf430f824e9c9c" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
