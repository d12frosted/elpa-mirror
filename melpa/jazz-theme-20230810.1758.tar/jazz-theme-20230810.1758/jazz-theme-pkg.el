(define-package "jazz-theme" "20230810.1758" "A warm color theme for Emacs 24+." 'nil :commit "fff04a4141f3c4c61f255ed8527415048c6d8956" :authors
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainers
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainer
  '("Roman Parykin" . "donderom@ymail.com")
  :url "https://github.com/donderom/jazz-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
