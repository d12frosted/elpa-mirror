(define-package "consult" "20211123.19" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "5d7c709ebd61174c5af04610be1445393a877eab" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
