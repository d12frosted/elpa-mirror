;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pink-bliss-uwu-theme" "20250513.1814"
  "Pink color theme."
  '((emacs "24.1"))
  :url "https://github.com/themkat/pink-bliss-uwu"
  :commit "eddb2835e198c62aa31d98d90396d8f2fbf8f05e"
  :revdesc "eddb2835e198")
