(define-package "moom" "20210306.1633" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "9e3a36cd4efb2a37aab0dfe024704de37a04e037" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
