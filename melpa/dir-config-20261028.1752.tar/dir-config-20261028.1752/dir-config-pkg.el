;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "20261028.1752"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "803126f03c13e1cbb3a269cfd1fcca60a6471aaf"
  :revdesc "803126f03c13"
  :keywords '("convenience" "files" "lisp")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
