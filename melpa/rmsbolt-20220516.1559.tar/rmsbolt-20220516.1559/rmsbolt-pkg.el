(define-package "rmsbolt" "20220516.1559" "A compiler output viewer"
  '((emacs "25.1"))
  :commit "b56d3b6cdbfa828144d3d8e559472064b0908d0e" :authors
  '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainer
  '("Jay Kamat" . "jaygkamat@gmail.com")
  :keywords
  '("compilation" "tools")
  :url "http://gitlab.com/jgkamat/rmsbolt")
;; Local Variables:
;; no-byte-compile: t
;; End:
