(define-package "leaf-keywords" "20210220.2026" "Additional leaf.el keywords for external packages"
  '((emacs "24.4")
    (leaf "3.5.0"))
  :commit "1eaeb361a01e8ce4347f23092e69a5c86992f43c" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("lisp" "settings")
  :url "https://github.com/conao3/leaf-keywords.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
