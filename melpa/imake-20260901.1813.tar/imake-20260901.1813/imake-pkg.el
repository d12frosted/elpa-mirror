;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imake" "20260901.1813"
  "Simple, opinionated make target runner."
  '((emacs      "28.1")
    (compat     "31.0")
    (marginalia "2.12"))
  :url "https://github.com/tarsius/imake"
  :commit "4b72c5a40c0b43b45ddb53811e01ed63c0d95242"
  :revdesc "4b72c5a40c0b"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev")))
