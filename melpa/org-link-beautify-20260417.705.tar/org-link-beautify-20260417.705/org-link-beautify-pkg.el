;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260417.705"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "273e5b250fa2cc9b2dbbb63d9a7225536116fbd7"
  :revdesc "273e5b250fa2"
  :keywords '("hypermedia"))
