;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-ispell" "20241104.1520"
  "Run ispell on tree-sitter text nodes."
  '((emacs "29.1"))
  :url "https://github.com/erickgnavar/treesit-ispell.el"
  :commit "fd1598fb16fe99dc8d8245974641c3e474dc31d1"
  :revdesc "fd1598fb16fe"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
