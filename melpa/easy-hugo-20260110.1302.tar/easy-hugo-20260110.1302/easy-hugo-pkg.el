;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-hugo" "20260110.1302"
  "Write blogs made with hugo by markdown or org-mode."
  '((emacs     "25.1")
    (request   "0.3.0")
    (transient "0.3.6"))
  :url "https://github.com/masasam/emacs-easy-hugo"
  :commit "08a60ca443a4d685d8856d89f7df6cdf4b177bea"
  :revdesc "08a60ca443a4")
