(define-package "consult" "20210401.1759" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "63f0a893b5502c938eec87b778feb3edd380546d" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
