;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250426.506"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "325d9e699168fe2ec210ffca79d74e3eab0eee07"
  :revdesc "325d9e699168"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
