(define-package "detached" "20220522.910" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "1e17ad996559507f50a80555e1f731bef159073b" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
