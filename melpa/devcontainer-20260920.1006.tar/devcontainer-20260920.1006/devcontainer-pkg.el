;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20260920.1006"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "cc26a0c326a15ffc7154186e9958a3567f3857e6"
  :revdesc "cc26a0c326a1"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
