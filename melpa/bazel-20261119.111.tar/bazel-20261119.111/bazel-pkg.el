;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261119.111"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "704f787704e33e27544f56de7ab9c91106b3ca5d"
  :revdesc "704f787704e3"
  :keywords '("build tools" "languages"))
