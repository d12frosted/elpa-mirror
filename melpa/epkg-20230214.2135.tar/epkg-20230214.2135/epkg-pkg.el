(define-package "epkg" "20230214.2135" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "29.1.3.4")
    (closql "20210927")
    (llama "0.2.0"))
  :commit "57a886da663fa40afaccfb3de6ce8dfa7a33495f" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
