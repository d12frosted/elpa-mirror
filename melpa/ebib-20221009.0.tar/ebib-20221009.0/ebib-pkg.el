(define-package "ebib" "20221009.0" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "26.1"))
  :commit "404b7546c48669ba14e8e0a70e2d61d734038b40" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
