;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260807.857"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.96.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6a83589393fb67725f288d08d6f12d136564db0e"
  :revdesc "6a83589393fb")
