(define-package "helm-core" "20210906.557" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "af5337f2e2874d5a4b9a912ea539b91f9d88a93b")
;; Local Variables:
;; no-byte-compile: t
;; End:
