(define-package "erk" "20231025.252" "Elisp (GitHub) Repository Kit"
  '((emacs "28.1")
    (auto-compile "1.2.0")
    (dash "2.18.0")
    (license-templates "0.1.3"))
  :commit "f664196ad5736ec03ff04b4566a363309b8ceda4" :authors
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainers
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainer
  '("Positron Solutions" . "contact@positron.solutions")
  :keywords
  '("convenience" "programming")
  :url "http://github.com/positron-solutions/elisp-repo-kit")
;; Local Variables:
;; no-byte-compile: t
;; End:
