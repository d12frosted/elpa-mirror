(define-package "el-patch" "20220417.1946" "Future-proof your Elisp"
  '((emacs "26"))
  :commit "d4f4574bcf4005f4fbafde8874cb19b907783956" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/el-patch")
;; Local Variables:
;; no-byte-compile: t
;; End:
