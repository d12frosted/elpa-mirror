(define-package "eldev" "20220501.1128" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "7275089749779599d87bee878e5103921ea919f9" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
