(define-package "srfi" "20210812.2301" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "e31bf04a3be3aad1286b7fe919c2e4810aae751e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
