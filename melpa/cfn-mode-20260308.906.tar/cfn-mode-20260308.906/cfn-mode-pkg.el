;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260308.906"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "58739bc6257723bf7d540f64a64b19e15ff75a10"
  :revdesc "58739bc62577"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
