;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lxc-tramp" "20230119.1251"
  "TRAMP integration for LXC containers."
  '((emacs  "24")
    (cl-lib "0.6"))
  :url "https://github.com/montag451/lxc-tramp"
  :commit "57559701334bb5635b82a252bd00298d06d794fe"
  :revdesc "57559701334b"
  :keywords '("lxc" "convenience"))
