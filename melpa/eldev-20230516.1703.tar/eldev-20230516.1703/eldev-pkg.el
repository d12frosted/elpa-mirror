(define-package "eldev" "20230516.1703" "Elisp development tool"
  '((emacs "24.4"))
  :commit "a34a17bb257c845e5b6ebf64e5a5b28d61fb4ca2" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
