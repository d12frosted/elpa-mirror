;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pebble-mode" "20230123.1801"
  "A major mode for pebble."
  '((emacs "24.3"))
  :url "https://github.com/ArneBab/pebble-mode"
  :commit "bcbc76aa89196338f12a8ddfe4486edf83c19c5e"
  :revdesc "bcbc76aa8919")
