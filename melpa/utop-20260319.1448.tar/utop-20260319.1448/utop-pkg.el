;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "utop" "20260319.1448"
  "Universal toplevel for OCaml."
  '((emacs "26"))
  :url "https://github.com/ocaml-community/utop"
  :commit "8cd6716d0f90efd67da90afa5bc31c7abe9a7a57"
  :revdesc "8cd6716d0f90"
  :keywords '("ocaml" "languages")
  :authors '(("Jeremie Dimino" . "jeremie@dimino.org"))
  :maintainers '(("Jeremie Dimino" . "jeremie@dimino.org")))
