(define-package "flexoki-themes" "20231129.1344" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "0311923c068b4f3c2b2a67e8559550a1b65d1403" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
