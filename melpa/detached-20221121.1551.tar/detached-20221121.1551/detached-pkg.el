(define-package "detached" "20221121.1551" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "0c7586847fc7bff2a815a31a65a88162d1377a21" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
