;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261022.1600"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "4b79e304d29f35ecb83c4518137dee204568feff"
  :revdesc "4b79e304d29f"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
