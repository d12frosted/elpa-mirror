(define-package "immersive-translate" "20230909.647" "Translate the current buffer immersively"
  '((emacs "28.2"))
  :commit "4e9655ba0e9c990a332fc24f975d965eaba63e14" :authors
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainers
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainer
  '("Eli Qian" . "eli.q.qian@gmail.com")
  :keywords
  '("convenience" "help" "translate")
  :url "https://github.com/Elilif/emacs-immersive-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
