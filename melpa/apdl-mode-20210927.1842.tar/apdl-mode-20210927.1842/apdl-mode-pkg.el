(define-package "apdl-mode" "20210927.1842" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "c7133c3c50501fea73398d082ed97567a1b707aa" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
