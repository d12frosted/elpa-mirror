;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260623.1437"
  "Support for Org links to Magit buffers."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (magit    "4.5")
    (org      "9.8"))
  :url "https://github.com/magit/orgit"
  :commit "281ab0c95371be01fac967faaeab820e0a8ace7f"
  :revdesc "281ab0c95371"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
