;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20261008.1917"
  "Folding text based on indentation (origami alternative)."
  '((emacs    "26.1")
    (kirigami "1.0.5"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "c71cb0451f66d7c37460da01bfd11b02fd2e31d6"
  :revdesc "c71cb0451f66"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
