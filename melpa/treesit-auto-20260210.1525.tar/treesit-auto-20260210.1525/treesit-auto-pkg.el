;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-auto" "20260210.1525"
  "Automatically use tree-sitter enhanced major modes."
  '((emacs "29.0"))
  :url "https://github.com/renzmann/treesit-auto.git"
  :commit "5fc2223efff80694158543d5b59bcb5403c58873"
  :revdesc "5fc2223efff8"
  :keywords '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :authors '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers '(("Robb Enzmann" . "robbenzmann@gmail.com")))
