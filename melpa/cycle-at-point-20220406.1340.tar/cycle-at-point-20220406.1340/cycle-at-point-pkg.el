(define-package "cycle-at-point" "20220406.1340" "Cycle (rotate) the thing under the cursor"
  '((emacs "28.1")
    (recomplete "0.2"))
  :commit "4637a9288028f3eaa31cfa9658cfe78f423b16cf" :authors
  '(("Campbell Barton"))
  :maintainer
  '("Campbell Barton")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-cycle-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
