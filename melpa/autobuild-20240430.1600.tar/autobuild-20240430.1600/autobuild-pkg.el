;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autobuild" "20240430.1600"
  "Define and execute build rules and compilation pipelines."
  '((emacs   "26.1")
    (selcand "0.0.3"))
  :url "https://github.com/erjoalgo/autobuild"
  :commit "4760f6ea843d5d15c3fcf7cbf6b69153b61739fa"
  :revdesc "4760f6ea843d"
  :keywords '("compile" "build" "pipeline" "autobuild" "extensions" "processes" "tools")
  :maintainers '(("concat \"erjoalgo\" \"@\" \"gmail\" \".com\"" . "")))
