;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buster-snippets" "20151125.1010"
  "Yasnippets for the Buster javascript testing framework."
  '((yasnippet "0.8.0"))
  :url "https://github.com/magnars/buster-snippets.el"
  :commit "bb8769dae132659858e74d52f3f4e8790399423a"
  :revdesc "bb8769dae132"
  :keywords '("snippets")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
