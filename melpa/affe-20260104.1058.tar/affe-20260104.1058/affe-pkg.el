;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "affe" "20260104.1058"
  "Asynchronous Fuzzy Finder for Emacs."
  '((emacs   "29.1")
    (consult "2.8"))
  :url "https://github.com/minad/affe"
  :commit "295e2fb26a2de66e13c0f8414d1ada5b090a1011"
  :revdesc "295e2fb26a2d"
  :keywords '("matching" "files" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
