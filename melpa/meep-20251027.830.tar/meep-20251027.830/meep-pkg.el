;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251027.830"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "521e1d818cc3f9b886ece80546685dca88231742"
  :revdesc "521e1d818cc3"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
