(define-package "hammy" "20230702.342" "Programmable, interactive interval timers"
  '((emacs "28.1")
    (ts "0.2.2"))
  :commit "471958b7269a7901804e3e7be20e14d69fc7b11d" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/hammy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
