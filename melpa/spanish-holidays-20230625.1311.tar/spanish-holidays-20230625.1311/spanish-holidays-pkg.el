(define-package "spanish-holidays" "20230625.1311" "Spain holidays for calendar" 'nil :commit "c8db8829311a7101bb0b9d8a054b177dd73190b9" :authors
  '(("Carlos Pajuelo" . "carlospajuelo_@hotmail.com"))
  :maintainers
  '(("Carlos Pajuelo" . "carlospajuelo_@hotmail.com"))
  :maintainer
  '("Carlos Pajuelo" . "carlospajuelo_@hotmail.com")
  :keywords
  '("calendar")
  :url "https://gitlab.com/gnuhack/spanish-holidays")
;; Local Variables:
;; no-byte-compile: t
;; End:
