;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20261031.30"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "9dbd862056a235b6895c8530e651651db9ad3092"
  :revdesc "9dbd862056a2"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
