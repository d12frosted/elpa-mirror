(define-package "org-link-beautify" "20230301.19" "Beautify Org Links"
  '((emacs "28.1")
    (all-the-icons "5.0.0"))
  :commit "f784f82176b23566b94acad6d3d451e5fb4608b5" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
