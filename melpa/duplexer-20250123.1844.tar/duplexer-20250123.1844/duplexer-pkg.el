;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "duplexer" "20250123.1844"
  "Handle conflicts between local minor modes and reuse rules."
  '((emacs "29.1")
    (dash  "2.19.1"))
  :url "https://github.com/eki3z/duplexer.el"
  :commit "242b0bf47192164835a26ae5c553e689dd1b2974"
  :revdesc "242b0bf47192"
  :keywords '("tools")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
