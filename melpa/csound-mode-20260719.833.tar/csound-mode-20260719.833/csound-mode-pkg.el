;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csound-mode" "20260719.833"
  "A major mode for interacting and coding Csound."
  '((emacs "27.1"))
  :url "https://github.com/hlolli/csound-mode"
  :commit "9b12204deb8cede38dbb178f4b9c5f101e06d6a3"
  :revdesc "9b12204deb8c"
  :authors '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers '(("Hlöðver Sigurðsson" . "hlolli@gmail.com")))
