;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20250216.749"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.8.0"))
  :url "https://github.com/aurtzy/disproject"
  :commit "1147157225fa096e55f5eeba4ab36f2eeddbf326"
  :revdesc "1147157225fa"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
