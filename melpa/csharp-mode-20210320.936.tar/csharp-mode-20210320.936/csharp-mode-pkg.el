(define-package "csharp-mode" "20210320.936" "C# mode derived mode"
  '((emacs "26.1")
    (tree-sitter "0.12.1")
    (tree-sitter-indent "0.1")
    (tree-sitter-langs "0.9.1"))
  :commit "1c2b9cb51b6ecc8bf52d3f040b6c02639310a153" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
