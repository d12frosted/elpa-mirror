(define-package "org-link-beautify" "20230412.258" "Beautify Org Links"
  '((emacs "28.1")
    (all-the-icons "5.0.0"))
  :commit "0ecb7b5915c376fe401a74493bc0950469b700ea" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
