;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-commandlinefu" "20150611.545"
  "Search and browse commandlinefu.com from helm."
  '((emacs     "24.1")
    (helm      "1.7.0")
    (json      "1.3")
    (let-alist "1.0.3"))
  :url "https://github.com/xuchunyang/helm-commandlinefu"
  :commit "9ee7e018c5db23ae9c8d1c8fa969876f15b7280d"
  :revdesc "9ee7e018c5db"
  :keywords '("commandlinefu.com")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
