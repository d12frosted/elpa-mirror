;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "echo-bar" "20260720.1423"
  "Turn the echo area into a custom status bar."
  ()
  :url "https://github.com/qaiviq/echo-bar.el"
  :commit "518ba97f790f0816c7df229b578ccc7e1a8e4f7e"
  :revdesc "518ba97f790f"
  :keywords '("convenience" "tools")
  :authors '(("Adam Tillou" . "qaiviq@gmail.com"))
  :maintainers '(("Adam Tillou" . "qaiviq@gmail.com")))
