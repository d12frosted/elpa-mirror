(define-package "consult" "20210523.2025" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "6020efd7de9882fca0b67c80876454e1994b72e9" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
