;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "20260905.2028"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "55a69ae6325c06fdde9a94b55c8f3dbc901686ff"
  :revdesc "55a69ae6325c"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
