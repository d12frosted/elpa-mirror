(define-package "consult" "20210725.2120" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "07af37b6a532e75df7430b6f42ec4b958beb4889" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
