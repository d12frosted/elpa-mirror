;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20250929.427"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "dbd9aa370f4bd3ba980b3114888880dd3c38dace"
  :revdesc "dbd9aa370f4b"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
