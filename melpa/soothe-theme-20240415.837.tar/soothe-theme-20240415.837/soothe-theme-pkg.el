;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soothe-theme" "20240415.837"
  "A dark colorful theme."
  '((emacs      "24.3")
    (autothemer "0.2"))
  :url "https://github.com/emacsfodder/emacs-soothe-theme"
  :commit "a8d3d964cfe9fc2157f45d2d26647a450ed9161a"
  :revdesc "a8d3d964cfe9"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
