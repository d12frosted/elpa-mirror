;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-sidebar" "20260415.424"
  "Tree browser leveraging dired."
  '((emacs         "25.1")
    (dired-subtree "0.0.1")
    (compat        "30.0.0.0"))
  :url "https://github.com/jojojames/dired-sidebar"
  :commit "68f34735f14e2dbaa0b9c31376e8ad6c338ed24f"
  :revdesc "68f34735f14e"
  :keywords '("dired" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
