;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260923.1359"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "24eed02c31e80df16aed5f741b77b66e270de6eb"
  :revdesc "24eed02c31e8"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
