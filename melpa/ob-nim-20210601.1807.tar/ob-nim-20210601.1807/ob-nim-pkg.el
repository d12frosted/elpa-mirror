;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-nim" "20210601.1807"
  "Babel Functions for nim."
  '((cl-lib "0.5"))
  :url "https://github.com/Lompik/ob-nim"
  :commit "315ee36b3ff72437bd65704c456f7ac48205e389"
  :revdesc "315ee36b3ff7"
  :keywords '("literate programming" "reproducible research"))
