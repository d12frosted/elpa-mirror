;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digistar-mode" "20241229.2007"
  "Major mode for Digistar scripts."
  '((emacs "29.1"))
  :url "https://github.com/retroj/digistar-mode"
  :commit "4c1ebcf22007ecc9e5b236864514b8b31c4b2576"
  :revdesc "4c1ebcf22007"
  :keywords '("languages")
  :authors '(("John Foerch" . "jjfoerch@gmail.com"))
  :maintainers '(("John Foerch" . "jjfoerch@gmail.com")))
