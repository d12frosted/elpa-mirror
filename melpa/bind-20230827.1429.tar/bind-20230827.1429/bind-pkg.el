(define-package "bind" "20230827.1429" "Bind commands to keys"
  '((emacs "25.1"))
  :commit "8e5ab488f0529565af5ba62bc047ac4b149ce945" :authors
  '(("repelliuss <https://github.com/repelliuss>"))
  :maintainers
  '(("repelliuss" . "repelliuss@gmail.com"))
  :maintainer
  '("repelliuss" . "repelliuss@gmail.com")
  :url "https://github.com/repelliuss/bind")
;; Local Variables:
;; no-byte-compile: t
;; End:
