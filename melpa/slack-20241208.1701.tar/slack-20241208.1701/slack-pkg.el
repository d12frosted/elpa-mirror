;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "20241208.1701"
  "Slack client for Emacs."
  '((websocket "1.8")
    (request   "0.2.0")
    (oauth2    "0.10")
    (circe     "2.2")
    (alert     "1.2")
    (emojify   "0.2")
    (emacs     "25.1")
    (dash      "2.19.1")
    (s         "1.13.1")
    (ts        "0.3"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "cfe8472d98b150b3c1c6b2cfff72ca87506e0818"
  :revdesc "cfe8472d98b1"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
