(define-package "ekg" "20231007.340" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.1.1"))
  :commit "bd7bb3bde2508455471a848d7013e169a81f1de0" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
