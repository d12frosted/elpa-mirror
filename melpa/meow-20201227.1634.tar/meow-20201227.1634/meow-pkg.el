(define-package "meow" "20201227.1634" "Modal Editing On Wheel"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1"))
  :commit "1c1b3c0ad6d733c6ef3a3193c9506d796edd0308" :authors
  (("Shi Tianshu"))
  :maintainer
  ("Shi Tianshu")
  :keywords
  ("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
