(define-package "consult" "20211027.1058" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "8bc1f0569af8eff7cfa7c49d90bec2085623ccd6" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
