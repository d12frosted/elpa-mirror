(define-package "centered-cursor-mode" "20230911.1503" "cursor stays vertically centered" 'nil :commit "63311fe60cbf7285f2c0db16937eb822d3267be3" :authors
  '(("André Riemann" . "andre.riemann@web.de"))
  :maintainers
  '(("André Riemann" . "andre.riemann@web.de"))
  :maintainer
  '("André Riemann" . "andre.riemann@web.de")
  :keywords
  '("convenience")
  :url "https://github.com/andre-r/centered-cursor-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
