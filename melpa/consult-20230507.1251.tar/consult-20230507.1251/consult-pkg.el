(define-package "consult" "20230507.1251" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "267b0c9d86e7f593d042a1669a03782ecac82a54" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
