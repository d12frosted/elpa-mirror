(define-package "consult" "20220601.1541" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "b76f7fb0856ecf03a6f539ccb4d4a0fd627acd87" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
