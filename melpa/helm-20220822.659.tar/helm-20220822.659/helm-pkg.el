(define-package "helm" "20220822.659" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.7")
    (popup "0.5.3"))
  :commit "b778e722bd3613792661da527f16f99cfde23794" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
