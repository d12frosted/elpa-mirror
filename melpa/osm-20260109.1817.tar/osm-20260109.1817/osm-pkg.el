;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260109.1817"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "7880b450138b3d260480e3e527fb3178cc8e2bc9"
  :revdesc "7880b450138b"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
