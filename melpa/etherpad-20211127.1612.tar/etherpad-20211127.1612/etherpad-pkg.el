(define-package "etherpad" "20211127.1612" "Interface to the Etherpad API"
  '((emacs "26.3")
    (request "0.3")
    (let-alist "0.0")
    (websocket "1.12")
    (parsec "0.1")
    (0xc "0.1"))
  :commit "a884fd4dc9cf5b532bb359eac3ac58ee83980a16" :authors
  '(("nik gaffney" . "nik@fo.am"))
  :maintainer
  '("nik gaffney" . "nik@fo.am")
  :keywords
  '("comm" "etherpad" "collaborative editing")
  :url "https://github.com/zzkt/ethermacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
