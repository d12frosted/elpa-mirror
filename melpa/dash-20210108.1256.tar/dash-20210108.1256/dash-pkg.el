(define-package "dash" "20210108.1256" "A modern list library for Emacs"
  '((emacs "24"))
  :commit "f9d67aee0a53c074ec16583b01438e1ddc6a25fd" :authors
  '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainer
  '("Magnar Sveen" . "magnars@gmail.com")
  :keywords
  '("extensions" "lisp")
  :url "https://github.com/magnars/dash.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
