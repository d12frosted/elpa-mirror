(define-package "consult" "20220415.1647" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "b670d9a6d5c2a8062391bd5b972172061b65d8f6" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
