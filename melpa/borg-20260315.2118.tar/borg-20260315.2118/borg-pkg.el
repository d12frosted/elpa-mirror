;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260315.2118"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "6fbd5c4e899f377a869c20853bf7a29c0d18d281"
  :revdesc "6fbd5c4e899f"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
