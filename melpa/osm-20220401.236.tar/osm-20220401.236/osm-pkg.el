(define-package "osm" "20220401.236" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "1264c3e1dc514567a5093b46fa5b4a7abdf74dec" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
