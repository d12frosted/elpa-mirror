;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260510.1603"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9c73697d4321cb34ba241a7f30efdbbc4ceed109"
  :revdesc "9c73697d4321"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
