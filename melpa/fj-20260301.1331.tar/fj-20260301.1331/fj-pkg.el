;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20260301.1331"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "ab4e168a635024714266b3c04a843a403563ede2"
  :revdesc "ab4e168a6350"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
