(define-package "modus-themes" "20211027.808" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "49868efd521088114d05f0d929eb70aa9bf983ce" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
