;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-scrolltoplace" "20180608.606"
  "An Erc module to scrolltobottom better with keep-place."
  '((emacs                   "24.0")
    (switch-buffer-functions "0.0.1"))
  :url "https://gitlab.com/jgkamat/erc-scrolltoplace"
  :commit "feb0fbf1fd4bdf220ae2d31ea7c066d8e62089f9"
  :revdesc "feb0fbf1fd4b"
  :keywords '("erc" "module" "comm" "scrolltobottom" "keep-place")
  :authors '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainers '(("Jay Kamat" . "jaygkamat@gmail.com")))
