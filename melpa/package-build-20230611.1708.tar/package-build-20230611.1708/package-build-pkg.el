(define-package "package-build" "20230611.1708" "Tools for assembling a package archive"
  '((emacs "26.1"))
  :commit "1c3f0b631e58f57d70d28807385904004b285853" :authors
  '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
    ("Steve Purcell" . "steve@sanityinc.com")
    ("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers
  '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainer
  '("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
  :keywords
  '("maint" "tools")
  :url "https://github.com/melpa/package-build")
;; Local Variables:
;; no-byte-compile: t
;; End:
