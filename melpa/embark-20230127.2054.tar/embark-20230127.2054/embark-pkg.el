(define-package "embark" "20230127.2054" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "213ced2c5d30848ec03bb8599590b111b27c7839" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
