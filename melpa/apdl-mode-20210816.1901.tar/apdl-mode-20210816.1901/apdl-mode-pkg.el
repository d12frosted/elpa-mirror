(define-package "apdl-mode" "20210816.1901" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "b0b0c196c3e5bcd71a9f055935df9f6bceb50556" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
