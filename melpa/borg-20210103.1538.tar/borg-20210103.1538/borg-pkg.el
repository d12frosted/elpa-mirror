(define-package "borg" "20210103.1538" "assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.2.2")
    (magit "2.90.1"))
  :commit "bda86a0d25adf3d709140b808ee879e7e5954c86" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
