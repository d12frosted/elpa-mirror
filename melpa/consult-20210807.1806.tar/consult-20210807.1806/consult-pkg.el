(define-package "consult" "20210807.1806" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "620b10db130fc62cf104ea1a91d6a6e38ceb8bc1" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
