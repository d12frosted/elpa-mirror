(define-package "consult" "20210807.1806" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b73cb9d9fec2b00763e4f7f953cd495126a37d84" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
