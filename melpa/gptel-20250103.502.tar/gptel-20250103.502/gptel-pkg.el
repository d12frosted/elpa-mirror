;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250103.502"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "16684057e99971f366880f779970c5fe2b54fb6e"
  :revdesc "16684057e999"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
