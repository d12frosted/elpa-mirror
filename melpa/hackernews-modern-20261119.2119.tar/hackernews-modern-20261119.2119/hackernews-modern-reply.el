;;; hackernews-modern-reply.el --- Reply to Hacker News comments from hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Buffer to write comments and replies and the requests that post
;; them to Hacker News.

;;; Code:

(require 'hackernews-modern-core)
(require 'hackernews-modern-account)

(declare-function hackernews-modern--display-comments "hackernews-modern-comments" (buffer items))

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar-local hackernews-modern--reply-parent nil
  "ID of the item the current reply buffer answers.")

(defvar-local hackernews-modern--reply-comments-buffer nil
  "Comments buffer the current reply buffer was opened from.")

(defvar-local hackernews-modern--reply-body-start nil
  "Marker at the start of the text written in the reply buffer.")

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern-reply-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-c") #'hackernews-modern-reply-send)
    (define-key map (kbd "C-c C-k") #'hackernews-modern-reply-cancel)
    map)
  "Keymap used in hackernews-modern reply buffer.")

(define-derived-mode hackernews-modern-reply-mode text-mode "HN Reply"
  "Mode for writing a Hacker News comment.

Write below the separator line.  Paragraphs are separated by a
blank line, lines indented by two spaces are code and text
surrounded by asterisks is italic.

\\<hackernews-modern-reply-mode-map>
\\[hackernews-modern-reply-send]	Send the comment.
\\[hackernews-modern-reply-cancel]	Cancel.

\\{hackernews-modern-reply-mode-map}"
  :interactive nil
  (visual-line-mode 1))

(defun hackernews-modern--reply (id)
  "Open a buffer to reply to item ID of the current comments buffer."
  (let* ((comments (current-buffer))
         (item     (gethash id hackernews-modern--comments-items))
         (story-p  (eql id hackernews-modern--comments-id))
         (buffer   (get-buffer-create
                    (format "*HN reply to %s*"
                            (if story-p "story" (cdr (assq 'by item)))))))
    (when (and (numberp id) (< id 0))
      (user-error "Reload the comments before replying to this comment"))
    (with-current-buffer buffer
      (unless (derived-mode-p #'hackernews-modern-reply-mode)
        (hackernews-modern-reply-mode)
        (setq hackernews-modern--reply-parent id)
        (setq hackernews-modern--reply-comments-buffer comments)
        (let ((inhibit-read-only t))
          (insert (if story-p
                      (format "Commenting on: %s\n"
                              (xml-substitute-special
                               (or (cdr (assq 'title item)) "")))
                    (format "Replying to %s:\n%s\n"
                            (cdr (assq 'by item))
                            (hackernews-modern--html-excerpt
                             (cdr (assq 'text item))))))
          (insert (substitute-command-keys
                   (concat "\\<hackernews-modern-reply-mode-map>"
                           "\\[hackernews-modern-reply-send] send · "
                           "\\[hackernews-modern-reply-cancel] cancel · "
                           "blank line = paragraph, 2 spaces = code, "
                           "*text* = italic\n")))
          (insert (make-string 72 ?─) "\n")
          (add-text-properties (point-min) (point)
                               '(read-only t face shadow
                                           front-sticky (read-only)
                                           rear-nonsticky (read-only face))))
        (setq hackernews-modern--reply-body-start (point-marker))))
    (pop-to-buffer buffer '((display-buffer-below-selected)
                            (window-height . 0.4)))
    (goto-char (point-max))))

(defun hackernews-modern--reply-text ()
  "Return the text written in the current reply buffer."
  (string-trim-right
   (string-trim-left (buffer-substring-no-properties
                      hackernews-modern--reply-body-start (point-max))
                     "[\n\r]+")))

(defun hackernews-modern-reply-cancel ()
  "Discard the current reply."
  (declare (modes hackernews-modern-reply-mode))
  (interactive)
  (when (or (string-empty-p (hackernews-modern--reply-text))
            (y-or-n-p "Discard this comment? "))
    (quit-window t)))

(defun hackernews-modern-reply-send ()
  "Send the current reply to Hacker News."
  (declare (modes hackernews-modern-reply-mode))
  (interactive)
  (let ((text   (hackernews-modern--reply-text))
        (buffer (current-buffer)))
    (when (string-empty-p text)
      (user-error "The comment is empty"))
    (hackernews-modern--with-login
     (lambda ()
       (hackernews-modern--post-comment buffer text)))))

(defun hackernews-modern--post-comment (buffer text &optional retried)
  "Post TEXT as the reply of reply BUFFER.
The reply form is fetched first to obtain its anti-forgery token.
When the session has expired, log in again once unless RETRIED."
  (let* ((parent   (buffer-local-value 'hackernews-modern--reply-parent buffer))
         (comments (buffer-local-value 'hackernews-modern--reply-comments-buffer buffer))
         (story    (buffer-local-value 'hackernews-modern--comments-id comments))
         (path     (format (if (eql parent story) "item?id=%s" "reply?id=%s") parent)))
    (message "Sending comment...")
    (hackernews-modern--site-request
     path
     (lambda (body _redirect)
       (let ((hmac (and body
                        (string-match "name=\"hmac\" value=\"\\([^\"]+\\)\"" body)
                        (match-string 1 body)))
             (goto (or (and body
                            (string-match "name=\"goto\" value=\"\\([^\"]+\\)\"" body)
                            (hackernews-modern--decode-entities (match-string 1 body)))
                       (format "item?id=%s" story))))
         (cond
          (hmac
           (hackernews-modern--site-request
            "comment"
            (lambda (result redirect)
              (if redirect
                  (hackernews-modern--reply-sent buffer text)
                (message "Comment not sent: %s"
                         (hackernews-modern--page-message result))))
            `(("parent" ,(number-to-string parent))
              ("goto"   ,goto)
              ("hmac"   ,hmac)
              ("text"   ,text))))
          ((and (not retried) body (string-match-p "logged in" body))
           (hackernews-modern-login
            (lambda () (hackernews-modern--post-comment buffer text t))))
          (t
           (message "Comment not sent: %s"
                    (hackernews-modern--page-message body)))))))))

(defun hackernews-modern--reply-sent (buffer text)
  "Close reply BUFFER and show TEXT in its comments buffer.
The comment is added locally because the API takes a while to
include new comments."
  (let ((parent   (buffer-local-value 'hackernews-modern--reply-parent buffer))
        (comments (buffer-local-value 'hackernews-modern--reply-comments-buffer buffer)))
    (when (buffer-live-p buffer)
      (let ((window (get-buffer-window buffer t)))
        (if window
            (quit-window t window)
          (kill-buffer buffer))))
    (when (buffer-live-p comments)
      (with-current-buffer comments
        (let* ((items  hackernews-modern--comments-items)
               (id     (- (1+ (hash-table-count items))))
               (owner  (gethash parent items))
               (story  (gethash hackernews-modern--comments-id items)))
          (puthash id `((id . ,id)
                        (by . ,(hackernews-modern--current-user))
                        (time . ,(float-time))
                        (text . ,(hackernews-modern--text-to-html text))
                        (kids))
                   items)
          (setcdr (assq 'kids owner) (cons id (cdr (assq 'kids owner))))
          (setcdr (assq 'descendants story)
                  (1+ (or (cdr (assq 'descendants story)) 0)))
          (hackernews-modern--display-comments comments items)
          (let ((pos (text-property-any (point-min) (point-max)
                                        'hackernews-modern-comment-id id))
                (window (get-buffer-window comments t)))
            (when pos
              (goto-char pos)
              (when window
                (set-window-point window pos)))))))
    (message "Comment sent")))

(provide 'hackernews-modern-reply)

;;; hackernews-modern-reply.el ends here
