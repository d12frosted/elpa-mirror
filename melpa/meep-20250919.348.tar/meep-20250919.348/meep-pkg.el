;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250919.348"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "038ff7ae029bde2cab5c267d865116dca809a4f6"
  :revdesc "038ff7ae029b"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
