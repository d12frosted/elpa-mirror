;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20260124.1253"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "5786ef4fbb48d7c17399734590859eae4d4cd5bd"
  :revdesc "5786ef4fbb48"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
