;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-tree" "20260516.827"
  "Interactive side-bar feature for init.el using leaf."
  '((emacs      "25.1")
    (imenu-list "0.9"))
  :url "https://github.com/conao3/leaf-tree.el"
  :commit "6c85ef64bb21ddbd64e70625dbd59b0539fac534"
  :revdesc "6c85ef64bb21"
  :keywords '("convenience" "leaf")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
