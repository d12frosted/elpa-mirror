(define-package "cape" "20230101.1106" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "68ae230a5b7ca523bfac2eecf6e2ce9b691cdd04" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
