(define-package "symbols-outline" "20231204.856" "Display symbols (functions, variables, etc) in outline view"
  '((emacs "27.1"))
  :commit "2e3fa40e0204f19ca3cacf103828316f01c0520a" :authors
  '(("Shihao Liu"))
  :maintainers
  '(("Shihao Liu"))
  :maintainer
  '("Shihao Liu")
  :keywords
  '("outlines")
  :url "https://github.com/liushihao456/symbols-outline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
