;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comet-trail" "20260413.747"
  "Cursor comet trail effect."
  '((emacs "29.1"))
  :url "https://git.andros.dev/andros/comet-trail.el"
  :commit "6bb17b3672d421f2456bf69f76138ef5b0f48647"
  :revdesc "6bb17b3672d4"
  :keywords '("faces" "convenience")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
