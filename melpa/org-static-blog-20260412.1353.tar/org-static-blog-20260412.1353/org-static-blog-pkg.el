;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-static-blog" "20260412.1353"
  "A simple org-mode based static blog generator."
  '((emacs "24.3"))
  :url "https://github.com/bastibe/org-static-blog"
  :commit "9b935947aee70cec2920e7645c0858e629459caa"
  :revdesc "9b935947aee7")
