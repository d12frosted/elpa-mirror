;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "heex-ts-mode" "20250511.643"
  "Major mode for Heex with tree-sitter support."
  '((emacs "29.1"))
  :url "https://github.com/wkirschbaum/elixir-ts-mode"
  :commit "7496adcad0339978ef462b92160b6d40c3595841"
  :revdesc "7496adcad033"
  :keywords '("heex" "languages" "tree-sitter"))
