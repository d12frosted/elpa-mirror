(define-package "gams-mode" "20240709.410" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "6fb90d9c83747ac020743cd7a8c2efda0c5936eb" :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
