;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260604.1835"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "581941d91db6490018340a3cabdef55ce58a4f61"
  :revdesc "581941d91db6"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
