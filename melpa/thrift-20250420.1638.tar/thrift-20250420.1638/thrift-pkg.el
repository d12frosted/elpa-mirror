;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20250420.1638"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "7560ce1f64359cc66ae85e93e6b1bdbd1eaf23b3"
  :revdesc "7560ce1f6435"
  :keywords '("languages"))
