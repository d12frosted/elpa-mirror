;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "owcmd" "20200517.2039"
  "Run a single command in the other window."
  '((emacs "26.3"))
  :url "https://github.com/fishyfriend/owcmd"
  :commit "05fb8f8f81838b5888fdec8b3947096dd2222e61"
  :revdesc "05fb8f8f8183"
  :keywords '("convenience")
  :authors '(("Jacob First" . "jacob.first@member.fsf.org"))
  :maintainers '(("Jacob First" . "jacob.first@member.fsf.org")))
