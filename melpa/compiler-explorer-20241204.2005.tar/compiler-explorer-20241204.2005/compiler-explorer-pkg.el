;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "20241204.2005"
  "Compiler explorer client (godbolt.org)."
  '((emacs "27.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "bb66a38f9b208fb7458e684e15043679eb420fff"
  :revdesc "bb66a38f9b20"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
