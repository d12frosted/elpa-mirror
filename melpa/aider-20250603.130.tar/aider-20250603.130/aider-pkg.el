;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250603.130"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.9.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "ea861fbe75f559647ad4d2751d91e7e4b8305212"
  :revdesc "ea861fbe75f5"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
