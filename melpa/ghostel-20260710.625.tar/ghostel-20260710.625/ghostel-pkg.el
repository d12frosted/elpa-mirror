;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260710.625"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "766a2d440ea785818d1792def48d397e01b84846"
  :revdesc "766a2d440ea7"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
