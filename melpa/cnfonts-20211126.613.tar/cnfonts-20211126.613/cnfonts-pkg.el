(define-package "cnfonts" "20211126.613" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "639d035b9ff172704785bb9d6428e5b371a4aab3" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
