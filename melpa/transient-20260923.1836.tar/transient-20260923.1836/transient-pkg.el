;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260923.1836"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "db34982dd7d38b3275ae432e23cd708e28303b81"
  :revdesc "db34982dd7d3"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
