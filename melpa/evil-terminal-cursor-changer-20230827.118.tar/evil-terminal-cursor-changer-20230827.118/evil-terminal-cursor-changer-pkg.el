(define-package "evil-terminal-cursor-changer" "20230827.118" "Change cursor shape and color by evil state in terminal" 'nil :commit "380de63bbb32dda00434d50f47e187f9cbf89b32" :authors
  '(("7696122"))
  :maintainers
  '(("7696122"))
  :maintainer
  '("7696122")
  :keywords
  '("evil" "terminal" "cursor")
  :url "https://github.com/7696122/evil-terminal-cursor-changer")
;; Local Variables:
;; no-byte-compile: t
;; End:
