;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20260928.831"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.11.1"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "fdfcd34b5548693cc5d84154159a5c4c1faf3992"
  :revdesc "fdfcd34b5548"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
