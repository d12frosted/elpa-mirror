(define-package "org-bookmarks" "20240428.2209" "Manage bookmarks in Org mode"
  '((emacs "26.1"))
  :commit "99d4075ccb1297249bba93f4300c94ac8a8d4a7c" :keywords
  '("outline" "matching" "hypermedia" "org")
  :url "https://repo.or.cz/org-bookmarks.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
