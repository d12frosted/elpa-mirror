(define-package "clojure-ts-mode" "20230805.1336" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "2d78f6be4f37196ae3a22c51ce2b39f126f003ee" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
