;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-relative-date" "20260830.1852"
  "Live relative-date overlays on org timestamps."
  '((emacs "27.1")
    (org   "9.1"))
  :url "https://github.com/RobertPlant/org-relative-date"
  :commit "159fe6fd7311fabec3e85864cf69ea12a1692811"
  :revdesc "159fe6fd7311"
  :keywords '("calendar" "org" "convenience")
  :authors '(("Rob Plant" . "rob@robertplant.io"))
  :maintainers '(("Rob Plant" . "rob@robertplant.io")))
