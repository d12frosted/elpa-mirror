(define-package "fountain-mode" "20231020.1310" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "ffa4f4f38ed2e1f0c3cc9aed5ca26b77af24d8d0" :authors
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainers
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainer
  '("Paul W. Rankin" . "hello@paulwrankin.com")
  :keywords
  '("wp" "text")
  :url "https://github.com/rnkn/fountain-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
