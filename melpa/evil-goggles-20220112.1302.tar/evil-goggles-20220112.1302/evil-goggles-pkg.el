(define-package "evil-goggles" "20220112.1302" "Add a visual hint to evil operations"
  '((emacs "24.4")
    (evil "1.0.0"))
  :commit "1b66053ea5f06b08a52bebdd42bffd8eff82032b" :authors
  '(("edkolev" . "evgenysw@gmail.com"))
  :maintainers
  '(("edkolev" . "evgenysw@gmail.com"))
  :maintainer
  '("edkolev" . "evgenysw@gmail.com")
  :keywords
  '("emulations" "evil" "vim" "visual")
  :url "http://github.com/edkolev/evil-goggles")
;; Local Variables:
;; no-byte-compile: t
;; End:
