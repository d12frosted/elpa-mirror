;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hidepw" "20200326.112"
  "Minor mode to hide passwords."
  ()
  :url "https://github.com/jekor/hidepw"
  :commit "73f099da79d73fe4087472df3469d8b9b20a59f2"
  :revdesc "73f099da79d7"
  :keywords '("hide" "hidden" "password" "faces")
  :authors '(("Chris Forno" . "jekor@jekor.com"))
  :maintainers '(("Chris Forno" . "jekor@jekor.com")))
