(define-package "magit-section" "20220429.934" "Sections for read-only buffers"
  '((emacs "25.1")
    (compat "28.1.1.0")
    (dash "20210826"))
  :commit "eef732e30b9409e1b3c96edf2a62c764be86097c" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
