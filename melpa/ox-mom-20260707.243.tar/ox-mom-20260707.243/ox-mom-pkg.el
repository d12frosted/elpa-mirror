;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-mom" "20260707.243"
  "Groff MOM Macro Back-End for Org Export Engine."
  '((emacs "27.1")
    (org   "9.6"))
  :url "https://github.com/hinman/ox-mom"
  :commit "40711a3681cbeb4cbcb520371297bf3d932a333b"
  :revdesc "40711a3681cb"
  :keywords '("org" "groff" "mom" "wp" "outlines")
  :authors '(("Lee Hinman" . "hinman@gmail.com"))
  :maintainers '(("Lee Hinman" . "hinman@gmail.com")))
