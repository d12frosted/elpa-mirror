;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-emms" "20260725.1523"
  "Playback multimedia files from Org documents."
  '((emacs "24.4")
    (org   "9.3")
    (emms  "0.0"))
  :url "https://git.sr.ht/~jagrg/org-emms"
  :commit "92b86f3e2dc4b04019935e49b13890e5d36cd5cc"
  :revdesc "92b86f3e2dc4"
  :keywords '("multimedia")
  :authors '(("Jonathan Gregory" . "jgrgatautisticidotorg"))
  :maintainers '(("Jonathan Gregory" . "jgrgatautisticidotorg")))
