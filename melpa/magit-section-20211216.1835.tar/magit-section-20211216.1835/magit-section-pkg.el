(define-package "magit-section" "20211216.1835" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "1c2f6e901d41feb64956763f6a5c0ac0735cb7b2" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
