(define-package "ada-ts-mode" "20230814.1220" "Major mode for Ada using Tree-sitter"
  '((emacs "29.1"))
  :commit "4fbfc5bac2aebe6c10ba27165a1d85b85ebe5f93" :authors
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainer
  '("Troy Brown" . "brownts@troybrown.dev")
  :keywords
  '("ada" "languages" "tree-sitter")
  :url "https://github.com/brownts/ada-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
