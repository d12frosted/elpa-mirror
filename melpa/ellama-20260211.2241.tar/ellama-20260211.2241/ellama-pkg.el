;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260211.2241"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "501ca4bf1f055d42efe90a6757f2deb8972e1d78"
  :revdesc "501ca4bf1f05"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
