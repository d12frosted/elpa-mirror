;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual-avy" "20250830.2115"
  "Transient UI for Avy."
  '((emacs  "29.1")
    (avy    "0.5.0")
    (casual "2.0.0"))
  :url "https://github.com/kickingvegas/casual-avy"
  :commit "c5bc8e9d57a843f75e6125f097550414af3d5ec7"
  :revdesc "c5bc8e9d57a8"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
