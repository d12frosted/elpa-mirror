(define-package "zotra" "20230930.8" "Import bibliographic data from (almost) everywhere"
  '((emacs "27.1"))
  :commit "b76ee6fc3cfd419e2ca2876eeee84690f14859f6" :authors
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainers
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainer
  '("Mohammad Pedramfar <https://github.com/mpedramfar>")
  :url "https://github.com/mpedramfar/zotra")
;; Local Variables:
;; no-byte-compile: t
;; End:
