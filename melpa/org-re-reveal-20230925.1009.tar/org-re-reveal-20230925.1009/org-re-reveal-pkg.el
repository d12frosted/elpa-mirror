(define-package "org-re-reveal" "20230925.1009" "Org export to reveal.js presentations"
  '((emacs "24.4")
    (org "8.3")
    (htmlize "1.34"))
  :commit "0ce9c4e594c5e497d40da711340e04cdd9c3b536" :keywords
  '("tools" "outlines" "hypermedia" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/org-re-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
