(define-package "sniem" "20231003.849" "Hands-eased united editing method"
  '((emacs "27.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "1e531b6c31e680a7c15a8c5b18c6a0af9963b527" :authors
  '(("SpringHan"))
  :maintainers
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
