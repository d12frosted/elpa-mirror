(define-package "eldev" "20211219.1520" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "bcfbef5062b54451171db56159e22765a25ec22a" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
