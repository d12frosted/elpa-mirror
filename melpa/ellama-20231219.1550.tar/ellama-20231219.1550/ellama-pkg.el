(define-package "ellama" "20231219.1550" "Tool for interacting with LLMs"
  '((emacs "28.1")
    (llm "0.6.0")
    (spinner "1.7.4"))
  :commit "5d3e37cda7b35f6d33ac570cb1b294facef4630e" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
