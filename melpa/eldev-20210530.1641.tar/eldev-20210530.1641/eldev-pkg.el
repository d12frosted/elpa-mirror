(define-package "eldev" "20210530.1641" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "9e59d6c8f5ce57a1cb2765c02a336a534cec1e50" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
