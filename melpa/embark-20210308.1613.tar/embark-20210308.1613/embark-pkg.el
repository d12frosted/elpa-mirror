(define-package "embark" "20210308.1613" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "38598d2eeca97f79dad266d4bb07eb830da1fe8c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
