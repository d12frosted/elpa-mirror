;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260212.1328"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "9399bf2340bf0a4671ac34a4a11e94f4efe0bc66"
  :revdesc "9399bf2340bf")
