;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260903.304"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "d34e493510313fb4811ffce373a9a2c9e0bb0923"
  :revdesc "d34e49351031"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
