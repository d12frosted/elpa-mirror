(define-package "verilog-ts-mode" "20230917.1436" "Verilog Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "1e4a7cd562c2a710d5b0323f9c7a651e76a4202f" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
