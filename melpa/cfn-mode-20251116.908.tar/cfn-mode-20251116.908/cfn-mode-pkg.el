;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20251116.908"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "e30da051d2d9fb1d05454984135cbff47e4dd7b5"
  :revdesc "e30da051d2d9"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
