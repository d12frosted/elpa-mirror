;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260222.1721"
  "Unified interface for AI coding backends such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, agent-shell, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9ec648d29f24df6f8c639e702c227f2f9fc8f726"
  :revdesc "9ec648d29f24"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
