(define-package "loopy" "20210810.307" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "f6b541da982534c0d93e9558766655f9a243151b" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
