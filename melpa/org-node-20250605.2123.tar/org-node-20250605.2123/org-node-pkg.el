;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250605.2123"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.14.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "494222feb52d237e9df862d02213063f3027f48a"
  :revdesc "494222feb52d"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
