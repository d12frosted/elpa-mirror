;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260107.2148"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "1e67caefebef3bc05bb19e74aaf412036a3759b6"
  :revdesc "1e67caefebef"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
