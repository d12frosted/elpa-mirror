(define-package "yatex" "20220923.942" "Yet Another tex-mode for emacs //野鳥//" 'nil :commit "e3b7e199a87d059c1017f72b6aee818b3e84ab7d")
;; Local Variables:
;; no-byte-compile: t
;; End:
