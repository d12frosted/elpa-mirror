(define-package "racket-mode" "20231109.104" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "25224889d20b37bfd0d315a656542bb4fe8c2076" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
