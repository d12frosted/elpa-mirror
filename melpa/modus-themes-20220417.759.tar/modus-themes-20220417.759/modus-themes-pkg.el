(define-package "modus-themes" "20220417.759" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "2329803b865151aec13a26f44da2382026178c38" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
