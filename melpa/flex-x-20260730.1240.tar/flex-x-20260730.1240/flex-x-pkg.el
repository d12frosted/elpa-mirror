;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "20260730.1240"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "42ec8532099230f47d770039de377684a2e4f732"
  :revdesc "42ec85320992"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
