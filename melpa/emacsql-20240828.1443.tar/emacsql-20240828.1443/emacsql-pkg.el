(define-package "emacsql" "20240828.1443" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "540885d141d383d4a0af3b37ce2d67dac0555d67" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
