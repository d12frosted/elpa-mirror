(define-package "rustic" "20201127.1922" "Rust development environment"
  '((emacs "26.1")
    (xterm-color "1.6")
    (dash "2.13.0")
    (s "1.10.0")
    (f "0.18.2")
    (projectile "0.14.0")
    (markdown-mode "2.3")
    (spinner "1.7.3")
    (let-alist "1.0.4")
    (seq "2.3")
    (ht "2.0")
    (async "1.9.4"))
  :commit "7ad2c83922b1aa006aab05a209740ae294bd3907" :keywords
  ("languages")
  :authors
  (("Mozilla"))
  :maintainer
  ("Mozilla"))
;; Local Variables:
;; no-byte-compile: t
;; End:
