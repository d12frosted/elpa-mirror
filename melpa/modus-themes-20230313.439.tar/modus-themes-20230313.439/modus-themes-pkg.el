(define-package "modus-themes" "20230313.439" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "add4cc0c01f358aac4889363efb98ab10585a269" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
