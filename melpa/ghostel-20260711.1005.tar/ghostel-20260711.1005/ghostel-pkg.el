;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260711.1005"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "0d68577e11aebe2c17f716cd8e539a1c2d9a8848"
  :revdesc "0d68577e11ae"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
