(define-package "srfi" "20201129.2137" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "22657a98d4cd7d0690dac0d437a27ec3eef6f1df" :keywords
  ("languages" "util")
  :authors
  (("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  ("Lassi Kortela" . "lassi@lassi.io")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
