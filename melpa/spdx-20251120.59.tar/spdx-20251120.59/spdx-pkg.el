;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20251120.59"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "3f899e8f50a8f31e6d53d8fe32d36ff8e3abd12d"
  :revdesc "3f899e8f50a8"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
