(define-package "prettier" "20220524.1319" "Code formatting with Prettier"
  '((emacs "26.1")
    (iter2 "0.9")
    (nvm "0.2"))
  :commit "89835f38e4eb6ece99fb315a304d83dc19eed304" :authors
  '(("Julian Scheid" . "julians37@gmail.com"))
  :maintainer
  '("Julian Scheid" . "julians37@gmail.com")
  :keywords
  '("convenience" "languages" "files")
  :url "https://github.com/jscheid/prettier.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
