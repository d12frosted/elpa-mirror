(define-package "darkman" "20230711.1806" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "740d33a2b20efb59fc2ebd3b67f66c7ac4356b59" :authors
  '(("Taha Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainers
  '(("Taha Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Taha Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://darkman.grtcdr.tn")
;; Local Variables:
;; no-byte-compile: t
;; End:
