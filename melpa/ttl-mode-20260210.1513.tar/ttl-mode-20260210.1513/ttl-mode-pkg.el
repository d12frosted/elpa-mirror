;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ttl-mode" "20260210.1513"
  "Mode for Turtle (and Notation 3)."
  ()
  :url "https://github.com/emacsattic/ttl-mode"
  :commit "66a9a27c828b6cc08cdd0184cfcf05beb5c2ac60"
  :revdesc "66a9a27c828b")
