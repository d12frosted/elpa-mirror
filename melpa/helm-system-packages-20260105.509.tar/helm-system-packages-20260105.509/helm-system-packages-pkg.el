;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "20260105.509"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "35aa6c08bc632d76c066aef0b079f6733219c634"
  :revdesc "35aa6c08bc63"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
