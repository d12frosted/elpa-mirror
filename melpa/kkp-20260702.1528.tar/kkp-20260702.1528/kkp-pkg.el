;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "20260702.1528"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "bc5d5bf24ee75b860327e79ab26cc2280e87f339"
  :revdesc "bc5d5bf24ee7"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
