;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "20260404.1716"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.1")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "458a08356be7c062a48ad82b11566018d620ac29"
  :revdesc "458a08356be7"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
