(define-package "hl-indent-scope" "20230116.2310" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "5e806bfedd01bf82e4fda27e4b9809662318c287" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
