(define-package "bqn-mode" "20230418.1011" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "0a51e0930bfbf41ae32b28b8bdec76b92bd311da" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
