;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251112.1449"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "a04cdffc495e449e5f4a26ef961d3deedce2de0e"
  :revdesc "a04cdffc495e"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
