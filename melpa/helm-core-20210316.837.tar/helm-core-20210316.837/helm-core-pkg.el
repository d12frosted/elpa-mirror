(define-package "helm-core" "20210316.837" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "1cbc70883d1e4b36ded9f7fedb182c969c867589")
;; Local Variables:
;; no-byte-compile: t
;; End:
