(define-package "helm-core" "20210316.837" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "4805da0e8f176ba23a3783c9f92e026a52510599")
;; Local Variables:
;; no-byte-compile: t
;; End:
