(define-package "blamer" "20230930.1047" "Show git blame info about current line"
  '((emacs "27.1")
    (posframe "1.1.7"))
  :commit "4b70b657f83542491b77a4dc512674f3fa5ce01c" :authors
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainer
  '("Artur Yaroshenko" . "artawower@protonmail.com")
  :url "https://github.com/artawower/blamer.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
