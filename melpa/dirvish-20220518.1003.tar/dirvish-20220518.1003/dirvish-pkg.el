(define-package "dirvish" "20220518.1003" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "f529fdd55abf72cefedacbbbc884b276f3a85cba" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
