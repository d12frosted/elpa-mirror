(define-package "dired-hist" "20240321.159" "Traverse Dired buffer's history: back, forward"
  '((emacs "27.1"))
  :commit "39738dbdeb952d1ab5abe83e29bfa4ec870a4333" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
    ("Anoncheg1"))
  :maintainers
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience" "dired" "history")
  :url "https://github.com/Anoncheg1/dired-hist")
;; Local Variables:
;; no-byte-compile: t
;; End:
