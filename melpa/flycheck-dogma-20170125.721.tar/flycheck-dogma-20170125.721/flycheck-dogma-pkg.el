;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dogma" "20170125.721"
  "Flycheck checker for elixir dogma."
  '((flycheck "29"))
  :url "https://github.com/aaronjensen/flycheck-dogma"
  :commit "7e14207a7da67dc5524a8949cb37a3d11de1db6e"
  :revdesc "7e14207a7da6"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
