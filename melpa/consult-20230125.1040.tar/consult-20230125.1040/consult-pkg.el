(define-package "consult" "20230125.1040" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "94ba4efec3d05065f443410c7773fa3f3be166bb" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
