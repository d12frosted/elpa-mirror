;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-cmake" "20250320.1638"
  "Eldoc support for CMake."
  '((emacs "25.1"))
  :url "https://github.com/ikirill/eldoc-cmake"
  :commit "1a75d6e7a91ff4fd7bb8001b52a7dd3b62051af3"
  :revdesc "1a75d6e7a91f")
