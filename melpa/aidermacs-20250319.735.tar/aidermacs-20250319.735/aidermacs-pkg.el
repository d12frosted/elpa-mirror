;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250319.735"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "e598ae9e9a2f6ee00fe2865f9f9655e9a37a60dd"
  :revdesc "e598ae9e9a2f"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
