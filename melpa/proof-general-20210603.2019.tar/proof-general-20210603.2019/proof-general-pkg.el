(define-package "proof-general" "20210603.2019" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.5"))
  :commit "6a115fa3a08e29040c29ec98f46687debe8b2b82" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
