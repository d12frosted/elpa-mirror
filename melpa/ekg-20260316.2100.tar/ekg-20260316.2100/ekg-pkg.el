;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260316.2100"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "030be5fa926ef1aac1f30e49d4fa1cf9ab7078c1"
  :revdesc "030be5fa926e"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
