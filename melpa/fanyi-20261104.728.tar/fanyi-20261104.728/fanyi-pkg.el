;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fanyi" "20261104.728"
  "Not only English-Chinese translator."
  '((emacs "29.1"))
  :url "https://github.com/condy0919/fanyi.el"
  :commit "991a63c90033e1376bd905d0d7ea6b0fcf3a827a"
  :revdesc "991a63c90033"
  :keywords '("convenience" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
