(define-package "yeetube" "20230803.505" "YouTube/Invidious Front End"
  '((emacs "27.2"))
  :commit "e339ebb4df6d249db754170a41cc4ee0bdc9e4e6" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
