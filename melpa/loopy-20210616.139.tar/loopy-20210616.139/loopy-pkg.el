(define-package "loopy" "20210616.139" "A looping macro"
  '((emacs "27.1"))
  :commit "2d423906f70f40df5a01e95dcd210cc108c24035" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
