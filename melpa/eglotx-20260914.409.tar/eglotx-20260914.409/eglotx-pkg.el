;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglotx" "20260914.409"
  "Native LSP multiplexer for Eglot."
  '((emacs   "29.1")
    (eglot   "1.24")
    (jsonrpc "1.0.29"))
  :url "https://github.com/cxa/eglotx"
  :commit "445f9e149ebd21bd9ff6bb3851bb0cdad060b785"
  :revdesc "445f9e149ebd"
  :keywords '("tools" "languages")
  :authors '(("CHEN Xian'an" . "xianan.chen@gmail.com"))
  :maintainers '(("CHEN Xian'an" . "xianan.chen@gmail.com")))
