(define-package "consult" "20211202.1100" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "01ac431687ec4225b92e2fcfadf0b12dd3a5d616" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
