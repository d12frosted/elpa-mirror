(define-package "dtache" "20220501.931" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "9becf3a921a0fde3a6e5d6f30379cf3d9826d565" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
