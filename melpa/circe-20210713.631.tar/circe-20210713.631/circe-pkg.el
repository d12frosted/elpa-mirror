(define-package "circe" "20210713.631" "Client for IRC in Emacs"
  '((emacs "24.4")
    (cl-lib "0.5"))
  :commit "b0e0b73faa60de77e569e87dfc458fb95d180467" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :keywords
  '("irc" "chat" "comm")
  :url "https://github.com/jorgenschaefer/circe")
;; Local Variables:
;; no-byte-compile: t
;; End:
