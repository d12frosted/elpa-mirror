;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250625.846"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "bf915cc9dae70e2a333e00cd85666f1501769701"
  :revdesc "bf915cc9dae7"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
