(define-package "dirvish" "20220520.539" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "426408f2f9d6a5cf33ea34d1eaa476c7a9dbfd08" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
