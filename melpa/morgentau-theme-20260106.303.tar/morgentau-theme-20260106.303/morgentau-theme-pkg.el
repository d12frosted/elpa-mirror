;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morgentau-theme" "20260106.303"
  "Tango-based custom theme."
  '((emacs "24"))
  :url "https://github.com/Melchizedek6809/morgentau-theme"
  :commit "2395b8af83fbec097ef747a23a67305159808efb"
  :revdesc "2395b8af83fb"
  :keywords '("theme" "dark" "faces"))
