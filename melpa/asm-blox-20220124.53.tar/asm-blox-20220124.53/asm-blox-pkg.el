(define-package "asm-blox" "20220124.53" "Programming game involving WAT and YAML"
  '((emacs "26.1")
    (yaml "0.3.4"))
  :commit "8bc20ab442765dffc6c710c1922757c2df3675a4" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
