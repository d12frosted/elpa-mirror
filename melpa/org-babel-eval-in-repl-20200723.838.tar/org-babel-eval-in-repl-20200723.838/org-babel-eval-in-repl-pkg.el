(define-package "org-babel-eval-in-repl" "20200723.838" "Eval org-mode babel code blocks in various REPLs."
  '((eval-in-repl "0.9.2")
    (matlab-mode "3.3.6")
    (ess "16.10")
    (emacs "24"))
  :commit "85136ac7397fcdf0a4700a860de44d7912bb6b4c" :keywords
  ("literate programming" "reproducible research" "async execution")
  :authors
  (("Takeshi Teshima" . "diadochos.developer@gmail.com"))
  :maintainer
  ("Takeshi Teshima" . "diadochos.developer@gmail.com")
  :url "https://github.com/diadochos/org-babel-eval-in-repl")
;; Local Variables:
;; no-byte-compile: t
;; End:
