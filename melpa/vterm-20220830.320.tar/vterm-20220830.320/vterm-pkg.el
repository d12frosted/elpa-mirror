(define-package "vterm" "20220830.320" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "0838ee3b3b77f0a6945b57bca87315acf650479f" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
