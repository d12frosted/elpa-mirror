;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260901.1333"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.14.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "daa584f7140399db6370ea6c5ae80f19c0c65183"
  :revdesc "daa584f71403")
