;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sticky-shell" "20261112.2014"
  "Minor mode to keep track of previous prompt in your shell."
  '((emacs "25.1"))
  :url "https://github.com/andyjda/sticky-shell"
  :commit "f29d82b03403daa1e44f6b8440f4f2c8f7a6beef"
  :revdesc "f29d82b03403"
  :keywords '("processes" "terminals" "tools")
  :authors '(("Andrew De Angelis" . "bobodeangelis@gmail.com"))
  :maintainers '(("Andrew De Angelis" . "bobodeangelis@gmail.com")))
