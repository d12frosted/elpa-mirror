;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260731.1456"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "5881cbe676d12228cc8bea2eb1b615316801d155"
  :revdesc "5881cbe676d1"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
