(define-package "consult" "20220913.1933" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "1dcdb3df44cf02a2ca996b0ba11674ddcdb51ec0" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
