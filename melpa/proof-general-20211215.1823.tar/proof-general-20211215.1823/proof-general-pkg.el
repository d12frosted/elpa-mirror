(define-package "proof-general" "20211215.1823" "PG init file for package.el and ELPA compatibility"
  '((emacs "25.1"))
  :commit "07755c54ac86df0c9e8bc915dfa12ef72b23e13a" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
