;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-inactive-region" "20260410.318"
  "Highlight the inactive region."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-show-inactive-region"
  :commit "d2715aba9fb17e38651b434f0f71fa2234eb8576"
  :revdesc "d2715aba9fb1"
  :keywords '("convenience" "faces")
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
