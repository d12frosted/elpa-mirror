(define-package "selectrum" "20210211.2212" "Easily select item from list"
  '((emacs "25.1"))
  :commit "6a63e08e5fee060c4704d13d08fde1acfc547c6c" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
