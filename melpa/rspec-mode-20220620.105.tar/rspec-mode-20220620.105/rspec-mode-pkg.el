(define-package "rspec-mode" "20220620.105" "Enhance ruby-mode for RSpec"
  '((ruby-mode "1.0")
    (cl-lib "0.4"))
  :commit "2ad9e69dc9cf13fdc0dae84148467c9e353c9742" :authors
  '(("Peter Williams, et al."))
  :maintainer
  '("Peter Williams, et al.")
  :keywords
  '("rspec" "ruby")
  :url "http://github.com/pezra/rspec-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
