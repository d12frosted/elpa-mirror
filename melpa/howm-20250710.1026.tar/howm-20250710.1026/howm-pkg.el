;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "howm" "20250710.1026"
  "Wiki-like note-taking tool."
  '((cl-lib "0.5"))
  :url "https://kaorahi.github.io/howm/"
  :commit "fc872fa0b980523c75c6504cb71a42e1465ed7a4"
  :revdesc "fc872fa0b980"
  :authors '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com"))
  :maintainers '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com")))
