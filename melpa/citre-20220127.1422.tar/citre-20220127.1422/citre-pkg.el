(define-package "citre" "20220127.1422" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "b7ccce3528cfecb5ac686b6fef179a1bd778aa33" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
