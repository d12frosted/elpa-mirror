;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260427.728"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5321d1b2af5f0fab31ce3aa9b6d9970f0d737db7"
  :revdesc "5321d1b2af5f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
