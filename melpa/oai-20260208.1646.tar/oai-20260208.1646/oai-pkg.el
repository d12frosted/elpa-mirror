;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260208.1646"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "7d9d206617b81b312570c311c648e443bfcb34fb"
  :revdesc "7d9d206617b8"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
