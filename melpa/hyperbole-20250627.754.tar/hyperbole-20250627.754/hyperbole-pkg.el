;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250627.754"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "575f988b41e7e01c7854b90f69140b1d660e7b29"
  :revdesc "575f988b41e7"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
