;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260710.706"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "5233aca8494a545597901cc34b7e395536faedd1"
  :revdesc "5233aca8494a"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
