(define-package "kakoune" "20230206.2037" "A simulation, but not emulation, of kakoune"
  '((ryo-modal "0.45")
    (multiple-cursors "1.4")
    (expand-region "0.11.0")
    (emacs "25.1"))
  :commit "b39c5605e896c55ea246f755c46171bd6d0768a8" :authors
  '(("Joseph Morag" . "jm4157@columbia.edu"))
  :maintainer
  '("Joseph Morag" . "jm4157@columbia.edu")
  :url "https://github.com/jmorag/kakoune.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
