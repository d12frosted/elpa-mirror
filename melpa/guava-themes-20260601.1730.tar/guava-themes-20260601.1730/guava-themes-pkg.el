;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260601.1730"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "f5131035d8e73de42cd97d6dd366f36d15000be5"
  :revdesc "f5131035d8e7"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
