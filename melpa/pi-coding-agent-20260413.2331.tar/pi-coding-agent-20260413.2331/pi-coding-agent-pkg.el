;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260413.2331"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "8908e604a2d4b29bf9ea31d77f8dc55875f5b750"
  :revdesc "8908e604a2d4"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
