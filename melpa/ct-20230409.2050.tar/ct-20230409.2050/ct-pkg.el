(define-package "ct" "20230409.2050" "Color Tools - a color api"
  '((emacs "26.1")
    (dash "2.18.0")
    (hsluv "1.0.0"))
  :commit "62614d24109b11bc340cfd529740879f1c304c4f" :authors
  '(("neeasade"))
  :maintainer
  '("neeasade")
  :keywords
  '("convenience" "color" "theming" "rgb" "hsv" "hsl" "cie-lab" "background")
  :url "https://github.com/neeasade/ct.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
