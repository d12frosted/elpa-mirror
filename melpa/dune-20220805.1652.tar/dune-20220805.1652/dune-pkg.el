(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "cda880127fa9b9f87267ff51eb845db5aad94e83" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
