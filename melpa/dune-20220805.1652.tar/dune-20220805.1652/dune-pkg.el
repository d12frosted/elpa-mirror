(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "88ebd2cc2f7a41b7cf3552b546ccf3b8e00a8e69" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
