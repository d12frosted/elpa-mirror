(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "c460d6c8d96ec05e6e4155f1e12cb5c1a93316bc" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
