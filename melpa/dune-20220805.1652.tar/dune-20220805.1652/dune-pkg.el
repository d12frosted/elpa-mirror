(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "b3333f533baeb89749bdb509756bc6e19ad78ee8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
