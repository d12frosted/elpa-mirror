(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "d4bcecbb2b527c72f7024edc645d4a7205aaa8e5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
