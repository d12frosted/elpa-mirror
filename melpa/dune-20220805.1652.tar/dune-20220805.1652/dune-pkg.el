(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "f7ad29cf6bae73d5ff2bfb3a6f3ea6b07b66fde5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
