(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "35921086654964891ab0fc843de95c5331404001" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
