(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "7ce9e8eaf7b65645879c8974dc4f2c5e06876ffa" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
