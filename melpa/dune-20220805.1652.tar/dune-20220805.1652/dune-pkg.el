(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "cb043e71fe31812baa9ebff7e648c73f3930483c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
