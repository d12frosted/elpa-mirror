(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "07fc48aac0a44dc8a35d5c3380ef4906cd41fbbd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
