(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "90bbd551398b7c1f27a7858fe3b776d3ed77853e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
