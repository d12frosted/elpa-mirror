(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "dcde9174164aa82708d3108eef40287b363cc8ea" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
