(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "e8f442a122d4ec9d5704dddef82a6dd5f19121f5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
