(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "84fec4a375f32a72a46fa6ed1079bd5447de50af" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
