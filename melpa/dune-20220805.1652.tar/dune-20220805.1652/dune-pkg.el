(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "03b699f2cb25531fd372848a271597f2130adac4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
