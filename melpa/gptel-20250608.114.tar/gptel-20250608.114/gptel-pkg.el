;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250608.114"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "26322518a608fa6c336d58d252618e13dba1e8cc"
  :revdesc "26322518a608"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
