;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260129.1653"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "ef288408e646102e92083147978ff525f0494cb3"
  :revdesc "ef288408e646"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
