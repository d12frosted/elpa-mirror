(define-package "consult" "20230125.1237" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "345325fc4b3033d1847409442cf746bb4f3c7485" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
