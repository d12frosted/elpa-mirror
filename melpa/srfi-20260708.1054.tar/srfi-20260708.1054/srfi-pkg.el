;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260708.1054"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "6a68aa5862e589e0fe3e04b793b5f862a0965553"
  :revdesc "6a68aa5862e5"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
