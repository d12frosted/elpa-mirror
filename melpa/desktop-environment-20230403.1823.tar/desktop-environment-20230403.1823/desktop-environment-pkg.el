(define-package "desktop-environment" "20230403.1823" "Helps you control your GNU/Linux computer"
  '((emacs "25.1"))
  :commit "530035e567a95830f1a8b265e026b76d163c7367" :authors
  '(("Damien Cassou <damien@cassou.me>, Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers
  '(("Damien Cassou <damien@cassou.me>, Nicolas Petton" . "nicolas@petton.fr"))
  :maintainer
  '("Damien Cassou <damien@cassou.me>, Nicolas Petton" . "nicolas@petton.fr")
  :url "https://gitlab.petton.fr/DamienCassou/desktop-environment")
;; Local Variables:
;; no-byte-compile: t
;; End:
