;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-search-mc" "20231213.841"
  "Multiple-cursors extension for phi-search."
  '((phi-search       "2.0.0")
    (multiple-cursors "1.2.1")
    (emacs            "25.1"))
  :url "https://github.com/knu/phi-search-mc.el"
  :commit "8670eb007604555baa7ef017684a46fc97d254dc"
  :revdesc "8670eb007604"
  :keywords '("search" "cursors")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
