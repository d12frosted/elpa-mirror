;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "20260625.1756"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "0a672d41be405570209e8fafca738162b4ac7111"
  :revdesc "0a672d41be40"
  :keywords '("languages" "tools"))
