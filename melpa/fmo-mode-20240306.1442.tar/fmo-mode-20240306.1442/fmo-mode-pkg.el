;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fmo-mode" "20240306.1442"
  "Format only changed lines."
  '((emacs      "29.1")
    (difflib    "0.3.7")
    (format-all "0.5.0"))
  :url "https://github.com/xeechou/fmo-mode.el"
  :commit "eb63a36ee8ca0ec985e6fd043db974e6f9b38c83"
  :revdesc "eb63a36ee8ca"
  :keywords '("languages" "util")
  :authors '(("Xichen Zhou" . "sichem.zh@gmail.com"))
  :maintainers '(("Xichen Zhou" . "sichem.zh@gmail.com")))
