;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260731.722"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "42d55c206907303959d885b2f28bd46bf5468409"
  :revdesc "42d55c206907"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
