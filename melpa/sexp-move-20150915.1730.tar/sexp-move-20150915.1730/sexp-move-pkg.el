;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sexp-move" "20150915.1730"
  "Improved S-Expression Movement."
  ()
  :url "https://gitlab.com/elzair/sexp-move"
  :commit "117f7a91ab7c25e438413753e916570122011ce7"
  :revdesc "117f7a91ab7c"
  :keywords '("sexp")
  :authors '(("Philip Woods" . "elzairthesorcerer@gmail.com"))
  :maintainers '(("Philip Woods" . "elzairthesorcerer@gmail.com")))
