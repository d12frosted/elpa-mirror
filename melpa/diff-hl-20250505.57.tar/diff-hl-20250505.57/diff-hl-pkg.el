;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20250505.57"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "0a378d035726fe66015fc740503be592bca8637c"
  :revdesc "0a378d035726"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
