;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-markdown" "20261008.2114"
  "Preview Markdown LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.19.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "38af3f5c05fb4afa555d6a22d3ecb45d251dd3ae"
  :revdesc "38af3f5c05fb"
  :keywords '("tex" "markdown" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
