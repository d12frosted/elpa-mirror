;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250106.300"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "6d8188426b1ebc823cac54788e6221ae2b155f74"
  :revdesc "6d8188426b1e"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
