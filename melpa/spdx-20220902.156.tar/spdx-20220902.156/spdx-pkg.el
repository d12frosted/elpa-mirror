(define-package "spdx" "20220902.156" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "2f09d671abd72b1db521be5b5fdceca8cd84d1e8" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
