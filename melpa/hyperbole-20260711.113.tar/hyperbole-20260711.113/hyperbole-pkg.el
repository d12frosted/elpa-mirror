;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260711.113"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "afd47e44f7550e67b158a2203fdb903b4a9ef3dd"
  :revdesc "afd47e44f755"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
