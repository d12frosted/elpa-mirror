;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260103.1344"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "0c3481b2ecbcf470f377b1b0ccab2070174967ef"
  :revdesc "0c3481b2ecbc"
  :keywords '("languages"))
