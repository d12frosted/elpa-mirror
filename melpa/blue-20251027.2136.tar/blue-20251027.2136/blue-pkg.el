;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251027.2136"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "33cabcf7731ab027cda910b5059b8545970dc032"
  :revdesc "33cabcf7731a"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
