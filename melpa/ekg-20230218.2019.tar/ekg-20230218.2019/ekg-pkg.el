(define-package "ekg" "20230218.2019" "A system for recording and linking information"
  '((triples "0.2.3")
    (emacs "28.1"))
  :commit "7a112094e34ad54406e028e83afcff90ccab143f" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
