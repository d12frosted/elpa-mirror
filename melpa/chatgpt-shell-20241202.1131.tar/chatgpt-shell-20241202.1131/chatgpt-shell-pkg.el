;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241202.1131"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.72.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "dae161bf588b57cb95f23481bbac400649ec233c"
  :revdesc "dae161bf588b")
