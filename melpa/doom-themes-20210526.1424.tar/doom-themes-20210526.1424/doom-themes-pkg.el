(define-package "doom-themes" "20210526.1424" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "09ad78c67d71aada3880809a4701250cc81b5d4d" :authors
  '(("Henrik Lissner <http://github/hlissner>"))
  :maintainer
  '("Henrik Lissner" . "henrik@lissner.net")
  :keywords
  '("dark" "light" "blue" "atom" "one" "theme" "neotree" "icons" "faces" "nova")
  :url "https://github.com/hlissner/emacs-doom-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
