(define-package "look-mode" "20220210.601" "quick file viewer for image and text file browsing" 'nil :commit "e0eb613974bea22a117b04341272f20092f8542e" :authors
  '(("Peter H. Mao <peter.mao@gmail.com>" . "petermao@jpl.nasa.gov"))
  :maintainer
  '("Peter H. Mao <peter.mao@gmail.com>" . "petermao@jpl.nasa.gov"))
;; Local Variables:
;; no-byte-compile: t
;; End:
