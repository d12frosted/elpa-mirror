;;; look-mode-autoloads.el --- automatically extracted autoloads
;;
;;; Code:

(add-to-list 'load-path (directory-file-name
                         (or (file-name-directory #$) (car load-path))))


;;;### (autoloads nil "look-mode" "look-mode.el" (0 0 0 0))
;;; Generated autoloads from look-mode.el

(autoload 'look-at-files "look-mode" "\
Look at files in directory. Insert into temporary buffer one at a
time.  This function gets the file list from
dired-get-marked-files OR by expanding LOOK-WILDCARD with
`file-expand-wildcards', and passes it to `look-at-next-file'.
If ADD is non-nil (set by prefix arg such as C-u) then files are
added to the end of the currently looked at files, otherwise they
replace them." t nil)

(add-hook 'dired-mode-hook
          (lambda ()
            (define-key dired-mode-map "\M-l" 'look-at-files)))
          
(if (fboundp 'register-definition-prefixes) (register-definition-prefixes "look-mode" '("lface-" "list-subdirectories-recursively" "look-")))

;;;***

;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; look-mode-autoloads.el ends here
