;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-sanityinc-tomorrow" "20260618.806"
  "A version of Chris Kempson's \"tomorrow\" themes."
  '((emacs "24.1"))
  :url "https://github.com/purcell/color-theme-sanityinc-tomorrow"
  :commit "87cbc712c77a9b305d356f2ae448e424a8bd3c5c"
  :revdesc "87cbc712c77a"
  :keywords '("faces" "themes")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
