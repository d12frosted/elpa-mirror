;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260120.2333"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "c234f9f891f08fb2cf52096742336af1406f8dd7"
  :revdesc "c234f9f891f0"
  :keywords '("convenience"))
