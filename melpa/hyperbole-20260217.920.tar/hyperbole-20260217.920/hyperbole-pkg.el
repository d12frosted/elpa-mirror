;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260217.920"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ebd53c0fdfc327a6e236b8c90ce5d5a0d9d0b956"
  :revdesc "ebd53c0fdfc3"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
