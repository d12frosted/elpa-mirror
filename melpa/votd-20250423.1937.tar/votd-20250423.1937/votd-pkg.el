;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "votd" "20250423.1937"
  "Bible Verse Of The Day."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/votd"
  :commit "01e07f0e4b8a26d8135893e87027f68eb3694f02"
  :revdesc "01e07f0e4b8a"
  :keywords '("convenience" "comm" "hypermedia"))
