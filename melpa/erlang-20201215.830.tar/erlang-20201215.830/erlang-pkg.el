(define-package "erlang" "20201215.830" "Erlang major mode"
  '((emacs "24.1"))
  :commit "6378a0c825db64df91e01ee39e3a268f4ba050b7" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
