;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260408.1039"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "907da53e0f4feb8f1ca766552a09fe54f2bfaa1d"
  :revdesc "907da53e0f4f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
