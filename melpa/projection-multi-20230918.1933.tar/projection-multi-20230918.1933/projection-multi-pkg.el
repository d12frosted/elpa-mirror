(define-package "projection-multi" "20230918.1933" "Projection integration for `compile-multi'"
  '((emacs "29.1")
    (projection "0.1")
    (compile-multi "0.5"))
  :commit "3dc583de7027d1fe6c8ca9bd67d761c3568569b6" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
