(define-package "cask" "20210402.1837" "Cask: Project management for package development"
  '((emacs "24.1")
    (s "1.8.0")
    (f "0.16.0")
    (epl "0.5")
    (shut-up "0.1.0")
    (cl-lib "0.3")
    (package-build "1.2")
    (ansi "0.4.1"))
  :commit "1c329de12cb2fba1552df5f1fb65a5613aa4db50" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("speed" "convenience")
  :url "http://github.com/cask/cask")
;; Local Variables:
;; no-byte-compile: t
;; End:
