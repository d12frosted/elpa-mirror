(define-package "emoji-cheat-sheet-plus" "20200202.1404" "emoji-cheat-sheet for emacs"
  '((emacs "24")
    (helm "1.6.4"))
  :commit "d445e9cf907e2d1dd3b4dd98c98cfc00626e4ac8" :authors
  '(("Sylvain Benner (based on the work of Shingo Fukuyama)"))
  :maintainer
  '("Sylvain Benner (based on the work of Shingo Fukuyama)")
  :keywords
  '("emacs" "emoji")
  :url "https://github.com/syl20bnr/emacs-emoji-cheat-sheet-plus")
;; Local Variables:
;; no-byte-compile: t
;; End:
