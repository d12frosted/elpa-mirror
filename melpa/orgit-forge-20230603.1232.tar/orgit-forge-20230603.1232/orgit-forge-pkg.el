(define-package "orgit-forge" "20230603.1232" "Org links to Forge issue buffers"
  '((emacs "25.1")
    (compat "29.1.4.1")
    (forge "0.3")
    (magit "3.3")
    (org "9.6")
    (orgit "1.9"))
  :commit "8ba92a54aee9693b1bf03baf14f83550a7c89b18" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("hypermedia" "vc")
  :url "https://github.com/magit/orgit-forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
