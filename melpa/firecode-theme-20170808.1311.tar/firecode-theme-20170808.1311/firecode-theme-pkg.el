;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firecode-theme" "20170808.1311"
  "An Emacs 24 theme based on FireCode (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "8b7b03ecdd41e70dab145b98906017e1392eaef4"
  :revdesc "8b7b03ecdd41")
