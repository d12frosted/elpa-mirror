;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swift-helpful" "20220707.846"
  "Show documentation for Swift programs."
  '((emacs      "25.1")
    (dash       "2.12.0")
    (lsp-mode   "6.0")
    (swift-mode "8.0.0"))
  :url "https://github.com/danielmartin/swift-helpful"
  :commit "b46c580e4b8f55761431ec677866de3fc66592e9"
  :revdesc "b46c580e4b8f"
  :keywords '("help" "swift")
  :authors '(("Daniel Martín" . "mardani29@yahoo.es"))
  :maintainers '(("Daniel Martín" . "mardani29@yahoo.es")))
