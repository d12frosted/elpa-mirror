(define-package "swift-helpful" "20220707.846" "Show documentation for Swift programs."
  '((emacs "25.1")
    (dash "2.12.0")
    (lsp-mode "6.0")
    (swift-mode "8.0.0"))
  :commit "b46c580e4b8f55761431ec677866de3fc66592e9" :authors
  '(("Daniel Martín" . "mardani29@yahoo.es"))
  :maintainer
  '("Daniel Martín" . "mardani29@yahoo.es")
  :keywords
  '("help" "swift")
  :url "https://github.com/danielmartin/swift-helpful")
;; Local Variables:
;; no-byte-compile: t
;; End:
