(define-package "stimmung-themes" "20220705.1627" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "d09863f13a1a32906d962e55abd5b13ca7e844a5" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
