(define-package "ob-swiftui" "20230421.1542" "Org babel functions for SwiftUI evaluation"
  '((emacs "25.1")
    (swift-mode "8.2.0")
    (org "9.2.0"))
  :commit "da6bd8d13da6bf6b949c4c9b1d4754fecb0345c7" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/ob-swiftui")
;; Local Variables:
;; no-byte-compile: t
;; End:
