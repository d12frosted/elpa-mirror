;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typewriter-roll-mode" "20250718.2028"
  "Aid for distraction-free writing."
  '((emacs "24.1"))
  :url "https://github.com/KeyWeeUsr/typewriter-roll-mode"
  :commit "dd6738e86db6492c945e3a9238e0cfbe154ad98b"
  :revdesc "dd6738e86db6"
  :keywords '("convenience" "line" "carriage" "writing" "distraction" "cr" "rewind")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
