(define-package "modus-themes" "20210101.1900" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "33bc26d1f3b17ab71a779c3e596341e4590ff265" :authors
  (("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  ("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  ("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
