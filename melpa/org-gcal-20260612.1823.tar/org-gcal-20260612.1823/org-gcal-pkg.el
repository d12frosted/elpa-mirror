;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gcal" "20260612.1823"
  "Org sync with Google Calendar."
  '((aio              "1.0")
    (alert            "1.2")
    (emacs            "26.1")
    (oauth2-auto      "20240326.2225")
    (org              "9.3")
    (persist          "0.8")
    (request          "20190901")
    (request-deferred "20181129"))
  :url "https://github.com/kidd/org-gcal.el"
  :commit "7304b592c283944db54ac83201d7be6f13a1f447"
  :revdesc "7304b592c283"
  :keywords '("convenience")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com"))
  :maintainers '(("Raimon Grau" . "raimonster@gmail.com")))
