;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260315.1023"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "158704c537733325b15ad49def0a30e83c6a5741"
  :revdesc "158704c53773"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
