;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260917.430"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "f83b1f7b693d91284f34965187e31768099f3382"
  :revdesc "f83b1f7b693d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
