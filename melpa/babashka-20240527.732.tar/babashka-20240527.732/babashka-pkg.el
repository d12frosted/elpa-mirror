;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "babashka" "20240527.732"
  "Babashka Tasks Interface."
  '((emacs    "27.1")
    (parseedn "1.1.0"))
  :url "https://github.com/licht1stein/babashka.el"
  :commit "4ea9d7febf3e9d301c91231ba2833f3417ba9059"
  :revdesc "4ea9d7febf3e"
  :authors '(("Mykhaylo Bilyanskyy" . "mb@m1k.pw"))
  :maintainers '(("Mykhaylo Bilyanskyy" . "mb@m1k.pw")))
