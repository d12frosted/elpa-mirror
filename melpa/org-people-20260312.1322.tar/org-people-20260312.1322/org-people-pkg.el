;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260312.1322"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "3dc04513b7f42e2d487970dea99e457ef1326fdd"
  :revdesc "3dc04513b7f4"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
