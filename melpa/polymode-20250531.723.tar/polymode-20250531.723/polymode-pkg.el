;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polymode" "20250531.723"
  "Extensible framework for multiple major modes."
  '((emacs "25"))
  :url "https://github.com/polymode/polymode"
  :commit "37a9f045afbf4f6077e55e7bd7ec6b0cdf8bfa70"
  :revdesc "37a9f045afbf"
  :keywords '("languages" "multi-modes" "processes")
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
