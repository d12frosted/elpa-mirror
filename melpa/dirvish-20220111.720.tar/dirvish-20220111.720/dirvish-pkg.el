(define-package "dirvish" "20220111.720" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "190e757759bbee8329be0e0b08b2ff0bac685797" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
