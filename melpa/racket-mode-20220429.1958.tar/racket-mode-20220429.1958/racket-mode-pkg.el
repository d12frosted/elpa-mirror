(define-package "racket-mode" "20220429.1958" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "e878810ce83f1a6f8903e7614e25cc90454679d5" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
