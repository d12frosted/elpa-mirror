(define-package "helm-core" "20220818.1631" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "292ddf32ba03361468e78cdf77ee5902e7e75842" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
