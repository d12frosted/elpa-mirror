;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-server" "20260519.1235"
  "Speaks HTTP for you."
  '((emacs "30.1"))
  :url "https://codeberg.org/martenlienen/http-server.el"
  :commit "00e746baf4a622a7545b4af5c5237a55d51f801b"
  :revdesc "00e746baf4a6"
  :keywords '("comm")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
