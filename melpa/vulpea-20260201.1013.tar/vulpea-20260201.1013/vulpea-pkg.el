;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260201.1013"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "c3bba97c105b572cfc070ca94a21ee0179da21d2"
  :revdesc "c3bba97c105b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
