;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260605.1810"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "571b0abb7ad300648257bc7ca0d841d71db5136f"
  :revdesc "571b0abb7ad3"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
