(define-package "consult" "20210228.133" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "c5d74b191fb4ee70509e2592fa16a9398f96977b" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
