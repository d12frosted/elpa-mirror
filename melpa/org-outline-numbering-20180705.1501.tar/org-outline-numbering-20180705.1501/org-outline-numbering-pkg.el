;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-outline-numbering" "20180705.1501"
  "Show outline numbering as overlays in org-mode."
  '((emacs  "24")
    (org    "8.3")
    (cl-lib "0.6")
    (ov     "1.0.6"))
  :url "https://gitlab.com/andersjohansson/org-outline-numbering"
  :commit "b95b6a7ed9289637cb512232470633b330ca9713"
  :revdesc "b95b6a7ed928"
  :keywords '("wp" "convenience"))
