;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dollaro" "20260210.1514"
  "Simple text templates."
  '((s "1.6.0"))
  :url "https://github.com/emacsattic/dollaro"
  :commit "d18b07fc6a63ce773b745714e135284b6eec7485"
  :revdesc "d18b07fc6a63"
  :keywords '("tools" "convenience")
  :authors '(("Alessandro Piras" . "laynor@gmail.com"))
  :maintainers '(("Alessandro Piras" . "laynor@gmail.com")))
