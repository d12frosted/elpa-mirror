(define-package "consult" "20220523.1452" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "2dab69568b4a6aea2fc379882583c89d334ce090" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
