;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20261006.1756"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "e0a1feeed58ce7d3eb26f96bb4d048b732c14fcc"
  :revdesc "e0a1feeed58c"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
