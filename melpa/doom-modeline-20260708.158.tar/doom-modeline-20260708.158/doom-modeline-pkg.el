;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260708.158"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "eb5db7916cff689f8a1115117354998aed32e176"
  :revdesc "eb5db7916cff"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
