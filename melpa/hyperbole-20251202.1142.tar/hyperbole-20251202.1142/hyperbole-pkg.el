;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251202.1142"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "2d5d22a6664ff55338a355e64554b5ceb0a31177"
  :revdesc "2d5d22a6664f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
