;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260414.412"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "ac409f0a78bcffffbbf44d23a302b39fde43b966"
  :revdesc "ac409f0a78bc"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
