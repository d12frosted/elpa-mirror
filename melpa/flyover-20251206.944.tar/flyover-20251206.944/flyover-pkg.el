;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20251206.944"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "ddb40d548a4518e80a36d6b2e80fc6b675502019"
  :revdesc "ddb40d548a45"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
