;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260328.1613"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "f3010d3485d7939f252dee59e4b335cb28e5069c"
  :revdesc "f3010d3485d7"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
