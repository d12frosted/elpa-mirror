(define-package "pyim" "20211215.427" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "24.4")
    (async "1.6")
    (xr "1.13"))
  :commit "1f326742a926efa613038aef017c9fefe11ebfee" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
