;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260215.2353"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "8fa6758a0cda1fab373cb088fc33a60133adb3b5"
  :revdesc "8fa6758a0cda"
  :keywords '("comm")
  :authors '(("Patrick Thomson" . "patrickt@github.com"))
  :maintainers '(("Patrick Thomson" . "patrickt@github.com")))
