(define-package "for" "20230808.1022" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "9af133104995be358c019fa24301db7d8c55e9ff" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainers
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
