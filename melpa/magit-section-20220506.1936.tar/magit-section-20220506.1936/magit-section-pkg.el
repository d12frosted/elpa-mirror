(define-package "magit-section" "20220506.1936" "Sections for read-only buffers."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (dash "20210826"))
  :commit "84922c3997980a44f9fa2702a4e7db678adf98f8" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
