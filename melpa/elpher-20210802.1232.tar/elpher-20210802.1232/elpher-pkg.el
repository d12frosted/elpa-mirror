(define-package "elpher" "20210802.1232" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "7a7fc41273acf74bf2982a9607cf066c15f875d7" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
