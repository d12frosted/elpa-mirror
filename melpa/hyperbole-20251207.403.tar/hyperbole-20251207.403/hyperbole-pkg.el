;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251207.403"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "d3e1a9bf19936ad7a108da341f5c774f9114f823"
  :revdesc "d3e1a9bf1993"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
