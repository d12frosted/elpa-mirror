(define-package "docstr" "20220214.1539" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "963c49a09888d1974a53240d0f6c6825803f30d1" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
