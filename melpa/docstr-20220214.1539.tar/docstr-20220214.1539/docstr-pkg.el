(define-package "docstr" "20220214.1539" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "2972fdafc4ccc9bcd7601826ea9ba150e651f3a6" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
