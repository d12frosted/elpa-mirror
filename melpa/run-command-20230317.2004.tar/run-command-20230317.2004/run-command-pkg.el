(define-package "run-command" "20230317.2004" "Run an external command from a context-dependent list"
  '((emacs "27.1"))
  :commit "477c42acce9e36ec59d18deaa73992f94faf7b99" :authors
  '(("Massimiliano Mirra" . "hyperstruct@gmail.com"))
  :maintainer
  '("Massimiliano Mirra" . "hyperstruct@gmail.com")
  :keywords
  '("processes")
  :url "https://github.com/bard/emacs-run-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
