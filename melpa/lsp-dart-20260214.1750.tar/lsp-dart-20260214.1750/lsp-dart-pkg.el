;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-dart" "20260214.1750"
  "Dart support lsp-mode."
  '((emacs        "28.1")
    (lsp-treemacs "0.3")
    (lsp-mode     "7.0.1")
    (dap-mode     "0.6")
    (f            "0.20.0")
    (dash         "2.14.1")
    (dart-mode    "1.0.5")
    (jsonrpc      "1.0.15")
    (ht           "2.2"))
  :url "https://emacs-lsp.github.io/lsp-dart"
  :commit "584b398b4341ab15fbb55c883e1ff54f0cd8fa8b"
  :revdesc "584b398b4341"
  :keywords '("languages" "extensions"))
