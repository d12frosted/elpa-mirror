;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260301.502"
  "Unified interface for AI coding backends such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "ff3d63696d32d63384ddd996b73c75237dea0c8f"
  :revdesc "ff3d63696d32"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
