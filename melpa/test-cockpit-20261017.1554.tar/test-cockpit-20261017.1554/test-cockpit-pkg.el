;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20261017.1554"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "3bc8478d348e0f72a102c4d7c25de8af3c3728a5"
  :revdesc "3bc8478d348e"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
