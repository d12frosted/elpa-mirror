;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260602.1910"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "3eedd7b53df9938dae1798f9ebb955a766002b65"
  :revdesc "3eedd7b53df9"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
