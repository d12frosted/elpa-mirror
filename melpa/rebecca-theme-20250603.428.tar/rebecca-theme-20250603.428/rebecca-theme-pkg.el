;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rebecca-theme" "20250603.428"
  "Rebecca Purple Theme."
  '((emacs "24"))
  :url "https://github.com/vic/rebecca-theme"
  :commit "718787fb8c9f3e29e09bb9cbdd966c810f15aa81"
  :revdesc "718787fb8c9f"
  :keywords '("theme" "dark")
  :authors '(("vic" . "vborja@apache.org"))
  :maintainers '(("vic" . "vborja@apache.org")))
