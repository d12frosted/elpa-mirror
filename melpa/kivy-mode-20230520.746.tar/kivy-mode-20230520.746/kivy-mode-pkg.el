(define-package "kivy-mode" "20230520.746" "Emacs major mode for editing Kivy files" 'nil :commit "bd041aea52d96161fb610a5f1485a7375a0531e1" :authors
  '(("Dean Serenevy" . "dean@serenevy.net"))
  :maintainers
  '(("Dean Serenevy" . "dean@serenevy.net"))
  :maintainer
  '("Dean Serenevy" . "dean@serenevy.net"))
;; Local Variables:
;; no-byte-compile: t
;; End:
