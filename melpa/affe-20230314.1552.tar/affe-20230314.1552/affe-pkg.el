(define-package "affe" "20230314.1552" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.33"))
  :commit "4f9763413beab8d8866e6f0d9c02599f3ba0c852" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
