(define-package "verilog-ts-mode" "20230905.1216" "Verilog Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "7948efea0316a5c7c3bd2ac803a1c46cfbaf067d" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
