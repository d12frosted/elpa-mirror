(define-package "apheleia" "20230420.1333" "Reformat buffer stably"
  '((emacs "26"))
  :commit "49890c3762cd9591f572b6d48c53b03f3caf1725" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/raxod502/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
