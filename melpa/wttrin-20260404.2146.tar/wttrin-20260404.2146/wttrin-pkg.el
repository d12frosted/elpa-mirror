;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260404.2146"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "a0f1b4f07c98ab3d4d4b50a330822d0991b733a7"
  :revdesc "a0f1b4f07c98"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
