;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260115.1653"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "c741caa708c22b98af42a8b2e3350b184b70ba42"
  :revdesc "c741caa708c2"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
