;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ruby" "20170723.146"
  "A flymake handler for ruby-mode files."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-ruby"
  :commit "6c320c6fb686c5223bf975cc35178ad6b195e073"
  :revdesc "6c320c6fb686"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
