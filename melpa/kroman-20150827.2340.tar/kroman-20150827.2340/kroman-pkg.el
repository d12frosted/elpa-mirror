;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kroman" "20150827.2340"
  "Korean hangul romanization."
  ()
  :url "https://github.com/victorteokw/kroman-el"
  :commit "431144a3cd629a2812a668a29ad85182368dc9b0"
  :revdesc "431144a3cd62"
  :keywords '("korean" "roman")
  :authors '(("Zhang Kai Yu" . "yeannylam@gmail.com"))
  :maintainers '(("Zhang Kai Yu" . "yeannylam@gmail.com")))
