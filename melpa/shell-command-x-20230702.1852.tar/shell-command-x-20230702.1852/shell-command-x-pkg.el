(define-package "shell-command-x" "20230702.1852" "Extensions for shell commands"
  '((emacs "28.1"))
  :commit "416dad677314e3eec704d5b02594b5f8a7e7fd65" :authors
  '(("Eliza Velasquez"))
  :maintainers
  '(("Eliza Velasquez"))
  :maintainer
  '("Eliza Velasquez")
  :keywords
  '("convenience" "processes" "unix")
  :url "https://github.com/elizagamedev/shell-command-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
