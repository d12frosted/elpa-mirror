;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20260826.246"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "47e3b209d36a236f5c1eca2fe40855f063e3bbeb"
  :revdesc "47e3b209d36a"
  :keywords '("tools" "convenience" "text"))
