;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260401.1006"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "ad100e185200e548a1398df3ff76f60ccbc04c63"
  :revdesc "ad100e185200"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
