(define-package "affe" "20230226.937" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.32"))
  :commit "3fcd1e4eb38fedf29cef58737ad28e382d997351" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
