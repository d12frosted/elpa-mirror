(define-package "meow" "20220214.1732" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "904d823ee80646b3aeb4ea798999543e08b3742e" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
