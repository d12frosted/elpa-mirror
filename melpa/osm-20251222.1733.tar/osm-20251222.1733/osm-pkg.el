;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251222.1733"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "af431c1775a83acd6df99ae401a91677c0f8b7e2"
  :revdesc "af431c1775a8"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
