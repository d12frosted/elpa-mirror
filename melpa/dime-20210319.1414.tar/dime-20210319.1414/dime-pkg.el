(define-package "dime" "20210319.1414" "Dylan interaction mode"
  '((emacs "25.1")
    (dylan "3.0"))
  :commit "c51cdb2d947494d8161a429134f9e9d23070a173" :url "https://opendylan.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
