(define-package "buffer-env" "20231003.1605" "Buffer-local process environments"
  '((emacs "27.1")
    (compat "29.1"))
  :commit "9b640912b0d545ceb01644ef1d2d0af40284d054" :authors
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainer
  '("Augusto Stoffel" . "arstoffel@gmail.com")
  :keywords
  '("processes" "tools")
  :url "https://github.com/astoff/buffer-env")
;; Local Variables:
;; no-byte-compile: t
;; End:
