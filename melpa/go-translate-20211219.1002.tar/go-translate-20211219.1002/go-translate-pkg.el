(define-package "go-translate" "20211219.1002" "Translation framework supports multiple engines such as Google/Bing/DeepL"
  '((emacs "27.1"))
  :commit "0ae9ab6faf3a6b01391894ae349ecf4c056ba36c" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
