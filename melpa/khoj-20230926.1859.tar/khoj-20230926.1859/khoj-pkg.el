(define-package "khoj" "20230926.1859" "AI personal assistant for your digital brain"
  '((emacs "27.1")
    (transient "0.3.0")
    (dash "2.19.1"))
  :commit "2f183833497a0efe67578938a60d6b1b9000d025" :authors
  '(("Debanjum Singh Solanky" . "debanjum@gmail.com"))
  :maintainers
  '(("Debanjum Singh Solanky" . "debanjum@gmail.com"))
  :maintainer
  '("Debanjum Singh Solanky" . "debanjum@gmail.com")
  :keywords
  '("search" "chat" "org-mode" "outlines" "markdown" "pdf" "image")
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
