;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250620.624"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.77.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "57cef17ecbebc15d0ea4cd861e0ef9aacc507e46"
  :revdesc "57cef17ecbeb")
