;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260806.1222"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "d69c0ac789ff2f4dc1f27be15877a4b9ed2fd272"
  :revdesc "d69c0ac789ff"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
