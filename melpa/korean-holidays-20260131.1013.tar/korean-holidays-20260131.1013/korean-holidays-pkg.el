;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "korean-holidays" "20260131.1013"
  "Korean holidays for calendar."
  ()
  :url "https://github.com/tttuuu888/korean-holidays"
  :commit "9fffbad583cb1ad97bdc31ebf908cc663a1c4d29"
  :revdesc "9fffbad583cb"
  :keywords '("calendar")
  :authors '(("SeungKi Kim" . "tttuuu888@gmail.com"))
  :maintainers '(("SeungKi Kim" . "tttuuu888@gmail.com")))
