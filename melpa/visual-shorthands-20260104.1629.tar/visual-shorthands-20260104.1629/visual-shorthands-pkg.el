;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-shorthands" "20260104.1629"
  "Visual abbreviations for symbol prefixes."
  '((emacs "29.1"))
  :url "https://github.com/gggion/visual-shorthands.el"
  :commit "1b2ca9df5b66ef3e48b331fa8d17c1458f24505d"
  :revdesc "1b2ca9df5b66"
  :keywords '("convenience")
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
