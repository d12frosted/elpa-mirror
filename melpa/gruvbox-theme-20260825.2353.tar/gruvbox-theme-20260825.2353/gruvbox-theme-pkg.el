;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gruvbox-theme" "20260825.2353"
  "A retro-groove colour theme for Emacs."
  '((autothemer "0.2"))
  :url "https://github.com/greduan/emacs-theme-gruvbox"
  :commit "b34b8c0d9fe84190bb69cf084d7354d5e948fd94"
  :revdesc "b34b8c0d9fe8"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
