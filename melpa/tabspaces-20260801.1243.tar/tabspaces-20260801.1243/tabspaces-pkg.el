;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260801.1243"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "221484ce8651a56e90078f2b9fb4c64ed7d27d01"
  :revdesc "221484ce8651"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
