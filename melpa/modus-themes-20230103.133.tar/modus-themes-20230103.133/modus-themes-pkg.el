(define-package "modus-themes" "20230103.133" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "59a8361c95c20d26bec06a65f56bd811ca07695e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
