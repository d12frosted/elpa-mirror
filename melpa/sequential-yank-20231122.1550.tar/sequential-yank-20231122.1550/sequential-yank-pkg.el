(define-package "sequential-yank" "20231122.1550" "Minor mode to copy and paste strings sequentially"
  '((emacs "24.4"))
  :commit "f3f77325877a91243ffdf57d502bff757b30da33" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/sequential-yank.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
