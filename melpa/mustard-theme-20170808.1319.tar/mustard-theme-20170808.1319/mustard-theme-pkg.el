;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mustard-theme" "20170808.1319"
  "An Emacs 24 theme based on Mustard (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "3b15d992c79590d7ea2503004e2a863b57e274b5"
  :revdesc "3b15d992c795")
