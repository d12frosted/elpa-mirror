;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-plsense" "20180118.58"
  "Company backend for Perl."
  '((company "0.9.3")
    (cl-lib  "0.5.0")
    (dash    "2.12.0")
    (s       "1.12")
    (emacs   "24"))
  :url "https://github.com/CeleritasCelery/company-plsense"
  :commit "b48e3181e08ec597269621d621aa06636f02d883"
  :revdesc "b48e3181e08e"
  :authors '(("Troy Hinckley" . "troy.hinckley@gmail.com"))
  :maintainers '(("Troy Hinckley" . "troy.hinckley@gmail.com")))
