(define-package "elpher" "20211008.1217" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "79336f8191caa394710722799e6b764493e80a52" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
