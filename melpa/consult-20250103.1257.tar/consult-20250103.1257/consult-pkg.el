;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250103.1257"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "c569eff92ebbcad549e3d8df4b5d5761ee4ea0fa"
  :revdesc "c569eff92ebb"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
