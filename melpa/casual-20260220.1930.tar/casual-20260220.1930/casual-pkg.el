;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260220.1930"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "ec52aca21dc6402ef6dce6a46b5714337d578329"
  :revdesc "ec52aca21dc6"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
