;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-lfe" "20170725.1420"
  "Org-babel functions for lfe evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-lfe"
  :commit "f7780f58e650b4d29dfd834c662b1d354b620a8e"
  :revdesc "f7780f58e650"
  :keywords '("org" "babel" "lfe" "lisp" "erlang")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
