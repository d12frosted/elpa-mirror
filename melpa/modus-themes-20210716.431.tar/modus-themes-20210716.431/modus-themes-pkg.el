(define-package "modus-themes" "20210716.431" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "9521dcec6c012d3776e3d05692720dd24922218b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
