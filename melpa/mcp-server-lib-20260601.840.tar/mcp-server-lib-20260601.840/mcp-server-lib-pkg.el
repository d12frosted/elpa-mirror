;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "20260601.840"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "679863e327fd6fba6d05862a9e84675a91aec848"
  :revdesc "679863e327fd"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
