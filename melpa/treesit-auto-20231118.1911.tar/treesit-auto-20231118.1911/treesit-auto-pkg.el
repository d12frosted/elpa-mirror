(define-package "treesit-auto" "20231118.1911" "Automatically use tree-sitter enhanced major modes"
  '((emacs "29.0"))
  :commit "f140fb604509728620d6748c0a5704c707f9af82" :authors
  '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers
  '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainer
  '("Robb Enzmann" . "robbenzmann@gmail.com")
  :keywords
  '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :url "https://github.com/renzmann/treesit-auto.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
