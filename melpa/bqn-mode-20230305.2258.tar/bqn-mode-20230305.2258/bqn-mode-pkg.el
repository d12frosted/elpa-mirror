(define-package "bqn-mode" "20230305.2258" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "f7a5713c301bc90a66108a233344d3fab449c1b1" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
