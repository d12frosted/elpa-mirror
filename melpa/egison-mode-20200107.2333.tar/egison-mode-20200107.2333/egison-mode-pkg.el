(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "fc939c84a0ca6e8de844edfdcc0aacdfde577c66" :authors
  (("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  ("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
