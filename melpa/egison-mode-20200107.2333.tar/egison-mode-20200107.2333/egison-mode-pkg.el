(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "df4e47f7c8adfe90d9bf408459772a6cb4e71b70" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
