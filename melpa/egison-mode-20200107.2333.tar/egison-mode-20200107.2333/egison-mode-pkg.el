(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "f06fabd97dc3333c7a2637b2cfff238704e87078" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
