(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "8e2ede05cd0f0d854519f9b9bc845691e901c6ea" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
