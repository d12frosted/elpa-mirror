(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "dbb395b41a4e4eb69f3f045cbfbe95a1575ac45b" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
