(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "490d7344d961fd27e9f82dffcc3b7eadfebf397b" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
