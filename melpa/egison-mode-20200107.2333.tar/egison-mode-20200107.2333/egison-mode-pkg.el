(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "9cd6ac07d68d69c6cdcec28d76dc1f5396f895db" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
