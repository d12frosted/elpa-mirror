(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "1ec6e8fedcda1bc2a6517cdbd8b1a85a1401a8f1" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
