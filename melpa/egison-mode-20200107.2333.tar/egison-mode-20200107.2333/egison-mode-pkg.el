(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "5e5d9b613f1d715d7289a44fd7af50cb236de9c4" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
