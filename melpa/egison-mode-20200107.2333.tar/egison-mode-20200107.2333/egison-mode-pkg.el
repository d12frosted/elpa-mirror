(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "f65b744b224024b0838e46a944ed4de2e2cedc08" :authors
  (("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  ("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
