(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "b778f68adc833e11bc8bc309a7e161ee58d64162" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
