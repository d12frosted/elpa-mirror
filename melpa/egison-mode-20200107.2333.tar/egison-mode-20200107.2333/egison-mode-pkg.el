(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "a41f72792792c4d0c84e331c3f05fa6a5bde963b" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
