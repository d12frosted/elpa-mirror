(define-package "simple-call-tree" "20240713.139" "analyze source code based on font-lock text-properties"
  '((emacs "24.3")
    (anaphora "1.0.0"))
  :commit "41ff2ba67625a7ef126fb0c42c772e98dea4caa4" :authors
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("programming")
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
