;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260805.1534"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "88c69d6d515b30b564b4f0b2cb54d13ce8349c8b"
  :revdesc "88c69d6d515b"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
