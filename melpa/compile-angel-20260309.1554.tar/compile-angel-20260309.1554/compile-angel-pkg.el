;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260309.1554"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "5ced2e9865ac2f35c2e0a550f5700213e64bcf79"
  :revdesc "5ced2e9865ac"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
