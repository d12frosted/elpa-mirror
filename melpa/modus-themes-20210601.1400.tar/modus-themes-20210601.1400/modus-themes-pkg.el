(define-package "modus-themes" "20210601.1400" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "7548191bc2bf5ab346c624570efb321bde91fedf" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
