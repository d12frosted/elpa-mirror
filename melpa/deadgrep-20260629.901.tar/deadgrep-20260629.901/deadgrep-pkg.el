;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "deadgrep" "20260629.901"
  "Fast, friendly searching with ripgrep."
  '((emacs   "25.1")
    (dash    "2.12.0")
    (s       "1.11.0")
    (spinner "1.7.3"))
  :url "https://github.com/Wilfred/deadgrep"
  :commit "1ce8b7027a179ecae379ff3093414c965307df1b"
  :revdesc "1ce8b7027a17"
  :keywords '("tools")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
