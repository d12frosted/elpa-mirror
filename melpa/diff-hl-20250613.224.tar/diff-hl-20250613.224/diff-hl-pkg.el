;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20250613.224"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "0fe1bc0fd8716e8521f49fdbeae68da64ea4772f"
  :revdesc "0fe1bc0fd871"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
