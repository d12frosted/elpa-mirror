;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250626.1201"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "1366c9af3fa68de98445bad2162ddefdba7e6f52"
  :revdesc "1366c9af3fa6"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
