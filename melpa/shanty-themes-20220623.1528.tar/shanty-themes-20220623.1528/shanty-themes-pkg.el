(define-package "shanty-themes" "20220623.1528" "The themes for digital workers"
  '((emacs "27.2"))
  :commit "906104f6a6b185efc19285fcc3bc943f094fb594" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
