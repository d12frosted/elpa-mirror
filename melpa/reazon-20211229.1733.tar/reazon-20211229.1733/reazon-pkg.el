(define-package "reazon" "20211229.1733" "miniKanren for Emacs"
  '((emacs "26"))
  :commit "f31c8b2e911c5885551d063c0a2b5de49a646eb1" :authors
  '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainer
  '("Nick Drozd" . "nicholasdrozd@gmail.com")
  :keywords
  '("languages" "extensions" "lisp")
  :url "https://github.com/nickdrozd/reazon")
;; Local Variables:
;; no-byte-compile: t
;; End:
