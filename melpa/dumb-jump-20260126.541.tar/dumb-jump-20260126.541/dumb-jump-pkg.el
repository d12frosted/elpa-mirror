;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260126.541"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.4")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "40ae11b288488145c7c59c21667da900ceea219f"
  :revdesc "40ae11b28848"
  :keywords '("programming"))
