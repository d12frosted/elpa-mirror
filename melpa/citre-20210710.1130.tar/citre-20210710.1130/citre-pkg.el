(define-package "citre" "20210710.1130" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "6bd9c512e2b08d2ff9c3e5f67341dc9c4115311b" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
