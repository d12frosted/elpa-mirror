;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20251107.1204"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "f5c7c76f10155204bad13c2dfa51bc48b7b20e1b"
  :revdesc "f5c7c76f1015"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
