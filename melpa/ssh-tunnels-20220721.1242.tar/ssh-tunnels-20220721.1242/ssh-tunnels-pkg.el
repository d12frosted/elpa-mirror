;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ssh-tunnels" "20220721.1242"
  "Manage SSH tunnels."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/death/ssh-tunnels"
  :commit "5010d779edef33f869065231b99d74723c9c7eaf"
  :revdesc "5010d779edef"
  :keywords '("tools" "convenience")
  :authors '(("death" . "github.com/death"))
  :maintainers '(("death" . "github.com/death")))
