(define-package "ssh-tunnels" "20220721.1242" "Manage SSH tunnels"
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "5010d779edef33f869065231b99d74723c9c7eaf" :authors
  '(("death <github.com/death>"))
  :maintainer
  '("death <github.com/death>")
  :keywords
  '("tools" "convenience")
  :url "http://github.com/death/ssh-tunnels")
;; Local Variables:
;; no-byte-compile: t
;; End:
