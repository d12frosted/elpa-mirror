;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261101.9"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "a797255d2a9d72d5ee2b790439c1c3388ea13fe8"
  :revdesc "a797255d2a9d"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
