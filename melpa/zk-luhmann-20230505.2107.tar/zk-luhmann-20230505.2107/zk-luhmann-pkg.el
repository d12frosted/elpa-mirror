(define-package "zk-luhmann" "20230505.2107" "Support for Luhmann-style IDs in zk"
  '((emacs "25.1")
    (zk "0.4")
    (zk-index "0.9"))
  :commit "be0d6aa9fb856736406a43e3908fc4a01e073b99" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/zk-luhmann")
;; Local Variables:
;; no-byte-compile: t
;; End:
