;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "20260203.2217"
  "Compiler explorer client (godbolt.org)."
  '((emacs "28.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "269bd9d9d2cbc45c10b5f91f988dc39bf783a68d"
  :revdesc "269bd9d9d2cb"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
