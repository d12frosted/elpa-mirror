;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260319.1649"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "746ee17659854a2a4159f5b163c4583e6b155d4c"
  :revdesc "746ee1765985")
