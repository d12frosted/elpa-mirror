;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20251217.1858"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs  "27.2")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "2bda7d6484f3fe8ad15860e227ea687c693a2552"
  :revdesc "2bda7d6484f3"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
