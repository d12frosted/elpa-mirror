(define-package "geiser" "20211220.2147" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3"))
  :commit "3ff258581804c5befd5596619b7ce85480a9f233" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
