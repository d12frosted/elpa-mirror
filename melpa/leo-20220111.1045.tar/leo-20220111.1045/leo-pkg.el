(define-package "leo" "20220111.1045" "Interface for dict.leo.org"
  '((emacs "27.1"))
  :commit "9f6aeb9670241255c373432af7785c7b87cee290" :authors
  '(("M.T. Enders <michael AT michael-enders.com>")
    ("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainer
  '("M.T. Enders <michael AT michael-enders.com>")
  :keywords
  '("convenience" "translate")
  :url "https://github.com/mtenders/emacs-leo")
;; Local Variables:
;; no-byte-compile: t
;; End:
