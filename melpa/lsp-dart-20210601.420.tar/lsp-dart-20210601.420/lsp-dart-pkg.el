(define-package "lsp-dart" "20210601.420" "Dart support lsp-mode"
  '((emacs "26.1")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (pkg-info "0.4")
    (dart-mode "1.0.5"))
  :commit "7ef909a1c9e0e1c924b43637899e0d53b0d1b00f" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
