;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "20260804.551"
  "Run REPLs in a terminal backend."
  '((emacs "29.1"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "bf97d0a417902417febc2b6925152dab5610057f"
  :revdesc "bf97d0a41790"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
