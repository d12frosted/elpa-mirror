(define-package "org-gcal" "20210220.806" "Org sync with Google Calendar"
  '((request "20190901")
    (request-deferred "20181129")
    (alert "0")
    (persist "0")
    (emacs "26"))
  :commit "299ee28a3534de1aabb5dea09171eec53014ad3b" :authors
  '(("myuhe <yuhei.maeda_at_gmail.com>"))
  :maintainer
  '("Raimon Grau" . "raimonster@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/kidd/org-gcal.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
