(define-package "reaper" "20220527.2122" "Interact with Harvest time tracking app"
  '((emacs "26.2"))
  :commit "a8ec93656698c5c02a02279ee7d7976325cc74cd" :authors
  '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers
  '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainer
  '("Thomas Fini Hansen" . "xen@xen.dk")
  :keywords
  '("tools")
  :url "https://github.com/xendk/reaper")
;; Local Variables:
;; no-byte-compile: t
;; End:
