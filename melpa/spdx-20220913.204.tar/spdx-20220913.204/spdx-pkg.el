(define-package "spdx" "20220913.204" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "77a896d367f7cf08bc7411d22090109d367d5c91" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
