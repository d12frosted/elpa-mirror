;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251010.507"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "d4a057e561e9945d2fd2081ea7b119f79e353d6e"
  :revdesc "d4a057e561e9"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
