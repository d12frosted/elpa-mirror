(define-package "jq-mode" "20230816.809" "Edit jq scripts."
  '((emacs "25.1"))
  :commit "e2aebaab165a9f0b38a15186a77b356e69cd3ada" :authors
  '(("Bjarte Johansen <Bjarte dot Johansen at gmail dot com>"))
  :maintainers
  '(("Bjarte Johansen <Bjarte dot Johansen at gmail dot com>"))
  :maintainer
  '("Bjarte Johansen <Bjarte dot Johansen at gmail dot com>")
  :url "https://github.com/ljos/jq-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
