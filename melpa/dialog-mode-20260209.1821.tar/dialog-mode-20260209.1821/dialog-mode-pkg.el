;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260209.1821"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "c44e9131597d9500f4a5005fab68a8fe5610425b"
  :revdesc "c44e9131597d"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
