;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250119.1447"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "bb7909e5d66750ab721cefbfbd4a6f60af8e8878"
  :revdesc "bb7909e5d667"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
