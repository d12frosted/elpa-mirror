;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms-mark-ext" "20130529.327"
  "Extra functions for emms-mark-mode and emms-tag-edit-mode."
  '((emms "3.0"))
  :url "https://github.com/vapniks/emms-mark-ext"
  :commit "ec68129e3e9e469e5bf160c6a1b7030e322f3541"
  :revdesc "ec68129e3e9e"
  :keywords '("convenience" "multimedia")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
