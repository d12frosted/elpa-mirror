;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261111.1223"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "1cb16b6c2e7a843f5b00c4c4f05ff6162bbe3d3c"
  :revdesc "1cb16b6c2e7a"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
