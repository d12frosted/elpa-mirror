(define-package "diff-hl" "20211106.2353" "Highlight uncommitted changes using VC"
  '((cl-lib "0.2")
    (emacs "25.1"))
  :commit "e628ba35b8fa6f9fe13dc2525bd82532dc9bd864" :authors
  '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("vc" "diff")
  :url "https://github.com/dgutov/diff-hl")
;; Local Variables:
;; no-byte-compile: t
;; End:
