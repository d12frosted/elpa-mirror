;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260126.1252"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "f5ea2d098b90ac4fcb0e6ebfe71dd5524bf42d81"
  :revdesc "f5ea2d098b90"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
