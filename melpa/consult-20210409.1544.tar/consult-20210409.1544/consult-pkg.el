(define-package "consult" "20210409.1544" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "846c715ee1df94292a9bb2467810bd7959ccf078" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
