(define-package "org-link-beautify" "20240523.157" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1")
    (qrencode "1.2"))
  :commit "5a553695e2f51607fc3f8dd77e7e2221cc3ed042" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
