;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260324.454"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "f21752a8e1d3af35897a0b9e594769b3d652e831"
  :revdesc "f21752a8e1d3"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
