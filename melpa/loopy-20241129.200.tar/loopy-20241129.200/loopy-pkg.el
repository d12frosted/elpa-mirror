;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20241129.200"
  "A looping macro."
  '((emacs  "27.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.3.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "2a76b3f5236915ed0776963522cc86b27a898b83"
  :revdesc "2a76b3f52369"
  :keywords '("extensions"))
