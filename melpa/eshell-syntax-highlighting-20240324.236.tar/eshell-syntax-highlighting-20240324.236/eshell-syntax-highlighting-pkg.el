(define-package "eshell-syntax-highlighting" "20240324.236" "Highlight eshell commands"
  '((emacs "25.1"))
  :commit "e8dbadda152975ae03185aa8a6d6379b42ecd817" :authors
  '(("Alex Kreisher" . "akreisher18@gmail.com"))
  :maintainers
  '(("Alex Kreisher" . "akreisher18@gmail.com"))
  :maintainer
  '("Alex Kreisher" . "akreisher18@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/akreisher/eshell-syntax-highlighting")
;; Local Variables:
;; no-byte-compile: t
;; End:
