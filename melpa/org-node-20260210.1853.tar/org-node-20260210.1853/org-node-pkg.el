;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260210.1853"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.28.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "6fe0cf482204b131f5cb1ce9353fa77c8fdecdad"
  :revdesc "6fe0cf482204"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
