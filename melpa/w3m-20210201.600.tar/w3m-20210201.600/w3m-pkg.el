(define-package "w3m" "20210201.600" "an Emacs interface to w3m" 'nil :commit "45f557bf85ae8c68890cdf0dd7a9961903e0731d" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
