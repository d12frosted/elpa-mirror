(define-package "gumshoe" "20231223.2307" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "b73422708a9a77dbe9937523f5855ef927a651c0" :authors
  '(("overdr0ne"))
  :maintainers
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
