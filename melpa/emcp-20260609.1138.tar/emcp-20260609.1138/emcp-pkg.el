;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260609.1138"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "5f000f3c1eb0453123ae12e002325510c95a8cf0"
  :revdesc "5f000f3c1eb0"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
