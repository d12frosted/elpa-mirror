;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asm-blox" "20240106.1930"
  "Programming game involving WAT."
  '((emacs "26.1")
    (yaml  "0.5.1"))
  :url "https://github.com/zkry/asm-blox"
  :commit "6731d8e4f78d0b43ec9b90d8184c1d86d725ac7c"
  :revdesc "6731d8e4f78d"
  :keywords '("games"))
