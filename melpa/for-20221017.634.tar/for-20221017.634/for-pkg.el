(define-package "for" "20221017.634" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "7b5d13eae258c5299a6525cb32a3bb69fb7f652c" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
