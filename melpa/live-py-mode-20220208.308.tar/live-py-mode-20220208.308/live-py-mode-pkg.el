(define-package "live-py-mode" "20220208.308" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "04bc45ca08835e1519d185ce2170108c9b6ea7b6" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
