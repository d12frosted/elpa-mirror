(define-package "live-py-mode" "20220208.308" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "6fa9967b2ac69ae40980804ca6152e8f2f5e9f12" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
