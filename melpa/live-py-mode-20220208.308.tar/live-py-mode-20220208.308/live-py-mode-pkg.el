(define-package "live-py-mode" "20220208.308" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "38864c22bf68c7a8975d1d5b2ba4881f75ac2442" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
