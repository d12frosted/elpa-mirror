(define-package "apdl-mode" "20210912.701" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "3e7845648d6c27d37bfe9fb8fbb955ea9bd32268" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
