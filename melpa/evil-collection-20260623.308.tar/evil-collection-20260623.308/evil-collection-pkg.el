;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260623.308"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "e2a1989c79dafaf739a34f93fb2265a23d1c818e"
  :revdesc "e2a1989c79da"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
