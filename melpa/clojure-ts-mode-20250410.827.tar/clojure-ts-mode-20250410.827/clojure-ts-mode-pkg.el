;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20250410.827"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "http://github.com/clojure-emacs/clojure-ts-mode"
  :commit "a0b01b212723dea772dd8c06932be0f9f66ea000"
  :revdesc "a0b01b212723"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Danny Freeman" . "danny@dfreeman.email")))
