(define-package "org-roam" "20210123.1009" "Roam Research replica with Org-mode"
  '((emacs "26.1")
    (dash "2.13")
    (f "0.17.2")
    (s "1.12.0")
    (org "9.3")
    (emacsql "3.0.0")
    (emacsql-sqlite3 "1.0.2"))
  :commit "aa52b65a4a22a948b17f94f42a7ccddfd52d4d9e" :authors
  '(("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  '("Jethro Kuan" . "jethrokuan95@gmail.com")
  :keywords
  '("org-mode" "roam" "convenience")
  :url "https://github.com/org-roam/org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
