(define-package "golden-ratio" "20230909.1819" "Automatic resizing of Emacs windows to the golden ratio" 'nil :commit "749b313cf27e15856443890e62a94008d4a6795a" :authors
  '(("Roman Gonzalez" . "romanandreg@gmail.com"))
  :maintainers
  '(("Roman Gonzalez" . "romanandreg@gmail.com"))
  :maintainer
  '("Roman Gonzalez" . "romanandreg@gmail.com")
  :keywords
  '("window" "resizing"))
;; Local Variables:
;; no-byte-compile: t
;; End:
