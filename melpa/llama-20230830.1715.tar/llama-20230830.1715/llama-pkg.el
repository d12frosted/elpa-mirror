(define-package "llama" "20230830.1715" "Compact syntax for short lambda"
  '((seq "2.23"))
  :commit "beddc6a85787e2a95910e284076c162068c6f0de" :keywords
  '("extensions")
  :url "https://git.sr.ht/~tarsius/llama")
;; Local Variables:
;; no-byte-compile: t
;; End:
