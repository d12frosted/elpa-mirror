;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250704.536"
  "Minor mode to format JS code on file save."
  '((emacs "28.1"))
  :url "https://github.com/prettier/prettier-emacs"
  :commit "bd984c943a343dbafc22f87a6ce8cf96ae5d1ef7"
  :revdesc "bd984c943a34"
  :keywords '("convenience" "wp" "edit" "js"))
