(define-package "gptel" "20240905.1239" "Interact with ChatGPT or other LLMs"
  '((emacs "27.1")
    (transient "0.4.0")
    (compat "29.1.4.1"))
  :commit "b7a147d624e15aabaaecf1119ba5894552e18527" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
