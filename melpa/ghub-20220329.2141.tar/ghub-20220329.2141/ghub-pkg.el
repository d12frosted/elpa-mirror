(define-package "ghub" "20220329.2141" "Client libraries for Git forge APIs."
  '((emacs "25.1")
    (let-alist "1.0.6")
    (treepy "0.1.1"))
  :commit "80f5008b8c6b48dee2b77fbffe380653d2d7720d" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
