;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260616.1927"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "2657492d21cd0251ffda989acb02e1caa980c962"
  :revdesc "2657492d21cd"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
