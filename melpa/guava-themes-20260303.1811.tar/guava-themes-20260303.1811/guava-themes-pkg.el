;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260303.1811"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "39995a2de698b9f407b86a25dca2b9d8d23641e5"
  :revdesc "39995a2de698"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
