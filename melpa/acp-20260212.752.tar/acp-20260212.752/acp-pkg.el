;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20260212.752"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "a5227b4dc94fcd41b3fdb531fa4c24d8124b12be"
  :revdesc "a5227b4dc94f")
