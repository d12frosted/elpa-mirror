(define-package "modus-themes" "20230325.1537" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "038295f72c0f901f0944bb27e4be1a9ad052fe84" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
