;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260310.2351"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "b6c8de84a302cfb4d7bb09e7a78684a3f870c320"
  :revdesc "b6c8de84a302"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
