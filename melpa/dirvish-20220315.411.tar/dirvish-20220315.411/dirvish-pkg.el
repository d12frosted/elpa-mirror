(define-package "dirvish" "20220315.411" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "5f419f3e766bcb52b7af33089d807f6e2539b575" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
