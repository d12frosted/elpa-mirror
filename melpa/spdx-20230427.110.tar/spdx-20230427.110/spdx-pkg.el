(define-package "spdx" "20230427.110" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "cf3ba8ac98349f73c8f94b3bdd38e6a74e8ac6ee" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
