(define-package "embark" "20211231.319" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "49b9bca8e5a9dd2cf56be82d9dd9ca4b8530bd1f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
