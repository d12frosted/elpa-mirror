(define-package "ob-fsharp" "20170618.1429" "Org-Babel F#"
  '((fsharp-mode "1.9.8")
    (emacs "25"))
  :commit "65ec2b626ac55313d8a04e746940370f615fed1e" :authors
  '(("Jürgen Hötzel" . "juergen@archlinux.org"))
  :maintainer
  '("Jürgen Hötzel" . "juergen@archlinux.org")
  :keywords
  '("literate programming" "reproducible research")
  :url "https://github.com/juergenhoetzel/ob-fsharp")
;; Local Variables:
;; no-byte-compile: t
;; End:
