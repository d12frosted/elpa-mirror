(define-package "git-cliff" "20231020.1845" "Generate and update changelog using git-cliff"
  '((emacs "27.1")
    (transient "0.4.3"))
  :commit "d675d2ec3f6fb10a07fc3632bb7034a74f92cf8b" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/liuyinz/git-cliff.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
