(define-package "srfi" "20210325.445" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "633a0ff419438987f6271ff5a5da26307950a3cd" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
