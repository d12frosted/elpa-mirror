(define-package "moe-theme" "20220107.1114" "A colorful eye-candy theme. Moe, moe, kyun!" 'nil :commit "376245293a0d84c5ba3e7d760e020c13056791f1" :authors
  '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainer
  '("kuanyui" . "azazabc123@gmail.com")
  :keywords
  '("themes")
  :url "https://github.com/kuanyui/moe-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
