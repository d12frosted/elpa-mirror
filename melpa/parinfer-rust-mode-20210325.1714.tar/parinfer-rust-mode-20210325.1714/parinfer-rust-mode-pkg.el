(define-package "parinfer-rust-mode" "20210325.1714" "An interface for the parinfer-rust library"
  '((emacs "26.1"))
  :commit "f130fa04ec75131686872f24a253d0a1d5522fa4" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
