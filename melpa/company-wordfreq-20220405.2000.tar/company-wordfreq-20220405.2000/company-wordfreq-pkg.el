;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-wordfreq" "20220405.2000"
  "Company backend for human language texts."
  '((emacs   "27.1")
    (company "0.9"))
  :url "https://github.com/johannes-mueller/company-wordfreq.el"
  :commit "83569cf346c2320ef22f6a858e3424f771c4324e"
  :revdesc "83569cf346c2"
  :keywords '("company" "convenience" "matching")
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
