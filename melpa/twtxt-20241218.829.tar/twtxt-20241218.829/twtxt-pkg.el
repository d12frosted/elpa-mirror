;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twtxt" "20241218.829"
  "A twtxt client for Emacs."
  '((emacs   "25.1")
    (request "0.2.0"))
  :url "https://codeberg.org/deadblackclover/twtxt-el"
  :commit "a5c527013d4872fb7711f49ae86c795f8150b30e"
  :revdesc "a5c527013d48"
  :authors '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com"))
  :maintainers '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com")))
