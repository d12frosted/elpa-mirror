;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250301.1406"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "e46e356df7bb326032a8d1f21e6a0d7e0e138f1d"
  :revdesc "e46e356df7bb"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
