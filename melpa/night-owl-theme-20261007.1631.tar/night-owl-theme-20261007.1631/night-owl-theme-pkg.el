;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "night-owl-theme" "20261007.1631"
  "A color theme for the night owls out there."
  '((emacs "24"))
  :url "https://github.com/aaronjensen/night-owl-theme"
  :commit "1b56ab29b322103287d97990108681d389188c65"
  :revdesc "1b56ab29b322"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
