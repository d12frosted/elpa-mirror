;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fedi" "20261111.1708"
  "Helper functions for fediverse clients."
  '((emacs         "28.1")
    (markdown-mode "2.5"))
  :url "https://codeberg.org/martianh/fedi.el"
  :commit "82fb942987141b19ee5202ce6e76b236309d07a6"
  :revdesc "82fb94298714"
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
