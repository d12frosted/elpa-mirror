(define-package "racket-mode" "20231121.1518" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "1d108edab0adb7b1014a7881b8352f5980092fea" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
