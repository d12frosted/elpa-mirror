(define-package "electric-operator" "20230828.801" "Automatically add spaces around operators"
  '((dash "2.10.0")
    (emacs "24.4"))
  :commit "cb21b85b43255f9c1681995e7e36912e7f4e17b3" :authors
  '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers
  '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainer
  '("David Shepherd" . "davidshepherd7@gmail.com")
  :keywords
  '("electric")
  :url "https://github.com/davidshepherd7/electric-operator")
;; Local Variables:
;; no-byte-compile: t
;; End:
