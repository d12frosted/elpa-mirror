;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260508.1403"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "29f279c36c002810b750c10326ccd7d63b3aded1"
  :revdesc "29f279c36c00"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
