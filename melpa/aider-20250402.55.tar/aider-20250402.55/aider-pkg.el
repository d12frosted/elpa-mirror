;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250402.55"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "d42565be7ef768d9ac7758acbe7c6b9d75b48eca"
  :revdesc "d42565be7ef7"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
