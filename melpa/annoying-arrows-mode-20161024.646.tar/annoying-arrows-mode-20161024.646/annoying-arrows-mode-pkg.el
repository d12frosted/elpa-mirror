;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annoying-arrows-mode" "20161024.646"
  "Ring the bell if using arrows too much."
  '((cl-lib "0.5"))
  :url "https://github.com/magnars/annoying-arrows-mode.el"
  :commit "3c42e9807d7696da2da2a21b63beebf9cdb3f5dc"
  :revdesc "3c42e9807d76"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
