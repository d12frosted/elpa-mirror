(define-package "meow" "20220305.2058" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "fa7012c07707cb6e9d51e74d67fd9f448b8a3cee" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
