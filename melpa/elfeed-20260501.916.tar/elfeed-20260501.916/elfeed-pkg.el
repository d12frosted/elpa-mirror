;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260501.916"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/skeeto/elfeed"
  :commit "a399cf00055cf72decf61629a8714eca8d3bfbe9"
  :revdesc "a399cf00055c"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
