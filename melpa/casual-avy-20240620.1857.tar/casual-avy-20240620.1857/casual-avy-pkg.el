(define-package "casual-avy" "20240620.1857" "Transient UI for Avy"
  '((emacs "29.1")
    (avy "0.5.0")
    (casual-lib "1.0.0"))
  :commit "486e71dfa985a260820586e096394ab326553811" :authors
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainer
  '("Charles Choi" . "kickingvegas@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kickingvegas/casual-avy")
;; Local Variables:
;; no-byte-compile: t
;; End:
