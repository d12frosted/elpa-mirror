(define-package "org-zettelkasten" "20230428.1502" "A Zettelkasten mode leveraging Org"
  '((emacs "25.1")
    (org "9.3"))
  :commit "ef005996a857af1049fdf80e07cb5eb46990626e" :authors
  '(("Yann Herklotz" . "yann@ymhg.org"))
  :maintainers
  '(("Yann Herklotz" . "yann@ymhg.org"))
  :maintainer
  '("Yann Herklotz" . "yann@ymhg.org")
  :keywords
  '("files" "hypermedia" "org" "notes")
  :url "https://sr.ht/~ymherklotz/org-zettelkasten")
;; Local Variables:
;; no-byte-compile: t
;; End:
