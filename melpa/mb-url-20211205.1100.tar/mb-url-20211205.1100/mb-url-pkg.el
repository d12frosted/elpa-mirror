(define-package "mb-url" "20211205.1100" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "ca0a3878763180fe2d775feae88b87d21dd8dcb8" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
