(define-package "mb-url" "20211205.1100" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "09f32af1a58d0b042b699c76d2b30e9226508f5e" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
