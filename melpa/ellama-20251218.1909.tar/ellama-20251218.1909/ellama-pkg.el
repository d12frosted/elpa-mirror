;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20251218.1909"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "45db4174ed73e4ebc2fe21f99fe4bfc01da9d488"
  :revdesc "45db4174ed73"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
