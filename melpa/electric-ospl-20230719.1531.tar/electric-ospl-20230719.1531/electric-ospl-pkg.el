(define-package "electric-ospl" "20230719.1531" "Electric OSPL Mode"
  '((emacs "26.1"))
  :commit "8bf02159c2658a08198b2765ee979e930378956c" :authors
  '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers
  '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainer
  '("Samuel W. Flint" . "swflint@flintfam.org")
  :keywords
  '("convenience" "text")
  :url "https://git.sr.ht/~swflint/electric-ospl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
