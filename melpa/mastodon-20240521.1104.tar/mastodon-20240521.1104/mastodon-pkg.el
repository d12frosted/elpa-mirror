(define-package "mastodon" "20240521.1104" "Client for fediverse services using the Mastodon API"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4"))
  :commit "0d91d5e874c526865eda543d3cb7580ac1eb25ad" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
