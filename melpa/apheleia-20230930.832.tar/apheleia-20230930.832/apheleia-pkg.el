(define-package "apheleia" "20230930.832" "Reformat buffer stably"
  '((emacs "26"))
  :commit "da31e1b7f36c14ec4c280cd84499dcfba1f5f0d4" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
