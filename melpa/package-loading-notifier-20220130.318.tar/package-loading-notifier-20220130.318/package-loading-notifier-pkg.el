(define-package "package-loading-notifier" "20220130.318" "Notify a package is being loaded"
  '((emacs "25"))
  :commit "bc06ba97a0537aa202f277e5597ac96ca39307ab" :authors
  '(("SeungKi Kim" . "tttuuu888@gmail.com"))
  :maintainers
  '(("SeungKi Kim" . "tttuuu888@gmail.com"))
  :maintainer
  '("SeungKi Kim" . "tttuuu888@gmail.com")
  :keywords
  '("convenience" "faces" "config" "startup")
  :url "https://github.com/tttuuu888/package-loading-notifier")
;; Local Variables:
;; no-byte-compile: t
;; End:
