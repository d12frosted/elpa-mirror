;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260228.654"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "63cd4eabddb6f49105ac702d1af1fe3bd8394210"
  :revdesc "63cd4eabddb6"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
