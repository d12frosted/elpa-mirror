;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260124.1044"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "7c9676460b882fd2114c5630815b7d1326091809"
  :revdesc "7c9676460b88"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
