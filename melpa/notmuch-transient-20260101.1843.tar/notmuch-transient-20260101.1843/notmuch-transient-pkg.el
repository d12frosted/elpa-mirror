;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-transient" "20260101.1843"
  "Command dispatchers for Notmuch."
  '((emacs     "29.1")
    (compat    "30.1")
    (notmuch   "0.39")
    (transient "0.12"))
  :url "https://github.com/tarsius/notmuch-transient"
  :commit "a1e18fa9202248c3c6264147bd0e82cda0a03a53"
  :revdesc "a1e18fa92022"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev")))
