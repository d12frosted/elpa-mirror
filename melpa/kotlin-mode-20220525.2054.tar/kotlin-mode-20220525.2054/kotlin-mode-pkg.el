(define-package "kotlin-mode" "20220525.2054" "Major mode for kotlin"
  '((emacs "24.3"))
  :commit "d92c3b773473e9fe15f61f6177e4fbf097aadd05" :authors
  '(("Shodai Yokoyama" . "quantumcars@gmail.com"))
  :maintainer
  '("Shodai Yokoyama" . "quantumcars@gmail.com")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
