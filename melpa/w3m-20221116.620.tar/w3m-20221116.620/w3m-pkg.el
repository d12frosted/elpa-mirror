(define-package "w3m" "20221116.620" "an Emacs interface to w3m" 'nil :commit "a12b89d59ff0ca4a28cc4124fe41cff5b24e53e8" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
