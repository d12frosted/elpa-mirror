;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260205.1638"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "86ed2796cafa087e430199d0e05d714687df9229"
  :revdesc "86ed2796cafa")
