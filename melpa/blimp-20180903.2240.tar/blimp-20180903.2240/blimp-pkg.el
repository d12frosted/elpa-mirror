;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blimp" "20180903.2240"
  "Bustling Image Manipulation Package."
  '((emacs "25")
    (eimp  "1.4.0"))
  :url "https://github.com/walseb/blimp"
  :commit "b048b037129b68674b99310bcc08fb96d44fdbb4"
  :revdesc "b048b037129b"
  :keywords '("multimedia" "unix")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
