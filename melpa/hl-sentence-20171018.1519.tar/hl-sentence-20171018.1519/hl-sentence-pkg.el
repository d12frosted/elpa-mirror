;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-sentence" "20171018.1519"
  "Highlight a sentence based on customizable face."
  ()
  :url "https://github.com/milkypostman/hl-sentence"
  :commit "86ae38d3103bd20da5485cbdd59dfbd396c45ee4"
  :revdesc "86ae38d3103b"
  :keywords '("highlighting")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainers '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")))
