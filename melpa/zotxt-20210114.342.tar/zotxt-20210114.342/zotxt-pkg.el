(define-package "zotxt" "20210114.342" "Tools to integrate emacs with Zotero via the zotxt plugin."
  '((request "0.3.2")
    (deferred "0.5.1"))
  :commit "a98b524c559807d9f0980a1593e435aeaf242e07" :authors
  '(("Erik Hetzner" . "egh@e6h.org"))
  :maintainer
  '("Erik Hetzner" . "egh@e6h.org")
  :keywords
  '("bib"))
;; Local Variables:
;; no-byte-compile: t
;; End:
