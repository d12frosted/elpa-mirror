(define-package "hl-prog-extra" "20220211.548" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "aaa9cd5085c13cbbfa41648ca4134a1699e64d5e" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
