(define-package "verb" "20211103.1927" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "f9ea5780ec65e6f30451514b72ce99619dd8457f" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
