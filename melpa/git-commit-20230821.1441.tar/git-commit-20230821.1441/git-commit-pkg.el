(define-package "git-commit" "20230821.1441" "Edit Git commit messages."
  '((emacs "25.1")
    (compat "29.1.3.4")
    (transient "20230201")
    (with-editor "20230118"))
  :commit "027bae37aef0e3f5a6e1192fa727c315eea9de66" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
