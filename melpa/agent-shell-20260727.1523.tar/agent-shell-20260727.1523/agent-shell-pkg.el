;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260727.1523"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8a5076d1ecb9a2f3ecfcd33cbd94c8bceacabf46"
  :revdesc "8a5076d1ecb9")
