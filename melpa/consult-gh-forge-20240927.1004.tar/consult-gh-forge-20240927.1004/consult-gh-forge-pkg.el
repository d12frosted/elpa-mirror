;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-forge" "20240927.1004"
  "Magit/Forge Integration for consult-gh."
  '((emacs      "29.1")
    (consult    "1.0")
    (forge      "0.3.3")
    (consult-gh "2.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "79204bab021d9c58687dbce44694419c966d6998"
  :revdesc "79204bab021d"
  :keywords '("matching" "git" "repositories" "forges" "completion"))
