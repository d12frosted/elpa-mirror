;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260621.1531"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9e2b30e5c50a5da7e69653e7076405c21a08564f"
  :revdesc "9e2b30e5c50a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
