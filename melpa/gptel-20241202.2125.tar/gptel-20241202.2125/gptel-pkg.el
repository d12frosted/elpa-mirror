;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241202.2125"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "4593d0b475d26d25312732440f80a278ad560ef9"
  :revdesc "4593d0b475d2"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
