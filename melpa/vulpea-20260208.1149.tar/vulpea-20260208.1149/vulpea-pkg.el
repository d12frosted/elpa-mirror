;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260208.1149"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "93e0a873e9054b38fe734c1f613639d60a734439"
  :revdesc "93e0a873e905"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
