;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260510.721"
  "Lets your agent talk to Emacs."
  '((emacs       "30.1")
    (http-server "0.1.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "eb3b4a161d38b8e4e08acd0cf503107c804834c5"
  :revdesc "eb3b4a161d38"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
