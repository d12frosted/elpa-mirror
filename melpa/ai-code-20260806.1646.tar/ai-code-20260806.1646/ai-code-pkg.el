;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260806.1646"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "1d26606bedb86b9fb65b80018464277ad52c02c7"
  :revdesc "1d26606bedb8"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
