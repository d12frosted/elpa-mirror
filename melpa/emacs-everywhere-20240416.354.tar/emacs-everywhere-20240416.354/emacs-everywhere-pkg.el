(define-package "emacs-everywhere" "20240416.354" "System-wide popup windows for quick edits"
  '((emacs "26.3"))
  :commit "2109b78ccadb084db302d5009b6d0f039ff240ec" :authors
  '(("TEC <https://github.com/tecosaur>"))
  :maintainers
  '(("TEC" . "contact@tecosaur.net"))
  :maintainer
  '("TEC" . "contact@tecosaur.net")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/tecosaur/emacs-everywhere")
;; Local Variables:
;; no-byte-compile: t
;; End:
