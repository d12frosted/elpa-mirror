(define-package "srfi" "20220922.1947" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "72bd263bc3171c5a2123441a4ed89ef9dbbfca02" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
