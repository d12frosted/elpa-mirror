(define-package "apropospriate-theme" "20221005.1428" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "cb56b8c1a4ea42a329b279e57b3db473f0be4adc" :authors
  '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainer
  '("Justin Talbott" . "justin@waymondo.com")
  :url "http://github.com/waymondo/apropospriate-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
