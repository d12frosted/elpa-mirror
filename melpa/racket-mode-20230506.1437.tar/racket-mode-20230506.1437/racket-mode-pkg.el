(define-package "racket-mode" "20230506.1437" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "c2fe266c18bb6e55a13c7ba795b0a5f7372b6c13" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
