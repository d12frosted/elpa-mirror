;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nonogram" "20260914.727"
  "Play nonogram (picross) puzzles with SVG graphics."
  '((emacs "27.1"))
  :url "https://git.andros.dev/andros/nonogram.el"
  :commit "4fdb98adbe5272884ec698fee369d8dfe7b3a289"
  :revdesc "4fdb98adbe52"
  :keywords '("games")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
