;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260128.527"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "2e6ba04c393ad95973a48483147046683454af86"
  :revdesc "2e6ba04c393a"
  :keywords '("comm"))
