;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260111.1646"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b14310df58cc8bd33860e9bf548ee1497dc3fd20"
  :revdesc "b14310df58cc"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
