;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20261109.1937"
  "46 new custom blocks & 56 link types for Org-mode."
  '((s     "1.13.1")
    (dash  "2.18.1")
    (emacs "28.2")
    (org   "9.8")
    (lf    "26.10.1")
    (seq   "2.0"))
  :url "https://alhassy.com/org-special-block-extras"
  :commit "6ff9297e65758681e03a51e8364d0b6a1ddf0d19"
  :revdesc "6ff9297e6575"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
