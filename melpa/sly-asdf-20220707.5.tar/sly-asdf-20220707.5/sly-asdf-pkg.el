(define-package "sly-asdf" "20220707.5" "ASDF system support for SLY"
  '((emacs "24.3")
    (sly "1.0.0beta2")
    (popup "0.5.3"))
  :commit "3180921efdc19a2195960e1d601b2a6f31a6feea" :maintainer
  '("Matt George" . "mmge93@gmail.com")
  :keywords
  '("languages" "lisp" "sly" "asdf")
  :url "https://github.com/mmgeorge/sly-asdf")
;; Local Variables:
;; no-byte-compile: t
;; End:
