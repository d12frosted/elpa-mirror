(define-package "popper" "20230227.200" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "f0038228eb5f3687d845eb70508d986de0a67682" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
