(define-package "ready-player" "20240909.1329" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "d3017e9d3ca6a662c7533eb47efcfc14f53058dc" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
