;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251215.1701"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "5cfa8d63525bb8686031dd3e55c7f8569d81eb72"
  :revdesc "5cfa8d63525b")
