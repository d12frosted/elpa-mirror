;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boon" "20260215.930"
  "An Ergonomic Command Mode."
  '((emacs            "26.1")
    (dash             "2.12.0")
    (expand-region    "0.10.0")
    (multiple-cursors "1.3.0"))
  :url "https://github.com/jyp/boon"
  :commit "1aa2b2f8f6c0b32cd600355bbeabc036624d0566"
  :revdesc "1aa2b2f8f6c0")
