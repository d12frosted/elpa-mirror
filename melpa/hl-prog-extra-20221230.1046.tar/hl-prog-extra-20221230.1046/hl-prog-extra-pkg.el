(define-package "hl-prog-extra" "20221230.1046" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "d276c4a28d76da3a115c0fea55aef328fdef3f1c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
