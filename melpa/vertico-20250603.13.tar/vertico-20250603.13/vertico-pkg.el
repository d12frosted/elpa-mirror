;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20250603.13"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "c82f09f9dc1d90aa22728792836551aa4827fb60"
  :revdesc "c82f09f9dc1d"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
