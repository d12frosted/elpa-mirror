(define-package "transient" "20220314.1605" "Transient commands"
  '((emacs "25.1"))
  :commit "0619c7ef198349c11c8ef598c7caa741b3c4c9b0" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("bindings")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
