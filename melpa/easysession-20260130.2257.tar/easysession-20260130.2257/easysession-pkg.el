;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260130.2257"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "39c7539d7058a54210b30dece7ae88d977adcd38"
  :revdesc "39c7539d7058"
  :keywords '("convenience"))
