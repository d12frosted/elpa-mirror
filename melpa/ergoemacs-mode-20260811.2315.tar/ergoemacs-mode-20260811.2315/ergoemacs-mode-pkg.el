;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ergoemacs-mode" "20260811.2315"
  "Emacs mode based on common modern interface and ergonomics."
  '((emacs   "24.1")
    (cl-lib  "0.5")
    (nadvice "0.4"))
  :url "https://github.com/ergoemacs/ergoemacs-mode"
  :commit "5e83523752a47231af64c352fe4af57ad44dc456"
  :revdesc "5e83523752a4"
  :keywords '("convenience")
  :authors '(("Xah Lee" . "xah@xahlee.org")
             ("David Capello" . "davidcapello@gmail.com")
             ("Matthew L. Fidler" . "matthew.fidler@gmail.com")
             ("Kim F. Storm -- CUA approach for C-x and C-c" . "storm@cua.dk"))
  :maintainers '(("Matthew L. Fidler" . "matthew.fidler@gmail.com")))
