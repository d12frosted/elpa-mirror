;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250917.1738"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "982f77d2074293ade7d2694a069efbdcc3379c00"
  :revdesc "982f77d20742"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
