;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-compile" "20261011.1946"
  "Run, evaluate and compile across many languages."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.2.1"))
  :url "https://github.com/plandes/flex-compile"
  :commit "88cff5c6536d878ec7b21e3bd8e640911713b68f"
  :revdesc "88cff5c6536d"
  :keywords '("compilation" "integration" "processes"))
