;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260821.530"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "e5c9e9acae64da1cc52a21124a7b6987fb9f2a53"
  :revdesc "e5c9e9acae64"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
