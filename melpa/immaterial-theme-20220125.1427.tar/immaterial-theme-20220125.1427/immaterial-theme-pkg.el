(define-package "immaterial-theme" "20220125.1427" "A flexible theme based on material design principles"
  '((emacs "25"))
  :commit "592ebfcb6e3761174b6e2cdf91cc55a1e2ffb9c7" :authors
  '(("Peter Gardfjäll"))
  :maintainer
  '("Peter Gardfjäll")
  :keywords
  '("themes")
  :url "https://github.com/petergardfjall/emacs-immaterial-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
