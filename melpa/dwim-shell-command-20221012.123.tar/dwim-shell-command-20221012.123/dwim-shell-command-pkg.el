(define-package "dwim-shell-command" "20221012.123" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "919817520fa507dd3c7e6859eb982976e28b2575" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
