(define-package "ox-rfc" "20190926.851" "RFC Back-End for Org Export Engine"
  '((emacs "24.3")
    (org "8.3"))
  :commit "b86c9e6f21d99ea657b4f2224f816300485ed73f" :keywords
  ("org" "rfc" "wp" "xml")
  :authors
  (("Christian Hopps" . "chopps@devhopps.com"))
  :maintainer
  ("Christian Hopps" . "chopps@devhopps.com")
  :url "https://github.com/choppsv1/org-rfc-export")
;; Local Variables:
;; no-byte-compile: t
;; End:
