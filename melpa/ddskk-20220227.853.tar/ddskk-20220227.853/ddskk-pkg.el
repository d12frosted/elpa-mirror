(define-package "ddskk" "20220227.853" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "e3fb5e2905ea66a8b15d6da9ed6abee031bc8ebc")
;; Local Variables:
;; no-byte-compile: t
;; End:
