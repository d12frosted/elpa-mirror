;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zero-input" "20240527.728"
  "Zero Chinese input method framework."
  '((emacs "24.4")
    (s     "1.2.0"))
  :url "https://gitlab.emacsos.com/sylecn/zero-el"
  :commit "e87bbf24c1475a784ad9d1ba8447e038824d796b"
  :revdesc "e87bbf24c147")
