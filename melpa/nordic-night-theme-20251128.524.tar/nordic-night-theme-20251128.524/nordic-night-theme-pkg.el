;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nordic-night-theme" "20251128.524"
  "A darker, more colorful version of the lovely Nord theme."
  '((emacs "24.1"))
  :url "https://codeberg.org/ashton314/nordic-night"
  :commit "ed738c2f989665232c691d3dd432505230e64d88"
  :revdesc "ed738c2f9896"
  :authors '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers '(("Ashton Wiersdorf" . "mail@wiersdorf.dev")))
