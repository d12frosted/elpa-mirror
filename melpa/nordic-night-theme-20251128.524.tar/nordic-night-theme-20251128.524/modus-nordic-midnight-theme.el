;; -*- lexical-binding: t; -*-

(require 'modus-nordic-night-theme)

(defcustom modus-nordic-midnight-palette-overrides nil
  "Overrides for nordic-midnight palette.")

(defvar modus-nordic-midnight-palette-partial nil)

(defvar modus-nordic-midnight-palette
  (modus-themes-generate-palette
   '(
     ;; Background colors
     (bg-07 "#3f4f4f")
     (bg-08 "#3d5056")
     (bg-09 "#3b4551")
     (bg-10 "#233949")
     (bg-11 "#512e31")
     (bg-12 "#573d35")
     (bg-13 "#61553d")
     (bg-14 "#46503e")
     (bg-15 "#4c3e4a")

     ;; Extended nord colors
     (nn-dark1 "#000000")
     (nn-dark2 "#121212")
     (nn-dark3 "#1c1c1c")
     (nn-light1 "#6b7386")
     (nn-light2 "#8892a4")
     (nn-light3 "#c6c6cf")

     ;; Main theme colors
     (bg-main "#000000")                 ; nn-dark1
     (bg-dim  "#121212")                 ; nn-dark2
     (bg-alt  "#1c1c1c")
     (fg-main "#d8dee9")
     (fg-dim  "#8892a4")
     (fg-alt  "#b5bdcc")

     ;; Base theme colors
     (red "#bf616a")
     (green "#a3be8c")
     (yellow "#ebcb8b")
     (yellow-warmer "#d08770")
     (blue "#5e81ac")
     (blue-warmer "#81a1c1")
     (blue-faint "#8fbcbb")
     (cyan "#88c0d0")
     (magenta "#b48ead"))
   'cool))

;; Nordic-Midnight theme
(modus-themes-theme
 'modus-nordic-midnight
 'nordic-themes
 "Pitch-black version of the Nord theme."
 'dark
 'modus-nordic-midnight-palette
 'modus-nordic-night-palette-partial
 'modus-nordic-midnight-palette-overrides)
