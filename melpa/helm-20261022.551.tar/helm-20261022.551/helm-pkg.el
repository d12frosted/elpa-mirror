;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20261022.551"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "9f62a1d36796c254b0a545d28d3c7bd30fec0395"
  :revdesc "9f62a1d36796"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
