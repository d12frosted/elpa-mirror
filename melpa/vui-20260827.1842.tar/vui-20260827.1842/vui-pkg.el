;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260827.1842"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "f010659c6b0173e153f622830a603008a759b014"
  :revdesc "f010659c6b01"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
