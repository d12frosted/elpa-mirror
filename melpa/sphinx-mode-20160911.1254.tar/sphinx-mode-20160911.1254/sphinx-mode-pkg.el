(define-package "sphinx-mode" "20160911.1254" "Minor mode providing sphinx support." 'nil :commit "3d6e3059350593dc077f06f54c33869b9e28f7bc" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
