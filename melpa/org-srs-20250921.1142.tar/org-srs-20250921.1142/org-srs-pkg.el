;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20250921.1142"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "2421e1072aeb6b19674747c9217720cbe1630102"
  :revdesc "2421e1072aeb"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
