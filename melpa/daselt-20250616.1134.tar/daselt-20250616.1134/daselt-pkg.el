;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20250616.1134"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "ec14c0a3457a14f98ecaee7df1505ebdd7f9ae10"
  :revdesc "ec14c0a3457a"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
