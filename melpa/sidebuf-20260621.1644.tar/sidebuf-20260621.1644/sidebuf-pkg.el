;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sidebuf" "20260621.1644"
  "Buffer list sidebar panel."
  '((emacs "27.1"))
  :url "https://github.com/rain-64/sidebuf"
  :commit "bac206ea46bdf8450317d29b98dfcd970aa6e85e"
  :revdesc "bac206ea46bd"
  :keywords '("convenience" "buffers")
  :authors '(("rain-64" . "https://github.com/rain-64"))
  :maintainers '(("rain-64" . "https://github.com/rain-64")))
