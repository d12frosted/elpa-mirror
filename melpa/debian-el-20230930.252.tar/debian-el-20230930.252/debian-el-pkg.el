(define-package "debian-el" "20230930.252" "Emacs helpers specific to Debian users" 'nil :commit "484a03874b975f8566625be7f9310cb072667925")
;; Local Variables:
;; no-byte-compile: t
;; End:
