;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260620.1423"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "67fd8abea687a8d0d574b740a73edc55be29a648"
  :revdesc "67fd8abea687"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
