;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20260627.1316"
  "Integration for the command-line tool `fasd'."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "249334222d13b5ea6d4811833326358e8d0dd30a"
  :revdesc "249334222d13"
  :keywords '("convenience"))
