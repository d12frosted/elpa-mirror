;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20250505.1941"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "e75ebf5a88b02833d700bcf9ee4419c5888caf12"
  :revdesc "e75ebf5a88b0"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")))
