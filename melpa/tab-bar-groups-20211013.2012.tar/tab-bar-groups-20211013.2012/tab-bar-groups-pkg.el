;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-bar-groups" "20211013.2012"
  "Tab groups for the tab bar."
  '((emacs "27.1")
    (s     "1.12.0"))
  :url "https://github.com/fritzgrabo/tab-bar-groups"
  :commit "a0389d87d2e793055dd74ae85b4593aa1d2720fd"
  :revdesc "a0389d87d2e7"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
