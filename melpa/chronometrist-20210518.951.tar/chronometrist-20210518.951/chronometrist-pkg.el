(define-package "chronometrist" "20210518.951" "A time tracker with a nice interface"
  '((emacs "25.1")
    (literate-elisp "0.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "d0d065a7d99ac77d0379ae630018b7bc2d6663b1" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "https://github.com/contrapunctus-1/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
