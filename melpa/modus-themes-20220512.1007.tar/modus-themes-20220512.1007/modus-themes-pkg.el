(define-package "modus-themes" "20220512.1007" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "0494b9bfa00cd3170513680641b06f34bf7eb8a2" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
