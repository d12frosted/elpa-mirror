;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261111.709"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "12ed43f170f6a0fae7d25e4fe4221617d3490f30"
  :revdesc "12ed43f170f6"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
