;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markup-faces" "20141110.817"
  "Collection of faces for markup language modes."
  ()
  :url "https://github.com/sensorflo/markup-faces"
  :commit "98a807ed82473eb41c6a201ed7ef816d6bcd67b0"
  :revdesc "98a807ed8247"
  :keywords '("wp" "faces")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Florian Kaufmann" . "sensorflo@gmail.com")))
