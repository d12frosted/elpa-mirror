;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lurk-mode" "20230120.2226"
  "A major mode for editing lurk files."
  '((emacs "25.1"))
  :url "https://github.com/lurk-lang/lurk-emacs"
  :commit "59a3f956944a5ddd43cfd57deeff6b647fc46554"
  :revdesc "59a3f956944a"
  :keywords '("languages" "lurk" "lisp")
  :maintainers '(("Jeff Weiss" . "jweiss@protocol.ai")))
