;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyfun-mode" "20261123.2351"
  "Major mode for the Pyfun language."
  '((emacs "29.1"))
  :url "https://github.com/simontreanor/Pyfun"
  :commit "71cc00a5108cf3a2f7afa35110445c4b802f0999"
  :revdesc "71cc00a5108c"
  :keywords '("languages")
  :authors '(("Simon Treanor" . "https://github.com/simontreanor"))
  :maintainers '(("Simon Treanor" . "https://github.com/simontreanor")))
