;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stillness-mode" "20260817.1547"
  "Prevent windows from jumping on minibuffer activation."
  '((emacs "26.1")
    (dash  "2.18.0"))
  :url "https://github.com/neeasade/stillness-mode.el"
  :commit "3d014c504884fae408c9316f27be855fc809cc87"
  :revdesc "3d014c504884"
  :keywords '("convenience"))
