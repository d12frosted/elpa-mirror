;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260117.1520"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "7d217dde516f69a648671e7a775b8aa4e233eb92"
  :revdesc "7d217dde516f"
  :keywords '("convenience"))
