;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260527.1207"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "1cf1318c2920af5712c31e9ad14b28abf0b4246f"
  :revdesc "1cf1318c2920"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
