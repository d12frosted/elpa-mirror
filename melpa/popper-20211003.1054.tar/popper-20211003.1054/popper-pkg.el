(define-package "popper" "20211003.1054" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "918306c2afbb09e92f7cc704ddbabe9701bef6f8" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
