;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lazy-ruff" "20241127.1414"
  "Integration with the Ruff Python linter/formatter."
  '((emacs "24.3")
    (org   "9.1"))
  :url "https://github.com/christophermadsen/emacs-lazy-ruff"
  :commit "88b917750729a7ab9bbcc798cfac9245a46909b2"
  :revdesc "88b917750729"
  :keywords '("languages" "tools"))
