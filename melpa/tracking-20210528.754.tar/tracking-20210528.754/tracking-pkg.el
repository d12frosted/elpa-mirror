(define-package "tracking" "20210528.754" "Buffer modification tracking" 'nil :commit "c0b2f997b3b73640d635ee84627bb8cf36c9adfe" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
