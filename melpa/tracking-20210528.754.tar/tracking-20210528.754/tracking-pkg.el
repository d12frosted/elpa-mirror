(define-package "tracking" "20210528.754" "Buffer modification tracking" 'nil :commit "b0e0b73faa60de77e569e87dfc458fb95d180467" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
