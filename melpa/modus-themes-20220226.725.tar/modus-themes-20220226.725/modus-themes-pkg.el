(define-package "modus-themes" "20220226.725" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "c08d623721e8c5d3fec71dd5b09dbe55d38d8ea3" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
