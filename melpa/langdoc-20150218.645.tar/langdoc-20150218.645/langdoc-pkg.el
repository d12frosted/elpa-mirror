;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "langdoc" "20150218.645"
  "Help to define help document mode for various languages."
  '((cl-lib "0.2"))
  :url "https://github.com/tom-tan/langdoc/"
  :commit "2c7223bacb116992d700ecb19a60df5c09c63424"
  :revdesc "2c7223bacb11"
  :keywords '("convenience" "eldoc")
  :authors '(("Tomoya Tanjo" . "ttanjo@gmail.com"))
  :maintainers '(("Tomoya Tanjo" . "ttanjo@gmail.com")))
