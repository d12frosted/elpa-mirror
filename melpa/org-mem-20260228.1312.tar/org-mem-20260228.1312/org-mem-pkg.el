;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260228.1312"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "0440fe37e414872fbfdebeddca24207b502c0862"
  :revdesc "0440fe37e414"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
