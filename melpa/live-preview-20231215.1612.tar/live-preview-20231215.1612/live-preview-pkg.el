;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-preview" "20231215.1612"
  "Live preview by any shell command while editing."
  '((emacs "24.4"))
  :url "https://github.com/lassik/emacs-live-preview"
  :commit "135f2b9a8ecf81d00cf92175d144a33561e36f4c"
  :revdesc "135f2b9a8ecf"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
