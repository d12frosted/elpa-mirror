(define-package "kele" "20230115.2315" "Spritzy Kubernetes cluster management"
  '((emacs "27.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (plz "0.3")
    (request "0.3.2")
    (yaml "0.5.1"))
  :commit "c0abe726f7cf2407539c9279393a9f923ac6ede7" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
