;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260616.505"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "1fb7d7416f6abaa4db1cb45488ca0fdef1dd2ccf"
  :revdesc "1fb7d7416f6a"
  :keywords '("data" "extensions"))
