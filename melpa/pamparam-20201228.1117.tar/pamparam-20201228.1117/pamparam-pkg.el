(define-package "pamparam" "20201228.1117" "Simple and fast flashcards."
  '((emacs "26.1")
    (lispy "0.27.0")
    (worf "0.1.0")
    (ivy-posframe "0.5.5"))
  :commit "66827c3fe86a3e50aa2d594e80cccc0fc1064f3b" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("outlines" "hypermedia" "flashcards" "memory")
  :url "https://github.com/abo-abo/pamparam")
;; Local Variables:
;; no-byte-compile: t
;; End:
