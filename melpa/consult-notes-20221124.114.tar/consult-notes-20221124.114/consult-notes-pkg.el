(define-package "consult-notes" "20221124.114" "Manage notes with consult"
  '((emacs "27.1")
    (consult "0.17")
    (s "1.12.0")
    (dash "2.19"))
  :commit "3c73e4f6056ce938f9b9f554970f990c0b256538" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience")
  :url "https://github.com/mclear-tools/consult-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
