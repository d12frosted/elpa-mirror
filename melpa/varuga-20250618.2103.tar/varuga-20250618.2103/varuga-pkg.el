;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "varuga" "20250618.2103"
  "Send ical calendar invites by email."
  '((emacs "27.1"))
  :url "https://git.systemreboot.net/varuga"
  :commit "f055e8572b2e4d7a700392b8a71bacbfdc8e442a"
  :revdesc "f055e8572b2e"
  :authors '(("Arun Isaac" . "arunisaac@systemreboot.net"))
  :maintainers '(("Arun Isaac" . "arunisaac@systemreboot.net")))
