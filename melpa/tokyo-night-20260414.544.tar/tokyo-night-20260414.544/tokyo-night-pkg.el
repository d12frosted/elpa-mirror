;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20260414.544"
  "Shared infrastructure for Tokyo Night themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "743d9ce693424434e516c096bf5320cad65277ad"
  :revdesc "743d9ce69342"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
