;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251219.1425"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "38ca8b5d47c16aa33a52214bb3bf4fdb4fd2c1da"
  :revdesc "38ca8b5d47c1"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
