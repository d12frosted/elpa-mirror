;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20251203.2141"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "f491974456ea7b0e33a3c2abc98483175a731334"
  :revdesc "f491974456ea"
  :keywords '("languages"))
