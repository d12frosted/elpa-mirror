;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "api-credit" "20260908.1434"
  "AI API balance in the modeline."
  '((emacs "25.1"))
  :url "https://github.com/OverbearingPearl/api-credit"
  :commit "2ac9925d2d2f1fcdd42ace6980efdb8ea220b4d5"
  :revdesc "2ac9925d2d2f"
  :keywords '("comm" "convenience")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
