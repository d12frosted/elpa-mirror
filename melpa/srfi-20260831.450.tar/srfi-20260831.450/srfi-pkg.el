;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260831.450"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "4b513b1ec369d07a785453ff9d0c045da5d47229"
  :revdesc "4b513b1ec369"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
