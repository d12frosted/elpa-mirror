;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-ido" "20250330.1737"
  "Support using Ido in Magit."
  '((ido-completing-read+ "4.14")
    (magit                "4.3.2"))
  :url "https://github.com/emacsorphanage/magit-ido"
  :commit "2b94abf65a208e4c844d046217350efbf77cf582"
  :revdesc "2b94abf65a20"
  :authors '(("Jonas Bernoulli" . "emacs.magit-ido@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit-ido@jonas.bernoulli.dev")))
