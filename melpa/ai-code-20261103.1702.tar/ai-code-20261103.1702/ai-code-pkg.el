;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261103.1702"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "dc8640e0e0106c5355b40a83b647fde13781e742"
  :revdesc "dc8640e0e010"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
