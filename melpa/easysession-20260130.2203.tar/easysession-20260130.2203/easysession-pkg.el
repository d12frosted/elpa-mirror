;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260130.2203"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "611e826b60a99c80f4d10cdc56924570a9eed2b4"
  :revdesc "611e826b60a9"
  :keywords '("convenience"))
