(define-package "ghub" "20220618.1940" "Client libraries for Git forge APIs."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (let-alist "1.0.6")
    (treepy "0.1.1"))
  :commit "fb9d33b21b3105acc1fcbced851dca70c4be2ff8" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
