;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyfun-mode" "20261018.6"
  "Major mode for the Pyfun language."
  '((emacs "29.1"))
  :url "https://github.com/simontreanor/Pyfun"
  :commit "e5a01a201c94603e531eec69439cfca595ecf72c"
  :revdesc "e5a01a201c94"
  :keywords '("languages")
  :authors '(("Simon Treanor" . "https://github.com/simontreanor"))
  :maintainers '(("Simon Treanor" . "https://github.com/simontreanor")))
