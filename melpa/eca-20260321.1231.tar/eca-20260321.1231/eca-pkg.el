;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260321.1231"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "c0c8dca1267287f75e3841319d978bd2aeb2a8c4"
  :revdesc "c0c8dca12672"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
