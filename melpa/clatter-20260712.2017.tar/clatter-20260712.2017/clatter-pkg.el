;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260712.2017"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "c03a31ff0b1bc31561954a6b6fd629ae13e87f64"
  :revdesc "c03a31ff0b1b"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
