(define-package "alarm-clock" "20220819.1538" "Alarm Clock"
  '((emacs "24.4")
    (f "0.17.0"))
  :commit "2ca4e5177d2ca9a21fa52f4b4b75711617d5424c" :authors
  '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainer
  '("Steve Lemuel" . "wlemuel@hotmail.com")
  :keywords
  '("calendar" "tools" "convenience")
  :url "https://github.com/wlemuel/alarm-clock")
;; Local Variables:
;; no-byte-compile: t
;; End:
