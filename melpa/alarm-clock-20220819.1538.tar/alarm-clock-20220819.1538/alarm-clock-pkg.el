(define-package "alarm-clock" "20220819.1538" "Alarm Clock"
  '((emacs "24.4")
    (f "0.17.0"))
  :commit "ec41b150ef5ecdd23e732ff41c14c4d6158bacf9" :authors
  '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainer
  '("Steve Lemuel" . "wlemuel@hotmail.com")
  :keywords
  '("calendar" "tools" "convenience")
  :url "https://github.com/wlemuel/alarm-clock")
;; Local Variables:
;; no-byte-compile: t
;; End:
