(define-package "kiwix" "20201231.209" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (request "0.3.0"))
  :commit "9ab1437440d5e2c940a431b2d3454a73d0640435" :authors
  (("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  ("stardiviner" . "numbchild@gmail.com")
  :keywords
  ("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
