(define-package "meow" "20220722.1703" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "7c310df591c6cb0846ae3161e5713f62f4eab7ee" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
