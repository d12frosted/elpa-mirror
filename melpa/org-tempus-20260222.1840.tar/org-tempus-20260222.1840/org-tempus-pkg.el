;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tempus" "20260222.1840"
  "Enhance Org time tracking."
  '((emacs "27.1"))
  :url "https://github.com/rul/org-tempus"
  :commit "f3912ccd9032bea28ff0ee4b3d49a90e17097e26"
  :revdesc "f3912ccd9032"
  :keywords '("calendar")
  :authors '(("Raul Benencia" . "id@rbenencia.name"))
  :maintainers '(("Raul Benencia" . "id@rbenencia.name")))
