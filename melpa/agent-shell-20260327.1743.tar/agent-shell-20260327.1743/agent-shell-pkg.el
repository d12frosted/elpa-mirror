;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260327.1743"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "63f64772cbaa1f4c77d8e6644a60c9a4b6b5648e"
  :revdesc "63f64772cbaa")
