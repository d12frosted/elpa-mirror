(define-package "mistty" "20230921.1634" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "76eda346729608c2e77026d202782b2406dc79b9" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
