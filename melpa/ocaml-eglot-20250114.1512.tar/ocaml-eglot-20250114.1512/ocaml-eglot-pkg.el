;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocaml-eglot" "20250114.1512"
  "An OCaml companion for Eglot."
  '((emacs "29.1"))
  :url "https://github.com/tarides/ocaml-eglot"
  :commit "904707ea0eecc9edaa427135c8f4897079351ae3"
  :revdesc "904707ea0eec"
  :keywords '("ocaml" "languages")
  :authors '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com"))
  :maintainers '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com")))
