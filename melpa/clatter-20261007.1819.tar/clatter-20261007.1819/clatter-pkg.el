;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20261007.1819"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "1a589d20f787c985e149ba368fc519b1a746e4a2"
  :revdesc "1a589d20f787"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
