(define-package "consult" "20230129.112" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "835921c022cc14eecad10060e3aa89936e5ee85c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
