;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260605.649"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "c3aa204f5538d6b125fb86372ba5d6baeb3d35a0"
  :revdesc "c3aa204f5538"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
