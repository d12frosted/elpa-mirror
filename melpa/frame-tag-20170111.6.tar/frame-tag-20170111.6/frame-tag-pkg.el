;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-tag" "20170111.6"
  "Minor mode that assigns a unique number to each frame for easy switching."
  '((cl-lib "0.5"))
  :url "https://github.com/liangzan/frame-tag.el"
  :commit "73d6163568c7d32952175e663318b872f995a4e5"
  :revdesc "73d6163568c7"
  :keywords '("frame" "movement")
  :authors '(("Wong Liang Zan" . "zan@liangzan.net"))
  :maintainers '(("Wong Liang Zan" . "zan@liangzan.net")))
