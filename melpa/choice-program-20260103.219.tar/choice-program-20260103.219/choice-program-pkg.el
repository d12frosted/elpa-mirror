;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "choice-program" "20260103.219"
  "Parameter based program."
  '((emacs "29")
    (dash  "2.17.0"))
  :url "https://github.com/plandes/choice-program"
  :commit "a44798754e7392e87b005b2b9fa6a04b662662b0"
  :revdesc "a44798754e73"
  :keywords '("execution" "processes" "unix" "lisp"))
