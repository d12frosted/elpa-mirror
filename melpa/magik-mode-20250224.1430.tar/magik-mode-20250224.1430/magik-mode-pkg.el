;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250224.1430"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "224f0eca413f9adea6078d1213fa61f300e25133"
  :revdesc "224f0eca413f"
  :keywords '("languages"))
