;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241017.1753"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "e2ff708b959f6ba60f6b32acd978b86f7640567f"
  :revdesc "e2ff708b959f"
  :keywords '("convenience" "modal-editing"))
