;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20260113.244"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "e2b153750752f8991718cfe9c0abaeafa05f493e"
  :revdesc "e2b153750752"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
