;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20250617.1940"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "b694d50dc1f0dd4c5d09fc12ddccf4b64923b978"
  :revdesc "b694d50dc1f0"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
