(define-package "dwim-shell-command" "20220809.738" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "f89b831f6f66326f63905b800d95bda233bf9765" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
