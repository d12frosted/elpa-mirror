;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250516.939"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.8.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "bd30eeec2d872ad6980c87c8ad826e8bf56c62e6"
  :revdesc "bd30eeec2d87"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
