(define-package "evil-surround" "20230912.1705" "emulate surround.vim from Vim"
  '((evil "1.2.12"))
  :commit "0d860be74165ceb8314742e4191cdad693f40a6d" :authors
  '(("Tim Harper <timcharper at gmail dot com>")
    ("Vegard Øye <vegard_oye at hotmail dot com>"))
  :maintainers
  '(("Tom Dalziel" . "tom.dalziel@gmail.com"))
  :maintainer
  '("Tom Dalziel" . "tom.dalziel@gmail.com")
  :keywords
  '("emulation" "vi" "evil"))
;; Local Variables:
;; no-byte-compile: t
;; End:
