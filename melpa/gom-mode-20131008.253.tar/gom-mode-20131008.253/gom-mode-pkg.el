;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gom-mode" "20131008.253"
  "Major mode for Gomfile."
  ()
  :url "https://github.com/syohex/emacs-gom-mode"
  :commit "972e33df1d38ff323bc97de87477305826013701"
  :revdesc "972e33df1d38"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
