;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260215.2013"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "c6360e4643c8ead16fa68488d2116d77208c12f6"
  :revdesc "c6360e4643c8"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
