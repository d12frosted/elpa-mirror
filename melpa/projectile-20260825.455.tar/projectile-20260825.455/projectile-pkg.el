;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260825.455"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "5abaa50c48ee661181cf96a1a7c1131f2d619b51"
  :revdesc "5abaa50c48ee"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
