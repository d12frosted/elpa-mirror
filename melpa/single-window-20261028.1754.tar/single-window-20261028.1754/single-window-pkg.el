;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "single-window" "20261028.1754"
  "Always open buffers in the current window."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/single-window.el"
  :commit "77b7aa891a01f21ea084b9a4b159a27f5aff38f8"
  :revdesc "77b7aa891a01"
  :keywords '("convenience" "windows")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
