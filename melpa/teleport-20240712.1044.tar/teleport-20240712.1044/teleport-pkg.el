(define-package "teleport" "20240712.1044" "Integration for tsh (goteleport.com)"
  '((emacs "28.1")
    (dash "2.18.0"))
  :commit "c189e702489a05c728a9e73415755c2823e1ff67" :authors
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainers
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainer
  '("Caramel Hooves" . "caramel.hooves@protonmail.com")
  :keywords
  '("tools")
  :url "https://github.com/caramelhooves/teleport.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
