(define-package "dirvish" "20220113.518" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e4143a37a589032f638e0da0fe7be92188be9a43" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
