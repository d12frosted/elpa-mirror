(define-package "dir-treeview-themes" "20221106.2133" "Themes for dir-treeview"
  '((emacs "24.4")
    (dir-treeview "1.3.3"))
  :commit "1d2e19c1df9f68186d7d0fe4529c92f7112136a2" :authors
  '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainer
  '("Tilman Rassy" . "tilman.rassy@googlemail.com")
  :keywords
  '("tools" "convenience" "files")
  :url "https://github.com/tilmanrassy/emacs-dir-treeview-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
