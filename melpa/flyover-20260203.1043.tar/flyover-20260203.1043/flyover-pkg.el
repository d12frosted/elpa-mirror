;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20260203.1043"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "4e14ec26bf6668f4ba83171b70c62ad97743fed4"
  :revdesc "4e14ec26bf66"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
