;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20241124.514"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "c10ac32b0a241e62d92d91e79be5c67cac449864"
  :revdesc "c10ac32b0a24"
  :keywords '("outlines"))
