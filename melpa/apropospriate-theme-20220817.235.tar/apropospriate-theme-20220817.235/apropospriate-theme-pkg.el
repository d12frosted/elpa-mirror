(define-package "apropospriate-theme" "20220817.235" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "07265cc0122d3bde62615e8f5671e271598d95da")
;; Local Variables:
;; no-byte-compile: t
;; End:
