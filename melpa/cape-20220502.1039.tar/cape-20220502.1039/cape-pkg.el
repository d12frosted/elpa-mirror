(define-package "cape" "20220502.1039" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "d836397d9c025f03125fb4321abd48d557518bb6" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
