(define-package "alectryon" "20211018.321" "Toggle between Coq and reStructuredText"
  '((flycheck "31")
    (emacs "25.1"))
  :commit "135be1a851a1110dffe8bb349183b73a49a1f090" :authors
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://github.com/cpitclaudel/alectryon")
;; Local Variables:
;; no-byte-compile: t
;; End:
