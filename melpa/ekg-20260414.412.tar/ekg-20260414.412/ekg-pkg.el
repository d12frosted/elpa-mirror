;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260414.412"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "ac409f0a78bcffffbbf44d23a302b39fde43b966"
  :revdesc "ac409f0a78bc"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
