;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260104.1700"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "9a7913a7c7b9b8e076b38e7133122dc608e7667e"
  :revdesc "9a7913a7c7b9")
