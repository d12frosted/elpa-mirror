;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20251218.1852"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "7fc4e35ab163695272b2504b00b1a0958bd5ab65"
  :revdesc "7fc4e35ab163"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
