;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "semantic-thrift" "20251215.345"
  "Thrift LALR parser."
  '((thrift "0.0.1")
    (emacs  "28.2"))
  :url "https://github.com/jerryxgh/semantic-thrift"
  :commit "b4f999b41e07f387d7797ba5d417fb0b0c1762ee"
  :revdesc "b4f999b41e07"
  :keywords '("extensions" "thrift" "semantic")
  :authors '((nil . "GuanghuiXugh_xu@qq.com"))
  :maintainers '((nil . "GuanghuiXugh_xu@qq.com")))
