(define-package "immaterial-theme" "20201129.1847" "A flexible theme based on material design principles"
  '((emacs "25"))
  :commit "fe8875f116cead5bff6befb6c77a6ebb6f20a490" :keywords
  ("themes")
  :authors
  (("Peter Gardfjäll"))
  :maintainer
  ("Peter Gardfjäll")
  :url "https://github.com/petergardfjall/emacs-immaterial-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
