(define-package "org-timeblock" "20231124.1100" "Interactive SVG calendar for orgmode tasks"
  '((emacs "28.1")
    (compat "29.1")
    (org-ql "0.7")
    (org "9.0")
    (svg "1.1")
    (persist "0.5"))
  :commit "2d65c888e2516c28c51a68907c023199e7996c87" :authors
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainers
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainer
  '("Ilya Chernyshov" . "ichernyshovvv@gmail.com")
  :keywords
  '("org" "calendar" "timeblocking" "agenda")
  :url "https://github.com/ichernyshovvv/org-timeblock")
;; Local Variables:
;; no-byte-compile: t
;; End:
