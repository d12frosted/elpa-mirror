(define-package "emacsql-sqlite" "20230217.2219" "EmacSQL back-end for SQLite"
  '((emacs "25.1")
    (emacsql "3.1.1"))
  :commit "65357c6b8e96f4d1533bcc3100eeee6c34f70f46" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
