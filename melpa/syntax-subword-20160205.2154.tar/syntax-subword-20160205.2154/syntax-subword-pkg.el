;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syntax-subword" "20160205.2154"
  "Make operations on words more fine-grained."
  ()
  :url "https://github.com/jpkotta/syntax-subword"
  :commit "9aa9b3f846bfe2474370642458a693ac4760d9fe"
  :revdesc "9aa9b3f846bf"
  :authors '(("Jonathan Kotta" . "jpkotta@gmail.com"))
  :maintainers '(("Jonathan Kotta" . "jpkotta@gmail.com")))
