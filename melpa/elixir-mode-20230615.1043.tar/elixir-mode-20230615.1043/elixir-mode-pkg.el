(define-package "elixir-mode" "20230615.1043" "Major mode for editing Elixir files"
  '((emacs "25"))
  :commit "6c7f2b2b358919c6a3dd857c9de66d32ca6f9a8c" :keywords
  '("languages" "elixir")
  :url "https://github.com/elixir-editors/emacs-elixir")
;; Local Variables:
;; no-byte-compile: t
;; End:
