(define-package "w3m" "20220805.157" "an Emacs interface to w3m" 'nil :commit "a8e2e5c7b7576afd7b097b40c6ca39e5717f97a5" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
