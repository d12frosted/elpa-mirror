(define-package "w3m" "20220805.157" "an Emacs interface to w3m" 'nil :commit "c8b94ebeab34dcb5f3d26e65b6cbd92de6cd054c" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
