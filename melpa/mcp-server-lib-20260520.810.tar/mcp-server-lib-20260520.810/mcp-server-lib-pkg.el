;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "20260520.810"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "77b2a5eb9b5082814e56ce5aa44baba1434c395a"
  :revdesc "77b2a5eb9b50"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
