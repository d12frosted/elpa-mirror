(define-package "moom" "20220830.1501" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "ba04944750dcb273532e5e0807e398c9b4e6b0f4" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
