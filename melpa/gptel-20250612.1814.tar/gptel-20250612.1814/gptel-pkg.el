;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250612.1814"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "fdd4ede799fdcbdf16f064a5b720ca507bbddca8"
  :revdesc "fdd4ede799fd"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
