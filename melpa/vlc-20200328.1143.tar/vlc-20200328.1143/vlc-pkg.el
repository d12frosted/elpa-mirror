;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vlc" "20200328.1143"
  "VideoLAN VLC Media Player Control."
  '((emacs "25.1"))
  :url "https://github.com/xuchunyang/vlc.el"
  :commit "07c4a12904f2700fb8420c4e71395fd59a5e6faa"
  :revdesc "07c4a12904f2"
  :keywords '("tools"))
