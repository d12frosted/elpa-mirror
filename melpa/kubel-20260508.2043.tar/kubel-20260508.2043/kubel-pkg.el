;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "20260508.2043"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "f2d64227c6d2ce0a3a9023345b230b5b2b30d147"
  :revdesc "f2d64227c6d2"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
