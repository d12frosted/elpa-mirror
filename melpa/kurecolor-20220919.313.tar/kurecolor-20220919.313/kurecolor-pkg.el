(define-package "kurecolor" "20220919.313" "color editing goodies"
  '((emacs "24.4")
    (s "1.12"))
  :commit "190756dc0046358e172cff7e9f94db23634a4485" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
