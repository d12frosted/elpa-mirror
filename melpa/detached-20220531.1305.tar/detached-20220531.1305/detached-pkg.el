(define-package "detached" "20220531.1305" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "6e7a236fa5858b7a9adae487bee7e767baf611e9" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
