;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "init-dir" "20260104.1727"
  "Init directory instead of just a single file."
  '((emacs          "27.1")
    (benchmark-init "1.2"))
  :url "https://github.com/chaosemer/init-dir"
  :commit "cc5a4676cbc698144c7a9bca465fccb5bdd4ace4"
  :revdesc "cc5a4676cbc6"
  :keywords '("extensions" "internal")
  :authors '(("Jared Finder" . "jared@finder.org"))
  :maintainers '(("Jared Finder" . "jared@finder.org")))
