(define-package "modus-themes" "20220830.206" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "fb7e470f060bdc340fed3e075d176ba3c1b321db" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
