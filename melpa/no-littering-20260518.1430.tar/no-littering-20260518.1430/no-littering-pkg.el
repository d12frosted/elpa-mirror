;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260518.1430"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "d9921c0a4e2655ec60acaf82ebab94adfcf3e878"
  :revdesc "d9921c0a4e26"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
