(define-package "fpga" "20230530.1157" "FPGA & ASIC Utils"
  '((emacs "28.1")
    (ggtags "0.9.0")
    (company "0.9.13"))
  :commit "49f24117a0f176fcfadd32e05bc894dc3845a0b8" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/gmlarumbe/fpga")
;; Local Variables:
;; no-byte-compile: t
;; End:
