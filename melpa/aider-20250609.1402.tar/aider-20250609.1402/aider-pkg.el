;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250609.1402"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.9.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "09082c2341e24c34d5a45dc6e9fa9dd8b74043b7"
  :revdesc "09082c2341e2"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
