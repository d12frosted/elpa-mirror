(define-package "geiser-guile" "20221022.2254" "Guile and Geiser talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (geiser "0.26.1"))
  :commit "a2ef4dbd7d63896f012896d497b17d8162f82178" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
