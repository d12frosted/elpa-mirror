;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dslide" "20241227.1017"
  "Domain Specific sLIDEs. Programmable Presentation."
  '((emacs "29.2"))
  :url "https://github.com/positron-solutions/dslide"
  :commit "8e36127be7d0cce257707d82bd5cfbe0166c1d6d"
  :revdesc "8e36127be7d0"
  :keywords '("convenience" "org-mode" "presentation" "narrowing")
  :authors '(("Positron" . "contact@positron.solutions"))
  :maintainers '(("Positron" . "contact@positron.solutions")))
