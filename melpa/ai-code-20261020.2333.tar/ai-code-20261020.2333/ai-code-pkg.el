;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261020.2333"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9c0b2cbc3a1db5cbc6e03fc2575feaaffb23caef"
  :revdesc "9c0b2cbc3a1d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
