(define-package "keg" "20211104.1438" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "24b6bd72761b21dc7b6241eb47951a57dd2101d8" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
