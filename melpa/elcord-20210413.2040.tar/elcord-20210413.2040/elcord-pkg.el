(define-package "elcord" "20210413.2040" "Allows you to integrate Rich Presence from Discord"
  '((emacs "25.1"))
  :commit "b25f9a9f6f2263f3cff5893e9733cc9ec1d6c1dc" :authors
  '(("heatingdevice")
    ("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com"))
  :maintainer
  '("heatingdevice")
  :keywords
  '("games")
  :url "https://github.com/Mstrodl/elcord")
;; Local Variables:
;; no-byte-compile: t
;; End:
