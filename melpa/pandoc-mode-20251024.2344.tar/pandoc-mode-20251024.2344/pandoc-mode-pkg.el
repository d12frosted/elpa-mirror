;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pandoc-mode" "20251024.2344"
  "Minor mode for interacting with Pandoc."
  ()
  :url "http://joostkremers.github.io/pandoc-mode/"
  :commit "da577c6f5ac091d5133955d9e1766f43e8bf96bd"
  :revdesc "da577c6f5ac0"
  :keywords '("text" "pandoc")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
