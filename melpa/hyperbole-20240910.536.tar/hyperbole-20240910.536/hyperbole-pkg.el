(define-package "hyperbole" "20240910.536" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.2"))
  :commit "246ab46e6566e353f603dc58253e9fabf37a0c01" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainer
  '("Robert Weiner" . "rsw@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
