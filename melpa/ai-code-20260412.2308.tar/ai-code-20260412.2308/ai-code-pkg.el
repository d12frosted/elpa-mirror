;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260412.2308"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b46e06834b41a2a13085818dbd03603ca33459c0"
  :revdesc "b46e06834b41"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
