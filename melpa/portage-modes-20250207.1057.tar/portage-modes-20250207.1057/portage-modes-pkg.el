;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "portage-modes" "20250207.1057"
  "Major modes for editing Portage config files."
  ()
  :url "https://github.com/OpenSauce04/portage-modes"
  :commit "10ac263d717ec771e79fdfc1309ea822ec4ba501"
  :revdesc "10ac263d717e"
  :authors '(("OpenSauce" . "opensauce04@gmail.com"))
  :maintainers '(("OpenSauce" . "opensauce04@gmail.com")))
