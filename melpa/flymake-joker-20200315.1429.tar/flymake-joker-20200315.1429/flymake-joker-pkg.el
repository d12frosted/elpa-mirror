;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-joker" "20200315.1429"
  "Add Clojure syntax checker (via Joker) to flymake."
  '((emacs            "26.1")
    (flymake-quickdef "0.1.1"))
  :url "https://github.com/beetleman/flymake-joker"
  :commit "fc132beedac9e6f415b72e578e77318fd13af9ee"
  :revdesc "fc132beedac9"
  :authors '(("Mateusz Probachta" . "mateusz.probachta@gmail.com"))
  :maintainers '(("Mateusz Probachta" . "mateusz.probachta@gmail.com")))
