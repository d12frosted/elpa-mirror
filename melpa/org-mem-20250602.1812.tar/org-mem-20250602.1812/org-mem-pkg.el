;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250602.1812"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "38959dd834dde799c94e6823847ef0c7523d8a5f"
  :revdesc "38959dd834dd"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
