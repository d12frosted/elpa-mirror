(define-package "dirvish" "20220601.406" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "1358cd49edacdf0ce93b2e3307b95b4271083f00" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
