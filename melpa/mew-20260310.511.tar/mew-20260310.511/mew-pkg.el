;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260310.511"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "9cbe1f910f3b8909caa28af588c05d243e2f8f8a"
  :revdesc "9cbe1f910f3b")
