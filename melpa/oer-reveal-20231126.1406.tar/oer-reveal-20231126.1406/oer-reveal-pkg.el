(define-package "oer-reveal" "20231126.1406" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.22.0"))
  :commit "a0cf45cbe9dc18e646d2ce4f4be440160e7e91cb" :authors
  '(("Jens Lechtenbörger"))
  :maintainers
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
