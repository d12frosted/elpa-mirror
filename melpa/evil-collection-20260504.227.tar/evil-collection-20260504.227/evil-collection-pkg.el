;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260504.227"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "12ac598b76eaba5be59197c2af0c533a294abd3d"
  :revdesc "12ac598b76ea"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
