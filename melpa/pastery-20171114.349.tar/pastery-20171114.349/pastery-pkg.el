;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pastery" "20171114.349"
  "Paste snippets to pastery.net."
  '((emacs   "24.4")
    (request "0.2.0"))
  :url "https://github.com/diasbruno/pastery.el"
  :commit "4493be98b743b4d062cb4e00760125e394a55022"
  :revdesc "4493be98b743"
  :keywords '("tools")
  :authors '(("Bruno Dias" . "dias.h.bruno@gmail.com"))
  :maintainers '(("Bruno Dias" . "dias.h.bruno@gmail.com")))
