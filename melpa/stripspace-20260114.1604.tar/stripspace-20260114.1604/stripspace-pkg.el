;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260114.1604"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "e2671ccdd30a950ed84105e872ec564d74bef3ba"
  :revdesc "e2671ccdd30a"
  :keywords '("convenience"))
