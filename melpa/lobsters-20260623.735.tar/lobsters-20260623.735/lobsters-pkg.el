;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lobsters" "20260623.735"
  "A Lobsters client."
  '((emacs              "25.1")
    (request            "0.2.0")
    (visual-fill-column "2.4"))
  :url "https://github.com/tanrax/lobsters.el"
  :commit "41ca67e5827793e91834bf03cdefab581783c3d5"
  :revdesc "41ca67e58277"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
