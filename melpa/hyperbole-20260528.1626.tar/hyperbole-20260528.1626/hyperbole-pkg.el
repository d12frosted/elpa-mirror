;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260528.1626"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "9ef5fb795c68f2881911a90a79f399efef9e32d6"
  :revdesc "9ef5fb795c68"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
