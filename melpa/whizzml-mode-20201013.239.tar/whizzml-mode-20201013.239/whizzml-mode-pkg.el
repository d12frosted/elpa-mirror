;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whizzml-mode" "20201013.239"
  "Programming mode for editing WhizzML files."
  '((emacs "24.4"))
  :url "https://github.com/whizzml/whizzml-mode"
  :commit "3dce3be0c32b9b2d259e462b4b27c530af47466a"
  :revdesc "3dce3be0c32b"
  :keywords '("languages" "lisp")
  :authors '(("Jose Antonio Ortega Ruiz" . "jao@bigml.com"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "jao@bigml.com")))
