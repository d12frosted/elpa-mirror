;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260314.2021"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "3ed61f1ccfc635f45efe948fdb452c23874d8184"
  :revdesc "3ed61f1ccfc6"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
