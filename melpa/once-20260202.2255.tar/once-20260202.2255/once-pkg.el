;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "once" "20260202.2255"
  "Add-hook and eval-after-load, but only once."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/once"
  :commit "3c3b778d557ff913ec3935c3a1711b44e5d18156"
  :revdesc "3c3b778d557f"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
