(define-package "kconfig-ref" "20230220.1207" "A simple package for looking up kconfig symbol quickly"
  '((emacs "24.4")
    (ripgrep "0.4.0")
    (projectile "2.7.0"))
  :commit "dfb127fa5ac003a06f108d2e876c84a1931e5678" :authors
  '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers
  '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainer
  '("Jason Kim" . "sukbeom.kim@gmail.com")
  :keywords
  '("tools" "kconfig" "linux" "kernel")
  :url "https://github.com/seokbeomkim/kconfig-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
