;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260308.333"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "7fdc937947374d37a1382e03db1a03e502c9eb05"
  :revdesc "7fdc93794737"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
