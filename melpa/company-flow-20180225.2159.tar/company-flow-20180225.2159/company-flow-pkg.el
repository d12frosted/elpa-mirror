;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-flow" "20180225.2159"
  "Flow backend for company-mode."
  '((company "0.8.0")
    (dash    "2.13.0"))
  :url "https://github.com/aaronjensen/company-flow"
  :commit "76ef585c70d2a3206c2eadf24ba61e59124c3a16"
  :revdesc "76ef585c70d2"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
