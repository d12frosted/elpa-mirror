(define-package "buffer-manage" "20201217.2302" "Manage buffers"
  '((emacs "26.1")
    (choice-program "0.13")
    (dash "2.17.0"))
  :commit "06c7e0188a291c1fb21311c5ae7931dc7ce94099" :keywords
  ("internal" "maint")
  :authors
  (("Paul Landes"))
  :maintainer
  ("Paul Landes")
  :url "https://github.com/plandes/buffer-manage")
;; Local Variables:
;; no-byte-compile: t
;; End:
