;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20261008.2331"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "da793dca2d36f46bf83508a3468e31466d91f02f"
  :revdesc "da793dca2d36"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
