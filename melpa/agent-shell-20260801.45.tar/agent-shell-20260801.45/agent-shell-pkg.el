;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260801.45"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4ffd013ed54c79a184d5deee264e8bcfd4082d27"
  :revdesc "4ffd013ed54c")
