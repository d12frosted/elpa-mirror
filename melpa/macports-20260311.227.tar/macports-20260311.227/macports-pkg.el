;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macports" "20260311.227"
  "A porcelain for MacPorts."
  '((emacs     "26.1")
    (transient "0.1.0"))
  :url "https://github.com/amake/macports.el"
  :commit "971f50ed908ac846c4fba957eb1e30fef6a83852"
  :revdesc "971f50ed908a"
  :keywords '("convenience"))
