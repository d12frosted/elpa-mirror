;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260226.1040"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "365965232cff300d05d874703eb5e3cf297b350b"
  :revdesc "365965232cff"
  :keywords '("convenience" "text"))
