(define-package "async" "20240714.558" "Asynchronous processing in Emacs"
  '((emacs "24.4"))
  :commit "3cd3464130981263325c3faf09eb3c8e0561522a" :authors
  '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("async")
  :url "https://github.com/jwiegley/emacs-async")
;; Local Variables:
;; no-byte-compile: t
;; End:
