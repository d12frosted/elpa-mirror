(define-package "aangit" "20231017.2022" "Quickly scaffold new Angular apps with Aangit"
  '((emacs "29.1")
    (transient "0.4"))
  :commit "68aeb3761b732daedd468c9f7593947cf4cb1d9a" :authors
  '(("Steven Edwards" . "steven@stephenwithav.io"))
  :maintainers
  '(("Steven Edwards" . "steven@stephenwithav.io"))
  :maintainer
  '("Steven Edwards" . "steven@stephenwithav.io")
  :keywords
  '("angular" "tools")
  :url "https://github.com/stephenwithav/aangit")
;; Local Variables:
;; no-byte-compile: t
;; End:
