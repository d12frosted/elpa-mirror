;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260512.639"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b17467866f49750121892c479718733ed3129156"
  :revdesc "b17467866f49"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
