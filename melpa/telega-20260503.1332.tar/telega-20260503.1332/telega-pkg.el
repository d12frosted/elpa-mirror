;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260503.1332"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "a1804b6fdc5bbfc3bcb99042a3f56ebdb6da3acc"
  :revdesc "a1804b6fdc5b"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
