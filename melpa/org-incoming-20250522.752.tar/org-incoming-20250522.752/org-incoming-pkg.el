;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-incoming" "20250522.752"
  "Sort incoming PDFs into your org files."
  '((emacs    "24.4")
    (dash     "2.19.1")
    (datetime "0.7.2")
    (s        "1.13.1"))
  :url "https://github.com/tinloaf/org-incoming"
  :commit "e702e208326a583e44e4e0c6bf7d9ce397a97453"
  :revdesc "e702e208326a"
  :keywords '("files")
  :authors '(("Lukas Barth" . "mail@tinloaf.de"))
  :maintainers '(("Lukas Barth" . "mail@tinloaf.de")))
