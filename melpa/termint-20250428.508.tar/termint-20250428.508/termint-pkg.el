;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "20250428.508"
  "Run REPLs in a terminal backend."
  '((emacs "29"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "3ee989c17445cfd8f48ded96f43fdcb8b3a4eef4"
  :revdesc "3ee989c17445"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
