(define-package "verb" "20210429.2113" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "0d7f7d36f6ae8130a9bd40845f156a3e3b30eb49" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
