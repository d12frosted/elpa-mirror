;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "writefreely" "20241222.1909"
  "Push your Org files as markdown to a writefreely instance."
  '((emacs   "24.3")
    (org     "9.0")
    (ox-hugo "0.12")
    (request "0.3"))
  :url "https://github.com/dangom/writefreely.el"
  :commit "cfcd21b82dc4a4543efb6209fc0a4f4bc3c78e4a"
  :revdesc "cfcd21b82dc4"
  :keywords '("convenience")
  :authors '(("Daniel Gomez" . "d.gomezatposteodotorg"))
  :maintainers '(("Daniel Gomez" . "d.gomezatposteodotorg")))
