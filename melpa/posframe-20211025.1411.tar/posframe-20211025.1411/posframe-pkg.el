(define-package "posframe" "20211025.1411" "Pop a posframe (just a frame) at point"
  '((emacs "26"))
  :commit "70ba4e77c114d980c0d87ed1f6b201188a3f8954" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
