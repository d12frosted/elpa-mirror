;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-erlang" "20170123.538"
  "Company backend based on ivy-erlang-complete."
  '((emacs               "24.4")
    (ivy-erlang-complete "0.1")
    (company             "0.9.2"))
  :url "https://github.com/s-kostyaev/company-erlang"
  :commit "bc0524a16f17b66c7397690e4ca0e004f09ea6c5"
  :revdesc "bc0524a16f17"
  :keywords '("tools")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
