;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260604.2125"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "1491be8d85014c6eaec81821dd13a0018402df82"
  :revdesc "1491be8d8501"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
