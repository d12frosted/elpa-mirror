(define-package "neil" "20231116.1226" "companion for Babashka Neil"
  '((emacs "27.1"))
  :commit "b8d7a1602ef848e5928a0f11add8973b91e0acf0" :authors
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainer
  '("Ag Ibragimov" . "agzam.ibragimov@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/babashka/neil")
;; Local Variables:
;; no-byte-compile: t
;; End:
