(define-package "flycheck" "20221110.824" "On-the-fly syntax checking"
  '((dash "2.12.1")
    (pkg-info "0.4")
    (let-alist "1.0.4")
    (seq "1.11")
    (emacs "24.3"))
  :commit "15559e8243b81d63c63f62a42d251f2db9e4995d" :authors
  '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "http://www.flycheck.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
