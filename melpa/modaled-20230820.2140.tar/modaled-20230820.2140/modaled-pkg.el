(define-package "modaled" "20230820.2140" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "c6d08582135dd047300e10b7a683151e4a9117af" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
