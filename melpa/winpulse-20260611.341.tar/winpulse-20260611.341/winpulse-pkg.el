;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winpulse" "20260611.341"
  "Momentary window background flash animation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/winpulse"
  :commit "dcfccb28394d8eb09a8bbbca69e466b334af461d"
  :revdesc "dcfccb28394d"
  :authors '(("Alvaro Ramirez" . "https://xenodium.com"))
  :maintainers '(("Alvaro Ramirez" . "https://xenodium.com")))
