(define-package "cnfonts" "20211129.424" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "73c87e82d3273d85db51365eb7056458ccff2b4a" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
