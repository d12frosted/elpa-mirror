(define-package "embark" "20210826.51" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d1b46dafdad8e1ed21075401c0022814e3d08fcd" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
