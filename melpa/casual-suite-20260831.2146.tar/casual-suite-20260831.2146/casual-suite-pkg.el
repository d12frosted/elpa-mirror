;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual-suite" "20260831.2146"
  "A suite of opinionated Transient UIs."
  '((emacs                 "30.1")
    (casual-avy            "3.0.0")
    (casual-symbol-overlay "3.0.0"))
  :url "https://github.com/kickingvegas/casual-suite"
  :commit "ea305a1242cc68133f530ea049e1f7fc121333d0"
  :revdesc "ea305a1242cc"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
