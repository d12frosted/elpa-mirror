;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260129.613"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "62becb2bbe53410e09dec85afbc816e92802f4de"
  :revdesc "62becb2bbe53"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
