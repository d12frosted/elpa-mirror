;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260303.747"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "146bbbd653d4f7787217c100098bbb8d7b0973e4"
  :revdesc "146bbbd653d4"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
