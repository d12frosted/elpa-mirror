(define-package "jest" "20220703.1950" "helpers to run jest"
  '((emacs "24.4")
    (dash "2.18.0")
    (magit-popup "2.12.0")
    (projectile "0.14.0")
    (s "1.12.0")
    (js2-mode "20180301")
    (cl-lib "0.6.1"))
  :commit "398fcd7920dc3e9865574f5228baeaba03d1d297" :authors
  '(("Edmund Miller" . "edmund.a.miller@gmail.com"))
  :maintainer
  '("Edmund Miller" . "edmund.a.miller@gmail.com")
  :keywords
  '("jest" "javascript" "testing")
  :url "https://github.com/emiller88/emacs-jest/")
;; Local Variables:
;; no-byte-compile: t
;; End:
