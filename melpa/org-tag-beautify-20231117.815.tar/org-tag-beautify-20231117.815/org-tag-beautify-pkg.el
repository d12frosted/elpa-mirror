(define-package "org-tag-beautify" "20231117.815" "Beautify Org mode tags"
  '((emacs "26.1")
    (nerd-icons "0.0.1"))
  :commit "c2e0f8e2400e308fdbc18e0e40533a21d5c5f4f0" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-tag-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
