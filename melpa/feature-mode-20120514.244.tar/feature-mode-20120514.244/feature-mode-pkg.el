(define-package "feature-mode" "20120514.244" "Major mode for editing Gherkin (i.e. Cucumber) user stories" 'nil :commit "4bd8f19da816115094beb4b0e085822eb298ac37" :authors
  '(("Michael Klishin"))
  :maintainer
  '("Michael Klishin")
  :url "https://github.com/michaelklishin/cucumber.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
