;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260803.155"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "1cf54ac295fcf7bb74c93398ebbe4e1c5174a028"
  :revdesc "1cf54ac295fc"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
