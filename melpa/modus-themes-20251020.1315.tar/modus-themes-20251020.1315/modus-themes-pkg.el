;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251020.1315"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "f55db96b093d76d08ff6a318a65d7a70c861db97"
  :revdesc "f55db96b093d"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
