;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260131.1357"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "a18c55194f43c2be3cea60168802d919f39cbd09"
  :revdesc "a18c55194f43"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
