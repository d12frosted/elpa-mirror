;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260306.1529"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "af5fc3ace4e815bae9d9f005fc0b3eba05ecc077"
  :revdesc "af5fc3ace4e8"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
