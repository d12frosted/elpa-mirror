;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fastnav" "20120211.1457"
  "Fast navigation and editing routines."
  ()
  :url "https://github.com/gleber/fastnav.el"
  :commit "1019ba2b61d1a070204099b23da347278a61bc89"
  :revdesc "1019ba2b61d1"
  :keywords '("nav" "fast" "fastnav" "navigation")
  :authors '(("Zsolt Terek" . "zsolt@google.com"))
  :maintainers '(("Zsolt Terek" . "zsolt@google.com")))
