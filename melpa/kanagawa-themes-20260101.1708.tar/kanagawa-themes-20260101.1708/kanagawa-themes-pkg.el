;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kanagawa-themes" "20260101.1708"
  "Elegant theme inspired by The Great Wave off Kanagawa."
  '((emacs "24.3"))
  :url "https://github.com/Fabiokleis/kanagawa-emacs"
  :commit "bb648eab6884dc2f8fa9f2c378295d8351cc22f2"
  :revdesc "bb648eab6884"
  :keywords '("themes" "faces")
  :authors '(("Sion Eltnam Sokaris" . "meritamen@sdf.org"))
  :maintainers '(("Fabio Kleis" . "fabiohkrc@gmail.com")
                 ("Sion Eltnam Sokaris" . "meritamen@sdf.org")))
