(define-package "occurx-mode" "20230605.1357" "Occur-like filtering of buffers with rx patterns"
  '((emacs "27.1")
    (rbit "0.1"))
  :commit "e17c67b3701339270b3428172cce0ea237810e5f" :authors
  '(("k32"))
  :maintainers
  '(("k32"))
  :maintainer
  '("k32")
  :keywords
  '("matching")
  :url "https://github.com/k32/occurx-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
