(define-package "tab-bar-notch" "20231116.1500" "Adjust tab-bar height for MacBook Pro notch"
  '((emacs "27.1"))
  :commit "c94d9ffe00de55a805d89af78126c83c623da049" :authors
  '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainers
  '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainer
  '("Jim Myhrberg" . "contact@jimeh.me")
  :keywords
  '("convenience" "hardware")
  :url "https://github.com/jimeh/tab-bar-notch")
;; Local Variables:
;; no-byte-compile: t
;; End:
