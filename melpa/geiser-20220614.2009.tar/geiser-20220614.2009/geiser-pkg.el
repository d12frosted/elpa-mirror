(define-package "geiser" "20220614.2009" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (project "0.8.1"))
  :commit "57637081c47e90a4a257fc5472d3cf49756bafde" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
