;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magic-latex-buffer" "20261007.1012"
  "Magically enhance LaTeX-mode font-locking for semi-WYSIWYG editing."
  '((cl-lib "0.5")
    (emacs  "25.1"))
  :url "http://zk-phi.github.io/"
  :commit "6d1c578ea60e51f91f0b43dde89787fa62245eba"
  :revdesc "6d1c578ea60e")
