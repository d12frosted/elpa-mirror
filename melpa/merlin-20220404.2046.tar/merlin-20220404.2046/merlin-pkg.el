(define-package "merlin" "20220404.2046" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "d21dcfa47afeff4cc21b80538322c3ba62453b7e" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
