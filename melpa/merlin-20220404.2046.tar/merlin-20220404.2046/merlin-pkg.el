(define-package "merlin" "20220404.2046" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "0fb973c5490216b1cfa364bbbe9da60f572d43c2" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
