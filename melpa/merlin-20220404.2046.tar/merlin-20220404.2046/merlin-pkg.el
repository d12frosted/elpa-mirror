(define-package "merlin" "20220404.2046" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "4b8acadcfc4d703d3afe7c6d16477567cfa15442" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
