(define-package "merlin" "20220404.2046" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "c447386d83522b26eb359d489eb6f5b7488203a5" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
