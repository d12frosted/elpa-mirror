;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nemerle" "20161029.2023"
  "Major mode for editing nemerle programs."
  ()
  :url "https://github.com/rsdn/nemerle"
  :commit "8818c5af5598e16ea59189e1e3245f0a3d7c78f0"
  :revdesc "8818c5af5598"
  :keywords '("nemerle" "mode" "languages")
  :authors '(("Jacek Sliwerski" . "rzyj@o2.pl"))
  :maintainers '(("Jacek Sliwerski" . "rzyj@o2.pl")))
