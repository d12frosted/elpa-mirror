;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-grammalecte" "20260907.1957"
  "Integrate Grammalecte with Flycheck."
  '((emacs    "29.1")
    (flycheck "32"))
  :url "https://git.umaneti.net/flycheck-grammalecte/"
  :commit "d2259c73503bb695017e3a3d4285b4a44fca39c6"
  :revdesc "d2259c73503b"
  :keywords '("i18n" "text")
  :authors '(("Guilhem Doulcier" . "guilhem.doulcier@espci.fr")
             ("tienne Pflieger" . "etienne@pflieger.bzh")))
