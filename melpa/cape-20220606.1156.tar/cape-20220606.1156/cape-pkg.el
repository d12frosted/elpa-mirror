(define-package "cape" "20220606.1156" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "d69114e8bd44d08c30b3374f4d7032d73621f1c6" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
