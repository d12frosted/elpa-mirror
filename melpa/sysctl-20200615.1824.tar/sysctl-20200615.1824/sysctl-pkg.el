;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sysctl" "20200615.1824"
  "Manage sysctl though org-mode."
  '((emacs "26"))
  :url "https://github.com/dantecatalfamo/sysctl.el"
  :commit "d8c2e18de1d7a3b2999a4d5054c0bbf30cb10fed"
  :revdesc "d8c2e18de1d7"
  :keywords '("sysctl" "tools" "unix"))
