;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rg-themes" "20250317.817"
  "The rg theme collection."
  '((emacs "25.1"))
  :url "https://github.com/raegnald/rg-themes"
  :commit "26aa40ebfa40a3a6190106d84060ca3ad1f75cc4"
  :revdesc "26aa40ebfa40"
  :keywords '("faces")
  :authors '(("Ronaldo Gligan" . "ronaldogligan@gmail.com"))
  :maintainers '(("Ronaldo Gligan" . "ronaldogligan@gmail.com")))
