;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260521.2003"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "aaa9913956d69de7cdf30c364befb3521b2d8852"
  :revdesc "aaa9913956d6"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
