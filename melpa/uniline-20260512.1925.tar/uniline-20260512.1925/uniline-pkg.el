;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260512.1925"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "3023362f0d65ceaf95985c613e5abf49c4732beb"
  :revdesc "3023362f0d65"
  :keywords '("convenience" "text"))
