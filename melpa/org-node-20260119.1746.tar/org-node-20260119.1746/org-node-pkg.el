;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260119.1746"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "7eba767815447105d9369d70fb30b9ce5c8e1ad3"
  :revdesc "7eba76781544"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
