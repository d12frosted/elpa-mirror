(define-package "cliphist" "20190920.149" "Read data from clipboard managers at Linux and Mac"
  '((emacs "24.3")
    (ivy "0.9.0"))
  :commit "3105e5c4b4d2d0338edb6effd9329426854b80b1" :keywords
  ("clipboard" "manager" "history")
  :authors
  (("Chen Bin <chenin DOT sh AT gmail DOT com>"))
  :maintainer
  ("Chen Bin <chenin DOT sh AT gmail DOT com>")
  :url "http://github.com/redguardtoo/cliphist")
;; Local Variables:
;; no-byte-compile: t
;; End:
