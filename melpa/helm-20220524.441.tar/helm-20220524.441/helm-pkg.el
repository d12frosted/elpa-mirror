(define-package "helm" "20220524.441" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.4")
    (popup "0.5.3"))
  :commit "49bf6a160a96057f56e51c69e9402569b12643f1" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
