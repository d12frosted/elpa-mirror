(define-package "live-py-mode" "20230227.18" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "b0721520a55b34a86144ebee5dd3f2d8287bf34c" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
