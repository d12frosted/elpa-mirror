;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix3" "20260907.849"
  "Frontend to experimental commands of Nix."
  '((emacs         "29.1")
    (promise       "1.1")
    (compat        "29.1")
    (magit-section "4.5")
    (s             "1.12")
    (transient     "0.13"))
  :url "https://github.com/emacs-twist/nix3.el"
  :commit "ffd3be0803e9238ceaca31338e194d34099042de"
  :revdesc "ffd3be0803e9"
  :keywords '("processes")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
