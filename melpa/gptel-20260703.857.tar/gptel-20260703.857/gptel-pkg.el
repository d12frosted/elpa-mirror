;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260703.857"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "9ff70ce03589862bb7d6e67d224f3230526a9311"
  :revdesc "9ff70ce03589"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
