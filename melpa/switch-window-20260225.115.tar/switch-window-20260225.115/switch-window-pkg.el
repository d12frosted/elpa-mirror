;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "switch-window" "20260225.115"
  "A *visual* way to switch window."
  '((emacs "24"))
  :url "https://github.com/dimitri/switch-window"
  :commit "a72cf11d21c1f24924a9faeaa9f5d213d8623141"
  :revdesc "a72cf11d21c1"
  :keywords '("convenience")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org")
             ("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")
                 ("Feng Shu" . "tumashu@163.com")))
