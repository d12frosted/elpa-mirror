;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperstitional-themes" "20260911.2025"
  "Weird themes with incremental palettes."
  '((emacs "24.1"))
  :url "https://github.com/precompute/hyperstitional-themes"
  :commit "83b56d201ddd1d6ff9e5888c007eb5443dc2b78a"
  :revdesc "83b56d201ddd"
  :authors '(("precompute" . "git@precompute.net"))
  :maintainers '(("precompute" . "git@precompute.net")))
