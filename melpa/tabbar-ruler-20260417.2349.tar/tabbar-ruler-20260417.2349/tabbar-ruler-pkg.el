;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabbar-ruler" "20260417.2349"
  "Pretty tabbar, autohide, use both tabbar/ruler."
  '((tabbar     "2.0.1")
    (powerline  "2.3")
    (mode-icons "0.4.0")
    (cl-lib     "0.5"))
  :url "https://github.com/mlf176f2/tabbar-ruler.el"
  :commit "2b72193e4fa9665236ec5dd17c47d0cf91ccc977"
  :revdesc "2b72193e4fa9"
  :keywords '("tabbar" "ruler mode" "menu" "tool bar."))
