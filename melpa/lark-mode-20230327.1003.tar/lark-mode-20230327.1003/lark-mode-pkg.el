(define-package "lark-mode" "20230327.1003" "Major mode for editing Lark parser code"
  '((emacs "24.3"))
  :commit "9e19b40df29d273cf3aec9ddd0e739d3b3d9b3a8" :authors
  '(("Ta Quang Trung"))
  :maintainers
  '(("Ta Quang Trung"))
  :maintainer
  '("Ta Quang Trung")
  :keywords
  '("languages")
  :url "https://github.com/taquangtrung/lark-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
