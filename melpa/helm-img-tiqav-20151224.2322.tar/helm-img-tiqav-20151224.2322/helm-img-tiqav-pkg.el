;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-img-tiqav" "20151224.2322"
  "An helm-source for joking."
  '((helm-img "0.0.1"))
  :url "https://github.com/l3msh0/helm-img"
  :commit "33a7e9508bc8f37d53320b56c92b53d321a57bb0"
  :revdesc "33a7e9508bc8"
  :keywords '("convenience")
  :authors '(("Sho Matsumoto" . "l3msh0_at_gmail.com")))
