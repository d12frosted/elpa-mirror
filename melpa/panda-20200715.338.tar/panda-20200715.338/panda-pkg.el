(define-package "panda" "20200715.338" "Client for Bamboo's REST API."
  '((emacs "25"))
  :commit "6508ac3228975c39d10a1caa70b9ce34ff3ed21d" :authors
  '(("Sebastian Monia" . "smonia@outlook.com"))
  :maintainers
  '(("Sebastian Monia" . "smonia@outlook.com"))
  :maintainer
  '("Sebastian Monia" . "smonia@outlook.com")
  :keywords
  '("maint" "tool")
  :url "https://github.com/sebasmonia/panda")
;; Local Variables:
;; no-byte-compile: t
;; End:
