;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "20261112.1622"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "f3a3cb0c6542ee497d8e9ec85f3603acb64736ca"
  :revdesc "f3a3cb0c6542")
