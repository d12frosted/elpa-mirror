(define-package "kiwix" "20201220.208" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (request "0.3.0"))
  :commit "3e1275df1a560b61ef1bf1aa3343f731c7cb8992" :keywords
  ("kiwix" "wikipedia")
  :authors
  (("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  ("stardiviner" . "numbchild@gmail.com")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
