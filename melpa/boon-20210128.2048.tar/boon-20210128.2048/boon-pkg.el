(define-package "boon" "20210128.2048" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (expand-region "0.10.0")
    (dash "2.12.0")
    (multiple-cursors "1.3.0"))
  :commit "28182f017e772fdb96384555b8124668293ad041")
;; Local Variables:
;; no-byte-compile: t
;; End:
