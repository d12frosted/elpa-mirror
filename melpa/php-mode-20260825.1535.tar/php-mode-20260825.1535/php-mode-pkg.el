;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20260825.1535"
  "Major mode for editing PHP code."
  '((emacs "28.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "0e32f79ffca49578eba452d38b62e434e517df5e"
  :revdesc "0e32f79ffca4"
  :keywords '("languages" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
