;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-raku" "20220420.732"
  "Raku support in Flycheck."
  '((emacs    "26.3")
    (flycheck "0.22"))
  :url "https://github.com/Raku/flycheck-raku"
  :commit "4da1970a75396aff1957b07f7579c1de6b817e6b"
  :revdesc "4da1970a7539"
  :keywords '("tools" "convenience")
  :authors '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com")
             ("Johnathon Weare" . "jrweare@gmail.com")
             ("Siavash Askari Nasr" . "siavash.askari.nasr@gmail.com"))
  :maintainers '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com")
                 ("Johnathon Weare" . "jrweare@gmail.com")
                 ("Siavash Askari Nasr" . "siavash.askari.nasr@gmail.com")))
