;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20250111.1310"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "567fc247cd9691fe8390281373f8e50353913ced"
  :revdesc "567fc247cd96"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
