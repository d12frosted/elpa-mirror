(define-package "paren-face" "20240611.12" "A face for parentheses in lisp modes"
  '((emacs "25.1")
    (compat "29.1.4.1"))
  :commit "29dcaf75e0af00f07ac035b486131280dac55fc8" :authors
  '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")
  :keywords
  '("faces" "lisp")
  :url "https://github.com/tarsius/paren-face")
;; Local Variables:
;; no-byte-compile: t
;; End:
