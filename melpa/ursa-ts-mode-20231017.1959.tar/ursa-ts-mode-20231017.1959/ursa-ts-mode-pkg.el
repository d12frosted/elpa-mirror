(define-package "ursa-ts-mode" "20231017.1959" "Major mode for Ursa, using tree-sitter"
  '((emacs "29.1"))
  :commit "c2cfc9e7beb26ba45f63b3a7cec500589127b964" :authors
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("ursalang" "languages" "tree-sitter")
  :url "https://github.com/ursalang/ursa-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
