;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250609.1745"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "d69a7da810c8feaa56da0e8518a892308643cc91"
  :revdesc "d69a7da810c8"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
