;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-crystal" "20200805.2344"
  "Add support for Crystal to Flycheck."
  '((flycheck "30"))
  :url "https://github.com/crystal-lang-tools/emacs-crystal-mode"
  :commit "f9e4db16ff9fdc6a296363aa35d19cfb4926e472"
  :revdesc "f9e4db16ff9f"
  :keywords '("tools" "crystal"))
