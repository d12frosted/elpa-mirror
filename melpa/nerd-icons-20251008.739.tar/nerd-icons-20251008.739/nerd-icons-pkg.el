;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20251008.739"
  "Emacs Nerd Font Icons Library."
  '((emacs "24.3"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "124a9a9ade68af8db98f64ff3a69303733278e77"
  :revdesc "124a9a9ade68"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
