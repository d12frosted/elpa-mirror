(define-package "nerd-icons" "20230408.2116" "Emacs Nerd Font Icons Library"
  '((emacs "24.3"))
  :commit "1589a878c203c1b6c44d5b071051be1e9e8d6103" :authors
  '(("Hongyu Ding" . "rainstormstudio@yahoo.com"))
  :maintainer
  '("Hongyu Ding" . "rainstormstudio@yahoo.com")
  :keywords
  '("lisp")
  :url "https://github.com/rainstormstudio/nerd-icons.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
