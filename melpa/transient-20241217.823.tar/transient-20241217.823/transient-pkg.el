;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20241217.823"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.0.0.0")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "a99dcda957a5663dcffbb48700eaf332972406b1"
  :revdesc "a99dcda957a5"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
