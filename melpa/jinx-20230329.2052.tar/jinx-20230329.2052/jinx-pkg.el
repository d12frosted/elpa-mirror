(define-package "jinx" "20230329.2052" "Enchanted Just-in-time Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "72d7a1ad9d1fd05e505d559fc188da21de0be014" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
