;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "protocols" "20170802.1132"
  "Protocol database access functions."
  '((cl-lib "0.5"))
  :url "https://github.com/davep/protocols.el"
  :commit "d0f7c4acb05465f1a0d4be54363bbd2802647e77"
  :revdesc "d0f7c4acb054"
  :keywords '("convenience" "net" "protocols")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
