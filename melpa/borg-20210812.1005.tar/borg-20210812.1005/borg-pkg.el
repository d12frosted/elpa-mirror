(define-package "borg" "20210812.1005" "assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.3.0")
    (magit "3.0.0"))
  :commit "0ff7d7e469d75c26caed8d50ca80299cc4a77b88" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
