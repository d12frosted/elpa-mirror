(define-package "borg" "20210812.1005" "assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.3.0")
    (magit "3.0.0"))
  :commit "541f384a08737294e90d5a526ff6a06a647aab16" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
