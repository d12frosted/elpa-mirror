;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bmx-mode" "20210319.620"
  "Batch Mode eXtras."
  '((emacs   "25.1")
    (cl-lib  "0.5")
    (company "0.9.4")
    (dash    "2.13.0")
    (s       "1.12.0"))
  :url "https://github.com/josteink/bmx-mode"
  :commit "6f008707efe0bb5646f0c1b0d6f57f0a8800e200"
  :revdesc "6f008707efe0"
  :keywords '("c" "convenience" "tools")
  :authors '(("Jostein Kjønigsen" . "jostein@gmail.com"))
  :maintainers '(("Jostein Kjønigsen" . "jostein@gmail.com")))
