;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20261016.1226"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "7a8da3a361c2e92649d59342b340eacd92c05f3b"
  :revdesc "7a8da3a361c2"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
