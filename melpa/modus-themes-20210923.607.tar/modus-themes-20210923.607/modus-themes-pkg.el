(define-package "modus-themes" "20210923.607" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "56fca037eb203c057ad4ab7a4aa0cead236c89b1" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
