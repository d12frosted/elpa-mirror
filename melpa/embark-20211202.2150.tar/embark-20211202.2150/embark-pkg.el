(define-package "embark" "20211202.2150" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "07124c7c66c61dd28f55be301573cf30a22a5fac" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
