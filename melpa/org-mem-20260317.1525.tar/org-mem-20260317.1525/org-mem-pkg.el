;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260317.1525"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "7f85d407804b7f7ca56de23fef3d5599815ba104"
  :revdesc "7f85d407804b"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
