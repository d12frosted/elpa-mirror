(define-package "mame" "20230617.1456" "A MAME front-end"
  '((emacs "27.1"))
  :commit "f49842a0af4d9750c585251124cf494cde3225d6" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
