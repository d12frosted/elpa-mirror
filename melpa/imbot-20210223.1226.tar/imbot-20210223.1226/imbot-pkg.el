(define-package "imbot" "20210223.1226" "Automatic system input method switcher"
  '((emacs "25.1"))
  :commit "b5d191c9168918a47373c70e97ae83ba46b946f6" :keywords
  '("convenience")
  :url "https://github.com/QiangF/imbot")
;; Local Variables:
;; no-byte-compile: t
;; End:
