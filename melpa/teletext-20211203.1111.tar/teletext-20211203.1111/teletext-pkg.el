(define-package "teletext" "20211203.1111" "Teletext broadcast viewer"
  '((emacs "24.3"))
  :commit "6b003e9dab9bd0c27d188a81f5fff740d66a2282" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("comm" "help" "hypermedia")
  :url "https://github.com/lassik/emacs-teletext")
;; Local Variables:
;; no-byte-compile: t
;; End:
