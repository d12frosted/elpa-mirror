(define-package "dirvish" "20220511.1007" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "583fe26e2ae34d509585479e41f3d234fb657227" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
