(define-package "embark" "20230202.1737" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "3f2a7c47e6095dc7ee0983e0e1993f8ddf28c313" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
