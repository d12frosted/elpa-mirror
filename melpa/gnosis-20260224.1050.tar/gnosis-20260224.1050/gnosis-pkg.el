;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260224.1050"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "54660aabfa3200663053dd0063f2c215ef674ddb"
  :revdesc "54660aabfa32"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
