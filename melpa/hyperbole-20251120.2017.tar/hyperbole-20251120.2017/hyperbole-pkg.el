;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251120.2017"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "51ee435a1d1ba87b46b3cc97476c31ca2af792cd"
  :revdesc "51ee435a1d1b"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
