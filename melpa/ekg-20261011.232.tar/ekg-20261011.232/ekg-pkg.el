;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261011.232"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "39441026802cbf5c5ccd269b3c37cc953716e9c8"
  :revdesc "39441026802c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
