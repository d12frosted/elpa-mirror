;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260227.1951"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "bf5a20599c122a3ad5ca060e6b69ac8084e37fb7"
  :revdesc "bf5a20599c12")
