(define-package "emacsql" "20230217.1717" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "4a9dc9234f774b384d064c56c05c4d1539a3496a" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
