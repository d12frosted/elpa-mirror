;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260624.1841"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "88a9155f9dd3bc59fe047800c506b519bef7ef7f"
  :revdesc "88a9155f9dd3"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
