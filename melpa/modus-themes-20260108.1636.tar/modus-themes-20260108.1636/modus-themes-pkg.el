;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260108.1636"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "be8111f2676c7e9a2a8264a923e249fb852219e4"
  :revdesc "be8111f2676c"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
