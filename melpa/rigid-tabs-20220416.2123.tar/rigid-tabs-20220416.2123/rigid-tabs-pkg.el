(define-package "rigid-tabs" "20220416.2123" "Fix TAB alignment in diff buffers"
  '((emacs "24.3"))
  :commit "872a10c8751574c9610cba1800f541a6eda24997" :authors
  '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers
  '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainer
  '("Yuri D'Elia" . "wavexx@thregr.org")
  :keywords
  '("diff" "whitespace" "version control" "magit")
  :url "https://gitlab.com/wavexx/rigid-tabs.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
