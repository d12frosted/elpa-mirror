;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260618.1215"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "1957c98a35e21179159c87634d531d7c6ecb592c"
  :revdesc "1957c98a35e2"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
