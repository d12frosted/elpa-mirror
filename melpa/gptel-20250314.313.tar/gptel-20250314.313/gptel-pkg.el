;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250314.313"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "7de8e885c12865beb6d2ec8bf6698ce3b2ad4f7f"
  :revdesc "7de8e885c128"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
