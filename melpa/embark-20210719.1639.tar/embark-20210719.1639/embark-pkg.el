(define-package "embark" "20210719.1639" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "af8453247882fc790d495c4faada0e90e29117be" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
