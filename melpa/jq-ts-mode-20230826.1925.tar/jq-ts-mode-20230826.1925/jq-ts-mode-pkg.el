(define-package "jq-ts-mode" "20230826.1925" "Tree-sitter support for jq buffers"
  '((emacs "29.1"))
  :commit "a495509f6920756dcf5cbf87ef1907b5abda2e5c" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("jq" "languages" "tree-sitter")
  :url "https://github.com/nverno/jq-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
