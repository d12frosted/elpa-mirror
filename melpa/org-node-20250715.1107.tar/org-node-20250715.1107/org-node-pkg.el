;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250715.1107"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.17.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "15d4c452af2485dbb45952c9e2b6648861837837"
  :revdesc "15d4c452af24"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
