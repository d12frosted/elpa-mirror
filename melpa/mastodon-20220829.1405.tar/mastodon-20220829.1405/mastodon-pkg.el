(define-package "mastodon" "20220829.1405" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0"))
  :commit "7146bddc60712f3b6cff67514894d0057df31469" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
