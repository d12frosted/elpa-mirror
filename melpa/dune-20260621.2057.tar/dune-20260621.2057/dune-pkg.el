;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "20260621.2057"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "47f64de764078db6edb2698958b5270a17bffb05"
  :revdesc "47f64de76407")
