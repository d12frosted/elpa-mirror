;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emc" "20250921.1900"
  "Invoking a C/C++ (et al.) build toolchain from ELisp."
  '((delight "1.7")
    (emacs   "29.1"))
  :url "https://github.com/marcoxa/emc"
  :commit "83a7a105c98a2797ceac083d397a77ee052b1e91"
  :revdesc "83a7a105c98a"
  :keywords '("extensions" "c" "lisp" "building tools" "development" "deployment.")
  :authors '(("Marco Antoniotti" . "marcoxa[at]gmail.com"))
  :maintainers '(("Marco Antoniotti" . "marcoxa[at]gmail.com")))
