(define-package "org-newtab" "20240223.358" "Supercharge your browser's new tab page"
  '((emacs "27.1")
    (websocket "1.14")
    (async "1.9.7"))
  :commit "2a64ed98b4be3780c41526e3f023db78012c273d" :authors
  '(("Zweihänder" . "zweidev@zweihander.me"))
  :maintainers
  '(("Zweihänder" . "zweidev@zweihander.me"))
  :maintainer
  '("Zweihänder" . "zweidev@zweihander.me")
  :keywords
  '("outlines")
  :url "https://github.com/Zweihander-Main/org-newtab")
;; Local Variables:
;; no-byte-compile: t
;; End:
