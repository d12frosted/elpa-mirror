;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260208.1631"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "06ec7b6525249ed0e1f066827de3e6dbddf33c3a"
  :revdesc "06ec7b652524"
  :keywords '("languages"))
