;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260201.1731"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "65363f379fd1d1e16e785a4aa3b93d13505ff116"
  :revdesc "65363f379fd1"
  :keywords '("languages"))
