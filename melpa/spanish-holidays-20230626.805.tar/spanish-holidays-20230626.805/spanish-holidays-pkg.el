(define-package "spanish-holidays" "20230626.805" "Spain holidays for calendar" 'nil :commit "26d552ae71f670dc966a3b7b7614d1622bce9f38" :authors
  '(("Carlos Pajuelo" . "carlospajuelo_@hotmail.com"))
  :maintainers
  '(("Carlos Pajuelo" . "carlospajuelo_@hotmail.com"))
  :maintainer
  '("Carlos Pajuelo" . "carlospajuelo_@hotmail.com")
  :keywords
  '("calendar")
  :url "https://gitlab.com/gnuhack/spanish-holidays")
;; Local Variables:
;; no-byte-compile: t
;; End:
