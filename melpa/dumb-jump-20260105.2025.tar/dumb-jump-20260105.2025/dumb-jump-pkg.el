;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260105.2025"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.3")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "b1ec972ed36d0a14246aeda63c8d65ee912ccc8f"
  :revdesc "b1ec972ed36d"
  :keywords '("programming"))
