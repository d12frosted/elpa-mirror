;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260612.627"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "6d1d24a95a8ade0b6d21d2ef48fce0c43b4fca7a"
  :revdesc "6d1d24a95a8a"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
