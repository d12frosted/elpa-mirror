;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260720.2228"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.2"))
  :url "https://github.com/jojojames/fzfa"
  :commit "2f671bba99e227e9933d63ea36eb9d995012e805"
  :revdesc "2f671bba99e2"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
