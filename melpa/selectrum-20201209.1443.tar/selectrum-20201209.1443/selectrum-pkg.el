(define-package "selectrum" "20201209.1443" "Easily select item from list"
  '((emacs "25.1"))
  :commit "5b74d157b32945877f3246e128b8b814d638f53b" :keywords
  ("extensions")
  :authors
  (("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  ("Radon Rosborough" . "radon.neon@gmail.com")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
