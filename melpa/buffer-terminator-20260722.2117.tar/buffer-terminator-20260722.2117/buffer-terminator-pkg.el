;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260722.2117"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "c69a568cd4668466b3fde1e8a21f3637ab6e7f84"
  :revdesc "c69a568cd466"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
