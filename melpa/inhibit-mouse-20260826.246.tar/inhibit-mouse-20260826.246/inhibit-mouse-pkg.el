;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "20260826.246"
  "Deactivate mouse input (alternative to disable-mouse)."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "383919fdb0ab261deb4deb50e4652f1678df0e47"
  :revdesc "383919fdb0ab"
  :keywords '("convenience" "mouse")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
