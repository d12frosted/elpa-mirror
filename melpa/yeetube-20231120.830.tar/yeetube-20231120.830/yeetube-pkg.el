(define-package "yeetube" "20231120.830" "YouTube Front End"
  '((emacs "27.2")
    (compat "29.1.4.2"))
  :commit "38a43ae1fb133daac4e8115a9ad794345dacd73c" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.org/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
