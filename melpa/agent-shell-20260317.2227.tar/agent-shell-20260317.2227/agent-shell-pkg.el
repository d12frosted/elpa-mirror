;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260317.2227"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4fbaef9ac1fb1b9591b50a351633441cd4398bb4"
  :revdesc "4fbaef9ac1fb")
