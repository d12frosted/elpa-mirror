;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "20250313.1702"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "26.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "5d15a0b5263f7fc885a2d7469466c9df58884f67"
  :revdesc "5d15a0b5263f"
  :keywords '("tools"))
