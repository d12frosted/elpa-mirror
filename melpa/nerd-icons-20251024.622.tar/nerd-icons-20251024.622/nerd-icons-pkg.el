;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20251024.622"
  "Emacs Nerd Font Icons Library."
  '((emacs "24.3"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "a5ef06f4aa293e18be49ed81e6c1a75d1348a0e4"
  :revdesc "a5ef06f4aa29"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
