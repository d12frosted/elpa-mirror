;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "20260313.2319"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "682049dbc0616f5f9737db3aad2aa1caacf71727"
  :revdesc "682049dbc061"
  :keywords '("convenience"))
