;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flywrite" "20260401.143"
  "Inline writing suggestions via LLM."
  '((emacs "29.1"))
  :url "https://github.com/awdeorio/flywrite"
  :commit "8cf2ef464e496b1f1c9a5a590979bb0d9fc79931"
  :revdesc "8cf2ef464e49"
  :keywords '("text" "wp")
  :authors '(("Andrew DeOrio" . "awdeorio@umich.edu"))
  :maintainers '(("Andrew DeOrio" . "awdeorio@umich.edu")))
