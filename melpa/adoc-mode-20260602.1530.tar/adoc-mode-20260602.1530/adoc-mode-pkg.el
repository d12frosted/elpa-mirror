;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260602.1530"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "1083ba1c2e4c72de0eb968dd4c630f4eb3bb9664"
  :revdesc "1083ba1c2e4c"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
