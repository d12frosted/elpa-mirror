;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260714.1317"
  "MCP server for Org-mode."
  '((emacs          "28.2")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "9bda1ff906a058828d962a91fb1110a9f5620973"
  :revdesc "9bda1ff906a0"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
