;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sml-basis" "20210518.2040"
  "Standard ML Basis Library lookup."
  '((emacs "24.5"))
  :url "https://github.com/lassik/emacs-sml-basis"
  :commit "c048d575e30a20ec825fd0c5eb9c8a4428a43298"
  :revdesc "c048d575e30a"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
