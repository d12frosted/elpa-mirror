(define-package "sml-basis" "20210518.2040" "Standard ML Basis Library lookup"
  '((emacs "24.5"))
  :commit "c048d575e30a20ec825fd0c5eb9c8a4428a43298" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/lassik/emacs-sml-basis")
;; Local Variables:
;; no-byte-compile: t
;; End:
