;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260826.757"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "5e5d0a420b3d798f4f1cb4ad87d64c8fd280f89a"
  :revdesc "5e5d0a420b3d"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
