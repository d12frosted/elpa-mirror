(define-package "imbot" "20210217.30" "Automatic system input method switcher"
  '((emacs "25.1"))
  :commit "aa934d3e76e8c7ce04cf3451c77b23c83810d998" :keywords
  '("convenience")
  :url "https://github.com/QiangF/imbot")
;; Local Variables:
;; no-byte-compile: t
;; End:
