;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20261011.1410"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "87ae84981ddeb4446586ba65cb30cec6e6ccfdb0"
  :revdesc "87ae84981dde"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
