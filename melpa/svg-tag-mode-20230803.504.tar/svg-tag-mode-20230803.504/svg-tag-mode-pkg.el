(define-package "svg-tag-mode" "20230803.504" "Replace keywords with SVG tags"
  '((emacs "27.1")
    (svg-lib "0.2"))
  :commit "0e0ea48799d8911ed6c1ef60565a20fd5cf3dae4" :authors
  '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr"))
  :maintainers
  '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr"))
  :maintainer
  '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr")
  :keywords
  '("convenience")
  :url "https://github.com/rougier/svg-tag-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
