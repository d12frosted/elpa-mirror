;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bui" "20260502.555"
  "Buffer interface library."
  '((emacs "29.1"))
  :url "https://github.com/alezost/bui.el"
  :commit "5be69e47d5fa4e48a6c8f75d6b85f4c32a31398c"
  :revdesc "5be69e47d5fa"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
