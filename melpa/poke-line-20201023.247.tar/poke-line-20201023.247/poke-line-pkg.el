(define-package "poke-line" "20201023.247" "Minor mode to show position in a buffer using a Pokemon"
  '((emacs "24.3"))
  :commit "8d484dbaa1215d902fbd1e3c9163b39a43ec532a" :authors
  '(("Ryan Miller" . "ryan@devopsmachine.com"))
  :maintainer
  '("Ryan Miller" . "ryan@devopsmachine.com")
  :keywords
  '("pokemon" "fun" "mode-line" "mouse")
  :url "https://github.com/RyanMillerC/poke-line/")
;; Local Variables:
;; no-byte-compile: t
;; End:
