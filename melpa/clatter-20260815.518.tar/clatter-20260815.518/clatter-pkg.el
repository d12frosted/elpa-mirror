;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260815.518"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "ba4d0bd9a8b61cdff043c8a9d362554788ff533a"
  :revdesc "ba4d0bd9a8b6"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
