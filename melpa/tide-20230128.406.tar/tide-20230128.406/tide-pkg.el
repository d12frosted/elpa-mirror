(define-package "tide" "20230128.406" "Typescript Interactive Development Environment"
  '((emacs "25.1")
    (dash "2.10.0")
    (s "1.11.0")
    (flycheck "27")
    (cl-lib "0.5"))
  :commit "52924d0b591238994457b36c79f1ce906653feda" :authors
  '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainer
  '("Anantha kumaran" . "ananthakumaran@gmail.com")
  :keywords
  '("typescript")
  :url "http://github.com/ananthakumaran/tide")
;; Local Variables:
;; no-byte-compile: t
;; End:
