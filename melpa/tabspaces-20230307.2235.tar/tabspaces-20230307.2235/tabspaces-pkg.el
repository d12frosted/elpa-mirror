(define-package "tabspaces" "20230307.2235" "Leverage tab-bar and project for buffer-isolated workspaces"
  '((emacs "27.1")
    (project "0.8.1"))
  :commit "315a5b375f9276f9725991c42a7c8a63ff26d51f" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainers
  '(("Colin McLear"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/mclear-tools/tabspaces")
;; Local Variables:
;; no-byte-compile: t
;; End:
