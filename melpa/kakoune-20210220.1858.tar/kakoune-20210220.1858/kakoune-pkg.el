(define-package "kakoune" "20210220.1858" "A simulation, but not emulation, of kakoune"
  '((ryo-modal "0.45")
    (multiple-cursors "1.4")
    (expand-region "0.11.0")
    (emacs "25.1"))
  :commit "d81bd00323ba10343a28bc855ee5ddbd09b7d2a5" :authors
  '(("Joseph Morag" . "jm4157@columbia.edu"))
  :maintainer
  '("Joseph Morag" . "jm4157@columbia.edu")
  :url "https://github.com/jmorag/kakoune.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
