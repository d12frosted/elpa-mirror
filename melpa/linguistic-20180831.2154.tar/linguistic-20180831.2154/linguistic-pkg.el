(define-package "linguistic" "20180831.2154" "A package for basic linguistic analysis." 'nil :commit "18e28a7e54efb140c17e16836bc5dac766c9522e" :authors
  '(("Andrew Favia <drewlinguistics01 at gmail dot com>"))
  :maintainer
  '("Andrew Favia <drewlinguistics01 at gmail dot com>")
  :keywords
  '("linguistics" "text analysis" "matching")
  :url "https://github.com/andcarnivorous/linguistic")
;; Local Variables:
;; no-byte-compile: t
;; End:
