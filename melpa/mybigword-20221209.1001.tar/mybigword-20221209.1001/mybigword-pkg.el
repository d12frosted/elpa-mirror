(define-package "mybigword" "20221209.1001" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "26.1")
    (avy "0.5.0"))
  :commit "b52a0e91f0fb7fc409c93d7fe40e3515dc013b4a" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
