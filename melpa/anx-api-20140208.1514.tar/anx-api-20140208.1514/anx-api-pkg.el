;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anx-api" "20140208.1514"
  "Interact with the AppNexus API from Emacs."
  ()
  :url "https://github.com/rmloveland/emacs-appnexus-api"
  :commit "b2411ebc966ac32c3ffc61bc22bf183834df0fa0"
  :revdesc "b2411ebc966a"
  :keywords '("convenience" "json" "rest" "api" "appnexus"))
