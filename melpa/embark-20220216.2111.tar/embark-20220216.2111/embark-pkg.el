(define-package "embark" "20220216.2111" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "a0443e23b6e7c2823099dda2494841ee5f38829f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
