(define-package "embark" "20220216.2111" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "29848fc3c88761fac6cea4093e6af48aa10b1fd3" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
