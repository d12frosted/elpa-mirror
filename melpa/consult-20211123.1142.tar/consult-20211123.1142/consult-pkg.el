(define-package "consult" "20211123.1142" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "09e7813a4c42be0ce04c500fda44cee457a35c85" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
