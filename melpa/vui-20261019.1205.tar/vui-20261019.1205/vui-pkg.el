;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261019.1205"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "49cbd91f2b1e7180ef1f20da868ae18d00bc980e"
  :revdesc "49cbd91f2b1e"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
