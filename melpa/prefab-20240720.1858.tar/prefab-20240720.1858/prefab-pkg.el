;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prefab" "20240720.1858"
  "Integration for project generation tools like cookiecutter."
  '((emacs     "27.1")
    (f         "0.2.0")
    (transient "0.3.7"))
  :url "https://github.com/laurencewarne/prefab.el"
  :commit "51da6c214f095a44f3d2223bcf079a3073923115"
  :revdesc "51da6c214f09")
