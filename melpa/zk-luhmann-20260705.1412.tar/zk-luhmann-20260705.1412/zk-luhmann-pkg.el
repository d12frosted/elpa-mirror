;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-luhmann" "20260705.1412"
  "Support for Luhmann-style IDs in zk."
  '((emacs    "25.1")
    (zk       "0.7")
    (zk-index "0.10"))
  :url "https://github.com/localauthor/zk-luhmann"
  :commit "8b34138abc432a37642d7d60f1c2d043e07bb680"
  :revdesc "8b34138abc43"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
