(define-package "auto-highlight-symbol" "20231027.231" "Automatic highlighting current symbol minor mode"
  '((emacs "26.1")
    (ht "2.3"))
  :commit "23d0d3a4365328bbd67cbe5fb2b443693c896ea0" :authors
  '(("Mitsuo Saito" . "arch320@NOSPAM.gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("highlight" "face" "match" "convenience")
  :url "http://github.com/jcs-elpa/auto-highlight-symbol")
;; Local Variables:
;; no-byte-compile: t
;; End:
