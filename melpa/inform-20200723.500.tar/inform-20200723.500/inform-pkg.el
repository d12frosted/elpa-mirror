(define-package "inform" "20200723.500" "Symbol links in Info buffers to their help documentation."
  '((emacs "25.1"))
  :commit "8ff0a19a9f40cfa8283da8ed73de94c35a327423" :url "https://github.com/dieter-wilhelm/inform" :maintainer
  ("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de")
  :authors
  (("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :keywords
  ("help" "docs" "convenience"))
;; Local Variables:
;; no-byte-compile: t
;; End:
