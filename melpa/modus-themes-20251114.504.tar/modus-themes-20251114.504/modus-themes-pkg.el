;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251114.504"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "0e3b21ef87193c467402c2a0c5f46f060dc04ec5"
  :revdesc "0e3b21ef8719"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
