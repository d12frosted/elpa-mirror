(define-package "consult-tex" "20231012.1121" "Consult powered completion for tex"
  '((emacs "28.2")
    (consult "0.35"))
  :commit "81cf7d7e2ef52c01c291c4ec7215020cbce29085" :authors
  '(("Titus Pinta"))
  :maintainers
  '(("Titus Pinta" . "titus.pinta@gmail.com"))
  :maintainer
  '("Titus Pinta" . "titus.pinta@gmail.com")
  :keywords
  '("consult" "tex" "latex")
  :url "https://gitlab.com/titus.pinta/consult-TeX")
;; Local Variables:
;; no-byte-compile: t
;; End:
