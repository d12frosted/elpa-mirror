(define-package "helm-core" "20220708.343" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "93e9428400154db2f5bd4f03f201e0554d5cc4ab" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
