;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zoom" "20260509.908"
  "Fixed and automatic balanced window layout."
  '((emacs "24.4"))
  :url "https://github.com/cyrus-and/zoom"
  :commit "5e524d98c7f2b4dd6ed41d95573b29b263632eb2"
  :revdesc "5e524d98c7f2"
  :keywords '("frames")
  :authors '(("Andrea Cardaci" . "cyrus.and@gmail.com"))
  :maintainers '(("Andrea Cardaci" . "cyrus.and@gmail.com")))
