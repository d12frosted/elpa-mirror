;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250927.823"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "6cc997945fc059dfad58deae9b5340b5a73af4ad"
  :revdesc "6cc997945fc0"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
