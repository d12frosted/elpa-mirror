;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260711.945"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "0939004f0bf00021246b8fb62fc5e8939b8d98da"
  :revdesc "0939004f0bf0"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
