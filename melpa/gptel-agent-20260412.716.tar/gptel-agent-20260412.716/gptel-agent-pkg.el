;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260412.716"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "bef06bccdbf847e0c4a94d1b57dd96d979437430"
  :revdesc "bef06bccdbf8"
  :keywords '("comm"))
