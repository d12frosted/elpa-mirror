;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circom-mode" "20250603.929"
  "Major mode for editing Circom circuit."
  '((emacs "24.3"))
  :url "https://github.com/taquangtrung/emacs-circom-mode"
  :commit "c91761e5323a132c580cd8dd91cb69ed524b6d4f"
  :revdesc "c91761e5323a"
  :keywords '("languages"))
