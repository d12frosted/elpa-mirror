(define-package "danneskjold-theme" "20210402.1712" "Beautiful high-contrast Emacs theme." 'nil :commit "a713069a3459ca6e93a5e4658168fb2464bacb54" :authors
  '(("Dmitry Akatov" . "akatovda@yandex.com"))
  :maintainer
  '("Dmitry Akatov" . "akatovda@yandex.com")
  :url "https://github.com/rails-to-cosmos/")
;; Local Variables:
;; no-byte-compile: t
;; End:
