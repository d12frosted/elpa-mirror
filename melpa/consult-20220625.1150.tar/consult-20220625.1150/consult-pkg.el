(define-package "consult" "20220625.1150" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "b7f9a554a81e9b2e4710e8d400e3a353523ede07" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
