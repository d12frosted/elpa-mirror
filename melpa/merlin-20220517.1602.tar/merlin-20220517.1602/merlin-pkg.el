(define-package "merlin" "20220517.1602" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "dd7663fcff929ac395909cada9e829acdc77e97e" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
