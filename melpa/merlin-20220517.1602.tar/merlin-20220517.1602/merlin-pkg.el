(define-package "merlin" "20220517.1602" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "7225332a1ae1ca03dae179bba3fe35c39a1100f2" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
