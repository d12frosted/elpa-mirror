(define-package "merlin" "20220517.1602" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "145d76338b56148d6122b5ffef43e74889d289dd" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
