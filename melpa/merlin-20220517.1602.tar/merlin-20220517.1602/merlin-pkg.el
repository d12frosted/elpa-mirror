(define-package "merlin" "20220517.1602" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "5b5f8f5fa6940cc4c99f49adad9aca181d10c564" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
