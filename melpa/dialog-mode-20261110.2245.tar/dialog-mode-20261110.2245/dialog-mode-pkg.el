;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20261110.2245"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "a330024de229de95edc658b3f2aa9874f1f616bc"
  :revdesc "a330024de229"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
