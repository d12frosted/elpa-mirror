(define-package "cnfonts" "20230215.2323" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "f8aa4dc265a628b201a51a1dc0c30c199d97bf40" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
