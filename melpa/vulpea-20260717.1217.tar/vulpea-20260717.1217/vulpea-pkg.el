;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260717.1217"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "6c178e128091392f9b2414dcbecd6c024a7e406b"
  :revdesc "6c178e128091"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
