;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260323.1823"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "21f53cbc9668c0998641fa2a55585a7a3a16ad05"
  :revdesc "21f53cbc9668"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
