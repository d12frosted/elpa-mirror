(define-package "magik-mode" "20230507.1716" "mode for editing Magik + some utils." 'nil :commit "214c335aeac7e6f424b6c12fa1372b185f113d2e" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
