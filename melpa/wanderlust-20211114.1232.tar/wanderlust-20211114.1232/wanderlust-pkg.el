(define-package "wanderlust" "20211114.1232" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "1cd39461a8787498e55f6b5ef95faebed5bf496d")
;; Local Variables:
;; no-byte-compile: t
;; End:
