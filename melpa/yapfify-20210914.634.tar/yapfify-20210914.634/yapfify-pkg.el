;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yapfify" "20210914.634"
  "(automatically) format python buffers using YAPF."
  ()
  :url "https://github.com/JorisE/yapfify"
  :commit "c9347e3b1dec5fc8d34883e206fcdc8500d22368"
  :revdesc "c9347e3b1dec"
  :authors '(("Joris Engbers" . "info@jorisengbers.nl"))
  :maintainers '(("Joris Engbers" . "info@jorisengbers.nl")))
