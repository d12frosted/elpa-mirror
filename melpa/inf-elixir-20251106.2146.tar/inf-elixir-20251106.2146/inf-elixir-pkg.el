;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-elixir" "20251106.2146"
  "Run an interactive Elixir shell."
  '((emacs "25.1"))
  :url "https://github.com/J3RN/inf-elixir"
  :commit "085f1c198a121c569a161f9fa71e6cce1998cd63"
  :revdesc "085f1c198a12"
  :keywords '("languages" "processes" "tools")
  :authors '(("Jonathan Arnett" . "j3rn@j3rn.com"))
  :maintainers '(("Jonathan Arnett" . "j3rn@j3rn.com")))
