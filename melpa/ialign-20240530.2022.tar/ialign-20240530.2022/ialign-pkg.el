(define-package "ialign" "20240530.2022" "visual align-regexp"
  '((emacs "24.4"))
  :commit "819c1808e3e6422b8a015287647b07f498f0cf26" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("tools" "editing" "align" "interactive")
  :url "https://github.com/mkcms/interactive-align")
;; Local Variables:
;; no-byte-compile: t
;; End:
