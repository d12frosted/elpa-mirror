;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20261102.856"
  "Insert SPDX license and copyright headers."
  '((emacs "29.1"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "cbf1141034211129f5d2bc71cae3fdc621e8a8c2"
  :revdesc "cbf114103421"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
