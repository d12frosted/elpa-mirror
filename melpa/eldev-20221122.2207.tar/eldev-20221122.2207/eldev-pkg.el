(define-package "eldev" "20221122.2207" "Elisp development tool"
  '((emacs "24.4"))
  :commit "621273bb7cc986bd929f97bde89428f55372567a" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
