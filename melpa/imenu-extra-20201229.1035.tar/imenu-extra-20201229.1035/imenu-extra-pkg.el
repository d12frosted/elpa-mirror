;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imenu-extra" "20201229.1035"
  "Add extra items into existing imenu items."
  '((emacs "25.1"))
  :url "https://github.com/redguardtoo/imenu-extra"
  :commit "68b0aaaefc18b267e4e383df36a8dfb7448bc83c"
  :revdesc "68b0aaaefc18"
  :keywords '("convenience")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
