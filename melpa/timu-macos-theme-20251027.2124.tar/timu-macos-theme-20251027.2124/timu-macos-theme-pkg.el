;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-macos-theme" "20251027.2124"
  "Color theme inspired by the macOS UI."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/timu-macos-theme"
  :commit "a558be6a6816217cbb1cbf0703cb4e756d7bf7a3"
  :revdesc "a558be6a6816"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
