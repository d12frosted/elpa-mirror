(define-package "ox-hugo" "20211218.1728" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "cd313dca9a2c7da9f8f4e1b2ddfe1a9cfaf45e34" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
