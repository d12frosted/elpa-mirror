;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-space" "20151208.1228"
  "Repeat motion in Evil. Correct the behaviour of what SPC should do."
  '((evil "1.0.0"))
  :url "https://github.com/linktohack/evil-space"
  :commit "a9c07284d308425deee134c9d88a2d538dd229e6"
  :revdesc "a9c07284d308"
  :keywords '("space" "repeat" "motion")
  :authors '(("Quang Linh LE" . "linktohack@gmail.com"))
  :maintainers '(("Quang Linh LE" . "linktohack@gmail.com")))
