;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hydandata-light-theme" "20190809.1925"
  "A light color theme that is easy on your eyes."
  ()
  :url "https://github.com/chkhd/hydandata-light-theme"
  :commit "812ffa4bee3163098ef66ee4506feed45018be4e"
  :revdesc "812ffa4bee31"
  :keywords '("color-theme" "theme")
  :authors '(("David Chkhikvadze" . "david@chkhd.net"))
  :maintainers '(("David Chkhikvadze" . "david@chkhd.net")))
