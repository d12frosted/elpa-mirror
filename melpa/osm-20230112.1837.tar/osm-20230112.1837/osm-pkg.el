(define-package "osm" "20230112.1837" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "63426c9c032ef5bce406646de683205f2b851685" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
