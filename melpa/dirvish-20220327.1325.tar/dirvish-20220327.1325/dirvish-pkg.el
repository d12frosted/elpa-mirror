(define-package "dirvish" "20220327.1325" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "1d4f2e2e3b70e1438d31771b9f11f3983aa5054d" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
