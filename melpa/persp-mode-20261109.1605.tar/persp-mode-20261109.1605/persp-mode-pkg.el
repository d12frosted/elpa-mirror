;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persp-mode" "20261109.1605"
  "Windows/buffers sets shared among frames + save/load."
  '((emacs "24.3"))
  :url "https://github.com/Bad-ptr/persp-mode.el"
  :commit "927ab4e182c3d0cb03741332e2ef7d2c8479fc27"
  :revdesc "927ab4e182c3"
  :keywords '("perspectives" "session" "workspace" "persistence" "windows" "buffers" "convenience")
  :authors '(("Constantin Kulikov" . "zxnotdead@gmail.com"))
  :maintainers '(("Constantin Kulikov" . "zxnotdead@gmail.com")))
