(define-package "centaur-tabs" "20220110.1121" "Aesthetic, modern looking customizable tabs plugin"
  '((emacs "24.4")
    (powerline "2.4")
    (cl-lib "0.5"))
  :commit "655da23a4ac8c31ae820056112af4c9743843b4d" :authors
  '(("Emmanuel Bustos" . "ema2159@gmail.com"))
  :maintainer
  '("Emmanuel Bustos" . "ema2159@gmail.com")
  :url "https://github.com/ema2159/centaur-tabs")
;; Local Variables:
;; no-byte-compile: t
;; End:
