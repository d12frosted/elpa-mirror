;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20260515.1821"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "89436ed83a7a77a424627479ff486ca97a009f4a"
  :revdesc "89436ed83a7a"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
