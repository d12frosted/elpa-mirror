(define-package "for" "20220927.1224" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "2c9af7d57b5e78952d63543f65097601e95401b2" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
