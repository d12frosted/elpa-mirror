(define-package "zotra" "20230818.1958" "Library to use Zotero translators"
  '((emacs "27.1"))
  :commit "13d3996a7e976722bdca4139de2435e8d2ea226d" :authors
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainers
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainer
  '("Mohammad Pedramfar <https://github.com/mpedramfar>")
  :url "https://github.com/mpedramfar/zotra")
;; Local Variables:
;; no-byte-compile: t
;; End:
