(define-package "symbols-outline" "20230823.1542" "Display symbols (functions, variables, etc) in outline view"
  '((emacs "27.1"))
  :commit "8c4e722507577456e583cf4d87a047527e91a1bd" :authors
  '(("Shihao Liu"))
  :maintainers
  '(("Shihao Liu"))
  :maintainer
  '("Shihao Liu")
  :keywords
  '("outlines")
  :url "https://github.com/liushihao456/symbols-outline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
