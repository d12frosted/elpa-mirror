;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251104.228"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "144c09ecdfaa8105b6e1b8f4bd8181f98cc6adf6"
  :revdesc "144c09ecdfaa"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
