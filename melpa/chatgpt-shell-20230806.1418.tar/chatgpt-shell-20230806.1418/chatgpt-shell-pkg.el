(define-package "chatgpt-shell" "20230806.1418" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.42.1"))
  :commit "c5f470a182027b6afde3e39558837e22c7fe282a" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
