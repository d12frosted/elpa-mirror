(define-package "eshell-syntax-highlighting" "20240430.21" "Highlight eshell commands"
  '((emacs "25.1"))
  :commit "46a7c62ae125a451ca38080eb5dcd7d147838da7" :authors
  '(("Alex Kreisher" . "akreisher18@gmail.com"))
  :maintainers
  '(("Alex Kreisher" . "akreisher18@gmail.com"))
  :maintainer
  '("Alex Kreisher" . "akreisher18@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/akreisher/eshell-syntax-highlighting")
;; Local Variables:
;; no-byte-compile: t
;; End:
