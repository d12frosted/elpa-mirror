(define-package "package-build" "20201225.757" "Tools for assembling a package archive"
  '((cl-lib "0.5")
    (emacs "25.1"))
  :commit "848c757c41071b655ab23dc6b4867f0d3edc357d" :authors
  (("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainer
  ("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
  :keywords
  ("tools")
  :url "https://github.com/melpa/package-build")
;; Local Variables:
;; no-byte-compile: t
;; End:
