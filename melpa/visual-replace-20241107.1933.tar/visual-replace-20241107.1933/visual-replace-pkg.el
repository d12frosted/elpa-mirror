;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "20241107.1933"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "https://github.com/szermatt/visual-replace"
  :commit "0b9bb151827799827c413dddfdc3a10fb4e6a101"
  :revdesc "0b9bb1518277"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
