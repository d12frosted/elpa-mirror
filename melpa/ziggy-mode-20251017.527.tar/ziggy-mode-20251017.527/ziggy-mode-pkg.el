;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ziggy-mode" "20251017.527"
  "Major mode for Ziggy, a data serialization language."
  '((emacs       "29.1")
    (reformatter "0.6"))
  :url "https://github.com/dcolazin/ziggy-mode"
  :commit "5b42008a022ae1d9221add6f57ce65715d7f9947"
  :revdesc "5b42008a022a"
  :authors '(("2024 Robbie Lyman" . "rb.lymn@gmail.com"))
  :maintainers '(("Davide Colazingari" . "dcolazin@gmail.com")))
