;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-shell-command" "20251008.1304"
  "Shell commands with DWIM behaviour."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/dwim-shell-command"
  :commit "1f40c468fd5bf5241276347ea785b7f3082d8260"
  :revdesc "1f40c468fd5b")
