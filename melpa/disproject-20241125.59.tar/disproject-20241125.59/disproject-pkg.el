;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20241125.59"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.7.8"))
  :url "https://github.com/aurtzy/disproject"
  :commit "cc9a82f3d9bfcd921650bfeb0f4b9c1dfc59137b"
  :revdesc "cc9a82f3d9bf"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
