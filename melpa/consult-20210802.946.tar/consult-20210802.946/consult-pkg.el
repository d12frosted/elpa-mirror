(define-package "consult" "20210802.946" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "e3418a995a48e221a0dddd22693c17e6b786933c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
