;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-ascii-plot" "20260126.1121"
  "Unicode-art bar plots in org-mode tables."
  ()
  :url "https://github.com/tbanel/orgtblasciiplot"
  :commit "e9583daf44a9b1c88e767aa792527e6f21acb0a4"
  :revdesc "e9583daf44a9"
  :keywords '("org" "table" "ascii" "plot"))
