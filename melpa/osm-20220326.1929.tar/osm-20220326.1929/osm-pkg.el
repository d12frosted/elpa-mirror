(define-package "osm" "20220326.1929" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "79951a695e6ae05e3729efe0c4ea42b7af35996d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
