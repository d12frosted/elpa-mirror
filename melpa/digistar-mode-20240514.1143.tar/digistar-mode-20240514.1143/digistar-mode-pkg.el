(define-package "digistar-mode" "20240514.1143" "major mode for Digistar scripts" 'nil :commit "a2f32ee6788e3b3253a448fa2c42d100ee621a1d" :authors
  '(("John Foerch" . "jjfoerch@gmail.com"))
  :maintainers
  '(("John Foerch" . "jjfoerch@gmail.com"))
  :maintainer
  '("John Foerch" . "jjfoerch@gmail.com")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
