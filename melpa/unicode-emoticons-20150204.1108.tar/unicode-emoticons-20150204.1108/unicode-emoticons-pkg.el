;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-emoticons" "20150204.1108"
  "Shortcuts for common unicode emoticons."
  ()
  :url "https://github.com/hagleitn/unicode-emoticons"
  :commit "52a09955c2afc1807c0f37f1467ccfc1e1da690a"
  :revdesc "52a09955c2af"
  :keywords '("games" "entertainment" "comms"))
