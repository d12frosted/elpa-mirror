;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "threes" "20160820.1242"
  "A clone of Threes (a tiny puzzle game)."
  '((emacs "24")
    (seq   "1.11"))
  :url "https://github.com/xuchunyang/threes.el"
  :commit "6981acb30b856c77cba6aba63fefbf102cbdfbb2"
  :revdesc "6981acb30b85"
  :keywords '("games")
  :authors '(("Chunyang Xu" . "xuchunyang.me@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang.me@gmail.com")))
