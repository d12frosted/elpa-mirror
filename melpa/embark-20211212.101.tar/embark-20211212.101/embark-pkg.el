(define-package "embark" "20211212.101" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "33b47bb8999f8c7d67e9d1e04668e421e3c7246f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
