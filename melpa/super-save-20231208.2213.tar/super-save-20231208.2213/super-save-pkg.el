(define-package "super-save" "20231208.2213" "Auto-save buffers, based on your activity."
  '((emacs "25.1"))
  :commit "0bbc1b16e3eabf8565749180f83cc80073a35da2" :authors
  '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.com")
  :keywords
  '("convenience")
  :url "https://github.com/bbatsov/super-save")
;; Local Variables:
;; no-byte-compile: t
;; End:
