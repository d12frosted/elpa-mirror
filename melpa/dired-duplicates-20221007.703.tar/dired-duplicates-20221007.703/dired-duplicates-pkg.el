(define-package "dired-duplicates" "20221007.703" "Find duplicate files locally and remotely"
  '((emacs "27.1"))
  :commit "3c16f563880453ad65e1b19ec92d7c4c5a6269f2" :authors
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainers
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainer
  '("Harald Judt" . "h.judt@gmx.at")
  :keywords
  '("files")
  :url "https://codeberg.org/hjudt/dired-duplicates")
;; Local Variables:
;; no-byte-compile: t
;; End:
