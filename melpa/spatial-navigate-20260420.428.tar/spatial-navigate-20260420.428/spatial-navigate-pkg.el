;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-navigate" "20260420.428"
  "Directional navigation between blank-space blocks."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spatial-navigate"
  :commit "764cf2ea5ded501493bfd543c5a290b8cda847d5"
  :revdesc "764cf2ea5ded"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
