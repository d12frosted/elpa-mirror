;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trailing-newline-indicator" "20261122.2117"
  "Show an indicator for the trailing newline."
  '((emacs "26.1"))
  :url "https://github.com/saulotoledo/trailing-newline-indicator"
  :commit "a09c5639d3d80420668088178e98d15ec6b967c7"
  :revdesc "a09c5639d3d8"
  :keywords '("convenience" "display" "editing")
  :authors '(("Saulo S. de Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo S. de Toledo" . "saulotoledo@gmail.com")))
