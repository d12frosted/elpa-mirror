;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260720.457"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "9b81c45c423755333929dbe4e2e204ae0246c016"
  :revdesc "9b81c45c4237"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
