;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20260915.2146"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "faecaf5df1d208b3814220bfa52acd3094c70649"
  :revdesc "faecaf5df1d2"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
