;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260521.1356"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f27478dd7fae11fac6432e7a86360aa5f7d4c503"
  :revdesc "f27478dd7fae"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
