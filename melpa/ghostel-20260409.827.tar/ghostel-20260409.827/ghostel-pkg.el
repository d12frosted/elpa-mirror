;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260409.827"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "a46c7843fc072c8991a354f36ef4369669773f63"
  :revdesc "a46c7843fc07"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
