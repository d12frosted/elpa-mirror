;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dbc" "20201001.1452"
  "Control how to open buffers."
  '((emacs  "24.4")
    (cl-lib "0.5")
    (ht     "2.3"))
  :url "https://gitlab.com/matsievskiysv/display-buffer-control"
  :commit "6728e72f72347d098b7d75ac4c29a7d687cc9ed3"
  :revdesc "6728e72f7234"
  :keywords '("convenience"))
