;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-math-input" "20260521.850"
  "Insert Unicode math symbols using TeX notation."
  '((emacs "28.1"))
  :url "https://github.com/astoff/unicode-math-input.el"
  :commit "7841e535fa309be64414df61eb2dac55958035b4"
  :revdesc "7841e535fa30")
