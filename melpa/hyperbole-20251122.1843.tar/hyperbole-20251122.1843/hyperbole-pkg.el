;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251122.1843"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e2fdb31d44e0ff8cba807f84abd12a7b4c559bb0"
  :revdesc "e2fdb31d44e0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
