;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quiz" "20260407.759"
  "Multiple choice quiz game."
  '((emacs "25.1"))
  :url "https://github.com/davep/quiz.el"
  :commit "708e25d570e9835c1058762794825935a8dec296"
  :revdesc "708e25d570e9"
  :keywords '("games" "trivia" "quiz")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
