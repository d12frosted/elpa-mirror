(define-package "detached" "20221113.1307" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "9f67f604af1c26547c219448b55ae19292b8fa5d" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
