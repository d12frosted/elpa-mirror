;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260813.1046"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "dcf8688d53a72c7867b47793485877fc539811ab"
  :revdesc "dcf8688d53a7")
