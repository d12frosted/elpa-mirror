;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-eglot" "20260214.2327"
  "Flycheck support for eglot."
  '((emacs    "28.1")
    (eglot    "1.9")
    (flycheck "32"))
  :url "https://github.com/flycheck/flycheck-eglot"
  :commit "6cf99e53b4e43ac62604ebcb73a6c0794b19a5fe"
  :revdesc "6cf99e53b4e4"
  :keywords '("convenience" "language" "tools")
  :authors '(("Sergey Firsov" . "intramurz@gmail.com"))
  :maintainers '(("Sergey Firsov" . "intramurz@gmail.com")))
