(define-package "pyim-cangjiedict" "20210617.934" "Some cangjie dicts for pyim"
  '((pyim "3.7"))
  :commit "d17e3d32a6480939b350a91a915ebe8e6efad819" :authors
  '(("Yuanchen Xie" . "yuanchen.gm@gmail.com"))
  :maintainers
  '(("Yuanchen Xie" . "yuanchen.gm@gmail.com"))
  :maintainer
  '("Yuanchen Xie" . "yuanchen.gm@gmail.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/p1uxtar/pyim-cangjiedict")
;; Local Variables:
;; no-byte-compile: t
;; End:
