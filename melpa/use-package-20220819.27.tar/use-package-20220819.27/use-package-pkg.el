(define-package "use-package" "20220819.27" "A configuration macro for simplifying your .emacs"
  '((emacs "24.3")
    (bind-key "2.4"))
  :commit "8a3d29e433d97cfa5612e7bc686ce7c0d24b8f47" :authors
  '(("John Wiegley" . "johnw@newartisans.com"))
  :maintainer
  '("John Wiegley" . "johnw@newartisans.com")
  :keywords
  '("dotemacs" "startup" "speed" "config" "package")
  :url "https://github.com/jwiegley/use-package")
;; Local Variables:
;; no-byte-compile: t
;; End:
