(define-package "naga-theme" "20230418.1210" "Dark color theme with green foreground color"
  '((emacs "24.1"))
  :commit "5cf1ecaa052d3bdaee93ad5e98bb4f5346404b3f" :authors
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainers
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainer
  '("Johannes Maier" . "johannes.maier@mailbox.org")
  :keywords
  '("faces" "themes")
  :url "https://github.com/kenranunderscore/emacs-naga-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
