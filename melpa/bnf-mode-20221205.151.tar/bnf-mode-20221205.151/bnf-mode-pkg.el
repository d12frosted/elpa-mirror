(define-package "bnf-mode" "20221205.151" "Major mode for editing BNF grammars."
  '((cl-lib "0.5")
    (emacs "25.1"))
  :commit "5aec265406614582ba4ee1bc18671502f0621b2e" :authors
  '(("Serghei Iakovlev" . "egrep@protonmail.ch"))
  :maintainer
  '("Serghei Iakovlev" . "egrep@protonmail.ch")
  :keywords
  '("languages")
  :url "https://github.com/sergeyklay/bnf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
