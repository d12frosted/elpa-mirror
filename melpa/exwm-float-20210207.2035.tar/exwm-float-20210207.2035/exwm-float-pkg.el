;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-float" "20210207.2035"
  "Convenient modes and bindings for floating EXWM frames."
  '((emacs  "25.1")
    (xelb   "0.18")
    (exwm   "0.24")
    (popwin "1.0.2"))
  :url "https://gitlab.com/mtekman/exwm-float.el"
  :commit "047c83aa6b54bfb6ca8cac4d3ea18542611cef77"
  :revdesc "047c83aa6b54"
  :keywords '("outlines"))
