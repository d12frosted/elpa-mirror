(define-package "helm" "20240919.642" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "4.0")
    (wfnames "1.2"))
  :commit "5f3a973daf27a9cd4ec573c271fa42a2109021e8" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
