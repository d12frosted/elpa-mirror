;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20260102.823"
  "Miasma: color theme inspired by the woods."
  ()
  :url "http://github.com/daut/miasma-theme.el"
  :commit "c4ac925c1b9af099d93dc2ebec225ebc260be120"
  :revdesc "c4ac925c1b9a")
