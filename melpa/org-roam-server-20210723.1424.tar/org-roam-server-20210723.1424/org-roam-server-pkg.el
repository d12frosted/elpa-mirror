(define-package "org-roam-server" "20210723.1424" "Org Roam Database Visualizer"
  '((org-roam "1.2.1")
    (org "9.3")
    (emacs "26.1")
    (dash "2.17.0")
    (simple-httpd "1.5.1")
    (s "1.12.0")
    (f "0.20.0"))
  :commit "e658cb917f9cfc3cb7fa032bc3573007487a8feb" :authors
  '(("Göktuğ Karakaşlı" . "karakasligk@gmail.com"))
  :maintainer
  '("Göktuğ Karakaşlı" . "karakasligk@gmail.com")
  :url "https://github.com/goktug97/org-roam-server")
;; Local Variables:
;; no-byte-compile: t
;; End:
