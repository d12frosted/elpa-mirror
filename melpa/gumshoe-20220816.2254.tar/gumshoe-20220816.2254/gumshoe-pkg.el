(define-package "gumshoe" "20220816.2254" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "5e30a68f1cd80c8bdf67c06afa1fe7642decbef7" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
