(define-package "trinary" "20230225.1822" "Trinary logic"
  '((emacs "24"))
  :commit "bdb4b9087cde8ebf4a7ac7172510ec454a7ce5a4" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/emacs-elsa/trinary-logic")
;; Local Variables:
;; no-byte-compile: t
;; End:
