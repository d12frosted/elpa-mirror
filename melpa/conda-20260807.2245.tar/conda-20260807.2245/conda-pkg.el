;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conda" "20260807.2245"
  "Work with your conda environments."
  '((emacs    "25.1")
    (pythonic "0.1.0")
    (dash     "2.13.0")
    (s        "1.11.0")
    (f        "0.18.2"))
  :url "https://github.com/necaris/conda.el"
  :commit "6b78fb0feb3279b32dbdf60243b5941ae233d0d0"
  :revdesc "6b78fb0feb32"
  :keywords '("languages" "local" "tools" "python" "environment" "conda")
  :authors '(("Rami Chowdhury" . "rami.chowdhury@gmail.com"))
  :maintainers '(("Rami Chowdhury" . "rami.chowdhury@gmail.com")))
