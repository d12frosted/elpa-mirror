(define-package "universal-sidecar-roam" "20231008.1742" "Integrate universal-sidecar and org-roam"
  '((emacs "26.1")
    (universal-sidecar "1.0.0")
    (org-roam "2.0.0"))
  :commit "d8311910fae3ea65fb4153e3872ec24b64d5d8aa" :authors
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainer
  '("Samuel W. Flint" . "me@samuelwflint.com")
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar")
;; Local Variables:
;; no-byte-compile: t
;; End:
