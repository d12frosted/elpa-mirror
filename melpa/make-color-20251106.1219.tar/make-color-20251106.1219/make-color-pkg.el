;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "make-color" "20251106.1219"
  "Alternative to picking color - update fg/bg color by pressing r/g/b/... keys."
  ()
  :url "https://github.com/alezost/make-color.el"
  :commit "aac38ff562f8ba46917f8281ad79973caf379f49"
  :revdesc "aac38ff562f8"
  :keywords '("color")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
