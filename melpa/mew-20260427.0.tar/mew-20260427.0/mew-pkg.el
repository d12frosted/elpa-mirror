;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260427.0"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "f39a55db34bbaf5ff756e2164ca0fd5240a88538"
  :revdesc "f39a55db34bb")
