(define-package "consult" "20210621.2003" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "51d276785d9c983271b13c8c1be43bdff37b8083" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
