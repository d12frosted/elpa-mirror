(define-package "elisp-autofmt" "20230101.539" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "3576eb2762305afe26b0ae7767d3bd2e3963ae7f" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
