;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiles" "20260602.1050"
  "Tagged Instant Lightweight Emacs Snippets."
  '((emacs "27.1"))
  :url "https://github.com/ctanas/tiles"
  :commit "c3a8de0a375f3050ebca2870cc2befde324a4f9f"
  :revdesc "c3a8de0a375f"
  :keywords '("files" "text" "convenience")
  :authors '(("Claudiu Tănăselia" . "https://www.tanaselia.ro"))
  :maintainers '(("Claudiu Tănăselia" . "https://www.tanaselia.ro")))
