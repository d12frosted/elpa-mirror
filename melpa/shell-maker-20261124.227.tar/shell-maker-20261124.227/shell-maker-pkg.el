;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20261124.227"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "dc203af83984c29d487a8e54dc30234365319a85"
  :revdesc "dc203af83984")
