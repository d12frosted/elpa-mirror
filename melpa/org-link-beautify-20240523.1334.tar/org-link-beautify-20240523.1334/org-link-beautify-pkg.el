(define-package "org-link-beautify" "20240523.1334" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1")
    (qrencode "1.2"))
  :commit "3b73d3402f35d1e6373aebc5c3edeb66ec7760af" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
