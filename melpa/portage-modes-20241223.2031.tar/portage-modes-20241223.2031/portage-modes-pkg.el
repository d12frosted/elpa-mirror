;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "portage-modes" "20241223.2031"
  "Major modes for editing Portage config files."
  ()
  :url "https://github.com/OpenSauce04/portage-modes"
  :commit "021ed4834f2fcae1b51b633211a2376a8cc34124"
  :revdesc "021ed4834f2f"
  :authors '(("OpenSauce" . "opensauce04@gmail.com"))
  :maintainers '(("OpenSauce" . "opensauce04@gmail.com")))
