(define-package "modaled" "20230616.1820" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "2560235fb7e5d1e07277f460484de2c3988df2ef" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
