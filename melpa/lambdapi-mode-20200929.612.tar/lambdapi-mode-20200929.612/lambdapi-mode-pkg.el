(define-package "lambdapi-mode" "20200929.612" "A major mode for editing Lambdapi source code"
  '((emacs "26.1")
    (eglot "1.5")
    (math-symbol-lists "1.2.1")
    (highlight "20190710.1527"))
  :commit "402e9dfe90c3bad6e6ab6dbcd328e071c943ac06" :keywords
  ("languages")
  :authors
  (("Rodolphe Lepigre, Gabriel Hondet"))
  :maintainer
  ("Deducteam" . "dedukti-dev@inria.fr")
  :url "https://github.com/Deducteam/lambdapi")
;; Local Variables:
;; no-byte-compile: t
;; End:
