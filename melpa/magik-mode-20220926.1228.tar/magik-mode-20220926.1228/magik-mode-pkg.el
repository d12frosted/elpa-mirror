(define-package "magik-mode" "20220926.1228" "mode for editing Magik + some utils." 'nil :commit "0ae427be02275054ec08cd6fc5259f38473120b3" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
