;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251106.32"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "08c4d3b6cecb55d32c630a8d9b72f8ee766d0996"
  :revdesc "08c4d3b6cecb"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
