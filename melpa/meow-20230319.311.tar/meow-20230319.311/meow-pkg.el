(define-package "meow" "20230319.311" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "fb61ce5943d7ad11f4a7350e4b561947bbbaea71" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
