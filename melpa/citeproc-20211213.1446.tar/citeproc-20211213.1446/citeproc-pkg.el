(define-package "citeproc" "20211213.1446" "A CSL 1.0.1 Citation Processor"
  '((emacs "25")
    (dash "2.13.0")
    (s "1.12.0")
    (f "0.18.0")
    (queue "0.2")
    (string-inflection "1.0")
    (org "9")
    (parsebib "2.4"))
  :commit "538fed794c29acf81efee8a2674268bd3d7cc471" :authors
  '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainer
  '("András Simonyi" . "andras.simonyi@gmail.com")
  :keywords
  '("bib")
  :url "https://github.com/andras-simonyi/citeproc-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
