;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260401.1540"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "b4a1072d6c7c022be8d94bddc60c0c0c2c0f9db3"
  :revdesc "b4a1072d6c7c"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
