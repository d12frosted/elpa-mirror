(define-package "org-link-beautify" "20230228.958" "Beautify Org Links"
  '((emacs "28.1")
    (all-the-icons "5.0.0"))
  :commit "5d8ea07090dee2999f637ddcd61705b3b1cc34c7" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
