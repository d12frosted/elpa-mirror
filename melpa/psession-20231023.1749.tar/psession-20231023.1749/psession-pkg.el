(define-package "psession" "20231023.1749" "Persistent save of elisp objects."
  '((emacs "24")
    (cl-lib "0.5")
    (async "1.9.3"))
  :commit "1f74eecb5375fa94eb8d809f8e27caa48ed2323d" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://github.com/thierryvolpiatto/psession")
;; Local Variables:
;; no-byte-compile: t
;; End:
