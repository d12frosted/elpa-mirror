(define-package "dirvish" "20220311.1304" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "0d5f0f776a8788c1c4768ea0cc507d308a925c38" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
