;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250526.2210"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "e918a2cfef964a2e0a1042b04220305218418fde"
  :revdesc "e918a2cfef96"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
