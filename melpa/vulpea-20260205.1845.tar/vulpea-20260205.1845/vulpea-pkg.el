;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260205.1845"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "4a851cfd69d5c112795acc463aa80c351e3e2dae"
  :revdesc "4a851cfd69d5"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
