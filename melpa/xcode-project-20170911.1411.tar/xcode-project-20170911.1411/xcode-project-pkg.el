(define-package "xcode-project" "20170911.1411" "A package for reading Xcode project files."
  '((emacs "25"))
  :commit "f5548a26a1afc0b0d873556c25f6d8b6b9c2aa8c" :authors
  '(("John Buckley" . "john@olivetoast.com"))
  :maintainer
  '("John Buckley" . "john@olivetoast.com")
  :keywords
  '("languages" "tools")
  :url "https://github.com/nhojb/xcode-project.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
