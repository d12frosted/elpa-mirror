;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260410.1754"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "68208a0c1c9a9d097818628cc9c0bbaa023ac2bd"
  :revdesc "68208a0c1c9a"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
