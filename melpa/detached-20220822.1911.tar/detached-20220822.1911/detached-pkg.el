(define-package "detached" "20220822.1911" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "827e3d64fea7f66056d0f09a96b1039d1d3a6e26" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
