(define-package "parseclj" "20210927.1457" "Clojure/EDN parser"
  '((emacs "25"))
  :commit "f5f7ec16600505338ce0ef0ec63b6f2fa86f195c" :authors
  '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainer
  '("Arne Brasseur" . "arne@arnebrasseur.net")
  :keywords
  '("lisp" "clojure" "edn" "parser"))
;; Local Variables:
;; no-byte-compile: t
;; End:
