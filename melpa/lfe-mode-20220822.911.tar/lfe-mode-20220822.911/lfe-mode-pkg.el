(define-package "lfe-mode" "20220822.911" "Lisp Flavoured Erlang mode" 'nil :commit "f7cfdd30620448df1b058467ac160b34d4b8105b")
;; Local Variables:
;; no-byte-compile: t
;; End:
