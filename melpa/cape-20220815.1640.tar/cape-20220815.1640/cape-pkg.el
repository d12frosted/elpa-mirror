(define-package "cape" "20220815.1640" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "f632114f7df0dfd53c2147509cc351e5c857df8d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
