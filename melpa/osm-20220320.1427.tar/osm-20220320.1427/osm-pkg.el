(define-package "osm" "20220320.1427" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "f79b6a2e21f4655deabe4119bd66b274a82f3d61" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
