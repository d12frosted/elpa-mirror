(define-package "meow" "20211223.1520" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "959c19128ec2f9e4933bad6c9f29ac70bbb2083c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
