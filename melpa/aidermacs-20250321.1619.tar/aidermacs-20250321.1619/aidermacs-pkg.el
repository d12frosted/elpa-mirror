;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250321.1619"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "22dd34119c52d4abf5df41e5ef9c74685844f15f"
  :revdesc "22dd34119c52"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
