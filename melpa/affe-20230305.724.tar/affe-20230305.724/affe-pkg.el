(define-package "affe" "20230305.724" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.32"))
  :commit "cc54d36846e1f2ff9d4decbde8220a69be94cbf3" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
