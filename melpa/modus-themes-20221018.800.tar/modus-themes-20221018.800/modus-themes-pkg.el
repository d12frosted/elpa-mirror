(define-package "modus-themes" "20221018.800" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "d9e454603155d0bd73e6b6ac0bee4e370e30b701" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
