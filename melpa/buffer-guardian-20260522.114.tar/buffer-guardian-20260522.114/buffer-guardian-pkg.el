;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20260522.114"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "748b7af93b7fcbffdec7681aa46f14b5cf31d963"
  :revdesc "748b7af93b7f"
  :keywords '("maint")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
