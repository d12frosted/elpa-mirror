;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260929.135"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "f4cc44f6ab8864f66a6ec22981d5f67735cfa0c6"
  :revdesc "f4cc44f6ab88"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
