(define-package "dwim-shell-command" "20220910.1225" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "e5d427e4e63ca7b13960b5ad69893186ae3a9ceb" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
