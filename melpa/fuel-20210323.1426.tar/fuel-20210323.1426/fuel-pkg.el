(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "11799c10176b7b78477b614e0a2606e83cec0bcf")
;; Local Variables:
;; no-byte-compile: t
;; End:
