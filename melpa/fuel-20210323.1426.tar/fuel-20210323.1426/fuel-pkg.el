(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "59e924e19d8fce8beb9fa35a43bde026046fe776")
;; Local Variables:
;; no-byte-compile: t
;; End:
