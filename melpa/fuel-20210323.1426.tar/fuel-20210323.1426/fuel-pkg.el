(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "8eab96da4542cc031a996aa57a2104e71625625d")
;; Local Variables:
;; no-byte-compile: t
;; End:
