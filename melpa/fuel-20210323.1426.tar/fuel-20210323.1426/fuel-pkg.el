(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c6e4a8e387fc30d503d03b061040ab523571d22c")
;; Local Variables:
;; no-byte-compile: t
;; End:
