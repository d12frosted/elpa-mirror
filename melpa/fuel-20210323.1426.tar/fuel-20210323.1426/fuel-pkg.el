(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5a0079add1a371760402b1b4a74d96aeb7362f0b")
;; Local Variables:
;; no-byte-compile: t
;; End:
