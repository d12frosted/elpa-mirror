(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "954e5e323247b3bef650e490d52a28063a4e6ae5")
;; Local Variables:
;; no-byte-compile: t
;; End:
