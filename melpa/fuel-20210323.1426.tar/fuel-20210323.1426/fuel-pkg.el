(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "e51ec2a76052878a139b69ab8f0a03ae6ad98954")
;; Local Variables:
;; no-byte-compile: t
;; End:
