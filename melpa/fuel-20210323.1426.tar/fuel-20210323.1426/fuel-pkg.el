(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a4aaac4f4c293fcd08b5ef35821fe88fd370597a")
;; Local Variables:
;; no-byte-compile: t
;; End:
