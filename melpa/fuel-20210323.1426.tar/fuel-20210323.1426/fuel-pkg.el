(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "8b2c16b09ac47b5c02f28e0b8079bc745fcba650")
;; Local Variables:
;; no-byte-compile: t
;; End:
