(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5644bad8c18b61ada50879095838378044142ad9")
;; Local Variables:
;; no-byte-compile: t
;; End:
