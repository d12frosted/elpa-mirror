(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "81b4cdfcc1388265554b55c5652075cb64f45711")
;; Local Variables:
;; no-byte-compile: t
;; End:
