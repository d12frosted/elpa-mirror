;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260429.506"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "bef16cd85c10d269d2039c1fa786f8cdfdf25d95"
  :revdesc "bef16cd85c10"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
