(define-package "modus-themes" "20210520.623" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "bc67d06569290561f44f173cdf6f32e74126c313" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
