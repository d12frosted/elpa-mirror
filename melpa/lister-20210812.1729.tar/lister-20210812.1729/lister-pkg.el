(define-package "lister" "20210812.1729" "Yet another list printer"
  '((emacs "26.1"))
  :commit "a8cc3c5d1f0f4b710e15e76477eae40a99a79ad7" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("hypermedia")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
