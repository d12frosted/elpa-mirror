(define-package "ebib" "20210407.2146" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "bd1c9dcda79f734f6302e7c81ee0f13106a3a9e1" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
