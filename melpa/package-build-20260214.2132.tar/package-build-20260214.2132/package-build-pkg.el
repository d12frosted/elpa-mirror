;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260214.2132"
  "Tools for assembling a package archive."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/melpa/package-build"
  :commit "32fa831dc51e070abba308d2cfb176e06174af0e"
  :revdesc "32fa831dc51e"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")))
