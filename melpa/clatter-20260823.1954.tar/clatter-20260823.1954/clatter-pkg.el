;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260823.1954"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "bdc84f73f6333a755bf80feaaacc5eb9cfb5274f"
  :revdesc "bdc84f73f633"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
