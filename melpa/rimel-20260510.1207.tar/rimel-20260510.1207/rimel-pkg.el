;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260510.1207"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "c85829fd0c3645a1e9a554b5b3d2f848e58a31cc"
  :revdesc "c85829fd0c36"
  :keywords '("convenience" "chinese" "input-method" "rime"))
