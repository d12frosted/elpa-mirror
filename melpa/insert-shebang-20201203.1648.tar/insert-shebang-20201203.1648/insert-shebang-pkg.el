;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-shebang" "20201203.1648"
  "Insert shebang line automatically."
  ()
  :url "https://gitlab.com/psachin/insert-shebang"
  :commit "cc8cea997a8523bce9f303de993af3a73eb0d2e2"
  :revdesc "cc8cea997a85"
  :keywords '("shebang" "tool" "convenience")
  :authors '(("Sachin Patil" . "iclcoolster@gmail.com"))
  :maintainers '(("Sachin Patil" . "iclcoolster@gmail.com")))
