;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-maildir" "20261001.1604"
  "Display maildirs as a tree."
  '((emacs   "29.1")
    (compat  "31.1")
    (notmuch "0.39"))
  :url "https://github.com/tarsius/notmuch-maildir"
  :commit "7834265f8b1ebd5b59911b8a44874faed9e73030"
  :revdesc "7834265f8b1e"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-maildir@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-maildir@jonas.bernoulli.dev")))
