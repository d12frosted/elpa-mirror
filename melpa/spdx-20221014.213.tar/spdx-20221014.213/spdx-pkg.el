(define-package "spdx" "20221014.213" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "4ed06484aec64ff04e435c2c8c34325d6c6033f5" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
