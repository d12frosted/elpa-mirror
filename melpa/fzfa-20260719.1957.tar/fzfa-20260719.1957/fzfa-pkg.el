;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260719.1957"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.2"))
  :url "https://github.com/jojojames/fzfa"
  :commit "25607f169d462507c74fc2db195f14efc39ce6e0"
  :revdesc "25607f169d46"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
