;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260510.2253"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9c86c6ee8f1d4ea72774aad43a7ec7f74861f6ba"
  :revdesc "9c86c6ee8f1d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
