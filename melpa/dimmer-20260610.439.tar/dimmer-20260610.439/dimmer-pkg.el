;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "20260610.439"
  "Visually highlight the selected buffer."
  '((emacs "27.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "2252760d2e62197ac440e68f0fbedafd2796da1d"
  :revdesc "2252760d2e62"
  :keywords '("faces" "editing"))
