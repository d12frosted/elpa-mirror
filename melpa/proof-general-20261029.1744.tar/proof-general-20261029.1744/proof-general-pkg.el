;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261029.1744"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "01c3a4c51419821aa4268dfe47481ddb5e8b9189"
  :revdesc "01c3a4c51419"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
