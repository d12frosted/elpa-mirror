(define-package "autobuild" "20230518.438" "Define and execute build rules and compilation pipelines"
  '((cl-lib "0.3")
    (emacs "26.1")
    (selcand "0.0.1"))
  :commit "1cd2d923303392cb1bb93fa0398332c2fce8399c" :authors
  '(("Ernesto Alfonso"))
  :maintainers
  '((nil . "(concat \"erjoalgo\" \"@\" \"gmail\" \".com\")"))
  :maintainer
  '(nil . "(concat \"erjoalgo\" \"@\" \"gmail\" \".com\")")
  :keywords
  '("compile" "build" "pipeline" "autobuild" "extensions" "processes" "tools")
  :url "https://github.com/erjoalgo/autobuild")
;; Local Variables:
;; no-byte-compile: t
;; End:
