;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260612.642"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "44eb47c3761e151899a492f8c1c1543e69a24261"
  :revdesc "44eb47c3761e"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
