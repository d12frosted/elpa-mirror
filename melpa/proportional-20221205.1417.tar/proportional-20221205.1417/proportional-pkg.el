;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proportional" "20221205.1417"
  "Use a proportional font everywhere."
  '((emacs "25.1"))
  :url "https://github.com/ksjogo/proportional"
  :commit "6b675694292a5dbebb52b6196e8ccee6e3a73042"
  :revdesc "6b675694292a"
  :keywords '("faces"))
