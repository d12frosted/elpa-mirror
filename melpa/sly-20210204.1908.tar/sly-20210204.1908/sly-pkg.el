(define-package "sly" "20210204.1908" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "602af24d22d4bffa23f6cb906cf86d1684545c2b" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
