;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lithium" "20250703.243"
  "Lightweight modal interfaces."
  '((emacs "25.1"))
  :url "https://github.com/countvajhula/lithium"
  :commit "5ed65cba5ff3de06764ddf1b5efc6761c932017a"
  :revdesc "5ed65cba5ff3"
  :keywords '("convenience" "emulations" "lisp" "tools")
  :authors '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Siddhartha Kasivajhula" . "sid@countvajhula.com")))
