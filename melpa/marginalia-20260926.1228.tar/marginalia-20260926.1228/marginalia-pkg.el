;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marginalia" "20260926.1228"
  "Enrich existing commands with completion annotations."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/marginalia"
  :commit "42eafcfddbe88d92ed96521a00a5a90a49bac4dd"
  :revdesc "42eafcfddbe8"
  :keywords '("docs" "help" "matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
