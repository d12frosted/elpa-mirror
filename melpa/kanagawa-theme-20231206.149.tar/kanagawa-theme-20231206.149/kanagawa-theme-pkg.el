(define-package "kanagawa-theme" "20231206.149" "An elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa"
  '((emacs "24.3"))
  :commit "78ccf6930336da98f248896af53ab0307c4d6459" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/Meritamen/kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
