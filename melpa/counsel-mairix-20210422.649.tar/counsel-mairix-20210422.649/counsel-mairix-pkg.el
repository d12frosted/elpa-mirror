;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-mairix" "20210422.649"
  "Counsel interface for Mairix."
  '((emacs "26.3")
    (ivy   "0.13.1"))
  :url "https://sr.ht/~ane/counsel-mairix"
  :commit "39fa2ad10a5f899cb3f3275f9a6ebd166c51216a"
  :revdesc "39fa2ad10a5f"
  :keywords '("mail")
  :authors '(("Antoine Kalmbach" . "ane@iki.fi"))
  :maintainers '(("Antoine Kalmbach" . "ane@iki.fi")))
