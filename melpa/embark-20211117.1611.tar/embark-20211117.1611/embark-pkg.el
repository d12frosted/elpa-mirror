(define-package "embark" "20211117.1611" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "514b1308e97e322c89e691d1022b29586c72de14" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
