(define-package "meow" "20220726.1525" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "679f73dddcdcb13fc80fab3e1d04d4e28b780cf7" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
