(define-package "srfi" "20221211.252" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "84ae13c57d1b26337d760e10cf3b14fe8adaa81c" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
