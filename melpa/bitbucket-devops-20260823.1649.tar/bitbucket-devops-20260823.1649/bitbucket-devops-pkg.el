;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbucket-devops" "20260823.1649"
  "Bitbucket Cloud DevOps workflows."
  '((emacs         "29.1")
    (magit         "4.0.0")
    (markdown-mode "2.6")
    (transient     "0.3.0")
    (yaml          "1.2.3"))
  :url "https://github.com/will-abb/bitbucket-devops.el"
  :commit "e362baf75ebf9ca32ddd5a5fde17fe53cebfaad9"
  :revdesc "e362baf75ebf"
  :keywords '("tools" "vc")
  :authors '(("Will Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Will Bosch-Bello" . "williamsbosch@gmail.com")))
