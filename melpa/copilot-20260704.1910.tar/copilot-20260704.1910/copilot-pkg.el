;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260704.1910"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "667e199d0765d92b7c5220a5eb60a1ecaab52a3c"
  :revdesc "667e199d0765"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
