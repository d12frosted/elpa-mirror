;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20241221.1617"
  "LSP mode."
  '((emacs         "27.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "791d9a3e7bd1b373976a514cf230a3ba8e6b142e"
  :revdesc "791d9a3e7bd1"
  :keywords '("languages"))
