(define-package "lister" "20211023.1842" "Yet another list printer"
  '((emacs "26.1"))
  :commit "cdc4ee6df5033824582648974d20ac442f2d61da" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
