;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250215.1514"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.1")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "b304bd39b4bc50505962043d0ac2d8bb5b34e4af"
  :revdesc "b304bd39b4bc"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
