(define-package "helm-bufler" "20210708.2217" "Helm source for Bufler"
  '((emacs "26.3")
    (bufler "0.2pre")
    (helm "1.9.4"))
  :commit "cb10234bc35fb3f2489c8bfd5b4e80fd1dc05c5e" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/bufler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
