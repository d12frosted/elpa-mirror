;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-fuz" "20191222.946"
  "Integration between fuz and ivy."
  '((emacs "25.1")
    (fuz   "1.3.0")
    (ivy   "0.13.0"))
  :url "https://github.com/Silex/ivy-fuz.el"
  :commit "f171ac73422a4bae1503d63d804e691482ed35b2"
  :revdesc "f171ac73422a"
  :keywords '("convenience")
  :authors '(("Zhu Zihao" . "all_but_last@163.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
