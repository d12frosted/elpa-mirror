(define-package "fanyi" "20211015.219" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "25f54daf8aabc75df6c934e90f399a28420ebcc2" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
