;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-hlint" "20170723.146"
  "A flymake handler for haskell-mode files using hlint."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-hlint"
  :commit "f910736b26784efc9a2fa29503f45c1f1dd0aa38"
  :revdesc "f910736b2678"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
