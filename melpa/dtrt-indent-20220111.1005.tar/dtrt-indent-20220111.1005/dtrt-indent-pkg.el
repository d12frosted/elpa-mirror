(define-package "dtrt-indent" "20220111.1005" "Adapt to foreign indentation offsets" 'nil :commit "ac0c29b9327ade80f562f2501264d2eaeb5bf318" :authors
  '(("Julian Scheid" . "julians37@googlemail.com"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("convenience" "files" "languages" "c"))
;; Local Variables:
;; no-byte-compile: t
;; End:
