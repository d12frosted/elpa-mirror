(define-package "gdscript-mode" "20230421.620" "Major mode for Godot's GDScript language"
  '((emacs "26.3"))
  :commit "30c4d48f81d5e52e8667cc10780e4af743e27f96" :authors
  '(("Nathan Lovato <nathan@gdquest.com>, Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainer
  '(nil . "nathan@gdquest.com")
  :keywords
  '("languages")
  :url "https://github.com/godotengine/emacs-gdscript-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
