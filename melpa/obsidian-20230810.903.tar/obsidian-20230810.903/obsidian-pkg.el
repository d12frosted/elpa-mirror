(define-package "obsidian" "20230810.903" "Obsidian Notes interface"
  '((emacs "27.2")
    (s "1.12.0")
    (dash "2.13")
    (markdown-mode "2.5")
    (elgrep "1.0.0")
    (yaml "0.5.1"))
  :commit "659ae9fc8dd17c5315a325b1639e7d881ec6e9c2" :authors
  '(("Mykhaylo Bilyanskyy"))
  :maintainers
  '(("Mykhaylo Bilyanskyy"))
  :maintainer
  '("Mykhaylo Bilyanskyy")
  :keywords
  '("obsidian" "pkm" "convenience")
  :url "https://github.com./licht1stein/obsidian.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
