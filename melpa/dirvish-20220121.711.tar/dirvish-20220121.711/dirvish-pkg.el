(define-package "dirvish" "20220121.711" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e694d3891e91e235b055698814dc7a2f7390eda6" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
