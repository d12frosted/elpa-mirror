;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-napkin" "20240405.1223"
  "Babel functions for Napkin."
  '((emacs "26.1"))
  :url "https://github.com/pinetr2e/ob-napkin"
  :commit "497bde38772e6fd2a393dd292435ae3787580db4"
  :revdesc "497bde38772e"
  :keywords '("tools" "literate programming" "reproducible research" "napkin" "plantuml"))
