;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-invox" "20260624.405"
  "Invoice management for contractors using Org mode."
  '((emacs "27.1")
    (org   "9.0"))
  :url "https://github.com/a-manumohan/org-invox"
  :commit "0373529a0c922fcca62c7cb604099323bc869f76"
  :revdesc "0373529a0c92"
  :keywords '("outlines" "tools")
  :authors '(("Manu Mohan" . "me@manumohan.net"))
  :maintainers '(("Manu Mohan" . "me@manumohan.net")))
