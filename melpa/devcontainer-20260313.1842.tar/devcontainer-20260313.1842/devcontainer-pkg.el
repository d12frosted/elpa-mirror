;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20260313.1842"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "5758aece4911a1d5f93f6c4fb2f50491021ebf40"
  :revdesc "5758aece4911"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
