(define-package "for" "20220912.1351" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "8ed0796e4e67ed00a7b5f7f61edf498ee1d33424" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
