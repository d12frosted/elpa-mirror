;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250522.1552"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "29ba1b8183a1f8e6de0c6601a56358a9d2c3a704"
  :revdesc "29ba1b8183a1"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
