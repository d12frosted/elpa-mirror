;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250525.329"
  "Modern HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "139e9e498a48c9ba85146a361f39f87f3b50b4c2"
  :revdesc "139e9e498a48"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
