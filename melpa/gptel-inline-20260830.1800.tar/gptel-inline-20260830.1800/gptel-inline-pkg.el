;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-inline" "20260830.1800"
  "Persistent gptel session that follows you around."
  '((emacs  "30.1")
    (compat "30.1.0.0")
    (gptel  "0.9.9.5"))
  :url "https://github.com/karthink/gptel-inline"
  :commit "11763858eda358e9481ce4938024f84e506e1cde"
  :revdesc "11763858eda3"
  :keywords '("comm")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
