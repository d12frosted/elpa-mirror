;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260729.257"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "1216b0912659f183cccfbe9d16b13516633949b7"
  :revdesc "1216b0912659"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
