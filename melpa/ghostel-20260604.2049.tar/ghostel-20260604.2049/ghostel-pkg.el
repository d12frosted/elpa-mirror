;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260604.2049"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5779a2adceb2a173978adbc0288135479433445c"
  :revdesc "5779a2adceb2"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
