;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20250922.854"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "82dae7acab575a6454e1ff19654248982ee2c9e1"
  :revdesc "82dae7acab57")
