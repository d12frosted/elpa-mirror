;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260414.1450"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "bdd85c2edf6575bd6225febfe1c2f81089cc196b"
  :revdesc "bdd85c2edf65"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
