;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kele" "20251210.1212"
  "Spritzy Kubernetes cluster management."
  '((emacs         "29.1")
    (async         "1.9.7")
    (dash          "2.19.1")
    (f             "0.20.0")
    (magit-section "4.0.0")
    (memoize       "0")
    (plz           "0.8.0")
    (yaml          "0.5.1"))
  :url "https://github.com/jinnovation/kele.el"
  :commit "fd6b4d7916754ae0959c639ebf9f0ff972513428"
  :revdesc "fd6b4d791675"
  :keywords '("kubernetes" "tools")
  :authors '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers '(("Jonathan Jin" . "me@jonathanj.in")))
