(define-package "helm" "20240526.828" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.8")
    (wfnames "1.1"))
  :commit "4390fd4de85d1291d655f3bc80083a9ab03e3f54" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
