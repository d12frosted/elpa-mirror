;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam" "20251103.703"
  "A database abstraction layer for Org-mode."
  '((emacs         "26.1")
    (compat        "30.1")
    (dash          "2.13")
    (org           "9.6")
    (emacsql       "4.1.0")
    (magit-section "3.0.0"))
  :url "https://github.com/org-roam/org-roam"
  :commit "255c70c3e5fa483a8ee6219ff1b26c1e6cdc0210"
  :revdesc "255c70c3e5fa"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainers '(("Jethro Kuan" . "jethrokuan95@gmail.com")))
