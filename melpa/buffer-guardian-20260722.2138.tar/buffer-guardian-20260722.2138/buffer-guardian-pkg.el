;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20260722.2138"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "1f2ce13b9d6706a29eaa9fae5bfb176ce6466798"
  :revdesc "1f2ce13b9d67"
  :keywords '("maint")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
