(define-package "meow" "20220216.1819" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "583e072d84a73dbb353d9c48d6236dd69795795c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
