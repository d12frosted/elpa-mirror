(define-package "racket-mode" "20220330.1931" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "b3edf04740f6edfc872b1ba61b13a58a03d983c0" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
