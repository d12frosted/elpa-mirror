(define-package "embark" "20210416.1427" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "b8f82c9b6bdcd6e4d53e7d0bad869f3c8a8ef2f9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
