;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260513.1434"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "d37d36e2fe643523bc5cf9ab6bb26d14600ae308"
  :revdesc "d37d36e2fe64"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
