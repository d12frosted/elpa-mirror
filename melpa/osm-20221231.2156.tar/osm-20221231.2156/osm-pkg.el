(define-package "osm" "20221231.2156" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "4f18c7dc78620f2a40b543e6857cd70acc867dbf" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
