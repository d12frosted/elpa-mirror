(define-package "inkpot-theme" "20230611.151" "A port of vim's inkpot theme"
  '((emacs "24.1"))
  :commit "5eda63068e98774b04d7e217702034069b13e9df" :authors
  '(("Sarah Iovan" . "sarah@hwaetageek.com")
    ("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Sarah Iovan" . "sarah@hwaetageek.com"))
  :maintainer
  '("Sarah Iovan" . "sarah@hwaetageek.com")
  :url "https://codeberg.org/ideasman42/emacs-inkpot-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
