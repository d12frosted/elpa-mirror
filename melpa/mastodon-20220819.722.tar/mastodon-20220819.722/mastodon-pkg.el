(define-package "mastodon" "20220819.722" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.2")
    (seq "1.0"))
  :commit "b8838b8a2fb8932227c4daf2cf823ad9d0e1eea6" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
