(define-package "gnuplot" "20201221.1226" "Major-mode and interactive frontend for gnuplot"
  '((emacs "24.3"))
  :commit "6a192efca961b6c494c3f5ebaf1b1cecf30a5d63" :keywords
  ("data" "gnuplot" "plotting")
  :authors
  (("Jon Oddie")
   ("Bruce Ravel")
   ("Phil Type"))
  :maintainer
  ("Bruce Ravel" . "bruceravel1@gmail.com")
  :url "https://github.com/emacsorphanage/gnuplot")
;; Local Variables:
;; no-byte-compile: t
;; End:
