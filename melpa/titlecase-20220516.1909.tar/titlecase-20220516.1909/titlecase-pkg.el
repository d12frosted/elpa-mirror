(define-package "titlecase" "20220516.1909" "Title-case phrases"
  '((emacs "25.1"))
  :commit "ca79d9b25e8bab5eef92b13dc69ac0c38ac39172" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://github.com/duckwork/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
