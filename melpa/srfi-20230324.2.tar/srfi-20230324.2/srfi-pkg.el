(define-package "srfi" "20230324.2" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "67de3f09d1e51ba8449ebc00748ad2e285d0ae0e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
