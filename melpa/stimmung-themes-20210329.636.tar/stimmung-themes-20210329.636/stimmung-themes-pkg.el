(define-package "stimmung-themes" "20210329.636" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "fbe77198ac7ce5dbca9b4f0bfd0c9e35a665a0a7" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
