(define-package "modus-themes" "20220815.856" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "7e08e8b8e5d5a3d4fc4d73544603feca2729db20" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
