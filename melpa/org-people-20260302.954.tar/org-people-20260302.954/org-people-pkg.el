;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260302.954"
  "Work with a contact-list in org-mode files."
  '((emacs "28.0")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "339c81c20bffa84ee195e07fbebde29d97697b5d"
  :revdesc "339c81c20bff"
  :keywords '("outlines" "contacts" "people"))
