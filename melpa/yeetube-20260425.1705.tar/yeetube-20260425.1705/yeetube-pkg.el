;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260425.1705"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs     "27.2")
    (compat    "29.1.4.2")
    (transient "0.7.2"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "41bfc27e0aa70714fcb33e3c724853549359fdd1"
  :revdesc "41bfc27e0aa7"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
