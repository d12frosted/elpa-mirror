(define-package "embark" "20220419.1915" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "5e86f50825469a6ef00d7a3c6d6f59af5b759495" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
