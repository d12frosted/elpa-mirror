(define-package "zig-ts-mode" "20240928.1338" "Tree Sitter support for Zig"
  '((emacs "29.1"))
  :commit "8cc482ff294b30a7f749ea5f1ee4804d479a6ba3" :authors
  '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers
  '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainer
  '("meowking" . "mr.meowking@tutamail.com")
  :keywords
  '("zig" "languages" "tree-sitter")
  :url "https://codeberg.org/meow_king/zig-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
