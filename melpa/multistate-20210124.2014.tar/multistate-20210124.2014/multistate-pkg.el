;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multistate" "20210124.2014"
  "Multistate mode."
  '((emacs "25.1")
    (ht    "2.3"))
  :url "https://gitlab.com/matsievskiysv/multistate"
  :commit "a7ab9dc7aac0b6d6d2f872de4e0d1b8550834a9b"
  :revdesc "a7ab9dc7aac0"
  :keywords '("convenience"))
