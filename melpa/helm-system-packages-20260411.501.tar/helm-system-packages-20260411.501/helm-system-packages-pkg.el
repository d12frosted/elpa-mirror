;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "20260411.501"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "ca29a21bb9177ebdb3f0d81a22b80d747d916335"
  :revdesc "ca29a21bb917"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
