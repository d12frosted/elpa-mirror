;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-solidity" "20170805.644"
  "A flymake handler for solidity using solc."
  '((flymake-easy "0.10"))
  :url "https://github.com/kootenvp/flymake-solidity"
  :commit "48bfe9525f764d8a68cc0270905dbf45bfd00bb8"
  :revdesc "48bfe9525f76"
  :authors '(("Pascal van Kooten" . "kootenpv@gmail.com"))
  :maintainers '(("Pascal van Kooten" . "kootenpv@gmail.com")))
