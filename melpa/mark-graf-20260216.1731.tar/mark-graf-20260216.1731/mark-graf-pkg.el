;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-graf" "20260216.1731"
  "Modern WYSIWYG-style markdown editing."
  '((emacs "30.1"))
  :url "https://github.com/hyperZphere/mark-graf"
  :commit "f86639fcb2e64960c6b96d4c0a99885f671db871"
  :revdesc "f86639fcb2e6"
  :keywords '("markdown" "wp" "text")
  :authors '(("Marc Ansset" . "info@ansset.com"))
  :maintainers '(("Marc Ansset" . "info@ansset.com")))
