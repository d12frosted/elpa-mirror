;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "20261124.2019"
  "Minimal and elegant modeline."
  '((emacs "30.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "56429fb2a8116de3df2bfb978187422d8d94ce48"
  :revdesc "56429fb2a811"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
