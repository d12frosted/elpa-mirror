(define-package "buffer-manage" "20191015.1730" "manage buffers"
  '((emacs "26")
    (choice-program "0.5")
    (dash "2.13.0"))
  :commit "4fd0e6f9f3da31bc805be2000adf2c91088dd39b" :keywords
  ("interactive" "buffer" "management")
  :authors
  (("Paul Landes"))
  :maintainer
  ("Paul Landes")
  :url "https://github.com/plandes/buffer-manage")
;; Local Variables:
;; no-byte-compile: t
;; End:
