(define-package "mono-complete" "20230405.529" "Completion suggestions with multiple back-ends"
  '((emacs "28.1"))
  :commit "29436788b9ebe8a147b1deece6e86151528880f5" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mono-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
