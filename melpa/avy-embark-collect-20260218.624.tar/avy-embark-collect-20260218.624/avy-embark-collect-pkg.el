;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-embark-collect" "20260218.624"
  "Use avy to jump to Embark Collect entries."
  '((emacs  "29.1")
    (embark "1.1")
    (avy    "0.5"))
  :url "https://github.com/oantolin/embark"
  :commit "0bdfd38d281d6375e6e675ce6f1bd597a9e3b136"
  :revdesc "0bdfd38d281d"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
