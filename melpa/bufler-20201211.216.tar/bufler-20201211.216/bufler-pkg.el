(define-package "bufler" "20201211.216" "Group buffers into workspaces with programmable rules"
  '((emacs "26.3")
    (dash "2.17")
    (dash-functional "2.17")
    (f "0.17")
    (pretty-hydra "0.2.2")
    (magit-section "0.1"))
  :commit "752e2c2fb5543c3d675f00db34b0b6affc03f24d" :keywords
  ("convenience")
  :authors
  (("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  ("Adam Porter" . "adam@alphapapa.net")
  :url "https://github.com/alphapapa/bufler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
