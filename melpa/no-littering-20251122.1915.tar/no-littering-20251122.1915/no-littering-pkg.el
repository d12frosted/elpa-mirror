;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20251122.1915"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "68169beaebc160430386148eb80ec5e09b64d53f"
  :revdesc "68169beaebc1"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
