(define-package "org-notifications" "20210826.1721" "Creates notifications for org-mode entries"
  '((emacs "25.1")
    (org "9.0")
    (sound-wav "0.2")
    (alert "1.2")
    (seq "2.21"))
  :commit "04d648ab5f5f65b600a3af1c9e8ce4e07800d995" :authors
  '(("doppelc"))
  :maintainer
  '("doppelc")
  :keywords
  '("outlines")
  :url "https://github.com/doppelc/org-notifications")
;; Local Variables:
;; no-byte-compile: t
;; End:
