;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20250527.1751"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "06b94e8cd578adcb53c68e15766dec88e95afb8f"
  :revdesc "06b94e8cd578"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")
                 ("John Ciolfi" . "john.ciolfi.32@gmail.com")))
