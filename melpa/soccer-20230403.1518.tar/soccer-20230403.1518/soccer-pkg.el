(define-package "soccer" "20230403.1518" "Fixtures, results, table etc for soccer"
  '((emacs "26.1")
    (dash "2.19.1"))
  :commit "4515eaa5e12613185f4569c79772db886dcfa2f7" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("games" "soccer" "football")
  :url "https://github.com/md-arif-shaikh/soccer")
;; Local Variables:
;; no-byte-compile: t
;; End:
