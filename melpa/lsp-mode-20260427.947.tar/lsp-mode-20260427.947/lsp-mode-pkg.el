;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260427.947"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "ca79027f47b6ae6d386b938bf0b2bdfbf49d0d99"
  :revdesc "ca79027f47b6"
  :keywords '("languages"))
