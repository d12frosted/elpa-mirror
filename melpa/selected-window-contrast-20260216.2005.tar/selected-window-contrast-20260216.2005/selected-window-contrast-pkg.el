;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260216.2005"
  "Highlight by brightness of text and background."
  '((emacs "25.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "b5a15be393b6af4f74432d0b04a051af35f59272"
  :revdesc "b5a15be393b6"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
