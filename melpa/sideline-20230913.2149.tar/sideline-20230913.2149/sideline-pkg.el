(define-package "sideline" "20230913.2149" "Show information on the side"
  '((emacs "27.1"))
  :commit "b63cea69948d386f007004ba6a272fc0e944ffb9" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/emacs-sideline/sideline")
;; Local Variables:
;; no-byte-compile: t
;; End:
