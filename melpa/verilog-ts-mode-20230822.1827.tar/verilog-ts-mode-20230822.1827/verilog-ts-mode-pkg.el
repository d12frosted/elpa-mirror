(define-package "verilog-ts-mode" "20230822.1827" "Verilog Tree-sitter major mode"
  '((emacs "28.1")
    (compat "29.1.4.0"))
  :commit "ed165e8631f2c7acc526afc9762b04f226ec573a" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
