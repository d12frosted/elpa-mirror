;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "20260122.651"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "e5d3435b2f1e3a5fd352eac6de2bc43771e0d86e"
  :revdesc "e5d3435b2f1e"
  :keywords '("color" "theme" "faces"))
