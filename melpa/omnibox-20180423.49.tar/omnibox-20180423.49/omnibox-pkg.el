;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omnibox" "20180423.49"
  "Selection package."
  '((emacs       "26.1")
    (dash        "2.13")
    (frame-local "0.0.1"))
  :url "https://github.com/sebastiencs/omnibox"
  :commit "8ee75c71c20c438ebc43ba24ef6f543633d118f3"
  :revdesc "8ee75c71c20c"
  :keywords '("completion" "selection" "convenience" "frames")
  :authors '(("Sebastien Chapuis" . "sebastien@chapu.is"))
  :maintainers '(("Sebastien Chapuis" . "sebastien@chapu.is")))
