(define-package "eldev" "20210516.2018" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "70167056fd81e8477b0a5508cf7e28d7a48a2367" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
