(define-package "pyim-cangjie5dict" "20210420.202" "Some cangjie5 dicts for pyim"
  '((pyim "1.0"))
  :commit "ebbdba1d9bcc065c423d1450eae2577e8d267050" :authors
  '(("Yuanchen Xie" . "yuanchen.gm@gmail.com"))
  :maintainer
  '("Yuanchen Xie" . "yuanchen.gm@gmail.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/erstern/pyim-cangjie5dict")
;; Local Variables:
;; no-byte-compile: t
;; End:
