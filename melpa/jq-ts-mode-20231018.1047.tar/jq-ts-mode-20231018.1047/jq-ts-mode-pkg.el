(define-package "jq-ts-mode" "20231018.1047" "Tree-sitter support for jq buffers"
  '((emacs "29.1"))
  :commit "14a4df0ed089bc9d322b9846d1b87f603c241161" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("jq" "languages" "tree-sitter")
  :url "https://github.com/nverno/jq-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
