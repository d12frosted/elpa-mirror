;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "20250301.1617"
  "Sections for read-only buffers."
  '((emacs  "27.1")
    (compat "30.0.2.0")
    (llama  "0.6.0")
    (seq    "2.24"))
  :url "https://github.com/magit/magit"
  :commit "dfbc8fb91367dd6c12072c4cddabb47470c23f8c"
  :revdesc "dfbc8fb91367"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
