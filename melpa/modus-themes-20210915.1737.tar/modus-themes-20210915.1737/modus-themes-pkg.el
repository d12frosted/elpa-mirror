(define-package "modus-themes" "20210915.1737" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "4c9465b8bdb778fb5fe306d0b1d9d9218df9cf72" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
