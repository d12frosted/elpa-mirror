;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20251227.407"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "3e4322c5247cc237bd82879bc12a79ed6674de91"
  :revdesc "3e4322c5247c"
  :keywords '("hypermedia"))
