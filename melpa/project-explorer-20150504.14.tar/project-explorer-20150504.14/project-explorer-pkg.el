;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-explorer" "20150504.14"
  "A project explorer sidebar."
  '((cl-lib     "0.3")
    (es-lib     "0.3")
    (es-windows "0.1")
    (emacs      "24"))
  :url "https://github.com/sabof/project-explorer"
  :commit "589a09008706f5f4ef91393dc4306eede0d15ca9"
  :revdesc "589a09008706")
