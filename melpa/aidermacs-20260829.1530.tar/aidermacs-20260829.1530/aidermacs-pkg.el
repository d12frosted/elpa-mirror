;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260829.1530"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "9046a03af9edfe7077ea4dfa67b52b8c63edb0a6"
  :revdesc "9046a03af9ed"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
