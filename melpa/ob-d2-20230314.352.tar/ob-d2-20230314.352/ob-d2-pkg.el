;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-d2" "20230314.352"
  "Org-babel functions for d2."
  '((emacs "24.1"))
  :url "https://github.com/xcapaldi/ob-d2"
  :commit "5d197f8225a9fb4da997235b231abe30049c6825"
  :revdesc "5d197f8225a9"
  :keywords '("languages"))
