(define-package "meow" "20230410.1028" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "2437a95767597c95af4036d5c907dd0c89d80b6b" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
