;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-views" "20251130.249"
  "View emails in mu4e using xwidget-webkit."
  '((emacs          "26.1")
    (xwidgets-reuse "0.3")
    (ht             "2.2")
    (esxml          "20210323.1102"))
  :url "https://github.com/lordpretzel/mu4e-views"
  :commit "892ea3163fa4964e9fc99e732e0c0d21d4931ae7"
  :revdesc "892ea3163fa4"
  :keywords '("mail")
  :authors '(("Boris Glavic" . "lordpretzel@gmail.com"))
  :maintainers '(("Boris Glavic" . "lordpretzel@gmail.com")))
