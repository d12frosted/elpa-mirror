(define-package "phpunit" "20230124.743" "Launch PHP unit tests using phpunit"
  '((s "1.12.0")
    (f "0.19.0")
    (pkg-info "0.6")
    (cl-lib "0.5")
    (emacs "24.3"))
  :commit "4a36906344c0abc11f48cc08cd8d50a9f46963f8" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
    ("Eric Hansen" . "hansen.c.eric@gmail.com"))
  :maintainers
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("tools" "php" "tests" "phpunit")
  :url "https://github.com/nlamirault/phpunit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
