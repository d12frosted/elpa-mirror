(define-package "dirvish" "20220120.1441" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "91ef79e20afb5120f5bf02f43f4d292c22a254dc" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
