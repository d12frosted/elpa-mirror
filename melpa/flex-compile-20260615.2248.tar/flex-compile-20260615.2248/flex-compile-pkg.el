;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-compile" "20260615.2248"
  "Run, evaluate and compile across many languages."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.1"))
  :url "https://github.com/plandes/flex-compile"
  :commit "2d9d805ad6d1db8d7eeedf67460e4e13c9b06528"
  :revdesc "2d9d805ad6d1"
  :keywords '("compilation" "integration" "processes"))
