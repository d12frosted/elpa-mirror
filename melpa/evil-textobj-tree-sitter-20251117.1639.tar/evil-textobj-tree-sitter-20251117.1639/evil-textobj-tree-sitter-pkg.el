;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-tree-sitter" "20251117.1639"
  "Provides evil textobjects using tree-sitter."
  '((emacs "25.1"))
  :url "https://github.com/meain/evil-textobj-tree-sitter"
  :commit "411596f993b97d83951f214c5e0f5cc15da492aa"
  :revdesc "411596f993b9"
  :keywords '("evil" "tree-sitter" "text-object" "convenience"))
