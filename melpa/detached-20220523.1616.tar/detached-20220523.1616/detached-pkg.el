(define-package "detached" "20220523.1616" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "43faf8459416aaa22738fbafec0f67f210a912fd" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
