(define-package "dtache" "20220319.1410" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "bdbd007caf16002b2b46edb7c19123195d1f91af" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
