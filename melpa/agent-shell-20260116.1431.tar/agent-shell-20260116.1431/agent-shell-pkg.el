;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260116.1431"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "321ad6b33d2b4d3879ac1d88d4cacddc1b10bfc6"
  :revdesc "321ad6b33d2b")
