;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260306.122"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "65773b1b0b96c8c35d068da08dd68d6839bbb076"
  :revdesc "65773b1b0b96"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
