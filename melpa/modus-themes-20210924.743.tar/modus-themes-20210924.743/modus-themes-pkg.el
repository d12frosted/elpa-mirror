(define-package "modus-themes" "20210924.743" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "8650eba4236a50cc63db8711c1ce20c66bfe24f0" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
