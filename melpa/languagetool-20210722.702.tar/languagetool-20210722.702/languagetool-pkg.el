(define-package "languagetool" "20210722.702" "LanguageTool integration for grammar and spell check"
  '((emacs "25.1")
    (request "0.3.2"))
  :commit "d3665a97cc87577f434a7476e1194b43f35408a8" :authors
  '(("Joar Buitrago" . "jebuitragoc@unal.edu.co"))
  :maintainer
  '("Joar Buitrago" . "jebuitragoc@unal.edu.co")
  :keywords
  '("grammar" "text" "docs" "tools" "convenience" "checker")
  :url "https://github.com/PillFall/Emacs-LanguageTool.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
