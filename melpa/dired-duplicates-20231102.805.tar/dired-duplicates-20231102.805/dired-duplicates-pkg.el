(define-package "dired-duplicates" "20231102.805" "Find duplicate files locally and remotely"
  '((emacs "27.1"))
  :commit "ec0a89ca325b4fb970824d0663d91e4f8f58235f" :authors
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainers
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainer
  '("Harald Judt" . "h.judt@gmx.at")
  :keywords
  '("files")
  :url "https://codeberg.org/hjudt/dired-duplicates")
;; Local Variables:
;; no-byte-compile: t
;; End:
