;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260415.2031"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "3c40e8a1dd7b20c6db90874b7b3088089a48acdc"
  :revdesc "3c40e8a1dd7b"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
