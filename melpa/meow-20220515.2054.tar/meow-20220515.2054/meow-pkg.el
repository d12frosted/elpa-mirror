(define-package "meow" "20220515.2054" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "b6db7f35d4a664e1e175318e96982fa3688f8264" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
