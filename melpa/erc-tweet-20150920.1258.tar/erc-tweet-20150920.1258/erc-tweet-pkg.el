;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-tweet" "20150920.1258"
  "Shows text of a tweet when an url is posted in erc buffers."
  ()
  :url "https://github.com/kidd/erc-tweet.el"
  :commit "91fed61e139fa788d66a7358f0d50acc896414b8"
  :revdesc "91fed61e139f"
  :keywords '("extensions")
  :authors '(("Raimon Grau" . "raimonster@gmail.com"))
  :maintainers '(("Raimon Grau" . "raimonster@gmail.com")))
