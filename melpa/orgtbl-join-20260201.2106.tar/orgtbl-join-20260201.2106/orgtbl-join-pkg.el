;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260201.2106"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "0dc5719fbc861350d09b5e1556612dccccd7b006"
  :revdesc "0dc5719fbc86"
  :keywords '("data" "extensions"))
