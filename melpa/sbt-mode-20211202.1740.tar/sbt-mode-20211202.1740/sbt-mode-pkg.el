(define-package "sbt-mode" "20211202.1740" "Interactive support for sbt projects"
  '((emacs "24.4"))
  :commit "ec1f6091344ee525f8f383faee6966ee96d7a601" :keywords
  '("languages")
  :url "https://github.com/hvesalai/emacs-sbt-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
