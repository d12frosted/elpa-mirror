(define-package "nushell-mode" "20230612.726" "Major mode for Nushell scripts"
  '((emacs "24.4"))
  :commit "ff8f8013af3076c041bd5235a54776890f4c4d0e" :authors
  '(("Azzam S.A" . "vcs@azzamsa.com"))
  :maintainers
  '(("Azzam S.A" . "vcs@azzamsa.com"))
  :maintainer
  '("Azzam S.A" . "vcs@azzamsa.com")
  :keywords
  '("languages" "unix")
  :url "https://github.com/mrkkrp/nushell-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
