(define-package "workroom" "20221120.1533" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0"))
  :commit "4e746fcd34c9d269d49a100d3729d13f88b1b858" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
