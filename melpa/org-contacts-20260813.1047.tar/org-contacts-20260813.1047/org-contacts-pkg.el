;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "20260813.1047"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "791a9daff267083df2dce76f33e0027f516c64d8"
  :revdesc "791a9daff267"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
