(define-package "org-node" "20240920.1646" "Link org-id entries into a network"
  '((emacs "28.1")
    (compat "30")
    (llama "0"))
  :commit "d6ed8e3a3d3b6086fe79c51d09cbff5a27360c2a" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node")
;; Local Variables:
;; no-byte-compile: t
;; End:
