(define-package "telega" "20210709.2036" "Telegram client (unofficial)"
  '((emacs "26.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "08946c8de0e814b6f54d79ce9634948c60484082" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
