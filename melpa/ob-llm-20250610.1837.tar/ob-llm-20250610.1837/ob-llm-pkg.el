;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-llm" "20250610.1837"
  "Use `llm' as an Org Babel language."
  '((emacs "27.1"))
  :url "https://github.com/sunflowerseastar/ob-llm"
  :commit "edd3f6f71cc87732469087549087c09ffdc3fd9f"
  :revdesc "edd3f6f71cc8"
  :keywords '("llm" "org-mode" "tools" "convenience" "org" "babel")
  :authors '(("Grant Surlyn" . "grant@sunflowerseastar.com"))
  :maintainers '(("Grant Surlyn" . "grant@sunflowerseastar.com")))
