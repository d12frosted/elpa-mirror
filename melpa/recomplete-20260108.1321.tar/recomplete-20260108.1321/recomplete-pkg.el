;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recomplete" "20260108.1321"
  "Immediately (re)complete actions."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-recomplete"
  :commit "d580e7f0bdf885d3cc5948197ff6e1f4785aa712"
  :revdesc "d580e7f0bdf8"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
