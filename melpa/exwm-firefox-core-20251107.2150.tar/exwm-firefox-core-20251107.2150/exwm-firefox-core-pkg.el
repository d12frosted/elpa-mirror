;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-firefox-core" "20251107.2150"
  "Firefox hotkeys to functions."
  '((emacs "24.4")
    (exwm  "0.16"))
  :url "https://github.com/walseb/exwm-firefox-core"
  :commit "d8e599b7584f5570f3e50e111248d1d857cd5641"
  :revdesc "d8e599b7584f"
  :keywords '("extensions")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
