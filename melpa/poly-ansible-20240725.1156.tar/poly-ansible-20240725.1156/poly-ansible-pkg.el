(define-package "poly-ansible" "20240725.1156" "Polymode for Ansible: Jinja2 in YAML"
  '((ansible "0.4.1")
    (ansible-doc "0.4")
    (emacs "24.1")
    (jinja2-mode "0.2")
    (polymode "0.2")
    (systemd "1.4")
    (yaml-mode "0.0.13"))
  :commit "f1d92e75e2dcdf68794668b7f2e75ea5665f12fc" :authors
  '(("Peter Oliver" . "poly-ansible@mavit.org.uk"))
  :maintainers
  '(("Peter Oliver" . "poly-ansible@mavit.org.uk"))
  :maintainer
  '("Peter Oliver" . "poly-ansible@mavit.org.uk")
  :keywords
  '("languages")
  :url "https://gitlab.com/mavit/poly-ansible/")
;; Local Variables:
;; no-byte-compile: t
;; End:
