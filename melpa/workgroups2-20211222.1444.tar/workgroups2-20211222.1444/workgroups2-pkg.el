(define-package "workgroups2" "20211222.1444" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "925f8b90d6b0b1b3e45686e0bbfc7096d8485b44" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
