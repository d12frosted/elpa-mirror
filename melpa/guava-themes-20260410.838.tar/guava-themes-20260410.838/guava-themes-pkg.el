;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260410.838"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "384b4350270931f0fea2e625186a6408e7b47e71"
  :revdesc "384b43502709"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
