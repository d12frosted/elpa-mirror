;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251009.1007"
  "BLUE build system interface."
  '((emacs "30.1"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "264109e3f4875dea1b81b379791135b57cac3370"
  :revdesc "264109e3f487"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
