;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20250630.750"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "a9a0cdd941f97203a6fda22e3550e2f5238ab27e"
  :revdesc "a9a0cdd941f9"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
