;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cypher-ts-mode" "20260817.1627"
  "Cypher editing mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/nutcase/cypher-ts-mode"
  :commit "d8643a1bce1f71f42725cfea13d7cfe03215ffa6"
  :revdesc "d8643a1bce1f"
  :keywords '("languages" "files" "cypher" "graph" "database" "treesitter")
  :authors '(("Julian Flake" . "flake@uni-koblenz.de"))
  :maintainers '(("Julian Flake" . "flake@uni-koblenz.de")))
