;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-maxima" "20230529.1026"
  "Maxima company integration."
  '((emacs   "25.1")
    (maxima  "0.6.1")
    (seq     "2.20")
    (company "0.9.13"))
  :url "https://gitlab.com/sasanidas/maxima"
  :commit "b2bcf2e6997a5ab3502baba9143af44ac2cc2eb3"
  :revdesc "b2bcf2e6997a"
  :keywords '("languages" "tools" "convenience")
  :maintainers '(("Fermin Munoz" . "fmfs@posteo.net")))
