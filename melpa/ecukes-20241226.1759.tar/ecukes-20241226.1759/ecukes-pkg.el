;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ecukes" "20241226.1759"
  "Cucumber for Emacs."
  '((emacs     "25")
    (commander "0.6.1")
    (espuds    "0.2.2")
    (ansi      "0.3.0")
    (dash      "2.2.0")
    (s         "1.8.0")
    (f         "0.11.0"))
  :url "https://github.com/ecukes/ecukes"
  :commit "70cb0748b222b7c96ab9821ef898ffbdb45eacd8"
  :revdesc "70cb0748b222"
  :keywords '("test"))
