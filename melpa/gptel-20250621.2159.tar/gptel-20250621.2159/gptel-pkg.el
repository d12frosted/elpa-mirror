;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250621.2159"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "0ff882cf99924ef1949d882c50df928518373263"
  :revdesc "0ff882cf9992"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
