(define-package "sculpture-themes" "20210528.1749" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "21a16690693b003a9a0e7258b3f4177f52202074" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
