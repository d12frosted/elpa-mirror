(define-package "deno-ts-mode" "20230903.1505" "Major mode for Deno"
  '((emacs "29.1"))
  :commit "1f607c05f8b41d7e30a6b4f83aa1e53bc030354e" :authors
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainers
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainer
  '("Graham Marlow" . "info@mgmarlow.com")
  :keywords
  '("languages")
  :url "https://git.sr.ht/~mgmarlow/deno-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
