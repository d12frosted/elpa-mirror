;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251101.1029"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "3293e1363caf9ecdf26c408315dcabc8a0a0494b"
  :revdesc "3293e1363caf"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
