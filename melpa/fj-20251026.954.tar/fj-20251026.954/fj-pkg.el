;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20251026.954"
  "Client for forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.5")
    (transient "0.9.3")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "97bf77ee47933cffe0bfc8a7ee1d0546bec29372"
  :revdesc "97bf77ee4793"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
