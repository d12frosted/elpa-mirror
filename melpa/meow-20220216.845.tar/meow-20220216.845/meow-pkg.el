(define-package "meow" "20220216.845" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "df68729f6fd4afd280689a7771ec18028a51048d" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
