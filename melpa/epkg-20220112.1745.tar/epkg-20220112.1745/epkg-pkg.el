(define-package "epkg" "20220112.1745" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "9b3fded4c6904268fbdf84fb457aa195b2c90cba" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
