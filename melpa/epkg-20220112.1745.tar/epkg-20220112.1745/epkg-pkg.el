(define-package "epkg" "20220112.1745" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "cd1394f05b92985bfc6fddbfb0f1155e302d9e81" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
