;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250528.145"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "0f99806d11111f2e45822a692afcefd5af09d5d6"
  :revdesc "0f99806d1111"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
