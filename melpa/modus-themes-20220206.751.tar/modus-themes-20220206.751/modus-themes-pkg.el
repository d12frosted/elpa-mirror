(define-package "modus-themes" "20220206.751" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "6789e5790c8faec1cdac5036a5910d4644707eba" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
