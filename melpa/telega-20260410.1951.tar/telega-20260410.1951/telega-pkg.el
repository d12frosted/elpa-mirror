;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260410.1951"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "93b16e46c26fc81e1fb02b6c4c7ef7bbdd3dd5a2"
  :revdesc "93b16e46c26f"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
