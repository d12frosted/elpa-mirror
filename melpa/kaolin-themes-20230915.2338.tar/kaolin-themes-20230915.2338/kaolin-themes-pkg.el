(define-package "kaolin-themes" "20230915.2338" "A set of eye pleasing themes"
  '((emacs "25.1")
    (autothemer "0.2.2")
    (cl-lib "0.6"))
  :commit "e1c8590d83e3259d35b01892bedf7b68c5a6bb09" :authors
  '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers
  '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainer
  '("Ogden Webb" . "ogdenwebb@gmail.com")
  :keywords
  '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
