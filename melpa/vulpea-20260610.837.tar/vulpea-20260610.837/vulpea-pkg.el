;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260610.837"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "3c54580dc4216c0412aa111d383067bc6bee6251"
  :revdesc "3c54580dc421"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
