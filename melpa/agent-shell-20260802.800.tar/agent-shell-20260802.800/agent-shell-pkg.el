;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260802.800"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "586a9c4056f3d70860e8d8c4e78bfbeb458eb360"
  :revdesc "586a9c4056f3")
