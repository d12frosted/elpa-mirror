(define-package "dtache" "20220320.1338" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "e7d143df8a8f88cbbe0fa023cd1fc30219598d88" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
