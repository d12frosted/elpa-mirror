(define-package "eshell-prompt-extras" "20230810.1153" "Display extra information for your eshell prompt."
  '((emacs "25"))
  :commit "9e92db814e052d2e038764bd710278a9e8136fc8" :authors
  '(("zwild" . "judezhao@outlook.com"))
  :maintainers
  '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainer
  '("Chunyang Xu" . "mail@xuchunyang.me")
  :keywords
  '("eshell" "prompt")
  :url "https://github.com/zwild/eshell-prompt-extras")
;; Local Variables:
;; no-byte-compile: t
;; End:
