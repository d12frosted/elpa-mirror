;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250620.1256"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "9c3b7d3e99d07fc3f8ffd29239303592bc9a54d4"
  :revdesc "9c3b7d3e99d0"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
