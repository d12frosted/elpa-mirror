;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-git-toolbelt" "20260119.1930"
  "A Magit interface for git-toolbelt."
  '((emacs     "26.1")
    (magit     "3.0.0")
    (transient "0.3.0"))
  :url "https://github.com/jonathanchu/magit-git-toolbelt"
  :commit "e7e39cd616b61a8cb60ac2f375b77d117508230f"
  :revdesc "e7e39cd616b6"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
