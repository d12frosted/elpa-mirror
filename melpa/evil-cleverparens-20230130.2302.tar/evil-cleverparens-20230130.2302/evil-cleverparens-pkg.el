(define-package "evil-cleverparens" "20230130.2302" "Evil friendly minor-mode for editing lisp."
  '((evil "1.0")
    (paredit "1")
    (smartparens "1.6.1")
    (emacs "24.4")
    (dash "2.12.0"))
  :commit "345ee7715b4ce9952bea74038f3a3f63fea05eac" :authors
  '(("Olli Piepponen" . "opieppo@gmail.com"))
  :maintainer
  '("Olli Piepponen" . "opieppo@gmail.com")
  :keywords
  '("convenience" "emulations")
  :url "https://github.com/emacs-evil/evil-cleverparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
