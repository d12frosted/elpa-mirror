(define-package "asm-blox" "20221112.48" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "374d9703afd2976736abe6a73c4d4561a3238211" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
