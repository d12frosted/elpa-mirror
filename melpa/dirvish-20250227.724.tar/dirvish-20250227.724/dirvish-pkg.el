;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250227.724"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "8a2aafdc377453d8d5b92db6009a8ec4a131834d"
  :revdesc "8a2aafdc3774"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
