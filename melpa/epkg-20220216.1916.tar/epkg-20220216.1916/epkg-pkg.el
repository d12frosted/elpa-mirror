(define-package "epkg" "20220216.1916" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "a408955ae1bba04367ddeb84376396eb5fa3a2a9" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
