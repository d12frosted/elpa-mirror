(define-package "epkg" "20220216.1916" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "475bfb19e293edcdbeb23d30b2e4954ca7ab8f39" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
