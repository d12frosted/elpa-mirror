;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260829.842"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "78460349e86c96a6251a3c551119f3a4900c3ada"
  :revdesc "78460349e86c"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
