;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260928.106"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "dcb98d34485cfcbd4fb72ac91adb322675cbcca4"
  :revdesc "dcb98d34485c"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
