;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260618.13"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "474b57bc2b65ac92e200c351d91a322b308ea1bc"
  :revdesc "474b57bc2b65"
  :keywords '("extensions"))
