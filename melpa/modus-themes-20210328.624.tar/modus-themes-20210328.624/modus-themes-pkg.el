(define-package "modus-themes" "20210328.624" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "9c1414b6f095e1ae8a27a90d8962fcff9941bbe5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
