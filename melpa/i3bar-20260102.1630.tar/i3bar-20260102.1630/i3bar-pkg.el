;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "i3bar" "20260102.1630"
  "Display status from an i3status command in the tab bar."
  '((emacs "28.1"))
  :url "https://github.com/Stebalien/i3bar.el"
  :commit "111448dc2f84566c656c471eb05a8cb6cd946de1"
  :revdesc "111448dc2f84"
  :keywords '("unix")
  :authors '(("Steven Allen" . "steven@stebalien.com"))
  :maintainers '(("Steven Allen" . "steven@stebalien.com")))
