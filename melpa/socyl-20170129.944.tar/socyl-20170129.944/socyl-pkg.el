(define-package "socyl" "20170129.944" "Frontend for several search tools"
  '((s "1.11.0")
    (dash "2.12.0")
    (pkg-info "0.5.0")
    (cl-lib "0.5"))
  :commit "fcc0deda5b6c39d25e48e7da2a0ae73295193ea8" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("ripgrep" "sift" "ack" "pt" "ag" "grep" "search")
  :url "https://github.com/nlamirault/socyl")
;; Local Variables:
;; no-byte-compile: t
;; End:
