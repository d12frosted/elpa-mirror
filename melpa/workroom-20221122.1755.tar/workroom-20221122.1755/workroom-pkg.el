(define-package "workroom" "20221122.1755" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0")
    (compat "28.1.2.2"))
  :commit "f9d88f211ce5a302688839ea7dbd71e424b0bb28" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
