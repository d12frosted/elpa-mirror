;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gleam-ts-mode" "20260604.1354"
  "Major mode for Gleam."
  '((emacs "29.1"))
  :url "https://github.com/gleam-lang/gleam-mode"
  :commit "ae8aecda23e9dca755d80e86cdb7c336011c2321"
  :revdesc "ae8aecda23e9"
  :keywords '("languages" "gleam")
  :authors '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com")))
