;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-auto" "20260209.2010"
  "Automatically use tree-sitter enhanced major modes."
  '((emacs "29.0"))
  :url "https://github.com/renzmann/treesit-auto.git"
  :commit "398fcf2678301119aed3d6de78257ee0069986a2"
  :revdesc "398fcf267830"
  :keywords '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :authors '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers '(("Robb Enzmann" . "robbenzmann@gmail.com")))
