;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-solidity" "20220213.1910"
  "Org-babel functions for solidity evaluation."
  '((emacs         "24.4")
    (solidity-mode "0.1.10"))
  :url "https://github.com/hrkrshnn/ob-solidity"
  :commit "7e3e6cb2d7ec9269514e80248c7ec85c04dbbf89"
  :revdesc "7e3e6cb2d7ec"
  :keywords '("solidity" "literate programming" "reproducible research" "languages"))
