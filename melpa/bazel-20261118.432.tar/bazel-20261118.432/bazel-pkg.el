;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261118.432"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "dc0dad05a96b41b7d3506334d52b6da373b3c3b8"
  :revdesc "dc0dad05a96b"
  :keywords '("build tools" "languages"))
