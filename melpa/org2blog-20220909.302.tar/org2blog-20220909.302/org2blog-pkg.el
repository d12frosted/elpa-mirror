(define-package "org2blog" "20220909.302" "Blog from Org mode to WordPress"
  '((htmlize "1.56")
    (hydra "0.15.0")
    (xml-rpc "1.6.15")
    (writegood-mode "2.2.0")
    (metaweblog "1.1.14"))
  :commit "4df3158bfd78c4e601b9bd78bc15b1c7243be9fc" :authors
  '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainer
  '("Grant Rettke" . "grant@wisdomandwonder.com")
  :keywords
  '("comm" "convenience" "outlines" "wp")
  :url "https://github.com/org2blog/org2blog")
;; Local Variables:
;; no-byte-compile: t
;; End:
