(define-package "consult" "20210622.446" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "676d4970fcbb768d6f8c9c0f422aa32318378dd9" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
