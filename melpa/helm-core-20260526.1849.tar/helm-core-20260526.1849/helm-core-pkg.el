;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20260526.1849"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "3c70d12d713455ffaeec67808ded3c3e6daa7b86"
  :revdesc "3c70d12d7134"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
