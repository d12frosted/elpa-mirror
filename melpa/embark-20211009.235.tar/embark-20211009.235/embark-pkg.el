(define-package "embark" "20211009.235" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "0df853911db9744cb2211dd5b9374abb94201c38" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
