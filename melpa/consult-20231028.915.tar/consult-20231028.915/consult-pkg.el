(define-package "consult" "20231028.915" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "c81ef01d894eadf23f97b86711358480ae2e0f8a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
