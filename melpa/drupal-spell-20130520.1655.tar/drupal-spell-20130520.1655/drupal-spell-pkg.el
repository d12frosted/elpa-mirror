(define-package "drupal-spell" "20130520.1655" "Aspell extra dictionary for Drupal" 'nil :commit "4087c28c89a884ee050961c57166e6b09085f59d" :keywords
  ("wp")
  :authors
  (("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainer
  ("Arne Jørgensen" . "arne@arnested.dk")
  :url "https://github.com/arnested/drupal-spell")
;; Local Variables:
;; no-byte-compile: t
;; End:
