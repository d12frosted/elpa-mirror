(define-package "drupal-spell" "20130520.1655" "Aspell extra dictionary for Drupal" 'nil :commit "a69f5e3b62c4c0da74ce26c1d00d5b8f7395e4ae" :authors
  '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainer
  '("Arne Jørgensen" . "arne@arnested.dk")
  :keywords
  '("wp")
  :url "https://github.com/arnested/drupal-spell")
;; Local Variables:
;; no-byte-compile: t
;; End:
