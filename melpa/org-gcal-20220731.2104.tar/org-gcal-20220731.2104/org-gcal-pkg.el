(define-package "org-gcal" "20220731.2104" "Org sync with Google Calendar"
  '((request "20190901")
    (request-deferred "20181129")
    (alert "0")
    (persist "0")
    (emacs "26")
    (org "9.3"))
  :commit "229463ae02f9c0d8ddb510e611b2344ec9a17111" :authors
  '(("myuhe <yuhei.maeda_at_gmail.com>"))
  :maintainer
  '("Raimon Grau" . "raimonster@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/kidd/org-gcal.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
