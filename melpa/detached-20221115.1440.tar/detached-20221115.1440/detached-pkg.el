(define-package "detached" "20221115.1440" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "53161621ff32649cecf17a7038cac7942b01a328" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
