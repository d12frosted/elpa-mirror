(define-package "hl-indent-scope" "20220909.1029" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "64bb4ded1d47969455e79b3d4c1405879c2e705b" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
