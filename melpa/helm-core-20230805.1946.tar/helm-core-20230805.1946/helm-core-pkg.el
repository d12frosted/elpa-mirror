(define-package "helm-core" "20230805.1946" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "cc045f492ed07692987808f82b7c2bcfd59551e2" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
