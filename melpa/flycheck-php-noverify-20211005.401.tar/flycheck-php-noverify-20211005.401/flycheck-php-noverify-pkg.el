;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-php-noverify" "20211005.401"
  "Flycheck checker for PHP Noverify linter."
  '((flycheck "0.22"))
  :url "https://github.com/Junker/flycheck-php-noverify"
  :commit "3aa3035c637eb0476f05bd0fbc66c058aa67ffb7"
  :revdesc "3aa3035c637e")
