;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260418.249"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "7690b9569892bf5e5f87cae290cb6a861cd1deeb"
  :revdesc "7690b9569892"
  :keywords '("faces" "files" "q"))
