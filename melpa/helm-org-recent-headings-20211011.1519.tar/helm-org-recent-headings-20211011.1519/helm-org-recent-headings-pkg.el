;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-org-recent-headings" "20211011.1519"
  "Helm source for org-recent-headings."
  '((emacs               "26.1")
    (org                 "9.0.5")
    (dash                "2.18.0")
    (helm                "1.9.4")
    (org-recent-headings "0.2-pre")
    (s                   "1.12.0"))
  :url "https://github.com/alphapapa/org-recent-headings"
  :commit "97418d581ea030f0718794e50b005e9bae44582e"
  :revdesc "97418d581ea0"
  :keywords '("hypermedia" "outlines" "org")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
