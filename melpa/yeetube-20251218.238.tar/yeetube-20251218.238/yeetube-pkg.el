;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20251218.238"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs  "27.2")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "b69e36f63ef913c24eb32a249879011fb1174a3e"
  :revdesc "b69e36f63ef9"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
