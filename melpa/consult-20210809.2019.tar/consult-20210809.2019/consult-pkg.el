(define-package "consult" "20210809.2019" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7940c0732bee6846ecffbad2b1a245348d25125a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
