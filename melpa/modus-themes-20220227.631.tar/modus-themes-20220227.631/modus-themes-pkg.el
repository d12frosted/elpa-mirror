(define-package "modus-themes" "20220227.631" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "be3ab04e904c95b6803410875b0e4ea36bae9352" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
