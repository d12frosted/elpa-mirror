(define-package "ghub" "20240311.1319" "Client libraries for Git forge APIs."
  '((emacs "25.1")
    (compat "29.1.4.4")
    (let-alist "1.0.6")
    (treepy "0.1.2"))
  :commit "c9da8253ae0807ea517cf9ef2474d367745fc201" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
