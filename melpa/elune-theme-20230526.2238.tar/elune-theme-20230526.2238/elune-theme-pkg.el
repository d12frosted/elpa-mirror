(define-package "elune-theme" "20230526.2238" "Elune theme" 'nil :commit "e0f3f4def066e679cfdde3bbade4c83dcfc38cd8" :authors
  '(("Çağan Korkmaz" . "xcatalystt@gmail.com"))
  :maintainers
  '(("Çağan Korkmaz" . "xcatalystt@gmail.com"))
  :maintainer
  '("Çağan Korkmaz" . "xcatalystt@gmail.com")
  :url "https://github.com/xcatalyst/elune-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
