(define-package "apropospriate-theme" "20211111.1916" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "781fdb354dee083aa301cb4494996b3668125073")
;; Local Variables:
;; no-byte-compile: t
;; End:
