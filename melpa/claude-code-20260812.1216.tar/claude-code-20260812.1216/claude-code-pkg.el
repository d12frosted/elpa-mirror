;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code" "20260812.1216"
  "Run Claude Code sessions."
  '((emacs         "28.1")
    (projectile    "2.5.0")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (markdown-mode "2.5"))
  :url "https://github.com/yuya373/claude-code-emacs"
  :commit "ebc13e87c4c04e5df2c486c118570e1076fbc945"
  :revdesc "ebc13e87c4c0"
  :keywords '("tools" "convenience"))
