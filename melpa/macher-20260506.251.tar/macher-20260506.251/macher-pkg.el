;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20260506.251"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.3"))
  :url "https://github.com/kmontag/macher"
  :commit "55e75f2ee27eedc3cbf7e8bfcef27bcce11e3540"
  :revdesc "55e75f2ee27e"
  :keywords '("convenience" "gptel" "llm"))
