;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20260115.1052"
  "An Org-social client for Emacs."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "252aac839dea4d269497a20dc88fa3d7eb9aa3aa"
  :revdesc "252aac839dea"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
