(define-package "gptel" "20230323.243" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "42d53b25e5b36c08ed56c1b742aabc89587b8427" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
