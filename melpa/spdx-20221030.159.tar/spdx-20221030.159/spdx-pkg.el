(define-package "spdx" "20221030.159" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "fb9dd3b819be5244836f476bbb844142e6480a91" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
