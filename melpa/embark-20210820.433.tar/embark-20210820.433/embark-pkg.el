(define-package "embark" "20210820.433" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c4712a32c8acb398a85830ef12768b4951b4b6b4" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
