(define-package "empv" "20231117.812" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0"))
  :commit "46af2b87bf091fda5a88cf8a1f0d1e2a3c18c82f" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
