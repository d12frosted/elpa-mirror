(define-package "dirvish" "20220406.1205" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "9745ee85abc55ec24e66a867a19ef7fb0773076e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
