;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260823.1237"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "3cf51316db1dcef64a01399ec82499b742d911e9"
  :revdesc "3cf51316db1d"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
