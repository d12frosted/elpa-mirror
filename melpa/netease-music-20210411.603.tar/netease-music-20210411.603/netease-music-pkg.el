;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "netease-music" "20210411.603"
  "Listen netease music."
  '((names "0.5")
    (emacs "25"))
  :url "https://github.com/nicehiro/netease-music"
  :commit "db7f1eef2d8544983509db679be1cbe6a5678071"
  :revdesc "db7f1eef2d85"
  :keywords '("multimedia" "chinese" "music")
  :authors '(("hiro方圆" . "wfy11235813@gmail.com"))
  :maintainers '(("hiro方圆" . "wfy11235813@gmail.com")))
