(define-package "consult" "20220716.522" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "13164571bee929463e640ebdbe958995da91a57b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
