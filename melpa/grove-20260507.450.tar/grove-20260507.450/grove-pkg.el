;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "20260507.450"
  "Obsidian-like note-taking for org files."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "950e00c94b2a193a771dc2e680e80f30eb05bcc8"
  :revdesc "950e00c94b2a"
  :keywords '("notes" "outlines" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
