;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nael" "20260309.1253"
  "Major mode for Lean."
  '((emacs "29.1"))
  :url "https://codeberg.org/mekeor/nael"
  :commit "c1d349746731bbff6bf1887c51eb7a1f3bea5c4c"
  :revdesc "c1d349746731"
  :keywords '("languages")
  :authors '(("Adam Topaz" . "topaz@ualberta.ca")
             ("Akira Komamura" . "akira.komamura@gmail.com")
             ("Bao Zhiyuan" . "bzy_sustech@foxmail.com")
             ("Daniel Selsam" . "daniel.selsam@protonmail.com")
             ("Gabriel Ebner" . "gebner@gebner.org")
             ("Henrik Böving" . "hargonix@gmail.com")
             ("Hongyu Ouyang" . "oyhy0214@163.com")
             ("Jakub Bartczuk" . "bartczukkuba@gmail.com")
             ("Leonardo de Moura" . "leonardo@microsoft.com")
             ("Mauricio Collares" . "mauricio@collares.org")
             ("Mekeor Melire" . "mekeor@posteo.de")
             ("Philip Kaludercic" . "philipk@posteo.net")
             ("Richard Copley" . "buster@buster.me.uk")
             ("Sebastian Ullrich" . "sebasti@nullri.ch")
             ("Siddharth Bhat" . "siddu.druid@gmail.com")
             ("Simon Hudon" . "simon.hudon@gmail.com")
             ("Soonho Kong" . "soonhok@cs.cmu.edu")
             ("Tomáš Skřivan" . "skrivantomas@seznam.cz")
             ("Wojciech Nawrocki" . "wjnawrocki@protonmail.com")
             ("Yael Dillies" . "yael.dillies@gmail.com")
             ("Yury G. Kudryashov" . "urkud@urkud.name"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
