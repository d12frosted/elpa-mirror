;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "20260313.2345"
  "Slack client."
  '((websocket "1.12")
    (request   "0.3.2")
    (circe     "2.11")
    (alert     "1.2")
    (emojify   "1.2.1")
    (emacs     "25.1")
    (dash      "2.19.1")
    (s         "1.13.1")
    (ts        "0.3"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "345b405cd0cc4e79c865ecbaafe5a407072c9224"
  :revdesc "345b405cd0cc"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
