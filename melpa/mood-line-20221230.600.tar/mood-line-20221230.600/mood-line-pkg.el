(define-package "mood-line" "20221230.600" "A minimal mode line inspired by doom-modeline"
  '((emacs "25.1"))
  :commit "e42ee24e236d470c930179b6af5f15d6a0aab9f8" :authors
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainer
  '("Jessie Hildebrandt <jessieh.net>")
  :keywords
  '("mode-line" "faces")
  :url "https://gitlab.com/jessieh/mood-line")
;; Local Variables:
;; no-byte-compile: t
;; End:
