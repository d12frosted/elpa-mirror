;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260117.910"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "4a54c3b6b74663864696c4755a7653af1c959337"
  :revdesc "4a54c3b6b746"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
