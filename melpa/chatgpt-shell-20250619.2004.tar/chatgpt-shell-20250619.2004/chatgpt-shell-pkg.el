;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250619.2004"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.77.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "4799ee03abbe02a8b3a3ff64cd4c8e2fefd1db5c"
  :revdesc "4799ee03abbe")
