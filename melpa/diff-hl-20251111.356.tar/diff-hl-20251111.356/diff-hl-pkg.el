;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20251111.356"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "bdbdbbf87f64719d94b99489a65d9c9f7d296251"
  :revdesc "bdbdbbf87f64"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
