;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stock-tracker" "20250206.814"
  "Track stock price."
  '((emacs "27.1")
    (dash  "2.16.0")
    (async "1.9.5"))
  :url "https://github.com/beacoder/stock-tracker"
  :commit "51963a654a1199ec23f0938c247b1411fee85c6f"
  :revdesc "51963a654a11"
  :keywords '("convenience" "stock" "finance")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
