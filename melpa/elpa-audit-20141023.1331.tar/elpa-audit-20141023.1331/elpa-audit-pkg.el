;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpa-audit" "20141023.1331"
  "Handy functions for inspecting and comparing package archives."
  ()
  :url "https://github.com/purcell/elpa-audit"
  :commit "1ca4e6073f8c4cbb41688b69d3b3feaa1a392efc"
  :revdesc "1ca4e6073f8c"
  :keywords '("maint")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
