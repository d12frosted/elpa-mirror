;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260901.1816"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "e8c23cc6ced6825e216644d05fa3a4fde038fea8"
  :revdesc "e8c23cc6ced6"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
