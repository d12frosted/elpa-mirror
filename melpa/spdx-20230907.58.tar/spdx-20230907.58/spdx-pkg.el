(define-package "spdx" "20230907.58" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "31f66d713767fbdc11f42bf6f132d1faa1bb2b3a" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
