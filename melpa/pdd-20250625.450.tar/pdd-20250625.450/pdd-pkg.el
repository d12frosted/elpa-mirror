;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250625.450"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "4ac51e14ad5abf775c3793a7d453606c1ae4f590"
  :revdesc "4ac51e14ad5a"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
