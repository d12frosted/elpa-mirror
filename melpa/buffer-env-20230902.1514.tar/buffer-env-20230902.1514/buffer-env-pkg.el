(define-package "buffer-env" "20230902.1514" "Buffer-local process environments"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "c7fac260f8f0b2dd29294286075d0b78f4383ae0" :authors
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainer
  '("Augusto Stoffel" . "arstoffel@gmail.com")
  :keywords
  '("processes" "tools")
  :url "https://github.com/astoff/buffer-env")
;; Local Variables:
;; no-byte-compile: t
;; End:
