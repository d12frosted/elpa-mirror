;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "caseformat" "20160115.1615"
  "Format based letter case converter."
  '((emacs  "24")
    (cl-lib "0.5")
    (dash   "2.12.1")
    (s      "1.10.0"))
  :url "https://github.com/HKey/caseformat"
  :commit "e4961889309408b3425da9b69c16ddfadd17a674"
  :revdesc "e49618893094"
  :keywords '("convenience")
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
