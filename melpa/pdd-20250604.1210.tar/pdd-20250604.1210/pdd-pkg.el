;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250604.1210"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "0ba4389132b617a38c3a2c0dd2ddd1be21140d9c"
  :revdesc "0ba4389132b6"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
