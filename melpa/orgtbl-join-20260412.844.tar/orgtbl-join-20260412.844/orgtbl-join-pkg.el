;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260412.844"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "37883c21e85e71797538d154226e24666bc73047"
  :revdesc "37883c21e85e"
  :keywords '("data" "extensions"))
