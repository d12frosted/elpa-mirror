;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-score" "20260419.349"
  "Gnus-style scoring for Elfeed."
  '((emacs  "26.1")
    (elfeed "3.3.0"))
  :url "https://github.com/sp1ff/elfeed-score"
  :commit "f6d25f6c1c967822e75ff01ad4d57be1c80f480a"
  :revdesc "f6d25f6c1c96"
  :keywords '("news")
  :authors '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainers '(("Michael Herstine" . "sp1ff@pobox.com")))
