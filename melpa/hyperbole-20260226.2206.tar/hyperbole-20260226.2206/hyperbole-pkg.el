;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260226.2206"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "6ffe7e7ab0729eea5130b412efc5958b5c3576b8"
  :revdesc "6ffe7e7ab072"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
