(define-package "dirvish" "20220322.1044" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "2a6c18ae17c472f5200c0b7ed01e726e55ca663f" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
