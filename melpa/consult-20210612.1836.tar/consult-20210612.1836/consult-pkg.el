(define-package "consult" "20210612.1836" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "118793723a0b3dd999be21182512dcfd5d1ead2e" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
