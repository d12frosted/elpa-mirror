(define-package "embark" "20220413.2146" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "ab778510d5db9935a2d436b13d98c47b824172ee" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
