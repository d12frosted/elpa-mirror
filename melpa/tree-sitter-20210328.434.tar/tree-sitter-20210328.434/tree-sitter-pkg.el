(define-package "tree-sitter" "20210328.434" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.15.1"))
  :commit "c95731dea6171f5d09b15bb7a2d0cd789ee65e71" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
