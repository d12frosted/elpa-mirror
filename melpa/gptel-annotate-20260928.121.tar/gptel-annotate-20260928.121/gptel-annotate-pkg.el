;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-annotate" "20260928.121"
  "Annotate files or buffers with LLMs."
  '((emacs  "29.1")
    (compat "30.1.0.0")
    (gptel  "0.9.9.5"))
  :url "https://github.com/karthink/gptel-annotate"
  :commit "ec65d175b7a1b83fa6f256f5454b2e5f082b4841"
  :revdesc "ec65d175b7a1"
  :keywords '("comm")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
