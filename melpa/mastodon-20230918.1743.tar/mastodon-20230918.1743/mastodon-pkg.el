(define-package "mastodon" "20230918.1743" "Client for fediverse services using the Mastodon API"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4"))
  :commit "d260eeb57917e289800c198b97e5d54c3e241b28" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
