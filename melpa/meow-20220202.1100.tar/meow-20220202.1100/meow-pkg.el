(define-package "meow" "20220202.1100" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "845c4693ade5aa24715d3c0e4da678ca3fa98b51" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
