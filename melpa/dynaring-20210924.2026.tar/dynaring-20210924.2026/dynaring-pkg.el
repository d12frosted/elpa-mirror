(define-package "dynaring" "20210924.2026" "A dynamically sized ring structure"
  '((emacs "25.1"))
  :commit "76142cf100d9e611024638a761e62bd82af156cd" :authors
  '(("Mike Mattie" . "codermattie@gmail.com")
    ("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers
  '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainer
  '("Sid Kasivajhula" . "sid@countvajhula.com")
  :url "https://github.com/countvajhula/dynaring")
;; Local Variables:
;; no-byte-compile: t
;; End:
