;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "travis" "20150825.1138"
  "Emacs client for Travis."
  '((s        "1.9.0")
    (dash     "2.9.0")
    (pkg-info "0.5.0")
    (request  "0.1.0"))
  :url "https://github.com/nlamirault/emacs-travis"
  :commit "c8769d3db10ed4604969049e3bd276afa0a0138e"
  :revdesc "c8769d3db10e"
  :keywords '("travis")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
