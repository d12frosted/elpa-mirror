;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-techwriter" "20260101.1209"
  "Input methods for Russian technical writers."
  ()
  :url "https://github.com/dunmaksim/emacs-russian-techwriter-input-method"
  :commit "10a82cb6e92db1e7c5c86d024a74a718d8d17005"
  :revdesc "10a82cb6e92d"
  :keywords '("multilingual" "input method" "cyrillic" "i18n")
  :authors '(("Maxim Dunaevskii" . "dunmaksim@yandex.ru")))
