;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260227.1835"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.1.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "d60dba65d022118217b7730e6981530319037f1d"
  :revdesc "d60dba65d022"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
