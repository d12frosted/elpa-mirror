(define-package "magit-section" "20201221.2057" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "2fb44690b4de28ada77571b1a7acabbe7718fdbd" :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  ("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
