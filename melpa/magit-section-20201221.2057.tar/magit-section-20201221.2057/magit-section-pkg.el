(define-package "magit-section" "20201221.2057" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "3c4259e3e090d8575a6bcf80ad53a393bb16b05f" :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  ("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
