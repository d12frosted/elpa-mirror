;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260103.2047"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6303b9eec3cab66b4eba650d722c77b418a31388"
  :revdesc "6303b9eec3ca")
