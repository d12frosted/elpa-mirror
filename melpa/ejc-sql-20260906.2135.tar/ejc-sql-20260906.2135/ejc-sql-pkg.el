;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20260906.2135"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "26.3")
    (clomacs "0.0.5")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "77d0ab532767f0235002affd49c04cbea35b4e9f"
  :revdesc "77d0ab532767"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
