;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "20260901.1833"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "8019402d4a582a6b024baa2590575fea47a2fe70"
  :revdesc "8019402d4a58"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
