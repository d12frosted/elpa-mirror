(define-package "shell-command-x" "20230918.1955" "Extensions for shell commands"
  '((emacs "28.1"))
  :commit "5ad0a0270e22e6f89f2163e2dc65a0f39915793b" :authors
  '(("Eliza Velasquez"))
  :maintainers
  '(("Eliza Velasquez"))
  :maintainer
  '("Eliza Velasquez")
  :keywords
  '("convenience" "processes" "unix")
  :url "https://github.com/elizagamedev/shell-command-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
