;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordreference" "20260805.1233"
  "Interface for wordreference.com."
  '((emacs "28.1"))
  :url "https://codeberg.org/martianh/wordreference.el"
  :commit "b5bd5eab1e4981bae12d759da241d736cd0fa125"
  :revdesc "b5bd5eab1e49"
  :keywords '("convenience" "translate" "wp" "dictionary")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
