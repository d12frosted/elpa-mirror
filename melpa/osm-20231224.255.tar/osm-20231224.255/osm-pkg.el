(define-package "osm" "20231224.255" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "38aabf3a2c9a524b966eb83dc7aae723ec07365c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
