(define-package "helm-core" "20220821.1912" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "c9efe654a6362cbc4a2fdcc5fdcad94a967dd371" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
