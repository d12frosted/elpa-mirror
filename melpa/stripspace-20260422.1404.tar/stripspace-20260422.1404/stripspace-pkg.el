;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260422.1404"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "5dd864613dc2743d0970684de7c8c01a431f1ffa"
  :revdesc "5dd864613dc2"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
