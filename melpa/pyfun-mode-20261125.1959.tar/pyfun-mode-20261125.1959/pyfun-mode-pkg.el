;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyfun-mode" "20261125.1959"
  "Major mode for the Pyfun language."
  '((emacs "29.1"))
  :url "https://github.com/simontreanor/Pyfun"
  :commit "bea887edfd87c11c2f59321b4010b0bd02600fab"
  :revdesc "bea887edfd87"
  :keywords '("languages")
  :authors '(("Simon Treanor" . "https://github.com/simontreanor"))
  :maintainers '(("Simon Treanor" . "https://github.com/simontreanor")))
