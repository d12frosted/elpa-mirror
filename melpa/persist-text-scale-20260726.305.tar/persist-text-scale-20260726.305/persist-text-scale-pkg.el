;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20260726.305"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "e001e355f14fd662179d4b7fce275909ff7d2a9c"
  :revdesc "e001e355f14f"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
