(define-package "moom" "20220902.1121" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "f82260600adfd87c013b0ad8399343641e143930" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
