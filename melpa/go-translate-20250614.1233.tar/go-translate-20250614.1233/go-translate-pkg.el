;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250614.1233"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "11f18582140679a895dec48023664b4292366762"
  :revdesc "11f185821406"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
