(define-package "dirvish" "20220223.1713" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "9bb39bef29a41162e00a563da4966b6a368e6b5f" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
