;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iplayer" "20240305.1633"
  "Browse and download BBC TV/radio shows."
  ()
  :url "https://github.com/csrhodes/iplayer-el"
  :commit "62d3ca74e4f4d4f72f17e9075b06d0ba561ae5df"
  :revdesc "62d3ca74e4f4"
  :keywords '("multimedia" "bbc")
  :authors '(("Christophe Rhodes" . "csr21@cantab.net"))
  :maintainers '(("Christophe Rhodes" . "csr21@cantab.net")))
