(define-package "spdx" "20230912.57" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "b1c5a94367dd7b145b6c4b832bd381d1a0b7e692" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
