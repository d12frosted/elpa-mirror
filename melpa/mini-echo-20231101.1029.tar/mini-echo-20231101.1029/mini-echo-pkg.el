(define-package "mini-echo" "20231101.1029" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "56871a564140b493d678627399942821d045a71d" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
