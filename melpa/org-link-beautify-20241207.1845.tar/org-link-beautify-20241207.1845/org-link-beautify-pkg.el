;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20241207.1845"
  "Beautify Org Links."
  '((emacs      "29.1")
    (org        "9.7.14")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "8e9c782a8778c3bdbd58610584344030bac1b17f"
  :revdesc "8e9c782a8778"
  :keywords '("hypermedia"))
