(define-package "lambdapi-mode" "20220106.1308" "A major mode for editing Lambdapi source code"
  '((emacs "26.1")
    (eglot "1.5")
    (math-symbol-lists "1.2.1")
    (highlight "20190710.1527"))
  :commit "16644a4d9d0bcdd43c009c597dddb89f6a64a482" :maintainer
  '("Deducteam" . "dedukti-dev@inria.fr")
  :keywords
  '("languages")
  :url "https://github.com/Deducteam/lambdapi")
;; Local Variables:
;; no-byte-compile: t
;; End:
