;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews" "20250314.1759"
  "Hacker News Client for Emacs."
  ()
  :url "https://github.com/clarete/hackernews.el"
  :commit "1d3ba5faf47a3907e270ed5aa4099f73dadfdf6c"
  :revdesc "1d3ba5faf47a"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Lincoln de Sousa" . "lincoln@clarete.li"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
