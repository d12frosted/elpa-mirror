;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260813.957"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "102eaeaa44a11158ee5892f6b59230b64ae07d00"
  :revdesc "102eaeaa44a1"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
