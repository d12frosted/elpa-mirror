(define-package "brutalist-theme" "20231110.943" "Brutalist theme" 'nil :commit "0238406db380b733708e4ad7e5a75aeafe6a2640" :authors
  '(("Gergely Nagy"))
  :maintainers
  '(("Gergely Nagy"))
  :maintainer
  '("Gergely Nagy")
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
