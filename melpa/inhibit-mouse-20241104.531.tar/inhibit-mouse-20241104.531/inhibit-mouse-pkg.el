;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "20241104.531"
  "Deactivate mouse input during editing."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "204106ea994a253c3de1029fddaadd6bb2b5fd65"
  :revdesc "204106ea994a"
  :keywords '("convenience"))
