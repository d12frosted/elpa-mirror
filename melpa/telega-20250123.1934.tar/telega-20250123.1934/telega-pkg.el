;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250123.1934"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "5853e64c6c1b1c27272f30ab4911ddaeb8174d24"
  :revdesc "5853e64c6c1b"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
