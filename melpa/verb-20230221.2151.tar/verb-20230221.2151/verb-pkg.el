(define-package "verb" "20230221.2151" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "ba215b70fb09f35656d0791599be2d5abc3113d8" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
