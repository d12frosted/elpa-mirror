;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260309.1944"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "058e1b00e48af4ac687b61c741fc87e16bcf07cc"
  :revdesc "058e1b00e48a"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
