;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cc-cedict" "20241221.1256"
  "Interface to CC-CEDICT (a Chinese-English dictionary)."
  '((emacs "26.1"))
  :url "https://github.com/xuchunyang/cc-cedict.el"
  :commit "4b30010f98b34c7e1b3a3c327f9be0851ef83641"
  :revdesc "4b30010f98b3")
