;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anakondo" "20210221.1727"
  "Adds clj-kondo based Clojure[Script] editing facilities."
  '((emacs "26.3"))
  :url "https://github.com/didibus/anakondo"
  :commit "16b0ba14d94a5d7e55655efc9e1d6d069a9306f2"
  :revdesc "16b0ba14d94a"
  :keywords '("clojure" "clojurescript" "cljc" "clj-kondo" "completion" "languages" "tools")
  :authors '(("Didier A." . "didibus@users.noreply.github.com"))
  :maintainers '(("Didier A." . "didibus@users.noreply.github.com")))
