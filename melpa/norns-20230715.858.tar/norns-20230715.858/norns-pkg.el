(define-package "norns" "20230715.858" "Interactive development environment for monome norns"
  '((emacs "27.1")
    (dash "2.17.0")
    (s "1.12.0")
    (f "0.20.0")
    (request "0.3.2")
    (websocket "1.13"))
  :commit "1a342900d70b306578f6e1ab8daabc62a8a610fd" :keywords
  '("processes" "terminals")
  :url "https://github.com/p3r7/norns.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
