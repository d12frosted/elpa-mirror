;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260530.128"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "0bdf5d43c414b10e82ea65814644d8d09520cee4"
  :revdesc "0bdf5d43c414"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
