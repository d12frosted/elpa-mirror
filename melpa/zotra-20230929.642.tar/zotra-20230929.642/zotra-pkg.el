(define-package "zotra" "20230929.642" "Library to use Zotero translators"
  '((emacs "27.1"))
  :commit "04e27c2d5d0c28f51029e60f9cce45dfea1e086c" :authors
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainers
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainer
  '("Mohammad Pedramfar <https://github.com/mpedramfar>")
  :url "https://github.com/mpedramfar/zotra")
;; Local Variables:
;; no-byte-compile: t
;; End:
