(define-package "embark" "20211118.1645" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "6e064fcff8b65c94daae88a11894da4c70e01c73" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
