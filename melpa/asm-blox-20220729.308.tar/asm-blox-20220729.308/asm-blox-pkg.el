(define-package "asm-blox" "20220729.308" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "5c070c9ba9a09e8dbb4f34df0536b45f87dcbb94" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
