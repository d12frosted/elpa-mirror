;;; mustache-parse.el --- Mustache parse module

;; Copyright (C) 2013 Wilfred Hughes

;; Author: Wilfred Hughes <me@wilfred.me.uk>
;; URL: https://github.com/Wilfred/mustache.el

;; This file is part of mustache.el.

;; mustache.el is free software: you can redistribute it and/or modify it
;; under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; mustache.el is distributed in the hope that it will be useful, but
;; WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
;; General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with mustache.el.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Mustache parse module.

;;; Code:

(require 'cl-lib)
(require 's)

(defvar mst--remaining-lexemes nil
  "Since `mst--parse-inner' recursively calls itself, we need a shared value to mutate.")

(defun mst--parse (lexemes)
  "Given a list LEXEMES, return a list of lexemes nested according to #tags or ^tags."
  (setq mst--remaining-lexemes lexemes)
  (mst--parse-inner))

(defun mst--parse-inner (&optional section-name)
  "Parse `mst--remaining-lexemes', and return a list of lexemes nested according to #tags or ^tags."
  (let (parsed-lexemes
        lexeme)
    (cl-loop while mst--remaining-lexemes do
          (setq lexeme (pop mst--remaining-lexemes))
          (cond
           ((mst--open-section-p lexeme)
            ;; recurse on this nested section
            (push (cons lexeme (mst--parse-inner (mst--section-name lexeme))) parsed-lexemes))
           ((mst--close-section-p lexeme)
            ;; this is the last tag in this section
            (unless (equal section-name (mst--section-name lexeme))
              (error "Mismatched brackets: You closed a section with %s, but it wasn't open" section-name))
            (push lexeme parsed-lexemes)
            (cl-return))
           (t
            ;; this is just a tag in the current section
            (push lexeme parsed-lexemes))))

    ;; ensure we aren't inside an unclosed section
    (when (and section-name (not (mst--close-section-p lexeme)))
      (error "Unclosed section: You haven't closed %s" section-name))

    (nreverse parsed-lexemes)))

(defun mst--open-section-p (lexeme)
  "Is LEXEME a #tag or ^tag ?"
  (cl-destructuring-bind (type value) lexeme
    (and (equal type :tag)
         (or
          (s-starts-with-p "#" value)
          (s-starts-with-p "^" value)))))

(defun mst--close-section-p (lexeme)
  "Is LEXEME a /tag ?"
  (cl-destructuring-bind (type value) lexeme
    (and (equal type :tag)
         (s-starts-with-p "/" value))))

(defun mst--section-name (lexeme)
  "Get the name of the section from LEXEME, a two part list returned by `mst--lex'.
The leading character (the #, ^ or /) is stripped."
  (s-chop-prefixes '("#" "^" "/") (cadr lexeme)))

(provide 'mustache-parse)
;;; mustache-parse.el ends here
