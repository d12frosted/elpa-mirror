(define-package "mustache" "20210217.648" "a mustache templating library in emacs lisp"
  '((ht "0.9")
    (s "1.3.0")
    (dash "1.2.0"))
  :commit "0abcf474db6cec7b984491001981404f14908188" :authors
  '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainer
  '("Wilfred Hughes" . "me@wilfred.me.uk")
  :keywords
  '("convenience" "mustache" "template")
  :url "https://github.com/Wilfred/mustache.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
