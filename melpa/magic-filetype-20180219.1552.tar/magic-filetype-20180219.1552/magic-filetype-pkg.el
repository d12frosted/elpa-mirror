(define-package "magic-filetype" "20180219.1552" "Enhance filetype major mode"
  '((emacs "24")
    (s "1.9.0"))
  :commit "019494add5ff02dd36cb3f500142fc51125522cc" :authors
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("emulations" "vim" "ft" "file" "magic-mode")
  :url "https://github.com/zonuexe/magic-filetype.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
