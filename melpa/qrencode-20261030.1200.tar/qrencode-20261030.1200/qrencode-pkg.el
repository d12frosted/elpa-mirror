;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "20261030.1200"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "e46b52870556f08723feebe68d4cd16cdbfa2393"
  :revdesc "e46b52870556"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
