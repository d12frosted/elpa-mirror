;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-checkbashisms" "20230313.1418"
  "Checkbashisms checker for flycheck."
  '((emacs    "24")
    (flycheck "0.25"))
  :url "https://github.com/cuonglm/flycheck-checkbashisms"
  :commit "ca8f11679c77d6702f34e773bdde185ceb47a05d"
  :revdesc "ca8f11679c77"
  :keywords '("convenience" "tools" "sh" "unix")
  :authors '(("Cuong Le" . "cuong.manhle.vn@gmail.com"))
  :maintainers '(("Cuong Le" . "cuong.manhle.vn@gmail.com")))
