;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-eask" "20251231.1617"
  "Eask support in Flycheck."
  '((emacs    "27.1")
    (flycheck "0.14"))
  :url "https://github.com/flycheck/flycheck-eask"
  :commit "9141ad6b9ec2f2572a4dcddf54247825516c93b2"
  :revdesc "9141ad6b9ec2"
  :keywords '("lisp" "eask")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
