(define-package "fennel-mode" "20220309.445" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "c55eecd7c731a18c40be98684370c4c6903d243d" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
