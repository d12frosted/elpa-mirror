(define-package "org-web-tools" "20231220.1425" "Display and capture web content with Org-mode"
  '((emacs "27.1")
    (org "9.0")
    (compat "29.1.4.2")
    (dash "2.12")
    (esxml "0.3.4")
    (s "1.10.0")
    (plz "0.7.1")
    (request "0.3.0"))
  :commit "abc2c03cb99598fc51b12de8f80be322f5457c34" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("hypermedia" "outlines" "org" "web")
  :url "http://github.com/alphapapa/org-web-tools")
;; Local Variables:
;; no-byte-compile: t
;; End:
