(define-package "no-clown-fiesta-theme" "20230220.1019" "Not-so-colorful-theme"
  '((emacs "26.1")
    (autothemer "0.2"))
  :commit "e143cdfa7cecac6383328eca88586105f308bca9" :authors
  '(("ranmaru22"))
  :maintainers
  '(("ranmaru22"))
  :maintainer
  '("ranmaru22")
  :url "https://github.com/ranmaru22/no-clown-fiesta-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
