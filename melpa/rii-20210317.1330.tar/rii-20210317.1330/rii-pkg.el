;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rii" "20210317.1330"
  "Reversible input interface for multiple input."
  '((emacs "24.3"))
  :url "https://github.com/ROCKTAKEY/rii"
  :commit "9df603a5c63ae38ec776e27dc93d3618e2b0fabe"
  :revdesc "9df603a5c63a"
  :keywords '("extensions" "tools")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
