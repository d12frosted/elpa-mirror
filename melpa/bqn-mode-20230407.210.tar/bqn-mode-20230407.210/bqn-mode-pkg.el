(define-package "bqn-mode" "20230407.210" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "87677284ae6d01b716f00cb858c22587da2becd3" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
