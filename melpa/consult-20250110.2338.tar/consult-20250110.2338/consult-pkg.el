;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250110.2338"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "90a403e6610acaae61a0158b50e9778e857a18f8"
  :revdesc "90a403e6610a"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
