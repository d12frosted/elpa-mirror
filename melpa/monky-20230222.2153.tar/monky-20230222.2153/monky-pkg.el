;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monky" "20230222.2153"
  "Control Hg from Emacs."
  ()
  :url "https://github.com/ananthakumaran/monky"
  :commit "7046eee5fc9ac625924382cb4a82b0d8efcd9ff0"
  :revdesc "7046eee5fc9a"
  :keywords '("tools")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
