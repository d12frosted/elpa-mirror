(define-package "fountain-mode" "20231020.1037" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "acc772cef03465ec207695cedc408db512a3697f" :authors
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainers
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainer
  '("Paul W. Rankin" . "hello@paulwrankin.com")
  :keywords
  '("wp" "text")
  :url "https://github.com/rnkn/fountain-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
