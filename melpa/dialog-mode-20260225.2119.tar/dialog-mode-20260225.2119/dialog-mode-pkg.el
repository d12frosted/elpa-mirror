;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260225.2119"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "7cc200c954693a4a27c454df1facb172710f8686"
  :revdesc "7cc200c95469"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
