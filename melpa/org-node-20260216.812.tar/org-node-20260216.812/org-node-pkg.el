;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260216.812"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "7bde5508668c5ca9ea5dfd5bdc95d851483dc952"
  :revdesc "7bde5508668c"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
