;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251211.1001"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "5105919ee0a146e3746df54539294c464c0d065a"
  :revdesc "5105919ee0a1")
