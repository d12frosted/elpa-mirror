;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250423.1044"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "2da1315a2b64e9f4a49b8dd7f437da08bd99ff49"
  :revdesc "2da1315a2b64"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
