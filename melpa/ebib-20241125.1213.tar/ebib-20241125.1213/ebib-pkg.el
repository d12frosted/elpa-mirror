;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebib" "20241125.1213"
  "A BibTeX database manager."
  '((parsebib "6.0")
    (emacs    "27.1")
    (compat   "29.1.4.3"))
  :url "https://github.com/joostkremers/ebib"
  :commit "69e8c5ac955e99ab0bc369561985820494ed1c7f"
  :revdesc "69e8c5ac955e"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
