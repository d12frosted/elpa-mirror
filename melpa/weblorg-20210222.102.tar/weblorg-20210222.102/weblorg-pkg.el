(define-package "weblorg" "20210222.102" "Static Site Generator for org-mode"
  '((templatel "0.1.4")
    (emacs "26.1"))
  :commit "96aa798389536eee543ffeb0fa3c34dbd123c359" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
