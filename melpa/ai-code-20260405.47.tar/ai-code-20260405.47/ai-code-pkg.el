;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260405.47"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "ba8c11359a7fab121fcee756cd31361de046bd5d"
  :revdesc "ba8c11359a7f"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
