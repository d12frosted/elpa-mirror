;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "20260718.1704"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "2d525968b14820c806d09688e6d1448a98230a01"
  :revdesc "2d525968b148"
  :keywords '("wp" "convenience"))
