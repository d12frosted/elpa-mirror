(define-package "vs-dark-theme" "20231020.542" "Visual Studio IDE dark theme"
  '((emacs "24.1"))
  :commit "2ec99feff875e0e8a850cb423c798da0315f1bd1" :authors
  '(("Jen-Chieh Shen"))
  :maintainers
  '(("Jen-Chieh Shen"))
  :maintainer
  '("Jen-Chieh Shen")
  :url "https://github.com/emacs-vs/vs-dark-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
