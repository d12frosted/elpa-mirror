;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20260621.121"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "67972625ae052a5a07929043324fbd3b6b2fc08a"
  :revdesc "67972625ae05"
  :keywords '("convenience" "gptel" "llm"))
