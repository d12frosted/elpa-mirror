(define-package "conllu-mode" "20190203.1356" "editing mode for CoNLL-U files"
  '((emacs "25")
    (cl-lib "0.5")
    (flycheck "30")
    (hydra "0.13.0")
    (s "1.0"))
  :commit "d1b5b682e0a481ab74caed20bbca6177edb83080" :authors
  '(("bruno cuconato" . "bcclaro+emacs@gmail.com"))
  :maintainer
  '("bruno cuconato" . "bcclaro+emacs@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/odanoburu/conllu-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
