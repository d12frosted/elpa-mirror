(define-package "bqn-mode" "20230418.213" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "7c15e57a9a75a1d63fbf4c1a234b42568dcf2df0" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
