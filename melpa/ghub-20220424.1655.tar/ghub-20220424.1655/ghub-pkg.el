(define-package "ghub" "20220424.1655" "Client libraries for Git forge APIs."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (let-alist "1.0.6")
    (treepy "0.1.1"))
  :commit "b17ae4a3edbecc854564ea77d5aa4173f3a28ccb" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
