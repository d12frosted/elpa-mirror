/* SPDX-License-Identifier: GPL-3.0-or-later
 * fzf-additions.c — extensions to the upstream fzf scorer that aren't in
 * fzf.h, kept here so future syncs with upstream don't conflict.
 *
 *   fzf_has_match(text, pattern) -> bool
 *
 *     Returns true iff PATTERN matches TEXT, with no score computation.
 *     fzf's `fzf_get_score' returns 0 when the pattern doesn't match and a
 *     positive integer otherwise — so the caller can already use it as a
 *     boolean — but the scoring computation itself is O(text_len × pattern_len)
 *     for fuzzy-v2 (the default algorithm) plus a slab allocation per call.
 *     When the caller only needs the match decision (e.g. to build a filter
 *     set for refinement), fzf_has_match skips the DP table entirely:
 *
 *       fuzzy_v1 / fuzzy_v2  O(text_len + pattern_len)
 *       exact_match          O(text_len × pattern_len) worst case, O(n) avg
 *       prefix / suffix      O(pattern_len)
 *       equal                O(pattern_len)
 *
 *     The match decision is identical to fzf_get_score's; only the score
 *     and the position vector are skipped.  Pattern composition (AND across
 *     term-sets, OR within a term-set, `inv' negation) mirrors fzf's logic.
 */

#include "fzf-additions.h"
#include "fzf-private.h"
#include "fzf-simd-prefilter.h"

#include <ctype.h>
#include <string.h>

static inline char fzf_addn_lower(unsigned char c) {
  return (char)tolower(c);
}

static inline bool fzf_addn_space(unsigned char c) {
  return c == ' ' || (c >= '\t' && c <= '\r');
}

/* Fuzzy: the pattern's characters appear in TEXT in order.  Pattern is
   already case-normalized by fzf_parse_pattern when case_sensitive is
   false, so we only need to lowercase the text side. */
static bool fzf_addn_fuzzy(
    bool case_sensitive, const char *text, size_t tn,
    const fzf_string_t *pattern, const fzf_ascii_query_plan_t *plan) {
  const char *pat = pattern->data;
  size_t pn = pattern->size;
  if (pn == 0) return true;
  if (tn < pn) return false;
#if FZF_HAVE_SIMD_PREFILTER
  if (plan && plan->pattern_size == pn &&
      plan->case_sensitive == case_sensitive &&
      pn >= FZF_SIMD_FUZZY_MIN_PATTERN && tn >= FZF_SIMD_FUZZY_MIN_TEXT) {
    const char *first = fzf_ascii_plan_find_byte(
        text, tn, &plan->bytes[0], case_sensitive);
    return first && fzf_ascii_plan_ordered_after_first(
                        text, tn, plan, (size_t)(first - text));
  }
#else
  (void)plan;
#endif
  size_t pi = 0;
  if (case_sensitive) {
    for (size_t ti = 0; ti < tn && pi < pn; ti++)
      if (text[ti] == pat[pi]) pi++;
  } else {
    for (size_t ti = 0; ti < tn && pi < pn; ti++)
      if (fzf_addn_lower((unsigned char)text[ti]) == pat[pi]) pi++;
  }
  return pi == pn;
}

/* Exact: PATTERN appears as a contiguous substring of TEXT.  No memmem
   — not portable — so use a hand-rolled scan. */
static inline bool fzf_addn_word(unsigned char c) {
  return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
         (c >= '0' && c <= '9');
}

static bool fzf_addn_exact_impl(
    bool case_sensitive, bool boundary_check, const char *text, size_t tn,
    const fzf_string_t *pattern, const fzf_ascii_query_plan_t *plan) {
  const char *pat = pattern->data;
  size_t pn = pattern->size;
  if (pn == 0) return true;
  if (tn < pn) return false;
#if FZF_HAVE_SIMD_PREFILTER
  if (plan && plan->pattern_size == pn &&
      plan->case_sensitive == case_sensitive) {
    size_t from = 0;
    while (from <= tn - pn) {
      size_t position = fzf_ascii_plan_find_exact(text, tn, plan, from);
      if (position == SIZE_MAX) return false;
      if (!boundary_check ||
          ((position == 0 ||
            !fzf_addn_word((unsigned char)text[position - 1])) &&
           (position + pn == tn ||
            !fzf_addn_word((unsigned char)text[position + pn]))))
        return true;
      if (position == tn - pn) return false;
      from = position + 1;
    }
    return false;
  }
#else
  (void)plan;
#endif
  for (size_t i = 0; i + pn <= tn; i++) {
    bool eq = true;
    if (case_sensitive) {
      eq = (memcmp(text + i, pat, pn) == 0);
    } else {
      for (size_t j = 0; j < pn; j++)
        if (fzf_addn_lower((unsigned char)text[i + j]) != pat[j]) {
          eq = false; break;
        }
    }
    if (eq &&
        (!boundary_check ||
         ((i == 0 || !fzf_addn_word((unsigned char)text[i - 1])) &&
          (i + pn == tn ||
           !fzf_addn_word((unsigned char)text[i + pn])))))
      return true;
  }
  return false;
}

static bool fzf_addn_exact(
    bool case_sensitive, const char *text, size_t tn,
    const fzf_string_t *pattern, const fzf_ascii_query_plan_t *plan) {
  return fzf_addn_exact_impl(case_sensitive, false, text, tn, pattern, plan);
}

static bool fzf_addn_exact_boundary(
    bool case_sensitive, const char *text, size_t tn,
    const fzf_string_t *pattern, const fzf_ascii_query_plan_t *plan) {
  return fzf_addn_exact_impl(case_sensitive, true, text, tn, pattern, plan);
}

static bool fzf_addn_prefix(bool case_sensitive,
                            const char *text, size_t tn,
                            const char *pat,  size_t pn) {
  if (pn == 0) return true;
  size_t start = 0;
  /* fzf's anchored matchers ignore surrounding candidate whitespace unless
     the pattern itself anchors whitespace.  Keep the boolean fast path in
     lockstep with fzf_prefix_match. */
  if (!fzf_addn_space((unsigned char)pat[0]))
    while (start < tn && fzf_addn_space((unsigned char)text[start])) start++;
  if (tn - start < pn) return false;
  if (case_sensitive) return memcmp(text + start, pat, pn) == 0;
  for (size_t i = 0; i < pn; i++)
    if (fzf_addn_lower((unsigned char)text[start + i]) != pat[i]) return false;
  return true;
}

static bool fzf_addn_suffix(bool case_sensitive,
                            const char *text, size_t tn,
                            const char *pat,  size_t pn) {
  if (pn == 0) return true;
  size_t end = tn;
  if (!fzf_addn_space((unsigned char)pat[pn - 1]))
    while (end > 0 && fzf_addn_space((unsigned char)text[end - 1])) end--;
  if (end < pn) return false;
  const char *tail = text + (end - pn);
  if (case_sensitive) return memcmp(tail, pat, pn) == 0;
  for (size_t i = 0; i < pn; i++)
    if (fzf_addn_lower((unsigned char)tail[i]) != pat[i]) return false;
  return true;
}

static bool fzf_addn_equal(bool case_sensitive,
                           const char *text, size_t tn,
                           const char *pat,  size_t pn) {
  if (pn == 0) return false;
  size_t start = 0;
  size_t end = tn;
  if (!fzf_addn_space((unsigned char)pat[0]))
    while (start < end && fzf_addn_space((unsigned char)text[start])) start++;
  if (!fzf_addn_space((unsigned char)pat[pn - 1]))
    while (end > start && fzf_addn_space((unsigned char)text[end - 1])) end--;
  if (end - start != pn) return false;
  if (case_sensitive) return memcmp(text + start, pat, pn) == 0;
  for (size_t i = 0; i < pn; i++)
    if (fzf_addn_lower((unsigned char)text[start + i]) != pat[i]) return false;
  return true;
}

/* Dispatch one term to the right cheap match implementation.  Uses
   function-pointer identity to identify the algorithm — same trick the
   upstream fzf evaluator uses, so dispatch stays in lockstep without
   shipping a parallel enum.

   IMPORTANT: the matched-against pattern lives in `term->text`
   (a `fzf_string_t *`), not `term->ptr`.  `ptr` retains the original
   input including prefix tokens (`!`, `'`, `^`, trailing `$`); after
   fzf_parse_pattern strips those, only `text->data`/`text->size` reflect
   the actual bytes to compare against. */
static bool fzf_addn_term(const fzf_term_t *term,
                          const char *text, size_t tn) {
  fzf_string_t *pat = (fzf_string_t *)term->text;
  const char *p     = pat ? pat->data : "";
  size_t      pn    = pat ? pat->size : 0;
  bool match;
  if (term->fn == fzf_fuzzy_match_v1 || term->fn == fzf_fuzzy_match_v2) {
    const fzf_ascii_query_plan_t *plan = NULL;
    if (pn >= FZF_SIMD_FUZZY_MIN_PATTERN &&
        pn <= FZF_SIMD_MAX_PATTERN && tn >= FZF_SIMD_FUZZY_MIN_TEXT &&
        fzf_get_simd_prefilter_allowed())
      plan = fzf_ascii_query_plan_from_parsed(pat);
    match = fzf_addn_fuzzy(term->case_sensitive, text, tn, pat, plan);
  } else if (term->fn == fzf_exact_match_naive) {
    if (term->case_sensitive && tn >= pn && memcmp(text, p, pn) == 0) {
      match = true;
    } else {
      const fzf_ascii_query_plan_t *plan = NULL;
      if (pn >= 2 && pn <= FZF_SIMD_MAX_PATTERN && tn >= pn &&
          tn - pn + 1 >= FZF_SIMD_LITERAL_MIN_STARTS &&
          fzf_get_simd_prefilter_allowed())
        plan = fzf_ascii_query_plan_from_parsed(pat);
      match = fzf_addn_exact(term->case_sensitive, text, tn, pat, plan);
    }
  } else if (term->fn == fzf_exact_match_boundary) {
    if (term->case_sensitive && tn >= pn && memcmp(text, p, pn) == 0 &&
        (pn == tn || !fzf_addn_word((unsigned char)text[pn]))) {
      match = true;
    } else {
      const fzf_ascii_query_plan_t *plan = NULL;
      if (pn >= 2 && pn <= FZF_SIMD_MAX_PATTERN && tn >= pn &&
          tn - pn + 1 >= FZF_SIMD_LITERAL_MIN_STARTS &&
          fzf_get_simd_prefilter_allowed())
        plan = fzf_ascii_query_plan_from_parsed(pat);
      match = fzf_addn_exact_boundary(
          term->case_sensitive, text, tn, pat, plan);
    }
  } else if (term->fn == fzf_prefix_match)
    match = fzf_addn_prefix(term->case_sensitive, text, tn, p, pn);
  else if (term->fn == fzf_suffix_match)
    match = fzf_addn_suffix(term->case_sensitive, text, tn, p, pn);
  else if (term->fn == fzf_equal_match)
    match = fzf_addn_equal (term->case_sensitive, text, tn, p, pn);
  else
    /* Unknown algorithm — fall back to "no match" rather than guess. */
    match = false;
  return term->inv ? !match : match;
}

/* True when FN is one of the ASCII-only algorithm variants that
   fzf_addn_term evaluates cheaply.  fzf_parse_pattern assigns the `_utf8'
   variants for any term containing non-ASCII bytes; those (and any future
   algorithm) are not byte-wise matchable here and must go through the full
   scorer instead. */
static bool fzf_addn_is_ascii_algo(fzf_algo_t fn) {
  return fn == fzf_fuzzy_match_v1 || fn == fzf_fuzzy_match_v2 ||
         fn == fzf_exact_match_naive || fn == fzf_exact_match_boundary ||
         fn == fzf_prefix_match ||
         fn == fzf_suffix_match || fn == fzf_equal_match;
}

bool fzf_has_match_bytes_preclassified(
    const char *text, size_t tn, bool input_is_ascii,
    fzf_pattern_t *pattern, fzf_slab_t *slab) {
  fzf_clear_allocation_failure();
  if (!pattern || pattern->size == 0) return true;
  /* The cheap matchers below are byte-wise ASCII only (no Unicode case
     folding).  A non-ASCII candidate must therefore use the full scorer even
     when every query term is ASCII: Unicode lowercase mappings can cross that
     boundary (for example U+212A KELVIN SIGN -> ASCII k).  Likewise, defer if
     any term requests normalization, uses a `_utf8' variant, or selects an
     unrecognized algorithm.  The full scorer is authoritative for Unicode
     case folding, normalization, and `inv' negation. */
  if (!input_is_ascii)
    return fzf_get_score_bytes_preclassified(
               text, tn, false, pattern, slab) > 0;
  for (size_t i = 0; i < pattern->size; i++) {
    fzf_term_set_t *set = pattern->ptr[i];
    for (size_t j = 0; j < set->size; j++)
      if (set->ptr[j].normalize ||
          !fzf_addn_is_ascii_algo(set->ptr[j].fn))
        return fzf_get_score_bytes_preclassified(
                   text, tn, input_is_ascii, pattern, slab) > 0;
  }
  /* AND across term-sets, OR within each term-set — same composition as
     fzf_get_score, just collapsed to bool. */
  for (size_t i = 0; i < pattern->size; i++) {
    fzf_term_set_t *set = pattern->ptr[i];
    bool any = false;
    for (size_t j = 0; j < set->size; j++) {
      if (fzf_addn_term(&set->ptr[j], text, tn)) { any = true; break; }
    }
    if (!any) return false;
  }
  return true;
}

bool fzf_has_match_bytes(const char *text, size_t text_len,
                         fzf_pattern_t *pattern, fzf_slab_t *slab) {
  if (!pattern || pattern->size == 0) {
    fzf_clear_allocation_failure();
    return true;
  }
  return fzf_has_match_bytes_preclassified(
      text, text_len, is_ascii_utf8proc(text, text_len), pattern, slab);
}

bool fzf_has_match(const char *text, fzf_pattern_t *pattern, fzf_slab_t *slab) {
  if (!pattern || pattern->size == 0) {
    fzf_clear_allocation_failure();
    return true;
  }
  size_t text_len = strlen(text);
  return fzf_has_match_bytes_preclassified(
      text, text_len, is_ascii_utf8proc(text, text_len), pattern, slab);
}
