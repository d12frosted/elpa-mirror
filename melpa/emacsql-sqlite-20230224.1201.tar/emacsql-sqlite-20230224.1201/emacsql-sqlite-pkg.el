(define-package "emacsql-sqlite" "20230224.1201" "EmacSQL back-end for SQLite"
  '((emacs "25.1")
    (emacsql "20230220"))
  :commit "7c533fb6c27c3a10b6ab05bddf663e37c109e459" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
