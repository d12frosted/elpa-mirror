(define-package "spdx" "20210413.2056" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "61493057eaed155fd4559138aaa6291a708ed7c9" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
