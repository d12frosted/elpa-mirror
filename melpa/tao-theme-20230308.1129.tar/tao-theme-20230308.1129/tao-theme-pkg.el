(define-package "tao-theme" "20230308.1129" "This package provides two parametrized uncoloured color themes for Emacs: tao-yin and tao-yang." 'nil :commit "34442c5c133faf9f583948e58161e26d18d7d608" :authors
  '(("Peter Kosov" . "11111000000@email.com"))
  :maintainer
  '("Peter Kosov" . "11111000000@email.com")
  :url "http://github.com/11111000000/tao-theme-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
