(define-package "spdx" "20220427.140" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "37422ad4a1a691207a273bc6500cdd1da092a2d9" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
