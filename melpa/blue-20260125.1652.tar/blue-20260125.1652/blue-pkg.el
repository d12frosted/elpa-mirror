;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260125.1652"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "7dff262de973445c846e1223b5808240c8bf458d"
  :revdesc "7dff262de973"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
