;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260306.2117"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "4452fadcd4bff3b9435cf5a370bae220986564fa"
  :revdesc "4452fadcd4bf"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
