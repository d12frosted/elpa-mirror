(define-package "kaesar" "20230622.951" "AES algorithm encrypt/decrypt"
  '((emacs "24.3")
    (kaesar-pbkdf2 "0.9.0"))
  :commit "26035fef9796b5856d90bcc965240ec3eac4414b" :authors
  '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers
  '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainer
  '("Masahiro Hayashi" . "mhayashi1120@gmail.com")
  :keywords
  '("data")
  :url "https://github.com/mhayashi1120/Emacs-kaesar")
;; Local Variables:
;; no-byte-compile: t
;; End:
