;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251219.2252"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "5a23d9bc762258210b4df42716e15955cd525cbc"
  :revdesc "5a23d9bc7622")
