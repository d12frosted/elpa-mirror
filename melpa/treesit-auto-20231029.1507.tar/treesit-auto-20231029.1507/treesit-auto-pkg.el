(define-package "treesit-auto" "20231029.1507" "Automatically use tree-sitter enhanced major modes"
  '((emacs "29.0"))
  :commit "f5ed138a4179058bf436f18953ed6dc493d9a124" :authors
  '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers
  '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainer
  '("Robb Enzmann" . "robbenzmann@gmail.com")
  :keywords
  '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :url "https://github.com/renzmann/treesit-auto.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
