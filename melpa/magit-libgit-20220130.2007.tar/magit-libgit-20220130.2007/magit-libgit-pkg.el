(define-package "magit-libgit" "20220130.2007" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "036f5cb77576dd0fd141210ec02918893b482da5" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
