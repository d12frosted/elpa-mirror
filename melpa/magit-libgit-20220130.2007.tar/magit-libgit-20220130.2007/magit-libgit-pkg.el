(define-package "magit-libgit" "20220130.2007" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "ca7504a12d0e899d7a82f3b0cbe2598d8d376fb8" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
