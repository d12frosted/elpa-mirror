(define-package "magit-libgit" "20220130.2007" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "68be0584f464b6aa2a7d026339835ee70f472e92" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
