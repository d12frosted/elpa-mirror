;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260602.822"
  "MCP server for Org-mode."
  '((emacs          "27.1")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "559bd877c08d9d127f1bf75ea164f77827dad3d4"
  :revdesc "559bd877c08d"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
