;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260402.405"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "8b8f43dcdc3d5e6935fc9754764cc059e11fc0df"
  :revdesc "8b8f43dcdc3d"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
