;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250524.2054"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "e4f5de43aa6cc24d2d8d41d25ec5d63b795d8cbf"
  :revdesc "e4f5de43aa6c"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
