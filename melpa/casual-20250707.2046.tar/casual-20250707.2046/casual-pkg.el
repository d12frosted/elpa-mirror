;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20250707.2046"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/casual"
  :commit "c7866a70b3e0689d58990b6903abaca2891e195c"
  :revdesc "c7866a70b3e0"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
