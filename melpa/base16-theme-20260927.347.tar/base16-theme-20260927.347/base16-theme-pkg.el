;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260927.347"
  "A set of base16 themes for your favorite editor."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "81f77672e7b07fefa7aca90d334c31abd0cf0ff1"
  :revdesc "81f77672e7b0"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
