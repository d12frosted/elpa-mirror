;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260519.831"
  "Lets your agent talk to Emacs."
  '((emacs       "30.1")
    (http-server "0.1.0")
    (elisp-refs  "1.6"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "c65c3c248d52f421531f4b37953be290c1df5ceb"
  :revdesc "c65c3c248d52"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
