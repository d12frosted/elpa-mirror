(define-package "stimmung-themes" "20210328.1411" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "f354fbde72d4e765fec9266c9d46146c728b28a0" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
