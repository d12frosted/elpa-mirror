;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260524.1405"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2b2407865e29d561d4f574a4c58708eded57ca95"
  :revdesc "2b2407865e29")
