;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "olivetti" "20241030.136"
  "Minor mode to automatically balance window margins."
  '((emacs "24.4"))
  :url "https://github.com/rnkn/olivetti"
  :commit "e2a07f1e5e4713f0a3a551f135f596b60724befe"
  :revdesc "e2a07f1e5e47"
  :keywords '("wp" "text")
  :authors '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainers '(("Paul W. Rankin" . "rnkn@rnkn.xyz")))
