(define-package "proof-general" "20220714.1137" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "945ce172b9931e2539e839945ab121117bbe40e8" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
