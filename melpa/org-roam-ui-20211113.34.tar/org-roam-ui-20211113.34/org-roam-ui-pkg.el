(define-package "org-roam-ui" "20211113.34" "User Interface for Org-roam"
  '((emacs "27.1")
    (org-roam "2.0.0")
    (simple-httpd "20191103.1446")
    (websocket "1.13"))
  :commit "57a9bb1eda6dcd2954ad98872bb342a649318899" :authors
  '(("Kirill Rogovoy, Thomas Jorna"))
  :maintainer
  '("Kirill Rogovoy, Thomas Jorna")
  :keywords
  '("files" "outlines")
  :url "https://github.com/org-roam/org-roam-ui")
;; Local Variables:
;; no-byte-compile: t
;; End:
