;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "procress" "20260129.1256"
  "Process progress."
  '((emacs  "27.1")
    (auctex "13.0"))
  :url "https://github.com/haji-ali/procress.git"
  :commit "de0c3b40a7f5d66d71529784e0a35069a064e27d"
  :revdesc "de0c3b40a7f5"
  :keywords '("compile" "progress" "tex" "svg")
  :authors '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")))
