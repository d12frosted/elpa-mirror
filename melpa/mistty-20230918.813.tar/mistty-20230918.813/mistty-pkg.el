(define-package "mistty" "20230918.813" "Shell/Comint alternative based on term.el"
  '((emacs "29.1")
    (iter2 "1.4"))
  :commit "513075f2c85005efd50acaee52436e2d7a5145d7" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
