;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20260517.149"
  "Nucleo-backed completion style."
  '((emacs "27.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "0cccfa2fdaa61850f255fd16b6f8750fa415c1b1"
  :revdesc "0cccfa2fdaa6"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
