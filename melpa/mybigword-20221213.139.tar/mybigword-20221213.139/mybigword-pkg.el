(define-package "mybigword" "20221213.139" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "26.1")
    (avy "0.5.0"))
  :commit "d2d806027ee8dc6ccac26d21c8c37e661dc71392" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
