(define-package "apdl-mode" "20210912.1107" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "8bb83dac1d8623b8495e6b6de0f3164e90591f85" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
