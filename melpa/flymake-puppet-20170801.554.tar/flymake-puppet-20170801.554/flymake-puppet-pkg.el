;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-puppet" "20170801.554"
  "Flymake handler using puppet-lint."
  '((flymake-easy "0.9"))
  :url "https://github.com/benprew/flymake-puppet"
  :commit "9579e5c736cb890195464fabf51df113313de88d"
  :revdesc "9579e5c736cb")
