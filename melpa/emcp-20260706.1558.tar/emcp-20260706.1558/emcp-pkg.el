;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260706.1558"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "cc452a2cb8b128305c7091a4adf9435e6b227fc1"
  :revdesc "cc452a2cb8b1"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
