(define-package "fountain-mode" "20211006.249" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "f6634058f9c65f6176483efd966f8463467ddb3c" :authors
  '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainer
  '("Paul W. Rankin" . "pwr@bydasein.com")
  :keywords
  '("wp" "text")
  :url "https://github.com/rnkn/fountain-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
