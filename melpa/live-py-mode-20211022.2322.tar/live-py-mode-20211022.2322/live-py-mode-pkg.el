(define-package "live-py-mode" "20211022.2322" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "9563ad3d0883ebb04674fa1629aed63a30c6d3f6" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
