(define-package "forge" "20210930.1703" "Access Git forges from Magit."
  '((emacs "25.1")
    (closql "20210927")
    (dash "2.18.1")
    (emacsql-sqlite "3.0.0")
    (ghub "3.5.2")
    (let-alist "1.0.6")
    (magit "3.0.0")
    (markdown-mode "2.4")
    (transient "0.3.3")
    (yaml "0.3.3"))
  :commit "6738256931b043a1ed36c31b8b6fd4dd962d8ec9" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
