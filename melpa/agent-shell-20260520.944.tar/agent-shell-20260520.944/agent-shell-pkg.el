;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260520.944"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "152fd8463616d1751cf7fbda3fdf11431c8123f8"
  :revdesc "152fd8463616")
