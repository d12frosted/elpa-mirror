;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-org" "20261020.1341"
  "Preview Org LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.24.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "f9022d77a35f56583110ded4bbb57a6357df9cc9"
  :revdesc "f9022d77a35f"
  :keywords '("tex" "org" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
