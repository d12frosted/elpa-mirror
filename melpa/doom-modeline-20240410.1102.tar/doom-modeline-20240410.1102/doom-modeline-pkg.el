(define-package "doom-modeline" "20240410.1102" "A minimal and modern mode-line"
  '((emacs "25.1")
    (compat "29.1.4.2")
    (nerd-icons "0.1.0")
    (shrink-path "0.3.1"))
  :commit "826d2916f1b93dc047a029e12ed252b68374c113" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
