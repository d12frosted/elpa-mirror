;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251105.745"
  "An Org-social client."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "7a1edb97f7cd1401cef3abb0bb0b2966a9484fe8"
  :revdesc "7a1edb97f7cd"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
