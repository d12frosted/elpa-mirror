;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260215.645"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "e5f2736eee9cac6d7505ce6148ee163fef607b28"
  :revdesc "e5f2736eee9c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
