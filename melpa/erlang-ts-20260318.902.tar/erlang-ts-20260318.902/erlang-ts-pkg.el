;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang-ts" "20260318.902"
  "Major modes for editing Erlang."
  '((emacs  "29.2")
    (erlang "27.2"))
  :url "https://github.com/erlang/emacs-erlang-ts"
  :commit "6538670e7aca2d11c7d98afaf38a4d37a9f1bbe1"
  :revdesc "6538670e7aca"
  :keywords '("erlang" "languages" "treesitter"))
