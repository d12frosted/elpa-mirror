;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260311.1512"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "def49d12e2eeefbbd29f5024932e3f04af9da7d9"
  :revdesc "def49d12e2ee"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
