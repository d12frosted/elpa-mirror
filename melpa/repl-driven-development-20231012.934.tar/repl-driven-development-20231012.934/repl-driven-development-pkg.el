(define-package "repl-driven-development" "20231012.934" "Send arbitrary code to a REPL in the background"
  '((s "1.12.0")
    (lf "1.0")
    (dash "2.16.0")
    (eros "0.1.0")
    (bind-key "2.4.1")
    (emacs "29")
    (f "0.20.0")
    (devdocs "0.5")
    (pulsar "1.0.1")
    (peg "1.0.1")
    (hierarchy "0.6.0")
    (json-navigator "0.1.1"))
  :commit "39a1032ad7d95db5277c6571b303cdc775fba93a" :authors
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainer
  '("Musa Al-hassy" . "alhassy@gmail.com")
  :keywords
  '("repl-driven-development" "rdd" "repl" "lisp" "java" "python" "ruby" "programming" "convenience")
  :url "http://alhassy.com/repl-driven-development")
;; Local Variables:
;; no-byte-compile: t
;; End:
