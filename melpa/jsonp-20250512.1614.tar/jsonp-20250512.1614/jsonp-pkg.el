;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsonp" "20250512.1614"
  "Resolve JSON pointers in ELisp objects."
  '((emacs "28.1"))
  :url "https://github.com/joshbax189/jsonp-el"
  :commit "b806443fde7b7981259bb9edf1fb0590d112b9ef"
  :revdesc "b806443fde7b"
  :keywords '("comm" "tools"))
