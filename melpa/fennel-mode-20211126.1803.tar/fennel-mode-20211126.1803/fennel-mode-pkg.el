(define-package "fennel-mode" "20211126.1803" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "a622c110a2ae6ababfaab0506647a7fbc81e623a" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://gitlab.com/technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
