(define-package "tree-sitter-langs" "20240414.713" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.15.0"))
  :commit "c8d5479f41224ab5df21660444be8cf3c9d24d7a" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainers
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/tree-sitter-langs")
;; Local Variables:
;; no-byte-compile: t
;; End:
