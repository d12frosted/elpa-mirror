;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260814.1041"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "24b0f2e9f535af305767f56a417532b8165eaea8"
  :revdesc "24b0f2e9f535"
  :keywords '("convenience" "chinese" "input-method" "rime"))
