;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20260617.643"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "a3a3b151687197906586464b8f9e812261673897"
  :revdesc "a3a3b1516871"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
