;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260423.1642"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "d33052d6f779e9b2c2c64b11e4b9c11c19f0e706"
  :revdesc "d33052d6f779"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
