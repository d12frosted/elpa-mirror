;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261123.554"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "cc42436a206796320a012253eee301de447566e0"
  :revdesc "cc42436a2067"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
