;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260116.1316"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "b1bb0da38ce14d31148abe9e733212747b0b5dc4"
  :revdesc "b1bb0da38ce1"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
