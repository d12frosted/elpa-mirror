(define-package "octicons" "20150801.1329" "octicons utility"
  '((cl-lib "0.5"))
  :commit "77bb1a49045f89b3eaf9bcffeefbb9e1abaee556" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-octicons")
;; Local Variables:
;; no-byte-compile: t
;; End:
