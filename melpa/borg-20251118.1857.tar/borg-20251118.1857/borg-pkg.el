;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20251118.1857"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.4"))
  :url "https://github.com/emacscollective/borg"
  :commit "b5ef66d76eaf5fbffb79753e6130d1afad60d608"
  :revdesc "b5ef66d76eaf"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
