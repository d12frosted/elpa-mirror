(define-package "chronometrist-key-values" "20210617.1707" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "524ba9592fc7095209e380392915b376f75bec00" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
