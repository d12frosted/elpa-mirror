(define-package "chronometrist-key-values" "20210617.1707" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "37afe58cd9b05d1968a422874774b3d7747ddc1e" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
