(define-package "chronometrist-key-values" "20210617.1707" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "ba9e8dfa9cba4385f9d88b72676c63ea14c11722" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
