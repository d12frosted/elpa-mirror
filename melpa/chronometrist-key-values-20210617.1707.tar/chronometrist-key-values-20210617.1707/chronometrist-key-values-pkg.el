(define-package "chronometrist-key-values" "20210617.1707" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "73e6d98612187aa64f4adacd26e058349cf131c6" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
