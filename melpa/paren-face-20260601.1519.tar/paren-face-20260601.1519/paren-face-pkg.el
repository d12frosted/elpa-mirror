;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paren-face" "20260601.1519"
  "A face for parentheses in lisp modes."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/paren-face"
  :commit "57307b5ea75e07d2dc0c64c7e3eeadee3369a7aa"
  :revdesc "57307b5ea75e"
  :keywords '("faces" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")))
