;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptai" "20250220.1735"
  "Integrate with the OpenAI API."
  '((emacs "24.1"))
  :url "https://github.com/antonhibl/gptai"
  :commit "446b3a3f8a4f2412c969189a1f64aed099582094"
  :revdesc "446b3a3f8a4f"
  :keywords '("comm" "convenience")
  :authors '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainers '(("Anton Hibl" . "antonhibl11@gmail.com")))
