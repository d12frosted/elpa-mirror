;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261009.141"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d9493d8921a6ade0c3a4c561db092803f0595e83"
  :revdesc "d9493d8921a6")
