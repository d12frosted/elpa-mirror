;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-call-tree" "20260813.1701"
  "Analyze source code based on font-lock text-properties."
  '((emacs    "24.3")
    (anaphora "1.0.0"))
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el"
  :commit "197850cd03e31891592a2f6a93c7e7552d4a9268"
  :revdesc "197850cd03e3"
  :keywords '("programming")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
