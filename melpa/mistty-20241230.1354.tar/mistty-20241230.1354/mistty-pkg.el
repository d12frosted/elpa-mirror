;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241230.1354"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "8a0fa72f7b94ebba0dcc5af70442ed70634512fc"
  :revdesc "8a0fa72f7b94"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
