(define-package "butler" "20210928.146" "Emacs client for Jenkins"
  '((deferred "0.3.2")
    (json "1.2")
    (emacs "24"))
  :commit "454cb9d3980b9ac555f3f77e4e48056de07f051b" :authors
  '(("Ashton Kemerling" . "ashtonkemerling@gmail.com"))
  :maintainer
  '("Ashton Kemerling" . "ashtonkemerling@gmail.com")
  :keywords
  '("jenkins" "hudson" "ci")
  :url "http://www.github.com/AshtonKem/Butler.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
