;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250123.705"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "b057ea8a105c9b37cd39bf038916bb254884da77"
  :revdesc "b057ea8a105c"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
