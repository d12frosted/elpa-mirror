;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "catppuccin-theme" "20241210.2015"
  "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs."
  '((emacs "26.1"))
  :url "https://github.com/catppuccin/emacs"
  :commit "b51b07e1b9c3e841165fdcd4fb32f9b94de7faa2"
  :revdesc "b51b07e1b9c3"
  :maintainers '(("Jeremy Baxter" . "jeremy@baxters.nz")))
