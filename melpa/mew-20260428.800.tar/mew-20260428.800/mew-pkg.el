;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260428.800"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "3ca03eeafadaac216f9bab5a526e295a66f30f5e"
  :revdesc "3ca03eeafada")
