(define-package "symbols-outline" "20231205.209" "Display symbols (functions, variables, etc) in outline view"
  '((emacs "27.1"))
  :commit "269653389fca6326679c50d004d171c94408a04e" :authors
  '(("Shihao Liu"))
  :maintainers
  '(("Shihao Liu"))
  :maintainer
  '("Shihao Liu")
  :keywords
  '("outlines")
  :url "https://github.com/liushihao456/symbols-outline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
