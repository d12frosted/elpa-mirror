(define-package "fanyi" "20211009.848" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "eeb1e6120429e22af9446839b61c42a51b7cb046" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
