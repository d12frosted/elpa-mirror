(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c998640cdb430b8220fdd9d8fe7907ff4a058a29")
;; Local Variables:
;; no-byte-compile: t
;; End:
