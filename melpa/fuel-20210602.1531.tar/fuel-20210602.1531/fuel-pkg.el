(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "df2e0dd4db588f182d95e017026947f1079a7ad3")
;; Local Variables:
;; no-byte-compile: t
;; End:
