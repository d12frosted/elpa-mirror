(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "6d8fa22187bc55ec8516d2e4710283e1f3fec1c7")
;; Local Variables:
;; no-byte-compile: t
;; End:
