(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ce86de6c23826a318be6dab8c6105542d76d52eb")
;; Local Variables:
;; no-byte-compile: t
;; End:
