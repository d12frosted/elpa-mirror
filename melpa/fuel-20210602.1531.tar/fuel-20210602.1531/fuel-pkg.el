(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f24e18ba802494327f4ff322ece9761069a5060f")
;; Local Variables:
;; no-byte-compile: t
;; End:
