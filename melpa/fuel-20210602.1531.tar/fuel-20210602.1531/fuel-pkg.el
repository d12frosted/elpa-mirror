(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9c0a9f9cc69b522879545db809ef355d4296be52")
;; Local Variables:
;; no-byte-compile: t
;; End:
