(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "654bb836138567e77f4d471d03bf98a79d96f3bc")
;; Local Variables:
;; no-byte-compile: t
;; End:
