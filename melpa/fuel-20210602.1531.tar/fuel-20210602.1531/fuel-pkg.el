(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ff17d0339e16eb716f57665ebd5028e0d8c373b9")
;; Local Variables:
;; no-byte-compile: t
;; End:
