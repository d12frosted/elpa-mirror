(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "55891de5f3ee425d2c563999642b30b9f61463b3")
;; Local Variables:
;; no-byte-compile: t
;; End:
