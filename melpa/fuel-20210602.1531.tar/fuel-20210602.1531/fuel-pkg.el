(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d81a9cb5b2f1374a5cf9521553b56b116576f98f")
;; Local Variables:
;; no-byte-compile: t
;; End:
