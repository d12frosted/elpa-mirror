(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d156ea6aee527c0a763367ea9cadb3a490b916f3")
;; Local Variables:
;; no-byte-compile: t
;; End:
