(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "cefe1975e5e278533e891f846b9e7773965093cc")
;; Local Variables:
;; no-byte-compile: t
;; End:
