(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d9b6d549251d4a1a7cec2e83b11bda2ef7ff4ed2")
;; Local Variables:
;; no-byte-compile: t
;; End:
