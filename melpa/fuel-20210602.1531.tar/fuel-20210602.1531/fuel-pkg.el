(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "82135888f48370f2e7075c525836ca926a20d318")
;; Local Variables:
;; no-byte-compile: t
;; End:
