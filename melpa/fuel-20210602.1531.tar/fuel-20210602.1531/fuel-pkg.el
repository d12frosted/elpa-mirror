(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d34f4dfb1cbe870152b60d41bcbb5195f318de0a")
;; Local Variables:
;; no-byte-compile: t
;; End:
