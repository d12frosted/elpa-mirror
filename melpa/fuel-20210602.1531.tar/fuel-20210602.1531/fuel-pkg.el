(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5e4f5601c8c0d81951e045c3b18068d85162e714")
;; Local Variables:
;; no-byte-compile: t
;; End:
