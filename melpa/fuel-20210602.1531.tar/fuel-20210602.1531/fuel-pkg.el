(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1f00dde04109f810b4cf9a9a35416199482d79c3")
;; Local Variables:
;; no-byte-compile: t
;; End:
