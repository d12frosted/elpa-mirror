(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4c46bd8b1d257bec90bcd1e85b4b1da1f75c6248")
;; Local Variables:
;; no-byte-compile: t
;; End:
