(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d7a262b5344f1187120ac96a660ef0bec5344d09")
;; Local Variables:
;; no-byte-compile: t
;; End:
