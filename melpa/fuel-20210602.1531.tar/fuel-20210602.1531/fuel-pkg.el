(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c222034873bee22bbe92808e7993ddcfbeddfab8")
;; Local Variables:
;; no-byte-compile: t
;; End:
