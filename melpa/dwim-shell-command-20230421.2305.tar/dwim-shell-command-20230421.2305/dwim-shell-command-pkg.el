(define-package "dwim-shell-command" "20230421.2305" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "79bf3ff2c7f6c4cd055d2cc9680ac94dd7beaba3" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
