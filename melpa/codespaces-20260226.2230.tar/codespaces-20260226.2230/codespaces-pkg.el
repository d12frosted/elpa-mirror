;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260226.2230"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "3563a297e3bcfd29468dac323f2201aee9d87b94"
  :revdesc "3563a297e3bc"
  :keywords '("comm")
  :authors '(("Fabian Markl" . "fabian@markl.dev"))
  :maintainers '(("Fabian Markl" . "fabian@markl.dev")))
