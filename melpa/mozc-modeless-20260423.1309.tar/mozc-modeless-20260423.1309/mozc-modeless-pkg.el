;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc-modeless" "20260423.1309"
  "Modeless Japanese input with Mozc."
  '((emacs "29.0")
    (mozc  "1.0"))
  :url "https://github.com/kiyoka/mozc-modeless-emacs"
  :commit "b5d246fd8f5ba3051808da82b2148a116b312ae7"
  :revdesc "b5d246fd8f5b"
  :keywords '("i18n" "input-method")
  :authors '(("Kiyoka Nishiyama" . "kiyokap@gmail.com"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyokap@gmail.com")))
