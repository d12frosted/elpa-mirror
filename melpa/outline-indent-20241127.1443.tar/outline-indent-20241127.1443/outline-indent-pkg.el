;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20241127.1443"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "1235ea2cd1609a8ba3798af039870940928efee3"
  :revdesc "1235ea2cd160"
  :keywords '("outlines"))
