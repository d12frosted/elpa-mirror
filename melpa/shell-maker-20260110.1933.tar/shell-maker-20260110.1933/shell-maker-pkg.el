;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260110.1933"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "26fd77a01ca15b441fd13186cb89f6b845a08e7c"
  :revdesc "26fd77a01ca1")
