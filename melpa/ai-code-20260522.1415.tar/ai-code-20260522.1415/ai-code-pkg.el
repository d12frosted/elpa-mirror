;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260522.1415"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "f2cb1857b19950aeca5990eaaf9490386b1a42c5"
  :revdesc "f2cb1857b199"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
