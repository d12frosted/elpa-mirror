;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250927.913"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "04c772d386e38f391a41f5dfd64bc7efc378ef36"
  :revdesc "04c772d386e3"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
