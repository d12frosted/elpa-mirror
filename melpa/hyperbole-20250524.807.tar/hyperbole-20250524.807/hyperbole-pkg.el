;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250524.807"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "5b6855e2257bbccc5b898fac9dad5d85ac3ee79e"
  :revdesc "5b6855e2257b"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
