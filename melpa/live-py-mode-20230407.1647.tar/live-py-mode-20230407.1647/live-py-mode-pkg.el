(define-package "live-py-mode" "20230407.1647" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "89a786ba668f7d4a5dab1f96779b1933c2fd2aa8" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
