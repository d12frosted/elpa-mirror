(define-package "org-tag-beautify" "20240924.635" "Beautify Org mode tags"
  '((emacs "26.1")
    (nerd-icons "0.0.1"))
  :commit "5bc2b9523f133d7990d7968fd4f948bd68e06a7e" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-tag-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
