;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260430.1710"
  "An Emacs Atom/RSS feed reader."
  '((emacs "27.1"))
  :url "https://github.com/skeeto/elfeed"
  :commit "763f3ed56c7c0629895f1f05e71fa9cccc26ead0"
  :revdesc "763f3ed56c7c"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
