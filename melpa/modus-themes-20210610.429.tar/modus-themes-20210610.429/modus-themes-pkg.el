(define-package "modus-themes" "20210610.429" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "d370818768ed7bba67e5c0ba9a8d1a3b58421bf7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
