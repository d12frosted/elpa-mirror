;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20260504.948"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "05d2ab6cfef91139cd6f43657311a0618cc4706e"
  :revdesc "05d2ab6cfef9"
  :keywords '("calendar" "holidays"))
