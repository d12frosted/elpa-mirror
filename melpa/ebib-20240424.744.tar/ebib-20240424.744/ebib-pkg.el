(define-package "ebib" "20240424.744" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "27.1")
    (compat "29.1.4.3"))
  :commit "44dd6db401ddb7696e3d55bbbc358b5f26de6a4b" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
