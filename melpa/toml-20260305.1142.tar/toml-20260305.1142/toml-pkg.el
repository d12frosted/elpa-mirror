;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260305.1142"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "7ad64be66dc95342e31627bc65762001a1e3cde7"
  :revdesc "7ad64be66dc9"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
