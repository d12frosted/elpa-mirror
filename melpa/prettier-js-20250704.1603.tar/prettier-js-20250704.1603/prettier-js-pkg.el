;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250704.1603"
  "Minor mode to format code on file save."
  '((emacs "28.1"))
  :url "https://github.com/prettier/prettier-emacs"
  :commit "a0eea197b0c7fbdff585414a7564effadcb58294"
  :revdesc "a0eea197b0c7"
  :keywords '("convenience" "wp" "edit" "js"))
