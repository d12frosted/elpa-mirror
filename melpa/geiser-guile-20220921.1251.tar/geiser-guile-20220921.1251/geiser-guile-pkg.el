(define-package "geiser-guile" "20220921.1251" "Guile's implementation of the geiser protocols"
  '((emacs "25.1")
    (geiser "0.26.1"))
  :commit "f9b0828e1599078c596df0100886d4199b9b62bc" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
