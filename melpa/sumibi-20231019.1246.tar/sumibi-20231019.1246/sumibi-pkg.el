;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20231019.1246"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "28.1")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "d6bbc65b71f0c59a471fffe13797d1ab6cac80f8"
  :revdesc "d6bbc65b71f0"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
