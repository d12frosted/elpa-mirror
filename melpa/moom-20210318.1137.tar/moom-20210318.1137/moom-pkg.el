(define-package "moom" "20210318.1137" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "9d3170f60dd188bac2d0304daf2a94bec9bfbbd3" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
