(define-package "evil-cleverparens" "20230111.1651" "Evil friendly minor-mode for editing lisp."
  '((evil "1.0")
    (paredit "1")
    (smartparens "1.6.1")
    (emacs "24.4")
    (dash "2.12.0"))
  :commit "af7dcc27148aab383147146f37f6808a3943060f" :authors
  '(("Olli Piepponen" . "opieppo@gmail.com"))
  :maintainer
  '("Olli Piepponen" . "opieppo@gmail.com")
  :keywords
  '("convenience" "emulations")
  :url "https://github.com/emacs-evil/evil-cleverparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
