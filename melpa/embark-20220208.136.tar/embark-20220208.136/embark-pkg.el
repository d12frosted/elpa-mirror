(define-package "embark" "20220208.136" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "2163e3f87460121e41cc1af953c30df02511b58d" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
