(define-package "apdl-mode" "20210810.1718" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "dfe232e246475f0eea5358ad4e7e6f94fe2aebab" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
