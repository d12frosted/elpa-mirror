(define-package "dirvish" "20220122.904" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "8b63425a3be43a155a58023588692413138db23f" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
