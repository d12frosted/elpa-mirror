(define-package "dirvish" "20220608.1236" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "f47331477af930a9759cadc9ade8cf81bc03497d" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
