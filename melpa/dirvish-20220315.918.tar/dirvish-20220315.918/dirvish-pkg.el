(define-package "dirvish" "20220315.918" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "653e1fbb0992242a82f5dc5d2e75a2d2f134201e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
