(define-package "bnf-mode" "20221204.1241" "Major mode for editing BNF grammars."
  '((cl-lib "0.5")
    (emacs "24.3"))
  :commit "31b5fa2fd62cf74d8d085c10f2c3a1c5f1515ddb" :authors
  '(("Serghei Iakovlev" . "egrep@protonmail.ch"))
  :maintainer
  '("Serghei Iakovlev" . "egrep@protonmail.ch")
  :keywords
  '("languages")
  :url "https://github.com/sergeyklay/bnf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
