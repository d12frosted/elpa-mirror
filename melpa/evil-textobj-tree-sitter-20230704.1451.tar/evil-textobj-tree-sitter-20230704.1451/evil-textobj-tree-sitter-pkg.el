(define-package "evil-textobj-tree-sitter" "20230704.1451" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.15.0"))
  :commit "e8bb9d63deeb2953ff9600e1633de667b3d7673e" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
