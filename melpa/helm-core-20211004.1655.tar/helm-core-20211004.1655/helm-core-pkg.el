(define-package "helm-core" "20211004.1655" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "76f435bd39e2a5765f5943e207504948eed3915b")
;; Local Variables:
;; no-byte-compile: t
;; End:
