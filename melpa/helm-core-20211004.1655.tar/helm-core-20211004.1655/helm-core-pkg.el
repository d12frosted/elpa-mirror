(define-package "helm-core" "20211004.1655" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "0dafe79c15619412fdf629e1cfc1e920ce13a52a")
;; Local Variables:
;; no-byte-compile: t
;; End:
