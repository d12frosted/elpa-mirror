(define-package "helm-core" "20211004.1655" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "54c8bfb7792141baab37793e7f1da4246ce9af50")
;; Local Variables:
;; no-byte-compile: t
;; End:
