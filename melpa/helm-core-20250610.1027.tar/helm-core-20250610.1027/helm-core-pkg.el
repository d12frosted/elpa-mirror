;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250610.1027"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "01b2efc256ef0917ae12a83ff169baa5e35da885"
  :revdesc "01b2efc256ef"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
