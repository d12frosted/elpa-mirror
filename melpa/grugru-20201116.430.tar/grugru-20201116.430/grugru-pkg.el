(define-package "grugru" "20201116.430" "Rotate text at point"
  '((emacs "24.4"))
  :commit "8c4baf15a428fffbf12cde59dcbf1571e96bed05" :keywords
  ("convenience" "abbrev" "tools")
  :authors
  (("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  ("ROCKTAKEY" . "rocktakey@gmail.com")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
