;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260326.739"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "366e4721539de9ba5972bbb320c9cade29141298"
  :revdesc "366e4721539d"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
