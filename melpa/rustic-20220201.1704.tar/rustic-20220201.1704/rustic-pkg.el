(define-package "rustic" "20220201.1704" "Rust development environment"
  '((emacs "26.1")
    (rust-mode "1.0.3")
    (dash "2.13.0")
    (f "0.18.2")
    (let-alist "1.0.4")
    (markdown-mode "2.3")
    (project "0.3.0")
    (s "1.10.0")
    (seq "2.3")
    (spinner "1.7.3")
    (xterm-color "1.6"))
  :commit "15e5662ffbfa1bd0197d478fbd0c0e579dc68bee" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
