(define-package "pandoc-mode" "20211207.1129" "Minor mode for interacting with Pandoc"
  '((hydra "0.10.0")
    (dash "2.10.0"))
  :commit "d7da6433aa905ff350e5c04798f5d2d8f1c19803" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "pandoc")
  :url "http://joostkremers.github.io/pandoc-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
