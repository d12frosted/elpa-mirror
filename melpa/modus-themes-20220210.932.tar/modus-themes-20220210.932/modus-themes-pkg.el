(define-package "modus-themes" "20220210.932" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "718653fb298a7dc673fad2b6082c3dacba00a88b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
