(define-package "srfi" "20220724.11" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "10c36b101cadfdded4d7b78d920fc2919a7d674e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
