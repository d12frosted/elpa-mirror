;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260316.405"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "a22c090df03321cc94514d670075ccac3f1988e8"
  :revdesc "a22c090df033"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
