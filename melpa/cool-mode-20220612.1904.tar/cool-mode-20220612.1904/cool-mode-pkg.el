(define-package "cool-mode" "20220612.1904" "Major mode for cool compiler language"
  '((emacs "25"))
  :commit "961e66956412a1dd63f79473a8273da8853f7179" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :url "https://github.com/nverno/cool-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
