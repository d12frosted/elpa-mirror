;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "20260630.853"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.23"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "263d9a5325a0ab835951e664be0b66de39b06aec"
  :revdesc "263d9a5325a0"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
