(define-package "snap-indent" "20230625.1700" "Simple automatic indentation"
  '((emacs "24.1"))
  :commit "ef3bcab6535f6503d4b0812ce6acd3b184b49484" :authors
  '(("Jeff Valk" . "jv@jeffvalk.com"))
  :maintainers
  '(("Jeff Valk" . "jv@jeffvalk.com"))
  :maintainer
  '("Jeff Valk" . "jv@jeffvalk.com")
  :keywords
  '("indent" "tools" "convenience")
  :url "https://github.com/jeffvalk/snap-indent")
;; Local Variables:
;; no-byte-compile: t
;; End:
