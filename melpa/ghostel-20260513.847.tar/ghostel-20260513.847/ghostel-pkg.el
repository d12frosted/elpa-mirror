;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260513.847"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "113f7a2d4f3ec2a22015a238108ca12585a80e02"
  :revdesc "113f7a2d4f3e"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
