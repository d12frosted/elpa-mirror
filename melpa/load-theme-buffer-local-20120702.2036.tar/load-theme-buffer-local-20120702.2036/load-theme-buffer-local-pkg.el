;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "load-theme-buffer-local" "20120702.2036"
  "Install emacs24 color themes by buffer."
  ()
  :url "https://github.com/vic/color-theme-buffer-local"
  :commit "bc221a88aefec5bdc137b5d5e449e1f1e55ce901"
  :revdesc "bc221a88aefe"
  :keywords '("faces")
  :authors '(("Victor Borja" . "vic.borja@gmail.com"))
  :maintainers '(("Victor Borja" . "vic.borja@gmail.com")))
