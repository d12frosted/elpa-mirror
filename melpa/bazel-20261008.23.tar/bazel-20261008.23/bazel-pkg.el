;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261008.23"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "5986655b5785e3fff3770af0fada2173a96d4030"
  :revdesc "5986655b5785"
  :keywords '("build tools" "languages"))
