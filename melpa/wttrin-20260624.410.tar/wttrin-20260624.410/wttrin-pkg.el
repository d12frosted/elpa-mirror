;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260624.410"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "efd3cdce5b3aebfdb3e02460d1ec0434cef85949"
  :revdesc "efd3cdce5b3a"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
