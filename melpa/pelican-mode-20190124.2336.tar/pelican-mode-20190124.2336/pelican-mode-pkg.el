;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pelican-mode" "20190124.2336"
  "Minor mode for editing Pelican sites."
  '((emacs "25"))
  :url "https://git.korewanetadesu.com/pelican-mode.git"
  :commit "a69934885c7a3b303049e2418333b3915b8f8fb8"
  :revdesc "a69934885c7a"
  :keywords '("convenience" "editing")
  :authors '(("Joe Wreschnig" . "joe.wreschnig@gmail.com"))
  :maintainers '(("Joe Wreschnig" . "joe.wreschnig@gmail.com")))
