;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youdotcom" "20240207.1853"
  "You.com search package."
  '((emacs "25.1"))
  :url "https://github.com/SamuelVanie/youdotcom.el"
  :commit "0b835f143e88c3321006a3e48ac5190d071b872c"
  :revdesc "0b835f143e88"
  :keywords '("ai" "tools")
  :authors '(("Samuel Michael Vanié" . "samuelmichaelvanie@gmail.com"))
  :maintainers '(("Samuel Michael Vanié" . "samuelmichaelvanie@gmail.com")))
