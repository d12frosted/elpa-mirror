;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260709.19"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "f9ff19c3eca7d88b8ad6385c5592369d4b4d9cda"
  :revdesc "f9ff19c3eca7"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
