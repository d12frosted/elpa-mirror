(define-package "consult" "20230129.1746" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "fdba8a4fc4ce28e5d8a33ed47a1a87f04234fd5e" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
