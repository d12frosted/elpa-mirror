;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250716.528"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "03dd33339cf9d3ead57a47737f246b94dddba9a2"
  :revdesc "03dd33339cf9"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
