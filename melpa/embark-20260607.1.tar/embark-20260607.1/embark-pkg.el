;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark" "20260607.1"
  "Conveniently act on minibuffer completions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/oantolin/embark"
  :commit "d3da7e40d4dab4b302766498833ffeaccb89cdd5"
  :revdesc "d3da7e40d4da"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
