;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective" "20260331.1411"
  "Switch between named \"perspectives\" of the editor."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/nex3/perspective-el"
  :commit "1271ac579798fe65ba2246a72a44efb1eeeba2ec"
  :revdesc "1271ac579798"
  :keywords '("workspace" "convenience" "frames")
  :authors '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers '(("Natalie Weizenbaum" . "nex342@gmail.com")))
