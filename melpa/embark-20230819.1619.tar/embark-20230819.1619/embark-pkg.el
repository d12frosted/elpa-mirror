(define-package "embark" "20230819.1619" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "1ca4f35342e953443adca63dd907bbbb7dcf9055" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
