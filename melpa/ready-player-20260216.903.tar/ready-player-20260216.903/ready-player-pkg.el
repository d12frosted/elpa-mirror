;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "20260216.903"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "b578f76002dc63c1773e1d8edea5b5fbc56a5244"
  :revdesc "b578f76002dc")
