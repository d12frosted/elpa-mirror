;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251209.1907"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "a6de6aeb225369e15ab5b2c679276f05b6a42a6b"
  :revdesc "a6de6aeb2253"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
