;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskpaper-mode" "20241005.1504"
  "Major mode for working with TaskPaper files."
  '((emacs "25.1"))
  :url "https://github.com/saf-dmitry/taskpaper-mode"
  :commit "3fc3195fd221abd85853fcb116eb79fb342b6aea"
  :revdesc "3fc3195fd221"
  :keywords '("outlines" "notetaking" "task management" "productivity" "taskpaper")
  :authors '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainers '(("Dmitry Safronov" . "saf.dmitry@gmail.com")))
