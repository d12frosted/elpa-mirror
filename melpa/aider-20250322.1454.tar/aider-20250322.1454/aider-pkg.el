;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250322.1454"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "59dfd29f21105988d92f8a47b45f18c1249aa169"
  :revdesc "59dfd29f2110"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
