(define-package "consult" "20201222.1731" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "db9b49a555562b993914abcfe8d05cdc29913113" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
