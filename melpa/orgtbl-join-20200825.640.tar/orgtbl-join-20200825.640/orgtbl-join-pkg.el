(define-package "orgtbl-join" "20200825.640" "join columns from another table"
  '((cl-lib "0.5"))
  :commit "e93e8eaeab2137bc391cf6d0643619ce6b066d19" :authors
  (("Thierry Banel tbanelwebmin at free dot fr"))
  :maintainer
  ("Thierry Banel tbanelwebmin at free dot fr")
  :keywords
  ("org" "table" "join" "filtering"))
;; Local Variables:
;; no-byte-compile: t
;; End:
