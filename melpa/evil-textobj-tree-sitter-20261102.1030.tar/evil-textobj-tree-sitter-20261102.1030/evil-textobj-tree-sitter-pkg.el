;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-tree-sitter" "20261102.1030"
  "Provides evil textobjects using tree-sitter."
  '((emacs "25.1"))
  :url "https://github.com/meain/evil-textobj-tree-sitter"
  :commit "08ff3afa85a19bfbf95baaf21bd2f2516de7af54"
  :revdesc "08ff3afa85a1"
  :keywords '("evil" "tree-sitter" "text-object" "convenience"))
