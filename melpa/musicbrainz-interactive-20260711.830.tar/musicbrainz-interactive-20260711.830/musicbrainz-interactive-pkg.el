;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "musicbrainz-interactive" "20260711.830"
  "Interactive commands for MusicBrainz related things."
  '((emacs       "28.1")
    (musicbrainz "0.1"))
  :url "https://github.com/zzkt/metabrainz"
  :commit "6c699a9c1a8b9292a732ae1bd662b021fcd8d8b8"
  :revdesc "6c699a9c1a8b"
  :keywords '("data" "convenience" "music")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
