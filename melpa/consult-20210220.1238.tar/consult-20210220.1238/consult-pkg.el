(define-package "consult" "20210220.1238" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "2eed7a9b9b3882408485198d7f6295d1f154b119" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
