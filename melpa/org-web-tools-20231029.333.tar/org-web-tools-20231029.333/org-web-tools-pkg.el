(define-package "org-web-tools" "20231029.333" "Display and capture web content with Org-mode"
  '((emacs "25.1")
    (org "9.0")
    (compat "29.1.4.2")
    (dash "2.12")
    (esxml "0.3.4")
    (s "1.10.0")
    (request "0.3.0"))
  :commit "de6450aaa43b073007b3c5a2c9d45368a297ec27" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("hypermedia" "outlines" "org" "web")
  :url "http://github.com/alphapapa/org-web-tools")
;; Local Variables:
;; no-byte-compile: t
;; End:
