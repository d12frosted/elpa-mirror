;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260104.1111"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "e85a4c625071e24104927195a045a1d919b712c1"
  :revdesc "e85a4c625071"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
