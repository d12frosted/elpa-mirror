(define-package "tikz" "20210927.1704" "A minor mode to edit TikZ pictures"
  '((emacs "24.1"))
  :commit "f9ea0793affa34be29e1861bfa559fd248b7d22e" :authors
  '(("Emilio Torres-Manzanera" . "torres@uniovi.es"))
  :maintainer
  '("Emilio Torres-Manzanera" . "torres@uniovi.es")
  :keywords
  '("tex")
  :url "https://github.com/emiliotorres/tikz")
;; Local Variables:
;; no-byte-compile: t
;; End:
