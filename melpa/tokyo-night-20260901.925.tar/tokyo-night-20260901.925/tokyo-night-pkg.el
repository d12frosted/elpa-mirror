;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20260901.925"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "96276384546c9020198cec7a807c186b063ed63f"
  :revdesc "96276384546c"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
