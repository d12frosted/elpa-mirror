(define-package "proof-general" "20210918.2238" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "25.1"))
  :commit "38ae8fdf23f37af71b8a4f9717ba48c52653db63" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
