(define-package "helm-core" "20220727.508" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "e39db6bbf26d6a4b4b4d14140d98b4a254c7e153" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
