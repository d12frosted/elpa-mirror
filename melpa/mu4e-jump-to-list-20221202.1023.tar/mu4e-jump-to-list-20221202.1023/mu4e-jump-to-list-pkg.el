;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-jump-to-list" "20221202.1023"
  "Mu4e jump-to-list extension."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://gitlab.com/wavexx/mu4e-jump-to-list.el"
  :commit "cf19684d2333cb0cda7f6b62c7607144baa49310"
  :revdesc "cf19684d2333"
  :keywords '("mu4e" "mail" "convenience")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
