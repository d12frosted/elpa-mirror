(define-package "deno-ts-mode" "20230903.1457" "Major mode for Deno"
  '((emacs "29.1"))
  :commit "15e280d33dd182f6d37318e8a7edb73190594b98" :authors
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainers
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainer
  '("Graham Marlow" . "info@mgmarlow.com")
  :keywords
  '("languages")
  :url "https://git.sr.ht/~mgmarlow/deno-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
