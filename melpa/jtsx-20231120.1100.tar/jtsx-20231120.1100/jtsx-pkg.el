(define-package "jtsx" "20231120.1100" "Extends default support for JSX/TSX"
  '((emacs "29.1"))
  :commit "81234bcbfd7ad9e0265ed8fbd21659843a64afa0" :authors
  '(("Loïc Lemaître" . "loic.lemaitre@gmail.com"))
  :maintainers
  '(("Loïc Lemaître" . "loic.lemaitre@gmail.com"))
  :maintainer
  '("Loïc Lemaître" . "loic.lemaitre@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/llemaitre19/jtsx")
;; Local Variables:
;; no-byte-compile: t
;; End:
