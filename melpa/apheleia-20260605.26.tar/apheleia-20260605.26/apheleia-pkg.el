;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20260605.26"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "5acfadf6e109a65e2b66aa5feb764b96ca3e3c10"
  :revdesc "5acfadf6e109"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
