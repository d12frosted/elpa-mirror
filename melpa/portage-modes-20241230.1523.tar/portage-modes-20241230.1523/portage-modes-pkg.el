;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "portage-modes" "20241230.1523"
  "Major modes for editing Portage config files."
  ()
  :url "https://github.com/OpenSauce04/portage-modes"
  :commit "07b8c073a70b099c2581258d45304dbb78fe0640"
  :revdesc "07b8c073a70b"
  :authors '(("OpenSauce" . "opensauce04@gmail.com"))
  :maintainers '(("OpenSauce" . "opensauce04@gmail.com")))
