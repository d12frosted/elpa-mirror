(define-package "embark" "20210607.315" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "de58da4ce4b5d726e33f82e42458bbb46ce683e1" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
