(define-package "tuareg" "20210627.1931" "OCaml mode for Emacs."
  '((caml "3.12.0.1")
    (emacs "24.4"))
  :commit "c1d5aa12b1abb2a0cc1756ed331182fce64b6cce" :authors
  '(("Albert Cohen" . "Albert.Cohen@inria.fr")
    ("Sam Steingold" . "sds@gnu.org")
    ("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
    ("Till Varoquaux" . "till@pps.jussieu.fr")
    ("Sean McLaughlin" . "seanmcl@gmail.com")
    ("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainer
  '("Albert Cohen" . "Albert.Cohen@inria.fr")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/tuareg")
;; Local Variables:
;; no-byte-compile: t
;; End:
