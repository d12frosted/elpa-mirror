;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-project-extra" "20260116.837"
  "Consult integration for project.el."
  '((emacs   "28.1")
    (consult "0.17")
    (project "0.8.1"))
  :url "https://github.com/Qkessler/consult-project-extra"
  :commit "9d260c030feca2358bbfe77135fb0205ae7e54fc"
  :revdesc "9d260c030fec"
  :keywords '("convenience" "project" "management"))
