(define-package "modus-themes" "20210915.722" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "998cab76b2b45ebadc8552a6cbad35839f620953" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
