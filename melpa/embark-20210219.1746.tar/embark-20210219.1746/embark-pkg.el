(define-package "embark" "20210219.1746" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "506af19fa072db32982d3e38084b19258ffeb4b5" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
