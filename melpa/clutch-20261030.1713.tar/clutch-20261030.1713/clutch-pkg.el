;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261030.1713"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "2e8823d588b423303a6196e1d14b562a234efd58"
  :revdesc "2e8823d588b4"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
