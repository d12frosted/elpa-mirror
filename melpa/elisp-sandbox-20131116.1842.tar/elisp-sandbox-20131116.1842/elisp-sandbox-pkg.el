;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-sandbox" "20131116.1842"
  "Evaluate EmacsLisp expressions in a sandbox."
  ()
  :url "https://github.com/joelmccracken/elisp-sandbox"
  :commit "ddd669266ca36d7e4ebba73eb1ab42523787e042"
  :revdesc "ddd669266ca3"
  :keywords '("lisp")
  :authors '(("Joel McCracken" . "mccracken.joel@gmail.com")
             ("D. Goel" . "deego@gnufans.org"))
  :maintainers '(("Joel McCracken" . "mccracken.joel@gmail.com")
                 ("D. Goel" . "deego@gnufans.org")))
