;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20260917.1122"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "61a479424d7cdd0a25b07dfc28cc837c7fbb058d"
  :revdesc "61a479424d7c"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
