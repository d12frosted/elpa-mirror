(define-package "php-mode" "20221027.1506" "Major mode for editing PHP code"
  '((emacs "25.2"))
  :commit "0526c4310ae9c6be8e70553b8d894f5e4e7f117e" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
