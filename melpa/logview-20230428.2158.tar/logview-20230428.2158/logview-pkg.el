(define-package "logview" "20230428.2158" "Major mode for viewing log files"
  '((emacs "25.1")
    (datetime "0.6.1")
    (extmap "1.0"))
  :commit "856ebf1aa9a8d0ebde3352ba14bad2fbb78c82a8" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("files" "tools")
  :url "https://github.com/doublep/logview")
;; Local Variables:
;; no-byte-compile: t
;; End:
