(define-package "citar" "20230111.1449" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "4.2")
    (org "9.5")
    (citeproc "0.9"))
  :commit "ea489eca7f5321b5ede1ea294abf47ecbc9f11ca" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/emacs-citar/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
