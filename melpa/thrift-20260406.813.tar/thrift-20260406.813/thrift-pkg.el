;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260406.813"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "a7c84a7072e9b839def6239da266315c08bce5fa"
  :revdesc "a7c84a7072e9"
  :keywords '("languages"))
