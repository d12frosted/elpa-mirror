;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20260107.1707"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "6946aa5bebbd5dbbb2985d22325a03290fb6b79f"
  :revdesc "6946aa5bebbd"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
