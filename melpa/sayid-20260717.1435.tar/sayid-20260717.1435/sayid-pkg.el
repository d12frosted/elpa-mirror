;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "20260717.1435"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "2.0"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "16fe77228cb3f76eee52d1be336a505f23a31223"
  :revdesc "16fe77228cb3"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
