(define-package "electric-operator" "20220218.826" "Automatically add spaces around operators"
  '((dash "2.10.0")
    (emacs "24.4"))
  :commit "6dbd8f80aee44e2f6ff9995f1bebb8f05575505a" :authors
  '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainer
  '("David Shepherd" . "davidshepherd7@gmail.com")
  :keywords
  '("electric")
  :url "https://github.com/davidshepherd7/electric-operator")
;; Local Variables:
;; no-byte-compile: t
;; End:
