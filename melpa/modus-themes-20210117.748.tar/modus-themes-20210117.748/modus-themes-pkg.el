(define-package "modus-themes" "20210117.748" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "8b3215ed2d1070811ea5fa1a773a40e38b7c397a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
