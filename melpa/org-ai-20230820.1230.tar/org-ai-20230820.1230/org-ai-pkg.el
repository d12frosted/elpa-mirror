(define-package "org-ai" "20230820.1230" "Your AI assistant with ChatGPT, DALL-E, Whisper, Stable Diffusion"
  '((emacs "27"))
  :commit "e188f2b3506da47452142746f7ea9e08e97a9c09" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
