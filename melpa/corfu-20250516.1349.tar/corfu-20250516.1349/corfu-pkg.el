;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250516.1349"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "3ce82b95e6ba6e466693ba6e157d771129bbd222"
  :revdesc "3ce82b95e6ba"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
