(define-package "impatient-showdown" "20220730.1259" "Preview markdown buffer live over HTTP using showdown"
  '((emacs "24.3")
    (impatient-mode "1.1"))
  :commit "3d07d3377d8e5cec93f113d57e656f76d2f52afe" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "live" "preview" "markdown" "http" "server" "impatient")
  :url "https://github.com/jcs-elpa/impatient-showdown")
;; Local Variables:
;; no-byte-compile: t
;; End:
