(define-package "repeatable-motion" "20150629.1812" "Make repeatable versions of motions"
  '((emacs "24"))
  :commit "e664b0a4a3e39c4085378a28b5136b349a0afb22" :authors
  '(("William Hatch" . "willghatch@gmail.com"))
  :maintainer
  '("William Hatch" . "willghatch@gmail.com")
  :keywords
  '("motion" "repeatable")
  :url "https://github.com/willghatch/emacs-repeatable-motion")
;; Local Variables:
;; no-byte-compile: t
;; End:
