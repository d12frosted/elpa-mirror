;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250529.2255"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "71d1c7ec8f9ac1d991267e4576d89b6adb093584"
  :revdesc "71d1c7ec8f9a"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
