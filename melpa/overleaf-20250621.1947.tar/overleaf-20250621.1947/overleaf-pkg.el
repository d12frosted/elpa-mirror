;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250621.1947"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "37308c18561fcd31a4c7a9b1b4bb26318d4b0b25"
  :revdesc "37308c18561f"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
