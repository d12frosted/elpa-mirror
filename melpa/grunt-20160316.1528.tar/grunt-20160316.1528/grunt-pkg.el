;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grunt" "20160316.1528"
  "Some glue to stick Emacs and Gruntfiles together."
  '((dash       "2.9.0")
    (ansi-color "3.4.2")
    (emacs      "24.3"))
  :url "https://github.com/gempesaw/grunt.el"
  :commit "4c269e2738658643ec2ed9ef61a2a3d71b08d304"
  :revdesc "4c269e273865"
  :keywords '("convenience" "grunt")
  :authors '(("Daniel Gempesaw" . "dgempesaw@sharecare.com"))
  :maintainers '(("Daniel Gempesaw" . "dgempesaw@sharecare.com")))
