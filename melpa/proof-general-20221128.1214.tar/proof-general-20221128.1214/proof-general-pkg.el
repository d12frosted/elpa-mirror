(define-package "proof-general" "20221128.1214" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "8e688a67703e4a132cc09bece1b746289868f6ab" :maintainer
  '(nil . "proof-general-maintainers@groupes.renater.fr")
  :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
