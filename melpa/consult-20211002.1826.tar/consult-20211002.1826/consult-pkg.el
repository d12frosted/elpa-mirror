(define-package "consult" "20211002.1826" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "e40ff0466ac301c10be23eccea0c3f7320ec05bc" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
