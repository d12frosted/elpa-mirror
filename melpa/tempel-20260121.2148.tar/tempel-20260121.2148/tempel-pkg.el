;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260121.2148"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "632a4478ed4ce5a77f3bf78a9551a003e30f6c1c"
  :revdesc "632a4478ed4c"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
