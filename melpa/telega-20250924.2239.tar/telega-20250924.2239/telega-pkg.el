;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250924.2239"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "f8d803bed9aa55df56361e37ba085ad2fc7bafce"
  :revdesc "f8d803bed9aa"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
