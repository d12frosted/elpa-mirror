(define-package "kaomoji" "20220721.441" "Input kaomoji superb easily"
  '((emacs "24.3")
    (helm-core "3.6.0"))
  :commit "fba0018a13eba70c2bffc6153dcfee99937fa3d6" :authors
  '(("Ono Hiroko" . "azazabc123@gmail.com"))
  :maintainer
  '("Ono Hiroko" . "azazabc123@gmail.com")
  :keywords
  '("tools" "fun")
  :url "https://github.com/kuanyui/kaomoji.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
