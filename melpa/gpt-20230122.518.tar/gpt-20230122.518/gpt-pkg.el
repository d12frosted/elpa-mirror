(define-package "gpt" "20230122.518" "Run instruction-following language models"
  '((emacs "24.4"))
  :commit "9c0d5d89b53a825fd20543f7d640e9da69a0e547" :authors
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainer
  '("Andreas Stuhlmueller" . "andreas@ought.org")
  :keywords
  '("gpt3" "language" "copilot" "convenience" "tools")
  :url "https://github.com/stuhlmueller/gpt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
