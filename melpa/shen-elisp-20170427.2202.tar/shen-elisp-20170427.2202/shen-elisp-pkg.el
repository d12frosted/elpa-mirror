(define-package "shen-elisp" "20170427.2202" "Shen implementation in Elisp"
  '((emacs "24.4"))
  :commit "ffe17dee05f75539cf5e4c59395e4c7400ececaa" :authors
  '(("Aditya Siram" . "aditya.siram@gmail.com"))
  :maintainer
  '("Aditya Siram" . "aditya.siram@gmail.com")
  :url "https://github.com/deech/shen-elisp")
;; Local Variables:
;; no-byte-compile: t
;; End:
