(define-package "literate-calc-mode" "20231021.804" "Inline results from calc"
  '((emacs "25.1")
    (dash "2.19.1")
    (s "1.12.0"))
  :commit "2579d7b28994bb16c3e02577953e7d9669121288" :authors
  '(("Robin Schroer"))
  :maintainers
  '(("Robin Schroer"))
  :maintainer
  '("Robin Schroer")
  :keywords
  '("calc" "languages" "tools")
  :url "https://github.com/sulami/literate-calc-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
