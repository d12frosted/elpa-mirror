;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bracket-face" "20260901.1122"
  "A face for brackets."
  '((emacs "30.1"))
  :url "https://github.com/tarsius/paren-face"
  :commit "f9e2f30366937223fc71611f2590c802d577bd22"
  :revdesc "f9e2f3036693"
  :keywords '("faces" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")))
