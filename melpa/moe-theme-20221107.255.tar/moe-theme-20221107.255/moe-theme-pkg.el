(define-package "moe-theme" "20221107.255" "A colorful eye-candy theme. Moe, moe, kyun!" 'nil :commit "b7960f079e6f2b82468b4ca2afd4edf8bbdb6fdb" :authors
  '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainer
  '("kuanyui" . "azazabc123@gmail.com")
  :keywords
  '("themes")
  :url "https://github.com/kuanyui/moe-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
