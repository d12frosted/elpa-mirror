;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bookmarks-extractor" "20220829.146"
  "Extract bookmarks from Org mode."
  '((emacs "25.1"))
  :url "https://github.com/jxq0/org-bookmarks-extractor"
  :commit "26d810d4d58de1f64f0bbd649e13816f96663d73"
  :revdesc "26d810d4d58d"
  :keywords '("convenience" "org")
  :authors '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainers '(("Xuqing Jia" . "jxq@jxq.me")))
