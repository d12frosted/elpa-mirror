(define-package "hyperdrive" "20230620.1851" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.6pre")
    (persist "0.5"))
  :commit "8ba6994293f8475412b87817df666ce896b8f7d7" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
