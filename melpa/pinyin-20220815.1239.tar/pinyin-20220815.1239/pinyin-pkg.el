(define-package "pinyin" "20220815.1239" "Convert Hanzi to Pinyin (汉字转拼音)"
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "b7a0aad8ff35e50d1c536df4c0e73fc7e9d06700" :authors
  '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainer
  '("Xu Chunyang" . "mail@xuchunyang.me")
  :keywords
  '("extensions")
  :url "https://github.com/xuchunyang/pinyin.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
