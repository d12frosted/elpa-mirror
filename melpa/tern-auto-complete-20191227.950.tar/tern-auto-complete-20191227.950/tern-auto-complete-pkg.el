;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tern-auto-complete" "20191227.950"
  "Tern Completion by auto-complete.el."
  '((tern          "0.0.1")
    (auto-complete "1.4")
    (cl-lib        "0.5")
    (emacs         "24"))
  :url "https://github.com/ternjs/tern"
  :commit "0d19800db70a6348c627a69f444b91d21ad89629"
  :revdesc "0d19800db70a"
  :authors '((nil . "m.sakuraiatkiwanami.net"))
  :maintainers '((nil . "m.sakuraiatkiwanami.net")))
