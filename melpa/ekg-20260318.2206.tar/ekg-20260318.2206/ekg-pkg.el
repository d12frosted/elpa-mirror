;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260318.2206"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "d88a85db0c441e131aaf87ee03df7bb47f4534c5"
  :revdesc "d88a85db0c44"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
