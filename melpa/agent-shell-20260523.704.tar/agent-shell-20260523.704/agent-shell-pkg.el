;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260523.704"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "cded16843a1a5b590d90f1d425dd38acab021b0d"
  :revdesc "cded16843a1a")
