;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bilibili" "20250309.1703"
  "Watch videos in BiliBili (哔哩哔哩) with org mode."
  '((emacs "29.1")
    (org   "9.0")
    (mpvi  "1.0"))
  :url "https://github.com/lorniu/bilibili.el"
  :commit "b841fbd301923e104ae816b855565e71f9c41e64"
  :revdesc "b841fbd30192"
  :keywords '("multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
