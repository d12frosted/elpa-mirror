(define-package "docker-tramp" "20161021.520" "TRAMP integration for docker containers"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "d8b510365d8e65551f4f792f251e7212411708c3" :authors
  '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainer
  '("Mario Rodas" . "marsam@users.noreply.github.com")
  :keywords
  '("docker" "convenience")
  :url "https://github.com/emacs-pe/docker-tramp.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
