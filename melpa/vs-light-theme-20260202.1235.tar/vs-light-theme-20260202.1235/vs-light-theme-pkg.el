;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-light-theme" "20260202.1235"
  "Visual Studio IDE light theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-light-theme"
  :commit "7e0fad816fc8eee099d3ddd972430904dcdd8b3b"
  :revdesc "7e0fad816fc8"
  :keywords '("faces"))
