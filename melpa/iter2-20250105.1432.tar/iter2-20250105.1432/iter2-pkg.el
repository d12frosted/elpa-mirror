;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iter2" "20250105.1432"
  "Reimplementation of Elisp generators."
  '((emacs "25.1"))
  :url "https://github.com/doublep/iter2"
  :commit "fc200dbaf74823690712f6d6383ab2bab8d1cda4"
  :revdesc "fc200dbaf748"
  :keywords '("elisp" "extensions")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
