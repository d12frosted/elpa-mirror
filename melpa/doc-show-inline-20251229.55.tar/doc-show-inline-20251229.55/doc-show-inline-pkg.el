;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doc-show-inline" "20251229.55"
  "Show doc-strings found in external files."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-doc-show-inline"
  :commit "d7bf74864c0184de5eda3fedc4f1639c041b678f"
  :revdesc "d7bf74864c01"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
