(define-package "ghub" "20220422.1610" "Client libraries for Git forge APIs."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (let-alist "1.0.6")
    (treepy "0.1.1"))
  :commit "3f8d68ec6fcb0eec541e7ab1f45ec78aee362edb" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
