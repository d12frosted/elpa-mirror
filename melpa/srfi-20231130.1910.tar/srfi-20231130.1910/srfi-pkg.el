(define-package "srfi" "20231130.1910" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "542890f13125f3f72b6c02c5648ba5cb15d73949" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
