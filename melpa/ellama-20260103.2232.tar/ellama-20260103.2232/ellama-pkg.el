;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260103.2232"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "3ddbe73e862a3bb6f0bdfbf977602cab85fbdf5c"
  :revdesc "3ddbe73e862a"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
