;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260821.1224"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "b646ce87b747a6fa4b264e319a80ef3417a99703"
  :revdesc "b646ce87b747"
  :keywords '("languages"))
