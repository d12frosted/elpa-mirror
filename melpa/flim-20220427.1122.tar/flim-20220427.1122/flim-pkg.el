(define-package "flim" "20220427.1122" "A library to provide basic features about message representation or encoding."
  '((emacs "24.5")
    (apel "10.8")
    (oauth2 "0.11"))
  :commit "e7e2f51b6817f55e45916811c5fa1f102fcd24bd")
;; Local Variables:
;; no-byte-compile: t
;; End:
