(define-package "ebib" "20220711.1845" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "26.1"))
  :commit "43f4e50d8e20c87f279da1a7317977297387bff1" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
