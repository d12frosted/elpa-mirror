(define-package "nm" "20151110.1910" "NEVERMORE: an email interface for Notmuch"
  '((notmuch "0.21")
    (peg "0.6")
    (company "0")
    (emacs "24.3"))
  :commit "5a3f29174b3a4b2b2e7a700a862f3b16a942687e" :authors
  '(("Trevor Jim"))
  :maintainer
  '("Trevor Jim")
  :url "https://github.com/tjim/nevermore")
;; Local Variables:
;; no-byte-compile: t
;; End:
