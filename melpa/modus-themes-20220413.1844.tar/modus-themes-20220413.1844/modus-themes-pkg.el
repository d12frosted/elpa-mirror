(define-package "modus-themes" "20220413.1844" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "dd2b51a76f7177224202b68efdd1bec6fdc65553" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
