;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260604.1617"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a0b24c6962c51fca6c3b8543c28371f89012c36c"
  :revdesc "a0b24c6962c5")
