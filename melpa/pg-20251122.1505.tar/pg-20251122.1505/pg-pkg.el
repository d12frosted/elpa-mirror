;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20251122.1505"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "4746a8bd1e299157dbbafa43a127405c224d1a32"
  :revdesc "4746a8bd1e29"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
