;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20261001.1412"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "aa7c7475e7e941f845089c2e0d2414ff94e5b32d"
  :revdesc "aa7c7475e7e9"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
