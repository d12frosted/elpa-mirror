(define-package "shanty-themes" "20220816.1830" "The themes for digital workers"
  '((emacs "24.5.1"))
  :commit "9ddd8ccd94b51ad5b19ee7097dcfccb3588b5eef" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
