;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260413.1134"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "36a1ad51c8e43c905936034c5e72a12ff3286144"
  :revdesc "36a1ad51c8e4"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
