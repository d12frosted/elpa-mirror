;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcute" "20250325.1442"
  "Commands for marking and killing lines electrically."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "97b4c3b0bd3e22d4d4b1a9aed3435b5a58b09259"
  :revdesc "97b4c3b0bd3e"
  :keywords '("convenience"))
