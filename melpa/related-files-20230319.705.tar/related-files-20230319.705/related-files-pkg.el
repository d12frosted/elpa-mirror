(define-package "related-files" "20230319.705" "Easily find files related to the current one"
  '((emacs "28.2"))
  :commit "3ae9de03998d4d1f48a847ebe5e8964eb0d02dbc" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("tools")
  :url "https://www.gnu.org/software/emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
