(define-package "org-roam-bibtex" "20220626.1121" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "2.2.0")
    (bibtex-completion "2.0.0"))
  :commit "201262a839db20af2a49165a80f85f82dad159d1" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
