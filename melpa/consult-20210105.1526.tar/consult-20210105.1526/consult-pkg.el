(define-package "consult" "20210105.1526" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7a2f751421f4a1601811fa59571bd64baf7ec900" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
