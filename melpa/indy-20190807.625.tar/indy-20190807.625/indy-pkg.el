;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indy" "20190807.625"
  "A minor mode and EDSL to manage your mode's indentation rules."
  ()
  :url "https://github.com/kwrooijen/indy"
  :commit "abc5bee424780ad2de5520f8fefbf8e120c0d9ed"
  :revdesc "abc5bee42478"
  :keywords '("convenience" "matching" "tools")
  :authors '(("Kevin W. van Rooijen" . "kevin.van.rooijen@attichacker.com"))
  :maintainers '(("Kevin W. van Rooijen" . "kevin.van.rooijen@attichacker.com")))
