(define-package "languagetool" "20220514.309" "LanguageTool integration for grammar and spell check"
  '((emacs "27.0")
    (request "0.3.2"))
  :commit "503d18bd3c074fe8f495cfa6a34ccca1ef6961ce" :authors
  '(("Joar Buitrago" . "jebuitragoc@unal.edu.co"))
  :maintainer
  '("Joar Buitrago" . "jebuitragoc@unal.edu.co")
  :keywords
  '("grammar" "text" "docs" "tools" "convenience" "checker")
  :url "https://github.com/PillFall/Emacs-LanguageTool.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
