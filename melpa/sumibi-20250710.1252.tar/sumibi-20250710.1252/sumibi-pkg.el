;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250710.1252"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (mozc           "0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "4778d1010003cbd009bd5bc2595fdf394483a87a"
  :revdesc "4778d1010003"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
