;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260309.1547"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "add72000e580aaf80e64195412747181fc95d231"
  :revdesc "add72000e580"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
