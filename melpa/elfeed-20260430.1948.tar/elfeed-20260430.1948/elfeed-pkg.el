;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260430.1948"
  "An Emacs Atom/RSS feed reader."
  '((emacs "27.1"))
  :url "https://github.com/skeeto/elfeed"
  :commit "d96c8640cafc0cc1dec5f0d0c9ac613fcc9ce334"
  :revdesc "d96c8640cafc"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
