;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiktoken" "20240103.340"
  "Count BPE Tokens."
  '((emacs "28.0")
    (f     "0.20.0"))
  :url "https://github.com/zkry/tiktoken.el"
  :commit "1dec1547024c10f32cd49129f937fa1d3ee39d01"
  :revdesc "1dec1547024c"
  :keywords '("tools"))
