(define-package "dirvish" "20220516.1701" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "411c9192b7896575a1069e712d737348a998d5ff" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
