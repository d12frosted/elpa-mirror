;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etherpad" "20261115.1524"
  "Collaborative editing via Etherpad."
  '((emacs     "29.1")
    (websocket "1.12"))
  :url "https://codeberg.org/zzkt/ethermacs"
  :commit "08c855fba70aa00aab74dc070cbe250adc1a7768"
  :revdesc "08c855fba70a"
  :keywords '("comm" "etherpad" "collaborative editing")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
