;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20251107.458"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "c49d29bbe1864e9eac14bfefe241735eea2bfcfe"
  :revdesc "c49d29bbe186"
  :keywords '("hypermedia"))
