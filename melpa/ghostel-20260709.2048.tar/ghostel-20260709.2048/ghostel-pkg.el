;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260709.2048"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "3ca01b7e00bafe2605f1423952599938c32af82d"
  :revdesc "3ca01b7e00ba"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
