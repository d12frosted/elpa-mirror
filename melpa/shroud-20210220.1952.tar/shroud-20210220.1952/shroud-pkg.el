;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shroud" "20210220.1952"
  "Shroud secrets."
  '((emacs "25")
    (epg   "1.0.0")
    (s     "1.6.0")
    (bui   "1.2.0")
    (dash  "2.18.0"))
  :url "https://github.com/o-nly/emacs-shroud"
  :commit "2e6ff2bab4a1e798c090c9d7fbd90b7f3463d5c5"
  :revdesc "2e6ff2bab4a1"
  :keywords '("tools" "password")
  :authors '(("Amar Singh" . "nly@disroot.org"))
  :maintainers '(("Amar Singh" . "nly@disroot.org")))
