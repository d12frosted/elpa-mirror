;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-java" "20251112.638"
  "Java support for lsp-mode."
  '((emacs         "28.1")
    (lsp-mode      "6.0")
    (markdown-mode "2.3")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.0")
    (request       "0.3.0")
    (treemacs      "2.5")
    (dap-mode      "0.5"))
  :url "https://github.com/emacs-lsp/lsp-java"
  :commit "bdd55fe935888c325b0194ee1d9cbc41436cdc52"
  :revdesc "bdd55fe93588"
  :keywords '("languague" "tools"))
