(define-package "lsp-scheme" "20220805.1810" "Scheme support for lsp-mode"
  '((emacs "25.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "3c4f2ad5ed5da391d6ea2b6ec10e98f710e61cea" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
