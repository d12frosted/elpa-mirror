;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud" "20251023.2252"
  "A modular front-end for interacting with external debuggers."
  '((load-relative "1.3.1")
    (loc-changes   "1.2")
    (test-simple   "1.3.0")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud/"
  :commit "941f89d65b3c7fb7783b39f44f63e55b4b46da1b"
  :revdesc "941f89d65b3c"
  :keywords '("debugger" "gdb" "python" "perl" "go" "bash" "zsh" "bashdb" "zshdb" "remake" "trepan" "perldb" "pdb")
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
