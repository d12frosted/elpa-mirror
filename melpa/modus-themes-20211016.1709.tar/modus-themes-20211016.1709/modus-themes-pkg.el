(define-package "modus-themes" "20211016.1709" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "4fa0fcd47c14d933d38ec0f73fbacd05e8c5fe95" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
