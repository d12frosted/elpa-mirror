(define-package "midje-mode" "20170809.403" "Minor mode for running Midje tests in emacs"
  '((cider "0.1.4")
    (clojure-mode "1.0"))
  :commit "10ad5b6084cd03d5cd268b486a7c3c246d85535f")
;; Local Variables:
;; no-byte-compile: t
;; End:
