(define-package "cnfonts" "20211225.2154" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "d5f23825967c01493baa3d987a3a1eeb14ca21b6" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
