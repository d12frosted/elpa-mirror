(define-package "ox-hugo" "20220115.2319" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "268f16a0448ccc703ea76595e37b546ba634f5c0" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
