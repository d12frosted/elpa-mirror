;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260910.1444"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "c8d1ac5184158fb9fe84551a58a387b4d651c593"
  :revdesc "c8d1ac518415"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
