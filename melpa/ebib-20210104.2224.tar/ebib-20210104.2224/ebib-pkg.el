(define-package "ebib" "20210104.2224" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "7ea1f6884d27499eb52baa95d20c6c2b5b194ba3" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
