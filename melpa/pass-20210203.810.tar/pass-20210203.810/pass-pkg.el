(define-package "pass" "20210203.810" "Major mode for password-store.el"
  '((emacs "25")
    (password-store "2.1.0")
    (password-store-otp "0.1.5")
    (f "0.17"))
  :commit "5651da53137db9adcb125b4897c2fe27eeb4368d" :authors
  '(("Nicolas Petton" . "petton.nicolas@gmail.com")
    ("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Nicolas Petton" . "petton.nicolas@gmail.com"))
  :maintainer
  '("Nicolas Petton" . "petton.nicolas@gmail.com")
  :keywords
  '("password-store" "password" "keychain"))
;; Local Variables:
;; no-byte-compile: t
;; End:
