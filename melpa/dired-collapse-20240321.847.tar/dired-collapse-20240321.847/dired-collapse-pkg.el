(define-package "dired-collapse" "20240321.847" "Collapse unique nested paths in dired listing"
  '((dash "2.10.0")
    (f "0.19.0")
    (dired-hacks-utils "0.0.1"))
  :commit "7ae2366249656f9c6999a6074ab6a5e4ced34e5b" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("files"))
;; Local Variables:
;; no-byte-compile: t
;; End:
