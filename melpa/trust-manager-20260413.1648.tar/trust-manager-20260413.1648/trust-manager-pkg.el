;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "20260413.1648"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "b68eed8311881487ef0c60eb3c276330acd4c1ee"
  :revdesc "b68eed831188"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
