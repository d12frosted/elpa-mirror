;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "20260603.2154"
  "Interface to query and view results from org-roam."
  '((emacs         "28")
    (org-roam      "2.2.0")
    (s             "1.12.0")
    (magit-section "3.3.0")
    (transient     "0.4")
    (dash          "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "35900a7a97c459b6ded44d665d60c81ba2df6cc2"
  :revdesc "35900a7a97c4")
