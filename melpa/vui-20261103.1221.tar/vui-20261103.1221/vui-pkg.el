;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261103.1221"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "a2291635de9692a22243cb9d0e3f3b1c5b02b282"
  :revdesc "a2291635de96"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
