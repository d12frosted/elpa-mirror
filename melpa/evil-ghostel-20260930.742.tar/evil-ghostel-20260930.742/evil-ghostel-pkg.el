;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260930.742"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "f1860ff4c0db2f63f5aa7b7d55d0eeec98c49453"
  :revdesc "f1860ff4c0db"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
