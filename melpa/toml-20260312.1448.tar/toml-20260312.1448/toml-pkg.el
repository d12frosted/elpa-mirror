;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260312.1448"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "0b733e42afa655f507ea7a9eb7197345e51c6e74"
  :revdesc "0b733e42afa6"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
