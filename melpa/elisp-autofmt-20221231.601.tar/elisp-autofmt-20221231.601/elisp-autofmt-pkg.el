(define-package "elisp-autofmt" "20221231.601" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "95f99bc1d078cbc3a61ea914561bb6318d9be5f3" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
