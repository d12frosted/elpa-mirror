;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260514.29"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "55a72cc3128719af6ae850ea9483d4b92dad46fa"
  :revdesc "55a72cc31287"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
