;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260404.1148"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "49ec87926943ef077c3c649b851a9e4bf65cb00f"
  :revdesc "49ec87926943"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
