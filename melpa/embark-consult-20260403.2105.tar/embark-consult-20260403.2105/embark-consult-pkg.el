;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark-consult" "20260403.2105"
  "Consult integration for Embark."
  '((emacs   "29.1")
    (compat  "30")
    (embark  "1.1")
    (consult "3.2"))
  :url "https://github.com/oantolin/embark"
  :commit "f9ed4c2b5e2afe8c14b8b56fcf28349a57a25102"
  :revdesc "f9ed4c2b5e2a"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
