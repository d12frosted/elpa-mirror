(define-package "modus-themes" "20210707.1005" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "26d63e2ce7bc8df09a10cc6897c5d7989d12b4ec" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
