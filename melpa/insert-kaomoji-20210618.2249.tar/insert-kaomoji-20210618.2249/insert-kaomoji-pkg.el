(define-package "insert-kaomoji" "20210618.2249" "Easily insert kaomojis"
  '((emacs "24.4"))
  :commit "25b74d527cef00f6a49985161a8caaf62faa887c" :authors
  '(("Philip K." . "philip@warpmail.net"))
  :maintainer
  '("Philip K." . "philip@warpmail.net")
  :keywords
  '("wp")
  :url "https://git.sr.ht/~zge/kaomoji")
;; Local Variables:
;; no-byte-compile: t
;; End:
