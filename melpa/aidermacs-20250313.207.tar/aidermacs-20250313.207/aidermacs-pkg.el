;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250313.207"
  "AI pair programming with Aider."
  '((emacs "29.1"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "02acb8ac63cd730085c315340dcd51db4c547e35"
  :revdesc "02acb8ac63cd"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
