(define-package "citre" "20220130.538" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "d7b6428da289c2f63a7a97f4eaba5b76616a09ce" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
