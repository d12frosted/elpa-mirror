(define-package "org-tidy" "20230829.53" "A minor mode to tidy org-mode buffers"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "11f71638710d4c0fefd9bf7293145b9b24a7d70e" :authors
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainers
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainer
  '("Xuqing Jia" . "jxq@jxq.me")
  :keywords
  '("convenience" "org")
  :url "https://github.com/jxq0/org-tidy")
;; Local Variables:
;; no-byte-compile: t
;; End:
