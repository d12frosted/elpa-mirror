(define-package "universal-sidecar-elfeed-score" "20230925.9" "Show Elfeed Score information in sidecar"
  '((emacs "25.1")
    (universal-sidecar "1.0.0")
    (elfeed "3.4.1")
    (elfeed-score "1.2.6"))
  :commit "dfcd0cd9d8f1e7fc3d8d4d1ed1da32d657acb088" :authors
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainer
  '("Samuel W. Flint" . "me@samuelwflint.com")
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar")
;; Local Variables:
;; no-byte-compile: t
;; End:
