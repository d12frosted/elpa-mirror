;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250930.2106"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "3ba329d652ee6934660d35789706dae15c6511f9"
  :revdesc "3ba329d652ee"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
