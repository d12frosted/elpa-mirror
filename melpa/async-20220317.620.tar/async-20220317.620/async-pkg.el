(define-package "async" "20220317.620" "Asynchronous processing in Emacs"
  '((emacs "24.4"))
  :commit "5463ef80d2f252f23125320ef48c0fee42454bb9" :authors
  '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainer
  '("John Wiegley" . "jwiegley@gmail.com")
  :keywords
  '("async")
  :url "https://github.com/jwiegley/emacs-async")
;; Local Variables:
;; no-byte-compile: t
;; End:
