(define-package "mini-echo" "20231101.1542" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "3cc55960f4d835490cf35f9d2cbf80fbb0626225" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
