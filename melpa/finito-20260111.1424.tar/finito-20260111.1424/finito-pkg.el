;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "finito" "20260111.1424"
  "View and collect books."
  '((emacs     "28.1")
    (dash      "2.19.1")
    (request   "0.3.2")
    (f         "0.2.0")
    (s         "1.12.0")
    (transient "0.3.0")
    (graphql   "0.1.1")
    (async     "1.9.3"))
  :url "https://github.com/LaurenceWarne/finito.el"
  :commit "4f768de5ce9784ca54125c5056b0a026ba2eb42c"
  :revdesc "4f768de5ce97"
  :keywords '("outlines"))
