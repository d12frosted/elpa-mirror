;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcmpl-homebrew" "20200911.742"
  "Pcomplete for homebrew."
  ()
  :url "https://github.com/suzzvv/pcmpl-homebrew"
  :commit "a2044042dd498abad1dc06162a8ee0d70314ca40"
  :revdesc "a2044042dd49"
  :keywords '("pcomplete" "homebrew" "tools" "cask" "services")
  :authors '(("zwild" . "judezhao@outlook.com"))
  :maintainers '(("zwild" . "judezhao@outlook.com")))
