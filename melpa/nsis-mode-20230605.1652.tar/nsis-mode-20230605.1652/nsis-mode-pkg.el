(define-package "nsis-mode" "20230605.1652" "NSIS-mode" 'nil :commit "a3bc65b373d74acfad8eb4ef8072fd7059b6ace9" :authors
  '(("Matthew L. Fidler"))
  :maintainers
  '(("Matthew L. Fidler"))
  :maintainer
  '("Matthew L. Fidler")
  :keywords
  '("nsis")
  :url "http://github.com/mlf176f2/nsis-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
