(define-package "rutils" "20210805.608" "R utilities with transient"
  '((emacs "26.1")
    (ess "18.10.1")
    (transient "0.3.0"))
  :commit "e216db63a2ccd50fe5c80679fc5b929dd2c114e8" :authors
  '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainer
  '("Shuguang Sun" . "shuguang79@qq.com")
  :keywords
  '("convenience")
  :url "https://github.com/ShuguangSun/rutils.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
