;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-insert-plus" "20260117.1852"
  "Use insert and append as operators."
  '((emacs "24.4")
    (evil  "1.14.0"))
  :url "https://github.com/yad-tahir/evil-insert-plus"
  :commit "088eca49f37c54113d29020f25b53d4e01290ab2"
  :revdesc "088eca49f37c"
  :keywords '("emulations" "textvim" "editing")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
