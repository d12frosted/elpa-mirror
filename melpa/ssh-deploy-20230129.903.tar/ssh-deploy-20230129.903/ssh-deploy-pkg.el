(define-package "ssh-deploy" "20230129.903" "Deployment via Tramp, global or per directory."
  '((emacs "25"))
  :commit "94b56c0428fa0c788578161edc9e7992b13cd400" :authors
  '(("Christian Johansson" . "christian@cvj.se"))
  :maintainers
  '(("Christian Johansson" . "christian@cvj.se"))
  :maintainer
  '("Christian Johansson" . "christian@cvj.se")
  :keywords
  '("tools" "convenience")
  :url "https://github.com/cjohansson/emacs-ssh-deploy")
;; Local Variables:
;; no-byte-compile: t
;; End:
