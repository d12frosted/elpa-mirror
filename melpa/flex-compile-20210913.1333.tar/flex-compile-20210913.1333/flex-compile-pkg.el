(define-package "flex-compile" "20210913.1333" "Run, evaluate and compile across many languages"
  '((emacs "26.1")
    (dash "2.17.0")
    (buffer-manage "0.11"))
  :commit "f597addcfb77737ae54da56536c4601c2814e70a" :authors
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("compilation" "integration" "processes")
  :url "https://github.com/plandes/flex-compile")
;; Local Variables:
;; no-byte-compile: t
;; End:
