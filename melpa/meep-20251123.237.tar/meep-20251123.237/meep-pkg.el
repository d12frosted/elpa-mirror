;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251123.237"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "da2a20bfd4dc03fff497f44e865ac0bc21eba580"
  :revdesc "da2a20bfd4dc"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
