(define-package "apdl-mode" "20211004.527" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "48c66a669523d45de7e066d42933c1c7ca965bf4" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
