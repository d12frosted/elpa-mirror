;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20260115.1253"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4"))
  :url "https://emacs-guix.gitlab.io/website/"
  :commit "bccba0c1e6446f10075d8eaebae9eef6e67159a3"
  :revdesc "bccba0c1e644"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
