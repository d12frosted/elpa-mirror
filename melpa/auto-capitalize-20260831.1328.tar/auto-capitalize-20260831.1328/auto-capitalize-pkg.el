;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "20260831.1328"
  "Automatic capitalization with batteries included."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/abdulnafe-t/auto-capitalize.el"
  :commit "18bab2a936ba4077389c9061a8e02f50a40b19c8"
  :revdesc "18bab2a936ba"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
