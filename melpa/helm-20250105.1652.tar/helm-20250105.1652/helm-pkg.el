;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250105.1652"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "39e585745b5c68a3dd08262458d37c9d6879948b"
  :revdesc "39e585745b5c"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
