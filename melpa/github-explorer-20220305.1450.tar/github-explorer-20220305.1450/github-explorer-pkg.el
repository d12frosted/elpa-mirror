;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-explorer" "20220305.1450"
  "Explore a GitHub repository on the fly."
  '((emacs   "25")
    (graphql "0"))
  :url "https://github.com/TxGVNN/github-explorer"
  :commit "49e5c350169b556deaabdcb67e9440bd4d5b4f8b"
  :revdesc "49e5c350169b"
  :keywords '("comm")
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
