;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "path-helper" "20181208.2229"
  "Set PATH environment variables from config files."
  '((emacs "24"))
  :url "https://github.com/arouanet/path-helper"
  :commit "34538affb3f341b3c56a875bb094ddb2b859a8ef"
  :revdesc "34538affb3f3"
  :keywords '("tools" "unix")
  :authors '(("Arnaud Rouanet" . "arnaud@rouanet.org"))
  :maintainers '(("Arnaud Rouanet" . "arnaud@rouanet.org")))
