;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260818.257"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "2a1fc8de4aa28f4199bc73f8c31206c8137dec0f"
  :revdesc "2a1fc8de4aa2"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
