;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-modeline" "20250222.1334"
  "A modeline segment for EXWM workspaces."
  '((emacs "27.1")
    (exwm  "0.26"))
  :url "https://github.com/SqrtMinusOne/exwm-modeline"
  :commit "c933baccb8535a81ebae06a5dc4245b801c47f06"
  :revdesc "c933baccb853"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
