(define-package "helm" "20210917.657" "Helm is an Emacs incremental and narrowing framework"
  '((emacs "25.1")
    (async "1.9.4")
    (popup "0.5.3")
    (helm-core "3.8.0"))
  :commit "33b60d88926d36c3610616a42bf722623ae66978" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://github.com/emacs-helm/helm")
;; Local Variables:
;; no-byte-compile: t
;; End:
