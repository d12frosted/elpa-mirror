;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polymode" "20250525.1736"
  "Extensible framework for multiple major modes."
  '((emacs "25"))
  :url "https://github.com/polymode/polymode"
  :commit "e87bf5b4da2934875fae643cb5d74b66c5b45711"
  :revdesc "e87bf5b4da29"
  :keywords '("languages" "multi-modes" "processes")
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
