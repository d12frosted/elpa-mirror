;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-navigate" "20260602.1236"
  "Directional navigation between blank-space blocks."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spatial-navigate"
  :commit "22213dace66bfde31568d6e6e4df7b195cc6e4f1"
  :revdesc "22213dace66b"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
