;;; eca-util.el --- ECA (Editor Code Assistant) util -*- lexical-binding: t; -*-
;; Copyright (C) 2025 Eric Dallo
;;
;; SPDX-License-Identifier: Apache-2.0
;;
;; This file is not part of GNU Emacs.
;;
;;; Commentary:
;;
;;  The ECA (Editor Code Assistant) utils.
;;
;;; Code:

(require 'cl-lib)
(require 'color)
(require 'dash)
(require 'f)
(require 'transient nil t)

(declare-function eca-api-notify "eca-api")

(defcustom eca-buttons-allow-mouse nil
  "Whether to allow mouse clicks on ECA buttons."
  :type 'boolean
  :group 'eca)

(defcustom eca-find-root-for-buffer-function #'eca-find-root-for-buffer
  "Function for getting the ECA's session root."
  :type 'function
  :group 'eca)

(defcustom eca-worktree-mode 'merged
  "How ECA handles git worktrees of the same repository.

- `merged': all worktrees share one ECA session and chat history.
  New worktrees are dynamically added to the running session when
  a file inside them is visited.  This is the default since 0.110.0
  and is efficient when you want a unified AI context across branches.

- `isolated': each worktree gets its own independent ECA session,
  chat history, and cache.  Toggle-window, resume, and agent context
  all scope to the individual worktree.  This matches the behaviour
  prior to 0.110.0 and is preferred for parallel worktree workflows."
  :type '(choice (const :tag "Merged (shared session per repo)" merged)
          (const :tag "Isolated (independent session per worktree)" isolated))
  :group 'eca)

(defun eca-uuid ()
  "Return a fresh v4-style UUID string.

Uses Emacs's pseudo-random generator reseeded from system entropy
on every call so consecutive ids inside the same Emacs session do
not repeat across, e.g., quickly-clicked \"+ new chat\" tabs.  Used
for client-generated `chatId' values sent to the eca server."
  (random t)
  (format "%04x%04x-%04x-4%03x-%01x%03x-%04x%04x%04x"
          (random 65536) (random 65536)
          (random 65536)
          (logand (random 65536) #x0fff)
          (logior #x8 (logand (random 16) #x3))
          (logand (random 65536) #x0fff)
          (random 65536) (random 65536) (random 65536)))

(defun eca-assoc (map key val)
  "Return a new MAP with KEY associated to flat plist VAL, replacing any existing."
  (cons (cons key val)
        (cl-remove-if (lambda (pair) (equal (car pair) key)) map)))

(defun eca-dissoc (map key)
  "Return a new MAP with KEY removed."
  (cl-remove-if (lambda (pair) (equal (car pair) key)) map))

(defun eca-get (map key)
  "Return the plist value associated with KEY in MAP, or nil."
  (let ((pair (cl-find key map :key #'car :test #'equal)))
    (when pair (cdr pair))))

(defun eca-vals (map)
  "Return the plist values from MAP."
  (-map #'cdr map))

(defun eca-plist-equal (plist1 plist2)
  "Check if PLIST1 is equal to PLIST2."
  (and (= (length plist1) (length plist2))
       (cl-loop for (key val) on plist1 by #'cddr
                always (equal val (plist-get plist2 key)))))

(defun eca--property-run-bounds (pos prop)
  "Return (START . END) of the run of text property PROP at POS, or nil.
The run is the text around POS whose PROP value is `eq' to the one
at POS, so two adjacent items propertized separately are two runs."
  (when-let* ((value (and pos (get-text-property pos prop))))
    (cons (if (and (> pos (point-min))
                   (eq value (get-text-property (1- pos) prop)))
              (previous-single-property-change pos prop nil (point-min))
            pos)
          (next-single-property-change pos prop nil (point-max)))))

(defun eca--text-change-unsafe-p ()
  "Return non-nil when a timer must not change buffer text now.
Timers also run while Lisp code waits, e.g. on the `sit-for' that
emojify calls from `jit-lock-functions'.  Redisplay is then still in
progress, with `inhibit-redisplay' bound, and changing the text of a
buffer under it can crash Emacs (#335).  Code changing text silently
binds `inhibit-modification-hooks': a change made there would skip
the change hooks, e.g. jit-lock's.  Timers run from the command loop
see neither binding, so a deferred change gets made soon after."
  (or inhibit-redisplay inhibit-modification-hooks))

(defvar-local eca--session-id-cache nil)

(defvar eca--sessions '())
(defvar eca--session-ids 0)

(defvar eca-session-deleting-functions nil
  "Functions called before an ECA session is deleted.
Each function receives the session being deleted.")

(defvar eca-sessions-updated-hook nil
  "Normal hook run after a ECA session is created or deleted.")

(cl-defstruct eca--session
  ;; id to manage multiple eca sessions
  (id nil)

  ;; The status of this session
  (status 'stopped)

  ;; The eca <process>
  (process nil)

  ;; the chat buffers
  (chats '())

  (last-chat-buffer nil)

  ;; The chat currently being hydrated by a chat/open request.
  (opening-chat-id nil)

  ;; A list of workspace folders of this session
  (workspace-folders '())

  ;; The workspace folders this session started with, which key its
  ;; chats storage on the server, so a restart starts with them again.
  (initial-workspace-folders '())

  ;; The chats being reopened after a restart, see
  ;; `eca-chat-restore-chats', or nil.
  (chat-restore nil)

  ;; A plist of request method names (strings) -> handlers used when
  ;; receiving requests from server.
  (request-handlers '())

  ;; A plist of client request ids -> handlers for pending requests used when
  ;; receiving responses from server.
  (response-handlers '())

  ;; The suported models by the server.
  (models '())

  ;; The servers and their status.
  (tool-servers '())

  ;; The supported chat agents by the server.
  (chat-agents nil)

  ;; The available variants for the current model.
  (chat-variants '())

  ;; Selection defaults inherited by new chats in this session.
  (chat-default-model nil)
  (chat-default-agent nil)
  (chat-default-variant nil)
  (chat-default-trust nil)

  ;; The welcome message for new chats.
  (chat-welcome-message "")

  ;; The global config file path the server reads, from `initialize'.
  (global-config-path nil)

  ;; Init progress tasks alist: (taskId . plist) where plist has :title :type
  (init-tasks nil)

  ;; Provider status list from providers/list response.
  (providers nil)

  ;; Background jobs list from jobs/list and jobs/updated.
  (jobs nil))

(defun eca-find-root-for-buffer ()
  "Return the path that first matches the following:
- Buffer is within an existent eca session workspace-folder.
- Use `project` to return the project root if available.
- Otherwise return buffer file or `default-directory`."
  (let* ((default-path (or (when buffer-file-name (file-name-directory buffer-file-name))
                           default-directory))
         (existing-sessions-folders (-keep (lambda (session)
                                             (--first (or (f-same? it default-path)
                                                          (f-ancestor-of? it default-path))
                                                      (eca--session-workspace-folders session)))
                                           (eca-vals eca--sessions))))
    (or (when existing-sessions-folders
          (-max-by (lambda (a b)
                     (> (length (expand-file-name a))
                        (length (expand-file-name b))))
                   existing-sessions-folders))
        (when (fboundp 'project-current)
          (when-let* ((project (project-current)))
            (if (fboundp 'project-root)
                (project-root project)
              (car (with-no-warnings
                     (project-roots project))))))
        default-path)))

(defvar eca--git-common-dir-cache (make-hash-table :test 'equal)
  "Cache of expanded dir -> git common dir (or `:none') lookups.
Avoids spawning a git process on every `eca-session' resolution;
cleared whenever a session is created or deleted.")

(defun eca--git-common-dir (dir)
  "Return the absolute git common dir for DIR, or nil if not in a git repo.
Uses `git rev-parse --git-common-dir` to find the shared git
directory, which is the same for all worktrees of a repository.
Results are cached in `eca--git-common-dir-cache' since this can
be called repeatedly (e.g. resolving sessions from timers) and
spawning git each time causes visible lag (#275)."
  (let* ((dir (expand-file-name dir))
         (cached (gethash dir eca--git-common-dir-cache)))
    (if cached
        (unless (eq cached :none) cached)
      (let* ((default-directory dir)
             (output (ignore-errors
                       (string-trim
                        (with-output-to-string
                          (with-current-buffer standard-output
                            ;; TRAMP-aware, no intermediate shell,
                            ;; stderr discarded.
                            (process-file "git" nil '(t nil) nil
                                          "rev-parse" "--git-common-dir"))))))
             (result (when (and output
                                (not (string-empty-p output))
                                ;; Git < 2.5 echoes the flag back literally
                                (not (string= output "--git-common-dir")))
                       (expand-file-name output default-directory))))
        (puthash dir (or result :none) eca--git-common-dir-cache)
        result))))

(defun eca--paths-nested-p (a b)
  "Return non-nil when paths A and B are equal or nested.
Two paths are nested when one is an ancestor directory of the
other.  Both paths are normalized via `file-truename' and
compared with a trailing slash to avoid prefix false-positives
\(e.g. \"/foo\" matching \"/foobar\")."
  (let ((a (file-name-as-directory (file-truename (expand-file-name a))))
        (b (file-name-as-directory (file-truename (expand-file-name b)))))
    (or (string= a b)
        (string-prefix-p a b)
        (string-prefix-p b a))))

(defun eca--session-for-worktree (root)
  "Find a session whose workspace shares the same git repo as ROOT.
Returns the session if ROOT is a git worktree (or regular repo) that
shares the same `git-common-dir' as one of an existing session's
workspace folders AND is not in an ancestor/descendant relationship
with that folder.  True git worktrees are always sibling directories,
never nested, so a match where one path contains the other indicates
ROOT is merely a sub- or super-directory of an existing folder rather
than a separate worktree (typical case: $HOME is a dotfiles git repo
and the user starts ECA on a subdirectory, or vice versa).  Returns
nil otherwise."
  (when-let* ((root-common-dir (eca--git-common-dir root)))
    (-first (lambda (session)
              (--first (when-let* ((folder-common-dir (eca--git-common-dir it)))
                         (and (string= (file-truename root-common-dir)
                                       (file-truename folder-common-dir))
                              (not (eca--paths-nested-p root it))))
                       (eca--session-workspace-folders session)))
            (eca-vals eca--sessions))))

(defun eca--session-add-workspace-folder (session folder)
  "Add FOLDER to SESSION's workspace-folders and notify the server."
  (let ((folder (directory-file-name (expand-file-name folder))))
    (unless (--first (string= it folder)
                     (eca--session-workspace-folders session))
      (setf (eca--session-workspace-folders session)
            (append (eca--session-workspace-folders session) (list folder)))
      (eca-api-notify
       session
       :method "workspace/didChangeWorkspaceFolders"
       :params (list :event
                     (list :added (vector
                                   (list :uri (eca--path-to-uri folder)
                                         :name (file-name-nondirectory (directory-file-name folder))))
                           :removed [])))
      (eca-info "Added workspace folder: %s" folder))))

(defun eca--session-remove-workspace-folder (session folder)
  "Remove FOLDER from SESSION's workspace-folders and notify the server.
Refuses to remove the last remaining folder, since the Emacs client
resolves buffers to sessions by matching against workspace-folders and
an empty list would make the session unreachable.  In `merged' worktree
mode, a removed folder whose git-common-dir still matches another
folder in the session can be auto-re-added by `eca-session' the next
time a buffer under it is visited."
  (let* ((folder (directory-file-name (expand-file-name folder)))
         (folders (eca--session-workspace-folders session)))
    (cond
     ((not (--first (string= it folder) folders))
      (eca-warn "Workspace folder not found: %s" folder))
     ((<= (length folders) 1)
      (user-error "Cannot remove the last workspace folder"))
     (t
      (setf (eca--session-workspace-folders session)
            (cl-remove-if (lambda (it) (string= it folder)) folders))
      (eca-api-notify
       session
       :method "workspace/didChangeWorkspaceFolders"
       :params (list :event
                     (list :added []
                           :removed (vector
                                     (list :uri (eca--path-to-uri folder)
                                           :name (file-name-nondirectory (directory-file-name folder)))))))
      (eca-info "Removed workspace folder: %s" folder)))))

(defun eca--session-sync-workspace-folders (session folders)
  "Add and remove SESSION's workspace folders so they match FOLDERS.
Used once a restarted session is up: it starts with the folders the
previous one started with, keying the same chats storage on the
server, then gets the folders added or removed since back."
  (when folders
    (let ((folders (--map (directory-file-name (expand-file-name it))
                          folders)))
      (dolist (folder folders)
        (eca--session-add-workspace-folder session folder))
      (dolist (folder (eca--session-workspace-folders session))
        (unless (member folder folders)
          (eca--session-remove-workspace-folder session folder))))))

(defun eca-session ()
  "Return the session related to root of current buffer otherwise nil."
  (or (eca-get eca--sessions eca--session-id-cache)
      (let* ((root (directory-file-name
                    (expand-file-name (funcall eca-find-root-for-buffer-function))))
             (session (or (-first (lambda (session)
                                    (--first (string= it root)
                                             (eca--session-workspace-folders session)))
                                  (eca-vals eca--sessions))
                          ;; Worktree fallback: only in merged mode, find a session
                          ;; sharing the same git repo and add this worktree to it.
                          ;; In isolated mode each worktree gets its own session.
                          (when (eq eca-worktree-mode 'merged)
                            (when-let* ((worktree-session (eca--session-for-worktree root)))
                              (eca--session-add-workspace-folder worktree-session root)
                              worktree-session)))))
        (when session
          (setq-local eca--session-id-cache (eca--session-id session)))
        session)))

(defun eca-session-for-root (root)
  "Return the running session owning ROOT."
  (let ((root (directory-file-name (expand-file-name root))))
    (-first (lambda (session)
              (--first (or (f-same? it root)
                           (f-ancestor-of? it root))
                       (eca--session-workspace-folders session)))
            (eca-vals eca--sessions))))

(defun eca-create-session (workspace-roots)
  "Create a new ECA session for WORKSPACE-ROOTS."
  (clrhash eca--git-common-dir-cache)
  (let ((session (make-eca--session))
        (id (cl-incf eca--session-ids))
        (folders (-distinct (--map (directory-file-name (expand-file-name it))
                                   workspace-roots))))
    (setf (eca--session-id session) id)
    (setf (eca--session-workspace-folders session) folders)
    (setf (eca--session-initial-workspace-folders session)
          (copy-sequence folders))
    (setf (eca--session-chat-default-trust session)
          (and (boundp 'eca-chat-trust-enable)
               (symbol-value 'eca-chat-trust-enable)))
    (setq eca--sessions (eca-assoc eca--sessions id session))
    (run-hooks 'eca-sessions-updated-hook)
    session))

(defun eca--session-project-name (session)
  "Return the project name for SESSION.
Extracts the last directory component from the first
workspace folder.  Falls back to \"unknown\"."
  (if-let* ((roots (eca--session-workspace-folders session))
            (root (car roots)))
      (file-name-nondirectory (directory-file-name root))
    "unknown"))

(defun eca-delete-session (session)
  "Delete SESSION from existing sessions."
  (when session
    (with-demoted-errors "eca-session-deleting-functions: %S"
      (run-hook-with-args 'eca-session-deleting-functions session))
    (clrhash eca--git-common-dir-cache)
    (setq eca--sessions
          (eca-dissoc eca--sessions (eca--session-id session)))
    (run-hooks 'eca-sessions-updated-hook)))

(defun eca-assert-session-running (session)
  "Assert that a eca SESSION is running."
  (unless session
    (user-error "ECA must be running, no session found, start with `eca` command")))

(defvar eca--uri-file-prefix (pcase system-type
                               (`windows-nt "file:///")
                               (_ "file://"))
  "Prefix for a file-uri.")

(defun eca--path-to-uri (path)
  "Convert a PATH to a uri."
  (concat eca--uri-file-prefix
          (--> path
               (expand-file-name it)
               (or (file-remote-p it 'localname) it)
               (eca--path-local-to-remote it))))

(defun eca--uri-to-path (uri)
  "Convert a file URI to a file path."
  (let ((path (cond
               ((string-prefix-p "file:///" uri)
                (url-unhex-string
                 (substring uri (if (eq system-type 'windows-nt) 8 7))))

               ((string-prefix-p "file://" uri)
                (url-unhex-string (substring uri 6)))

               (t uri))))
    (eca--path-remote-to-local path)))

(defcustom eca-local-to-remote-prefix-map nil
  "Alist of (LOCAL-PATH . REMOTE-PATH) for Docker or remote servers.
The longest matching prefix wins.

  \\='((\"/Users/me/dev\" . \"/workspace\")
    (\"/Users/me/dev/special\" . \"/custom\"))
  ;; /Users/me/dev/project → /workspace/project
  ;; /Users/me/dev/special → /custom"
  :type '(alist :key-type string :value-type string)
  :group 'eca)

(defvar eca--path-session nil
  "Session used to derive TRAMP path mappings.
Bound dynamically while handling server messages so path
translation uses the session owning the message instead of
resolving one from the current buffer.")

(defun eca--path-mappings ()
  "Return merged path mappings for translation.
Combines explicit `eca-local-to-remote-prefix-map' entries with
implicit mappings derived from TRAMP workspace folders.  Each
TRAMP folder like \"/docker:container:/workspace/project\" yields
a mapping (\"/docker:container:/workspace/project\" . \"/workspace/project\").
Folders come from `eca--path-session' when bound, otherwise from
the current buffer's session."
  (append
   eca-local-to-remote-prefix-map
   (when-let* ((session (or eca--path-session
                            (ignore-errors (eca-session))))
               (folders (eca--session-workspace-folders session)))
     (delq nil
           (mapcar
            (lambda (folder)
              (when (file-remote-p folder)
                (cons folder (file-local-name folder))))
            folders)))))

(defun eca--path--translate (path from-fn to-fn expand-from-p)
  "Translate PATH using explicit and TRAMP-derived path mappings.
FROM-FN extracts the side of each mapping to match against PATH;
TO-FN extracts the side to substitute in.  If EXPAND-FROM-P is
non-nil, expand the from-side path.  The longest matching prefix
wins; explicit user mappings take priority over TRAMP-derived ones
for equal-length prefixes."
  (let* ((ensure-slash (lambda (s) (if (string-suffix-p "/" s) s (concat s "/"))))
         (strip-slash (lambda (s) (if (string-suffix-p "/" s) (substring s 0 -1) s)))
         (sorted (sort (copy-sequence (eca--path-mappings))
                       (lambda (a b)
                         (let ((la (length (funcall from-fn a)))
                               (lb (length (funcall from-fn b))))
                           (if (= la lb)
                               (let ((explicit-a (member a eca-local-to-remote-prefix-map))
                                     (explicit-b (member b eca-local-to-remote-prefix-map)))
                                 (cond
                                  ((and explicit-a (not explicit-b)) t)
                                  ((and (not explicit-a) explicit-b) nil)
                                  (t (> (length (funcall to-fn a))
                                        (length (funcall to-fn b))))))
                             (> la lb)))))))
    (or (seq-some
         (lambda (m)
           (let* ((from-raw (funcall from-fn m))
                  (to-raw (funcall to-fn m))
                  (from (funcall ensure-slash
                                 (if (and expand-from-p (not (file-remote-p from-raw)))
                                     (expand-file-name from-raw)
                                   from-raw)))
                  (to-expanded (if (and (not expand-from-p) (not (file-remote-p to-raw)))
                                   (expand-file-name to-raw)
                                 to-raw)))
             (cond
              ((string= path (funcall strip-slash from))
               (funcall strip-slash to-expanded))
              ((string-prefix-p from path)
               (concat (funcall ensure-slash to-expanded) (substring path (length from)))))))
         sorted)
        path)))

(defun eca--path-local-to-remote (path)
  "Translate a local Emacs PATH to a remote path.
First strips any TRAMP prefix from PATH, then applies path
mappings (explicit `eca-local-to-remote-prefix-map' plus TRAMP
workspace folder mappings).  The longest matching prefix wins."
  (let ((local-path (or (file-remote-p path 'localname) path)))
    (eca--path--translate (expand-file-name local-path) #'car #'cdr t)))

(defun eca--path-remote-to-local (path)
  "Translate a remote server PATH to a local Emacs path.
Applies path mappings (explicit `eca-local-to-remote-prefix-map'
plus TRAMP workspace folder mappings).  The longest matching prefix
wins; explicit user mappings take priority over TRAMP-derived ones."
  (eca--path--translate path #'cdr #'car nil))

(defun eca-info (format &rest args)
  "Display eca info message with FORMAT with ARGS."
  (message "%s :: %s" (propertize "ECA" 'face 'success) (apply #'format format args)))

(defun eca-warn (format &rest args)
  "Display eca warn message with FORMAT with ARGS."
  (message "%s :: %s" (propertize "ECA" 'face 'warning) (apply #'format format args)))

(defun eca-error (format &rest args)
  "Display eca error message with FORMAT with ARGS."
  (message "%s :: %s" (propertize "ECA" 'face 'error) (apply #'format format args)))

(defun eca-safe-face-background (face &optional frame inherit)
  "Return background of FACE on FRAME, treating TTY sentinels as nil.
INHERIT is passed through to `face-background'.  On non-graphic
frames `face-background' returns the literal strings
\"unspecified-bg\" / \"unspecified-fg\" instead of nil, which
breaks callers that feed the result to `color-name-to-rgb' (e.g.
`color-lighten-name', `color-darken-name').  This wrapper maps
those sentinels back to nil so callers can short-circuit with
`when-let*' and friends."
  (let ((bg (face-background face frame inherit)))
    (unless (member bg '("unspecified-bg" "unspecified-fg"))
      bg)))

(defface eca-quota-warning-face
  '((t (:inherit warning)))
  "Face for subscription quota windows nearing their limit."
  :group 'eca)

(defface eca-quota-critical-face
  '((t (:inherit error)))
  "Face for subscription quota windows at or over their limit."
  :group 'eca)

(defun eca--quota-windows (quota)
  "Return the windows of the provider QUOTA as a list of plists."
  (append (plist-get quota :windows) nil))

(defun eca--quota-window-stale-p (window)
  "Return non-nil when the quota WINDOW reset time already passed.
Its usage is then outdated until the next request refreshes it."
  (when-let* ((resets-at (plist-get window :resetsAt)))
    (<= resets-at (float-time))))

(defun eca--quota-percent-face (percent)
  "Return the face for a quota usage of PERCENT, or nil when it is low."
  (cond
   ((not (numberp percent)) nil)
   ((>= percent 95) 'eca-quota-critical-face)
   ((>= percent 80) 'eca-quota-warning-face)))

(defun eca--format-duration-short (secs)
  "Format SECS as a short duration like \"2h 13m\" or \"3d 4h\"."
  (let ((secs (max 0 (floor secs))))
    (cond
     ((< secs 60) "<1m")
     ((< secs 3600) (format "%dm" (/ secs 60)))
     ((< secs 86400)
      (let ((h (/ secs 3600))
            (m (/ (mod secs 3600) 60)))
        (if (zerop m) (format "%dh" h) (format "%dh %dm" h m))))
     (t
      (let ((d (/ secs 86400))
            (h (/ (mod secs 86400) 3600)))
        (if (zerop h) (format "%dd" d) (format "%dd %dh" d h)))))))

(defun eca--quota-short-str (quota)
  "Return a compact QUOTA summary like \"5h 42% · 7d 13%\".
Each window part carries the `face' of its usage level, stale
windows show a dash instead of their outdated percentage."
  (mapconcat
   (lambda (window)
     (let ((label (plist-get window :label))
           (percent (plist-get window :usedPercent)))
       (if (or (eca--quota-window-stale-p window) (not (numberp percent)))
           (concat label " —")
         (let ((str (format "%s %d%%" label (round percent))))
           (if-let* ((face (eca--quota-percent-face percent)))
               (propertize str 'face face)
             str)))))
   (eca--quota-windows quota)
   " · "))

(defun eca--quota-reset-str (window)
  "Return the reset time description of the quota WINDOW, or nil if unknown.
For example \"resets in 2h 13m (14:00)\"."
  (when-let* ((resets-at (plist-get window :resetsAt)))
    (let ((remaining (- resets-at (float-time))))
      (if (<= remaining 0)
          "reset, refreshes on next request"
        (format "resets in %s (%s)"
                (eca--format-duration-short remaining)
                (format-time-string (if (< remaining 86400) "%H:%M" "%a %H:%M")
                                    (seconds-to-time resets-at)))))))

(defun eca--quota-window-lines (quota)
  "Return one descriptive line per window of QUOTA.
For example \"5h: 42% used · resets in 2h 13m (14:00)\"."
  (mapcar (lambda (window)
            (let ((percent (plist-get window :usedPercent))
                  (reset (eca--quota-reset-str window)))
              (concat (format "%s: %s used" (plist-get window :label)
                              (if (numberp percent) (format "%d%%" (round percent)) "?"))
                      (when reset (concat " · " reset)))))
          (eca--quota-windows quota)))

(defun eca--quota-updated-str (quota)
  "Return how long ago QUOTA was captured, like \"updated 3m ago\"."
  (let ((age (max 0 (floor (- (float-time) (or (plist-get quota :updatedAt) (float-time)))))))
    (cond
     ((< age 60) "updated just now")
     ((< age 3600) (format "updated %dm ago" (/ age 60)))
     ((< age 86400) (format "updated %dh ago" (/ age 3600)))
     (t (format "updated %dd ago" (/ age 86400))))))

(defun eca--quota-bar (percent width)
  "Return a bar of WIDTH characters filled up to PERCENT."
  (let* ((percent (min 100 (max 0 (or percent 0))))
         (filled (round (* width (/ percent 100.0)))))
    (concat (make-string filled ?█)
            (make-string (- width filled) ?░))))

;;;; Buttons

(defconst eca--button-tint 0.2
  "How much of its color tints the background of a button.")

(defvar eca--button-faces nil
  "Alist of (SOURCE . FACE), the faces drawing buttons as pills.
SOURCE is the face of the text of the buttons, or nil.")

(defun eca--button-source (text)
  "Return the face whose color the button TEXT takes, or nil.
That is the `font-lock-face' or `face' of TEXT, the first face of a
list of them."
  (let ((face (or (get-text-property 0 'font-lock-face text)
                  (get-text-property 0 'face text))))
    (if (consp face)
        (-first (lambda (f) (and (symbolp f) (facep f))) face)
      (and face (symbolp face) (facep face) face))))

(defun eca--tint-color (source alpha)
  "Return ALPHA of the color of face SOURCE over the default background.
ALPHA is between 0 and 1.  Return nil when one of the colors is
unknown, as on terminals that don't tell their colors."
  (let ((fg (face-foreground (or source 'default) nil t))
        (bg (eca-safe-face-background 'default nil t)))
    (when-let* (((not (member fg '("unspecified-fg" "unspecified-bg"))))
                (fg-rgb (and fg (color-name-to-rgb fg)))
                (bg-rgb (and bg (color-name-to-rgb bg))))
      (apply #'color-rgb-to-hex
             (append (cl-mapcar (lambda (f b) (+ (* alpha f) (* (- 1 alpha) b)))
                                fg-rgb bg-rgb)
                     '(2))))))

(defun eca--button-tint-color (source)
  "Return the background of buttons in face SOURCE, or nil.
That is `eca--button-tint' of the color of SOURCE over the default
background, see `eca--tint-color'."
  (eca--tint-color source eca--button-tint))

(defun eca--button-face-attributes (source)
  "Return the attributes of the face of buttons in face SOURCE.
They make a pill in the color of SOURCE, on a background tinted by
it, or in inverse video when the tint is unknown."
  (let ((tint (eca--button-tint-color source)))
    (append (list :inherit source :underline nil :weight 'bold
                  :slant 'normal :height 0.9)
            (if tint
                (list :background tint :inverse-video nil
                      ;; Inside the pill, a little out on its sides.
                      :box (list :line-width -2 :color tint))
              (list :background 'unspecified :inverse-video t :box nil)))))

(defun eca--button-fill-attributes (source)
  "Return the attributes of the fill of buttons in face SOURCE.
That is the background and edge of their pill, without the rest of
`eca--button-face-attributes', see `eca--button-fill-face'."
  (let ((tint (eca--button-tint-color source)))
    (if tint
        (list :background tint :box (list :line-width -2 :color tint))
      (list :background 'unspecified :box nil))))

(defun eca--button-fill-face (face)
  "Return the face filling the pills of buttons in FACE, or nil.
FACE is from `eca--button-face'.  Drawn again over the background of
the text of the buttons, as an overlay does, FACE itself would scale
their height again, as relative heights add up."
  (when (symbolp face)
    (or (get face 'eca--button-fill-face)
        (when-let* ((entry (rassq face eca--button-faces)))
          (let ((fill (intern (format "%s-fill" face))))
            (make-face fill)
            (set-face-documentation
             fill (format "Fill of the pills of the buttons in `%s'." face))
            (apply #'set-face-attribute fill nil
                   (eca--button-fill-attributes (car entry)))
            (put face 'eca--button-fill-face fill)
            fill)))))

(defun eca--refresh-button-faces (&rest _)
  "Recompute the faces of buttons from the colors of the current theme."
  (pcase-dolist (`(,source . ,face) eca--button-faces)
    (apply #'set-face-attribute face nil (eca--button-face-attributes source))
    (when-let* ((fill (eca--button-fill-face face)))
      (apply #'set-face-attribute fill nil (eca--button-fill-attributes source)))))

(defun eca--register-button-faces-refresh ()
  "Recompute the faces of buttons after a theme switch.
Emacs < 29 has no `enable-theme-functions', so advise `enable-theme'
and `disable-theme' there instead."
  (if (>= emacs-major-version 29)
      (progn
        (add-hook 'enable-theme-functions #'eca--refresh-button-faces)
        (add-hook 'disable-theme-functions #'eca--refresh-button-faces))
    (advice-add 'enable-theme :after #'eca--refresh-button-faces)
    (advice-add 'disable-theme :after #'eca--refresh-button-faces)))

(defun eca--button-face (source)
  "Return the face drawing as pills the buttons in face SOURCE.
It is made on first use, then follows theme switches."
  (or (alist-get source eca--button-faces)
      (let ((face (intern (format "eca-button-%s" (or source 'default)))))
        (make-face face)
        (set-face-documentation
         face (format "Face of buttons in `%s', drawn as pills." (or source 'default)))
        (apply #'set-face-attribute face nil (eca--button-face-attributes source))
        (push (cons source face) eca--button-faces)
        (apply #'set-face-attribute (eca--button-fill-face face) nil
               (eca--button-fill-attributes source))
        (eca--register-button-faces-refresh)
        face)))

(defun eca--button-pill (text)
  "Return TEXT padded and drawn as a pill, the look of buttons.
The pill takes the color of the face of TEXT, see `eca--button-face',
and keeps its other properties, the padding too.  Brackets around
TEXT, as in \"[Submit]\", are dropped since the pill tells it's a
button.  The pill gets its face as `eca-button-pill' too."
  (let* ((face (eca--button-face (eca--button-source text)))
         (label (if (string-match-p "\\`\\[[^]]*\\]\\'" text)
                    (substring text 1 -1)
                  text))
         (props (and (> (length label) 0) (text-properties-at 0 label)))
         (pill (concat (apply #'propertize " " props)
                       label
                       (apply #'propertize " " props))))
    (add-text-properties 0 (length pill)
                         (list 'face face 'font-lock-face face 'eca-button-pill face)
                         pill)
    pill))

(defun eca--buttonize (base-map text callback)
  "Return TEXT calling CALLBACK when actioned, its keymap inheriting BASE-MAP."
  (let ((km (make-composed-keymap (make-sparse-keymap) base-map))
        (callback-int (lambda (&rest _)
                        (interactive)
                        (funcall callback))))
    (when eca-buttons-allow-mouse
      (define-key km (kbd "<mouse-1>") callback-int))
    (define-key km (kbd "<return>") callback-int)
    (define-key km (kbd "RET") callback-int)
    (propertize text
                'eca-button-on-action callback
                'pointer 'hand
                'help-echo (string-trim (substring-no-properties text))
                'local-map km
                'keymap km)))

(defun eca-buttonize (base-map text callback)
  "Return TEXT as a button calling CALLBACK when actioned.
The button is drawn as a pill in the color of the face of TEXT, see
`eca--button-pill'.  Its keymap inherits BASE-MAP.  Links, like file
paths and URLs, use `eca-buttonize-link' instead."
  (eca--buttonize base-map (eca--button-pill text) callback))

(defun eca-buttonize-link (base-map text callback)
  "Return TEXT as a link calling CALLBACK when actioned.
Like `eca-buttonize', but TEXT keeps its look, as links like file
paths and URLs do.  Its keymap inherits BASE-MAP."
  (eca--buttonize base-map text callback))

;; `transient' is optional, see its `require' above.
(when (featurep 'transient)
  (transient-define-prefix eca--transient-menu-prefix ()
    "ECA transient menu."
    [["Chat"
      ("n" "New" eca-chat-new)
      ("e" "Resume" eca-chat-resume)
      ("f" "Select" eca-chat-select)
      ("c" "Clear" eca-chat-clear)
      ("r" "Reset" eca-chat-reset)
      ("k" "Delete" eca-chat-delete)
      ("R" "Rename" eca-chat-rename)
      ("t" "Talk" eca-chat-talk)
      ("i" "Compose prompt in buffer" eca-chat-compose)
      ("I" "Inline prompt at point" eca-chat-inline-prompt)
      ("T" "Toggle inline overlays" eca-chat-inline-toggle-overlays)
      ("p" "Repeat prompt" eca-chat-repeat-prompt)
      ("C" "Clear prompt" eca-chat-clear-prompt)
      ("m" "Select model" eca-chat-select-model)
      ("M" "Toggle MCP server" eca-mcp-toggle-server)
      ("v" "Select variant" eca-chat-select-variant)
      ("b" "Change agent" eca-chat-select-agent)
      ("o" "Open/close chat window" eca-chat-toggle-window)
      ("a" "Accept all pending tool calls" eca-chat-tool-call-accept-all)
      ("!" "Accept all pending tool calls and remember" eca-chat-tool-call-accept-all-and-remember)
      ("s" "Add to system prompt" eca-chat-add-context-to-system-prompt)
      ("u" "Add to user prompt" eca-chat-add-context-to-user-prompt)
      ("d" "Drop from system prompt" eca-chat-drop-context-from-system-prompt)
      ("A" "Accept next pending tool call" eca-chat-tool-call-accept-next)]

     ["Navigation"
      ("N h" "Message history" eca-chat-timeline)
      ("N c" "Chat" eca)
      ("N s" "Settings" eca-settings)
      ("N m" "MCP details" eca-mcp-details)
      ("N e" "Show stderr (logs)" eca-show-stderr)
      ("N E" "Show emacs errors" eca-show-errors)]

     ["Server"
      ("S r" "Restart" eca-restart)
      ("S s" "Stop" eca-stop)]

     ["Workspace"
      ("W a" "Add folder" eca-chat-add-workspace-root)
      ("W r" "Remove folder" eca-chat-remove-workspace-root)]]))

(defun eca-transient-menu ()
  "Open the ECA transient menu.
Requires the `transient' package."
  (interactive)
  (unless (featurep 'transient)
    (user-error "Install the `transient' package to use the ECA menu"))
  (condition-case err
      (transient-setup 'eca--transient-menu-prefix)
    (error
     (user-error
      "ECA menu failed: %s. Try: M-x package-reinstall RET transient"
      (error-message-string err)))))

(provide 'eca-util)
;;; eca-util.el ends here
