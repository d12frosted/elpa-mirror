;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260101.1343"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "abc41419e9eff719ccc8a156defb0e6db3b7f460"
  :revdesc "abc41419e9ef"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
