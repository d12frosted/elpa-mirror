(define-package "spdx" "20210806.1933" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d179efd9106f969c856c206d917c7614d73ee2cb" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
