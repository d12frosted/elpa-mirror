;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250624.1747"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "b7325aa91d1299dfd6fc432c0d0696d131082b6a"
  :revdesc "b7325aa91d12"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
