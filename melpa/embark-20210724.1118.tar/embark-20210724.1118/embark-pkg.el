(define-package "embark" "20210724.1118" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "be03ce9ce1630b32e29cc50118d058c05696cb35" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
