(define-package "x509-mode" "20230112.1912" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "066d292965211cbe46b5777c639f337ef253b4af" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
