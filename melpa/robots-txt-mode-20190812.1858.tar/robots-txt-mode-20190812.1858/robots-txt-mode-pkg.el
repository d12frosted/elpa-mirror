;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "robots-txt-mode" "20190812.1858"
  "Major mode for editing robots.txt."
  ()
  :url "https://github.com/emacs-php/robots-txt-mode"
  :commit "8bf67285a25a6756607354d184e36583f2847e7d"
  :revdesc "8bf67285a25a"
  :keywords '("languages" "comm" "web")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
