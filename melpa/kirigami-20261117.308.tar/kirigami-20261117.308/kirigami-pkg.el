;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20261117.308"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "237b57c68a9e08245c19a32b1d08680f78b5a3ad"
  :revdesc "237b57c68a9e"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
