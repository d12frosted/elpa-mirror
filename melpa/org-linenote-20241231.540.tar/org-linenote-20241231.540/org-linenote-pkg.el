;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-linenote" "20241231.540"
  "A package inspired by VSCode Linenote."
  '((emacs         "29.1")
    (projectile    "2.8.0")
    (vertico       "1.7")
    (eldoc         "1.11")
    (lsp-mode      "9.0.0")
    (fringe-helper "1.0.1"))
  :url "https://github.com/seokbeomKim/org-linenote"
  :commit "3ed444c34e0bab4be1e53250e3601464bb07d1a2"
  :revdesc "3ed444c34e0b"
  :keywords '("tools" "note" "org")
  :authors '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers '(("Jason Kim" . "sukbeom.kim@gmail.com")))
