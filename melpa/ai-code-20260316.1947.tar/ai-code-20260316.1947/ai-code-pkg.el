;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260316.1947"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "1b2a0da415518e8b5167fd0a0b08746ba458a03c"
  :revdesc "1b2a0da41551"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
