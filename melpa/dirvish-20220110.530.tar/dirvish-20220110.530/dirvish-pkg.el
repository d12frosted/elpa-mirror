(define-package "dirvish" "20220110.530" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "cbe76feca0b11dfe80124007adf8b67f15c085b9" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
