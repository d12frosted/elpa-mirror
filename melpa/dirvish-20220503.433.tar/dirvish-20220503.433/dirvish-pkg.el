(define-package "dirvish" "20220503.433" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "4b1254f0f6a34093014b5cb3f3af30c1de1ad705" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
