;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260826.615"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "38f8e90f7df711096b9942b4cb9080f4c2e052b6"
  :revdesc "38f8e90f7df7"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
