;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-markdown" "20260928.809"
  "Preview Markdown LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.18.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "1944a44ddf02d1507b381ffdf9460a9f248b5d63"
  :revdesc "1944a44ddf02"
  :keywords '("tex" "markdown" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
