(define-package "diff-hl" "20220620.1309" "Highlight uncommitted changes using VC"
  '((cl-lib "0.2")
    (emacs "25.1"))
  :commit "711f3f3ed9ad6b2362416b4ca1e0e304d42350d2" :authors
  '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("vc" "diff")
  :url "https://github.com/dgutov/diff-hl")
;; Local Variables:
;; no-byte-compile: t
;; End:
