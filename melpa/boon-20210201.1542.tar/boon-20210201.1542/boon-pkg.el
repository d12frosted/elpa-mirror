(define-package "boon" "20210201.1542" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (expand-region "0.10.0")
    (dash "2.12.0")
    (multiple-cursors "1.3.0"))
  :commit "d612497d833185ce6b879492821d7cc513a0eea5")
;; Local Variables:
;; no-byte-compile: t
;; End:
