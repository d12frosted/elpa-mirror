(define-package "soria-theme" "20230102.1459" "A xoria256 theme with some colors from openSUSE"
  '((emacs "25.1"))
  :commit "7669770034f773bd96a71bb5e0cde93a8f0495e9" :authors
  '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainer
  '("Miquel Sabaté Solà" . "mikisabate@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/mssola/soria")
;; Local Variables:
;; no-byte-compile: t
;; End:
