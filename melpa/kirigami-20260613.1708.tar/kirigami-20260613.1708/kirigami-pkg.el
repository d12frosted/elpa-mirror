;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260613.1708"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "4065d5c48f5c63b25a43945833a647a2a7dedf48"
  :revdesc "4065d5c48f5c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
