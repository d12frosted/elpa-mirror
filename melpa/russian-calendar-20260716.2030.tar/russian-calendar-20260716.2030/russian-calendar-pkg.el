;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20260716.2030"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "99077f02546a1a3619c46f95be926ceada155478"
  :revdesc "99077f02546a"
  :keywords '("calendar" "holidays"))
