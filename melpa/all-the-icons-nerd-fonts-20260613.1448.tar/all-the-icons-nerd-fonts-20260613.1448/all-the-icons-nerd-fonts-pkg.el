;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-the-icons-nerd-fonts" "20260613.1448"
  "Nerd font integration for all-the-icons."
  '((emacs         "28.1")
    (all-the-icons "5.0")
    (nerd-icons    "0.0.1"))
  :url "https://github.com/mohkale/all-the-icons-nerd-fonts"
  :commit "5a59837193e842111a7660db6196abe1f90ca3ad"
  :revdesc "5a59837193e8"
  :keywords '("convenience" "lisp")
  :authors '(("Mohsin Kaleem" . "mohkale@gmail.com"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@gmail.com")))
