;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-browse-commit" "20260311.511"
  "Browse pull/merge requests from magit-blame."
  '((emacs "25.1")
    (magit "3.0.0"))
  :url "https://github.com/bbw9n/magit-browse-commit"
  :commit "aedf47b76642566de7992f3d6834c7fc8b77d68c"
  :revdesc "aedf47b76642"
  :keywords '("vc" "tools" "git")
  :authors '(("Angeldswang" . "bbw9nio@gmail.com"))
  :maintainers '(("Angeldswang" . "bbw9nio@gmail.com")))
