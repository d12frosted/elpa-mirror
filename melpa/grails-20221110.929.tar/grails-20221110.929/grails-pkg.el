;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grails" "20221110.929"
  "Minor mode for Grails projects."
  '((emacs "24"))
  :url "https://github.com/lifeisfoo/emacs-grails"
  :commit "3019f86e555ee94388795a0475cfa213e3897bbb"
  :revdesc "3019f86e555e"
  :authors '(("Alessandro Miliucci" . "lifeisfoo@gmail.com"))
  :maintainers '(("Alessandro Miliucci" . "lifeisfoo@gmail.com")))
