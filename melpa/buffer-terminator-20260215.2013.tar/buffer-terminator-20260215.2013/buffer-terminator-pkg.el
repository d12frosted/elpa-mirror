;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260215.2013"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "22be91a46d07add6aa949d608d6aa561051f3866"
  :revdesc "22be91a46d07"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
