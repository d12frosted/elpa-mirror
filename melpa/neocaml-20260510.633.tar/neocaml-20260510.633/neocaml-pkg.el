;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260510.633"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "06f70b77b8417b3965f8c17188aaec1a38c2d6ec"
  :revdesc "06f70b77b841"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
