;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20260104.1113"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/dicom"
  :commit "4353dfab9d175322813556b5484d182c5ffe6cbd"
  :revdesc "4353dfab9d17"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
