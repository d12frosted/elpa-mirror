(define-package "mono-complete" "20230326.316" "Completion suggestions with multiple back-ends"
  '((emacs "28.1"))
  :commit "4ca1a156f4a1a568e43cf9c9d97ef1bd39985e6c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mono-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
