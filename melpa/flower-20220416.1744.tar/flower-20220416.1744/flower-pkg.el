(define-package "flower" "20220416.1744" "Emacs task tracker client."
  '((emacs "24.4")
    (clomacs "0.0.4"))
  :commit "047846409867b2dd0ba4e2047a414b498680cd9c" :authors
  '(("Sergey Sobko" . "flower@tpg.am"))
  :maintainer
  '("Sergey Sobko" . "flower@tpg.am")
  :keywords
  '("hypermedia" "outlines" "tools" "vc")
  :url "https://github.com/FlowerAutomation/flower")
;; Local Variables:
;; no-byte-compile: t
;; End:
