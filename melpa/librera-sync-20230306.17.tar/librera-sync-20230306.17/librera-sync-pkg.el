(define-package "librera-sync" "20230306.17" "Sync document's position with Librera Reader for Android"
  '((emacs "26.1")
    (f "0.17")
    (dash "2.12.0"))
  :commit "29e158fc478d5817dffc4045b067feed4c3d0dbe" :authors
  '(("Dmitriy Pshonko" . "jumper047@gmail.com"))
  :maintainers
  '(("Dmitriy Pshonko" . "jumper047@gmail.com"))
  :maintainer
  '("Dmitriy Pshonko" . "jumper047@gmail.com")
  :keywords
  '("multimedia" "sync")
  :url "https://github.com/jumper047/librera-sync")
;; Local Variables:
;; no-byte-compile: t
;; End:
