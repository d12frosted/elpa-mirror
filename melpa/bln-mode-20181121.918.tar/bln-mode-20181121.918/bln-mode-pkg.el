;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bln-mode" "20181121.918"
  "Binary line navigation minor mode for cursor movement in long lines."
  ()
  :url "https://github.com/mgrachten/bln-mode"
  :commit "a601b0bf975dd1432f6552ab6afe3f4f71133b4a"
  :revdesc "a601b0bf975d"
  :keywords '("motion" "location" "cursor" "convenience"))
