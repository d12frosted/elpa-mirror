(define-package "popper" "20211220.2222" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "d5ab9b2c4185f029425bb6ba1dc718de65f4db86" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
