(define-package "keg" "20211020.543" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "d98113b8c32ad0164b05f92bec447d64268e311e" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
