;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250601.1155"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "7c585deb8f52f38b1f5057ee6119490be146e967"
  :revdesc "7c585deb8f52"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
