;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-cmake" "20260427.1906"
  "A cmake backend for project.el."
  '((emacs "30.1"))
  :url "https://github.com/lucius-martius/project-cmake"
  :commit "5c7b00d19000d5ec7d7d3a0c419b4f509b122dd9"
  :revdesc "5c7b00d19000"
  :keywords '("tools" "convenience")
  :authors '(("Lucius Martius" . "lucius.martius@mailbox.org"))
  :maintainers '(("Lucius Martius" . "lucius.martius@mailbox.org")))
