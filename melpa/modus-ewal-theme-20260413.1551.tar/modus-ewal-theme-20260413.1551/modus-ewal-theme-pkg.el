;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-ewal-theme" "20260413.1551"
  "Modus theme that uses pywal colors powered by ewal."
  '((emacs        "25.1")
    (modus-themes "5.2.0")
    (ewal         "0.2.1"))
  :url "https://github.com/deadendpl/modus-ewal-theme"
  :commit "4e52d98c95fb506daa2eec35c6141171f686649d"
  :revdesc "4e52d98c95fb"
  :keywords '("faces" "theme")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
