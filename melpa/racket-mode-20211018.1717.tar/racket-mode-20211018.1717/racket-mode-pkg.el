(define-package "racket-mode" "20211018.1717" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "21704fba064129970cb1acbe66af56e238cde49c" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
