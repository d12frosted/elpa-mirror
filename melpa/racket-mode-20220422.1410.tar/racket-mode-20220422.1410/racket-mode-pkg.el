(define-package "racket-mode" "20220422.1410" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "db8b07a634b10db56ad7bb8c914fd2b9479b2ac5" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
