(define-package "jq-ts-mode" "20231022.1757" "Tree-sitter support for jq buffers"
  '((emacs "29.1"))
  :commit "977fc1f17f26e9a007cef7cc1941756ef9a384f6" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("jq" "languages" "tree-sitter")
  :url "https://github.com/nverno/jq-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
