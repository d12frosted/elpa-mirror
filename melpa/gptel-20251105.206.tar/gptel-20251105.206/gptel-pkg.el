;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251105.206"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "7c8d9c8496afa50bf03f2dd7fabeefe9449cf381"
  :revdesc "7c8d9c8496af"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
