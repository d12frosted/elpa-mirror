;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ego" "20200803.1101"
  "A static site generator based on org mode, forked from org-page."
  '((emacs    "24.5")
    (ht       "1.5")
    (mustache "0.22")
    (htmlize  "1.47")
    (org      "8.0")
    (dash     "2.0.0"))
  :url "https://github.com/emacs-china/EGO"
  :commit "211c4cb2af2582849d9df984fb2346deecaf79be"
  :revdesc "211c4cb2af25"
  :keywords '("org-mode" "convenience" "beautify")
  :authors '(("Feng Shu" . "tumashuAT163.com")
             ("Kelvin Hu" . "iniDOTkelvinATgmailDOTcom")
             ("Kuangdash" . "kuangdashAT163.com"))
  :maintainers '(("Feng Shu" . "tumashuAT163.com")
                 ("Kelvin Hu" . "iniDOTkelvinATgmailDOTcom")
                 ("Kuangdash" . "kuangdashAT163.com")))
