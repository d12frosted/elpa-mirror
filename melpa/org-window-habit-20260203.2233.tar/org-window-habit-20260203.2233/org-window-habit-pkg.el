;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20260203.2233"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "22f74d132057767bef9eca48326a7b5fab11456d"
  :revdesc "22f74d132057"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
