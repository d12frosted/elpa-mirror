;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250426.749"
  "A modern file manager based on dired mode."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "7926fec51b8d31a13f65b24b49fab814c1ac75c5"
  :revdesc "7926fec51b8d"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
