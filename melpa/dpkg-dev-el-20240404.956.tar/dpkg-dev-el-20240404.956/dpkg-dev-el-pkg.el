(define-package "dpkg-dev-el" "20240404.956" "startup file for the elpa-dpkg-dev-el package" 'nil :commit "b9d0223da04ed56b5f90210237b5c71afd03076e" :authors
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainer
  '("Peter S Galbraith" . "psg@debian.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
