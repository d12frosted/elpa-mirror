;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260706.1336"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (compat      "31.0.0.0")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b33815ec93e04a928e2c0d6bed5c2e9cc16aa405"
  :revdesc "b33815ec93e0")
