;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20261026.2216"
  "Pure Elisp HTTP server."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "f413c8ea511add76cca298e39eb20fb492504485"
  :revdesc "f413c8ea511a"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
