;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260222.634"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "479b050f3db3f4f24577977c7f85016cf0bf5db7"
  :revdesc "479b050f3db3"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
