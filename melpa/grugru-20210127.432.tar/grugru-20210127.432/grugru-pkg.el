(define-package "grugru" "20210127.432" "Rotate text at point"
  '((emacs "24.4"))
  :commit "4ac2bf3877e3af7d23ace3165b9c8ed536ff4832" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
