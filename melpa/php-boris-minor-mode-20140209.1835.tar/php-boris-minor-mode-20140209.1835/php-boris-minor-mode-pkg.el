;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-boris-minor-mode" "20140209.1835"
  "A minor mode to evaluate PHP code in the Boris repl."
  '((php-boris "0.0.1")
    (highlight "0"))
  :url "https://github.com/steckerhalter/php-boris-minor-mode"
  :commit "8648eba604e4ff82ef6594a2c5ee4cb4825e6235"
  :revdesc "8648eba604e4"
  :keywords '("php" "repl" "eval"))
