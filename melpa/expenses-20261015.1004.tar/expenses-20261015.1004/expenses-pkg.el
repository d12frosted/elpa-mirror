;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expenses" "20261015.1004"
  "Record and view expenses."
  '((emacs     "28.1")
    (dash      "2.19.1")
    (ht        "2.3")
    (transient "0.3.7"))
  :url "https://github.com/md-arif-shaikh/expenses"
  :commit "60e5b5528099d1632b901c1b1cd1086f2489146c"
  :revdesc "60e5b5528099"
  :keywords '("expense tracking" "convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
