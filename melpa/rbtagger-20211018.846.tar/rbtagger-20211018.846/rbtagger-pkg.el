(define-package "rbtagger" "20211018.846" "Ruby tagging tools"
  '((emacs "25.1"))
  :commit "b3d4a5b30d09bcc3ef3bf2148a3874328fd44b23" :authors
  '(("Thiago Araújo" . "thiagoaraujos@gmail.com"))
  :maintainer
  '("Thiago Araújo" . "thiagoaraujos@gmail.com")
  :keywords
  '("languages" "tools")
  :url "https://www.github.com/thiagoa/rbtagger")
;; Local Variables:
;; no-byte-compile: t
;; End:
