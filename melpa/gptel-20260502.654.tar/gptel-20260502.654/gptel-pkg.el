;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260502.654"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "9ce7c3ce7b763108c899e5d8ff57c8be87c1d0c9"
  :revdesc "9ce7c3ce7b76"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
