;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260215.2106"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "11051563d85ef988e22493e3130e09a655872b85"
  :revdesc "11051563d85e"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
