(define-package "flutter" "20201202.138" "Tools for working with Flutter SDK"
  '((emacs "24.4"))
  :commit "696228a619f6078b16f9f77071112f6ad2a25c4e" :keywords
  ("languages")
  :authors
  (("Aaron Madlon-Kay"))
  :maintainer
  ("Aaron Madlon-Kay")
  :url "https://github.com/amake/flutter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
