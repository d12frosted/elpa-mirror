;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260117.1621"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "f8d36e545cba296ccb6ac88caf785cef329f2515"
  :revdesc "f8d36e545cba"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
