(define-package "apdl-mode" "20211001.2103" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "e82c69cfdfe806172d6295ec5a6d97d78d6fd235" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
