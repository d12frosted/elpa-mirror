(define-package "helm" "20230818.542" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.3")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "b8e9509490e17cc0f23d267f7c5385868d59daee" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
