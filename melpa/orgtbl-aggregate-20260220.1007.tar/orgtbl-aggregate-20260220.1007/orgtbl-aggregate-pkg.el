;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260220.1007"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "32d78921e9068d607eda97143dd0eb9208a3c4e4"
  :revdesc "32d78921e906"
  :keywords '("data" "extensions"))
