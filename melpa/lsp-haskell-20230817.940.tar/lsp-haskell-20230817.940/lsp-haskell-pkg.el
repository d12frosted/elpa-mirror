(define-package "lsp-haskell" "20230817.940" "Haskell support for lsp-mode"
  '((emacs "27.1")
    (lsp-mode "3.0")
    (haskell-mode "16.1"))
  :commit "918ffa2516a59c90f909b584f7c9968716c0e006" :keywords
  '("haskell")
  :url "https://github.com/emacs-lsp/lsp-haskell")
;; Local Variables:
;; no-byte-compile: t
;; End:
