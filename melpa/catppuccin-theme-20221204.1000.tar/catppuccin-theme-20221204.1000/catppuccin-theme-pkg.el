(define-package "catppuccin-theme" "20221204.1000" "Catppuccin Theme"
  '((emacs "25.1"))
  :commit "116cdbb6105286c59dcdccb31333935cadd982f5" :authors
  '(("pspiagicw"))
  :maintainer
  '("Name" . "namesexistsinemails@gmail.com")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
