(define-package "gnosis" "20240717.524" "Spaced Repetition System"
  '((emacs "27.2")
    (emacsql "20240124")
    (compat "29.1.4.2"))
  :commit "a7c85363850b96176f502eecdc2a9d7b046c355c" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions")
  :url "https://thanosapollo.org/projects/gnosis")
;; Local Variables:
;; no-byte-compile: t
;; End:
