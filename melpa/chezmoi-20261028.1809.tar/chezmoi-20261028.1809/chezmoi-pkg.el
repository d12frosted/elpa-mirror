;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chezmoi" "20261028.1809"
  "A package for interacting with chezmoi."
  '((emacs "27.1"))
  :url "http://www.github.com/tuh8888/chezmoi.el"
  :commit "3ffac6f99f2c8aefbc8dcfc8ada608cc2eb73f50"
  :revdesc "3ffac6f99f2c"
  :keywords '("vc"))
