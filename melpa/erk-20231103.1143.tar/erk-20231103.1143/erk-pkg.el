(define-package "erk" "20231103.1143" "Elisp (GitHub) Repository Kit"
  '((emacs "28.1")
    (auto-compile "1.2.0")
    (dash "2.18.0")
    (license-templates "0.1.3"))
  :commit "2edc49b7c2749bd60af808e285fe92b48285cc1a" :authors
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainers
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainer
  '("Positron Solutions" . "contact@positron.solutions")
  :keywords
  '("convenience" "programming")
  :url "http://github.com/positron-solutions/elisp-repo-kit")
;; Local Variables:
;; no-byte-compile: t
;; End:
