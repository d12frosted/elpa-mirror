;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260223.2314"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "4b1e1899bfd20b8d2bde294b7d3008367d435be0"
  :revdesc "4b1e1899bfd2"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
