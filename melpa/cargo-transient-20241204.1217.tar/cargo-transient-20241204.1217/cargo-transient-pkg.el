;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cargo-transient" "20241204.1217"
  "A transient UI for Cargo, Rust's package manager."
  '((emacs "28.1"))
  :url "https://github.com/peterstuart/cargo-transient"
  :commit "b75511f911189b6b6c47976dd970eeb80ccfb3ee"
  :revdesc "b75511f91118"
  :authors '(("Peter Stuart" . "peter@peterstuart.org"))
  :maintainers '(("Peter Stuart" . "peter@peterstuart.org")))
