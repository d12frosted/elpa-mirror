(define-package "org-link-beautify" "20230806.741" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1"))
  :commit "0971b910dcaeed62f6a0afd5c31585a510d4eeb6" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
