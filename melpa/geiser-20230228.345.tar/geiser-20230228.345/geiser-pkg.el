(define-package "geiser" "20230228.345" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (project "0.8.1"))
  :commit "bd12f2dc6c5949e260f094fb60737498cd0ae9a5" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
