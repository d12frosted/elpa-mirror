;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20260627.1319"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "e60be7084d5395617565531efab49718fe7c1a36"
  :revdesc "e60be7084d53"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
