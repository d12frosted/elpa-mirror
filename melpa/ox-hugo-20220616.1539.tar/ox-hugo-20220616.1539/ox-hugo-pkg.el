(define-package "ox-hugo" "20220616.1539" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "26.3")
    (tomelr "0.4.3"))
  :commit "85d11219a58d3a7927d7fe67144987a574fa54aa" :authors
  '(("Kaushal Modi" . "kaushal.modi@gmail.com")
    ("Matt Price" . "moptop99@gmail.com"))
  :maintainer
  '("Kaushal Modi" . "kaushal.modi@gmail.com")
  :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
