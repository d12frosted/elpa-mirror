;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unkillable-scratch" "20221015.1323"
  "Disallow the \\*scratch\\* buffer from being killed."
  '((emacs "24"))
  :url "https://github.com/EricCrosson/unkillable-scratch"
  :commit "6c752e4cd4762bb4bcde2b0b96f2e83740efd104"
  :revdesc "6c752e4cd476"
  :keywords '("convenience")
  :authors '(("Eric Crosson" . "eric.s.crosson@utexas.com"))
  :maintainers '(("Eric Crosson" . "eric.s.crosson@utexas.com")))
