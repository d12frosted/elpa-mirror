(define-package "modus-themes" "20220720.1937" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "6ae36d5214738e46c12b475124fc50ce1f60304f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
