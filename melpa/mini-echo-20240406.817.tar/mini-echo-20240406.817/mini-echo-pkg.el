(define-package "mini-echo" "20240406.817" "Echo buffer status in minibuffer window"
  '((emacs "29.1")
    (hide-mode-line "1.0.3"))
  :commit "8285a5f9e87be869b1853e7c10024ca5231ab0d9" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
