(define-package "spdx" "20221224.105" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d4656b822ebd8446c6a12bcfc4e7849dbeaac68f" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
