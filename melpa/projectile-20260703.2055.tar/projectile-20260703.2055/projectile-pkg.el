;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260703.2055"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "cff0717b3eb4bd8fc1609b7ea60ceab967dda973"
  :revdesc "cff0717b3eb4"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
