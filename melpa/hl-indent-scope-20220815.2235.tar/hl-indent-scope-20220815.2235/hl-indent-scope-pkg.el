(define-package "hl-indent-scope" "20220815.2235" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "1adcc08057de9eeea88ba3ed8f2c819a1493a3a2" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
