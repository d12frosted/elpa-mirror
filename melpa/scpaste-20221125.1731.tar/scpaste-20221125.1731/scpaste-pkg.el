(define-package "scpaste" "20221125.1731" "Paste to the web via scp."
  '((htmlize "1.39"))
  :commit "56c67ef63be86ef1f03e15a62ad17c3983e1e5dc" :authors
  '(("Phil Hagelberg"))
  :maintainers
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("convenience" "hypermedia")
  :url "https://git.sr.ht/~technomancy/scpaste")
;; Local Variables:
;; no-byte-compile: t
;; End:
