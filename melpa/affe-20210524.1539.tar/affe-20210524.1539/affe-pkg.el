(define-package "affe" "20210524.1539" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.7"))
  :commit "e976530a59ff072f821571b72216bdb2411039ed" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
