;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minimal-dashboard" "20260710.1120"
  "A very minimal dashboard plugin."
  '((emacs "27.1"))
  :url "https://github.com/dheerajshenoy/minimal-dashboard.el"
  :commit "260a074d44eaa9e49576dca24c09cca54f1e193d"
  :revdesc "260a074d44ea"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com"))
  :maintainers '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com")))
