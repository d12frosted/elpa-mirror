(define-package "dwim-shell-command" "20220813.1201" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "70bb61c3a03b3e9f9d9dee7f2bb73461bbc300e8" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
