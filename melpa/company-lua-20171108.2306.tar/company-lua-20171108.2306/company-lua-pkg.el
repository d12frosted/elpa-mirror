;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-lua" "20171108.2306"
  "Company backend for Lua."
  '((company  "0.8.12")
    (s        "1.10.0")
    (f        "0.17.0")
    (lua-mode "20151025"))
  :url "https://github.com/ptrv/company-lua"
  :commit "29f6819de4d691e5fd0b62893a9f4fbc1c6fcb52"
  :revdesc "29f6819de4d6"
  :authors '(("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Peter Vasil" . "mail@petervasil.net")))
