(define-package "with-editor" "20240623.1342" "Use the Emacsclient as $EDITOR"
  '((emacs "25.1")
    (compat "29.1.4.5"))
  :commit "f5157d615238eb17e62f45eefe921002c6340366" :authors
  '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev")
  :keywords
  '("processes" "terminals")
  :url "https://github.com/magit/with-editor")
;; Local Variables:
;; no-byte-compile: t
;; End:
