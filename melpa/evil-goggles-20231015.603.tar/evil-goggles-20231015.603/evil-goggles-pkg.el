(define-package "evil-goggles" "20231015.603" "Add a visual hint to evil operations"
  '((emacs "24.4")
    (evil "1.0.0"))
  :commit "0dc8183113f6f132ffdd7918ddf80bc744d47b00" :authors
  '(("edkolev" . "evgenysw@gmail.com"))
  :maintainers
  '(("edkolev" . "evgenysw@gmail.com"))
  :maintainer
  '("edkolev" . "evgenysw@gmail.com")
  :keywords
  '("emulations" "evil" "vim" "visual")
  :url "http://github.com/edkolev/evil-goggles")
;; Local Variables:
;; no-byte-compile: t
;; End:
