;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260609.751"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "4c4b8c3531ac7602cba48be3a36661a50a172e43"
  :revdesc "4c4b8c3531ac"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
