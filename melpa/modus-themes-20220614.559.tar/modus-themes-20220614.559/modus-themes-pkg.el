(define-package "modus-themes" "20220614.559" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "554a75fba9cdc6c2cacd1ee53bc33c963e7e8953" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
