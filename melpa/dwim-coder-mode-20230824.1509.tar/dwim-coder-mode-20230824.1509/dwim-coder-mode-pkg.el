(define-package "dwim-coder-mode" "20230824.1509" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "1e67f81ec09e2784634db60177a7859ef7aeaa7b" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
