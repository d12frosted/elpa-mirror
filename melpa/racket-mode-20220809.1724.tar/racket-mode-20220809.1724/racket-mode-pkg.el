(define-package "racket-mode" "20220809.1724" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "194fe14888fb653219ed6e605377884673fb6308" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
