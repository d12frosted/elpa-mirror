;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260607.1954"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "2cde4e63be55e17ffcb2a9d174ea58d163034e43"
  :revdesc "2cde4e63be55"
  :keywords '("data" "extensions"))
