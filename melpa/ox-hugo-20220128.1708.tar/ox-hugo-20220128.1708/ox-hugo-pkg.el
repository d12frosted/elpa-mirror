(define-package "ox-hugo" "20220128.1708" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "1b6b3dc8f9f310102d1a6862889c6ff5e0fb7b13" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
