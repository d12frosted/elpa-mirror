;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251126.1107"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "f4474129e6680558a8046daf92767a5c1acd5082"
  :revdesc "f4474129e668"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
