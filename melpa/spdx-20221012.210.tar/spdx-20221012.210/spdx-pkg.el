(define-package "spdx" "20221012.210" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "07cbc0cb5258e4f873a292d67646723c0542fac0" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
