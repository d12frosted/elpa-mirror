;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20251229.1827"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "0.3")
    (vui    "0.1"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "a0373417ecaed1f91e9b02be0482d4aedba2034f"
  :revdesc "a0373417ecae"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
