;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260803.839"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "1fbb981f837e0e85a68a8ca2b1aee63802bd4be1"
  :revdesc "1fbb981f837e"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
