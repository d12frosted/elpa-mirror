(define-package "dtache" "20220126.2157" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "8d4106e2f2b352e1b4d9585b888547414df9318c" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
