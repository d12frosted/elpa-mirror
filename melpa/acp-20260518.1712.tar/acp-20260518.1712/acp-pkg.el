;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20260518.1712"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "4f3b0945660aff4f23e686a785b874688133f43b"
  :revdesc "4f3b0945660a")
