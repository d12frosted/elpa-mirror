(define-package "darkman" "20230901.953" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "d4d0587a40c60b2f23b953f4702e55a335762a24" :authors
  '(("Taha Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainers
  '(("Taha Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Taha Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://darkman.grtcdr.tn")
;; Local Variables:
;; no-byte-compile: t
;; End:
