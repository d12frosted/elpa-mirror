(define-package "mastodon" "20221029.1039" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4"))
  :commit "2d25c1546c3d011b8b494c02277ac64eb91340d3" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
