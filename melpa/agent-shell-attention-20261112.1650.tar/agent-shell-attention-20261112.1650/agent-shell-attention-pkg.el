;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-attention" "20261112.1650"
  "Mode-line attention tracker for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.52.2"))
  :url "https://github.com/ultronozm/agent-shell-attention.el"
  :commit "cc099725c41f144975d37abf108a9c879c716171"
  :revdesc "cc099725c41f"
  :keywords '("convenience")
  :authors '(("Paul D. Nelson" . "ultrono@gmail.com"))
  :maintainers '(("Paul D. Nelson" . "ultrono@gmail.com")))
