(define-package "modus-themes" "20220104.723" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "fe5e1f7a16bae0df0cc305dcb3e5be32cf10f0b5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
