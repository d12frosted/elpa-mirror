;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser" "20260426.1850"
  "GNU Emacs and Scheme talk to each other."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://gitlab.com/emacs-geiser/"
  :commit "185191df527b51ce521084f8c32030e87dabb5e9"
  :revdesc "185191df527b"
  :keywords '("languages" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
