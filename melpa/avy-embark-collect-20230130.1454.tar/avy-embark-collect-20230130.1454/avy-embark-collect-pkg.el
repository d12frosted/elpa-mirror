(define-package "avy-embark-collect" "20230130.1454" "Use avy to jump to Embark Collect entries"
  '((emacs "25.1")
    (embark "0.9")
    (avy "0.5"))
  :commit "784ce24a1ad37459041418182af49565cad4974b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
