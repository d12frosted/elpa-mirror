;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260707.1225"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.42.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "4acafb728ee235505c30ae29292b4f0db6fa3387"
  :revdesc "4acafb728ee2"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
