;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241206.1602"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.74.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "4a998e5735086beb46d73945149c9a4d0d91f77c"
  :revdesc "4a998e573508")
