(define-package "epkg" "20210927.2133" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "366b48e05d4e18eebd6c9d5285d0b0696a5a66bf" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
