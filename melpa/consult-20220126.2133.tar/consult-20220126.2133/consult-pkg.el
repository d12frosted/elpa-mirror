(define-package "consult" "20220126.2133" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "0ddc5eb13e2f8a20d1a175205f9edc04792ec644" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
