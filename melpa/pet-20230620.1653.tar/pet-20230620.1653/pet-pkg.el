(define-package "pet" "20230620.1653" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0"))
  :commit "094b17a25e9e1fd4ab63c3120cce7a7ebb7410c9" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
