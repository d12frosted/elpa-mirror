;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-go-staticcheck" "20220804.1907"
  "Go staticcheck linter for flymake."
  '((emacs "26.1"))
  :url "https://github.com/s-kostyaev/flymake-go-staticcheck"
  :commit "9098f7e07ea6513667dc6af6d9ad2fa854464d20"
  :revdesc "9098f7e07ea6"
  :keywords '("languages" "tools")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
