(define-package "helm-core" "20220425.1625" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "2569c427f7cc2490e8ae2d9a849c9539ee1e4944" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
