;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-chat" "20260303.1256"
  "Emacs client for Lisp Chat."
  '((emacs     "26.1")
    (websocket "1.12"))
  :url "https://github.com/ryukinix/lisp-chat"
  :commit "3b620f1c6d673ed2c7b14e70fd31d9d68a90837e"
  :revdesc "3b620f1c6d67"
  :keywords '("comm" "chat" "lisp"))
