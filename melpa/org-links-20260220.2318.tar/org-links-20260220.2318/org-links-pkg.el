;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260220.2318"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "8f9b49d66244c0ef423389a9a0440c9888ebc5fa"
  :revdesc "8f9b49d66244"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
