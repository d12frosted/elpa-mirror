;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20250516.1349"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "9a7b1bf5ef888987af140c0af9747f3162176eca"
  :revdesc "9a7b1bf5ef88"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
