;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260321.1830"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "822f83bec8d7e195d3745561422868716c8bada3"
  :revdesc "822f83bec8d7"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
