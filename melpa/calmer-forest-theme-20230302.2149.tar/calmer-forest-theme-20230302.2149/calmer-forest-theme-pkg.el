;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calmer-forest-theme" "20230302.2149"
  "Darkish theme with green/orange tint."
  ()
  :url "https://github.com/caldwell/calmer-forest-theme"
  :commit "09fc50730ea386d3589863f8809e02e5bdd459cf"
  :revdesc "09fc50730ea3"
  :authors '(("David Caldwell" . "david@porkrind.org"))
  :maintainers '(("David Caldwell" . "david@porkrind.org")))
