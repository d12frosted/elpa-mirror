;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nova-theme" "20260202.501"
  "A dark, pastel color theme."
  '((emacs "24.3"))
  :url "https://github.com/muirmanders/emacs-nova-theme"
  :commit "6daa91ff091653cae7a94345ca579084f954effc"
  :revdesc "6daa91ff0916"
  :keywords '("theme" "dark" "nova" "pastel" "faces")
  :authors '(("Muir Manders" . "muir+emacs@mnd.rs"))
  :maintainers '(("Muir Manders" . "muir+emacs@mnd.rs")))
