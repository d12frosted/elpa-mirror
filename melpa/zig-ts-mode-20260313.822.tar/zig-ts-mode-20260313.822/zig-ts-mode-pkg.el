;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-ts-mode" "20260313.822"
  "Major mode for Zig code."
  '((emacs "29.1"))
  :url "https://codeberg.org/meow_king/zig-ts-mode"
  :commit "91d080cf66241abdf483e5947faa1d7fad82d7b8"
  :revdesc "91d080cf6624"
  :keywords '("zig" "languages" "tree-sitter")
  :authors '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers '(("meowking" . "mr.meowking@tutamail.com")))
