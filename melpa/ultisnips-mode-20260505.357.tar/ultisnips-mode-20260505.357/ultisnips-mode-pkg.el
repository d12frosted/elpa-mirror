;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "20260505.357"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "d4107d91e256579a930fc435e39c86e399dcc112"
  :revdesc "d4107d91e256"
  :keywords '("languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
