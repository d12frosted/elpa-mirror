;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-shorthands" "20251231.1535"
  "Visual abbreviations for symbol prefixes."
  '((emacs "29.1"))
  :url "https://github.com/gggion/visual-shorthands.el"
  :commit "5f190f1891755bffbff066b63a3a494299988094"
  :revdesc "5f190f189175"
  :keywords '("convenience")
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
