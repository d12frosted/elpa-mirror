(define-package "go-translate" "20240509.145" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "880c0fd60ed8251632320c258894d3c025fd0237" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
