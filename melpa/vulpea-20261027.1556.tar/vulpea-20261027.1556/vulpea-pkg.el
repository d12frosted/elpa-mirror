;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261027.1556"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "e8d00d8415275d5ac4606c8b1b3aeff2ee9699dd"
  :revdesc "e8d00d841527"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
