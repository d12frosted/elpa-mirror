(define-package "spdx" "20231129.103" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "030a24a42928ef4d79ee37aaefd103ea7dfa4b14" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
