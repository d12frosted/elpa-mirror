;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260914.1248"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "c7c35c39f9281e38bf1a24dfb9ff7a27f8d8de40"
  :revdesc "c7c35c39f928"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
