(define-package "sdml-mode" "20240716.1" "Major mode for SDML"
  '((emacs "28.1")
    (tree-sitter "0.18.0")
    (tree-sitter-indent "0.3"))
  :commit "d5d124e078f784d9f4e60b98eaf88f205d02a77c" :authors
  '(("Simon Johnston" . "johnstonskj@gmail.com"))
  :maintainers
  '(("Simon Johnston" . "johnstonskj@gmail.com"))
  :maintainer
  '("Simon Johnston" . "johnstonskj@gmail.com")
  :keywords
  '("languages" "tools")
  :url "https://github.com/johnstonskj/emacs-sdml-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
