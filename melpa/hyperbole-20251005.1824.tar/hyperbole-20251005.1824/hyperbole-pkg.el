;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251005.1824"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b038dc70ab871274ddc2e1997f6dcf69ec8764df"
  :revdesc "b038dc70ab87"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
