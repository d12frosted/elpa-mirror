(define-package "modus-themes" "20210830.849" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "af648e2d4b26a69b04041204018508dd60f0dfd3" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
