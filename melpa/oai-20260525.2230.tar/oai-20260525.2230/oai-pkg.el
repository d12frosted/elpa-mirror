;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260525.2230"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "e893e93ca7f2157233ffa3a19a7fc72f7f722009"
  :revdesc "e893e93ca7f2"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
