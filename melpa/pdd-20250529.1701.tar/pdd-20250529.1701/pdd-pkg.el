;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250529.1701"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "e11fc14050f4a1698899169ae8020a07afc116b7"
  :revdesc "e11fc14050f4"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
