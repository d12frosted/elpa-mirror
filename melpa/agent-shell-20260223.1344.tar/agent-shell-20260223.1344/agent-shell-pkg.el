;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260223.1344"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a1803cd7848284e69f8d1379afc9b76fbea52383"
  :revdesc "a1803cd78482")
