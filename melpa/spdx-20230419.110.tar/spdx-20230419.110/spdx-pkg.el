(define-package "spdx" "20230419.110" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "f8ec8996ff5e0f34f98aecd7363dc44c3a4e5a6f" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
