(define-package "worf" "20210809.1409" "A warrior does not press so many keys! (in org-mode)"
  '((swiper "0.11.0")
    (ace-link "0.1.0")
    (hydra "0.13.0")
    (zoutline "0.1.0"))
  :commit "e31759db6aae8a951c0843a4c855bccb626348c4" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/abo-abo/worf")
;; Local Variables:
;; no-byte-compile: t
;; End:
