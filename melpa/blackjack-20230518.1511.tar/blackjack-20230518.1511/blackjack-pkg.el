(define-package "blackjack" "20230518.1511" "The game of Blackjack"
  '((emacs "26.2"))
  :commit "376e1b5384f127973307ed4fc14b23af1d2a83a9" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
