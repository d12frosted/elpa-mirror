(define-package "kanagawa-theme" "20231204.1442" "An elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa"
  '((autothemer "0.2.18")
    (emacs "28.1"))
  :commit "4d7bb58a62a6d91f6cb49eeae6c9f5b5510f4357" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/Meritamen/kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
