;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250326.1419"
  "Cache metadata on all Org files."
  '((emacs   "29.1")
    (el-job  "2.4.1")
    (emacsql "4.2.0")
    (llama   "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "5b18de5e0297ae360c05c44f37107962ba620955"
  :revdesc "5b18de5e0297"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
