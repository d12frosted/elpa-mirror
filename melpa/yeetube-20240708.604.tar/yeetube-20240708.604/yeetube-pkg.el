(define-package "yeetube" "20240708.604" "Scrape YouTube - Play with mpv & Download with yt-dlp |"
  '((emacs "27.2")
    (compat "29.1.4.2"))
  :commit "5c0a3efd2fb5cc25a6a90741ad198e31fdb15640" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://thanosapollo.org/projects/yeetube/")
;; Local Variables:
;; no-byte-compile: t
;; End:
