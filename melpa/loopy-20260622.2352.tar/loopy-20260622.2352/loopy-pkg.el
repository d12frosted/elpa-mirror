;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260622.2352"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "09fecad848c8671902ceae7d74afecdd29a84ac5"
  :revdesc "09fecad848c8"
  :keywords '("extensions"))
