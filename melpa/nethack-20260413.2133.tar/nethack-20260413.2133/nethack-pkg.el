;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20260413.2133"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "4c729808271880da42adc9588eb9ec26b2534f65"
  :revdesc "4c7298082718"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
