(define-package "awk-ts-mode" "20231115.1037" "Major mode for awk using tree-sitter"
  '((emacs "29.1"))
  :commit "7b3f26d24be4732e001ae3a0e0db35111e68c38f" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("awk" "languages" "tree-sitter")
  :url "https://github.com/nverno/awk-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
