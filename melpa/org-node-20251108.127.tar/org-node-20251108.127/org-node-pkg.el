;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20251108.127"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "187dba00e51517c4f0e11740c1b81f2b281b455c"
  :revdesc "187dba00e515"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
