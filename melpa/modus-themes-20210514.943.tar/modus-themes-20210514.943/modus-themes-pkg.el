(define-package "modus-themes" "20210514.943" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "313970ced9dc10d0000478aac0538da7c35ab08b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
