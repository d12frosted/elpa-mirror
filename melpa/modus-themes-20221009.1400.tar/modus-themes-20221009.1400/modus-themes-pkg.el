(define-package "modus-themes" "20221009.1400" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "72e1b474841e9c69871154f89ba27c088f228e13" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
