(define-package "meow" "20211215.1758" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "1508d165b6990ce8b58f6d1b885c13a72e54748a" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
