(define-package "consult" "20221014.1631" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "8717aa24d83bcde75fddbc669dd45218c1335e9c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
