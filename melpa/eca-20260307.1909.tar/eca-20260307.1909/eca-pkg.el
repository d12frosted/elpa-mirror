;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260307.1909"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "3bd1bf40a51583e04e2415418ef848be4ffd52e7"
  :revdesc "3bd1bf40a515"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
