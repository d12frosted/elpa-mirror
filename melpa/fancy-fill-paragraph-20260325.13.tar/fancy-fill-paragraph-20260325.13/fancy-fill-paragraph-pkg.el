;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-fill-paragraph" "20260325.13"
  "Fancy paragraph fill."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-fancy-fill-paragraph"
  :commit "45817466187949e03f78eb678e855a66624a47e2"
  :revdesc "458174661879"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
