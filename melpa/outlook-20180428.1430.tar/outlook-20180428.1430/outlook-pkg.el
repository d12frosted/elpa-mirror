;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outlook" "20180428.1430"
  "Send emails in MS Outlook style."
  '((emacs "24.4"))
  :url "https://github.com/asavonic/outlook.el"
  :commit "b6a7a06b996d84647e8024412876e9e76ca884e4"
  :revdesc "b6a7a06b996d"
  :keywords '("mail"))
