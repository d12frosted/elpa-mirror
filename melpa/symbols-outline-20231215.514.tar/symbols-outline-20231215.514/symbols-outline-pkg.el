(define-package "symbols-outline" "20231215.514" "Display symbols (functions, variables, etc) in outline view"
  '((emacs "27.1"))
  :commit "ffd2311b57ca40f5e0d0aff3704f23972ef0dc93" :authors
  '(("Shihao Liu"))
  :maintainers
  '(("Shihao Liu"))
  :maintainer
  '("Shihao Liu")
  :keywords
  '("outlines")
  :url "https://github.com/liushihao456/symbols-outline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
