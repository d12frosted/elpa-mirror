(define-package "eldev" "20211203.2205" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "51af03cb5023d4bbd983adfbfabbbf8eca5a8315" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
