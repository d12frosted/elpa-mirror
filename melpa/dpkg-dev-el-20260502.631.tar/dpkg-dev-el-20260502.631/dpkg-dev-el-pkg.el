;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dpkg-dev-el" "20260502.631"
  "Startup file for the elpa-dpkg-dev-el package."
  '((emacs     "27.1")
    (debian-el "37.0"))
  :commit "1392d194b3ef00e58901163081df47ba06afba24"
  :revdesc "1392d194b3ef"
  :authors '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers '(("Peter S Galbraith" . "psg@debian.org")))
