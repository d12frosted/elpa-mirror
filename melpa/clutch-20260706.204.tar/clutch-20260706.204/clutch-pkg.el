;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260706.204"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "357494b049d3acedaa96e12de438b9990cdcbc2c"
  :revdesc "357494b049d3"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
