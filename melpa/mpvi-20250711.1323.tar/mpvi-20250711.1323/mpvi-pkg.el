;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250711.1323"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "71cd924361f652376aa2bee290bced3a0090d46d"
  :revdesc "71cd924361f6"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
