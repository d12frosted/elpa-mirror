;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261018.1933"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "4787ef9f568f758c8a875d34e0978f41ab2fdca1"
  :revdesc "4787ef9f568f"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
