;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20261008.1916"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "cdfcd6273ae336c8a4c39b308c2810b84e4766a9"
  :revdesc "cdfcd6273ae3"
  :keywords '("convenience" "lisp"))
