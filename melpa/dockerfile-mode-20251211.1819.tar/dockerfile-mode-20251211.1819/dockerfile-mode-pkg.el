;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dockerfile-mode" "20251211.1819"
  "Major mode for editing Docker's Dockerfiles."
  '((emacs "24"))
  :url "https://github.com/spotify/dockerfile-mode"
  :commit "5af2702b00053ddc6c00c4f409140a863af364d8"
  :revdesc "5af2702b0005"
  :keywords '("docker" "languages" "processes" "tools"))
