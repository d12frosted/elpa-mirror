(define-package "test-cockpit" "20231022.2120" "A command center to run tests of a software project"
  '((emacs "28.1")
    (projectile "2.7")
    (toml "20230411.1449"))
  :commit "e6657d5fa89a32c78ef45be6daf13a2f9473edde" :authors
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainer
  '("Johannes Mueller" . "github@johannes-mueller.org")
  :url "https://github.com/johannes-mueller/test-cockpit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
