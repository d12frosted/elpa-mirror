;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faust-mode" "20201004.1353"
  "Faust syntax colorizer for Emacs."
  ()
  :url "https://github.com/rukano/emacs-faust-mode"
  :commit "2a56cda14b152d5471f21a5d82f23c141dc7134c"
  :revdesc "2a56cda14b15"
  :keywords '("languages" "faust")
  :authors '(("rukano" . "rukano@gmail.com"))
  :maintainers '(("Yassin Philip" . "xaccrocheur@gmail.com")))
