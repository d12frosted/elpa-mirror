(define-package "jsonian" "20230823.613" "A major mode for editing JSON files"
  '((emacs "27.1"))
  :commit "4cf2e80468fb6e7c2dc32b39b64c3f91cdeb43b2" :authors
  '(("Ian Wahbe"))
  :maintainers
  '(("Ian Wahbe"))
  :maintainer
  '("Ian Wahbe")
  :url "https://github.com/iwahbe/jsonian")
;; Local Variables:
;; no-byte-compile: t
;; End:
