;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iceberg-theme" "20260516.316"
  "Well-designed, eye-friendly, dark blue color scheme."
  '((emacs           "28.1")
    (solarized-theme "1.3"))
  :url "https://github.com/conao3/iceberg-theme.el"
  :commit "42bed6ff66a202fca4433886f9ce7b8399379db0"
  :revdesc "42bed6ff66a2"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
