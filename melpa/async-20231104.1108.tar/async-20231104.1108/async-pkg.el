(define-package "async" "20231104.1108" "Asynchronous processing in Emacs"
  '((emacs "24.4"))
  :commit "37ea3e2403e9c2d98118c224382d48884bbf7723" :authors
  '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("async")
  :url "https://github.com/jwiegley/emacs-async")
;; Local Variables:
;; no-byte-compile: t
;; End:
