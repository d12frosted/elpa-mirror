;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-refactor" "20261112.952"
  "A collection of commands for refactoring Clojure code."
  '((emacs        "28.1")
    (yasnippet    "0.6.1")
    (paredit      "24")
    (clojure-mode "5.18.0")
    (cider        "2.0.0")
    (parseedn     "1.2.0")
    (transient    "0.4.1")
    (spinner      "1.7"))
  :url "https://github.com/clojure-emacs/clj-refactor.el"
  :commit "78e3c3d850057d3110d4565f0ba63b920232cae7"
  :revdesc "78e3c3d85005"
  :keywords '("convenience" "clojure" "cider")
  :authors '(("Magnar Sveen" . "magnars@gmail.com")
             ("Lars Andersen" . "expez@expez.com")
             ("Benedek Fazekas" . "benedek.fazekas@gmail.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")
                 ("Lars Andersen" . "expez@expez.com")
                 ("Benedek Fazekas" . "benedek.fazekas@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
