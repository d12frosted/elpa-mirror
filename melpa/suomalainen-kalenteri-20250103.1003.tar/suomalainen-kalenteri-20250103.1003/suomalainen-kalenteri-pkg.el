;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "suomalainen-kalenteri" "20250103.1003"
  "Finnish national and Christian holidays for calendar."
  ()
  :url "https://github.com/tlikonen/suomalainen-kalenteri"
  :commit "4b63a82c3145bfff2dc1f7b45ce2463824462da0"
  :revdesc "4b63a82c3145"
  :keywords '("calendar" "holidays" "finnish")
  :authors '(("Teemu Likonen" . "tlikonen@iki.fi"))
  :maintainers '(("Teemu Likonen" . "tlikonen@iki.fi")))
