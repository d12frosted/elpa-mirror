;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260516.2154"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "faf950080202d48e73e9d43ee51c2b70bbe881dd"
  :revdesc "faf950080202"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
