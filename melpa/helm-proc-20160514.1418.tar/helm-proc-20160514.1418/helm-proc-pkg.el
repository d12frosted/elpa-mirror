(define-package "helm-proc" "20160514.1418" "Helm interface for managing system processes"
  '((helm "1.6.0"))
  :commit "0a75a86e4f381143134e0cdcd8c84c5b5b0fb2d6" :authors
  '(("Markus Hauck" . "markus1189@gmail.com"))
  :maintainer
  '("Markus Hauck" . "markus1189@gmail.com")
  :keywords
  '("helm"))
;; Local Variables:
;; no-byte-compile: t
;; End:
