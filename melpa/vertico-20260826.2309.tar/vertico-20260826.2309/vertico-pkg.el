;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20260826.2309"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "df51b901b78251be1e3bb54f173856f4cc395163"
  :revdesc "df51b901b782"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
