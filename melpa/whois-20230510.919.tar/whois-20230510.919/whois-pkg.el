(define-package "whois" "20230510.919" "Syntax highlighted domain name queries using system whois"
  '((emacs "24"))
  :commit "bf131b99bb3f5583d27d1c72ef0fbd829ef85664" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("network" "comm")
  :url "https://github.com/lassik/emacs-whois")
;; Local Variables:
;; no-byte-compile: t
;; End:
