(define-package "logview" "20240831.1130" "Major mode for viewing log files"
  '((emacs "25.1")
    (datetime "0.8")
    (extmap "1.0"))
  :commit "749255d1600c966187a195ef05a4608c2853ec49" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("files" "tools")
  :url "https://github.com/doublep/logview")
;; Local Variables:
;; no-byte-compile: t
;; End:
