(define-package "citre" "20210820.1729" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "1d6d2b6feffb70becc010e2d34117ca5f11c8def" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
