;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260717.1502"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "c3f2079bdd5d480a7509b2f28cc104ec7473ffb7"
  :revdesc "c3f2079bdd5d"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
