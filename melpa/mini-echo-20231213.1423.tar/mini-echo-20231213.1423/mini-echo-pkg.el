(define-package "mini-echo" "20231213.1423" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "b039eef2fa61005bc251d7e5ee3026760c83f9ef" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
