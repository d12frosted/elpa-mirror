;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-box" "20251110.909"
  "Display documentation in childframe."
  '((emacs "27.1"))
  :url "https://github.com/casouri/eldoc-box"
  :commit "573b2f51bf578f5a1fb8e148f2b81311c1421cc2"
  :revdesc "573b2f51bf57"
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
