;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20260106.941"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "5c42288756409e6ff3919eb27913ad655b77467d"
  :revdesc "5c4228875640"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
