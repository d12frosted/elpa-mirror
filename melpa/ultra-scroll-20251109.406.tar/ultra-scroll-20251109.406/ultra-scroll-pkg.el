;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultra-scroll" "20251109.406"
  "Fast and smooth scrolling."
  '((emacs "29.1"))
  :url "https://github.com/jdtsmith/ultra-scroll"
  :commit "f990ae3c0344ac1d8f976d62265d154959280581"
  :revdesc "f990ae3c0344"
  :keywords '("convenience"))
