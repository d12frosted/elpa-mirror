;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iota" "20230918.1028"
  "Replace marker with increasing integers."
  ()
  :url "https://git.sr.ht/~mango/iota.el"
  :commit "c065c087567f074bff639eb12fa53018654b8ce2"
  :revdesc "c065c087567f"
  :keywords '("abbrev" "data" "wp")
  :authors '(("Thomas Voss" . "mail@thomasvoss.com"))
  :maintainers '(("Thomas Voss" . "mail@thomasvoss.com")))
