;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260501.352"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "6488547579699430875ecf3fb1924130982f5ebf"
  :revdesc "648854757969"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
