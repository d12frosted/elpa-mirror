;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20250414.344"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "8e4075713885f7ec7253936e3e74c7860ce7f77f"
  :revdesc "8e4075713885"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
