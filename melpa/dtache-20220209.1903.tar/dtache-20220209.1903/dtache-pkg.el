(define-package "dtache" "20220209.1903" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "9b39e9ebbfd19bae1b0b30e98b574f0e8a952bec" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
