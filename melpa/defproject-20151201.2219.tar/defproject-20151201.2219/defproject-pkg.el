;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "defproject" "20151201.2219"
  "Manager dir-locals and project specific variables."
  '((emacs "24"))
  :url "https://github.com/kotfic/defproject"
  :commit "674d48a5e34cb4bba76faa38ee901322ec649086"
  :revdesc "674d48a5e34c"
  :keywords '("convenience")
  :authors '((nil . "kotfic@gmail.com"))
  :maintainers '((nil . "kotfic@gmail.com")))
