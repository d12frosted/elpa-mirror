(define-package "dracula-theme" "20230901.813" "Dracula Theme"
  '((emacs "24.3"))
  :commit "12d2d0aa6eb7991d2511ddc095de809cbef697fb" :authors
  '(("film42"))
  :maintainers
  '(("Étienne Deparis" . "etienne@depar.is"))
  :maintainer
  '("Étienne Deparis" . "etienne@depar.is")
  :url "https://github.com/dracula/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
