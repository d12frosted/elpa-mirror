;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260115.1854"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "26980ac23209fa88aa300420f8f9f955558db2cf"
  :revdesc "26980ac23209")
