;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260208.1626"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e55d2a7710046e77423ac23558732b639ec7ba6b"
  :revdesc "e55d2a771004"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
