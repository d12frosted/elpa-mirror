(define-package "spdx" "20230609.123" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "225fbe14e21fecc231723006b6a6f44ddcbada3d" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
