;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-vcsh" "20230402.1219"
  "Magit vcsh integration."
  '((magit "2.90.1")
    (vcsh  "0.4")
    (emacs "24.4"))
  :url "http://git.smrk.net/magit-vcsh.el"
  :commit "fd6c86c066b14bbf78644d38eca9711d6d9544a1"
  :revdesc "fd6c86c066b1"
  :keywords '("vc" "files" "magit")
  :authors '(("těpán Němec" . "stepnem@smrk.net"))
  :maintainers '(("těpán Němec" . "stepnem@smrk.net")))
