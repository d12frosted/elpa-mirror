(define-package "ledger-mode" "20240322.545" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "ea9d3acb452c53d9c62852b7df6219ff6b146ffb")
;; Local Variables:
;; no-byte-compile: t
;; End:
