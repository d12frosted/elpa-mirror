(define-package "binky-mode" "20230809.1320" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "3fe965685d00da7d87c748e9098a9bbaa8a0fb58" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
