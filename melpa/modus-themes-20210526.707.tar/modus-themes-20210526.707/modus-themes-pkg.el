(define-package "modus-themes" "20210526.707" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "fb4713bc7cc59b9b011854fc1f7bf01bbd023976" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
