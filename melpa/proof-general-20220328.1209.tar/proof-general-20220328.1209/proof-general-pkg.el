(define-package "proof-general" "20220328.1209" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "40c40d229e9db177f2114266ac6246daf6a060bc" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
