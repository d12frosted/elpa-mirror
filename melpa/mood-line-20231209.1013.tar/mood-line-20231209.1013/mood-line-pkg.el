(define-package "mood-line" "20231209.1013" "A minimal mode line inspired by doom-modeline"
  '((emacs "26.1"))
  :commit "a0c84a3c1ea9d7718393a6faff2537dedd34b882" :authors
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainers
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainer
  '("Jessie Hildebrandt <jessieh.net>")
  :keywords
  '("mode-line" "faces")
  :url "https://gitlab.com/jessieh/mood-line")
;; Local Variables:
;; no-byte-compile: t
;; End:
