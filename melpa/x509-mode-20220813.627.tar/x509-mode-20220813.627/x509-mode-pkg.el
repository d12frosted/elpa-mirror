(define-package "x509-mode" "20220813.627" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "24.3"))
  :commit "0e34667fac01fe42f0d8a6e501b5bbd5d4982e8e" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
