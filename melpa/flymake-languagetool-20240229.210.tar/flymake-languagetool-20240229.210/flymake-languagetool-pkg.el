(define-package "flymake-languagetool" "20240229.210" "Flymake support for LanguageTool"
  '((emacs "27.1"))
  :commit "7da39ebf2f105689a9e55cc58508b0ac8c34754c" :keywords
  '("convenience" "grammar" "check")
  :url "https://github.com/emacs-languagetool/flymake-languagetool")
;; Local Variables:
;; no-byte-compile: t
;; End:
