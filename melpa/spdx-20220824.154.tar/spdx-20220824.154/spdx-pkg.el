(define-package "spdx" "20220824.154" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "3e9b59dbdb81a8ade36f21ae57690df5922a67b5" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
