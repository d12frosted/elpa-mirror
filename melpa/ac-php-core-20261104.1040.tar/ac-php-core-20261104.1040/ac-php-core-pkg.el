;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20261104.1040"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "c2132776a121362fbe3b83535348ded1ee671d03"
  :revdesc "c2132776a121"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
