;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20261022.1215"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "d41a41f8e7d760bb3f74a2fe54ccb3e008e80e5a"
  :revdesc "d41a41f8e7d7"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
