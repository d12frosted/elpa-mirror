(define-package "mentor" "20221015.451" "Frontend for the rTorrent bittorrent client"
  '((emacs "25.1")
    (xml-rpc "1.6.15")
    (seq "1.11")
    (async "1.9.3"))
  :commit "c1d7121a455aaeebb11254916d4c0037a8171fec" :authors
  '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainer
  '("Stefan Kangas" . "stefankangas@gmail.com")
  :keywords
  '("comm" "processes" "bittorrent")
  :url "https://github.com/skangas/mentor")
;; Local Variables:
;; no-byte-compile: t
;; End:
