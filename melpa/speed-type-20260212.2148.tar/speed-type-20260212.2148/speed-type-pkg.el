;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260212.2148"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "1096a7d6eb1a49e6d558402a0e6a2e31fac6bbad"
  :revdesc "1096a7d6eb1a"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
