(define-package "tree-sitter-langs" "20201209.1538" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.9.2"))
  :commit "43fc289dd1a8ba63bb97e5b09750bc9f211eadb5" :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
