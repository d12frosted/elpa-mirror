;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261104.706"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "3fddd964509384c05311628dd62a36f68917a4da"
  :revdesc "3fddd9645093"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
