;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261105.847"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "9f1021edcc7b1c066c61fd01a15c4f159900bf78"
  :revdesc "9f1021edcc7b"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
