;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ednc" "20251103.2242"
  "Emacs Desktop Notification Center."
  '((emacs "26.1"))
  :url "https://github.com/sinic/ednc"
  :commit "dba45d825841f26738d68c306a4b345ee48b6941"
  :revdesc "dba45d825841"
  :keywords '("unix")
  :authors '(("Simon Nicolussi" . "sinic@sinic.name"))
  :maintainers '(("Simon Nicolussi" . "sinic@sinic.name")))
