;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250521.1731"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "71061551cd71b69ebc3731c3a8d5364ce2d62687"
  :revdesc "71061551cd71"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
