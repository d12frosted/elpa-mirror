;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sound-wav" "20260103.1801"
  "Play wav file."
  '((deferred "0.3.1")
    (cl-lib   "0.5"))
  :url "https://github.com/syohex/emacs-sound-wav"
  :commit "99eae68e7774ea1429cce1432facd47a95670254"
  :revdesc "99eae68e7774"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
