;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260518.707"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5b7b94100212f3b09c5308d84350d1f67bc1794c"
  :revdesc "5b7b94100212"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
