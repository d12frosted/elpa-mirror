;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-view-data" "20260822.1255"
  "View data from dired via ESS and R."
  '((emacs         "26.1")
    (ess           "18.10.1")
    (ess-view-data "1.5"))
  :url "https://github.com/ShuguangSun/dired-view-data"
  :commit "dd1aeb67a59321e82d755e065181af074f661efa"
  :revdesc "dd1aeb67a593"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
