;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250919.1527"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.17.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "bde11fbc7dd93ca175649fc7e0cf8ba1a18c026e"
  :revdesc "bde11fbc7dd9"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
