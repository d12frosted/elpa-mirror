;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20260812.1458"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "c5de920c8c139799ec6a1e80bad4afed5fcbe6ee"
  :revdesc "c5de920c8c13"
  :keywords '("docs" "startdict" "sdcv"))
