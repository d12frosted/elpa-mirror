;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-shader" "20260503.1236"
  "LSP Clients for ShaderLab."
  '((emacs    "29.1")
    (lsp-mode "6.1"))
  :url "https://github.com/shader-ls/lsp-shader"
  :commit "85430cd7d20019aa39e624990fd814650af9b3a2"
  :revdesc "85430cd7d200"
  :keywords '("convenience" "shader")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
