(define-package "tok-theme" "20220127.853" "My theme"
  '((emacs "24.3"))
  :commit "5c402f7edfdafba06a8b8a17744a8a1bdbebf6b4" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
