;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260115.1602"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "82e127376d3252ccadb37321d9f521521b25b880"
  :revdesc "82e127376d32"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
