;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "egison-mode" "20260104.1519"
  "Egison editing mode."
  ()
  :url "https://github.com/egisatoshi/egison/blob/master/elisp/egison-mode.el"
  :commit "4e796ee52785e052f3b10c6493fa484461bb4482"
  :revdesc "4e796ee52785"
  :authors '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainers '(("Satoshi Egi" . "egisatoshi@gmail.com")))
