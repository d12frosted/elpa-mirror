(define-package "ledger-mode" "20210102.1440" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "2d441c04c317da4c1a1457954e3e9b2fa0565dd9")
;; Local Variables:
;; no-byte-compile: t
;; End:
