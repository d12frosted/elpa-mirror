(define-package "eide" "20220316.619" "IDE interface" 'nil :commit "23c78f4850f44d18eef66c694e7e05882d841ba6" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://forge.chapril.org/hjuvi/eide")
;; Local Variables:
;; no-byte-compile: t
;; End:
