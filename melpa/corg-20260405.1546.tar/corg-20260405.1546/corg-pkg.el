;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corg" "20260405.1546"
  "Header completion for org-mode."
  '((emacs  "27.1")
    (s      "1.13.1")
    (compat "30"))
  :url "https://github.com/isamert/corg.el"
  :commit "afcdeba074c30c51342a004a42f1bb233a7b1e3f"
  :revdesc "afcdeba074c3"
  :keywords '("abbrev" "convenience" "completion" "matching")
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
