;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-trello" "20210314.1901"
  "Minor mode to synchronize org-mode buffer and trello board."
  '((emacs            "24.3")
    (dash             "2.18.0")
    (s                "1.11.0")
    (deferred         "0.4.0")
    (request-deferred "0.2.0"))
  :url "https://github.com/org-trello/org-trello"
  :commit "9c1c94dff1a46631669023286078b887d077c305"
  :revdesc "9c1c94dff1a4"
  :keywords '("org-mode" "trello" "sync" "org-trello")
  :authors '(("Antoine R. Dumont" . "antoine.romain.dumont@gmail.com"))
  :maintainers '(("Antoine R. Dumont" . "antoine.romain.dumont@gmail.com")))
