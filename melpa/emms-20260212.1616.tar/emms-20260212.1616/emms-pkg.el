;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "20260212.1616"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://www.gnu.org/software/emms/"
  :commit "2c902ddbab99f55a8d1ef047a9a403d4e6f61d02"
  :revdesc "2c902ddbab99"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
