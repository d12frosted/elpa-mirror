(define-package "modus-themes" "20210131.250" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "d4382e81788e7d6add84e04ea2355e223a60700e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
