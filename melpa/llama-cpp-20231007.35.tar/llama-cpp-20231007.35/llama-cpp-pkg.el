(define-package "llama-cpp" "20231007.35" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "20b588549ab35fe5c5dba4171443c2508d8dc14a" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
