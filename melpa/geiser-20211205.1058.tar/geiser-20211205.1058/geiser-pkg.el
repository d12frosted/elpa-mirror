(define-package "geiser" "20211205.1058" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "b4bd69d8c3d6dcc8b508579054eb7905923ef738" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
