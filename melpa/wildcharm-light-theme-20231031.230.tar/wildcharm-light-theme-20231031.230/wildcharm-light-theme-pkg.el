(define-package "wildcharm-light-theme" "20231031.230" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "5b1272afbf7fff2b7b15388978d9f28e70304094" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
