(define-package "embark" "20210801.2252" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c8125e65350ec7e931d4687998fae53fbd4c95d2" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
