(define-package "graphql" "20180912.31" "GraphQL utilities"
  '((emacs "25"))
  :commit "672dd9ebd7e67d8089388b0c484cd650e76565f3" :authors
  '(("Sean Allred" . "code@seanallred.com"))
  :maintainer
  '("Sean Allred" . "code@seanallred.com")
  :keywords
  '("hypermedia" "tools" "lisp")
  :url "https://github.com/vermiculus/graphql.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
