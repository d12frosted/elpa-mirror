(define-package "mhc" "20201227.406" "Message Harmonized Calendaring system."
  '((calfw "20150703"))
  :commit "67f9596dcd43b7ece3ab6e7a6ce8dc18a4851fe8" :authors
  '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainer
  '("Yoshinari Nomura" . "nom@quickhack.net")
  :keywords
  '("calendar")
  :url "http://www.quickhack.net/mhc")
;; Local Variables:
;; no-byte-compile: t
;; End:
