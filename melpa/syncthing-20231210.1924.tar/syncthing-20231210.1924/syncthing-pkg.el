(define-package "syncthing" "20231210.1924" "Client for Syncthing"
  '((emacs "27.1"))
  :commit "5091577252ffe78bf0a9d38a3220414b043fcfbb" :authors
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainer
  '("Peter Badida" . "keyweeusr@gmail.com")
  :keywords
  '("convenience" "syncthing" "sync" "client" "view")
  :url "https://github.com/KeyWeeUsr/emacs-syncthing")
;; Local Variables:
;; no-byte-compile: t
;; End:
