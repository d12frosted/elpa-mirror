;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtags" "20260207.909"
  "A front-end for rtags."
  '((emacs "24.3"))
  :url "https://github.com/Andersbakken/rtags"
  :commit "83d545e283bddec192647b0f823d46975c53cfd4"
  :revdesc "83d545e283bd"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
