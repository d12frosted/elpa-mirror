;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20260108.7"
  "Modular text completion framework."
  '((emacs "26.1"))
  :url "http://company-mode.github.io/"
  :commit "f35b6d8e12ac745d5fd6952f2f51944d7c3ec5bf"
  :revdesc "f35b6d8e12ac"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
