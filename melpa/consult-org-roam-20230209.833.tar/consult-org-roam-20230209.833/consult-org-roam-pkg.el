(define-package "consult-org-roam" "20230209.833" "Consult integration for org-roam"
  '((emacs "27.1")
    (org-roam "2.2.0")
    (consult "0.16"))
  :commit "8f9f122627a6b4e1613401b06d707e3efdb3c2d0" :authors
  '(("jgru <https://github.com/jgru>"))
  :maintainer
  '("jgru <https://github.com/jgru>")
  :url "https://github.com/jgru/consult-org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
