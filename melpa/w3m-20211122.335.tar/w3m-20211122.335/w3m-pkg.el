(define-package "w3m" "20211122.335" "an Emacs interface to w3m" 'nil :commit "3b3e93f588204923487f8f5e562a068bab78683b" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
