;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261116.1158"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "42ae5358a3e221f6ba4c762484651690a3f8492b"
  :revdesc "42ae5358a3e2"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
