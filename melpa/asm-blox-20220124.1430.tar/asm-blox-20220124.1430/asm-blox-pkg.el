(define-package "asm-blox" "20220124.1430" "Programming game involving WAT and YAML"
  '((emacs "26.1")
    (yaml "0.3.4"))
  :commit "47aa63d320c39f8566a8d95c61f27383f561b001" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
