;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260203.1253"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ed34d88366add52b3289b2168ef698b545867f03"
  :revdesc "ed34d88366ad")
