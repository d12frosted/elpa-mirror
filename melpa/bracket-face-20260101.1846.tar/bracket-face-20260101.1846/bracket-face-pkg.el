;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bracket-face" "20260101.1846"
  "A face for brackets."
  '((emacs "30.1"))
  :url "https://github.com/tarsius/paren-face"
  :commit "2c279a236404b2eebacb435aa92d5e9c97939c03"
  :revdesc "2c279a236404"
  :keywords '("faces" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")))
