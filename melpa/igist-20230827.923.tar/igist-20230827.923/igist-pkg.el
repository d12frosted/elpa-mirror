(define-package "igist" "20230827.923" "List, create, update and delete GitHub gists"
  '((emacs "27.1")
    (ghub "3.6.0")
    (transient "0.4.1"))
  :commit "565eb8d89f62e9a09ff6c60fa383197e876ceea3" :authors
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainer
  '("Karim Aziiev" . "karim.aziiev@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/KarimAziev/igist")
;; Local Variables:
;; no-byte-compile: t
;; End:
