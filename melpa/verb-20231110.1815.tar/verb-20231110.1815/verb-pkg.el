(define-package "verb" "20231110.1815" "Organize and send HTTP requests"
  '((emacs "26.3"))
  :commit "d931cd2a2448df8f66143df2499c811def69281d" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
