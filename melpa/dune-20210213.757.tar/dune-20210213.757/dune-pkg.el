(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "0c8f161e4a79cfa55d89afad7936ed431784f65d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
