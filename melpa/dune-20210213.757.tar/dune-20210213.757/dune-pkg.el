(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "a181b937c20c706f24ba1d17021593b0087ac574" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
