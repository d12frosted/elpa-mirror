(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "8a1adbe94601dcc5ad1d17e87626df66cb15d545" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
