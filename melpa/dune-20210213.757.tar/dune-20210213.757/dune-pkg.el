(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "d45c3521b0be75f47d1188b65f999d8fb0d496eb" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
