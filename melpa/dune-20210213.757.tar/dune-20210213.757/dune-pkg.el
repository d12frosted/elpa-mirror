(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "26f5e57d1aef71f476a6dc40990b9d6a517f7849" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
