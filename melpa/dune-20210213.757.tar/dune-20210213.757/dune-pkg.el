(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "53d8c024d437ca29951066c54ca22634706c64da" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
