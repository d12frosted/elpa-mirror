(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "0e25eef3d692f9a0985b552098d115a97057b198" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
