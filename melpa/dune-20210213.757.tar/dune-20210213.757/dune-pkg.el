(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "110e8a039b25cc52ba7fecc29b0fedae597b104a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
