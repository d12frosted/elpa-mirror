(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "898db3b97b8aec0320b3c9320d9714a3ef85f734" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
