(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "f68e6f98f954df093832ff5652efeca91730ac6a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
