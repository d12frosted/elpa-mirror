(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "f4265291524065e731158c685ec859dc03c837c3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
