(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "d75bd885262b98075299e9145a2aa3bd1a54a35d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
