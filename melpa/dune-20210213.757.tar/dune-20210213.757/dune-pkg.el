(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "4981b8e273f38e4df6122061498501725e4e4b1c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
