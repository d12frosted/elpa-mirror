(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "4eb12f59293c8fb6d851b553daa8494cd8a3200f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
