(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "53e892cbf1d28a9fd532bd541670f740b392782f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
