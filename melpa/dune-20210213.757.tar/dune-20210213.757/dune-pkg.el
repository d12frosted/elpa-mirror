(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "7368482c37d94a5f303bc34c3c2cfe26145f362b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
