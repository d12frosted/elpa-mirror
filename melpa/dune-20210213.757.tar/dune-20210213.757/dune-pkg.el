(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "f73d179868394fe321fbab166c97f0dece82b60b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
