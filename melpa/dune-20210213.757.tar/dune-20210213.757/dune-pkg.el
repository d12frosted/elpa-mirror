(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "ad2b5de915444866c14a8c27270b3b1b3cf233ba" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
