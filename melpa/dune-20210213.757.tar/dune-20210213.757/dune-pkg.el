(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "d9797e471a9fe8bb81c6579fd77e63cebecfe89e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
