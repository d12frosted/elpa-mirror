(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "a77798ec2938c3cdd08ebc1ca41c0698b87cd953" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
