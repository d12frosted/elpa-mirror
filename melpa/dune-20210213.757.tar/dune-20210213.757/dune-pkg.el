(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "daa604b40ffc727a59ce0ffe086536c5f5b118b2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
