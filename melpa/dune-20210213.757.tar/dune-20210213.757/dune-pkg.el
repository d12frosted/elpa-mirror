(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "c396a640f5f0e2641c60048d72325a63ef7f4429" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
