(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "740ba89eb928de8ccf4906b83fe28dea26d1e313" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
