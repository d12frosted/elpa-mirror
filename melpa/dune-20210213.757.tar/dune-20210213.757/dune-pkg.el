(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "66982576945ca3e61ee7ac87f927bebcc17b271e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
