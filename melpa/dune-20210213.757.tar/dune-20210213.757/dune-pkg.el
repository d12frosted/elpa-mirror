(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "eec019e30cfc00ec710251a1c6bba1c49203a2ab" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
