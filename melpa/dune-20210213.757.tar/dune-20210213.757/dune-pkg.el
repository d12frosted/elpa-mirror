(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "4a20cca7e1362714c61b8984768bf871c0db78b3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
