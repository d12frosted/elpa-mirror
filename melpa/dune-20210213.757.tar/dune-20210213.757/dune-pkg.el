(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "d180b517590cff34dd0e776279695cc518105285" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
