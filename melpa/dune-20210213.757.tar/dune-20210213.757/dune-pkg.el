(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "dbf5f195648582f5304677dc3013a9327c27be13" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
