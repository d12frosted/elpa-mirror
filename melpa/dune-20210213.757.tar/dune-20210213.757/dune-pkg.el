(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "12de523d4482d52f2648d50fc58d5a28af193b66" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
