(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "5b448466d35684d78fdfb59cc4d08cec82ec1a5b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
