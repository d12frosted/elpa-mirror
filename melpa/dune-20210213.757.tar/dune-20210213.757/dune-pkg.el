(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "ac3a66e0f7d3577b27cc5d5f2399163bfbe11828" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
