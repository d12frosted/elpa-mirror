(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "4f2664f04260273855300c8a4665d69a89c85598" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
