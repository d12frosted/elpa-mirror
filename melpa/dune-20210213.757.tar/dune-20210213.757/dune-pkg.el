(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "b456daf3940aeb2a562f777d9a81e92ad21243b9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
