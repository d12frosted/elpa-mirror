(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "f57453bacf0e2f5193753aa159501a393d17d214" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
