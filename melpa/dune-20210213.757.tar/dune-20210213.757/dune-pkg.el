(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "a88ce5bbc996b550071c8df890276eb1b10e778c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
