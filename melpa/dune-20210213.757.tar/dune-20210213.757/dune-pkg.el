(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "aa3acbfe90c2753c9a72fbb911699ab2f938ba9c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
