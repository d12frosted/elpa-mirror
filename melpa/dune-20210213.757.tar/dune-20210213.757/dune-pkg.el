(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "cc0be5ba3a4ccb3687ea45f5d35eb458e53a3daa" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
