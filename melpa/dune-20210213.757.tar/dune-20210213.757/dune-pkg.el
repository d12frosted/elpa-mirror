(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "eee9a64f5336cc6700f6e8875205010e89511ae8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
