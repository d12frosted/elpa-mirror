(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "60da8764ced1825f6b5c4015c55c961588c281e8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
