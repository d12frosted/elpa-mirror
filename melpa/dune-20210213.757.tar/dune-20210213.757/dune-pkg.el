(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "b6fb05f644db9cd52fbd9c30493ccd159faa17ce" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
