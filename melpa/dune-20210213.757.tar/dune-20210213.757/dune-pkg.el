(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "5abbffe326893f841946fd36bc4fd9de56c6b008" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
