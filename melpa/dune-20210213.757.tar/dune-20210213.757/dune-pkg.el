(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "b538a1bb38a2530aa4068e64f5f3afa3aa0f4c08" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
