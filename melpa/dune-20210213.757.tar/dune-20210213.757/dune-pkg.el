(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "269f50aa42547af6e08d9076c85538846431f7ac" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
