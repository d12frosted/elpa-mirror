(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "33e7110d023f2d0e62ddaebdad5414102ddfec1d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
