(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "8dd908c7332e8d65d3786a3d13869cb77f615d35" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
