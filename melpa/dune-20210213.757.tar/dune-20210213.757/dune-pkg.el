(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "8a79b3b02735bc778d57babe59701ae7ef897737" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
