(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "c974911b1048550da03450ea81c2125ca485de61" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
