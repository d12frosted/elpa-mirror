(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "c547ff38e6000f61f28096bd6a84f03b773dafd8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
