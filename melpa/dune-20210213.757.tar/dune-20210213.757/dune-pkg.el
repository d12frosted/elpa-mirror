(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "4a5632e8f9574177e4a34b33cc3ceb4a8b1df214" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
