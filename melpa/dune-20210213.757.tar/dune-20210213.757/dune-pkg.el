(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "c07c42f528c2f0ae67943110f0854a689f713205" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
