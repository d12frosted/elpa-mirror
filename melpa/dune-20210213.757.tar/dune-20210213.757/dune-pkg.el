(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "25757032e62a0630a745b3ae73b35c7b84a36f6f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
