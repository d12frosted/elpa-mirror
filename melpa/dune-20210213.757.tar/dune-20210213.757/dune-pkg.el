(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "9ef424f645b7c190d3b35355e5138f29efb12c25" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
