(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "2a40bc927ba42794b4780d576ce0868f7bdbce2f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
