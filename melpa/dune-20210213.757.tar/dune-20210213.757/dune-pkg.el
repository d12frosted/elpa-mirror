(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "30ff3b2db9c0e40ade024db06b461075d4be7eb9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
