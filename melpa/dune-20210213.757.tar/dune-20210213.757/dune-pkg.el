(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "3df9a0e0a9a0b6a57b3661aef09760be1095b211" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
