(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "846b38c1efab4757240d131d2c45102930fc305c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
