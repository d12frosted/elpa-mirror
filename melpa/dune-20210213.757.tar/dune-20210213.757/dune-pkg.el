(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "41c60fbb7f00f29e366d6fa4c1793a4230601ebc" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
