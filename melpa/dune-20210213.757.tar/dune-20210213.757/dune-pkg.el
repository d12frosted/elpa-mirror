(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "1cdf7b097e7dc927d36c7f67e7d4949b84cdbd2b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
