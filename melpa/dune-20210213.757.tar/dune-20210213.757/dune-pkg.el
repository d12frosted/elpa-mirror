(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "08439c1072dc9d22031d77b71bd9b9d6ed0670b1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
