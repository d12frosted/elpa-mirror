(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "cbe1df2b589d6e4bf678e94071e0cae2ce58a4e6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
