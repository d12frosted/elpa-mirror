(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "e0d08fca1bd7ec21010563200ad55849c5fd592f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
