(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "d6e14f9d3b6126f5f6de44d582ac6bdd6e4f2901" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
