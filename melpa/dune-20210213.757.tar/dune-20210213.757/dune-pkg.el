(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "4933706c28ca6f0caa7b731b5cec3cbea5b92085" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
