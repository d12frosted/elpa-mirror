(define-package "treemacs" "20220621.2130" "A tree style file explorer package"
  '((emacs "26.1")
    (cl-lib "0.5")
    (dash "2.11.0")
    (s "1.12.0")
    (ace-window "0.9.0")
    (pfuture "1.7")
    (hydra "0.13.2")
    (ht "2.2")
    (cfrs "1.3.2"))
  :commit "d6a4c6f08d5ae61af2e97d1584f38f73e7a7c513" :authors
  '(("Alexander Miller" . "alexanderm@web.de"))
  :maintainer
  '("Alexander Miller" . "alexanderm@web.de")
  :url "https://github.com/Alexander-Miller/treemacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
