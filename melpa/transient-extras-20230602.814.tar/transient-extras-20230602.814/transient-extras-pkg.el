(define-package "transient-extras" "20230602.814" "Extra features for transient"
  '((emacs "28.1"))
  :commit "72eb0e66714d3144de55b983a23eca5c0b664fcc" :authors
  '(("Al Haji-Ali <abdo.haji.ali@gmail.com>, Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers
  '(("Al Haji-Ali <abdo.haji.ali@gmail.com>, Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainer
  '("Al Haji-Ali <abdo.haji.ali@gmail.com>, Samuel W. Flint" . "swflint@flintfam.org")
  :keywords
  '("convenience")
  :url "https://github.com/haji-ali/transient-extras.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
