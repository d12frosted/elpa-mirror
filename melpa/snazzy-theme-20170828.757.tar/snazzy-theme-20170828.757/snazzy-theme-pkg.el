;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snazzy-theme" "20170828.757"
  "An elegant syntax theme with bright colors."
  '((emacs        "24")
    (base16-theme "2.1"))
  :url "https://github.com/weijiangan/emacs-snazzy/"
  :commit "578d7ebc4ed91c0a630b652c4b6fdd54d9ae16cd"
  :revdesc "578d7ebc4ed9"
  :keywords '("faces" "theme" "color" "snazzy"))
