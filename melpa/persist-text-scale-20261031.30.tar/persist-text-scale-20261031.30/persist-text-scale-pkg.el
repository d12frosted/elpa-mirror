;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20261031.30"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "cc4074359bdce0c05b8791fd45284ca7af6104bc"
  :revdesc "cc4074359bdc"
  :keywords '("convenience" "faces")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
