;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pasvortilo" "20251210.2125"
  "Password manager interface for pass/gopass."
  '((emacs     "26.1")
    (transient "0.3.0"))
  :url "https://codeberg.org/mester/pasvortilo"
  :commit "a38d016d00164ab319173aa47f2d7f6a7dd1aaf3"
  :revdesc "a38d016d0016"
  :keywords '("unix" "extensions" "passwords"))
