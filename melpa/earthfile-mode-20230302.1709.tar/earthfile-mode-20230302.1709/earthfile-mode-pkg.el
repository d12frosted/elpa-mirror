(define-package "earthfile-mode" "20230302.1709" "Major mode for editing Earthly file"
  '((emacs "26"))
  :commit "a242a4d68ebefce81879823c54155e0a04d3ea4a" :authors
  '(("Thanabodee Charoenpiriyakij" . "wingyminus@gmail.com"))
  :maintainers
  '(("Thanabodee Charoenpiriyakij" . "wingyminus@gmail.com"))
  :maintainer
  '("Thanabodee Charoenpiriyakij" . "wingyminus@gmail.com")
  :url "https://github.com/earthly/earthly-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
