;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260516.1059"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "16373528d8332a2c40d659a435cbb9a350e5fcca"
  :revdesc "16373528d833"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
