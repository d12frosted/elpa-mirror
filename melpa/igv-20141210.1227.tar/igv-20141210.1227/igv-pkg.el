;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "igv" "20141210.1227"
  "Control Integrative Genomic Viewer within Emacs."
  ()
  :commit "47ac6ceede252f451348a2c696398c0cb5279555"
  :revdesc "47ac6ceede25"
  :authors '(("Stefano Barbi" . "stefanobarbi@gmail.com"))
  :maintainers '(("Stefano Barbi" . "stefanobarbi@gmail.com")))
