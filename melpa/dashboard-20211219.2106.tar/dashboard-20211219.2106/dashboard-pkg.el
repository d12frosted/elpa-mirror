(define-package "dashboard" "20211219.2106" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "43441eef61c1a1a9471d330c0a29ca579ebba51c" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
