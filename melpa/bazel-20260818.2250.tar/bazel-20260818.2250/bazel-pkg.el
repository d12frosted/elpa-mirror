;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260818.2250"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "350444711bda2be1604582a365d9beccfd09a62d"
  :revdesc "350444711bda"
  :keywords '("build tools" "languages"))
