(define-package "ibrowse" "20230811.756" "Interact with your browser"
  '((emacs "27.1"))
  :commit "5f708dd93a9f4d98e005d08ef6f1d30bfd3eb2f4" :authors
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainers
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainer
  '("Nicolas Graves" . "ngraves@ngraves.fr")
  :keywords
  '("comm" "data" "files" "tools")
  :url "https://git.sr.ht/~ngraves/ibrowse.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
