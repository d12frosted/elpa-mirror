;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "json-par" "20260307.1319"
  "Minor mode for structural editing of JSON."
  '((emacs "24.4"))
  :url "https://github.com/taku0/json-par"
  :commit "a90a7e1bb878d2534a490366504dd716b5be6054"
  :revdesc "a90a7e1bb878"
  :keywords '("abbrev" "convenience" "files")
  :authors '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainers '(("taku0" . "mxxouy6x3m_github@tatapa.org")))
