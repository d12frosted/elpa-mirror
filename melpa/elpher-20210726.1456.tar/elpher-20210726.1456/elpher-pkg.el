(define-package "elpher" "20210726.1456" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "5705f7a053a80c7234f30f7dae6f7931afdc6fcc" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
