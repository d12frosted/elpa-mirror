(define-package "verb" "20230711.1636" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "db122b8847b1c1896f3cf9512fd0ec9f79927715" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
