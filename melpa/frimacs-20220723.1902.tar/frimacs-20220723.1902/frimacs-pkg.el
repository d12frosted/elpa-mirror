(define-package "frimacs" "20220723.1902" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "b35fdefb60ead4d7559131601c43761973762a9a" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
