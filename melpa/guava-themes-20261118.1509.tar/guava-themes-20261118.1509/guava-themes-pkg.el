;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261118.1509"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "8f614bcef1acb2a67a3d335f48f3efaab88b5e30"
  :revdesc "8f614bcef1ac"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
