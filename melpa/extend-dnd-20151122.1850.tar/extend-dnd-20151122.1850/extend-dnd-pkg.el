;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "extend-dnd" "20151122.1850"
  "R drag and Drop."
  ()
  :url "https://github.com/mlf176f2/extend-dnd"
  :commit "80c966c93b82c9bb5c6225a432557c39144fc602"
  :revdesc "80c966c93b82"
  :keywords '("extend" "drag and drop"))
