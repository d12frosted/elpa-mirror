(define-package "extend-dnd" "20151122.1850" "R drag and Drop" 'nil :commit "80c966c93b82c9bb5c6225a432557c39144fc602" :authors
  '(("Matthew L. Fidler"))
  :maintainer
  '("Matthew L. Fidler")
  :keywords
  '("extend" "drag and drop")
  :url "https://github.com/mlf176f2/extend-dnd")
;; Local Variables:
;; no-byte-compile: t
;; End:
