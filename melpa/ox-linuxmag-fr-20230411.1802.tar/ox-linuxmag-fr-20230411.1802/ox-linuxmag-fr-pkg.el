(define-package "ox-linuxmag-fr" "20230411.1802" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "05d4a7f2d2e69fcaadb173b8a48df4019cd5423b" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
