(define-package "dix" "20220105.1017" "Apertium XML editing minor mode"
  '((cl-lib "0.5")
    (emacs "26.2"))
  :commit "a2d924725380aca4d61df4a70825fc4b76185938" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("languages")
  :url "http://wiki.apertium.org/wiki/Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
