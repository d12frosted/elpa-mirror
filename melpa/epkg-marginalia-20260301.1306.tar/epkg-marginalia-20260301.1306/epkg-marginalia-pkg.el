;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg-marginalia" "20260301.1306"
  "Show Epkg information in completion annotations."
  '((emacs      "28.1")
    (compat     "30.1")
    (epkg       "4.1")
    (marginalia "2.9"))
  :url "https://github.com/emacscollective/epkg-marginalia"
  :commit "d6ccf20529c39652968d1b017fae78404ac191fb"
  :revdesc "d6ccf20529c3"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev")))
