(define-package "modaled" "20230819.1542" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "e47bd427a2161193b85dc6121c975833f867f47e" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
