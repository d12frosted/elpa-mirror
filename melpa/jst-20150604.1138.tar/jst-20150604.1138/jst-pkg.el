;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jst" "20150604.1138"
  "JS test mode."
  '((s      "1.9")
    (f      "0.17")
    (dash   "2.10")
    (pcache "0.3")
    (emacs  "24.4"))
  :url "https://github.com/cheunghy/jst-mode"
  :commit "865ff97449a4cbbcb40d38b4908cf4d7b22a5108"
  :revdesc "865ff97449a4"
  :keywords '("js" "javascript" "jasmine" "coffee" "coffeescript")
  :authors '(("Cheung Hoi Yu" . "yeannylam@gmail.com"))
  :maintainers '(("Cheung Hoi Yu" . "yeannylam@gmail.com")))
