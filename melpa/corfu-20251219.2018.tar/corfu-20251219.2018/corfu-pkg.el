;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251219.2018"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "21edb09ddcfda7f90ad357346137ce0e669017a3"
  :revdesc "21edb09ddcfd"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
