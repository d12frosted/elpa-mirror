;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260123.1259"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "69e8c8bf20fa0876dfbf84a90c8e0c04750fdc0f"
  :revdesc "69e8c8bf20fa"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
