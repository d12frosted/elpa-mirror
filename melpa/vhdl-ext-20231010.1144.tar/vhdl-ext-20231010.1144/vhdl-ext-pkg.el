(define-package "vhdl-ext" "20231010.1144" "VHDL Extensions"
  '((emacs "29.1")
    (vhdl-ts-mode "0.1.0")
    (lsp-mode "8.0.0")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "32")
    (outshine "3.0.1")
    (async "1.9.7"))
  :commit "423816f9dfb2f487d593204a87562af97cddd0dd" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
