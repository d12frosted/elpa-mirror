;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guard" "20261005.1630"
  "Custom modular init framework."
  '((emacs "29.1"))
  :url "https://github.com/Dspil/guard.el"
  :commit "80cea13d380f3dae169b0f099a47a00b4f5d0693"
  :revdesc "80cea13d380f"
  :keywords '("convenience" "initialization" "profiles" "tools")
  :authors '(("Dionisis Spiliopoulos" . "dennisspiliopoylos@gmail.com"))
  :maintainers '(("Dionisis Spiliopoulos" . "dennisspiliopoylos@gmail.com")))
