(define-package "meow" "20211213.1752" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "c111e74296579614847bff9df8f7a1c7e1d6ff45" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
