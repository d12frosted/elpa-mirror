(define-package "modus-themes" "20211027.1523" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "435574d081dfeadd8de3315b1e280e7c3a1fa5f5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
