;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uiua-mode" "20260617.1125"
  "Uiua integration."
  '((emacs       "27.1")
    (reformatter "0.8"))
  :url "https://github.com/crmsnbleyd/uiua-mode"
  :commit "043351d9bb58c16bb66cbe802012bdf5453c4b13"
  :revdesc "043351d9bb58"
  :keywords '("languages" "uiua"))
