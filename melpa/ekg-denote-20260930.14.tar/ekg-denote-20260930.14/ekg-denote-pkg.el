;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-denote" "20260930.14"
  "A denote integration for ekg."
  '((emacs  "28.1")
    (ekg    "0.7.0")
    (denote "4.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "84c9d9a9685f07b6988a618f11920ca063474fc8"
  :revdesc "84c9d9a9685f"
  :keywords '("outlines" "hypermedia")
  :authors '(("Jay Rajput" . "jayrajput@gmail.com"))
  :maintainers '(("Jay Rajput" . "jayrajput@gmail.com")))
