;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260108.1324"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c1f185e0d50251f5eedc7ed056f3a60ee6e42894"
  :revdesc "c1f185e0d502")
