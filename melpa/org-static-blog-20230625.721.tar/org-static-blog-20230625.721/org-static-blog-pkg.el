(define-package "org-static-blog" "20230625.721" "a simple org-mode based static blog generator"
  '((emacs "24.3"))
  :commit "eebf509c3acbda760faa7fd12b2e8902ae09482f" :authors
  '(("Bastian Bechtold"))
  :maintainers
  '(("Bastian Bechtold"))
  :maintainer
  '("Bastian Bechtold")
  :url "https://github.com/bastibe/org-static-blog")
;; Local Variables:
;; no-byte-compile: t
;; End:
