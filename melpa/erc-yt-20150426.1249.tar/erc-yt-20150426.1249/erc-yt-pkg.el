;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-yt" "20150426.1249"
  "An erc module to display youtube links nicely."
  '((dash "2.10.0"))
  :url "https://github.com/yhvh/erc-yt"
  :commit "43e7d49325b17a3217a6ffb4a9daf75c5ff4e6f8"
  :revdesc "43e7d49325b1"
  :keywords '("multimedia")
  :authors '(("William Stevenson" . "yhvh2000@gmail.com"))
  :maintainers '(("William Stevenson" . "yhvh2000@gmail.com")))
