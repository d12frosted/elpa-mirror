;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260525.213"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.1")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "a1fecd42661550aeb07188b645f3f13bb32728e3"
  :revdesc "a1fecd426615"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
