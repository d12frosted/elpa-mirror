;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260106.942"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "3d06b8841087fdc090fe18a741fd83e45a1d2872"
  :revdesc "3d06b8841087"
  :keywords '("languages"))
