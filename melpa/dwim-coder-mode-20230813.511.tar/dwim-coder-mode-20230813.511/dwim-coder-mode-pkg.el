(define-package "dwim-coder-mode" "20230813.511" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "20bc157c2489b8c2b10abc819817aa2a732707c1" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
