(define-package "lacquer" "20220811.649" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "70650105be1b4c1ade34c0a1c3263d80b2388593" :authors
  '(("zakudriver" . "zy.hua1122@gmail.com"))
  :maintainer
  '("zakudriver" . "zy.hua1122@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/zakudriver/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
