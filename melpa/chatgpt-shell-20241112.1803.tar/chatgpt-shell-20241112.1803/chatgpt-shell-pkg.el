;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241112.1803"
  "ChatGPT shell + buffer insert commands."
  '((emacs       "28.1")
    (shell-maker "0.62.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "a416349704392946826111e1a74455f3d8ea7801"
  :revdesc "a41634970439")
