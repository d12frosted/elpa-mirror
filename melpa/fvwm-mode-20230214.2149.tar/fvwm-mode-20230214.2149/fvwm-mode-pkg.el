;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fvwm-mode" "20230214.2149"
  "A major mode for editing Fvwm configuration files."
  ()
  :url "https://github.com/theBlackDragon/fvwm-mode"
  :commit "574c0370f6199c9a1492923bf0d35fdd26738d24"
  :revdesc "574c0370f619"
  :keywords '("files")
  :authors '(("Bert Geens" . "bert@lair.be"))
  :maintainers '(("Bert Geens" . "bert@lair.be")))
