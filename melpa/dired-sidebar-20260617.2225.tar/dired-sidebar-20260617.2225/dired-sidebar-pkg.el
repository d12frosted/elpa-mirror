;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-sidebar" "20260617.2225"
  "Tree browser leveraging dired."
  '((emacs         "29.1")
    (dired-subtree "0.0.1")
    (compat        "30.0.0.0"))
  :url "https://github.com/jojojames/dired-sidebar"
  :commit "87195352eabf027bf63a948573797ef74657d106"
  :revdesc "87195352eabf"
  :keywords '("dired" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
