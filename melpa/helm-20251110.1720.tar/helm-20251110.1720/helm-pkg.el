;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251110.1720"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "c27aec49eb6b8e9063cbd3dc016bec237d4231ec"
  :revdesc "c27aec49eb6b"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
