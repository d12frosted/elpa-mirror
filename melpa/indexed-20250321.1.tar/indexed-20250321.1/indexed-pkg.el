;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250321.1"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (llama  "0.5.0")
    (el-job "2.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f0f2cb9688eeb0dd656e45bedbc7366b13fb3946"
  :revdesc "f0f2cb9688ee"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
