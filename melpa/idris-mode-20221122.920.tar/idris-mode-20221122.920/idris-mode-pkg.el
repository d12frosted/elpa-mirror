(define-package "idris-mode" "20221122.920" "Major mode for editing Idris code"
  '((emacs "24")
    (prop-menu "0.1")
    (cl-lib "0.5"))
  :commit "cc85f0e138db34cdc04af19c0ad7c1042f690204" :keywords
  '("languages")
  :url "https://github.com/idris-hackers/idris-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
