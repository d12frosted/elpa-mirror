;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-yank" "20210220.1815"
  "Automagically create a Gist if pasting more than 5 lines."
  ()
  :url "https://github.com/jwiegley/erc-yank"
  :commit "55d96f18c5df9d8fce51fa073d7a12c47a46ac80"
  :revdesc "55d96f18c5df"
  :keywords '("comm" "erc" "chat" "irc" "yank" "gist")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("John Wiegley" . "jwiegley@gmail.com")))
