;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsonian" "20250420.810"
  "A major mode for editing JSON files."
  '((emacs "27.1"))
  :url "https://github.com/iwahbe/jsonian"
  :commit "4135e9290525964ac9926e3e5b45df1155678ed3"
  :revdesc "4135e9290525")
