;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "20260822.1405"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "c122e2be04978ff64e4058ec7eb3a165e628da21"
  :revdesc "c122e2be0497"
  :keywords '("wp" "convenience"))
