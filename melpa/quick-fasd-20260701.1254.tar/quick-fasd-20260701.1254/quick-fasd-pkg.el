;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20260701.1254"
  "Integration for the command-line tool `fasd'."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "40ac0f067b8c24ab4ac8283a9bf79655e586304f"
  :revdesc "40ac0f067b8c"
  :keywords '("convenience"))
