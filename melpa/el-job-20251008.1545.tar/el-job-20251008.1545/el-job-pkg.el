;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20251008.1545"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "6d72fdde4a62183a8870d467c80f6ff98bfe7ec1"
  :revdesc "6d72fdde4a62"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
