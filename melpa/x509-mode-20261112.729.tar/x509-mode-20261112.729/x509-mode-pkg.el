;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261112.729"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "22d01c15a4bebb1df8b41bd74b3d2566399aa5ae"
  :revdesc "22d01c15a4be"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
