;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-char-preview" "20260101.549"
  "Preview character when executing `goto-char` command."
  '((emacs "24.3"))
  :url "https://github.com/emacs-vs/goto-char-preview"
  :commit "b78fa6419466984b97459e95ffb77f3e9ae10a09"
  :revdesc "b78fa6419466"
  :keywords '("convenience" "character" "navigation")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
