;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qso" "20260928.2219"
  "Amateur radio QSO logging."
  '((emacs "25.1")
    (adif  "1.0.6"))
  :url "https://github.com/K6SM/Emacs-QSO-Logger"
  :commit "1cfa9190df5c52cf6b1f8253e1cb4916663e80af"
  :revdesc "1cfa9190df5c"
  :keywords '("comm" "hamradio" "adif" "logging"))
