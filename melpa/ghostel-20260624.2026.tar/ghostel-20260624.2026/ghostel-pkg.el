;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260624.2026"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "78e9677cf599f8c073efccd8baae7dfe9bbb1948"
  :revdesc "78e9677cf599"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
