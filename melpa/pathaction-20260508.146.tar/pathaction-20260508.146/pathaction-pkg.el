;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260508.146"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "72b4bb035e5bf96e27fffdf3e32cf5c3abb3cc44"
  :revdesc "72b4bb035e5b"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
