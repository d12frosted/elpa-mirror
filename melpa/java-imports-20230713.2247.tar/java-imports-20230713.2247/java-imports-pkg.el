;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "java-imports" "20230713.2247"
  "Code for dealing with Java imports."
  '((emacs  "24.4")
    (s      "1.10.0")
    (pcache "0.5.1"))
  :url "http://www.github.com/dakrone/emacs-java-imports"
  :commit "1489813795ecd061896e265720709040bd90d96f"
  :revdesc "1489813795ec"
  :keywords '("java" "kotlin")
  :authors '(("Lee Hinman" . "lee@writequit.org"))
  :maintainers '(("Lee Hinman" . "lee@writequit.org")))
