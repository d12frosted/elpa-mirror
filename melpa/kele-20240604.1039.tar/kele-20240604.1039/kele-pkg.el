(define-package "kele" "20240604.1039" "Spritzy Kubernetes cluster management"
  '((emacs "29.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (memoize "0")
    (plz "0.7.3")
    (s "1.13.0")
    (yaml "0.5.1"))
  :commit "48779977519adf0d63f05ee66b8591abf86a00b4" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
