;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "caskxy" "20140513.1539"
  "Control Cask in Emacs."
  '((log4e      "0.2.0")
    (yaxception "0.1"))
  :url "https://github.com/aki2o/caskxy"
  :commit "279f3ab79bd77fe69cb3148a79896b9bf118a9b3"
  :revdesc "279f3ab79bd7"
  :keywords '("convenience")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
