;;; guix-project.el --- Guix integration with projects  -*- lexical-binding: t -*-

;; Copyright © 2026 Sergio Pastor Pérez <sergio.pastorperez@gmail.com>

;; This file is part of Emacs-Guix.

;; Emacs-Guix is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; Emacs-Guix is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with Emacs-Guix.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; This package enhances 'project.el' so it can operate on Guix store item
;; checkouts in the store and in temporal build directories under '/tmp'.
;;
;; Since the package alters the state of the 'project.el' there are no autoload
;; directives defined.  In order to use it require it in your 'init.el':
;;
;; (require 'guix-project)
;;
;; Or interactively: 'M-x load-library RET guix-project RET'

;;; Code:

(require 'project)
(require 'rx)

(defvar guix-source-regex
  (rx (or
       (seq "/tmp/guix-build-"
            (group (+ (not (any "/"))))
            ".drv-"
            (+ digit)
            "/"
            (or (backref 1)
                "source")
            "/")
       (seq "/gnu/store/"
            (+ (not (any "/")))
            "/")))
  "Regex that matches either a directory in the Guix store or a checkout in
a temporal build directory.")

(defun guix-source-checkout-p (root)
  "Return t if project ROOT is a checkout in the Guix store or '/tmp'."
  (when (string-match guix-source-regex root)
    ;; HACK: we need to shape the return into something that `project-root'
    ;; cl-method can dispatch to.  The 'transient' one does the job.
    (cons 'transient
          (match-string 0 root))))

(add-hook 'project-find-functions #'guix-source-checkout-p)

;; Do not remember these ephemeral directories.
(setq project-list-exclude (cons guix-source-regex
                                 project-list-exclude))

(provide 'guix-project)

;;; guix-project.el ends here
