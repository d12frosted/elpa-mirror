;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20261113.1209"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3")
    (consult       "3.5"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "df1f6268c51027eb2cd5ec2e0efa77d55389775a"
  :revdesc "df1f6268c510"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
