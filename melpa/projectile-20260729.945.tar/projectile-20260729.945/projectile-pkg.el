;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260729.945"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "3ae0ce7ee050c0e98d6a605383a2f07c01e16862"
  :revdesc "3ae0ce7ee050"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
