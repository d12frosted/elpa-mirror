(define-package "org-roam-ql" "20230821.2334" "Interface to query and view results from org-roam"
  '((emacs "28")
    (org-roam "2.2.0")
    (s "1.12.0")
    (magit-section "3.3.0")
    (transient "0.4")
    (org-super-agenda "1.2"))
  :commit "588ef2952875761a1f4cfce598e79edf03e317bc" :authors
  '(("Shariff AM Faleel"))
  :maintainers
  '(("Shariff AM Faleel"))
  :maintainer
  '("Shariff AM Faleel")
  :url "https://github.com/ahmed-shariff/org-roam-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
