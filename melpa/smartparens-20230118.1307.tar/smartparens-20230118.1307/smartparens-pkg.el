(define-package "smartparens" "20230118.1307" "Automatic insertion, wrapping and paredit-like navigation with user defined pairs."
  '((dash "2.13.0")
    (cl-lib "0.3"))
  :commit "1c875af690a79bad175782d8ba1f09fad19da864" :authors
  '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matus Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("abbrev" "convenience" "editing")
  :url "https://github.com/Fuco1/smartparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
