;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-editor" "20261025.2008"
  "Use the Emacsclient as $EDITOR."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/magit/with-editor"
  :commit "9f56eb92ce7e47730ba52785564d09d8f13abe31"
  :revdesc "9f56eb92ce7e"
  :keywords '("processes" "terminals")
  :authors '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev")))
