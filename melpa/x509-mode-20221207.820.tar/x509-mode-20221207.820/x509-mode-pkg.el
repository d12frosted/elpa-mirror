(define-package "x509-mode" "20221207.820" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "e7b054d3be67e307eaf2ae6679f0b6962ee35724" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
