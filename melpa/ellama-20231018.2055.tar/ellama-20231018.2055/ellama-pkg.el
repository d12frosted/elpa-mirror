(define-package "ellama" "20231018.2055" "Ollama client for calling local LLMs"
  '((emacs "28.1")
    (spinner "1.7.4"))
  :commit "316e982ef656624c16d16d83d70cbfb550034ab9" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
