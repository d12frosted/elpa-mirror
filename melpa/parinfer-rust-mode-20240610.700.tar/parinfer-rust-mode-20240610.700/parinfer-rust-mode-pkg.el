(define-package "parinfer-rust-mode" "20240610.700" "An interface for the parinfer-rust library"
  '((emacs "26.1")
    (track-changes "1.1"))
  :commit "7b122c5d1c6263611d1d78d77b7a804332521b85" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
