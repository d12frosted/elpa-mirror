(define-package "org-modern" "20240428.741" "Modern looks for Org"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "a06443c1d0251decada41a3bdca30f712cf9a96e" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "text")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
