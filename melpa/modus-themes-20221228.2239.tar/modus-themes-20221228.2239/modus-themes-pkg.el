(define-package "modus-themes" "20221228.2239" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "3bcd88cb79a95acecedccc691353e02a13d54251" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
