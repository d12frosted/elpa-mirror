(define-package "org-ml" "20201225.1752" "Functional Org Mode API"
  '((emacs "26.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "502f724d3419fd913bbf2be5097ff97f49363756" :authors
  (("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  ("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :keywords
  ("org-mode" "outlines")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
