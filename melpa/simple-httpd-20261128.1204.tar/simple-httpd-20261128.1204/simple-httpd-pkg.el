;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20261128.1204"
  "Pure Elisp HTTP server."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "f3bf2c85149a316f6f806198ba1f560a04031b87"
  :revdesc "f3bf2c85149a"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
