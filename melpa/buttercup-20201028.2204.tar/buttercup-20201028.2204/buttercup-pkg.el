(define-package "buttercup" "20201028.2204" "Behavior-Driven Emacs Lisp Testing" 'nil :commit "2f24a44f31caf5e832bd48438b5424193c5213d1" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Jorgen Schaefer" . "contact@jorgenschaefer.de")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
