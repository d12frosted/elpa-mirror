(define-package "hyperdrive" "20240816.1834" "P2P filesystem"
  '((emacs "28.1")
    (map "3.0")
    (compat "30.0.0.0")
    (org "9.7.6")
    (plz "0.9.0")
    (persist "0.6.1")
    (taxy-magit-section "0.13")
    (transient "0.7.4"))
  :commit "74cd5f6ce35a20aed6872968d69ebdfcd2e035c6" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
