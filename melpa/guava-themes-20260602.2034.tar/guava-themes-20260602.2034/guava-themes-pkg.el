;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260602.2034"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "7317d9969461aff8e2cd838c9bfb6eea477b586e"
  :revdesc "7317d9969461"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
