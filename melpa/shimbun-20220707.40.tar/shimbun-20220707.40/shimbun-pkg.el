(define-package "shimbun" "20220707.40" "interfacing with web newspapers" 'nil :commit "6d19aab88f9a465d60134d37fad41826b61cf513" :authors
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
    ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
    ("Yuuichi Teranishi " . "teranisi@gohome.org")
    ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  '("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  '("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
