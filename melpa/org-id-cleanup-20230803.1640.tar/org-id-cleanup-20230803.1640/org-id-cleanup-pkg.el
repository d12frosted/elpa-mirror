(define-package "org-id-cleanup" "20230803.1640" "Interactively find, present and maybe delete unused IDs of org-id"
  '((org "9.3")
    (dash "2.12")
    (emacs "26.3"))
  :commit "588acb063f1c73025f973cbbba64a9f65a737bdd" :authors
  '(("Marc Ihm" . "marc@ihm.name"))
  :maintainers
  '(("Marc Ihm" . "marc@ihm.name"))
  :maintainer
  '("Marc Ihm" . "marc@ihm.name")
  :url "https://github.com/marcIhm/org-id-cleanup")
;; Local Variables:
;; no-byte-compile: t
;; End:
