;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260119.2349"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "10795b8877bde0541c3b166decc16835ab905f15"
  :revdesc "10795b8877bd")
