(define-package "extmap" "20230905.1753" "Externally-stored constant mapping for Elisp"
  '((emacs "24.1"))
  :commit "feec00acc54806e99b3240391548e8e6e482760c" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/doublep/extmap")
;; Local Variables:
;; no-byte-compile: t
;; End:
