;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260201.2049"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2e0ecf5e7abd13aaff3f0dde20249da35445e065"
  :revdesc "2e0ecf5e7abd")
