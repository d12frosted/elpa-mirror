;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260730.1805"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "5ec6f10b71e2cb4d5f8dabbb1941bd5bd42d6ac1"
  :revdesc "5ec6f10b71e2"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
