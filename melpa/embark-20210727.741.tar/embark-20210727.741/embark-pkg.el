(define-package "embark" "20210727.741" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "2b9053ffe26c4441cc12b28c865e66bf09382a9c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
