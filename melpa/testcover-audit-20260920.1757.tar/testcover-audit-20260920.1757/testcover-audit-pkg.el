;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "testcover-audit" "20260920.1757"
  "Quantitative coverage statistics for testcover.el."
  '((emacs   "27.1")
    (project "0.9.8"))
  :url "https://github.com/OverbearingPearl/testcover-audit"
  :commit "926f31e4e45a8337d13d3cc29561109245392cd2"
  :revdesc "926f31e4e45a"
  :keywords '("tools")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
