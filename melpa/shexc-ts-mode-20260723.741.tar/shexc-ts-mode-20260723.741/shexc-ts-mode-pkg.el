;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "20260723.741"
  "Tree-sitter major mode for ShExC."
  '((emacs     "29.1")
    (transient "0.5.0")
    (compat    "29.1.4.4"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "991beb5616d197b61b59ea36c0b23e21ac8026d1"
  :revdesc "991beb5616d1"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
