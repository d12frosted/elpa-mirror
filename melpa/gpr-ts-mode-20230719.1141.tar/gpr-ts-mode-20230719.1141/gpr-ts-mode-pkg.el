(define-package "gpr-ts-mode" "20230719.1141" "Major mode for GNAT project files using Tree-Sitter"
  '((emacs "29"))
  :commit "2fac9f29e446c202566e0cc83042de33758aad17" :authors
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainer
  '("Troy Brown" . "brownts@troybrown.dev")
  :keywords
  '("gpr" "gnat" "ada" "languages" "tree-sitter")
  :url "https://github.com/brownts/gpr-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
