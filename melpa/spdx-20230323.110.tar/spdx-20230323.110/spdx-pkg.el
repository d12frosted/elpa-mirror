(define-package "spdx" "20230323.110" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "ec718680d07b1b80598e7b2935445ec7e3706013" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
