;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-recoll" "20220920.1206"
  "Helm interface for the recoll desktop search tool."
  '((helm  "3.3")
    (emacs "24.4"))
  :url "https://github.com/emacs-helm/helm-recoll"
  :commit "c054047ecca360c3e02281d8d0c021f654e63f37"
  :revdesc "c054047ecca3"
  :keywords '("convenience")
  :authors '(("Thierry Volpiatto" . "thierry.volpiattoatgmail.com"))
  :maintainers '(("Joe Bloggs" . "vapniksatyahoo.com")
                 ("Michael Heerdegen" . "michael_heerdegenatweb.de")
                 ("Cayetano Santos" . "cayetanosantosatgmail.com")))
