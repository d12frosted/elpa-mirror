(define-package "lsp-dart" "20210818.228" "Dart support lsp-mode"
  '((emacs "26.1")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (pkg-info "0.4")
    (dart-mode "1.0.5"))
  :commit "5de57edaac9e5e3c34ac803752f98c5cf8ba3a52" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
