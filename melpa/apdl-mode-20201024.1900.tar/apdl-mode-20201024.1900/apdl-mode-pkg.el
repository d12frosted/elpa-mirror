(define-package "apdl-mode" "20201024.1900" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "178af26baac72890fca1904aa9e9c90bc1668a4c" :url "https://github.com/dieter-wilhelm/apdl-mode" :maintainer
  ("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de")
  :authors
  (("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :keywords
  ("APDL" "Ansys" "languages" "FEA" "convenience" "tools"))
;; Local Variables:
;; no-byte-compile: t
;; End:
