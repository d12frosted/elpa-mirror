;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260209.531"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "05af28aa80c24880e02de60fc07c32161135b3f5"
  :revdesc "05af28aa80c2"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
