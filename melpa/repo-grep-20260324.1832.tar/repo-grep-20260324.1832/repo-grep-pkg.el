;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "20260324.1832"
  "Project-wide grep search."
  '((emacs "27.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "90a42a1383e7232ff4e2384f20631d930f682b75"
  :revdesc "90a42a1383e7"
  :keywords '("tools" "search" "grep" "convenience" "project"))
