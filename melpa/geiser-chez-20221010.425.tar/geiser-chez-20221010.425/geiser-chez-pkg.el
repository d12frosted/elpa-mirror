(define-package "geiser-chez" "20221010.425" "Chez Scheme's implementation of the geiser protocols"
  '((emacs "26.1")
    (geiser "0.19"))
  :commit "53b7279550a06967f660656363daa87bb261a753" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chez" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chez")
;; Local Variables:
;; no-byte-compile: t
;; End:
