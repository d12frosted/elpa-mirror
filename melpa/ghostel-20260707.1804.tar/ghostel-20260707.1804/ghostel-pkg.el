;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260707.1804"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f0d7756040878b202217da7a20fe77dc332db169"
  :revdesc "f0d775604087"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
