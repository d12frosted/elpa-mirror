(define-package "modus-themes" "20210311.1314" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "bd673153104705cedbd97178dd5c2b0f8cfef984" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
