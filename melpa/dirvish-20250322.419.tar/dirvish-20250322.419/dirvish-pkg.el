;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250322.419"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "9c9fbe4201c9f9271dfe66ba6f3f1370e111a3c1"
  :revdesc "9c9fbe4201c9"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
