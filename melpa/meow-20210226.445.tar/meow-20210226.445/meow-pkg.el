(define-package "meow" "20210226.445" "Modal Editing On Wheel"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1")
    (s "1.12.0"))
  :commit "883b3f767c6e70ac3c006ba3ac8d419196c99dac" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
