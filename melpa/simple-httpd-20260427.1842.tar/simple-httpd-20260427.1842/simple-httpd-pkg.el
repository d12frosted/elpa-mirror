;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260427.1842"
  "Pure Elisp HTTP server."
  '((emacs  "26.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "7dacb738e6e75a965b25919853967479b6319951"
  :revdesc "7dacb738e6e7"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
