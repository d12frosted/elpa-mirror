;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaleidoscope" "20170808.817"
  "Controlling Kaleidoscope-powered devices."
  '((s "1.11.0"))
  :url "https://github.com/algernon/kaleidoscope.el"
  :commit "b89a243f6024099192f1bc38d8a54e3e7a654090"
  :revdesc "b89a243f6024")
