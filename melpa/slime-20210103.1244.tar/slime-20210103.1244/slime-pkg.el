(define-package "slime" "20210103.1244" "Superior Lisp Interaction Mode for Emacs"
  '((cl-lib "0.5")
    (macrostep "0.9"))
  :commit "144715838a75ff60c62fdf42139cb08ac1b6e99f" :keywords
  '("languages" "lisp" "slime")
  :url "https://github.com/slime/slime")
;; Local Variables:
;; no-byte-compile: t
;; End:
