;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatu" "20251113.2350"
  "Convert and insert any images to org-mode or markdown buffer."
  '((org           "9.6.6")
    (emacs         "29.1")
    (plantuml-mode "1.2.9"))
  :url "https://github.com/kimim/chatu"
  :commit "54fde21a03de78fc234ff3ce25a84fc4833adbca"
  :revdesc "54fde21a03de"
  :keywords '("multimedia" "convenience")
  :authors '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers '(("Kimi Ma" . "kimi.im@outlook.com")))
