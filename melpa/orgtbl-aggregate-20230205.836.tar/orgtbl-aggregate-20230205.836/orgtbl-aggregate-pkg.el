(define-package "orgtbl-aggregate" "20230205.836" "Create an aggregated Org table from another one"
  '((emacs "26.1"))
  :commit "4f9fcb4f7380b247d628b899135df23c8fc8b6f1" :keywords
  '("data" "extensions")
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
