;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250717.1048"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "bf2d6eba32f63ef2e5dc436e370aafcbad4dffb6"
  :revdesc "bf2d6eba32f6"
  :keywords '("languages"))
