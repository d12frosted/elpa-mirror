;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20251124.33"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "b4ccf22dd850f1cb1d532ae11d9ce5674d401aea"
  :revdesc "b4ccf22dd850"
  :keywords '("comm"))
