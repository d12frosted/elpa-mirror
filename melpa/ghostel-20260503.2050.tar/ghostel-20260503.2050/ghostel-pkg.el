;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260503.2050"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "d95910967c0989019b222b6a2b6ffeee9be908d4"
  :revdesc "d95910967c09"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
