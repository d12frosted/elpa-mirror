(define-package "corfu" "20231222.1723" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "9cebcfedca0ab165fcfc8a56acc2d2513a02b9e3" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
