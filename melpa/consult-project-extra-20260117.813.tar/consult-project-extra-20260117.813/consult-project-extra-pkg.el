;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-project-extra" "20260117.813"
  "Consult integration for project.el."
  '((emacs   "28.1")
    (consult "0.17")
    (project "0.8.1"))
  :url "https://github.com/Qkessler/consult-project-extra"
  :commit "2b3fa36fd3a14deacf594f4acd54d220d6890c55"
  :revdesc "2b3fa36fd3a1"
  :keywords '("convenience" "project" "management"))
