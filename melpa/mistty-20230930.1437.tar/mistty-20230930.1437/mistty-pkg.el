(define-package "mistty" "20230930.1437" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "12261f4843f839bb3c988dd63a009d27284964e6" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
