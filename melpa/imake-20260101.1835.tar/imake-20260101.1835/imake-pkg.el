;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imake" "20260101.1835"
  "Simple, opinionated make target runner."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/imake"
  :commit "c3d7fcc0d40676f47450891dc034511185566a0e"
  :revdesc "c3d7fcc0d406"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev")))
