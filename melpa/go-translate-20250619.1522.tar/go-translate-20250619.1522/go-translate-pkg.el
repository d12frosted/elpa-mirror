;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250619.1522"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "099a469bca192eeee0b3d0c493a62df8bf9a8d46"
  :revdesc "099a469bca19"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
