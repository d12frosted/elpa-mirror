;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260325.240"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "67e7e209952f1febc57cf52f759e88abf909d6f5"
  :revdesc "67e7e209952f"
  :keywords '("faces" "files" "q"))
