;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-sandbox" "20210325.1622"
  "Utility functions to work with nix-shell sandboxes."
  '((dash "2.12.1")
    (s    "1.10.0"))
  :url "https://github.com/travisbhartwell/nix-emacs"
  :commit "d3ec98405f1f9dac833abf9e146249b1b943870d"
  :revdesc "d3ec98405f1f"
  :authors '(("Sven Keidel" . "svenkeidel@gmail.com"))
  :maintainers '(("Sven Keidel" . "svenkeidel@gmail.com")))
