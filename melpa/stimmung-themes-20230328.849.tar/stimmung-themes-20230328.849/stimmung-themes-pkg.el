(define-package "stimmung-themes" "20230328.849" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "2af004d29f5b10de499ff7814f0b703a11ab4b6c" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
