(define-package "kagi" "20240420.1017" "Kagi API integration"
  '((emacs "29.1")
    (shell-maker "0.46.1"))
  :commit "d686d629b2585487cc3931626d1168c7808c0c73" :authors
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainer
  '("Bram Schoenmakers" . "me@bramschoenmakers.nl")
  :keywords
  '("terminals" "wp")
  :url "https://codeberg.org/bram85/kagi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
