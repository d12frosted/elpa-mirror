;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260404.345"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b807af0f1fe942a5166b6cf25b9e0ff2e7be9eba"
  :revdesc "b807af0f1fe9"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
