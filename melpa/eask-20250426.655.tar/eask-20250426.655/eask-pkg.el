;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20250426.655"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "65dd7f00d3aaaaacd5b96987ffc36db7acba5795"
  :revdesc "65dd7f00d3aa"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
