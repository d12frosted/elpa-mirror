(define-package "kurecolor" "20220815.1327" "color editing goodies"
  '((emacs "28.1")
    (s "1.12"))
  :commit "bcd6a38f91fb9e65e35b0f647f919922c0145160" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
