(define-package "kurecolor" "20220815.1327" "color editing goodies"
  '((emacs "28.1")
    (s "1.12"))
  :commit "c548c79d9d94d260f9a886e0db4ba809846df565" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
