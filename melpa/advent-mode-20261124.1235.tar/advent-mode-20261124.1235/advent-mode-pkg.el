;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20261124.1235"
  "Advent of Code mode."
  '((emacs "29.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "c17f6eb5886602be7ce39d0072a6f8fe8f02c05c"
  :revdesc "c17f6eb58866"
  :keywords '("lisp")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
