;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260913.550"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "77efeb09fe25f8c713dce32d93d52da9fd79084f"
  :revdesc "77efeb09fe25"
  :keywords '("convenience" "chinese" "input-method" "rime"))
