;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "peppers-theme" "20260817.1354"
  "Custom dark theme based on modus framework."
  '((emacs        "28.1")
    (modus-themes "4.0.0"))
  :url "https://codeberg.org/joar/peppers-theme"
  :commit "583aeafea8423629f3a4732facc682b5a8a53ced"
  :revdesc "583aeafea842"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Joar von Arndt" . "joarxpablo@vonarndt.se"))
  :maintainers '(("Joar von Arndt" . "joarxpablo@vonarndt.se")))
