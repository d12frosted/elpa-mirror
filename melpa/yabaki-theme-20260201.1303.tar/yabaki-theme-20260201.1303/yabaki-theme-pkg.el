;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yabaki-theme" "20260201.1303"
  "Yabaki, the cast shadow."
  '((emacs "27.1"))
  :url "https://codeberg.org/seahorse/yabaki-theme"
  :commit "eae3e0015da43f38a17b5a378f61c0f21fb83f79"
  :revdesc "eae3e0015da4"
  :authors '(("David Goudou" . "david.goudou@gmail.com"))
  :maintainers '(("David Goudou" . "david.goudou@gmail.com")))
