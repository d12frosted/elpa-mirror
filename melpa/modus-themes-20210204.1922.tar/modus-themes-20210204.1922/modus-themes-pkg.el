(define-package "modus-themes" "20210204.1922" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "dace3326471498d5d4626185180841df4e3fbb44" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
