;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backline" "20250514.1229"
  "Preserve appearance of outline headings."
  '((emacs               "26.1")
    (compat              "30.0.0.0")
    (outline-minor-faces "1.0.2"))
  :url "https://github.com/tarsius/backline"
  :commit "2fe9b5a7c8df8df13314522d9ed19a3de2cc697d"
  :revdesc "2fe9b5a7c8df"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev")))
