;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260324.1932"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "38714e1d0db162b6c3ab82ee1cd2ded2956b3762"
  :revdesc "38714e1d0db1"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
