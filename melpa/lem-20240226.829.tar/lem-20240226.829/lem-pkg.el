(define-package "lem" "20240226.829" "A lemmy client"
  '((emacs "29.1")
    (fedi "0.2")
    (markdown-mode "2.5"))
  :commit "9dfb5e20a941e18807dd58cf0804e0f1d6d83a9a" :authors
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainers
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainer
  '("martian hiatus <martianhiatus [a t] riseup [d o t] net>")
  :keywords
  '("multimedia" "comm" "web" "fediverse")
  :url "https://codeberg.org/martianh/lem.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
