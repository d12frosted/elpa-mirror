(define-package "eri" "20240220.711" "Enhanced relative indentation (eri)" 'nil :commit "90d82aef193d9148cf87d19ddb9ab677c739d788" :url "https://github.com/agda/agda")
;; Local Variables:
;; no-byte-compile: t
;; End:
