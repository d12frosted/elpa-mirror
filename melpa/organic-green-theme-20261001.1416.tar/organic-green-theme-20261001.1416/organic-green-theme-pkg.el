;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20261001.1416"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "858fbb67da99835836f6128b6438deaee9636499"
  :revdesc "858fbb67da99"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
