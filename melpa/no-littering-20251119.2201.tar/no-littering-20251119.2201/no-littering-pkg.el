;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20251119.2201"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "6da37e0b51540c3e0bae8d9e3a1aa51ad2188fa4"
  :revdesc "6da37e0b5154"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
