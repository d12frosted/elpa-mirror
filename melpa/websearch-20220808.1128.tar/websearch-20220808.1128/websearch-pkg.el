(define-package "websearch" "20220808.1128" "Query search engines"
  '((emacs "24.4"))
  :commit "b67c4d4e01adfb1756dc5e0eb0b86d9b6a923bd5" :authors
  '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainer
  '("Maciej Barć" . "xgqt@riseup.net")
  :keywords
  '("convenience" "hypermedia")
  :url "https://gitlab.com/xgqt/emacs-websearch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
