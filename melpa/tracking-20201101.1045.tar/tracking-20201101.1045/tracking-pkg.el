(define-package "tracking" "20201101.1045" "Buffer modification tracking" 'nil :commit "eccb12e476d54a41442f27086d4843d94f795f49" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
