(define-package "tracking" "20201101.1045" "Buffer modification tracking" 'nil :commit "107b74c9f4318eaa385819876cd8772ef650d1f4" :authors
  (("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  ("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
