(define-package "tracking" "20201101.1045" "Buffer modification tracking" 'nil :commit "4778675e0c3bde1c028085b7d96693fe033d2c72" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
