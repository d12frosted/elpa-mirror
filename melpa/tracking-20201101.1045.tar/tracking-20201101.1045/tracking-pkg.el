(define-package "tracking" "20201101.1045" "Buffer modification tracking" 'nil :commit "7386df382d6cc819c9f6290c185f3f962339afd1" :authors
  (("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  ("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
