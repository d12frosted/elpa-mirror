(define-package "selectrum" "20210117.1934" "Easily select item from list"
  '((emacs "25.1"))
  :commit "1a51fdf7849d99fb8bb9ae5f688fb718e3ea47f1" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
