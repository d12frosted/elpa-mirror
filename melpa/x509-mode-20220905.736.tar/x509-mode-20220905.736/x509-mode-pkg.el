(define-package "x509-mode" "20220905.736" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "44d2b212ab1c371849101b31dfeacabfe643d23a" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
