;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260529.1108"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "904f8dcb1164291c2486048e19ed76fd60062e90"
  :revdesc "904f8dcb1164")
