(define-package "mastodon" "20220903.1634" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0"))
  :commit "23013ff6daa54c8268c6f5b791270b78e1ac7eb0" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
