;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20250623.2324"
  "Client libraries for Git forge APIs."
  '((emacs     "29.1")
    (compat    "30.1")
    (let-alist "1.0.6")
    (llama     "0.6.3")
    (treepy    "0.1.2"))
  :url "https://github.com/magit/ghub"
  :commit "d0576a1375c12f7611131e0187ac7275e2f32907"
  :revdesc "d0576a1375c1"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
