(define-package "posframe" "20211103.542" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "3effe69038de5e21c47b658e4dd11d3baf3e208d" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
