;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chocolate-theme" "20210128.1647"
  "A dark chocolaty theme."
  '((emacs      "24.1")
    (autothemer "0.2"))
  :url "https://github.com/SavchenkoValeriy/emacs-chocolate-theme"
  :commit "ccc05f7ad96d3d1332727689bf6250443adc7ec0"
  :revdesc "ccc05f7ad96d"
  :authors '(("Valeriy Savchenko" . "sinmipt@gmail.com"))
  :maintainers '(("Valeriy Savchenko" . "sinmipt@gmail.com")))
