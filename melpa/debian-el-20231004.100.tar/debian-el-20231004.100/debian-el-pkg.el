(define-package "debian-el" "20231004.100" "Emacs helpers specific to Debian users" 'nil :commit "03b9e00e581231233a08361dbaa359b01669dd3f")
;; Local Variables:
;; no-byte-compile: t
;; End:
