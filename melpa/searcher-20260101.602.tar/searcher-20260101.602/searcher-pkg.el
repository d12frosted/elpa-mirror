;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "searcher" "20260101.602"
  "Searcher in pure elisp."
  '((emacs "25.1")
    (dash  "2.10")
    (f     "0.20.0"))
  :url "https://github.com/jcs-elpa/searcher"
  :commit "b9ffe260b8d5303a83e73ed44f81d77fb260c43d"
  :revdesc "b9ffe260b8d5"
  :keywords '("convenience" "search" "searcher" "string")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
