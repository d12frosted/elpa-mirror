(define-package "meow" "20220328.1431" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "6a0e74eb2ef507818291cd53dd5757435d6c79f8" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
