;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260527.1523"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "02f962d67012df17c98eda5d83c75f8416a56982"
  :revdesc "02f962d67012"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
