;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-forward" "20140430.713"
  "Semantic navigation."
  '((expand-region "0.8.0"))
  :url "https://github.com/magnars/smart-forward.el"
  :commit "7b6dbfdbd4b646376a567c70e1a161545431b72b"
  :revdesc "7b6dbfdbd4b6"
  :keywords '("navigation")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
