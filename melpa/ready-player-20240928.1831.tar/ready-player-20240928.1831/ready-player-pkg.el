(define-package "ready-player" "20240928.1831" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "b7689a91c17eec7879120c6b5e0da20b0b8f9174" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
