;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu2tex" "20200512.704"
  "Convert plain text molecule names and units to TeX."
  ()
  :url "https://github.com/cdominik/mu2tex"
  :commit "4b84cdac955cb36a8c44a2be48f3310252e3d3ad"
  :revdesc "4b84cdac955c"
  :keywords '("tex")
  :authors '(("Carsten Dominik" . "carsten.dominik@gmail.com"))
  :maintainers '(("Carsten Dominik" . "carsten.dominik@gmail.com")))
