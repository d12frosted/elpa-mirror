(define-package "vulpea" "20221123.646" "A collection of org-roam note-taking functions"
  '((emacs "27.2")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12")
    (dash "2.19"))
  :commit "846fe12effccb7a08cb68b85d6b1805d0d872f39" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
