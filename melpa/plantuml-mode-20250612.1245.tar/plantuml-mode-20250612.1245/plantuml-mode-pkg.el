;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plantuml-mode" "20250612.1245"
  "Major mode for PlantUML."
  '((dash  "2.0.0")
    (emacs "25.0"))
  :url "https://github.com/skuro/plantuml-mode"
  :commit "8278e91422eb42cf7ed6125bfbb28e571d293eb8"
  :revdesc "8278e91422eb"
  :keywords '("uml" "plantuml" "ascii"))
