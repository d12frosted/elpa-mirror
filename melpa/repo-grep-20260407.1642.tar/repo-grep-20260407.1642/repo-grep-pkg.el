;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "20260407.1642"
  "Project-wide grep search."
  '((emacs "27.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "237bba04c330e079f04bbd0f03721c97ccffec01"
  :revdesc "237bba04c330"
  :keywords '("tools" "search" "grep" "convenience" "project"))
