;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ansible-lint" "20260215.2013"
  "A Flymake backend for ansible-lint."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/flymake-ansible-lint.el"
  :commit "580ae9b179aab4ee4b90c07be0b82a80f314ccf8"
  :revdesc "580ae9b179aa"
  :keywords '("tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
