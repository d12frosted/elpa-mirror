;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20251109.130"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "79cbb54befd5e00d2e1027092823d823122e4a5f"
  :revdesc "79cbb54befd5"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
