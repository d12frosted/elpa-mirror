;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250430.1058"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "28.1")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "e689d522dc30cf21e7ebd5e50edd9e67a8e58f0b"
  :revdesc "e689d522dc30"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
