(define-package "ebib" "20240305.738" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "26.1")
    (compat "29.1.4.3"))
  :commit "8679b8db0e1de46409fb7a0e1a36a399119549b4" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
