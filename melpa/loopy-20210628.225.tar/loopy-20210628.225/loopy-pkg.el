(define-package "loopy" "20210628.225" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "90d1d0e2d281d600faf4385d50eec8a55df7f5f8" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
