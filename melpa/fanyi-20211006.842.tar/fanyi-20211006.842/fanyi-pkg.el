(define-package "fanyi" "20211006.842" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "4deddb48b5c9798bdb68a341a9cd23056b4fb2c4" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
