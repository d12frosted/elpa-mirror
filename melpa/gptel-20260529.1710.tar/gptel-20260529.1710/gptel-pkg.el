;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260529.1710"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "447d5cedd1862a45d8b821ceec04f61d6e2b4bd3"
  :revdesc "447d5cedd186"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
