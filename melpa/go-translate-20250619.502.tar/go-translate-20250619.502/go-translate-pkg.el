;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250619.502"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "3887a37de6d4be21c86ee5515c348a46a1383e6c"
  :revdesc "3887a37de6d4"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
