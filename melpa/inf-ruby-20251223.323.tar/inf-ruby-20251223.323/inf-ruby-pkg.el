;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-ruby" "20251223.323"
  "Run a Ruby process in a buffer."
  '((emacs "26.1"))
  :url "http://github.com/nonsequitur/inf-ruby"
  :commit "03f3b202d7368992855d5fd3b5486b855fb37e05"
  :revdesc "03f3b202d736"
  :keywords '("languages" "ruby")
  :authors '(("Cornelius Mika" . "cornelius.mika@gmail.com")
             ("Dmitry Gutov" . "dgutov@yandex.ru")
             ("Kyle Hargraves" . "pd@krh.me"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
