;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "npm" "20241222.1203"
  "Run your npm workflows."
  '((emacs     "25.1")
    (transient "0.1.0")
    (jest      "20220807.2243"))
  :url "https://github.com/shaneikennedy/npm.el"
  :commit "70b55636955111c16cdb39630f1c1a7c054286f9"
  :revdesc "70b556369551"
  :keywords '("tools"))
