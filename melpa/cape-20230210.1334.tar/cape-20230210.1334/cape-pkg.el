(define-package "cape" "20230210.1334" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "2f8daa2ecadfda3c4c1c1a630243bbc0586b34f1" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
