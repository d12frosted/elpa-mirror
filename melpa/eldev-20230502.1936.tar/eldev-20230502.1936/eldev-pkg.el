(define-package "eldev" "20230502.1936" "Elisp development tool"
  '((emacs "24.4"))
  :commit "9fefb32f0cfd7c4d3fb5cfed8d777e12218271c3" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
