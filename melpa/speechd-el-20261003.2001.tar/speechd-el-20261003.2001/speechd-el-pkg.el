;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speechd-el" "20261003.2001"
  "Info file for package managers."
  ()
  :url "https://github.com/brailcom/speechd-el"
  :commit "ac938ce803680c52599f47ae0fa0b054e58fba15"
  :revdesc "ac938ce80368"
  :authors '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainers '(("Milan Zamazal" . "pdm@zamazal.org")))
