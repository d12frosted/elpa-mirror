(define-package "elbank" "20180316.1343" "Personal finances reporting application"
  '((emacs "25")
    (seq "2.16"))
  :commit "6dbd21e31fdf7cf62491f6d24b8198d4f91a031b" :authors
  '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainer
  '("Nicolas Petton" . "nicolas@petton.fr")
  :keywords
  '("tools" "personal-finances"))
;; Local Variables:
;; no-byte-compile: t
;; End:
