;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi-project" "20260513.1126"
  "Find files, compile, and search in multiple projects."
  '((emacs "26.1"))
  :url "https://github.com/ellisvelo/multi-project.git"
  :commit "1ddfd60410dd146c59e9950ef88c5f0084807012"
  :revdesc "1ddfd60410dd"
  :keywords '("convenience" "project" "management")
  :authors '(("Shawn Ellis" . "shawn.ellis17@gmail.com"))
  :maintainers '(("Shawn Ellis" . "shawn.ellis17@gmail.com")))
