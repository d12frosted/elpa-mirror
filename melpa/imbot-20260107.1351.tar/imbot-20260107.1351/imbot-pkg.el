;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260107.1351"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "16352f8d05eb96ba2644ebf52606fd85b657a9a9"
  :revdesc "16352f8d05eb"
  :keywords '("convenience" "input method" "dbus"))
