;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective" "20260614.1712"
  "Switch between named \"perspectives\" of the editor."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/nex3/perspective-el"
  :commit "9a44b55acfa8be2854dd2afb7aba7a25d825e9a3"
  :revdesc "9a44b55acfa8"
  :keywords '("workspace" "convenience" "frames")
  :authors '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers '(("Natalie Weizenbaum" . "nex342@gmail.com")))
