;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260208.2054"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "653f07f256eaf8551f5b5d4561b00a89721943c0"
  :revdesc "653f07f256ea")
