;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-defaults" "20260516.316"
  "Awesome leaf config collections."
  '((emacs         "26.1")
    (leaf          "4.1")
    (leaf-keywords "1.1"))
  :url "https://github.com/conao3/leaf-defaults.el"
  :commit "f435f79390d4ba62a6b756aa985c73918d1f26f6"
  :revdesc "f435f79390d4"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
