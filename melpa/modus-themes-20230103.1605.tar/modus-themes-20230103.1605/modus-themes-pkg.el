(define-package "modus-themes" "20230103.1605" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "953f70236dbc19aa9e9610714ba26379ef366e25" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
