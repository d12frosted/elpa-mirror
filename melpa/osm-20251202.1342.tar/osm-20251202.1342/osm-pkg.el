;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251202.1342"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "5fdbad233924e5f40ae12dfd01c778c53c781fa6"
  :revdesc "5fdbad233924"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
