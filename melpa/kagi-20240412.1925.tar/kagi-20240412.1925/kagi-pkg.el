(define-package "kagi" "20240412.1925" "Kagi API integration"
  '((emacs "29.1")
    (shell-maker "0.46.1"))
  :commit "69ca50537cf1196dfc28b9460cfc234d8568bfc3" :authors
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainer
  '("Bram Schoenmakers" . "me@bramschoenmakers.nl")
  :keywords
  '("terminals" "wp")
  :url "https://codeberg.org/bram85/kagi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
