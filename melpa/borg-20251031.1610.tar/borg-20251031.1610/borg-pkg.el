;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20251031.1610"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "27.1")
    (epkg  "4.1")
    (magit "4.4"))
  :url "https://github.com/emacscollective/borg"
  :commit "3dabd57f7269416ff57d70fa16f39077c63fbd2e"
  :revdesc "3dabd57f7269"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
