;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mybuild-mode" "20221007.1928"
  "Major mode for editing Mybuild files from Embox."
  '((emacs "24.3"))
  :url "https://github.com/easimonenko/mybuild-mode"
  :commit "54e3c31e3b5f133eb8611a3759e59733b17e33e3"
  :revdesc "54e3c31e3b5f"
  :keywords '("languages")
  :authors '(("Evgeny Simonenko" . "easimonenko@gmail.com"))
  :maintainers '(("Evgeny Simonenko" . "easimonenko@gmail.com")))
