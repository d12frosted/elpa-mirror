;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260128.1627"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "c6cdb86950fafcf9902da067f2314997fd1f7b94"
  :revdesc "c6cdb86950fa"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
