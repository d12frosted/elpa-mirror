;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260504.2154"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "7d611ea0e59b1a58095fdb136d73aec1f2d1c168"
  :revdesc "7d611ea0e59b"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
