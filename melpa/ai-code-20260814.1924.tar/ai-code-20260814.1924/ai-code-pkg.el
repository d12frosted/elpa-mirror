;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260814.1924"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "ec46ea9fd667ab72b046c710d17783c6491f27f6"
  :revdesc "ec46ea9fd667"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
