(define-package "racket-mode" "20220801.1757" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "b0c8d71f5622a2fe7c2dfb3a27fcbc07bd582c90" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
