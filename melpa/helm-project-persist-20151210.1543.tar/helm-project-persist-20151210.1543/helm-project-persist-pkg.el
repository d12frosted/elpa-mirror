;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-project-persist" "20151210.1543"
  "Helm integration for project-persist package."
  '((helm            "1.5.2")
    (project-persist "0.1.4"))
  :url "https://github.com/Sliim/helm-project-persist"
  :commit "357950fbac18090985a750e40d5d8b10ee9dcd53"
  :revdesc "357950fbac18"
  :keywords '("project-persist" "project" "helm")
  :authors '(("Sliim" . "sliim@mailoo.org"))
  :maintainers '(("Sliim" . "sliim@mailoo.org")))
