;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "j-mode" "20260328.1226"
  "Major mode for editing J programs."
  ()
  :url "https://github.com/zellio/j-mode"
  :commit "e49ef0692d73b320c281e40d9fa96b2c17073695"
  :revdesc "e49ef0692d73"
  :keywords '("j" "languages")
  :authors '(("Zachary Elliott" . "ZacharyElliott1@gmail.com"))
  :maintainers '(("Zachary Elliott" . "ZacharyElliott1@gmail.com")))
