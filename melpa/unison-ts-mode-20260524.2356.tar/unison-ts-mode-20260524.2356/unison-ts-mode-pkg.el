;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-ts-mode" "20260524.2356"
  "Tree-sitter support for Unison."
  '((emacs "29.1"))
  :url "https://github.com/fmguerreiro/unison-ts-mode"
  :commit "c14947ebbe3e1ef8282e320aaaa1cb4678d2a775"
  :revdesc "c14947ebbe3e"
  :keywords '("languages" "unison" "tree-sitter")
  :authors '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com"))
  :maintainers '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com")))
