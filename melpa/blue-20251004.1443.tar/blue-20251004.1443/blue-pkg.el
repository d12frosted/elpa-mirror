;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251004.1443"
  "BLUE build system interface."
  '((emacs "30.1"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "cb1bd2465ae56280687097fd342023daa44c7039"
  :revdesc "cb1bd2465ae5"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
