;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-notmuch" "20261117.1121"
  "Links to notmuch messages."
  '((emacs   "29.1")
    (compat  "31.1")
    (notmuch "0.39")
    (org     "9.8"))
  :url "https://github.com/tarsius/ol-notmuch"
  :commit "95b2900606ed7a93cff7ec1a91895ed0eabfbec9"
  :revdesc "95b2900606ed"
  :keywords '("hypermedia" "mail")
  :authors '(("Matthieu Lemerre" . "racin@free.fr"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ol-notmuch@jonas.bernoulli.dev")))
