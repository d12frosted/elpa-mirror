;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "find-file-rg" "20220314.1540"
  "Find file in project using ripgrep."
  '((emacs "25.1"))
  :url "https://github.com/muffinmad/emacs-find-file-rg"
  :commit "404b1cc97c2f700d3dc1c66b640f96ed5a268dc3"
  :revdesc "404b1cc97c2f"
  :keywords '("tools")
  :authors '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com"))
  :maintainers '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com")))
