(define-package "modus-themes" "20220510.332" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "6117ec171bdfb3df5e5d43e8995bdbbd23267ae3" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
