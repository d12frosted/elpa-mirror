(define-package "spdx" "20220318.106" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "251b9e7e5ba3a92ea26c3d676b9e76f8c42b2654" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
