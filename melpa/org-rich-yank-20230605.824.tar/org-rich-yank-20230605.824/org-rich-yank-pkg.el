(define-package "org-rich-yank" "20230605.824" "Paste with org-mode markup and link to source"
  '((emacs "24.4"))
  :commit "9d840c04cba45d245d0dbb4147d6a2b865f45cb5" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("convenience" "hypermedia" "org")
  :url "https://github.com/unhammer/org-rich-yank")
;; Local Variables:
;; no-byte-compile: t
;; End:
