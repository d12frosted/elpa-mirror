(define-package "consult" "20210312.1143" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "bd58f2e3b7a9bd52145aa97997e62ec5d9e7e4d5" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
