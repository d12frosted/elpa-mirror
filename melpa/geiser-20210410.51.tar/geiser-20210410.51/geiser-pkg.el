(define-package "geiser" "20210410.51" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "003c9aec8d678ad2392fed25e83fa07d5ec875ef" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
