;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osa-chrome" "20250129.1831"
  "Google Chrome remote tab control."
  '((emacs "25.1")
    (osa   "1.0"))
  :url "https://github.com/atomontage/osa-chrome"
  :commit "53a139a6c56d52d9bddbf420b0e65f042a1259eb"
  :revdesc "53a139a6c56d"
  :keywords '("comm")
  :authors '(("xristos" . "xristos@sdf.org"))
  :maintainers '(("xristos" . "xristos@sdf.org")))
