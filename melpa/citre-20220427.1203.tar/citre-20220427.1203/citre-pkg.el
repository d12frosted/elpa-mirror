(define-package "citre" "20220427.1203" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "87e2cbf3b2ae6d59ec919a2dcb38e56ccfa5ec14" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
