;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "20250416.1246"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "6357317ef9e887da3f6e0d7fc08cdeac67110b14"
  :revdesc "6357317ef9e8"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
