;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260427.323"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "d0076b893a610cf068bc5ba488d067ea687f1fa8"
  :revdesc "d0076b893a61"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
