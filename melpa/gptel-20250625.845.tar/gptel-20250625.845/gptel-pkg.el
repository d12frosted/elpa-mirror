;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250625.845"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "5341ec71b6ffccf1822c7c6e31930f990d5842fd"
  :revdesc "5341ec71b6ff"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
