;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20261124.1419"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "244a4e70b97878e362512de06d45df74b5597f19"
  :revdesc "244a4e70b978"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
