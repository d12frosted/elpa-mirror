;;; daselt-cdlatex.el --- daselt-commands for cdlatex  -*- lexical-binding: t; -*-

;; Copyright (C) 2024, 2025  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Package-Requires: ((emacs "29.1"))
;; Version: 1.0
;; Keywords: tools
;; URL: https://gitlab.com/nameiwillforget/d-emacs/daselt-mode/

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;;
;;; Code:

(defun daselt-cdlatex-math-symbol ()
  "This is a modified version of cdlatex-math-symbol that ensures no math
delimiters are inserted when it is used in the minibuffer and during searches."
  (interactive)
  (let* ((cell (cdlatex-read-char-with-help
                cdlatex-math-symbol-alist-comb
                1 cdlatex-math-symbol-no-of-levels
                "Math symbol level %d of %d: "
                "AVAILABLE MATH SYMBOLS.  [%c]=next level "
                cdlatex-math-symbol-prefix
                (get 'cdlatex-math-symbol-alist-comb 'cdlatex-bindings)))
         (char (car cell))
         (level (cdr cell))
         (entry (assoc char cdlatex-math-symbol-alist-comb))
         (symbol (nth level entry)))
    (if (or (not symbol)
            (not (stringp symbol))
            (equal symbol ""))
        (error "No such math symbol %c on level %d" char level))
    (unless (or (derived-mode-p 'minibuffer-mode)
                (derived-mode-p 'isearch-mode))
      (cdlatex-ensure-math))
    (insert symbol)
    (when (string-match "\\?" symbol)
      (cdlatex-position-cursor))))

(defun daselt-cdlatex-math-modify (&optional arg)
  "This is a wrapper around `cdlatex-math-modify' that uses the prefix arg to
determine whether point is a minibuffer."
  (interactive "P")
  (let ((minibuffer-or-isearch t))
    (cl-letf (((symbol-function #'cdlatex--texmathp)
               (lambda () (if (or (derived-mode-p 'minibuffer-mode)
                                  (derived-mode-p 'isearch-mode))
                          arg
                        (symbol-function #'cdlatex--texmathp)))))
      (cdlatex-math-modify (unless minibuffer-or-isearch current-prefix-arg)))))

(defun daselt-cdlatex-math-modify-modeline-math ()
  "This is a wrapper around `daselt-cdlatex-math-modify' that adds an argument,
so d-cdlatex-math-modify-modeline is called for math-symbols."
  (interactive)
  (daselt-cdlatex-math-modify t))

(provide 'daselt-cdlatex)
;;; daselt-cdlatex.el ends here
