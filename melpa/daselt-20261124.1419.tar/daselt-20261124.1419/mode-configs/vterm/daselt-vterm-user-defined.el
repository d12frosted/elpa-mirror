;;; daselt-vterm-user-defined.el --- User-defined Daselt commands for vterm  -*- lexical-binding: t; -*-

(declare-function alias-edit-add "alias-edit")

(defun daselt-vterm-add-alias ()
  ""
  (declare (ftype (function () t)))
  (interactive)
  (let ((buffer (current-buffer)))
    (save-excursion
      (alias-edit-add (read-string "Expansion: ")
                      (thing-at-point 'sexp t))
      (async-shell-command "guix home reconfigure /home/alex/src/guix/conf/home.scm")
      (set-buffer buffer))))

(defun daselt-vterm-add-alias-expansion ()
  ""
  (declare (ftype (function () t)))
  (interactive)
  (let ((buffer (current-buffer))
        (expansion (if (region-active-p)
                       (buffer-substring (region-beginning)
                                         (region-end))
                     (save-excursion
                       (backward-word)
                       (thing-at-point 'sexp t)))))
    (alias-edit-add expansion)
    (async-shell-command "guix home reconfigure /home/alex/src/guix/conf/home.scm")
    (set-buffer buffer)))
