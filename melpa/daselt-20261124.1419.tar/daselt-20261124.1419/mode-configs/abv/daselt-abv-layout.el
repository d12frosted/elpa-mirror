;;; daselt-abv-layout.el --- Daselt abv layout class & helpers  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; License: GPL-3+

;;; Commentary:

;; This file is the foundation of the Daselt abv integration.  It
;; defines the `daselt-abv-layout' class (a subclass of
;; `abv-typed-layout'), the default layout instance
;; (`daselt-abv--default-layout'), and the assorted coordinate,
;; placeval, indexed-sequence and lookup helpers that the rest of the
;; Daselt abv modules build on.

;;; Code:

(declare-function daselt-bind-bindlist-p "daselt-bind")
(declare-function daselt-bind--get-unique-layout-match "daselt-bind")



(require 'abv-typed-layout)
(require 'abv-language)
(require 'cl-lib)
(require 'abv-name-table)
(require 'abv-corpus)
(require 'abv-layout)
(require 'abv-morph)
(require 'dash)
(require 'abv-weights)
(require 'abv-measure)
(require 'abv-english)
(require 'abv-german)
(require 'abv-corpus-language-statistics)

(defvar daselt-dfk-layout)
;; Pre-declared here: its value is produced at runtime by
;; `daselt-dfk-import-current-layout' from daselt-dfk.el.

(declare-function daselt-abv--erg-score "daselt-abv-ergonomics" (coord))

(defvar daselt-abv-untyped nil
  "List of root strings that failed to be assigned a typing during generation.")
(defvar daselt-abv-undistilled nil
  "List of rich morph sequences that failed to produce a valid distillate.")

(defclass daselt-abv-layout-options (abv-layout-options)
  ((prefer-first-up-to :initarg :prefer-first-up-to :type (or boolean number)
                       :initform 100
                       :documentation "Prefer to use the first letter up to this number of already assigned one-symbol deep-structures.

Only used by `abv-typed-layout-type-root'."))
  :documentation "Options of a `daselt-abv-layout'.")

(defclass daselt-abv-layout (abv-typed-layout)
  ((letter-frequency-alist :initarg :letter-frequency-alist :initform nil :type list)
   (options :initarg :options
            :initform (make-instance 'daselt-abv-layout-options)
            :documentation "All options of this layout; see the
`daselt-abv-layout-options' class."))
  "Daselt-specific ABV layout class.

This class inherits from `abv-typed-layout' but allows us to
specialize methods for Daselt behavior without affecting other layout
types.")

(defun daselt-abv--filter-to-paired (placevals)
  "Filter PLACEVALS to only those that form lower-upper layer pairs.

The filtering uses a predefined mapping of paired layers."
  (let* ((pairs '((1 . 2) (4 . 3) (5 . 6) (8 . 7))))
    (cl-remove-if-not (lambda (pv)
                        (pcase-let* ((`(,L ,r ,c) (car pv))
                                     (upper (cdr (assoc L pairs))))
                          (alist-get (list upper r c) placevals
                                     nil nil #'equal)))
                      placevals)))

(defun daselt-abv--generate-default-layout ()
  "Generate and return the default `daselt-abv-layout' instance.

Computes valid placevals, applies class filters and separator rules, sets up the
layer pairs, and calculates root, prefix, infix, and suffix placevals for
Daselt. Also sets the default save file location."
  (let* ((script (abv-script))
         (parse-data (abv-parse-data)))
    (cl-flet* ((get-signs (syms)
                 (cl-remove-duplicates
                  (apply #'append (mapcar (lambda (sym)
                                            (let ((signs (slot-value
                                                          (if (memq sym '(expansion-beginning-separator
                                                                          expansion-end-separator
                                                                          syntax-separator))
                                                              parse-data
                                                            script)
                                                          sym)))
                                              (if (atom signs)
                                                  (list signs)
                                                signs)))
                                          syms))))
               (remove-signs (syms placevals)
                 (cl-remove-if (lambda (pv)
                                 (let ((signs (get-signs syms)))
                                   (cl-member (string-to-char (cdr pv))
                                              signs
                                              :test #'=)))
                               placevals))
               (remove-positions (posns placevals)
                 (cl-remove-if (lambda (pv)
                                 (cl-member (car pv) posns :test #'equal))
                               placevals)))

      (let* ((candidate-placevals
              (cl-remove-if
               (lambda (cons) (< 1 (length (cdr cons))))
               (daselt-base-flatten-n-times
                (cdr (daselt-coords-coordinatize-layout
                      (symbol-value daselt-dfk-layout)))
                2)))
              (special-positions '((1 -1 -3) (1 -1 3) ; Separators for parsing
                                   (3 1 0) ; Major mode prefix
                                   (4 1 0) ; Capitalization prefix
                                   (5 1 0) ; Name prefix
                                   (6 1 0) ; Language prefix
                                   (7 1 0) ; Function key
                                   (8 1 0) ; Minor mode prefix
                                   (4 -1 -2) ; LaTeX math-mode
                                   (4 -1 2) ; Yasnippets
                                   ))
             (standard-placevals (remove-positions
                                  special-positions
                                  (remove-signs '(morph-separator-signs
                                                  word-separator-signs
                                                  line-separator-signs
                                                  opening-bracket-signs
                                                  closing-bracket-signs
                                                  quotation-signs
                                                  subsentence-separator-signs
                                                  sentence-separator-signs
                                                  expansion-beginning-separator
                                                  expansion-end-separator
                                                  syntax-separator)
                                                candidate-placevals)))
              (special-prefix-positions '((3 1 0) ; Major mode prefix
                                          (4 1 0) ; Capitalization prefix
                                          (5 1 0) ; Name prefix
                                          (6 1 0) ; Language prefix
                                          (7 1 0) ; Function key
                                          (8 1 0) ; Minor mode prefix
                                          ))
             (prefix-placevals (remove-positions special-prefix-positions standard-placevals))
             (suffix-placevals standard-placevals)
             (infix-placevals standard-placevals)
             (root-placevals prefix-placevals)
             (standalone-placevals prefix-placevals)
             (separator-placevals `(((4 2 0) . "␠") ((6 2 0) . "␟")))

             (layer-pairs '((1 . 2) (4 . 3) (5 . 6) (8 . 7)))
             (save-file
              (let ((dir (ignore-errors
                           (and (boundp 'daselt-mode-pkg-configs-directory)
                                (file-name-as-directory
                                 daselt-mode-pkg-configs-directory)))))
                (expand-file-name
                 (concat (or dir (file-name-as-directory user-emacs-directory))
                         "abv/save.el"))))

             (lower-paired-prefix-placevals (daselt-abv--filter-to-paired
                                             prefix-placevals))

             (lower-paired-suffix-placevals (daselt-abv--filter-to-paired
                                             suffix-placevals))

             (lower-paired-root-placevals (daselt-abv--filter-to-paired
                                           root-placevals)))
        (make-instance 'daselt-abv-layout
                       :name "daselt-default"
                       ;; :separators '(?- ?_ ?: ?. ?, ?! ?? ?' ?` ?\⟨ ?\⟩ ?\  ?\t ?\n)
                       :single-symbol-placevals standard-placevals
                       :layer-pairs layer-pairs
                       :save-file save-file
                       :prefix-placevals prefix-placevals
                       :lower-paired-prefix-placevals lower-paired-prefix-placevals
                       :suffix-placevals suffix-placevals
                       :lower-paired-suffix-placevals lower-paired-suffix-placevals
                       :infix-placevals infix-placevals
                       :root-placevals root-placevals
                       :lower-paired-root-placevals lower-paired-root-placevals
                       :standalone-placevals standalone-placevals
                       :separator-placevals separator-placevals
                       :standard-placevals standard-placevals
                       :weights (abv-weights)
                       :prefer-first-up-to 100)))))


(defun daselt-abv--seq-placevals (seq)
  "Return plain placevals from SEQ.

SEQ can be a list of placevals (plain) or indexed placevals."
  (if (and seq (consp (car seq)) (stringp (cdar seq)))
      seq
    (mapcar #'cdr seq)))

(defvar daselt-abv--default-layout
  (when (boundp 'daselt-dfk-layout)
    (daselt-abv--generate-default-layout))
  "Default abv layout instance preconfigured for Daselt.

The instance precomputes valid placevals, class filters, layer pairs and
save-file location. It is used by the assignment, visualization and
deep-generation functions. It stays nil until `daselt-dfk-layout' has
been imported.")

(cl-defmethod abv-layout-string ((_layout daselt-abv-layout) value)
  "Return the string corresponding to VALUE in the layout.

This is so layouts can use representations other than strings for typings. VALUE
can be anything, like Daselt-coordinates.

By default it is assumed to be a string, which is returned unchanged."
  (if (stringp value)
      value
    (if (daselt-coords-p value)
        (daselt-coords-binding value)
      (if (cl-every #'daselt-coords-p value)
          (mapconcat #'daselt-coords-binding value)))))

(defun daselt-abv--parse-data-separators (parse-data)
  "Return a list of separator characters from PARSE-DATA.

PARSE-DATA is an `abv-parse-data' instance. Return nil if PARSE-DATA is nil."
  (when parse-data
    (let (separators)
      ;; Add expansion separators if they are characters.
      (dolist (slot '(expansion-beginning-separator expansion-end-separator))
        (let ((val (ignore-errors (slot-value parse-data slot))))
          (when (characterp val)
            (push val separators))))
      (cl-remove-duplicates separators :test #'char-equal))))


(defun daselt-abv--filter-placevals-by-separators (placevals separators)
  "Filter placevals by separators."
  (if separators
      (cl-remove-if
       (lambda (pv)
         (cl-member pv separators
                    :test (lambda (pv sep)
                            (let ((val (cdr pv)))
                              (and (stringp val) (= (string-to-char val)
                                                    sep))))))
       placevals)
    placevals))



(defgroup daselt-abv nil
  "Daselt integration with abv."
  :group 'abv)

(defcustom daselt-abv-layout
  daselt-abv--default-layout
  "Layout to use for abv."
  :type 'object
  :group 'daselt-abv)


;;;; Helper functions used internally by methods and deep structure generation.
;;;; Availability and relative-freedom checks
;;;; Indexed sequence helpers

(defun daselt-abv--first-index-of-letter (root letter)
  "Return the 0-based first index of LETTER in ROOT, or length of ROOT.

LETTER is expected to be a one-character string. The search is case-insensitive.
If LETTER is not found, return the length of ROOT."
  (let ((low (and (stringp letter)
                  (= (length letter) 1)
                  (downcase letter))))
    (if low
        (or (cl-position (aref low 0) (downcase root) :test #'char-equal)
            (length root))
      (length root))))

(defun daselt-abv--index-plain-seq (root plain-seq)
  "Attach indices to PLAIN-SEQ using ROOT and return an indexed sequence.

Each element in PLAIN-SEQ is a placeval (COORD . BINDING). The result elements
are ((LETTER . INDEX) . PLACEVAL). LETTER is the lowercase one-character string
extracted from BINDING when possible, otherwise the downcased BINDING string.
INDEX is the first index of LETTER in ROOT; when absent, it is set to the length
of ROOT."
  (mapcar (lambda (pv)
            (pcase-let* ((`(,_coord . ,binding) pv)
                         (letter (if (daselt-abv--letter-p binding)
                                     (downcase binding)
                                   (if (stringp binding) (downcase binding) "")))
                         (idx (daselt-abv--first-index-of-letter root letter)))
              (cons (cons letter idx) pv)))
          plain-seq))




(defvar daselt-abv--layout-match-cache nil
  "Dynamic memo for `daselt-abv--unique-layout-match'.
When bound to a hash table, batches of root typings share the
expensive recursive layout walks instead of repeating them for
every character of every candidate subsequence.")

(defun daselt-abv--unique-layout-match (s)
  "Memoizing wrapper around `daselt-bind--get-unique-layout-match'.
Consult `daselt-abv--layout-match-cache' when it is a hash table;
the keyboard layout cannot change while the dynamic binding is
active."
  (if (hash-table-p daselt-abv--layout-match-cache)
      (or (gethash s daselt-abv--layout-match-cache)
          (let ((pv (daselt-bind--get-unique-layout-match s)))
            (puthash s pv daselt-abv--layout-match-cache)
            pv))
    (daselt-bind--get-unique-layout-match s)))

(defun daselt-abv--string-combinations (string &optional min max)
  "Return sequences of indexed placevals for subsequences of STRING.

Use `daselt-base-powerlist', `string-to-list' and
`daselt-bind--get-unique-layout-match' to return sequences of
indexed placevals of symbols present in STRING, in their original order.

Each element in a returned sequence is a cons of the form ((LETTER . INDEX) .
  PLACEVAL) where PLACEVAL is the layout placeval derived from LETTER; INDEX is
  the 0-based index at which LETTER first appears in STRING. Sequences are
  ordered left-to-right as in STRING.

MIN and MAX bound the length of subsequences. MAX defaults to 2. This function
  does not deduplicate equal sequences and does not filter by validity
  classes; it
  only uses the layout bindings."
  (let* ((chars (string-to-list (or string "")))
         (min (or min 1))
         (max (or max 2))
         ;; map letter string -> first index
         (first-idx (let ((tbl (make-hash-table :test 'equal))
                          (i 0))
                      (dolist (ch chars tbl)
                        (let ((s (downcase (string ch))))
                          (unless (gethash s tbl)
                            (puthash s i tbl)))
                        (setq i (1+ i)))))
         (subs (cl-remove-if (lambda (xs) (< (length xs) min))
                             (daselt-base-powerlist chars nil max))))
    (cl-remove-if #'null
                  (mapcar (lambda (sub)
             (let ((res (mapcar (lambda (ch)
                                                  (let* ((s (downcase (string ch)))
                                                         (pv (daselt-abv--unique-layout-match s)))
                                                   (and pv (cons (cons s (gethash s first-idx 0)) pv))))
                                               sub)))
                              (unless (cl-member nil res) res)))
                          subs))))
(defun daselt-abv--expand-seq-at (seq i j)
  "Expand SEQ at index I by varying j-th coordinate component.

The component J is 0 for layer, 1 for row, and 2 for column. Return a list of
new sequences."
  (let* ((elt (nth i seq))
         (meta (car elt))
         (pv (cdr elt))
         (coord (car pv))
         (L (nth 0 coord))
         (r (nth 1 coord))
         (c (nth 2 coord)))
    (pcase j
      (0 ; vary layer
       (cl-remove-if #'null
                     (mapcar (lambda (l2)
                               (let* ((coord2 (list l2 r c))
                                      (bnd (daselt-coords-binding coord2)))
                                 (when bnd
                                   (append (cl-subseq seq 0 i)
                                           (list (cons meta (cons coord2 bnd)))
                                           (nthcdr (1+ i) seq)))))
                             '(1 4 5 8 2 3 6 7))))
      (1 ; vary row
       (cl-remove-if #'null
                     (mapcar (lambda (r2)
                               (let* ((coord2 (list L r2 c))
                                      (bnd (daselt-coords-binding coord2)))
                                 (when bnd
                                   (append (cl-subseq seq 0 i)
                                           (list (cons meta (cons coord2 bnd)))
                                           (nthcdr (1+ i) seq)))))
                             '(-1 0 1))))
      (2 ; vary column
       (cl-remove-if #'null
                     (mapcar (lambda (c2)
                               (let* ((coord2 (list L r c2))
                                      (bnd (daselt-coords-binding coord2)))
                                 (when bnd
                                   (append (cl-subseq seq 0 i)
                                           (list (cons meta (cons coord2 bnd)))
                                           (nthcdr (1+ i) seq)))))
                             '(-5 -4 -3 -2 -1 1 2 3 4 5)))))))

(cl-defun daselt-abv--embellish (seqs directions)
  "Embellish indexed SEQS according to DIRECTIONS.

Each SEQ is a list of indexed placevals: ((LETTER . INDEX) . PLACEVAL)

Return sequences whose elements have been embellished by allowing the
coordinates of constituent placevals to be varied per DIRECTIONS. When new
placevals are created, they inherit the same (LETTER . INDEX) metadata from
their source element.

Algorithm: If no direction is provided, return SEQS. Otherwise, find the first
non-nil flag in DIRECTIONS at position (i, j). Expand each SEQ in SEQS by
varying the j-th coordinate of its i-th element. Recurse with the new set of
sequences and with the flag at (i, j) set to nil."
  ;; (unless (cl-every (lambda (seq)
  ;;                     (<= (length directions)
  ;;                         (length seq)))
  ;;                   seqs)
  ;;   (error "Sequences %s do not have enough morphs to embellish in directions %s" seqs directions))
  (if (null directions)
      seqs
    (let (found)
      (cl-loop for dir in directions for i from 0
               do (cl-loop for flag in dir for j from 0
                           do (when flag (setq found (list i j)) (cl-return)))
               when found do (cl-return))
      (if (not found)
          seqs
        (pcase-let* ((`(,i ,j) found)
                     (new-seqs (mapcan (lambda (seq) (daselt-abv--expand-seq-at seq i j))
                                       seqs))
                     (new-directions (let ((dirs (copy-tree directions)))
                                       (setf (nth j (nth i dirs)) nil)
                                       dirs)))
          (daselt-abv--embellish new-seqs new-directions))))))

(defun daselt-abv--placevals->coord-hash (placevals)
    "Return a hash mapping COORD -> BINDING for PLACEVALS alist."
    (let ((ht (make-hash-table :test 'equal)))
    (dolist (pv placevals ht)
      (puthash (car pv) (cdr pv) ht))))

(defun daselt-abv--keys (hash)
  "Return a list of keys of HASH."
  (let (ks) (maphash (lambda (k _v) (push k ks)) hash) ks))

(defun daselt-abv--letter-p (s)
  "Return non-nil if S is a single ASCII letter string."
  (and (stringp s) (= (length s) 1)
       (let ((c (aref s 0)))
         (or (and (<= ?a c) (<= c ?z)) (and (<= ?A c) (<= c ?Z))))))

(defun daselt-abv--down (s)
  "If S is a single-character string, return its lowercase; otherwise identity."
  (if (and (stringp s) (= (length s) 1)) (downcase s) s))

(defun daselt-abv--coord-layers-in-order (complementp)
  "Return a list of layers in accessibility order; if COMPLEMENTP, start with 2."
  (if complementp '(2 1 4 6 5 7 3 8) '(1 2 4 6 5 7 3 8)))

(defun daselt-abv--collect-letter-bases (placevals)
      "Map lowercase letter -> a preferred base coordinate from PLACEVALS.

Preference is for layer 1 if available; otherwise the coordinate with minimal
`daselt-abv--erg-score'."
      (let ((per-letter (make-hash-table :test 'equal)))
    (dolist (pv placevals)
      (let* ((coord (car pv)) (binding (daselt-abv--down (cdr pv))))
        (when (daselt-abv--letter-p binding)
          (push coord (gethash binding per-letter)))))
    (let ((out (make-hash-table :test 'equal)))
      (maphash
       (lambda (letter coords)
             (let* ((on-l1 (cl-find-if (lambda (cc) (= (car cc) 1)) coords))
                (best (or on-l1 (car (cl-sort (copy-sequence coords)
                                              (lambda (a b)
                                                    (< (daselt-abv--erg-score a)
                                                   (daselt-abv--erg-score b))))))))
           (puthash letter best out)))
       per-letter)
      out)))

(defun daselt-abv--affix-letters (affix)
  "Return a list of unique lowercase letter strings in AFFIX, in order,
excluding a letter that is among several within a [] bracket."
  (let ((seen (make-hash-table :test 'equal))
        (out '())
        (inside-brackets nil)
        (i 0))
    (while (< i (length affix))
      (let* ((ch (aref affix i))
             (s (downcase (string ch))))
        (cond
         ;; Check for opening bracket
         ((= ch ?\[) (setq inside-brackets t))
         ;; Check for closing bracket
         ((= ch ?\]) (setq inside-brackets nil))
         ;; Process letters if not inside brackets
         ((and (or (not inside-brackets)
                   (and (ignore-errors (= ?\[ (aref affix (1- i))))
                        (ignore-errors (= ?\] (aref affix (1+ i))))))
               (daselt-abv--letter-p s) (not (gethash s seen)))
          (puthash s t seen) (push s out))))
      (setq i (1+ i)))
    (nreverse out)))


(defun daselt-abv--letter-rarity (letter preferred-hash)
    "Return how many coordinates in PREFERRED-HASH bind to LETTER."
    (let ((n 0))
    (maphash (lambda (_coord binding)
                 (when (and (stringp binding) (string= (daselt-abv--down binding) letter))
                 (setq n (1+ n))))
             preferred-hash)
    n))

(defun daselt-abv--free-candidates (preferred-hash counts-hash)
  "Return coordinates not yet used in COUNTS-HASH."
  (cl-loop for coord in (daselt-abv--keys preferred-hash)
           unless (> (gethash coord counts-hash 0) 0)
           collect coord))

(defun daselt-abv--choose-fallback (preferred-hash counts-hash)
  "Choose a coordinate by minimal usage, then ergonomic cost."
  (let ((coords (daselt-abv--keys preferred-hash)))
    (car (cl-sort (copy-sequence coords)
                  (lambda (a b)
                    (let* ((ca (gethash a counts-hash 0)) (cb (gethash b counts-hash 0)))
                      (if (/= ca cb) (< ca cb)
                        (< (daselt-abv--erg-score a) (daselt-abv--erg-score b)))))))))

(defun daselt-abv--complement-hash (universe-hash subset-hash)
  "Return a hash of coords present in UNIVERSE-HASH but not in SUBSET-HASH."
  (let ((ht (make-hash-table :test 'equal)))
    (maphash (lambda (coord binding)
               (unless (gethash coord subset-hash) (puthash coord binding ht)))
             universe-hash)
    ht))

(defun daselt-abv--sorted-affixes-by-frequency (affixes freq-alist)
  "Sort AFFIXES by descending frequency using FREQ-ALIST; ties by length.

When frequencies and lengths are equal, sort lexicographically."
  (let* ((freq (abv-layout-alist->hash freq-alist))
         (pair (mapcar (lambda (a) (cons a (or (gethash a freq) 0))) affixes)))
    (mapcar #'car
            (cl-sort pair (lambda (a b)
                            (let ((fa (cdr a)) (fb (cdr b)))
                              (if (/= fa fb) (> fa fb)
                                (let ((la (length (car a))) (lb (length (car b))))
                                  (if (/= la lb) (< la lb) (string< (car a) (car b)))))))))))

(defun daselt-abv--normalize-frequencies (freqs)
  "Normalize FREQS to an alist of (STRING .

COUNT).

Accepted key shapes are: - string - (string), as produced by abv-corpus reducers
- symbol (its name is used)

Only positive integer counts are kept."
  (cl-loop for (k . v) in freqs
           for key = (cond
                      ((stringp k) k)
                      ((and (consp k) (stringp (car k))) (car k))
                      ((symbolp k) (symbol-name k))
                      (t nil))
           when (and key (integerp v) (> v 0))
           collect (cons key v)))

(defun daselt-abv--table->bindlist-var (table-sym)
  "Return the symbol to use for the bindlist variable from TABLE-SYM."
  (intern (replace-regexp-in-string "-table$" "-bindlist" (symbol-name table-sym))))
(defun daselt-abv-table->bindlist (table-sym)
  "Convert an affix table variable to a bindlist and define a companion var.

TABLE-SYM names a variable bound to a hash-table mapping affix string to
coordinate. Create and set a new variable whose name is TABLE-SYM with the
suffix \"-table\" replaced by \"-bindlist\" and whose value is a list of (COORDS
. AFFIX). Return the bindlist.

Interactively, prompt for a variable named like \"daselt-abv-*-table\"."
  (interactive
   (list (intern (completing-read "Affix table: " obarray
                                  (lambda (s)
                                    (and (string-match-p "^daselt-abv-.*-table$" (symbol-name s))
                                         (hash-table-p (symbol-value s))))
                                  t))))
  (unless (and (symbolp table-sym) (boundp table-sym) (hash-table-p (symbol-value table-sym)))
    (user-error "Table %s is not bound to a hash-table" table-sym))
  (let* ((tbl (symbol-value table-sym))
         (blist (cl-loop for k being the hash-keys of tbl using (hash-value v)
                         collect (cons v (if (stringp k) k (format "%s" k))))))
    (set (daselt-abv--table->bindlist-var table-sym) blist)
    blist))
(defun daselt-abv--seq-coords (seq)
  "Return list of coordinates from SEQ (plain or indexed)."
  (mapcar #'car (daselt-abv--seq-placevals seq)))

(defun daselt-abv--value-coords (val)
  "Return plain coordinates from VAL (which may be an abv-rich-value)."
  (if (cl-typep val 'abv-rich-value)
      (if (slot-boundp val 'plain-value)
          (slot-value val 'plain-value)
        nil)
    val))

;;;; Lookup methods

(cl-defmethod tl--fresh-mnemonic-key ((layout daselt-abv-layout) string taken-p &optional base)
  "Daselt fresh keys: two-symbol mnemonics of STRING's own letters."
  (daselt-abv--fresh-2symbol-candidate string layout taken-p (or base "")))

(cl-defmethod abv-layout-visualize-layer ((_layout daselt-abv-layout) table-id laycoord)
  ;; Base method retained below for generic layouts.
  "Draw a visualization of TABLE-ID for the layer matching LAYCOORD.

TABLE-ID is one of prefix, suffix, infix or root. Ensure the companion bindlist
exists, filter its entries by LAYCOORD, and draw the placevals either in a
temporary buffer when called interactively or return an image when called
non-interactively."
  (let* ((table-sym (pcase table-id ('prefix 'daselt-abv-prefix-table)
                           ('suffix 'daselt-abv-suffix-table)
                           ('infix  'daselt-abv-infix-table)
                           ('root   'daselt-abv-root-table)
                           (_ (user-error "Unknown table-id %S" table-id)))))
    (when (and (symbolp table-sym) (boundp table-sym) (hash-table-p (symbol-value table-sym)))
      (unless (and (boundp (daselt-abv--table->bindlist-var table-sym))
                   (daselt-bind-bindlist-p (symbol-value (daselt-abv--table->bindlist-var table-sym))))
        (daselt-abv-table->bindlist table-sym))
      (let* ((blist (symbol-value (daselt-abv--table->bindlist-var table-sym)))
             (placevals (daselt-coords-placevals-matching-indexed-rx blist 0 laycoord))
             (drawer (if (called-interactively-p 'any)
                         #'daselt-coords-draw-placevals-in-temp-buffer
                       #'daselt-coords-draw-placevals)))
        (funcall drawer placevals nil nil current-prefix-arg)))))

(cl-defmethod abv-layout-lookup-affix ((_layout daselt-abv-layout) table-id query)
  "Lookup QUERY in TABLE-ID and echo its coordinate tuple.

TABLE-ID is one of prefix, suffix, infix or root. Return the coordinate (list
LAYER ROW COL) or nil when not found. When found, also message the mapping."
  (let* ((table-sym (pcase table-id ('prefix 'daselt-abv-prefix-table)
                           ('suffix 'daselt-abv-suffix-table)
                           ('infix  'daselt-abv-infix-table)
                           ('root   'daselt-abv-root-table)
                           (_ (user-error "Unknown table-id %S" table-id))))
         (tbl (and (boundp table-sym) (symbol-value table-sym)))
         (hit (and (hash-table-p tbl) (gethash query tbl))))
    (if hit
        (prog1 hit (message "%s => %S" query hit))
      (message "Not found in %S" table-id)
      nil)))

(cl-defmethod abv-layout-lookup-root ((_layout daselt-abv-layout) root)
  "Return the deep mapping for ROOT from LAYOUT's root-table.

The value is either a single placeval (for one-symbol assignments) or a list of
two placevals. Return nil if ROOT is not present."
  (let ((tbl (oref daselt-abv--default-layout root-table)))
    (and (hash-table-p tbl) (gethash root tbl))))

;;;; Coordinate accessors (shared with inflection/typing modules)

(defun daselt-abv--char-coord (layout char)
  "Return the Daselt coordinate triple (LAYER ROW COL) for CHAR on LAYOUT.

Returns nil when CHAR has no placeval on LAYOUT."
  (when-let*((pv (abv-layout-char-placeval layout char)))
    (car pv)))

(defun daselt-abv--coord-layer (coord)
  "Return the layer component of Daselt coordinate COORD."
  (nth 0 coord))

(defun daselt-abv--coord-row (coord)
  "Return the row component of Daselt coordinate COORD."
  (nth 1 coord))

(defun daselt-abv--coord-col (coord)
  "Return the column component of Daselt coordinate COORD."
  (nth 2 coord))

(defun daselt-abv--lower-layer-p (layer)
  "Return non-nil if LAYER is a lower layer in a Daselt layer pair.

The layer pairs are (1 . 2), (4 . 3), (5 . 6), (8 . 7); lower layers are 1, 4,
5, 8."
  (memq layer '(1 4 5 8)))

(provide 'daselt-abv-layout)
;;; daselt-abv-layout.el ends here
