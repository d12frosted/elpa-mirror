;;; daselt-abv.el --- Daselt's abv module  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; License: GPL-3+

;;; Commentary:

;; This file is now a thin aggregator.  The implementation has been
;; split into the following component modules, each with its own
;; dedicated test file:
;;
;;   `daselt-abv-layout'      - layout class, default layout, placeval
;;                              helpers, coordinate accessors and lookup
;;                              methods.
;;   `daselt-abv-ergonomics'  - ergonomic / availability / mnemonic /
;;                              collision / candidate scoring.
;;   `daselt-abv-typing'      - `abv-set-typings' specializations,
;;                              `abv-typed-layout-type-root', the
;;                              morph-sequence-string,
;;                              exchange-characters and morph-typing-string
;;                              methods.
;;   `daselt-abv-distill'     - Daselt distillation algorithm
;;                              (`abv-distill') and the embellished
;;                              sequence-string method.
;;   `daselt-abv-inflection'  - decoding inflection features, word type
;;                              and conversion suffixes from coordinates.
;;   `daselt-abv-names'       - `abv--add-name', `abv--add-macro' and
;;                              `abv--add-formula' Daselt methods.
;;   `daselt-abv-syntax-help' - Daselt specializations of abv's
;;                              syntax-helper generics: trigger legends
;;                              and key-grid visualizations of
;;                              inflection, word-type and conversion
;;                              triggers.
;;
;; The Daselt keybindings of the abv integration (the ei choice
;; interface's minibuffer keys and the abv edit-buffer maps) are
;; defined in abv.dbl and documented in doc/keybindings.org.
;;
;; Requiring this module pulls in all of the above in the right order
;; and re-exports `daselt-abv' for backwards compatibility.

;;; Code:

(require 'daselt-abv-layout)
(require 'daselt-abv-ergonomics)
(require 'daselt-abv-typing)
(require 'daselt-abv-distill)
(require 'daselt-abv-inflection)
(require 'daselt-abv-names)
(require 'daselt-abv-syntax-help)

(provide 'daselt-abv)
;;; daselt-abv.el ends here
