;;; daselt-abv-tests--setup.el --- Test setup for daselt-abv tests  -*- lexical-binding: t; -*-

;;; Commentary:

;; Test setup that loads the Daselt keyboard environment required to
;; load `daselt-abv' and its split component modules.

;;; Code:

(require 'cl-lib)

;; Run the heavy setup at most once per session.  We key off
;; `daselt-dfk-layout' (which is the variable the rest of
;; `daselt-abv' needs to be bound and non-nil), rather than off
;; `(featurep 'daselt-base)', because some abv source files
;; transitively load `daselt-base' without going through this setup.
(unless (and (boundp 'daselt-dfk-layout)
             daselt-dfk-layout)
  (let ((daselt-dir (expand-file-name "~/proj/d-ext/d-emacs"))
        (daselt-abv-dir (expand-file-name "~/proj/d-ext/d-emacs/mode-configs/abv/")))
    (when (file-exists-p daselt-dir)
      (add-to-list 'load-path daselt-dir))
    (when (file-exists-p daselt-abv-dir)
      (add-to-list 'load-path daselt-abv-dir)))

  (require 'daselt-base)
  (require 'daselt-xkb)
  (require 'daselt-dfk)
  (require 'daselt-coords)
  (require 'daselt-bind)
  

  ;; Load core abv classes used as specializers in `daselt-abv'.
  (require 'abv-language-table)
  (require 'abv-language-table-words)
  (require 'abv-corpus-language-statistics)
  (require 'abv-collection)
  (require 'abv)

  (let ((xkb-file (expand-file-name "~/proj/d-ext/daselt/d-xkb/dxkb")))
    (when (file-exists-p xkb-file)
      (setq daselt-xkb-file xkb-file)
      (setq daselt-dfk-keyboard-layout-type "iso")
      (condition-case err
          (progn
            (daselt-xkb-generate-layouts)
            (setq daselt-xkb-layout 'daselt-xkb-main-layout)
            (daselt-dfk-import-current-layout))
        (error (message "daselt-abv-tests--setup: %S" err))))))

(provide 'daselt-abv-tests--setup)
;;; daselt-abv-tests--setup.el ends here
