;;; daselt-abv-names.el --- Daselt abv name/macro/formula addition  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; License: GPL-3+

;;; Commentary:

;; Coordinate-key generation for name, macro and formula additions
;; on a Daselt abv layout.  Implements the Daselt specializations of
;; `abv--add-name', `abv--add-macro', `abv--add-formula', the legacy
;; `abv--add-name--old' method and the shared helper
;; `daselt-abv--generate-free-key'.

;;; Code:

(require 'daselt-abv-layout)
(require 'abv-name-table)

(defun abv-name-table--taken-keys (name-table)
  "Return the taken key strings of NAME-TABLE and its ancestors.
Delegates to `abv-name-table-taken-keys' so generated keys avoid
ancestor tables' keys too."
  (abv-name-table-taken-keys name-table))

;; Old abv--add-name method superseded by the refactored version below.
(cl-defmethod abv--add-name--old (name (name-table abv-name-table)
                                       (layout daselt-abv-layout))
  "Daselt method for `abv--add-name'.

Generate a coordinate-related key string for NAME that is not yet taken in
NAME-TABLE. Use the layout's `standard-placevals' to enumerate available
single-character keys; when all are taken, try two-character combinations. Add
NAME to NAME-TABLE with the generated key and return the key."
  (let* ((placevals (oref (oref layout placevals) standard-placevals))
         (chars (cl-delete-duplicates
                 (delq nil
                       (mapcar (lambda (pv)
                                 (and (stringp (cdr pv))
                                      (not (string-empty-p (cdr pv)))
                                      (cdr pv)))
                               placevals))
                 :test #'string=))
         (taken (abv-name-table--taken-keys name-table))
         (free-key
          (or (cl-find-if
               (lambda (ch) (not (member ch taken)))
               chars)
              (cl-loop for c1 in chars
                       thereis (cl-loop for c2 in chars
                                        for pair = (concat c1 c2)
                                        thereis (and (not (member pair taken))
                                                     pair))))))
    (unless free-key
      (user-error "No free coordinate key available in `%s'"
                  (or (oref name-table name) name-table)))
    (abv-add-with name-table free-key name)
    (abv-table-set-reversion-cache name-table)
    free-key))

;;; Key-generation helper shared by name, macro, and formula addition.

(defun daselt-abv--generate-free-key (layout name-table)
  "Generate a free coordinate key for NAME-TABLE on LAYOUT.

Search single-character keys from `standard-placevals' first, then two-character
combinations. Return the key string, or signal `user-error' when none is free."
  (let* ((placevals (oref (oref layout placevals) standard-placevals))
         (chars (cl-delete-duplicates
                 (delq nil
                       (mapcar (lambda (pv)
                                     (and (stringp (cdr pv))
                                      (not (string-empty-p (cdr pv)))
                                      (cdr pv)))
                               placevals))
                 :test #'string=))
         (taken (abv-name-table--taken-keys name-table))
         (free-key
          (or (cl-find-if
               (lambda (ch) (not (member ch taken)))
               chars)
              (cl-loop for c1 in chars
                       thereis (cl-loop for c2 in chars
                                        for pair = (concat c1 c2)
                                        thereis (and (not (member pair taken))
                                                     pair))))))
    (unless free-key
      (user-error "No free coordinate key available in `%s'"
                  (or (oref name-table name) name-table)))
    free-key))

(cl-defmethod abv--add-name (name (name-table abv-name-table)
                                  (layout daselt-abv-layout))
                                          "Daselt method for `abv--add-name'.

Generate a coordinate-related key string for NAME that is not yet taken in
NAME-TABLE. Use the layout's `standard-placevals' to enumerate available
single-character keys; when all are taken, try two-character combinations. Add
NAME to NAME-TABLE with the generated key and return the key."
                                          (let ((free-key (daselt-abv--generate-free-key layout name-table)))
    (abv-add-with name-table free-key name)
    (abv-table-set-reversion-cache name-table)
    free-key))

(cl-defmethod abv--add-macro (macro-string (table abv-table)
                                           (layout daselt-abv-layout))
  "Daselt method for `abv--add-macro'.

Generate a coordinate key for MACRO-STRING and add to TABLE."
  (let ((free-key (daselt-abv--generate-free-key layout table)))
    (abv-add-with table free-key macro-string)
    (abv-table-set-reversion-cache table)
    free-key))

(cl-defmethod abv--add-formula (formula-string (table abv-table)
                                               (layout daselt-abv-layout))
  "Daselt method for `abv--add-formula'.

Generate a coordinate key for FORMULA-STRING and add to TABLE."
  (let ((free-key (daselt-abv--generate-free-key layout table)))
    (abv-add-with table free-key formula-string)
    (abv-table-set-reversion-cache table)
    free-key))

(provide 'daselt-abv-names)
;;; daselt-abv-names.el ends here
