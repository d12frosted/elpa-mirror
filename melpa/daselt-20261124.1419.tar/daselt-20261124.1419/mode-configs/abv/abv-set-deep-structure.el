;;; abv-set-deep-structure.el --- Set deep structure for Daselt-abv  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Keywords: abbrev

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; 

;;; Code:

(pcase-let ((`(,pfx-freqs ,sfx-freqs ,ifx-freqs ,root-freqs)
             (mapcar (lambda (ty)
                       (eval `(abv-corpus-reduced-monogram-frequencies
                               (oref (oref (oref abv-collection-current current-language) morphs) ,ty)
                               ,(oref ahp-corpus :statistics-table)
                               "initial")))
                     '(:prefixes :suffixes :infixes :roots))))
  )

(provide 'abv-set-deep-structure)
;;; abv-set-deep-structure.el ends here
