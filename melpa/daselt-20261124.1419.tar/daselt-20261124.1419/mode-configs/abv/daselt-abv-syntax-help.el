;;; daselt-abv-syntax-help.el --- Daselt syntax-help specializations  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; License: GPL-3+

;;; Commentary:

;; Specializations of abv's syntax-helper generics for the Daselt
;; layout.  On Daselt, a syntax-trigger character's position encodes
;; grammatical features (see `daselt-abv-inflection'), so the trigger
;; legends are drawn as keyboard-layer grids: each key position is
;; labelled with the trigger character and the inflection, word type
;; or conversion method it selects.
;;
;; Implements the Daselt methods of
;; `abv-layout-inflection-trigger-groups',
;; `abv-layout-word-type-trigger-entries',
;; `abv-layout-conversion-trigger-entries',
;; `abv-layout-visualize-inflection-triggers',
;; `abv-layout-visualize-word-type-triggers' and
;; `abv-layout-visualize-conversion-triggers', plus the interactive
;; commands `daselt-abv-visualize-inflection-matrix',
;; `daselt-abv-visualize-word-type-matrix' and
;; `daselt-abv-visualize-conversion-matrix'.

;;; Code:

(require 'cl-lib)
(require 'eieio)
(require 'daselt-abv-layout)
(require 'daselt-abv-inflection)
(require 'abv-syntax-help)

(declare-function daselt-base-with-max-buffer-maybe-return "daselt-base"
                  (bufname fun))
(declare-function daselt-coords-draw-placevals "daselt-coords"
                  (placevals &optional bounds runcoords org noupperrow))
(declare-function abv-current-collection "abv" ())
(declare-function abv-typed-layout--typing-provenance
                  "abv-typed-layout" (layout key word))
(declare-function abv-typed-layout--string-base-letters
                  "abv-typed-layout" (layout string))

;;;; Layout and placeval access

(defun daselt-abv-syntax-help--layout (&optional layout)
  "Return LAYOUT or the default Daselt layout.

Signal a `user-error' when no layout is available, i.e. neither
argument nor `daselt-abv--default-layout' after the dfk layout
has been imported."
  (or layout
      daselt-abv--default-layout
      (user-error "Daselt layout unavailable; import the dfk layout first")))

(defun daselt-abv-syntax-help--char-placevals (&optional layout)
  "Return LAYOUT's single-character placevals as ((L R C) . \"c\")."
  (cl-loop for pv in (oref (daselt-abv-syntax-help--layout layout)
                           single-symbol-placevals)
           when (and (stringp (cdr pv)) (= 1 (length (cdr pv))))
           collect pv))

(defun daselt-abv-syntax-help--decode-placevals (layout pred)
  "Return (COORD CHAR INFO) triples for char placevals on LAYOUT.

PRED takes a coordinate and returns the decoded info plist, or
nil to skip the position.  Only canonical positions are kept: a
character can sit on several coordinates (e.g. shifted layers),
but typing it decodes through `abv-layout-char-placeval', which
finds only the first, so the enumeration must match that."
  (cl-loop for pv in (daselt-abv-syntax-help--char-placevals layout)
           for coord = (car pv)
           for canon = (abv-layout-char-placeval
                        layout (string-to-char (cdr pv)))
           for info = (and canon
                           (equal (car canon) coord)
                           (funcall pred coord))
           when info collect (list coord (cdr pv) info)))

(defun daselt-abv-syntax-help--entries (layout pred)
  "Return (CHAR . INFO) entries for char placevals on LAYOUT.

PRED takes a coordinate and returns the decoded info, or nil to
skip the position."
  (mapcar (lambda (triple) (cons (nth 1 triple) (nth 2 triple)))
          (daselt-abv-syntax-help--decode-placevals layout pred)))

(defun daselt-abv-syntax-help--core-row-p (coord)
  "Return non-nil when COORD's row is one of the three core rows."
  (memq (daselt-abv--coord-row coord) '(-1 0 1)))

(defun daselt-abv-syntax-help--from-types ()
  "Return the source types of the Daselt conversion-method table."
  (delete-dups
   (mapcar (lambda (entry) (car (car entry)))
           daselt-abv--conversion-method-table)))

;;;; Enumeration specializations

(cl-defmethod abv-layout-inflection-trigger-groups
    ((layout daselt-abv-layout) word-type &optional _language)
  "Daselt inflection trigger groups for WORD-TYPE.

Each trigger character's coordinate encodes the features via the
decoders of `daselt-abv-inflection'.  Positions outside the three
core rows (where the row decoders are meaningless) are omitted."
  (pcase word-type
    (`verb
     (list
      (list :title
            "Verb char 1 — column: tense, row: person, layer: number/negation/subject"
            :entries
            (daselt-abv-syntax-help--entries
             layout
             (lambda (coord)
               (let ((info (daselt-abv--verb-first-char-info coord)))
                 (and (plist-get info :tense)
                      (plist-get info :person)
                      info)))))
      (list :title
            "Verb char 2 (optional) — row: mood, column: aspect, layer: voice/particle"
            :optional t
            :entries
            (daselt-abv-syntax-help--entries
             layout
             (lambda (coord)
               ;; Every column counts: one decoding no aspect
               ;; keeps the default aspect but still sets mood,
               ;; voice and particle.
               (let ((info (daselt-abv--verb-second-char-info coord)))
                 (and (plist-get info :mood)
                      info)))))))
    (`noun
     (list
      (list :title
            "Noun — layer: number/definiteness, row: case/particle"
            :entries
            (daselt-abv-syntax-help--entries
             layout
             (lambda (coord)
               (and (daselt-abv-syntax-help--core-row-p coord)
                    (daselt-abv--noun-info coord)))))))
    (`adjective
     (list
      (list :title "Adjective — row: degree, layer: negation/particle"
            :entries
            (daselt-abv-syntax-help--entries
             layout
             (lambda (coord)
               (and (daselt-abv-syntax-help--core-row-p coord)
                    (daselt-abv--degree-info coord)))))))
    (`adverb
     (list
      (list :title "Adverb — row: degree, layer: negation/particle"
            :entries
            (daselt-abv-syntax-help--entries
             layout
             (lambda (coord)
               (and (daselt-abv-syntax-help--core-row-p coord)
                    (daselt-abv--degree-info coord)))))))
    (`pronoun
     (list
      (list :title
            "Pronoun char 1 — row: person, layer: number"
            :entries
            (daselt-abv-syntax-help--entries
             layout
             (lambda (coord)
               (let ((person (daselt-abv--person-from-row
                              (daselt-abv--coord-row coord))))
                 (and person
                      `(:person ,person
                                :number ,(daselt-abv--number-from-layer
                                          (daselt-abv--coord-layer coord))))))))
      (list :title
            "Pronoun char 2 (optional) — column: gender, row: case"
            :optional t
            :entries
            (daselt-abv-syntax-help--entries
             layout
             (lambda (coord)
               (let ((gender (daselt-abv--gender-from-col
                              (daselt-abv--coord-col coord)))
                     (case (pcase (daselt-abv--coord-row coord)
                             (-1 'nominative)
                             (0 'objective)
                             (1 'possessive-determiner))))
                 (and gender case
                      `(:gender ,gender :case ,case))))))))
    (`determiner
     (list
      (list :title "Determiner — layer: number"
            :entries
            (daselt-abv-syntax-help--entries
             layout
             (lambda (coord)
               (and (daselt-abv-syntax-help--core-row-p coord)
                    `(:number ,(daselt-abv--number-from-layer
                                (daselt-abv--coord-layer coord)))))))))
    (_ nil)))

(cl-defmethod abv-layout-word-type-trigger-entries
    ((layout daselt-abv-layout) &optional _language)
  "Daselt word-type triggers: the trigger char's column gives the type."
  (daselt-abv-syntax-help--entries
   layout
   (lambda (coord) (daselt-abv--word-type-from-coord coord))))

(cl-defmethod abv-layout-conversion-trigger-entries
    ((layout daselt-abv-layout) &optional from-type _language)
  "Daselt conversion triggers from FROM-TYPE.

With FROM-TYPE nil, entries for every source type of
`daselt-abv--conversion-method-table' are returned; a trigger
character then appears once per source type that supports it.
Keys on higher layers carry their explicit affix from
`daselt-abv--conversion-method-table'; first-layer keys carry a
nil method — at expansion time the word's stored
conversion-default, then the language's regex-matched conversion
suffix, then the key's position affix apply (see
`abv-syntax--effective-conversion-method')."
  (let ((from-types (or (and from-type (list from-type))
                        (daselt-abv-syntax-help--from-types))))
    (apply #'append
           (mapcar
            (lambda (from)
              (daselt-abv-syntax-help--entries
               layout
               (lambda (coord)
                 (let* ((to (daselt-abv--word-type-from-coord coord))
                        (method (and to
                                     (daselt-abv--conversion-method-from-coord
                                      from coord))))
                   (and to
                        (assoc (cons from to)
                               daselt-abv--conversion-method-table
                               #'equal)
                        (cons to method))))))
            from-types))))

;;;; Grid visualization

(defun daselt-abv-syntax-help--entry-placevals (layout entries label-fn)
  "Return ((L R C) . LABEL) placevals for ENTRIES on LAYOUT.

LABEL-FN takes an entry (CHAR . INFO) and returns its cell label.
Entries' trigger strings are single characters here."
  (cl-loop for entry in entries
           for pv = (abv-layout-char-placeval
                     layout (string-to-char (car entry)))
           when pv collect (cons (car pv) (funcall label-fn entry))))

(defun daselt-abv-syntax-help--inflection-sections (layout groups)
  "Return (HEADING . PLACEVALS) sections for inflection GROUPS."
  (mapcar
   (lambda (group)
     (cons (or (plist-get group :title) "Triggers")
           (daselt-abv-syntax-help--entry-placevals
            layout (plist-get group :entries)
            (lambda (entry)
              (format "%s: %s" (car entry)
                      (abv-syntax-help-format-features (cdr entry)))))))
   groups))

(defun daselt-abv-syntax-help--conversion-label (layout entry from-type)
  "Return the grid label for a conversion ENTRY from FROM-TYPE.
Explicit higher-layer affixes label themselves; first-layer keys
label with \"default\" plus their position affix, which is the
last-resort fallback at expansion time."
  (let ((method (cdr (cdr entry))))
    (or method
        (let ((affix (abv-layout-position-affix-from-string
                      layout (car entry) nil from-type)))
          (if affix
              (format "default (%s)" affix)
            "default")))))

(defun daselt-abv-syntax-help--draw (title sections)
  "Insert TITLE and grid SECTIONS into the current buffer.

SECTIONS is a list of (HEADING . PLACEVALS); each section's
placevals are drawn with `daselt-coords-draw-placevals', which
recurses over layers with layer headers."
  (insert (format "* %s\n" title))
  (dolist (section sections)
    (insert (format "\n%s\n" (car section)))
    (daselt-coords-draw-placevals (cdr section))))

(defun daselt-abv-syntax-help--draw-temp (title sections)
  "Draw TITLE and grid SECTIONS in the maximized Daselt layout buffer."
  (daselt-base-with-max-buffer-maybe-return
   "*daselt-layout*"
   (lambda ()
     (org-mode)
     (insert (format "#+title: %s\n" title))
     (daselt-abv-syntax-help--draw title sections))))

(cl-defmethod abv-layout-visualize-inflection-triggers
    ((layout daselt-abv-layout) word-type &optional _language)
  "Draw Daselt key grids for WORD-TYPE's inflection triggers.

Inserts one grid section per trigger group into the current
buffer; each cell shows the trigger character and the features
its position encodes."
  (let ((sections (daselt-abv-syntax-help--inflection-sections
                   layout
                   (abv-layout-inflection-trigger-groups layout word-type))))
    (if (not sections)
        (prog1 nil
          (message "No inflection triggers for %s on %s"
                   word-type (oref layout name)))
      (daselt-abv-syntax-help--draw
       (format "Inflection triggers for %s" word-type) sections))))

(cl-defmethod abv-layout-visualize-word-type-triggers
    ((layout daselt-abv-layout) &optional _language)
  "Draw a Daselt key grid for the word-type triggers.

Each cell shows the trigger character typed after the word-type
separator and the word type its column encodes."
  (let ((entries (abv-layout-word-type-trigger-entries layout)))
    (if (not entries)
        (prog1 nil
          (message "No word-type triggers on %s" (oref layout name)))
      (daselt-abv-syntax-help--draw
       "Word-type triggers"
       (list
        (cons "Word type by column"
              (daselt-abv-syntax-help--entry-placevals
               layout entries
               (lambda (entry)
                 (format "%s: %s" (car entry)
                         (symbol-name (cdr entry)))))))))))

(cl-defmethod abv-layout-visualize-conversion-triggers
    ((layout daselt-abv-layout) &optional from-type _language)
  "Draw a Daselt key grid for conversion triggers from FROM-TYPE.

FROM-TYPE is required: the Daselt conversion grid labels each
position with the suffix selected for one source type at a time."
  (unless from-type
    (user-error "Daselt conversion grids need one FROM-TYPE at a time"))
  (let ((entries (abv-layout-conversion-trigger-entries layout from-type)))
    (if (not entries)
        (prog1 nil
          (message "No conversion triggers from %s on %s"
                   from-type (oref layout name)))
      (daselt-abv-syntax-help--draw
       (format "Conversion triggers from %s" from-type)
       (list
          (cons (format "Conversions from %s" from-type)
                (daselt-abv-syntax-help--entry-placevals
                 layout entries
                 (lambda (entry)
                   (format "%s: %s → %s" (car entry)
                           (daselt-abv-syntax-help--conversion-label
                            layout entry from-type)
                           (symbol-name (car (cdr entry))))))))))))

;;;; Interactive commands

;;;###autoload
(defun daselt-abv-visualize-inflection-matrix (word-type &optional plain)
  "Draw key grids for WORD-TYPE's inflection triggers on the Daselt layout.

With prefix argument PLAIN, show a plain org-table legend instead
of the key grids."
  (interactive
   (list (intern (completing-read "Word type: "
                                  (mapcar #'symbol-name
                                          abv-syntax-help-word-types)
                                  nil t))
         current-prefix-arg))
  (let ((layout (daselt-abv-syntax-help--layout)))
    (if plain
        (abv-syntax-help-plain-inflection-legend layout word-type)
      (daselt-abv-syntax-help--draw-temp
       (format "Inflection triggers for %s" word-type)
       (daselt-abv-syntax-help--inflection-sections
        layout
        (abv-layout-inflection-trigger-groups layout word-type))))))

;;;###autoload
(defun daselt-abv-visualize-word-type-matrix (&optional plain)
  "Draw a key grid of the word-type triggers on the Daselt layout.

With prefix argument PLAIN, show a plain org-table legend instead
of the key grid."
  (interactive (list current-prefix-arg))
  (let ((layout (daselt-abv-syntax-help--layout)))
    (if plain
        (abv-syntax-help-plain-word-type-legend layout)
      (daselt-abv-syntax-help--draw-temp
       "Word-type triggers"
       (list
        (cons "Word type by column"
              (daselt-abv-syntax-help--entry-placevals
               layout
               (abv-layout-word-type-trigger-entries layout)
               (lambda (entry)
                 (format "%s: %s" (car entry)
                         (symbol-name (cdr entry)))))))))))

;;;###autoload
(defun daselt-abv-visualize-conversion-matrix
    (from-type &optional plain)
  "Draw a key grid of conversion triggers from FROM-TYPE on the Daselt layout.

With prefix argument PLAIN, show a plain org-table legend instead
of the key grid."
  (interactive
   (list (intern (completing-read "Convert from word type: "
                                  (mapcar #'symbol-name
                                          (daselt-abv-syntax-help--from-types))
                                  nil t))
         current-prefix-arg))
  (let ((layout (daselt-abv-syntax-help--layout)))
    (if plain
        (abv-syntax-help-plain-conversion-legend layout from-type)
       (daselt-abv-syntax-help--draw-temp
        (format "Conversion triggers from %s" from-type)
        (list
         (cons (format "Conversions from %s" from-type)
               (daselt-abv-syntax-help--entry-placevals
                layout
                (abv-layout-conversion-trigger-entries layout from-type)
                (lambda (entry)
                  (format "%s: %s → %s" (car entry)
                          (daselt-abv-syntax-help--conversion-label
                           layout entry from-type)
                          (symbol-name (car (cdr entry))))))))))))

;;;###autoload
(defun daselt-abv-explain-typing (word)
  "Explain how WORD's abbreviation key is built.
Shows the key, its base-letter reading (each symbol mapped to its
base-layer letter), how many letters match the word in order, and
the provenance class: plain mnemonic (subsequence of the word's
own letters), layer variant (the same with symbols swapped for
lookalikes like h -> H/eta), deep (truncation of the morph deep
typings), free-pool fill, or numbered fallback."
  (interactive
   (list (read-string "Explain typing of word: "
                      (and (region-active-p)
                           (buffer-substring-no-properties
                            (region-beginning) (region-end))))))
  (let* ((collection (abv-current-collection))
         (layout (daselt-abv-syntax-help--layout))
         (hit nil))
    (cl-dolist (table (oref collection tables))
      (let ((oa (and (slot-boundp table 'obarray)
                     (oref table obarray))))
        (when (obarrayp oa)
          (mapatoms
           (lambda (sym)
             (when (and (not hit) (boundp sym)
                        (stringp (symbol-value sym))
                        (string= (symbol-value sym) word))
               (setq hit (cons table (symbol-name sym)))))
           oa)
          (when hit (cl-return nil)))))
    (if (not hit)
        (message "No abbreviation bound for %S in the collection" word)
      (let* ((key (cdr hit))
             (prov (abv-typed-layout--typing-provenance layout key word))
             (bases (abv-typed-layout--string-base-letters layout key))
             (reading (and (listp bases)
                           (apply #'string
                                  (delq nil (copy-sequence bases))))))
        (message "%S -> key %S [%s]: reads as %S, %d/%d letters match"
                 word key
                 (plist-get prov :kind)
                 (or reading key)
                 (plist-get prov :matched)
                 (plist-get prov :total))))))


;;;; Morph derivation analysis (layer-geometric mnemonic model)

;; The mnemonic design ties word keys to MORPH typings: a word key
;; renders a prefix of each constituent morph's graph typing.  These
;; helpers make that composition visible and measurable.  Deviations
;; are expressed in LAYOUT GEOMETRY, not optics: a substituted symbol
;; is understood as "the same key, shifted by k layers" (same row and
;; column), never as "a glyph that looks like" the expected one.

(defun daselt-abv--coords-of (layout str)
  "Return (LAYER ROW COL) of the one-symbol STR on LAYOUT, or nil.
Scans the single-symbol placevals directly: the Daselt match
machinery can miss after `eieio-persistent-read' (persisted hash
tables restore eql-test, so string lookups fail by identity)."
  (ignore-errors
    (car (car (cl-member str (oref (oref layout placevals) single-symbol-placevals)
                         :test (lambda (s pv) (string= s (cdr pv))))))))

(defvar daselt-abv--layer-mnemonic-order '(1 2 4 3 5 6 8 7)
  "Layers by descending mnemonic value (see
`daselt-abv--variant-layer-order').  Shift distance in the
derivation analysis is measured as rank distance in this order,
not as raw layer-number distance.")

(defun daselt-abv--layer-rank (layer)
  "Mnemonic rank of LAYER (0 = best); nil when unknown."
  (cl-position layer daselt-abv--layer-mnemonic-order))

(defun daselt-abv--deriv-classify (s1 s2 layout)
  "Compare key symbol S1 with expected typing symbol S2 on LAYOUT.
Return `exact', (shift DL) for the same key position with mnemonic
rank distance DL (see `daselt-abv--layer-mnemonic-order'), or
`wrong'."
  (cond
   ((string= s1 s2) 'exact)
   ((let ((c1 (daselt-abv--coords-of layout s1))
          (c2 (daselt-abv--coords-of layout s2)))
      (and c1 c2
           (= (nth 1 c1) (nth 1 c2))
           (= (nth 2 c1) (nth 2 c2))
           (list 'shift
                 (abs (- (or (daselt-abv--layer-rank (nth 0 c1)) 99)
                         (or (daselt-abv--layer-rank (nth 0 c2)) 99)))))))
   (t 'wrong)))

(defun daselt-abv--deriv-better-p (a b)
  "Return non-nil when alignment A beats B (fewer bad, then fewer
shifts, then less layer distance)."
  (or (< (nth 0 a) (nth 0 b))
      (and (= (nth 0 a) (nth 0 b))
           (or (< (nth 1 a) (nth 1 b))
               (and (= (nth 1 a) (nth 1 b))
                    (< (nth 2 a) (nth 2 b)))))))

(defun daselt-abv--deriv-join (rest bad sh dl label)
  "Extend alignment REST by one step."
  (list (+ bad (nth 0 rest))
        (+ sh (nth 1 rest))
        (+ dl (nth 2 rest))
        (if label (cons label (nth 3 rest)) (nth 3 rest))))

(defun daselt-abv--deriv-dp (memo key typings layout ci cj ki)
  "Align KEY[ki..] against TYPINGS[ci..][cj..]; memoized in MEMO.
Return (BAD SHIFTS DL LABELS), or nil when nothing fits."
  (or (gethash (list ci cj ki) memo)
      (let ((best nil)
            (ntyp (length typings))
            (klen (length key)))
        (when (= ki klen)
          (setq best '(0 0 0 nil)))
        (if (= ci ntyp)
            (unless (= ki klen)
              ;; No morphs left: every remaining symbol is an
              ;; orphan.
              (let ((ls nil) (i ki) (bad 0))
                (while (< i klen)
                  (push (list 'orphan (substring key i (1+ i))) ls)
                  (cl-incf bad)
                  (cl-incf i))
                (setq best (list bad 0 0 (nreverse ls)))))
          (let ((tlen (length (nth ci typings))))
            (when (< ki klen)
              (when (< cj tlen)
                ;; Consume KEY[ki] against TYPINGS[ci][cj].
                (let* ((ks (substring key ki (1+ ki)))
                       (ts (substring (nth ci typings) cj (1+ cj)))
                       (cls (daselt-abv--deriv-classify ks ts layout))
                       (cand nil))
                  (pcase cls
                    ('exact
                     (setq cand
                           (daselt-abv--deriv-join
                            (daselt-abv--deriv-dp
                             memo key typings layout ci (1+ cj) (1+ ki))
                            0 0 0 (list 'exact ks ci))))
                    ((pred listp)
                     (setq cand
                           (daselt-abv--deriv-join
                            (daselt-abv--deriv-dp
                             memo key typings layout ci (1+ cj) (1+ ki))
                            0 1 (cadr cls)
                            (list 'shift ks ci (cadr cls)))))
                    ('wrong
                     (setq cand
                           (daselt-abv--deriv-join
                            (daselt-abv--deriv-dp
                             memo key typings layout ci (1+ cj) (1+ ki))
                            1 0 0 (list 'wrong ks ci)))))
                  (when (and cand (or (null best)
                                      (daselt-abv--deriv-better-p
                                       cand best)))
                    (setq best cand)))
                ;; Skip one expected typing symbol (prefix
                ;; truncation).
                (let ((cand2 (daselt-abv--deriv-dp
                              memo key typings layout ci (1+ cj) ki)))
                  (when (and cand2 (or (null best)
                                       (daselt-abv--deriv-better-p
                                        cand2 best)))
                    (setq best cand2)))
                ;; Orphan: consume a key symbol from nowhere.
                (let* ((ks (substring key ki (1+ ki)))
                       (cand3
                        (daselt-abv--deriv-join
                         (daselt-abv--deriv-dp
                          memo key typings layout ci cj (1+ ki))
                         1 0 0 (list 'orphan ks))))
                  (when (or (null best)
                            (daselt-abv--deriv-better-p cand3 best))
                    (setq best cand3))))
            ;; Morph exhausted: move to the next.
            (when (= cj tlen)
              (let ((cand4 (daselt-abv--deriv-dp
                            memo key typings layout (1+ ci) 0 ki)))
                (when (and cand4 (or (null best)
                                     (daselt-abv--deriv-better-p
                                      cand4 best)))
                  (setq best cand4))))))
        (puthash (list ci cj ki) best memo)
        best))))

(defun daselt-abv-derivation-labels (key cells language layout)
  "Classify how KEY renders the morph typings of CELLS on LAYOUT.
CELLS is the separator-free morph sequence (list of (FORM . TYPE)
cells); LANGUAGE resolves the morph typings.  The key is aligned
to a concatenation of typing prefixes (the generator's render
rule: each morph contributes a prefix of its typing, affixes may
contribute nothing).  Each key symbol gets a label

  (EXACT CHAR CELL)      the morph's own symbol, verbatim
  (SHIFT CHAR CELL DL)   same key position, DL layers away
                         (\"r shifted by three layers\")
  (WRONG CHAR CELL)      a different key position than expected
  (ORPHAN CHAR)          no correspondence to any morph typing

The alignment minimizes the number of WRONG and ORPHAN labels,
then SHIFT labels, then total layer distance.  Return the label
list in key order, or nil when a morph typing cannot be resolved."
  (let* ((typings
          (delq nil
                (mapcar (lambda (cell)
                          (let ((ts (abv-typed-layout-morph-typing-string
                                     cell layout language)))
                            (and (stringp ts) (not (string= ts "")) ts)))
                        cells))))
    (unless (memq nil typings)
      (let ((memo (make-hash-table :test 'equal)))
        (nth 3 (daselt-abv--deriv-dp memo key typings layout 0 0 0))))))

(defun daselt-abv-derivation-class (labels)
  "Summarize LABELS from `daselt-abv-derivation-labels'.
Return one of rule-exact, layer-shift, deviating, non-derived."
  (cond
   ((null labels) 'non-derived)
   ((cl-every (lambda (l) (eq (car l) 'exact)) labels) 'rule-exact)
   ((cl-every (lambda (l) (memq (car l) '(exact shift))) labels)
    'layer-shift)
   ((cl-some (lambda (l) (eq (car l) 'orphan)) labels) 'non-derived)
   (t 'deviating)))

(defun daselt-abv-show-derivation (word)
  "Show how WORD's abbrev key decomposes into its morphs' symbols.
Displays the word's key, each constituent morph with its graph
typing, the key symbols aligned to them, and the geometric label
of every deviation (same key shifted by k layers, different key,
or no correspondence)."
  (interactive "sWord: ")
  (let* ((coll (abv-current-collection))
         (layout (daselt-abv-syntax-help--layout))
         (table (cl-find-if
                 (lambda (tb)
                   (and (object-of-class-p tb 'abv-language-table)
                        (not (object-of-class-p tb 'abv-sublingual-table))))
                 (oref coll tables)))
         (sym nil))
    (when (and table (obarrayp (oref table obarray)))
      (mapatoms (lambda (s)
                  (when (and (boundp s)
                             (stringp (symbol-value s))
                             (string= (symbol-value s) word)
                             (not sym))
                    (setq sym s)))
                (oref table obarray)))
    (unless (and table sym)
      (user-error "No abbrev for %S" word))
    (let* ((key (symbol-name sym))
           (mseq (get sym :morph-sequence))
           (cells (cl-remove-if
                   (lambda (c) (abv-morph--separator-type-p (cdr c)))
                   mseq))
           (language (oref table language))
           (labels (daselt-abv-derivation-labels
                    key cells language layout))
           (class (daselt-abv-derivation-class labels)))
      (daselt-base-with-max-buffer-maybe-return
       "*abv derivation*"
       (lambda ()
         (with-current-buffer (get-buffer-create "*abv derivation*")
           (let ((inhibit-read-only t))
             (erase-buffer)
             (insert (format "%S  key: %S  (%s)\n\n" word key class))
             (dolist (cell cells)
               (insert
                (format "  morph %-10S (%s)  typing %S\n"
                        (car cell) (cdr cell)
                        (abv-typed-layout-morph-typing-string
                         cell layout language))))
             (insert "\n")
             (dolist (l labels)
               (let ((morph (and (nth 2 l)
                                 (car (nth (nth 2 l) cells)))))
                 (pcase (car l)
                   ('exact
                    (insert (format "  %S  exact symbol of %S\n"
                                    (nth 1 l) morph)))
                   ('shift
                    (insert
                     (format "  %S  %d layer(s) from %S's symbol\n"
                             (nth 1 l) (nth 3 l) morph)))
                   ('wrong
                    (insert
                     (format "  %S  different key than %S's symbol\n"
                             (nth 1 l) morph)))
                   ('orphan
                    (insert
                     (format "  %S  no morph correspondence\n"
                             (nth 1 l)))))))
             (goto-char (point-min)))))))))
(provide 'daselt-abv-syntax-help)
;;; daselt-abv-syntax-help.el ends here
