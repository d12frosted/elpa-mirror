;;; daselt-abv-inflection.el --- Daselt abv inflection/word-type/conversion decoding  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; License: GPL-3+

;;; Commentary:

;; Decoding module for the Daselt abv integration.  Translates a
;; coordinate on the Daselt layout into grammatical features (tense,
;; person, mood, aspect, voice, case, gender, degree, number),
;; word-type tags (verb, noun, adjective, ...) and conversion-method
;; suffixes.  Implements the Daselt specializations of
;; `abv-layout-inflection-info',
;; `abv-layout-word-type-from-string' and
;; `abv-layout-conversion-method-from-string'.

;;; Code:

(require 'daselt-abv-layout)

;;;; Coordinate-component decoders

(defun daselt-abv--number-from-layer (layer)
  "Decode grammatical number from LAYER.

Lower layers (1,4,5,8) denote singular; upper layers denote plural."
  (if (daselt-abv--lower-layer-p layer) 'singular 'plural))

(defun daselt-abv--negate-from-layer (layer)
  "Decode negation from LAYER.

Layer pair (1,2) means nil (no negation); pair (5,6) means t (negated). Returns
nil for other layers."
  (cond ((memq layer '(1 2)) nil)
        ((memq layer '(5 6)) t)))

(defun daselt-abv--tense-from-col (col)
  "Decode tense from column COL.

Columns -5,-4 encode far/near-past; -2 encodes past; -1,0,1 encode present; 2
encodes future; -3 past-participle, 3 gerund and 4 infinitive. Other columns
return nil."
  (cond ((= col -3) 'past-participle)
        ((= col -2) 'past)
        ((memq col '(-1 0 1)) 'present)
        ((= col 2) 'future)
        ((= col 3) 'gerund)
        ((= col 4) 'infinitive)))

(defun daselt-abv--person-from-row (row)
  "Decode grammatical person from row ROW.

Row -1 is first person, 0 is third, 1 is second."
  (cond ((= row -1) 1)
        ((= row 0) 3)
        ((= row 1) 2)))

(defun daselt-abv--aspect-from-col (col)
  "Decode aspect from column COL (absolute value 2 or 3).

Column -3 is perfect, -2 progressive, 2 perfect-progressive, 3 simple."
  (cond ((= col -3) 'perfect)
        ((= col -2) 'progressive)
        ((= col 2) 'perfect-progressive)
        ((= col 3) 'simple)))

(defun daselt-abv--mood-from-row (row)
  "Decode mood from row ROW.

Row -1 is subjunctive, 0 indicative, 1 imperative."
  (cond ((= row -1) 'subjunctive)
        ((= row 0) 'indicative)
        ((= row 1) 'imperative)))

(defun daselt-abv--voice-from-layer (layer)
  "Decode voice from LAYER.  Layers 2 and 6 denote passive voice."
  (if (memq layer '(2 6)) 'passive 'active))

(defun daselt-abv--case-from-row (row)
  "Decode grammatical case from row ROW.

Row 0 is common (default), -1 is genitive."
  (if (= row -1) 'genitive 'common))

(defun daselt-abv--degree-from-row (row)
  "Decode degree of comparison from row ROW.

Row -1 is positive, 0 comparative, 1 superlative."
  (cond ((= row -1) 'positive)
        ((= row 0) 'comparative)
        ((= row 1) 'superlative)))

(defun daselt-abv--gender-from-col (col)
  "Decode gender from column COL.

Column -2 is masculine, -1 feminine, 0 neuter."
  (cond ((= col -2) 'masculine)
        ((= col -1) 'feminine)
        ((= col 0) 'neuter)))

(defun daselt-abv--verb-first-char-info (coord)
  "Decode COORD into first-character verb inflection features.

Returns a plist with :tense, :person, :number, :negate, and
:subject.  The layer pair encodes negation and the subject
pronoun: (1,2) neither, (5,6) negated, (4,3) with subject, (8,7)
negated with subject."
  (let* ((col (daselt-abv--coord-col coord))
         (row (daselt-abv--coord-row coord))
         (layer (daselt-abv--coord-layer coord)))
    `(:tense ,(daselt-abv--tense-from-col col)
             :person ,(daselt-abv--person-from-row row)
             :number ,(daselt-abv--number-from-layer layer)
             :negate ,(and (memq layer '(5 6 7 8)) t)
             :subject ,(and (memq layer '(3 4 7 8)) t))))

(defun daselt-abv--verb-second-char-info (coord)
  "Decode COORD into second-character verb inflection features.

Returns a plist with :mood, :aspect, :voice, and :particle.  The
layer pair (5,6) appends the verb's particle."
  (let* ((col (daselt-abv--coord-col coord))
         (row (daselt-abv--coord-row coord))
         (layer (daselt-abv--coord-layer coord)))
    `(:mood ,(daselt-abv--mood-from-row row)
            :aspect ,(daselt-abv--aspect-from-col col)
            :voice ,(daselt-abv--voice-from-layer layer)
            :particle ,(and (memq layer '(5 6)) t))))

(defun daselt-abv--degree-info (coord)
  "Decode COORD into adjective/adverb inflection features.

Returns a plist with :degree, :negate, and :particle.  The upper
layer of a layer pair appends the word's particle."
  (let ((layer (daselt-abv--coord-layer coord)))
    `(:degree ,(daselt-abv--degree-from-row (daselt-abv--coord-row coord))
              :negate ,(daselt-abv--negate-from-layer layer)
              :particle ,(not (daselt-abv--lower-layer-p layer)))))

(defun daselt-abv--noun-info (coord)
  "Decode COORD into noun inflection features.

Returns a plist with :number, :case, :definiteness, and :particle.
The layer pair encodes definiteness: (5,6) definite, (4,3)
indefinite.  Row 1 appends the noun's particle."
  (let ((row (daselt-abv--coord-row coord))
        (layer (daselt-abv--coord-layer coord)))
    `(:number ,(daselt-abv--number-from-layer layer)
              :case ,(daselt-abv--case-from-row row)
              :definiteness ,(cond ((memq layer '(5 6)) 'definite)
                                   ((memq layer '(3 4)) 'indefinite))
              :particle ,(= row 1))))

;;;; abv-layout-inflection-info specializations

(cl-defmethod abv-layout-inflection-info ((layout daselt-abv-layout)
                                          (_type (eql 'verb)) data &optional _language)
  "Return verb inflection info from DATA on a Daselt layout.

DATA is a string of one or two characters from the syntax separator. The first
character encodes tense, person, number, and negate via its position on the
layout: - Column encodes tense: -2=past, -1/0/1=present, 2=future, ; -3
past-participle, 3 gerund and 4 infinitive. - Row encodes person: -1=1st, 0=3rd,
1=2nd. - Layer pair encodes negate and subject pronoun: (1,2) neither, (5,6)
negated, (4,3) with subject, (8,7) negated with subject. - Lower layer in pair
is singular, upper is plural.

The optional second character encodes mood, aspect, and voice: - Column with
|col| 2-3 encodes aspect: -3=perfect, -2=progressive, 2=perfect-progressive,
3=simple. - Row encodes mood: -1=subjunctive, 0=indicative, 1=imperative. -
Layers 2 and 6 encode passive voice, all others active. - Layer pair (5,6)
appends the verb's particle."
  (let* ((chars (string-to-list (or data "")))
         (coord1 (and chars (daselt-abv--char-coord layout (car chars))))
         (coord2 (and (cdr chars)
                      (daselt-abv--char-coord layout (cadr chars))))
         (info1 (and coord1 (daselt-abv--verb-first-char-info coord1)))
         (info2 (and coord2 (daselt-abv--verb-second-char-info coord2))))
    (append info1 info2)))

(cl-defmethod abv-layout-inflection-info ((layout daselt-abv-layout)
                                          (_type (eql 'noun)) data &optional _language)
  "Return noun inflection info from DATA on a Daselt layout.

DATA is a string of one character. Its position encodes: - Layer pair determines
number: lower layer=singular, upper=plural. - Row determines case: 0=common,
-1=genitive; row 1 appends the noun's particle. - Layer pair encodes
definiteness: (5,6)=definite, (4,3)=indefinite."
  (let* ((chars (string-to-list (or data "")))
         (coord (and chars (daselt-abv--char-coord layout (car chars)))))
    (when coord
      (daselt-abv--noun-info coord))))

(cl-defmethod abv-layout-inflection-info ((layout daselt-abv-layout)
                                          (_type (eql 'adjective)) data &optional _language)
  "Return adjective inflection info from DATA on a Daselt layout.

DATA is a string of one character. Its row encodes degree of comparison:
-1=positive, 0=comparative, 1=superlative. Its layer pair encodes negate:
(1,2)=nil, (5,6)=t. The upper layer of a pair appends the word's particle."
  (let* ((chars (string-to-list (or data "")))
         (coord (and chars (daselt-abv--char-coord layout (car chars)))))
    (when coord
      (daselt-abv--degree-info coord))))

(cl-defmethod abv-layout-inflection-info ((layout daselt-abv-layout)
                                          (_type (eql 'adverb)) data &optional _language)
  "Return adverb inflection info from DATA on a Daselt layout.

DATA is a string of one character. Its row encodes degree of comparison:
-1=positive, 0=comparative, 1=superlative. Its layer pair encodes negate:
(1,2)=nil, (5,6)=t. The upper layer of a pair appends the word's particle."
  (let* ((chars (string-to-list (or data "")))
         (coord (and chars (daselt-abv--char-coord layout (car chars)))))
    (when coord
      (daselt-abv--degree-info coord))))

(cl-defmethod abv-layout-inflection-info ((layout daselt-abv-layout)
                                          (_type (eql 'pronoun)) data &optional _language)
              "Return pronoun inflection info from DATA on a Daselt layout.

DATA is a string of one or two characters. The first character encodes person
and number: - Row encodes person: -1=1st, 0=3rd, 1=2nd. - Layer pair determines
number: lower=singular, upper=plural.

The optional second character encodes gender and case: - Column encodes gender:
-2=masculine, -1=feminine, 0=neuter. - Row encodes case: -1=nominative,
0=objective, 1=possessive."
              (let* ((chars (string-to-list (or data "")))
         (coord1 (and chars (daselt-abv--char-coord layout (car chars))))
         (coord2 (and (cdr chars)
                      (daselt-abv--char-coord layout (cadr chars))))
         (info1 (when coord1
                  `(:person ,(daselt-abv--person-from-row
                              (daselt-abv--coord-row coord1))
                            :number ,(daselt-abv--number-from-layer
                                      (daselt-abv--coord-layer coord1)))))
         (info2 (when coord2
                  `(:gender ,(daselt-abv--gender-from-col
                              (daselt-abv--coord-col coord2))
                            :case ,(pcase (daselt-abv--coord-row coord2)
                                     (-1 'nominative)
                                     (0 'objective)
                                     (1 'possessive-determiner))))))
    (append info1 info2)))

(cl-defmethod abv-layout-inflection-info ((layout daselt-abv-layout)
                                          (_type (eql 'determiner)) data &optional _language)
                                                                "Return
                        determiner inflection info from DATA on a Daselt layout.

DATA is a string of one character. Its layer pair determines number: lower
layer=singular, upper=plural."
                                                                (let* ((chars (string-to-list (or data "")))
         (coord (and chars (daselt-abv--char-coord layout (car chars)))))
    (when coord
      `(:number ,(daselt-abv--number-from-layer
                  (daselt-abv--coord-layer coord))))))

;;;; Word-type mapping from single-character strings

(defun daselt-abv--word-type-from-coord (coord)
  "Decode word type from Daselt coordinate COORD.

Column determines type: -3 → pronoun, -2 → verb, -1 → adjective, 1 → adverb, 2 →
verb, 3 → determiner."
  (let* ((col (daselt-abv--coord-col coord)))
    (cond
     ;; Column overrides for less common types
     ((= col -3) 'pronoun)
     ((= col -2) 'verb)
     ((= col -1) 'adjective)
     ((= col 1) 'adverb)
     ((= col 2) 'noun)
     ((= col 3) 'determiner)
     (t nil))))

(cl-defmethod abv-layout-word-type-from-string ((layout daselt-abv-layout)
                                                string &optional _language)
  "Decode word type from STRING on a Daselt layout.

STRING is one character. Its position determines the word type."
  (let* ((chars (string-to-list (or string ""))))
    (when chars
      (let ((coord (daselt-abv--char-coord layout (car chars))))
        (when coord
          (daselt-abv--word-type-from-coord coord))))))


;;;; Conversion-method mapping from coordinates

(defconst daselt-abv--conversion-method-table
  '(((verb . noun)
     (((-1 lower) . "-ment")
      ((0 lower)  . "-ion")
      ((1 lower)  . "-ation")
      ((-1 upper) . "-al")
      ((0 upper)  . "-age")
      ((1 upper)  . "-ery")))
    ((adjective . noun)
     (((-1 lower) . "-ness")
      ((0 lower)  . "-ity")
      ((1 lower)  . "-ation")
      ((-1 upper) . "-th")
      ((0 upper)  . "-ism")
      ((1 upper)  . "-ity")))
    ((noun . verb)
     (((-1 lower) . "-ize")
      ((0 lower)  . "-ify")
      ((1 lower)  . "-en")
      ((-1 upper) . "-ate")
      ((0 upper)  . "-ish")
      ((1 upper)  . "-er")))
    ((adjective . verb)
     (((-1 lower) . "-ize")
      ((0 lower)  . "-en")
      ((1 lower)  . "-ify")
      ((-1 upper) . "-ate")
      ((0 upper)  . "-ish")
      ((1 upper)  . "-er")))
    ((noun . adjective)
     (((-1 lower) . "-al")
      ((0 lower)  . "-ic")
      ((1 lower)  . "-ful")
      ((-1 upper) . "-ous")
      ((0 upper)  . "-less")
      ((1 upper)  . "-ical")))
    ((verb . adjective)
     (((-1 lower) . "-ive")
      ((0 lower)  . "-able")
      ((1 lower)  . "-ing")
      ((-1 upper) . "-ory")
      ((0 upper)  . "-ent")
      ((1 upper)  . "-ant")))
    ((noun . adverb)
     (((-1 lower) . "-ly")
      ((0 lower)  . "-wise")
      ((1 lower)  . "-ward")))
    ((adjective . adverb)
     ;; English adverbialization (-ly with its -y/-ally
     ;; orthographic variants and per-word conversion-defaults
     ;; like good -> well) is entirely handled by the language
     ;; layer, so no key position may override it with an
     ;; explicit affix.
     (((-1 lower) . language)
      ((0 lower)  . language)))
    ((verb . adverb)
     (((-1 lower) . "-ingly")))
    ;; Same-type conversions: the key of the word's own type.
    ((verb . verb)
     (((-1 lower) . "re-")
      ((0 lower)  . "un-")
      ((1 lower)  . "de-")
      ((-1 upper) . "over-")
      ((0 upper)  . "mis-")
      ((1 upper)  . "under-")
      ((-1 lower 5) . "dis-")
      ((0 lower 5)  . "pre-")
      ((1 lower 5)  . "sub-")
      ((-1 upper 5) . "self--")
      ((0 upper 5)  . "co-")
      ((1 upper 5)  . "out-")
      ((-1 lower 8) . "up-")
      ((1 lower 8)  . "down-")))
    ((noun . noun)
     (((-1 lower) . "-ist")
      ((0 lower)  . "-ism")
      ((1 lower)  . "-ship")
      ((-1 upper) . "sub-")
      ((0 upper)  . "co-")
      ((1 upper)  . "non-")
      ((-1 lower 5) . "re-")
      ((0 lower 5)  . "dis-")
      ((1 lower 5)  . "pre-")
      ((-1 upper 5) . "in-")
      ((0 upper 5)  . "counter-")
      ((1 upper 5)  . "self--")
      ((-1 lower 8) . "up-")
      ((1 lower 8)  . "down-")))
    ((adjective . adjective)
     (((-1 lower) . "non-")
      ((0 lower)  . "-ish")
      ((1 lower)  . "over-")
      ((-1 upper) . "sub-")
      ((0 upper)  . "anti-")
      ((1 upper)  . "self--")
      ((-1 lower 5) . "un-")
      ((0 lower 5)  . "in-")
      ((-1 upper 5) . "inter-")
      ((0 upper 5)  . "extra-"))))
  "Conversion-method table mapping (FROM-TYPE .

TO-TYPE) to affixes. Each entry is a list of ((ROW LOWER/UPPER [PAIR]) . AFFIX)
pairs. ROW is -1, 0, or 1. LOWER/UPPER distinguishes lower vs upper layer in a
Daselt layer pair. PAIR, the lower layer of a layer pair (1, 4, 5 or 8, see
`daselt-abv--pair-lower-layer'), restricts the entry to that pair; an entry
without PAIR holds on every pair that has no entry of its own for the
position. An affix starting with '-' is appended to the word, one
ending in '-' is put before it (see `abv-syntax-method-kind'). Any other
string replaces the word entirely.  Several word-type characters convert in a
chain, each from the type the previous one produced.  The symbol `language' in place of a suffix
string defers the conversion to the language's rules: no position affix is
decoded and the expansion falls back to `abv-syntax-convert-word' (stored
conversion-default, regex-matched suffix, language default).

The selectors apply to the higher layers only: keys on the first
layer (layer 1) return the word's stored conversion-default for
the target type when one is stored (see
`daselt-abv--conversion-method-from-coord'); without one they
return nil, and the expansion falls back to the language's
regex-matched conversion suffix and then to the language's own
conversion (which may be dictionary-validated) before using the
key's affix from this table, which applies only when the language
has no answer (see `abv-syntax--effective-conversion-method').")

(defun daselt-abv--pair-lower-layer (layer)
  "Return the lower layer of the Daselt layer pair containing LAYER.
The pairs are (1 . 2), (4 . 3), (5 . 6) and (8 . 7)."
  (pcase layer
    ((or 1 2) 1)
    ((or 4 3) 4)
    ((or 5 6) 5)
    ((or 8 7) 8)))

(defun daselt-abv--position-affix-from-coord (from-type coord)
  "Decode the position-encoded affix from COORD given FROM-TYPE.
Every key that supports a conversion returns the affix its row
and lower/upper position within its layer pair encodes in
`daselt-abv--conversion-method-table'; an entry for the key's own
layer pair wins over one for all pairs.  A
`language' sentinel in the table decodes no position affix: the
conversion is deferred to the language's rules.
This ignores first-layer conversion-default semantics; it is the
fallback used when neither a stored default nor a language
conversion applies (see `abv-syntax--effective-conversion-method')."
  (let* ((row (daselt-abv--coord-row coord))
         (layer (daselt-abv--coord-layer coord))
         (to-type (daselt-abv--word-type-from-coord coord))
         (lower (daselt-abv--lower-layer-p layer))
         (key (cons from-type to-type))
         (entry (assoc key daselt-abv--conversion-method-table
                       #'equal)))
    (when (and entry to-type)
      (let* ((methods (cadr entry))
             (lu-sym (if lower 'lower 'upper))
             (pair (daselt-abv--pair-lower-layer layer))
             (match (cl-flet ((find-for (entry-pair)
                                (cl-find (list row lu-sym entry-pair) methods
                                         :key (lambda (cell)
                                                (pcase-let ((`(,r ,lu ,p)
                                                             (car cell)))
                                                  (list r lu p)))
                                         :test #'equal)))
                      (or (find-for pair) (find-for nil)))))
        (when (and match (stringp (cdr match)))
          (cdr match))))))

(defun daselt-abv--conversion-method-from-coord (from-type coord
                                                  &optional conversion-default)
        "Decode a conversion-method suffix from COORD given FROM-TYPE.
Keys on the first layer (layer 1) request the word's stored
conversion default: return CONVERSION-DEFAULT when non-nil and nil
otherwise — the expansion then consults the language's
regex-based conversion methods
(`abv-language-conversion-suffix-match') and the language's own
conversion (which may be dictionary-validated) before falling
back to the key's position-encoded affix
(`daselt-abv--position-affix-from-coord'), the last resort when
the language has no answer.  Keys on the higher
layers decode their default affixes from
`daselt-abv--conversion-method-table' by row and lower/upper
position within their layer pair."
  (let* ((layer (daselt-abv--coord-layer coord)))
    (if (= layer 1)
        conversion-default
      (daselt-abv--position-affix-from-coord from-type coord))))

(cl-defmethod abv-layout-conversion-method-from-string
    ((layout daselt-abv-layout) string &optional _language from-type
     conversion-default)
     "Decode a conversion-method suffix from STRING on a Daselt layout.

STRING is a single character. FROM-TYPE is the source word type symbol (e.g.,
`verb'). The character's coordinate determines both the target type and the
conversion suffix: on the first layer (layer 1) the word's stored conversion
default (CONVERSION-DEFAULT, when non-nil) is returned; a first-layer key
without a stored default returns nil, letting the caller fall back to the
language's regex-matched conversion suffix and then to the language's own
conversion before resorting to the key's position affix
(`abv-layout-position-affix-from-string', the last-resort fallback when the
language has no answer).  Keys on the higher layers decode
their suffix from `daselt-abv--conversion-method-table'."
    (let* ((chars (string-to-list (or string ""))))
    (when chars
      (let ((coord (daselt-abv--char-coord layout (car chars))))
        (when coord
          (daselt-abv--conversion-method-from-coord
           from-type coord conversion-default))))))

(cl-defmethod abv-layout-position-affix-from-string
    ((layout daselt-abv-layout) string &optional _language from-type)
    "Decode the position-encoded affix from STRING on a Daselt layout.
STRING is a single character; its coordinate's row and lower/upper
position within the layer pair select the affix from
`daselt-abv--conversion-method-table'.  Unlike
`abv-layout-conversion-method-from-string' this returns the
position affix for every key, including first-layer keys.  A
`language' sentinel in the table decodes no position affix, so
the conversion defers to the language's rules."
  (let* ((chars (string-to-list (or string ""))))
    (when chars
      (let ((coord (daselt-abv--char-coord layout (car chars))))
        (when coord
          (daselt-abv--position-affix-from-coord from-type coord))))))

(provide 'daselt-abv-inflection)
;;; daselt-abv-inflection.el ends here
