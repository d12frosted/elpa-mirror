;;; daselt-abv-typing-tests.el --- Tests for daselt-abv-typing  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; Author: Alexander Praehauser <ahprae@protonmail.com>
;; Keywords: abbrev

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Tests for `daselt-abv-typing': `abv-set-typings' specializations,
;; `daselt-abv--assign-one', `abv-typed-layout-type-root' and the
;; morph-typing/sequence-string methods.

;;; Code:

(require 'ert)
(require 'cl-lib)
(require 'daselt-abv-tests--setup)
(require 'daselt-abv-typing)


;;;; Helpers

(defun daselt-abv-typing-tests--make-placevals ()
  "Return a small set of paired placevals for tests."
  '(((1 0 1) . "a") ((2 0 1) . "A")
    ((1 0 2) . "b") ((2 0 2) . "B")
    ((1 0 -1) . "c") ((2 0 -1) . "C")
    ((1 0 -2) . "d") ((2 0 -2) . "D")))


;;;; abv-set-typings (placevals list specialization)

(ert-deftest daselt-abv-set-typings-placevals-assigns-affixes ()
  "`abv-set-typings' (placevals, stats) assigns coords to affixes."
  (let* ((placevals (daselt-abv-typing-tests--make-placevals))
         (stats '(("ab" . 5) ("cd" . 3)))
         (table (make-hash-table :test 'equal))
         (layout daselt-abv--default-layout)
         (result (abv-set-typings placevals stats
                                  :table table
                                  :reset t
                                  :layout layout)))
    ;; Both affixes should have been assigned.
    (should (gethash "ab" table))
    (should (gethash "cd" table))
    ;; The result is an alist of (affix . coord).
    (should (consp result))
    ;; Each assigned coord is a triple.
    (should (= 3 (length (gethash "ab" table))))
    (should (= 3 (length (gethash "cd" table))))))

(ert-deftest daselt-abv-set-typings-placevals-reset-skip-existing ()
  "When RESET is nil, already-tabled affixes are skipped."
  (let* ((placevals (daselt-abv-typing-tests--make-placevals))
         (stats '(("ab" . 5)))
         (table (make-hash-table :test 'equal))
         (layout daselt-abv--default-layout))
    ;; Pre-populate.
    (puthash "ab" '(9 9 9) table)
    (let ((result (abv-set-typings placevals stats
                                   :table table
                                   :reset nil
                                   :layout layout)))
      ;; Result is empty; table unchanged for "ab".
      (should (null (alist-get "ab" result)))
      (should (equal '(9 9 9) (gethash "ab" table))))))


;;;; abv-typed-layout-morph-typing-string

(ert-deftest daselt-abv-morph-typing-string-nil-returns-empty ()
  "Nil typing returns the empty string."
  (let* ((lang (make-instance 'abv-language
                               :name "test"
                               :script (make-instance 'abv-script)
                               :morphs (make-instance 'abv-morph-data)))
         (layout daselt-abv--default-layout)
         (morph '("nothing-assigned-here" . root)))
    ;; With no graph in the layout, lookup yields nil -> "".
    (should (string= ""
                     (abv-typed-layout-morph-typing-string morph layout lang)))))

(ert-deftest daselt-abv-morph-typing-string-special-coords ()
  "Special coords (4 2 0) and (6 2 0) translate to Unicode separators."
  (let* ((lang (make-instance 'abv-language
                               :name "test"
                               :script (make-instance 'abv-script)
                               :morphs (make-instance 'abv-morph-data)))
         (layout daselt-abv--default-layout)
         (morph '("anything" . root))
         ;; Trick: bind `abv-typed-layout-morph-typing' via cl-labels.
         (orig-fn (symbol-function 'abv-typed-layout-morph-typing)))
    (unwind-protect
        (progn
          (fset 'abv-typed-layout-morph-typing
                (lambda (&rest _) (make-instance 'abv-rich-value :plain-value '(4 2 0))))
          (should (string= "␠" (abv-typed-layout-morph-typing-string morph layout lang)))
          (fset 'abv-typed-layout-morph-typing
                (lambda (&rest _) (make-instance 'abv-rich-value :plain-value '(6 2 0))))
          (should (string= "␟" (abv-typed-layout-morph-typing-string morph layout lang))))
      (fset 'abv-typed-layout-morph-typing orig-fn))))


(ert-deftest daselt-abv-morph-typing-string-name-cell-returns-key ()
  "A name cell's typing string is its name-table key.
Regression: the Daselt method only handled coordinate typings, so
the plain string key of a name cell reached the coordinate clauses,
errored, and typing-key generation failed for every distillate
containing a name cell."
  (let* ((lang (make-instance 'abv-language
                               :name "english"
                               :script (make-instance 'abv-script)
                               :morphs (make-instance 'abv-morph-data)))
         (layout daselt-abv--default-layout)
         (nt (make-instance 'abv-name-table
                            :obarray (obarray-make) :name "test-names"))
         (collection (make-instance 'abv-collection
                                    :global-name-table nt
                                    :tables nil)))
    (set (intern "Eu" (oref nt obarray)) "Euler")
    (abv-table-set-reversion-cache nt)
    (let ((abv-collection-current collection))
      (should (string= "Eu"
                       (abv-typed-layout-morph-typing-string
                        '("Euler" . name) layout lang))))))

;;;; abv-typed-layout-type-root

(ert-deftest daselt-abv-type-root-returns-existing-when-not-reset ()
  "Without :reset, an existing entry is returned as-is."
  (let* ((layout daselt-abv--default-layout)
         (table (make-hash-table :test 'equal))
         (existing '((1 0 1) (1 0 2))))
    (puthash "foo" existing table)
    (should (equal existing
                   (abv-typed-layout-type-root layout "foo" table)))))

(ert-deftest daselt-abv-type-root-types-short-root ()
  "Short (< 3 chars) roots produce a coordinate assignment on reset."
  (let* ((layout daselt-abv--default-layout)
         (table (make-hash-table :test 'equal)))
    (let ((result (abv-typed-layout-type-root layout "ab" table)))
      (should result)
      (should (listp result))
      ;; The assigned value is stored in the table.
      (should (equal result (gethash "ab" table))))))


;;;; abv-set-typings (layout method) requires LANGUAGE

(ert-deftest daselt-abv-set-typings-layout-errors-without-language ()
  "Calling `abv-set-typings' (layout, list) without LANGUAGE signals error."
  (let ((layout daselt-abv--default-layout))
    (should-error (abv-set-typings layout '(("ab" . 5)))
                  :type 'user-error)))


;;;; abv-typed-layout-morph-sequence-string with sub-languages

(ert-deftest daselt-abv-sequence-string-mixed-parent-typings ()
  "Morphs typed only in the parent graph render through it.
Regression: with an own graph that types only some morphs of a
sequence, the remaining morphs rendered as empty strings,
truncating the distillate string and breaking distillation."
  (let* ((plang (make-instance 'abv-language
                               :name "english"
                               :script (make-instance 'abv-script)
                               :morphs (make-instance 'abv-morph-data)))
         (slang (make-instance 'abv-sub-language
                               :name "english/sub"
                               :parent-language plang
                               :script (oref plang script)
                               :morphs (oref plang morphs)))
         (pg (make-instance 'abv-typing-graph))
         (sg (make-instance 'abv-typing-graph))
         (layout (make-instance 'daselt-abv-layout
                                :typing-graphs
                                (list (cons "english" pg)
                                      (cons "english/sub" sg)))))
    ;; "old" is typed only in the parent graph, "new" only in the
    ;; own graph; typings are plain strings.
    (puthash "old" "O" (oref pg root-table))
    (puthash "new" "N" (oref sg root-table))
    (cl-letf (((symbol-function 'abv-language-abstraction)
               (lambda (morph _language) (car morph))))
      ;; The mixed sequence renders completely via per-morph
      ;; fallback to the parent graph.
      (should (string= "ON"
                       (abv-typed-layout-morph-sequence-string
                        '(("old" . root) ("new" . root)) layout slang)))
      ;; A morph typed nowhere fails the whole sequence: nil instead
      ;; of a silently truncated string.
      (should (null (abv-typed-layout-morph-sequence-string
                     '(("ghost" . root) ("new" . root)) layout slang))))))

(ert-deftest daselt-abv-sequence-string-all-parent-typings ()
  "A sequence typed entirely in the parent graph renders fully."
  (let* ((plang (make-instance 'abv-language
                               :name "english"
                               :script (make-instance 'abv-script)
                               :morphs (make-instance 'abv-morph-data)))
         (slang (make-instance 'abv-sub-language
                               :name "english/sub"
                               :parent-language plang
                               :script (oref plang script)
                               :morphs (oref plang morphs)))
         (pg (make-instance 'abv-typing-graph))
         (sg (make-instance 'abv-typing-graph))
         (layout (make-instance 'daselt-abv-layout
                                :typing-graphs
                                (list (cons "english" pg)
                                      (cons "english/sub" sg)))))
    (puthash "old" "O" (oref pg root-table))
    (cl-letf (((symbol-function 'abv-language-abstraction)
               (lambda (morph _language) (car morph))))
      (should (string= "OO"
                       (abv-typed-layout-morph-sequence-string
                        '(("old" . root) ("old" . root)) layout slang))))))

(ert-deftest daselt-abv-sequence-string-untypeable-morph-yields-nil ()
  "A sequence with an untypeable morph fails instead of truncating.
Regression: a morph typed in neither the own nor the parent graph
rendered as an empty string, so partial distillate strings were
accepted and registered as garbage abbreviations."
  (let* ((lang (make-instance 'abv-language
                              :name "english"
                              :script (make-instance 'abv-script)
                              :morphs (make-instance 'abv-morph-data)))
         (graph (make-instance 'abv-typing-graph))
         (layout (make-instance 'daselt-abv-layout
                                :typing-graphs
                                (list (cons "english" graph)))))
    (puthash "old" "O" (oref graph root-table))
    (cl-letf (((symbol-function 'abv-language-abstraction)
               (lambda (morph _language) (car morph))))
      ;; Fully typed sequence renders.
      (should (string= "O"
                       (abv-typed-layout-morph-sequence-string
                        '(("old" . root)) layout lang)))
      ;; One untypeable morph poisons the whole sequence.
      (should (null (abv-typed-layout-morph-sequence-string
                     '(("old" . root) ("ghost" . root)) layout lang))))))

(ert-deftest daselt-abv-sequence-string-name-cell-uses-name-key ()
  "A name cell renders as its name-table key; unresolvable names fail."
  (let* ((lang (make-instance 'abv-language
                              :name "english"
                              :script (make-instance 'abv-script)
                              :morphs (make-instance 'abv-morph-data)))
         (graph (make-instance 'abv-typing-graph))
         (layout (make-instance 'daselt-abv-layout
                                :typing-graphs
                                (list (cons "english" graph))))
         (nt (make-instance 'abv-name-table
                            :obarray (obarray-make) :name "test-names"))
         (tbl (make-instance 'abv-language-table
                             :name "t"
                             :language lang
                             :obarray (obarray-make)))
         (collection (make-instance 'abv-collection
                                    :global-name-table nt
                                    :tables (list tbl))))
    (when (slot-exists-p tbl 'hidden-obarray)
      (oset tbl hidden-obarray (obarray-make)))
    (set (intern "Eu" (oref nt obarray)) "Euler")
    (abv-table-set-reversion-cache nt)
    (puthash "old" "O" (oref graph root-table))
    (let ((abv-collection-current collection))
      ;; The name key is used like a morph typing.
      (should (string= "OEu"
                       (abv-typed-layout-morph-sequence-string
                        '(("old" . root) ("Euler" . name)) layout lang)))
      ;; A name that resolves in no name table is untypeable and
      ;; fails the whole sequence.
      (should (null (abv-typed-layout-morph-sequence-string
                     '(("old" . root) ("Ghost" . name)) layout lang))))))


(ert-deftest daselt-abv-sequence-string-threaded-twin-in-parent-graph ()
  "A threaded morph form renders through its plain twin in the parent graph.
Regression: morph sequences carry threaded forms (root \"fini\"
threaded from plain \"fine\") while typing graphs are keyed by
plain forms; without the plain-twin bridge, sublingual distillate
strings came out empty and typing keys were skipped."
  (let* ((morphs (make-instance 'abv-morph-data :roots '("fine")))
         (threaded (make-instance 'abv-morph-data :roots '("fini")))
         (plang (make-instance 'abv-language
                               :name "english"
                               :script (make-instance 'abv-script)
                               :morphs morphs))
         (slang (make-instance 'abv-sub-language
                               :name "english/sub"
                               :parent-language plang
                               :script (oref plang script)
                               :morphs (oref plang morphs)))
         (pg (make-instance 'abv-typing-graph))
         (sg (make-instance 'abv-typing-graph))
         (layout (make-instance 'daselt-abv-layout
                                :typing-graphs
                                (list (cons "english" pg)
                                      (cons "english/sub" sg)))))
    (puthash "fine" "F" (oref pg root-table))
    (cl-letf (((symbol-function 'abv-language--copy-morphs-with-threaded)
               (lambda (&rest _) threaded))
              ;; Abstraction finds no plain candidate for "fini";
              ;; stub it to the concrete fallback like the real one.
              ((symbol-function 'abv-language-abstraction)
               (lambda (morph _language) (car morph))))
      ;; Through the sub-language: own graph empty, parent
      ;; graph types the plain twin.
      (should (string= "F"
                       (abv-typed-layout-morph-sequence-string
                        '(("fini" . root)) layout slang)))
      ;; Mixed with own-graph typings.
      (puthash "te" "T" (oref sg suffix-table))
      (should (string= "FT"
                       (abv-typed-layout-morph-sequence-string
                        '(("fini" . root) ("te" . suffix)) layout slang))))))

;;;; Typing under the language abstraction

(ert-deftest daselt-abv-set-morph-typings-uses-abstraction ()
  "Incremental typings are stored under the language abstraction.
Distillates can carry concrete forms (e.g. \"serve\") whose
abstraction (\"serv\") is what lookups query; storing the raw form
would leave the morph untypeable."
  (let* ((lang (make-instance 'abv-language
                               :name "abstest"
                               :script (make-instance 'abv-script)
                               :morphs (make-instance 'abv-morph-data)))
         (layout daselt-abv--default-layout)
         (graph (make-instance 'abv-typing-graph :abv-language lang))
         (orig-fn (symbol-function 'abv-language-abstraction)))
    (object-add-to-list layout 'typing-graphs
                         (cons "abstest" graph))
    (unwind-protect
        (progn
          (fset 'abv-language-abstraction
                (lambda (morph _language)
                  (pcase (car morph)
                    ("serve" "serv")
                    (_ nil))))
          (daselt-abv-set-morph-typings
           layout '(("other" . 1)) lang
           (list '("serve" . root)) nil t)
          ;; The root table is keyed by the abstraction.
          (should (gethash "serv" (oref graph root-table)))
          (should-not (gethash "serve" (oref graph root-table)))
          ;; The lookup through the concrete form resolves.
          (should-not (string-empty-p
                       (abv-typed-layout-morph-typing-string
                        '("serve" . root) layout lang))))
      (fset 'abv-language-abstraction orig-fn))))

(ert-deftest daselt-abv-set-morph-typings-raw-form-fallback ()
  "Morphs without an abstraction are typed under their raw form."
  (let* ((lang (make-instance 'abv-language
                               :name "abstest2"
                               :script (make-instance 'abv-script)
                               :morphs (make-instance 'abv-morph-data)))
         (layout daselt-abv--default-layout)
         (graph (make-instance 'abv-typing-graph :abv-language lang))
         (orig-fn (symbol-function 'abv-language-abstraction)))
    (object-add-to-list layout 'typing-graphs
                         (cons "abstest2" graph))
    (unwind-protect
        (progn
          (fset 'abv-language-abstraction (lambda (&rest _) nil))
          (daselt-abv-set-morph-typings
           layout '(("other" . 1)) lang
           (list '("plor" . root)) nil t)
          (should (gethash "plor" (oref graph root-table)))
          (should-not (string-empty-p
                       (abv-typed-layout-morph-typing-string
                        '("plor" . root) layout lang))))
      (fset 'abv-language-abstraction orig-fn))))

(ert-deftest daselt-abv-set-morph-typings-affix-without-parent-language ()
  "Affix typings work for languages without parent languages.
Regression: the `taken' binding of the affix `and-let*' computed
the parent graphs' tables, which is nil for a base language; the
nil binding made `and-let*' abort, so prefix/suffix/infix morphs
of base languages were silently never typed (\"No typing could be
assigned\" when adding words like \"unrest\")."
  (let* ((lang (make-instance 'abv-language
                               :name "afftest"
                               :script (make-instance 'abv-script)
                               :morphs (make-instance 'abv-morph-data)))
         (layout daselt-abv--default-layout)
         (graph (make-instance 'abv-typing-graph :abv-language lang))
         (orig-fn (symbol-function 'abv-language-abstraction)))
    (object-add-to-list layout 'typing-graphs
                         (cons "afftest" graph))
    (unwind-protect
        (progn
          (fset 'abv-language-abstraction
                (lambda (morph _language)
                  (pcase (car morph)
                    ("un" "un")
                    (_ nil))))
          (daselt-abv-set-morph-typings
           layout '(("other" . 1)) lang
           (list '("un" . prefix)) nil t)
          (should (gethash "un" (oref graph prefix-table)))
          (should-not (string-empty-p
                       (abv-typed-layout-morph-typing-string
                        '("un" . prefix) layout lang))))
      (fset 'abv-language-abstraction orig-fn))))

;;;; Cue promotion includes two-letter words

;;;; Deep reuse before embellishment

(ert-deftest daselt-abv-set-typings-cues-include-two-letter ()
  "The cue phase promotes frequent TWO-letter words alongside
three-letter words, in frequency order."
  (let* ((lang (make-instance 'abv-language
                               :name "cue2"
                               :script (make-instance 'abv-script)
                               :morphs (make-instance 'abv-morph-data
                                                      :roots '("of" "the"))))
         (layout daselt-abv--default-layout)
         (graph (make-instance 'abv-typing-graph :abv-language lang))
         (stats (make-instance 'abv-corpus-language-statistics
                               :language lang
                               :root-frequency nil
                               :root-word-frequency
                               '(("of" . 5000) ("the" . 4000)
                                 ("cat" . 100) ("ofx" . 50)))))
    (object-add-to-list layout 'typing-graphs
                         (cons "cue2" graph))
    (unwind-protect
        (let ((daselt-abv-untyped nil))
          ;; The cue filter tests length and word-p; the system
          ;; dictionary must not decide which words count.
          (cl-letf (((symbol-function 'abv-language-word-p)
                     (lambda (_lang word)
                       (member word '("of" "the" "cat")))))
            (daselt-abv--set-typings-helper layout stats nil graph))
          ;; All three qualify as cue words; two-letter "of" is
          ;; the most frequent and must have been promoted.
          (should (gethash "of" (oref graph cue-table)))
          (should (gethash "the" (oref graph cue-table)))
          (should (gethash "cat" (oref graph cue-table)))
          ;; "ofx" is not a dictionary word of length 2-3.
          (should-not (gethash "ofx" (oref graph cue-table))))
      ;; Clean up the graph registration so other tests on the
      ;; shared default layout are not affected.
      (setf (slot-value layout 'typing-graphs)
            (cl-remove-if (lambda (g) (string= (car g) "cue2"))
                          (slot-value layout 'typing-graphs))))))

;;;; Mnemonic variant tier, base letters, provenance

(ert-deftest daselt-abv-mnemonic-variant-strings-order ()
  "Layer variants of the word's own letter subsequences: plain
subsequences are excluded (the plain tier's business),
single-position variants come before double-position ones, and
every string has the requested length."
  (let ((vs (abv-typed-layout--mnemonic-variant-strings
             daselt-abv--default-layout "her" 2)))
    (should (member "hE" vs))
    (should (member "He" vs))
    (should-not (member "he" vs))
    (should-not (member "hr" vs))
    (should-not (member "er" vs))
    ;; Single-position variants precede double-position ones.
    (should (< (cl-position "hE" vs :test #'string=)
               (cl-position "HE" vs :test #'string=)))
    (should (cl-every (lambda (s) (= 2 (length s))) vs))))

(ert-deftest daselt-abv-mnemonic-variant-strings-single-symbol ()
  "One-symbol variants cover the word's letters across layers
(h -> H/eta/...), the plain letters themselves excluded."
  (let ((vs (abv-typed-layout--mnemonic-variant-strings
             daselt-abv--default-layout "her" 1)))
    (should (member "H" vs))
    (should (member "η" vs))
    (should-not (member "h" vs))
    (should-not (member "e" vs))
    (should-not (member "r" vs))
    (should (cl-every (lambda (s) (= 1 (length s))) vs))))

(ert-deftest daselt-abv-string-base-letters-layers ()
  "Symbols map to their base-layer letters (E -> e, rho -> r)."
  (should (equal (list ?e ?r)
                 (abv-typed-layout--string-base-letters
                  daselt-abv--default-layout "Eρ")))
  (should (equal (list ?o ?t)
                 (abv-typed-layout--string-base-letters
                  daselt-abv--default-layout "O𝕋"))))

(ert-deftest daselt-abv-typing-provenance-classes ()
  "Provenance classification with the real layer machinery."
  (let ((layout daselt-abv--default-layout))
    (should (eq 'plain-mnemonic
                (plist-get (abv-typed-layout--typing-provenance
                            layout "he" "her") :kind)))
    (should (eq 'variant-mnemonic
                (plist-get (abv-typed-layout--typing-provenance
                            layout "hE" "her") :kind)))
    (should (eq 'numbered
                (plist-get (abv-typed-layout--typing-provenance
                            layout "om1" "form") :kind)))
    (should (eq 'fill
                (plist-get (abv-typed-layout--typing-provenance
                            layout "Q" "den") :kind)))
    (should (eq 'deep
                (plist-get (abv-typed-layout--typing-provenance
                            layout "yω" "interaction") :kind)))))

(ert-deftest daselt-abv-erg-best-picks-cheaper-pair ()
  "erg-best prefers the ergonomic rendering among candidates.
\"dr\" is an inward mittig roll; \"dt\" is a same-finger lateral
(same-hand index columns) and must lose under every weighting."
  (require 'daselt-abv-ergonomics)
  (should (equal (abv-typed-layout--erg-best
                  daselt-abv--default-layout '("dt" "dr"))
                 "dr"))
  (should (equal (abv-typed-layout--erg-best
                  daselt-abv--default-layout '("dr" "dt"))
                 "dr"))
  ;; Cross-hand home pair beats the pinky-heavy mnemonic.
  (should (equal (abv-typed-layout--erg-best
                  daselt-abv--default-layout '("hs" "dr"))
                 "dr")))


;;;; Layer families, usage counts, scored affixes, rebalance (A3/B1/B2)

(ert-deftest daselt-abv-layer-family-pairs ()
  "Layer pairs share a family."
  (should (eq (daselt-abv--layer-family 1) 'base))
  (should (eq (daselt-abv--layer-family 2) 'base))
  (should (eq (daselt-abv--layer-family 3) 'four))
  (should (eq (daselt-abv--layer-family 4) 'four))
  (should (eq (daselt-abv--layer-family 5) 'five))
  (should (eq (daselt-abv--layer-family 6) 'five))
  (should (eq (daselt-abv--layer-family 7) 'eight))
  (should (eq (daselt-abv--layer-family 8) 'eight))
  (should (null (daselt-abv--layer-family 0))))

(ert-deftest daselt-abv-usage-counts-sums-table ()
  "Usage counts harvest expansion strings with their counts."
  (let* ((tbl (make-instance 'abv-language-table :name "t"))
         (oa (obarray-make)))
    (set (intern "k1" oa) "word")
    (put (intern "k1" oa) 'count 5)
    (set (intern "k2" oa) "other")
    (put (intern "k2" oa) 'count 2)
    (set (intern "k3" oa) "word")           ; duplicate: counts add
    (put (intern "k3" oa) 'count 1)
    (oset tbl obarray oa)
    (let ((h (daselt-abv--usage-counts tbl)))
      (should (= (gethash "word" h) 6))
      (should (= (gethash "other" h) 2))
      (should (= 2 (hash-table-count h))))))

(ert-deftest daselt-abv-table-words-collects ()
  "Table words collects expansions of length >= 2."
  (let* ((tbl (make-instance 'abv-language-table :name "t"))
         (oa (obarray-make)))
    (set (intern "k1" oa) "word")
    (set (intern "k2" oa) "x")
    (set (intern "k3" oa) 42)
    (oset tbl obarray oa)
    (should (equal (daselt-abv--table-words tbl) '("word")))))

(ert-deftest daselt-abv-assign-one-prefers-letter-matched-twin ()
  "B2: with the letter base occupied, the scored neighbor step
picks the letter-matched layer twin over unmarked neighbors."
  (let* ((layout daselt-abv--default-layout)
         (letter-base (let ((h (make-hash-table :test 'equal)))
                        (puthash "e" (car (rassoc "e"
                                                  (oref (oref layout placevals)
                                                        standard-placevals)))
                                 h)
                        h))
         (preferred (let ((h (make-hash-table :test 'equal)))
                      (dolist (pv (oref (oref layout placevals)
                                        standard-placevals))
                        (puthash (car pv) t h))
                      h))
         (counts (let ((h (make-hash-table :test 'equal)))
                   (puthash (gethash "e" letter-base) 1 h)
                   h))
         (chosen (daselt-abv--assign-one layout "en" preferred counts
                                         letter-base nil)))
    ;; E, the layer-2 twin of the e base, is letter-matched and on
    ;; the home row; it must beat every unmarked candidate.
    (should (equal (list 2 0 -3) chosen))))

(ert-deftest daselt-abv-rebalance-affixes-moves-to-host-family ()
  "B1: an affix whose hosts key on the base family moves there."
  (let* ((layout daselt-abv--default-layout)
         (graph (abv-typing-graph))
         (tbl (make-instance 'abv-language-table :name "t"))
         (oa (obarray-make)))
    ;; Suffix EN on a five-family coordinate; a host entry keyed
    ;; Bϝ (base + five) with usage count.
    (puthash "en" '(5 -1 -3) (oref graph suffix-table))
    (let ((sym (intern "Bϝ" oa)))
      (set sym "been")
      (put sym 'count 5)
      (put sym :morph-sequence '(( "be" . root) ("en" . suffix))))
    (oset tbl obarray oa)
    (let ((moved (daselt-abv--rebalance-affixes layout graph tbl)))
      (should (= moved 1))
      (let ((coord (gethash "en" (oref graph suffix-table))))
        (should (eq (daselt-abv--layer-family (nth 0 coord)) 'base))))))

(ert-deftest daselt-abv-rebalance-affixes-keeps-matching-family ()
  "B1: no move when the affix already sits on the host family."
  (let* ((layout daselt-abv--default-layout)
         (graph (abv-typing-graph))
         (tbl (make-instance 'abv-language-table :name "t"))
         (oa (obarray-make)))
    (puthash "en" '(2 0 -3) (oref graph suffix-table))
    (let ((sym (intern "Bϝ" oa)))
      (set sym "been")
      (put sym 'count 5)
      (put sym :morph-sequence '(("be" . root) ("en" . suffix))))
    (oset tbl obarray oa)
    (should (= 0 (daselt-abv--rebalance-affixes layout graph tbl)))
    (should (equal '(2 0 -3) (gethash "en" (oref graph suffix-table))))))


(provide 'daselt-abv-typing-tests)
;;; daselt-abv-typing-tests.el ends here
