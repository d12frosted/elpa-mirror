;;; daselt-abv-distill-tests.el --- Tests for daselt-abv-distill  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; Author: Alexander Praehauser <ahprae@protonmail.com>
;; Keywords: abbrev

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Tests for `daselt-abv-distill': helper functions like
;; `daselt-abv--one-hot', `daselt-abv--make-search-rings' (both
;; defined in `daselt-abv-typing'), the
;; `abv-typed-layout-embellished-sequence-string' method and
;; `daselt-abv--exit-if-suitable'.

;;; Code:

(require 'ert)
(require 'cl-lib)
(require 'daselt-abv-tests--setup)
(require 'daselt-abv-distill)
(require 'daselt-abv-typing)


;;;; one-hot

(ert-deftest daselt-abv-my-one-hot ()
  "`daselt-abv--one-hot' returns a list of DIM with t at IDX."
  (should (equal '(t nil nil) (daselt-abv--one-hot 3 0)))
  (should (equal '(nil t nil) (daselt-abv--one-hot 3 1)))
  (should (equal '(nil nil t) (daselt-abv--one-hot 3 2)))
  (should (equal '(t) (daselt-abv--one-hot 1 0)))
  ;; Out-of-range IDX -> no `t' (every element is nil).
  (should (equal '(nil nil nil) (daselt-abv--one-hot 3 5))))


;;;; make-search-rings

(ert-deftest daselt-abv-make-search-rings-shape ()
  "`daselt-abv--make-search-rings' returns (nil . rings)."
  (let ((rings (daselt-abv--make-search-rings 2)))
    (should (consp rings))
    (should (null (car rings)))
    (should (consp (cdr rings)))))

(ert-deftest daselt-abv-make-search-rings-len-1 ()
  "For length 1 there is one position to vary."
  (let ((rings (daselt-abv--make-search-rings 1)))
    ;; The first element is nil (the "no embellishment" ring).
    (should (null (car rings)))
    ;; Each subsequent ring has 1 entry with 1 position.
    (dolist (ring (cdr rings))
      (should (= 1 (length ring))))))

(ert-deftest daselt-abv-make-search-rings-default-dim ()
  "Default DIM is 3, so each one-hot vector has length 3."
  (let ((rings (daselt-abv--make-search-rings 2)))
    ;; The non-nil rings consist of dim-3 one-hot vectors.
    (dolist (ring (cdr rings))
      (dolist (entry ring)
        (should (= 3 (length entry)))))))


;;;; exit-if-suitable

(ert-deftest daselt-abv-exit-if-suitable-without-lang-returns-nil ()
  "If the table has no language, the macro returns nil silently."
  ;; The function uses `and-let*' which short-circuits on nil.
  (let ((table (make-instance 'abv-language-table
                              :name "t"
                              :language nil
                              :obarray (obarray-make))))
    ;; We need to call it inside a `catch' frame so any throw is captured.
    (should (null
             (catch 'found-distillate
               (daselt-abv--exit-if-suitable
                nil table daselt-abv--default-layout))))))

(ert-deftest daselt-abv-exit-if-suitable-accepts-name-only ()
  "A distillate consisting solely of a name cell is suitable.
Names are root-like: their name-table key makes the distillate
distinctive even without a root."
  (let* ((lang (make-instance 'abv-language
                              :name "english"
                              :script (make-instance 'abv-script)
                              :morphs (make-instance 'abv-morph-data)))
         (graph (make-instance 'abv-typing-graph))
         (layout (make-instance 'daselt-abv-layout
                                :typing-graphs
                                (list (cons "english" graph))))
         (table (make-instance 'abv-language-table
                               :name "t"
                               :language lang
                               :obarray (obarray-make)))
         (nt (make-instance 'abv-name-table
                            :obarray (obarray-make) :name "test-names"))
         (collection (make-instance 'abv-collection
                                    :global-name-table nt
                                    :tables (list table))))
    (when (slot-exists-p table 'hidden-obarray)
      (oset table hidden-obarray (obarray-make)))
    (set (intern "Eu" (oref nt obarray)) "Euler")
    (abv-table-set-reversion-cache nt)
    (let ((abv-collection-current collection))
      (should (equal
               (catch 'found-distillate
                 (daselt-abv--exit-if-suitable
                  (list (cons '("Euler" . name) 0)) table layout))
               (list (cons '("Euler" . name) 0)))))))


;;;; abv-distill method dispatch

(ert-deftest daselt-abv-distill-method-defined ()
  "The `abv-distill' generic is defined and dispatched for daselt-abv-layout.

We don't run distillation to completion here; it requires a fully
populated language-table and graph.  Instead we verify that the method
exists (the symbol is fboundp) and that calling it dispatches past the
generic to the Daselt method (which prints a progress message before
the table is populated enough to proceed)."
  (should (fboundp 'abv-distill))
  (let* ((lang (make-instance 'abv-language
                              :name "test"
                              :script (make-instance 'abv-script)
                              :morphs (make-instance 'abv-morph-data)))
         (tbl (make-instance 'abv-language-table
                             :name "t"
                             :language lang
                             :obarray (obarray-make))))
    (when (slot-exists-p tbl 'hidden-obarray)
      (oset tbl hidden-obarray (obarray-make)))
    ;; Capture messages; the Daselt method prints a "Starting Daselt
    ;; distillation..." line before failing on the empty table.
    (let ((msgs (with-temp-buffer
                  (cl-letf (((symbol-function 'message)
                             (lambda (fmt &rest args)
                               (insert (apply #'format fmt args) "\n"))))
                    (condition-case _err
                        (abv-distill tbl daselt-abv--default-layout
                                     :re-distill t :sync t)
                      (error nil)))
                  (buffer-string))))
      (should (string-match-p "Starting Daselt distillation" msgs)))))


;;;; abv-typed-layout-embellished-sequence-string

(ert-deftest daselt-abv-embellished-sequence-string-fallback ()
  "The embellished-sequence-string generic is fboundp and dispatches."
  (should (fboundp 'abv-typed-layout-embellished-sequence-string)))

(defun daselt-abv-distill-tests--emb-table (deep &optional root)
  "Return (TABLE LAYOUT) for embellisher tests.
LAYOUT is a fresh `daselt-abv-layout' with the default layout's
placevals; its graph's root-table maps the root ROOT (default
\"test\") to DEEP (a list of coordinates).  TABLE is a language
table over that layout."
  (let* ((lang (make-instance 'abv-language
                              :name "embtest"
                              :script (make-instance 'abv-script)
                              :morphs (make-instance 'abv-morph-data)))
         (graph (make-instance 'abv-typing-graph))
         (layout (make-instance
                  'daselt-abv-layout
                  :root-placevals
                  (oref (oref daselt-abv--default-layout placevals) root-placevals)
                  :typing-graphs (list (cons "embtest" graph))))
         (table (make-instance 'abv-language-table
                               :name "embtest-table"
                               :language lang
                               :obarray (obarray-make))))
    (puthash (or root "test") deep (oref graph root-table))
    (list table layout)))

(ert-deftest daselt-abv-variant-strings-include-layers ()
  "Letter variants include the same-position symbols of higher
layers: \"hl\" varies l to its case partner L and the Greek
lookalikes λ/Λ, rightmost position first, before anything else."
  (let ((layout daselt-abv--default-layout))
    (let ((vs (abv-typed-layout--variant-strings layout "hl")))
      (should (member "hL" vs))
      (should (member "hλ" vs))
      (should (member "hΛ" vs))
      ;; Rightmost flip leads.
      (should (equal "hL" (car vs))))))

(ert-deftest daselt-abv-variant-strings-order ()
  "Every variant keeps the base length and differs in exactly one
position; positions run right to left."
  (let ((layout daselt-abv--default-layout))
    (dolist (v (abv-typed-layout--variant-strings layout "hl"))
      (should (= 2 (length v)))
      (should (cl-position-if
               (lambda (i) (/= (aref v i) (aref "hl" i)))
               (number-sequence 0 1))))))

(ert-deftest daselt-abv-embellished-case-variant-first ()
  "A free shift-layer case variant beats other ring variants.
The base \"tt\" (deep of the root \"test\") is taken; \"tT\" is the
rightmost-flip case variant and must win over ergonomically cheaper
non-case variants like \"dt\".  This is also the regression test for
the ergonomic-cost crash (wrong-type-argument listp) that silently
diverted every embellished key into the numbered fallback."
  (pcase-let ((`(,table ,layout)
               (daselt-abv-distill-tests--emb-table
                '((1 0 2) (1 0 2)))))   ; t t
    (should (equal "tT"
                   (abv-typed-layout-embellished-sequence-string
                    '(("test" . root)) layout table
                    :taken-strings '("tt"))))))

(ert-deftest daselt-abv-embellished-case-variant-then-other-flip ()
  "With the rightmost case flip also taken, the left flip follows."
  (pcase-let ((`(,table ,layout)
               (daselt-abv-distill-tests--emb-table
                '((1 0 2) (1 0 2)))))
    (should (equal "Tt"
                   (abv-typed-layout-embellished-sequence-string
                    '(("test" . root)) layout table
                    :taken-strings '("tt" "tT"))))))

(ert-deftest daselt-abv-embellished-exhausted-cases-then-fresh-2symbol ()
  "Once the case variants are used up, a FRESH 2-symbol
combination of the root's own letters wins: \"te\" for the root
\"test\" whose base \"tt\" collided."
  (pcase-let ((`(,table ,layout)
               (daselt-abv-distill-tests--emb-table
                '((1 0 2) (1 0 2)))))
    (should (equal "te"
                   (abv-typed-layout-embellished-sequence-string
                    '(("test" . root)) layout table
                    :taken-strings '("tt" "tT" "Tt"))))))

(ert-deftest daselt-abv-fresh-2symbol-letter-pairs-first ()
  "Phase A of the fresh 2-symbol search prefers the most
prefix-like free letter pair of the root's own spelling."
  (let* ((layout daselt-abv--default-layout)
         (taken (let ((ht (make-hash-table :test 'equal)))
                  (dolist (s '("tt" "te" "ts" "tT" "Tt" "et" "st"))
                    (puthash s t ht))
                  ht))
         (taken-p (lambda (s) (gethash s taken))))
    ;; All in-order pairs of "test" except "es" are taken.
    (should (equal "es"
                   (daselt-abv--fresh-2symbol-candidate
                    "test" layout taken-p "tt")))))

(ert-deftest daselt-abv-fresh-2symbol-whole-space-fallback ()
  "When every letter pair of the root is taken, phase B scans the
whole 2-symbol space in ergonomic order and returns the cheapest
free pair (a 2-char non-root-letter string, never the base)."
  (let* ((layout daselt-abv--default-layout)
         (letter-pairs
          (delq nil
                (mapcar (lambda (combo)
                          (mapconcat (lambda (elt) (cddr elt)) combo))
                        (daselt-abv--string-combinations "test" 2 2))))
         (taken (let ((ht (make-hash-table :test 'equal)))
                  (dolist (s (cons "tt" letter-pairs))
                    (puthash s t ht))
                  ht))
         (taken-p (lambda (s) (gethash s taken)))
         (res (daselt-abv--fresh-2symbol-candidate
               "test" layout taken-p "tt")))
    (should (and (stringp res) (= 2 (length res))))
    (should-not (member res letter-pairs))
    ;; Free for the taken predicate and not the base.
    (should-not (funcall taken-p res))
    (should-not (string= res "tt"))))

(ert-deftest daselt-abv-embellished-mnemonic-3symbol-fallback ()
  "Deep-collision losers truncate to a richer mnemonic only as the
LAST resort: the root \"form\" with a colliding deep \"om\" first
exhausts the case variants, the fresh 2-symbol letter pairs AND
the whole free 2-symbol space (every 2-char string over the
root placevals is taken here); only then a 3-symbol combination
of its own letters wins (\"for\" ahead of \"fom\")."
  (pcase-let ((`(,table ,layout)
               (daselt-abv-distill-tests--emb-table
                '((1 0 -1) (1 1 2)) "form")))   ; o m
    ;; Everything 2 chars long is taken.
    (let* ((rps (oref (oref layout placevals) root-placevals))
           (taken (make-hash-table :test 'equal)))
      (dolist (a rps)
        (dolist (b rps)
          (puthash (concat (cdr a) (cdr b)) t taken)))
      (should (equal "for"
                     (abv-typed-layout-embellished-sequence-string
                      '(("form" . root)) layout table
                      :taken-strings taken)))
      (puthash "for" t taken)
      (should (equal "fom"
                     (abv-typed-layout-embellished-sequence-string
                      '(("form" . root)) layout table
                      :taken-strings taken))))))

(ert-deftest daselt-abv-embellished-mnemonic-only-single-root ()
  "Multi-morph sequences skip the 3-symbol mnemonic fallback."
  (pcase-let ((`(,table ,layout)
               (daselt-abv-distill-tests--emb-table
                '((1 0 -1) (1 1 2)))))
    ;; No case variant of "om" is free and no single root exists:
    ;; the result must NOT be a 3-letter mnemonic of "form".
    (let ((res (abv-typed-layout-embellished-sequence-string
                '(("form" . root) ("er" . suffix)) layout table
                :taken-strings '("om" "oM" "Om"))))
      (should-not (member res '("for" "fom" "frm" "orm"))))))

(ert-deftest daselt-abv-case-variant-p ()
  "`daselt-abv--case-variant-p' recognizes pure case differences."
  (should (daselt-abv--case-variant-p "tT" "tt"))
  (should (daselt-abv--case-variant-p "Tt" "tt"))
  (should (daselt-abv--case-variant-p "Jc" "jC"))
  (should-not (daselt-abv--case-variant-p "tt" "tt"))
  (should-not (daselt-abv--case-variant-p "dt" "tt"))
  (should-not (daselt-abv--case-variant-p "t" "tt"))
  (should-not (daselt-abv--case-variant-p "τt" "tt")))


;;;; Same-word distillate-collision guard

;;;; Sublingual parent-coverage filtering in `abv-distill'

(defun daselt-abv-distill-tests--sub-table (parent-expansions distillates)
  "Return a sublingual table over a parent with PARENT-EXPANSIONS.
PARENT-EXPANSIONS is a list of strings bound in the parent's
obarray; DISTILLATES is a list of (SEQ . POSITIONS) entries put
into the parent's distillate hash.  Return the sublingual table."
  (let* ((lang (make-instance 'abv-language
                              :name "test-english"
                              :script (make-instance 'abv-script)
                              :morphs (make-instance 'abv-morph-data)))
         (parent (make-instance 'abv-language-table
                                :name "english-table"
                                :language lang
                                :obarray (obarray-make))))
    (when (slot-exists-p parent 'hidden-obarray)
      (oset parent hidden-obarray (obarray-make)))
    (dolist (exp parent-expansions)
      (set (intern "k" (oref parent obarray)) exp))
    (pcase-dolist (`(,seq . ,positions) distillates)
      (puthash seq positions (oref parent distillate)))
    (let ((sub (make-instance 'abv-sublingual-table
                              :name "math-table"
                              :parent-language-table parent
                              :obarray (obarray-make))))
      (when (slot-exists-p sub 'hidden-obarray)
        (oset sub hidden-obarray (obarray-make)))
      sub)))

(ert-deftest daselt-abv-distill-keeps-covered-word-without-distillate ()
  "A parent-covered sequence without a parent distillate is distilled.
Multi-word composition needs the component's distillate registered in
the sublingual table (the parent word may exist there without ever
having been distilled).  Such sequences must reach the Daselt
distiller; only sequences whose distillate the parent actually
supplies are dropped by the parent-coverage filter."
  (let* ((sub (daselt-abv-distill-tests--sub-table '("finiteness") nil))
         (rseq (make-abv-rich-morph-sequence
                :morph-sequence `((fini . root) ("[ie]?t[e]?" . suffix)
                                  ("[n]?ess" . suffix))
                :abstraction `((fini . root) ("[ie]?t[e]?" . suffix)
                               ("[n]?ess" . suffix))
                :composite-string "finiteness"))
         (seen nil))
    (cl-letf (((symbol-function 'daselt-abv--distill-helper)
               (lambda (_table _layout &rest keys)
                 (let ((rseqs (plist-get keys :rseqs)))
                   (setq seen (mapcar #'abv-rich-morph-sequence-composite-string
                                      rseqs)))
                 'done)))
      (abv-distill sub daselt-abv--default-layout
                   :sync t :rseqs (list rseq))
      (should (equal seen '("finiteness"))))))

(ert-deftest daselt-abv-distill-drops-covered-word-with-distillate ()
  "A parent-covered sequence with a parent distillate is not distilled.
The parent abbreviation stays authoritative: the sequence is dropped
and the parent's distillate is returned instead of running the
Daselt distiller."
  (let* ((seq `((fini . root) ("[ie]?t[e]?" . suffix) ("[n]?ess" . suffix)))
         (sub (daselt-abv-distill-tests--sub-table
               '("finiteness" "finiteness")
               (list (cons seq '(0 1 2)))))
         (rseq (make-abv-rich-morph-sequence
                :morph-sequence seq
                :abstraction seq
                :composite-string "finiteness"))
         (seen nil))
    (cl-letf (((symbol-function 'daselt-abv--distill-helper)
               (lambda (_table _layout &rest keys)
                 (let ((rseqs (plist-get keys :rseqs)))
                   (setq seen (mapcar #'abv-rich-morph-sequence-composite-string
                                      rseqs)))
                 'done)))
      (let ((result (abv-distill sub daselt-abv--default-layout
                                 :sync t :rseqs (list rseq))))
        ;; The Daselt distiller never runs for the dropped sequence.
        (should (null seen))
        (should (equal result seq))))))

(ert-deftest daselt-abv-same-word-variant-p ()
  "Hyphenated and un-separated spellings of one compound match.
This is the predicate guarding both
`daselt-abv--handle-distillate-collision' call sites: a reverse
distillate-cache hit only prompts when it belongs to a different
word."
  (let ((hyphenated '((("su[bcfgprs]") . prefix) ("-" . morph-separator)
                      (("sheaf") . root)))
        (glued '((("su[bcfgprs]") . prefix) (("sheaf") . root))))
    (should (daselt-abv--same-word-variant-p hyphenated glued))
    (should (daselt-abv--same-word-variant-p glued hyphenated))
    (should (daselt-abv--same-word-variant-p glued glued))
    ;; A different word never matches, separators or not.
    (should-not (daselt-abv--same-word-variant-p
                 glued '((("su[bcfgprs]") . prefix) (("sheafify") . root))))
    ;; Word separators are NOT dropped: another word is another word.
    (should-not (daselt-abv--same-word-variant-p
                 glued '((("su[bcfgprs]") . prefix) (("sheaf") . root)
                         (" " . formal) (("case") . root))))))


(ert-deftest daselt-abv-unique-typing-variant-tier-beats-deep ()
  "When all plain letter subsequences of a word are taken, LAYER
VARIANTS of its own letters win before deep truncations: her with
he/hr/er taken types as a letter variant (hE-class), not as the
deep spelling."
  (pcase-let ((`(,table ,layout)
               (daselt-abv-distill-tests--emb-table
                '((1 0 -1) (1 1 2)) "her")))
    (oset (oref layout placevals) single-symbol-placevals
          (oref (oref daselt-abv--default-layout placevals) single-symbol-placevals))
    (let ((taken (make-hash-table :test 'equal)))
      (dolist (s '("he" "hr" "er")) (puthash s t taken))
      (let ((res (abv-typed-layout--unique-typing
                  layout table '(("her" . root))
                  :taken-strings taken :min-length 2)))
        (should (and res (= 2 (length res))))
        (should (member res (abv-typed-layout--mnemonic-variant-strings
                             layout "her" 2)))))))

(ert-deftest daselt-abv-fill-single-symbol-keys-family-first ()
  "Free one-symbol keys go to short words in frequency order,
letter-family keys (the plain letter or a layer variant) before
arbitrary free symbols."
  (pcase-let ((`(,table ,layout)
               (daselt-abv-distill-tests--emb-table
                '((1 0 -1) (1 1 2)) "her")))
    (oset (oref layout placevals) single-symbol-placevals
          (oref (oref daselt-abv--default-layout placevals) single-symbol-placevals))
    (let* ((graph (cdr (car (oref layout typing-graphs))))
           (mseq (oref graph morph-sequence-table))
           (oa (oref table obarray))
           (lang (oref table language)))
      ;; Ensure the language caches exist, then make the abstraction
      ;; of (("her" . root)) be itself.
      (abv-language-sequence-abstraction '(("her" . root)) lang :silent t)
      (puthash '(("her" . root)) '(("her" . root))
               (oref (oref lang caches) abstract-sequence-cache))
      ;; "her" sits on a 2-symbol key; its plain letter h is taken
      ;; by a fake entry, so the family fill must pick h's layer
      ;; variant H rather than an arbitrary free symbol.
      (puthash '(("her" . root)) "Eρ" mseq)
      (puthash '(("fake" . root)) "h" mseq)
      (let ((sym (intern "Eρ" oa)))
        (set sym "her")
        (put sym :morph-sequence '(("her" . root))))
      (let ((assigned (abv-language-table-fill-single-symbol-keys
                       table layout :ignore-own-obarray t)))
        (should (= 1 assigned))
        (should (equal "H" (gethash '(("her" . root)) mseq)))))))

(ert-deftest daselt-abv-fill-single-symbol-keys-arbitrary-fallback ()
  "When no family key is free, an arbitrary free single-symbol key
serves the remainder."
  (pcase-let ((`(,table ,layout)
               (daselt-abv-distill-tests--emb-table
                '((1 0 -1) (1 1 2)) "her")))
    (oset (oref layout placevals) single-symbol-placevals
          (oref (oref daselt-abv--default-layout placevals) single-symbol-placevals))
    (let* ((graph (cdr (car (oref layout typing-graphs))))
           (mseq (oref graph morph-sequence-table))
           (oa (oref table obarray))
           (lang (oref table language))
           (family (append
                    (abv-typed-layout--mnemonic-strings
                     layout "her" 1)
                    (abv-typed-layout--mnemonic-variant-strings
                     layout "her" 1)))
           (free (cl-find-if
                  (lambda (s) (not (member s family)))
                  (abv-typed-layout--single-symbol-strings layout))))
      (abv-language-sequence-abstraction '(("her" . root)) lang :silent t)
      (puthash '(("her" . root)) '(("her" . root))
               (oref (oref lang caches) abstract-sequence-cache))
      ;; "her" on a 2-symbol key; the whole h family is taken by
      ;; fake entries, so the expected assignment is FREE, the
      ;; first non-family single symbol.
      (puthash '(("her" . root)) "Eρ" mseq)
      (let ((n 0))
        (dolist (s family)
          (setq n (1+ n))
          (puthash `((,(concat "fake" (number-to-string n)) . root))
                   s mseq)))
      (let ((sym (intern "Eρ" oa)))
        (set sym "her")
        (put sym :morph-sequence '(("her" . root))))
      (let ((assigned (abv-language-table-fill-single-symbol-keys
                       table layout :ignore-own-obarray t)))
        (should (= 1 assigned))
        (should (equal free (gethash '(("her" . root)) mseq)))))))

(provide 'daselt-abv-distill-tests)
;;; daselt-abv-distill-tests.el ends here
