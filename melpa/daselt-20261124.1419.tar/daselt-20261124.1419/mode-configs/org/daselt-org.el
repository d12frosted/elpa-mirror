;;; daselt-org.el -- daselt-commands for org  -*- lexical-binding: t; -*-

;; Copyright (C) 2024, 2025  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Package-Requires: ((emacs "29.1"))
;; Version: 1.0
;; Keywords: tools
;; URL: https://gitlab.com/nameiwillforget/d-emacs/daselt-mode/

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;;

;;; Code:

(declare-function daselt-backward-up-list "daselt-ext")
(declare-function org-todo "org")
(declare-function org-insert-heading "org")
(declare-function org-insert-todo-heading "org")
(declare-function org-insert-heading-after-current "org")
(declare-function sp-backward-up-sexp "smartparens")

;;;; Preamble
(defun daselt-org-insert-superheading (&optional number)
  "Insert a heading one or several levels above the previous one.

By default, go one level up. If a prefix number is given, that number of levels
are gone up."
  (interactive "p")
  (org-insert-heading)
  (left-char)
  (if number
      (delete-char (- number))
    (delete-char -1))
  (right-char))

(defun daselt-org-insert-todo-superheading (&optional number)
  "Insert a todo heading one or several levels above the previous one.

By default, go one level up. If a prefix number is given, that number of levels
are gone up."
  (interactive "p")
  (call-interactively #'org-insert-todo-heading)
  (left-word)
  (left-char)
  (if number
      (delete-char (- number))
    (delete-char -1))
  (right-word)
  (insert " "))

(defun daselt-org-insert-todo-heading-after-current ()
  "Insert a todo heading one level above the previous one."
  (interactive)
  (org-insert-heading-after-current)
  (org-todo))

(defun daselt-org-convert-quote ()
  "Convert the quote at or surrounding point to an Org block quote."
  (interactive)
  (cl-flet ((format-quote ()
              (mark-sexp)
              (let* ((quote (buffer-substring (1+ (region-beginning))
                                              (1- (region-end))))
                     (finquote (concat "#+begin_quote\n"
                                       quote
                                       "\n#+end_quote")))
                (daselt-base-replace-region finquote))))
    (save-excursion
      ;; Go up lists as long as possible or until a quote is found.
      (let ((endloop)
            (backward-up-fun ; Use `sp-backward-up-sexp' if possible.
             (if (package-installed-p 'smartparens)
                 #'sp-backward-up-sexp
               (lambda () (daselt-backward-up-list 1)))))
        (while (not endloop)
          (if (= (char-after) ?\")
              (progn (format-quote)
                     (setq endloop t))
            (condition-case msg (funcall backward-up-fun)
              (error (progn (setq endloop t)
                            (message msg))))))))))

(defun daselt-org-remove-page-heading (heading)
  "Remove page HEADING of imported documents.

Might need to be adapted to your imported document."
  (interactive "sHeading: ")
  (save-excursion
    (while (re-search-forward (concat heading (rx (or blank "\n")
                                                  (*? anychar)
                                                  word-end))
                              nil t)
      (delete-region (match-beginning 0)
                     (match-end 0))
      (delete-all-space)
      (insert " "))))

(provide 'daselt-org)
;;; daselt-org.el ends here
