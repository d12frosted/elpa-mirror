;;; daselt-auctex.el --- Daselt-code for AucTeX    -*- lexical-binding: t; -*-

;; Copyright (C) 2025  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Keywords: tools, tex

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;;

;;; Code:

;;;; Preamble
(declare-function texmathp "texmathp")
(declare-function daselt--exchange-read-args "daselt-ext")
(declare-function daselt-exchange "daselt-ext")
(declare-function daselt-query-exchange "daselt-ext")

;;;; Functions
;;;;; General
(defun check-math-mode (beg _end)
  "Check whether the region between BEG and point is in math-mode."
  (save-excursion (save-match-data (goto-char beg) (texmathp))))

;;;;; Insertion
(defun daselt-latex-insert-normpair-yas-snippet (&optional ARG)
  "This command inserts a correctly spaced norm pair yas-snippet.

If the region is active and usable, it inserts the norm pair around the region.
It is bound to ∣ in LaTeX-mode, because their spacing otherwise is awful.

Without a prefix argument, it inserts a snippet like
\\mathopen{∣}-\\mathclose{∣}.

With a universal prefix argument C-u it just inserts a normal norm sign.

With -2 as a prefix, it inserts a snippet like
\\mathopen{\\mathsmaller{\\mathsmaller{∣}}}${1:-}\\mathclose{\\mathsmaller{\\mathsmaller{∣}}}.

With -1 as a prefix, it inserts a snippet like
\\mathopen{\\mathsmaller{∣}}${1:-}\\mathclose{\\mathsmaller{∣}}.

With 0 as a prefix, it inserts a snippet like \\left\\vert${1:-}\\right\\vert.

With 2 as a prefix, it inserts \\big\\vert${1:-}\\big\\vert.

With 3 as a prefix, it inserts \\bigg\\vert${1:-}\\bigg\\vert."
  (interactive "p")
  (let ((snippet (cond ((= ARG -2) "\\mathsmaller{\\mathsmaller{\\mathopen{∣}}}${1:-}\\mathsmaller{\\mathsmaller{\\mathclose{∣}}}")
                       ((= ARG -1) "\\mathsmaller{\\mathopen{∣}}${1:-}\\mathsmaller{\\mathclose{∣}}")
                       ((= ARG 0)
                        "\\left\\vert${1:-}\\right\\vert")
                       ((= ARG 2)
                        "\\big\\vert${1:-}\\big\\vert")
                       ((= ARG 3)
                        "\\bigg\\vert${1:-}\\bigg\\vert")
                       (t "\\mathopen{∣}${1:-}\\mathclose{∣}"))))
    (cond ((derived-mode-p 'vterm-mode)
           (vterm--self-insert))
          ((eq ARG 4)
           (self-insert-command 1))
           ((use-region-p)
            (call-interactively #'kill-region)
            (yas-expand-snippet snippet)
            (yank))
           (t (yas-expand-snippet snippet)))))

(defun daselt-latex-insert-othernormpair-yas-snippet (&optional ARG)
  "This command inserts a correctly spaced ∥-norm pair yas-snippet.

If the region is active and usable, it inserts the norm pair around the region.
It is bound to ∥ in LaTeX-mode, because their spacing otherwise is awful.

Without a prefix argument, it inserts a snippet like
\\mathopen{∥}-\\mathclose{∥}.

With a universal prefix argument C-u it just inserts a normal norm sign.

With -2 as a prefix, it inserts a snippet like
\\mathopen{\\mathsmaller{\\mathsmaller{∥}}}${1:-}\\mathclose{\\mathsmaller{\\mathsmaller{∥}}}.

With -1 as a prefix, it inserts a snippet like
\\mathopen{\\mathsmaller{∥}}${1:-}\\mathclose{\\mathsmaller{∥}}.

With 0 as a prefix, it inserts a snippet like \\left\\|${1:-}\\right\\|.

With 2 as a prefix, it inserts \\big\\|${1:-}\\big\\|.

With 3 as a prefix, it inserts \\bigg\\|${1:-}\\bigg\\|."
  (interactive "p")
  (let ((snippet (cond ((= ARG -2)
                        "\\mathopen{\\mathsmaller{\\mathsmaller{∥}}}${1:-}\\mathclose{\\mathsmaller{\\mathsmaller{∥}}}")
                       ((= ARG -1)
                        "\\mathopen{\\mathsmaller{∥}}${1:-}\\mathclose{\\mathsmaller{∥}}")
                       ((= ARG 0)
                        "\\left\\|${1:-}\\right\\|")
                       ((= ARG 2)
                        "\\big\\|${1:-}\\big\\|")
                       ((= ARG 3)
                        "\\bigg\\|${1:-}\\bigg\\|")
                       (t "\\mathopen{∥}${1:-}\\mathclose{∥}"))))
    (cond ((derived-mode-p 'vterm-mode)
           (vterm--self-insert))
          ((eq ARG 4)
           (self-insert-command 1))
           ((use-region-p)
            (call-interactively #'kill-region)
            (yas-expand-snippet snippet)
            (yank))
           (t (yas-expand-snippet snippet)))))


;;;;; Navigation
(defun daselt-latex-forward-down-environment (&optional N)
  "Move into the N-th next environment.

If there is no environment within the current environment, move to the beginning
of the current environment. Skip the label if one exists.

Requires latex-extra."
  (declare (ftype (function (&optional integer) t)))
  (interactive "p")
  (let ((N (or N 1)))
    (latex/forward-environment N)
    (latex/backward-environment 1)
    (forward-line)
    (when (looking-at-p "[[:space:]]*\\\\label{")
      (forward-line))
    (when (looking-at "[[:space:]]*")
      (goto-char (match-end 0)))))

(defun daselt-latex-backward-down-environment (&optional N)
  "Move into the N-th previous environment.

If there is no previous environment within the current environment, move to the
end of the current environment.

Requires latex-extra."
  (declare (ftype (function (&optional integer) t)))
  (interactive "p")
  (let ((N (or N 1)))
    (latex/backward-environment N)
    (latex/forward-environment 1)
    (forward-line -2)
    (end-of-line)))


;;;;;; Section navigation
(defun daselt-latex--section-same-level-p (h1 h2)
  "Return non-nil if section headers H1 and H2 are at the same level.

Requires `latex-extra'."
  (and h1 h2
       (latex/section<= h1 h2)
       (latex/section<= h2 h1)))

(defun daselt-latex--current-section-header ()
  "Return the section header at point, or the closest preceding one.

Return nil if there is no section at or before point.

Requires `latex-extra'."
  (save-excursion
    (goto-char (line-beginning-position))
    (or (latex//header-at-point)
        (progn (latex//impl-previous-section)
               (latex//header-at-point)))))

(defun daselt-latex--parent-section-bounds (header)
  "Return the bounds of the section containing the section with HEADER.

The return value is a cons (START . END), where START is the position of the
containing (higher-level) section's header and END is the start of the next
section at that level or higher (or `point-max'). Return nil if HEADER has no
containing section.

Requires `latex-extra'."
  (save-excursion
    (goto-char (line-beginning-position))
    (unless (latex//header-at-point)
      (latex//impl-previous-section))
    (when (looking-at "\\\\") (forward-char 1))
    (let (parent-start parent-header)
      (while (and (not parent-start)
                  (re-search-backward (latex/section-regexp) nil :noerror))
        (let ((h (latex//header-at-point)))
          (when (latex/section< header h)
            (setq parent-start (point)
                  parent-header h))))
      (when parent-start
        (goto-char parent-start)
        (forward-char 1)
        (let (parent-end)
          (while (and (not parent-end)
                      (re-search-forward (latex/section-regexp) nil :noerror))
            (let ((mb (match-beginning 0))
                  (h (latex//header-at-point)))
              (when (latex/section<= parent-header h)
                (setq parent-end mb))))
          (cons parent-start (or parent-end (point-max))))))))

(defun daselt-latex--find-sibling-section (header from bound direction)
  "Find the next section at HEADER's level, searching from FROM in DIRECTION.

DIRECTION is 1 (forward) or -1 (backward); the search is bounded by BOUND.
Return the position of the matched header, or nil.

Requires `latex-extra'."
  (save-excursion
    (goto-char from)
    (catch 'found
      (while (if (> direction 0)
                 (re-search-forward (latex/section-regexp) bound :noerror)
               (re-search-backward (latex/section-regexp) bound :noerror))
        (let ((mb (match-beginning 0))
              (h (latex//header-at-point)))
          (when (daselt-latex--section-same-level-p header h)
            (throw 'found mb)))))))

(defun daselt-latex--move-section-same-level (n)
  "Move N sections at the same level, wrapping within the parent section.

N>0 moves forward, N<0 moves backward. When the movement would leave the
containing higher-level section, wrap to the other end of the same-level
sections in that section instead of ascending.

Requires `latex-extra'."
  (let* ((header (daselt-latex--current-section-header))
         (bounds (when header
                   (daselt-latex--parent-section-bounds header))))
    (if (or (null header) (null bounds))
        (latex/next-section-same-level n)
      (let ((start (point))
            (parent-start (car bounds))
            (parent-end (cdr bounds)))
        (latex/next-section-same-level n)
        (let ((new-pos (point)))
          (when (or (= new-pos start)
                    (and (> n 0) (>= new-pos parent-end))
                    (and (< n 0) (<= new-pos parent-start)))
            (let ((target (if (> n 0)
                              (daselt-latex--find-sibling-section
                               header parent-start parent-end 1)
                            (daselt-latex--find-sibling-section
                             header (1- parent-end) parent-start -1))))
              (when target (goto-char target)))))))))

(defun daselt-latex-next-section-same-level (&optional n)
  "Move forward to the next section at the same level, wrapping within parent.

With prefix argument N, move N sections. If point is at the last section of its
level within the containing higher-level section, wrap to the first one instead
of ascending to the next higher-level section.

Requires `latex-extra'."
  (declare (ftype (function (&optional integer) t)))
  (interactive "p")
  (let ((n (or n 1)))
    (when (and (called-interactively-p 'interactive)
               (not (region-active-p)))
      (push-mark))
    (daselt-latex--move-section-same-level n)))

(defun daselt-latex-previous-section-same-level (&optional n)
  "Move backward to the previous same-level section, wrapping within parent.

With prefix argument N, move N sections. If point is at the first section of its
level within the containing higher-level section, wrap to the last one instead
of ascending to the containing section.

Requires `latex-extra'."
  (declare (ftype (function (&optional integer) t)))
  (interactive "p")
  (let ((n (or n 1)))
    (when (and (called-interactively-p 'interactive)
               (not (region-active-p)))
      (push-mark))
    (daselt-latex--move-section-same-level (- n))))


;;;;; Folding
(defun daselt-latex-fold-all-environments ()
  "Fold all LaTeX environments in buffer.

Requires latex-extra."
  (declare (ftype (function nil t)))
  (interactive)
  (save-excursion
    (daselt-base-goto-min)
    (if (search-forward "\\begin{document}" nil t)
        (progn (beginning-of-line)
               (daselt-latex-forward-down-environment)
               (while (not (string= "document"
                                    (progn (latex/forward-environment 1)
                                           (daselt-latex-backward-down-environment)
                                           (forward-char)
                                           (LaTeX-current-environment))))
                 (TeX-fold-env)
                 (latex/forward-environment 1)))
      (message "No document found."))))

(defun daselt-latex-clear-all-environments ()
  "Clear all LaTeX environments in buffer.

Requires latex-extra."
  (declare (ftype (function nil t)))
  (interactive)
  (save-excursion
    (daselt-base-goto-min)
    (daselt-latex-forward-down-environment)
    (while (not (string= "document"
                         (progn (latex/forward-environment 1)
                                (daselt-latex-backward-down-environment)
                                (forward-char)
                                (LaTeX-current-environment))))
      (LaTeX-mark-environment)
      (TeX-fold-clearout-region (region-beginning)
                                (region-end))
      (latex/forward-environment 1))))


;;;;; Indenting
(defun daselt-latex-indent-environment (&optional count)
  "Indent the LaTeX environment point is currently in.

With COUNT given, indent the COUNT-th nested environment point is in."
  (declare (ftype (function (&optional natnum) t)))
  (interactive "P")
  (let ((count (or count 1)))
    (save-excursion
      (LaTeX-mark-environment count)
      (let ((beg (region-beginning))
            (end (region-end)))
        (indent-region beg end)))))

(defun daselt-latex-indent-section (&optional count)
  "Indent the LaTeX section point is currently in.

With COUNT given, indent the COUNT-th nested section point is in."
  (declare (ftype (function (&optional natnum) t)))
  (interactive "P")
  (let ((count (or count 1)))
    (save-excursion
      (LaTeX-mark-section count)
      (indent-region (region-beginning) (region-end)))))


;;;;; Deletion
(defun daselt-latex-delete-environment ()
  "Delete the \\begin and \\end tags of the current LaTeX environment."
  (interactive)
  (when (LaTeX-current-environment)
    (save-excursion
      (let* ((begin-start (save-excursion
                            (LaTeX-find-matching-begin)
                            (point)))
             (begin-end (save-excursion
                          (goto-char begin-start)
                          (search-forward-regexp "begin{.*?}")))
             (end-end (save-excursion
                        (LaTeX-find-matching-end)
                        (point)))
             (end-start (save-excursion
                          (goto-char end-end)
                          (1- (search-backward-regexp "\\end")))))
        ;; Delete end first since deleting begin first shifts the location of end.
        (delete-region end-start end-end)
        (delete-region begin-start begin-end)))))

(defun daselt-latex-kill-ring-delete-math-delimiters-completing (entry)
  "Delete math delimiters from a kill-ring entry selected with `completing-read`."
  (interactive (list (completing-read "Select kill-ring entry: " kill-ring nil t)))
  (let ((new (replace-regexp-in-string (rx (or "$" "\\(" "\\)" "\\[" "\\]")) "" entry)))
    (kill-new new t)))

(defun daselt-latex-kill-ring-delete-math-delimiters ()
  "Delete math delimiters from the first kill-ring entry."
  (interactive)
  (daselt-latex-kill-ring-delete-math-delimiters-completing (car kill-ring)))


;;;;; Previews
(defun daselt-latex-refresh-region-previews (beg end)
  "Refresh math previews between BEG and END.

Requires `math-preview'."
  (declare (ftype (function (number number) t)))
  (interactive "r")
  (math-preview-clear-region beg end)
  (math-preview-region beg end))

(defun daselt-latex-refresh-environment-previews (&optional count)
  "Refresh math previews in COUNTth environment.

Requires `math-preview'."
  (declare (ftype (function (&optional number) t)))
  (interactive "p")
  (LaTeX-mark-environment count)
  (daselt-latex-refresh-region-previews (region-beginning)
                                        (region-end)))

(defun daselt-latex-refresh-section-previews (&optional no-subsections)
  "Refresh math previews in current section.

Requires `math-preview'."
  (declare (ftype (function (&optional boolean) t)))
  (interactive "P")
  (LaTeX-mark-section no-subsections)
  (daselt-latex-refresh-region-previews (region-beginning)
                                        (region-end)))

(defun daselt-latex-refresh-buffer-previews ()
  "Refresh math previews in the whole buffer.

Requires `math-preview'."
  (declare (ftype (function nil t)))
  (interactive)
  (daselt-latex-refresh-region-previews (point-min) (point-max)))


;; Better done with smartparens.
;; (defun daselt-latex-remove-modifier (env)
;;   "This command removes TeX modifier ENV.

;; Requires cdlatex."
;;   (interactive (completing-read "Environment: "
;;                                 (mapcar #'car LaTeX-environment-list)))
;;   ;; (replace-regexp (format "\\\\%s{\\(.*?\\)}" env) "\\1")
;;   (replace-regexp (rx-to-string `(seq "\\" ,env "{" (group (*? nonl)) "}")) "\\1"))


;;;;; Searching
(defun daselt-latex-isearchp-within-mathmode ()
  "This function does a search restricted to mathmode."
  (interactive)
  (let ((old-pred isearch-filter-predicate))
    (condition-case nil (progn (setq-local isearch-filter-predicate 'check-math-mode)
                               (call-interactively #'isearch-forward))
      (setq-local isearch-filter-predicate old-pred))))

;;;;; Replacing
(daselt-base-def-by-forms
 (`(defun ,(intern (concat "daselt-latex-" mquery "replace-" type "-in-mathmode")) ()
     ,(format "%seplace %s OLD with NEW in LaTeX mathmode regions."
              (if (string-empty-p mquery)
                  "R"
                "Query r")
              type)
     (interactive)
     (let ((isearch-filter-predicate 'check-math-mode))
       (call-interactively (quote ,(intern (concat mquery "replace"
                                                   (unless (and (not (string-empty-p mquery))
                                                                (string= type "string"))
                                                     (concat "-" type)))))))))
 (type . ("string" "regexp"))
 (mquery . (("" "query-") ("" "query-"))))

(defun daselt-latex-exchange-in-mathmode (string1 string2 &optional delimited)
  "Exchange STRING1 with STRING2 in LaTeX mathmode regions.

Works like `daselt-exchange' on the active region or the whole buffer,
but only touches occurrences in math mode.  DELIMITED is as in
`daselt-exchange'."
  (interactive (daselt--exchange-read-args "Exchange in math"))
  (let ((isearch-filter-predicate #'check-math-mode))
    (daselt-exchange string1 string2 delimited)))

(defun daselt-latex-query-exchange-in-mathmode
    (string1 string2 &optional delimited)
  "Query-exchange STRING1 with STRING2 in LaTeX mathmode regions.

Works like `daselt-query-exchange', but only offers occurrences in math
mode.  DELIMITED is as in `daselt-exchange'."
  (interactive (daselt--exchange-read-args "Query exchange in math"))
  (let ((isearch-filter-predicate #'check-math-mode))
    (daselt-query-exchange string1 string2 delimited)))


;;;;; Reftex
(defun daselt-reftex-throw-114 ()
  "Throw 114 to `myexit'."
  (declare (ftype (function () t)))
  (interactive)
  (throw 'myexit 114))

(defun daselt-reftex-throw-82 ()
  "Throw 82 to `myexit'."
  (declare (ftype (function () t)))
  (interactive)
  (throw 'myexit 82))

(defun daselt-reftex-relabel (beg end)
  "Relabel all LaTeX \\label commands in the region from BEG to END using
`reftex-label'.

Searches for `\\label{...}', removes it, and then calls `reftex-label' to insert
a new label."
  (interactive "r")
  ;; Ensure RefTeX is loaded
  (require 'reftex)
  (save-excursion
                                (goto-char beg)
                                (while (re-search-forward "\\\\label{[^}]+}" end t)
      ;; Delete the old \label{...}
      (delete-region (match-beginning 0) (match-end 0))
      ;; Step back a bit so we're still within the environment
      (backward-char 1)
      ;; Insert the new label
      (reftex-label))))

;;;;; Math-preview
(defun daselt-latex-math-preview-refresh-region (beg end)
  "Clear all math preview overlays in the region, then re-render them."
  (interactive "r")
  (math-preview-clear-region beg end)
  (math-preview-region beg end))

;;;; Documentation
(defun daselt-latex-texdoc (&optional arg)
  "Open LaTeX package documentation via texdoc in Emacs.

Prompt for selection of the package of which to show the documentation. Use
texdoc to find candidate manuals, then visit the chosen file in Emacs.

With prefix argument ARG, also list all found manuals in a buffer before
prompting for which one to open."
  (interactive "P")
  (if (not (executable-find "texdoc"))
                                  (message "texdoc not found")
                  (let ((pkg (thing-at-point 'symbol t))
          buffer list doc default-doc)
      (setq pkg (TeX-read-string "View documentation for (in Emacs): " pkg))
      (unless (zerop (length pkg))
        ;; Collect manuals using `texdoc --list --nointeract'.
        (with-current-buffer
                                        (setq buffer (get-buffer-create (format "*texdoc: %s*" pkg)))
                        (erase-buffer)
                        (call-process "texdoc" nil t nil "--list" "--nointeract" pkg)
                        (goto-char (point-min))
                        (while (re-search-forward
                  "^ *\\([0-9]+\\) +\\([-~/a-zA-Z0-9_.${}#%,:\\ ()]+\\)"
                  nil t)
            (push (cons (match-string 1) (match-string 2)) list))
                        (setq list (nreverse list)))

        (cond
         ((null list)
          (message "No documentation found for %s" pkg))

         ;; If there is exactly one match, just open it.
         ((and (not arg) (= (length list) 1))
          (setq default-doc (cdar list))
          (find-file default-doc))

         (t
          ;; Multiple matches or prefix-arg: show buffer and prompt.
          (TeX-pop-to-buffer buffer)
          (let* ((nums (mapcar #'car list))
                 (choice (TeX-read-string
                          (format "Enter number to view in Emacs [%s]: "
                                  (mapconcat #'identity nums ", "))
                          (car nums))))
            (setq doc (cdr (assoc choice list)))
            (if (and doc (file-exists-p doc))
                                            (find-file doc)
                            (message "No valid selection or file does not exist.")))))))))

(provide 'daselt-auctex)
;;; daselt-auctex.el ends here
