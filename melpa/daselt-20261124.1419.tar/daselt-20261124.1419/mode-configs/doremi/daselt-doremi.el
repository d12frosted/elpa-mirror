;;; daselt-doremi.el -- daselt-functions for daselt-doremi  -*- lexical-binding: t; -*-

;; Copyright (C) 2024, 2025  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Package-Requires: ((emacs "29.1"))
;; Version: 1.0
;; Keywords: tools
;; URL: https://gitlab.com/nameiwillforget/d-emacs/daselt-mode/

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; This file contains functions for functions used in doremi. If daselt-doremi
;; is t, it is parsed automatically when daselt-mode is started or doremi is
;; evaluated, depending on what comes first. Each element in this file should be
;; a function or macro definition.

;;; Code:

(defun daselt-doremi--set-key-customs-from-bindlists ()
  "Append to doremi customs their entries in daselt bindlists in this directory
  that contain \"customs\" in their name."
  (daselt-base-recurse-through-directory
   (lambda (filepath) (daselt-base-act-on-sexps-in-file
                       filepath
                       (lambda ()
                         (mapcar (lambda (bind)
                                   (let* ((cust (cdr bind))
                                          (bindstr (daselt-bind-string bind t t))
                                          (bindkbd (kbd bindstr))
                                          (custbup (intern (concat "daselt-" (symbol-name
                                                                              cust)
                                                                   "-backup"))))
                                     (if (eval `(bound-and-true-p ,custbup))
                                         (add-to-list cust bindkbd)
                                       (progn (set custbup cust)
                                              (add-to-list cust bindkbd)))))
                                 (daselt-base-read-region)))))
   (concat daselt-mode-pkg-configs-directory "/doremi/")
   (lambda (filepath) (and (string-match-p (rx ".dbl" string-end) filepath)
                           (string-match-p "customs" (file-name-base filepath))))))

(provide 'daselt-doremi)
;;; daselt-doremi.el ends here
