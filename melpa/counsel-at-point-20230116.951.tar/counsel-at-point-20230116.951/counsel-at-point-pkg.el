(define-package "counsel-at-point" "20230116.951" "Context sensitive project search"
  '((emacs "26.2")
    (counsel "0.13.0"))
  :commit "a84cc0e409325d051208c43dfcabcebaa0d98ba3" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-counsel-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
