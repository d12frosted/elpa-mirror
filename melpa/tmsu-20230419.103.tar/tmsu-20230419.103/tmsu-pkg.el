(define-package "tmsu" "20230419.103" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "024534c8795945bb6d9403747c51c0941f6b57ae" :authors
  '(("Wojciech Siewierski"))
  :maintainers
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
