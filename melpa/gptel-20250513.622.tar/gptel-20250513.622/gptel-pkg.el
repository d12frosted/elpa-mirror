;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250513.622"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "32bbf5ecf744d803ca4b86cb5c9e51ef2a6bc5fa"
  :revdesc "32bbf5ecf744"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
