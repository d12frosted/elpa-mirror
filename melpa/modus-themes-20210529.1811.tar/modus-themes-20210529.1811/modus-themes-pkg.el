(define-package "modus-themes" "20210529.1811" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "79f537cc9b43e5398229a55f46a72082bd6cd9d5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
