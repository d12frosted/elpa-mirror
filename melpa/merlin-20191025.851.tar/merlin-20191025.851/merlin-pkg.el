(define-package "merlin" "20191025.851" "Mode for Merlin, an assistant for OCaml." 'nil :commit "d0278ca384943373abb28ec15999d4d91b527fe9" :keywords
  ("ocaml" "languages")
  :authors
  (("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  ("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
