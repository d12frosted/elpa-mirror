(define-package "merlin" "20191025.851" "Mode for Merlin, an assistant for OCaml." 'nil :commit "5125e54a7aa033d444514c3af1122076845d57b6" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
