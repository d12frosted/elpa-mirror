(define-package "merlin" "20191025.851" "Mode for Merlin, an assistant for OCaml." 'nil :commit "89c23b36692d4b2599523be3ccce24d2efb24b6f" :keywords
  ("ocaml" "languages")
  :authors
  (("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  ("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
