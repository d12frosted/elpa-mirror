(define-package "demo-it" "20211221.2152" "Create demonstrations" 'nil :commit "e399fd7ceb73caeae7cb50b247359bafcaee2a3f" :authors
  '(("Howard Abrams" . "howard.abrams@gmail.com"))
  :maintainer
  '("Howard Abrams" . "howard.abrams@gmail.com")
  :keywords
  '("demonstration" "presentation" "test"))
;; Local Variables:
;; no-byte-compile: t
;; End:
