(define-package "fussy" "20231120.2200" "Fuzzy completion style using `flx'"
  '((emacs "27.2")
    (flx "0.5"))
  :commit "36920eadbb198d8116463ea139a605a1e157a593" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainers
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("matching")
  :url "https://github.com/jojojames/fussy")
;; Local Variables:
;; no-byte-compile: t
;; End:
