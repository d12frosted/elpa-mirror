;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-matchit" "20260409.318"
  "Vim matchit ported to Evil."
  '((emacs "27.1"))
  :url "https://github.com/redguardtoo/evil-matchit"
  :commit "10a9e98c9818c20722216345efd00bbb5465b1ec"
  :revdesc "10a9e98c9818"
  :keywords '("matchit" "vim" "evil")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
