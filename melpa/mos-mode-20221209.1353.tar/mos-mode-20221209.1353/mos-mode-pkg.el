;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mos-mode" "20221209.1353"
  "MOS toolkit usage."
  '((emacs    "24.4")
    (lsp-mode "8.0.0")
    (dap-mode "0.7")
    (dash     "2.19.1")
    (ht       "2.3"))
  :url "https://github.com/themkat/mos-mode"
  :commit "770f49417e8ad7dbf382c8691f6f689d793b9314"
  :revdesc "770f49417e8a")
