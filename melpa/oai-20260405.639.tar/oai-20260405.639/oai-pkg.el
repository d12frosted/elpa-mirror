;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260405.639"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "66ebed3e641dae8b1b8ec917a3d0228c5d2c86c6"
  :revdesc "66ebed3e641d"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
