(define-package "dwim-shell-command" "20221021.2139" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "7112c4c51a46454013ea0f97980f0496e2f8d084" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
