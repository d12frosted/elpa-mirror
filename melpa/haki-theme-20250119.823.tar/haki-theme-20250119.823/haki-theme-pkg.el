;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haki-theme" "20250119.823"
  "An elegant, high-contrast dark theme in modern sense."
  '((emacs "27.1"))
  :url "https://github.com/idlip/haki"
  :commit "38ab81334e11dd11c797aa724149b7cb1fa8eafa"
  :revdesc "38ab81334e11"
  :keywords '("faces" "theme" "accessibility"))
