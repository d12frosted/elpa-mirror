;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-todo" "20260521.1155"
  "Highlight TODO and similar keywords."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/hl-todo"
  :commit "38040e1b1fd8c0dfe41356ce001883300124f876"
  :revdesc "38040e1b1fd8"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev")))
