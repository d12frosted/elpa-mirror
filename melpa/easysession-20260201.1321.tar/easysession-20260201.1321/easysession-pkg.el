;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260201.1321"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "7a4d8e673884a8644593652757854ce8ea297511"
  :revdesc "7a4d8e673884"
  :keywords '("convenience"))
