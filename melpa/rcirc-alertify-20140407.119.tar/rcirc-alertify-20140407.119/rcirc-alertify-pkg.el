;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rcirc-alertify" "20140407.119"
  "Cross platform notifications for rcirc."
  '((alert "20140406.1353"))
  :url "https://github.com/fgallina/rcirc-alertify"
  :commit "ea5cafc55893f375eccbe013d12dbaa94bf6e259"
  :revdesc "ea5cafc55893"
  :keywords '("comm" "convenience")
  :authors '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org")))
