(define-package "wildcharm-theme" "20230814.1051" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "484cc771272fb5f9bbce3101f5b76e0f678be0a6" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
