;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "use-package-x" "20260519.125"
  "Additional keywords for use-package."
  '((emacs       "30.1")
    (compat      "31")
    (use-package "2.4"))
  :url "https://github.com/DevelopmentCool2449/use-package-x"
  :commit "2f679f089956af769ddc8f7473f01afd9b6fe56a"
  :revdesc "2f679f089956"
  :keywords '("convenience" "extensions")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Elias G. Perez" . "eg642616@gmail.com")))
