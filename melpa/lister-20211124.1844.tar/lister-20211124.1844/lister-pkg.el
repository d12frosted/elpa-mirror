(define-package "lister" "20211124.1844" "Yet another list printer"
  '((emacs "26.1"))
  :commit "aaaf67a3ace078d317295fd500dae40ecf547392" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
