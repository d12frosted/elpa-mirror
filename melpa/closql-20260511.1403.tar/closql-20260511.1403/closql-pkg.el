;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "closql" "20260511.1403"
  "Store EIEIO objects using EmacSQL."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "0.2")
    (emacsql  "4.3"))
  :url "https://github.com/emacscollective/closql"
  :commit "0cc3b6a63e72d0c408e484de39944eafb70b2ca7"
  :revdesc "0cc3b6a63e72"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev")))
