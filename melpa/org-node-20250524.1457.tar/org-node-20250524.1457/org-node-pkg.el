;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250524.1457"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "1d6fff99cd57eec7ddedbfc0b38f0cbc6680b146"
  :revdesc "1d6fff99cd57"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
