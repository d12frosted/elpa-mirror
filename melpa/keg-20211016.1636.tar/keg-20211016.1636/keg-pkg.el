(define-package "keg" "20211016.1636" "Modern Elisp package development system"
  '((emacs "24.1")
    (cl-lib "0.6"))
  :commit "6929ed8f8f673b27674be5ea5acdf2c9eec0ea3f" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
