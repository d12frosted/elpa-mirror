;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gtd" "20260121.336"
  "An implementation of GTD."
  '((emacs     "28.1")
    (compat    "30.0.0.0")
    (org-edna  "1.1.2")
    (f         "0.20.0")
    (org       "9.6")
    (transient "0.11.0")
    (dag-draw  "1.0.4"))
  :url "https://github.com/Trevoke/org-gtd.el"
  :commit "bbfbb703bd591f52bf8317778da7b03f48d7b864"
  :revdesc "bbfbb703bd59"
  :authors '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainers '(("Aldric Giacomoni" . "trevoke@gmail.com")))
