;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-scrum" "20241231.2251"
  "Org mode extensions for scrum planning and reporting."
  '((emacs  "24.5")
    (org    "8.2")
    (seq    "2.3")
    (cl-lib "1.0"))
  :url "https://github.com/ianxm/emacs-scrum"
  :commit "c1da15f576c8f55245df4804221c3b0efa7fbf40"
  :revdesc "c1da15f576c8"
  :authors '(("Ian Martins" . "ianxm@jhu.edu"))
  :maintainers '(("Ian Martins" . "ianxm@jhu.edu")))
