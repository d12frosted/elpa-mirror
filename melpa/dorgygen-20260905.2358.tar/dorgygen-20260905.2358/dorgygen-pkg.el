;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dorgygen" "20260905.2358"
  "Source code documentation in org-mode."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/dorgygen"
  :commit "69d2ffc538fe104022604b409d7bd16ea74705b4"
  :revdesc "69d2ffc538fe"
  :keywords '("tools" "wp"))
