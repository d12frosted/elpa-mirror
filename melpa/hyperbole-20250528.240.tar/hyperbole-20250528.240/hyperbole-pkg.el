;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250528.240"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b8d3e67c58a01f22b5a9a376472944d983279469"
  :revdesc "b8d3e67c58a0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
