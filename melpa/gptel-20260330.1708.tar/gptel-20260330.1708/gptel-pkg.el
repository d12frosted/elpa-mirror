;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260330.1708"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "d6c920d4c09c732868881d0cdad59c98439d398c"
  :revdesc "d6c920d4c09c"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
