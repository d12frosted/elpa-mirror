(define-package "racket-mode" "20211126.1444" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "cdc552eed25a44de1c53f0200be791dc83d65022" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
