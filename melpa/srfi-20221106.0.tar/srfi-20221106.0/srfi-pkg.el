(define-package "srfi" "20221106.0" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "8aac9d38e75f1fceba06f1070a869571b905318b" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
