;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250530.521"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "597a42d8087d4660f3093658bddc2f120bc72512"
  :revdesc "597a42d8087d"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
