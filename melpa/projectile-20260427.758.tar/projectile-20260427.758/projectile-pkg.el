;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260427.758"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "28014dae7034fff49f5740b013a426aade7873f3"
  :revdesc "28014dae7034"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
