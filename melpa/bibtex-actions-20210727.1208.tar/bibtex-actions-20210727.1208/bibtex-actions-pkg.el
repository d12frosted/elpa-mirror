(define-package "bibtex-actions" "20210727.1208" "Biblographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0"))
  :commit "4c6aa3612da91e9de27687bb2a7aeb4999ca84f5" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
