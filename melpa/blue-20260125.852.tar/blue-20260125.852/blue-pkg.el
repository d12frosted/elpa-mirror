;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260125.852"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "ad01628045be6c3ab8e40e610b885fd7464a9a15"
  :revdesc "ad01628045be"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
