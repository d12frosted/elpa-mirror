(define-package "apdl-mode" "20210925.2332" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "5d34411895d664051515537e00e5e060be21fbf6" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
