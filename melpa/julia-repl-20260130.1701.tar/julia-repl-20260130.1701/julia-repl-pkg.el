;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-repl" "20260130.1701"
  "A minor mode for a Julia REPL."
  '((emacs "29.1")
    (s     "1.12"))
  :url "https://github.com/tpapp/julia-repl"
  :commit "550e7c5e930282a8dde03e5edffba7079424dbb5"
  :revdesc "550e7c5e9302"
  :keywords '("languages")
  :authors '(("Tamas Papp" . "tkpapp@gmail.com"))
  :maintainers '(("Tamas Papp" . "tkpapp@gmail.com")))
