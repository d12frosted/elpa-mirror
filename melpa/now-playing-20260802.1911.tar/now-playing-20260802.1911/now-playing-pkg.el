;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "now-playing" "20260802.1911"
  "Interface for the macOS Music app."
  '((emacs     "30.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/now-playing"
  :commit "38ee9fe80ba6b0fa81e299edac2cae389f87933a"
  :revdesc "38ee9fe80ba6"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
