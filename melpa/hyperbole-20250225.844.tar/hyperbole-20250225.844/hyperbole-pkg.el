;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250225.844"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "eb67e83f288f72b69e1f7728b6d4be7b0a48b6de"
  :revdesc "eb67e83f288f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
