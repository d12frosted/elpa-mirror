(define-package "org-autoexport" "20240902.825" "Auto-export org file on save"
  '((emacs "28.1")
    (org "9.6"))
  :commit "0ab203602563f97156e28be3299e949cc379f292" :authors
  '(("Glenn Hutchings" . "zondo42@gmail.com"))
  :maintainers
  '(("Glenn Hutchings" . "zondo42@gmail.com"))
  :maintainer
  '("Glenn Hutchings" . "zondo42@gmail.com")
  :keywords
  '("org" "wp")
  :url "https://git.sr.ht/~zondo/org-autoexport")
;; Local Variables:
;; no-byte-compile: t
;; End:
