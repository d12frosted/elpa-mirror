(define-package "ue" "20210924.747" "Minor mode for Unreal Engine projects"
  '((emacs "26.1")
    (projectile "2.5.0"))
  :commit "665815b757e1aae692750b5848d3eca8bbc360da" :authors
  '(("Oleksandr Manenko" . "seidfzehsd@use.startmail.com"))
  :maintainer
  '("Oleksandr Manenko" . "seidfzehsd@use.startmail.com")
  :keywords
  '("unreal engine" "languages" "tools")
  :url "https://gitlab.com/unrealemacs/ue.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
