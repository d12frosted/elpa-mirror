;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-window" "20260215.304"
  "Jump to windows using keyboard spatial mapping."
  '((emacs    "28.1")
    (posframe "1.0.0"))
  :url "https://github.com/lewang/spatial-window"
  :commit "d194ae2864c3f894766cf7f59306aff57afd9dcc"
  :revdesc "d194ae2864c3"
  :keywords '("convenience" "windows")
  :authors '(("Le Wang" . "lewang.dev.26@gmail.com"))
  :maintainers '(("Le Wang" . "lewang.dev.26@gmail.com")))
