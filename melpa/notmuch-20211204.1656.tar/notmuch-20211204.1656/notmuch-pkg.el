(define-package "notmuch" "20211204.1656" "run notmuch within emacs" 'nil :commit "f17d75b83c90ae4ea75f79377f3acb873b9e564e" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
