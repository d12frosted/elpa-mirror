(define-package "notmuch" "20211204.1656" "run notmuch within emacs" 'nil :commit "c01152885c565813aa9510481e425e7c61815b56" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
