(define-package "notmuch" "20211204.1656" "run notmuch within emacs" 'nil :commit "ab8d0e572537006a4e1dafa266075ed0d848c80f" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
