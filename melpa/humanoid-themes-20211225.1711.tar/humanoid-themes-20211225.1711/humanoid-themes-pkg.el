(define-package "humanoid-themes" "20211225.1711" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "3d18cb0075c87f15172242f6032caf4121422e87" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
