(define-package "org-jira" "20220725.1808" "Syncing between Jira and Org-mode."
  '((emacs "24.5")
    (cl-lib "0.5")
    (request "0.2.0")
    (dash "2.14.1"))
  :commit "93629335727d855e8795470e78282c9dc532c839" :maintainer
  '("Matthew Carter" . "m@ahungry.com")
  :keywords
  '("ahungry" "jira" "org" "bug" "tracker")
  :url "https://github.com/ahungry/org-jira")
;; Local Variables:
;; no-byte-compile: t
;; End:
