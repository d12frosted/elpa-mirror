;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260511.914"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "c2d8c8a28c9745c4cd1a2b111149a28002a25f22"
  :revdesc "c2d8c8a28c97"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
