(define-package "mini-echo" "20240602.1724" "Echo buffer status in minibuffer window"
  '((emacs "29.1")
    (dash "2.19.1")
    (hide-mode-line "1.0.3"))
  :commit "bba194a1e4d3cf243917ed0a456de6a689f78115" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
