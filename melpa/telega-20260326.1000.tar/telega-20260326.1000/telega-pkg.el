;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260326.1000"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "8078beccf88c132d504ba9031062a6a2c65a1c8b"
  :revdesc "8078beccf88c"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
