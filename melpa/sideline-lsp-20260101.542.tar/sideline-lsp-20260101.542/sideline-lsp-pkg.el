;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-lsp" "20260101.542"
  "Show lsp information with sideline."
  '((emacs    "28.1")
    (sideline "0.1.0")
    (lsp-mode "6.0")
    (dash     "2.18.0")
    (ht       "2.4")
    (s        "1.12.0"))
  :url "https://github.com/emacs-sideline/sideline-lsp"
  :commit "dfa29a7b27e5ab64788c76544444f678ae4db18d"
  :revdesc "dfa29a7b27e5"
  :keywords '("convenience" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
