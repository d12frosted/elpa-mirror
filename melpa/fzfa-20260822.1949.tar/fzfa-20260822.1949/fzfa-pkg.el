;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260822.1949"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.2"))
  :url "https://github.com/jojojames/fzfa"
  :commit "99274680596209a0c0be80bba3ed470ed1e11ba2"
  :revdesc "992746805962"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
