;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250603.412"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "8aee5dff97311f72cc208830349cd508d0371e29"
  :revdesc "8aee5dff9731"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
