;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251102.1807"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "61117aa76d4a278cd1b461cf108eba4bdf452adb"
  :revdesc "61117aa76d4a"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
