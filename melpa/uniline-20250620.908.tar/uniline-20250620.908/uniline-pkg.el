;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250620.908"
  "Add ╭─╴UNICODE╶─╮ based ╭─╴diagrams╶─╮ to ╭▶╴text files╶●╮."
  '((emacs "29.1"))
  :url "https://github.com/tbanel/uniline"
  :commit "7ede354080cef4f7293356aad1967c8c43476314"
  :revdesc "7ede354080ce"
  :keywords '("convenience" "text"))
