;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "20260404.1841"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.1")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "8e1334cfc8114ddd71b4de99760429e4e8a81f7b"
  :revdesc "8e1334cfc811"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
