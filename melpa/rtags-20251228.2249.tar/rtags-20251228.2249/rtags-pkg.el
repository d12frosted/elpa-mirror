;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtags" "20251228.2249"
  "A front-end for rtags."
  '((emacs "24.3"))
  :url "https://github.com/Andersbakken/rtags"
  :commit "829a6298d6bfba8ed541570fcbe3daf5ce3135d0"
  :revdesc "829a6298d6bf"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
