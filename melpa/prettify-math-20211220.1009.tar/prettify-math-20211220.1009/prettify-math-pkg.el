(define-package "prettify-math" "20211220.1009" "Prettify math formula"
  '((emacs "27.1")
    (dash "2.19.0")
    (s "1.12.0")
    (jsonrpc "1.0.9"))
  :commit "b4cf35096f664b37cd431c4745165bbad6021bd1" :authors
  '(("Shaq Xu" . "shaqxu@163.com"))
  :maintainer
  '("Shaq Xu" . "shaqxu@163.com")
  :keywords
  '("math" "asciimath" "tex" "latex" "prettify" "mathjax")
  :url "https://github.com/shaqxu/prettify-math")
;; Local Variables:
;; no-byte-compile: t
;; End:
