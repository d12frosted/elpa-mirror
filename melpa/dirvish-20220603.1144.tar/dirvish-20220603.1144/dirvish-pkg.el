(define-package "dirvish" "20220603.1144" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "853c890bc754a024dbe4cfbb286ea0583b359213" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
