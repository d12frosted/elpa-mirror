;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smtpmail-multi" "20160218.2349"
  "Use different smtp servers for sending mail."
  ()
  :url "https://github.com/vapniks/smtpmail-multi"
  :commit "81eabfe56f620ee044ff9dd52fa8b6148d0a9f30"
  :revdesc "81eabfe56f62"
  :keywords '("comm")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
