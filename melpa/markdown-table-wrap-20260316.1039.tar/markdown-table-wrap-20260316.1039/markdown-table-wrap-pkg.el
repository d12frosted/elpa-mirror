;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-table-wrap" "20260316.1039"
  "Word-wrap GFM pipe tables to fit window width."
  '((emacs "28.1"))
  :url "https://github.com/dnouri/markdown-table-wrap"
  :commit "71a1cec53bf9d7875126b4cd557b2c00ae52b576"
  :revdesc "71a1cec53bf9"
  :keywords '("text" "markdown" "tables")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
