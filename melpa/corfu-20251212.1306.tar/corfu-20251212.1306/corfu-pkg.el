;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251212.1306"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "30185aa634803f4effa18fe451983a9847202960"
  :revdesc "30185aa63480"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
