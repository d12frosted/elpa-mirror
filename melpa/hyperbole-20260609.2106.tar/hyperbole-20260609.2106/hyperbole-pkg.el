;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260609.2106"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "8122ddbe417c58d5067ab7e3f0d9dd79210940d4"
  :revdesc "8122ddbe417c"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
