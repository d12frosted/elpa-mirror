(define-package "live-py-mode" "20211031.103" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "acacf37194c3a3d41cad7866da545240cc20207a" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
