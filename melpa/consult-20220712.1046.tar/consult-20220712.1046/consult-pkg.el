(define-package "consult" "20220712.1046" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "53e78c6be5c64f9fdeb61c55cbec9a4f56f46adc" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
