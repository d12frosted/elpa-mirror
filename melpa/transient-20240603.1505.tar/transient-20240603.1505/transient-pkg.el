(define-package "transient" "20240603.1505" "Transient commands"
  '((emacs "26.1")
    (compat "29.1.4.4")
    (seq "2.24"))
  :commit "3ead3849420b82e08214a5a25e69dbe1becf5647" :authors
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
