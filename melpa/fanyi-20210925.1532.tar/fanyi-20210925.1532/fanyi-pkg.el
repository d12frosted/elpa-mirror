(define-package "fanyi" "20210925.1532" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "1b5c4337137a5ea1576e0389672b1c13e4d135bc" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
