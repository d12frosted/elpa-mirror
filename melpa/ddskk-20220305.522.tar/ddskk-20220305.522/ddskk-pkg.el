(define-package "ddskk" "20220305.522" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "5c209e0306364118abf9d9440d7b8b9613183072")
;; Local Variables:
;; no-byte-compile: t
;; End:
