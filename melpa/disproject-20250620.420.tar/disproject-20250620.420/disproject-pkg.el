;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20250620.420"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.9.2"))
  :url "https://github.com/aurtzy/disproject"
  :commit "26691dc9f3400974f31d7a0daef37ce370d5c956"
  :revdesc "26691dc9f340"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
