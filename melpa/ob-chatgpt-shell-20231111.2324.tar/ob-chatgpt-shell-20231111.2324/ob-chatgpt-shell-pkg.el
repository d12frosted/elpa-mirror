(define-package "ob-chatgpt-shell" "20231111.2324" "Org babel functions for ChatGPT evaluation"
  '((emacs "27.1")
    (chatgpt-shell "0.88.1"))
  :commit "03f8edabb95c6ffc64050d79fdb3091532711b59" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
