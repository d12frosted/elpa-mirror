;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "default-font-presets" "20250918.1048"
  "Support selecting fonts from a list of presets."
  '((emacs "26.1"))
  :url "https://codeberg.org/ideasman42/emacs-default-font-presets"
  :commit "78cc92edd0bda363aa779879e259654f1b317d9e"
  :revdesc "78cc92edd0bd"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
