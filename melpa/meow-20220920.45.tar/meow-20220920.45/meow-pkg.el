(define-package "meow" "20220920.45" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "c3f291ad289769fc9a3b2745a5e9969af6322d0c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
