(define-package "helm-core" "20210519.1827" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "2b60812516a0560ba5b2501771b53273a56c6488")
;; Local Variables:
;; no-byte-compile: t
;; End:
