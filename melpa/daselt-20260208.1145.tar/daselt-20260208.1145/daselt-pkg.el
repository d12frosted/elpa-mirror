;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260208.1145"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "d9e4d6e1671195406cb5aaded1bd7d09f8dbea35"
  :revdesc "d9e4d6e16711"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
