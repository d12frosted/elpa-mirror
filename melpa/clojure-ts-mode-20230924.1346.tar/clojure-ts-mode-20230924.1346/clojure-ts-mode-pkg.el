(define-package "clojure-ts-mode" "20230924.1346" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "a7b9654488693cdc9057a91410f74de42a397d1b" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
