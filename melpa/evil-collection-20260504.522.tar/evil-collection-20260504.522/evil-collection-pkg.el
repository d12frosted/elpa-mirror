;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260504.522"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "5c79c9e09ca54b285706c38a8e94e29cc17ab00c"
  :revdesc "5c79c9e09ca5"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
