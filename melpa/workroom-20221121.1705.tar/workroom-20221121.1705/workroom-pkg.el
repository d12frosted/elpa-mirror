(define-package "workroom" "20221121.1705" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0"))
  :commit "a02bb2a3a66d38f5166dd1e7e04e2d490c72e243" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
