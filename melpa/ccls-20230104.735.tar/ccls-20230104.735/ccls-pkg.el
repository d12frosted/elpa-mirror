(define-package "ccls" "20230104.735" "ccls client for lsp-mode"
  '((emacs "25.1")
    (lsp-mode "6.3.1")
    (dash "2.14.1"))
  :commit "e4d1aad88365ee8ca3d57b15e31c94abc04bac55" :authors
  '(("Tobias Pisani, Fangrui Song"))
  :maintainer
  '("Tobias Pisani, Fangrui Song")
  :keywords
  '("languages" "lsp" "c++")
  :url "https://github.com/MaskRay/emacs-ccls")
;; Local Variables:
;; no-byte-compile: t
;; End:
