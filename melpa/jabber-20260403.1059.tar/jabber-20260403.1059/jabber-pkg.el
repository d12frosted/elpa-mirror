;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260403.1059"
  "XMPP/Jabber client."
  '((emacs "29.1")
    (fsm   "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-jabber"
  :commit "71e40798a0db8d47893efaa1b6c9d151aab701b7"
  :revdesc "71e40798a0db"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
