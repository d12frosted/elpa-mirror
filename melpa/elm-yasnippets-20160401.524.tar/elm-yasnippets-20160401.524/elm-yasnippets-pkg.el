;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elm-yasnippets" "20160401.524"
  "Yasnippets for Elm."
  '((yasnippet "0.8.0"))
  :url "https://github.com/abingham/elm-yasnippets"
  :commit "45a11a0cef0c36633fb3477d3dc4167e82779ba4"
  :revdesc "45a11a0cef0c"
  :keywords '("snippets")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
