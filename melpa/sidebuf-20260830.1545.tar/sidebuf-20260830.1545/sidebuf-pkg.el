;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sidebuf" "20260830.1545"
  "Buffer list sidebar panel."
  '((emacs "27.1"))
  :url "https://github.com/rain-64/sidebuf"
  :commit "9245426b8d8fc63f5bb2b5a28ebb957db4e4ce2c"
  :revdesc "9245426b8d8f"
  :keywords '("convenience" "buffers")
  :authors '(("rain-64" . "https://github.com/rain-64"))
  :maintainers '(("rain-64" . "https://github.com/rain-64")))
