(define-package "notmuch" "20210115.1130" "run notmuch within emacs" 'nil :commit "6a7b61b1d50bf25ebce61fa58af1c195951b387c" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
