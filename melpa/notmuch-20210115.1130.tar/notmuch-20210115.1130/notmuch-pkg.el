(define-package "notmuch" "20210115.1130" "run notmuch within emacs" 'nil :commit "15d8067c0a209a24d757b416107d92007529f01f" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
