;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250303.118"
  "Fast org-roam replacement."
  '((emacs  "28.1")
    (compat "30")
    (el-job "0.3.22")
    (llama  "0.4.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "e01c5893b8274fabddfb8a5900619cdf299d0bfa"
  :revdesc "e01c5893b827"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
