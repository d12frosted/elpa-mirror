(define-package "elisp-autofmt" "20231026.2028" "Emacs lisp auto-format"
  '((emacs "29.1"))
  :commit "d5d6010a1bc1b1f5a2422474f701d4573a95aa5b" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
