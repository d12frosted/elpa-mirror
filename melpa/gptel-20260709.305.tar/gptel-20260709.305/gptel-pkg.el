;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260709.305"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "38bc5293e3f051d09ddc09d11a895552925da09a"
  :revdesc "38bc5293e3f0"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
