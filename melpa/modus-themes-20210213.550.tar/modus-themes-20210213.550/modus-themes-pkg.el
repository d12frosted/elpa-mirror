(define-package "modus-themes" "20210213.550" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "2f80b40710d13017a0756830c9e314cf8e3dd82c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
