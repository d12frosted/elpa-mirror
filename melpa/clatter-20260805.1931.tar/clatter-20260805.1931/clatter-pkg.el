;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260805.1931"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "7e9bd24362702b72f005d4ba4db7686b4729b5d2"
  :revdesc "7e9bd2436270"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
