(define-package "citre" "20210908.1527" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "0216565f646f6c5fec401166969379233be74b7d" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
