;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260219.1848"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "48b3e7be311155e1f04f9015b6eb6524dbe77a5f"
  :revdesc "48b3e7be3111"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
