(define-package "decor" "20231129.2342" "Modify visual decorations"
  '((emacs "24.1"))
  :commit "05901f3f3a72a8fd3e7999c7fb98804c03ce3b1a" :authors
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainer
  '("Peter Badida" . "keyweeusr@gmail.com")
  :keywords
  '("convenience" "window" "decoration" "distraction" "xprop" "xwayland")
  :url "https://github.com/KeyWeeUsr/decor")
;; Local Variables:
;; no-byte-compile: t
;; End:
