(define-package "websearch" "20220807.2219" "Query search engines"
  '((emacs "24.4"))
  :commit "f69d26bee3330b59132deecf97b7c17fd1c5f27e" :authors
  '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainer
  '("Maciej Barć" . "xgqt@riseup.net")
  :keywords
  '("convenience" "hypermedia")
  :url "https://gitlab.com/xgqt/emacs-websearch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
