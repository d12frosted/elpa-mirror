;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260812.1055"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "88c875af2980eca4348f3d68acdaa44a20b8ac51"
  :revdesc "88c875af2980"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
