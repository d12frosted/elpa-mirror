;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esh-autosuggest" "20260530.527"
  "History autosuggestions for eshell."
  '((emacs   "24.4")
    (company "0.9.4"))
  :url "https://sr.ht/~dieggsy/esh-autosuggest"
  :commit "40774022105ed16287fcf26553a16c4cdda5e1ab"
  :revdesc "40774022105e"
  :keywords '("completion" "company" "matching" "convenience" "abbrev")
  :authors '(("Diego A. Mundo" . "dieggsy@pm.me"))
  :maintainers '(("Diego A. Mundo" . "dieggsy@pm.me")))
