;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260320.1920"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "de0db122d1d57d5fd7e2c1853faf411456382235"
  :revdesc "de0db122d1d5")
