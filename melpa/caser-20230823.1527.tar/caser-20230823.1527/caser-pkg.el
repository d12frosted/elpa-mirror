(define-package "caser" "20230823.1527" "Change text casing from camelCase to dash-case to snake_case"
  '((emacs "29.1"))
  :commit "ede9bbf3ee1f9fd7833c00f9169e282c5d1b5f9e" :url "https://hg.sr.ht/~zck/caser.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
