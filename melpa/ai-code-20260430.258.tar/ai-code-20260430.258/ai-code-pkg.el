;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260430.258"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a2d0a0a89b1a2e32567fd211b7d3fa4a2050f20c"
  :revdesc "a2d0a0a89b1a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
