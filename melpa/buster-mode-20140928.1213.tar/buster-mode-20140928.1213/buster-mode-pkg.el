;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buster-mode" "20140928.1213"
  "Minor mode to speed up development when writing tests with Buster.js."
  ()
  :url "https://github.com/magnars/buster-mode"
  :commit "de6958ef8369400922618b8d1e99abfa91b97ac5"
  :revdesc "de6958ef8369"
  :keywords '("buster" "testing" "javascript")
  :authors '(("Magnar Sveen" . "magnars@gmail.com")
             ("Christian Johansen" . "christian@cjohansen.no"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")
                 ("Christian Johansen" . "christian@cjohansen.no")))
