(define-package "mmm-mode" "20240221.1457" "Allow Multiple Major Modes in a buffer"
  '((emacs "25.1")
    (cl-lib "0.2"))
  :commit "fec26407278ca77d5e7119689a1f79e4e6262699" :authors
  '(("Michael Abraham Shulman" . "viritrilbia@gmail.com"))
  :maintainers
  '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("convenience" "faces" "languages" "tools")
  :url "https://github.com/purcell/mmm-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
