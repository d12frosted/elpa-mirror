(define-package "live-py-mode" "20211030.1712" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "4fd23377a2b03a6b2c921046acf7ef0df520304d" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
