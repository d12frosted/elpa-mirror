;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compilation-history" "20260413.2031"
  "Track compilation history in SQLite."
  '((emacs "29.1"))
  :url "https://github.com/djgoku/compilation-history"
  :commit "cfc37a18469634696761e239d0517cfb96a2ca40"
  :revdesc "cfc37a184696"
  :keywords '("processes" "tools")
  :authors '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainers '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com")))
