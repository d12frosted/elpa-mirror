(define-package "org-d20" "20210212.142" "minor mode for d20 tabletop roleplaying games"
  '((s "1.11.0")
    (seq "2.19")
    (dash "2.12.0")
    (emacs "24"))
  :commit "e6149dcfbb6302d10109dd792fd0ffae7bfe2595" :authors
  '(("Sean Whitton" . "spwhitton@spwhitton.name"))
  :maintainers
  '(("Sean Whitton" . "spwhitton@spwhitton.name"))
  :maintainer
  '("Sean Whitton" . "spwhitton@spwhitton.name")
  :keywords
  '("outlines" "games")
  :url "https://spwhitton.name/tech/code/org-d20/")
;; Local Variables:
;; no-byte-compile: t
;; End:
