;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "20260112.924"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "33c1efd417974896f1991b4c94833bd5ef370e92"
  :revdesc "33c1efd41797"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
