(define-package "dirvish" "20220317.1723" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "d1fc7a9985f6c1d215b9d008541517f911ce1a3e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
