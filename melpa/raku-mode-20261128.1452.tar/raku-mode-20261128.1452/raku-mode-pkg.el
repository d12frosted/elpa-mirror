;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "raku-mode" "20261128.1452"
  "Major mode for editing Raku code."
  '((emacs "24.4"))
  :url "https://github.com/Raku/raku-mode"
  :commit "caf34eecf6b65a8a9c1bedd9cbd03491c29202ce"
  :revdesc "caf34eecf6b6"
  :keywords '("languages")
  :authors '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com"))
  :maintainers '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com")))
