;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-latte" "20260204.1115"
  "Auto-highlight unlinked Org-roam references."
  '((emacs       "27.1")
    (org-roam    "2.0")
    (inflections "1.1"))
  :url "https://github.com/yad-tahir/org-roam-latte"
  :commit "3f0f4f5c2e68bc77c3927f6ce5dead4ff2511627"
  :revdesc "3f0f4f5c2e68"
  :keywords '("hypermedia" "outlines" "org-roam" "convenience")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
