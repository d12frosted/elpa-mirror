(define-package "tree-sitter-langs" "20201108.944" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.9.2"))
  :commit "dc9094b5066ec3c4ad583ed285c282f5811323b5" :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
