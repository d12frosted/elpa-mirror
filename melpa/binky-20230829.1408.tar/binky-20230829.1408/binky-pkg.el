(define-package "binky" "20230829.1408" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "1201002d665b74fc2e8121933acf7dc4102cbcbd" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
