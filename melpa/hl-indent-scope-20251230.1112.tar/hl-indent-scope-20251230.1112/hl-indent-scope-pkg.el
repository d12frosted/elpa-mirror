;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent-scope" "20251230.1112"
  "Highlight indentation by scope."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope"
  :commit "18652d3c68a70d78451b5e72990fda4bb406d6df"
  :revdesc "18652d3c68a7"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
