;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-compass" "20260724.1822"
  "Navigate software aided by metrics and visualization."
  '((emacs        "26.1")
    (s            "1.12.0")
    (dash         "2.13")
    (async        "1.9.7")
    (simple-httpd "1.5.1"))
  :url "https://github.com/ag91/code-compass"
  :commit "9004c885ac20e10237c97b66b5dd4e61f4e8a1e1"
  :revdesc "9004c885ac20"
  :keywords '("tools" "extensions" "help")
  :authors '(("Andrea" . "andrea-dev@hotmail.com"))
  :maintainers '(("Andrea" . "andrea-dev@hotmail.com")))
