(define-package "fedi" "20230801.1500" "Helper functions for fediverse clients"
  '((emacs "28.1"))
  :commit "308e671f8f5329f28d3846b0c31039f52bd9d6e7" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
