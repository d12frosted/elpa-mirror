;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-indent" "20260516.852"
  "Indent-lint frontend for flycheck."
  '((emacs       "27.1")
    (indent-lint "1.1.4")
    (flycheck    "36"))
  :url "https://github.com/conao3/indent-lint.el"
  :commit "3660b10520d78dd545fd0c52d7e7a36dc602492d"
  :revdesc "3660b10520d7"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
