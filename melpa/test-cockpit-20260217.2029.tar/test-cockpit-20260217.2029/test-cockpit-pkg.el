;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260217.2029"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "b4a7445b62c655a81c47c98fd682aa2dc7769cd6"
  :revdesc "b4a7445b62c6"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
