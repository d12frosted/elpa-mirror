(define-package "wordel" "20220124.251" "An Elisp implementation of \"Wordle\" (aka \"Lingo\")"
  '((emacs "27.1"))
  :commit "c2f0d61646d2744167661e5ce60fae679d50c850" :authors
  '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com"))
  :maintainer
  '("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/progfolio/wordel")
;; Local Variables:
;; no-byte-compile: t
;; End:
