;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rsync-mode" "20210911.0"
  "Rsync projects to remote machines."
  '((emacs   "27.1")
    (spinner "1.7.1"))
  :url "https://github.com/r-zip/rsync-mode.el"
  :commit "2bc76aa8c2d82bb08ef70e23813a653d66bf3195"
  :revdesc "2bc76aa8c2d8"
  :keywords '("comm")
  :authors '(("Ryan Pilgrim" . "ryan.z.pilgrim@gmail.com"))
  :maintainers '(("Ryan Pilgrim" . "ryan.z.pilgrim@gmail.com")))
