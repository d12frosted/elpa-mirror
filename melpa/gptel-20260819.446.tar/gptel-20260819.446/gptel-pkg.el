;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260819.446"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "df4c9d8b768675bcde4a02b65eea67e2f6dcc6d4"
  :revdesc "df4c9d8b7686"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
