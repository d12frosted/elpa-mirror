;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250627.1102"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "c2c67d5794bdb59b2eaddf0c380dbe6d1fb870c0"
  :revdesc "c2c67d5794bd"
  :keywords '("languages"))
