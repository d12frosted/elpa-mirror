(define-package "protobuf-ts-mode" "20230410.855" "Tree sitter support for Protocol Buffers (proto3 only)"
  '((emacs "29"))
  :commit "cde61510b711d90bf2978ca4cbd3f36fce8b4c3e" :authors
  '(("ookami" . "mail@ookami.one"))
  :maintainers
  '(("ookami" . "mail@ookami.one"))
  :maintainer
  '("ookami" . "mail@ookami.one")
  :keywords
  '("protobuf" "languages" "tree-sitter")
  :url "https://git.ookami.one/cgit/protobuf-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
