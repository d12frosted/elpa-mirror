;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-latex" "20261010.1034"
  "Preview LaTeX math as SVG in LaTeX buffers."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.20.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "0db30bbbdd549a2e712c2f1b5af38bac0a8cbd11"
  :revdesc "0db30bbbdd54"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
