(define-package "tuareg" "20231002.121" "OCaml mode"
  '((emacs "26.3")
    (caml "4.8"))
  :commit "f03eb1cb0c6f897d6f670b916ea7d768b906d329" :authors
  '(("Albert Cohen" . "Albert.Cohen@inria.fr")
    ("Sam Steingold" . "sds@gnu.org")
    ("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
    ("Till Varoquaux" . "till@pps.jussieu.fr")
    ("Sean McLaughlin" . "seanmcl@gmail.com")
    ("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainers
  '(("Christophe Troestler" . "Christophe.Troestler@umons.ac.be"))
  :maintainer
  '("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/tuareg")
;; Local Variables:
;; no-byte-compile: t
;; End:
