;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260604.1000"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "72c32ad0f1f1120a1af9f8d4223b2b3c5f9d7310"
  :revdesc "72c32ad0f1f1"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
