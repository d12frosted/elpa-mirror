;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fastbuild-bff-mode" "20261028.643"
  "Major mode for FASTBuild BFF files."
  '((emacs "26.1"))
  :url "https://github.com/cyberkm/fastbuild-bff-mode"
  :commit "fd8f22093c4b43475b144decc42c40a037d7939d"
  :revdesc "fd8f22093c4b"
  :keywords '("languages" "tools" "build")
  :authors '(("Pavel Bibergal" . "cyberkm@gmail.com"))
  :maintainers '(("Pavel Bibergal" . "cyberkm@gmail.com")))
