;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260322.100"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "7f19163423bab741efb105d832803f0f35cae0c6"
  :revdesc "7f19163423ba"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
