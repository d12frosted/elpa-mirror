(define-package "color-theme-sanityinc-tomorrow" "20240220.813" "A version of Chris Kempson's \"tomorrow\" themes"
  '((emacs "24.1"))
  :commit "730d4b836749481d712eaa01ef7a712e942d1b1e" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("faces" "themes")
  :url "https://github.com/purcell/color-theme-sanityinc-tomorrow")
;; Local Variables:
;; no-byte-compile: t
;; End:
