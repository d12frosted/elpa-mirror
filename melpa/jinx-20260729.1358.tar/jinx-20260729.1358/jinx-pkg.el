;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260729.1358"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "d6268c346a1da6ddf7b027784199092e490544d6"
  :revdesc "d6268c346a1d"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
