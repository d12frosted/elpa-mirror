(define-package "darkman" "20230621.1453" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "2638df0a7ab3b845ea1a48904c05515e0d754a67" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainers
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://darkman.grtcdr.tn")
;; Local Variables:
;; no-byte-compile: t
;; End:
