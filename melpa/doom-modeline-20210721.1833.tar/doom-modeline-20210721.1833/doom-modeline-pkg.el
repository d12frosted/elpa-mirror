(define-package "doom-modeline" "20210721.1833" "A minimal and modern mode-line"
  '((emacs "25.1")
    (all-the-icons "2.2.0")
    (shrink-path "0.2.0")
    (dash "2.11.0"))
  :commit "0ad2e966abb1394682296c0ab85f11117ae9da3d" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
