(define-package "flymake-sqlfluff" "20231029.1805" "A flymake plugin for SQL files using sqlfluff"
  '((emacs "27.1"))
  :commit "f23324690066a2841f82f166d63f4d7ff0334b01" :authors
  '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers
  '(("Erick Navarro" . "erick@navarro.io"))
  :maintainer
  '("Erick Navarro" . "erick@navarro.io")
  :url "https://github.com/erickgnavar/flymake-sqlfluff")
;; Local Variables:
;; no-byte-compile: t
;; End:
