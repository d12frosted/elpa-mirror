;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lacquer" "20230824.725"
  "Switch theme/font by selecting from a cache."
  '((emacs "25.2"))
  :url "https://github.com/zakudriver/lacquer"
  :commit "c8a0fb81f18001b3d510f545ba253ed4f9a50f5b"
  :revdesc "c8a0fb81f180"
  :keywords '("tools")
  :authors '(("zakudriver" . "zy.hua1122@gmail.com"))
  :maintainers '(("zakudriver" . "zy.hua1122@gmail.com")))
