;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-zones" "20260910.135"
  "Time zone lookups."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/time-zones"
  :commit "dc6c438031f5c279bf1bbf39c053f22807460bbf"
  :revdesc "dc6c438031f5")
