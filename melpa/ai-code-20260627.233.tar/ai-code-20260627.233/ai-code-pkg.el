;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260627.233"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "934c5b67cd602eff926d21fd243bc0e7326a3c9f"
  :revdesc "934c5b67cd60"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
