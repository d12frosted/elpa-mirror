;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20241218.533"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.8"))
  :url "https://github.com/emacs-helm/helm"
  :commit "0acbce6e5dc830bc6e0d49f598ef0e607e28521c"
  :revdesc "0acbce6e5dc8"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
