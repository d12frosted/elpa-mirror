;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "20250618.315"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "cb30874ebe793a3657904198afde517e10f5200f"
  :revdesc "cb30874ebe79"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
