(define-package "axiom-environment" "20210119.2053" "An environment for using Axiom/OpenAxiom/FriCAS"
  '((emacs "24.2"))
  :commit "7afc30fc293effbfde0e4d75a42832a69dbcfd49" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("axiom" "openaxiom" "fricas"))
;; Local Variables:
;; no-byte-compile: t
;; End:
