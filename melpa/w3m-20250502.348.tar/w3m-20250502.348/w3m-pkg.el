;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "w3m" "20250502.348"
  "An Emacs interface to w3m."
  ()
  :url "https://github.com/emacs-w3m/emacs-w3m"
  :commit "c67785a7039ca5bb416b5c5a4fa5b8704e54eb8f"
  :revdesc "c67785a7039c"
  :keywords '("w3m" "www" "hypermedia"))
