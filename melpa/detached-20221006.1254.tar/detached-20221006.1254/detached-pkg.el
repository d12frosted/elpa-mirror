(define-package "detached" "20221006.1254" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "07bce132989ac97a10956c3264d1c237de0ef8ec" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
