;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260406.1756"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "c6eb80106b75816bcd9c2ec6962b33e24bd36723"
  :revdesc "c6eb80106b75"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
