(define-package "lister" "20211028.1659" "Yet another list printer"
  '((emacs "26.1"))
  :commit "22df7ad4a7cccd5e5861a37127263317ef6bea2a" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
