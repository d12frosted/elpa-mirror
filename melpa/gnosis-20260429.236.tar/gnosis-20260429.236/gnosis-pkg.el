;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260429.236"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://codeberg.org/thanosapollo/emacs-gnosis"
  :commit "32b72c9fc46978dfd248b623df2c3b3e88284e9f"
  :revdesc "32b72c9fc469"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
