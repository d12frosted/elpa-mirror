(define-package "consult" "20221130.736" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "24310db92e41f19827f9198a54ee718257ebeee1" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
