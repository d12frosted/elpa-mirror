;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260531.1502"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0fec1976d1f71cf0938538b8182817f3eeb389ff"
  :revdesc "0fec1976d1f7")
