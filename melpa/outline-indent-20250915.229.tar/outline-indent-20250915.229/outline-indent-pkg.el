;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20250915.229"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "d94a64dde65e61a40cb67e6e868dcb2d845be2ca"
  :revdesc "d94a64dde65e"
  :keywords '("outlines"))
