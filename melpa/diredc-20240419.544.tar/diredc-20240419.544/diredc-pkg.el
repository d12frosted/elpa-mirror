(define-package "diredc" "20240419.544" "Midnight Commander features (plus) for dired"
  '((emacs "26.1")
    (key-assist "1.0"))
  :commit "d179e93982f4c554a310645bb35ef5bed9f38a52" :keywords
  '("files")
  :url "https://github.com/Boruch-Baum/emacs-diredc")
;; Local Variables:
;; no-byte-compile: t
;; End:
