;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cloak-mode" "20260309.528"
  "A minor mode to cloak sensitive values."
  '((emacs "27.1"))
  :url "https://github.com/erickgnavar/cloak-mode"
  :commit "8a8d06a280c340a7e1639f60c8c44cd4b4127e6b"
  :revdesc "8a8d06a280c3"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
