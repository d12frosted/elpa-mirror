;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250527.633"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "c9bc2bc1bd4805d3e4abc99c47988ed0e9a52a48"
  :revdesc "c9bc2bc1bd48"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
