(define-package "embark" "20210720.1810" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "221eb6fd68020b61208404dd5b64ecb45e52f933" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
