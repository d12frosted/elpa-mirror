(define-package "flexoki-themes" "20231019.851" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "50c0e02a4e27b9a9c1ee2b2fb0d0ab404c1ed356" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
