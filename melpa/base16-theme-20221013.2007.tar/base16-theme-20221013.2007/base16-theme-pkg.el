(define-package "base16-theme" "20221013.2007" "Collection of themes built on combinations of 16 base colors" 'nil :commit "6e316cbbdc88ae660aef944c6120db57abfb96c6" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/tinted-theming/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
