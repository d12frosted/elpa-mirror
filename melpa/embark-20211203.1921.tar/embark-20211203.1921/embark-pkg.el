(define-package "embark" "20211203.1921" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "b283be3fe8cf871d61b0046fc96b30fe499b5979" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
