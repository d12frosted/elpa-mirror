;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "everlasting-scratch" "20250206.628"
  "The *scratch* that lasts forever."
  '((emacs "25.1"))
  :url "https://github.com/beacoder/everlasting-scratch"
  :commit "a990e8d2261e5ac109729eb8c2c8e1947e45c8ed"
  :revdesc "a990e8d2261e"
  :keywords '("convenience" "tool")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
