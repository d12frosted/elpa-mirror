;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jack-connect" "20220201.1417"
  "Manage jack connections within Emacs."
  ()
  :commit "1acaebfe8f37f0194e95c3e812c9515a6f688eee"
  :revdesc "1acaebfe8f37"
  :authors '(("Stefano Barbi" . "stefanobarbi@gmail.com"))
  :maintainers '(("Stefano Barbi" . "stefanobarbi@gmail.com")))
