(define-package "notmuch" "20220807.1005" "run notmuch within emacs" 'nil :commit "6d6d2a5fe7a04cc8de43d6b27844c50f02d749ed" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
