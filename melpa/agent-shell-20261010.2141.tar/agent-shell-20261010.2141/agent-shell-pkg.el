;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261010.2141"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ee760a022f8b8a0b3126c692460094451efc1605"
  :revdesc "ee760a022f8b")
