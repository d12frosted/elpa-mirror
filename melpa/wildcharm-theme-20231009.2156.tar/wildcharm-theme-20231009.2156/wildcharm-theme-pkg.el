(define-package "wildcharm-theme" "20231009.2156" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "572c7d2deb5d8f989386f010e2aff2e2b4b55dd1" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
