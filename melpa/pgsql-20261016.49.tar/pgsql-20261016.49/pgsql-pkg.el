;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "20261016.49"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "61eb714f85f3142a8be998e5311f6cab62b9f29f"
  :revdesc "61eb714f85f3"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
