(define-package "srfi" "20220108.212" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "a47c0df8b5df36f5a8ca41f3f5dc60e1fbd09924" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
