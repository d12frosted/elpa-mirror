(define-package "uxntal-mode" "20230707.1623" "Major mode for Uxntal assembly"
  '((emacs "27.1"))
  :commit "0f0bb416d43a940ee7a057db075bf5804708dc5c" :authors
  '(("d_m" . "d_m@plastic-idolatry.com"))
  :maintainers
  '(("d_m" . "d_m@plastic-idolatry.com"))
  :maintainer
  '("d_m" . "d_m@plastic-idolatry.com")
  :url "https://github.com/non/uxntal-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
