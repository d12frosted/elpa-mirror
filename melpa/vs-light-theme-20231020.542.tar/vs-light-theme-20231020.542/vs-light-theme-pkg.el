(define-package "vs-light-theme" "20231020.542" "Visual Studio IDE light theme"
  '((emacs "24.1"))
  :commit "6d64f04575d9629ecf240f73fd8e051cae7f0127" :authors
  '(("Jen-Chieh Shen"))
  :maintainers
  '(("Jen-Chieh Shen"))
  :maintainer
  '("Jen-Chieh Shen")
  :url "https://github.com/emacs-vs/vs-light-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
