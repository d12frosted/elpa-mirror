(define-package "gumshoe" "20211015.1752" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "e530afd2e42bc560b3236cebeabdeaef0e33faca" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
