;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exec-in-buffer" "20250629.324"
  "Choose programs to execute on buffers in projects."
  '((emacs "24.1"))
  :url "https://github.com/arteen1000/exec-in-buffer"
  :commit "57ddaf95d46714ec1382f83ba952480b4cd0b73d"
  :revdesc "57ddaf95d467"
  :keywords '("tools" "c" "c++" "formatting" "projects")
  :authors '(("Arteen Abrishami" . "arteen@ucla.edu"))
  :maintainers '(("Arteen Abrishami" . "arteen@ucla.edu")))
