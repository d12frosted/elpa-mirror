;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dime" "20260212.8"
  "Dylan interaction mode."
  '((emacs "25.1")
    (dylan "3.0"))
  :url "https://opendylan.org/"
  :commit "c22f339b5394d26af4961192825e58ae766965ec"
  :revdesc "c22f339b5394")
