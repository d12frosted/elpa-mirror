;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ls-git" "20250417.1907"
  "The git project manager for helm."
  '((helm  "3.9.5")
    (emacs "25.3"))
  :url "https://github.com/emacs-helm/helm-ls-git"
  :commit "90e60d9171f91eea5037e9edb0002340b65bf0f9"
  :revdesc "90e60d9171f9"
  :keywords '("helm" "convenience" "vc" "files" "buffers" "completion" "diff" "log" "git"))
