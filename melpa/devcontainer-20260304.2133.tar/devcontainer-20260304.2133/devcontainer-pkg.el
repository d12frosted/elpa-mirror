;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20260304.2133"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "f1db36f5f3fa50f85487322143846e0648fcd6e4"
  :revdesc "f1db36f5f3fa"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
