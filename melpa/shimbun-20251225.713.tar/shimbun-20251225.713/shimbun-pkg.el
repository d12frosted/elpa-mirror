;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shimbun" "20251225.713"
  "Interfacing with web newspapers."
  ()
  :url "https://github.com/emacs-w3m/emacs-w3m"
  :commit "1669155d9aa074638d7fc7db0c356628d2c810fb"
  :revdesc "1669155d9aa0"
  :keywords '("news")
  :authors '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
             ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
             ("Yuuichi Teranishi" . "teranisi@gohome.org")
             ("Katsumi Yamaoka" . "yamaoka@jpl.org"))
  :maintainers '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
                 ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
                 ("Yuuichi Teranishi" . "teranisi@gohome.org")
                 ("Katsumi Yamaoka" . "yamaoka@jpl.org")))
