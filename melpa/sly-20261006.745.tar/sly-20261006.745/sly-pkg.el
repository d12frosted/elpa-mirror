;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20261006.745"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.5"))
  :url "https://github.com/joaotavora/sly"
  :commit "191fe38eaa83e4e7556a940aa4b234666215cced"
  :revdesc "191fe38eaa83"
  :keywords '("languages" "lisp" "sly"))
