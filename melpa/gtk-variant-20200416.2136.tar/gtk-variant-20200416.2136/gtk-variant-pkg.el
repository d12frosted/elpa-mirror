;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gtk-variant" "20200416.2136"
  "Set the GTK theme variant (titlebar color)."
  '((emacs "25.1"))
  :url "https://github.com/bepvte/gtk-variant.el"
  :commit "a60af277fbb52306c17663074cf9954dd6cea024"
  :revdesc "a60af277fbb5"
  :keywords '("frames" "gtk" "titlebar"))
