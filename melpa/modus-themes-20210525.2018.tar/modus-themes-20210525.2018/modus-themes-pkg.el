(define-package "modus-themes" "20210525.2018" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "8cd5d91fb0d3da66d41edd78a9ee5df068ba2a43" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
