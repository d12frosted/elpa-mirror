(define-package "dirvish" "20220323.1206" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "0ae07c9380a8246d104eabb4cc937b0d78a5cbb5" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
