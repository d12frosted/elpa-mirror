;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20261112.1817"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "a774ac4cba86c93300b14bb7bc4fcb8ca5b817c6"
  :revdesc "a774ac4cba86"
  :keywords '("tools" "convenience" "text"))
