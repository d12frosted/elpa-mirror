;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260207.1559"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b32e4d9bc26e7bf0f473f2f7e4ce1cda9b95dff8"
  :revdesc "b32e4d9bc26e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
