;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260609.1520"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "95100fbd47a10462fa4832216c45102604d3aadd"
  :revdesc "95100fbd47a1"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
