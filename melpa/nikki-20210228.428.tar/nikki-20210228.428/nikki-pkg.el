;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nikki" "20210228.428"
  "A simple diary mode."
  '((emacs "24.3"))
  :url "https://github.com/th994/nikki"
  :commit "b2ea20d04a061df88d72bd8dd0412a6e7876458d"
  :revdesc "b2ea20d04a06"
  :keywords '("convenience")
  :authors '(("Taiki Harada" . "thdev994@gmail.com"))
  :maintainers '(("Taiki Harada" . "thdev994@gmail.com")))
