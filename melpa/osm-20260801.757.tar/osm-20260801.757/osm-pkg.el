;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260801.757"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/osm"
  :commit "117a00204afd95c9ac2ef1016e31c67d5cd01268"
  :revdesc "117a00204afd"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
