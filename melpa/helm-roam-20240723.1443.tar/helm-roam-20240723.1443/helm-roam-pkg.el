;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-roam" "20240723.1443"
  "Helm command for org-roam."
  '((emacs    "24.1")
    (org      "9.3")
    (helm     "3.9.9")
    (org-roam "2.2.2"))
  :url "https://github.com/vhqr0/helm-roam"
  :commit "85222a9ea50c69b18c1e31a66cc70adb851967d5"
  :revdesc "85222a9ea50c"
  :keywords '("org-mode" "roam" "helm" "convenience")
  :authors '(("VHQR" . "zq_cmd@163.com"))
  :maintainers '(("VHQR" . "zq_cmd@163.com")))
