(define-package "spdx" "20220826.158" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "03e2065006fabf5a9529c1b061a1731e1f75bdd8" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
