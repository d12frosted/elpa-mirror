(define-package "affe" "20210810.823" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.7"))
  :commit "c4522daca0414f91cfcd6bdf22f96b30c99d0112" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
