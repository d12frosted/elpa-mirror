;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260215.340"
  "A q editing mode."
  '((emacs "24"))
  :url "https://github.com/psaris/q-mode"
  :commit "96b688fd94f6514ee4d9ec6c1b612dfbcae87011"
  :revdesc "96b688fd94f6"
  :keywords '("faces" "files" "q"))
