;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "20260901.1936"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "27.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "3fff0631a1f953cb00c9482714ce3f2f8a829084"
  :revdesc "3fff0631a1f9"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
