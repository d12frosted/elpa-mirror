(define-package "ebib" "20211014.1059" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "b829aac34b90471cb53960ac0c0186603d032946" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
