(define-package "eshell-command-not-found" "20240706.2228" "Integrate command-not-found in eshell"
  '((emacs "25.1"))
  :commit "6882c486fa26de0b1a891a36efb558b6d1ecbc24" :authors
  '(("Jaehyun Yeom" . "jae.yeom@gmail.com"))
  :maintainers
  '(("Jaehyun Yeom" . "jae.yeom@gmail.com"))
  :maintainer
  '("Jaehyun Yeom" . "jae.yeom@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/jaeyeom/eshell-command-not-found")
;; Local Variables:
;; no-byte-compile: t
;; End:
