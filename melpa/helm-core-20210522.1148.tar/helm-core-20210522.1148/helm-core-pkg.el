(define-package "helm-core" "20210522.1148" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "61cb9f2d0078213333a5e1ef428f9baf17eb2bb2")
;; Local Variables:
;; no-byte-compile: t
;; End:
