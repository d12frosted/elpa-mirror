;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code" "20260516.650"
  "Run Claude Code sessions."
  '((emacs         "28.1")
    (projectile    "2.5.0")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (markdown-mode "2.5"))
  :url "https://github.com/yuya373/claude-code-emacs"
  :commit "2d2595dd93186d5cfe45ae3c6a522106e79452a7"
  :revdesc "2d2595dd9318"
  :keywords '("tools" "convenience"))
