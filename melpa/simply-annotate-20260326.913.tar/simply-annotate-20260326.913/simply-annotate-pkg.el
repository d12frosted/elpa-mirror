;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260326.913"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "6f76275c08c730f667224a04a5a126d652a83315"
  :revdesc "6f76275c08c7"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
