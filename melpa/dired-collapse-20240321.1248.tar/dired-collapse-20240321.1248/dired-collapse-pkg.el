(define-package "dired-collapse" "20240321.1248" "Collapse unique nested paths in dired listing"
  '((dash "2.10.0")
    (f "0.19.0")
    (dired-hacks-utils "0.0.1"))
  :commit "c854688bf2973c8d66f8aaacafeb21f89e543b99" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("files"))
;; Local Variables:
;; no-byte-compile: t
;; End:
