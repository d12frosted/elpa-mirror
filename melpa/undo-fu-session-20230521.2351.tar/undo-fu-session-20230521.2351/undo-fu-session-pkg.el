(define-package "undo-fu-session" "20230521.2351" "Persistent undo, available between sessions"
  '((emacs "28.1"))
  :commit "834f551117b52e9f8aac7d6908d75c56cd9a2cd4" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-undo-fu-session")
;; Local Variables:
;; no-byte-compile: t
;; End:
