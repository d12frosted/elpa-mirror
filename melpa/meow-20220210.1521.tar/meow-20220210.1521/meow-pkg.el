(define-package "meow" "20220210.1521" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "af87729bbc7f90892bd48bd7ad432d1ef551e3ca" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
