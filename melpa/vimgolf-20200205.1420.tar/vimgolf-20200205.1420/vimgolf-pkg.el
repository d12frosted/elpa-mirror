;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vimgolf" "20200205.1420"
  "VimGolf interface for the One True Editor."
  ()
  :url "https://github.com/timvisher/vimgolf.el"
  :commit "f565447ed294898588a19438d56c116555d8c628"
  :revdesc "f565447ed294"
  :keywords '("games" "vimgolf" "vim")
  :authors '(("Tim Visher" . "tim.visher@gmail.com"))
  :maintainers '(("Tim Visher" . "tim.visher@gmail.com")))
