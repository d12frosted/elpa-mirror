;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dslide" "20241229.1209"
  "Domain Specific sLIDEs. Programmable Presentation."
  '((emacs "29.2"))
  :url "https://github.com/positron-solutions/dslide"
  :commit "a82ef64c7c9fcef2cfda4d4bd2903a145ade525b"
  :revdesc "a82ef64c7c9f"
  :keywords '("convenience" "org-mode" "presentation" "narrowing")
  :authors '(("Positron" . "contact@positron.solutions"))
  :maintainers '(("Positron" . "contact@positron.solutions")))
