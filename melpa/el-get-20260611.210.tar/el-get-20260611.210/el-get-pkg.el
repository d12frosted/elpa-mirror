;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-get" "20260611.210"
  "Manage the external elisp bits and pieces you depend upon."
  ()
  :url "http://www.emacswiki.org/emacs/el-get"
  :commit "08d9e5988ed7e4087901138ca565a2e8833a2a7a"
  :revdesc "08d9e5988ed7"
  :keywords '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
