(define-package "fpga" "20230913.1255" "FPGA & ASIC Utils"
  '((emacs "29.1")
    (company "0.9.13"))
  :commit "a217e07adf45322aa8643615843f6b6e1ee7ff45" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/gmlarumbe/fpga")
;; Local Variables:
;; no-byte-compile: t
;; End:
