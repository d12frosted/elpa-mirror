;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260102.1040"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "29f7f28f64bd7ddb673e64986edca409a5c4d35f"
  :revdesc "29f7f28f64bd"
  :keywords '("hypermedia"))
