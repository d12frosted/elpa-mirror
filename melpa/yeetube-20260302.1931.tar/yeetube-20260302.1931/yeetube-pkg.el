;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260302.1931"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs  "27.2")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "77e816972a70db86ad06ef10db56e0d8cecede5c"
  :revdesc "77e816972a70"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
