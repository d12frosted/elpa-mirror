(define-package "bbdb" "20220211.546" "The Insidious Big Brother Database for GNU Emacs" 'nil :commit "1172bd901e29f5c001d52ef521b2b3ae50f3110c" :maintainer
  '("Roland Winkler" . "winkler@gnu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
