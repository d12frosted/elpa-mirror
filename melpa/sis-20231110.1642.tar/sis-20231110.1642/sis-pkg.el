(define-package "sis" "20231110.1642" "Less manual switch for native or OS input source (input method)."
  '((emacs "25.1")
    (terminal-focus-reporting "0.0"))
  :commit "24bb3bca50c67855eba077aeeb3af86c18569aae" :keywords
  '("convenience")
  :url "https://github.com/laishulu/emacs-smart-input-source")
;; Local Variables:
;; no-byte-compile: t
;; End:
