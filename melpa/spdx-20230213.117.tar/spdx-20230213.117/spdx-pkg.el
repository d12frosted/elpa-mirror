(define-package "spdx" "20230213.117" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d0987bbd3566b31d4c750da3ee5b30b376561780" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
