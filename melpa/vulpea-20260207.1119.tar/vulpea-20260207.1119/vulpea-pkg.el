;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260207.1119"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "b7f72313c984192f32ba78e9e917436b3a2ca811"
  :revdesc "b7f72313c984"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
