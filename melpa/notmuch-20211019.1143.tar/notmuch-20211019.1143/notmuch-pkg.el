(define-package "notmuch" "20211019.1143" "run notmuch within emacs" 'nil :commit "93104f0d9de4fa2919896a55dfdd207bbaf22589" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
