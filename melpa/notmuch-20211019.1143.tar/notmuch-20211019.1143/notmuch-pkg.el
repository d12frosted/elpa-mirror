(define-package "notmuch" "20211019.1143" "run notmuch within emacs" 'nil :commit "2ce6c76a61c907b5d1d508e12255e83d9256937c" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
