(define-package "sideline-blame" "20230406.2312" "Show blame messages with sideline"
  '((emacs "27.1")
    (sideline "0.1.0")
    (vc-msg "1.1.1"))
  :commit "4d3343795bc95662adb65c85bcbb41947862699f" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "blame")
  :url "https://github.com/emacs-sideline/sideline-blame")
;; Local Variables:
;; no-byte-compile: t
;; End:
