(define-package "shen-elisp" "20180915.2028" "Shen implementation in Elisp"
  '((emacs "24.4"))
  :commit "73b74c8d6e3a2ea34b667d177d9f130765bfe501" :authors
  (("Aditya Siram" . "aditya.siram@gmail.com"))
  :maintainer
  ("Aditya Siram" . "aditya.siram@gmail.com")
  :url "https://github.com/deech/shen-elisp")
;; Local Variables:
;; no-byte-compile: t
;; End:
