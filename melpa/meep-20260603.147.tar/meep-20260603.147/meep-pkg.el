;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260603.147"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "3f5ccd3782d12bb334fe36e619cede0e16196183"
  :revdesc "3f5ccd3782d1"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
