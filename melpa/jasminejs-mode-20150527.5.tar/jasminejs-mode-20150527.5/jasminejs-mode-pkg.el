(define-package "jasminejs-mode" "20150527.5" "A minor mode for manipulating jasmine test files" 'nil :commit "23637d6718423d376eebbdaa4d6d914c7cab26ed" :authors
  '(("Eric Stolten" . "stoltene2@gmail.com"))
  :maintainer
  '("Eric Stolten" . "stoltene2@gmail.com")
  :keywords
  '("javascript" "jasmine")
  :url "https://github.com/stoltene2/jasminejs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
