(define-package "repl-driven-development" "20231005.142" "Send arbitrary code to a REPL in the background"
  '((s "1.12.0")
    (lf "1.0")
    (dash "2.16.0")
    (eros "0.1.0")
    (bind-key "2.4.1")
    (emacs "29.1")
    (f "0.20.0")
    (devdocs "0.5")
    (pulsar "1.0.1"))
  :commit "f532e9c7f8e655a1029836eb7d5c94700129aedb" :authors
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainer
  '("Musa Al-hassy" . "alhassy@gmail.com")
  :keywords
  '("repl-driven-development" "rdd" "repl" "lisp" "java" "python" "ruby" "programming" "convenience")
  :url "http://alhassy.com/repl-driven-development")
;; Local Variables:
;; no-byte-compile: t
;; End:
