;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-desktop-notify" "20250616.816"
  "Gnus Desktop Notification global minor mode."
  '((gnus "1.0"))
  :url "http://www.thregr.org/~wavexx/software/gnus-desktop-notify.el/"
  :commit "344777f35a65f0cf76bf29ea97c6f4b6880aed4a"
  :revdesc "344777f35a65"
  :authors '(("Yuri D'Elia" . "wavexxATthregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexxATthregr.org")))
