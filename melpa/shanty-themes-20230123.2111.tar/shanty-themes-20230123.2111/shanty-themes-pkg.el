(define-package "shanty-themes" "20230123.2111" "The themes for digital workers"
  '((emacs "24.5.1"))
  :commit "3f678d953771c4a109bd16f6d7def6bd9bbc811d" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
