(define-package "org-category-capture" "20230816.1231" "Contextualy capture of org-mode TODOs."
  '((org "9.0.0")
    (emacs "24"))
  :commit "418ec0311ff3dde2578930d834cdb507158797e7" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "todo" "tools" "outlines")
  :url "https://github.com/IvanMalison/org-project-capture")
;; Local Variables:
;; no-byte-compile: t
;; End:
