(define-package "universal-sidecar" "20230923.31" "A universal sidecar buffer"
  '((emacs "26.1")
    (magit-section "3.0.0"))
  :commit "0cec1fa196df55cfb13c1e2ee226b55ff740e7f2" :authors
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainer
  '("Samuel W. Flint" . "me@samuelwflint.com")
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar")
;; Local Variables:
;; no-byte-compile: t
;; End:
