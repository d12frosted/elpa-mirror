(define-package "sway" "20230906.712" "Communication with the Sway window manager"
  '((emacs "28.1"))
  :commit "425005713af1e9269f1d5b5221fb4ea3046f52e4" :authors
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainers
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainer
  '("Thibault Polge" . "thibault@thb.lt")
  :keywords
  '("frames")
  :url "https://github.com/thblt/sway.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
