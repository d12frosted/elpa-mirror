(define-package "org-gtd" "20230218.1624" "An implementation of GTD."
  '((emacs "27.1")
    (org-edna "1.1.2")
    (f "0.20.0")
    (org "9.6")
    (org-agenda-property "1.3.1")
    (transient "0.3.7"))
  :commit "59c0905c8832845a36666f45b04bcc8ba8194f39" :authors
  '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainer
  '("Aldric Giacomoni" . "trevoke@gmail.com")
  :url "https://github.com/Trevoke/org-gtd.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
