;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-opener" "20161207.1810"
  "Opening urls as buffers in evil."
  '((evil   "1.2.12")
    (opener "0.2.2"))
  :url "https://github.com/0robustus1/opener.el"
  :commit "c384f67278046fdcd220275fdd212ab85672cbeb"
  :revdesc "c384f6727804"
  :keywords '("url" "http" "files")
  :authors '(("Tim Reddehase" . "tr@rightsrestricted.com"))
  :maintainers '(("Tim Reddehase" . "tr@rightsrestricted.com")))
