;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20250331.149"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "2f98fe1dfc1b14e0756e1c235f58fc668b441dec"
  :revdesc "2f98fe1dfc1b"
  :keywords '("languages"))
