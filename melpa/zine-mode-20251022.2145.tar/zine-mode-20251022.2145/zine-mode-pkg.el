;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zine-mode" "20251022.2145"
  "Major mode for zine, the static site generator."
  '((emacs         "29.1")
    (reformatter   "0.6")
    (markdown-mode "2.8-alpha")
    (ziggy-mode    "0.0.2"))
  :url "https://github.com/dcolazin/zine-mode"
  :commit "e54a3bde1f8ea5ed00b91c7bf038329a9b0da174"
  :revdesc "e54a3bde1f8e"
  :authors '(("2024 Robbie Lyman" . "rb.lymn@gmail.com"))
  :maintainers '(("Davide Colazingari" . "dcolazin@gmail.com")))
