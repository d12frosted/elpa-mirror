(define-package "package-build" "20230428.1928" "Tools for assembling a package archive"
  '((emacs "26.1"))
  :commit "82677d41a8a7d601a11a39791d44f883df2ce2c5" :authors
  '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
    ("Steve Purcell" . "steve@sanityinc.com")
    ("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers
  '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainer
  '("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
  :keywords
  '("maint" "tools")
  :url "https://github.com/melpa/package-build")
;; Local Variables:
;; no-byte-compile: t
;; End:
