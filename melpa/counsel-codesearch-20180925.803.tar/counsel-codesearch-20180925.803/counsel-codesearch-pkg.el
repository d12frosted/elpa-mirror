;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-codesearch" "20180925.803"
  "Counsel interface for codesearch.el."
  '((codesearch "1")
    (counsel    "0.10.0")
    (emacs      "24")
    (ivy        "0.10.0"))
  :url "https://github.com/abingham/emacs-counsel-codesearch"
  :commit "b7989fad3e06f301c31d5e896c42b6cc549a0e0c"
  :revdesc "b7989fad3e06"
  :keywords '("tools")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
