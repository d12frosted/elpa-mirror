(define-package "tok-theme" "20220202.1805" "My theme"
  '((emacs "24.3"))
  :commit "5df42d3f5569d9005f9180337aa88befaf77c491" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
