;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260905.500"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "af960f74746b8d4875ee480811907b7f9a1c8e0e"
  :revdesc "af960f74746b"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
