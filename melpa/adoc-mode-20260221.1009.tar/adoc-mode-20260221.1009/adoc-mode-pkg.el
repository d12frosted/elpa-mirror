;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260221.1009"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "6fc5ebc9478de17b1971222485e7729f04fbcf57"
  :revdesc "6fc5ebc9478d"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
