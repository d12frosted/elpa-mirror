;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash" "20260223.741"
  "Flash-style navigation."
  '((emacs "27.1"))
  :url "https://github.com/Prgebish/flash"
  :commit "a2163d3a288fb8a31c598b0bfb62979f27947d6d"
  :revdesc "a2163d3a288f"
  :keywords '("convenience" "navigation")
  :authors '(("Vadim Pavlov" . "https://github.com/Prgebish"))
  :maintainers '(("Vadim Pavlov" . "https://github.com/Prgebish")))
