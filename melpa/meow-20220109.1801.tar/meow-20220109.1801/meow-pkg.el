(define-package "meow" "20220109.1801" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "1689b2861c6e23afc2ec4376c341ceb0470b8f5d" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
