(define-package "affe" "20230301.337" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.32"))
  :commit "21a6c74157b02388f429e8d5f8c910d04aa16f08" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
