;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskpaper-mode" "20241005.834"
  "Major mode for working with TaskPaper files."
  '((emacs "25.1"))
  :url "https://github.com/saf-dmitry/taskpaper-mode"
  :commit "29284dde520673dfaa83cce1b686e8df0670510e"
  :revdesc "29284dde5206"
  :keywords '("outlines" "notetaking" "task management" "productivity" "taskpaper")
  :authors '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainers '(("Dmitry Safronov" . "saf.dmitry@gmail.com")))
