(define-package "cnfonts" "20230225.2139" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "f42f417e84af020e6dfd51ebb4b1c605001b96b6" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
