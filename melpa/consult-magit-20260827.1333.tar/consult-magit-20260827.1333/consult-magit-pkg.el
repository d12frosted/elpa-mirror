;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-magit" "20260827.1333"
  "Switch and manage magit buffers with consult."
  '((emacs   "28.1")
    (consult "1.0")
    (magit   "3.0"))
  :url "https://github.com/nhojb/consult-magit"
  :commit "8d030b9927b7e6c3b08066380dfaa9ea5c19026e"
  :revdesc "8d030b9927b7"
  :keywords '("convenience" "vc" "tools")
  :authors '(("John Buckley" . "nhoj.buckley@gmail.com"))
  :maintainers '(("John Buckley" . "nhoj.buckley@gmail.com")))
