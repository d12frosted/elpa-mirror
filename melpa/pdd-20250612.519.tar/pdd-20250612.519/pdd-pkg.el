;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250612.519"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "b276cf42c2db4cf9f8eb2f624b88af2486f838e2"
  :revdesc "b276cf42c2db"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
