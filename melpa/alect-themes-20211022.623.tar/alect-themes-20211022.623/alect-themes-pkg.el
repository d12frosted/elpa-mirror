(define-package "alect-themes" "20211022.623" "Configurable light, dark and black themes for Emacs 24 or later"
  '((emacs "24.0"))
  :commit "1dfa1dc278e4ccf2b9232d39b239159aeaa3dba2" :authors
  '(("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  '("Alex Kost" . "alezost@gmail.com")
  :keywords
  '("color" "theme")
  :url "https://github.com/alezost/alect-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
