;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teacode-expand" "20181231.640"
  "Expansion of text by TeaCode program."
  '((emacs "24.4"))
  :url "https://github.com/raguay/TeaCode-Expand"
  :commit "7df6f9ec95da1fb47bbae489bb3f2c27ed3a9b3a"
  :revdesc "7df6f9ec95da"
  :keywords '("lisp")
  :authors '(("Richard Guay" . "raguay@customct.com"))
  :maintainers '(("Richard Guay" . "raguay@customct.com")))
