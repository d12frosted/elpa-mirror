;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gerrit" "20251105.1900"
  "Gerrit client."
  '((emacs "28.2")
    (magit "2.13.1")
    (s     "1.12.0")
    (dash  "0.2.15"))
  :url "https://github.com/thisch/gerrit.el"
  :commit "fd136c1134c6a8ee2be7ca3fc33fc47d349b3511"
  :revdesc "fd136c1134c6"
  :keywords '("extensions")
  :authors '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainers '(("Thomas Hisch" . "t.hisch@gmail.com")))
