(define-package "jsdoc" "20230331.647" "Insert JSDoc comments"
  '((emacs "29.1")
    (dash "2.11.0")
    (s "1.12.0"))
  :commit "10606a37f70cbf419590bbbc292fe1e800435ed5" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/jsdoc.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
