;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260118.36"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "314b167ce85807895a1025c692ed4e73e1709b77"
  :revdesc "314b167ce858"
  :keywords '("convenience"))
