(define-package "llama" "20240907.1202" "Compact syntax for short lambda"
  '((emacs "26.1"))
  :commit "85fb21ca30be475ead68ab5dfabdc28410992673" :keywords
  '("extensions")
  :url "https://github.com/tarsius/llama")
;; Local Variables:
;; no-byte-compile: t
;; End:
