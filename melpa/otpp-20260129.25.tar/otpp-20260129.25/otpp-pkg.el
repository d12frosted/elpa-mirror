;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260129.25"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "f6d2f021ebfbaead14ba44662a365d42ed037dc9"
  :revdesc "f6d2f021ebfb"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
