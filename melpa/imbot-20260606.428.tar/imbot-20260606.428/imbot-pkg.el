;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260606.428"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "69d1551bbca9c991a4cfe3ccb133d862854ee1c7"
  :revdesc "69d1551bbca9"
  :keywords '("convenience" "input method" "dbus"))
