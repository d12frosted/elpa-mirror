(define-package "gpt" "20221227.559" "Run instruction-following language models"
  '((emacs "24.4"))
  :commit "a6c88faea5d754ade16b0d6250996ae6eb798d20" :authors
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainer
  '("Andreas Stuhlmueller" . "andreas@ought.org")
  :keywords
  '("gpt3" "language" "copilot" "convenience" "tools")
  :url "https://github.com/stuhlmueller/gpt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
