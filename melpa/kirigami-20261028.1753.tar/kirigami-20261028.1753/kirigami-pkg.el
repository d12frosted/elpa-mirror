;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20261028.1753"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "655890f0c49707f2c94a1652ab016f4eadf506fb"
  :revdesc "655890f0c497"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
