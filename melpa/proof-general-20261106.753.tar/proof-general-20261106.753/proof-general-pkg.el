;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261106.753"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "d8a41be1c5280d171aa5a55969a9e4576bdfcb34"
  :revdesc "d8a41be1c528"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
