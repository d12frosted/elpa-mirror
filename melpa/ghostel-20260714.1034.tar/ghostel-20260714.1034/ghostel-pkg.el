;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260714.1034"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "1978b3ed6e3c8be0edc9835a1364a2305ac5f181"
  :revdesc "1978b3ed6e3c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
