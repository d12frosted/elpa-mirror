;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess" "20241207.1936"
  "Emacs Speaks Statistics."
  '((emacs         "26.1")
    (polymode      "0.2.2")
    (poly-R        "0.2.2")
    (poly-noweb    "0.2.2")
    (poly-markdown "0.2.2"))
  :url "https://github.com/emacs-ess/ESS"
  :commit "462b3fad7d7fcc8ca1da3d7ace57a42884403b04"
  :revdesc "462b3fad7d7f"
  :authors '(("David Smith" . "dsmith@stats.adelaide.edu.au")
             ("A.J. Rossini" . "blindglobe@gmail.com")
             ("Richard M. Heiberger" . "rmh@temple.edu")
             ("Kurt Hornik" . "Kurt.Hornik@R-project.org")
             ("Martin Maechler" . "maechler@stat.math.ethz.ch")
             ("Rodney A. Sparapani" . "rsparapa@mcw.edu")
             ("Stephen Eglen" . "stephen@gnu.org")
             ("Sebastian P. Luque" . "spluque@gmail.com")
             ("Henning Redestig" . "henning.red@googlemail.com")
             ("Vitalie Spinu" . "spinuvit@gmail.com")
             ("Lionel Henry" . "lionel.hry@gmail.com")
             ("J. Alexander Branham" . "alex.branham@gmail.com"))
  :maintainers '(("ESS Core Team" . "ESS-core@r-project.org")))
