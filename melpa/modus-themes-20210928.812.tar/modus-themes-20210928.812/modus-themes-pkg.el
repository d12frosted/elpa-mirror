(define-package "modus-themes" "20210928.812" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "2b27c14d792f08da6650c566cd3a58b9b3405be8" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
