(define-package "package-build" "20220828.1519" "Tools for assembling a package archive"
  '((emacs "25.1"))
  :commit "ac2abd863047e5437398f5d58fe38c4a17062401" :authors
  '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
    ("Steve Purcell" . "steve@sanityinc.com")
    ("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainer
  '("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
  :keywords
  '("maint" "tools")
  :url "https://github.com/melpa/package-build")
;; Local Variables:
;; no-byte-compile: t
;; End:
