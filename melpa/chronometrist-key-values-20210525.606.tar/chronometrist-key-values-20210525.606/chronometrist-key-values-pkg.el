(define-package "chronometrist-key-values" "20210525.606" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "4fdfe4d0c892c180abf23319d47d63160914bd98" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "gemini://tilde.team/~contrapunctus/software.gmi")
;; Local Variables:
;; no-byte-compile: t
;; End:
