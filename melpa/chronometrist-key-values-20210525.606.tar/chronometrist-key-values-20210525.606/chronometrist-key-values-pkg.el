(define-package "chronometrist-key-values" "20210525.606" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "9d7076a30bd8832e3965c5e2e35e2ba3440b6319" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "gemini://tilde.team/~contrapunctus/software.gmi")
;; Local Variables:
;; no-byte-compile: t
;; End:
