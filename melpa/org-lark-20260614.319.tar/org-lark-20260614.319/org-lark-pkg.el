;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "20260614.319"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "ebbe9ed102be2bf00b698f1280a305d8f3b0d38d"
  :revdesc "ebbe9ed102be"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
