;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar" "20261116.1729"
  "Citation-related commands for org, latex, markdown."
  '((emacs    "29.1")
    (parsebib "4.2")
    (org      "9.5")
    (citeproc "0.9"))
  :url "https://github.com/emacs-citar/citar"
  :commit "a256578fdaa42892103172394d9dc86c2bf461ec"
  :revdesc "a256578fdaa4"
  :authors '(("Bruce D'Arcus" . "https://github.com/bdarcus"))
  :maintainers '(("Bruce D'Arcus" . "https://github.com/bdarcus")))
