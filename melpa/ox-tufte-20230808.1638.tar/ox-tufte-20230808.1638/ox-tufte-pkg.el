(define-package "ox-tufte" "20230808.1638" "Tufte HTML org-mode export backend"
  '((org "9.5")
    (emacs "27.1"))
  :commit "8419da9eff55802e6191476242923cfa6d680f72" :authors
  '(("M. Lee Hinman"))
  :maintainers
  '(("The Bayesians Inc."))
  :maintainer
  '("The Bayesians Inc.")
  :keywords
  '("org" "tufte" "html" "outlines" "hypermedia" "calendar" "wp")
  :url "https://github.com/ox-tufte/ox-tufte")
;; Local Variables:
;; no-byte-compile: t
;; End:
