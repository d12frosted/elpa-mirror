(define-package "meow" "20211210.1625" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "04c36643904751abdec88787c1129d7b2fa0d5e3" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
