(define-package "meow" "20211210.1625" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "8d11275e18bac4e12b5b2794d67fb82a5e0e2468" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
