(define-package "meow" "20211210.1625" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "6aa14bcee5d8fad5c0346a95aa9ccfab79682ca3" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
