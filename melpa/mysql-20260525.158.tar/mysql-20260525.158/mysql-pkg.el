;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20260525.158"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "e302bce83b933dc46ed22e29b2a467b11fee495c"
  :revdesc "e302bce83b93"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
