;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250609.1751"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.3")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "bd0abf4af7723f5ad59798dc6ccef3034779acdc"
  :revdesc "bd0abf4af772"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
