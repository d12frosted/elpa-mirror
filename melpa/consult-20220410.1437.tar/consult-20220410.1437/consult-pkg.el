(define-package "consult" "20220410.1437" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "c0bdc7030ec484043e7d60360f1abf517bbdaf2c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
