;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg-marginalia" "20260511.1534"
  "Show Epkg information in completion annotations."
  '((emacs      "28.1")
    (compat     "30.1")
    (cond-let   "1.1")
    (epkg       "4.1")
    (marginalia "2.9"))
  :url "https://github.com/emacscollective/epkg-marginalia"
  :commit "9e994d33b997a677a47716f966e4390131738247"
  :revdesc "9e994d33b997"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev")))
