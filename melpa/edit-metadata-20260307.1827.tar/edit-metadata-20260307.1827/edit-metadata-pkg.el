;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-metadata" "20260307.1827"
  "Edit embedded metadata."
  '((exiftool "0.3.2")
    (emacs    "28.1")
    (compat   "29.1"))
  :url "https://codeberg.org/mxpi/edit-metadata"
  :commit "52f7b4818e7a9335fd51bfc6198d8a52e14b2d1f"
  :revdesc "52f7b4818e7a"
  :keywords '("files" "multimedia")
  :authors '(("Michael Piotrowski" . "mxp@dynalabs.de"))
  :maintainers '(("Michael Piotrowski" . "mxp@dynalabs.de")))
