(define-package "pyim-basedict" "20220528.2314" "The default pinyin dict of pyim" 'nil :commit "c606c34101b2c07352ee6bf16f90abeac26a2f2c" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/tumashu/pyim-basedict")
;; Local Variables:
;; no-byte-compile: t
;; End:
