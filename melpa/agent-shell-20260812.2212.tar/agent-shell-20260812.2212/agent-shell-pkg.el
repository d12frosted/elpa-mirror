;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260812.2212"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e57d6a851cc460307c100d5ff0649fd978b65b85"
  :revdesc "e57d6a851cc4")
