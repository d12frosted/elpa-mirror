;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20241128.928"
  "LSP mode."
  '((emacs         "27.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "6b60f98eb16bb5419c55136050bb795a8d1a0e92"
  :revdesc "6b60f98eb16b"
  :keywords '("languages"))
