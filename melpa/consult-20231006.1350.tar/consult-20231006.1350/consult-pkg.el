(define-package "consult" "20231006.1350" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "41c18d408716222558e02e19a7db7a1afb40dace" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
