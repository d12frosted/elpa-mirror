(define-package "friendly-shell" "20220309.1711" "Better shell-mode API"
  '((emacs "24.1")
    (cl-lib "0.6.1")
    (dash "2.17.0")
    (with-shell-interpreter "0.2.4"))
  :commit "e530e359848e8bdad09d26529f17eb25e5558b3e" :keywords
  '("processes" "terminals")
  :url "https://github.com/p3r7/friendly-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
