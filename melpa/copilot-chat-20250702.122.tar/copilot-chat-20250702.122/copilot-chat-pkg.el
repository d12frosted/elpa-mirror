;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20250702.122"
  "Copilot chat interface."
  '((emacs         "29.1")
    (aio           "1.0")
    (request       "0.3.2")
    (transient     "0.8.3")
    (polymode      "0.2.2")
    (org           "9.4.6")
    (markdown-mode "2.6")
    (shell-maker   "0.76.2"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "77b3ab4a17be62036da5d86af1e2cf0b6d4f881d"
  :revdesc "77b3ab4a17be"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
