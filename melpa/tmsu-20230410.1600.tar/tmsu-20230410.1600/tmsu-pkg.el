(define-package "tmsu" "20230410.1600" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "256d1913ca900bb3c79af8d064bfa6675c14b8b7" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
