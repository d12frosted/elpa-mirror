(define-package "ado-mode" "20210113.315" "Major mode for editing Stata-related files"
  '((emacs "24.1"))
  :commit "29d56532c7ab6f680c596add31fd80cd79186e89" :authors
  '(("Bill Rising" . "brising@alum.mit.edu"))
  :maintainer
  '("Bill Rising" . "brising@alum.mit.edu")
  :keywords
  '("tools" "languages" "files" "convenience" "stata" "mata" "ado")
  :url "https://github.com/louabill/ado-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
