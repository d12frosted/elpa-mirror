(define-package "ghub" "20230212.2209" "Client libraries for Git forge APIs."
  '((emacs "25.1")
    (compat "29.1.3.4")
    (let-alist "1.0.6")
    (treepy "0.1.1"))
  :commit "47b7dc9bb299d50647cd24efebaf41dbc07d9e90" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
