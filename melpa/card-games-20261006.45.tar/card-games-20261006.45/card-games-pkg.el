;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "card-games" "20261006.45"
  "Play card games (console + SVG)."
  '((emacs "26.1"))
  :url "https://code.bru.st/corwin/card-game.el"
  :commit "74af63a089756424897f6a80e6bb3f9838994658"
  :revdesc "74af63a08975"
  :keywords '("games")
  :authors '(("Corwin Brust" . "corwin@bru.st"))
  :maintainers '(("Corwin Brust" . "corwin@bru.st")))
