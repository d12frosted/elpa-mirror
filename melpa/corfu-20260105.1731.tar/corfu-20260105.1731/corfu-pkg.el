;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20260105.1731"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "4a71080bd9b8cd9804a45c07129f0fb03c4ebdfc"
  :revdesc "4a71080bd9b8"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
