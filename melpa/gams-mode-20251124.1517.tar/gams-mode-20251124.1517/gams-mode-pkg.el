;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-mode" "20251124.1517"
  "Major mode for General Algebraic Modeling System (GAMS)."
  '((emacs "25.1"))
  :url "https://github.com/ShiroTakeda/gams-mode"
  :commit "dfab98a2ef847bae4bc3ae3abdf638355efd73db"
  :revdesc "dfab98a2ef84"
  :keywords '("languages" "tools" "gams"))
