(define-package "ejc-sql" "20230219.605" "Emacs SQL client uses Clojure JDBC."
  '((emacs "26.3")
    (clomacs "0.0.5")
    (dash "2.16.0")
    (spinner "1.7.3"))
  :commit "c9a602efd4b3a1b607c630e55e3124d4a63048fb" :authors
  '(("Kostafey" . "kostafey@gmail.com"))
  :maintainer
  '("Kostafey" . "kostafey@gmail.com")
  :keywords
  '("sql" "jdbc")
  :url "https://github.com/kostafey/ejc-sql")
;; Local Variables:
;; no-byte-compile: t
;; End:
