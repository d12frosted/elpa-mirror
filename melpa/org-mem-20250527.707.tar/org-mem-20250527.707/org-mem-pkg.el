;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250527.707"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "6cc8d52b302745d977914f84c08fea04b1c3f0b9"
  :revdesc "6cc8d52b3027"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
