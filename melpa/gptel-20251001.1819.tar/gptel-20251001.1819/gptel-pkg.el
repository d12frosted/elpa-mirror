;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251001.1819"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "29b731784184440efb51e7aee6eff060e88ee08b"
  :revdesc "29b731784184"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
