(define-package "simple-call-tree" "20240706.506" "analyze source code based on font-lock text-properties"
  '((emacs "24.3")
    (anaphora "1.0.0"))
  :commit "6a85489676be6a5cf7a606fcd384f4b26f8de8c2" :authors
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("programming")
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
