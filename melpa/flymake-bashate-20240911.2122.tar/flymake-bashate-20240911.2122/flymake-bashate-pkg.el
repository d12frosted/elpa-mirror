(define-package "flymake-bashate" "20240911.2122" "A Flymake backend for bashate, a Bash scripts style checker"
  '((flymake-quickdef "1.0.0")
    (emacs "26.1"))
  :commit "e375a5235d77a3e8a296ce2b942ef9d996228dbb" :keywords
  '("tools")
  :url "https://github.com/jamescherti/flymake-bashate.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
