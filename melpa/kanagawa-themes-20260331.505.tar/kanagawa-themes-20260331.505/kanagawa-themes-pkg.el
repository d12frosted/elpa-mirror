;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kanagawa-themes" "20260331.505"
  "Elegant theme inspired by The Great Wave off Kanagawa."
  '((emacs "24.3"))
  :url "https://github.com/Fabiokleis/kanagawa-emacs"
  :commit "6f1bf124d0cfad0d081ae4ca9d8b0a25b98f18f6"
  :revdesc "6f1bf124d0cf"
  :keywords '("themes" "faces")
  :authors '(("Mrjtjmn" . "meritamen@sdf.org"))
  :maintainers '(("Fabio Kleis" . "fabiohkrc@gmail.com")
                 ("Mrjtjmn" . "meritamen@sdf.org")))
