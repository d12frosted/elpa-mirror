(define-package "ebib" "20210809.1349" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "831ffcca35601e169c0778035688c5d17d138b58" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
