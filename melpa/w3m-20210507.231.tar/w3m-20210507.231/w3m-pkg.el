(define-package "w3m" "20210507.231" "an Emacs interface to w3m" 'nil :commit "67675533a6ee7003cbd5106450ef1025bead5d67" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
