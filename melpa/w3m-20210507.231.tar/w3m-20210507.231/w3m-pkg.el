(define-package "w3m" "20210507.231" "an Emacs interface to w3m" 'nil :commit "7fdb9bb2d067b11ac64800c35ff045d70d86d580" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
