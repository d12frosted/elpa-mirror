(define-package "w3m" "20210507.231" "an Emacs interface to w3m" 'nil :commit "d5ca99db36e7e75b151329de63c98e3b4cf6bc8b" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
