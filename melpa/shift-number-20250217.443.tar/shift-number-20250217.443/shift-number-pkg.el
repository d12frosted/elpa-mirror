;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shift-number" "20250217.443"
  "Increase/decrease the number at point."
  '((emacs "24.1"))
  :url "https://github.com/alezost/shift-number.el"
  :commit "5ba437d7ac206885148c65ea59582a7a4730f4c4"
  :revdesc "5ba437d7ac20"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
