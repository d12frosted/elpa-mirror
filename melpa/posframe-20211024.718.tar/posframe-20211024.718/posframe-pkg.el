(define-package "posframe" "20211024.718" "Pop a posframe (just a frame) at point"
  '((emacs "26"))
  :commit "cd4f8d20f14c13423368c08af95cda1aa17ae1e6" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
