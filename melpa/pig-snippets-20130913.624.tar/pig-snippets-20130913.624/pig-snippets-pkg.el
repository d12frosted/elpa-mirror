(define-package "pig-snippets" "20130913.624" "Snippets for pig-mode"
  '((yasnippet "0.8.0"))
  :commit "4c6c6e1b1bb719d8adc6c47cc24665f6fe558959")
;; Local Variables:
;; no-byte-compile: t
;; End:
