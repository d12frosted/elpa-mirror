(define-package "grugru" "20210115.847" "Rotate text at point"
  '((emacs "24.4"))
  :commit "d48811bd449ebfd7c029fa336183ea7c140fff3c" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
