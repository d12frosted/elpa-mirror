;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260220.1418"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "4bccd24fc680238f8d29fee1629401f620d50ca6"
  :revdesc "4bccd24fc680"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
