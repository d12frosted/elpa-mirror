;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "launch" "20130619.2204"
  "Launch files with OS-standard associated applications."
  ()
  :url "https://github.com/sfllaw/emacs-launch"
  :commit "e7c3b573fc05fe4d3d322389079909311542e799"
  :revdesc "e7c3b573fc05"
  :keywords '("convenience" "processes")
  :authors '(("Simon Law" . "sfllaw@sfllaw.ca"))
  :maintainers '(("Simon Law" . "sfllaw@sfllaw.ca")))
