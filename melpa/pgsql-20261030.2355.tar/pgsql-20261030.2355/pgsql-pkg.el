;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "20261030.2355"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "adf4ca1d5997e492bb30f133f12b8960df73c73f"
  :revdesc "adf4ca1d5997"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
