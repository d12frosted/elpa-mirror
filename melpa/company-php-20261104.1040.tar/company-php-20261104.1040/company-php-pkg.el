;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-php" "20261104.1040"
  "A company back-end for PHP."
  '((cl-lib      "0.5")
    (ac-php-core "2.0")
    (company     "0.9"))
  :url "https://github.com/xcwen/ac-php"
  :commit "c2132776a121362fbe3b83535348ded1ee671d03"
  :revdesc "c2132776a121"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
