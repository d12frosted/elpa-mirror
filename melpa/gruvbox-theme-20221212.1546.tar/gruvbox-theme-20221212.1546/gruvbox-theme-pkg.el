(define-package "gruvbox-theme" "20221212.1546" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "8afb82da23b998c17868d1d84c149b1ff4563373" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
