(define-package "consult" "20220406.1136" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "e9fa6ab2258f015fad3d3e87764872125bc57374" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
