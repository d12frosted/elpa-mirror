(define-package "nova-theme" "20230824.401" "A dark, pastel color theme"
  '((emacs "24.3"))
  :commit "c11aea3ce572cc940bc201cb5a33c0d2014cf8c4" :authors
  '(("Muir Manders" . "muir+emacs@mnd.rs"))
  :maintainers
  '(("Muir Manders" . "muir+emacs@mnd.rs"))
  :maintainer
  '("Muir Manders" . "muir+emacs@mnd.rs")
  :keywords
  '("theme" "dark" "nova" "pastel" "faces")
  :url "https://github.com/muirmanders/emacs-nova-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
