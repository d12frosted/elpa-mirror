;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "20260601.1213"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "30.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "b8e8f7841a2f0a3abfef510d3a78b5214ae8f296"
  :revdesc "b8e8f7841a2f"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
