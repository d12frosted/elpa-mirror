;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-static-blog" "20260413.1402"
  "A simple org-mode based static blog generator."
  '((emacs "24.3"))
  :url "https://github.com/bastibe/org-static-blog"
  :commit "353fcde0aa27ce11c3513fb4d25ac49fb0b9c57d"
  :revdesc "353fcde0aa27")
