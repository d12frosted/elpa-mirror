(define-package "tuareg" "20210827.1713" "OCaml mode for Emacs."
  '((emacs "24.4")
    (caml "4.8")
    (cl-lib "0.5"))
  :commit "ef1ec3fd191085c4013344de8f2c850ef0c6a40f" :authors
  '(("Albert Cohen" . "Albert.Cohen@inria.fr")
    ("Sam Steingold" . "sds@gnu.org")
    ("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
    ("Till Varoquaux" . "till@pps.jussieu.fr")
    ("Sean McLaughlin" . "seanmcl@gmail.com")
    ("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainer
  '("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/tuareg")
;; Local Variables:
;; no-byte-compile: t
;; End:
