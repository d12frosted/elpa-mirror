;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251214.934"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "1ac37ee6748adfe40371c335d7165cee6b4cd182"
  :revdesc "1ac37ee6748a"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
