(define-package "w3m" "20210817.327" "an Emacs interface to w3m" 'nil :commit "d7166799bd93cf90f77cb9e4c59cb691bb3a1b8c" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
