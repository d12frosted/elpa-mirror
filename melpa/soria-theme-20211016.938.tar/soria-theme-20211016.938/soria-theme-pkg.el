(define-package "soria-theme" "20211016.938" "A xoria256 theme with some colors from openSUSE"
  '((emacs "25.1"))
  :commit "8321f8a59e711532f9469dfbc95663b396d2ad28" :authors
  '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainer
  '("Miquel Sabaté Solà" . "mikisabate@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/mssola/soria")
;; Local Variables:
;; no-byte-compile: t
;; End:
