;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260703.1529"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "cd2e6a663eae2d4fe1c8628d090104b5c2148876"
  :revdesc "cd2e6a663eae")
