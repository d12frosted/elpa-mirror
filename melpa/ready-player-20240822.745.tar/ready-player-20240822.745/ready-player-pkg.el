(define-package "ready-player" "20240822.745" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "10fd98bf722b617fbb742dd89348f3b3896515ba" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
