;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251106.800"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "bbaa20a45bd0563e7ae48cc4b84e5d3998308d5e"
  :revdesc "bbaa20a45bd0"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
