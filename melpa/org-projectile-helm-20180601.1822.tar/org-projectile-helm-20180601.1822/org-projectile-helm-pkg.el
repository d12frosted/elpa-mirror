(define-package "org-projectile-helm" "20180601.1822" "helm functions for org-projectile"
  '((org-projectile "1.0.0")
    (helm "2.3.1")
    (emacs "25"))
  :commit "674e3cdda4a3ea4bdcc369dae032d49dfb5c5765" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org" "projectile" "todo" "helm" "outlines")
  :url "https://github.com/IvanMalison/org-projectile")
;; Local Variables:
;; no-byte-compile: t
;; End:
