;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250228.1402"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.76.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "b6b2dc335024f580a3527b0ceb320c3ec2f2c31a"
  :revdesc "b6b2dc335024")
