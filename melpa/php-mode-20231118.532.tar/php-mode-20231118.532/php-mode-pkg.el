(define-package "php-mode" "20231118.532" "Major mode for editing PHP code"
  '((emacs "26.1"))
  :commit "1565b0db7d547d4e339ce7aaf27653eafc705090" :authors
  '(("Eric James Michael Ritz"))
  :maintainers
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
