;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260125.2250"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "204e7b140105e0c996f65b3bf112567756edf741"
  :revdesc "204e7b140105"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
