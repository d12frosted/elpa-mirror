;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-history" "20100505.839"
  "Integration with shell history."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/shell-history.el"
  :commit "ee371a81f2d2bf5a308344078329ca1e9b5ed38c"
  :revdesc "ee371a81f2d2"
  :keywords '("processes" "convenience")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
