(define-package "mb-url" "20211029.2220" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "670d31edc0938c49c77d80543c6b2a955edadf85" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
