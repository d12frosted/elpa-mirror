;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocaml-eglot" "20260819.1639"
  "An OCaml companion for Eglot."
  '((emacs "29.1"))
  :url "https://github.com/tarides/ocaml-eglot"
  :commit "909a786934e7b02d5b8556a4f242a1fa3374d095"
  :revdesc "909a786934e7"
  :keywords '("ocaml" "languages")
  :authors '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com"))
  :maintainers '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com")))
