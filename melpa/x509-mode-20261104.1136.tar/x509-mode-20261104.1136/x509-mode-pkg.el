;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261104.1136"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "f52a1d9da3a6a49ebf32736596571435de5f10ea"
  :revdesc "f52a1d9da3a6"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
