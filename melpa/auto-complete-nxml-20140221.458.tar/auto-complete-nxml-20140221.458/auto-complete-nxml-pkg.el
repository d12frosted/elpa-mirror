;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-nxml" "20140221.458"
  "Do completion by auto-complete.el on nXML-mode."
  '((auto-complete "1.4"))
  :url "https://github.com/aki2o/auto-complete-nxml"
  :commit "ac7b09a23e45f9bd02affb31847263de4180163a"
  :revdesc "ac7b09a23e45"
  :keywords '("completion" "html" "xml")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
