;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250530.1422"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "28.1")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "006e7e21d81ad3a4c4d3ff251e68bbc8fdc30eaa"
  :revdesc "006e7e21d81a"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
