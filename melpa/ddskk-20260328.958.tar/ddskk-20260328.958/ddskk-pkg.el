;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk" "20260328.958"
  "Daredevil SKK (Simple Kana to Kanji conversion program)."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :url "https://github.com/skk-dev/ddskk"
  :commit "c3836d9a9e6e8497bd419c11d5a59667464491a8"
  :revdesc "c3836d9a9e6e"
  :keywords '("japanese" "mule" "input method")
  :authors '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp")))
