;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "20260927.555"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "9c197392d5ef8c68e8923ac1de01a7e5383f1f85"
  :revdesc "9c197392d5ef"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
