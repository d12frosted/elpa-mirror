;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocamlformat" "20260317.1629"
  "Utility functions to format ocaml code."
  '((emacs "24.3"))
  :url "https://github.com/ocaml-ppx/ocamlformat"
  :commit "195e470387ecdcfb0f9ce309b0d8d17807bde25d"
  :revdesc "195e470387ec"
  :keywords '("languages" "ocaml"))
