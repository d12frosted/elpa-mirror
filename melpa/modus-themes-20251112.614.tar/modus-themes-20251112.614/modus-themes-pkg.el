;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251112.614"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "3b0850883ab1f7c5446fb12217e779426565741c"
  :revdesc "3b0850883ab1"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
