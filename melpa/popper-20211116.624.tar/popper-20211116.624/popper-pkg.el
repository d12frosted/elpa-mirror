(define-package "popper" "20211116.624" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "4d58a6dbba5d488ff9ac9318e202d84da505e691" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
