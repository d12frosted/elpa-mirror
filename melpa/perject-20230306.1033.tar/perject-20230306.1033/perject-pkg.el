(define-package "perject" "20230306.1033" "Session-persistent project management"
  '((emacs "27.1")
    (dash "2.10")
    (transient "0.3.7"))
  :commit "82d007ec7201c21d8dd31d95e857632887582be6" :authors
  '(("overideal"))
  :maintainers
  '(("overideal"))
  :maintainer
  '("overideal")
  :url "https://github.com/overideal/perject")
;; Local Variables:
;; no-byte-compile: t
;; End:
