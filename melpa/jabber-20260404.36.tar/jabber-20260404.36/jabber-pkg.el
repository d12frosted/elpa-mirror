;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260404.36"
  "XMPP/Jabber client."
  '((emacs "29.1")
    (fsm   "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-jabber"
  :commit "02005d1d7f1ef2dae252897c2517b1c342bc20df"
  :revdesc "02005d1d7f1e"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
