(define-package "humanoid-themes" "20210520.2212" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "09ec7a3da848f24d232578fc7e4ac5ff4a7736c7" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
