;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260330.228"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "424c835bc46ed083088e82e2fcd48c2e1c34bacf"
  :revdesc "424c835bc46e"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
