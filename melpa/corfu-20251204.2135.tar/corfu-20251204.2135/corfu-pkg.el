;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251204.2135"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "144959455bf4e6f6479502659e7d0b540dfa1a82"
  :revdesc "144959455bf4"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
