;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260805.801"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "59e549a84aac390091d288629f7f84fdc82454c9"
  :revdesc "59e549a84aac"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
