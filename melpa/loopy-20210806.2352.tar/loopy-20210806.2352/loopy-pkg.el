(define-package "loopy" "20210806.2352" "A looping macro" 'nil :commit "71815b60c87d465961a390d8f253b3a9663859c3" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
