;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260330.1947"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "602c1629056cbe9994390c29cd0d02f56d57b73c"
  :revdesc "602c1629056c"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
