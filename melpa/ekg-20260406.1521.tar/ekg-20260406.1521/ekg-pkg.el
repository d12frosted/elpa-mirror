;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260406.1521"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "057a8949a6cd512fc7a7c1628a51987642d87a6c"
  :revdesc "057a8949a6cd"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
