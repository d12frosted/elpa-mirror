;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-gt" "20260906.1838"
  "Improvements for org-roam."
  '((emacs    "30.1")
    (org      "9.8")
    (org-roam "2.2.2"))
  :url "https://github.com/dmgerman/org-roam-gt"
  :commit "7b06c24e10eb2faf3323142137c7393e0045bb1e"
  :revdesc "7b06c24e10eb"
  :keywords '("outlines" "hypermedia")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
