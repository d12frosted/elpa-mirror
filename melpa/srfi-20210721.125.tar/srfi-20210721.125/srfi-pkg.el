(define-package "srfi" "20210721.125" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "de1fdca07229e5d43c18cb3dc300397849eeab78" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
