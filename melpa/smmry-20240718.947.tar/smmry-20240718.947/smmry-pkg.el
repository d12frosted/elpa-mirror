;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smmry" "20240718.947"
  "SMMRY client."
  ()
  :url "https://github.com/microamp/smmry.el"
  :commit "d3473b139430d221b4c4587dae685cd67a02c099"
  :revdesc "d3473b139430"
  :keywords '("api" "smmry")
  :authors '(("Sangho Na" . "sangho@nsh.nz"))
  :maintainers '(("Sangho Na" . "sangho@nsh.nz")))
