;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "call-graph" "20251226.1055"
  "Generate call graph for c/c++ functions."
  '((emacs     "28.1")
    (tree-mode "1.0.0")
    (ivy       "0.10.0")
    (beacon    "1.3.4"))
  :url "https://github.com/beacoder/call-graph"
  :commit "8e2bd21b31fbd8f774df1d03204efba95112262b"
  :revdesc "8e2bd21b31fb"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
