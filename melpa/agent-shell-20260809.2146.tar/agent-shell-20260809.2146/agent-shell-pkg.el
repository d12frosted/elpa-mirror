;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260809.2146"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.96.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "81de2124cd155cc2f5f8ca6d2a3cf1063470e048"
  :revdesc "81de2124cd15")
