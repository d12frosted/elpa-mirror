(define-package "sculpture-themes" "20220330.1824" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "d4f311fbe0d5ac6b6622afd0d84cf976e0a96153" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
