(define-package "ahg" "20221013.916" "Alberto's Emacs interface for Mercurial (Hg)" 'nil :commit "8f0dc52dedcf20e1662c964c6577cfb737381505" :authors
  '(("Alberto Griggio" . "agriggio@users.sourceforge.net"))
  :maintainers
  '(("Alberto Griggio" . "agriggio@users.sourceforge.net"))
  :maintainer
  '("Alberto Griggio" . "agriggio@users.sourceforge.net")
  :url "https://bitbucket.org/agriggio/ahg")
;; Local Variables:
;; no-byte-compile: t
;; End:
