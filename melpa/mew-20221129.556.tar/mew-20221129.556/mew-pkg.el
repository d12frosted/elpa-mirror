(define-package "mew" "20221129.556" "Messaging in the Emacs World" 'nil :commit "7ab02416029d0f15580efa3c4c3ff39f32d7c0ad" :authors
  '(("Kazu Yamamoto" . "Kazu@Mew.org"))
  :maintainer
  '("Kazu Yamamoto" . "Kazu@Mew.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
