;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260112.1904"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.3")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "cb6051874933640a1f7131cc90f80d8f15f40b1a"
  :revdesc "cb6051874933"
  :keywords '("programming"))
