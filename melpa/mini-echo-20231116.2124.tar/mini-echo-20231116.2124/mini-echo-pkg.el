(define-package "mini-echo" "20231116.2124" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "2793a21472375ed01ec97922ceb0fa6df7a40b33" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
