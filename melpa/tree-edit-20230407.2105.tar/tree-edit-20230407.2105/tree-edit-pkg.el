(define-package "tree-edit" "20230407.2105" "A library for structural refactoring and editing"
  '((emacs "29.0")
    (dash "2.19")
    (reazon "0.4.0")
    (s "0.0.0"))
  :commit "86aef84896d67bcc61923663f799ab8dba05d108" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
