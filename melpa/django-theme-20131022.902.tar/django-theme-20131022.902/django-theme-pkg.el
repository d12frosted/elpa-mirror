;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "django-theme" "20131022.902"
  "Custom face theme for Emacs."
  ()
  :url "http://github/anrzejsliwa/django-theme"
  :commit "86c8142b3eb1addd94a43aa6f1d98dab06401af0"
  :revdesc "86c8142b3eb1")
