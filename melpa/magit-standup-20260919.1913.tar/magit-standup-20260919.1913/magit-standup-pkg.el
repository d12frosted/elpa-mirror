;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-standup" "20260919.1913"
  "Collect recent git commits for standup notes."
  '((emacs     "28.1")
    (magit     "4.5.0")
    (transient "0.8.0"))
  :url "https://github.com/function-artisans/magit-standup"
  :commit "d7ae3175f0ff9bd5d911cf6586e8614c2b447ff6"
  :revdesc "d7ae3175f0ff"
  :keywords '("tools" "vc")
  :authors '(("István Karaszi" . "ikaraszi@gmail.com"))
  :maintainers '(("István Karaszi" . "ikaraszi@gmail.com")))
