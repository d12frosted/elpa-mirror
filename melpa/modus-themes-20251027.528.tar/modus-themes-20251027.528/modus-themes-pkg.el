;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251027.528"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "f7ac5a6aa067f7db9b862d86ba144a8431ac2712"
  :revdesc "f7ac5a6aa067"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
