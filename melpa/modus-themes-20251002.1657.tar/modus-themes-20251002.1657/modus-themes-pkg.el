;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251002.1657"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "3e091098f0292acbb1be80cf6af56adfa2ab4df1"
  :revdesc "3e091098f029"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
