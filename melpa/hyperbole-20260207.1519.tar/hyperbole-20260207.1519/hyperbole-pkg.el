;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260207.1519"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "7e1ec9cd90f69f8ba4d1290c59ae472027a51be6"
  :revdesc "7e1ec9cd90f6"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
