;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "init-dir" "20260830.2045"
  "Init directory instead of just a single file."
  '((emacs          "27.1")
    (benchmark-init "1.2"))
  :url "https://github.com/chaosemer/init-dir"
  :commit "c3218e445fe851c007e7f7981b239d69bb8033b3"
  :revdesc "c3218e445fe8"
  :keywords '("extensions" "internal")
  :authors '(("Jared Finder" . "jared@finder.org"))
  :maintainers '(("Jared Finder" . "jared@finder.org")))
