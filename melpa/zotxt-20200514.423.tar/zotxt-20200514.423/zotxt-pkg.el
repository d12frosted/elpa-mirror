(define-package "zotxt" "20200514.423" "Tools to integrate emacs with Zotero via the zotxt plugin."
  '((request "0.3.2")
    (deferred "0.5.1"))
  :commit "63f13c794b165d047867d8e688cd17ae91bad858" :authors
  '(("Erik Hetzner" . "egh@e6h.org"))
  :maintainer
  '("Erik Hetzner" . "egh@e6h.org")
  :keywords
  '("bib"))
;; Local Variables:
;; no-byte-compile: t
;; End:
