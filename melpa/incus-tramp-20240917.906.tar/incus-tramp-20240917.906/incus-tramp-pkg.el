;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "incus-tramp" "20240917.906"
  "TRAMP integration for Incus containers."
  '((emacs "24.4"))
  :url "https://gitlab.com/lckarssen/incus-tramp.git"
  :commit "dfeb8381bcde28209bafb45b03bb8d6795aedb61"
  :revdesc "dfeb8381bcde"
  :keywords '("incus" "convenience")
  :authors '(("Lennart C. Karssen" . "lennart@karssen.org"))
  :maintainers '(("Lennart C. Karssen" . "lennart@karssen.org")))
