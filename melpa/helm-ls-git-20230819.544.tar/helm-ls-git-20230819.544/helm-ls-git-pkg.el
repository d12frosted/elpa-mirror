(define-package "helm-ls-git" "20230819.544" "list git files."
  '((helm "1.7.8"))
  :commit "82fbb05faa5a38547195d372637de779a9aff0b7")
;; Local Variables:
;; no-byte-compile: t
;; End:
