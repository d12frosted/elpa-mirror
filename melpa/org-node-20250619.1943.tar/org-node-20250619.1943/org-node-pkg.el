;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250619.1943"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.16.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "d5c6cefe993e8737270165ebb788e904365728aa"
  :revdesc "d5c6cefe993e"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
