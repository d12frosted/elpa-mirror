;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260208.757"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "11ddace991f63e98212be400570d85d716d2db83"
  :revdesc "11ddace991f6"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
