(define-package "apropospriate-theme" "20230310.2249" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "99e492804de96a0bb98fa058c4c86908132b4cf7" :authors
  '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainer
  '("Justin Talbott" . "justin@waymondo.com")
  :url "http://github.com/waymondo/apropospriate-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
