;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "holy-books" "20261015.356"
  "Org-mode links/tooltips/lookups for Quran & Bible."
  '((s     "1.12.0")
    (dash  "2.16.0")
    (emacs "27.1")
    (org   "9.1"))
  :url "https://alhassy.github.io/holy-books/"
  :commit "4f88779b5beabad81d6b08def3162a83539d9311"
  :revdesc "4f88779b5bea"
  :keywords '("quran" "bible" "links" "tooltips" "convenience" "comm" "hypermedia")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
