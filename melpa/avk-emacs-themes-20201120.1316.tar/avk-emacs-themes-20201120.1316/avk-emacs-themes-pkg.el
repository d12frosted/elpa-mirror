(define-package "avk-emacs-themes" "20201120.1316" "Collection of avk themes" 'nil :commit "d35a50520c0ddfcf04a0d72eb64fead68039e8d8" :url "https://github.com/avkoval/avk-emacs-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
