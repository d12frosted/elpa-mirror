(define-package "consult" "20210208.132" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "bdcf836224bc9b5c0ae2ef402684090dfcaf48fb" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
