;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260130.1654"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "2563f41361d36e6b223f66819228396a0f6b74e5"
  :revdesc "2563f41361d3"
  :keywords '("convenience"))
