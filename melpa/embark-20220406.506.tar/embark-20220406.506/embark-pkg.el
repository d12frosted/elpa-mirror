(define-package "embark" "20220406.506" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "ba1762b7846301fec6c18bfb5ba2125db572a5db" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
