;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "himalaya" "20260219.1107"
  "Interface for the email client Himalaya CLI."
  '((emacs "27.1"))
  :url "https://github.com/dantecatalfamo/himalaya-emacs"
  :commit "e308694ef60b211bad2a70c46a1566ef0b985f2e"
  :revdesc "e308694ef60b"
  :keywords '("mail" "comm")
  :authors '(("soywod" . "clement.douin@posteo.net"))
  :maintainers '(("soywod" . "clement.douin@posteo.net")))
