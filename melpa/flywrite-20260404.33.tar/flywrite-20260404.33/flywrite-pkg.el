;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flywrite" "20260404.33"
  "Inline writing suggestions via LLM."
  '((emacs "29.1"))
  :url "https://github.com/awdeorio/flywrite"
  :commit "174d72ed77a72e0b5751062caa4cae1a853f9974"
  :revdesc "174d72ed77a7"
  :keywords '("text" "wp")
  :authors '(("Andrew DeOrio" . "awdeorio@umich.edu"))
  :maintainers '(("Andrew DeOrio" . "awdeorio@umich.edu")))
