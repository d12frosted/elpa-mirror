(define-package "spdx" "20230106.115" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "151f49fa95a6c593aa694c6bd7ded6d3a04479b1" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
