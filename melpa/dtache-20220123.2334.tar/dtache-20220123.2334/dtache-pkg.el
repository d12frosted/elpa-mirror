(define-package "dtache" "20220123.2334" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "01deeaae00af1a661c11f87c7d35586f60a6f640" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
