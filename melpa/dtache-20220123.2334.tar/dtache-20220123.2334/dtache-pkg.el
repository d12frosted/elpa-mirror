(define-package "dtache" "20220123.2334" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "cdeb7dcf3ba3780c470e9649fcd77afb885195bd" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
