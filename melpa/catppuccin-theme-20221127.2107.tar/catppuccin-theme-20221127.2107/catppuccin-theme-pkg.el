(define-package "catppuccin-theme" "20221127.2107" "Catppuccin Theme"
  '((emacs "25.1"))
  :commit "c4fc122b75b4a5d1d051c2a0e19a0eb0aa51501b" :authors
  '(("pspiagicw"))
  :maintainer
  '("Name" . "namesexistsinemails@gmail.com")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
