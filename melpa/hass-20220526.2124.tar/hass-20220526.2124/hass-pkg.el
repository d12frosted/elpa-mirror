(define-package "hass" "20220526.2124" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3"))
  :commit "5da5404c8de483ca70dcab13ad07805f1b37e4bd" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
