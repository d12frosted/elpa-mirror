;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "20241223.1051"
  "Explore and visualise Denote files."
  '((emacs  "29.1")
    (denote "3.1")
    (dash   "2.19.1"))
  :url "https://github.com/pprevos/denote-explore"
  :commit "5ad2cb513f61de5b5b293e92237185016643a93a"
  :revdesc "5ad2cb513f61"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
