(define-package "timu-spacegrey-theme" "20230911.2108" "Color theme inspired by the Spacegray theme in Sublime Text"
  '((emacs "26.1"))
  :commit "c4d027ae7f6e6c2ccbb5e274b6dc58fff3c44434" :authors
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainer
  '("Aimé Bertrand" . "aime.bertrand@macowners.club")
  :keywords
  '("faces" "themes")
  :url "https://gitlab.com/aimebertrand/timu-spacegrey-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
