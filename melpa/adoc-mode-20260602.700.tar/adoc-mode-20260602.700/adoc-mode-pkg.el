;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260602.700"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "24523d5da6de9dc7641b5987129d3b34798cefa5"
  :revdesc "24523d5da6de"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
