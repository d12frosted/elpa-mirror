(define-package "ssh-deploy" "20210626.2228" "Deployment via Tramp, global or per directory."
  '((emacs "25"))
  :commit "7c68d80422037cc9fdbd1e8b66142c9314dca193" :authors
  '(("Christian Johansson" . "christian@cvj.se"))
  :maintainer
  '("Christian Johansson" . "christian@cvj.se")
  :keywords
  '("tools" "convenience")
  :url "https://github.com/cjohansson/emacs-ssh-deploy")
;; Local Variables:
;; no-byte-compile: t
;; End:
