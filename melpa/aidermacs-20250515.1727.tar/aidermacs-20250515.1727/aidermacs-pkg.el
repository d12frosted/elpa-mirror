;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250515.1727"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "e829b9e2964a41aa1b1754c44dd46031fb2d5d0d"
  :revdesc "e829b9e2964a"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
