;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260412.1314"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "0f6038896e27910750a21c5fc16334034ad2c830"
  :revdesc "0f6038896e27"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
