(define-package "flymake-eslint" "20230928.1554" "A Flymake backend for Javascript using eslint"
  '((emacs "26.1"))
  :commit "879344bd55383d6e1acc179b97888ff926c3b2c9" :authors
  '(("Dan Orzechowski"))
  :maintainers
  '(("Dan Orzechowski"))
  :maintainer
  '("Dan Orzechowski")
  :keywords
  '("languages" "tools")
  :url "https://github.com/orzechowskid/flymake-eslint")
;; Local Variables:
;; no-byte-compile: t
;; End:
