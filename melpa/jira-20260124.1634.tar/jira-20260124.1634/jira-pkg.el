;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20260124.1634"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "5be4bb3d02d7d1afeafc1789f232cb37e9d9622c"
  :revdesc "5be4bb3d02d7"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
