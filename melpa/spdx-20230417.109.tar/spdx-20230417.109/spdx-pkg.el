(define-package "spdx" "20230417.109" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "5c550a62fb659499d1bd3508494644109fee1e04" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
