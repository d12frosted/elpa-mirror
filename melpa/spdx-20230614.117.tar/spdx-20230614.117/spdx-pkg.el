(define-package "spdx" "20230614.117" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "20bfbbd4aa226fc52b0f4a04b58cce348ad39cd6" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
