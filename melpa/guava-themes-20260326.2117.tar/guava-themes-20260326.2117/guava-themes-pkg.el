;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260326.2117"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "2857fcf25bc6ac0f7d39f9ec75d35a5d57190f0a"
  :revdesc "2857fcf25bc6"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
