(define-package "org-mac-link" "20231001.1136" "Insert org-mode links to items selected in various Mac apps"
  '((emacs "27.1"))
  :commit "a74c0b0a7ea444c1d9e5a3574724be8fb232d10b" :authors
  '(("Anthony Lander" . "anthony.lander@gmail.com")
    ("John Wiegley" . "johnw@gnu.org")
    ("Christopher Suckling <suckling at gmail dot com>")
    ("Daniil Frumin" . "difrumin@gmail.com")
    ("Alan Schmitt" . "alan.schmitt@polytechnique.org")
    ("Mike McLean" . "mike.mclean@pobox.com"))
  :maintainers
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainer
  '("Aimé Bertrand" . "aime.bertrand@macowners.club")
  :keywords
  '("files" "wp" "url" "org")
  :url "https://gitlab.com/aimebertrand/org-mac-link")
;; Local Variables:
;; no-byte-compile: t
;; End:
