;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nickel-mode" "20261027.1210"
  "A major mode for editing Nickel source code."
  '((emacs "24.3"))
  :url "https://github.com/nickel-lang/nickel-mode"
  :commit "ff523bc1def96ff76d909ec661ab358a7695f631"
  :revdesc "ff523bc1def9"
  :keywords '("languages" "configuration-language" "configuration" "nickel" "infrastructure")
  :authors '(("The Nickel Team" . "(nickel-lang@tweag.io)"))
  :maintainers '(("The Nickel Team" . "(nickel-lang@tweag.io)")))
