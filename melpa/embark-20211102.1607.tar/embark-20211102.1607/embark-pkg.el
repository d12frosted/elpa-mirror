(define-package "embark" "20211102.1607" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "810544f9fcb8e0ddf0d9b89682c208e2127f8f13" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
