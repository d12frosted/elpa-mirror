;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260607.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "b9dcb0970e87be36c1e597481c76141c9892e44a"
  :revdesc "b9dcb0970e87"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
