(define-package "chronometrist" "20220215.1904" "Friendly and powerful personal time tracker and analyzer"
  '((emacs "27.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "e6df8138eef45cf149cdb8b4d77e8ef289f7aaa7" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
