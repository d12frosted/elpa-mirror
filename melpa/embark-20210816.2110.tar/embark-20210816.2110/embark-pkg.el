(define-package "embark" "20210816.2110" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "2192ddeffcf1e8555091b62cf547dc80c110a33a" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
