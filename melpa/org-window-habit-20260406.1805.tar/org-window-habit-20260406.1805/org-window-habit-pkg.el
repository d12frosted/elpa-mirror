;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20260406.1805"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "dcf1d7b896bd2c0a706c00c0d0daab2fa9e49828"
  :revdesc "dcf1d7b896bd"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
