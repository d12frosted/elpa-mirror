;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordcount-section" "20260314.1744"
  "Universal Sidecar Section to show Word Counts."
  '((emacs             "28.1")
    (compat            "29.1")
    (universal-sidecar "1.5.1"))
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar"
  :commit "3b6bd928f7adb840e62a63dd5bf1236ece912b13"
  :revdesc "3b6bd928f7ad"
  :keywords '("text" "convenience")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
