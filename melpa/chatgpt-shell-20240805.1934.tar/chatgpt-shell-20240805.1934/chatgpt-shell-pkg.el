(define-package "chatgpt-shell" "20240805.1934" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.50.5"))
  :commit "fe75c5d516b149c635cda97627e8f920f277d36e" :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
