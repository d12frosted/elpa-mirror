(define-package "butler" "20150812.8" "Emacs client for Jenkins"
  '((deferred "0.3.2")
    (json "1.2")
    (emacs "24"))
  :commit "8ceb35737107572455cca9a61ff46b3ff78f1016")
;; Local Variables:
;; no-byte-compile: t
;; End:
