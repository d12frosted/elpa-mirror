(define-package "el-get" "20210613.1418" "Manage the external elisp bits and pieces you depend upon" 'nil :commit "8842fa434c79549f78fe5f9ca7ef1ff318376726" :authors
  '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainer
  '("Dimitri Fontaine" . "dim@tapoueh.org")
  :keywords
  '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :url "http://www.emacswiki.org/emacs/el-get")
;; Local Variables:
;; no-byte-compile: t
;; End:
