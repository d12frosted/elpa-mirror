;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buttercup" "20260411.2019"
  "Behavior-Driven Emacs Lisp Testing."
  '((emacs "24.4"))
  :url "https://github.com/jorgenschaefer/emacs-buttercup"
  :commit "57d03004cc730678bcdefb91ad294824975cfea4"
  :revdesc "57d03004cc73"
  :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainers '(("Ola Nilsson" . "ola.nilsson@gmail.com")))
