;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-mode" "20251124.838"
  "Major mode for General Algebraic Modeling System (GAMS)."
  '((emacs "25.1"))
  :url "https://github.com/ShiroTakeda/gams-mode"
  :commit "783b7810f208b7dd0b74029ced34db085d70df28"
  :revdesc "783b7810f208"
  :keywords '("languages" "tools" "gams"))
