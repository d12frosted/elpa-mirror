(define-package "moe-theme" "20221227.1141" "A colorful eye-candy theme. Moe, moe, kyun!" 'nil :commit "67b36749595aeb7c15295562c49252477a69a7fa" :authors
  '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainer
  '("kuanyui" . "azazabc123@gmail.com")
  :keywords
  '("themes")
  :url "https://github.com/kuanyui/moe-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
