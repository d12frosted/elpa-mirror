(define-package "creamsody-theme" "20220819.754" "Straight from the soda fountain"
  '((autothemer "0.2")
    (emacs "24"))
  :commit "0823101e9886cc31cc48f2d79f354a4fd2c2b9f3" :url "http://github.com/emacsfodder/emacs-theme-creamsody")
;; Local Variables:
;; no-byte-compile: t
;; End:
