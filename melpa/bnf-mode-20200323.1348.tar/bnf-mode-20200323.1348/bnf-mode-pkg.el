(define-package "bnf-mode" "20200323.1348" "Major mode for editing BNF grammars."
  '((cl-lib "0.5")
    (emacs "24.3"))
  :commit "2d1ee12f3ba6e75841066bf429d7bf836d4b89d7" :authors
  '(("Serghei Iakovlev" . "egrep@protonmail.ch"))
  :maintainer
  '("Serghei Iakovlev" . "egrep@protonmail.ch")
  :keywords
  '("languages")
  :url "https://github.com/sergeyklay/bnf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
