(define-package "elfeed-web" "20210226.258" "web interface to Elfeed"
  '((simple-httpd "1.5.1")
    (elfeed "3.2.0")
    (emacs "24.3"))
  :commit "243add9e74003cd5718f33482b7bb8b4fe140fb5" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/elfeed")
;; Local Variables:
;; no-byte-compile: t
;; End:
