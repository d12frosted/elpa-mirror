;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251210.946"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.2")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c80932f299e72a56d31a11db45d1adfc5f9f6429"
  :revdesc "c80932f299e7")
