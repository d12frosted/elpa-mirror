;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imgur" "20241201.1257"
  "Imgur client."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/imgur"
  :commit "9a7f47d6da3f6a7365f8575c0403f05398ad05c5"
  :revdesc "9a7f47d6da3f"
  :keywords '("convenience" "imgur" "client")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
