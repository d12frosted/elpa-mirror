(define-package "modus-themes" "20220315.448" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "6a1e155198858624cb8b14107b6df12d708a7283" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
