(define-package "tmsu" "20230430.1243" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "c92497b9b5282864cde2a9e0f507fd8b78e0400e" :authors
  '(("Wojciech Siewierski"))
  :maintainers
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
