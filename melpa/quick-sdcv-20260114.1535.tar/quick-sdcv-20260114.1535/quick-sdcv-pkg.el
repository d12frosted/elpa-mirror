;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20260114.1535"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "10be5e6d499da524000d1b6891080d01d5b9a949"
  :revdesc "10be5e6d499d"
  :keywords '("docs" "startdict" "sdcv"))
