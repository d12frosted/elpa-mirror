;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "20260112.1241"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "a061c1be82d13906ca83d4e4b591c8b6bf7c6326"
  :revdesc "a061c1be82d1"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
