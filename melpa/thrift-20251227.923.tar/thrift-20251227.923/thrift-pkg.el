;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20251227.923"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "749e4d12818e6d0b6edbd256db5d100a0e0c3c14"
  :revdesc "749e4d12818e"
  :keywords '("languages"))
