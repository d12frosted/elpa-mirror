(define-package "helm" "20240521.633" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.8")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "055ea7e3219f2177108bf226d25318af69faa265" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
