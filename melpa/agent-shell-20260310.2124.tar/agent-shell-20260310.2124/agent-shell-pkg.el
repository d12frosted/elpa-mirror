;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260310.2124"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "586528b562eae7c0fb43b13a79b62429add7bf9d"
  :revdesc "586528b562ea")
