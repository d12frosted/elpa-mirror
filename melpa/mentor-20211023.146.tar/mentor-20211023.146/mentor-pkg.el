(define-package "mentor" "20211023.146" "Frontend for the rTorrent bittorrent client"
  '((emacs "25.1")
    (xml-rpc "1.6.15")
    (seq "1.11")
    (cl-lib "0.5")
    (async "1.9.3"))
  :commit "b94a8747eb3ad16b00f83917a5b9017eb8aa9ec6" :authors
  '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainer
  '("Stefan Kangas" . "stefankangas@gmail.com")
  :keywords
  '("comm" "processes" "bittorrent"))
;; Local Variables:
;; no-byte-compile: t
;; End:
