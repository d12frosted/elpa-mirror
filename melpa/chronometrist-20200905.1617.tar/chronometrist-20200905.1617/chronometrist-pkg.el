(define-package "chronometrist" "20200905.1617" "A time tracker with a nice interface"
  '((emacs "25.1")
    (dash "2.16.0")
    (seq "2.20")
    (s "1.12.0")
    (ts "0.2")
    (anaphora "1.0.4"))
  :commit "ad2a7fffed94c093e6d83a6938115f66e4e888f3" :keywords
  ("calendar")
  :authors
  (("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  ("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :url "https://github.com/contrapunctus-1/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
