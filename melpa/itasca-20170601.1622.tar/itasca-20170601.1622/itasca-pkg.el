;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "itasca" "20170601.1622"
  "Major modes for Itasca software data files."
  '((emacs "24.3"))
  :url "https://github.com/jkfurtney/itasca-emacs/"
  :commit "3d15dd1b70d6db69b0f4758a3e28b8b506cc84ca"
  :revdesc "3d15dd1b70d6"
  :keywords '("itasca" "flac" "3dec" "udec" "flac3d" "pfc" "pfc2d" "pfc3d" "fish")
  :authors '(("Jason Furtney" . "jkfurtney@gmail.com"))
  :maintainers '(("Jason Furtney" . "jkfurtney@gmail.com")))
