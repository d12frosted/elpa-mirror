(define-package "pygn-mode" "20230401.1858" "Major-mode for chess PGN files, powered by Python"
  '((emacs "26.1")
    (tree-sitter "0.15.2")
    (tree-sitter-langs "0.10.7")
    (uci-mode "0.5.4")
    (nav-flash "1.0.0")
    (ivy "0.10.0"))
  :commit "8d290f69ce64a5e6f310ffa42c44fd781c20bcfd" :authors
  '(("Dodge Coates and Roland Walker"))
  :maintainers
  '(("Dodge Coates and Roland Walker"))
  :maintainer
  '("Dodge Coates and Roland Walker")
  :keywords
  '("data" "games" "chess")
  :url "https://github.com/dwcoates/pygn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
