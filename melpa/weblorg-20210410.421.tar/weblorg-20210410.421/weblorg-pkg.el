(define-package "weblorg" "20210410.421" "Static Site Generator for org-mode"
  '((templatel "0.1.5")
    (emacs "26.1"))
  :commit "66bf957ace451ad0140e77d2fea235aefcd9ae26" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
