;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260112.2223"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e855e181e40a10dc440f26086ac2b4a51c0dbe66"
  :revdesc "e855e181e40a")
