(define-package "timesheet" "20191024.151" "Timesheet management add-on for org-mode"
  '((s "1")
    (org "7")
    (auctex "11"))
  :commit "5098dc87d3d4f289b6c1b6532070dacbfe6de9fd" :authors
  '(("Tom Marble"))
  :maintainer
  '("Tom Marble")
  :keywords
  '("org" "timesheet")
  :url "https://github.com/tmarble/timesheet.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
