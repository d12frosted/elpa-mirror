(define-package "howm" "20221210.1121" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "b8b3a4c48c9df05f31dcca60cc65eabfae8b3f6c" :authors
  '(("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
