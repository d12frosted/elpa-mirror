(define-package "lacquer" "20220321.720" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "0d7d09f7fe22fb0241e91228ce44568ed3e3e798" :authors
  '(("dingansich_kum0" . "zy.hua1122@outlook.com"))
  :maintainer
  '("dingansich_kum0" . "zy.hua1122@outlook.com")
  :keywords
  '("tools")
  :url "https://github.com/dingansichKum0/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
