(define-package "embark" "20221201.2022" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "bdabc5396a935edb8bfd2104b67703b110fad6ef" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
