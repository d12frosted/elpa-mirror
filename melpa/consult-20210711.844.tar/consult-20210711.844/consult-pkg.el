(define-package "consult" "20210711.844" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f66acb3b72e6b137a9a6d2d6f1e895509bb64358" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
