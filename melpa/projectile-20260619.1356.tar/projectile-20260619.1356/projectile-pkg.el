;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260619.1356"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "3bbd5259841c1404edb4935ead441536f5ebb4a8"
  :revdesc "3bbd5259841c"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
