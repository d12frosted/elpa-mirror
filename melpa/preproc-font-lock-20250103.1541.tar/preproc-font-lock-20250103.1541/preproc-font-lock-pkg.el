;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "preproc-font-lock" "20250103.1541"
  "Highlight C preprocessor directives."
  ()
  :url "https://github.com/Lindydancer/preproc-font-lock"
  :commit "b16b59afcdc53614e6c3c272d1eaea592a832f65"
  :revdesc "b16b59afcdc5"
  :keywords '("c" "languages" "faces"))
