;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sparkweather" "20260112.1420"
  "Weather forecasts with sparklines."
  '((emacs "29.1"))
  :url "https://github.com/aglet/sparkweather"
  :commit "967fbddc81ab04ff11baba9bd6739d74f5bc593a"
  :revdesc "967fbddc81ab"
  :keywords '("convenience" "weather")
  :authors '(("Robin Stephenson" . "robin@aglet.net"))
  :maintainers '(("Robin Stephenson" . "robin@aglet.net")))
