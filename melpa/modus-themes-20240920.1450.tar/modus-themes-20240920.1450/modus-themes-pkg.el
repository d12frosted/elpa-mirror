(define-package "modus-themes" "20240920.1450" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "19e91f9e72cd79af1d7305bb7aae0c9ae18ccba4" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
