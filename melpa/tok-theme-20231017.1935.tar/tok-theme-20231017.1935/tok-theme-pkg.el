(define-package "tok-theme" "20231017.1935" "Minimal monochromatic theme for Emacs in the spirit of Zmacs and Smalltalk-80."
  '((emacs "27.0"))
  :commit "6a989fdc6652404b871ea9c6191dd04395203339" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
