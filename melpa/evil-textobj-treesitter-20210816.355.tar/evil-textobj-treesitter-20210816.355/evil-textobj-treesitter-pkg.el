(define-package "evil-textobj-treesitter" "20210816.355" "Provides evil textobjects using treesitter"
  '((emacs "25.1")
    (evil "1.0.0")
    (tree-sitter "0.15.0"))
  :commit "461195b882b2179a0e6f8efcd37835ab2a0ed5e2" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-treesitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
