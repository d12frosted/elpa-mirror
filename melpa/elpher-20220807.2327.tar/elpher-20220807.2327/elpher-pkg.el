(define-package "elpher" "20220807.2327" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "f103164b28ef710f8d49595955725be1e127a018" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
