(define-package "gerrit" "20220408.1546" "Gerrit client"
  '((emacs "25.1")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "3425027a4394eb71fe1a6024799cb7b4b0e9413e" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
