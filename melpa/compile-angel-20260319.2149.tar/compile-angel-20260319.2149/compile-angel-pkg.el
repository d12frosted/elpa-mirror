;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260319.2149"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "47d41c65d3ddd278b4d4a9bdd7beaa5e4c0153cd"
  :revdesc "47d41c65d3dd"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
