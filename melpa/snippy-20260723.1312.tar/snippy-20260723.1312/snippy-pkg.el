;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snippy" "20260723.1312"
  "Vscode snippet support with Yasnippet."
  '((emacs     "30.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/MiniApollo/snippy"
  :commit "e6c417925776c123f81ad6de3ba6e50b9e9f0079"
  :revdesc "e6c417925776"
  :keywords '("convenience" "emulations")
  :authors '(("Mark Surmann" . "surmannmark@gmail.com"))
  :maintainers '(("Mark Surmann" . "surmannmark@gmail.com")))
