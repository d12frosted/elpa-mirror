(define-package "fb2-reader" "20230305.2309" "Read FB2 and FB2.ZIP documents"
  '((emacs "26.2")
    (f "0.17")
    (s "1.11.0")
    (dash "2.12.0")
    (visual-fill-column "2.2")
    (async "1.9.4"))
  :commit "9836db284749e0cef4c43c2cb5358c82ae9b8589" :authors
  '(("Dmitriy Pshonko" . "jumper047@gmail.com"))
  :maintainers
  '(("Dmitriy Pshonko" . "jumper047@gmail.com"))
  :maintainer
  '("Dmitriy Pshonko" . "jumper047@gmail.com")
  :keywords
  '("multimedia" "ebook" "fb2")
  :url "https://github.com/jumper047/fb2-reader")
;; Local Variables:
;; no-byte-compile: t
;; End:
