(define-package "ledger-mode" "20240320.359" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "44ec610ca522fa35ecf241cc2c9c1adb56c139ed")
;; Local Variables:
;; no-byte-compile: t
;; End:
