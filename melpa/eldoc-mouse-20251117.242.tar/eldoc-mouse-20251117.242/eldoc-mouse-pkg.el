;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20251117.242"
  "Display documentation for mouse hover."
  '((emacs    "30.1")
    (posframe "1.4.0")
    (eglot    "1.8"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "655d2b617c5d8b1039c62215c51ec30948a51ac7"
  :revdesc "655d2b617c5d"
  :keywords '("tools" "languages" "convenience" "emacs" "mouse" "hover")
  :authors '((nil . "HuangFeiyusibadake1@163.com"))
  :maintainers '((nil . "HuangFeiyusibadake1@163.com")))
