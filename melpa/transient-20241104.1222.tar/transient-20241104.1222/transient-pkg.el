;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20241104.1222"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.0.0.0")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "bb103abb7f20736b6a5bdea7706d0bf850a8c7e1"
  :revdesc "bb103abb7f20"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
