;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "20260609.1710"
  "Visually highlight the selected buffer."
  '((emacs "27.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "3e4fabe3449c9c308d61de932a9e0740c637a4c8"
  :revdesc "3e4fabe3449c"
  :keywords '("faces" "editing"))
