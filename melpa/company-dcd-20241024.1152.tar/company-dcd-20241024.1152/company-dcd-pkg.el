;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-dcd" "20241024.1152"
  "Company backend for Dlang using DCD."
  '((company          "0.9")
    (flycheck-dmd-dub "0.7")
    (yasnippet        "0.8")
    (popwin           "0.7")
    (cl-lib           "0.5"))
  :url "https://github.com/tsukimizake/company-dcd"
  :commit "d1f0bf4ed3b86ba6e4173450d237185df37ef464"
  :revdesc "d1f0bf4ed3b8"
  :keywords '("languages")
  :authors '(("tsukimizake" . "shomasd_at_gmail.com"))
  :maintainers '(("tsukimizake" . "shomasd_at_gmail.com")))
