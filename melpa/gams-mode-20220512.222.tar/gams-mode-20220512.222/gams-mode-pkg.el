(define-package "gams-mode" "20220512.222" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "d7f5bb688e569c7c517e4c3af32a5319c492362b" :authors
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
