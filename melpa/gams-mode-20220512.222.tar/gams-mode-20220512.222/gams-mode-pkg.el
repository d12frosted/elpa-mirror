(define-package "gams-mode" "20220512.222" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "937b2223259fb102bd6991fe46f509897e4f6cba" :authors
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
