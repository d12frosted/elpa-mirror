;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatui-dark-theme" "20170513.1422"
  "Dark color theme with colors from https://flatuicolors.com/."
  '((emacs "24"))
  :url "https://github.com/theasp/flatui-dark-theme"
  :commit "5b959a9f743f891e4660b1b432086417947872ea"
  :revdesc "5b959a9f743f"
  :keywords '("color" "theme" "dark" "flatui" "faces")
  :authors '(("Andrew Phillips" . "theasp@gmail.com"))
  :maintainers '(("Andrew Phillips" . "theasp@gmail.com")))
