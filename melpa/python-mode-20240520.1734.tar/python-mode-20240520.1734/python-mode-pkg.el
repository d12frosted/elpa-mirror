(define-package "python-mode" "20240520.1734" "Python major mode" 'nil :commit "8c96c67f93a1d860a44665909255987bb4b26856" :authors
  '(("2015-2023 https://gitlab.com/groups/python-mode-devs")
    ("2003-2014 https://launchpad.net/python-mode")
    ("1995-2002 Barry A. Warsaw")
    ("1992-1994 Tim Peters"))
  :maintainer
  '(nil . "python-mode@python.org")
  :keywords
  '("python" "languages" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
