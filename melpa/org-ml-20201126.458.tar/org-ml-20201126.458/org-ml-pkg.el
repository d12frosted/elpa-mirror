(define-package "org-ml" "20201126.458" "Functional Org Mode API"
  '((emacs "26.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "9634161090ccc9247bc31815db5374cef54ad2c5" :keywords
  ("org-mode" "outlines")
  :authors
  (("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  ("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
