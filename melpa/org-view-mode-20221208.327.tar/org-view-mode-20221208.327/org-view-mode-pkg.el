(define-package "org-view-mode" "20221208.327" "Read-only viewer with less markup clutter in org mode files"
  '((emacs "25.1"))
  :commit "014f96acb7093ffae93c62aabff750e63c3babc5" :authors
  '(("Arthur Miller" . "arthur.miller@live.com"))
  :maintainer
  '("Arthur Miller" . "arthur.miller@live.com")
  :keywords
  '("convenience" "outlines" "tools")
  :url "https://github.com/amno1/org-view-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
