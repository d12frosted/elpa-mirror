(define-package "universal-sidecar-elfeed-related" "20231002.22" "Related Papers Sidecar Section for Elfeed"
  '((emacs "25.1")
    (universal-sidecar "1.0.0")
    (bibtex-completion "1.0.0")
    (elfeed "3.4.1"))
  :commit "8e9b4ce2faf304aedc485e7bedb6f0e460d9ea09" :authors
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainer
  '("Samuel W. Flint" . "me@samuelwflint.com")
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar")
;; Local Variables:
;; no-byte-compile: t
;; End:
