;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260628.2307"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "a6ee9afb313f3eacb7fe95cdaca4551d9bec76d2"
  :revdesc "a6ee9afb313f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
