(define-package "consult" "20220120.1426" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "0127b52a97da30e30fea9605cf8f7e156052f366" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
