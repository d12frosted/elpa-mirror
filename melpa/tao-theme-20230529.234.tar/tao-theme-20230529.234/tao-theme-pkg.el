(define-package "tao-theme" "20230529.234" "This package provides two parametrized uncoloured color themes for Emacs: tao-yin and tao-yang." 'nil :commit "4443e91293a044869e836bfeb0b10e9b4d3b102b" :authors
  '(("Peter Kosov" . "11111000000@email.com"))
  :maintainer
  '("Peter Kosov" . "11111000000@email.com")
  :url "http://github.com/11111000000/tao-theme-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
