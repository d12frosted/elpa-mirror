;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260601.1618"
  "Support for Org links to Magit buffers."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (magit    "4.5")
    (org      "9.8"))
  :url "https://github.com/magit/orgit"
  :commit "4a4c03ee40b0e2509b49303e151ee217edaf0da4"
  :revdesc "4a4c03ee40b0"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
