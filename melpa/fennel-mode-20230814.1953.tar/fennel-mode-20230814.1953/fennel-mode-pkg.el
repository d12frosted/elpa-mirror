(define-package "fennel-mode" "20230814.1953" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "79b75f541da3007ebbbf28f7b9517321d4b487dd" :authors
  '(("Phil Hagelberg"))
  :maintainers
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
