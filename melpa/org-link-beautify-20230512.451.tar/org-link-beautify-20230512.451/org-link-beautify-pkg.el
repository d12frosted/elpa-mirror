(define-package "org-link-beautify" "20230512.451" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1"))
  :commit "a7a909af2b7526e2bf442f97b895dac16849e35f" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
