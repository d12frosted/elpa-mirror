(define-package "modus-themes" "20221027.1157" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "8ce7e5c84851a1cc8f5141b25807e2e9d58b3f8a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
