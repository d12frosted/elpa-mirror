;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260706.2216"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (compat      "31.0.0.0")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "77a8a44da3cd712981854c1871bc0a239c6574ea"
  :revdesc "77a8a44da3cd")
