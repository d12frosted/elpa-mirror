(define-package "cnfonts" "20230214.705" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "4244c9e8a306b459777f950dd70f659e6f629355" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
