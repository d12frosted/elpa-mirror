;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260329.636"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "7eaf21adbdb64286f03bf517c9a82a32cdce1a8b"
  :revdesc "7eaf21adbdb6"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
