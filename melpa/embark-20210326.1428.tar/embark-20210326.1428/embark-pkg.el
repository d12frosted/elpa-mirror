(define-package "embark" "20210326.1428" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "49cd0aff39e7bc9173ec49d1c14d7ab8d9d25355" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
