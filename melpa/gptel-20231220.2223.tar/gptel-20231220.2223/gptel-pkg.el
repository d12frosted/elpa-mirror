(define-package "gptel" "20231220.2223" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "e927fd5a2a94f3615654ced07a3a6f440f029153" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
