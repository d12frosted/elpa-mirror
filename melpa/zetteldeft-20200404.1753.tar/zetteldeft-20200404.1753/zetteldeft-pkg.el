(define-package "zetteldeft" "20200404.1753" "Turn deft into a zettelkasten system"
  '((emacs "25.1")
    (deft "0.8"))
  :commit "271ea573b0a4f265d16108db2ec7c928f3e9aa31" :authors
  '(("EFLS <Elias Storms>"))
  :maintainer
  '("EFLS <Elias Storms>")
  :keywords
  '("deft" "zettelkasten" "zetteldeft" "wp" "files")
  :url "https://efls.github.io/zetteldeft/")
;; Local Variables:
;; no-byte-compile: t
;; End:
