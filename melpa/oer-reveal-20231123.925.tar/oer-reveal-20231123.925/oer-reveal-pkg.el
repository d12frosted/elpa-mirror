(define-package "oer-reveal" "20231123.925" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.22.0"))
  :commit "c31f94db49b84cbfddea5410be7f6fa2a422aa1f" :authors
  '(("Jens Lechtenbörger"))
  :maintainers
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
