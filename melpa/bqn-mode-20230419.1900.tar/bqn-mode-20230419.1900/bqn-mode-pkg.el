(define-package "bqn-mode" "20230419.1900" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "117eb0e12e8eb481fdea943304e4f5eaf6b1cd1f" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
