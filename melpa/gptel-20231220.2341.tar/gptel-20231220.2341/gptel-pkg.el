(define-package "gptel" "20231220.2341" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "ddd69cbbcf88139c620b803bc79909e08778a43e" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
