;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc-temp" "20160228.840"
  "Use mozc temporarily."
  '((emacs "24")
    (dash  "2.10.0")
    (mozc  "0"))
  :url "https://github.com/HKey/mozc-temp"
  :commit "7f5dd5fc8ceeca9b1822f7e056a4be67e2e74959"
  :revdesc "7f5dd5fc8cee"
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
