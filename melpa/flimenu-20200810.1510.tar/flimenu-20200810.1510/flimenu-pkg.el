;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flimenu" "20200810.1510"
  "Flatten imenu automatically."
  '((emacs "24.4"))
  :url "https://github.com/IvanMalison/flimenu"
  :commit "4c0ff37cf3bd6c836bd136b5f6c450560a6c92b9"
  :revdesc "4c0ff37cf3bd"
  :keywords '("imenu" "browse" "structure" "hook" "mode" "matching" "tools" "convenience" "files")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
