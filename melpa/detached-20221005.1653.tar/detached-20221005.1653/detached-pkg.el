(define-package "detached" "20221005.1653" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "0b5f2fcd1e3fa7959c749aec898ea3caaa36d726" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
