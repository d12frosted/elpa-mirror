;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20250310.1827"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "d58a41c5eae2e397c01640b23e783c18b7d4edf9"
  :revdesc "d58a41c5eae2"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
