(define-package "cape" "20220427.1409" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "29130e35225fa8e5f5ecc86f2ad2425f7ec3c35d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
