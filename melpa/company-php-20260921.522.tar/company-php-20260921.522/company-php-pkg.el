;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-php" "20260921.522"
  "A company back-end for PHP."
  '((cl-lib      "0.5")
    (ac-php-core "2.0")
    (company     "0.9"))
  :url "https://github.com/xcwen/ac-php"
  :commit "ab7f0275e0dd73dfe66c6cad271b9282f6e8a276"
  :revdesc "ab7f0275e0dd"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
