(define-package "hyperdrive" "20230925.2257" "P2P filesystem"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5"))
  :commit "903847d50e894056c81fa87b343199f17bf91b8d" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
