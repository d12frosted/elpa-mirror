(define-package "modus-themes" "20210828.756" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "83aaca4429e4b8726a46b9a483fddebcad267379" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
