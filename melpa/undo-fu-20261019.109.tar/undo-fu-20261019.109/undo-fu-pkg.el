;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu" "20261019.109"
  "Undo helper with redo."
  '((emacs "25.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu"
  :commit "11c1bfd9a142ce2563ed33f2026d9095768e4668"
  :revdesc "11c1bfd9a142"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
