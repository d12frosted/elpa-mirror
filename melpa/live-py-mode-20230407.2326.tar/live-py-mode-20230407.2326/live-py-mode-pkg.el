(define-package "live-py-mode" "20230407.2326" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "c41918cfd432ed75747f47113d080a229fa31b47" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
