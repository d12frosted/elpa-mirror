(define-package "modus-themes" "20211213.700" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "8f9491d0e2b915dda99224bdbf5b0c063ea537a5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
