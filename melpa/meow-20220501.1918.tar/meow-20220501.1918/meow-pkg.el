(define-package "meow" "20220501.1918" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "72d6ff36b62a57aa9c9dbfbd44cdb3002a0e940a" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
