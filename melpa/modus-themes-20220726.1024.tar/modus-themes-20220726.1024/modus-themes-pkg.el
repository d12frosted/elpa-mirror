(define-package "modus-themes" "20220726.1024" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "e44e579381d5346f470f3a707a43fc63d0d75bc1" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
