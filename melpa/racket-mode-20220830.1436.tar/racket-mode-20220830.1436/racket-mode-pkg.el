(define-package "racket-mode" "20220830.1436" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "db7baebe64d5c1620c06e9bfca267a81ddc64aca" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
