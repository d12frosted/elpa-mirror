(define-package "zotxt" "20210222.347" "Tools to integrate emacs with Zotero via the zotxt plugin."
  '((request "0.3.2")
    (deferred "0.5.1"))
  :commit "a760009b9ecfa0b3362e77a6b44453821768d02e" :authors
  '(("Erik Hetzner" . "egh@e6h.org"))
  :maintainer
  '("Erik Hetzner" . "egh@e6h.org")
  :keywords
  '("bib"))
;; Local Variables:
;; no-byte-compile: t
;; End:
