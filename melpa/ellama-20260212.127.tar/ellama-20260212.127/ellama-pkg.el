;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260212.127"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "b5459e1cfdae4cdb0b00f8784c1d73687c0900ae"
  :revdesc "b5459e1cfdae"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
