(define-package "consult" "20210205.1956" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "c3c28f4cf98ce3a5a45547ac9e31271e760fed36" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
