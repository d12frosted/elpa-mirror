;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260110.452"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "394137c90cd6c8534a732d56ccf4146b70ca0266"
  :revdesc "394137c90cd6"
  :keywords '("comm"))
