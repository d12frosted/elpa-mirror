;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260404.2018"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "dcae05a4a3bae4d07cb6d7144f54d14651c56f61"
  :revdesc "dcae05a4a3ba"
  :keywords '("convenience" "comm" "hypermedia"))
