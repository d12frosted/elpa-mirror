;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-term" "20260818.1002"
  "Quickly toggle persistent term and shell buffers."
  '((emacs "25.1"))
  :url "https://github.com/justinlime/toggle-term.el"
  :commit "e9c90e4f476fededcaa921882b214d264a42980d"
  :revdesc "e9c90e4f476f"
  :keywords '("frames" "convenience" "terminals"))
