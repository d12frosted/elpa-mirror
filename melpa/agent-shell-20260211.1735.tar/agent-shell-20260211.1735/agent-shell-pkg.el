;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260211.1735"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1f875d0e52ce2d4c582022aa9201d73c0e70500e"
  :revdesc "1f875d0e52ce")
