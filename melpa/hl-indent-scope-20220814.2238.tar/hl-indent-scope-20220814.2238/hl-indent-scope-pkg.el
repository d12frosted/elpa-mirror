(define-package "hl-indent-scope" "20220814.2238" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "8deb138941b0b8848afbb2effb36516f44ee44c9" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
