;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20260916.626"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "291595d9de6649f60d0363c1c75e6326ee4d4fff"
  :revdesc "291595d9de66"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
