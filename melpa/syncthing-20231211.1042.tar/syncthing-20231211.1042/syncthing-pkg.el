(define-package "syncthing" "20231211.1042" "Client for Syncthing"
  '((emacs "27.1"))
  :commit "74d5ae77f063c79a53b91b4fe0c26a9e4c5282f0" :authors
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainer
  '("Peter Badida" . "keyweeusr@gmail.com")
  :keywords
  '("convenience" "syncthing" "sync" "client" "view")
  :url "https://github.com/KeyWeeUsr/emacs-syncthing")
;; Local Variables:
;; no-byte-compile: t
;; End:
