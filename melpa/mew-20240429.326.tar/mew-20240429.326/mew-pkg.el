(define-package "mew" "20240429.326" "Messaging in the Emacs World" 'nil :commit "e16e1338c356cfc4b49aee22b4875c4b3b82e100" :authors
  '(("Mew developing team"))
  :maintainers
  '(("Mew developing team"))
  :maintainer
  '("Mew developing team"))
;; Local Variables:
;; no-byte-compile: t
;; End:
