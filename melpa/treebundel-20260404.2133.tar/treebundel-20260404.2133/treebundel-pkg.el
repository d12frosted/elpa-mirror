;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treebundel" "20260404.2133"
  "Bundle related git-worktrees together."
  '((emacs  "27.1")
    (compat "29.1.4.2"))
  :url "https://github.com/purplg/treebundel"
  :commit "35e55a21914772e2f125fd1c4682f7e239f192d3"
  :revdesc "35e55a219147"
  :keywords '("convenience" "vc"))
