;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260722.142"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a71b3e9f11cdece7fd0b94e637fdc0fca47169ab"
  :revdesc "a71b3e9f11cd")
