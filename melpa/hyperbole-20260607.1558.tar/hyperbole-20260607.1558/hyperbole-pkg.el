;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260607.1558"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "8f36d43b2b45a01be0c66be83899d51bdd85b31a"
  :revdesc "8f36d43b2b45"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
