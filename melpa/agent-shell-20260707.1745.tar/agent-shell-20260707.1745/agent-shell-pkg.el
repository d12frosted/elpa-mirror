;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260707.1745"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "41a2fa7cc606f6fc1e72ae7c87c4f40b9bd93236"
  :revdesc "41a2fa7cc606")
