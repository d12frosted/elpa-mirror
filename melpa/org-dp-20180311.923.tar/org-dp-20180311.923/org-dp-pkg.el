;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dp" "20180311.923"
  "Declarative Local Programming with Org Elements."
  '((cl-lib "0.5"))
  :url "https://github.com/tj64/org-dp"
  :commit "334fefd06eb925c86b1642787b2a088aa0932bab"
  :revdesc "334fefd06eb9"
  :authors '(("Thorsten Jolitz" . "tjolitzATgmailDOTcom"))
  :maintainers '(("Thorsten Jolitz" . "tjolitzATgmailDOTcom")))
