;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260828.410"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "7f6201d750234a48f1ab5995880a816b5ecb03bc"
  :revdesc "7f6201d75023"
  :keywords '("languages" "lisp" "slime"))
