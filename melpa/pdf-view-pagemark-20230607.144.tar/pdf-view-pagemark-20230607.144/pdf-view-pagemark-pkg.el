(define-package "pdf-view-pagemark" "20230607.144" "Add indicator in pdfview mode to show the page remaining"
  '((pdf-tools "0.90")
    (posframe "1.4.2")
    (emacs "26.0"))
  :commit "90a2908795bd4bf1015ff18ab338b50a785a1843" :authors
  '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers
  '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainer
  '("Kimi Ma" . "kimi.im@outlook.com")
  :keywords
  '("multimedia" "convenience")
  :url "https://github.com/kimim/pdf-view-pagemark")
;; Local Variables:
;; no-byte-compile: t
;; End:
