;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251219.1923"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "5961dc715c508c99eb74a0c44d6f8122b56857b9"
  :revdesc "5961dc715c50"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
