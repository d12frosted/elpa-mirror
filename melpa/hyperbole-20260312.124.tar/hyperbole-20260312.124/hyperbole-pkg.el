;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260312.124"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "6e0c833a421b6ecb5eaec8339cb754eef7eff913"
  :revdesc "6e0c833a421b"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
