(define-package "detached" "20221125.1010" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "fedb0df5b0fbba13c662107855fb07a922793096" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
