;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-control" "20260101.600"
  "Management for indentation level."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/indent-control"
  :commit "222fa01879c08adc5cc84cef6aa4fcff90c7c938"
  :revdesc "222fa01879c0"
  :keywords '("convenience" "control" "indent" "tab" "generic" "level")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
