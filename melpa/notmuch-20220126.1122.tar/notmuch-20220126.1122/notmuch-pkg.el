(define-package "notmuch" "20220126.1122" "run notmuch within emacs" 'nil :commit "2c1d1107f5dacdb4a2c514909fd96f45f83e2f3c" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
