;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-flycheck" "20260322.16"
  "Provides the command `consult-flycheck'."
  '((emacs    "29.1")
    (consult  "2.8")
    (flycheck "35"))
  :url "https://github.com/minad/consult-flycheck"
  :commit "21c74a96e787606f8572453b17f6912c3755be42"
  :revdesc "21c74a96e787"
  :keywords '("languages" "tools" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
