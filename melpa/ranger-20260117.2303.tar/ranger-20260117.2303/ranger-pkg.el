;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ranger" "20260117.2303"
  "Make dired more like ranger."
  '((emacs "27.1"))
  :url "https://github.com/ralesi/ranger"
  :commit "8a7e0f246049789953b65e2776bfdf2a80d25bca"
  :revdesc "8a7e0f246049"
  :keywords '("files" "convenience" "dired")
  :authors '(("Rich Alesi" . "https://github.com/ralesi"))
  :maintainers '(("Rich Alesi" . "https://github.com/ralesi")))
