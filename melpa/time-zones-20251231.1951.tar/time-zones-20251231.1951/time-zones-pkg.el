;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-zones" "20251231.1951"
  "Time zone lookups."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/time-zones"
  :commit "fd94705f04b1e5bc4a9b08ef9092fea839fe92d7"
  :revdesc "fd94705f04b1")
