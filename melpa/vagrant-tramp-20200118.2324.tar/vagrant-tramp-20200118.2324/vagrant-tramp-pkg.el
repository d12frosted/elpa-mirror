(define-package "vagrant-tramp" "20200118.2324" "Vagrant method for TRAMP"
  '((dash "2.12.0"))
  :commit "f67925928dd844b74e4002f433e6f0ebd3aae357" :authors
  (("Doug MacEachern" . "dougm@vmware.com")
   ("Ryan Prior     " . "ryanprior@gmail.com"))
  :maintainer
  ("Doug MacEachern" . "dougm@vmware.com")
  :keywords
  ("vagrant")
  :url "https://github.com/dougm/vagrant-tramp")
;; Local Variables:
;; no-byte-compile: t
;; End:
