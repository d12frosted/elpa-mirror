;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260215.2225"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "http://github.com/bormoge/guava-themes"
  :commit "f86baca1b8161fd72bb677c71bcff9cc9fff38b6"
  :revdesc "f86baca1b816"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
