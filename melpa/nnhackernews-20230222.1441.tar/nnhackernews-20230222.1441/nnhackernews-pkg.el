(define-package "nnhackernews" "20230222.1441" "Gnus backend for Hacker News"
  '((emacs "25.2")
    (request "0.3.3")
    (dash "2.18.1")
    (anaphora "1.0.4"))
  :commit "bf0ff5d4a079004f937e7440ba282c156f24dced" :keywords
  '("news")
  :url "https://github.com/dickmao/nnhackernews")
;; Local Variables:
;; no-byte-compile: t
;; End:
