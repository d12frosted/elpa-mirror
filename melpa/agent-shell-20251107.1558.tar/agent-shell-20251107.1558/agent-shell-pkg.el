;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251107.1558"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2a5460305fa5cd8155e5ced5b49e7c66348498bf"
  :revdesc "2a5460305fa5")
