;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260128.2204"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "1b92d190041220b118594e3d7af6d4b88ae239f0"
  :revdesc "1b92d1900412"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
