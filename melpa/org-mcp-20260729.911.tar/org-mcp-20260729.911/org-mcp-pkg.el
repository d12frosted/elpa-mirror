;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260729.911"
  "MCP server for Org-mode."
  '((emacs          "28.2")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "13ef5d3076f59dc6e9788e330f937c51479eb7cd"
  :revdesc "13ef5d3076f5"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
