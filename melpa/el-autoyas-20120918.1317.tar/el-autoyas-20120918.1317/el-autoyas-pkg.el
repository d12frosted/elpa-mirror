(define-package "el-autoyas" "20120918.1317" "Automatically create Emacs-Lisp Yasnippets" 'nil :commit "bde0251ecb504f585dfa27c205c8e312655310cc" :keywords
  ("emacs" "lisp" "mode" "yasnippet")
  :authors
  (("Matthew L. Fidler"))
  :maintainer
  ("Matthew L. Fidler")
  :url "https://github.com/mlf176f2/el-autoyas.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
