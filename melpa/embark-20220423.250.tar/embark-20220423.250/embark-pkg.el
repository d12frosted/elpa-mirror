(define-package "embark" "20220423.250" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "29e227f7ec4cdf9fdab8b5723f4db236c81c2eb7" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
