;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20261123.1138"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "979181d4f5d37eb8ee20a12fd26fb9bebfe329ff"
  :revdesc "979181d4f5d3"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
