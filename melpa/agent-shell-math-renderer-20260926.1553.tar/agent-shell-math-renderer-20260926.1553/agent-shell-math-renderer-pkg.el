;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20260926.1553"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.10.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "0d989803370d5c278d57c5203aa436320992f9b6"
  :revdesc "0d989803370d"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
