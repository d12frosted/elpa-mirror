(define-package "mini-echo" "20231212.1334" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "3c6030944ca32c9d9144660e4e497c4f26520851" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
