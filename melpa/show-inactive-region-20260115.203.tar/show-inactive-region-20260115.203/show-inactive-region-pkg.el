;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-inactive-region" "20260115.203"
  "Highlight the inactive region."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-show-inactive-region"
  :commit "c8fd7e6289ab55bbf0caa47f7f9093e3489fc19f"
  :revdesc "c8fd7e6289ab"
  :keywords '("convenience" "faces")
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
