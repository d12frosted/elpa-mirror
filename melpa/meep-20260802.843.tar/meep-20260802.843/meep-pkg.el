;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260802.843"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "e5a27b12b6676eb552d009174fc112e7ec9f15b1"
  :revdesc "e5a27b12b667"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
