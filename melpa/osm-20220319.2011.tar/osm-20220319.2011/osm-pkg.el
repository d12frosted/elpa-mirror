(define-package "osm" "20220319.2011" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "da25f3fe7b8b6201c94bc352cc4c3b16d60d9e21" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
