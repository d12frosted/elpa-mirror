(define-package "dirvish" "20211229.1455" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "f8968616ddaf1fd3aee021fa8c213f41261fd279" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
