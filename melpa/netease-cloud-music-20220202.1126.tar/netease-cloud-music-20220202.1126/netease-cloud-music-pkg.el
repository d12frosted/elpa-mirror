(define-package "netease-cloud-music" "20220202.1126" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "9b1926a5fb2310b8eabc033e07ed0b15c33ddb9c" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
