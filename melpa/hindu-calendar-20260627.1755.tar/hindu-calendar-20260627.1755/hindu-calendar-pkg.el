;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hindu-calendar" "20260627.1755"
  "Astronomical traditional Hindu calendar (panchanga)."
  '((emacs "24.3"))
  :url "https://github.com/bdsatish/hindu-calendar"
  :commit "0868cb7548830e50d801f68a79e34fd988464f3e"
  :revdesc "0868cb754883"
  :keywords '("calendar" "panchanga" "hindu" "indian")
  :authors '(("B.D.Satish" . "bdsatish@gmail.com"))
  :maintainers '(("B.D.Satish" . "bdsatish@gmail.com")))
