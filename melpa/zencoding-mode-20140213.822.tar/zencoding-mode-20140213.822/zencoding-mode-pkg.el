;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zencoding-mode" "20140213.822"
  "Unfold CSS-selector-like expressions to markup."
  ()
  :url "https://github.com/rooney/zencoding"
  :commit "58e42af182c98cb9941d27cd042d227fbf4e146c"
  :revdesc "58e42af182c9"
  :keywords '("convenience")
  :authors '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainers '(("Chris Done" . "chrisdone@gmail.com")))
