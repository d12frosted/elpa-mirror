(define-package "mistty" "20231001.1847" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "b24fb56d6925f0bca2812aaa85734500375865cd" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
