;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "20241122.120"
  "Slack client for Emacs."
  '((websocket "1.8")
    (request   "0.2.0")
    (oauth2    "0.10")
    (circe     "2.2")
    (alert     "1.2")
    (emojify   "0.2")
    (emacs     "25.1")
    (dash      "2.19.1")
    (s         "1.13.1")
    (ts        "0.3"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "f7dfb94dedb19fdc6f5ecf6c7d7603aed56125e9"
  :revdesc "f7dfb94dedb1"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
