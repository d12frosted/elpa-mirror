(define-package "shimbun" "20201021.552" "interfacing with web newspapers" 'nil :commit "71e15af1a54085b5a259c998e64c8f32ffd96d03" :keywords
  ("news")
  :authors
  (("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
   ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
   ("Yuuichi Teranishi " . "teranisi@gohome.org")
   ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  ("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
