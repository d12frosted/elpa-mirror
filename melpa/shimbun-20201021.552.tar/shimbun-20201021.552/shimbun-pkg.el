(define-package "shimbun" "20201021.552" "interfacing with web newspapers" 'nil :commit "085de54acae027e7f0d0b9bf34d3142993234fd3" :authors
  (("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
   ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
   ("Yuuichi Teranishi " . "teranisi@gohome.org")
   ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  ("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  ("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
