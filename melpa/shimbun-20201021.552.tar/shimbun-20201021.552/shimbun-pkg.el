(define-package "shimbun" "20201021.552" "interfacing with web newspapers" 'nil :commit "6594b1b7abfb81bffd94f088d2e0a1acd7f990ec" :keywords
  ("news")
  :authors
  (("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
   ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
   ("Yuuichi Teranishi " . "teranisi@gohome.org")
   ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  ("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
