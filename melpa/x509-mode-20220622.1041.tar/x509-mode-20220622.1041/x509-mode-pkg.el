(define-package "x509-mode" "20220622.1041" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "24.3"))
  :commit "163f4b6376614d361ef66012b7b2fed709ed8bb3" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
