;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20261018.1619"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.67.1")
    (latex-to-svg-backend "0.15.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "070a0b586eef602f9e397f3633a000bce882ff67"
  :revdesc "070a0b586eef"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
