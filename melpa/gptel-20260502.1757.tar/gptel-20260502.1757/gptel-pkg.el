;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260502.1757"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "45133d515756cd477bcbf7be83733873d738ae0c"
  :revdesc "45133d515756"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
