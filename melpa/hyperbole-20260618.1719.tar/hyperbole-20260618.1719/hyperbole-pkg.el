;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260618.1719"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "64d7dafee66939636b21430ec3a3db70193d3c39"
  :revdesc "64d7dafee669"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
