;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cursorfree" "20260905.1240"
  "Complex editing through voice."
  '((emacs "29.1")
    (phony "1.0.1"))
  :url "https://github.com/ErikPrantare/cursorfree.el"
  :commit "4447f905dd5f389059e7cfeee21dd71a289bfa46"
  :revdesc "4447f905dd5f"
  :keywords '("convenience")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
