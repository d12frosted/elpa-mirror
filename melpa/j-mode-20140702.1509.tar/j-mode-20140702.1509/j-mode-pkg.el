(define-package "j-mode" "20140702.1509" "Major mode for editing J programs" 'nil :commit "caa55dfaae01d1875380929826952c2b3ef8a653" :keywords
  '("j" "langauges")
  :url "http://github.com/zellio/j-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
