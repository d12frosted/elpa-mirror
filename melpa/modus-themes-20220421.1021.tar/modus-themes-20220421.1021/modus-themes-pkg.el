(define-package "modus-themes" "20220421.1021" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "e8f1b8997466e244d9aa1a11b7ffaa4b70419874" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
