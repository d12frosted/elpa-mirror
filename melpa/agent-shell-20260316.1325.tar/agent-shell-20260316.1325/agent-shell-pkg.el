;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260316.1325"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "20c5bb2780b94286926e1164d33fe2705d57d381"
  :revdesc "20c5bb2780b9")
