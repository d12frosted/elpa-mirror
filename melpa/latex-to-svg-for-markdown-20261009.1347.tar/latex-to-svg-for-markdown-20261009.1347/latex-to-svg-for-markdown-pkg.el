;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-markdown" "20261009.1347"
  "Preview Markdown LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.20.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "9e32304e5e10ddaa3d1ac604b9311f81a5b0841d"
  :revdesc "9e32304e5e10"
  :keywords '("tex" "markdown" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
