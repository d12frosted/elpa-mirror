;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20261122.1546"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "096a10aafa633340e04fcadf9a1be258c336a142"
  :revdesc "096a10aafa63"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
