;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "punpun-themes" "20250421.1819"
  "Common color definitions for punpun themes."
  '((emacs "24.1"))
  :url "https://depp.brause.cc/punpun-themes"
  :commit "735cedca649e0576ffba3771a039744c4a70528d"
  :revdesc "735cedca649e"
  :keywords '("themes" "faces")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
