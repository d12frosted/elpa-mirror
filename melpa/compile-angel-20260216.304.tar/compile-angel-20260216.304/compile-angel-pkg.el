;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260216.304"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "29308eb5080080e78b36254aff68c769b21f9103"
  :revdesc "29308eb50800"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
