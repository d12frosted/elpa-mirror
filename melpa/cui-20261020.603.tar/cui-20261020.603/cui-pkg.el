;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261020.603"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "38854e3421f63fed5e6123149173c3d91ddab04a"
  :revdesc "38854e3421f6"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
