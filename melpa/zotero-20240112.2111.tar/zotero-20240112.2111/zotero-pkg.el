;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zotero" "20240112.2111"
  "Library for the Zotero API."
  '((emacs "27.1")
    (ht    "2.2")
    (oauth "1.11")
    (s     "1.12.0"))
  :url "https://gitlab.com/fvdbeek/emacs-zotero"
  :commit "eef5080e6a2ed0cae12c3d21580864f4b394cd5f"
  :revdesc "eef5080e6a2e"
  :keywords '("zotero" "hypermedia")
  :authors '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainers '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com")))
