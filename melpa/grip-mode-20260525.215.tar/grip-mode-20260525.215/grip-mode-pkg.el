;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grip-mode" "20260525.215"
  "Instant GitHub-flavored Markdown/Org preview using grip."
  '((emacs "24.4"))
  :url "https://github.com/seagle0128/grip-mode"
  :commit "101e0f0b675e72a3bcd6e975ac371f83b4e2a7f4"
  :revdesc "101e0f0b675e"
  :keywords '("convenience" "markdown" "preview")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
