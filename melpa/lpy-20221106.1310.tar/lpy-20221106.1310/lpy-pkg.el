(define-package "lpy" "20221106.1310" "A lispy interface to Python"
  '((emacs "25.1")
    (lispy "0.27.0"))
  :commit "fa95b11e1023704510cc7dd2897bf8bcc3027cbb" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("python" "lisp")
  :url "https://github.com/abo-abo/lpy")
;; Local Variables:
;; no-byte-compile: t
;; End:
