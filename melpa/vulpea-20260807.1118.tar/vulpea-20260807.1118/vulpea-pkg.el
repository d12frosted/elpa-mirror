;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260807.1118"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "50148723f24ee6632f5962f37dfed03025bc45c7"
  :revdesc "50148723f24e"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
