(define-package "doom-modeline" "20240307.320" "A minimal and modern mode-line"
  '((emacs "25.1")
    (compat "29.1.4.2")
    (nerd-icons "0.1.0")
    (shrink-path "0.3.1"))
  :commit "d066e7bd758d9966f98bca072c2079f36c8a2cb6" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
