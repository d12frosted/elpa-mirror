(define-package "zotero" "20211006.2051" "Library for the Zotero API"
  '((emacs "27.1")
    (ht "2.2")
    (oauth "1.0.4")
    (s "1.12.0"))
  :commit "e63eba9deed272e4d8f4426949b9a5743db3c511" :authors
  '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainer
  '("Folkert van der Beek" . "folkertvanderbeek@gmail.com")
  :keywords
  '("zotero" "hypermedia")
  :url "https://gitlab.com/fvdbeek/emacs-zotero")
;; Local Variables:
;; no-byte-compile: t
;; End:
