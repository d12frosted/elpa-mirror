(define-package "stock-tracker" "20230105.503" "Track stock price"
  '((emacs "27.1")
    (dash "2.16.0")
    (async "1.9.5"))
  :commit "327488e0f1232616bf33ab1a69da1a53aca25371" :authors
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainer
  '("Huming Chen" . "chenhuming@gmail.com")
  :keywords
  '("convenience" "stock" "finance")
  :url "https://github.com/beacoder/stock-tracker")
;; Local Variables:
;; no-byte-compile: t
;; End:
