;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bpftrace-mode" "20190608.2201"
  "Major mode for editing bpftrace script files."
  '((emacs "24.0"))
  :url "https://gitlab.com/jgkamat/bpftrace-mode"
  :commit "587b39ea7a1d786df5c04796d51bf2a5a4eda0d7"
  :revdesc "587b39ea7a1d"
  :keywords '("highlight" "c")
  :authors '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainers '(("Jay Kamat" . "jaygkamat@gmail.com")))
