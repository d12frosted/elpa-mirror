(define-package "racket-mode" "20220528.1411" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "f92a8746d5aa6353b10dd5b5923e236b07ac7627" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
