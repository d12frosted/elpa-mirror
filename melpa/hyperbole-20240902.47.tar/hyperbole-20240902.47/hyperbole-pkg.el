(define-package "hyperbole" "20240902.47" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.2"))
  :commit "64294de59fa6f3e7b8127d72081ae7ceaa8276d5" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainer
  '("Robert Weiner" . "rsw@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
