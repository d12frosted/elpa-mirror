;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260911.213"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "eb1bf43f781abf882f041c3239db038d0f97a591"
  :revdesc "eb1bf43f781a"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
