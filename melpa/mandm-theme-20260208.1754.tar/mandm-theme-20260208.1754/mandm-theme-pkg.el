;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mandm-theme" "20260208.1754"
  "An M&M color theme."
  ()
  :url "https://github.com/choppsv1/emacs-mandm-theme.git"
  :commit "217775591a4b2f8e531f745e6a9fb6cea6153bd7"
  :revdesc "217775591a4b"
  :authors '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainers '(("Christian Hopps" . "chopps@gmail.com")))
