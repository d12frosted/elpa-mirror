(define-package "mb-url" "20210916.1649" "Multiple Backends for Emacs URL package"
  '((emacs "24.4"))
  :commit "3fb03409ecbba5f0bcb755aba3b386383cb52840" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
