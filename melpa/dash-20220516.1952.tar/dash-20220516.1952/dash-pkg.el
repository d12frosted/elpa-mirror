(define-package "dash" "20220516.1952" "A modern list library for Emacs"
  '((emacs "24"))
  :commit "65d27bb71df896f49c75901fb24f934ac4457508" :authors
  '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainer
  '("Magnar Sveen" . "magnars@gmail.com")
  :keywords
  '("extensions" "lisp")
  :url "https://github.com/magnars/dash.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
