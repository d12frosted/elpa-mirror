(define-package "modus-themes" "20220819.1229" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "e85d2c14dcc16c265339e48c697e281776336ada" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
