(define-package "org-noter" "20240915.303" "A synchronized, Org-mode, document annotator"
  '((emacs "24.4")
    (cl-lib "0.6")
    (org "9.4"))
  :commit "5b49b68fa2e91a617ded1e6086bcc40d938fdd91" :authors
  '(("Gonçalo Santos" . "in@bsentia")
    ("Maintainer Dmitry M" . "dmitrym@gmail.com"))
  :maintainers
  '(("Peter Mao" . "peter.mao@gmail.com")
    ("Dmitry M" . "dmitrym@gmail.com"))
  :maintainer
  '("Peter Mao" . "peter.mao@gmail.com")
  :keywords
  '("lisp" "pdf" "interleave" "annotate" "external" "sync" "notes" "documents" "org-mode")
  :url "https://github.com/org-noter/org-noter")
;; Local Variables:
;; no-byte-compile: t
;; End:
