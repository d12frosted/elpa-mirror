(define-package "kaolin-themes" "20201206.914" "A set of eye pleasing themes"
  '((emacs "25.1")
    (autothemer "0.2.2")
    (cl-lib "0.6"))
  :commit "65e46afa01da61506d23c16266fa4065b25aec6d" :keywords
  ("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors
  (("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainer
  ("Ogden Webb" . "ogdenwebb@gmail.com")
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
