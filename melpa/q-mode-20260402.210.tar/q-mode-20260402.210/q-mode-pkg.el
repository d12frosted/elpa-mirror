;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260402.210"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "2cc0745bf0cc4251db39b109e9d068eb5794d1eb"
  :revdesc "2cc0745bf0cc"
  :keywords '("faces" "files" "q"))
