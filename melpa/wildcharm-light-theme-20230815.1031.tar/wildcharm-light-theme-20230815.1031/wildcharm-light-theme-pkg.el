(define-package "wildcharm-light-theme" "20230815.1031" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "011b527698a816b5bf41dda15580d1a621866fd3" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
