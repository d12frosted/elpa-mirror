(define-package "elisp-autofmt" "20230305.2340" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "93110e902a22599b20cf0077de3e0ec65a5efc21" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
