;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20251008.1041"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/dicom"
  :commit "df5acfbb5d1211515d2dfec141fd063be35bff16"
  :revdesc "df5acfbb5d12"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
