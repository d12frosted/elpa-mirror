;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuffer-frame" "20260826.804"
  "Minibuffer in centered child frame."
  '((emacs "28.1"))
  :url "https://github.com/zHaOdANiuu/minibuffer-frame"
  :commit "b76229d0b69a0954cc4cf47103c12c8985be6e97"
  :revdesc "b76229d0b69a"
  :keywords '("convenience" "minibuffer" "child-frame")
  :authors '(("Daniu Zhao" . "zhaodaniu1@gmail.com"))
  :maintainers '(("Daniu Zhao" . "zhaodaniu1@gmail.com")))
