(define-package "macports" "20230814.1525" "A porcelain for MacPorts"
  '((emacs "25.1")
    (transient "0.1.0"))
  :commit "0a99de715b1f62a01d8128dfaef263a168ee05e4" :authors
  '(("Aaron Madlon-Kay"))
  :maintainers
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("convenience")
  :url "https://github.com/amake/macports.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
