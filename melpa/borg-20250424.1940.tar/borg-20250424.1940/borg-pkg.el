;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20250424.1940"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "27.1")
    (epkg  "4.0.5")
    (magit "4.3.2"))
  :url "https://github.com/emacscollective/borg"
  :commit "20b8c432c9d1d46ad80e2f84099e66835a44b0d9"
  :revdesc "20b8c432c9d1"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
