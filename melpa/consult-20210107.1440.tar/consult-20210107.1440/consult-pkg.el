(define-package "consult" "20210107.1440" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7fccac2cd972c6ccdba7c292183e8f0bab273264" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
