(define-package "corfu" "20240716.1916" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "30"))
  :commit "1a2c1f262c0dc1bcbff7d1ccde841d7b609294d0" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "text")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
