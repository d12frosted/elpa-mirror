(define-package "dirvish" "20220313.911" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "79b9f1c204421c35d07dadec95f05bd4365d6ca5" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
