;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-todo" "20250119.1111"
  "Search hl-todo keywords in consult."
  '((emacs   "29.1")
    (consult "1.9")
    (hl-todo "3.8.2"))
  :url "https://github.com/liuyinz/consult-todo"
  :commit "07a540e45dcb80cdcdfb913a643353ad8cdc4516"
  :revdesc "07a540e45dcb"
  :authors '(("liuyinz" . "liuyinz@gmail.com"))
  :maintainers '(("liuyinz" . "liuyinz@gmail.com")))
