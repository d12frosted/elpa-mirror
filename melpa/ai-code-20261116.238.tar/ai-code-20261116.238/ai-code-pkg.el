;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261116.238"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "06a1c846ce9d78bbb4450d26dcb1ecf8dfd78e3c"
  :revdesc "06a1c846ce9d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
