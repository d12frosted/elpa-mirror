;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20261031.30"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "aff0092735681f809a904baef13aaecec2ec7a36"
  :revdesc "aff009273568"
  :keywords '("convenience" "lisp"))
