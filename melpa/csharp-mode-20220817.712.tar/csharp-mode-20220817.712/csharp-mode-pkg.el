(define-package "csharp-mode" "20220817.712" "C# mode derived mode"
  '((emacs "26.1"))
  :commit "7d7bf8895ba7d34f941169be69a8abaaf7e044ca" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
