(define-package "citre" "20210712.1207" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "45d3fe691b622f95f5525ff425243189d9705bdd" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
