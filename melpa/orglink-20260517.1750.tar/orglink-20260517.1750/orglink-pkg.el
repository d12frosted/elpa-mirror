;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglink" "20260517.1750"
  "Use Org Mode links in other modes."
  '((emacs  "26.1")
    (compat "31.0")
    (llama  "1.0")
    (org    "9.7")
    (seq    "2.24"))
  :url "https://github.com/tarsius/orglink"
  :commit "e3c3999c4a88acd46208bef4f014fc2245f494a8"
  :revdesc "e3c3999c4a88"
  :keywords '("hypermedia")
  :authors '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev")))
