(define-package "moe-theme" "20210308.1053" "A colorful eye-candy theme. Moe, moe, kyun!" 'nil :commit "d432815230f4e62d3f38a0819621ff227f780522" :authors
  '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainer
  '("kuanyui" . "azazabc123@gmail.com")
  :keywords
  '("themes")
  :url "https://github.com/kuanyui/moe-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
