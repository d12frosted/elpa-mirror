;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260424.1321"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "00b73f7ca78d4518ef20eb787a0afb638b8726c4"
  :revdesc "00b73f7ca78d"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
