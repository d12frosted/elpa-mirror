(define-package "buttercup" "20221204.2303" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "6a1a678ca76a525e6f9f34c5f2c8d9a1e11308b3" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
