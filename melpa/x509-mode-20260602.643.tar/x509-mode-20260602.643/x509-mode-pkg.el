;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20260602.643"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "3d1a4b3973212b26774b43f7450ff320bec54afe"
  :revdesc "3d1a4b397321"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
