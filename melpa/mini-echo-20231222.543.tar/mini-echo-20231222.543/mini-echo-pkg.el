(define-package "mini-echo" "20231222.543" "Echo buffer status in minibuffer window"
  '((emacs "29.1"))
  :commit "ca2e2f8186243c7a28f0b05ea3f564da3806215f" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
