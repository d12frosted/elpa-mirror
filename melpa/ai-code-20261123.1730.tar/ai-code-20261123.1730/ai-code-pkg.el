;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261123.1730"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "faad9277ba7db7759a6c3a351b65eeaf8d6abbe5"
  :revdesc "faad9277ba7d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
