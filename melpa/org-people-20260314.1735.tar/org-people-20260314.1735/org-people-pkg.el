;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260314.1735"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "996a72101bd003fdfebeb6c41bfad64a1067ebd8"
  :revdesc "996a72101bd0"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
