(define-package "maxima" "20220531.1751" "Major mode for Maxima"
  '((emacs "25.1")
    (s "1.11.0")
    (test-simple "1.3.0"))
  :commit "02ca33f2fa3c2fff22e13a07bfe0e65f39f120c2" :authors
  '(("William F. Schelter")
    ("Jay Belanger")
    ("Fermin Munoz"))
  :maintainer
  '("Fermin Munoz" . "fmfs@posteo.net")
  :keywords
  '("maxima" "tools" "math")
  :url "https://gitlab.com/sasanidas/maxima")
;; Local Variables:
;; no-byte-compile: t
;; End:
