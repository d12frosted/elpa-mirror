;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260907.2350"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "5fd9336e13d54f1359d47c9d8bc98a27b2d368ee"
  :revdesc "5fd9336e13d5")
