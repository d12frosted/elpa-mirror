(define-package "uptimes" "20231008.2125" "Track and display Emacs session uptimes."
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "b2420c297b7d9b06de7025752a7d8c328a29419b" :authors
  '(("Dave Pearson" . "davep@davep.org"))
  :maintainers
  '(("Dave Pearson" . "davep@davep.org"))
  :maintainer
  '("Dave Pearson" . "davep@davep.org")
  :keywords
  '("processes" "uptime")
  :url "https://github.com/davep/uptimes.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
