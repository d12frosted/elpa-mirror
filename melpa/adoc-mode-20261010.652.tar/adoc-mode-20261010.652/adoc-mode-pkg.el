;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20261010.652"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "fee5fa3916334ddf82a2149f661972acf251760e"
  :revdesc "fee5fa391633"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
