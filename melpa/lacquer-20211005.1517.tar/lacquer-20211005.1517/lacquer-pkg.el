(define-package "lacquer" "20211005.1517" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "6609581a58ae9c0124de785b056f4f5bbcec3b61" :authors
  '(("dingansich_kum0" . "zy.hua1122@outlook.com"))
  :maintainer
  '("dingansich_kum0" . "zy.hua1122@outlook.com")
  :keywords
  '("tools")
  :url "https://github.com/dingansichKum0/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
