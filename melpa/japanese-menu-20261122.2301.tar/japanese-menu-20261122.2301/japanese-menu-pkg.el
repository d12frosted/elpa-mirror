;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "japanese-menu" "20261122.2301"
  "Japanese menu translation."
  '((emacs "26.1"))
  :url "https://github.com/yt-emacs-ja/emacs-japanese-menu"
  :commit "735f57862271edc750d35117ccaa5875a81ef749"
  :revdesc "735f57862271"
  :keywords '("convenience" "japanese" "menu")
  :authors '(("yt-emacs-ja" . "https://github.com/yt-emacs-ja"))
  :maintainers '(("yt-emacs-ja" . "https://github.com/yt-emacs-ja")))
