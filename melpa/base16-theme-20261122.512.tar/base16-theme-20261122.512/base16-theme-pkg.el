;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20261122.512"
  "A set of base16 themes for your favorite editor."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "e2aa701f6f73cd3d658ddc48e23e17caaaa77808"
  :revdesc "e2aa701f6f73"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
