(define-package "org-ml" "20220601.1412" "Functional Org Mode API"
  '((emacs "27.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "f191ebfee6dcf6a05b5d1db43cf75f4a20faa8b4" :authors
  '(("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  '("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :keywords
  '("org-mode" "outlines")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
