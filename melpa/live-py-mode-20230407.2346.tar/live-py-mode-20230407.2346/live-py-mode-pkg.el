(define-package "live-py-mode" "20230407.2346" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "5371af2fde4a51295dc60ac0ffe78ff58d767990" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
