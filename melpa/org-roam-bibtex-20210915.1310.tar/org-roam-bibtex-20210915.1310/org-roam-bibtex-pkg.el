(define-package "org-roam-bibtex" "20210915.1310" "Org Roam meets BibTeX"
  '((emacs "27.2")
    (org-roam "2.0.0")
    (bibtex-completion "2.0.0")
    (org-ref "1.1.1"))
  :commit "2c15e43d827cd4c75e5484903dea6325ceccb103" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
