;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-denote" "20260227.2236"
  "Minor mode integrating Citar and Denote."
  '((emacs  "28.1")
    (citar  "1.4")
    (denote "4.1")
    (dash   "2.19.1"))
  :url "https://github.com/pprevos/citar-denote"
  :commit "d41ac804e073dd96d991217e351669aa5e2c75c6"
  :revdesc "d41ac804e073"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
