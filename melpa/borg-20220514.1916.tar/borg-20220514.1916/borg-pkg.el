(define-package "borg" "20220514.1916" "Assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "04df5cac8c3ba8981833feabd15a87af319f734b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
