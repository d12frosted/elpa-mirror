;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260812.1355"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "fd53e45e098e6efd8ce0dac29f23ddd1819b9695"
  :revdesc "fd53e45e098e"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
