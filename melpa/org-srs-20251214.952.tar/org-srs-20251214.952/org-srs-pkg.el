;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251214.952"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "df683bdaf46cd999dd73fc2f20d10992630464f0"
  :revdesc "df683bdaf46c"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
