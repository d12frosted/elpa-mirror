(define-package "embark" "20210730.2247" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "fd7eb416e9952265613d239b0338cc0388ab965b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
