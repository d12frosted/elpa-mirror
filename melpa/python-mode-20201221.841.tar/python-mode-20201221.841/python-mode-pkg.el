(define-package "python-mode" "20201221.841" "Python major mode" 'nil :commit "2f35bd5b4590c7b708b30adbd4c46bba1b43038b" :authors
  (("2015-2020 https://gitlab.com/groups/python-mode-devs")
   ("2003-2014 https://launchpad.net/python-mode")
   ("1995-2002 Barry A. Warsaw")
   ("1992-1994 Tim Peters"))
  :maintainer
  (nil . "python-mode@python.org")
  :keywords
  ("languages" "processes" "python" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
