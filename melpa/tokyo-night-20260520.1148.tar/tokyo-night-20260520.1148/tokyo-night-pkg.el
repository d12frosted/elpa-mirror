;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20260520.1148"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "e4c2f466c83477952b7e97db33cfae873ed20be2"
  :revdesc "e4c2f466c834"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
