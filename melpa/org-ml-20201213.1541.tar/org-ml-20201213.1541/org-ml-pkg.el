(define-package "org-ml" "20201213.1541" "Functional Org Mode API"
  '((emacs "26.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "386026a89989f39ce9041154647859362c26d0c4" :keywords
  ("org-mode" "outlines")
  :authors
  (("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  ("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
