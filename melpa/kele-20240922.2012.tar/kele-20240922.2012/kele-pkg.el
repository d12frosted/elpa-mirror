(define-package "kele" "20240922.2012" "Spritzy Kubernetes cluster management"
  '((emacs "29.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (memoize "0")
    (plz "0.8.0")
    (s "1.13.0")
    (yaml "0.5.1"))
  :commit "9d0763776642b98094bfdfd4802a6038b5b732e9" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
