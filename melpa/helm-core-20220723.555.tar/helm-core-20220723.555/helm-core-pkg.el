(define-package "helm-core" "20220723.555" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "8af377a9cb52051d98caf710845d9d456e6290ee" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
