;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260521.706"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "cfc995702685baea5c71bc1521242b1876787dff"
  :revdesc "cfc995702685"
  :keywords '("convenience" "input method" "dbus"))
