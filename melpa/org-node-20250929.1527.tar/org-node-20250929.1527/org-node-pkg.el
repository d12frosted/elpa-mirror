;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250929.1527"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.20.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "7fa41ad904e72b0a24b64301d0de97f83a639c21"
  :revdesc "7fa41ad904e7"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
