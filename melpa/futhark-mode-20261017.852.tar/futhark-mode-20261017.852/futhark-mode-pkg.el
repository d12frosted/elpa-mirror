;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "futhark-mode" "20261017.852"
  "Major mode for editing Futhark source files."
  '((emacs       "24.3")
    (cl-lib      "0.5")
    (reformatter "0.4"))
  :url "https://github.com/diku-dk/futhark-mode"
  :commit "70dec794df3e6a5535ae23b2a69ef98c1122d71a"
  :revdesc "70dec794df3e"
  :keywords '("languages"))
