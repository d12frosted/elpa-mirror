(define-package "embark-org-roam" "20240303.326" "Embark export buffer for org roam nodes"
  '((emacs "27.1")
    (embark "0.23")
    (org-roam "2.2.0"))
  :commit "acc554bc40cdea886452b7a23bed2940665effb0" :authors
  '(("Bram Adams" . "bram.adams@queensu.ca"))
  :maintainers
  '(("Bram Adams" . "bram.adams@queensu.ca"))
  :maintainer
  '("Bram Adams" . "bram.adams@queensu.ca")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/bramadams/embark-org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
