(define-package "posframe" "20211024.1304" "Pop a posframe (just a frame) at point"
  '((emacs "26"))
  :commit "e5ca8bf12294aaf7496f978a56bb917bfa22a5a7" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
