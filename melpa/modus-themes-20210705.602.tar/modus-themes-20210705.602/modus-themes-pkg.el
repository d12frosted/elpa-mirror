(define-package "modus-themes" "20210705.602" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "52b0cd1a040b49a8d9fe97d582a055403fcdf5de" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
