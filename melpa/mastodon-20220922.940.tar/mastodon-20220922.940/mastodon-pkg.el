(define-package "mastodon" "20220922.940" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4"))
  :commit "6b88c28779bd64aaf56c9d1e0c5fced77a506c0a" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
