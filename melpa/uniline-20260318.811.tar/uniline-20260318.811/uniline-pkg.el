;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260318.811"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "2916cabe8e9c588a612fd896d0be4611bd1ad4e8"
  :revdesc "2916cabe8e9c"
  :keywords '("convenience" "text"))
