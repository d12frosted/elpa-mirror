(define-package "marginalia" "20210123.26" "Enrich existing commands with completion annotations"
  '((emacs "26.1"))
  :commit "5d15697804a6ee2d46b0187eea2bf0d01ed422b1" :authors
  '(("Omar Antolín Camarena, Daniel Mendler"))
  :maintainer
  '("Omar Antolín Camarena, Daniel Mendler")
  :url "https://github.com/minad/marginalia")
;; Local Variables:
;; no-byte-compile: t
;; End:
