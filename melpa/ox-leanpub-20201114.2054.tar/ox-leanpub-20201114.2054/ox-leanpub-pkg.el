(define-package "ox-leanpub" "20201114.2054" "Export Org documents to Leanpub book format"
  '((org "9.1")
    (ox-gfm "1.0")
    (emacs "26.1")
    (s "1.12.0"))
  :commit "a63f6ffed224865b1fbfbc3a63d628dc3cdc31ae" :keywords
  ("files" "org" "leanpub")
  :authors
  (("Diego Zamboni" . "diego@zzamboni.org"))
  :maintainer
  ("Diego Zamboni" . "diego@zzamboni.org")
  :url "https://gitlab.com/zzamboni/ox-leanpub")
;; Local Variables:
;; no-byte-compile: t
;; End:
