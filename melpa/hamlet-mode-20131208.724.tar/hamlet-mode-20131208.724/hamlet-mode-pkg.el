;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hamlet-mode" "20131208.724"
  "Hamlet editing mode."
  '((cl-lib "0.3")
    (dash   "2.3.0")
    (s      "1.7.0"))
  :url "https://github.com/lightquake/hamlet-mode"
  :commit "7362b955e556a3d007fa06945a27e5b99349527d"
  :revdesc "7362b955e556"
  :keywords '("wp" "languages" "comm")
  :authors '(("Kata" . "lightquake@amateurtopologist.com"))
  :maintainers '(("Kata" . "lightquake@amateurtopologist.com")))
