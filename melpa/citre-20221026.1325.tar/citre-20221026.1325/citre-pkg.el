(define-package "citre" "20221026.1325" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "bce7ad69e1a1947232de7368eb18e75bd159ba65" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
