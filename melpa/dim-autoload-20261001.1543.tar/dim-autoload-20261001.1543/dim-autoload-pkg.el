;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dim-autoload" "20261001.1543"
  "Dim or hide autoload cookie lines."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/dim-autoload"
  :commit "c093abc77680613c96c42ee0c9e2edc4a76bb0d8"
  :revdesc "c093abc77680"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.dim-autoload@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.dim-autoload@jonas.bernoulli.dev")))
