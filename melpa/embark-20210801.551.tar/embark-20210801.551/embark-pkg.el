(define-package "embark" "20210801.551" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "f0018688f8389fc84b0d4df508120bb69c9f5442" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
