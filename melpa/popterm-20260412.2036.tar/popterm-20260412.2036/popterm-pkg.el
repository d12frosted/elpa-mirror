;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260412.2036"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "a84598e42becacc78b270698838b6d5f6e1e3655"
  :revdesc "a84598e42bec"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
