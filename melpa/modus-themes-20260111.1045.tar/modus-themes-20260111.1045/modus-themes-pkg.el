;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260111.1045"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "4d9a19513debce59e0cc027aafaaa13a397fe12d"
  :revdesc "4d9a19513deb"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
