(define-package "detached" "20221006.1447" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "fe4003c870b93a8f1a2a2503d09e56427a30739c" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
