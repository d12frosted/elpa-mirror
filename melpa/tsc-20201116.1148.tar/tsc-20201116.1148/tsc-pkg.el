(define-package "tsc" "20201116.1148" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "4c46854b716e9efee62df3d794b3a10313525f0b" :keywords
  ("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
   ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
