(define-package "tsc" "20201116.1148" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "43fc289dd1a8ba63bb97e5b09750bc9f211eadb5" :keywords
  ("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
   ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
