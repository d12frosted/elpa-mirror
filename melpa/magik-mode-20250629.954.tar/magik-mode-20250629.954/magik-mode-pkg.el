;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250629.954"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "7ce63035af71114d6c2f3cd1fb6bc696ea2dedbb"
  :revdesc "7ce63035af71"
  :keywords '("languages"))
