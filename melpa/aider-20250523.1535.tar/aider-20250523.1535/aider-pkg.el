;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250523.1535"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "90c311c809075fd74cd0d98edb05353480fe663b"
  :revdesc "90c311c80907"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
