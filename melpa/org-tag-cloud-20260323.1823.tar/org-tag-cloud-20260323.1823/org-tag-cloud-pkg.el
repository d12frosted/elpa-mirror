;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-cloud" "20260323.1823"
  "Easily maintain a tag-cloud of org-mode tags."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-tag-cloud"
  :commit "8e1a9f3e868011551a0f7d00b3ae4771dac93809"
  :revdesc "8e1a9f3e8680"
  :keywords '("outlines" "tagcloud" "tags")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
