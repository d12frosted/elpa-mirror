;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260704.1037"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "8c628bc470901e0936c3816eec280213d75a9a4d"
  :revdesc "8c628bc47090"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
