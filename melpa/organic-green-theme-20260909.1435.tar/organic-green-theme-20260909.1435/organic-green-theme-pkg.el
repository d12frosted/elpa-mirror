;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20260909.1435"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "b0fe9c9e1486ba5b1446224050cfc600692e1dfb"
  :revdesc "b0fe9c9e1486"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
