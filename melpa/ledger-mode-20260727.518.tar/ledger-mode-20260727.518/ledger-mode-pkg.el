;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "20260727.518"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "b0e71b7e9ee612ccb0b0e5f8bfefcfddb69ae861"
  :revdesc "b0e71b7e9ee6")
