;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260228.525"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "1b23d7cb1598c1f15cf9b14cdceb67b19e9a407d"
  :revdesc "1b23d7cb1598"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
