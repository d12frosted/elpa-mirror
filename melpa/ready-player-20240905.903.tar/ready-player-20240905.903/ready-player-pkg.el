(define-package "ready-player" "20240905.903" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "5762ba949001eb043a7e23970fd1fce5ec833a7a" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
