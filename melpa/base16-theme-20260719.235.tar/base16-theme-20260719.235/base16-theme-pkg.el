;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260719.235"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "0fa7a37a5140cc64f44ef404309b8961d2e46562"
  :revdesc "0fa7a37a5140"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
