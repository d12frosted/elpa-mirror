(define-package "wildcharm-light-theme" "20230809.2330" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "a26bb76e2ddfe722c7cd074e09542853d29477e5" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
