(define-package "consult" "20210708.1014" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "4a810cc72687791d9159f47d09cb11a1d88963fd" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
