;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260225.556"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "24.4")
    (dash  "2.9.0"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "d194c4777f0a8e970864cd316fc3b93cfc34e6b2"
  :revdesc "d194c4777f0a"
  :keywords '("programming"))
