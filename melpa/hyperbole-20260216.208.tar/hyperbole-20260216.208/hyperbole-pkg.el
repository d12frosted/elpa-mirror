;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260216.208"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "09dfbc4831574f741079edc1bcbf4ff4d6da8a81"
  :revdesc "09dfbc483157"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
