(define-package "naga-theme" "20240306.2013" "Dark color theme with green foreground color"
  '((emacs "24.1"))
  :commit "eed957239803debe1198f361da3e821bb69283f7" :authors
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainers
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainer
  '("Johannes Maier" . "johannes.maier@mailbox.org")
  :keywords
  '("faces" "themes")
  :url "https://github.com/kenranunderscore/emacs-naga-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
