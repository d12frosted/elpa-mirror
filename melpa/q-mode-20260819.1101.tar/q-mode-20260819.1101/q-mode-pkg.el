;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260819.1101"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "e0f6a052c476d7ab0a16a0c62cc52a01a373f4e9"
  :revdesc "e0f6a052c476"
  :keywords '("faces" "files" "q"))
