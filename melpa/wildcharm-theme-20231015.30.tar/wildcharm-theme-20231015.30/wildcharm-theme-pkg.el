(define-package "wildcharm-theme" "20231015.30" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "14f29cfa8d185b544a481012e3bc33cbe5338dd4" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
