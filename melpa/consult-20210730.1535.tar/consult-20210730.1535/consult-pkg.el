(define-package "consult" "20210730.1535" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "69bbd213dc8a98abe94a4f5b1920e3d689d31caa" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
