(define-package "org-ref" "20220524.1219" "citations, cross-references and bibliographies in org-mode"
  '((org "9.4")
    (dash "0")
    (s "0")
    (f "0")
    (htmlize "0")
    (hydra "0")
    (avy "0")
    (parsebib "0")
    (bibtex-completion "0")
    (citeproc "0")
    (ox-pandoc "0"))
  :commit "2d91eba9274a79f908723a4a215e0f0b5c04ed01" :authors
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainer
  '("John Kitchin" . "jkitchin@andrew.cmu.edu")
  :keywords
  '("org-mode" "cite" "ref" "label")
  :url "https://github.com/jkitchin/org-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
