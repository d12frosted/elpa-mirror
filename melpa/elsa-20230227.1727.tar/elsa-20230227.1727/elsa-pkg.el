(define-package "elsa" "20230227.1727" "Emacs Lisp Static Analyser"
  '((emacs "25.1")
    (trinary "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3")
    (lsp-mode "0"))
  :commit "cd47ebc0054caf1a9e784c6228f9cab2a9e6c723" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
