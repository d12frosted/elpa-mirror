(define-package "shm" "20150217.1308" "Structured Haskell Mode" 'nil :commit "8abc5cd73e59ea85bef906e14e87dc388c4f350f" :authors
  '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainer
  '("Chris Done" . "chrisdone@gmail.com")
  :keywords
  '("development" "haskell" "structured"))
;; Local Variables:
;; no-byte-compile: t
;; End:
