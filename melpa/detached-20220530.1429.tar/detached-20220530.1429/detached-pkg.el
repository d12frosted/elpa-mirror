(define-package "detached" "20220530.1429" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "bae90a13ddff90fcbfa581a1e8556072e01fd09b" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
