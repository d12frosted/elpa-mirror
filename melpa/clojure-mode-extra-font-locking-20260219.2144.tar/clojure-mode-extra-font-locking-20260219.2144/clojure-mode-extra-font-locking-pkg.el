;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode-extra-font-locking" "20260219.2144"
  "Extra font-locking for Clojure mode."
  '((clojure-mode "5.21.0"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "b9a648b148487677323c853d1c600be4e65d9351"
  :revdesc "b9a648b14848"
  :keywords '("languages" "lisp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
