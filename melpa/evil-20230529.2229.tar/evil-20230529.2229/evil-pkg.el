(define-package "evil" "20230529.2229" "Extensible Vi layer for Emacs."
  '((emacs "24.1")
    (goto-chg "1.6")
    (cl-lib "0.5"))
  :commit "42f4b7736f5746fd5d072139280997985ea42269" :maintainer
  '("Tom Dalziel" . "tom.dalziel@gmail.com")
  :keywords
  '("emulations")
  :url "https://github.com/emacs-evil/evil")
;; Local Variables:
;; no-byte-compile: t
;; End:
