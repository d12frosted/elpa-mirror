(define-package "for" "20220911.1100" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "c56ee0ee4906fa8f9843f4280e486a79adfe31c4" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
