(define-package "sly" "20210603.1451" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "53d50fbff09dff955ed8ab50c585e3831a3836e3" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
