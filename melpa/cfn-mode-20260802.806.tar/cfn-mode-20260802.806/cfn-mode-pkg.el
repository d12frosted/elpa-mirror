;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260802.806"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "46776788b43391ae6a2d6223360d1f144d2bcd69"
  :revdesc "46776788b433"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
