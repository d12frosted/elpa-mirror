(define-package "embark" "20210220.1926" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "52968cf024fb10954764fee26516f92bc4d13882" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
