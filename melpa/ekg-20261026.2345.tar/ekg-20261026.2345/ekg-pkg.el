;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261026.2345"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "fc62197ec994bb13225044c8066f9d2f1cc12e1e"
  :revdesc "fc62197ec994"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
