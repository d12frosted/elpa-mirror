(define-package "mb-url" "20210917.1715" "Multiple Backends for Emacs URL package"
  '((emacs "24.4"))
  :commit "ac82a66826a4b03533e7e995d83ed4f019b8968a" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
