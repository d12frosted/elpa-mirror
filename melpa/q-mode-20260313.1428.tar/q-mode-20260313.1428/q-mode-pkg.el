;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260313.1428"
  "A q editing mode."
  '((emacs "24"))
  :url "https://github.com/psaris/q-mode"
  :commit "5fa1e2bcec67107c009625c534bb7f8071a8e741"
  :revdesc "5fa1e2bcec67"
  :keywords '("faces" "files" "q"))
