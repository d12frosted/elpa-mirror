(define-package "dirvish" "20220105.1016" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "ce849870836994f8d560cdb9cad1328b0d13e00f" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
