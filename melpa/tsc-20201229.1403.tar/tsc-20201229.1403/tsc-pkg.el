(define-package "tsc" "20201229.1403" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "076865a6c879840ab61e0aa7b336a2e3e1f97cd4" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
    ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
