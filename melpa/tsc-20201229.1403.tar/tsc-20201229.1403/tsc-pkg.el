(define-package "tsc" "20201229.1403" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "e7f2f625c1b9a2dce4f6b16a5affbb4f57337ae0" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
    ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
