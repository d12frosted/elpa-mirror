(define-package "eldoc-box" "20230921.401" "Display documentation in childframe"
  '((emacs "27.1"))
  :commit "270a9a8948fc3f4ba3547b5584597841f93c7828" :authors
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainer
  '("Yuan Fu" . "casouri@gmail.com")
  :url "https://github.com/casouri/eldoc-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
