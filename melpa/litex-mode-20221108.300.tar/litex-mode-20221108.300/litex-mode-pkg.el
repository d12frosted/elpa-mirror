(define-package "litex-mode" "20221108.300" "Minor mode for converting lisp to LaTeX"
  '((emacs "24.4")
    (units-mode "0.1.1"))
  :commit "72e20233db66cb37306bdc066c68e6d7086ab3c4" :authors
  '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainer
  '("Gaurav Atreya" . "allmanpride@gmail.com")
  :keywords
  '("calculator" "lisp" "latex")
  :url "https://github.com/Atreyagaurav/litex-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
