(define-package "semi" "20220427.1124" "A library to provide MIME features."
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9"))
  :commit "dca60ff62fcd5abb9f7e92a8e75f2b282112c7dd")
;; Local Variables:
;; no-byte-compile: t
;; End:
