;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251105.807"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "1b663444fed07f0c622f67c1bdcde2804bc06c1e"
  :revdesc "1b663444fed0"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
