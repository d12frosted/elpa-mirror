(define-package "isearch-project" "20231103.1007" "Incremental search through the whole project"
  '((emacs "27.1")
    (f "0.20.0"))
  :commit "167e34130687ef338efe3251daa2a141fa0f141d" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "search")
  :url "https://github.com/jcs-elpa/isearch-project")
;; Local Variables:
;; no-byte-compile: t
;; End:
