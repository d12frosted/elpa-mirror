(define-package "flutter" "20220502.50" "Tools for working with Flutter SDK"
  '((emacs "25.1"))
  :commit "e49cbcb70235fa39a7d243521e03ad874451a39a" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("languages")
  :url "https://github.com/amake/flutter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
