;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250225.833"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.1")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "462b0faf3a797ca8f299a2e3297f9d28381ed3b8"
  :revdesc "462b0faf3a79"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
