;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bert" "20131117.1014"
  "BERT serialization library for Emacs."
  ()
  :url "https://github.com/manzyuk/bert-el"
  :commit "a3eec6980a725aa4abd2019e4c00246450260490"
  :revdesc "a3eec6980a72"
  :keywords '("comm" "data")
  :authors '(("Oleksandr Manzyuk" . "manzyuk@gmail.com"))
  :maintainers '(("Oleksandr Manzyuk" . "manzyuk@gmail.com")))
