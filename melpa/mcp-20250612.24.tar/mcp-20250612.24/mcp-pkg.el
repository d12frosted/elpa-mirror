;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp" "20250612.24"
  "Model Context Protocol."
  '((emacs   "30.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/lizqwerscott/mcp.el"
  :commit "3a380185597f56290057f370ab65dde89a20a18f"
  :revdesc "3a380185597f"
  :keywords '("tools")
  :authors '(("lizqwer scott" . "lizqwerscott@gmail.com"))
  :maintainers '(("lizqwer scott" . "lizqwerscott@gmail.com")))
