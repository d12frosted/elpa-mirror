(define-package "detached" "20221005.1112" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "fdf05c63a3013cfaf095c616e330cafffe8b3d68" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
