(define-package "react-snippets" "20170803.2250" "Yasnippets for React"
  '((yasnippet "0.7.0"))
  :commit "bfc4b68b81374a6a080240592641091a7e8a6d61" :authors
  '(("John Mastro" . "john.b.mastro@gmail.com"))
  :maintainer
  '("John Mastro" . "john.b.mastro@gmail.com")
  :keywords
  '("snippets"))
;; Local Variables:
;; no-byte-compile: t
;; End:
