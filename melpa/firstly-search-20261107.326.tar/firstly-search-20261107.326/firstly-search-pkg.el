;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "20261107.326"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "30.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "2f3cc2e0837bb16a1a15646787f27c75e44056a7"
  :revdesc "2f3cc2e0837b"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
