(define-package "eldev" "20220718.1906" "Elisp development tool"
  '((emacs "24.4"))
  :commit "e6452da5697b71083de888156babd8c0b8006585" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
