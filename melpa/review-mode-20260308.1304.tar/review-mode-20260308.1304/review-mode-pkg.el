;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "review-mode" "20260308.1304"
  "Major mode for ReVIEW."
  ()
  :url "https://github.com/kmuto/review-el"
  :commit "b173db73d9477e88fa1b85415a3d3f9ca91febe9"
  :revdesc "b173db73d947"
  :authors '(("Kenshi Muto" . "kmuto@kmuto.jp"))
  :maintainers '(("Kenshi Muto" . "kmuto@kmuto.jp")))
