;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260415.1216"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "0a90eac6ec24377ff9aeb718c28103ffbaeedeb4"
  :revdesc "0a90eac6ec24"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
