;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lf" "20261013.1851"
  "A Language Features library for Emacs Lisp."
  '((s     "1.12.0")
    (dash  "2.16.0")
    (emacs "27.1"))
  :url "https://alhassy.github.io/lf.el/"
  :commit "d48230ba3871f6744feee63da622e60b8b49b16f"
  :revdesc "d48230ba3871"
  :keywords '("convenience" "programming")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
