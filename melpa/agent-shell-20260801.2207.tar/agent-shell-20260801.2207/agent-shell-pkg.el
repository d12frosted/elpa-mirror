;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260801.2207"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "86e306298a000f3af38aa0c7dc691b1179e4d9de"
  :revdesc "86e306298a00")
