;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260630.745"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "1df5e9c7f7a165af10d04587a8053f9b2c809da2"
  :revdesc "1df5e9c7f7a1"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
