;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-latte" "20260213.555"
  "Auto-highlight unlinked Org-roam references."
  '((emacs       "27.1")
    (org-roam    "2.0")
    (inflections "1.1"))
  :url "https://github.com/yad-tahir/org-roam-latte"
  :commit "28df5361d8b90b1ee739a11c6c1accdcb58cb08d"
  :revdesc "28df5361d8b9"
  :keywords '("hypermedia" "outlines" "org-roam" "convenience")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
