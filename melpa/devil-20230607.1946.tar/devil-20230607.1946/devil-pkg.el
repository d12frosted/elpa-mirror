(define-package "devil" "20230607.1946" "Minor mode for translating key sequences"
  '((emacs "24.4"))
  :commit "e9d2024b695b14a318f74f08774548292021fb69" :authors
  '(("Susam Pal" . "susam@susam.net"))
  :maintainers
  '(("Susam Pal" . "susam@susam.net"))
  :maintainer
  '("Susam Pal" . "susam@susam.net")
  :keywords
  '("convenience" "abbrev")
  :url "https://github.com/susam/devil")
;; Local Variables:
;; no-byte-compile: t
;; End:
