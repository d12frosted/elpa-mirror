;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "major-mode-icons" "20220210.1404"
  "Display icon for major-mode on mode-line."
  '((emacs         "24.3")
    (powerline     "2.4")
    (all-the-icons "2.3.0"))
  :url "https://repo.or.cz/major-mode-icons.git"
  :commit "b0214e0af13cd3691c4d28f03e3108bd98ec7a85"
  :revdesc "b0214e0af13c"
  :keywords '("frames" "multimedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
