;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241123.1100"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "4bf0f712fe58ed011172a20c50cbc0180f3057dd"
  :revdesc "4bf0f712fe58"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
