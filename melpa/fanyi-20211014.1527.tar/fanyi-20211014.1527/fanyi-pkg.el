(define-package "fanyi" "20211014.1527" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "eff1c508df6017d6dfc2fae9de6a6f0c92ce9949" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
