;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251105.311"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a73c890f47c4b5d9a5b833ee5694def4938eaa4d"
  :revdesc "a73c890f47c4"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
