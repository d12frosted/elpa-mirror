(define-package "boon" "20230214.2035" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "786cf085a9af60083279297c599d5ea0f744efba")
;; Local Variables:
;; no-byte-compile: t
;; End:
