;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260306.535"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "50bf206dced76fdda5c77ce62d88144c079e40be"
  :revdesc "50bf206dced7"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
