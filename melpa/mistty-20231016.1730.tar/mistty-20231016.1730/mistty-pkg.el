(define-package "mistty" "20231016.1730" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "2524edeff25ec4d51fbef1ac005a0b6a92a10b56" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
