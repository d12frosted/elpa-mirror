;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260217.2111"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "6edbdfc3ef39539e36dd91512e98637fb27f9e76"
  :revdesc "6edbdfc3ef39"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
