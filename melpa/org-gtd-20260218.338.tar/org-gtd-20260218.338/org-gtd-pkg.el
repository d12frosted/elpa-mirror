;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gtd" "20260218.338"
  "An implementation of GTD."
  '((emacs     "28.1")
    (compat    "30.0.0.0")
    (org-edna  "1.1.2")
    (f         "0.20.0")
    (org       "9.6")
    (transient "0.11.0")
    (dag-draw  "1.0.4"))
  :url "https://github.com/Trevoke/org-gtd.el"
  :commit "8502f62a776e0626400984a5cbce99d05ca57c18"
  :revdesc "8502f62a776e"
  :authors '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainers '(("Aldric Giacomoni" . "trevoke@gmail.com")))
