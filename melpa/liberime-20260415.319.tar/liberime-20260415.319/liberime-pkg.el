;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260415.319"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "149c1926952bf65a9647e8420378c23ecf4eed84"
  :revdesc "149c1926952b"
  :keywords '("convenience" "chinese" "input-method" "rime"))
