;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20260514.248"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "b8a6dc8e87de6f1845f88349d8e554bb8d25a7a0"
  :revdesc "b8a6dc8e87de"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
