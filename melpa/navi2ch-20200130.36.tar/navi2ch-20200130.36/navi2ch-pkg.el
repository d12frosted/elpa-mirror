(define-package "navi2ch" "20200130.36" "Navigator for 2ch for Emacsen" 'nil :commit "7811dba052f679bd920a1f648d621a6fecace10f" :authors
  (("Taiki SUGAWARA" . "taiki@users.sourceforge.net"))
  :maintainer
  ("Taiki SUGAWARA" . "taiki@users.sourceforge.net")
  :keywords
  ("network" "2ch"))
;; Local Variables:
;; no-byte-compile: t
;; End:
