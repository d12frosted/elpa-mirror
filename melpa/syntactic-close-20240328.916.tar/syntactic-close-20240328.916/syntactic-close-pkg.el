(define-package "syntactic-close" "20240328.916" "Insert closing delimiter"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "cd31774136af5bc949ea842c78c7f6df6bc81301" :authors
  '(("Andreas Röhler" . "andreas.roehler@online.de")
    ("Emacs User Group Berlin" . "emacs-berlin@emacs-berlin.org"))
  :maintainers
  '(("Andreas Röhler" . "andreas.roehler@online.de"))
  :maintainer
  '("Andreas Röhler" . "andreas.roehler@online.de")
  :keywords
  '("languages" "convenience")
  :url "https://github.com/emacs-berlin/syntactic-close")
;; Local Variables:
;; no-byte-compile: t
;; End:
