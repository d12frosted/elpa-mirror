;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250509.746"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "58f2677f88235d0c6295a98a37c209e0fa824032"
  :revdesc "58f2677f8823"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
