(define-package "spdx" "20210226.1448" "Insert SPDX license and copyright headers"
  '((emacs "24.1"))
  :commit "1111f3ab067b83965da15697bc8a6e4f68e37bf4" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
