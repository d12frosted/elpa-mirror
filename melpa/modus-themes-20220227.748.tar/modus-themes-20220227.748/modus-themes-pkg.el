(define-package "modus-themes" "20220227.748" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "404a9658196debdde95a51148fc62c5b2faccfb9" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
