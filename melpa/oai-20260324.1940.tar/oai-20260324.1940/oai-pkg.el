;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260324.1940"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "02834436a0a42e1f66780449ce83ba33e2d392a3"
  :revdesc "02834436a0a4"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
