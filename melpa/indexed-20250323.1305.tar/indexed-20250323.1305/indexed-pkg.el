;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250323.1305"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (el-job "2.2.0")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "ee98e3c55a2a3d9ebf462e1b0e65e9a532fb33b2"
  :revdesc "ee98e3c55a2a"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
