;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "strie" "20160211.2222"
  "A simple trie data structure implementation."
  '((cl-lib "0.5"))
  :url "https://github.com/jcatw/strie.el"
  :commit "eb7efb0cccc127c414f6a64db11454869d9c10a8"
  :revdesc "eb7efb0cccc1"
  :authors '(("James Atwood" . "jatwood@cs.umass.edu"))
  :maintainers '(("James Atwood" . "jatwood@cs.umass.edu")))
