(define-package "sumibi" "20230610.739" "Japanese input method powered by ChatGPT API"
  '((emacs "28.1")
    (popup "0.5.9")
    (unicode-escape "1.1")
    (deferred "0.5.1"))
  :commit "2705b96eec49e742f661651cebfc7b4c3e6c5416" :authors
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainer
  '("Kiyoka Nishiyama" . "kiyoka@sumibi.org")
  :keywords
  '("lisp" "ime" "japanese")
  :url "https://github.com/kiyoka/Sumibi")
;; Local Variables:
;; no-byte-compile: t
;; End:
