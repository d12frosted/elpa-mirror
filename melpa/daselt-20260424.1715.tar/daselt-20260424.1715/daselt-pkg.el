;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260424.1715"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "7cc83064166c8db951fdcb932d118ce6fe904ada"
  :revdesc "7cc83064166c"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
