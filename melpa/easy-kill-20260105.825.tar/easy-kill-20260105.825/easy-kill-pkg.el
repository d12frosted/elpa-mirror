;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-kill" "20260105.825"
  "Kill & mark things easily."
  '((emacs  "25")
    (cl-lib "0.5"))
  :url "https://github.com/leoliu/easy-kill"
  :commit "3c0fbada8ca555e120e3de2a65109aa8c6e02036"
  :revdesc "3c0fbada8ca5"
  :keywords '("killing" "convenience")
  :authors '(("Leo Liu" . "sdl.web@gmail.com"))
  :maintainers '(("Leo Liu" . "sdl.web@gmail.com")))
