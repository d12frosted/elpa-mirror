;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260611.1131"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "9857e72f953642cedc1286a04aebb7203226e6a8"
  :revdesc "9857e72f9536"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
