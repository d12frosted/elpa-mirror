(define-package "osm" "20230220.1723" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "6c0054004174840be106b3627a4b704a197bad6a" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
