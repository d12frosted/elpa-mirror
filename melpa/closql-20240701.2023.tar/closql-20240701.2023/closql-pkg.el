(define-package "closql" "20240701.2023" "Store EIEIO objects using EmacSQL"
  '((emacs "26.1")
    (compat "29.1.4.5")
    (emacsql "20240124"))
  :commit "47c263ce130fa79f6c124fe8cca7c9b1d323289e" :authors
  '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev")
  :keywords
  '("extensions")
  :url "https://github.com/emacscollective/closql")
;; Local Variables:
;; no-byte-compile: t
;; End:
