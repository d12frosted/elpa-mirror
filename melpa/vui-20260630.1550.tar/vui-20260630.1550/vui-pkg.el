;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260630.1550"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "1540158d84fea6031f1977869fd6d5ee3e6a2b99"
  :revdesc "1540158d84fe"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
