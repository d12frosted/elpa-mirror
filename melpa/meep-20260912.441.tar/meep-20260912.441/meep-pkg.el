;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260912.441"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "d136f23370aa2dc5275e3a7f686b7cc30eaff5f1"
  :revdesc "d136f23370aa"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
