(define-package "ox-linuxmag-fr" "20230505.644" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "2e22e72cf886db104b6a31172736f073bf743eb4" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
