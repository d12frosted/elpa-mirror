;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260204.1708"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "584bef80397396662af331cb64d5856f72596ff9"
  :revdesc "584bef803973"
  :keywords '("convenience"))
