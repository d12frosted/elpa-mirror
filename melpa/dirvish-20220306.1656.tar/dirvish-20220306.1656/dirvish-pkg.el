(define-package "dirvish" "20220306.1656" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "7846fb02cf84d6a585c6623cf695411e15dc0e80" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
