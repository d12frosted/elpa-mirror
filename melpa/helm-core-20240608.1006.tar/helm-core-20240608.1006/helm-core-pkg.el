(define-package "helm-core" "20240608.1006" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.8"))
  :commit "b19cd01e165bc5138c527ed8f07d8aa30a97e432" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
