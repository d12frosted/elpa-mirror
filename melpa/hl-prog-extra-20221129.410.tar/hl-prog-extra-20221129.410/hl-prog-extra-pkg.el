(define-package "hl-prog-extra" "20221129.410" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "1436f7307b12fc9538238f95c2b223436537ba3d" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
