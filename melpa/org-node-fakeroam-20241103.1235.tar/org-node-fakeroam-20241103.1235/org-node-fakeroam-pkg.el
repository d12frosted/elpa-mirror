;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node-fakeroam" "20241103.1235"
  "Stand-ins for org-roam-autosync-mode."
  '((emacs    "28.1")
    (compat   "30")
    (org-node "1.7.0")
    (org-roam "2.2.2")
    (emacsql  "4.0.3"))
  :url "https://github.com/meedstrom/org-node-fakeroam"
  :commit "1e4daef6e9bd190237705fdcbb3e6f6033b41277"
  :revdesc "1e4daef6e9bd"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
