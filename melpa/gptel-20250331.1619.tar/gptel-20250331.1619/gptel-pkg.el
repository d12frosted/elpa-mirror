;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250331.1619"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "dfd88798c1ca26b28c1eb1987cb9967a4fc4d712"
  :revdesc "dfd88798c1ca"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
