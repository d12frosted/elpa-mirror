;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dslide" "20241227.312"
  "Domain Specific sLIDEs. Programmable Presentation."
  '((emacs "29.2"))
  :url "https://github.com/positron-solutions/dslide"
  :commit "16ebe8ac72039049d95ec8dc44ad359da55bd313"
  :revdesc "16ebe8ac7203"
  :keywords '("convenience" "org-mode" "presentation" "narrowing")
  :authors '(("Positron" . "contact@positron.solutions"))
  :maintainers '(("Positron" . "contact@positron.solutions")))
