;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20251002.1207"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "ed7d2714a7767fe570fce980e8bfeb210e46a5b0"
  :revdesc "ed7d2714a776"
  :keywords '("languages"))
