;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250226.217"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "9f06a1361903921076b415d1b1f6d9fbb4379eff"
  :revdesc "9f06a1361903"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
