;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260427.100"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "1e64206f74856e1605a44860d9390dbb08920458"
  :revdesc "1e64206f7485"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
