;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minimal-dashboard" "20251102.1952"
  "A very minimal dashboard plugin."
  '((emacs "27.1"))
  :url "https://github.com/dheerajshenoy/minimal-dashboard.el"
  :commit "b7dbce88a19777c0d33df025e2b830094e521af8"
  :revdesc "b7dbce88a197"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com"))
  :maintainers '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com")))
