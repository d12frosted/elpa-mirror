;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "streak" "20240106.2145"
  "Track a daily streak in your Mode Line."
  '((emacs "27.1"))
  :url "https://github.com/fosskers/streak"
  :commit "2d56788cbbf6114e61c85dd57b05133f8f351ac6"
  :revdesc "2d56788cbbf6"
  :keywords '("calendar")
  :authors '(("Colin Woodbury" . "https://www.fosskers.ca"))
  :maintainers '(("Colin Woodbury" . "colin@fosskers.ca")))
