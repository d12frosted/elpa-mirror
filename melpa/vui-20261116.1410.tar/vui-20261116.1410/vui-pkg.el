;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261116.1410"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "004dd852746d8af838107dd7e3f44c5bbea04d79"
  :revdesc "004dd852746d"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
