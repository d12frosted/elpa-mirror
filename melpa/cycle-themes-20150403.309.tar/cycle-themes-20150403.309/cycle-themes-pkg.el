;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cycle-themes" "20150403.309"
  "A global minor mode to make switching themes easier."
  '((cl-lib "0.5"))
  :url "https://github.com/toroidal-code/cycle-themes.el"
  :commit "2660c3178be7b28c2cb5dde2dd70a4bd51dae3a2"
  :revdesc "2660c3178be7"
  :keywords '("themes" "utility" "global minor mode")
  :authors '(("Katherine Whitlock" . "toroidalcode@gmail.com"))
  :maintainers '(("Katherine Whitlock" . "toroidalcode@gmail.com")))
