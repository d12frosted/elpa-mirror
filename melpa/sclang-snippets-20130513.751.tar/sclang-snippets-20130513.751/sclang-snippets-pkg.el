;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sclang-snippets" "20130513.751"
  "Snippets for the SuperCollider Emacs mode."
  '((yasnippet "0.8.0"))
  :url "https://github.com/ptrv/sclang-snippets"
  :commit "c840a416b96f83bdd70491e3d1fbe2f1ae8b3f58"
  :revdesc "c840a416b96f"
  :keywords '("snippets")
  :authors '(("ptrv" . "mail@petervasil.net"))
  :maintainers '(("ptrv" . "mail@petervasil.net")))
