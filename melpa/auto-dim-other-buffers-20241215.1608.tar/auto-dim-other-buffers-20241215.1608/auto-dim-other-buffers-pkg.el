;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-dim-other-buffers" "20241215.1608"
  "Makes windows without focus less prominent."
  '((emacs "27.1"))
  :url "https://github.com/mina86/auto-dim-other-buffers.el"
  :commit "ea1626235ca5d2e80c265188cd134a724d180560"
  :revdesc "ea1626235ca5"
  :keywords '("faces")
  :authors '(("Michal Nazarewicz" . "mina86@mina86.com"))
  :maintainers '(("Michal Nazarewicz" . "mina86@mina86.com")))
