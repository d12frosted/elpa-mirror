(define-package "embark" "20220104.755" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c9b26c2e18f01ae401df6a69b7a0c1a6bc44b90c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
