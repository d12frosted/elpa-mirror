(define-package "consult" "20230509.1755" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "576a54fced02bbddc9b09bf41752b3371e8ca829" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
