;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ai" "20241020.609"
  "Use ChatGPT and other LLMs in org-mode and beyond."
  '((emacs     "27.1")
    (websocket "1.15"))
  :url "https://github.com/rksm/org-ai"
  :commit "c8977cfa7d9358518f6de8aaca17a969ede4d16b"
  :revdesc "c8977cfa7d93"
  :authors '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers '(("Robert Krahn" . "robert@kra.hn")))
