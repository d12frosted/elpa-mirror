;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261021.328"
  "Browse GitHub repos without cloning."
  '((emacs "29.1")
    (ghub  "4.0.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "ced1c937d35201e2750b95910defa8e83c0891e2"
  :revdesc "ced1c937d352"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
