;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser" "20260425.1245"
  "GNU Emacs and Scheme talk to each other."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://gitlab.com/emacs-geiser/"
  :commit "7bb18cd896e736fb90a0b5c2f945331fcabf0fbb"
  :revdesc "7bb18cd896e7"
  :keywords '("languages" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
