(define-package "helm-core" "20210914.749" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "33b60d88926d36c3610616a42bf722623ae66978")
;; Local Variables:
;; no-byte-compile: t
;; End:
