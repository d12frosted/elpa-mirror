(define-package "cangjie" "20200808.828" "Retrieve cangjie code for han characters"
  '((emacs "24.4")
    (s "1.12.0")
    (dash "2.14.1")
    (f "0.2.0"))
  :commit "0cbf706890df06b9e0d541692c579ed213da8252" :keywords
  '("convenience" "writing")
  :url "https://github.com/kisaragi-hiu/cangjie.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
