(define-package "notmuch" "20210620.2015" "run notmuch within emacs" 'nil :commit "7406abf5e0596b7865e7fe31ef9e92727ed15c54" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
