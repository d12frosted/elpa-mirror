(define-package "dwim-coder-mode" "20230808.1755" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "bf0b7acdad380382f217c4467e49e7a60a4bb93f" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
