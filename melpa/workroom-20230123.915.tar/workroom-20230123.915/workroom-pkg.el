(define-package "workroom" "20230123.915" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0")
    (compat "28.1.2.2"))
  :commit "e4ce5ca4ba1cec97a7c354246389ae37b10132dc" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
