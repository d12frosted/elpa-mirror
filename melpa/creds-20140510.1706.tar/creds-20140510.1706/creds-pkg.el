(define-package "creds" "20140510.1706" "A parser credentials file library (not limited to credentials entries)"
  '((s "1.9.0")
    (dash "2.5.0"))
  :commit "00ebefd10005c170b790a01380cb6a98f798ce5c" :authors
  '(("Antoine R. Dumont <eniotna.t AT gmail.com>"))
  :maintainer
  '("Antoine R. Dumont <eniotna.t AT gmail.com>")
  :keywords
  '("credentials")
  :url "https://github.com/ardumont/emacs-creds")
;; Local Variables:
;; no-byte-compile: t
;; End:
