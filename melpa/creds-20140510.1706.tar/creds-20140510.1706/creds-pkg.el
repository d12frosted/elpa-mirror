(define-package "creds" "20140510.1706" "A parser credentials file library (not limited to credentials entries)"
  '((s "1.9.0")
    (dash "2.5.0"))
  :commit "b059397a7d59481f05fbb1bb9c8d3c2c69226482")
;; Local Variables:
;; no-byte-compile: t
;; End:
