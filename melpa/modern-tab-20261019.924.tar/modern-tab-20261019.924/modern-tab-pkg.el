;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modern-tab" "20261019.924"
  "The common part of the two tab modes."
  '((emacs "29.1"))
  :url "https://github.com/MArpogaus/modern-tab"
  :commit "2cff8c4f1aeabba7ff4f09f08235802200409de0"
  :revdesc "2cff8c4f1aea"
  :keywords '("convenience" "tabs")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
