;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260310.1920"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "86fbe695085fd59c7b65799da84a3e917ebf4528"
  :revdesc "86fbe695085f")
