(define-package "cape" "20230120.2006" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.1.0"))
  :commit "007adba83e9326d7a69f293ac665626b4624d07d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
