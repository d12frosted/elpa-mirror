;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "20260926.1436"
  "Sections for read-only buffers."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/magit"
  :commit "2a522a62ad25658abd031d4c8e361cc4ed8de579"
  :revdesc "2a522a62ad25"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
