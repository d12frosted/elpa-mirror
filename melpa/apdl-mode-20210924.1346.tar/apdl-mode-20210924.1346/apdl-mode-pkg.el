(define-package "apdl-mode" "20210924.1346" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "184eef4da219ff615101c93321b44ce06beb9b3d" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
