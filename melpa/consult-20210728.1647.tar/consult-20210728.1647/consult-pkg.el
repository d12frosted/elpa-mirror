(define-package "consult" "20210728.1647" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "717e3241080d8409d00c77ce0e93f4182f2da3c7" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
