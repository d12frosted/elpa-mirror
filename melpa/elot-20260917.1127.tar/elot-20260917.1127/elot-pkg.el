;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "20260917.1127"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "a6a66f28ab7223b1caa275bb4c5e456b8f1c158d"
  :revdesc "a6a66f28ab72"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
