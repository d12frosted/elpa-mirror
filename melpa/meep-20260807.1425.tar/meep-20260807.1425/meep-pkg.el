;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260807.1425"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "74c6783e826a998d01a5aade6fac2a105b88514a"
  :revdesc "74c6783e826a"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
