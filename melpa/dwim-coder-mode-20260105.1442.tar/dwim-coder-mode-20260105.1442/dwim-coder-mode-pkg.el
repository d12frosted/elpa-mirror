;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-coder-mode" "20260105.1442"
  "DWIM keybindings for C, Python, Rust, and more."
  '((emacs "30"))
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html"
  :commit "a0f55e02166454ec4c6219091669f3babb2d088a"
  :revdesc "a0f55e021664"
  :keywords '("convenience" "hacks")
  :authors '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers '(("Mohammed Sadiq" . "sadiq@sadiqpk.org")))
