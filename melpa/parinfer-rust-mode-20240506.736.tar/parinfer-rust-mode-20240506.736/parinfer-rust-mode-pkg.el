(define-package "parinfer-rust-mode" "20240506.736" "An interface for the parinfer-rust library"
  '((emacs "26.1")
    (track-changes "1.1"))
  :commit "a3a8292793bfc3a62917c851b004bdd89d2adfe8" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
