;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250618.1447"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "e0018f5403296ec572e318580b687cf839ea6de8"
  :revdesc "e0018f540329"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
