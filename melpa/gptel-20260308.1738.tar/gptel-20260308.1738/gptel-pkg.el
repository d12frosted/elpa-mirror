;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260308.1738"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "fa2f4d50dee20727e3a7953ee04c453f9f6f3480"
  :revdesc "fa2f4d50dee2"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
