;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "custom-keymap" "20250906.1450"
  "Configure user key sequence bindings from a custom variable."
  '((emacs "29.3"))
  :url "https://github.com/viandant/custom-keymap"
  :commit "d8db247fd8ce47bc9ecc7f75c4074fc4f82c4119"
  :revdesc "d8db247fd8ce"
  :keywords '("internal" "keymap" "keyboard" "customization")
  :authors '(("Viandant" . "viandant@langenst.de"))
  :maintainers '(("Viandant" . "viandant@langenst.de")))
