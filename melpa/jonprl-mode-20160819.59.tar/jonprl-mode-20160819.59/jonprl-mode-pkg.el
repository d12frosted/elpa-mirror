;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jonprl-mode" "20160819.59"
  "A major mode for editing JonPRL files."
  '((emacs     "24.3")
    (cl-lib    "0.5")
    (yasnippet "0.8.0"))
  :url "https://github.com/david-christiansen/jonprl-mode"
  :commit "6059bb64891fae45827174e044d6a87ac07172d8"
  :revdesc "6059bb64891f"
  :keywords '("languages")
  :authors '(("David Raymond Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Raymond Christiansen" . "david@davidchristiansen.dk")))
