(define-package "magit-section" "20210813.904" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "2.18.1"))
  :commit "8cadf302b88c9c6ae33d4205fc243ce643e21840" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
