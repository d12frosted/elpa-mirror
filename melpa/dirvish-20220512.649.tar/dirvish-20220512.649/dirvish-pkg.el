(define-package "dirvish" "20220512.649" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "49655579f2aef3e8caaff03dcf8c5e46cfcd2839" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
