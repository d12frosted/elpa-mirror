;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rib-mode" "20170726.1448"
  "RenderMan® Interface Bytestream (RIB) Major Mode."
  '((emacs "24"))
  :url "https://github.com/blezek/rib-mode"
  :commit "97470158784c3c212e22e2c20b8471ee65ba59af"
  :revdesc "97470158784c"
  :authors '(("Remik Ziemlinski and Daniel Blezek" . "daniel.blezek@gmail.com"))
  :maintainers '(("Remik Ziemlinski and Daniel Blezek" . "daniel.blezek@gmail.com")))
