(define-package "ducpel" "20140702.1154" "Logic game with sokoban elements"
  '((cl-lib "0.5"))
  :commit "2f2ce2df269d99261c808a5c4ebc00d6d2cddabc" :authors
  '(("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  '("Alex Kost" . "alezost@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/alezost/ducpel")
;; Local Variables:
;; no-byte-compile: t
;; End:
