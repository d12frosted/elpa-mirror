(define-package "ducpel" "20140702.1154" "Logic game with sokoban elements"
  '((cl-lib "0.5"))
  :commit "b53b935ab95c02b82ccf38f63c89e39e99477a55" :authors
  (("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  ("Alex Kost" . "alezost@gmail.com")
  :keywords
  ("games")
  :url "https://github.com/alezost/ducpel")
;; Local Variables:
;; no-byte-compile: t
;; End:
