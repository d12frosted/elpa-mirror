;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260107.910"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "1620d8ac1f555b4b4299fb7a852d59ddeaaae2e4"
  :revdesc "1620d8ac1f55"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
