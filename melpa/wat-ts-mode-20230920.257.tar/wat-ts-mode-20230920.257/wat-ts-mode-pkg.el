(define-package "wat-ts-mode" "20230920.257" "Major mode for webassembly text format"
  '((emacs "29.1"))
  :commit "7cfe5b33f3745baf9ec05ad0c3dfe173b44c36f5" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("wasm" "wat" "wast" "languages" "tree-sitter")
  :url "https://github.com/nverno/wat-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
