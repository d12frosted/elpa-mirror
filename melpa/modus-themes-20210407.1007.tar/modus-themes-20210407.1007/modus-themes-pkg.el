(define-package "modus-themes" "20210407.1007" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "5f04e2de4b0816048ee917b694b3430f39c40a7b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
