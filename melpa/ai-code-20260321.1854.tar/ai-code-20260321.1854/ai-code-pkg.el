;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260321.1854"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e4f5639bcf1c0157effea5ba3488d39180fa6f03"
  :revdesc "e4f5639bcf1c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
