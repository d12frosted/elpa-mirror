(define-package "latex-labeler" "20231007.2222" "Simplify equation labeling in LaTeX"
  '((emacs "28.1"))
  :commit "b17fe782665aa46a9187c78f0575e7a527edf5f8" :authors
  '(("X9hRRDys"))
  :maintainers
  '(("X9hRRDys"))
  :maintainer
  '("X9hRRDys")
  :keywords
  '("tools")
  :url "https://github.com/X9hRRDys/latex-labeler")
;; Local Variables:
;; no-byte-compile: t
;; End:
