;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "20241208.1219"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "160ce3d5bb505d2d614a51e9ef0ebf3e955d3480"
  :revdesc "160ce3d5bb50"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
