;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251223.558"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "6dcd3690371fbaa7291b15187f4427cdfa6ada72"
  :revdesc "6dcd3690371f"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
