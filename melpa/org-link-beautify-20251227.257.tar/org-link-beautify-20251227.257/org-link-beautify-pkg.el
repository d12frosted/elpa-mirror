;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20251227.257"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "5fbbd35af1632a7dcba6609077783937fafce8ad"
  :revdesc "5fbbd35af163"
  :keywords '("hypermedia"))
