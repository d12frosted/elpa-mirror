(define-package "org-modern" "20231202.1037" "Modern looks for Org"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "f7cbd2d208a45ae9b333997356dd44bc5add6394" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "wp")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
