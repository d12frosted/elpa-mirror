;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-compile" "20260521.1100"
  "Automatically compile Emacs Lisp libraries."
  '((emacs "28.1"))
  :url "https://github.com/emacscollective/auto-compile"
  :commit "a1579f69437420e3a415dccf3fd3618a5e426ea1"
  :revdesc "a1579f694374"
  :keywords '("compile" "convenience" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev")))
