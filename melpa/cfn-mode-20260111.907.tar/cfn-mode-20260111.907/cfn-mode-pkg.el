;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260111.907"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "0ae97bf5b10c0a0f27b1009b29c191c1673229bf"
  :revdesc "0ae97bf5b10c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
