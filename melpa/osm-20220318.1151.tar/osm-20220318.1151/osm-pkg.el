(define-package "osm" "20220318.1151" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "cd3f8e0d05ab453f9dee2527448a53c8a0e5a1cc" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
