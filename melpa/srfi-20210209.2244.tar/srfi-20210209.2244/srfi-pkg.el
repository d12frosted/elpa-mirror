(define-package "srfi" "20210209.2244" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "bc5bccdd7b35808daa0639cff84d6b56a50879ff" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
