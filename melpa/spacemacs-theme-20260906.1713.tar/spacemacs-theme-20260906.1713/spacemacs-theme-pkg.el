;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacemacs-theme" "20260906.1713"
  "Color theme with a dark and light versions."
  '((emacs "24"))
  :url "https://github.com/nashamri/spacemacs-theme"
  :commit "b24b756863e290959a64245504ef2ade8c1e3a9f"
  :revdesc "b24b756863e2"
  :keywords '("color" "theme"))
