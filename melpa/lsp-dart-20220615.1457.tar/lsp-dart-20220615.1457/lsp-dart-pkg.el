(define-package "lsp-dart" "20220615.1457" "Dart support lsp-mode"
  '((emacs "26.3")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (dart-mode "1.0.5"))
  :commit "6bb26feb9c21bed7a3a52c7b35a2a84805233a5e" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
