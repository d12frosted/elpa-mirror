;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260929.1342"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "634b667d16a7523f237cf29bc0aab950d199f907"
  :revdesc "634b667d16a7")
