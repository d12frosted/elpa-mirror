;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260127.1742"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "725d69791cc5a38a163bd5d40e58c57787542fe5"
  :revdesc "725d69791cc5"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
