;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260828.1350"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "a3d8319d8960fe5119e798f904ff47768281ccbd"
  :revdesc "a3d8319d8960"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
