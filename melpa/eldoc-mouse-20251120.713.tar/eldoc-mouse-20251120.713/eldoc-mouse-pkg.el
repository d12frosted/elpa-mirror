;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20251120.713"
  "Display documentation for mouse hover."
  '((emacs    "30.1")
    (posframe "1.4.0")
    (eglot    "1.8"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "14cee0b85236f1140fc1cdb569d39e1a1b401420"
  :revdesc "14cee0b85236"
  :keywords '("tools" "languages" "convenience" "emacs" "mouse" "hover")
  :authors '((nil . "HuangFeiyusibadake1@163.com"))
  :maintainers '((nil . "HuangFeiyusibadake1@163.com")))
