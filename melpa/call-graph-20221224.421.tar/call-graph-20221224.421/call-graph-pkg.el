(define-package "call-graph" "20221224.421" "Generate call graph for c/c++ functions"
  '((emacs "25.1")
    (hierarchy "0.7.0")
    (tree-mode "1.0.0")
    (ivy "0.10.0"))
  :commit "7da5a73c26c31f9d5102d42cd1bf61ce5d9cf31c" :authors
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainer
  '("Huming Chen" . "chenhuming@gmail.com")
  :keywords
  '("programming" "convenience")
  :url "https://github.com/beacoder/call-graph")
;; Local Variables:
;; no-byte-compile: t
;; End:
