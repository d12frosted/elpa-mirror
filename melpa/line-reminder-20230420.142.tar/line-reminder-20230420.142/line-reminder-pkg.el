(define-package "line-reminder" "20230420.142" "Line annotation for changed and saved lines"
  '((emacs "25.1")
    (indicators "0.0.4")
    (fringe-helper "1.0.1")
    (ov "1.0.6")
    (ht "2.0"))
  :commit "583bff387b361e1fe442f57e9ad1f6f8e87dedf4" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "annotation")
  :url "https://github.com/emacs-vs/line-reminder")
;; Local Variables:
;; no-byte-compile: t
;; End:
