;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-tmux" "20221005.2025"
  "Babel Support for Interactive Terminal."
  '((emacs "25.1")
    (seq   "2.3")
    (s     "1.9.0"))
  :url "https://github.com/ahendriksen/ob-tmux"
  :commit "e672ca5a9534b9f33ed7aa5cd21b88189ccc5697"
  :revdesc "e672ca5a9534"
  :keywords '("literate programming" "interactive shell" "tmux"))
