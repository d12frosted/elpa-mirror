(define-package "fanyi" "20210901.1026" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "7b17789fc9f7fe188236bb1087587e1fd6b5cad3" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
