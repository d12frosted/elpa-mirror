(define-package "boon" "20210224.1322" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "aaf373b48afc12eb1bfe0fa1a760e9fce90a4ed0")
;; Local Variables:
;; no-byte-compile: t
;; End:
