;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260515.226"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "0638922d3f9a0d5993766a53ac4aed5020e07177"
  :revdesc "0638922d3f9a"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
