;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260601.1518"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "a279e2606f749e35e9af3d9f349484ee379eda84"
  :revdesc "a279e2606f74"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
