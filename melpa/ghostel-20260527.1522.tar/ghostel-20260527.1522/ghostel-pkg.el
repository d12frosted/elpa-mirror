;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260527.1522"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5c90a187d54d17f076243474dc46c9600557d617"
  :revdesc "5c90a187d54d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
