;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20250620.1221"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "44ae67da1eea8714724e11d2b4169b243af241a2"
  :revdesc "44ae67da1eea"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
