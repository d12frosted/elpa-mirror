;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-extras-a2ps" "20230303.1511"
  "A transient interface to a2ps."
  '((emacs            "28.1")
    (transient-extras "1.0.0"))
  :url "https://git.sr.ht/~swflint/transient-extras-a2ps"
  :commit "e91a1cddb1f0cb8b99d2bd30db64d467e5fa7ea8"
  :revdesc "e91a1cddb1f0"
  :keywords '("convenience")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
