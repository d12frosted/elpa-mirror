(define-package "marcopolo" "20150326.1618" "Emacs client for Docker API"
  '((s "1.9.0")
    (dash "2.9.0")
    (pkg-info "0.5.0")
    (request "0.1.0"))
  :commit "ce6ad40d7feab0568924e3bd9659b76e3eecd55e" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("docker")
  :url "https://github.com/nlamirault/marcopolo")
;; Local Variables:
;; no-byte-compile: t
;; End:
