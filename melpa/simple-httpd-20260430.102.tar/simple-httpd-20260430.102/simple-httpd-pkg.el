;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260430.102"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "19e634f72d5973ebf7b6ea98d3dc836a07b5eebb"
  :revdesc "19e634f72d59"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
