(define-package "khardel" "20201019.553" "Integrate with khard"
  '((emacs "25.1")
    (yaml-mode "0.0.13"))
  :commit "ca021fad32430e3f3a995d4158e73b5ee485258d" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://github.com/DamienCassou/khardel")
;; Local Variables:
;; no-byte-compile: t
;; End:
