;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260221.1142"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c61a903c4cbeb7822dc9fde9f83cc728f079fac6"
  :revdesc "c61a903c4cbe")
