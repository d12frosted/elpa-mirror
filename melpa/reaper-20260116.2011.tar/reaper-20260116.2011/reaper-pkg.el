;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reaper" "20260116.2011"
  "Interact with Harvest time tracking app."
  '((emacs "26.2"))
  :url "https://github.com/xendk/reaper"
  :commit "747d53b4a7db77648931ae1396151ae447404b08"
  :revdesc "747d53b4a7db"
  :keywords '("tools")
  :authors '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers '(("Thomas Fini Hansen" . "xen@xen.dk")))
