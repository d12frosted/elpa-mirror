;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwin" "20251125.1739"
  "Navigate and arrange desktop windows."
  '((emacs "30.2"))
  :url "https://github.com/lsth/dwin"
  :commit "7f514fd2670e12999d07f32d1eeb94c61874bf3b"
  :revdesc "7f514fd2670e"
  :keywords '("frames" "processes" "convenience")
  :authors '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de"))
  :maintainers '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de")))
