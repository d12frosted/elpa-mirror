;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "20260401.1337"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "e3f930f6ad3f5296252409d3015d6ecce0a5e91b"
  :revdesc "e3f930f6ad3f"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
