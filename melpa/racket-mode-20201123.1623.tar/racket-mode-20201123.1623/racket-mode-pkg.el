(define-package "racket-mode" "20201123.1623" "Racket editing, REPL, and more"
  '((emacs "25.1")
    (faceup "0.0.2")
    (pos-tip "20191127.1028"))
  :commit "3ef9162cf03f3f6fb5d2709ab48e39f4cf713647" :authors
  (("Greg Hendershott"))
  :maintainer
  ("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
