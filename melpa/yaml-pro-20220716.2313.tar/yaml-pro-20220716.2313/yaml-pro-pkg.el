(define-package "yaml-pro" "20220716.2313" "Parser-aided YAML editing features"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "9e8886b2b55d318ba7ba0df50789894381321dad" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("tools")
  :url "https://github.com/zkry/yaml-pro")
;; Local Variables:
;; no-byte-compile: t
;; End:
