;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250928.1252"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "753cdab306532d7618f3126cb31c6ab0e7069522"
  :revdesc "753cdab30653"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
