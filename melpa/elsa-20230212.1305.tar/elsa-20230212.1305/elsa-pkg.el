(define-package "elsa" "20230212.1305" "Emacs Lisp Static Analyser"
  '((trinary "1.0.0")
    (emacs "25.1")
    (seq "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3"))
  :commit "7ba4e073783bbeb1e861f0d450c7cdc62eab406c" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
