(define-package "navigel" "20230527.1620" "Facilitate the creation of tabulated-list based UIs"
  '((emacs "25.1")
    (tablist "1.0"))
  :commit "680b71f0f2017f9417504639d5c47366b102c2b7" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://gitlab.petton.fr/DamienCassou/navigel")
;; Local Variables:
;; no-byte-compile: t
;; End:
