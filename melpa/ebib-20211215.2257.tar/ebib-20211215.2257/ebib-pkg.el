(define-package "ebib" "20211215.2257" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "4e014cfe2f116e0909450930efa0f176ae1d49f0" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
