;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "korean-holidays" "20260324.1431"
  "Korean holidays for calendar."
  ()
  :url "https://github.com/tttuuu888/korean-holidays"
  :commit "d33e91b5c556384916ebee485d5b59a196b3c832"
  :revdesc "d33e91b5c556"
  :keywords '("calendar")
  :authors '(("SeungKi Kim" . "tttuuu888@gmail.com"))
  :maintainers '(("SeungKi Kim" . "tttuuu888@gmail.com")))
