(define-package "notmuch" "20210805.1158" "run notmuch within emacs" 'nil :commit "3df2281746d57abbb45790ecb432ef40533c30bc" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
