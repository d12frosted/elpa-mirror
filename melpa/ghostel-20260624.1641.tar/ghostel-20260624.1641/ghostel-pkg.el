;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260624.1641"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "962d1bec28e926bd5764a05cfd784b0de3529e53"
  :revdesc "962d1bec28e9"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
