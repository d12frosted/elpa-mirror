;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-or-bury-alive" "20230606.1503"
  "Precise control over buffer killing."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/kill-or-bury-alive"
  :commit "16c393db6ad0c7e184af0a24d26b637e23543b1f"
  :revdesc "16c393db6ad0"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
