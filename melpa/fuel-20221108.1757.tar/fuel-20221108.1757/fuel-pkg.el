(define-package "fuel" "20221108.1757" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "8c9bb02fe3c958d657857117825a83548cdfe2f0")
;; Local Variables:
;; no-byte-compile: t
;; End:
