;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250622.651"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "72f83607df85b4e7af2be7bc66cc70742ae2e92f"
  :revdesc "72f83607df85"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
