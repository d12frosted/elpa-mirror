;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-sidebar" "20260612.632"
  "Sidebar for `ibuffer'."
  '((emacs "29.1"))
  :url "https://github.com/jojojames/ibuffer-sidebar"
  :commit "1330b0f156e2275acd1a9256fc13a1d22e5e3a9e"
  :revdesc "1330b0f156e2"
  :keywords '("ibuffer" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
