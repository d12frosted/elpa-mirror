;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250617.639"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "53c3456771e64d93d8bf7ae49affed8eab932340"
  :revdesc "53c3456771e6"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
