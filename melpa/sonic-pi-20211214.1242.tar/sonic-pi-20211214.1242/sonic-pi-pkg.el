(define-package "sonic-pi" "20211214.1242" "A Emacs client for SonicPi"
  '((cl-lib "0.5")
    (osc "0.1")
    (dash "2.2.0")
    (emacs "24")
    (highlight "0"))
  :commit "9ae16d0fd4cba77ae0bedac83f2cb46569be6ade" :authors
  '(("Joseph Wilk" . "joe@josephwilk.net"))
  :maintainer
  '("Joseph Wilk" . "joe@josephwilk.net")
  :keywords
  '("sonicpi" "ruby")
  :url "http://www.github.com/repl-electric/sonic-pi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
