;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sonic-pi" "20211214.1242"
  "A Emacs client for SonicPi."
  '((cl-lib    "0.5")
    (osc       "0.1")
    (dash      "2.2.0")
    (emacs     "24")
    (highlight "0"))
  :url "http://www.github.com/repl-electric/sonic-pi.el"
  :commit "9ae16d0fd4cba77ae0bedac83f2cb46569be6ade"
  :revdesc "9ae16d0fd4cb"
  :keywords '("sonicpi" "ruby")
  :authors '(("Joseph Wilk" . "joe@josephwilk.net"))
  :maintainers '(("Joseph Wilk" . "joe@josephwilk.net")))
