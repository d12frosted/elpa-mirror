;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-http" "20261108.345"
  "Http request in org-mode babel."
  '((s      "1.9.0")
    (cl-lib "0.5"))
  :url "https://github.com/zweifisch/ob-http"
  :commit "cd6d145da1f5f11d107f423c36f8b9a6af742dfd"
  :revdesc "cd6d145da1f5"
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
