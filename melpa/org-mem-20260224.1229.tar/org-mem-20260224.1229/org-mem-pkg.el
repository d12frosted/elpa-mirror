;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260224.1229"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.1.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "ebecc2378422c6bec2fe82d3ba5194de303263a6"
  :revdesc "ebecc2378422"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
