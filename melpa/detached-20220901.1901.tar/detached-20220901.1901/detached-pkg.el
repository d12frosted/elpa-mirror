(define-package "detached" "20220901.1901" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "2aa05c6e33b058a86cce680cbedbdf8db52e4f77" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
