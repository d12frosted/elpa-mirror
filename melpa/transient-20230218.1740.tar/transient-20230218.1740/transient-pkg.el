(define-package "transient" "20230218.1740" "Transient commands"
  '((emacs "25.1")
    (compat "29.1.3.4"))
  :commit "3657117b147b589fe3e27d2a8e6d24fcb0fc1137" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
