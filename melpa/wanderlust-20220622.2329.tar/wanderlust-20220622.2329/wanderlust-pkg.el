(define-package "wanderlust" "20220622.2329" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "512a98741d64f55eaa03fae3a6cd42fe872b4822")
;; Local Variables:
;; no-byte-compile: t
;; End:
