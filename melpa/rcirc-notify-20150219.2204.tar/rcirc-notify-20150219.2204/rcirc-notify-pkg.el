;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rcirc-notify" "20150219.2204"
  "Libnotify popups."
  ()
  :url "https://github.com/nicferrier/rcirc-notify"
  :commit "841a7b5a6cdb0c11a812df924d2c6a7d364fd455"
  :revdesc "841a7b5a6cdb"
  :keywords '("lisp" "rcirc" "irc" "notify" "growl")
  :authors '(("Alex Schroeder" . "alex@gnu.org")
             ("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
