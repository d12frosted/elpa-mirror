;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251009.1324"
  "BLUE build system interface."
  '((emacs "30.1"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "67b058ca787bb173e0ae8becdf217e611759d36d"
  :revdesc "67b058ca787b"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
