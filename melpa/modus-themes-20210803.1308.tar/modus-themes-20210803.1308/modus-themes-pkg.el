(define-package "modus-themes" "20210803.1308" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "2cf3258407c5e742758931deecf2142c5cc99835" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
