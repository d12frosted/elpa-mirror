(define-package "buttercup" "20220410.1557" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "ceedad5efa797e860dbb356bc2c3028a4e0321ec" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
