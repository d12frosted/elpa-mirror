(define-package "modus-themes" "20210901.555" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "7e204cf98ba37de552e0575f028e74e34ae39b80" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
