(define-package "gumshoe" "20211229.152" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "2366f1c65cdcf09c6b98ca466110842cd88c9db3" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
