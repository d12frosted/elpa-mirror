;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-prescient" "20260906.1958"
  "Prescient.el + Company."
  '((emacs     "26.1")
    (prescient "6.1.0")
    (company   "0.9.6"))
  :url "https://github.com/raxod502/prescient.el"
  :commit "ae52777d6b6b856b54c85441c7a713949f1720de"
  :revdesc "ae52777d6b6b"
  :keywords '("extensions")
  :authors '(("Radian LLC" . "contact+prescient@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+prescient@radian.codes")))
