;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20241208.336"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "98780c55480643231cc86155191b13f3f355aace"
  :revdesc "98780c554806"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
