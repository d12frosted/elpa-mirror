;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-newtab" "20240227.155"
  "Supercharge your browser's new tab page."
  '((emacs     "27.1")
    (websocket "1.14")
    (async     "1.9.7"))
  :url "https://github.com/Zweihander-Main/org-newtab"
  :commit "eca494a43e242558bd8db24d321ad62a8ec86c02"
  :revdesc "eca494a43e24"
  :keywords '("outlines")
  :authors '(("Zweihänder" . "zweidev@zweihander.me"))
  :maintainers '(("Zweihänder" . "zweidev@zweihander.me")))
