(define-package "org-side-tree" "20231002.2218" "Navigate Org outlines in side window tree"
  '((emacs "28.1"))
  :commit "e1641feecccd0b22d786a6008953f2e093087843" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/org-side-tree")
;; Local Variables:
;; no-byte-compile: t
;; End:
