;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260115.1900"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "2041464428078efc6f09dfdc6f23db3195997a76"
  :revdesc "204146442807"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
