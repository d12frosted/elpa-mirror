;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20260902.1428"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "3b93c42c8f1e360daf39695d664beca54dc3d5fe"
  :revdesc "3b93c42c8f1e"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
