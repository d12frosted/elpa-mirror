(define-package "org2blog" "20220831.558" "Blog from Org mode to WordPress"
  '((htmlize "1.56")
    (hydra "0.15.0")
    (xml-rpc "1.6.15")
    (metaweblog "1.1.13"))
  :commit "65db95d6f866c140fbc6629419be8f41f40f03b3" :authors
  '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainer
  '("Grant Rettke" . "grant@wisdomandwonder.com")
  :keywords
  '("comm" "convenience" "outlines" "wp")
  :url "https://github.com/org2blog/org2blog")
;; Local Variables:
;; no-byte-compile: t
;; End:
