;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-line" "20241107.944"
  "Custom and simple mode line."
  '((emacs "28.1"))
  :url "https://gitlab.com/aimebertrand/timu-line"
  :commit "d0cbf4c901e88ccad06da452de88fc8364ab3089"
  :revdesc "d0cbf4c901e8"
  :keywords '("modeline" "frames" "ui")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
