(define-package "embark" "20220411.2055" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "67ef67885a2a51c3171b5e47dbb7d9a8d2aab1db" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
