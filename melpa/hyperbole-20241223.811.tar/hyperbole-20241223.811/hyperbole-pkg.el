;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241223.811"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "f7ef2196fd1ae6fd8d9503e75404187f015c4a4b"
  :revdesc "f7ef2196fd1a"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
