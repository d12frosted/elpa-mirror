;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260722.523"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "2154422ceaa5547931ca1eae0b5113e58b267c36"
  :revdesc "2154422ceaa5"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
