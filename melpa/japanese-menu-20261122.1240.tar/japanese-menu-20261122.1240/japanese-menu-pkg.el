;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "japanese-menu" "20261122.1240"
  "Japanese menu translation."
  '((emacs "26.1"))
  :url "https://github.com/yt-emacs-ja/emacs-japanese-menu"
  :commit "3147efe95904eba2e3ddbd2ebf58fb55db007130"
  :revdesc "3147efe95904"
  :keywords '("convenience" "japanese" "menu")
  :authors '(("yt-emacs-ja" . "https://github.com/yt-emacs-ja"))
  :maintainers '(("yt-emacs-ja" . "https://github.com/yt-emacs-ja")))
