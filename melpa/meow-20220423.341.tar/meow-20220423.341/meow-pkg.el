(define-package "meow" "20220423.341" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "c4b7df0305530da4a51561556794abaf831a228e" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
