;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ipython" "20260324.859"
  "Org-babel functions for IPython evaluation."
  '((s               "1.9.0")
    (dash            "2.10.0")
    (dash-functional "1.2.0")
    (f               "0.17.2")
    (emacs           "24"))
  :url "http://www.gregsexton.org"
  :commit "35414dccffe48ce70122c40ff5db0b74dfa82cdf"
  :revdesc "35414dccffe4"
  :keywords '("literate programming" "reproducible research")
  :authors '(("Greg Sexton" . "gregsexton@gmail.com"))
  :maintainers '(("Greg Sexton" . "gregsexton@gmail.com")))
