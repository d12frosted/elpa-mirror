;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yoficator" "20190509.1620"
  "Interactively yoficate Russian texts."
  ()
  :url "https://gitlab.com/link2xt/yoficator"
  :commit "fa914f9648515bca54b5e558ca57d2b65fa57491"
  :revdesc "fa914f964851"
  :authors '(("Eugene Minkovskii" . "emin@mccme.ru")
             ("Alexander Krotov" . "ilabdsf@gmail.com"))
  :maintainers '(("Eugene Minkovskii" . "emin@mccme.ru")
                 ("Alexander Krotov" . "ilabdsf@gmail.com")))
