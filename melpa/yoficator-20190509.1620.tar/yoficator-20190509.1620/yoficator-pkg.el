(define-package "yoficator" "20190509.1620" "Interactively yoficate Russian texts" 'nil :commit "fa914f9648515bca54b5e558ca57d2b65fa57491" :authors
  (("Eugene Minkovskii" . "emin@mccme.ru")
   ("Alexander Krotov" . "ilabdsf@gmail.com"))
  :maintainer
  ("Eugene Minkovskii" . "emin@mccme.ru")
  :url "https://gitlab.com/link2xt/yoficator")
;; Local Variables:
;; no-byte-compile: t
;; End:
