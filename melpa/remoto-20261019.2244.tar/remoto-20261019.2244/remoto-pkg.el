;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261019.2244"
  "Browse GitHub repos without cloning."
  '((emacs "29.1")
    (ghub  "4.0.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "524fd13f1160d75ce83a018ae0f72289f97f7068"
  :revdesc "524fd13f1160"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
