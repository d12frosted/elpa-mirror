(define-package "almost-mono-themes" "20210306.1040" "Almost monochromatic color themes"
  '((emacs "24"))
  :commit "6503bf0e5429a51906fb1db94941a4fa678bf9b1" :authors
  '(("John Olsson" . "john@cryon.se"))
  :maintainer
  '("John Olsson" . "john@cryon.se")
  :keywords
  '("faces")
  :url "https://github.com/cryon/almost-mono-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
