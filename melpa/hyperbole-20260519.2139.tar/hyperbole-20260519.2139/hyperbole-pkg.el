;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260519.2139"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b5e7972214c2e6cbb14676d8dc90f1b6dbb64b82"
  :revdesc "b5e7972214c2"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
