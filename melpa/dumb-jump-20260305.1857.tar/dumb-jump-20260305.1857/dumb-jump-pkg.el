;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260305.1857"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "26.1"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "f82ca680bc0b7d4fb15e1e680486b9450b829fe3"
  :revdesc "f82ca680bc0b"
  :keywords '("programming"))
