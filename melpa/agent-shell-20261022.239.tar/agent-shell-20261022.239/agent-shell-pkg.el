;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261022.239"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8b39a163d5c337addf3c0ad9878bff4cf6824cf7"
  :revdesc "8b39a163d5c3")
