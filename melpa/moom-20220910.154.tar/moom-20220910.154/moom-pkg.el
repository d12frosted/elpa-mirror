(define-package "moom" "20220910.154" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "6fc3f6ab35d676798b25bcfa764c772d14308402" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
