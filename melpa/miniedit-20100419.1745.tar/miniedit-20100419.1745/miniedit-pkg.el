;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miniedit" "20100419.1745"
  "Enhanced editing for minibuffer fields."
  ()
  :url "https://github.com/emacsorphanage/miniedit"
  :commit "e12bf659c3eb92dd8a4cb77642dc0865c54667a3"
  :revdesc "e12bf659c3eb")
