(define-package "consult-org-roam" "20221016.1032" "Consult integration for org-roam"
  '((emacs "27.1")
    (org-roam "2.2.0")
    (consult "0.16"))
  :commit "6f64973ca132217b9689c6140e5e2b7c598f6fbb" :authors
  '(("jgru <https://github.com/jgru>"))
  :maintainer
  '("jgru <https://github.com/jgru>")
  :url "https://github.com/jgru/consult-org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
