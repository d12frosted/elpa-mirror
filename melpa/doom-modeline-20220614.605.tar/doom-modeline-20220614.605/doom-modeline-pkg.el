(define-package "doom-modeline" "20220614.605" "A minimal and modern mode-line"
  '((emacs "25.1")
    (shrink-path "0.2.0")
    (dash "2.11.0"))
  :commit "a3d37058771ea1014160deb20452f0f269b65335" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
