;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "20260121.249"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "ad69f7b43ac31835f2862f16ced5b07ad46015c3"
  :revdesc "ad69f7b43ac3"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
