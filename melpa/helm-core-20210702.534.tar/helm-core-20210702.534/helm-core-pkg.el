(define-package "helm-core" "20210702.534" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "93a8963c4ee84a0d58da93bb61a20b9dff1eaa1e")
;; Local Variables:
;; no-byte-compile: t
;; End:
