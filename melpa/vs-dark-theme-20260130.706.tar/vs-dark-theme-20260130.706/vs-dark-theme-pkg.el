;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-dark-theme" "20260130.706"
  "Visual Studio IDE dark theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-dark-theme"
  :commit "755f69424bbd215ac682c7a99de92af852818d2b"
  :revdesc "755f69424bbd"
  :keywords '("faces"))
