(define-package "rg" "20210617.1715" "A search tool based on ripgrep"
  '((emacs "25.1")
    (transient "0.3.0")
    (wgrep "2.1.10"))
  :commit "fe5a2180088981cc927bd2a47187dc8e2de0f9e8" :authors
  '(("David Landell" . "david.landell@sunnyhill.email")
    ("Roland McGrath" . "roland@gnu.org"))
  :maintainer
  '("David Landell" . "david.landell@sunnyhill.email")
  :keywords
  '("matching" "tools")
  :url "https://github.com/dajva/rg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
