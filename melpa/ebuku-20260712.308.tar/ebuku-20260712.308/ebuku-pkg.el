;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebuku" "20260712.308"
  "Interface to the buku Web bookmark manager."
  '((emacs "25.1"))
  :url "https://github.com/flexibeast/ebuku"
  :commit "dba4523f18591491c2d716442ad1da184747d879"
  :revdesc "dba4523f1859"
  :keywords '("bookmarks" "buku" "data" "web" "www")
  :authors '(("Alexis" . "flexibeast@gmail.com")
             ("Erik Sjöstrand" . "sjostrand.erik@gmail.com")
             ("Hilton Chain" . "hako@ultrarare.space"))
  :maintainers '(("Alexis" . "flexibeast@gmail.com")))
