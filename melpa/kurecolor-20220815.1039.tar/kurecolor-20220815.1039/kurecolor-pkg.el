(define-package "kurecolor" "20220815.1039" "color editing goodies"
  '((emacs "28.1")
    (s "1.12"))
  :commit "54c9dde26f81055bb8b3f99e177a8bdd15c59505" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
