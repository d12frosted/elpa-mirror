;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260101.2301"
  "A q editing mode."
  '((emacs "24"))
  :url "https://github.com/psaris/q-mode"
  :commit "72dea863150151bc08fd983717b5a2d12f30d64e"
  :revdesc "72dea8631501"
  :keywords '("faces" "files" "q"))
