;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rsync" "20261005.758"
  "Allow rsync from dired buffers."
  '((s     "1.12.0")
    (dash  "2.0.0")
    (emacs "25.1"))
  :url "https://github.com/stsquad/dired-rsync"
  :commit "80deb1f638b69da3f1370bb5423fd850351b8a97"
  :revdesc "80deb1f638b6"
  :authors '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers '(("Alex Bennée" . "alex@bennee.com")))
