;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260925.1831"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "dfcf1a65069fa09f52f80523a90fae10d1b5ea20"
  :revdesc "dfcf1a65069f"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
