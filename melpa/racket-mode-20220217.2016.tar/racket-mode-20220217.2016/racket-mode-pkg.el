(define-package "racket-mode" "20220217.2016" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "2f7b12cfebbde9f2436959387d4348cc5869a6bb" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
