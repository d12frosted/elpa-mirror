(define-package "stimmung-themes" "20220502.850" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "c516bcc077ffc334006e77c608b068eb2f11e845" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
