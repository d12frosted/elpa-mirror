;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20260203.1904"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "298549faa46d3c41d931981d0f2d214febc8f91d"
  :revdesc "298549faa46d"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
