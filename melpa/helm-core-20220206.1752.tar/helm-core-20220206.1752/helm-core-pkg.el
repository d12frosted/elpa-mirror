(define-package "helm-core" "20220206.1752" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "f26fdbc9fe943f389ad2c5e72744c237e3eb9452" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
