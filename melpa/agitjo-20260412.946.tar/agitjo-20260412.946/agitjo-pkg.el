;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agitjo" "20260412.946"
  "Manage Forgejo PRs with AGit-Flow."
  '((emacs         "30.1")
    (magit         "4.3.8")
    (markdown-mode "2.7")
    (transient     "0.9.1"))
  :url "https://codeberg.org/halvin/agitjo"
  :commit "698b02d6cd3301e819c5a80f883fb06b38509c86"
  :revdesc "698b02d6cd33"
  :keywords '("convenience" "vc" "tools")
  :authors '(("Alvin Hsu" . "aurtzy@gmail.com"))
  :maintainers '(("Alvin Hsu" . "aurtzy@gmail.com")))
