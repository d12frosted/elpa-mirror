;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flywrite" "20260402.145"
  "Inline writing suggestions via LLM."
  '((emacs "29.1"))
  :url "https://github.com/awdeorio/flywrite"
  :commit "3430d85f7b92308291db9c40ed26cd86703af9e4"
  :revdesc "3430d85f7b92"
  :keywords '("text" "wp")
  :authors '(("Andrew DeOrio" . "awdeorio@umich.edu"))
  :maintainers '(("Andrew DeOrio" . "awdeorio@umich.edu")))
