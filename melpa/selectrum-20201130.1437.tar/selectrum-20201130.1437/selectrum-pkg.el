(define-package "selectrum" "20201130.1437" "Easily select item from list"
  '((emacs "25.1"))
  :commit "945f8fe18933a53b2012a1d179587d90a70bb536" :keywords
  ("extensions")
  :authors
  (("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  ("Radon Rosborough" . "radon.neon@gmail.com")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
