;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260214.1840"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "07b9b2f47a6a470b7d64574cebf12148df74618a"
  :revdesc "07b9b2f47a6a"
  :keywords '("comm")
  :authors '(("Patrick Thomson" . "patrickt@github.com"))
  :maintainers '(("Patrick Thomson" . "patrickt@github.com")))
