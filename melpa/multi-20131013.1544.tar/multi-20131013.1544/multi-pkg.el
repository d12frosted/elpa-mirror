;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi" "20131013.1544"
  "Clojure-style multi-methods for emacs lisp."
  '((emacs "24"))
  :url "https://github.com/kurisuwhyte/emacs-multi"
  :commit "884203b11fdac8374ec644cca975469aab263404"
  :revdesc "884203b11fda"
  :keywords '("multimethod" "generic" "predicate" "dispatch")
  :authors '(("Christina Whyte" . "kurisu.whyte@gmail.com"))
  :maintainers '(("Christina Whyte" . "kurisu.whyte@gmail.com")))
