;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cloud-to-butt-erc" "20130627.2308"
  "Replace 'the cloud' with 'my butt'."
  ()
  :url "http://www.github.com/leathekd/cloud-to-butt-erc"
  :commit "6710c03d1bc91736435cbfe845924940cae34e5c"
  :revdesc "6710c03d1bc9"
  :authors '(("David Leatherman" . "leathekd@gmail.com"))
  :maintainers '(("David Leatherman" . "leathekd@gmail.com")))
