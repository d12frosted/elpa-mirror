(define-package "pr-review" "20230320.419" "Review github PR"
  '((emacs "27.1")
    (magit-section "3.2")
    (magit "3.2")
    (markdown-mode "2.5")
    (ghub "3.5"))
  :commit "f11fe37fbbb68485bc3b0ca692f0175e66293f09" :authors
  '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainers
  '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainer
  '("Yikai Zhao" . "yikai@z1k.dev")
  :keywords
  '("tools")
  :url "https://github.com/blahgeek/emacs-pr-review")
;; Local Variables:
;; no-byte-compile: t
;; End:
