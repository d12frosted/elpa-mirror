(define-package "pos-tip" "20220715.1020" "Show tooltip at point" 'nil :commit "bfe74204d1201a33ace81898e7c485382817510a" :authors
  '(("S. Irie"))
  :maintainers
  '(("S. Irie"))
  :maintainer
  '("S. Irie")
  :keywords
  '("tooltip"))
;; Local Variables:
;; no-byte-compile: t
;; End:
