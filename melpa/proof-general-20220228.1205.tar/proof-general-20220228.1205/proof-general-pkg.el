(define-package "proof-general" "20220228.1205" "PG init file for package.el and ELPA compatibility"
  '((emacs "25.1"))
  :commit "fe8b9fccb3690178be7fc455202c941c4c674ac3" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
