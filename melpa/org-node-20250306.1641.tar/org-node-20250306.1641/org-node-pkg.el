;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250306.1641"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (el-job        "1.0.5")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "6eed6fc407dc8b7fa028a50e00f3bcc5fe55613b"
  :revdesc "6eed6fc407dc"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
