(define-package "hl-prog-extra" "20220504.607" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "f0e2a26787b841d45a4e41204919f098d82d5de3" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
