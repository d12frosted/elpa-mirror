;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cp5022x" "20120323.2335"
  "Cp50220, cp50221, cp50222 coding system."
  ()
  :url "https://github.com/awasira/cp5022x.el"
  :commit "ea7327dd75e54539576916f592ae1be98179ae35"
  :revdesc "ea7327dd75e5"
  :keywords '("languages" "cp50220" "cp50221" "cp50222" "cp51932" "cp932")
  :authors '(("ARISAWA Akihiro" . "ari@mbf.ocn.ne.jp"))
  :maintainers '(("ARISAWA Akihiro" . "ari@mbf.ocn.ne.jp")))
