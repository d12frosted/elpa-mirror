;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-clojure" "20260220.1437"
  "Basic interaction with a Clojure REPL."
  '((emacs        "28.1")
    (clojure-mode "5.11"))
  :url "https://github.com/clojure-emacs/inf-clojure"
  :commit "be5e9bd90775b35c8bc2ecb118d6af9a521b2d81"
  :revdesc "be5e9bd90775"
  :keywords '("processes" "comint" "clojure")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
