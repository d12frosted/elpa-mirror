;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251023.1519"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "2556bfb311680bc2bb3c81662d622d2e4d0e48dd"
  :revdesc "2556bfb31168"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
