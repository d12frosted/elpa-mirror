;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "20260912.749"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "c1220fc057745a19c120e448557bc992b2d8ec03"
  :revdesc "c1220fc05774"
  :keywords '("outlines" "tools" "convenience" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
