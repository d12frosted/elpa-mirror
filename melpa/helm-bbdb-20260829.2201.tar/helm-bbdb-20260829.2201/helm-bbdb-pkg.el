;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bbdb" "20260829.2201"
  "Helm interface for bbdb."
  '((emacs "26.1")
    (helm  "1.5")
    (bbdb  "3.1.2"))
  :url "https://github.com/emacs-helm/helm-bbdb"
  :commit "e05e35872f5f854fc137d7c3e5afc747a8ec3cee"
  :revdesc "e05e35872f5f"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Jonathan Gregory" . "jagrg@posteo.com")))
