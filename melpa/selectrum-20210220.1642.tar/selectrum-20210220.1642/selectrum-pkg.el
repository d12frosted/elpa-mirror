(define-package "selectrum" "20210220.1642" "Easily select item from list"
  '((emacs "25.1"))
  :commit "fb1070a344d83a69959e6cb4253ab13d6e549c92" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
