(define-package "bqn-mode" "20230414.227" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "d3f761111cba64cbace3cab3d42f6ae95898b1d1" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
