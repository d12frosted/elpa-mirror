;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mantra" "20250915.2223"
  "A system for scripting and parsing activity beyond macros."
  '((emacs  "27.1")
    (pubsub "0.1"))
  :url "https://github.com/countvajhula/mantra"
  :commit "9cfd73af7e1ecf611a4e2dc0ff82370497d39d53"
  :revdesc "9cfd73af7e1e"
  :authors '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
