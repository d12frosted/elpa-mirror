;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-server" "20261101.1340"
  "Speaks HTTP for you."
  '((emacs "30.1"))
  :url "https://codeberg.org/martenlienen/http-server.el"
  :commit "12cd1ca2ab1debe4f47f4783ae4e9b926218589f"
  :revdesc "12cd1ca2ab1d"
  :keywords '("comm")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
