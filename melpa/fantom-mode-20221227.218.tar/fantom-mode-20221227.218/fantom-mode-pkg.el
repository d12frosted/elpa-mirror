;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fantom-mode" "20221227.218"
  "A major mode for the Fantom programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/fantom-mode"
  :commit "51cd82d29a7dca7bfd043971ba1d0fd21ed11693"
  :revdesc "51cd82d29a7d"
  :keywords '("files" "fantom"))
