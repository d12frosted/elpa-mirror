;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260917.2205"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "d640f1ead4f7eef8aac4af76d51955b0b66c896e"
  :revdesc "d640f1ead4f7"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
