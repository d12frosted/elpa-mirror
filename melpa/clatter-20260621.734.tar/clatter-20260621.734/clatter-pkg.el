;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260621.734"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "bf967054e9c81d9a1fe8bf00e53e4762e3141d93"
  :revdesc "bf967054e9c8"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
