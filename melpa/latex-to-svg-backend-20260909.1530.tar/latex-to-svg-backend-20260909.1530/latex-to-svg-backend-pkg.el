;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-backend" "20260909.1530"
  "LaTeX-to-SVG rendering engine with caching."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/latex-to-svg-backend"
  :commit "bb2cf7343bb193f863584a3cc4db688ad4cff6db"
  :revdesc "bb2cf7343bb1"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
