;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hindent" "20260124.2208"
  "Indent haskell code using the \"hindent\" program."
  '((emacs "27.1"))
  :url "https://github.com/mihaimaruseac/hindent"
  :commit "57e769d48447c77da5a21d1923ba3634e3a605fe"
  :revdesc "57e769d48447"
  :authors '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainers '(("Chris Done" . "chrisdone@gmail.com")))
