(define-package "yeetube" "20240303.1914" "YouTube Front End | Interface for yt-dlp | mpv control |"
  '((emacs "27.2")
    (compat "29.1.4.2"))
  :commit "5df5ad659a7cf53eccd57c9568b8865167e121fc" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://thanosapollo.org/projects/yeetube/")
;; Local Variables:
;; no-byte-compile: t
;; End:
