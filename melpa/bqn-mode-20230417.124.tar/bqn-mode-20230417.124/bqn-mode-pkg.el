(define-package "bqn-mode" "20230417.124" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "9e9bbaf2dfb1d1961c467f384ff3c897e962ef33" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
