;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251212.1354"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "8d5638ba33c12b470e4000b54e3658123ee56450"
  :revdesc "8d5638ba33c1"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
