(define-package "magik-mode" "20210907.804" "mode for editing Magik + some utils." 'nil :commit "6fe271f371ccb06b599a782839030bb8dee8535f" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
