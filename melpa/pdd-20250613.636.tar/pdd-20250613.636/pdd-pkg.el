;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250613.636"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "fe8e19a1ebaee5385ecaae8a186ceb21ef84c4f7"
  :revdesc "fe8e19a1ebae"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
