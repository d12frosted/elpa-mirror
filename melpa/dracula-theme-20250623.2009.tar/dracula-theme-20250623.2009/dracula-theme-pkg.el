;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dracula-theme" "20250623.2009"
  "Dracula Theme."
  '((emacs "24.3"))
  :url "https://github.com/dracula/emacs"
  :commit "5fd916b588df72bc9e099f8ea5d319a929bdabed"
  :revdesc "5fd916b588df"
  :maintainers '(("tienne Deparis" . "etienne@depar.is")))
