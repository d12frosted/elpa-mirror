(define-package "suomalainen-kalenteri" "20211108.1333" "Finnish national and Christian holidays for calendar" 'nil :commit "56927306d8046f2ba38b8cadabde47c5b6851262" :authors
  '(("Teemu Likonen" . "tlikonen@iki.fi"))
  :maintainer
  '("Teemu Likonen" . "tlikonen@iki.fi")
  :keywords
  '("calendar" "holidays" "finnish")
  :url "https://github.com/tlikonen/suomalainen-kalenteri")
;; Local Variables:
;; no-byte-compile: t
;; End:
