;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260810.556"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "231d48d526b8f2e0b9ad28e5af79f55e5058556a"
  :revdesc "231d48d526b8"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
