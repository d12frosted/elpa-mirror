;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260108.1831"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e2c0aeb941589ea52429ef0594ef7562b6fa70c9"
  :revdesc "e2c0aeb94158")
