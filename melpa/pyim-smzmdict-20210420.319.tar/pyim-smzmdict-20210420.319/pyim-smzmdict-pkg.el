(define-package "pyim-smzmdict" "20210420.319" "Sanma(triple) Zhengma dict for pyim"
  '((pyim "1.0"))
  :commit "bebbeb2a97a70e7468e0373000ccfe840b825ccf" :authors
  '(("Yue Shi (Zhizhi)"))
  :maintainer
  '("Yuanchen Xie")
  :keywords
  '("convenience" "i18n" "pyim" "chinese" "zhengma")
  :url "https://github.com/p1uxtar/pyim-smzmdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
