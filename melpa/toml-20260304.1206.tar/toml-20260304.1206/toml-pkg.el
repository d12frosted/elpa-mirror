;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260304.1206"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "f045c39f2acd5a2dcc01e2c31be7ece586907db4"
  :revdesc "f045c39f2acd"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
