(define-package "spdx" "20231002.100" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "0f6d8f98987d982ad8ac2ffcb7b10ac5d7060e91" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
