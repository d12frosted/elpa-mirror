;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260316.1815"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "b31888114dbe400627c7da10dde07f38c5471145"
  :revdesc "b31888114dbe"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
