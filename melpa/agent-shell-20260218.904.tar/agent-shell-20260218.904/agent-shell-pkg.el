;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260218.904"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.10.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "dfe5d3ecd23135900242e03f2e2d6c2a9716b5f1"
  :revdesc "dfe5d3ecd231")
