;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260701.1430"
  "Support for Org links to Magit buffers."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.6")
    (org      "9.8"))
  :url "https://github.com/magit/orgit"
  :commit "7c4827cd04953166f71eaec151ad1c50872fc680"
  :revdesc "7c4827cd0495"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
