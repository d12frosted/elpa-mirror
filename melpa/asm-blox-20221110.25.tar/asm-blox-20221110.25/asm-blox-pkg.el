(define-package "asm-blox" "20221110.25" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "4d4320fd80946c3e810e4ad5ca02ffa4d2089f15" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
