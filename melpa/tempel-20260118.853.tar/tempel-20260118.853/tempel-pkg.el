;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260118.853"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "821031bc8015a08a5d4ee30f0318fe17420e6098"
  :revdesc "821031bc8015"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
