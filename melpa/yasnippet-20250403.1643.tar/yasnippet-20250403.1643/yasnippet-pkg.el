;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yasnippet" "20250403.1643"
  "Yet another snippet extension for Emacs."
  '((cl-lib "0.5")
    (emacs  "24.4"))
  :url "http://github.com/joaotavora/yasnippet"
  :commit "81a59d1a85da6104958e53f6fa180d204d4eb98d"
  :revdesc "81a59d1a85da"
  :keywords '("convenience" "emulation")
  :maintainers '(("Noam Postavsky" . "npostavs@gmail.com")))
