;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-magit" "20250519.1533"
  "Generate commit messages for magit using gptel."
  '((emacs "28.1")
    (magit "4.0")
    (gptel "0.9.8"))
  :url "https://github.com/ragnard/gptel-magit"
  :commit "2f4cbd1dba669525a8d5af35215d567394d7f2df"
  :revdesc "2f4cbd1dba66"
  :keywords '("vc" "convenience")
  :authors '(("Ragnar Dahlén" . "r.dahlen@gmail.com"))
  :maintainers '(("Ragnar Dahlén" . "r.dahlen@gmail.com")))
