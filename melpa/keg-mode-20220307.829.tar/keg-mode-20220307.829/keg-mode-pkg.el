;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keg-mode" "20220307.829"
  "Major mode for editing Keg files."
  '((emacs "24.4"))
  :url "https://github.com/conao3/keg.el"
  :commit "d2ef9cfaee1256849291cfade3d730667f55aaf2"
  :revdesc "d2ef9cfaee12"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
