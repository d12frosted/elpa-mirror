;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260216.1913"
  "Highlight by brightness of text and background."
  '((emacs "29.4"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "35ae2b655fc9fd1d32ab3e631532847f771668ee"
  :revdesc "35ae2b655fc9"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
