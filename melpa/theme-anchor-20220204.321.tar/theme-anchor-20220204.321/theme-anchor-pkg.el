(define-package "theme-anchor" "20220204.321" "Apply theme in current buffer only"
  '((emacs "26"))
  :commit "c6f715d4ccd30e83922e39cab856578ce19224bb" :authors
  '(("Liāu, Kiong-Gē" . "gliao.tw@pm.me"))
  :maintainers
  '(("Liāu, Kiong-Gē" . "gliao.tw@pm.me"))
  :maintainer
  '("Liāu, Kiong-Gē" . "gliao.tw@pm.me")
  :keywords
  '("extensions" "lisp" "theme")
  :url "https://github.com/GongYiLiao/theme-anchor")
;; Local Variables:
;; no-byte-compile: t
;; End:
