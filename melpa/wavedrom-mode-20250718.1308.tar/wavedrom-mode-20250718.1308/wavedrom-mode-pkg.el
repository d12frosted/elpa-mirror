;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wavedrom-mode" "20250718.1308"
  "WaveDrom Integration."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/wavedrom-mode"
  :commit "957369449ba885be81111372baec8857c85432f8"
  :revdesc "957369449ba8"
  :keywords '("fpga" "asic" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
