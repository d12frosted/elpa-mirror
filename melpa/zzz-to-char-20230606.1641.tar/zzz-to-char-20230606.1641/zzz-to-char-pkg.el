(define-package "zzz-to-char" "20230606.1641" "Fancy version of `zap-to-char' command"
  '((emacs "24.4")
    (avy "0.3.0"))
  :commit "3bc8e0b3b34f511be2ae663785e3cad758361ba2" :authors
  '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers
  '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainer
  '("Mark Karpov" . "markkarpov92@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/mrkkrp/zzz-to-char")
;; Local Variables:
;; no-byte-compile: t
;; End:
