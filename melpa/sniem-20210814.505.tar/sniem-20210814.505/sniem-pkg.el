(define-package "sniem" "20210814.505" "Simple united editing method"
  '((emacs "26.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "9d45a80c6153ec742945b9e189cc978ebdbc350d" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
