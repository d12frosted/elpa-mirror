(define-package "emms" "20210405.1208" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (seq "0"))
  :commit "488d38b879867cf4c2df052cfda4a36a2ca1394f" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
