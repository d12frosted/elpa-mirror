(define-package "git-commit" "20220130.2254" "Edit Git commit messages."
  '((emacs "25.1")
    (transient "20210920")
    (with-editor "20211001"))
  :commit "efe590bb4f1020cf8e9503e564a84f569f5ba82e" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
