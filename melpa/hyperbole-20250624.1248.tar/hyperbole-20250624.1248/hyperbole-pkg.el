;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250624.1248"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "6b93a58fc6ab277947cb3f1686872118dfc7a9ff"
  :revdesc "6b93a58fc6ab"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
