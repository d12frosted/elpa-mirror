;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251011.344"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "b267286538f4567577349ec3bcd8751c3c00476e"
  :revdesc "b267286538f4"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
