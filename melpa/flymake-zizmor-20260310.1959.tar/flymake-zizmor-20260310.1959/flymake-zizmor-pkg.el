;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-zizmor" "20260310.1959"
  "Flymake backend for zizmor, a Github Actions static analyzer."
  '((emacs "28.1"))
  :url "https://github.com/unhammer/flymake-zizmor"
  :commit "9b57aa59280a84b60bd4fdf384ef797a37c19b29"
  :revdesc "9b57aa59280a"
  :keywords '("convenience" "languages")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
