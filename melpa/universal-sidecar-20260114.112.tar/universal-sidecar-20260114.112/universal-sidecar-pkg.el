;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "universal-sidecar" "20260114.112"
  "A universal sidecar buffer."
  '((emacs         "26.1")
    (magit-section "3.0.0"))
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar"
  :commit "f908972efcbb6c7318c13671f94e5e5e69a45166"
  :revdesc "f908972efcbb"
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
