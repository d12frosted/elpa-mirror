(define-package "verb" "20240629.1327" "Organize and send HTTP requests"
  '((emacs "26.3"))
  :commit "c5e781c41c4034105ebfa4e281b02b6cc82402df" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
