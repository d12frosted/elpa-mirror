;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260308.905"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "dfac707031b7f460440a088e18b1f6185ff18007"
  :revdesc "dfac707031b7"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
