;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verse-mode" "20250910.2354"
  "Major mode for Verse."
  '((emacs "26.1"))
  :url "https://github.com/sness23/verse-mode"
  :commit "d5facb02832e812d47c4354b26c60d2f73097165"
  :revdesc "d5facb02832e"
  :keywords '("languages" "tools")
  :authors '(("Steven Ness" . "sness@sness.net"))
  :maintainers '(("Steven Ness" . "sness@sness.net")))
