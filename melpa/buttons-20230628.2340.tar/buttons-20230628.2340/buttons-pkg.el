(define-package "buttons" "20230628.2340" "Define and visualize hierarchies of keymaps"
  '((emacs "24.1")
    (cl-lib "0.3"))
  :commit "ae97996cc52bf0523f5b6626db14987c3b56b3e2" :authors
  '(("Ernesto Alfonso"))
  :maintainers
  '((nil . "(concat \"erjoalgo\" \"@\" \"gmail\" \".com\")"))
  :maintainer
  '(nil . "(concat \"erjoalgo\" \"@\" \"gmail\" \".com\")")
  :keywords
  '("lisp" "extensions" "convenience" "tools")
  :url "http://github.com/erjoalgo/emacs-buttons")
;; Local Variables:
;; no-byte-compile: t
;; End:
