;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261028.1920"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "4f95847e3e406e3049f27fc46f1401359fc0e463"
  :revdesc "4f95847e3e40"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
