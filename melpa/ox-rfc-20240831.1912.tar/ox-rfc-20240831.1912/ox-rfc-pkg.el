(define-package "ox-rfc" "20240831.1912" "RFC Back-End for Org Export Engine"
  '((emacs "24.3")
    (org "8.3"))
  :commit "21d7e532a9a0aed7c30dd6f16a3b117c0e3357b0" :authors
  '(("Christian Hopps" . "chopps@devhopps.com"))
  :maintainers
  '(("Christian Hopps" . "chopps@devhopps.com"))
  :maintainer
  '("Christian Hopps" . "chopps@devhopps.com")
  :keywords
  '("org" "rfc" "wp" "xml")
  :url "https://github.com/choppsv1/org-rfc-export")
;; Local Variables:
;; no-byte-compile: t
;; End:
