(define-package "kagi" "20240720.2058" "Kagi API integration"
  '((emacs "29.1")
    (shell-maker "0.46.1"))
  :commit "3ae19c59db3a168e964b8d1a690c2c360640ec82" :authors
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainer
  '("Bram Schoenmakers" . "me@bramschoenmakers.nl")
  :keywords
  '("terminals" "wp")
  :url "https://codeberg.org/bram85/kagi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
