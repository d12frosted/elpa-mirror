;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260202.807"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "3059cbca3371a867d6e2512d225caa5f23f1dce0"
  :revdesc "3059cbca3371")
