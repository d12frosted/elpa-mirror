;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260410.1751"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "7fc50aac89cae2d5f709c1d702efab8c87e8dfa5"
  :revdesc "7fc50aac89ca"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
