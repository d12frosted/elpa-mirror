(define-package "flycheck-grammalecte" "20210705.1656" "Integrate Grammalecte with Flycheck"
  '((emacs "26.1")
    (flycheck "26"))
  :commit "061ce63d217b7cd165c487d81331843dea5bc11c" :authors
  '(("Guilhem Doulcier" . "guilhem.doulcier@espci.fr")
    ("Étienne Deparis" . "etienne@depar.is"))
  :maintainer
  '("Étienne Deparis" . "etienne@depar.is")
  :keywords
  '("i18n" "text")
  :url "https://git.umaneti.net/flycheck-grammalecte/")
;; Local Variables:
;; no-byte-compile: t
;; End:
