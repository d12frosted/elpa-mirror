;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seti-theme" "20190201.1848"
  "A dark colored theme, inspired by Seti Atom Theme."
  ()
  :url "https://github.com/caisah/seti-theme"
  :commit "9d76db0b91d4f574dd96ac80fad41da35bffa109"
  :revdesc "9d76db0b91d4"
  :keywords '("themes")
  :authors '(("Vlad Piersec" . "vlad.piersec@gmail.com"))
  :maintainers '(("Vlad Piersec" . "vlad.piersec@gmail.com")))
