;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250312.2309"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (el-job        "1.0.5")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "4a795fa2c3f6d0420bc44a29973277d7aeb73c4e"
  :revdesc "4a795fa2c3f6"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
