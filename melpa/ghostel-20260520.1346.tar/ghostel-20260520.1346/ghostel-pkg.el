;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260520.1346"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "db4cc3af8a1c6ae89b0036f98dca768cdafbb326"
  :revdesc "db4cc3af8a1c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
