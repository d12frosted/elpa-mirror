;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "20260614.2114"
  "Visually highlight the selected buffer."
  '((emacs "27.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "01f0ebca1641a072a6af5bda68db405276787e79"
  :revdesc "01f0ebca1641"
  :keywords '("faces" "editing"))
