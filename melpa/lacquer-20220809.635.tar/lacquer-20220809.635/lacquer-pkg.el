(define-package "lacquer" "20220809.635" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "676919f5fc301451fcfb8553c3f8262a65c36192" :authors
  '(("zakudriver" . "zy.hua1122@outlook.com"))
  :maintainer
  '("zakudriver" . "zy.hua1122@outlook.com")
  :keywords
  '("tools")
  :url "https://github.com/zakudriver/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
