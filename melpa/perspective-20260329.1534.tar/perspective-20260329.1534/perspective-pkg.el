;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective" "20260329.1534"
  "Switch between named \"perspectives\" of the editor."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/nex3/perspective-el"
  :commit "f384207b12f07353e0a6d148de6bd332334fafcd"
  :revdesc "f384207b12f0"
  :keywords '("workspace" "convenience" "frames")
  :authors '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers '(("Natalie Weizenbaum" . "nex342@gmail.com")))
