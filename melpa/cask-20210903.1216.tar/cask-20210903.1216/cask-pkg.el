(define-package "cask" "20210903.1216" "Cask: Project management for package development"
  '((emacs "24.1")
    (s "1.8.0")
    (f "0.16.0")
    (epl "0.5")
    (shut-up "0.1.0")
    (cl-lib "0.3")
    (package-build "0")
    (ansi "0.4.1"))
  :commit "7b637efa35148dca5e6de10d0beba72168762f1c" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("speed" "convenience")
  :url "http://github.com/cask/cask")
;; Local Variables:
;; no-byte-compile: t
;; End:
