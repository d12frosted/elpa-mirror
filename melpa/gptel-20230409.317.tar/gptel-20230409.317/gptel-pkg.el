(define-package "gptel" "20230409.317" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "acf12ee6e384e2b6a5df013ddcd9adec43a75c70" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
