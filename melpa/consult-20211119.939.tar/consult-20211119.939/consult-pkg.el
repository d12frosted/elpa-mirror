(define-package "consult" "20211119.939" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "37096d4bc4031a6a3d020ae225b6c675fa5ec0b7" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
