(define-package "consult" "20211119.939" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "378365f13d600b31ec23b1440bb7b239e7e18d7c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
