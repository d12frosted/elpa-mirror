(define-package "consult" "20211119.939" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b70bd86747ca4d0d7aaba980f9995766c1bfc84e" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
