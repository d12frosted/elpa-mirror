;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pet" "20241126.806"
  "Executable and virtualenv tracker for python-mode."
  '((emacs "26.1")
    (f     "0.6.0")
    (map   "3.3.1")
    (seq   "2.24"))
  :url "https://github.com/wyuenho/emacs-pet"
  :commit "1d7ea0daa753ef8e9a61e799cae54e0afe6621b1"
  :revdesc "1d7ea0daa753"
  :keywords '("tools")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
