;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260425.1212"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "3c61db63eec06334869258905a86d1fb8af5c507"
  :revdesc "3c61db63eec0"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
