(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "07015ba648ef727c061d5dd1c19dc64f78fbb919" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
