(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b11461e12d59b23039e1446fb47fe047fcac4be0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
