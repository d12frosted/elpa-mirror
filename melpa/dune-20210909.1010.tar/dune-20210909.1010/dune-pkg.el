(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "fe2a7d8a428250c2e732b090d38bec3ba99caf36" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
