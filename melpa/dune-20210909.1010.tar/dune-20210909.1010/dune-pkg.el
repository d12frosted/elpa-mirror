(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "eaa1379e8ae0abc80febbee9ee3d557e4664db7b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
