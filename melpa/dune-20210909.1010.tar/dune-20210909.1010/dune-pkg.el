(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "064ff9fa95533653af69e6c10cf8307c7037d76f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
