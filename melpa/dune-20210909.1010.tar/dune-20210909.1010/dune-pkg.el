(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6000bebe6b588d85ab3ffa1e21e85df6feea6ea0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
