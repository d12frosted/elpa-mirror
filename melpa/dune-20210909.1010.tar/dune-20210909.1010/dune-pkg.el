(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ed854c8663b2322cd74b69248f94266e97f0f267" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
