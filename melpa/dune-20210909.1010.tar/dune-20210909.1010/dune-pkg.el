(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "00b4e843baacca8d3e7f7ae52d6abed7ebe575fd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
