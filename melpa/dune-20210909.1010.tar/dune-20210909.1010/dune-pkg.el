(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "28df1cf4c31ca9882dd1c9ab9e4d259e425e9db5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
