(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "eeca82146f1e811a12a64dbc521e086850281e25" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
