(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "eed8600e1d5e9545de49ea38c045b9c4a66c5633" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
