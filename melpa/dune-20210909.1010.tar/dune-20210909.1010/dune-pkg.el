(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "55ff54acfd1e337561a4e5213c75a8512e53e3f1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
