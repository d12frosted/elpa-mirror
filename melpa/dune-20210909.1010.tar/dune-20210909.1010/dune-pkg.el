(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "443f89320cc426593f5536bbc895a483be471e69" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
