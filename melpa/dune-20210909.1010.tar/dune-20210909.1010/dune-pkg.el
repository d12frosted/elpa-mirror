(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "97be53905a0c66873edb8c52046c741f1bbacaa4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
