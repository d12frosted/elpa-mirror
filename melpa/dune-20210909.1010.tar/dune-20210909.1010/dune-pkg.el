(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d178570a58a990400a362814d3d288902aeae91d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
