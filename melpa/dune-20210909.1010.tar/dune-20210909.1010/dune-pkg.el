(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e8d4bc5485f028b13ccfbeda4030b8dc6fea05ad" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
