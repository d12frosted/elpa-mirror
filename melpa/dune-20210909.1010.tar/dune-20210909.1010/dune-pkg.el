(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2b5b515c43799c5fad45e6f74e93262cf604ae24" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
