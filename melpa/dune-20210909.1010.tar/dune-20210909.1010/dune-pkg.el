(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f20ce60db081eb1214fe4510532fecf15be80f30" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
