(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d159f42375d19463970b3664c8cbf2d88a52464c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
