(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b12a5cd2664ae9e0820f52c816c88c372f0054ee" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
