(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d67f1b02d32b83aa3010066e5952d0a388adf2d5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
