(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "be7eb9c25bd132ad073ce15aadfb1e34f343243a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
