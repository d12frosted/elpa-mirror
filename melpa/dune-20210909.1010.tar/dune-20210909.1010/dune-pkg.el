(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a83a10aac905ea0690decd0558cfc7fe5285afb6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
