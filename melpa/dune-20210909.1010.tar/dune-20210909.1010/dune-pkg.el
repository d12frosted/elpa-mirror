(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "76a9b17fecf530fdb85564540c1bc7aacf2788ea" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
