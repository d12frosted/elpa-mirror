(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "cff55b104a0bb7ebf688570ebdeb3833371f1462" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
