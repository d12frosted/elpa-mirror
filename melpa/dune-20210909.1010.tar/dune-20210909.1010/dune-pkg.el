(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "43a7bf71bd01c8013854a60dd4ec82ca5f288d57" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
