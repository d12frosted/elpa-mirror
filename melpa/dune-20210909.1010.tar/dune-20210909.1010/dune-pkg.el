(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "70ed791de64cd0180b0bddb3318b5a51ac99c6b5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
