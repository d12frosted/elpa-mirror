(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0136e8ba2ea6001b60481aa8dcd823d7ae63d746" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
