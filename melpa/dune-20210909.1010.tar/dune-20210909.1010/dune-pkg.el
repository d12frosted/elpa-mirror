(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "11b6c5f25ef440628334d1e0fce4a7b6d6baa105" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
