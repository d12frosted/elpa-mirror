(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "dcf921ca5cd825ddb054682809bc4032e0d92ebc" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
