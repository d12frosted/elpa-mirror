(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0459195c722df4508b0d0f7550bdf02d191920d5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
