(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "faa9254023cf64bf92c8e4c0ecfb0f0368bd993b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
