(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "36d7c68777aa4e9644e58c71dc60a517dc3bcea7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
