(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "936c3981bd745fcb8ecd3da800952ee8cd1f65b7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
