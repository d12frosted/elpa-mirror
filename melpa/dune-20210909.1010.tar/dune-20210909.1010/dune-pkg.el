(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7d227546196a271dc40372d88a7bdaa6652a2832" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
