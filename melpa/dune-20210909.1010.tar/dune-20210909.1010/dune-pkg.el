(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7333e33a3fa7d9be93d7e32b0d12a5940b803a4f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
