(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d5676f07e5934a33d9365ecae913a2b6a2d869e0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
