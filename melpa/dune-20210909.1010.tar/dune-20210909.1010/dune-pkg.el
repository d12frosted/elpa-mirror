(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "862831cd6e1146b0c18e6bdbf7daafb42868d439" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
