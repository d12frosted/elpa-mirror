(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3b2c64a3d74fcc2d808d86119ed235999f1f88fa" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
