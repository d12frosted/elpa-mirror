(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0763bd51d8701a132f4803f8f0b7d7e9e866944a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
