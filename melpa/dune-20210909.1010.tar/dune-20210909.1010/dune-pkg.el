(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0b5564e1e98c244eb8cb0534ac511c526fd707f4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
