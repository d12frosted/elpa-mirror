(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "c7448890c1a9f2ad7a75dbd7c973b829729b12e1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
