(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f17ca7865665be62d48a520773d80ad10336686f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
