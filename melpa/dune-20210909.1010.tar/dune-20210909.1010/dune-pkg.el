(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6241519b9be7330f7c4a4a58fa6ce7edc7d1e793" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
