(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "4346cb9f869a505cb43cc42fa6253208aefd575a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
