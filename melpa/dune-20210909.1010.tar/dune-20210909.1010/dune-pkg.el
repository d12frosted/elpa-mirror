(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "853638c4a17fda92e9116f75f12018013505009f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
