(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "1a8246309b3864ad7b33b4f9ab89c171127eb861" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
