(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "4d0a47edd53dc2141059cbf99bfec858a08e9fe0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
