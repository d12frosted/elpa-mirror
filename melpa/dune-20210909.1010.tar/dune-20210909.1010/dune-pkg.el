(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2d97a3354d28d96c6102326e2e042056e19a06a1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
