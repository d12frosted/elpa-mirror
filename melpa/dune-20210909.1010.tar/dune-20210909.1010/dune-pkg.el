(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7eb686d1df0f1cc22e0f4fd9e2b0ee5cad9fd15b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
