(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e9cb2d66abb690b7a5585d293793a7e020762e00" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
