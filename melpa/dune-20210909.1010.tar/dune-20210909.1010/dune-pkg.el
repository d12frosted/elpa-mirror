(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "71a0d184e1ed546b6046c309e39f9e3ca807c986" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
