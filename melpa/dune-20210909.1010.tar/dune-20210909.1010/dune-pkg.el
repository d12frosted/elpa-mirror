(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ecbe78430ba1e93d043fc36dcda996d0cb833f25" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
