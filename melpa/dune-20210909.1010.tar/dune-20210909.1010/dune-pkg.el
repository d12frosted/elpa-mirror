(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "099652ae54ace149184424fef3c43a36319d2945" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
