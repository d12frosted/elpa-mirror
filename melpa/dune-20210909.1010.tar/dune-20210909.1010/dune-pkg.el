(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0b4bc8a955bbdc3d655310228554287b0ddc349f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
