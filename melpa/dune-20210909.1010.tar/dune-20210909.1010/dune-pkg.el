(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "9254c24c817f0f20a8242b9930ec0bcc595d2ec9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
