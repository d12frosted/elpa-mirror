(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "80e2e1485322b84ac19147e5a0f976db1fee64e5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
