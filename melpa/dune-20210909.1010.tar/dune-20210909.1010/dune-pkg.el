(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6335827f6b58f23524e8ea9f1b152a7aa8030fc3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
