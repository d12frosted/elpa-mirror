(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "add3172783176eeda73ab2d2aed286cd33a273d0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
