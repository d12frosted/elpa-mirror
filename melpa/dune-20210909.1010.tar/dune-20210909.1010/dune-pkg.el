(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f3ca9c3ce5799bf1ec064e57e5394ddc699e4831" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
