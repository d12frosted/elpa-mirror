(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "c46b89e1f6204ccff747357b9283d93fd3021b48" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
