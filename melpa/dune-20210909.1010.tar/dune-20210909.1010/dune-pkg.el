(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "fe032c380ff379e31495a770d18e99d800c8541f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
