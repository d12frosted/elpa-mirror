(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2cb16d57e99fc477bb89d72460e1fb7655b2f1e8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
