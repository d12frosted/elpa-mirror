(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7b90b08f9e68e7d1879a4cdc9de184cd446ea549" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
