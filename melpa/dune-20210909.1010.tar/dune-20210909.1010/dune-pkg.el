(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "339e431d979169c87bcc579d3a7b9f0331f269bd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
