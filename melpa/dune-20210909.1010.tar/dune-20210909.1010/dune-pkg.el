(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "168210bf8733bc79a9528e11da6957fbe70b827a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
