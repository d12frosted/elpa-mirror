(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a79a071739b9537da8f9dc236a964793979da849" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
