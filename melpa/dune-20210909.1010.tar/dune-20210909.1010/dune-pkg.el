(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3810cb4091a6fd51946ef447491bca23362a0328" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
