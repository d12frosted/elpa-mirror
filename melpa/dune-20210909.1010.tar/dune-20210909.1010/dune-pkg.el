(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "06378dc9c8362f22f3ecb481a475ff6bacace084" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
