(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "089727fb6f8262309f64925c95928d572b0d7718" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
