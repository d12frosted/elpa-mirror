(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "87a2d25e56caf65600e9d3f647bcb4999556ecb4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
