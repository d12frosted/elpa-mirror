(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b308e9552dbadc1a0f205993f244748836da3008" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
