(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "c63c9898e651e5505f965c3a48dd4089b8d88d9a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
