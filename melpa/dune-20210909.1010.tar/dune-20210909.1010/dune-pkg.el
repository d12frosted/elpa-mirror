(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "342b4145d09886d53660db242591aa607ddce8ee" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
