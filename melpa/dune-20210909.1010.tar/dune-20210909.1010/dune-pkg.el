(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a00e2de7bee81b1541d44331b63bf6294902ac19" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
