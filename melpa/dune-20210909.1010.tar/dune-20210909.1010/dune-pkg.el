(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "293742d6b1456c1d54a63705a774f3372c0b69a2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
