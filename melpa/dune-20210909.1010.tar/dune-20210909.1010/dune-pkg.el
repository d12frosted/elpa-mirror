(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3276f186934740f351b42e8e4993155a0771e31c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
