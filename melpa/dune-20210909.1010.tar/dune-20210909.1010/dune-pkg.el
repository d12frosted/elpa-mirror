(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0f09b884e9e299f966f6c599c98978caa3ce307d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
