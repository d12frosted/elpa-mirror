(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8322070ed8c15884490a4d8e8714643e0412b5a6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
