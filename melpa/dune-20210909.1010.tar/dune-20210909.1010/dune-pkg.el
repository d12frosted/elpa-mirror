(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "367ae306d8069e8a4c25debf16e14dfd10614012" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
