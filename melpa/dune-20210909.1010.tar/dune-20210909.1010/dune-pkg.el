(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b2e3864fab95fdfdcdd3aab7ceaf66dc41871964" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
