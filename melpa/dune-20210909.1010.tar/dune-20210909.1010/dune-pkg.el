(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b6299ec743c71c762a25caa4e66f72e590267a42" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
