(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "fd770a815ca5143e0e088b33bbaf873682b13053" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
