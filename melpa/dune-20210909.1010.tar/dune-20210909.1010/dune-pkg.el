(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "cf3e99aeb57c4aa0d4b0c88c8c6eb01af9d9e3f4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
