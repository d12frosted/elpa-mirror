(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "559811a51670c90e25d50483b6a258aa8a1f620f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
