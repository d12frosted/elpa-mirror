(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "921cf99374b6619b299cd3d61e0f50f472dc3c2f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
