(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "bc521522dcab27b2963a6445454d386fbe81fbef" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
