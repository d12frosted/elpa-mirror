(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "56c5a621fbbe60a21369fc01d6f3736eea457a88" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
