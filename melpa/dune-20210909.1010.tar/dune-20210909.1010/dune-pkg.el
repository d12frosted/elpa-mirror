(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "1c7412ce4168f83c5cad8cdddd72bc68dad825da" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
