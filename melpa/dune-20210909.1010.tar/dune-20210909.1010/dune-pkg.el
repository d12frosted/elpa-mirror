(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "af5caa8170ed375622801827619cf86f74e72b9a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
