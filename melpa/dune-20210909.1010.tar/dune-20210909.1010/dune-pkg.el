(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "419786f1d3c3f3289771ce78b12bb9469eb3084d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
