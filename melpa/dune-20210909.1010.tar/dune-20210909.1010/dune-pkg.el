(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ce51dc2cf369773be1e0b42057e025cd633b8f52" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
