(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a48edf8706ce272b0a96753ac0126e40cbe47481" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
