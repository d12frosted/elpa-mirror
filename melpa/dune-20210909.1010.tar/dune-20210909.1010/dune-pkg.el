(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0b7b0b2b44113b932b3655f6bc7cee1a2ac1484e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
