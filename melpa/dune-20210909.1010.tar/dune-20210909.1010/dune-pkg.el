(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "482b4f818857b35e5114498fa63012d13a6d84fd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
