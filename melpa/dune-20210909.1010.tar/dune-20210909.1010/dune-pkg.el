(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8f8c974a73cb38f336d6cb7e8e9407a541d8b20c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
