(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f1962910d0e678f5055d0bbd6e24bba64b1ef2b2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
