(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "dec2210009f564a6d3f76e8f94710fd795ca8527" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
