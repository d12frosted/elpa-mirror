(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "892c1954c94a8347330e29b8005a2261001ba70c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
