(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a6b1dc37e9e7286f88dbcfe5725ea93908798801" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
