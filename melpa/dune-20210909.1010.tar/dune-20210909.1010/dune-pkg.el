(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "9c3b942de19b7f5c64685a66df74abc5218fd52d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
