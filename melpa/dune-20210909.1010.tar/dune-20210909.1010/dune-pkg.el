(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "317e653ab1c748f1e6572c36e777274eb5521be4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
