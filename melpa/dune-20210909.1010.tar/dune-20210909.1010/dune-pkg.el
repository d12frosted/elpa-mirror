(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ebd799739dd7bc1beb06acec7e89e00190195835" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
