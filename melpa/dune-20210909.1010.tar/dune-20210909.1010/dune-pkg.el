(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "482260335eb57d50ce06a176eb49738a91d9a66c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
