(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "133466710c47868e0a66e8001836c0c858676a4e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
