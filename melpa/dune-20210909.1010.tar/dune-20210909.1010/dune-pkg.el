(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "5babcfd7f56f331d6271e51cb52fc4d09135ffb1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
