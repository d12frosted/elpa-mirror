(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "bb6be5db4fec0c43232834f5f98e361ce1538569" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
