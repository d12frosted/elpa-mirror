(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2d11857a9fc2b685d5f915b6cbb27645daab5950" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
