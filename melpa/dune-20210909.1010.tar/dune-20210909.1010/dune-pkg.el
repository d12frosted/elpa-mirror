(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "44c9a931daa2c180be756e6e46a572f70f5e59d5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
