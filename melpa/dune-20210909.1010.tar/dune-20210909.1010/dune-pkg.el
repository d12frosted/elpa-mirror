(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "dc053aa9dba52324c1d54ecb4afc2ff703c72597" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
