(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "56f6f7cc08794d2f9e24a5bc098c6c59783afccc" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
