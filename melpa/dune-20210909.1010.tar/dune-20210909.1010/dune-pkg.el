(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "371bf468e0e3d4d9be99e9aca8a85e6ee6427d65" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
