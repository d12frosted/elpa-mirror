(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "45ab36f6d36dbf5f15be1d3293770ba744bbb8a6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
