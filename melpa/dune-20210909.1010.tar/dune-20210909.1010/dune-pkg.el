(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e46699af03c7b5eb0c9897be3859ea046185dd26" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
