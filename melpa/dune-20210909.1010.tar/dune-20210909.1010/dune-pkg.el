(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "72b6f8a5192ade12d47beafbbcae1b32771ef5ad" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
