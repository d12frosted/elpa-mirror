(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8c8b71259079b1b260467340cc81b357371133ed" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
