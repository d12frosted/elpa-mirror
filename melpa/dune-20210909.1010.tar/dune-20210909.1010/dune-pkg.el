(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "55a27c721af1077a167e253af31ccb717986317b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
