(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8677fe3bf91112b18f429dcdb1bd58b09f9c9163" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
