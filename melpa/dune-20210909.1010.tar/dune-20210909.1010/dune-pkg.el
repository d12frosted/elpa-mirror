(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6c56e5bdd91525f48825bef7c47a39878d391ae5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
