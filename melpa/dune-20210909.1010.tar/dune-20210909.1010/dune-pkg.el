(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ac188544b55357c1fff277f54d1481d28a634e19" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
