(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0632fddead738c1a539f1c83180dc8762b04933a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
