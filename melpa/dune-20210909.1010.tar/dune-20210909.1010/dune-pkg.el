(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7454f1e06b2dc56fd0d48adfcc01bad70ecca190" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
