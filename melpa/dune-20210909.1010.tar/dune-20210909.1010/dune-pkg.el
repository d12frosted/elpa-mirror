(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "edda504c8b16edb3c7e76cf5ccff9f3e4229d836" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
