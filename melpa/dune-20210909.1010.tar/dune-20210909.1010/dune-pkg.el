(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f6b3d59a9ab928fe9696e08be3ffd27b49f740db" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
