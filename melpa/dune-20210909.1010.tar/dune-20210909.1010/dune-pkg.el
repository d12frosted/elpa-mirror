(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8e155da034f1f1c10fed88bdba4887ac26be9bcf" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
