(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e2dcb4004141387fdc64b9bee2e126e23f461109" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
