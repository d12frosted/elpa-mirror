(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d86fc30e06f61d43c6f18dfa1fb768a1b695d1e4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
