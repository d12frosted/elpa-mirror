(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "724ef5ee009f9c901f4bb545026cb0ce54fca6f1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
