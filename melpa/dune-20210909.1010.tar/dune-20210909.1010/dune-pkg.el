(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "dbaa19178afe086c7beb532f2e1d9981a7cc538c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
