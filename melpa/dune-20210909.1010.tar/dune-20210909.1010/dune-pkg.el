(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "dd2cd6d794e264c39052b1dfe6a41677dc0e3a34" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
