(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3eff8102d299bc6f408736ad641b0392957a4ac1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
