(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ba9a5494105aaa5691f35cd044736428855a0513" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
