(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ba17d111d99a3b65ccf2b35ba383d8083bc1f1e1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
