(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "5101dda2878c7062ca05c7edb12aef578f5fb84b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
