(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "27d185b7606f25e99f50f941df183121d959b6fb" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
