(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "9ccfc6122533ab8ed80e0c4587b582baa214c6d5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
