(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a6c6ed8e31d8e9098ee714f3d60470bd7997dfe7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
