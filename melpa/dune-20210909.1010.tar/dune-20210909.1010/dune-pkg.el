(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "df30c1afbe5f32f60c42e46628837fc47189aab4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
