(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "85967278b4270a2e850d4818ff7db990ee3adc53" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
