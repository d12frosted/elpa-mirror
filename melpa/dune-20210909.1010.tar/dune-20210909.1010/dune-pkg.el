(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b8e0fe7219b4568cd83507b82dbb865d4db79e1c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
