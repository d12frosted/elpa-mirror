(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "61ebc96248feb68c557858de0cb3af3eafc449ac" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
