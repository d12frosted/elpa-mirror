(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "63fa7402db9b2173356e014acfc3c50a7a509da4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
