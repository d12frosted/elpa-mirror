(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a3a82ef8f3112593bd7923cbd2cdd61a305f570a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
