(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6e76fbad10517dd0a52ee31abc83d4ea018058a6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
