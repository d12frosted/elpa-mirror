(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2ef6409e968804d4f2ec2a69ae0f36dee3c4aaca" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
