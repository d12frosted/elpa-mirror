(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3ad31ba242ffcf7074e2ab5b9f24e073d2009a54" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
