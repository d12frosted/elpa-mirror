(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "285da637cdff56b1ebbcb386c70fe2633121f18e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
