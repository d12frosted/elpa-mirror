(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f6a8920f49b51d7e0022bf7ae17dc6aa29357095" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
