(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "50815dbdda5c924142bf2c54feba87c5894465d5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
