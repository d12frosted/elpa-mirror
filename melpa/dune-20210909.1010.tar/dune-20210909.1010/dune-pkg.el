(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2d2b6475656e8d3ff86869445feff4610e71e35c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
