(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a16477642617552fccaa2e837a0a6314234df71c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
