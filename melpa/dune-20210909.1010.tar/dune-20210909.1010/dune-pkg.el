(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a6bc3ee17d3af36b063bec993b5ba10ff4699945" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
