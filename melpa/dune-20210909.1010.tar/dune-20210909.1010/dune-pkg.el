(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "eced55964b15df0a16a11e8bf4aa3934348a848d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
