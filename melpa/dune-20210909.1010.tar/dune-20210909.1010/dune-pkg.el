(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "cb6b71459113b6d9c80348f0570a59f84cf0ac1e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
