(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "71e65a2c9b09a32f8a0ff235954ed78b72a3dba2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
