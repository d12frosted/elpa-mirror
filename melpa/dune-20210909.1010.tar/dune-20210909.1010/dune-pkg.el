(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "862b4266190faf606ace3bfc13adaf2828c4655e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
