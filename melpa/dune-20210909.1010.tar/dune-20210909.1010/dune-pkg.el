(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "5061cc9ebe4ae3222938dd7c5f2bd6b842e8edc1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
