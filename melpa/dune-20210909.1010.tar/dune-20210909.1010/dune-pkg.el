(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "33694c441772a35bd03fef0c3294f19784a7dcc8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
