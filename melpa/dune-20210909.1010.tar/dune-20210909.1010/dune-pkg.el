(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "70793763b5b1f687f527f917fea33366f90167ac" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
