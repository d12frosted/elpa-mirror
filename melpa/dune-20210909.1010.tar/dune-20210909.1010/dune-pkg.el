(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3b0546de975a40348e451370355ae61f1b4f99f1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
