(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8f7eb1e013f4579e9b73a89fb32e8b50975fb6ee" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
