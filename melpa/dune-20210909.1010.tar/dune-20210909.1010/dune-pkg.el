(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "647ba82c612f97308322570b79e1ed8f136e3fa2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
