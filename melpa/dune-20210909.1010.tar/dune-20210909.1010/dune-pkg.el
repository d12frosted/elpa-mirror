(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "dc943a17c22377c9eb636bbdf896ba39559ea578" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
