(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "cb139e735ebcf808b6ccf9391df7e398a89c78b0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
