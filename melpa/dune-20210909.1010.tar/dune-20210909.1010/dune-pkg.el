(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "00ab3cba7f765e4d3ce48feb456b01e517647f19" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
