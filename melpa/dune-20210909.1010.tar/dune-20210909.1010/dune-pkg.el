(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "cf0ceccef1e177625b9361323bd7a3401a988d45" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
