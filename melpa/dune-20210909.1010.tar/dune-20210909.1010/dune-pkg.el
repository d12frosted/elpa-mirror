(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "c37e1d2aa243c431c8681705cf0185a5a33ca2ba" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
