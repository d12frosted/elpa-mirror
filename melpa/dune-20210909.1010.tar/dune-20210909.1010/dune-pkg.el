(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d4e004ef0fceb1970f2f8ac2465f6b6bf6136eab" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
