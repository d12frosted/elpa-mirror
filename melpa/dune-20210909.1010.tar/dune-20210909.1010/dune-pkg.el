(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "54b6bc704b836e4b4d444e6532655e5089e71a04" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
