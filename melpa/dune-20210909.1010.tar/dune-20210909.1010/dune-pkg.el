(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8dd64bf716fad5bd48dff2b768b660bd7067e8c9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
