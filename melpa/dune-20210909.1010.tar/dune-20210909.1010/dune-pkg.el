(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "1638e8c3cfd2a2ff3f716ba2090402b3145ef0d3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
