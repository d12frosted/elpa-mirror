(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ebc46c58f011592c63a80f768510b8a59d8b217d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
