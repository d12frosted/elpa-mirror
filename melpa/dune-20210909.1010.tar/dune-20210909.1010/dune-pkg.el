(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8ef59e4648abf2ff1f042136ad767f22dd31b93c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
