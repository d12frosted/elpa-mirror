(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "701ef7722d297bd3f809872a843dbacf92ac5700" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
