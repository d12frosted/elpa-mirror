(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a73b0662c9dc92e32dbbcc071d05bfa8be2057b0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
