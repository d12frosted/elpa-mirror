(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "cd6d19dbeb7574ce834ed994069a8112da904097" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
