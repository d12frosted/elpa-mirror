(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6046bb8319b51b6344f0422731ce2b36d2921f40" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
