(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6a0314ce37c02b42f3147e4592fba1ce2d5c49a5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
