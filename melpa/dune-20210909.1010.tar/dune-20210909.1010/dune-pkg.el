(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "32ef2d50be4e1f9f16f3cb2d9727be0c24920ec4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
