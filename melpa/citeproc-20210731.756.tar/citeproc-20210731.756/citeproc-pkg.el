(define-package "citeproc" "20210731.756" "A CSL 1.0.1 Citation Processor"
  '((emacs "25")
    (dash "2.13.0")
    (s "1.12.0")
    (f "0.18.0")
    (queue "0.2")
    (string-inflection "1.0")
    (org "9")
    (parsebib "2.4"))
  :commit "9b2120cd62c52239e3046cb9569d7b8ca21ae215" :authors
  '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainer
  '("András Simonyi" . "andras.simonyi@gmail.com")
  :keywords
  '("bib")
  :url "https://github.com/andras-simonyi/citeproc-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
