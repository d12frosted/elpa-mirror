;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260114.1604"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "40ea6e38f3845a4dd081111df0404dd5aca956de"
  :revdesc "40ea6e38f384"
  :keywords '("convenience"))
