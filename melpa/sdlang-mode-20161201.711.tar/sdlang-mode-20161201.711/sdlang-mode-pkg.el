;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sdlang-mode" "20161201.711"
  "Major mode for Simple Declarative Language files."
  '((emacs "24.3"))
  :url "https://github.com/CyberShadow/sdlang-mode"
  :commit "d42a6eedefeb44919fbacf58d302b6df18f05bbc"
  :revdesc "d42a6eedefeb"
  :keywords '("languages"))
