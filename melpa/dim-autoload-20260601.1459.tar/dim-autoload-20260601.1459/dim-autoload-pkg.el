;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dim-autoload" "20260601.1459"
  "Dim or hide autoload cookie lines."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/dim-autoload"
  :commit "a9024464f0f0573338eaa490cfca998e66bf47f7"
  :revdesc "a9024464f0f0"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.dim-autoload@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.dim-autoload@jonas.bernoulli.dev")))
