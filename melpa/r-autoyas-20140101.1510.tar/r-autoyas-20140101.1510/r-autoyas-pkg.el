(define-package "r-autoyas" "20140101.1510" "Provides automatically created yasnippets for R function argument lists."
  '((ess "0")
    (yasnippet "0.8.0"))
  :commit "d321a7da0ef2e94668d53e0807277da7b70ea678" :authors
  '(("Sven Hartenstein & Matthew Fidler"))
  :maintainer
  '("Matthew Fidler")
  :keywords
  '("r" "yasnippet")
  :url "https://github.com/mlf176f2/r-autoyas.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
