(define-package "tuareg" "20210624.902" "OCaml mode for Emacs."
  '((caml "3.12.0.1")
    (emacs "24.4"))
  :commit "98b3e77d2ade682566053be819a50853ffa8e0b4" :authors
  '(("Albert Cohen" . "Albert.Cohen@inria.fr")
    ("Sam Steingold" . "sds@gnu.org")
    ("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
    ("Till Varoquaux" . "till@pps.jussieu.fr")
    ("Sean McLaughlin" . "seanmcl@gmail.com")
    ("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainer
  '("Albert Cohen" . "Albert.Cohen@inria.fr")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/tuareg")
;; Local Variables:
;; no-byte-compile: t
;; End:
