(define-package "org-node" "20240917.928" "Link org-id entries into a network"
  '((emacs "28.1")
    (compat "30")
    (dash "2.19.1")
    (transient "0.4.3")
    (persist "0.6.1"))
  :commit "d2cf200c5379a7e4d7220b681fb8813c36dc4a2b" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node")
;; Local Variables:
;; no-byte-compile: t
;; End:
