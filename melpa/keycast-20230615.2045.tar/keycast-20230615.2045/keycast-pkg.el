(define-package "keycast" "20230615.2045" "Show current command and its binding"
  '((emacs "25.3")
    (compat "29.1.4.1"))
  :commit "a0549f420b100f6ea0e66422ba65a827f3fc47d8" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("multimedia")
  :url "https://github.com/tarsius/keycast")
;; Local Variables:
;; no-byte-compile: t
;; End:
