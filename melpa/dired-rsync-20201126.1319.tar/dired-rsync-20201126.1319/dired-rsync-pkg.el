(define-package "dired-rsync" "20201126.1319" "Allow rsync from dired buffers"
  '((s "1.12.0")
    (dash "2.0.0")
    (emacs "24"))
  :commit "fe5988154c843c70d080ae8a822f27ed83983d01" :authors
  (("Alex Bennée" . "alex@bennee.com"))
  :maintainer
  ("Alex Bennée" . "alex@bennee.com")
  :url "https://github.com/stsquad/dired-rsync")
;; Local Variables:
;; no-byte-compile: t
;; End:
