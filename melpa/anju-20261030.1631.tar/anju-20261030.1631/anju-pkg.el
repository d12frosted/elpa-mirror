;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20261030.1631"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "b485825b7aa0114ca570ef0ae9af3a4feb609086"
  :revdesc "b485825b7aa0"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
