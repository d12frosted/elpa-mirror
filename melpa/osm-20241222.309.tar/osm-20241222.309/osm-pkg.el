;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20241222.309"
  "OpenStreetMap viewer."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "fda895f1c38ade3ced65f6142e2f5c0221c3380e"
  :revdesc "fda895f1c38a"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
