;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260324.2122"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "0489cc8de30d099633f1a1d3e9898f2fdb108d70"
  :revdesc "0489cc8de30d"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
