;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260318.505"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "1d94d7bea657e5b17b135ec232aeb2d77cf0c5da"
  :revdesc "1d94d7bea657"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
