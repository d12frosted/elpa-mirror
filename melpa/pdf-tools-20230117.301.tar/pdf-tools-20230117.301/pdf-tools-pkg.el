(define-package "pdf-tools" "20230117.301" "Support library for PDF documents"
  '((emacs "26.3")
    (tablist "1.0")
    (let-alist "1.0.4"))
  :commit "e55e2ceca7a6091265eadec254c7fad98851a886" :authors
  '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainer
  '("Vedang Manerikar" . "vedang.manerikar@gmail.com")
  :keywords
  '("files" "multimedia")
  :url "http://github.com/vedang/pdf-tools/")
;; Local Variables:
;; no-byte-compile: t
;; End:
