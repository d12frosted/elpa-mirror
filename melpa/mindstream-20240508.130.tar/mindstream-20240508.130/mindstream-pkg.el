(define-package "mindstream" "20240508.130" "Start writing, stay focused, don't worry"
  '((emacs "25.1")
    (magit "3.3.0"))
  :commit "0eb1a8289deba7a305b0848dfc775c9969162303" :authors
  '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainers
  '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainer
  '("Siddhartha Kasivajhula" . "sid@countvajhula.com")
  :keywords
  '("convenience" "files" "languages" "outlines" "tools" "vc" "wp")
  :url "https://github.com/countvajhula/mindstream")
;; Local Variables:
;; no-byte-compile: t
;; End:
