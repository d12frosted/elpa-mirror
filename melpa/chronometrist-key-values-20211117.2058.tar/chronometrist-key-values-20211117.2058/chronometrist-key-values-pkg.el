(define-package "chronometrist-key-values" "20211117.2058" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "133554d1b89b988235475b1c815cd7d808128393" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
