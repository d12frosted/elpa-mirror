;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-tab-groups" "20260907.933"
  "Simple auto tab group creator for specified commands."
  '((emacs "29.1"))
  :url "https://github.com/MArpogaus/auto-tab-groups"
  :commit "4cdf0f121efe2e32854bb6e198eabb3230906f48"
  :revdesc "4cdf0f121efe"
  :keywords '("convenience" "tabs")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
