;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-tab-groups" "20260907.933"
  "Simple auto tab group creator for specified commands."
  '((emacs "29.1"))
  :url "https://github.com/MArpogaus/auto-tab-groups"
  :commit "4c874614677a44d693a3b55604c87f6bb905e2de"
  :revdesc "4c874614677a"
  :keywords '("convenience" "tabs")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
