(define-package "citre" "20220405.1637" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "c398d77adc4b7210ca9be665f9b0243deafe2d3f" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
