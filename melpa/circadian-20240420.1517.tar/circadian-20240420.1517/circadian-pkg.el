(define-package "circadian" "20240420.1517" "Theme-switching based on daytime"
  '((emacs "24.4"))
  :commit "ed24f8d3d47b8d866a740f7cc17e8e8845dba3f2" :authors
  '(("Guido Schmidt"))
  :maintainers
  '(("Guido Schmidt" . "git@guidoschmidt.cc"))
  :maintainer
  '("Guido Schmidt" . "git@guidoschmidt.cc")
  :keywords
  '("themes")
  :url "https://github.com/GuidoSchmidt/circadian")
;; Local Variables:
;; no-byte-compile: t
;; End:
