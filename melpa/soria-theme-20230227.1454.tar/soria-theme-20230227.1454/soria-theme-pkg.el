(define-package "soria-theme" "20230227.1454" "A xoria256 theme with some colors from openSUSE"
  '((emacs "25.1"))
  :commit "c5275d02fcc9f6af2cfebd69bcf69f8cdccbe3ab" :authors
  '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainer
  '("Miquel Sabaté Solà" . "mikisabate@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/mssola/soria")
;; Local Variables:
;; no-byte-compile: t
;; End:
