(define-package "embark" "20211121.2202" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "051c9b8aeff8987fbf4cd5acccb5fe3e8b6d4a55" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
