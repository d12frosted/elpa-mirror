;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marmalade-client" "20141231.2007"
  "Client for marmalade API from emacs."
  '((web "0.5.2")
    (kv  "0.0.19")
    (gh  "0.8.0"))
  :url "https://github.com/nicferrier/emacs-marmalade-upload"
  :commit "f315dea57e4fbebd9ee0668c0bafd4c45c7b754a"
  :revdesc "f315dea57e4f"
  :keywords '("lisp")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
