;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "20260324.1236"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "4fd1ae83d21f6349cd849f3652e7bf8f00edc9dd"
  :revdesc "4fd1ae83d21f"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
