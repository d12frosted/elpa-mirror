;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260217.318"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "c210c9f67cb9904d4b3ea394e3e6f1c9cebd3511"
  :revdesc "c210c9f67cb9"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
