;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260826.246"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "d0b3daa538a6aecaadcc7336a0c9f5d03774725e"
  :revdesc "d0b3daa538a6"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
