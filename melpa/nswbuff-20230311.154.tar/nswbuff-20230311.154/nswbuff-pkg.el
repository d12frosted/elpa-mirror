;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nswbuff" "20230311.154"
  "Quick switching between buffers."
  '((emacs "25.1"))
  :url "https://github.com/joostkremers/nswbuff"
  :commit "dfea30e33ddb212a0d537bc927b4bcdf3ebe2cd1"
  :revdesc "dfea30e33ddb"
  :keywords '("extensions" "convenience")
  :authors '(("David Ponce" . "david@dponce.com")
             ("Kahlil HODGSON" . "dorge@tpg.com.au")
             ("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
