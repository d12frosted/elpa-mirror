;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260709.1248"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "3668ca7f627f3497d907293f38dcfbe33fb6f4f7"
  :revdesc "3668ca7f627f"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
