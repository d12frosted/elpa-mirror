;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260314.2123"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "117d287ba217fb3315cf0115490d983d18df0308"
  :revdesc "117d287ba217")
