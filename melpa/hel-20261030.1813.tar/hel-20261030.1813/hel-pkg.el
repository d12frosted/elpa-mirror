;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "20261030.1813"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "68ecfc5536b0dc072db4f235ff317a2b56f5959a"
  :revdesc "68ecfc5536b0"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
