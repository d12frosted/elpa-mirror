(define-package "helm" "20240524.442" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.8")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "772313af34110ed0e712e7708967c18e6b1941f1" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
