;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260806.1645"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ddee01b8ec2dac9c5e9f748864bdacfe826efbcc"
  :revdesc "ddee01b8ec2d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
