(define-package "consult" "20211006.737" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "089140e998fdbd5d8f2fa54dc5c288f7e895d83a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
