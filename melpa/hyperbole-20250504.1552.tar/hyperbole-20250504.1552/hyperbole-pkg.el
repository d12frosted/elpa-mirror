;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250504.1552"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "d3c7ebdf0f8ca82becf7fae4e7f26672a93a21bf"
  :revdesc "d3c7ebdf0f8c"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
