;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20241209.1432"
  "Beautify Org Links."
  '((emacs      "29.1")
    (org        "9.7.14")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "ee302b5e06b303bb0ad9526638063ed97fc005a7"
  :revdesc "ee302b5e06b3"
  :keywords '("hypermedia"))
