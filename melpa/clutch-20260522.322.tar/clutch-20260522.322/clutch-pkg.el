;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260522.322"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.0")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "9484eb8848b83f9edf372c6114abdd7e3e87783d"
  :revdesc "9484eb8848b8"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
