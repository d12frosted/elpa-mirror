;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250417.621"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "d3164f4295c59b169ff3ab924ede53ba4799f1ca"
  :revdesc "d3164f4295c5"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
