(define-package "wanderlust" "20220607.2211" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "8fc4e70989deb8ffdd92ce436c4ef482a0d90c90")
;; Local Variables:
;; no-byte-compile: t
;; End:
