(define-package "icomplete-vertical" "20210520.2058" "Display icomplete candidates vertically"
  '((emacs "26.1"))
  :commit "99f7cf94f362d18b2f2716b431b9fcc64345c05b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
