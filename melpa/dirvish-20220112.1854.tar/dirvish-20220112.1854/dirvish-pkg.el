(define-package "dirvish" "20220112.1854" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "2fac05abc4a47e3824fa5b9dd7ac1b93a5973cf8" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
