;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etherpad" "20261125.650"
  "Collaborative editing via Etherpad."
  '((emacs     "29.1")
    (websocket "1.12"))
  :url "https://codeberg.org/zzkt/ethermacs"
  :commit "cc0a77909b907355a90854e292912bba75eb954d"
  :revdesc "cc0a77909b90"
  :keywords '("comm" "etherpad" "collaborative editing")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
