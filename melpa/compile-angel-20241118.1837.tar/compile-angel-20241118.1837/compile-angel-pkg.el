;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20241118.1837"
  "Compile Emacs Lisp libraries automatically."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "972bb9fc9ca187004a9a00d52192c172e2f39934"
  :revdesc "972bb9fc9ca1"
  :keywords '("convenience"))
