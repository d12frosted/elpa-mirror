;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260826.244"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "39ab4576b182d80e5545764d4dbacdd16df87f30"
  :revdesc "39ab4576b182"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
