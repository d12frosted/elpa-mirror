;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260130.507"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "fd01d7761f718f4b8c96245ee0abcd0c3e235bee"
  :revdesc "fd01d7761f71"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
