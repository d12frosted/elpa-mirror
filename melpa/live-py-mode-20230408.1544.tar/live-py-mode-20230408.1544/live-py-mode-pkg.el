(define-package "live-py-mode" "20230408.1544" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "f1a1db7852543ad8fa9aa23120c8cebed384398f" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
