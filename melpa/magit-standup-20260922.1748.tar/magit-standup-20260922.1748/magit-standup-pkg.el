;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-standup" "20260922.1748"
  "Collect recent git commits for standup notes."
  '((emacs     "28.1")
    (magit     "4.5.0")
    (transient "0.8.0"))
  :url "https://github.com/function-artisans/magit-standup"
  :commit "fba45b21733efbb1ae8ebe639505a2e0073f5270"
  :revdesc "fba45b21733e"
  :keywords '("tools" "vc")
  :authors '(("István Karaszi" . "ikaraszi@gmail.com"))
  :maintainers '(("István Karaszi" . "ikaraszi@gmail.com")))
