(define-package "pygn-mode" "20210827.1200" "Major-mode for chess PGN files, powered by Python"
  '((emacs "26.1")
    (tree-sitter "0.15.1")
    (tree-sitter-langs "0.10.1")
    (uci-mode "0.5.4")
    (nav-flash "1.0.0")
    (ivy "0.10.0"))
  :commit "c74be44a81407c67376bbe49d4c1704c313e3b39" :authors
  '(("Dodge Coates and Roland Walker"))
  :maintainer
  '("Dodge Coates and Roland Walker")
  :keywords
  '("data" "games" "chess")
  :url "https://github.com/dwcoates/pygn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
