;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fastdef" "20160713.1329"
  "Insert terminology from Google top search results."
  '((ivy "0.7.0")
    (w3m "0.0"))
  :url "https://github.com/redguardtoo/fastdef"
  :commit "0696f41dc150d35ce31fe8d2ea74f4173818bb55"
  :revdesc "0696f41dc150"
  :keywords '("terminology" "org-mode" "markdown")
  :authors '(("Chen Bin" . "cheninDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "cheninDOTshATgmailDOTcom")))
