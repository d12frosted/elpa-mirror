;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bolt-mode" "20180310.810"
  "Editing support for Bolt language."
  '((emacs "24.3"))
  :url "https://github.com/mpontus/bolt-mode"
  :commit "85a5a752bfbebb4aed884326c25db64c000e9934"
  :revdesc "85a5a752bfbe"
  :keywords '("languages")
  :authors '(("Mikhail Pontus" . "mpontus@gmail.com"))
  :maintainers '(("Mikhail Pontus" . "mpontus@gmail.com")))
