;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260216.1017"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.10.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6eb188d4fd2e9c92daa1e9e6c54fb6c28e011c96"
  :revdesc "6eb188d4fd2e")
