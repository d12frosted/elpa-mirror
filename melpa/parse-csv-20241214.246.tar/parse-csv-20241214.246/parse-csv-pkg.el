;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parse-csv" "20241214.246"
  "Parse strings with CSV fields into s-expressions."
  '((emacs "24.3"))
  :url "https://github.com/mrc/el-csv"
  :commit "b2e7010ba91ecce25498a73f64f950de4dd8dbe2"
  :revdesc "b2e7010ba91e"
  :keywords '("csv")
  :authors '(("Matt Curtis" . "matt.r.curtis@gmail.com"))
  :maintainers '(("Matt Curtis" . "matt.r.curtis@gmail.com")))
