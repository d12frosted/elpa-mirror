(define-package "blackjack" "20230611.1412" "The game of Blackjack"
  '((emacs "26.2")
    (dash "2.19.1"))
  :commit "85ba3094c7171e7cec02817f36c4f578f260765d" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
