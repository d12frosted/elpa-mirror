;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-projectile" "20250715.1037"
  "Helm integration for Projectile."
  '((helm       "3.0")
    (projectile "2.9")
    (cl-lib     "0.3"))
  :url "https://github.com/bbatsov/helm-projectile"
  :commit "52e552fe875a913f582ad968aba43dbd8520fe9d"
  :revdesc "52e552fe875a"
  :keywords '("project" "convenience"))
