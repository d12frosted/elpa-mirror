(define-package "eziam-theme" "20200118.2207" "A mostly monochrome theme, inspired by Tao and Leuven, with dark and light versions." 'nil :commit "e0c0daa37c3d70880052b3d55fcda05b92d575a6")
;; Local Variables:
;; no-byte-compile: t
;; End:
