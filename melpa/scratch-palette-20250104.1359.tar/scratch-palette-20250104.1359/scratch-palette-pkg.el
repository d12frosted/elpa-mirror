;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-palette" "20250104.1359"
  "Make scratch buffer for each files."
  ()
  :url "http://zk-phi.github.io/"
  :commit "e4389fbb97f2890c4caebba0588cbc5d5f1ecbc6"
  :revdesc "e4389fbb97f2")
