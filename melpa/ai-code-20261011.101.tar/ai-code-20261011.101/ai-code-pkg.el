;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261011.101"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "fd3decaf652dce018571d6e06808bb56830d4ecb"
  :revdesc "fd3decaf652d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
