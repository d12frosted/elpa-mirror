(define-package "dirvish" "20220313.623" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "36a064255e04e366fb40729879531eb0a15c3d7a" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
