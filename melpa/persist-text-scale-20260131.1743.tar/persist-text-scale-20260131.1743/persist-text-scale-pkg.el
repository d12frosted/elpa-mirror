;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20260131.1743"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "8098af6ba9ff251d19f9e41b39c84f7b9b758f26"
  :revdesc "8098af6ba9ff"
  :keywords '("convenience"))
