(define-package "hyde" "20120121.1531" "No description available." 'nil :commit "181f9d2f91c2678a22243c5485162fa7999fd893")
;; Local Variables:
;; no-byte-compile: t
;; End:
