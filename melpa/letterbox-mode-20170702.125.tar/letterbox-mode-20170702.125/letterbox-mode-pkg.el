;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "letterbox-mode" "20170702.125"
  "Hide sensitive text on a buffer."
  '((emacs "24.3"))
  :url "https://github.com/pacha64/letterbox-mode"
  :commit "88c67a51d67216d569a28e8423200883fde096dd"
  :revdesc "88c67a51d672"
  :keywords '("password" "convenience")
  :authors '(("Fernando Leboran" . "f.leboran@gmail.com"))
  :maintainers '(("Fernando Leboran" . "f.leboran@gmail.com")))
