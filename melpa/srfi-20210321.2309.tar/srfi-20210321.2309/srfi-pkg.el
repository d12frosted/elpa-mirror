(define-package "srfi" "20210321.2309" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "391587d01ddfb983af1bf473f1c411a12b8762bb" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
