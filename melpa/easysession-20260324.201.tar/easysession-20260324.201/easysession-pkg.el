;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260324.201"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "f4e9c836dfbbbd89f9f992ea9e8ba9c5e84e095b"
  :revdesc "f4e9c836dfbb"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
