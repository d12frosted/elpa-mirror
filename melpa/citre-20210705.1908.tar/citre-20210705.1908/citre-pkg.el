(define-package "citre" "20210705.1908" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "ce735e795b773fda039adf7c2eddc36191198590" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
