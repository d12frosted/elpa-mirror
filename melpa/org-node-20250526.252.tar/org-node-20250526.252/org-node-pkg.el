;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250526.252"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "a8697b2789b28169c2d1de1481bd4d3f6e04fd5b"
  :revdesc "a8697b2789b2"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
