;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260330.1402"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "392b5fab382d3f2c49123472bd3a1447345bd0f2"
  :revdesc "392b5fab382d"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
