(define-package "x509-mode" "20221031.1303" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "d28afe60398001753800ff721b6b098236b1b9bd" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
