(define-package "kanagawa-theme" "20240319.1142" "An elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa"
  '((emacs "24.3"))
  :commit "996693bda7105804c33d56b9993c56fc032ae641" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/meritamen/emacs-kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
