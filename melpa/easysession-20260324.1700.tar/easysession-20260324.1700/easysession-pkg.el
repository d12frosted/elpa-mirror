;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260324.1700"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "41a06800f1de5dcdb0109f4ddaf8460c9ed8ecc6"
  :revdesc "41a06800f1de"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
