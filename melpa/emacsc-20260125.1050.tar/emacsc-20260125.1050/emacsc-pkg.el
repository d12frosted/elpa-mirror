;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsc" "20260125.1050"
  "Helper for emacsc(1)."
  ()
  :url "https://github.com/knu/emacsc"
  :commit "e3c8636d64d787eec876792288e99511d604eeec"
  :revdesc "e3c8636d64d7"
  :keywords '("tools")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
