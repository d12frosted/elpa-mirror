;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20251210.2110"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "99de48f3f4729deb8584b5f911d5deeef3b583cd"
  :revdesc "99de48f3f472")
