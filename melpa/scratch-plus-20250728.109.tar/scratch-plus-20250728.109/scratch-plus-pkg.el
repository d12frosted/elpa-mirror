;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-plus" "20250728.109"
  "Better Scratch Buffer Behavior."
  '((emacs "29.1"))
  :url "https://git.sr.ht/~swflint/scratch-plus"
  :commit "b794901f968000f6e338808307385b683b79ec8b"
  :revdesc "b794901f9680"
  :keywords '("convenience")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
