(define-package "notmuch" "20231001.1112" "run notmuch within emacs" 'nil :commit "bd318e7eba99a6554b1527c65445824f880e5eb4" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
