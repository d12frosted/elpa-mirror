;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260619.1756"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "000589bbe5d962feb67ac1c9a82817796b805f82"
  :revdesc "000589bbe5d9"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
