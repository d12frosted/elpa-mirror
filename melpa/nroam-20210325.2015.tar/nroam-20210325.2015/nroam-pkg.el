(define-package "nroam" "20210325.2015" "Org-roam backlinks within org-mode buffers"
  '((emacs "26.1")
    (org-roam "1.2.3")
    (org "9.4.4"))
  :commit "9a76f16d3fdd49a1733e5f2777036f1f83068a40" :authors
  '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainer
  '("Nicolas Petton" . "nicolas@petton.fr")
  :keywords
  '("outlines" "convenience")
  :url "https://github.com/NicolasPetton/nroam")
;; Local Variables:
;; no-byte-compile: t
;; End:
