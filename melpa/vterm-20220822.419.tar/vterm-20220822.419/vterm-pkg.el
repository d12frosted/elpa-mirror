(define-package "vterm" "20220822.419" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "f65916b316aa17431221aa3885c0d67f2d1fc30d" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
