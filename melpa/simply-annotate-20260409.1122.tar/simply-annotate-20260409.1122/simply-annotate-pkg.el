;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260409.1122"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "dd3883222a4e214e82323bb091587aa48750ce71"
  :revdesc "dd3883222a4e"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
