(define-package "docstr" "20210417.1315" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "f6dcb378bb69c23d58978d5bc1e37c4ae160d278" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
