(define-package "docstr" "20210417.1315" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "5b80126a71662a4bcd3dff7cfbcf70954610092e" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
