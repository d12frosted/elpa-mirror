;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251023.1536"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "8249f6df52afe03aa1976bdc2bf0bda2298553b5"
  :revdesc "8249f6df52af"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
