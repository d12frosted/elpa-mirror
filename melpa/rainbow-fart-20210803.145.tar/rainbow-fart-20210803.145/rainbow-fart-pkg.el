(define-package "rainbow-fart" "20210803.145" "Checks the keywords of code to play suitable sounds"
  '((emacs "25.1")
    (flycheck "32snapshot"))
  :commit "f33a3bc639ad47ae48c261ba699d876a5f56057e" :keywords
  '("tools")
  :url "https://github.com/stardiviner/emacs-rainbow-fart")
;; Local Variables:
;; no-byte-compile: t
;; End:
