(define-package "yeetube" "20231013.923" "YouTube Front End"
  '((emacs "27.2"))
  :commit "e13361ce5bb7c2437938164e3710c0ce25fa49ab" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.com/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
