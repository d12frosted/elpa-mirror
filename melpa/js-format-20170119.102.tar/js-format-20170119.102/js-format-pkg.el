;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-format" "20170119.102"
  "Format or transform code style using NodeJS server with different javascript formatter."
  '((emacs    "24.1")
    (js2-mode "20101228"))
  :url "https://github.com/futurist/js-format.el"
  :commit "544bda9be72b74ec2d442543ba60cff727d96669"
  :revdesc "544bda9be72b"
  :keywords '("js" "javascript" "format" "standard" "jsbeautify" "esformatter" "airbnb")
  :authors '(("James Yang" . "jamesyang999@gmail.com"))
  :maintainers '(("James Yang" . "jamesyang999@gmail.com")))
