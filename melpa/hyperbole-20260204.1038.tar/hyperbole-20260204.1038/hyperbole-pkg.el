;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260204.1038"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "72bee1bf0cf549828261047c921ef8af27393110"
  :revdesc "72bee1bf0cf5"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
