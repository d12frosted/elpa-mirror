;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260210.1913"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "84a28d757e7208ceb1cfb75f09b7a1fab09d275d"
  :revdesc "84a28d757e72"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
