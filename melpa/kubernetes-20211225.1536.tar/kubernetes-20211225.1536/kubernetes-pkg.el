(define-package "kubernetes" "20211225.1536" "Magit-like porcelain for Kubernetes"
  '((emacs "25.1")
    (dash "2.12.0")
    (magit-section "3.1.1")
    (magit-popup "2.13.0")
    (with-editor "3.0.4")
    (transient "0.3.0"))
  :commit "4d69f6f4d9ec46a8aeb18d9d32776d9c6825d5b1" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool")
  :keywords
  '("kubernetes")
  :url "https://github.com/kubernetes-el/kubernetes-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
