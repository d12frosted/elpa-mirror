(define-package "demap" "20220316.2" "Detachable minimap package"
  '((emacs "24.4")
    (dash "2.18.0"))
  :commit "cd0aa62b0c2a8c56d15ec979a97f19f3a1f97471" :authors
  '(("Sawyer Gardner <https://gitlab.com/sawyerjgardner>"))
  :maintainer
  '("Sawyer Gardner <https://gitlab.com/sawyerjgardner>")
  :keywords
  '("lisp" "tools" "convenience")
  :url "https://gitlab.com/sawyerjgardner/demap.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
