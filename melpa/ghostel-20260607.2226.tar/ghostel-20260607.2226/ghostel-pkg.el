;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260607.2226"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "fa04bfebf152ba430af39bd1b71a15b5692daace"
  :revdesc "fa04bfebf152"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
