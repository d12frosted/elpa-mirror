(define-package "parinfer-rust-mode" "20240523.811" "An interface for the parinfer-rust library"
  '((emacs "26.1")
    (track-changes "1.1"))
  :commit "1a6235dbe3deeb8840b02e83c6e7996281ea284b" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
