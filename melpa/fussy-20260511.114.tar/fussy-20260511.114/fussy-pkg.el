;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260511.114"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "de7dd27b7a4a17a61f63e4c160c24a7fa2c34be7"
  :revdesc "de7dd27b7a4a"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
