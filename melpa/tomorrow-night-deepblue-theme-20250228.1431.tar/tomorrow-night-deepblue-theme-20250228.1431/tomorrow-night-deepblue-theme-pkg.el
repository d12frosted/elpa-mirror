;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tomorrow-night-deepblue-theme" "20250228.1431"
  "The Tomorrow Night Deepblue color theme."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/tomorrow-night-deepblue-theme.el"
  :commit "52616536fab81b1016ece465897d74d313e502a6"
  :revdesc "52616536fab8"
  :keywords '("faces" "themes"))
