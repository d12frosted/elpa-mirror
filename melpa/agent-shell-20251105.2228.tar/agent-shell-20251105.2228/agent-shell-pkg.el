;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251105.2228"
  "A single native shell experience to interact with agentic providers (Claude Code, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e87487222c9c5216c5d53b47c83a91da2f233ea9"
  :revdesc "e87487222c9c")
