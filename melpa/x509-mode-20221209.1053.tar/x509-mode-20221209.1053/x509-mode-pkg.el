(define-package "x509-mode" "20221209.1053" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "916c2a542dc25ce70896e2cd665b0e837a9f10d0" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
