(define-package "buffer-name-relative" "20230612.426" "Relative buffer names"
  '((emacs "28.1"))
  :commit "6c0657999d152cb6351b81166b745d2ac4bae059" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-buffer-name-relative")
;; Local Variables:
;; no-byte-compile: t
;; End:
