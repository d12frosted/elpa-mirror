(define-package "cape" "20221121.2106" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "8962e15381682544b268afd032661101692a3cd2" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
