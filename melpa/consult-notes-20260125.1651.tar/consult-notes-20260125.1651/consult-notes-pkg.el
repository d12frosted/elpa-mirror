;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-notes" "20260125.1651"
  "Manage notes with consult."
  '((emacs   "28.1")
    (consult "1.0")
    (s       "1.12.0")
    (dash    "2.19"))
  :url "https://github.com/mclear-tools/consult-notes"
  :commit "37e772594ad64ebe573cb5974f48e5d08b0e043c"
  :revdesc "37e772594ad6"
  :keywords '("convenience")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
