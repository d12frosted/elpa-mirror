;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250623.924"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "7ba05b1442bac7df16c885dea72a34ea84fcf8aa"
  :revdesc "7ba05b1442ba"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
