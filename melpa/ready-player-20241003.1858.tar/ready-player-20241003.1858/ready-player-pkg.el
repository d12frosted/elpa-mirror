;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "20241003.1858"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "b9ed57efb5ef5628ed53d7501b4e31b1054c7d17"
  :revdesc "b9ed57efb5ef")
