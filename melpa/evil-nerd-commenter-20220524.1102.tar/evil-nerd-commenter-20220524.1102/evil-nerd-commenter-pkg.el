(define-package "evil-nerd-commenter" "20220524.1102" "Comment/uncomment lines efficiently. Like Nerd Commenter in Vim"
  '((emacs "25.1"))
  :commit "81b7187c9b4fdd2a84fbd879312eef914e2d192d" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("convenience" "evil")
  :url "http://github.com/redguardtoo/evil-nerd-commenter")
;; Local Variables:
;; no-byte-compile: t
;; End:
