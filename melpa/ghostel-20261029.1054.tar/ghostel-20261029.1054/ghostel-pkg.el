;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261029.1054"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "43c58bc63b86e1de867dfacaba53ab0f51fb0691"
  :revdesc "43c58bc63b86"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
