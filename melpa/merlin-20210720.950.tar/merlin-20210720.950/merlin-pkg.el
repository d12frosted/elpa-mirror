(define-package "merlin" "20210720.950" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "38d19854a012e263c92dcba60427b674e1f319e9" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
