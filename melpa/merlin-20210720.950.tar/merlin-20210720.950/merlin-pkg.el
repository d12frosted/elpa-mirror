(define-package "merlin" "20210720.950" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "cdc6969e045e8308b2f72a4130fc924a525f9f1f" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
