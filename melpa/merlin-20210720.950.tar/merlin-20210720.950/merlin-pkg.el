(define-package "merlin" "20210720.950" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "e3269094be60aa05cddadf8fb663e9419fa662d9" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
