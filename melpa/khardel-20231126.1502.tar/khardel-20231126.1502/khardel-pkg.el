;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "khardel" "20231126.1502"
  "Integrate with khard."
  '((emacs     "27.1")
    (yaml-mode "0.0.13"))
  :url "https://github.com/DamienCassou/khardel"
  :commit "205e374b36252183a146a7a8f857bcf95a77edc3"
  :revdesc "205e374b3625"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
