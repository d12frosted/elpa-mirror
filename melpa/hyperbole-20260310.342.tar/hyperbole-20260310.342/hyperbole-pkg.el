;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260310.342"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "37355feeceeebbb2d4e6260ece721ab5c46ae6b4"
  :revdesc "37355feeceee"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
