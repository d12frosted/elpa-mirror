;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20261021.1627"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "d0e41a4d62afb72c5290952c09efdd03a13f2c1b"
  :revdesc "d0e41a4d62af"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
