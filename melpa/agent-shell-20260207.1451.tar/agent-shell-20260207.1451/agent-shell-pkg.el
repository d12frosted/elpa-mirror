;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260207.1451"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "823ddf92f22e59ff9ddbed6600ce426d361f6ebb"
  :revdesc "823ddf92f22e")
