;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-eldev" "20240419.2023"
  "Eldev support in Flymake."
  '((dash  "2.17")
    (emacs "28.1"))
  :url "https://github.com/emacs-eldev/flymake-eldev"
  :commit "d8f4d9da115002afd3785b777cd59a49d170e04a"
  :revdesc "d8f4d9da1150"
  :keywords '("tools" "convenience")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
