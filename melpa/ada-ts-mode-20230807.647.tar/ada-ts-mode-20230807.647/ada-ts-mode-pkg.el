(define-package "ada-ts-mode" "20230807.647" "Major mode for Ada using Tree-sitter"
  '((emacs "29.1"))
  :commit "eb0cd38f6f2f8a44592fe965ed8b961d1d8791f2" :authors
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainer
  '("Troy Brown" . "brownts@troybrown.dev")
  :keywords
  '("ada" "languages" "tree-sitter")
  :url "https://github.com/brownts/ada-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
