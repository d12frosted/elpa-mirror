;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-tools" "20261105.1259"
  "Indent, navigate (and more) by blocks of indentation: yaml, python etc."
  '((s         "0")
    (hydra     "0")
    (yafolding "0"))
  :url "https://gitlab.com/emacs-stuff/indent-tools/"
  :commit "ebec5797277b02f504ece5f79270835e110592b0"
  :revdesc "ebec5797277b"
  :keywords '("indentation" "movements" "navigation" "kill" "fold" "yaml" "python")
  :authors '(("vindarel" . "vindarel@mailz.org"))
  :maintainers '(("vindarel" . "vindarel@mailz.org")))
