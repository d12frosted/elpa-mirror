;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260210.1554"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "cf1313150943d9b2b3e42cb7d17970b165fc2e92"
  :revdesc "cf1313150943"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
