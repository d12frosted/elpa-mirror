(define-package "ellama" "20240529.701" "Tool for interacting with LLMs"
  '((emacs "28.1")
    (llm "0.6.0")
    (spinner "1.7.4"))
  :commit "1e1db6d5f1ced38ad1c76ffca1651787d54998de" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
