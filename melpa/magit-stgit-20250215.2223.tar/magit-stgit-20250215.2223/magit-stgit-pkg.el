;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-stgit" "20250215.2223"
  "StGit extension for Magit."
  '((emacs     "27.1")
    (llama     "0.6.0")
    (magit     "4.3.0")
    (transient "0.8.4"))
  :url "https://github.com/stacked-git/magit-stgit"
  :commit "b19d96f8f62bd4def83eb1c09e9cd2582856351e"
  :revdesc "b19d96f8f62b"
  :keywords '("git" "tools" "vc")
  :authors '(("Lluís Vilanova" . "vilanova@ac.upc.edu"))
  :maintainers '(("Peter Grayson" . "pete@jpgrayson.net")))
