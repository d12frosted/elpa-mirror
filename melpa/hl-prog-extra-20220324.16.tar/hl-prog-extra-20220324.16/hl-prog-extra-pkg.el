(define-package "hl-prog-extra" "20220324.16" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "3312497ddfc7b7bc0e773ae98fc02477a4b0c7a0" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
