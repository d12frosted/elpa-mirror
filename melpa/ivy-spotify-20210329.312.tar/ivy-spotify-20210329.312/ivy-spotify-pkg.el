;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-spotify" "20210329.312"
  "Search spotify with ivy."
  '((emacs    "26.1")
    (espotify "0.1")
    (ivy      "0.13.1"))
  :url "https://codeberg.org/jao/espotify"
  :commit "eefcb49d740570f6c874302d87be33e5b0ec54ff"
  :revdesc "eefcb49d7405"
  :keywords '("multimedia")
  :authors '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
