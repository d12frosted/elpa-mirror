;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rally-mode" "20161114.354"
  "A mode to interact with the Rally Software web site."
  '((popwin "1.0.0"))
  :url "https://pragcraft.wordpress.com/"
  :commit "0f5e09a6abe2de7613f174b4f54863df93343134"
  :revdesc "0f5e09a6abe2"
  :keywords '("rally" "ca" "agile")
  :authors '(("Sean LeBlanc" . "seanleblanc@gmail.com"))
  :maintainers '(("Sean LeBlanc" . "seanleblanc@gmail.com")))
