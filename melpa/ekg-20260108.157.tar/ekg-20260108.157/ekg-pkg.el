;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260108.157"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "3799114b6faed6550a58fb2bb32768b345546a62"
  :revdesc "3799114b6fae"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
