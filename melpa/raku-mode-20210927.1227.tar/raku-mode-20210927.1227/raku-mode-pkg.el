(define-package "raku-mode" "20210927.1227" "Major mode for editing Raku code"
  '((emacs "24.4"))
  :commit "977b14a7c1295ebf2aad2f807d3f8e7c27aeb47f" :authors
  '(("Hinrik Örn Sigurðsson" . "hinrik.sig@gmail.com"))
  :maintainer
  '("Hinrik Örn Sigurðsson" . "hinrik.sig@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/hinrik/perl6-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
