(define-package "meson-mode" "20210321.1136" "Major mode for the Meson build system files"
  '((emacs "26.1"))
  :commit "88717d5256d4cf47a85756dc5e204ea23eec165d" :authors
  '(("Michal Sojka" . "sojkam1@fel.cvut.cz"))
  :maintainer
  '("Michal Sojka" . "sojkam1@fel.cvut.cz")
  :keywords
  '("languages" "tools")
  :url "https://github.com/wentasah/meson-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
