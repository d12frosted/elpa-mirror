(define-package "srfi" "20220321.2152" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "5efe17755c04dedb62033c1c53eda3c28c3a5f65" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
