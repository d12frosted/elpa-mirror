(define-package "org-bookmarks" "20240602.929" "Manage bookmarks in Org mode"
  '((emacs "26.1"))
  :commit "e673af4511f33b0e673e584be9db7bfa5a7e5620" :keywords
  '("outline" "matching" "hypermedia" "org")
  :url "https://repo.or.cz/org-bookmarks.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
