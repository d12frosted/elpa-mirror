(define-package "dired-duplicates" "20231105.39" "Find duplicate files locally and remotely"
  '((emacs "27.1"))
  :commit "f821380a4fea30021f2b977f502dac864d4776bb" :authors
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainers
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainer
  '("Harald Judt" . "h.judt@gmx.at")
  :keywords
  '("files")
  :url "https://codeberg.org/hjudt/dired-duplicates")
;; Local Variables:
;; no-byte-compile: t
;; End:
