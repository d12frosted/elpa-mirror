(define-package "fountain-mode" "20231026.619" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "e723f39cd77c2c184b57071dcc4399ac2c1dc760" :authors
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainers
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainer
  '("Paul W. Rankin" . "hello@paulwrankin.com")
  :keywords
  '("wp" "text")
  :url "https://www.fountain-mode.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
