(define-package "elisp-demos" "20201116.1433" "Elisp API Demos"
  '((emacs "24.4"))
  :commit "3a8531e8435020276bb97ecd43c6350c2548d6c5" :keywords
  ("lisp" "docs")
  :authors
  (("Xu Chunyang"))
  :maintainer
  ("Xu Chunyang")
  :url "https://github.com/xuchunyang/elisp-demos")
;; Local Variables:
;; no-byte-compile: t
;; End:
