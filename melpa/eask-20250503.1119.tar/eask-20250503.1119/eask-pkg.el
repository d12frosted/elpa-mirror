;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20250503.1119"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "9c73393dad3df9b327aa64a6d171ebdd2c46bb45"
  :revdesc "9c73393dad3d"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
