(define-package "modus-themes" "20201205.1641" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "4b6d42d51ec2d8e08eece7ab40f435d8f2a954bd" :keywords
  ("faces" "theme" "accessibility")
  :authors
  (("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  ("Protesilaos Stavrou" . "info@protesilaos.com")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
