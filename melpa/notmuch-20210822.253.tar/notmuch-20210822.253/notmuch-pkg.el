(define-package "notmuch" "20210822.253" "run notmuch within emacs" 'nil :commit "357dd488caf0262f8a36ea4fd23b9d017cc93440" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
