;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251214.1041"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "b9d584fa6cf27adb247c446ef6e4944c5c2ed1b6"
  :revdesc "b9d584fa6cf2"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
