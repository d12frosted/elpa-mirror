;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "20261111.358"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "9b9cae807aad2984e4fa3ba05501d91319652e23"
  :revdesc "9b9cae807aad"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
