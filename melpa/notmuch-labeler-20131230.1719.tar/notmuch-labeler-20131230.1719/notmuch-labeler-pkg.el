(define-package "notmuch-labeler" "20131230.1719" "Improve notmuch way of displaying labels"
  '((notmuch "0"))
  :commit "d65d1129555d368243df4770ecc1e7ccb88efc58" :keywords
  ("emacs" "package" "elisp" "notmuch" "emails")
  :authors
  (("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainer
  ("Damien Cassou" . "damien.cassou@gmail.com")
  :url "https://github.com/DamienCassou/notmuch-labeler")
;; Local Variables:
;; no-byte-compile: t
;; End:
