;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241120.649"
  "A multi-llm comint Emacs shell (plus other goodies)."
  '((emacs       "28.1")
    (shell-maker "0.68.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "9c8215e2325d95909c9f4fee0df0d8df997fcd58"
  :revdesc "9c8215e2325d")
