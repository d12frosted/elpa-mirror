;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260426.1325"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.1.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "cdb3a3069eb7c1e5373fd7171743ad329d49ba5f"
  :revdesc "cdb3a3069eb7"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
