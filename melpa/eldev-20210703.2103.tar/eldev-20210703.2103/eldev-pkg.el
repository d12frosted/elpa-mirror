(define-package "eldev" "20210703.2103" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "68506f68a6ecb277401081289538c809a554a72c" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
