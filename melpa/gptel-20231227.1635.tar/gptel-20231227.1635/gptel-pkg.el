(define-package "gptel" "20231227.1635" "Interact with ChatGPT or other LLMs"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "0690c8b6a9d9844a1be5729592e05f3d04e48ec5" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
