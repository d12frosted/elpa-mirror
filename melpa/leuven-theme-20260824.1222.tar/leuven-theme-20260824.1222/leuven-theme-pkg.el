;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "20260824.1222"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "c6cce6185125fa5e2172c29d59aa76e8325537ea"
  :revdesc "c6cce6185125"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
