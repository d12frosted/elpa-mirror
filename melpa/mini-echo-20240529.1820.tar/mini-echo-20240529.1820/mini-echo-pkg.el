(define-package "mini-echo" "20240529.1820" "Echo buffer status in minibuffer window"
  '((emacs "29.1")
    (dash "2.19.1")
    (hide-mode-line "1.0.3"))
  :commit "a5f6f300bcd4a2cd63e4fcd860775adafdcdd2aa" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
