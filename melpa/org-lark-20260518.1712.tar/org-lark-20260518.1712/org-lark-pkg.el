;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "20260518.1712"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "bad9f9fa5375942d8076cca747b7c65de106bc93"
  :revdesc "bad9f9fa5375"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
