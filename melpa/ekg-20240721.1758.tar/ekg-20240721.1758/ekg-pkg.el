(define-package "ekg" "20240721.1758" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.17.0"))
  :commit "8bf0145ed35d41b810600685461d7587b9f5fe16" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
