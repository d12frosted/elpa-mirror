;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fanyi" "20261103.1435"
  "Not only English-Chinese translator."
  '((emacs "29.1"))
  :url "https://github.com/condy0919/fanyi.el"
  :commit "a4906f525a83b0787bff5d7f3c3b32bb94fa289f"
  :revdesc "a4906f525a83"
  :keywords '("convenience" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
