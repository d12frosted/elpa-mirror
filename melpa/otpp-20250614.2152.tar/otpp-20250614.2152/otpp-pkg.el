;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20250614.2152"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "2ce15a456e51ee5efe4ecfb757599ccf1d0cd96e"
  :revdesc "2ce15a456e51"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
