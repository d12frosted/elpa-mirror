;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-mc" "20190206.749"
  "Add multiple cursors quickly using ace jump."
  '((ace-jump-mode    "1.0")
    (multiple-cursors "1.0")
    (dash             "2.10.0"))
  :url "https://github.com/mm--/ace-mc"
  :commit "6877880efd99e177e4e9116a364576def3da391b"
  :revdesc "6877880efd99"
  :keywords '("motion" "location" "cursor")
  :authors '(("Josh Moller-Mara" . "jmm@cns.nyu.edu"))
  :maintainers '(("Josh Moller-Mara" . "jmm@cns.nyu.edu")))
