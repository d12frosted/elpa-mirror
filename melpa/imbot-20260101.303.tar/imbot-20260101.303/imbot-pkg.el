;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260101.303"
  "[No description available]."
  ()
  :url "https://github.com/QiangF/imbot"
  :commit "e4c3964c62d08c992dba026dce27882fc3a680ba"
  :revdesc "e4c3964c62d0")
