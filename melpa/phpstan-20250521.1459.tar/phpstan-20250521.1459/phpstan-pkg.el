;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpstan" "20250521.1459"
  "Interface to PHPStan."
  '((emacs       "25.1")
    (compat      "30")
    (php-mode    "1.22.3")
    (php-runtime "0.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "af600b9aff5f89aab5a0f5744c5734392414e013"
  :revdesc "af600b9aff5f"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
