(define-package "evil-textobj-tree-sitter" "20231013.1706" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1"))
  :commit "db6ab405980dc350b7db411cc25e4bba1be0c092" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
