(define-package "org-projectile" "20230813.153" "Repository todo management for org-mode"
  '((projectile "0.11.0")
    (dash "2.10.0")
    (emacs "24")
    (s "1.9.0")
    (org-category-capture "0.0.0"))
  :commit "5b484e95004f799f8f605a77550f18b00791e000" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "projectile" "todo" "tools" "outlines")
  :url "https://github.com/IvanMalison/org-projectile")
;; Local Variables:
;; no-byte-compile: t
;; End:
