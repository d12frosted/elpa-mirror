;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260122.332"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5074e53ddbe168f4021edc203ebd725c5630175b"
  :revdesc "5074e53ddbe1"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
