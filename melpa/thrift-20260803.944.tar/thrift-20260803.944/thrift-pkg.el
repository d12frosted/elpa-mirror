;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260803.944"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "941512b20c7b8460f73e75abdb20eef3bb6fb9b7"
  :revdesc "941512b20c7b"
  :keywords '("languages"))
