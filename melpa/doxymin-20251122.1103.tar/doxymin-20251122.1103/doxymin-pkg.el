;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doxymin" "20251122.1103"
  "Create doxygen style docs the easy way."
  '((emacs "28.1"))
  :url "https://gitlab.com/L0ren2/doxymin"
  :commit "1de66de7bf4b0c3f6d09eaf461337840bd28715e"
  :revdesc "1de66de7bf4b"
  :keywords '("(abbref" "convenience" "docs)")
  :authors '(("Lorenz Schwab" . "lorenz_schwabatwebdotde"))
  :maintainers '(("Lorenz Schwab" . "lorenz_schwabatwebdotde")))
