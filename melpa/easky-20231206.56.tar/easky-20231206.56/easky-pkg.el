(define-package "easky" "20231206.56" "Control the Eask command-line interface"
  '((emacs "27.1")
    (eask-mode "0.1.0")
    (eask "0.1.0")
    (ansi "0.4.1")
    (lv "0.0")
    (marquee-header "0.1.0"))
  :commit "4e40c120714f31d314cbd610081a48090fdae7e3" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("maint" "easky")
  :url "https://github.com/emacs-eask/easky")
;; Local Variables:
;; no-byte-compile: t
;; End:
