(define-package "paperless" "20180224.1245" "A major mode for sorting and filing PDF documents."
  '((emacs "24.4")
    (f "0.11.0")
    (s "1.10.0")
    (cl-lib "0.6.1"))
  :commit "b3b6c05da393f6b1292a3d5937bc4499baabd0b6" :keywords
  ("pdf" "convenience")
  :authors
  (("Anthony Green" . "green@moxielogic.com"))
  :maintainer
  ("Anthony Green" . "green@moxielogic.com")
  :url "http://github.com/atgreen/paperless")
;; Local Variables:
;; no-byte-compile: t
;; End:
