(define-package "jazz-theme" "20230809.1107" "A warm color theme for Emacs 24+." 'nil :commit "b9f20c16378b7acfa89cfd69b4ddb54ea5986547" :authors
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainers
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainer
  '("Roman Parykin" . "donderom@ymail.com")
  :url "https://github.com/donderom/jazz-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
