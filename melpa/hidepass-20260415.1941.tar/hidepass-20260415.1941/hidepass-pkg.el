;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hidepass" "20260415.1941"
  "Hide passwords at one or multiple lines."
  '((emacs "27.2"))
  :url "https://codeberg.org/Anoncheg/emacs-hidepass"
  :commit "0cdc0d7910501d91d5d75ae53a42726d3fca0302"
  :revdesc "0cdc0d791050"
  :keywords '("hide" "hidden" "password" "faces")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
