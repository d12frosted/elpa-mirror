(define-package "ox-qmd" "20230325.1315" "Qiita Markdown Back-End for Org Export Engine"
  '((emacs "27.2")
    (request "0.3.3")
    (mimetypes "1.0"))
  :commit "0b5fa1e20aaa48d93600e1b8d09c3b6f55af3373" :authors
  '(("0x60DF" . "0x60DF@gmail.com"))
  :maintainer
  '("0x60DF" . "0x60DF@gmail.com")
  :keywords
  '("wp")
  :url "https://github.com/0x60df/ox-qmd")
;; Local Variables:
;; no-byte-compile: t
;; End:
