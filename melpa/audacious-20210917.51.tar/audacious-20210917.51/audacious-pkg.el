;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "audacious" "20210917.51"
  "Emacs interface to control audacious."
  '((helm  "3.6.2")
    (emacs "24.4"))
  :url "https://github.com/shishimaru/audacious.el"
  :commit "65c37f12a5c774a0ae434beee27ff7737006dd2f"
  :revdesc "65c37f12a5c7"
  :authors '(("Hitoshi Uchida" . "hitoshi.uchida@gmail.com"))
  :maintainers '(("Hitoshi Uchida" . "hitoshi.uchida@gmail.com")))
