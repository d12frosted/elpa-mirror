(define-package "ct" "20220610.642" "Color Tools - a color api"
  '((emacs "26.1")
    (dash "2.18.0")
    (hsluv "1.0.0"))
  :commit "668e3fbdc959cd4ffed3c77b5a129e5496a28009" :authors
  '(("neeasade"))
  :maintainer
  '("neeasade")
  :keywords
  '("convenience" "color" "theming" "rgb" "hsv" "hsl" "cie-lab" "background")
  :url "https://github.com/neeasade/ct.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
