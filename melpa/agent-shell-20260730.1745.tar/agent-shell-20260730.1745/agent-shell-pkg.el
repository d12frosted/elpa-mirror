;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260730.1745"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "86190a1c8da80da072c713d6ad05494496603d57"
  :revdesc "86190a1c8da8")
