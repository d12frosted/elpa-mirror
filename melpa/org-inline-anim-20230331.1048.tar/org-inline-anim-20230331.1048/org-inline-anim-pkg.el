(define-package "org-inline-anim" "20230331.1048" "Inline playback of animated GIF/PNG for Org"
  '((emacs "25.3")
    (org "9.4"))
  :commit "9316fe78319fa18c7282993bd547cd33fda1b8ee" :authors
  '(("Shigeaki Nishina"))
  :maintainers
  '(("Shigeaki Nishina"))
  :maintainer
  '("Shigeaki Nishina")
  :keywords
  '("org" "outlines" "hypermedia" "multimedia")
  :url "https://github.com/shg/org-inline-anim.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
