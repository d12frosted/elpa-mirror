;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "20260905.1359"
  "Automatic capitalization with batteries included."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/abdulnafe-t/auto-capitalize.el"
  :commit "c04e98f8c8d08f032e43e5aa76feb9ca95afe22a"
  :revdesc "c04e98f8c8d0"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
