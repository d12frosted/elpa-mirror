;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mini-echo" "20241002.1628"
  "Echo buffer status in minibuffer window."
  '((emacs          "29.1")
    (dash           "2.19.1")
    (hide-mode-line "1.0.3"))
  :url "https://github.com/liuyinz/mini-echo.el"
  :commit "19522c828ba60c8200feda54aadc1c5b660e1b2c"
  :revdesc "19522c828ba6"
  :keywords '("frames")
  :authors '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers '(("liuyinz" . "liuyinz95@gmail.com")))
