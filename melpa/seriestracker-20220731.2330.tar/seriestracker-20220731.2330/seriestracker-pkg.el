(define-package "seriestracker" "20220731.2330" "Series tracker"
  '((dash "2.12.1")
    (transient "0.3.2")
    (emacs "27.1"))
  :commit "1b4fe12d2fff15e3646a2d7cbe528ad1f95c4f19" :authors
  '(("Maxime Wack <contact at maximewack dot com>"))
  :maintainers
  '(("Maxime Wack <contact at maximewack dot com>"))
  :maintainer
  '("Maxime Wack <contact at maximewack dot com>")
  :keywords
  '("multimedia")
  :url "https://www.github.com/MaximeWack/seriesTracker")
;; Local Variables:
;; no-byte-compile: t
;; End:
