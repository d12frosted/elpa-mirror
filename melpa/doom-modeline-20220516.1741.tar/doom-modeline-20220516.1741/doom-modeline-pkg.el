(define-package "doom-modeline" "20220516.1741" "A minimal and modern mode-line"
  '((emacs "25.1")
    (shrink-path "0.2.0")
    (dash "2.11.0"))
  :commit "f39129e52f3739a3bcf5d03ba90216a6ef6736a8" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
