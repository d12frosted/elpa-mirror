(define-package "dashboard" "20230509.834" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "ce0c33cc5af0188a3ea2215c67cd3fb0ae193fea" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers
  '(("Jesús Martínez" . "jesusmartinez93@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
