;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-todo" "20250223.1609"
  "Highlight TODO and similar keywords."
  '((emacs  "26.1")
    (compat "30.0.2.0"))
  :url "https://github.com/tarsius/hl-todo"
  :commit "adb59d58a01afa9c5a63c4afe6ec19481b3e20a6"
  :revdesc "adb59d58a01a"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev")))
