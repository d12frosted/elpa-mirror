;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phoenix-dark-mono-theme" "20170729.1406"
  "Monochromatic version of the Phoenix theme."
  ()
  :url "https://github.com/j0ni/phoenix-dark-mono"
  :commit "a54f515d162148bcb38676980bc2316adb3d7b8b"
  :revdesc "a54f515d1621"
  :authors '(("J Irving" . "j@lollyshouse.ca"))
  :maintainers '(("J Irving" . "j@lollyshouse.ca")))
