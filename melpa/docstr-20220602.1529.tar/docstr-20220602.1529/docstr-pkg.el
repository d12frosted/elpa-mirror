(define-package "docstr" "20220602.1529" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "5ae804724ccfe9ca935832180d535014e58b4d12" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/emacs-vs/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
