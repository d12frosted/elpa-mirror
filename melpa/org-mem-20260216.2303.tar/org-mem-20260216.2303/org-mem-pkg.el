;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260216.2303"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "63549c0de3bf861a7caa6e6597eaa6131e66387c"
  :revdesc "63549c0de3bf"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
