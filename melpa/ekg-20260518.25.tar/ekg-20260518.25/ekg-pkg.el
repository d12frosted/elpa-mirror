;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260518.25"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "fe4aa7e9574a73515824736e8ebfba81ee864a1d"
  :revdesc "fe4aa7e9574a"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
