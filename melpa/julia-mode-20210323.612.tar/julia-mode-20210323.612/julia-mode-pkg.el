(define-package "julia-mode" "20210323.612" "Major mode for editing Julia source code"
  '((emacs "24.3"))
  :commit "5cccdbd064395191cbc18107653f498bc4bab616" :keywords
  '("languages")
  :url "https://github.com/JuliaEditorSupport/julia-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
