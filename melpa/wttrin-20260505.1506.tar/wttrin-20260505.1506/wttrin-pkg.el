;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260505.1506"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "541586e3ff0606afcf0581210a62c95f5ee65c71"
  :revdesc "541586e3ff06"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
