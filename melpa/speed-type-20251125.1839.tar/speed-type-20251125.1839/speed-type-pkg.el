;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251125.1839"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "8f867d255b0dd13a51927bb9fa3ace313aa20c82"
  :revdesc "8f867d255b0d"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
