(define-package "sqlformat" "20230807.556" "Reformat SQL using sqlformat or pgformatter"
  '((emacs "24.3")
    (reformatter "0.3"))
  :commit "843c375783de963702bc993f06df8b7abf9fbaf4" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("languages")
  :url "https://github.com/purcell/sqlformat")
;; Local Variables:
;; no-byte-compile: t
;; End:
