;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250919.2306"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "6ce5880aa3b0eaa766aa15314a25513add3cee2d"
  :revdesc "6ce5880aa3b0"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
