;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-git-toolbelt" "20260125.2056"
  "A Magit interface for git-toolbelt."
  '((emacs     "26.1")
    (magit     "3.0.0")
    (transient "0.3.0"))
  :url "https://github.com/jonathanchu/magit-git-toolbelt"
  :commit "daad07c98c5f3893344b840c5ef7459417f60767"
  :revdesc "daad07c98c5f"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
