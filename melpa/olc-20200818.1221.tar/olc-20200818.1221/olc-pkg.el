(define-package "olc" "20200818.1221" "Open location code library"
  '((emacs "25.1"))
  :commit "d2dc62dbc3cf6460cc12bd96857a988bc80ac37e" :authors
  '(("David Byers" . "david.byers@liu.se"))
  :maintainer
  '("David Byers" . "david.byers@liu.se")
  :keywords
  '("extensions" "lisp")
  :url "https://gitlab.liu.se/davby02/olc")
;; Local Variables:
;; no-byte-compile: t
;; End:
