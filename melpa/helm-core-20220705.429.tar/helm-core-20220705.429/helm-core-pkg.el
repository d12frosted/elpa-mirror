(define-package "helm-core" "20220705.429" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "004c9c12edb40b67856e5f6e59141f8b0f06e53b" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
