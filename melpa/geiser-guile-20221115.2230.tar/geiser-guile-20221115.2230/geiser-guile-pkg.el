(define-package "geiser-guile" "20221115.2230" "Guile and Geiser talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (geiser "0.28"))
  :commit "961c9630f90733f517a9124750e72da55b569f10" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
