(define-package "consult" "20210702.1518" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9b9746e1126bac147c047a4240ba6c7e7d8db941" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
