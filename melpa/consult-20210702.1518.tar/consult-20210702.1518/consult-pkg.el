(define-package "consult" "20210702.1518" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9349a442e3f8ea597858ad77458bf27be24bb370" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
