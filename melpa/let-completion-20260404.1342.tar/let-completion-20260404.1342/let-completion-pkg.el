;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "let-completion" "20260404.1342"
  "Show let-binding values in Elisp completion."
  '((emacs "28.1"))
  :url "https://github.com/gggion/let-completion.el"
  :commit "001f10de44c66d998c2bd90f62192eca3ca0247a"
  :revdesc "001f10de44c6"
  :keywords '("lisp" "completion")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
