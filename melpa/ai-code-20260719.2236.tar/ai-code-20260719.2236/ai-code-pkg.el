;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260719.2236"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "0a7839ccc93f9769a27aa382da581518bcbf7390"
  :revdesc "0a7839ccc93f"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
