;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251206.1302"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "bf7f5d3fd1552449f9936eefc8067cfc2ea395e9"
  :revdesc "bf7f5d3fd155"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
