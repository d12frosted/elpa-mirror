(define-package "gruvbox-theme" "20220804.103" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "01bcb9ed82cf00be15900fbe9721f62a6d1fa673" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
