;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260601.1738"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "3eecec5d648d5761e41fbf3b1eba77b885a660fa"
  :revdesc "3eecec5d648d"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
