;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260711.748"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "9d6b20b81cce3a827fb01c98cd1359b3ae6a697e"
  :revdesc "9d6b20b81cce"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
