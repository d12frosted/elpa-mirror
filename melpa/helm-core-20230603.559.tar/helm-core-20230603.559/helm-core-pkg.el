(define-package "helm-core" "20230603.559" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "085adeb9e7fc8824918e65d9b602da7deb4f549a" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
