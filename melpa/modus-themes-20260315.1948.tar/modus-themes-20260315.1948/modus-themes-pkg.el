;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260315.1948"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "c865abc82d85bf5d084d87dc9d380f7a2a61d9dd"
  :revdesc "c865abc82d85"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
