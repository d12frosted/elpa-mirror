(define-package "mastodon" "20220830.2134" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0"))
  :commit "864ed2b18804859478053cd0d4a3b40d11d72c7f" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
