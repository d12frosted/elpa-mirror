;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsql" "20261001.1544"
  "High-level SQL database front-end."
  '((emacs "28.1"))
  :url "https://github.com/magit/emacsql"
  :commit "7a4c607912c8fdd1fca4def4915d68f43b12d4da"
  :revdesc "7a4c607912c8"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev")))
