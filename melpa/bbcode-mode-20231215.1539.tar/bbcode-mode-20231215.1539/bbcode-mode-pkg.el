;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbcode-mode" "20231215.1539"
  "Major mode for phpBB posts (BBCode markup)."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/lassik/emacs-bbcode-mode"
  :commit "109962f1070a5e6943c2e32c1eb84ce4debfb8f8"
  :revdesc "109962f1070a"
  :keywords '("bbcode" "languages")
  :authors '(("Eric James Michael Ritz" . "lobbyjones@gmail.com"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
