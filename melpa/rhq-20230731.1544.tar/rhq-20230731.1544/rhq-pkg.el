;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rhq" "20230731.1544"
  "Client for rhq."
  '((emacs "24.4"))
  :url "https://github.com/ROCKTAKEY/rhq"
  :commit "9f571787bf0781c78c277db82394fb9a692ec21e"
  :revdesc "9f571787bf07"
  :keywords '("tools" "extensions")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
