(define-package "boon" "20230618.1334" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "eda0e2fa70441678574eec15dd680b6fc450b76f")
;; Local Variables:
;; no-byte-compile: t
;; End:
