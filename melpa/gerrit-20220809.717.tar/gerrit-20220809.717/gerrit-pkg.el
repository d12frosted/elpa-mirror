(define-package "gerrit" "20220809.717" "Gerrit client"
  '((emacs "25.1")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "a6451dc02bf630be371965fd03722ba4b30e4ede" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
