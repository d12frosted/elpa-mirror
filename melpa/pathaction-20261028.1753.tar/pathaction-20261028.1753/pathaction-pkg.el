;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20261028.1753"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "0bee2e0184a5e6de9d00dc2845235a67fbacd379"
  :revdesc "0bee2e0184a5"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
