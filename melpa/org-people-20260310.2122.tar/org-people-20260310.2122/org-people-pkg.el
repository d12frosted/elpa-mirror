;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260310.2122"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "92bebdeddf0c58aa7d3224752f67d61c7e66b790"
  :revdesc "92bebdeddf0c"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
