;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261029.1325"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.18.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "75ff777b4e2ceb5adbb55c9699362a055dc9e6f1"
  :revdesc "75ff777b4e2c"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
