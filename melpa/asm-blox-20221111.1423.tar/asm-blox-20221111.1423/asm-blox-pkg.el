(define-package "asm-blox" "20221111.1423" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "85b8a0c5c52357b23585031d9b9b851d91bdb0a8" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
