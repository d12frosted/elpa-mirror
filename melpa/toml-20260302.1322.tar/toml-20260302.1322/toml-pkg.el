;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260302.1322"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "aea330f33f922c50e108aeca4e83159ca5da8556"
  :revdesc "aea330f33f92"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
