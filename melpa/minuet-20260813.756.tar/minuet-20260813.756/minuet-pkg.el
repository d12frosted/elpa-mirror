;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260813.756"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "9e7a7952dcf3e69f70e632530b13ccb245e449a1"
  :revdesc "9e7a7952dcf3"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
