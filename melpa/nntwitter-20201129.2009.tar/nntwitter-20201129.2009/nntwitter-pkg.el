(define-package "nntwitter" "20201129.2009" "Gnus Backend For Twitter"
  '((emacs "25.1")
    (dash "20190401")
    (anaphora "20180618")
    (request "20190819"))
  :commit "94916ad8c3e3bf697855c58257f92cd697c9521a" :keywords
  ("news")
  :url "https://github.com/dickmao/nntwitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
