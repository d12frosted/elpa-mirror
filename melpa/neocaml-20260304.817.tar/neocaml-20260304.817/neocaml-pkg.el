;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260304.817"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "45704034027daf28333b5c705c174902a1713e4c"
  :revdesc "45704034027d"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
