(define-package "editorconfig" "20230415.2312" "EditorConfig Emacs Plugin"
  '((emacs "26.1")
    (nadvice "0.3"))
  :commit "541ae8f957a28507f43715a385cfc5e22f9a29f9" :authors
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainer
  '("EditorConfig Team" . "editorconfig@googlegroups.com")
  :keywords
  '("convenience" "editorconfig")
  :url "https://github.com/editorconfig/editorconfig-emacs#readme")
;; Local Variables:
;; no-byte-compile: t
;; End:
