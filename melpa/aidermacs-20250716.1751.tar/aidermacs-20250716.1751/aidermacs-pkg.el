;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250716.1751"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "cfa273dbe8b0f13cd9f750ccf1ddb131fb2bfef5"
  :revdesc "cfa273dbe8b0"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
