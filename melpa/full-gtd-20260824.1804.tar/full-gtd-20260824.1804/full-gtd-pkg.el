;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "20260824.1804"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "27.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "39d9008e7732686e2bdc46943f6a5755a65b90b5"
  :revdesc "39d9008e7732"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
