;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261116.728"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "d2e225d307b4c7d0c1a64e4ba8ef03e72f441ba2"
  :revdesc "d2e225d307b4"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
