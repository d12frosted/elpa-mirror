(define-package "zotra" "20230809.516" "Library to use Zotero translators"
  '((emacs "27.1"))
  :commit "e47d65bb816a404fb9c65e6fbed906d899fc5f97" :authors
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainers
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainer
  '("Mohammad Pedramfar <https://github.com/mpedramfar>")
  :url "https://github.com/mpedramfar/zotra")
;; Local Variables:
;; no-byte-compile: t
;; End:
