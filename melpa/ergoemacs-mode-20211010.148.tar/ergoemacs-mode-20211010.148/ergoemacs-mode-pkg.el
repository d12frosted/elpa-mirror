(define-package "ergoemacs-mode" "20211010.148" "Emacs mode based on common modern interface and ergonomics."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "b67e0f944ad412eb56f793cabde634e3083c1794" :authors
  '(("Xah Lee" . "xah@xahlee.org")
    ("David Capello" . "davidcapello@gmail.com")
    ("Matthew L. Fidler" . "matthew.fidler@gmail.com")
    ("Kim F. Storm" . "storm@cua.dk"))
  :maintainer
  '("Matthew L. Fidler" . "matthew.fidler@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ergoemacs/ergoemacs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
