(define-package "thrift" "20230827.1926" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "5dd749a5c4a1443493c0a7edb4b45be88f0734d3" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
