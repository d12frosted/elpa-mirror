;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260318.237"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "4acdd8d45c806305e8ca0b07807c8d60f5f8e52b"
  :revdesc "4acdd8d45c80"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
