;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260518.1413"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "5d26546193be95d99987d3ca93b05b201c7d9a35"
  :revdesc "5d26546193be"
  :keywords '("convenience" "chinese" "input-method" "rime"))
