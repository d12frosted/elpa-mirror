(define-package "alectryon" "20210817.49" "Toggle between Coq and reStructuredText"
  '((flycheck "31")
    (emacs "25.1"))
  :commit "ef3a41a9dde03209cbed9a7f292c4a9a31596ef6" :authors
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://github.com/cpitclaudel/alectryon")
;; Local Variables:
;; no-byte-compile: t
;; End:
