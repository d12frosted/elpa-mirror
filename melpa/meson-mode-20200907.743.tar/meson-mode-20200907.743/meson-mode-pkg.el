(define-package "meson-mode" "20200907.743" "Major mode for the Meson build system files"
  '((emacs "26.1"))
  :commit "70c35d7a303a66cada554c89d02ebd97d45c2a06" :authors
  '(("Michal Sojka" . "sojkam1@fel.cvut.cz"))
  :maintainer
  '("Michal Sojka" . "sojkam1@fel.cvut.cz")
  :keywords
  '("languages" "tools")
  :url "https://github.com/wentasah/meson-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
