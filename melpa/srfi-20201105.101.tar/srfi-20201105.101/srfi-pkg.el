(define-package "srfi" "20201105.101" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "0d5dbfa6996237df8a4843f234013a5cfab390bc" :keywords
  ("languages" "util")
  :authors
  (("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  ("Lassi Kortela" . "lassi@lassi.io")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
