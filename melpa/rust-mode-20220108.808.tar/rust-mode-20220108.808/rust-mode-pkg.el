(define-package "rust-mode" "20220108.808" "A major-mode for editing Rust source code"
  '((emacs "25.1"))
  :commit "541786c9bb0887e2357b4d6210b25ca4ceea3ab3" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages")
  :url "https://github.com/rust-lang/rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
