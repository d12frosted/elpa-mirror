;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20260730.1339"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "195c80fd945031aaa8793e2a33f4b4fa2216862c"
  :revdesc "195c80fd9450"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
