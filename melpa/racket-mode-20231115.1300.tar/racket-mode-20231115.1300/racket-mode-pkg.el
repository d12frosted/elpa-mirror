(define-package "racket-mode" "20231115.1300" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "a745a92579ff65d2941a1226383a80a00b0c490c" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
