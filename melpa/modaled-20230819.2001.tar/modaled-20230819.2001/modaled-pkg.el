(define-package "modaled" "20230819.2001" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "9426c286bef2a9e0c43146af4b8fde3f6a3bc7a6" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
