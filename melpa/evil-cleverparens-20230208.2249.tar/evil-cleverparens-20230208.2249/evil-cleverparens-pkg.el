(define-package "evil-cleverparens" "20230208.2249" "Evil friendly minor-mode for editing lisp."
  '((evil "1.0")
    (paredit "1")
    (smartparens "1.6.1")
    (emacs "24.4")
    (dash "2.12.0"))
  :commit "46e3768d76d66fd67bf0299f058ecac13b8564fa" :authors
  '(("Olli Piepponen" . "opieppo@gmail.com"))
  :maintainer
  '("Olli Piepponen" . "opieppo@gmail.com")
  :keywords
  '("convenience" "emulations")
  :url "https://github.com/emacs-evil/evil-cleverparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
