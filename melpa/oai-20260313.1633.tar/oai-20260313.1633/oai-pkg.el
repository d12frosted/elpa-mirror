;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260313.1633"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "6aecd99588cf069fe024c7dd23d594c6fcdeabe6"
  :revdesc "6aecd99588cf"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
