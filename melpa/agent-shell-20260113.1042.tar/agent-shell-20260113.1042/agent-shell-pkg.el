;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260113.1042"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "52b934e794be802bb216e27154dc94398c0beed7"
  :revdesc "52b934e794be")
