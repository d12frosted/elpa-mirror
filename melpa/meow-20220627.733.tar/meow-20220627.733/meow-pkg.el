(define-package "meow" "20220627.733" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "74fbe3d7e07abf72cbb794d7048716216330e9e3" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
