;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260318.1600"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.2")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "520cad3b60017af0992a97ec4871b6a6af73a16a"
  :revdesc "520cad3b6001")
