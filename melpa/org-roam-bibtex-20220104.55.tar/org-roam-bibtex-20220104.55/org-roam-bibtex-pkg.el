(define-package "org-roam-bibtex" "20220104.55" "Org Roam meets BibTeX"
  '((emacs "27.2")
    (org-roam "2.0.0")
    (bibtex-completion "2.0.0")
    (org-ref "3.0"))
  :commit "af3b69bec9df9b7cfdf1c717cf7f4d69168cc75e" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
