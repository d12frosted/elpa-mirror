(define-package "el-patch" "20230219.214" "Future-proof your Elisp"
  '((emacs "26"))
  :commit "ad8b18578d224cf8ebb1cce9a3b1b5a3d93a0e69" :authors
  '(("Radian LLC" . "contact+el-patch@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+el-patch@radian.codes")
  :keywords
  '("extensions")
  :url "https://github.com/radian-software/el-patch")
;; Local Variables:
;; no-byte-compile: t
;; End:
