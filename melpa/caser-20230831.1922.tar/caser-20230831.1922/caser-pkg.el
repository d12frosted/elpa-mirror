(define-package "caser" "20230831.1922" "Change text casing from camelCase to dash-case to snake_case"
  '((emacs "29.1"))
  :commit "00167e37e5bacc06afdf35d246fe6d87829e8c4c" :url "https://hg.sr.ht/~zck/caser.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
