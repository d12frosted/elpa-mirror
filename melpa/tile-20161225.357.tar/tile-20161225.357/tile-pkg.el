;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tile" "20161225.357"
  "Tile windows with layouts."
  '((emacs  "25.1")
    (s      "1.9.0")
    (dash   "2.12.0")
    (stream "2.2.3"))
  :url "https://github.com/IvanMalison/tile"
  :commit "22660f21f6e95de5aba55cd5d293d4841e9a4661"
  :revdesc "22660f21f6e9"
  :keywords '("tile" "tiling" "window" "manager" "dynamic" "frames")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
