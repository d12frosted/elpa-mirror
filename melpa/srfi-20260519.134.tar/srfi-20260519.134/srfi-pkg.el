;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260519.134"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "7415d9bc1eead7cb34e66776268f60a3abcfa786"
  :revdesc "7415d9bc1eea"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
