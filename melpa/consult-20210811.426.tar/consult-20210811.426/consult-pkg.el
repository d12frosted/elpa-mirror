(define-package "consult" "20210811.426" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7b0137b6d8c16c4b5be194a8ad0b7aa33255c88f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
