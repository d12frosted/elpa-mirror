(define-package "sage-shell-mode" "20230614.616" "A front-end for Sage Math"
  '((cl-lib "0.6.1")
    (emacs "24.4")
    (let-alist "1.0.5")
    (deferred "0.5.1"))
  :commit "d803d3858c3991b5694b16f2be9255e3b3582170" :authors
  '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers
  '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainer
  '("Sho Takemori" . "stakemorii@gmail.com")
  :keywords
  '("sage" "math")
  :url "https://github.com/sagemath/sage-shell-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
