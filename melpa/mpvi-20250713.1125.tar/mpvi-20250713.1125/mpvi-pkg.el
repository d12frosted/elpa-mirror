;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250713.1125"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "0cfdd6b3d8e5cd5d58250b5870254f82059a98f5"
  :revdesc "0cfdd6b3d8e5"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
