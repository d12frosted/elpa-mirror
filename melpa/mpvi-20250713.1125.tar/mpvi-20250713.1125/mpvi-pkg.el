;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250713.1125"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "e61226a861d688a5ec7a26be1c229ab239bd8360"
  :revdesc "e61226a861d6"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
