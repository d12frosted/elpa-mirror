;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-quotes" "20140710.926"
  "Toggle between single and double quoted string."
  ()
  :url "https://github.com/toctan/toggle-quotes.el"
  :commit "33abc221d6887f0518337851318065cd86c34b03"
  :revdesc "33abc221d688"
  :keywords '("convenience" "quotes")
  :authors '(("Jim Tian" . "tianjin.sc@gmail.com"))
  :maintainers '(("Jim Tian" . "tianjin.sc@gmail.com")))
