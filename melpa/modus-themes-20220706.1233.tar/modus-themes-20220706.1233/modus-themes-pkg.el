(define-package "modus-themes" "20220706.1233" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "7ff26d12672035b578389b9059c3074004acbff0" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
