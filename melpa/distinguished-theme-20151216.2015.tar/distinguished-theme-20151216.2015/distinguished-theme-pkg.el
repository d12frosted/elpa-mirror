;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "distinguished-theme" "20151216.2015"
  "A dark and elegant theme for emacs."
  ()
  :url "https://github.com/Lokaltog/distinguished-theme"
  :commit "9b1d25ac59465a5016d187ea84b7614c95a29b3b"
  :revdesc "9b1d25ac5946"
  :authors '(("Kim Silkebækken" . "kim.silkebaekken@gmail.com"))
  :maintainers '(("Kim Silkebækken" . "kim.silkebaekken@gmail.com")))
