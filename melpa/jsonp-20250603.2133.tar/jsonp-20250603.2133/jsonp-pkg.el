;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsonp" "20250603.2133"
  "Resolve JSON pointers in ELisp objects."
  '((emacs "28.1"))
  :url "https://github.com/joshbax189/jsonp-el"
  :commit "3964615915a69f9cc2b1ec3fd8f32825b8380f72"
  :revdesc "3964615915a6"
  :keywords '("comm" "tools"))
