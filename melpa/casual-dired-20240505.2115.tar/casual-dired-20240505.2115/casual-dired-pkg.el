(define-package "casual-dired" "20240505.2115" "Casual Dired"
  '((emacs "29.1"))
  :commit "f72e58d94da30511aeb9fb4510699500b0f2fbff" :authors
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainer
  '("Charles Choi" . "kickingvegas@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kickingvegas/casual-dired")
;; Local Variables:
;; no-byte-compile: t
;; End:
