;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20261107.1819"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "bdec34dd34081a9fea160bc231b3bb2ce64916e6"
  :revdesc "bdec34dd3408"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
