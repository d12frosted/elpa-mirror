;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250115.1630"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "b2eeb4622da8e6497b6bff2f42c85c93df71dbee"
  :revdesc "b2eeb4622da8"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
