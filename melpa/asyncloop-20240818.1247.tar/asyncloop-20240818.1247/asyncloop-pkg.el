;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asyncloop" "20240818.1247"
  "Non-blocking series of functions."
  '((emacs "28"))
  :url "https://github.com/meedstrom/asyncloop"
  :commit "7d60950d160098a879293e049b9863bc955f8666"
  :revdesc "7d60950d1600"
  :keywords '("tools")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
