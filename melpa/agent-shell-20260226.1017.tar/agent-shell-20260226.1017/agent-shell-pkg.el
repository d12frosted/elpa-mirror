;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260226.1017"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "f6023c6440e14ac1e3a02255a2e9007f6aad8633"
  :revdesc "f6023c6440e1")
