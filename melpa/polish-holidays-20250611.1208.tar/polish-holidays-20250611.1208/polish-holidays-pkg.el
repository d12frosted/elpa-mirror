;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polish-holidays" "20250611.1208"
  "Polish holidays."
  '((emacs "24.1"))
  :url "https://github.com/przemarbor/polish-holidays"
  :commit "b729478f4f825c9f1282fdc9be57bbd26635bf32"
  :revdesc "b729478f4f82"
  :keywords '("calendar"))
