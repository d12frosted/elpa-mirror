;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260219.1720"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "b72ee87ffd5dc2d09a918760a0744cd810ee60de"
  :revdesc "b72ee87ffd5d"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
