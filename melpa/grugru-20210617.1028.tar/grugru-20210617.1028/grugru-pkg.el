(define-package "grugru" "20210617.1028" "Rotate text at point"
  '((emacs "24.4"))
  :commit "b1d873cb6186e08c6f7ec782df989b01e955fb4d" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
