(define-package "fpga" "20230606.726" "FPGA & ASIC Utils"
  '((emacs "28.1")
    (ggtags "0.9.0")
    (company "0.9.13"))
  :commit "97e6a439081c9a736b41a715a39e9f6e02bba3e2" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/gmlarumbe/fpga")
;; Local Variables:
;; no-byte-compile: t
;; End:
