;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260327.1632"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "22f14d83ad28d7f8f39529d9a2f35e9e004dd1f3"
  :revdesc "22f14d83ad28"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
