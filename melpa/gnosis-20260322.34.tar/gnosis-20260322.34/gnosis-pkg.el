;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260322.34"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "6809bb7fcede19049168ad161a70f94b9c79b8d0"
  :revdesc "6809bb7fcede"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
