(define-package "fanyi" "20211011.1611" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "e4401b48be558762b51242036704bcea3acd3bf8" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
