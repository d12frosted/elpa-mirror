(define-package "psession" "20231001.432" "Persistent save of elisp objects."
  '((emacs "24")
    (cl-lib "0.5")
    (async "1.9.3"))
  :commit "fc60f1253aeb9c38a08dc74f9c7dbfe0d535a19b" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://github.com/thierryvolpiatto/psession")
;; Local Variables:
;; no-byte-compile: t
;; End:
