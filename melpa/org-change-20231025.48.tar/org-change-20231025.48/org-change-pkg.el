(define-package "org-change" "20231025.48" "Annotate changes in org-mode files"
  '((emacs "26.1")
    (org "9.3"))
  :commit "0fe228a34656a26092cec1ed826127074005e4ef" :keywords
  '("wp" "convenience")
  :url "https://github.com/drghirlanda/org-change")
;; Local Variables:
;; no-byte-compile: t
;; End:
