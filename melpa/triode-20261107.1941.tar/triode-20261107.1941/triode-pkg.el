;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "triode" "20261107.1941"
  "Interface to Triode app, macOS internet radio."
  '((emacs     "30.1")
    (transient "0.9.0")
    (restlib   "0.1.5")
    (shazam    "1.0.0"))
  :url "https://github.com/kickingvegas/triode"
  :commit "e1bc9cf0475bd9eda2222c82f6421737762a3271"
  :revdesc "e1bc9cf0475b"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
