;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pet" "20250716.519"
  "Executable and virtualenv tracker for python-mode."
  '((emacs "26.1")
    (f     "0.6.0")
    (map   "3.3.1")
    (seq   "2.24"))
  :url "https://github.com/wyuenho/emacs-pet/"
  :commit "672bb8730360bc878936fa5efcd92c2134fa1d5f"
  :revdesc "672bb8730360"
  :keywords '("tools")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
