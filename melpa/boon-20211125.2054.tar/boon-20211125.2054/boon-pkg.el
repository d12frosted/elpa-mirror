(define-package "boon" "20211125.2054" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "12d6838c90058fea768cb55a0018807db804b11b")
;; Local Variables:
;; no-byte-compile: t
;; End:
