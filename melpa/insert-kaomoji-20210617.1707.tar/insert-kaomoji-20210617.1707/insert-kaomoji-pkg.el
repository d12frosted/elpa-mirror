(define-package "insert-kaomoji" "20210617.1707" "Easily insert kaomojis"
  '((emacs "24.4"))
  :commit "ff7e4b969fd0e90fe82c8ba608beb22dfb1d32c9" :authors
  '(("Philip K." . "philip@warpmail.net"))
  :maintainer
  '("Philip K." . "philip@warpmail.net")
  :keywords
  '("wp")
  :url "https://git.sr.ht/~zge/kaomoji")
;; Local Variables:
;; no-byte-compile: t
;; End:
