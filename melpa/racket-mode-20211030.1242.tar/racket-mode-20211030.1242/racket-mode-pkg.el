(define-package "racket-mode" "20211030.1242" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "1fe63cbc1f918d0d6e0dece24b2b582937b1be42" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
