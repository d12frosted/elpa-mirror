(define-package "brutal-theme" "20211013.1336" "Brutalist theme"
  '((emacs "24.1"))
  :commit "8b861d6c11d0f959ed4150a048706be02b73a176" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
