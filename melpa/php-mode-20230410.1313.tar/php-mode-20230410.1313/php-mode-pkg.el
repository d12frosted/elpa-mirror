(define-package "php-mode" "20230410.1313" "Major mode for editing PHP code"
  '((emacs "26.1"))
  :commit "9896cccd647fc85106cc4c6cfd3f0a0833854a24" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
