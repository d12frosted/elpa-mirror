;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php" "20261104.1040"
  "Auto Completion source for PHP."
  '((ac-php-core   "2.0")
    (auto-complete "1.4.0")
    (yasnippet     "0.8.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "c2132776a121362fbe3b83535348ded1ee671d03"
  :revdesc "c2132776a121"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
