(define-package "cg" "20230816.1122" "Major mode for editing Constraint Grammar files"
  '((emacs "26.1"))
  :commit "611ffa634c5af98843fa9477bcc5d6ee657da9f1" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("languages")
  :url "https://visl.sdu.dk/constraint_grammar.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
