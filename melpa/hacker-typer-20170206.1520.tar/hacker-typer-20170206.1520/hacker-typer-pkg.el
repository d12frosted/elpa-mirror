;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hacker-typer" "20170206.1520"
  "Pretend to write code like a pro."
  '((emacs "24"))
  :url "https://github.com/therockmandolinist/emacs-hacker-typer"
  :commit "d5a23714a4ccc5071580622f278597d5973f40bd"
  :revdesc "d5a23714a4cc"
  :keywords '("hacker" "typer" "multimedia" "games")
  :authors '(("Diego A. Mundo" . "diegoamundo@gmail.com"))
  :maintainers '(("Diego A. Mundo" . "diegoamundo@gmail.com")))
