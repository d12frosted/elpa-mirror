(define-package "dwim-shell-command" "20240405.140" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "88cf772445fb81a2e785cf6a4227acf12aca634b" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
