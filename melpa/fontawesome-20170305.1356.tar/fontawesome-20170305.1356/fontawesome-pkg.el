(define-package "fontawesome" "20170305.1356" "fontawesome utility"
  '((emacs "24.4"))
  :commit "3d779a5871fd875d4e24c49b4103774973d4e1a1" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-fontawesome")
;; Local Variables:
;; no-byte-compile: t
;; End:
