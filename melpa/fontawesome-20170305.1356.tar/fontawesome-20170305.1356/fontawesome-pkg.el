(define-package "fontawesome" "20170305.1356" "fontawesome utility"
  '((emacs "24.4"))
  :commit "b64edc9f350beef07168621933d3e287bce28434" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-fontawesome")
;; Local Variables:
;; no-byte-compile: t
;; End:
