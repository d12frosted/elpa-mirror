;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hutch" "20261007.1201"
  "AI code review for magit."
  '((emacs     "29.1")
    (magit     "4.0")
    (transient "0.7.4")
    (gptel     "0.9.9.4")
    (svg-lib   "0.3"))
  :url "https://github.com/adjaecent/magit-hutch"
  :commit "2cf8d6c415c0e4db9f49b91176c8d85de164864c"
  :revdesc "2cf8d6c415c0"
  :authors '(("Akshay Gupta" . "mail@kitallis.in"))
  :maintainers '(("Akshay Gupta" . "mail@kitallis.in")))
