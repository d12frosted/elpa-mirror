;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20260730.1513"
  "Light cornsilk theme with warm, earthy colors."
  '((emacs        "28.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "49cf5b6a8c46f6b315818ae06df160c3caefb213"
  :revdesc "49cf5b6a8c46"
  :keywords '("faces" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
