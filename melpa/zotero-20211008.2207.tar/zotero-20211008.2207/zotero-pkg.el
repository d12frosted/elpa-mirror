(define-package "zotero" "20211008.2207" "Library for the Zotero API"
  '((emacs "27.1")
    (ht "2.2")
    (oauth "1.0.4")
    (s "1.12.0"))
  :commit "811bd1f14b38c3dde3f80cd8a13490c9900de888" :authors
  '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainer
  '("Folkert van der Beek" . "folkertvanderbeek@gmail.com")
  :keywords
  '("zotero" "hypermedia")
  :url "https://gitlab.com/fvdbeek/emacs-zotero")
;; Local Variables:
;; no-byte-compile: t
;; End:
