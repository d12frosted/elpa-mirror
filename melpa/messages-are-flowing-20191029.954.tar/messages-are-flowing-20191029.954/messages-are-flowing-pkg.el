;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "messages-are-flowing" "20191029.954"
  "Visible indication when composing \"flowed\" emails."
  ()
  :url "https://github.com/legoscia/messages-are-flowing"
  :commit "d582a564a63b7b90764ffc5c618bc5300225d0ab"
  :revdesc "d582a564a63b"
  :keywords '("mail")
  :authors '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainers '(("Magnus Henoch" . "magnus.henoch@gmail.com")))
