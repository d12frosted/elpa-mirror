;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251218.2217"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "0dfb26dfeb46a29ffdbc4f3ba59b31b1af2381f9"
  :revdesc "0dfb26dfeb46"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
