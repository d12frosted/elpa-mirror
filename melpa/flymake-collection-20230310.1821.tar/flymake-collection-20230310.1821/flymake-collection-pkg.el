(define-package "flymake-collection" "20230310.1821" "Collection of checkers for flymake, bringing flymake to the level of flycheck"
  '((emacs "28.1")
    (let-alist "1.0")
    (flymake "1.2.1"))
  :commit "0c87b8ff48d8b0ef0eab6417ee9b57f0ca095a0d" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("language" "tools")
  :url "https://github.com/mohkale/flymake-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
