;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edna-theme" "20260214.2320"
  "A dark, Edna-inspired theme."
  '((emacs "26.1"))
  :url "https://codeberg.org/golanv/edna-theme"
  :commit "78da1fcde3d03f4ff65b310d19319dc26140566b"
  :revdesc "78da1fcde3d0"
  :keywords '("faces" "theme")
  :authors '(("golanv" . "https://codeberg.org/golanv"))
  :maintainers '(("golanv" . "https://codeberg.org/golanv")))
