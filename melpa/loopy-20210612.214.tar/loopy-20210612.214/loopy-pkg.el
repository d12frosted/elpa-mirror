(define-package "loopy" "20210612.214" "A looping macro"
  '((emacs "27.1"))
  :commit "7505eea58b8f070c02223a8c1418538dcd2efe19" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
