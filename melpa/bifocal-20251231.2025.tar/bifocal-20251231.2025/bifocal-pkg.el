;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bifocal" "20251231.2025"
  "Split-screen scrolling for comint-mode buffers."
  '((emacs "24.4"))
  :url "https://github.com/riscy/bifocal-mode"
  :commit "4e4f1084dc3dd95dfe0905854530e95dbf6c6c5b"
  :revdesc "4e4f1084dc3d"
  :keywords '("frames" "processes"))
