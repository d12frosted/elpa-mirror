;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpstan" "20241028.1536"
  "Interface to PHPStan."
  '((emacs       "24.3")
    (compat      "29")
    (php-mode    "1.22.3")
    (php-runtime "0.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "00bb0b3d996803f8a45bfed5485e52c9be7aa13b"
  :revdesc "00bb0b3d9968"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
