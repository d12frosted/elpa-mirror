(define-package "ekg" "20230923.1957" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.1.1"))
  :commit "503659a031913f4bf1c4ba0577f84aab649ae1f4" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
