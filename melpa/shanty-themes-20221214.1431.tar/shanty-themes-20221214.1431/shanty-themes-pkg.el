(define-package "shanty-themes" "20221214.1431" "The themes for digital workers"
  '((emacs "24.5.1"))
  :commit "376bcef0694ec6e2439151bf1587c768885d58dc" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
