;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251103.1614"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "3e9c96ebb374f5a2a1acc0ff8abf92981a10cbce"
  :revdesc "3e9c96ebb374"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
