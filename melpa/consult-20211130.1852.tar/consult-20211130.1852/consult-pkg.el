(define-package "consult" "20211130.1852" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "fec9fd36829849f54f287d156f3b1645c8e28018" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
