;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260216.1523"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "http://github.com/bbatsov/neocaml"
  :commit "34e13833a9b952d4405b2b1dc2b5a66c1cdbc4ac"
  :revdesc "34e13833a9b9"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
