(define-package "modus-themes" "20221026.1153" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "38677234ad7d406ca6c0c3817533ed8d5080e009" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
