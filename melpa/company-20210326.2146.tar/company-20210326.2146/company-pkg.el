(define-package "company" "20210326.2146" "Modular text completion framework"
  '((emacs "24.3"))
  :commit "613541e048916986e7cd464b054e72e84d96efd1" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
