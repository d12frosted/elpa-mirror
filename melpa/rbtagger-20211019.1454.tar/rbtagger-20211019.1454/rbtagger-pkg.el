(define-package "rbtagger" "20211019.1454" "Ruby tagging tools"
  '((emacs "25.1"))
  :commit "339ac47fe2448e1d391c9f415c9f701ff999a4b0" :authors
  '(("Thiago Araújo" . "thiagoaraujos@gmail.com"))
  :maintainer
  '("Thiago Araújo" . "thiagoaraujos@gmail.com")
  :keywords
  '("languages" "tools")
  :url "https://www.github.com/thiagoa/rbtagger")
;; Local Variables:
;; no-byte-compile: t
;; End:
