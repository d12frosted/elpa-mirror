(define-package "easysession" "20240807.327" "Easily persist and restore your editing sessions"
  '((emacs "25.1")
    (f "0.18.2"))
  :commit "7d6e4984cbffc06eccb7bdd5677f1ee139c41313" :keywords
  '("convenience")
  :url "https://github.com/jamescherti/easysession.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
