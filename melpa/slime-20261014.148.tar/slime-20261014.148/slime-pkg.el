;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20261014.148"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "579d609ecb3e4df695f2c45c9ab47229bab13a2e"
  :revdesc "579d609ecb3e"
  :keywords '("languages" "lisp" "slime"))
