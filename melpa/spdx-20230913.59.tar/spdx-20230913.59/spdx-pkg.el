(define-package "spdx" "20230913.59" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "99d60428a9b36f9cf5fa52defd196dd45db05617" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
