;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250616.831"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.3")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "0e8a9a3f0fff5874899d3283b04c36bae285fcb3"
  :revdesc "0e8a9a3f0fff"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
