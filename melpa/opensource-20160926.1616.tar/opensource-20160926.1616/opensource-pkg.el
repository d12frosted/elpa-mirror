(define-package "opensource" "20160926.1616" "Client for Opensource API"
  '((s "1.11.0")
    (dash "2.12.1")
    (pkg-info "0.6.0")
    (request "0.2.0"))
  :commit "42742d5f1b9590acff7f05ee0094e3a80f4f7171" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("opensource")
  :url "https://github.com/OpenSourceOrg/el-opensourceorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
