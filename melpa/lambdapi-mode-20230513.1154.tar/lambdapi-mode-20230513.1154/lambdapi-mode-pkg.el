(define-package "lambdapi-mode" "20230513.1154" "A major mode for editing Lambdapi source code"
  '((emacs "26.1")
    (eglot "1.5")
    (math-symbol-lists "1.2.1")
    (highlight "20190710.1527"))
  :commit "39fc3d46868866b69a4abb342805d8fa95c970cd" :maintainers
  '(("Deducteam" . "dedukti-dev@inria.fr"))
  :maintainer
  '("Deducteam" . "dedukti-dev@inria.fr")
  :keywords
  '("languages")
  :url "https://github.com/Deducteam/lambdapi")
;; Local Variables:
;; no-byte-compile: t
;; End:
