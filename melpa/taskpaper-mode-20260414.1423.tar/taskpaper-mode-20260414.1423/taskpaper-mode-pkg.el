;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskpaper-mode" "20260414.1423"
  "Major mode for TaskPaper files."
  '((emacs "25.1"))
  :url "https://github.com/saf-dmitry/taskpaper-mode"
  :commit "66da2e56f56507ecc385d1d8ff566fc0a5cbc2f8"
  :revdesc "66da2e56f565"
  :keywords '("outlines" "notetaking" "task management" "productivity" "taskpaper")
  :authors '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainers '(("Dmitry Safronov" . "saf.dmitry@gmail.com")))
