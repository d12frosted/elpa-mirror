(define-package "gumshoe" "20210920.1634" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "c33c84eab76f7812ed8289959fef25853f7bb7b1" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
