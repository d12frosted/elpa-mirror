;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251009.1004"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "f5b48d2a605c1383ddb8522ed315b625115f16a6"
  :revdesc "f5b48d2a605c"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
