;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iter2" "20250103.2159"
  "Reimplementation of Elisp generators."
  '((emacs "25.1"))
  :url "https://github.com/doublep/iter2"
  :commit "1041630f74e14bf97027e6b0953c285a8cd81e64"
  :revdesc "1041630f74e1"
  :keywords '("elisp" "extensions")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
