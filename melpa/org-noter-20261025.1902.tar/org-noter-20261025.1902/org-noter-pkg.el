;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-noter" "20261025.1902"
  "A synchronized, Org-mode, document annotator."
  '((emacs  "24.4")
    (cl-lib "0.6")
    (org    "9.4"))
  :url "https://github.com/org-noter/org-noter"
  :commit "525f978cbc9cec3f2c1e23dbc3388c670667cb80"
  :revdesc "525f978cbc9c"
  :keywords '("lisp" "pdf" "interleave" "annotate" "external" "sync" "notes" "documents" "org-mode")
  :authors '(("Gonçalo Santos" . "in@bsentia")
             ("Maintainer Dmitry M" . "dmitrym@gmail.com"))
  :maintainers '(("Peter Mao" . "peter.mao@gmail.com")
                 ("Dmitry M" . "dmitrym@gmail.com")))
