;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20260924.926"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "34337b2ed9e1de222ca474573f12ed08c05da909"
  :revdesc "34337b2ed9e1"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
