(define-package "x509-mode" "20221231.1329" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "665dd0348c45215312e4cd79df79916fbe21c132" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
