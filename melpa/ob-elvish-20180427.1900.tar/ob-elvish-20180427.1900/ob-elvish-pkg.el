;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-elvish" "20180427.1900"
  "Org-babel functions for Elvish shell."
  ()
  :url "https://github.com/zzamboni/ob-elvish"
  :commit "369181ceae1190bf971c71aebf9fc6133bd98c39"
  :revdesc "369181ceae11"
  :keywords '("literate programming" "elvish" "shell" "languages" "processes" "tools")
  :authors '(("Diego Zamboni" . "diego@zzamboni.org"))
  :maintainers '(("Diego Zamboni" . "diego@zzamboni.org")))
