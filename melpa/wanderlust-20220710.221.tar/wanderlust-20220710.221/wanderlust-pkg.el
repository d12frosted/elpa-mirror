(define-package "wanderlust" "20220710.221" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "d0296bb70abe97fdc3d855ee76eff0414a5fae62")
;; Local Variables:
;; no-byte-compile: t
;; End:
