;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20260116.859"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3"))
  :url "https://codeberg.com/guix/emacs-guix"
  :commit "853e961d09bfa8fac6f8a70533a6676b3fe47a40"
  :revdesc "853e961d09bf"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
