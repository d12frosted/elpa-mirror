;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-aws-iam-role" "20260625.102"
  "Browse, modify, and simulate AWS IAM Roles in Org Babel."
  '((emacs   "29.1")
    (async   "1.9")
    (promise "1.1"))
  :url "https://github.com/will-abb/org-aws-iam-role"
  :commit "2e7072a8322a95d39c0019d41eebf9b93bb4a08d"
  :revdesc "2e7072a8322a"
  :keywords '("aws" "iam" "org" "babel" "tools")
  :authors '(("William Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("William Bosch-Bello" . "williamsbosch@gmail.com")))
