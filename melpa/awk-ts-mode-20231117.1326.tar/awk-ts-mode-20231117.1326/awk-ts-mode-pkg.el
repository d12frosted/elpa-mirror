(define-package "awk-ts-mode" "20231117.1326" "Major mode for awk using tree-sitter"
  '((emacs "29.1"))
  :commit "b33e35927d51f13e4b11ed6c2441d74193c57f82" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("awk" "languages" "tree-sitter")
  :url "https://github.com/nverno/awk-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
