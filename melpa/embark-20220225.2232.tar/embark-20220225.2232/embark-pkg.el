(define-package "embark" "20220225.2232" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "8cb3f7655a7868cebe756c1f6c9f2d07ca4da5d4" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
