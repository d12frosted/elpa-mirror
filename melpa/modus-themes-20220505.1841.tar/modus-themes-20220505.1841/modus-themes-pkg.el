(define-package "modus-themes" "20220505.1841" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "e034dcaa1606db2e8c62cb1b4982e98a4f41eb12" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
