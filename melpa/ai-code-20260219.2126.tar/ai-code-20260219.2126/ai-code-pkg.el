;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260219.2126"
  "Unified interface for AI coding backends such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, agent-shell, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b8d7aef928f1c4a67db2ea31ed1f500d58a5b19b"
  :revdesc "b8d7aef928f1"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
