;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xquery-tool" "20200907.811"
  "A simple interface to saxonb's xquery."
  ()
  :url "https://github.com/paddymcall/xquery-tool.el"
  :commit "bd48e0f56b58e36309f7966dcf67db69d65100a4"
  :revdesc "bd48e0f56b58"
  :keywords '("xml" "xquery" "emacs")
  :authors '(("Patrick McAllister" . "pma@rdorte.org"))
  :maintainers '(("Patrick McAllister" . "pma@rdorte.org")))
