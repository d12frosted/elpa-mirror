(define-package "modus-themes" "20220628.1734" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "9eda0afacf49ec852e2c7b77785c46d5e7fc96da" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
