;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250704.34"
  "Minor mode to format JS code on file save."
  '((emacs "28.1"))
  :url "https://github.com/prettier/prettier-emacs"
  :commit "db508bd10e1596d0b2ebe6df329773bbb645f710"
  :revdesc "db508bd10e15"
  :keywords '("convenience" "wp" "edit" "js"))
