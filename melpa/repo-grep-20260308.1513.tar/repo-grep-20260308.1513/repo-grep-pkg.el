;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "20260308.1513"
  "Project-wide grep search."
  '((emacs "25.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "7efaad2dc00c096d727040dcd90ed7799ecb3bc1"
  :revdesc "7efaad2dc00c"
  :keywords '("tools" "search" "grep" "convenience" "project"))
