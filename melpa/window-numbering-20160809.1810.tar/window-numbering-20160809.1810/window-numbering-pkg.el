;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-numbering" "20160809.1810"
  "Numbered window shortcuts."
  ()
  :url "http://nschum.de/src/emacs/window-numbering-mode/"
  :commit "10809b3993a97c7b544240bf5d7ce9b1110a1b89"
  :revdesc "10809b3993a9"
  :keywords '("faces" "matching")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
