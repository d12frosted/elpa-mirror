(define-package "chronometrist-key-values" "20210608.802" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "794c8382ce0de7c4a6e8370b146879045a9164fa" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
