(define-package "geiser-stklos" "20230707.237" "STklos Scheme implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.16"))
  :commit "3358d0cc01436bd8f71a500175db2716e75b2eed" :authors
  '(("Jeronimo Pellegrini" . "j_p@aleph0.info"))
  :maintainers
  '(("Jeronimo Pellegrini" . "j_p@aleph0.info"))
  :maintainer
  '("Jeronimo Pellegrini" . "j_p@aleph0.info")
  :keywords
  '("languages" "stklos" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/stklos")
;; Local Variables:
;; no-byte-compile: t
;; End:
