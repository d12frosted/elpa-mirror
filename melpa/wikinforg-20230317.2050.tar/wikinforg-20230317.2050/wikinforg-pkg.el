(define-package "wikinforg" "20230317.2050" "Org-mode wikinfo integration"
  '((emacs "27.1")
    (wikinfo "0.0.0")
    (org "9.3"))
  :commit "fe16cbecc73a41110f2bad95c1f63a97a9da88ca" :authors
  '(("Nicholas Vollmer" . "progfolio@protonmail.com"))
  :maintainers
  '(("Nicholas Vollmer" . "progfolio@protonmail.com"))
  :maintainer
  '("Nicholas Vollmer" . "progfolio@protonmail.com")
  :keywords
  '("org" "convenience")
  :url "https://github.com/progfolio/wikinforg")
;; Local Variables:
;; no-byte-compile: t
;; End:
