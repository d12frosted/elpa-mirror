;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nlinum-relative" "20160526.708"
  "Relative line number with nlinum."
  '((emacs  "24.4")
    (nlinum "1.5"))
  :url "https://github.com/xcodebuild/nlinum-relative"
  :commit "5b9950c97ba79a6f0683e38b13da23f39e01031c"
  :revdesc "5b9950c97ba7"
  :keywords '("convenience")
  :authors '(("codefalling" . "code.falling@gmail.com"))
  :maintainers '(("codefalling" . "code.falling@gmail.com")))
