(define-package "proof-general" "20211011.1737" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "25.1"))
  :commit "f6df84995cf597a705df050e5abca4171d52db06" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
