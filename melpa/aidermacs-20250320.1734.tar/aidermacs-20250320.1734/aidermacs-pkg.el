;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250320.1734"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "d90d800c852378b5421004d8e5f64d461ceddfca"
  :revdesc "d90d800c8523"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
