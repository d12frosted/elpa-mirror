(define-package "inline-crypt" "20170824.900" "Simple inline encryption via openssl" 'nil :commit "281385b383f850fd2e895926b1cef804dd052633")
;; Local Variables:
;; no-byte-compile: t
;; End:
