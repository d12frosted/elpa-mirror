;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wolfram" "20231220.1950"
  "Wolfram Alpha Integration."
  ()
  :url "https://github.com/hsjunnesson/wolfram.el"
  :commit "743c92f88bb3b6a77bc84ac2221adc6222cebb94"
  :revdesc "743c92f88bb3"
  :keywords '("math")
  :authors '(("Hans Sjunnesson" . "hans.sjunnesson@gmail.com"))
  :maintainers '(("Hans Sjunnesson" . "hans.sjunnesson@gmail.com")))
