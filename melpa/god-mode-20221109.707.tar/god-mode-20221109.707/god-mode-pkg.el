(define-package "god-mode" "20221109.707" "Minor mode for God-like command entering"
  '((emacs "25.1"))
  :commit "49c1a1753188e5b2788b8c1f1f9fbd1264460bab" :authors
  '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainer
  '("Chris Done" . "chrisdone@gmail.com")
  :url "https://github.com/emacsorphanage/god-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
