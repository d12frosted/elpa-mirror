;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260413.1652"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "a0552436056f64ce0af39a8023bab6a994797e96"
  :revdesc "a0552436056f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
