;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-manually" "20200721.1903"
  "A company backend that lets you manually build candidates."
  '((emacs   "24.3")
    (company "0.9.0")
    (ivy     "0.13.0"))
  :url "https://github.com/yanghaoxie/company-manually"
  :commit "b922318da821fc3cf1d3155f21d543ea8470c881"
  :revdesc "b922318da821"
  :keywords '("convenience" "company-mode" "manually build candidates")
  :maintainers '(("Yanghao Xie" . "yhaoxie@gmail.com")))
