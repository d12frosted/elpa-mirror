(define-package "for" "20220829.1659" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "5b82e5a9f1e0ff69326fb4bdb995009953b30c14" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
