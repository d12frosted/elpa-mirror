;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250322.2106"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "bbc6ec2ffd0cf2e901a83625f69191fe91c76a06"
  :revdesc "bbc6ec2ffd0c"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
