;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-errcheck" "20160723.43"
  "Errcheck integration for go-mode."
  ()
  :url "https://github.com/dominikh/go-errcheck.el"
  :commit "9db21eccecedc2490793f176246094167164af31"
  :revdesc "9db21ecceced"
  :authors '(("Dominik Honnef" . "dominikh@fork-bomb.org"))
  :maintainers '(("Dominik Honnef" . "dominikh@fork-bomb.org")))
