;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-secretario-org" "20250411.1608"
  "Create inboxes out of org-mode files for el-secretario."
  '((emacs         "27.1")
    (org-ql        "0.6-pre")
    (dash          "2.18.1")
    (el-secretario "0.0.1"))
  :url "https://git.sr.ht/~zetagon/el-secretario"
  :commit "70dee3593e63384d536b59958d9765751c8065b9"
  :revdesc "70dee3593e63"
  :keywords '("convenience")
  :authors '(("Leo Okawa Ericson" . "https://sr.ht/~zetagon"))
  :maintainers '(("Leo Okawa Ericson" . "git@relevant-information.com")))
