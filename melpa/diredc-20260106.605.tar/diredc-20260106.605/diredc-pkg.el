;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260106.605"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "8a3b6f1f91e236f6fd00cd1c3ea9633b2db6382f"
  :revdesc "8a3b6f1f91e2"
  :keywords '("files"))
