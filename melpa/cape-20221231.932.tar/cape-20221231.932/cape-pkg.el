(define-package "cape" "20221231.932" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "0bbe3620d6b04f07124b6cde3d979252bdc5782d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
