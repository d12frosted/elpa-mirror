(define-package "workgroups2" "20220103.127" "save&load multiple named workspaces (or \"workgroups\")"
  '((emacs "25.1"))
  :commit "d8e6124a90696bca7ce3c646b7521b3cefa7fad9" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
