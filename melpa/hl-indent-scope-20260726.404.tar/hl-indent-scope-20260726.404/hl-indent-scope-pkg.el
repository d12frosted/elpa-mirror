;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent-scope" "20260726.404"
  "Highlight indentation by scope."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope"
  :commit "e044000b1ee9d67ca6638fd55e1bfe55ff3d5d16"
  :revdesc "e044000b1ee9"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
