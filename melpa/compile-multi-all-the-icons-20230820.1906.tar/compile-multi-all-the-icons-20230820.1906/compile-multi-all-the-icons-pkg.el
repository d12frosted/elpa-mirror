(define-package "compile-multi-all-the-icons" "20230820.1906" "Affixate `compile-multi' with icons"
  '((emacs "28.0")
    (all-the-icons-completion "0.0.1"))
  :commit "4171f5de58a120c661ef33b0af06686be6665a5c" :authors
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("mohsin kaleem" . "mohkale@kisara.moe")
  :keywords
  '("tools" "compile" "build")
  :url "https://github.com/mohkale/compile-multi")
;; Local Variables:
;; no-byte-compile: t
;; End:
