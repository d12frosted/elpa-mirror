;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "20261114.1054"
  "Compiler explorer client (godbolt.org)."
  '((emacs "29.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "b35a250f12e74cc75364b9ecbfe01670997213d2"
  :revdesc "b35a250f12e7"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
