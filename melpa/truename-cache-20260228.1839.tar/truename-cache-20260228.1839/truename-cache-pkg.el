;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260228.1839"
  "Efficiently de-dup file-names."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "356a11ff9fc0c37413779e3f7388ba1410225ea9"
  :revdesc "356a11ff9fc0"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
