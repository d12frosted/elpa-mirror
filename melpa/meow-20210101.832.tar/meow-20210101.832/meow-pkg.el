(define-package "meow" "20210101.832" "Modal Editing On Wheel"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1")
    (s "1.12.0"))
  :commit "671a59c2653a9c7495ff51b9624e9ff2e499ea4b" :authors
  (("Shi Tianshu"))
  :maintainer
  ("Shi Tianshu")
  :keywords
  ("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
