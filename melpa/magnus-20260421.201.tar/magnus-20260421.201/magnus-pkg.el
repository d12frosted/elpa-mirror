;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260421.201"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "ef87ed770acf3113f060afdd6949ac24ce46dee8"
  :revdesc "ef87ed770acf"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
