;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20261029.1335"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.89.4")
    (latex-to-svg-backend "0.18.1"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "b3bf1dc644e248ba31db62dc32d2911b30eba335"
  :revdesc "b3bf1dc644e2"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
