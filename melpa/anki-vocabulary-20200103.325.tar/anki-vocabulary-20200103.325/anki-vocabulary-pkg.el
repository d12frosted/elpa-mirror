;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-vocabulary" "20200103.325"
  "Help you to create vocabulary cards in Anki."
  '((emacs             "24.4")
    (s                 "1.0")
    (youdao-dictionary "0.4")
    (anki-connect      "1.0")
    (s                 "1.10"))
  :url "https://github.com/lujun9972/anki-vocabulary.el"
  :commit "863fe0219577f996ab126f1b7902db3c2cc59b2b"
  :revdesc "863fe0219577"
  :keywords '("lisp" "anki" "translator" "chinese")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
