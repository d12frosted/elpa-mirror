(define-package "chronometrist-key-values" "20211118.1235" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "7ca6413907ac57e09010265257c48b5500fe09f8" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
