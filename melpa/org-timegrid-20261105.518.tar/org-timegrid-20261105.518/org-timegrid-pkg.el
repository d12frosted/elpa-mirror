;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261105.518"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "b373a09e024e8d6a6f9d6843df1aae8d2158ac53"
  :revdesc "b373a09e024e"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
