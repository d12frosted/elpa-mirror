;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calibredb" "20260815.633"
  "Yet another calibre client."
  '((emacs     "29.1")
    (org       "9.3")
    (transient "0.1.0")
    (s         "1.12.0")
    (dash      "2.17.0")
    (request   "0.3.3")
    (esxml     "0.3.7"))
  :url "https://github.com/chenyanming/calibredb.el"
  :commit "4a9df521985739053c6c9f879fb949ceb2e479b1"
  :revdesc "4a9df5219857"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
