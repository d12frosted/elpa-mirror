(define-package "borg" "20220103.932" "assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.3.0")
    (magit "3.0.0"))
  :commit "c563966e969b19b10f08046f5c132eefa5534da4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
