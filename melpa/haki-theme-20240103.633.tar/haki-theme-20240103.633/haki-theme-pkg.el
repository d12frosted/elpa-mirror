(define-package "haki-theme" "20240103.633" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "157fa0651695cacaf34db8b62a009760824473b1" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
