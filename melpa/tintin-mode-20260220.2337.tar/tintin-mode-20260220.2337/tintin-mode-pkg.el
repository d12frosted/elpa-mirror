;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tintin-mode" "20260220.2337"
  "Major mode for editing TinTin++ config files."
  '((emacs "24.3"))
  :url "https://github.com/lesharris/tintin-mode"
  :commit "b94c10c5ba7fef01c53c4d4d66532e7abe82086c"
  :revdesc "b94c10c5ba7f"
  :authors '(("Les Harris" . "les@lesharris.com"))
  :maintainers '(("Les Harris" . "les@lesharris.com")))
