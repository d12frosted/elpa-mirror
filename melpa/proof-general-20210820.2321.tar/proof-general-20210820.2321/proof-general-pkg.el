(define-package "proof-general" "20210820.2321" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "25.1"))
  :commit "51696277a4dc30acd61e9ebb400d99934955e450" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
