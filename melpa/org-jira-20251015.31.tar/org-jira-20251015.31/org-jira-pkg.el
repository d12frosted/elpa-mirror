;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-jira" "20251015.31"
  "Syncing between Jira and Org-mode."
  '((emacs   "24.5")
    (cl-lib  "0.5")
    (request "0.2.0")
    (dash    "2.14.1"))
  :url "https://github.com/ahungry/org-jira"
  :commit "a81125fdc693e4cc12645481ddd512e93c6c3ca5"
  :revdesc "a81125fdc693"
  :keywords '("ahungry" "jira" "org" "bug" "tracker")
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
