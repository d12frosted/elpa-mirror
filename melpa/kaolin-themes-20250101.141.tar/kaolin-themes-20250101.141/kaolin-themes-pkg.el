;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "20250101.141"
  "A set of eye pleasing themes."
  '((emacs      "25.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "bd681916d433dbc21d23e2a99f44e18b4a0ab712"
  :revdesc "bd681916d433"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
