(define-package "hass" "20221126.2152" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3"))
  :commit "75bef04b88b5e7b5fbfcc225f4725d89e41630e8" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
