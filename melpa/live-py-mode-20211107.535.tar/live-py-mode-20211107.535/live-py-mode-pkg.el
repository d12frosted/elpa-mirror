(define-package "live-py-mode" "20211107.535" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "0ee96d2ca647c4ef84d4f2539325da6912f7301b" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
