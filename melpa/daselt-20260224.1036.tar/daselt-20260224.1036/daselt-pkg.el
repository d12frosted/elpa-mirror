;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260224.1036"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "b3ceec1e31953b7925aceb4c081b48bc9a413000"
  :revdesc "b3ceec1e3195"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
