;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "systemtap-mode" "20151122.1940"
  "A mode for SystemTap."
  ()
  :url "https://github.com/ruediger/systemtap-mode"
  :commit "8b5086d6b0050a12bb37e33c24c24d1f420afd3b"
  :revdesc "8b5086d6b005"
  :keywords '("tools" "languages")
  :maintainers '((nil . "ruediger@c-plusplus.de")))
