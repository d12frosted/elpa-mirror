;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260721.33"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "4c2a43b7c519dc98e88292c69c52371c54bc0e31"
  :revdesc "4c2a43b7c519"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
