;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oceanic-theme" "20161015.819"
  "Oceanic theme."
  ()
  :url "https://github.com/terry3/oceanic-theme"
  :commit "00288f6a5245eb001dc123e36af1820eb3cbe985"
  :revdesc "00288f6a5245"
  :keywords '("oceanic" "color" "theme"))
