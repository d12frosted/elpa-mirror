;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mw-thesaurus" "20260927.221"
  "Merriam-Webster Thesaurus."
  '((emacs   "26.1")
    (request "0.3.0")
    (dash    "2.16.0"))
  :url "https://github.com/agzam/mw-thesaurus.el"
  :commit "5c85f8069747a9cbb96b124e46547c459345a638"
  :revdesc "5c85f8069747"
  :keywords '("wp" "matching"))
