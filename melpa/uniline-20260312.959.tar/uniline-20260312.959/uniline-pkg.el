;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260312.959"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "419bb03931e7290ee88c26a160bd8dba6d5aca49"
  :revdesc "419bb03931e7"
  :keywords '("convenience" "text"))
