;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260812.1107"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "693712fb0c20ffe3f74edcd6b37f091d5a112279"
  :revdesc "693712fb0c20"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
