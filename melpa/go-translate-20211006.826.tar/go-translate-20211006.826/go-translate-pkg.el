(define-package "go-translate" "20211006.826" "Google Translate"
  '((emacs "26.1"))
  :commit "5125e5f2fed41ad8e7f6d90221f2d53b328c358c" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
