(define-package "transient" "20230130.1727" "Transient commands"
  '((emacs "25.1")
    (compat "28.1.1.0"))
  :commit "f27c840aec9d37c1784636511e8768ffe3431cab" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
