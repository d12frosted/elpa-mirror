;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-bashate" "20200625.642"
  "Integrate bashate with flycheck."
  '((flycheck "0.24")
    (emacs    "24.4"))
  :url "https://github.com/alexmurray/flycheck-bashate"
  :commit "69e53e84f712bafffd785d84d9304598c2df5615"
  :revdesc "69e53e84f712"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
