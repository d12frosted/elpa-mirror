(define-package "w3m" "20210728.2251" "an Emacs interface to w3m" 'nil :commit "f0baf78897c95799a725d6f9092eef4a55a7f518" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
