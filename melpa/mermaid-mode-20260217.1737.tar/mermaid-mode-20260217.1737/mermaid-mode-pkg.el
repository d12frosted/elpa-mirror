;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mermaid-mode" "20260217.1737"
  "Major mode for working with mermaid graphs."
  '((emacs "25.3"))
  :url "https://github.com/abrochard/mermaid-mode"
  :commit "3b972164bf6a20b2f51607791b1e593ffa1e63cc"
  :revdesc "3b972164bf6a"
  :keywords '("mermaid" "graphs" "tools" "processes"))
