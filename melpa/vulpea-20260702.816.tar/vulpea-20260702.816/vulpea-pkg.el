;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260702.816"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "1edbff627766c304c2d2daae36d6f71f840fe6d5"
  :revdesc "1edbff627766"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
