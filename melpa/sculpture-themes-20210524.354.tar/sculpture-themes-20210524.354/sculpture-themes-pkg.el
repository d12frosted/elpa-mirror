(define-package "sculpture-themes" "20210524.354" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "1da2b3501f3732b4a58d28b502e356226a43a96f" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
