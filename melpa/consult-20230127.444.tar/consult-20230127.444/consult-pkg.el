(define-package "consult" "20230127.444" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "795711154d0967a90ea32bc0727e81bd3530e423" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
