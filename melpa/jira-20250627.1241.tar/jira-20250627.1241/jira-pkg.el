;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20250627.1241"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "2f0260e7d1affa3e3c4398a1902c59ee980975a4"
  :revdesc "2f0260e7d1af"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
