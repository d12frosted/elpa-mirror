;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesky" "20260611.1336"
  "A Bluesky client."
  '((emacs "30.1")
    (plz   "0.9.0")
    (futur "1.7")
    (vui   "1.0.0"))
  :url "https://github.com/ahyatt/emacs-bluesky"
  :commit "f88486f57bde983f24d1cad04525039ca5d37344"
  :revdesc "f88486f57bde"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
