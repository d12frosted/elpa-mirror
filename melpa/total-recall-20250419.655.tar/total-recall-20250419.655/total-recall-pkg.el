;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "total-recall" "20250419.655"
  "Spaced repetition system."
  '((emacs "30.1"))
  :url "https://github.com/phf-1/total-recall"
  :commit "b71c53bb16fdb31db1fcdece46c937d1bcc89e67"
  :revdesc "b71c53bb16fd"
  :authors '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com"))
  :maintainers '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com")))
