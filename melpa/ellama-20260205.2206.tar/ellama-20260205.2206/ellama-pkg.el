;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260205.2206"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "366f05f7abbb80eb7d3c08055e2c3d26bd0654ac"
  :revdesc "366f05f7abbb"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
