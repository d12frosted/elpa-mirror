;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20250512.1129"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4"))
  :url "https://emacs-guix.gitlab.io/website/"
  :commit "94d3df0d87d4b450f2b5b9c14fc418a358c09314"
  :revdesc "94d3df0d87d4"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
