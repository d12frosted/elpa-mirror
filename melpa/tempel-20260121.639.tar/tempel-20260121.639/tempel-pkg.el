;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260121.639"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "f69c18d89de44072e983c8ca8378b276603a1012"
  :revdesc "f69c18d89de4"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
