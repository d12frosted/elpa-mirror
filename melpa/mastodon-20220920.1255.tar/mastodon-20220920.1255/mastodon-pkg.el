(define-package "mastodon" "20220920.1255" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4"))
  :commit "c917a2d0e85167dc82db14975d2d3960114d4279" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
