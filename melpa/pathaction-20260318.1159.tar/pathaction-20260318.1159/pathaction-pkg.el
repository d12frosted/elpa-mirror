;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260318.1159"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "9bc480c454ce615e48c7e83235bcb75b93eeac59"
  :revdesc "9bc480c454ce"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
