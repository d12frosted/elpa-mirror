;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "immaterial-theme" "20260802.918"
  "A family of themes loosely based on material colors."
  '((emacs "31"))
  :url "https://github.com/petergardfjall/emacs-immaterial-theme"
  :commit "1dcbade9c4b4dd1bb3c112f0f82c7bf9264036b2"
  :revdesc "1dcbade9c4b4"
  :keywords '("themes"))
