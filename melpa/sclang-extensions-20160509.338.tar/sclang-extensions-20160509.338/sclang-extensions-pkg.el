(define-package "sclang-extensions" "20160509.338" "Extensions for the SuperCollider Emacs mode."
  '((auto-complete "1.4.0")
    (s "1.3.1")
    (dash "1.2.0")
    (emacs "24.1"))
  :commit "e9cc79732f16fdb582129303110c163dcc0d6da0" :authors
  (("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainer
  ("Chris Barrett" . "chris.d.barrett@me.com")
  :keywords
  ("sclang" "supercollider" "languages" "tools"))
;; Local Variables:
;; no-byte-compile: t
;; End:
