(define-package "dwim-shell-command" "20230907.2028" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "34b89df657e5724af67e68d0662c26dec5aa085a" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
