(define-package "modus-themes" "20220803.1104" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "64f9378a5114399f3a47c9d23136af677c25e513" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
