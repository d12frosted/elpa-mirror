(define-package "embark" "20210723.1745" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "84f42eb23ed790e8899671042c20dfe21202bdcd" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
