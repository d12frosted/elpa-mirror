(define-package "wgsl-mode" "20221127.2129" "Syntax highlighting for the WebGPU Shading Language"
  '((emacs "24"))
  :commit "e7856d6755d93e40ed74598a68ef5f607322618b" :authors
  '(("Anthony Cowley"))
  :maintainers
  '(("Anthony Cowley"))
  :maintainer
  '("Anthony Cowley")
  :keywords
  '("wgsl" "c")
  :url "https://github.com/acowley/wgsl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
