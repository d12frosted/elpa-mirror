;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260619.154"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "91f1d9526e70eb1c0326b07151ff9f40f1dc3d1c"
  :revdesc "91f1d9526e70"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
