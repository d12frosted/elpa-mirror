;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260531.619"
  "LSP mode."
  '((emacs         "29.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "f83b4c48372535b49922e06d310c5f8ee65932cd"
  :revdesc "f83b4c483725"
  :keywords '("languages"))
