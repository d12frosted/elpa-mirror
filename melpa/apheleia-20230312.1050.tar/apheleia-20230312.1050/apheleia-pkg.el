(define-package "apheleia" "20230312.1050" "Reformat buffer stably"
  '((emacs "26"))
  :commit "26e436dfd03f79c4c1bf45695ac05d00ab7440c4" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/raxod502/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
