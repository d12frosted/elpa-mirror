(define-package "obsidian" "20231218.48" "Obsidian Notes interface"
  '((emacs "27.2")
    (f "0.2.0")
    (s "1.12.0")
    (dash "2.13")
    (markdown-mode "2.5")
    (elgrep "1.0.0")
    (yaml "0.5.1"))
  :commit "58fd1b656fb50ae6f719474e557ee43e7da61215" :authors
  '(("Mykhaylo Bilyanskyy"))
  :maintainers
  '(("Mykhaylo Bilyanskyy"))
  :maintainer
  '("Mykhaylo Bilyanskyy")
  :keywords
  '("obsidian" "pkm" "convenience")
  :url "https://github.com./licht1stein/obsidian.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
