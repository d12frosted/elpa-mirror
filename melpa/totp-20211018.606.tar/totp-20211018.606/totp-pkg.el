(define-package "totp" "20211018.606" "Time-based One-time Password (TOTP)"
  '((emacs "27.1"))
  :commit "977bec11b7f3db2875a47156c21fa5a6826782bf" :authors
  '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainer
  '("Jürgen Hötzel" . "juergen@hoetzel.info")
  :keywords
  '("tools" "pass" "password")
  :url "https://github.com/juergenhoetzel/emacs-totp")
;; Local Variables:
;; no-byte-compile: t
;; End:
