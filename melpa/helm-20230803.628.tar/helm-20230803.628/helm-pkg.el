(define-package "helm" "20230803.628" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.2")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "ce760c23c7369d98169563fdcf87f1e0363f29c8" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
