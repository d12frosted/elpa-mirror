;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260707.108"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://codeberg.org/thanosapollo/emacs-gnosis"
  :commit "f68bfc5500c38c1edb59ea6eed70b7a765d368f0"
  :revdesc "f68bfc5500c3"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
