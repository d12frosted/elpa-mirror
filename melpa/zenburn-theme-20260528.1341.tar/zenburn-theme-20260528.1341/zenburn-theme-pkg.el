;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenburn-theme" "20260528.1341"
  "A low contrast color theme for Emacs."
  ()
  :url "https://github.com/bbatsov/zenburn-emacs"
  :commit "afcde4813343cfcf1321cf9298b5ac0ebb89905b"
  :revdesc "afcde4813343"
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
