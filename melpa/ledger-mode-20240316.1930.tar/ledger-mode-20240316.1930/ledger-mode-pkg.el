(define-package "ledger-mode" "20240316.1930" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "2a78366929aca2f99303bcf39de13000cf85fa64")
;; Local Variables:
;; no-byte-compile: t
;; End:
