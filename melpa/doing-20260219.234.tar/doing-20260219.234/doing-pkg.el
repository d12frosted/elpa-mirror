;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doing" "20260219.234"
  "Frictionless activity log and time tracking."
  '((emacs "27.1")
    (org   "9.0"))
  :url "https://github.com/xiaoxinghu/doing.el"
  :commit "e3c39bf16f41637a0ef1c1512cb1417063dea956"
  :revdesc "e3c39bf16f41"
  :keywords '("convenience" "org" "time-tracking")
  :authors '(("Xiaoxing Hu" . "hi@xiaoxing.dev"))
  :maintainers '(("Xiaoxing Hu" . "hi@xiaoxing.dev")))
