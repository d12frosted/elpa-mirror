(define-package "dwim-coder-mode" "20230809.1604" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "84136b700cf1f683f250134c0c050034bd2bcceb" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
