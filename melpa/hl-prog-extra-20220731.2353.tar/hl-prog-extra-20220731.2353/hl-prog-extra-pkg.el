(define-package "hl-prog-extra" "20220731.2353" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "6d419cc36936f3bb3c9c63a6f77cc88a80b0db9c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
