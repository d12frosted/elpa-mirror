;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260325.2051"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "0c7a8d548c1093c0de1820d291aa8f17eb85f2bc"
  :revdesc "0c7a8d548c10"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
