;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261115.2155"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "597ace5fc80341ab97f919da1e2c003a837388bc"
  :revdesc "597ace5fc803"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
