(define-package "ocodo-svg-modelines" "20150516.1419" "A collection of beautiful SVG modelines"
  '((svg-mode-line-themes "0"))
  :commit "c7b0789a177219f117c4de5659ecfa8622958c40")
;; Local Variables:
;; no-byte-compile: t
;; End:
