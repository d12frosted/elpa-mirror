;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250704.802"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.17.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "9acd5a714279c8400ace74b173d1535219b9cde5"
  :revdesc "9acd5a714279"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
