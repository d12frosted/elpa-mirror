(define-package "demap" "20220310.422" "Detachable minimap package"
  '((emacs "24.4")
    (dash "2.18.0"))
  :commit "d0436f89e55c8cb386c4db3a3ece3f7d14d872c2" :authors
  '(("Sawyer Gardner <https://gitlab.com/sawyerjgardner>"))
  :maintainer
  '("Sawyer Gardner <https://gitlab.com/sawyerjgardner>")
  :keywords
  '("lisp" "tools" "convenience")
  :url "https://gitlab.com/sawyerjgardner/demap.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
