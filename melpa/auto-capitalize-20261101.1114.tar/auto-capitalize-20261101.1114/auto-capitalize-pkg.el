;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "20261101.1114"
  "Automatic capitalization with batteries included."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/abdulnafe-t/auto-capitalize.el"
  :commit "d1e9bb2b384c390c54c96ebdbbc19b57fc5e3abb"
  :revdesc "d1e9bb2b384c"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
