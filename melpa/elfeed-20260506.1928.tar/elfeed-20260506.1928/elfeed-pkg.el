;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260506.1928"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "6c9796f4172619a634b5a5c0f6dc14cfdcdf8797"
  :revdesc "6c9796f41726"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
