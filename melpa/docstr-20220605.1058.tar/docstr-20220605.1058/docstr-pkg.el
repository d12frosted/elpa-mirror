(define-package "docstr" "20220605.1058" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "9e3d606d5a6042facaace496046bb5b56d7c65c9" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/emacs-vs/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
