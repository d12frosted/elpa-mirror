(define-package "org-side-tree" "20231002.1013" "Navigate Org outlines in side window tree"
  '((emacs "28.1"))
  :commit "8c40c53665d889d7424f3578dcd3c54c2d6fb6d3" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/org-side-tree")
;; Local Variables:
;; no-byte-compile: t
;; End:
