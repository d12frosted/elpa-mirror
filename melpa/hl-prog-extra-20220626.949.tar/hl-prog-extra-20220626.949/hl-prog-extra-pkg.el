(define-package "hl-prog-extra" "20220626.949" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "bce1f135169a00c43299f4544c89051782219475" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
