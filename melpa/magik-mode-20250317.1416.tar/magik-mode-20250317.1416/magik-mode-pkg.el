;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250317.1416"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "9329a1c19e6f4e4a072f479d1082e6bd0509147e"
  :revdesc "9329a1c19e6f"
  :keywords '("languages"))
