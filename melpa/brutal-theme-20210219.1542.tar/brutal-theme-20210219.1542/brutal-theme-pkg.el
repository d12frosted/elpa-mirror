(define-package "brutal-theme" "20210219.1542" "Brutalist theme"
  '((emacs "24.1"))
  :commit "69b80acb91941b8f6e2e63f3725a67a67d606f14" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
