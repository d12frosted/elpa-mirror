;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aqui" "20260927.1838"
  "Location update (optimized for macOS)."
  '((emacs   "30.1")
    (restlib "0.1.0"))
  :url "https://github.com/kickingvegas/aqui"
  :commit "c8966ed2571ffae1099cc119bceccb8df586dbb2"
  :revdesc "c8966ed2571f"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
