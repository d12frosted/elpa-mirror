(define-package "company" "20231123.135" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "5d05b0829b65ac0f5c334b85b53d9d7cc0204427" :authors
  '(("Nikolaj Schumacher"))
  :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
