;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260712.1739"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "c467a935e89ca2e0738d662f7c0db04b3b8ae9d1"
  :revdesc "c467a935e89c"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
