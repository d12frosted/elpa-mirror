(define-package "flycheck" "20240629.1358" "On-the-fly syntax checking"
  '((emacs "26.1"))
  :commit "43cf1fdb0ef39e8aa678108d1b2d8a07bfa0d989" :authors
  '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://www.flycheck.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
