;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firrtl-mode" "20231127.1237"
  "Mode for working with FIRRTL files."
  '((emacs "24.3"))
  :url "https://github.com/ibm/firrtl-mode"
  :commit "0c7d971899f93367b78e13d70d64cfb89d80b45c"
  :revdesc "0c7d971899f9"
  :keywords '("languages" "firrtl")
  :authors '(("Schuyler Eldridge" . "schuyler.eldridge@ibm.com"))
  :maintainers '(("Schuyler Eldridge" . "schuyler.eldridge@ibm.com")))
