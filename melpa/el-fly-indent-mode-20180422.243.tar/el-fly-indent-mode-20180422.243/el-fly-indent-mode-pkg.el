;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-fly-indent-mode" "20180422.243"
  "Indent Emacs Lisp on the fly."
  '((emacs "25"))
  :url "https://github.com/jiahaowork/el-fly-indent-mode.el"
  :commit "1dd4b907ff4d9581c18b4e38e8719e83ba0dace1"
  :revdesc "1dd4b907ff4d"
  :keywords '("lisp" "languages")
  :authors '(("Jiahao Li" . "jiahaowork@gmail.com"))
  :maintainers '(("Jiahao Li" . "jiahaowork@gmail.com")))
