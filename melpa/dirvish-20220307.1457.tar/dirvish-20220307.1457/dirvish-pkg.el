(define-package "dirvish" "20220307.1457" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "f010dc7a081a61588c220fb815f023544f444493" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
