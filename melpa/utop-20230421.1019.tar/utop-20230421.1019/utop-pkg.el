(define-package "utop" "20230421.1019" "Universal toplevel for OCaml"
  '((emacs "26")
    (tuareg "2.2.0"))
  :commit "ba0e2c7fffab33cf78e2f6e4c346f65e7c0949ae" :authors
  '(("Jeremie Dimino" . "jeremie@dimino.org"))
  :maintainers
  '(("Jeremie Dimino" . "jeremie@dimino.org"))
  :maintainer
  '("Jeremie Dimino" . "jeremie@dimino.org")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml-community/utop")
;; Local Variables:
;; no-byte-compile: t
;; End:
