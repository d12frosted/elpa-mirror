;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260217.947"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "8bddd7dfcd96e5e02c6e899f814623bf8d8087d4"
  :revdesc "8bddd7dfcd96"
  :keywords '("data" "extensions"))
