;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250322.1504"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "5cafffd19afcb4f6708af2d781446e8dc592af42"
  :revdesc "5cafffd19afc"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
