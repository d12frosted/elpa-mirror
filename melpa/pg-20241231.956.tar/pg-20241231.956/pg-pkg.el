;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20241231.956"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0"))
  :url "https://github.com/emarsden/pg-el"
  :commit "3b3f9f5bc7164ff0b37a335dc89558c7196e539d"
  :revdesc "3b3f9f5bc716"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
