(define-package "spdx" "20230217.120" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d8d0768e6e6dcf57ae710f82671cd75b60acfbaa" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
