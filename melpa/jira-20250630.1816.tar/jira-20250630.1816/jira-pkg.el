;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20250630.1816"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "a9f20d63e45569f1c9906507a4e465b42d8588dc"
  :revdesc "a9f20d63e455"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
