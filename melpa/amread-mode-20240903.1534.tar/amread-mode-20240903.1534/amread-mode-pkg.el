;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amread-mode" "20240903.1534"
  "A minor mode helper user speed-reading."
  '((emacs "28.1")
    (pyim  "5.2.8")
    (hydra "0.15.0"))
  :url "https://repo.or.cz/amread-mode.git"
  :commit "bf06b05c6322fe74f0e5ac2436cad46f66f673c6"
  :revdesc "bf06b05c6322"
  :keywords '("wp")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
