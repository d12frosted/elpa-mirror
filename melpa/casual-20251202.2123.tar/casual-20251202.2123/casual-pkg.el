;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20251202.2123"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "f38fb5e5d850d96d57559526bff973f41cf73940"
  :revdesc "f38fb5e5d850"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
