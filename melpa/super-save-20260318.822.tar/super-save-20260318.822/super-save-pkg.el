;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "super-save" "20260318.822"
  "Auto-save buffers, based on your activity."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/super-save"
  :commit "54b922e7255014fc90040e681be317f8ebaf2471"
  :revdesc "54b922e72550"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
