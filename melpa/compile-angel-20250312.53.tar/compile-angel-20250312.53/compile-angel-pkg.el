;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20250312.53"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "a342f43d32b3802f342584590b9967fc7d4333c7"
  :revdesc "a342f43d32b3"
  :keywords '("convenience"))
