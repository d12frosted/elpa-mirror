(define-package "media-progress" "20230527.2209" "Display position where media player stopped"
  '((emacs "28.1"))
  :commit "0b22f92cf4bd40df6057485f63079c779eda9696" :authors
  '(("Dmitriy Pshonko <http://github.com/jumper047>"))
  :maintainers
  '(("Dmitriy Pshonko <http://github.com/jumper047>"))
  :maintainer
  '("Dmitriy Pshonko <http://github.com/jumper047>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/jumper047/media-progress")
;; Local Variables:
;; no-byte-compile: t
;; End:
