;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260820.902"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "ec7d59f50007cf899ebe7539a639bdb88392baf4"
  :revdesc "ec7d59f50007"
  :keywords '("languages" "lisp" "slime"))
