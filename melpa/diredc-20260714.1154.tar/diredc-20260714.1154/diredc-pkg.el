;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260714.1154"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "0ad972d370e63e9b81909a60c06a147986de84f2"
  :revdesc "0ad972d370e6"
  :keywords '("files"))
