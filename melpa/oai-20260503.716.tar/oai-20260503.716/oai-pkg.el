;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260503.716"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "650d2298f4a148d4588676c25bb2d3781bd9a1fc"
  :revdesc "650d2298f4a1"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
