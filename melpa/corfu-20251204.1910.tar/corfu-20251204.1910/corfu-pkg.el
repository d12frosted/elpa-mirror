;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251204.1910"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "ea42506402cf4f7837801e6cf020246156b00517"
  :revdesc "ea42506402cf"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
