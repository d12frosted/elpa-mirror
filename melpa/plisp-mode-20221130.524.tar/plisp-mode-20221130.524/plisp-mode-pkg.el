(define-package "plisp-mode" "20221130.524" "Major mode for PicoLisp programming." 'nil :commit "3a0ec9741ae7ca67852022c6fa85519fcb4b69ba" :authors
  '(("Alexis <flexibeast@gmail.com> (plisp-mode.el); Guillermo R. Palavecine <grpala@gmail.com>, Thorsten Jolitz <tjolitz@gmail.com>, Alexis" . "flexibeast@gmail.com"))
  :maintainer
  '("Alexis" . "flexibeast@gmail.com")
  :keywords
  '("picolisp" "lisp" "programming")
  :url "https://github.com/flexibeast/plisp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
