;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20251211.1501"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "664e00eac67f5761bdbee8a80cb39bf2a5fca21d"
  :revdesc "664e00eac67f"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
