(define-package "helm" "20230829.910" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.4")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "cf685db090f593884b597221bde1eaf43ee909b8" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
