;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251024.2159"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "95380046f0ae7a614f51bed41348c8525b03f867"
  :revdesc "95380046f0ae"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
