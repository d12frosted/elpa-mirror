(define-package "helm-core" "20230624.1641" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "75f93f056710cb035160ae077d4e015ce4e6a0ba" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
