;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260330.846"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "c4a48b1e5056e58b17231bb672d25c6a3be6e681"
  :revdesc "c4a48b1e5056"
  :keywords '("data" "extensions"))
