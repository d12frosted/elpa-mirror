(define-package "nsis-mode" "20230604.343" "NSIS-mode" 'nil :commit "e9d7b0a5a2d6cac4b31c9f9d9a37377cc87a6a3d" :authors
  '(("Matthew L. Fidler"))
  :maintainers
  '(("Matthew L. Fidler"))
  :maintainer
  '("Matthew L. Fidler")
  :keywords
  '("nsis")
  :url "http://github.com/mlf176f2/nsis-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
