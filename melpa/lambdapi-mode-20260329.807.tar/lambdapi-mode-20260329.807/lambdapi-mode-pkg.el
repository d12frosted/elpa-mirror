;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambdapi-mode" "20260329.807"
  "A major mode for editing Lambdapi source code."
  '((emacs             "27.1")
    (eglot             "1.6")
    (math-symbol-lists "1.2.1")
    (highlight         "20190710.1527"))
  :url "https://github.com/Deducteam/lambdapi"
  :commit "f8b222c2fe41caca3d7d1de628d4257829329ed4"
  :revdesc "f8b222c2fe41"
  :keywords '("languages")
  :maintainers '(("Deducteam" . "dedukti-dev@inria.fr")))
