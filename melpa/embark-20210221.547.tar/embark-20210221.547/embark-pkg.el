(define-package "embark" "20210221.547" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c23bb53054baab8b927eae7d818d446b39a8e92c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
