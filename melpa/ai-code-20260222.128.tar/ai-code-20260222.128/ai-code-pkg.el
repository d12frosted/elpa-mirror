;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260222.128"
  "Unified interface for AI coding backends such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, agent-shell, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "8d8539e75743f6acb23cda81f8d0343fc9f52a27"
  :revdesc "8d8539e75743"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
