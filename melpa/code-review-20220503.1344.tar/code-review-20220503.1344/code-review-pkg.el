(define-package "code-review" "20220503.1344" "Perform code review from Github, Gitlab, and Bitbucket Cloud"
  '((emacs "25.1")
    (closql "1.2.0")
    (magit "3.0.0")
    (a "1.0.0")
    (ghub "3.5.1")
    (uuidgen "1.2")
    (deferred "0.5.1")
    (markdown-mode "2.4")
    (forge "0.3.0")
    (emojify "1.2"))
  :commit "68f861e9427d476247805cd34a118ffc6e0673e8" :authors
  '(("Wanderson Ferreira <https://github.com/wandersoncferreira>"))
  :maintainer
  '("Wanderson Ferreira" . "wand@hey.com")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/wandersoncferreira/code-review")
;; Local Variables:
;; no-byte-compile: t
;; End:
