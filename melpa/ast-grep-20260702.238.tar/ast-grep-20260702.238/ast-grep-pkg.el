;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ast-grep" "20260702.238"
  "Search code using ast-grep with completing-read interface."
  '((emacs "28.1"))
  :url "https://github.com/sunskyxh/ast-grep.el"
  :commit "28bc6e9ac21acf1d1ef58b962b6acd670c27e80f"
  :revdesc "28bc6e9ac21a"
  :keywords '("tools" "matching")
  :authors '(("SunskyXH" . "sunskyxh@gmail.com"))
  :maintainers '(("SunskyXH" . "sunskyxh@gmail.com")))
