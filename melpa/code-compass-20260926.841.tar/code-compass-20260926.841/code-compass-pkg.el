;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-compass" "20260926.841"
  "Navigate software aided by metrics and visualization."
  '((emacs        "26.1")
    (s            "1.12.0")
    (dash         "2.13")
    (async        "1.9.7")
    (simple-httpd "1.5.1"))
  :url "https://github.com/ag91/code-compass"
  :commit "5c4f7035d5d4652a4d1151ebb85fc3719bc98bbd"
  :revdesc "5c4f7035d5d4"
  :keywords '("tools" "extensions" "help")
  :authors '(("Andrea" . "andrea-dev@hotmail.com"))
  :maintainers '(("Andrea" . "andrea-dev@hotmail.com")))
