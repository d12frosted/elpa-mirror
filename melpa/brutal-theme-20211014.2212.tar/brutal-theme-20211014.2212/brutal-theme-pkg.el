(define-package "brutal-theme" "20211014.2212" "Brutalist theme"
  '((emacs "24.1"))
  :commit "ce00e434baec93bdf846195516f083190edf3662" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
