;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260911.1910"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "83e1ad8a4c1bb6e0cd7ffabd5b0375fc0448931f"
  :revdesc "83e1ad8a4c1b"
  :keywords '("data" "extensions"))
