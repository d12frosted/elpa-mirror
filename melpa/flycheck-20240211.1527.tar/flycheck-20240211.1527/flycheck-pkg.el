(define-package "flycheck" "20240211.1527" "On-the-fly syntax checking"
  '((emacs "26.1")
    (pkg-info "0.4")
    (seq "2.24"))
  :commit "8a7c19e466725f17d5f631cf978a74985c1367ff" :authors
  '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "http://www.flycheck.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
