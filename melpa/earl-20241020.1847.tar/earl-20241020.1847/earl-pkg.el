;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "earl" "20241020.1847"
  "Erlang distribution protocol implementation."
  '((emacs "29.1"))
  :url "https://github.com/axelf4/earl"
  :commit "aa10aae9891a599f523f269cc391ed316775d12a"
  :revdesc "aa10aae9891a"
  :keywords '("comm" "extensions" "languages" "processes")
  :authors '(("Axel Forsman" . "axel@axelf.se"))
  :maintainers '(("Axel Forsman" . "axel@axelf.se")))
