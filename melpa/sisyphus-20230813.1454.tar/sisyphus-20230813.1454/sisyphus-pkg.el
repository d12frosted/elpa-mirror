(define-package "sisyphus" "20230813.1454" "Create releases of Emacs packages"
  '((emacs "27.1")
    (compat "29.1.4.2")
    (elx "1.6.0")
    (llama "0.3.0")
    (magit "3.4.0"))
  :commit "84d6d6fcd99fbe6630da0bcb1e61904954cb3a72" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/sisyphus")
;; Local Variables:
;; no-byte-compile: t
;; End:
