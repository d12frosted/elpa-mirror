(define-package "detached" "20220525.1513" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "09a7aeb7ec679fe4260b2f5010d186563c527245" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
