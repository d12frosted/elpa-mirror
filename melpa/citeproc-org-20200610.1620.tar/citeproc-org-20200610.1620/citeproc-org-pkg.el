(define-package "citeproc-org" "20200610.1620" "Render org-mode references in CSL styles"
  '((emacs "25.1")
    (dash "2.12.0")
    (org "9")
    (f "0.18.0")
    (citeproc "0.1")
    (org-ref "1.1.1"))
  :commit "a35655c55bbdc3f8c0571c8a8f14a33f9eac330b" :authors
  '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainer
  '("András Simonyi" . "andras.simonyi@gmail.com")
  :keywords
  '("org-ref" "org-mode" "cite" "bib")
  :url "https://github.com/andras-simonyi/citeproc-org")
;; Local Variables:
;; no-byte-compile: t
;; End:
