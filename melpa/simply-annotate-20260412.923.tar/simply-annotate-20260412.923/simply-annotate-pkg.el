;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260412.923"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "b52fd63b590160c9b3a1ee5201d99e83b5fcd66d"
  :revdesc "b52fd63b5901"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
