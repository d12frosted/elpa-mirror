(define-package "envrc" "20230622.1535" "Support for `direnv' that operates buffer-locally"
  '((seq "2")
    (emacs "25.1")
    (inheritenv "0.1"))
  :commit "7fccb591d67dd27962b127d6a0e646e94345602d" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("processes" "tools")
  :url "https://github.com/purcell/envrc")
;; Local Variables:
;; no-byte-compile: t
;; End:
