;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colormaps" "20171008.2224"
  "Hex colormaps."
  '((emacs "25"))
  :url "https://github.com/lepisma/colormaps.el"
  :commit "3a88961ba66b09a49ea5aa92b2b8776b2c92d68c"
  :revdesc "3a88961ba66b"
  :keywords '("tools")
  :authors '(("Abhinav Tushar" . "lepisma@fastmail.com"))
  :maintainers '(("Abhinav Tushar" . "lepisma@fastmail.com")))
