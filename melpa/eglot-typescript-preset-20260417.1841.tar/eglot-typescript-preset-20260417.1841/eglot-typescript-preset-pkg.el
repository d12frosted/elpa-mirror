;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-typescript-preset" "20260417.1841"
  "Eglot preset for TypeScript."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-typescript-preset"
  :commit "f789a45d98eb4d5cc8129a34893a91bd36abd09c"
  :revdesc "f789a45d98eb"
  :keywords '("typescript" "javascript" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
