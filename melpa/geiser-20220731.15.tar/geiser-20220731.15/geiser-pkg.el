(define-package "geiser" "20220731.15" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (project "0.8.1"))
  :commit "224302fe7a3f4dc711638958aa993f5e6816fe99" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
