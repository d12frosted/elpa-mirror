(define-package "posframe" "20211024.402" "Pop a posframe (just a frame) at point"
  '((emacs "26"))
  :commit "c33d7b6b0de2e419bc563ecdb690e45e92476166" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
