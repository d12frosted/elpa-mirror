(define-package "kite" "20130201.1938" "WebKit inspector front-end"
  '((json "1.2")
    (websocket "0.93.1"))
  :commit "7ed74d1147a6ddd152d3da65dc30df3517d53144" :keywords
  ("tools")
  :authors
  (("Julian Scheid" . "julians37@gmail.com"))
  :maintainer
  ("Julian Scheid" . "julians37@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
