;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260729.1521"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f87c7ee794c34d4e100b229d49f07b89d0fec840"
  :revdesc "f87c7ee794c3"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
