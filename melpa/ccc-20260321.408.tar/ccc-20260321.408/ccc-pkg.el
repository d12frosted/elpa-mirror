;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ccc" "20260321.408"
  "Buffer local cursor color control library."
  ()
  :url "https://github.com/skk-dev/ddskk"
  :commit "af3e22463dac6253648b13ad6fa68ba92d706d4e"
  :revdesc "af3e22463dac"
  :keywords '("cursor")
  :authors '(("Masatake YAMATO" . "masata-y@is.aist-nara.ac.jp")))
