(define-package "fennel-mode" "20231022.1453" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "bd9b780ede0d736dce52ca79bbb3b3f542ace24a" :authors
  '(("Phil Hagelberg"))
  :maintainers
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
