(define-package "dirvish" "20220214.1730" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "55d0a5cbfcf2c4d14ce049eece102c48bdc774b2" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
