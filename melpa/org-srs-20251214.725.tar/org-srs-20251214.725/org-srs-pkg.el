;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251214.725"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "385a117aa4a91ec0435f5c8cd7d4fb1562375b0e"
  :revdesc "385a117aa4a9"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
