;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontsloth" "20250614.26"
  "Elisp otf/ttf font loader/renderer."
  '((async  "1.9.7")
    (f      "0.20.0")
    (logito "0.1")
    (pcache "0.5")
    (stream "2.2.5")
    (emacs  "28.1"))
  :url "https://github.com/jollm/fontsloth"
  :commit "352e2a254fcc5c11fff6f8d57a8a34907e9cb176"
  :revdesc "352e2a254fcc"
  :keywords '("data" "font" "rasterization" "ttf" "otf")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")))
