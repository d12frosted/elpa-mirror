(define-package "chronometrist" "20210106.2147" "A time tracker with a nice interface"
  '((emacs "25.1")
    (dash "2.16.0")
    (seq "2.20")
    (s "1.12.0")
    (ts "0.2")
    (anaphora "1.0.4"))
  :commit "cef185de5ce47236c6ba70a7613f7aa51365e5ec" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "https://github.com/contrapunctus-1/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
