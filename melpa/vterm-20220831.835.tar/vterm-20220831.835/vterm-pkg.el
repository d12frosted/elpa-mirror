(define-package "vterm" "20220831.835" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "d6fcd38b9544dd4d05dbe5db10e950043b68de9c" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
