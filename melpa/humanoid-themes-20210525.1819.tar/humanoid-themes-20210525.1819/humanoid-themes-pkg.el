(define-package "humanoid-themes" "20210525.1819" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "bb8fc7526e2527fd5e01d5225135edcf2cb2c218" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
