(define-package "haskell-emacs-text" "20150713.1416" "Haskell functions from Data.Text"
  '((haskell-emacs "2.4.0"))
  :commit "cc240612740fc3fd6e3c3d8cdfe486a89954f5d1" :authors
  '(("Florian Knupfer"))
  :maintainer
  '("Florian Knupfer")
  :keywords
  '("haskell" "emacs" "ffi")
  :url "https://github.com/knupfer/haskell-emacs/modules/text")
;; Local Variables:
;; no-byte-compile: t
;; End:
