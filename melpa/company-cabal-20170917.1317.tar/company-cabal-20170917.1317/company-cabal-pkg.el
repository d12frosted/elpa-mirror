;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-cabal" "20170917.1317"
  "Company-mode cabal backend."
  '((cl-lib  "0.5")
    (company "0.8.0")
    (emacs   "24"))
  :url "https://github.com/iquiw/company-cabal"
  :commit "62112a7259e24bd6c08885629a185afe512b7d3d"
  :revdesc "62112a7259e2"
  :authors '(("Iku Iwasa" . "iku.iwasa@gmail.com"))
  :maintainers '(("Iku Iwasa" . "iku.iwasa@gmail.com")))
