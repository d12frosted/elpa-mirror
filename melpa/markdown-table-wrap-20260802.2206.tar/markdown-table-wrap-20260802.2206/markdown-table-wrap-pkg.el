;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-table-wrap" "20260802.2206"
  "Word-wrap GFM pipe tables to fit window width."
  '((emacs "28.1"))
  :url "https://github.com/dnouri/markdown-table-wrap"
  :commit "b319478d751601c42dfc178ccccdabefc5e76d04"
  :revdesc "b319478d7516"
  :keywords '("text" "markdown" "tables")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
