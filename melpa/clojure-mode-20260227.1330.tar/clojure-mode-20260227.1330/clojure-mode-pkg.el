;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260227.1330"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "bc1974e32ccdcad34727019f79ffceeb80b684f1"
  :revdesc "bc1974e32ccd"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
