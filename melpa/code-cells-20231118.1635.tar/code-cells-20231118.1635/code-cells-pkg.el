(define-package "code-cells" "20231118.1635" "Lightweight notebooks with support for ipynb files"
  '((emacs "27.1"))
  :commit "e470ea314cab37c63e223f1f31c2bd075f9ccd7b" :authors
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainer
  '("Augusto Stoffel" . "arstoffel@gmail.com")
  :keywords
  '("convenience" "outlines")
  :url "https://github.com/astoff/code-cells.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
