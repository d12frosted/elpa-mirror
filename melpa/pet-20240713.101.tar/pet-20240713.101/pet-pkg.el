(define-package "pet" "20240713.101" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0")
    (map "3.3.1")
    (seq "2.24"))
  :commit "71a1fa0f403edcbfd7ce5cc20945de0d97daec7f" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
