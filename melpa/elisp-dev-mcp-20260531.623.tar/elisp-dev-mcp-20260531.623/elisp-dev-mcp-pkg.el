;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-dev-mcp" "20260531.623"
  "MCP server for agentic Elisp development."
  '((emacs          "27.1")
    (mcp-server-lib "0.3.0"))
  :url "https://github.com/laurynas-biveinis/elisp-dev-mcp"
  :commit "73f84c8c916fc0b8761c236965c6daaa52817897"
  :revdesc "73f84c8c916f"
  :keywords '("tools" "development"))
