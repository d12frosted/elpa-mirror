;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260624.718"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "1f00eeb9b95bd3075b67ebf5efc5e08dbdfc0361"
  :revdesc "1f00eeb9b95b"
  :keywords '("data" "extensions"))
