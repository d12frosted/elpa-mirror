;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parsebib" "20241215.1707"
  "A library for parsing bib files."
  '((emacs "25.1"))
  :url "https://github.com/joostkremers/parsebib"
  :commit "e2dafd2996eabedd3a2dd38dd054f9ca361dcae4"
  :revdesc "e2dafd2996ea"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
