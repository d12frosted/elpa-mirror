;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251014.2225"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "dc8eb7a69f7aa797820d79772e3972ed993a4bcb"
  :revdesc "dc8eb7a69f7a"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
