(define-package "julia-ts-mode" "20230920.1231" "Major mode for Julia source code using tree-sitter"
  '((emacs "29")
    (julia-mode "0.4"))
  :commit "ff0c113e758c5171330fa25b8f0d4123d44a029c" :authors
  '(("Ronan Arraes Jardim Chagas"))
  :maintainers
  '(("Ronan Arraes Jardim Chagas"))
  :maintainer
  '("Ronan Arraes Jardim Chagas")
  :keywords
  '("julia" "languages" "tree-sitter")
  :url "https://github.com/ronisbr/julia-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
