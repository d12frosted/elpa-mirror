(define-package "vhdl-ext" "20230906.938" "VHDL Extensions"
  '((emacs "28.2")
    (eglot "1.9")
    (lsp-mode "8.0.1")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "33snapshot")
    (company "0.9.13")
    (outshine "3.1pre")
    (async "1.9.7"))
  :commit "b31dc2740083a43c1d4483c5be3acf79b5815ca2" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
