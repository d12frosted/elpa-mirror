(define-package "company-qml" "20170428.1708" "Company backend for QML files"
  '((qml-mode "0.1")
    (company "0.8.12"))
  :commit "4af4f32a7ad86d86bb9293fb0b675aec513b5736" :keywords
  ("extensions")
  :authors
  (("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainer
  ("Junpeng Qiu" . "qjpchmail@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
