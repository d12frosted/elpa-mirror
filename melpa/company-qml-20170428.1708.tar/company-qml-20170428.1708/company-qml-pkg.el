;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-qml" "20170428.1708"
  "Company backend for QML files."
  '((qml-mode "0.1")
    (company  "0.8.12"))
  :url "https://github.com/cute-jumper/company-qml"
  :commit "4af4f32a7ad86d86bb9293fb0b675aec513b5736"
  :revdesc "4af4f32a7ad8"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
