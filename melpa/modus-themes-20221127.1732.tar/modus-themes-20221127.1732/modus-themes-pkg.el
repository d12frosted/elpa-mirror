(define-package "modus-themes" "20221127.1732" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "dd64df9213c202af87c9b5ecca9c00c4c27eee33" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
