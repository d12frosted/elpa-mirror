;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260226.1408"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "40c989e597f12661b7f7a078564cc82a9d57f821"
  :revdesc "40c989e597f1"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
