;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "context-transient" "20240530.1344"
  "Context specific transients."
  '((emacs "29.1"))
  :url "https://github.com/licht1stein/context-transient.el"
  :commit "4461c3a5b8654cb1dacea404f78951172437804f"
  :revdesc "4461c3a5b865"
  :authors '(("Mykhaylo Bilyanskyy" . "mb@m1k.pw"))
  :maintainers '(("Mykhaylo Bilyanskyy" . "mb@m1k.pw")))
