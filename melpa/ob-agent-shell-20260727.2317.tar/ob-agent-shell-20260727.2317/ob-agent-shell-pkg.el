;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-agent-shell" "20260727.2317"
  "Org-babel backend for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.50.1")
    (org         "9.6"))
  :url "https://github.com/eddof13/ob-agent-shell"
  :commit "012e2d8acf152ee096d95e4b52ef3e82507e93a2"
  :revdesc "012e2d8acf15"
  :keywords '("tools" "convenience" "outlines")
  :authors '(("Eddie Jesinsky" . "eddie@jesinsky.com"))
  :maintainers '(("Eddie Jesinsky" . "eddie@jesinsky.com")))
