;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-agent-shell" "20260727.2317"
  "Org-babel backend for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.50.1")
    (org         "9.6"))
  :url "https://github.com/eddof13/ob-agent-shell"
  :commit "3e110db0da3bd8fe93cac0851b0e0a70f674aeff"
  :revdesc "3e110db0da3b"
  :keywords '("tools" "convenience" "outlines")
  :authors '(("Eddie Jesinsky" . "eddie@jesinsky.com"))
  :maintainers '(("Eddie Jesinsky" . "eddie@jesinsky.com")))
