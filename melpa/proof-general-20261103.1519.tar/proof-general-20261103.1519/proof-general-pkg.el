;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261103.1519"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "851655df5f230ddca9721b00c7fcbb5cb37d01bf"
  :revdesc "851655df5f23"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
