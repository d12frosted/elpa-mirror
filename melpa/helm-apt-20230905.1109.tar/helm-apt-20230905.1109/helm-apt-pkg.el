(define-package "helm-apt" "20230905.1109" "Helm interface for Debian/Ubuntu packages (apt-*)"
  '((helm "3.6")
    (emacs "25.1"))
  :commit "7c486d63995337a6585bdaabd69694aa296588bd" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://github.com/emacs-helm/helm-apt")
;; Local Variables:
;; no-byte-compile: t
;; End:
