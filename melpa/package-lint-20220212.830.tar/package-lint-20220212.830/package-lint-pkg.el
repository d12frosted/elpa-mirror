(define-package "package-lint" "20220212.830" "A linting library for elisp package authors"
  '((cl-lib "0.5")
    (emacs "24.1")
    (let-alist "1.0.6"))
  :commit "fc30a795000a1ae98bb3d09e5b2929bedfc402fe" :authors
  '(("Steve Purcell" . "steve@sanityinc.com")
    ("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("lisp")
  :url "https://github.com/purcell/package-lint")
;; Local Variables:
;; no-byte-compile: t
;; End:
