(define-package "pdf-view-pagemark" "20230825.1247" "Add indicator in pdfview mode to show the page remaining"
  '((pdf-tools "0.90")
    (posframe "1.4.2")
    (emacs "26.0"))
  :commit "eadbc335aa57627c6075b23922cfcafb56ca59b0" :authors
  '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers
  '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainer
  '("Kimi Ma" . "kimi.im@outlook.com")
  :keywords
  '("multimedia" "convenience")
  :url "https://github.com/kimim/pdf-view-pagemark")
;; Local Variables:
;; no-byte-compile: t
;; End:
