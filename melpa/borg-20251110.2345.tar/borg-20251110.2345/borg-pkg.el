;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20251110.2345"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "27.1")
    (epkg  "4.1")
    (magit "4.4"))
  :url "https://github.com/emacscollective/borg"
  :commit "0ed722d43c17d74fa4a6960200dd2d63dd77307f"
  :revdesc "0ed722d43c17"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
