;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-kanban" "20260910.2202"
  "Kanban dynamic block for org-mode."
  '((emacs "31.1")
    (s     "1.0")
    (dash  "2.17.0"))
  :url "https://github.com/gizmomogwai/org-kanban"
  :commit "d79668fded3e9e13c8238f13f053e49ceebf238d"
  :revdesc "d79668fded3e"
  :keywords '("org-mode" "org" "kanban" "tools")
  :authors '(("Christian Köstlin" . "christian.koestlin@gmail.com"))
  :maintainers '(("Christian Köstlin" . "christian.koestlin@gmail.com")))
