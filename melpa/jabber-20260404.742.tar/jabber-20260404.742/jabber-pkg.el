;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260404.742"
  "XMPP/Jabber client."
  '((emacs "29.1")
    (fsm   "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-jabber"
  :commit "3ab3a35dcb400c85797cd501e5c198cc80ff8c1d"
  :revdesc "3ab3a35dcb40"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
