;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phan" "20200805.356"
  "Utility functions for Phan (PHP static analizer)."
  '((emacs    "24")
    (composer "0.0.8")
    (f        "0.17"))
  :url "https://github.com/emacs-php/phan.el"
  :commit "b7d523630bb072c4dbcfa9995dc734b25b72a69f"
  :revdesc "b7d523630bb0"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@pixiv.com"))
  :maintainers '(("USAMI Kenta" . "tadsan@pixiv.com")))
