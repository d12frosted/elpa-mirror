(define-package "trashed" "20220106.1358" "Viewing/editing system trash can"
  '((emacs "25.1"))
  :commit "ddf5830730544435a068f2dc9ac75a81ea69df1d" :authors
  '(("Shingo Tanaka" . "shingo.fg8@gmail.com"))
  :maintainers
  '(("Shingo Tanaka" . "shingo.fg8@gmail.com"))
  :maintainer
  '("Shingo Tanaka" . "shingo.fg8@gmail.com")
  :keywords
  '("files" "convenience" "unix")
  :url "https://github.com/shingo256/trashed")
;; Local Variables:
;; no-byte-compile: t
;; End:
