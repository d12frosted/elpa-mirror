;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "malinka" "20171202.1021"
  "A C/C++ project configuration package for Emacs."
  '((s          "1.9.0")
    (dash       "2.4.0")
    (f          "0.11.0")
    (cl-lib     "0.3")
    (rtags      "0.0")
    (projectile "0.11.0"))
  :url "https://github.com/LefterisJP/malinka"
  :commit "e3dc5b0703a5954057110b82cb397a990ace23e6"
  :revdesc "e3dc5b0703a5"
  :keywords '("c" "c++" "project-management")
  :authors '(("Lefteris Karapetsas" . "lefteris@refu.co"))
  :maintainers '(("Lefteris Karapetsas" . "lefteris@refu.co")))
