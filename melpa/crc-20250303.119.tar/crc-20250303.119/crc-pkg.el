;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crc" "20250303.119"
  "Cyclic Redundancy Check."
  '((emacs "25.1"))
  :url "https://codeberg.org/tomenzgg/Emacs-CRC"
  :commit "568bd5e0fddfbf430c295da33a17f6ed99484188"
  :revdesc "568bd5e0fddf"
  :keywords '("lisp" "checksum" "algorithms")
  :authors '(("Jean Libète" . "tomenzgg@mail.mayfirst.org"))
  :maintainers '(("Jean Libète" . "tomenzgg@mail.mayfirst.org")))
