;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260919.9"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "37f78e1b7b56b1e8fb7caf8d0aa8cda6c3212dd9"
  :revdesc "37f78e1b7b56"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
