(define-package "catppuccin-theme" "20230415.2244" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "f8e99cb308351c3119aac491a38b4be19fe32316" :authors
  '(("nyxkrage"))
  :maintainer
  '("Carsten Kragelund" . "carsten@kragelund.me")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
