;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "20250526.911"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "2495deb997e9e384c53e467142ff0ea2adfab18e"
  :revdesc "2495deb997e9"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
