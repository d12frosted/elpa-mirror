;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260606.454"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "a22585bc0768bdd060ae13a36337cedee5979fd7"
  :revdesc "a22585bc0768"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
