(define-package "citre" "20220324.1741" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "8b51e58819e0a4b65c15f01177d1a154d9a9d153" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
