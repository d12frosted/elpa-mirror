(define-package "dirvish" "20220921.47" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "ae74476e6734d75e3f53b07a3554306d3fd6eef0" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
