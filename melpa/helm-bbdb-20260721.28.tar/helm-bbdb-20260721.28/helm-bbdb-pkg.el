;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bbdb" "20260721.28"
  "Helm interface for bbdb."
  '((emacs "26.1")
    (helm  "1.5")
    (bbdb  "3.1.2"))
  :url "https://github.com/emacs-helm/helm-bbdb"
  :commit "6dee414bfa905e6fbbacce58de17993f7d6e4314"
  :revdesc "6dee414bfa90")
