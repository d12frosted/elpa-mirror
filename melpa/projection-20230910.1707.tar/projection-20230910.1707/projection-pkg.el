(define-package "projection" "20230910.1707" "Project type support for `project'"
  '((emacs "29.1")
    (project "0.9.8")
    (compat "29.1.4.1")
    (f "0.20"))
  :commit "c3fbf532bdc8ba3ae798ca2639751edd3b05fa95" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
