;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260425.2305"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "1dcb6f5b4d6c51bf14c5f760272d2cb93072d234"
  :revdesc "1dcb6f5b4d6c"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
