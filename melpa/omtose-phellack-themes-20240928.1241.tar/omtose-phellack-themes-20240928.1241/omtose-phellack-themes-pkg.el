(define-package "omtose-phellack-themes" "20240928.1241" "Two dark themes, with cold blusish touch"
  '((emacs "24"))
  :commit "b96905deb9b2bef097e0c573100874812c1e9aa8" :url "http:/github.com/franksn/omtose-darker/")
;; Local Variables:
;; no-byte-compile: t
;; End:
