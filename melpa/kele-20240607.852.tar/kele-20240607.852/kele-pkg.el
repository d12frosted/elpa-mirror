(define-package "kele" "20240607.852" "Spritzy Kubernetes cluster management"
  '((emacs "29.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (memoize "0")
    (plz "0.8.0")
    (s "1.13.0")
    (yaml "0.5.1"))
  :commit "7b77ef1e163f069d9eb26d957e20da9703fe0c6e" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
