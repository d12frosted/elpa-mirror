;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20260524.1913"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "0ab96221ba65bddaa56a781c59f7bbed2b76f50c"
  :revdesc "0ab96221ba65"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
