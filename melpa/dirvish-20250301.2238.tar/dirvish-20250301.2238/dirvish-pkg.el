;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250301.2238"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "d020b13287a0a131d5537e6cf6d0fc8b52507c22"
  :revdesc "d020b13287a0"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
