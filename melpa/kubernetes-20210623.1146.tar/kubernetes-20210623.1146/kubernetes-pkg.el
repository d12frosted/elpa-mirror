(define-package "kubernetes" "20210623.1146" "Magit-like porcelain for Kubernetes."
  '((emacs "25.1")
    (dash "2.12.0")
    (magit "2.8.0")
    (magit-popup "2.13.0"))
  :commit "6df1a818d284bd859ebb3e19ffa610eaefb9fe7e" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool"))
;; Local Variables:
;; no-byte-compile: t
;; End:
