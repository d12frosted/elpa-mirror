;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250531.254"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "9a7db842b325c6de497c399d347e4cd4cabbde19"
  :revdesc "9a7db842b325"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
