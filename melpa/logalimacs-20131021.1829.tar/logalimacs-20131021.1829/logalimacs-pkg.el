;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "logalimacs" "20131021.1829"
  "Front-end to logaling-command for Ruby gems."
  '((popwin "0.6.2")
    (popup  "0.5.0")
    (stem   "20130120"))
  :url "https://github.com/logaling/logalimacs"
  :commit "8286e39502250fc6c3c6656a7f46a8eee8e9a713"
  :revdesc "8286e3950225"
  :keywords '("translation" "logaling-command")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
