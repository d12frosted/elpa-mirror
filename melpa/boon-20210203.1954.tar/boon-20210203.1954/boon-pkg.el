(define-package "boon" "20210203.1954" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "6a1a0ce2dca2bde4662a2d040f093bbc385de391")
;; Local Variables:
;; no-byte-compile: t
;; End:
