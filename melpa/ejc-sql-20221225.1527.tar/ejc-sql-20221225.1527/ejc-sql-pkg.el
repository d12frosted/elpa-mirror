(define-package "ejc-sql" "20221225.1527" "Emacs SQL client uses Clojure JDBC."
  '((emacs "26.3")
    (clomacs "0.0.5")
    (dash "2.16.0")
    (spinner "1.7.3"))
  :commit "c02e5c6c5bf98b62af456ddbc9f14bfd39f04333" :authors
  '(("Kostafey" . "kostafey@gmail.com"))
  :maintainer
  '("Kostafey" . "kostafey@gmail.com")
  :keywords
  '("sql" "jdbc")
  :url "https://github.com/kostafey/ejc-sql")
;; Local Variables:
;; no-byte-compile: t
;; End:
