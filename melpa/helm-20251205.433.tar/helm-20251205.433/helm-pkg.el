;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251205.433"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "c84c10cf5f4f7f9d42ac040a6a8149897a86b469"
  :revdesc "c84c10cf5f4f"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
