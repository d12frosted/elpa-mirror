;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260503.2106"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "e2da6276139b736a03bf17445e69540cd5a90015"
  :revdesc "e2da6276139b"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
