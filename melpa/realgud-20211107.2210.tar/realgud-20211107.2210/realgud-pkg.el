(define-package "realgud" "20211107.2210" "A modular front-end for interacting with external debuggers"
  '((load-relative "1.3.1")
    (loc-changes "1.2")
    (test-simple "1.3.0")
    (emacs "25"))
  :commit "9834d3b6f676cd72c8e13d434fd50fcdba17fa5e" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :keywords
  '("debugger" "gdb" "python" "perl" "go" "bash" "zsh" "bashdb" "zshdb" "remake" "trepan" "perldb" "pdb")
  :url "https://github.com/realgud/realgud/")
;; Local Variables:
;; no-byte-compile: t
;; End:
