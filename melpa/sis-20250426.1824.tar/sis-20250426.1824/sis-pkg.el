;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "20250426.1824"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "edab3e54eb0bf4996de6bd48a2bd4e4b0e15701d"
  :revdesc "edab3e54eb0b"
  :keywords '("convenience"))
