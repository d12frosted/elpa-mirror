;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thumb-through" "20120119.534"
  "Plain text reader of HTML documents."
  ()
  :url "https://github.com/apg/thumb-through"
  :commit "08d8fb720f93c6172653e035191a8fa9c3305e63"
  :revdesc "08d8fb720f93"
  :keywords '("html"))
