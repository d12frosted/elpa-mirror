;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260219.1644"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "18ad7b2b03f6caaacb7c11798dd9bbcaf69c5f04"
  :revdesc "18ad7b2b03f6"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
