;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20261023.2029"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.8")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "a6444b66cb1df41cd2465626e69f5e0a00fda9ca"
  :revdesc "a6444b66cb1d"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
