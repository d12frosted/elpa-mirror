(define-package "pyim" "20220607.103" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "25.1")
    (async "1.6")
    (xr "1.13"))
  :commit "f2b43ce74be5238af6452f46e77af2131c068d87" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
