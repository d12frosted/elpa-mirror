;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260303.1357"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.86.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "dc78f1e99f890fe5c2109ae0cc7382fca7a13a79"
  :revdesc "dc78f1e99f89")
