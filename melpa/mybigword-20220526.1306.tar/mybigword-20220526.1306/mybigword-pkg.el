(define-package "mybigword" "20220526.1306" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "25.1"))
  :commit "c49641cdfc33bd23b2a33a30d8aab2206c615cc2" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
