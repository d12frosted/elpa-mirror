(define-package "csound-mode" "20230525.1753" "A major mode for interacting and coding Csound"
  '((emacs "25")
    (shut-up "0.3.2")
    (multi "2.0.1")
    (dash "2.16.0")
    (highlight "0"))
  :commit "e8dc8eb22763482aad9b35dbf325637d2a47639c" :authors
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainer
  '("Hlöðver Sigurðsson" . "hlolli@gmail.com")
  :url "https://github.com/hlolli/csound-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
