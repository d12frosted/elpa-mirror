(define-package "csharp-mode" "20210826.421" "C# mode derived mode"
  '((emacs "26.1"))
  :commit "8b98e8e27e8d11171d035b95b55a4d36935bbe65" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
