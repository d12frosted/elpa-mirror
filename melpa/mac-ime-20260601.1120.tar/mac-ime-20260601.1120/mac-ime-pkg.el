;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mac-ime" "20260601.1120"
  "Seamless macOS IME integration without any IME patches."
  '((emacs "27.1"))
  :url "https://github.com/ma0001/mac-ime"
  :commit "7fbefe2d02977619cb5be584b3497f0042dcdfe8"
  :revdesc "7fbefe2d0297"
  :keywords '("i18n" "convenience"))
