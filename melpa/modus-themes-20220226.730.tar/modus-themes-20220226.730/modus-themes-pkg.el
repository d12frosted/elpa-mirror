(define-package "modus-themes" "20220226.730" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "33df82444444e3c987504857f21d256b3928001e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
