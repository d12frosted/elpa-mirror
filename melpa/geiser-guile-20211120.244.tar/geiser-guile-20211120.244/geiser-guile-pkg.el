(define-package "geiser-guile" "20211120.244" "Guile's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.18"))
  :commit "040b7184e277ff3b3571690f73a13e934477b2c8" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
