;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magent" "20260913.645"
  "AI coding agent."
  '((emacs       "29.1")
    (gptel       "0.9.8")
    (yaml        "1.0.0")
    (compat      "30.1.0.0")
    (acp         "0.13.1")
    (agent-shell "0.66.1"))
  :url "https://github.com/jamie-cui/magent"
  :commit "a0433644709d623eb2b2525065f6e6ce0255245c"
  :revdesc "a0433644709d"
  :keywords '("tools" "ai" "copilot")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
