(define-package "ox-hugo" "20220504.253" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0")
    (tomelr "0"))
  :commit "54c18ec38573d7300cb9dd82656591e45f0ea2a7" :authors
  '(("Kaushal Modi" . "kaushal.modi@gmail.com")
    ("Matt Price" . "moptop99@gmail.com"))
  :maintainer
  '("Kaushal Modi" . "kaushal.modi@gmail.com")
  :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
