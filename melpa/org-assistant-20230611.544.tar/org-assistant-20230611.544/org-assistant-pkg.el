(define-package "org-assistant" "20230611.544" "Org babel extension for Chat Assistant APIs"
  '((emacs "28.1")
    (uuidgen "1.2")
    (deferred "0.5.1")
    (s "1.12.0")
    (dash "2.19.1")
    (ht "0.9"))
  :commit "85977c9894437d0a3e6ed4afb2baa1534e1ddc22" :authors
  '(("Tyler Dodge" . "tyler@tdodge.consulting"))
  :maintainers
  '(("Tyler Dodge" . "tyler@tdodge.consulting"))
  :maintainer
  '("Tyler Dodge" . "tyler@tdodge.consulting")
  :keywords
  '("convenience")
  :url "https://github.com/tyler-dodge/org-assistant")
;; Local Variables:
;; no-byte-compile: t
;; End:
