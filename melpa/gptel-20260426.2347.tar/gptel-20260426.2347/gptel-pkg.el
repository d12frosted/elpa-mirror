;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260426.2347"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "302a1d895e0f92f665a2886eadf2eb4548a080cb"
  :revdesc "302a1d895e0f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
