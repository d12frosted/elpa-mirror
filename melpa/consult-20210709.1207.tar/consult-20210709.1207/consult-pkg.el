(define-package "consult" "20210709.1207" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f17db9520ddd612dc837f4112b6bcbb172acef85" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
