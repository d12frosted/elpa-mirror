(define-package "rust-mode" "20211228.1635" "A major-mode for editing Rust source code"
  '((emacs "25.1"))
  :commit "0099b2c0bb502d77ff61f37c02059e082a9610b6" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages")
  :url "https://github.com/rust-lang/rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
