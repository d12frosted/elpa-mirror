(define-package "matlab-mode" "20230425.1831" "Major mode for MATLAB(R) dot-m files" 'nil :commit "ec53b38dde7081d2d1976e12f2fe1162c13926f1")
;; Local Variables:
;; no-byte-compile: t
;; End:
