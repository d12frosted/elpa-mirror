;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser" "20260426.1726"
  "GNU Emacs and Scheme talk to each other."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://gitlab.com/emacs-geiser/"
  :commit "df9a3d3d8ae10417294c076d5804643441a1efca"
  :revdesc "df9a3d3d8ae1"
  :keywords '("languages" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
