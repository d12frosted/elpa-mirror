;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinboard-api" "20140324.1148"
  "Rudimentary http://pinboard.in integration."
  ()
  :url "https://github.com/danieroux/pinboard-api-el"
  :commit "b7b5214d0c35178f8dca08cf22d6ef3c21f0fce4"
  :revdesc "b7b5214d0c35"
  :keywords '("pinboard" "www")
  :authors '(("Danie Roux" . "danie@danieroux.com"))
  :maintainers '(("Danie Roux" . "danie@danieroux.com")))
