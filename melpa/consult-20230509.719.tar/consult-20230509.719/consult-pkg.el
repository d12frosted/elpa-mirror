(define-package "consult" "20230509.719" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "354fe94e49e8bfaae48192f2690814b54455e277" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
