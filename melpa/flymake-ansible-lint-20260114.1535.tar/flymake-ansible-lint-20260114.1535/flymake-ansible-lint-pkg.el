;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ansible-lint" "20260114.1535"
  "A Flymake backend for ansible-lint."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/flymake-ansible-lint.el"
  :commit "8eadddad5fac18cb5625f70371890813ff9d5b87"
  :revdesc "8eadddad5fac"
  :keywords '("tools"))
