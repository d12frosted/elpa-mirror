(define-package "modus-themes" "20220605.1714" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "6f2b048528d1c40bf5bead0d3e01beff28b78d2b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
