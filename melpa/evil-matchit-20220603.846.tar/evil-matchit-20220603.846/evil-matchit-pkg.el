(define-package "evil-matchit" "20220603.846" "Vim matchit ported to Evil"
  '((emacs "25.1"))
  :commit "a344ac8e495cb6b240a096c67a01399cbdc53895" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
