(define-package "chronometrist-key-values" "20220225.950" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "7cf2c86afd8f6fb6235320ac9f7ebd76153d8bc6" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
