(define-package "arxiv-mode" "20211231.100" "Read and search for articles on arXiv.org"
  '((emacs "27.1")
    (hydra "0"))
  :commit "74105e665758bad77bd67c00435dbee95c83d791" :authors
  '(("Alex Chen (fizban007)" . "fizban007@gmail.com")
    ("Simon Lin (Simon-Lin)" . "n.sibetz@gmail.com"))
  :maintainer
  '("Alex Chen (fizban007)" . "fizban007@gmail.com")
  :keywords
  '("bib" "convenience" "hypermedia")
  :url "https://github.com/fizban007/arxiv-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
