(define-package "epkg" "20221205.2051" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "28.1.1.0")
    (closql "20210927"))
  :commit "0bcd76c4afbb140c80781efa229bb924a286020b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
