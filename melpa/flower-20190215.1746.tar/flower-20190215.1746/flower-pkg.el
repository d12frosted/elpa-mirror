(define-package "flower" "20190215.1746" "Emacs task tracker client."
  '((emacs "24.4")
    (clomacs "0.0.3"))
  :commit "6ef1affa2d7090714ccc4494823de28cfc11da35" :authors
  '(("Sergey Sobko" . "SSobko@ptsecurity.com"))
  :maintainer
  '("Sergey Sobko" . "SSobko@ptsecurity.com")
  :keywords
  '("hypermedia" "outlines" "tools" "vc")
  :url "https://github.com/PositiveTechnologies/flower")
;; Local Variables:
;; no-byte-compile: t
;; End:
