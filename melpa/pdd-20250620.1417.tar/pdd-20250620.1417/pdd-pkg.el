;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250620.1417"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "85f9a096e46e0aaa4809c83bbcb1609fdec07e6e"
  :revdesc "85f9a096e46e"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
