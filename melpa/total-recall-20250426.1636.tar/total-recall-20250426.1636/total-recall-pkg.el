;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "total-recall" "20250426.1636"
  "Spaced repetition system."
  '((emacs "30.1"))
  :url "https://github.com/phf-1/total-recall"
  :commit "3a549a4b4f4dcd6e46abb7681d48e4ecedb87d35"
  :revdesc "3a549a4b4f4d"
  :authors '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com"))
  :maintainers '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com")))
