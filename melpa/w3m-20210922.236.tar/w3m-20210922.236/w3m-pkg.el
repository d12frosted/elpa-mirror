(define-package "w3m" "20210922.236" "an Emacs interface to w3m" 'nil :commit "f596768399039a6c50752b7ed9c091425ef9a959" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
