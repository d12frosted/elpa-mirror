(define-package "websearch" "20220815.1332" "Query search engines"
  '((emacs "24.4"))
  :commit "df943c1c42a17896529a03207ecc173526303825" :authors
  '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainer
  '("Maciej Barć" . "xgqt@riseup.net")
  :keywords
  '("convenience" "hypermedia")
  :url "https://gitlab.com/xgqt/emacs-websearch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
