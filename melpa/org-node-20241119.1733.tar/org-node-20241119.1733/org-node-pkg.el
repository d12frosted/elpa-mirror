;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241119.1733"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (el-job "0.3.4")
    (llama  "0.4.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "8ab82504e02982ae783e6235b7dbe803b0a70cb5"
  :revdesc "8ab82504e029"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
