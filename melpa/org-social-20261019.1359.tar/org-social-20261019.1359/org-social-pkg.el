;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20261019.1359"
  "An Org-social client."
  '((emacs            "30.1")
    (org              "9.0")
    (request          "0.3.0")
    (seq              "2.20")
    (emojify          "1.2")
    (async-http-queue "0.1"))
  :url "https://git.andros.dev/org-social/org-social.el"
  :commit "5883d53646faeb048d91ce052d15bcdde50d5f1a"
  :revdesc "5883d53646fa"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
