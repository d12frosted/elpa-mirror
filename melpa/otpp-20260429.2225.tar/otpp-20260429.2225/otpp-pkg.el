;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260429.2225"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "04d0c764a37b448885d18cb461b6cb45f9854de0"
  :revdesc "04d0c764a37b"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
