;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-template-helper-mode" "20260124.2229"
  "Go text/template overlay highlighting (Helm/YAML)."
  '((emacs "28.1"))
  :url "https://codeberg.org/rch/go-template-helper-mode"
  :commit "e13b09d9176dd88e65c4bea5eb5c878242ea7e13"
  :revdesc "e13b09d9176d"
  :keywords '("tools" "faces")
  :authors '(("Robert Charusta" . "rch-public@posteo.net"))
  :maintainers '(("Robert Charusta" . "rch-public@posteo.net")))
