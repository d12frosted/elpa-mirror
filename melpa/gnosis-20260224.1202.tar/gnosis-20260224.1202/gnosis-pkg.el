;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260224.1202"
  "Knowledge System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.2.0"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "efac49bb1c55779d41d1f0aa22a0fb18486b6722"
  :revdesc "efac49bb1c55"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
