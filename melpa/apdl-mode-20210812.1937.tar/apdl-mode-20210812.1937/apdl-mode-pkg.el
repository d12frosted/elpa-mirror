(define-package "apdl-mode" "20210812.1937" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "c1b1ab4cd2fa9bdd429e77fd4f5b792f25f8d741" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
