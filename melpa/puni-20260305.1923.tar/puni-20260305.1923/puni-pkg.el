;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "puni" "20260305.1923"
  "Parentheses Universalistic."
  '((emacs "26.1"))
  :url "https://github.com/AmaiKinono/puni"
  :commit "fe132f803868f325cf6f162139e327b76df9e4c1"
  :revdesc "fe132f803868"
  :keywords '("convenience" "lisp" "tools")
  :authors '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainers '(("Hao Wang" . "amaikinono@gmail.com")))
