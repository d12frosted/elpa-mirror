;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20241231.143"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "5558d9016699b784d90ceb11025b54e505c2d7ac"
  :revdesc "5558d9016699"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
