;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-rich-yank" "20260924.1340"
  "Paste with org-mode markup and link to source."
  '((emacs "25.1"))
  :url "https://github.com/unhammer/org-rich-yank"
  :commit "f246cd3d27b8ca61f0a1ccff83309b3e3ef3d45e"
  :revdesc "f246cd3d27b8"
  :keywords '("convenience" "hypermedia" "org")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
