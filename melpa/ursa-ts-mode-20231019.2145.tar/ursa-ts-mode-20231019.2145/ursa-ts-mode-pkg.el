(define-package "ursa-ts-mode" "20231019.2145" "Major mode for Ursa, using tree-sitter"
  '((emacs "29.1"))
  :commit "e5cb898e831976d9ac0e5b73e676a7976a77e693" :authors
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("ursalang" "languages" "tree-sitter")
  :url "https://github.com/ursalang/ursa-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
