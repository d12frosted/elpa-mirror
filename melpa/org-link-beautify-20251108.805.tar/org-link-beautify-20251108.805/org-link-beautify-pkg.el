;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20251108.805"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "e554e9ff22de880d2cc0c676c40de8428171f800"
  :revdesc "e554e9ff22de"
  :keywords '("hypermedia"))
