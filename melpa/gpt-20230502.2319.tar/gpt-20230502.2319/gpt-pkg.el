(define-package "gpt" "20230502.2319" "Run instruction-following language models"
  '((emacs "24.4"))
  :commit "a38c152caa99ca30af86040907f70b027173c19d" :authors
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainers
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainer
  '("Andreas Stuhlmueller" . "andreas@ought.org")
  :keywords
  '("gpt3" "language" "copilot" "convenience" "tools")
  :url "https://github.com/stuhlmueller/gpt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
