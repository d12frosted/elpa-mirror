;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260528.813"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "d001ee4d0372a327c11e15671c2864ba6efd2ee3"
  :revdesc "d001ee4d0372"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
