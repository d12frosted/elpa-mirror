;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ormolu" "20220530.921"
  "Format Haskell source code using the \"ormolu\" program."
  '((emacs       "24")
    (reformatter "0.4"))
  :url "https://github.com/vyorkin/ormolu.el"
  :commit "a6b1d3f8838d067ac5352fb0673c3c3dae7abd73"
  :revdesc "a6b1d3f8838d"
  :keywords '("files" "tools")
  :authors '(("Vasiliy Yorkin" . "vasiliy.yorkin@gmail.com")))
