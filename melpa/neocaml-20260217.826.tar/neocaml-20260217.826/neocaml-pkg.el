;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260217.826"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "4218ba706816659708e2f9cc56fa224dac090e19"
  :revdesc "4218ba706816"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
