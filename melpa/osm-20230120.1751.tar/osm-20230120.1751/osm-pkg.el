(define-package "osm" "20230120.1751" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.1.1"))
  :commit "360b91c8aab8891ecc8c47a9c5dc9a0e1ad19f01" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
