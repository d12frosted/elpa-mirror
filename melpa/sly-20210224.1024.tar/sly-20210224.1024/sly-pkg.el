(define-package "sly" "20210224.1024" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "fb84318c08f59bc786e047006fc81e2ace568309" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
