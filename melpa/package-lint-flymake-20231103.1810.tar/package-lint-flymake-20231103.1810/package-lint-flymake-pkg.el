(define-package "package-lint-flymake" "20231103.1810" "A package-lint Flymake backend"
  '((emacs "26.1")
    (package-lint "0.5"))
  :commit "5eba825d657b490c320b2ea2c302b1fa0c999610" :url "https://github.com/purcell/package-lint")
;; Local Variables:
;; no-byte-compile: t
;; End:
