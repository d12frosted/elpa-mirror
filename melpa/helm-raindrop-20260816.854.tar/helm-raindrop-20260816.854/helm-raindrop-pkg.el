;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-raindrop" "20260816.854"
  "Raindrop.io with helm interface."
  '((emacs   "29.1")
    (helm    "4.0.4")
    (request "0.3.2"))
  :url "https://github.com/masutaka/emacs-helm-raindrop"
  :commit "4bd33fb9c525052865976d1ab440d8492754307d"
  :revdesc "4bd33fb9c525"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
