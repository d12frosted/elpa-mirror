(define-package "call-graph" "20230117.926" "Generate call graph for c/c++ functions"
  '((emacs "25.1")
    (hierarchy "0.7.0")
    (tree-mode "1.0.0")
    (ivy "0.10.0"))
  :commit "f2849d394427d5753fc1ded1533922f84a5da73f" :authors
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainer
  '("Huming Chen" . "chenhuming@gmail.com")
  :keywords
  '("programming" "convenience")
  :url "https://github.com/beacoder/call-graph")
;; Local Variables:
;; no-byte-compile: t
;; End:
