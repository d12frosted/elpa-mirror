;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20261008.412"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "ae070aeaecf9bb467ccc9f5e06e5b67b960e7a4d"
  :revdesc "ae070aeaecf9"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
