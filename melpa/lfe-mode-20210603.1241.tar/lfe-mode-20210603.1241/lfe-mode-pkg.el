(define-package "lfe-mode" "20210603.1241" "Lisp Flavoured Erlang mode" 'nil :commit "86a922b40f8eb042a4880e9b73f39b74607dfb09")
;; Local Variables:
;; no-byte-compile: t
;; End:
