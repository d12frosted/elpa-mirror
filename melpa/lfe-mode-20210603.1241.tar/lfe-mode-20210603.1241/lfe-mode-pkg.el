(define-package "lfe-mode" "20210603.1241" "Lisp Flavoured Erlang mode" 'nil :commit "8d609fa22d281dcbfd6dac5aea34203491130194")
;; Local Variables:
;; no-byte-compile: t
;; End:
