(define-package "lfe-mode" "20210603.1241" "Lisp Flavoured Erlang mode" 'nil :commit "24d8784b5c8527bbcaca85d8a909c2cdafc1186f")
;; Local Variables:
;; no-byte-compile: t
;; End:
