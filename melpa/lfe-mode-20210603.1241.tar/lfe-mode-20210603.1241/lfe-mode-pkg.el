(define-package "lfe-mode" "20210603.1241" "Lisp Flavoured Erlang mode" 'nil :commit "1ed7cf7890b8720284fc4b8331422b4dc38556ae")
;; Local Variables:
;; no-byte-compile: t
;; End:
