(define-package "lfe-mode" "20210603.1241" "Lisp Flavoured Erlang mode" 'nil :commit "8a410905b8c7f74d955db4bbbd58823edf5293c8")
;; Local Variables:
;; no-byte-compile: t
;; End:
