;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20251001.1855"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "a1dc8b518e6a3345082acf139d402211e27406ad"
  :revdesc "a1dc8b518e6a"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
