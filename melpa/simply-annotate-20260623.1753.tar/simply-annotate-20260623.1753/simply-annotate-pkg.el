;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260623.1753"
  "Enhanced annotation system with threading."
  '((emacs     "27.2")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "8a080d5dfcb2c9960cbdefb1009dbbb0ddd56a04"
  :revdesc "8a080d5dfcb2"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
