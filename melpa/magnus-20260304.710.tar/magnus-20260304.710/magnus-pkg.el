;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260304.710"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "cf7809167de447d5bc57551178302d153c1c6c12"
  :revdesc "cf7809167de4"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
