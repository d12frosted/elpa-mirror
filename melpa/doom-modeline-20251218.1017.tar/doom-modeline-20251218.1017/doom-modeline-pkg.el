;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20251218.1017"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "c6fc9aa7a06025ae5887975243b08d36e3caff68"
  :revdesc "c6fc9aa7a060"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
