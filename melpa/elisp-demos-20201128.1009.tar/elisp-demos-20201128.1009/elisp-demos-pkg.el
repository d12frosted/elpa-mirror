(define-package "elisp-demos" "20201128.1009" "Elisp API Demos"
  '((emacs "24.4"))
  :commit "ed9578dfdbbdd6874d497fc9873ebfe09f869570" :authors
  (("Xu Chunyang"))
  :maintainer
  ("Xu Chunyang")
  :keywords
  ("lisp" "docs")
  :url "https://github.com/xuchunyang/elisp-demos")
;; Local Variables:
;; no-byte-compile: t
;; End:
