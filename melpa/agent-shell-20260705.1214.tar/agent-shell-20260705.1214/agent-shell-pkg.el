;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260705.1214"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8c7eea8f33c5d0d32eae6772d8c3b47f2ecb9228"
  :revdesc "8c7eea8f33c5")
