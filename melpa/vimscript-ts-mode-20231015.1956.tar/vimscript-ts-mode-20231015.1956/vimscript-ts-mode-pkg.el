(define-package "vimscript-ts-mode" "20231015.1956" "Vim-script major mode using tree-sitter"
  '((emacs "29.1"))
  :commit "a97aa5c671ef4267309450506e60843608e22c23" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("languages" "vim" "tree-sitter")
  :url "https://github.com/nverno/vimscript-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
