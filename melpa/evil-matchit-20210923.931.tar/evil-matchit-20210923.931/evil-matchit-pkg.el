(define-package "evil-matchit" "20210923.931" "Vim matchit ported to Evil"
  '((evil "1.14.0")
    (emacs "25.1"))
  :commit "ce90eae4bd31eb2cfe450266a5340f5eb43d78ec" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
