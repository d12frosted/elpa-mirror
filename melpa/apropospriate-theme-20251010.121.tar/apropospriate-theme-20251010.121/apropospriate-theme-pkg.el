;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apropospriate-theme" "20251010.121"
  "A light & dark theme set for Emacs."
  ()
  :url "https://github.com/waymondo/apropospriate-theme"
  :commit "2b26eed7e2063ca93998a6807f5a4e602483a23d"
  :revdesc "2b26eed7e206"
  :authors '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainers '(("Justin Talbott" . "justin@waymondo.com")))
