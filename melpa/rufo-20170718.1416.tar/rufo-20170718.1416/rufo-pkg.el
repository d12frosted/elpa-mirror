;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rufo" "20170718.1416"
  "Use rufo to automatically format ruby files."
  '((emacs "24.3"))
  :url "https://github.com/danielma/rufo.el"
  :commit "85a6d80fb05fef396a8029b8f944c92a53faf8fe"
  :revdesc "85a6d80fb05f"
  :authors '(("Daniel Ma and contributors" . "danielhgma@gmail.com"))
  :maintainers '(("Daniel Ma and contributors" . "danielhgma@gmail.com")))
