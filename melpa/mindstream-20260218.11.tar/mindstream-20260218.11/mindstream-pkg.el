;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mindstream" "20260218.11"
  "Start writing, stay focused, don't worry."
  '((emacs "28.1")
    (magit "3.3.0"))
  :url "https://github.com/countvajhula/mindstream"
  :commit "229c3084feca67f3bc592a26abbf5d2d77cf28c1"
  :revdesc "229c3084feca"
  :keywords '("convenience" "files" "languages" "outlines" "tools" "vc" "wp")
  :authors '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Siddhartha Kasivajhula" . "sid@countvajhula.com")))
