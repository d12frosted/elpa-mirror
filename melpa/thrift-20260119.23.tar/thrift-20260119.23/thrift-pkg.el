;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260119.23"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "6703ee890ae89ff265f4a43373b91e72322af64b"
  :revdesc "6703ee890ae8"
  :keywords '("languages"))
