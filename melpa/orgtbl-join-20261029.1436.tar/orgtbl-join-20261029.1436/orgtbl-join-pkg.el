;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20261029.1436"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "4f718b56ffee2f17a1d5ae2127e3acaef6ba0c29"
  :revdesc "4f718b56ffee"
  :keywords '("data" "extensions"))
