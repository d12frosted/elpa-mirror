;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "use-package-x" "20260904.2104"
  "Additional keywords for use-package."
  '((emacs       "30.1")
    (compat      "31")
    (use-package "2.4"))
  :url "https://github.com/DevelopmentCool2449/use-package-x"
  :commit "84fa4a4ed65a5f6c13a90d1827d6d2a90af3a5a9"
  :revdesc "84fa4a4ed65a"
  :keywords '("convenience" "extensions")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Elias G. Perez" . "eg642616@gmail.com")))
