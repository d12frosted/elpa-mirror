(define-package "dirvish" "20220319.546" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "558df68ffebe8248d4654f4691c047917ad07dee" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
