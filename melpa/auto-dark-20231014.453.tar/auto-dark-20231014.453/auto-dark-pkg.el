(define-package "auto-dark" "20231014.453" "Automatically sets the dark-mode theme based on macOS/Linux/Windows status"
  '((emacs "24.4"))
  :commit "65cc6337de9030ea7cae4661389019b9443543a2" :authors
  '(("Rahul M. Juliato")
    ("Tim Harper <timcharper at gmail dot com>")
    ("Vincent Zhang" . "seagle0128@gmail.com")
    ("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers
  '(("Rahul M. Juliato"))
  :maintainer
  '("Rahul M. Juliato")
  :keywords
  '("macos" "windows" "linux" "themes" "tools" "faces")
  :url "https://github.com/LionyxML/auto-dark-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
