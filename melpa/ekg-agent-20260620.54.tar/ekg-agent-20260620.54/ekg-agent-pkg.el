;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260620.54"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "875171178c64315b8bead9faf608770cff57fb20"
  :revdesc "875171178c64"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
