;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260703.1829"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c91b20c29e5512fc7dc340d22c265b9ff377b741"
  :revdesc "c91b20c29e55")
