(define-package "modus-themes" "20230205.1540" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "e1d107563521388c410a64cc9c451a319d3fd833" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
