(define-package "buttercup" "20220814.2150" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "e2b77ac49cc61c32566f22b84ba304a5703ff7b3" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
