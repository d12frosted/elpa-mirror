;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260131.1344"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "ec8a106d077536929251520374fabddcdaf6f06b"
  :revdesc "ec8a106d0775"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
