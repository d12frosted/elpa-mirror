(define-package "kotlin-ts-mode" "20231026.958" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "0472c9346e30f8499c87938a323c733628a0dd26" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
