(define-package "modus-themes" "20201212.724" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "15e611b65c9557ec607dcfbba820bbf262b345df" :keywords
  ("faces" "theme" "accessibility")
  :authors
  (("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  ("Protesilaos Stavrou" . "info@protesilaos.com")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
