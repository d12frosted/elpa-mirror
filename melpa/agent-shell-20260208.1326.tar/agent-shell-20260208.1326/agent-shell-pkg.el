;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260208.1326"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6203c326d4315b33a890b53d88e91eaab5051d43"
  :revdesc "6203c326d431")
