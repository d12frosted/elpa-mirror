;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comint-histories" "20260323.1914"
  "Many comint histories."
  '((emacs "25.1")
    (f     "0.21.0"))
  :url "https://github.com/NicholasBHubbard/comint-histories"
  :commit "7a494daf47b6dc51f5ffdd5e737837592647201f"
  :revdesc "7a494daf47b6"
  :keywords '("convenience" "processes" "terminals")
  :authors '(("Nicholas Hubbard" . "nicholashubbard@posteo.net"))
  :maintainers '(("Nicholas Hubbard" . "nicholashubbard@posteo.net")))
