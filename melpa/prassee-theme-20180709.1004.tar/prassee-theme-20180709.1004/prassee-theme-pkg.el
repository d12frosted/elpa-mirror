;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prassee-theme" "20180709.1004"
  "A high contrast color theme for Emacs."
  '((emacs "24"))
  :url "https://github.com/prassee/prassee-emacs-theme"
  :commit "81126f69cdbaab836c00ae7a49aaf89d4229fde1"
  :revdesc "81126f69cdba"
  :keywords '("dark" "high-contrast" "faces")
  :authors '(("Prassee" . "prassee.sathian@gmail.com"))
  :maintainers '(("Prassee" . "prassee.sathian@gmail.com")))
