;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "20241229.1811"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "https://github.com/szermatt/visual-replace"
  :commit "b10d7541dd5d6fe5ed0b82189fecf0bbe19edbd2"
  :revdesc "b10d7541dd5d"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
