;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-interpolation" "20131112.1652"
  "Ruby string interpolation helpers."
  ()
  :url "https://github.com/leoc/ruby-interpolation.el"
  :commit "1978e337601222cedf00e117bf4b5cac15d1f203"
  :revdesc "1978e3376012"
  :authors '(("Arthur Leonard Andersen" . "leoc.git@gmail.com"))
  :maintainers '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")))
