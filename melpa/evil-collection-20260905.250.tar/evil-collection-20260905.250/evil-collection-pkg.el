;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260905.250"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "96fe4a44edeab034b70fcc16cda850f247334446"
  :revdesc "96fe4a44edea"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
