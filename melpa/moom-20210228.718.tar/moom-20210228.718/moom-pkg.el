(define-package "moom" "20210228.718" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "a756418dde112a67c4c68355bee46ef17fc45d07" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
