(define-package "wucuo" "20211201.1214" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "09fc58a02621b6c9615f8289c457e30ca6f63bcb" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
