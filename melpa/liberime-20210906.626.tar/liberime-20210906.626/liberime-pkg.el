(define-package "liberime" "20210906.626" "Rime elisp binding"
  '((emacs "25.1"))
  :commit "8291e22cd0990a99cb2f88ca67a9065a157f39af" :authors
  '(("A.I."))
  :maintainer
  '("A.I.")
  :keywords
  '("convenience" "chinese" "input-method" "rime")
  :url "https://github.com/merrickluo/liberime")
;; Local Variables:
;; no-byte-compile: t
;; End:
