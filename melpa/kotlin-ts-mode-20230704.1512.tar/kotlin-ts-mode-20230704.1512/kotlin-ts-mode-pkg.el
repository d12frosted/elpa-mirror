(define-package "kotlin-ts-mode" "20230704.1512" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29"))
  :commit "85d614f9a3952bc744b597dcd55e83e83a413f31" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
