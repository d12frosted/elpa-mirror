;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241016.1139"
  "ChatGPT shell + buffer insert commands."
  '((emacs       "27.1")
    (shell-maker "0.53.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "15635913194d2001b2eb1f196a5f7d58646f0bbf"
  :revdesc "15635913194d")
