;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260328.327"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "f70e517f7dedb277cd70d31fb4c459966a4316a5"
  :revdesc "f70e517f7ded"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
