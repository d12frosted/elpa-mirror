;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-view-data" "20260816.1213"
  "View data in python."
  '((emacs  "28.1")
    (python "0.2"))
  :url "https://github.com/ShuguangSun/python-view-data"
  :commit "a3e4b96e6510eb2ccabd3faadd0dba0554318302"
  :revdesc "a3e4b96e6510"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
