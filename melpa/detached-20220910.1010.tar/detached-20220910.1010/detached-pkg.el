(define-package "detached" "20220910.1010" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "ee0821fd9799ec4c89ad65d34b8bed10728d74d9" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
