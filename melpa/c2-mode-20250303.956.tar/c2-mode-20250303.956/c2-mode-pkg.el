;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "c2-mode" "20250303.956"
  "Major mode for C2 programming language."
  '((emacs "24.3"))
  :url "https://github.com/easimonenko/c2-mode"
  :commit "e3cc3a94f88d98e5a1b9086a4ad480009040a1ed"
  :revdesc "e3cc3a94f88d"
  :keywords '("languages" "c2")
  :authors '(("Evgeny Simonenko" . "easimonenko@gmail.com"))
  :maintainers '(("Evgeny Simonenko" . "easimonenko@gmail.com")))
