;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dim-autoload" "20260521.1204"
  "Dim or hide autoload cookie lines."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/dim-autoload"
  :commit "fc238d7a2b4ecbcde163aad573bf2637274b49a4"
  :revdesc "fc238d7a2b4e"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.dim-autoload@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.dim-autoload@jonas.bernoulli.dev")))
