;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fedi" "20250714.632"
  "Helper functions for fediverse clients."
  '((emacs         "28.1")
    (markdown-mode "2.5"))
  :url "https://codeberg.org/martianh/fedi.el"
  :commit "1ba7f340913ee8499462935e40349b805e7b8a16"
  :revdesc "1ba7f340913e"
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
