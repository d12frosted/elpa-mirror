(define-package "teleport" "20231122.1737" "Integration for tsh (goteleport.com)"
  '((emacs "27.1")
    (dash "2.18.0"))
  :commit "4db64adf8e6d4c8b12035569fbd40a0eb91d6d6c" :authors
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainers
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainer
  '("Caramel Hooves" . "caramel.hooves@protonmail.com")
  :keywords
  '("tools")
  :url "https://github.com/caramelhooves/teleport.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
