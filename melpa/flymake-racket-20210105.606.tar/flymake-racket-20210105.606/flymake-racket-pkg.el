;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-racket" "20210105.606"
  "Flymake extension for Racket."
  '((emacs "26.1"))
  :url "https://github.com/jojojames/flymake-racket"
  :commit "3d3e5f2a9ab696670f9e52baa4dde7b84b7542df"
  :revdesc "3d3e5f2a9ab6"
  :keywords '("languages" "racket" "scheme")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
