;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250629.1453"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "a7568f471cb335caeda44c1eb172a6263930df0d"
  :revdesc "a7568f471cb3"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
