;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-glsl" "20210109.1403"
  "Support glsl in company-mode."
  '((company   "0.9.4")
    (glsl-mode "2.4")
    (emacs     "24.4"))
  :url "https://github.com/guidoschmidt/company-glsl"
  :commit "3a40501ba831a30a7fd3e8529b20d1305d0454aa"
  :revdesc "3a40501ba831"
  :authors '(("Guido Schmidt" . "git@guidoschmidt.cc"))
  :maintainers '(("Guido Schmidt" . "git@guidoschmidt.cc")))
