(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "ccdd3681b9e7d8b6a758f2aa61a0ae8eab21240b" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
