(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "70b985b1d00c8703acb1ebf16875616903470f45" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
