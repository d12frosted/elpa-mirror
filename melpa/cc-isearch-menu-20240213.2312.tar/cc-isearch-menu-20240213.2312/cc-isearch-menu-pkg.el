(define-package "cc-isearch-menu" "20240213.2312" "A Transient menu for isearch"
  '((emacs "29.1"))
  :commit "a5e24c5b4cd88d0192c633543a9fcd16084d05f0" :authors
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainer
  '("Charles Choi" . "kickingvegas@gmail.com")
  :keywords
  '("wp")
  :url "https://github.com/kickingvegas/cc-isearch-menu")
;; Local Variables:
;; no-byte-compile: t
;; End:
