;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260426.2034"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "75fe69fbe515a54f83de48f5b1807b0fac67c1ff"
  :revdesc "75fe69fbe515"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
