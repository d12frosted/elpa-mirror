(define-package "elisp-autofmt" "20230731.1350" "Emacs lisp auto-format"
  '((emacs "29.1"))
  :commit "f2bd5119861bbcd3ebada76d44441ce96de49bed" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
