(define-package "ebib" "20211210.1038" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "6af31ec0a351916f6703157cc03dd6aaf403c660" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
