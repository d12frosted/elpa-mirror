;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260227.1701"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "f44ea50308b1afe913b75dfc18e6280e52fd21b4"
  :revdesc "f44ea50308b1"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
