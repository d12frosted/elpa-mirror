(define-package "js2-mode" "20211201.1250" "Improved JavaScript editing mode"
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "548087f1555fac01df45bf3a47949761343d6372" :authors
  '(("Steve Yegge" . "steve.yegge@gmail.com")
    ("mooz" . "stillpedant@gmail.com")
    ("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Steve Yegge" . "steve.yegge@gmail.com")
  :keywords
  '("languages" "javascript")
  :url "https://github.com/mooz/js2-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
