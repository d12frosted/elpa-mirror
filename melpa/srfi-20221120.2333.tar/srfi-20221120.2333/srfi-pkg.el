(define-package "srfi" "20221120.2333" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "708cf6434dc1af42cd756d3daceaa569553862ab" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
