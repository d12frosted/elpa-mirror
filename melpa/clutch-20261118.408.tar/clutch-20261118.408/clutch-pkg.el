;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261118.408"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "19943ec9ca10c58e09319e1700867e828ba8a6b2"
  :revdesc "19943ec9ca10"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
