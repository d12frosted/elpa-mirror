(define-package "magit-section" "20220101.841" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "a6ab38b7017d14aa62d0d2b95b7a8a4668781ab0" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
