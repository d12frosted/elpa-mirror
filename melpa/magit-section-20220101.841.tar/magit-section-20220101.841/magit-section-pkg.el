(define-package "magit-section" "20220101.841" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "2a6b51b7f1b2d35f1dd3ec7b158362263fab77cc" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
