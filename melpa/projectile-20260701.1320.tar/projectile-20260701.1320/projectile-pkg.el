;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260701.1320"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "7bf37c23cd63f9593a434413928bcaac596ddbd6"
  :revdesc "7bf37c23cd63"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
