(define-package "humanoid-themes" "20231214.2157" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "a9e3ad8b245a1c95a2aca9bbe3c664202d8bf162" :authors
  '(("Thomas Friese"))
  :maintainers
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
