(define-package "modus-themes" "20230405.456" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "ede2ab0e0ff43b25fdac24a9946a95be705eff95" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
