;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "racket-mode" "20250423.1838"
  "Racket editing, REPL, and more."
  '((emacs "25.1"))
  :url "https://www.racket-mode.com/"
  :commit "aca07851659baaebb0c91e70554c45879746af9b"
  :revdesc "aca07851659b"
  :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")))
