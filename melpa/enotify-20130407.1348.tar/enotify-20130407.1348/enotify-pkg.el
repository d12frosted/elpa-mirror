(define-package "enotify" "20130407.1348" "A networked notification system for emacs" 'nil :commit "7fd2f48ef4ff32c8f013c634ea2dd6b1d1409f80")
;; Local Variables:
;; no-byte-compile: t
;; End:
