;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enotify" "20130407.1348"
  "A networked notification system for Emacs."
  ()
  :url "https://github.com/laynor/enotify"
  :commit "7fd2f48ef4ff32c8f013c634ea2dd6b1d1409f80"
  :revdesc "7fd2f48ef4ff"
  :keywords '("tools")
  :authors '(("Alessandro Piras" . "laynor@gmail.com"))
  :maintainers '(("Alessandro Piras" . "laynor@gmail.com")))
