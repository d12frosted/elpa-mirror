;;; enotify.el ends here
