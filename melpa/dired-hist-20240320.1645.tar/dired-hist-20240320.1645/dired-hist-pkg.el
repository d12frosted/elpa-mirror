(define-package "dired-hist" "20240320.1645" "Traverse Dired buffer's history: back, forward"
  '((emacs "27.1"))
  :commit "08633398ef90bb90a343aaeaff33fd26fa98da1e" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
    ("Anoncheg1"))
  :maintainers
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience" "dired" "history")
  :url "https://github.com/Anoncheg1/dired-hist")
;; Local Variables:
;; no-byte-compile: t
;; End:
