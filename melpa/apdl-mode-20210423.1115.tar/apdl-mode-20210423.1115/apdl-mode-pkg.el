(define-package "apdl-mode" "20210423.1115" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "5e9de43494cc307a3b43b0eebf774c03670a4582" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
