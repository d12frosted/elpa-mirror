(define-package "sage-shell-mode" "20201108.943" "A front-end for Sage Math"
  '((cl-lib "0.6.1")
    (emacs "24.4")
    (let-alist "1.0.5")
    (deferred "0.5.1"))
  :commit "c19c3c681142154d6068d1e0236fea825eda2fe2" :keywords
  ("sage" "math")
  :authors
  (("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainer
  ("Sho Takemori" . "stakemorii@gmail.com")
  :url "https://github.com/sagemath/sage-shell-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
