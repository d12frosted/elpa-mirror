;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260404.2018"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "cbda219e3a2e353208e56805ef0f431151793c00"
  :revdesc "cbda219e3a2e"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
