;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stillness-mode" "20260826.1610"
  "Prevent windows from jumping on minibuffer activation."
  '((emacs "26.1")
    (dash  "2.18.0"))
  :url "https://github.com/neeasade/stillness-mode.el"
  :commit "835b7fdcb40f2e183eab4157092a882fb52950f6"
  :revdesc "835b7fdcb40f"
  :keywords '("convenience"))
