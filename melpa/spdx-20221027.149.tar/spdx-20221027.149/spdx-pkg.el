(define-package "spdx" "20221027.149" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "023d666010f2dc86e32aa5c6553e88f07997236b" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
