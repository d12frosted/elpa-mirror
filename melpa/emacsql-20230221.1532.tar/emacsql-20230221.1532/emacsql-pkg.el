(define-package "emacsql" "20230221.1532" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "f0249f655fd1a2c066c5a1b3daa93c80c5ed9865" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
