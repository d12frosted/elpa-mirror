;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quiz" "20260408.1503"
  "Multiple choice quiz game."
  '((emacs "25.1"))
  :url "https://github.com/davep/quiz.el"
  :commit "e23b5d83f9209b950564553a805688b0bdd59d72"
  :revdesc "e23b5d83f920"
  :keywords '("games" "trivia" "quiz")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
