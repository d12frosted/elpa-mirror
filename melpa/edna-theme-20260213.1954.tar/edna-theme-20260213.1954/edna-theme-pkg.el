;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edna-theme" "20260213.1954"
  "A dark, Edna-inspired theme."
  '((emacs "26.1"))
  :url "https://codeberg.org/golanv/edna-theme"
  :commit "9d78518745d84f8f712b57ebba2855e2dddfa535"
  :revdesc "9d78518745d8"
  :keywords '("faces" "theme")
  :authors '(("golanv" . "https://codeberg.org/golanv"))
  :maintainers '(("golanv" . "https://codeberg.org/golanv")))
