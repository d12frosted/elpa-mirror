;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260310.1959"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "9ef717b04e248314fa67cfe4eeae07ea33d3cda4"
  :revdesc "9ef717b04e24")
