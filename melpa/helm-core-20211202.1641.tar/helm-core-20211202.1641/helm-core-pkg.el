(define-package "helm-core" "20211202.1641" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "05b9af36b7c6f73296b31f43c989482f2897c8e7")
;; Local Variables:
;; no-byte-compile: t
;; End:
