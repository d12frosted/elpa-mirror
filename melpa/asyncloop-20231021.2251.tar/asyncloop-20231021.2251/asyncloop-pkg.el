(define-package "asyncloop" "20231021.2251" "Non-blocking series of functions"
  '((emacs "28.1"))
  :commit "8ab4e373e7bd3217cad4d4130ac765abc5b83add" :authors
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainers
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainer
  '(nil . "<meedstrom91@gmail.com>")
  :keywords
  '("tools")
  :url "https://github.com/meedstrom/asyncloop")
;; Local Variables:
;; no-byte-compile: t
;; End:
