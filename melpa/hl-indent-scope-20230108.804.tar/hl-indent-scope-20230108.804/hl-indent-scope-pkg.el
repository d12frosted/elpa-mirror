(define-package "hl-indent-scope" "20230108.804" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "9c9fa7e5aa4d718a88421b1a830548fd61d90f55" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
