;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "total-recall" "20250426.2040"
  "Spaced repetition system."
  '((emacs "30.1"))
  :url "https://github.com/phf-1/total-recall"
  :commit "72659011a1167f7aec087ddaa9702acd52fcd69d"
  :revdesc "72659011a116"
  :authors '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com"))
  :maintainers '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com")))
