(define-package "ox-pandoc" "20231221.1300" "An Org-mode exporter using pandoc"
  '((org "8.2")
    (emacs "24.4")
    (dash "2.8")
    (ht "2.0"))
  :commit "b91a58202e5f7c641d2883e0c22f586f3293c351" :authors
  '(("KAWABATA, Taichi" . "kawabata.taichi@gmail.com")
    ("FENTON, Alex" . "a-fent@github"))
  :maintainers
  '(("FENTON, Alex" . "a-fent@github"))
  :maintainer
  '("FENTON, Alex" . "a-fent@github")
  :keywords
  '("tools")
  :url "https://github.com/a-fent/ox-pandoc")
;; Local Variables:
;; no-byte-compile: t
;; End:
