(define-package "pg" "20230423.839" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "26.1"))
  :commit "5a7523fee364e8fabf24eeaac3dac2991ef64187" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
