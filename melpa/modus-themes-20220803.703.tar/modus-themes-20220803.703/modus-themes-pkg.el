(define-package "modus-themes" "20220803.703" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "f04842805f2c07b78b210e9f97a75c3c2dc400ae" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
