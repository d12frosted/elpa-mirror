;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ttx-mode" "20260504.1858"
  "TrueType/OpenType font viewer using ttx."
  '((emacs "30.0"))
  :url "https://github.com/wmedrano/ttx-mode"
  :commit "11720c3623e38b054967653278d18ab480609213"
  :revdesc "11720c3623e3"
  :keywords '("tools" "fonts")
  :authors '(("Will Medrano" . "will@wmedrano.dev"))
  :maintainers '(("Will Medrano" . "will@wmedrano.dev")))
