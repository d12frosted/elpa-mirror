(define-package "helm-core" "20220617.518" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "7cd4a463153447c8dd7ad60173ccabfe8a367d55" :authors
  '(("Thierry Volpiatto "))
  :maintainer
  '("Thierry Volpiatto ")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
