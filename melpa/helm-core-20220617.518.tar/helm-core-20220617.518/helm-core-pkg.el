(define-package "helm-core" "20220617.518" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "6b95028425b5ac7567a046e762d2df2b6c443132" :authors
  '(("Thierry Volpiatto "))
  :maintainer
  '("Thierry Volpiatto ")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
