(define-package "gruvbox-theme" "20220801.1506" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "0abbbe5f7fe464fc127a05a8616b65caf5116dc8" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
