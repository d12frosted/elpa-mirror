;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250411.1734"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "eb3058e44df3d694cd7b24e0bbb6f92e831ea53d"
  :revdesc "eb3058e44df3"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
