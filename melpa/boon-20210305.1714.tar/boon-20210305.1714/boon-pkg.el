(define-package "boon" "20210305.1714" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "948501463dc2c63e133dda3b3ed28f4c81d24d26")
;; Local Variables:
;; no-byte-compile: t
;; End:
