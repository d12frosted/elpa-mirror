;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jjdescription" "20251007.1951"
  "Major mode for editing Jujutsu description files."
  '((emacs "25.1"))
  :url "https://github.com/necaris/jjdescription.el"
  :commit "883a3b9d5a400495f0b7ec87220633ad0502c894"
  :revdesc "883a3b9d5a40"
  :authors '(("Rami Chowdhury" . "rami.chowdhury@gmail.com"))
  :maintainers '(("Rami Chowdhury" . "rami.chowdhury@gmail.com")))
