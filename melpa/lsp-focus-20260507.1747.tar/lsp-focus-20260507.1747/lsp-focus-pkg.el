;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-focus" "20260507.1747"
  "Focus.el support for lsp-mode."
  '((emacs    "29.1")
    (focus    "0.1.1")
    (lsp-mode "6.1"))
  :url "https://github.com/emacs-lsp/lsp-focus"
  :commit "675a20610c63577bb5363c2ed9b253705bbfee4f"
  :revdesc "675a20610c63"
  :keywords '("languages" "lsp-mode"))
