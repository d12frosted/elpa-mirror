;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261114.27"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "effb508883aac916df13068c83a3420b858bce5c"
  :revdesc "effb508883aa"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
