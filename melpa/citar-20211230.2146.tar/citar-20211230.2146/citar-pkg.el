(define-package "citar" "20211230.2146" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (s "1.12")
    (parsebib "3.0")
    (org "9.5")
    (citeproc "0.9"))
  :commit "1e5b28833a0157e7d4d9bd7510548c1e2add05ea" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
