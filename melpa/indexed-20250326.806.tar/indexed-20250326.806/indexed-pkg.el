;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250326.806"
  "Cache metadata on all Org files."
  '((emacs   "29.1")
    (el-job  "2.4.0")
    (emacsql "4.2.0")
    (llama   "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "30a040f8fcc57f6335bf2b77d1fea61783978511"
  :revdesc "30a040f8fcc5"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
