;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbake" "20251230.1237"
  "Running bitbake from emacs."
  '((emacs    "24.1")
    (dash     "2.6.0")
    (mmm-mode "0.5.4")
    (s        "1.10.0"))
  :url "https://github.com/canatella/bitbake-el"
  :commit "44513a330d3bb2bceb1bfd99b4eb63b37f681369"
  :revdesc "44513a330d3b"
  :keywords '("convenience"))
