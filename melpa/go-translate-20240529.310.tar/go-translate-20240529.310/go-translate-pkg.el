(define-package "go-translate" "20240529.310" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "b735a2ec8d510f5b426c9a6f41725ae29717b2df" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
