;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260310.811"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "19159f33f16dd56f4f68357c8157ac20d70ddc1a"
  :revdesc "19159f33f16d"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
