;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo" "20240425.1307"
  "Running repo from Emacs."
  '((emacs "24.3"))
  :url "https://github.com/snogge/repo-el"
  :commit "1572f3ee82eaadc06e741f03e1889281308c79fa"
  :revdesc "1572f3ee82ea"
  :keywords '("convenience"))
