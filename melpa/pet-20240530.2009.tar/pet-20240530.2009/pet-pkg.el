(define-package "pet" "20240530.2009" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0")
    (map "3.3.1")
    (seq "2.24"))
  :commit "db2f595d1f3ac84e464ca79c212bf9a1cbea770b" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
