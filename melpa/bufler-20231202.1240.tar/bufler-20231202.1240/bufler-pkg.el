(define-package "bufler" "20231202.1240" "Group buffers into workspaces with programmable rules"
  '((emacs "26.3")
    (burly "0.4pre")
    (dash "2.18")
    (f "0.17")
    (pretty-hydra "0.2.2")
    (magit-section "0.1")
    (map "2.1"))
  :commit "2e57f56068d18b2ee5832a6c3e2cec0c5279a812" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/bufler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
