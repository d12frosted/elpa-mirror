(define-package "brutal-theme" "20211018.2212" "Brutalist theme"
  '((emacs "24.1"))
  :commit "7261842aa2e6db259eda4ed29db0ec69678c0f23" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
