(define-package "brutal-theme" "20211018.2212" "Brutalist theme"
  '((emacs "24.1"))
  :commit "5ec10f0614978c376df95ed9da05f2227cd7cd62" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
