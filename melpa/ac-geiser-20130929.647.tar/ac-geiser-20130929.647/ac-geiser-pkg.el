(define-package "ac-geiser" "20130929.647" "Auto-complete backend for geiser"
  '((geiser "0.5")
    (auto-complete "1.4"))
  :commit "0e2e36532336f27e3dc3b01fff55ad1a4329817d" :authors
  '(("Xiao Hanyu" . "xiaohanyu1988@gmail.com"))
  :maintainer
  '("Xiao Hanyu" . "xiaohanyu1988@gmail.com")
  :url "https://github.com/xiaohanyu/ac-geiser")
;; Local Variables:
;; no-byte-compile: t
;; End:
