(define-package "python-mode" "20201210.1044" "Python major mode" 'nil :commit "054a064c3b0df33ed6ad50b506278f93406c13fa")
;; Local Variables:
;; no-byte-compile: t
;; End:
