;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "20251005.551"
  "Explore and visualise Denote files."
  '((emacs  "29.1")
    (denote "4.0")
    (dash   "2.19.1"))
  :url "https://github.com/pprevos/denote-explore/"
  :commit "1f7934d02fef5dc128cdce7de7ecb0bac1decf01"
  :revdesc "1f7934d02fef"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
