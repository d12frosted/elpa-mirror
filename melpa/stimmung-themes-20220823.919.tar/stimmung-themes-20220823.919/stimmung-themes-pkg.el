(define-package "stimmung-themes" "20220823.919" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "fc9f685fee717f52a249a72189bbdccb225bc122" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
