(define-package "chordpro-mode" "20230921.212" "Major mode for ChordPro lead sheet file format"
  '((emacs "28.1")
    (compat "29.1.4.1"))
  :commit "8727d3b3527545886881c7f4e244766e84b0535e" :authors
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainer
  '("Howard Ding" . "hading2@gmail.com")
  :keywords
  '("convenience")
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
