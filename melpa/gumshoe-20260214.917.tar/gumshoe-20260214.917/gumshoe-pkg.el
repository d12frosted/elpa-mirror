;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gumshoe" "20260214.917"
  "Scoped spatial and temporal POINT movement tracking."
  '((emacs "27.1"))
  :url "https://github.com/Overdr0ne/gumshoe"
  :commit "356b8a39c765ba6fb39c350ef13760f8778238e4"
  :revdesc "356b8a39c765"
  :keywords '("tools"))
