;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backline" "20260601.1450"
  "Preserve appearance of outline headings."
  '((emacs               "28.1")
    (compat              "30.1")
    (outline-minor-faces "1.2"))
  :url "https://github.com/tarsius/backline"
  :commit "cc6e54e40bdbb725cdaf0cc95cef8cd48dce413f"
  :revdesc "cc6e54e40bdb"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev")))
