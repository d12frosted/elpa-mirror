;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250712.1240"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "c0319af5148af5997f634eccc62bb23dad870c6b"
  :revdesc "c0319af5148a"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
