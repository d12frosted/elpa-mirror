(define-package "cfn-mode" "20240526.804" "AWS cloudformation mode"
  '((emacs "27.0")
    (f "0.20.0")
    (s "1.12.0")
    (yaml-mode "0.0.13"))
  :commit "e5c204583e289d4fdef56afe69eea5e3b0423281" :authors
  '(("William Orr" . "will@worrbase.com"))
  :maintainers
  '(("William Orr" . "will@worrbase.com"))
  :maintainer
  '("William Orr" . "will@worrbase.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://gitlab.com/worr/cfn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
