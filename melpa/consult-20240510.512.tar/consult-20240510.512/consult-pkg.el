(define-package "consult" "20240510.512" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "807e37823538e074f869753d44617ce24b5a95b9" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
