;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20250427.805"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "c692638c0c3000a14389e0cd9002ae14432345f6"
  :revdesc "c692638c0c30"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
