(define-package "eldev" "20210120.2316" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "ef6ea342a2dee7d6e745bc48d4d0f50d4552d537" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
