;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260322.638"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "51dd5e6e2874c633e507041c5c3bd4fa054d4d1f"
  :revdesc "51dd5e6e2874"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
