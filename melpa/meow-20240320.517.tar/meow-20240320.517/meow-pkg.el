(define-package "meow" "20240320.517" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "c693c48a2fa106790389015673a7b01526862b00" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
