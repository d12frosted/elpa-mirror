(define-package "wanderlust" "20210103.850" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "af283fc360aeb08c67b31dce0ac6021dd4407819")
;; Local Variables:
;; no-byte-compile: t
;; End:
