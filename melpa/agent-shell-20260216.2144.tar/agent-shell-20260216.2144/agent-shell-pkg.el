;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260216.2144"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.10.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b40e0086a0cacefbfa0483be84cb98b15449e63a"
  :revdesc "b40e0086a0ca")
