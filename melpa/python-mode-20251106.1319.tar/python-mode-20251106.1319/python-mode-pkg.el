;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20251106.1319"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "3347a04a20c356274459e51daa41fed9cc1a69c0"
  :revdesc "3347a04a20c3"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
