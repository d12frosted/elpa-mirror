;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "20250718.1057"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.1")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "c2f517e35fbba07a9d6e6ab4091ee65ad773a32c"
  :revdesc "c2f517e35fbb"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
