;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260904.320"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "990ad02bd5b9830245e4df6bcdbfe96ce05d1c5f"
  :revdesc "990ad02bd5b9"
  :keywords '("languages" "lisp" "slime"))
