;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250322.2317"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "e4bd4519b0846b49e52453b41240d076c910e1f2"
  :revdesc "e4bd4519b084"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
