(define-package "company-coq" "20221129.842" "A collection of extensions for Proof General's Coq mode"
  '((cl-lib "0.5")
    (dash "2.12.1")
    (yasnippet "0.11.0")
    (company "0.8.12")
    (company-math "1.1"))
  :commit "6b1ca00b151c0b30b7492e43efc982a95e938ad1" :authors
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/cpitclaudel/company-coq")
;; Local Variables:
;; no-byte-compile: t
;; End:
