;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250719.323"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "9f48e1a7bcd8c524c5db92ca007a3fa6ab26bba7"
  :revdesc "9f48e1a7bcd8"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
