;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-bug" "20251001.25"
  "Conveniences for local-first issues with git-bug."
  '((emacs "29.1"))
  :url "http://www.github.com/WillForan/emacs-git-bug"
  :commit "b29eba066f61e3ee3a0c751f4d9958e3be19d56d"
  :revdesc "b29eba066f61"
  :keywords '("tools" "vc" "processes")
  :authors '(("Will Foran" . "willforan+emacs@gmail.com"))
  :maintainers '(("Will Foran" . "willforan+emacs@gmail.com")))
