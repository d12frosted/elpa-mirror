(define-package "fedi" "20231217.1658" "Helper functions for fediverse clients"
  '((emacs "28.1")
    (markdown-mode "2.5"))
  :commit "935d30b1b67dea19e20a1648b32adf21d2dcea2a" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
