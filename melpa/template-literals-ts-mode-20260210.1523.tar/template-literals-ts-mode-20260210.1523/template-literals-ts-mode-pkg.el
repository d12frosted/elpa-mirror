;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "template-literals-ts-mode" "20260210.1523"
  "Tree-sitter support for HTML/CSS in JS/TS template literals."
  '((emacs "30.1"))
  :url "https://github.com/ispringle/template-literals-ts-mode"
  :commit "30d2f1a82029fb698fc2850b110395affaec4b78"
  :revdesc "30d2f1a82029"
  :keywords '("languages" "javascript" "typescript" "tree-sitter")
  :authors '(("Ian S. Pringle" . "ian@dapringles.org"))
  :maintainers '(("Ian S. Pringle" . "ian@dapringles.org")))
