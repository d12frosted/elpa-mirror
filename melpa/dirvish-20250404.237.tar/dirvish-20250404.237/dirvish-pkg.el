;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250404.237"
  "A modern file manager based on dired mode."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "baf07f7f2a0f3fc1058d93a3eab7c567c900709e"
  :revdesc "baf07f7f2a0f"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
