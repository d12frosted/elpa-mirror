;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260211.1508"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "e10ca980263cb6a94b584649b6368e38d296464a"
  :revdesc "e10ca980263c"
  :keywords '("convenience"))
