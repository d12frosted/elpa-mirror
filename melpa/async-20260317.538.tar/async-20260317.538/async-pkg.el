;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async" "20260317.538"
  "Asynchronous processing in Emacs."
  '((emacs "24.4"))
  :url "https://github.com/jwiegley/emacs-async"
  :commit "475177f380c48ca36bc1f3dcdc61267448286897"
  :revdesc "475177f380c4"
  :keywords '("async")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
