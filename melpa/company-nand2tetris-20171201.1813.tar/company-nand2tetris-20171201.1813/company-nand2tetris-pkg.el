;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-nand2tetris" "20171201.1813"
  "Company backend for nand2tetris major mode."
  '((nand2tetris "1.1.0")
    (company     "0.5")
    (cl-lib      "0.5.0"))
  :url "http://www.github.com/CestDiego/nand2tetris.el/"
  :commit "fe37ee41367ceff6f7d7a472a5f80cf1285e1e01"
  :revdesc "fe37ee41367c"
  :keywords '("nand2tetris" "hdl" "company")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
