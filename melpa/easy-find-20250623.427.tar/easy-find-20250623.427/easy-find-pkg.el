;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-find" "20250623.427"
  "Simple file searching like Nemo."
  '((emacs "24.4"))
  :url "https://github.com/gnarledgrip/easy-find"
  :commit "d094399c8cef81ce700ae391c11fce026ab24d15"
  :revdesc "d094399c8cef"
  :keywords '("files" "convenience" "tools"))
