;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260424.1103"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "0d1c67521635af91c2876e0d850ee8bc74bda384"
  :revdesc "0d1c67521635"
  :keywords '("convenience" "chinese" "input-method" "rime"))
