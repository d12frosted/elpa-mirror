(define-package "live-py-mode" "20211231.331" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "55ee9385718fccdd123b96acb8aad693a7cab798" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
