;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260625.616"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "47302f99ecf2aee4eac22dcb095e13f93061d376"
  :revdesc "47302f99ecf2"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
