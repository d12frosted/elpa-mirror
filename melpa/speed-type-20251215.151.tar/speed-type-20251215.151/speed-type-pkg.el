;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251215.151"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "cf44c4f9f76195bc9abec0e9887a6b8da43d8adf"
  :revdesc "cf44c4f9f761"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
