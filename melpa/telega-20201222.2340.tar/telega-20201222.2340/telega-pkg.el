(define-package "telega" "20201222.2340" "Telegram client (unofficial)"
  '((emacs "26.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "47ff0cad12a908a97a4934a50e83ebaa2a0161f5" :keywords
  ("comm")
  :authors
  (("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  ("Zajcev Evgeny" . "zevlg@yandex.ru")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
