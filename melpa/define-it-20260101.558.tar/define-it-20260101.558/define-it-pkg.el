;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "define-it" "20260101.558"
  "Define, translate, wiki the word."
  '((emacs            "25.1")
    (s                "1.12.0")
    (popup            "0.5.3")
    (pos-tip          "0.4.6")
    (posframe         "1.1.7")
    (define-word      "0.1.0")
    (google-translate "0.11.18")
    (wiki-summary     "0.1"))
  :url "https://github.com/jcs-elpa/define-it"
  :commit "f33effcfcd4ef73cefd5d1c32991c5802269643e"
  :revdesc "f33effcfcd4e"
  :keywords '("convenience" "dictionary" "explanation" "search" "wiki")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
