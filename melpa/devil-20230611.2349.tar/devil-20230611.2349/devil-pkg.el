(define-package "devil" "20230611.2349" "Minor mode for translating key sequences"
  '((emacs "24.4"))
  :commit "4729fb499f2f7f3d694489cf05efef1720398b2f" :authors
  '(("Susam Pal" . "susam@susam.net"))
  :maintainers
  '(("Susam Pal" . "susam@susam.net"))
  :maintainer
  '("Susam Pal" . "susam@susam.net")
  :keywords
  '("convenience" "abbrev")
  :url "https://github.com/susam/devil")
;; Local Variables:
;; no-byte-compile: t
;; End:
