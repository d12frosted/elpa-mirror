;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "suggestion-box" "20170830.807"
  "Show tooltip on the cursor."
  '((emacs "25.1")
    (popup "0.5.3"))
  :url "https://github.com/yuutayamada/suggestion-box-el"
  :commit "50af0776c8caf3c79c4d37fd51cbf304ea34b68e"
  :revdesc "50af0776c8ca"
  :keywords '("convenience")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
