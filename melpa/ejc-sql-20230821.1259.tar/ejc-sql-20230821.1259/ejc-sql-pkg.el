(define-package "ejc-sql" "20230821.1259" "Emacs SQL client uses Clojure JDBC."
  '((emacs "26.3")
    (clomacs "0.0.5")
    (dash "2.16.0")
    (spinner "1.7.3"))
  :commit "d1cbeb22870dd6dfff15aee3ca17ff6dfe7954ee" :authors
  '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers
  '(("Kostafey" . "kostafey@gmail.com"))
  :maintainer
  '("Kostafey" . "kostafey@gmail.com")
  :keywords
  '("sql" "jdbc")
  :url "https://github.com/kostafey/ejc-sql")
;; Local Variables:
;; no-byte-compile: t
;; End:
