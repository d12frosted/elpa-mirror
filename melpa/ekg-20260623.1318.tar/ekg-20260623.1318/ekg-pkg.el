;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260623.1318"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "4ac373842f24eb7d3e34ba0ed3be4cb0f6384591"
  :revdesc "4ac373842f24"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
