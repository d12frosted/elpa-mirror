(define-package "gptel" "20231003.2147" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "648fa228a1ccb3ba399a511db8d154fa9fa95b4b" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
