;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-line-idle" "20260813.307"
  "Evaluate mode line content when idle."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-mode-line-idle"
  :commit "0db11cad15c320d189f2552a7045489b90d862c7"
  :revdesc "0db11cad15c3"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
