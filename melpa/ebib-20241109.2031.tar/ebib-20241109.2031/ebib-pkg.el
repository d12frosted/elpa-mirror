;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebib" "20241109.2031"
  "A BibTeX database manager."
  '((parsebib "6.0")
    (emacs    "27.1")
    (compat   "29.1.4.3"))
  :url "https://github.com/joostkremers/ebib"
  :commit "229bcec8b221de4f4890837d874a2a95fc9afa2c"
  :revdesc "229bcec8b221"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
