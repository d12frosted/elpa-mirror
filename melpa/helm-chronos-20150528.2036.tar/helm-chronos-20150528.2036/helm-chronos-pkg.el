;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-chronos" "20150528.2036"
  "Helm interface for chronos timers."
  '((chronos "1.2")
    (helm    "1.7.1"))
  :url "https://github.com/dxknight/helm-chronos"
  :commit "a14fc3d65dd96ce6616234b3f7b8b08b4c1817ef"
  :revdesc "a14fc3d65dd9"
  :keywords '("calendar")
  :authors '(("David Knight" . "dxknight@opmbx.org"))
  :maintainers '(("David Knight" . "dxknight@opmbx.org")))
