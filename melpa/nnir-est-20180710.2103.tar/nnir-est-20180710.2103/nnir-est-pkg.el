;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nnir-est" "20180710.2103"
  "Gnus nnir interface for HyperEstraier."
  ()
  :url "https://github.com/kawabata/nnir-est"
  :commit "6d0d5c8e33f4e4ccbc22350324c0990d2676fb5a"
  :revdesc "6d0d5c8e33f4"
  :keywords '("mail")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
