(define-package "helm-core" "20220104.1344" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "4a1c05249b05d6fac0afcbd8efbbc116b947bb64")
;; Local Variables:
;; no-byte-compile: t
;; End:
