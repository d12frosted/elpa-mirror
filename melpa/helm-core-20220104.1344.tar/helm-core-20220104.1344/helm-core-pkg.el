(define-package "helm-core" "20220104.1344" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "318a4d4cee492563efd3a36ad991706e79a99175")
;; Local Variables:
;; no-byte-compile: t
;; End:
