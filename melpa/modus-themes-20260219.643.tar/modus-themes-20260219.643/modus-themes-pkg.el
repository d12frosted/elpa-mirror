;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260219.643"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "b2e0aff5edcdcb5f79a072dcba3f4c0c26ec1000"
  :revdesc "b2e0aff5edcd"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
