(define-package "yaml-pro" "20240218.529" "Parser-aided YAML editing features"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "2c0acfd16b097e2a8996741d530d748a00bf5ba1" :authors
  '(("Zachary Romero"))
  :maintainers
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("tools")
  :url "https://github.com/zkry/yaml-pro")
;; Local Variables:
;; no-byte-compile: t
;; End:
