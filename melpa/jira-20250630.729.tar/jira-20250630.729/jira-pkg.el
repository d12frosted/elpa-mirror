;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20250630.729"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "427636ea67fc49ca248945d46f76f931eb3a065c"
  :revdesc "427636ea67fc"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
