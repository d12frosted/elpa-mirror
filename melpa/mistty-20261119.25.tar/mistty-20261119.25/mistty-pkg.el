;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20261119.25"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "9d2c39f3926f240b4d585d741e2e279a3a376fde"
  :revdesc "9d2c39f3926f"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
