;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260428.510"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "0408c9cdf8d20a10dac8a5c71584b2a91ff3d62f"
  :revdesc "0408c9cdf8d2"
  :keywords '("languages"))
