;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blog-admin" "20170923.1409"
  "Blog admin for emacs with hexo/org-page supported."
  '((ctable "0.1.1")
    (s      "1.10.0")
    (f      "0.17.3")
    (names  "20151201.0")
    (cl-lib "0.5"))
  :url "https://github.com/xcodebuild/blog-admin"
  :commit "b5f2e1dad7d68ec903619f7280bb0bcb7e398a1e"
  :revdesc "b5f2e1dad7d6"
  :keywords '("tools" "blog" "org" "hexo" "org-page")
  :authors '((nil . "code.falling@gmail.com"))
  :maintainers '((nil . "code.falling@gmail.com")))
