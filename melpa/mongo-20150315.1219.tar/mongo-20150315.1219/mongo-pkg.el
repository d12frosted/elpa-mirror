(define-package "mongo" "20150315.1219" "MongoDB driver for Emacs Lisp" 'nil :commit "595529ddd70ecb9fab8b11daad2c3929941099d6" :keywords
  ("convenience")
  :authors
  (("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainer
  ("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
