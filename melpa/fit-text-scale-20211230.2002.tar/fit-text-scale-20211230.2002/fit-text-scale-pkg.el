;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fit-text-scale" "20211230.2002"
  "Fit text by scaling."
  '((emacs "25.1"))
  :url "https://gitlab.com/marcowahl/fit-text-scale"
  :commit "c53c8ce606380088643463848a9ee3502b0c64f4"
  :revdesc "c53c8ce60638"
  :keywords '("convenience")
  :authors '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainers '(("Marco Wahl" . "marcowahlsoft@gmail.com")))
