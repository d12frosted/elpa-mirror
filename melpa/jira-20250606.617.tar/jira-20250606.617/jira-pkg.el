;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20250606.617"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "a1d5e46e39238706f8cdc8927714db6d1a87db2b"
  :revdesc "a1d5e46e3923"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
