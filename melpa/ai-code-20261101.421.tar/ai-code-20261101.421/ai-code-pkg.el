;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261101.421"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "1667aee622cfd0bc6c1a12842bb125086b62745c"
  :revdesc "1667aee622cf"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
