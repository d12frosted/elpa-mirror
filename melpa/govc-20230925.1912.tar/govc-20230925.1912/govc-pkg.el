(define-package "govc" "20230925.1912" "Interface to govc for managing VMware ESXi and vCenter"
  '((emacs "24.3")
    (dash "1.5.0")
    (s "1.9.0")
    (magit-popup "2.0.50")
    (json-mode "1.6.0"))
  :commit "2fab8d5337155ac7e6162b4cddd0b87fbfdf7515" :authors
  '(("The govc developers"))
  :maintainers
  '(("The govc developers"))
  :maintainer
  '("The govc developers")
  :keywords
  '("convenience")
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
