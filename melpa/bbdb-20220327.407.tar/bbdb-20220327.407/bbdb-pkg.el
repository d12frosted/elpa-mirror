(define-package "bbdb" "20220327.407" "The Insidious Big Brother Database for GNU Emacs" 'nil :commit "304415b1afff1ec857049237e4945d01655b5df2" :maintainer
  '("Roland Winkler" . "winkler@gnu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
