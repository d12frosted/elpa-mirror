;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260511.1012"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "3cbbb1c2f59f2909e1e1aff3f5da33b7d95456cd"
  :revdesc "3cbbb1c2f59f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
