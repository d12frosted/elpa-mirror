;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-grammarly" "20251231.1727"
  "LSP Clients for Grammarly."
  '((emacs     "28.1")
    (lsp-mode  "6.1")
    (grammarly "0.3.0")
    (request   "0.3.0")
    (s         "1.12.0")
    (ht        "2.3"))
  :url "https://github.com/emacs-grammarly/lsp-grammarly"
  :commit "4c3aa9e757ff9082a4d7ff104dd5ff0f28f0b811"
  :revdesc "4c3aa9e757ff"
  :keywords '("convenience" "lsp" "grammarly" "checker")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
