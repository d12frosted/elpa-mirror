(define-package "npm" "20210601.1122" "Run your npm workflows"
  '((emacs "25.1")
    (transient "0.1.0")
    (jest "20200625"))
  :commit "d14d654c025d8f75f678503c98cd8682e69341cd" :authors
  '(("Shane Kennedy"))
  :maintainer
  '("Shane Kennedy")
  :keywords
  '("tools")
  :url "https://github.com/shaneikennedy/npm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
