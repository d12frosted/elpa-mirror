;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syncthing" "20241210.752"
  "Client for Syncthing."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/emacs-syncthing"
  :commit "0c0617d11aadf34b5284ec082584a375d0568ab0"
  :revdesc "0c0617d11aad"
  :keywords '("convenience" "syncthing" "sync" "client" "view")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
