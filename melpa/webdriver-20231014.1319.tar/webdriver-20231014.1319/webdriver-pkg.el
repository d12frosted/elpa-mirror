(define-package "webdriver" "20231014.1319" "WebDriver local end implementation"
  '((emacs "27.1"))
  :commit "daaeb212aca1cd4a063152d99f8c857eb23c9382" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/mauroaranda/emacs-webdriver")
;; Local Variables:
;; no-byte-compile: t
;; End:
