;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260404.1558"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "67c0b414b98db9db1f6f152e42823f9abf7b5fa9"
  :revdesc "67c0b414b98d"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
