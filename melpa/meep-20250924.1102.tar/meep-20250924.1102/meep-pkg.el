;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250924.1102"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "c7a0ad0ff0e1a8f51c19cd163047f5fdd4d2f999"
  :revdesc "c7a0ad0ff0e1"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
