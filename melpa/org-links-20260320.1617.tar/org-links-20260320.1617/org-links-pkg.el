;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260320.1617"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "75c02487902c884d19440254627fbd8ef06c8a97"
  :revdesc "75c02487902c"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
