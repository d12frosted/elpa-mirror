(define-package "region-occurrences-highlighter" "20230408.1404" "Mark occurrences of current region (selection)."
  '((emacs "24"))
  :commit "3fbac20154035d75238facbc3b881ab3b47ab711" :authors
  '(("Álvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com"))
  :maintainers
  '(("Álvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com"))
  :maintainer
  '("Álvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/alvarogonzalezsotillo/region-occurrences-highlighter")
;; Local Variables:
;; no-byte-compile: t
;; End:
