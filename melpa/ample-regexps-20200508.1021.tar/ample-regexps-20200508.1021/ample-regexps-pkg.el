;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ample-regexps" "20200508.1021"
  "Ample regular expressions for Emacs."
  ()
  :url "https://github.com/immerrr/ample-regexps.el"
  :commit "153969ce547afe410b8986f01c9ed4087c9cd20b"
  :revdesc "153969ce547a"
  :keywords '("regexps" "extensions" "tools")
  :authors '(("immerrr" . "immerrr@gmail.com"))
  :maintainers '(("immerrr" . "immerrr@gmail.com")))
