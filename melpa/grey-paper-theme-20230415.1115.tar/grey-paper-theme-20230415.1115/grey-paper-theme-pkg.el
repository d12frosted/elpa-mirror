;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grey-paper-theme" "20230415.1115"
  "A greyscale theme with look-n-feel of an eink display."
  '((emacs "24.1"))
  :url "https://github.com/gugod/grey-paper-theme"
  :commit "4e5b8a31f586e2aa5c5d9bd939f0f518d919522e"
  :revdesc "4e5b8a31f586"
  :keywords '("faces")
  :authors '(("Kang-min Liu" . "gugod@gugod.org"))
  :maintainers '(("Kang-min Liu" . "gugod@gugod.org")))
