;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260824.1229"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "4146cbbb439c56f390d3fa0c31d592c517911f90"
  :revdesc "4146cbbb439c"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
