(define-package "tempel-collection" "20230324.941" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "096eff3618f6cd600fdf61859f9e5dd1bae08182" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
