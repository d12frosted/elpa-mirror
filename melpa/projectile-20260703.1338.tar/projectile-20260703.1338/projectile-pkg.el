;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260703.1338"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "321aa639472097ec3fc878556e4a1c8110b236b3"
  :revdesc "321aa6394720"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
