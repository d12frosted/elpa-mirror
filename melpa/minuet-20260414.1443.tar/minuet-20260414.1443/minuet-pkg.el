;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260414.1443"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "2cb82b64104fbf6a0d30497a04eb117b2ef7c98b"
  :revdesc "2cb82b64104f"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
