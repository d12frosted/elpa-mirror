(define-package "helm-core" "20231105.625" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "f1a0feb278f094287d4ce2b494dbbe786367c70a" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
