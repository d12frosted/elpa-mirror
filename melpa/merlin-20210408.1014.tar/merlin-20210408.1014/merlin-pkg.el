(define-package "merlin" "20210408.1014" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "cb1094ee0aeb5bd2bf5530911157c61cb316e6f3" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
