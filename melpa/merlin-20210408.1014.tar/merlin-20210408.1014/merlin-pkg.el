(define-package "merlin" "20210408.1014" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "fe7380bb13ff91f8ed5cfbfea6a6ca01ee1ef88c" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
