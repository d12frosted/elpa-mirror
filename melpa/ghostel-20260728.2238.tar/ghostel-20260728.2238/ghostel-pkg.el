;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260728.2238"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "051246d86bc3a89b8aea0763164d1b8bb398702f"
  :revdesc "051246d86bc3"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
