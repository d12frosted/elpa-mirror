(define-package "dwim-coder-mode" "20230623.942" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "49390a9afad79be7196100b5ec2ca79e103f2702" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
