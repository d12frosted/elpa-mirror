(define-package "shimbun" "20210614.2341" "interfacing with web newspapers" 'nil :commit "bf98643761924d6fdc1bdae8df1ac84559e5e881" :authors
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
    ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
    ("Yuuichi Teranishi " . "teranisi@gohome.org")
    ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  '("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  '("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
