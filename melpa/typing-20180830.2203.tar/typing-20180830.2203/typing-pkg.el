;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typing" "20180830.2203"
  "The Typing Of Emacs."
  ()
  :url "http://www.emacswiki.org/emacs/TypingOfEmacs"
  :commit "a2ef25dde2d8eb91bd9c0c6164cb5208208647fa"
  :revdesc "a2ef25dde2d8"
  :keywords '("games")
  :authors '(("Alex Schroeder" . "alex@gnu.org"))
  :maintainers '(("Alex Schroeder" . "alex@gnu.org")))
