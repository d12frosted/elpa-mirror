(define-package "hl-prog-extra" "20230109.536" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "5090976e95fb0c5d924e8db15d8545259d4a5328" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
