;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dot-env" "20230820.2014"
  "Dotenv functionality."
  '((emacs "24.4")
    (s     "1.13.0"))
  :url "https://github.com/amodelbello/dot-env.el"
  :commit "83ce690e8ef9175fc621c85d5fbef4f7ace7b7a8"
  :revdesc "83ce690e8ef9"
  :keywords '("convenience" "dotenv" "environment" "configuration"))
