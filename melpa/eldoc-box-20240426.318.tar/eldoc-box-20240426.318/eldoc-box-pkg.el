(define-package "eldoc-box" "20240426.318" "Display documentation in childframe"
  '((emacs "27.1"))
  :commit "2a6cda11eaa60c7a900d72bdf514f33b3821137d" :authors
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainer
  '("Yuan Fu" . "casouri@gmail.com")
  :url "https://github.com/casouri/eldoc-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
