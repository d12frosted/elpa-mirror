;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260625.929"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.1")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1d4265fc5c8bf3b0c3f47ff0084df633587ae801"
  :revdesc "1d4265fc5c8b")
