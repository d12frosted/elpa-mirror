(define-package "geiser" "20210421.116" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "803dfeb9414ed7b99c5d567170f32c97cafa1114" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
