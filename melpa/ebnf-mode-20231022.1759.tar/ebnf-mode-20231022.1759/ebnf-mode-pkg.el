;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebnf-mode" "20231022.1759"
  "Major mode for EBNF files."
  '((emacs "25.1"))
  :url "https://github.com/nverno/ebnf-mode"
  :commit "61486b1c9d4746249640410e58087e318f801ed8"
  :revdesc "61486b1c9d47"
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
