(define-package "srfi" "20210719.341" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "2fd628af87fa5509c0959b6a71ef1f072281acc3" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
