;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261017.336"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "6eb45b21ec05ed7ac762402a3f1aa69077b9be6c"
  :revdesc "6eb45b21ec05"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
