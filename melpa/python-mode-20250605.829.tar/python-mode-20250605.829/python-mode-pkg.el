;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250605.829"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "91d140c33a9ca428a5ab61c6ab5802d8f81dbf23"
  :revdesc "91d140c33a9c"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
