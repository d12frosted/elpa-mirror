(define-package "eldev" "20221108.2153" "Elisp development tool"
  '((emacs "24.4"))
  :commit "5d7986c65b57b83c57b4839e990444a1a5abebef" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
