(define-package "dwim-shell-command" "20221104.734" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "37ae27f55210f35684c1c83fc5a3eda7a0c68872" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
