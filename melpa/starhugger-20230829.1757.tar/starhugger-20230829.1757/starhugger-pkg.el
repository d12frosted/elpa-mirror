(define-package "starhugger" "20230829.1757" "Hugging Face/AI-powered text & code completion client"
  '((emacs "28.2")
    (compat "29.1.4.0")
    (dash "2.18.0")
    (s "1.13.1")
    (spinner "1.7.4"))
  :commit "aa8ac995e48b2e810ca11ddd04f68178a819fb5a" :keywords
  '("completion" "convenience" "languages")
  :url "https://gitlab.com/daanturo/starhugger.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
