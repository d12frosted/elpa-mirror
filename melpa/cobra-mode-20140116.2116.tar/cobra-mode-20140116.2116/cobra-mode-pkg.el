;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cobra-mode" "20140116.2116"
  "Major mode for .NET-based Cobra language."
  ()
  :url "https://github.com/Nekroze/cobra-mode"
  :commit "acd6e53f6286af5176471d01f25257e5ddb6dd01"
  :revdesc "acd6e53f6286"
  :keywords '("languages"))
