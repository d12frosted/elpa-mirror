;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leader-key" "20231001.2236"
  "Leader key configuration (e.g. for god-mode)."
  '((emacs "25.1"))
  :url "https://github.com/havner/leader-key"
  :commit "64d2a29e2f667399869f2b0334855a647211e50e"
  :revdesc "64d2a29e2f66"
  :keywords '("convenience" "keys" "keybinding" "config" "leader" "god" "god-mode")
  :authors '(("Lukasz Pawelczyk" . "havner@gmail.com"))
  :maintainers '(("Lukasz Pawelczyk" . "havner@gmail.com")))
