(define-package "run-command-recipes" "20220207.1504" "This is collection of recipes to `run-command'"
  '((emacs "25.1")
    (dash "2.18.0")
    (f "0.20.0")
    (run-command "0.1.0"))
  :commit "e1a4ccf047565f89b1264af9d76cda5cf7e2fd98" :authors
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainer
  '("semenInRussia" . "hrams205@gmail.com")
  :keywords
  '("extensions" "run-command")
  :url "https://github.com/semenInRussia/emacs-run-command-recipes")
;; Local Variables:
;; no-byte-compile: t
;; End:
