;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260309.212"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "07c630b3227bf8714728d021b4641055def18b31"
  :revdesc "07c630b3227b"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
