;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dslide" "20241226.844"
  "Domain Specific sLIDEs. Programmable Presentation."
  '((emacs "29.2"))
  :url "https://github.com/positron-solutions/dslide"
  :commit "9f04216b26df23ff53a9bce898dd7aee0ca1be25"
  :revdesc "9f04216b26df"
  :keywords '("convenience" "org-mode" "presentation" "narrowing")
  :authors '(("Positron" . "contact@positron.solutions"))
  :maintainers '(("Positron" . "contact@positron.solutions")))
