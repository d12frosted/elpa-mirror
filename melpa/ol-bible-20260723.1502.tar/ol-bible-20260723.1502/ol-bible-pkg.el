;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-bible" "20260723.1502"
  "Org Link support for Bible Passages."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~swflint/ol-bible"
  :commit "d2db628d7ceec5e1d9c164f95c8a4c1b02438870"
  :revdesc "d2db628d7cee"
  :keywords '("convenience" "outlines")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
