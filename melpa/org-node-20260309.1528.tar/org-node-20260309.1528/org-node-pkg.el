;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260309.1528"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.34.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "10ea878528a24ae9bf6903da198f347d093f2b11"
  :revdesc "10ea878528a2"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
