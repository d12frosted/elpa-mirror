(define-package "kanagawa-theme" "20231205.328" "An elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa"
  '((emacs "24.3"))
  :commit "fad62c62d77a43a35723bbacfd8b2a856981c58e" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/Meritamen/kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
