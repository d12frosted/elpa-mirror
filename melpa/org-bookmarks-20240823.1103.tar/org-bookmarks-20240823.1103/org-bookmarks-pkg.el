(define-package "org-bookmarks" "20240823.1103" "Manage bookmarks in Org mode"
  '((emacs "29.1"))
  :commit "3e472e6567fb9bc5abcec5ed8988d36fd3318bf2" :keywords
  '("outline" "matching" "hypermedia" "org")
  :url "https://repo.or.cz/org-bookmarks.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
