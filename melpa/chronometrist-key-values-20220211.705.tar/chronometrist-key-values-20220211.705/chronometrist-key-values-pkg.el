(define-package "chronometrist-key-values" "20220211.705" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "c13241b0a97ba19cf4b0d05fe0e1a3d8cb3f1181" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
