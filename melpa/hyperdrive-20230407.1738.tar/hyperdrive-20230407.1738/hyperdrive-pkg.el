(define-package "hyperdrive" "20230407.1738" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.3.2")
    (plz "0.4")
    (persist "0.5"))
  :commit "22e9ed4c54326aa351ffb3ae2ff5f8de623f1d51" :authors
  '(("Joseph Turner"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
