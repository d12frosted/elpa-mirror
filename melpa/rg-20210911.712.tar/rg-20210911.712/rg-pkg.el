(define-package "rg" "20210911.712" "A search tool based on ripgrep"
  '((emacs "25.1")
    (transient "0.3.0")
    (wgrep "2.1.10"))
  :commit "3e9cada75129e899add86d00e0aa3be050d04937" :authors
  '(("David Landell" . "david.landell@sunnyhill.email")
    ("Roland McGrath" . "roland@gnu.org"))
  :maintainer
  '("David Landell" . "david.landell@sunnyhill.email")
  :keywords
  '("matching" "tools")
  :url "https://github.com/dajva/rg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
