(define-package "fontsloth" "20230516.7" "Elisp otf/ttf font loader/renderer"
  '((f "0.20.0")
    (logito "0.1")
    (pcache "0.5")
    (stream "2.2.5")
    (emacs "28.1"))
  :commit "4d2abc7af4339558759f37163820560cb2a5bcd9" :authors
  '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainers
  '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainer
  '("Jo Gay" . "jo.gay@mailfence.com")
  :keywords
  '("data" "font" "rasterization" "ttf" "otf")
  :url "https://github.com/jollm/fontsloth")
;; Local Variables:
;; no-byte-compile: t
;; End:
