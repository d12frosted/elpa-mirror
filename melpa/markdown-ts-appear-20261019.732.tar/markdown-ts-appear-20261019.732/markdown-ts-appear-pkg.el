;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "20261019.732"
  "Reveal Markdown source at point."
  '((emacs "31.1"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "22577039b48c3209776bc2efc901b2bb8d4ebd9f"
  :revdesc "22577039b48c"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
