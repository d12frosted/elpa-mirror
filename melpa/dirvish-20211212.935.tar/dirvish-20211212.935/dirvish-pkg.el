(define-package "dirvish" "20211212.935" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (posframe "1.1.2"))
  :commit "d36abff4db176643d1282d53b1d8727150e8f6bb" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
