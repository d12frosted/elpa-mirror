(define-package "dwim-shell-command" "20231006.1316" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "26ac4a14afdb6860eb4966cf2c198bc513b318ff" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
