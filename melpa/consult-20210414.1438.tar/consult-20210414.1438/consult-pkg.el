(define-package "consult" "20210414.1438" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "bd8fe1b2e78fdbb6f37b7ad6ad82830d9fdf6188" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
