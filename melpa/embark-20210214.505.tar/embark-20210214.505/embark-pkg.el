(define-package "embark" "20210214.505" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "659df4bb9b9ac9abbb1afddcae35564137be0d9d" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
