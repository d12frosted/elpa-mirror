;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20261012.1332"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "66a16349803cacd276ae57235fd19627e58dd563"
  :revdesc "66a16349803c"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
