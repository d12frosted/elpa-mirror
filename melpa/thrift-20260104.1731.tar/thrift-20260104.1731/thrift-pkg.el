;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260104.1731"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "1c89f94651bcfb367f536836b02f090217340c4c"
  :revdesc "1c89f94651bc"
  :keywords '("languages"))
