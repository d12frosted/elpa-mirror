(define-package "helm-org-ql" "20231216.1011" "Helm support for org-ql"
  '((emacs "26.1")
    (dash "2.18.1")
    (s "1.12.0")
    (helm-org "1.0")
    (org-ql "0.6pre"))
  :commit "38e16b4a5f9148d2aba0e8a17cfe123771e981a5" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :url "https://github.com/alphapapa/org-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
