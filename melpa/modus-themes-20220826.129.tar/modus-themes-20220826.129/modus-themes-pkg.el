(define-package "modus-themes" "20220826.129" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "330cf93d19ffaba3d823ebc905c538c86129b3be" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
