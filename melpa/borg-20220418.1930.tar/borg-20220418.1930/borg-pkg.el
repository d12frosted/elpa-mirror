(define-package "borg" "20220418.1930" "assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "2cf5635da90d6dcc3e7e64500f67e914a44ef59f" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
