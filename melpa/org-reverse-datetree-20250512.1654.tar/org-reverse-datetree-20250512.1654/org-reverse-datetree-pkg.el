;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-reverse-datetree" "20250512.1654"
  "Create reverse date trees in org-mode."
  '((emacs "29.1")
    (dash  "2.19.1")
    (org   "9.6"))
  :url "https://github.com/akirak/org-reverse-datetree"
  :commit "bef2e26639e940320d3b4b498f4cbba03eb9dd86"
  :revdesc "bef2e26639e9"
  :keywords '("outlines")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
