(define-package "consult" "20210327.951" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b21fa778cd22f34ee2ddbf591c5c652bdd0cc6d6" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
