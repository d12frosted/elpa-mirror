(define-package "org-toodledo" "20150301.1113" "Toodledo integration for Emacs Org mode"
  '((request-deferred "0.2.0")
    (emacs "24")
    (cl-lib "0.5"))
  :commit "01b53b637f304b89cd3bf2d29009b5ed6ad9466d" :authors
  '(("Christopher J. White" . "emacs@grierwhite.com"))
  :maintainer
  '("Christopher J. White" . "emacs@grierwhite.com")
  :keywords
  '("outlines" "data"))
;; Local Variables:
;; no-byte-compile: t
;; End:
