(define-package "bnf-mode" "20240915.2118" "Major mode for editing BNF grammars."
  '((cl-lib "0.5")
    (emacs "27.1"))
  :commit "5304ab647e04916c5be4fdde41477ad429a89120" :authors
  '(("Serghei Iakovlev" . "gnu@serghei.pl"))
  :maintainers
  '(("Serghei Iakovlev" . "gnu@serghei.pl"))
  :maintainer
  '("Serghei Iakovlev" . "gnu@serghei.pl")
  :keywords
  '("languages")
  :url "https://github.com/sergeyklay/bnf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
