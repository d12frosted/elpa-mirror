(define-package "wanderlust" "20221117.1230" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "f5cb2f0cf5e2c893acf2e669fd549836828dfdfc")
;; Local Variables:
;; no-byte-compile: t
;; End:
