;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-org-node" "20250401.1359"
  "Citar integration with org-node."
  '((emacs    "26.1")
    (citar    "1.1")
    (org-node "2.0.0")
    (ht       "1.6"))
  :url "https://github.com/krisbalintona/citar-org-node"
  :commit "6b2c7788f31195500a63101b648dbc9dddc32737"
  :revdesc "6b2c7788f311"
  :keywords '("tools")
  :authors '(("Kristoffer Balintona" . "krisbalintona@gmail.com"))
  :maintainers '(("Kristoffer Balintona" . "krisbalintona@gmail.com")))
