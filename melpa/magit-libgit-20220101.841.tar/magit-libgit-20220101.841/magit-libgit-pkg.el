(define-package "magit-libgit" "20220101.841" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "2a6b51b7f1b2d35f1dd3ec7b158362263fab77cc" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
