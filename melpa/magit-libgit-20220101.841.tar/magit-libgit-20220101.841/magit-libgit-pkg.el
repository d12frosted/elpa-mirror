(define-package "magit-libgit" "20220101.841" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "6ba3b50373fffa89ae99fc0ad5135e3d574f6df4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
