(define-package "magit-libgit" "20220101.841" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "466c7adf5de85257712629dfa637dc03b9bc6cb4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
