(define-package "consult" "20230209.1024" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.3"))
  :commit "ef5a4dd28a0f5897ff26d93087d82651c86daccb" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
