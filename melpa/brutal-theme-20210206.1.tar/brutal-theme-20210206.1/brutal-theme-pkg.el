(define-package "brutal-theme" "20210206.1" "Brutalist theme"
  '((emacs "24.1"))
  :commit "8b6964b6d59791f3e16316aedee52b140623d51e" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
