;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250406.1053"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "5917d8a4909e6e4b90b824ebe05d05d60e899c64"
  :revdesc "5917d8a4909e"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
