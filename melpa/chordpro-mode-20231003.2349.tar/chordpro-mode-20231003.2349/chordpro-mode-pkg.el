(define-package "chordpro-mode" "20231003.2349" "Major mode for ChordPro lead sheet file format"
  '((emacs "28.1")
    (compat "29.1.4.1"))
  :commit "c2e0d7e1b2d3b857678bc13cde9e2733cfb71e84" :authors
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainer
  '("Howard Ding" . "hading2@gmail.com")
  :keywords
  '("convenience")
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
