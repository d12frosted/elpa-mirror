;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260213.1720"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "bf31ce7ab562f1e663739ed1023a23fbd468ee73"
  :revdesc "bf31ce7ab562"
  :keywords '("convenience"))
