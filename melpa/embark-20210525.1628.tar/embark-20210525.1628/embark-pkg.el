(define-package "embark" "20210525.1628" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "f5d99481093e005619a51d20c0f7d4cfe72a9911" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
