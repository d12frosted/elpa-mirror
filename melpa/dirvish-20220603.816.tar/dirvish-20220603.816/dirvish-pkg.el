(define-package "dirvish" "20220603.816" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "932ed141b21af1ed7128b80ba555c839e55cb632" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
