(define-package "ddskk" "20220803.1302" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "3ed86d42717ab2a54ec8de6ab32d552dc0a4c3b0")
;; Local Variables:
;; no-byte-compile: t
;; End:
