;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250312.1359"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "88e48f9bcb4628e45bf37faa42f90aa8559f958f"
  :revdesc "88e48f9bcb46"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
