;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261117.1041"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "40ac5e5c459f954d03a3b760779bd39d0cbba94b"
  :revdesc "40ac5e5c459f"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
