;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260112.1339"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "3b23b577f2bf76d44e6e5bcc72cba660ae4a4bda"
  :revdesc "3b23b577f2bf"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
