(define-package "zetteldeft" "20210406.1911" "Turn deft into a zettelkasten system"
  '((emacs "25.1")
    (deft "0.8")
    (ace-window "0.7.0"))
  :commit "158cd539fa6363524daf5ad055922f1a380957e4" :authors
  '(("EFLS <Elias Storms>"))
  :maintainer
  '("EFLS <Elias Storms>")
  :keywords
  '("deft" "zettelkasten" "zetteldeft" "wp" "files")
  :url "https://efls.github.io/zetteldeft/")
;; Local Variables:
;; no-byte-compile: t
;; End:
