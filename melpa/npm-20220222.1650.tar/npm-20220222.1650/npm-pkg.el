(define-package "npm" "20220222.1650" "Run your npm workflows"
  '((emacs "25.1")
    (transient "0.1.0")
    (jest "20200625"))
  :commit "45d8084aeafae415dc45ddc9c3a18b546315fcc6" :authors
  '(("Shane Kennedy"))
  :maintainer
  '("Shane Kennedy")
  :keywords
  '("tools")
  :url "https://github.com/shaneikennedy/npm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
