(define-package "autocrypt" "20220526.1846" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "5fae83ac0501a26c92e022218341c21cc71e463c" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
