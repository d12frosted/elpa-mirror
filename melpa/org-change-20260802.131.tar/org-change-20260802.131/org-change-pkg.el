;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "20260802.131"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "625dfedf2f01349daebb7021d738fa308a49704c"
  :revdesc "625dfedf2f01"
  :keywords '("wp" "convenience"))
