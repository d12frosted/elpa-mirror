;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250323.945"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (el-job "2.2.0")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "dadd6fe137273d20c9a85b14d7e3c9edf6464684"
  :revdesc "dadd6fe13727"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
