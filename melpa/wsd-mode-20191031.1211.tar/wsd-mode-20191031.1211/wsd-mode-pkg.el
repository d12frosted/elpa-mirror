(define-package "wsd-mode" "20191031.1211" "Emacs major-mode for www.websequencediagrams.com" 'nil :commit "44aac55afb57cb540559aa1015f9ad2d770dd5c8" :authors
  '(("Jostein Kjønigsen" . "jostein@gmail.com"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("wsd" "diagrams" "design" "process" "modelling" "uml")
  :url "https://github.com/josteink/wsd-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
