(define-package "wsd-mode" "20191031.1211" "Emacs major-mode for www.websequencediagrams.com" 'nil :commit "53330a2a43c4875f8682457df1a869a4c9028660" :keywords
  ("wsd" "diagrams" "design" "process" "modelling" "uml")
  :authors
  (("Jostein Kjønigsen" . "jostein@gmail.com"))
  :maintainer
  ("Jostein Kjønigsen" . "jostein@gmail.com")
  :url "https://github.com/josteink/wsd-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
