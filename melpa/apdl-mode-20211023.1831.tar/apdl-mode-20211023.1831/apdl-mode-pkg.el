(define-package "apdl-mode" "20211023.1831" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "8b326a38fa1bf3b9675b251c78eb9456245aeef9" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
