;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251008.1620"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "9a282ead3705e8dc9a862fa2fcd75f40a410b3bf"
  :revdesc "9a282ead3705"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
