;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260614.155"
  "Unified interface for AI coding backends."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a598500b5e92a6c02af91da12ed0deb0278437b7"
  :revdesc "a598500b5e92"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
