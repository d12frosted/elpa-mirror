(define-package "meow" "20220107.758" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "b04e2ea972ee25cbada0b852f7c09cdd5cd21c62" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
