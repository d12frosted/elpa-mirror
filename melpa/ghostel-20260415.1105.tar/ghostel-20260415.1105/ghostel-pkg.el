;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260415.1105"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5280db2fa1b0265ece41275d96f6c4b046e2b166"
  :revdesc "5280db2fa1b0"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
