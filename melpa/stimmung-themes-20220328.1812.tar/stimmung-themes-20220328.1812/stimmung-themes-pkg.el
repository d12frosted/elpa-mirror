(define-package "stimmung-themes" "20220328.1812" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "f97f8763c126fd0f7182ff67fe5d39ea267757cb" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
