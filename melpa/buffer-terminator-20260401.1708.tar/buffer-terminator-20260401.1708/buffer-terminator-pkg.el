;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260401.1708"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "04b89452d59d805332a3b797bf88b78440a1accf"
  :revdesc "04b89452d59d"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
