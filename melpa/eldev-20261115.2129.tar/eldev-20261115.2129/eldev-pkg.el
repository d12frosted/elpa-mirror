;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "20261115.2129"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "6c522f813c9e51f786c8ed4f8b3c6574a6a1be9c"
  :revdesc "6c522f813c9e"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
