(define-package "difftastic" "20240223.1134" "Wrapper for difftastic"
  '((emacs "27.1")
    (compat "29.1.4.2")
    (magit "20220326"))
  :commit "52fb92077c34cc6f0e549f5e7b92f7f0d954d33a" :authors
  '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers
  '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainer
  '("Przemyslaw Kryger" . "pkryger@gmail.com")
  :keywords
  '("tools" "diff")
  :url "https://github.com/pkryger/difftastic.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
