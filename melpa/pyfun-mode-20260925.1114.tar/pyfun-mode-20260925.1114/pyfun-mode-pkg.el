;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyfun-mode" "20260925.1114"
  "Major mode for the Pyfun language."
  '((emacs "29.1"))
  :url "https://github.com/simontreanor/Pyfun"
  :commit "7233d8d52ac84d891a37d26a8377c84961ab31a8"
  :revdesc "7233d8d52ac8"
  :keywords '("languages")
  :authors '(("Simon Treanor" . "https://github.com/simontreanor"))
  :maintainers '(("Simon Treanor" . "https://github.com/simontreanor")))
