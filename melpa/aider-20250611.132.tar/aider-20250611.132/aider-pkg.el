;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250611.132"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.9.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "305792bc41d08c82791083ad9ead4d2748043fbe"
  :revdesc "305792bc41d0"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
