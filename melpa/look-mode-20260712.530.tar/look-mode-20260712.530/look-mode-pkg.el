;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "look-mode" "20260712.530"
  "Quick file viewer for image and text file browsing."
  ()
  :url "https://github.com/petermao/look-mode"
  :commit "9102caebfb266e8153e14f7462dddfcfa8ba54dd"
  :revdesc "9102caebfb26"
  :authors '(("Peter H. Mao" . "petermao@jpl.nasa.gov"))
  :maintainers '(("Peter H. Mao" . "petermao@jpl.nasa.gov")))
