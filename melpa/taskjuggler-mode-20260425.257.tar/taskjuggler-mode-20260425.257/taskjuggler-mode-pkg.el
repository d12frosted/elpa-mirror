;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskjuggler-mode" "20260425.257"
  "Major mode for TaskJuggler project files."
  '((emacs "27.1"))
  :url "https://github.com/devrintalen/taskjuggler-mode.el"
  :commit "08af224c339131d1a784adea4cbead188bcf233b"
  :revdesc "08af224c3391"
  :keywords '("languages" "project-management")
  :authors '(("Devrin Talen" . "devrin@fastmail.com"))
  :maintainers '(("Devrin Talen" . "devrin@fastmail.com")))
