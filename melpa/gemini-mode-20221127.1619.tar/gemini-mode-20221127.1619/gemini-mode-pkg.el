;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gemini-mode" "20221127.1619"
  "A simple highlighting package for text/gemini."
  '((emacs "24.4"))
  :url "https://git.carcosa.net/jmcbray/gemini.el"
  :commit "a7dd7c6ea4e036d0d5ecc4a5d284874c400f10ba"
  :revdesc "a7dd7c6ea4e0"
  :keywords '("languages")
  :authors '(("Jason McBrayer" . "jmcbray@carcosa.net")
             ("tastytea" . "tastytea@tastytea.de")
             ("tienne Deparis" . "etienne@depar.is"))
  :maintainers '(("Jason McBrayer" . "jmcbray@carcosa.net")
                 ("tastytea" . "tastytea@tastytea.de")
                 ("tienne Deparis" . "etienne@depar.is")))
