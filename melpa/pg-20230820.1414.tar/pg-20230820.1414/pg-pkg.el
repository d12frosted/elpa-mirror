(define-package "pg" "20230820.1414" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "26.1"))
  :commit "e6b71c4c2315e186c53796ffdbc6533d5bcd40c5" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
