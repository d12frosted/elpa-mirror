;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-cfengine3" "20230226.1954"
  "Org Babel functions for CFEngine 3."
  '((emacs "24.1"))
  :url "https://github.com/nickanderson/ob-cfengine3"
  :commit "52aa32fdfa412860837e795d17d50dac237e56e4"
  :revdesc "52aa32fdfa41"
  :keywords '("tools" "convenience")
  :authors '(("Nick Anderson" . "nick@cmdln.org"))
  :maintainers '(("Nick Anderson" . "nick@cmdln.org")))
