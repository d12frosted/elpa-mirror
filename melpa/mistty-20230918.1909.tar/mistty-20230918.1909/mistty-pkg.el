(define-package "mistty" "20230918.1909" "Shell/Comint alternative based on term.el"
  '((emacs "29.1")
    (iter2 "1.4"))
  :commit "43adf85575ba86197e6d123d08e7b52605c989ba" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
