(define-package "consult" "20230411.443" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "1eb5894aa29f39b4444a8b9b589d4d3a39d77db3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
