(define-package "modus-themes" "20211207.1603" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "2f5b7ccbc4d13500344b1e5c9fe1be88d3ca964b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
