;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gather" "20141230.1338"
  "Gather string in buffer."
  ()
  :url "https://github.com/mhayashi1120/Emacs-gather/raw/master/gather.el"
  :commit "8909c886d72a682710bb79ccfcfe4df54a399b7e"
  :revdesc "8909c886d72a"
  :keywords '("matching" "convenience" "tools")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
