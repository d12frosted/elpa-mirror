;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260604.1857"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f298d78b14d110eedb6baa2a8328c808dd556256"
  :revdesc "f298d78b14d1"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
