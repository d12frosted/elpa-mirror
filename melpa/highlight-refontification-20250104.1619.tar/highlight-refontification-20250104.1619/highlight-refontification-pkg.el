;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-refontification" "20250104.1619"
  "Visualize refontification."
  ()
  :url "https://github.com/Lindydancer/highlight-refontification"
  :commit "31ce7f8086a85144695dc6c972bad9f1199bd179"
  :revdesc "31ce7f8086a8"
  :keywords '("faces" "tools"))
