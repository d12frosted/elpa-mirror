;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260622.1450"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "84b1016c88e48b73f8feb3af1ba8ee724fe4b426"
  :revdesc "84b1016c88e4"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
