;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260112.1807"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "cd6b5676f5cdf5f776cddfd147c2bc6dc62d4e5d"
  :revdesc "cd6b5676f5cd"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
