(define-package "apheleia" "20231105.2008" "Reformat buffer stably"
  '((emacs "27"))
  :commit "54a192c3454e82be9d5ad910d80796b27d58035f" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
