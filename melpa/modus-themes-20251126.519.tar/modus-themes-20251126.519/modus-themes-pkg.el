;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251126.519"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "ffdee3a436b8256301784476a97595a75990f154"
  :revdesc "ffdee3a436b8"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
