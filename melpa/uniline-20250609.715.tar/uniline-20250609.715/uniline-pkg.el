;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250609.715"
  "Add ╭─╴UNICODE╶─╮ based ╭─╴diagrams╶─╮ to ╭▶╴text files╶●╮."
  '((emacs "29.1"))
  :url "https://github.com/tbanel/uniline"
  :commit "e4f8453006ec07809502678c22673c27c7f4f510"
  :revdesc "e4f8453006ec"
  :keywords '("convenience" "text"))
