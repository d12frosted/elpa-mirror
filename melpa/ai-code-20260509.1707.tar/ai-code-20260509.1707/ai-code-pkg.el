;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260509.1707"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "04d717a6e84403dc9c65459341768e30eb1ce7d8"
  :revdesc "04d717a6e844"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
