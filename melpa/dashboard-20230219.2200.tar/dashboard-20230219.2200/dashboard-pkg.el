(define-package "dashboard" "20230219.2200" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "482595b0eaf2498246197754713fab282bd0cae9" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
