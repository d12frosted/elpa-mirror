;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251109.1717"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "1113f960659ca5cf2b047ff1301d6be2eda7f9a4"
  :revdesc "1113f960659c"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
