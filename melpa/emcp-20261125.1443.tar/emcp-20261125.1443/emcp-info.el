;;; emcp-info.el --- Info helpers for EMCP -*- lexical-binding: t -*-

;; Author: Marten Lienen <ml@martenlienen.com>

;;; License

;; This file is part of EMCP.

;; EMCP is free software: you can redistribute it and/or modify it under the terms of the
;; GNU General Public License as published by the Free Software Foundation, either version
;; 3 of the License, or (at your option) any later version.

;; EMCP is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
;; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
;; PURPOSE.  See the GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License along with EMCP.  If
;; not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Helpers for Emacs Info manuals that both the info-search tool and the
;; info:// resources use.

;;; Code:

(require 'cl-lib)
(require 'info)

(defun emcp-info--manuals ()
  "Return the names of all manuals in the Info directory."
  (with-temp-buffer
    (Info-mode)
    (Info-directory)
    (goto-char (point-min))
    (re-search-forward "\\* Menu: *\n" nil t)
    (let (manuals)
      ;; Menu entries look like "* Emacs: (emacs).  The extensible editor."
      (while (re-search-forward "\\*.*: *(\\([^)]+\\))" nil t)
        (cl-pushnew (match-string-no-properties 1) manuals :test #'equal))
      (nreverse manuals))))

(provide 'emcp-info)
;;; emcp-info.el ends here
