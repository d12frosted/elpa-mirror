;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20261125.1443"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.2.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "4e14f53b8201f098b46df982f7111b29fcbe7e33"
  :revdesc "4e14f53b8201"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
