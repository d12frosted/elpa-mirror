(define-package "hyperdrive" "20230411.2226" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.3.2")
    (plz "0.4")
    (persist "0.5"))
  :commit "d790a72e563ba5e46a810769eb1c45a631333203" :authors
  '(("Joseph Turner"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
