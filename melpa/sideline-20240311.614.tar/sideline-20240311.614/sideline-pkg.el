(define-package "sideline" "20240311.614" "Show information on the side"
  '((emacs "27.1")
    (ht "2.4"))
  :commit "0a70fd29a237527db110b33f3f20cf941b2a1343" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/emacs-sideline/sideline")
;; Local Variables:
;; no-byte-compile: t
;; End:
