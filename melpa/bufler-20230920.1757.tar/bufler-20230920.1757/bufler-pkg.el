(define-package "bufler" "20230920.1757" "Group buffers into workspaces with programmable rules"
  '((emacs "26.3")
    (burly "0.4pre")
    (dash "2.18")
    (f "0.17")
    (pretty-hydra "0.2.2")
    (magit-section "0.1")
    (map "2.1"))
  :commit "d2612c393fe9b8443ce9b946e53c148032e72d72" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/bufler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
