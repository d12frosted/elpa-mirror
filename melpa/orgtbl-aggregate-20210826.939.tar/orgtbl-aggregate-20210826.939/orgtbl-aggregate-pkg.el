(define-package "orgtbl-aggregate" "20210826.939" "Create an aggregated Org table from another one" 'nil :commit "8ba35fe6e4013bd9667974b9eb1b71debdae622c" :keywords
  '("org" "table" "aggregation" "filtering"))
;; Local Variables:
;; no-byte-compile: t
;; End:
