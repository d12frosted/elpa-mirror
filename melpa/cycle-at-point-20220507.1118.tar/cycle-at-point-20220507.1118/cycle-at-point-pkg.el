(define-package "cycle-at-point" "20220507.1118" "Cycle (rotate) the thing under the cursor"
  '((emacs "28.1")
    (recomplete "0.2"))
  :commit "85750fa695797b95608b331b64ea49d81f7c8a36" :authors
  '(("Campbell Barton"))
  :maintainer
  '("Campbell Barton")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-cycle-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
