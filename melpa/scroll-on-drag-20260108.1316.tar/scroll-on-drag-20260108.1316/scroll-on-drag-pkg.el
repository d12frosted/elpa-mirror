;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scroll-on-drag" "20260108.1316"
  "Interactive scrolling."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-scroll-on-drag"
  :commit "eb38193bbcbf7559f3fb3b1d5d5f86b713786689"
  :revdesc "eb38193bbcbf"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
