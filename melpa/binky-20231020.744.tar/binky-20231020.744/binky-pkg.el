(define-package "binky" "20231020.744" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "a50d016a751a23358f8f91c0ace63a87d2e5e00e" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
