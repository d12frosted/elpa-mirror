;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260112.1409"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "2b8a29ea03bd4655455525e9dde6b81856c21260"
  :revdesc "2b8a29ea03bd"
  :keywords '("languages"))
