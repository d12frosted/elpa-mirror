;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-python-preset" "20260424.334"
  "Eglot preset for Python."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-python-preset"
  :commit "8219aa2b3d595af42108881b4d26750ec20105b7"
  :revdesc "8219aa2b3d59"
  :keywords '("python" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
