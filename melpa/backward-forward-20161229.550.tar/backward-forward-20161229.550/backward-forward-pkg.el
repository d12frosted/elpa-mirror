;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backward-forward" "20161229.550"
  "Navigation backwards and forwards across marks."
  '((emacs "24.5"))
  :url "https://gitlab.com/vancan1ty/emacs-backward-forward/tree/master"
  :commit "58489957a62a0da25dfb5df902624d2548d800b4"
  :revdesc "58489957a62a"
  :keywords '("navigation" "convenience" "backward" "forward")
  :authors '(("Currell Berry" . "currellberry@gmail.com"))
  :maintainers '(("Currell Berry" . "currellberry@gmail.com")))
