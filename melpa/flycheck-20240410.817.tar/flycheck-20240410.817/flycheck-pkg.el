(define-package "flycheck" "20240410.817" "On-the-fly syntax checking"
  '((emacs "26.1"))
  :commit "4dd5b394c417b513cdbdd7355b3e5a7f71d3f2b9" :authors
  '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://www.flycheck.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
