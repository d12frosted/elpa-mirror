(define-package "embark" "20230909.1100" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "4f2729c97817e950eda45c052e685018d9f71740" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
