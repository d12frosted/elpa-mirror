;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultra-scroll" "20260515.2003"
  "Fast and smooth scrolling."
  '((emacs "29.1"))
  :url "https://github.com/jdtsmith/ultra-scroll"
  :commit "a7df62e8b0eec1c1211af3715f9844218350762c"
  :revdesc "a7df62e8b0ee"
  :keywords '("convenience"))
