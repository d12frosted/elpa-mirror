;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-org" "20251023.1335"
  "Calendar view for org-agenda."
  '((emacs "28.1")
    (calfw "2.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "eebff62bee9775753d2db63b185076197f5e9992"
  :revdesc "eebff62bee97"
  :keywords '("calendar" "org")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
