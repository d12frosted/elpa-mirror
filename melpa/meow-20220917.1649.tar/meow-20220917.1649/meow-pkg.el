(define-package "meow" "20220917.1649" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "5905f64b70169a7462d8c172802caf8812c7107f" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
