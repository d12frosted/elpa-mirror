(define-package "docker" "20211101.717" "Emacs interface to Docker"
  '((dash "2.14.1")
    (docker-tramp "0.1")
    (emacs "24.5")
    (json-mode "1.7.0")
    (s "1.12.0")
    (tablist "0.70")
    (transient "0.2.0"))
  :commit "a7097f68a96470ae7d77b86c7bdee9acb095f06e" :authors
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainer
  '("Philippe Vaucher" . "philippe.vaucher@gmail.com")
  :keywords
  '("filename" "convenience")
  :url "https://github.com/Silex/docker.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
