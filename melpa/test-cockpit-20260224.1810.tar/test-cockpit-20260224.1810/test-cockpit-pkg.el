;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260224.1810"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "09b8978bba47c8fcefcde435a93ec63255405f8c"
  :revdesc "09b8978bba47"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
