;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261008.2357"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "9be1b3303f54aee47bdea366750f883720f932e2"
  :revdesc "9be1b3303f54"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
