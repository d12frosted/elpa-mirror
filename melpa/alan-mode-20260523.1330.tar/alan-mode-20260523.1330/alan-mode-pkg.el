;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alan-mode" "20260523.1330"
  "Major mode for editing Alan files."
  '((flycheck "32")
    (emacs    "25.1")
    (s        "1.12"))
  :url "https://github.com/Kjerner/AlanForEmacs"
  :commit "10d7a0a51451e9b023ac3dc0b24fdba9d81ecb2c"
  :revdesc "10d7a0a51451"
  :keywords '("alan" "languages")
  :authors '(("Paul van Dam" . "pvandam@kjerner.com"))
  :maintainers '(("Paul van Dam" . "pvandam@kjerner.com")))
