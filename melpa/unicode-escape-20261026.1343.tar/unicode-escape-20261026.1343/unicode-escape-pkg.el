;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-escape" "20261026.1343"
  "Escape/Unescape unicode notations."
  '((emacs "28.1"))
  :url "https://github.com/kosh04/unicode-escape.el"
  :commit "03c95c5b69a88879cf83188fec6a687f8a6a4fdf"
  :revdesc "03c95c5b69a8"
  :keywords '("i18n" "unicode")
  :authors '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com"))
  :maintainers '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com")))
