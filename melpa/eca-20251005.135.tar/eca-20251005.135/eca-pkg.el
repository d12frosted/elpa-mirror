;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251005.135"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "3d94c4dbf30ba2695748bb3e87f9aaef3d61e3df"
  :revdesc "3d94c4dbf30b"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
