(define-package "rainbow-fart" "20201128.146" "Checks the keywords of code to play suitable sounds"
  '((emacs "25.1")
    (flycheck "32snapshot"))
  :commit "1aa022197c14cd9bf892930ee82d714a255d1f2a" :keywords
  ("tools")
  :url "https://github.com/stardiviner/emacs-rainbow-fart")
;; Local Variables:
;; no-byte-compile: t
;; End:
