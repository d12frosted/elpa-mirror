;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emamux-ruby-test" "20130812.1639"
  "Ruby test with emamux."
  '((emamux     "0.01")
    (projectile "0.9.1"))
  :url "https://github.com/syohex/emamux-ruby-test"
  :commit "785bfd44d097a46bb2ebe1e62ac7595fd4dc9ab5"
  :revdesc "785bfd44d097"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com")
             ("Malyshev Artem" . "proofit404@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")
                 ("Malyshev Artem" . "proofit404@gmail.com")))
