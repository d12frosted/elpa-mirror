;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260531.1350"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "f23ecb9446091ef10dca024940bec8afedead532"
  :revdesc "f23ecb944609"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
