(define-package "etd" "20221003.114" "Examples to Tests and Docs"
  '((emacs "24.4"))
  :commit "f26f603d088631ce0466aa529de7156fa94ffbc5" :authors
  '(("Jason M23" . "jasonm23@gmail.com"))
  :maintainers
  '(("Jason M23" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason M23" . "jasonm23@gmail.com")
  :keywords
  '("lisp" "tools" "extensions")
  :url "https://github.com/emacsfodder/kurecolor")
;; Local Variables:
;; no-byte-compile: t
;; End:
