(define-package "evil-textobj-tree-sitter" "20230506.937" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.15.0"))
  :commit "9cd23a7aae91f07e26ea45912f4d351b5660a7fc" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
