(define-package "creamsody-theme" "20220817.356" "Straight from the soda fountain"
  '((autothemer "0.2")
    (emacs "24"))
  :commit "cc16c7ce5d733c5e77ea67342dc655ab8f920684" :url "http://github.com/emacsfodder/emacs-theme-creamsody")
;; Local Variables:
;; no-byte-compile: t
;; End:
