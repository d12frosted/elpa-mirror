(define-package "asyncloop" "20231020.2144" "Non-blocking series of functions"
  '((emacs "28.1"))
  :commit "ac4803e6e2998a60d39c9e6818ba05214409b7c5" :authors
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainers
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainer
  '(nil . "<meedstrom91@gmail.com>")
  :keywords
  '("tools")
  :url "https://github.com/meedstrom/asyncloop")
;; Local Variables:
;; no-byte-compile: t
;; End:
