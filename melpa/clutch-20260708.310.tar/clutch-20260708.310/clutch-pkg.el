;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260708.310"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "13af58ac6ba72f49963265c5ce54b6f9233305ac"
  :revdesc "13af58ac6ba7"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
