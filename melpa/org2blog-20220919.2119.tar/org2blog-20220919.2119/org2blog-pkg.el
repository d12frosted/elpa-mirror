(define-package "org2blog" "20220919.2119" "Blog from Org mode to WordPress"
  '((htmlize "1.56")
    (hydra "0.15.0")
    (xml-rpc "1.6.15")
    (writegood-mode "2.2.0")
    (metaweblog "1.1.15"))
  :commit "a87e5d665838478dc03416f078e7d6f2100604ea" :authors
  '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainer
  '("Grant Rettke" . "grant@wisdomandwonder.com")
  :keywords
  '("comm" "convenience" "outlines" "wp")
  :url "https://github.com/org2blog/org2blog")
;; Local Variables:
;; no-byte-compile: t
;; End:
