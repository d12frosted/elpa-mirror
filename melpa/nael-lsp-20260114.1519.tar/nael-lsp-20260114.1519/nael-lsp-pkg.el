;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nael-lsp" "20260114.1519"
  "Nael and lsp-mode."
  '((emacs    "29.1")
    (lsp-mode "9")
    (nael     "0.8.0"))
  :url "https://codeberg.org/mekeor/nael"
  :commit "1a462a61a3599c436c9284a23cae4ff8815a84da"
  :revdesc "1a462a61a359"
  :keywords '("languages")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
