;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260123.810"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "dfeacda2010371898987371c92240717d3d5e4a2"
  :revdesc "dfeacda20103"
  :keywords '("data" "extensions"))
