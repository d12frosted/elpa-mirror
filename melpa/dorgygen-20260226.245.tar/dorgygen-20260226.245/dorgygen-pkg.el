;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dorgygen" "20260226.245"
  "Source code documentation in org-mode."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/dorgygen"
  :commit "577c93529479b42ee6188652a21c5f02aefe43df"
  :revdesc "577c93529479"
  :keywords '("tools" "wp"))
