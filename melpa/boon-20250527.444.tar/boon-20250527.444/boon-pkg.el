;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boon" "20250527.444"
  "Ergonomic Command Mode for Emacs."
  '((emacs            "26.1")
    (dash             "2.12.0")
    (expand-region    "0.10.0")
    (multiple-cursors "1.3.0"))
  :url "https://github.com/jyp/boon"
  :commit "dbb576b9ca4e581bf4caefb37c0b5806faac8f42"
  :revdesc "dbb576b9ca4e")
