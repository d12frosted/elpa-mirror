(define-package "dwim-shell-command" "20221024.2044" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "628853eb17530c61fe0f296e2c3b16152bc88270" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
