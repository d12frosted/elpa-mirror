;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20260917.2217"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "26.3")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "5375714deb211bf1ee7c7d8ba05cd78ce6ab98cc"
  :revdesc "5375714deb21"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
