;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-tree-sitter" "20260309.1232"
  "Provides evil textobjects using tree-sitter."
  '((emacs "25.1"))
  :url "https://github.com/meain/evil-textobj-tree-sitter"
  :commit "5eafab855fd0064289fffe1ee29ba42457ccdea3"
  :revdesc "5eafab855fd0"
  :keywords '("evil" "tree-sitter" "text-object" "convenience"))
