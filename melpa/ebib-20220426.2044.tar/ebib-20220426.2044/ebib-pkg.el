(define-package "ebib" "20220426.2044" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "26.1"))
  :commit "a338d8b2007e9353a5ced6c98f12f3332e153f12" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
