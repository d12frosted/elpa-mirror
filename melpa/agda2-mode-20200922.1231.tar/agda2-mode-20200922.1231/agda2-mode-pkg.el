(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "f8d553bf387d57bd2cf54f1cb1bd80af7326be19")
;; Local Variables:
;; no-byte-compile: t
;; End:
