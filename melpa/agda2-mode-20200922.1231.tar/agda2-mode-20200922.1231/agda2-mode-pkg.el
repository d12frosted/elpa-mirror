(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "0d3153c2eaae4fd8d8f3c7513c4dd1c4efae733b")
;; Local Variables:
;; no-byte-compile: t
;; End:
