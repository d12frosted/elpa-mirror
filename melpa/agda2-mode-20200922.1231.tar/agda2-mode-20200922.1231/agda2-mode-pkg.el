(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "709480dfea1c25c4f6b4495161a59d83cd6c0aa4")
;; Local Variables:
;; no-byte-compile: t
;; End:
