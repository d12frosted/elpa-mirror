(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "fdace3b9c446a1d621858dc343f5ed80422d0ea1")
;; Local Variables:
;; no-byte-compile: t
;; End:
