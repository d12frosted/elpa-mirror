(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "31a8197154473f01aa3aedc939b47ff690160bd5")
;; Local Variables:
;; no-byte-compile: t
;; End:
