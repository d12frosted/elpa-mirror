(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "ac044e77fa98625ca90ee21732236355c05ffac9")
;; Local Variables:
;; no-byte-compile: t
;; End:
