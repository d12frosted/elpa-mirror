(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "e12f391d2539b62a62d18aef74149a9a4695a871")
;; Local Variables:
;; no-byte-compile: t
;; End:
