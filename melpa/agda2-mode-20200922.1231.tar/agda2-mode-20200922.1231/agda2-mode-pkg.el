(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "5070bd8c145c4ada51266be9728f08749dc9fd3e")
;; Local Variables:
;; no-byte-compile: t
;; End:
