(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "2a8f1e74500b1d2c27a5dc19ad221de5bbb37ce4")
;; Local Variables:
;; no-byte-compile: t
;; End:
