(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "35410dfc952c70cc364eb44587bfb4065ee7b4c8")
;; Local Variables:
;; no-byte-compile: t
;; End:
