(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c71681368fdedcc83a136b4dc7b01e08b8a938ba")
;; Local Variables:
;; no-byte-compile: t
;; End:
