(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "03e85253bbc2528a9f94b883ca3fef81aafc355b")
;; Local Variables:
;; no-byte-compile: t
;; End:
