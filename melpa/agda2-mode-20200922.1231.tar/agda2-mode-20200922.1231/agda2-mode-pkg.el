(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c5400349d7d9cb1e54af19bdb2046b52ecada5bc")
;; Local Variables:
;; no-byte-compile: t
;; End:
