;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251008.1041"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "b7aa47fbc23711d539705d7a4ad5949f587d173e"
  :revdesc "b7aa47fbc237"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
