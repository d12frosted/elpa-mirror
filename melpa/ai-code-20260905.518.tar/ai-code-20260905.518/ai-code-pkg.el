;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260905.518"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "f934e2cc0c5a1a18cbcbeb097f19fdb573ec78ef"
  :revdesc "f934e2cc0c5a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
