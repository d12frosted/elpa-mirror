;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260127.918"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "8c730189cd6346dd6f31428772f71c29cf566e79"
  :revdesc "8c730189cd63"
  :keywords '("comm"))
