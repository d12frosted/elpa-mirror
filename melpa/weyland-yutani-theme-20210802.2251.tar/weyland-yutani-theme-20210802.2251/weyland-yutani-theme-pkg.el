;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weyland-yutani-theme" "20210802.2251"
  "Emacs theme based off Alien movie franchise."
  '((emacs "24.1"))
  :url "https://github.com/jstaursky/weyland-yutani-theme"
  :commit "e89a63a62e071180c9cdd9067679fadc3f7bf796"
  :revdesc "e89a63a62e07")
