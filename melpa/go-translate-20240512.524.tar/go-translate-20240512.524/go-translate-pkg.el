(define-package "go-translate" "20240512.524" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "c2f58ec36cf54ef84046901eefd51f33372666c5" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
