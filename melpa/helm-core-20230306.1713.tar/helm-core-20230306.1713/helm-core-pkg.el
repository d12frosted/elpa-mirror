(define-package "helm-core" "20230306.1713" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "d6b3adb4a6e89b4de0e58fe9b080020456568c8d" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
