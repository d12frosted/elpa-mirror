;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250331.735"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f3ea2cb33889e87165ea63406eabb1615a2c1724"
  :revdesc "f3ea2cb33889"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
