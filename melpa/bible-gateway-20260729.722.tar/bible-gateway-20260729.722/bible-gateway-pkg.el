;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260729.722"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "793183b1768da6896c14943c00dde7fb1bb1d7ae"
  :revdesc "793183b1768d"
  :keywords '("convenience" "comm" "hypermedia"))
