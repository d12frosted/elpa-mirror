;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "libmpdel" "20250609.909"
  "Communication with an MPD server."
  '((emacs "25.1"))
  :url "https://github.com/mpdel/libmpdel"
  :commit "d299cacc272f90d8a2704a72c52a5ef8cf423e8c"
  :revdesc "d299cacc272f"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
