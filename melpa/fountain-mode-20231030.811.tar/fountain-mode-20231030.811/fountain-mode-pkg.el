(define-package "fountain-mode" "20231030.811" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "b72da79e5be8cf96c82c19042fb5bbc80323e013" :authors
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainers
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainer
  '("Paul W. Rankin" . "hello@paulwrankin.com")
  :keywords
  '("wp" "text")
  :url "https://www.fountain-mode.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
