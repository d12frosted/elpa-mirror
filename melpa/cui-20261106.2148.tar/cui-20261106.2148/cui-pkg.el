;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261106.2148"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "494dfcd1b74734c2f6a3624b8405143b2274c0e8"
  :revdesc "494dfcd1b747"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
