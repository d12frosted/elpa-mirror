;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "retraction-viewer-section" "20240509.1440"
  "Show retraction information in the universal-sidecar."
  '((emacs             "25.1")
    (retraction-viewer "1.0.2")
    (universal-sidecar "1.5.1"))
  :url "https://git.sr.ht/~swflint/retraction-viewer"
  :commit "e8ab96e5a95a93849b912e2684b9776c685ac4bd"
  :revdesc "e8ab96e5a95a"
  :keywords '("bib" "tex")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
