;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredfd" "20260204.1745"
  "Dired functions and settings to mimic FD/FDclone."
  '((emacs "28.1"))
  :url "https://github.com/knu/diredfd.el"
  :commit "f2534e61c158fc6947580c4831391abccc01a667"
  :revdesc "f2534e61c158"
  :keywords '("unix" "directories" "dired")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
