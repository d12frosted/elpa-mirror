;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20261103.1506"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "b43005dc735c65bf0e09805a35e06c43b384ac22"
  :revdesc "b43005dc735c"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
