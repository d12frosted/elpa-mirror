(define-package "vulpea" "20210930.527" "A collection of org-roam note-taking functions"
  '((emacs "27.1")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12"))
  :commit "b5cbe33c1891e8e1756da52ff911750c0da00f79" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
