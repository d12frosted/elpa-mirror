(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "d8492f754068cc481482dc5ffec4769dc3b8884a" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
