(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "7dd6dacb10264c0035ea999fa110517f039c8cf1" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
