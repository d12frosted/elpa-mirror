(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "37492858b61907e4728b2e68e67238c68e9a0d49" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
