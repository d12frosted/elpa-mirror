(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "2c61fff4ec8fea9a0bdefd13a7a14a34c5e27ada" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
