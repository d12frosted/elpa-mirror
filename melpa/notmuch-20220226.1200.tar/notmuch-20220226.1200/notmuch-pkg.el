(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "b2eb0547e172dd766ccbc062319faa90a9500518" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
