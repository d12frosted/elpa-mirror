(define-package "kubectx-mode" "20200116.1918" "Change kubectl context/namespace and show in mode line"
  '((emacs "24"))
  :commit "f08687ae5403eb18bbeffc6dafdfde469bdb9a36" :authors
  '(("Terje Sannum" . "terje@offpiste.org"))
  :maintainers
  '(("Terje Sannum" . "terje@offpiste.org"))
  :maintainer
  '("Terje Sannum" . "terje@offpiste.org")
  :keywords
  '("tools" "kubernetes")
  :url "https://github.com/terjesannum/emacs-kubectx-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
