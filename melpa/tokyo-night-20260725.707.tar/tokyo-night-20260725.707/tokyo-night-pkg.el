;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20260725.707"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "8018d01efb80bc07d7311af8b9d7b934dfd6b19a"
  :revdesc "8018d01efb80"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
