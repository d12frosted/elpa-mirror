(define-package "fanyi" "20211211.201" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "c328cdd1c5a0e734937125771279838e401fc5a8" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
