;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "20241229.1725"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "e0c780b04682608431f3a8480bdb63ad91c69fc2"
  :revdesc "e0c780b04682"
  :keywords '("convenience"))
