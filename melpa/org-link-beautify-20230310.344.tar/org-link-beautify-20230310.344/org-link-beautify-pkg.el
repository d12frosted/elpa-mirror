(define-package "org-link-beautify" "20230310.344" "Beautify Org Links"
  '((emacs "28.1")
    (all-the-icons "5.0.0"))
  :commit "d4f1daf872fd995cec6708ae2f37a9f48c47fa93" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
