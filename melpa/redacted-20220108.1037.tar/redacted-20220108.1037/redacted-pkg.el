;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redacted" "20220108.1037"
  "Obscure text in buffer."
  '((emacs "25.1"))
  :url "https://github.com/bkaestner/redacted.el"
  :commit "b3f44ccf51d9d5274f7837fc825db0a378055744"
  :revdesc "b3f44ccf51d9"
  :keywords '("games")
  :authors '(("Benjamin Kästner" . "benjamin.kaestner@gmail.com"))
  :maintainers '(("Benjamin Kästner" . "benjamin.kaestner@gmail.com")))
