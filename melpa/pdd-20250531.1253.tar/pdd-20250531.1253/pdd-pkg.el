;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250531.1253"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "cf45dccead3895463d284dda135d1236fb5d760d"
  :revdesc "cf45dccead38"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
