;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-lsi" "20200812.929"
  "Add memo to directory and show it in dired."
  '((emacs "26.1"))
  :url "https://github.com/conao3/dired-lsi.el"
  :commit "0f4038c8b47f6cfc70f82062800700c14c9912c2"
  :revdesc "0f4038c8b47f"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
