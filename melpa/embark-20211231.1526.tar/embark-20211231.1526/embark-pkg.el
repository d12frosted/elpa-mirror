(define-package "embark" "20211231.1526" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "6572462f6c9ffbf720f53def86462e95de887610" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
