;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-kill" "20260102.958"
  "Kill & mark things easily."
  '((emacs  "25")
    (cl-lib "0.5"))
  :url "https://github.com/leoliu/easy-kill"
  :commit "1fd349ed0339f345beeb52a4850aa44190996f3b"
  :revdesc "1fd349ed0339"
  :keywords '("killing" "convenience")
  :authors '(("Leo Liu" . "sdl.web@gmail.com"))
  :maintainers '(("Leo Liu" . "sdl.web@gmail.com")))
