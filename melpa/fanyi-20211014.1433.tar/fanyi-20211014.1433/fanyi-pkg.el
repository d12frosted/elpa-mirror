(define-package "fanyi" "20211014.1433" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "f812604614ff4a2ed9bd81f0dc9fbf170953d610" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
