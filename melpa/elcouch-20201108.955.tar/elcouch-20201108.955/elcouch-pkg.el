(define-package "elcouch" "20201108.955" "View and manipulate CouchDB databases"
  '((emacs "25.1")
    (json-mode "1.0.0")
    (libelcouch "0.11.0")
    (navigel "0.3.0"))
  :commit "3d162dda14411349e12509029d2b621c5d1edea2" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("data" "tools")
  :url "https://gitlab.petton.fr/DamienCassou/elcouch")
;; Local Variables:
;; no-byte-compile: t
;; End:
