(define-package "eziam-theme" "20200327.1810" "A mostly monochrome theme, inspired by Tao and Leuven, with dark and light versions." 'nil :commit "f30927040c77f88cd1859be59978cddd238bf386")
;; Local Variables:
;; no-byte-compile: t
;; End:
