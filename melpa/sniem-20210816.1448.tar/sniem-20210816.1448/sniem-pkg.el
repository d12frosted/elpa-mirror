(define-package "sniem" "20210816.1448" "Simple united editing method"
  '((emacs "26.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "fe1247befd04b163ad86de45c9faf23e7fe9b37e" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
