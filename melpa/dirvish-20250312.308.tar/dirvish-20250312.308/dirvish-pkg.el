;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250312.308"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "622996fb41def424d888266a89b4677440b55aef"
  :revdesc "622996fb41de"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
