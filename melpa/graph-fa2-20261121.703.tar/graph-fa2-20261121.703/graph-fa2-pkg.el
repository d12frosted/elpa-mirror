;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graph-fa2" "20261121.703"
  "ForceAtlas2 pure-elisp background-cached engine."
  '((emacs "27.1"))
  :url "https://github.com/elij/graph-fa2"
  :commit "069c15c67c1e440162ff9d5e2ade53d46bb6c647"
  :revdesc "069c15c67c1e"
  :keywords '("multimedia" "graphs" "visualization")
  :authors '(("Elijah Charles" . "https://github.com/elij"))
  :maintainers '(("Elijah Charles" . "https://github.com/elij")))
