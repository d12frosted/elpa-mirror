;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20261112.442"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "22cb3ff7b14821d98a5be6b324357a21bc46fef3"
  :revdesc "22cb3ff7b148"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
