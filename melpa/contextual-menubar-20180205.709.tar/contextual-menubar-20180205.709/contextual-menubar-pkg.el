;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "contextual-menubar" "20180205.709"
  "Display the menubar only on a graphical display."
  ()
  :url "https://github.com/aaronjensen/contextual-menubar"
  :commit "f76f55232ac07df76ef9a334a0c527dfab97c40b"
  :revdesc "f76f55232ac0"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
