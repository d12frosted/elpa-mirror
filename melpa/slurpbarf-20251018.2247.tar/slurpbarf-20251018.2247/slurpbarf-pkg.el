;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slurpbarf" "20251018.2247"
  "Commands for slurping and barfing."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "20f209035ab01a798645efa29650dfd67d50fad4"
  :revdesc "20f209035ab0"
  :keywords '("convenience" "lisp" "xml"))
