;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260320.1043"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "17e51d83c6385e6e24b94a2a839910e899b418cb"
  :revdesc "17e51d83c638"
  :keywords '("data" "extensions"))
