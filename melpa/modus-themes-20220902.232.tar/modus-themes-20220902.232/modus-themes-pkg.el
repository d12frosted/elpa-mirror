(define-package "modus-themes" "20220902.232" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "6dd3c0ef8174afecff39d46280ebd56c19de97b7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
