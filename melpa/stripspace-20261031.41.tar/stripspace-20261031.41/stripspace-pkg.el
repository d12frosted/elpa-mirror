;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20261031.41"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "9cdcb1b74eabdc4a7d7b9565da4de59af1ae74b8"
  :revdesc "9cdcb1b74eab"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
