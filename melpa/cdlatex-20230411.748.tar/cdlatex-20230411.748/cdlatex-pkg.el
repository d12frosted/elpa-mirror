(define-package "cdlatex" "20230411.748" "Fast input methods for LaTeX environments and math" 'nil :commit "692142603c6229e5aa5c8285eb797e401cef9ac3" :authors
  '(("Carsten Dominik" . "carsten.dominik@gmail.com"))
  :maintainers
  '(("Carsten Dominik" . "carsten.dominik@gmail.com"))
  :maintainer
  '("Carsten Dominik" . "carsten.dominik@gmail.com")
  :keywords
  '("tex"))
;; Local Variables:
;; no-byte-compile: t
;; End:
