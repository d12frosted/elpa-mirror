;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srv" "20180715.1959"
  "Perform SRV DNS requests."
  '((emacs "24.3"))
  :url "https://github.com/legoscia/srv.el"
  :commit "714387d5a5cf34d8d8cd96bdb1f9cb8ded823ff7"
  :revdesc "714387d5a5cf"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainers '(("Magnus Henoch" . "magnus.henoch@gmail.com")))
