;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol-freshrss" "20260920.119"
  "FreshRSS compatible gReader protocol implementation for elfeed."
  '((emacs            "29.1")
    (elfeed           "4.0.0")
    (elfeed-protocol  "1.0.0")
    (deferred         "0.5.1")
    (request          "0.3.2")
    (request-deferred "0.3.2"))
  :url "https://codeberg.org/lou/elfeed-protocol-freshrss"
  :commit "5b282ae09f994d9d63ac2f7aa0d07414d9802464"
  :revdesc "5b282ae09f99"
  :authors '(("Lou Woell" . "lou@repetitions.de"))
  :maintainers '(("Lou Woell" . "lou@repetitions.de")))
