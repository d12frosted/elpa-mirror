(define-package "diredc" "20240122.1502" "Extensions for dired"
  '((emacs "26.1")
    (key-assist "1.0"))
  :commit "1082b1d399b6f291bd3eccd6d85ed8fd14c654ab" :keywords
  '("files")
  :url "https://github.com/Boruch-Baum/emacs-diredc")
;; Local Variables:
;; no-byte-compile: t
;; End:
