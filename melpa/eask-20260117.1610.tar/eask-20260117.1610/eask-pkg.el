;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20260117.1610"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "e8857600be6b9c3e40edbff6fd56fcfbc6286679"
  :revdesc "e8857600be6b"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
