;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260827.1930"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "8cfcbd09a55394ec12808b1abf074ac20404899c"
  :revdesc "8cfcbd09a553"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
