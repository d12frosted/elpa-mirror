;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260225.413"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "56cec058a0e368c77c727577d3e1453d0ae7b6bc"
  :revdesc "56cec058a0e3"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
