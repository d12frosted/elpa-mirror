(define-package "rcirc-alert" "20141127.1047" "Configurable alert messages on top of RCIRC" 'nil :commit "0adf8ff9c47023fec578f678424be62b0f49057f" :keywords
  ("lisp" "rcirc" "irc" "alert" "awesome")
  :maintainer
  ("Cayetano Santos"))
;; Local Variables:
;; no-byte-compile: t
;; End:
