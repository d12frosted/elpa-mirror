;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "theme-anchor" "20250530.309"
  "Apply theme in current buffer only."
  '((emacs "26"))
  :url "https://github.com/GongYiLiao/theme-anchor"
  :commit "d379c97654cc2801574563afdea6ac582330974d"
  :revdesc "d379c97654cc"
  :keywords '("extensions" "lisp" "theme")
  :authors '(("Kiong-Gē" . "gliao.tw@pm.me"))
  :maintainers '(("Kiong-Gē" . "gliao.tw@pm.me")))
