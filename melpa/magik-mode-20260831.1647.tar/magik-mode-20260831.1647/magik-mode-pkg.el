;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260831.1647"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "5a8598f36cf8c691270125c8d6254cc0263a8e70"
  :revdesc "5a8598f36cf8"
  :keywords '("languages"))
