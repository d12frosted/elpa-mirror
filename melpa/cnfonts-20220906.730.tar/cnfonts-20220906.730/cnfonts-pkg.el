(define-package "cnfonts" "20220906.730" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "d1fc8ebc0b4964e3414bb8b9b6cc8e3b475f7f3c" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
