(define-package "modus-themes" "20220105.737" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "128e6046026ce304442a6ae75cc71fc621912e3a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
