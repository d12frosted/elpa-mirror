;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20261002.1417"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "3e019ebf6e3f36ace96a6889dc4667beb0b3d4c6"
  :revdesc "3e019ebf6e3f"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
