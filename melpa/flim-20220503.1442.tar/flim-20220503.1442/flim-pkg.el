(define-package "flim" "20220503.1442" "A library to provide basic features about message representation or encoding."
  '((emacs "24.5")
    (apel "10.8")
    (oauth2 "0.11"))
  :commit "f8dcbb8b4e6fa0d72212d478fb4a1e74804a2aa8")
;; Local Variables:
;; no-byte-compile: t
;; End:
