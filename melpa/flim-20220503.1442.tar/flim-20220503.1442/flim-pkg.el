(define-package "flim" "20220503.1442" "A library to provide basic features about message representation or encoding."
  '((emacs "24.5")
    (apel "10.8")
    (oauth2 "0.11"))
  :commit "289e5bbd66f6f14306a6e0b922ee8f26267e2470")
;; Local Variables:
;; no-byte-compile: t
;; End:
