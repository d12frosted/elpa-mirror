;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260405.643"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f7dc4065bf6869454152e8e09adf0391de5af00e"
  :revdesc "f7dc4065bf68"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
