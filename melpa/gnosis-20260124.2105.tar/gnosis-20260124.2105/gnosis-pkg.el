;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260124.2105"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "cbb694bc9c89091faa7259f39c84ba97bbc25743"
  :revdesc "cbb694bc9c89"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
