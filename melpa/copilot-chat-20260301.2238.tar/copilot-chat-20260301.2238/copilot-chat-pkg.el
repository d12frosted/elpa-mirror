;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20260301.2238"
  "Copilot chat interface."
  '((emacs         "29.1")
    (aio           "1.0")
    (request       "0.3.2")
    (transient     "0.8.3")
    (polymode      "0.2.2")
    (org           "9.4.6")
    (markdown-mode "2.6")
    (shell-maker   "0.76.2")
    (mcp           "0.1.0"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "df46f7da5b716cd221e09f072516aa14cb9a9106"
  :revdesc "df46f7da5b71"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
