(define-package "consult" "20210625.1351" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "da14bfb035c07b579f351f3a2828a9e6dffc597b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
