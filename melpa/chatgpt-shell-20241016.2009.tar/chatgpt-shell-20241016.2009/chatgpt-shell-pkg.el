;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241016.2009"
  "ChatGPT shell + buffer insert commands."
  '((emacs       "27.1")
    (shell-maker "0.53.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "c845ada7074271b44a458043fbe3f160cfd7956e"
  :revdesc "c845ada70742")
