;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iqa" "20201113.849"
  "Init file(and directory) Quick Access."
  '((emacs "24.3"))
  :url "https://github.com/a13/iqa.el"
  :commit "eed962679783133e1ff6ae63d19efaeae4dadb6b"
  :revdesc "eed962679783")
