;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-backspace" "20171014.526"
  "Intellj like backspace."
  ()
  :url "https://github.com/itome/smart-backspace"
  :commit "acb390628a181a993aa0d137624f2e5283efa6d9"
  :revdesc "acb390628a18"
  :authors '(("Takeshi Tsukamoto" . "t.t.itm.0403@gmail.com"))
  :maintainers '(("Takeshi Tsukamoto" . "t.t.itm.0403@gmail.com")))
