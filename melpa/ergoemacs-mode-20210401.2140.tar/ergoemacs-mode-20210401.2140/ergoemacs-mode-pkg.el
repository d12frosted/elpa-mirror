(define-package "ergoemacs-mode" "20210401.2140" "Emacs mode based on common modern interface and ergonomics."
  '((emacs "24.1")
    (undo-tree "0.6.5")
    (cl-lib "0.5"))
  :commit "fc097bd8bcd313beb9563b5d48a60bc1f4b621c7" :authors
  '(("Xah Lee" . "xah@xahlee.org")
    ("David Capello" . "davidcapello@gmail.com")
    ("Matthew L. Fidler" . "matthew.fidler@gmail.com"))
  :maintainer
  '("Matthew L. Fidler" . "matthew.fidler@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ergoemacs/ergoemacs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
