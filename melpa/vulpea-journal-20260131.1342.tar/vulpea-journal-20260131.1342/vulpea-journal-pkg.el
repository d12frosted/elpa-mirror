;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-journal" "20260131.1342"
  "Daily note interface for vulpea."
  '((emacs     "29.1")
    (vulpea    "2.0.0")
    (vulpea-ui "1.0.0")
    (dash      "2.20.0"))
  :url "https://github.com/d12frosted/vulpea-journal"
  :commit "7525fde77555d25cbe3b78fbe5cf35113b65e7cd"
  :revdesc "7525fde77555"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
