(define-package "eldev" "20210516.2029" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "006d2474a58ba7cb63911d5a9b8b9febba6593c7" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
