(define-package "clojure-ts-mode" "20230825.147" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "3e4c55fab14e0885a411f6018fb8aedb04afc49d" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
