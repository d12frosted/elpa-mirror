(define-package "oer-reveal" "20201221.909" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "63a3b7744e1820bfc832f3f2ba03e7a9231e806d" :keywords
  ("hypermedia" "tools" "slideshow" "presentation" "oer")
  :authors
  (("Jens Lechtenbörger"))
  :maintainer
  ("Jens Lechtenbörger")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
