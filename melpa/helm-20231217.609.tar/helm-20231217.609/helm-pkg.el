(define-package "helm" "20231217.609" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.7")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "2ea205c890602cd4d8c6bf0dd6cb42fba73b48ab" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
