;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261002.123"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "36e979f1c64f509da6e96f501894f771833dc858"
  :revdesc "36e979f1c64f"
  :keywords '("build tools" "languages"))
