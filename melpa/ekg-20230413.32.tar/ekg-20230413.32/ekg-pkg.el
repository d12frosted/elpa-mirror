(define-package "ekg" "20230413.32" "A system for recording and linking information"
  '((triples "0.2.5")
    (emacs "28.1"))
  :commit "4d86dac060439f5197dbfcaebd18a227bdce5e1d" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
