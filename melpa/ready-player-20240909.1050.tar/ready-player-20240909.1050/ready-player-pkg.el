(define-package "ready-player" "20240909.1050" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "9b8d28f9e67ec75cab14043b38d28b2727cabc04" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
