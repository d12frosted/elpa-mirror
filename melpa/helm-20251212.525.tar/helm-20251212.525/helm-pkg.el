;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251212.525"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "0009e20e48b3e1300b1187e738b76de711ed8e08"
  :revdesc "0009e20e48b3"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
