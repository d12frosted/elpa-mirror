;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leadkey" "20260706.257"
  "Translate leader keys to key sequences."
  '((emacs "30.1"))
  :url "https://github.com/jixiuf/emacs-leadkey"
  :commit "a7bf4c8a5bfee908c5287ebe86dcbaddd2b0fb8d"
  :revdesc "a7bf4c8a5bfe"
  :keywords '("convenience")
  :authors '(("jixiuf" . "https://github.com/jixiuf"))
  :maintainers '(("jixiuf" . "https://github.com/jixiuf")))
