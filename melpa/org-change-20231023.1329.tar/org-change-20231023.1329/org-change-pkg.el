(define-package "org-change" "20231023.1329" "Annotate changes in org-mode files"
  '((emacs "26.1")
    (org "9.3"))
  :commit "d8c6d9b1de5570a0e8700abd17377444f296ca53" :keywords
  '("wp" "convenience")
  :url "https://github.com/drghirlanda/org-change")
;; Local Variables:
;; no-byte-compile: t
;; End:
