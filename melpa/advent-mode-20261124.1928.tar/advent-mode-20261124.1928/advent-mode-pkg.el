;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20261124.1928"
  "Advent of Code mode."
  '((emacs "29.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "bcf9898f080c19978db1c6d03ce6def336ab101c"
  :revdesc "bcf9898f080c"
  :keywords '("lisp")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
