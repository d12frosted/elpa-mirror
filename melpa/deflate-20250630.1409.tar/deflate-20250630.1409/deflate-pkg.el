;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "deflate" "20250630.1409"
  "The DEFLATE compression algorithm in pure Emacs LISP."
  '((dash  "2.0.0")
    (emacs "25.1"))
  :url "https://github.com/skuro/deflate"
  :commit "799390bb8bb88b230ae3ebf9d22cbb4457cdb71d"
  :revdesc "799390bb8bb8"
  :keywords '("files" "tools")
  :authors '(("Carlo Sciolla" . "carlo.sciolla@gmail.com"))
  :maintainers '(("Carlo Sciolla" . "carlo.sciolla@gmail.com")))
