;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu-session" "20250610.52"
  "Persistent undo, available between sessions."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu-session"
  :commit "d600ce368e9509f4ec2d425dc4bf48c3043f9354"
  :revdesc "d600ce368e95"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
