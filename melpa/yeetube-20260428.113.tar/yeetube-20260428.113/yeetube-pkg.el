;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260428.113"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "dc420f11bcb4276802e0d8bbff3a034be6aad92e"
  :revdesc "dc420f11bcb4"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
