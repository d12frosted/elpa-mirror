;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260308.1451"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.87.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "07f9130993d41a969fbe8ba23028fc8ad1855f07"
  :revdesc "07f9130993d4")
