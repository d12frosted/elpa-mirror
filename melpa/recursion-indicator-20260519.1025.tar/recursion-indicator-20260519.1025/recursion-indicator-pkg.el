;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recursion-indicator" "20260519.1025"
  "Recursion indicator."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/recursion-indicator"
  :commit "eb33010866742808cabae694fa4e77b33737522e"
  :revdesc "eb3301086674"
  :keywords '("convenience")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
