;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261015.2302"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "eb27245c02fb596d2836ab9f3e2b0d81d1d47c39"
  :revdesc "eb27245c02fb"
  :keywords '("build tools" "languages"))
