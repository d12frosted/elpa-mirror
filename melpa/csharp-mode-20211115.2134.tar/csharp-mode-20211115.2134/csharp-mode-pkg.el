(define-package "csharp-mode" "20211115.2134" "C# mode derived mode"
  '((emacs "26.1"))
  :commit "515b866704252fc862144d9ff677fba75488e445" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
