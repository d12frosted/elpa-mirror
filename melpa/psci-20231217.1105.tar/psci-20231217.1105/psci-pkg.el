(define-package "psci" "20231217.1105" "Major mode for purescript repl psci"
  '((emacs "25.1")
    (purescript-mode "13.10")
    (dash "2.9.0")
    (inheritenv "0.2"))
  :commit "2cc15af3703329a85289c73814d3ff34c9034a8f" :authors
  '(("Antoine R. Dumont <eniotna.t AT gmail.com>"))
  :maintainers
  '(("Antoine R. Dumont <eniotna.t AT gmail.com>"))
  :maintainer
  '("Antoine R. Dumont <eniotna.t AT gmail.com>")
  :keywords
  '("languages" "purescript" "psci" "repl")
  :url "https://github.com/purescript-emacs/emacs-psci")
;; Local Variables:
;; no-byte-compile: t
;; End:
