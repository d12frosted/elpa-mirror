(define-package "eldev" "20220306.1826" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "198910a70e3ef376283bf0d2cae516973e69a5a2" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
