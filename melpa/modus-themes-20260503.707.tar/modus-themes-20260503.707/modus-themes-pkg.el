;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260503.707"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "5efd13653a9071fa286acb52a46b1b2304bba62d"
  :revdesc "5efd13653a90"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
