(define-package "himalaya" "20230711.925" "Interface for the himalaya email client"
  '((emacs "27.1"))
  :commit "087c66964182221250c746f65584f332c97a4c86" :authors
  '(("Dante Catalfamo")
    ("soywod" . "clement.douin@posteo.net"))
  :maintainers
  '(("Dante Catalfamo"))
  :maintainer
  '("Dante Catalfamo")
  :keywords
  '("mail" "comm")
  :url "https://github.com/dantecatalfamo/himalaya-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
