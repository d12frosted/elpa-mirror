;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20251006.437"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "48f6188a6c7661ef8b5094d434b8c6b442d8d7de"
  :revdesc "48f6188a6c76"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
