(define-package "cape" "20220428.950" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "7f22485d61ddee0063493a25d9800c67421d8a0a" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
