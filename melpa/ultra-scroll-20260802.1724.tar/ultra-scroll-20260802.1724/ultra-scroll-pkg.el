;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultra-scroll" "20260802.1724"
  "Fast and smooth scrolling."
  '((emacs "29.1"))
  :url "https://github.com/jdtsmith/ultra-scroll"
  :commit "e8c0a938bd03971ffd8beefbf01481e7a136b594"
  :revdesc "e8c0a938bd03"
  :keywords '("convenience"))
