(define-package "dirvish" "20220413.1257" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "78ba565d1aa476d76e799876716ea2ff79a6aadc" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
