(define-package "osm" "20221021.1152" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "5b24ed076c9998be627c19549d403d5b219b7b28" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
