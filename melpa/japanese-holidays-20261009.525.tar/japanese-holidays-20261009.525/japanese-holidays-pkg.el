;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "japanese-holidays" "20261009.525"
  "Calendar functions for the Japanese calendar."
  '((emacs  "24.1")
    (cl-lib "0.3"))
  :url "https://github.com/emacs-jp/japanese-holidays"
  :commit "5a36492195422ea5446fc0895d7070f29999fffd"
  :revdesc "5a3649219542"
  :keywords '("calendar")
  :authors '(("Takashi Hattori" . "hattori@sfc.keio.ac.jp")
             ("Hiroya Murata" . "lapis-lazuli@pop06.odn.ne.jp"))
  :maintainers '(("Takashi Hattori" . "hattori@sfc.keio.ac.jp")
                 ("Hiroya Murata" . "lapis-lazuli@pop06.odn.ne.jp")))
