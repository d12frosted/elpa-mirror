(define-package "embark" "20211229.2056" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "81520eb69e0b4e1b5b5e1f348f043a0df54fe4a9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
