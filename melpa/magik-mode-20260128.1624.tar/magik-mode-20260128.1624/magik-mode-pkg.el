;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260128.1624"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "b1fc21f82e9d4bd3948589cee9491cf48a138934"
  :revdesc "b1fc21f82e9d"
  :keywords '("languages"))
