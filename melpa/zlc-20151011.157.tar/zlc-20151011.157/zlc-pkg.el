;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zlc" "20151011.157"
  "Provides zsh like completion system to Emacs."
  ()
  :url "https://github.com/mooz/emacs-zlc"
  :commit "4dd2ba267ecdeac845a7cbb3147294ee7daa25f4"
  :revdesc "4dd2ba267ecd"
  :keywords '("matching" "convenience")
  :authors '(("mooz" . "stillpedant@gmail.com"))
  :maintainers '(("mooz" . "stillpedant@gmail.com")))
