;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20261126.1300"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "bf8bbc0f2f88ad90bfb69f4c72d290babb18774c"
  :revdesc "bf8bbc0f2f88"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
