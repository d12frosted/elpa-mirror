;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250228.909"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "afefb33d722579f80ffe68b3c17945dd21fc81fd"
  :revdesc "afefb33d7225"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
