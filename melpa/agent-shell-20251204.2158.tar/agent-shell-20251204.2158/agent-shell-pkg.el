;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251204.2158"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ea9919be1f10459080ed9402e8aebba43f227168"
  :revdesc "ea9919be1f10")
