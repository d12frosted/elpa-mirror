;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20250615.1121"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "e853a146142544b080d9cbaa00379da4abd6103b"
  :revdesc "e853a1461425"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
