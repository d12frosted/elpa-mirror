(define-package "hippo-themes" "20230611.2119" "Hippo color theme"
  '((emacs "24.1"))
  :commit "f9a42e25a9dacff7471d702aff75eed98659c181" :authors
  '(("Kimi MA"))
  :maintainers
  '(("Kimi MA"))
  :maintainer
  '("Kimi MA")
  :keywords
  '("faces" "local" "color" "theme")
  :url "http://github.com/kimim/emacs-hippo-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
