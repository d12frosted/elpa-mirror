(define-package "cape" "20230122.1117" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "f1b359eb81d9ac6756c20d09167b08bfe13807c9" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
