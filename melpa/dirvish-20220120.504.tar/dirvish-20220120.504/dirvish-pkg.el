(define-package "dirvish" "20220120.504" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "762db50fa84decf5ec2b87ea51f5c8b70680a0af" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
