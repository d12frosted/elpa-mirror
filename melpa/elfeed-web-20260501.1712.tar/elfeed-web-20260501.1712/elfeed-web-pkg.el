;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-web" "20260501.1712"
  "Web interface to Elfeed."
  '((emacs        "28.1")
    (compat       "30")
    (elfeed       "3.4.2")
    (simple-httpd "1.5.1"))
  :url "https://github.com/emacs-elfeed/elfeed-web"
  :commit "500f7ea52590a0fc1bcf95403b52e04053389906"
  :revdesc "500f7ea52590"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
