;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260426.1741"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "d5a4c66fd6b92184411b8be61cfa2f14b905f9e6"
  :revdesc "d5a4c66fd6b9"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
