;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251124.537"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "823d31d19b2a2d23e6287aca15eaba3153eea570"
  :revdesc "823d31d19b2a"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
