;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-dark-theme" "20260202.706"
  "Visual Studio IDE dark theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-dark-theme"
  :commit "20c80dbc98e35022bacecd80783ff7b92fef6e15"
  :revdesc "20c80dbc98e3"
  :keywords '("faces"))
