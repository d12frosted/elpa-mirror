(define-package "loopy" "20210630.220" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "1211a9efd203fb1a3fa2975b26df0ccc64f4612c" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
