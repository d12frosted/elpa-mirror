;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260530.2016"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "0ab7baa2e5a48f0d90bfa3040e8bb150ea5e6e47"
  :revdesc "0ab7baa2e5a4"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
