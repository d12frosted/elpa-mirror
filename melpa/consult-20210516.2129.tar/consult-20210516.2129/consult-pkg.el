(define-package "consult" "20210516.2129" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9cc56bbd0d205b46550e5eb972ebe45ed297de87" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
