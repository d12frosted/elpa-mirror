;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "20260823.1231"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "a450b436e2cdb1b18d16fd273b1ce405d095c0f9"
  :revdesc "a450b436e2cd"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
