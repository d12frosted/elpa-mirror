;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260212.946"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "514714f60ad17d1cabe63de41bc0efa568e0f60e"
  :revdesc "514714f60ad1"
  :keywords '("hypermedia"))
