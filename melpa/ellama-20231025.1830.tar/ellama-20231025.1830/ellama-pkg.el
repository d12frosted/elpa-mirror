(define-package "ellama" "20231025.1830" "Ollama client for calling local LLMs"
  '((emacs "28.1")
    (spinner "1.7.4"))
  :commit "6b0108b8d6d538b1f68a338e337855f485854712" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
