;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20260306.305"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "0a459cb3e2b633e9a035e3bbc6299efc85e67c0f"
  :revdesc "0a459cb3e2b6"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
