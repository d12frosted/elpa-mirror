(define-package "netease-cloud-music" "20210810.1210" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "88a4c4dd3ea740a39a6151bfdff21e321ac3dbff" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
