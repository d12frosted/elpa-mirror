;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251209.1452"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.2")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "21bd1acf7a006b7edaa41d1910545ad5d76c0790"
  :revdesc "21bd1acf7a00")
