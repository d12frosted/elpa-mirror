;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "khoj" "20260325.2010"
  "Your Second Brain."
  '((emacs     "27.1")
    (transient "0.3.0")
    (dash      "2.19.1"))
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs"
  :commit "7475a781bc151bd97240f7c0ff667ce01d6f6378"
  :revdesc "7475a781bc15"
  :keywords '("search" "chat" "ai" "org-mode" "outlines" "markdown" "pdf" "image")
  :authors '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
             ("Saba Imran" . "saba@khoj.dev"))
  :maintainers '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
                 ("Saba Imran" . "saba@khoj.dev")))
