;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260715.1836"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "f549babc2bc449b2df5390ab41776f31c711f84e"
  :revdesc "f549babc2bc4"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
