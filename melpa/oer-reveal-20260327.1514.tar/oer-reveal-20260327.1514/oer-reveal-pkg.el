;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "20260327.1514"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.38.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "35f8e50dea185f4df0ac5ef08dd4ad26179c4e75"
  :revdesc "35f8e50dea18"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
