(define-package "flymake-collection" "20230420.849" "Collection of checkers for flymake, bringing flymake to the level of flycheck"
  '((emacs "28.1")
    (let-alist "1.0")
    (flymake "1.2.1"))
  :commit "16a41c45ea1837b96425dcb906b9209611e21280" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("language" "tools")
  :url "https://github.com/mohkale/flymake-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
