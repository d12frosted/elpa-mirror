(define-package "ekg" "20230810.316" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1"))
  :commit "c668d397add6b84a7e35dfae04cdfb2be451f032" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
