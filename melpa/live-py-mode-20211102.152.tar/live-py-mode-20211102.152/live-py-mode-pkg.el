(define-package "live-py-mode" "20211102.152" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "bd933c7351751eecc0f988166e983a9e478531be" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
