;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tblui" "20231201.1100"
  "Define tabulated list UI easily."
  '((dash        "2.12.1")
    (magit-popup "2.6.0")
    (tablist     "0.70")
    (cl-lib      "0.5"))
  :url "https://github.com/Yuki-Inoue/tblui.el"
  :commit "62ab5f62982c061a902fd3e54d94a68a4706572c"
  :revdesc "62ab5f62982c"
  :authors '(("Yuki Inoue" . "inouetakahiroki_at_gmail.com"))
  :maintainers '(("Yuki Inoue" . "inouetakahiroki_at_gmail.com")))
