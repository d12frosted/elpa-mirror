;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tickscript-mode" "20171219.203"
  "A major mode for Tickscript files."
  '((emacs "24.1"))
  :url "https://github.com/msherry/tickscript-mode"
  :commit "f0579f38ff14954df5002ce30ae6d4a2c978d461"
  :revdesc "f0579f38ff14"
  :keywords '("languages")
  :authors '(("Marc Sherry" . "msherry@gmail.com"))
  :maintainers '(("Marc Sherry" . "msherry@gmail.com")))
