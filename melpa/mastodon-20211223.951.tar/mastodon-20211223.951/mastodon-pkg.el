(define-package "mastodon" "20211223.951" "Client for Mastodon"
  '((emacs "24.4"))
  :commit "0cffc91cfd362190eac9580983cda74248a2d3a0" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Johnson Denen" . "johnson.denen@gmail.com")
  :url "https://github.com/jdenen/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
