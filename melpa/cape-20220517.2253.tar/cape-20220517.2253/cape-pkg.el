(define-package "cape" "20220517.2253" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "0a490abfbf89a24ceb148bdb8afbbd8823a2a201" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
