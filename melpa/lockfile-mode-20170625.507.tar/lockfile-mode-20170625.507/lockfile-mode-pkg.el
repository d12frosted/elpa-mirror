;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lockfile-mode" "20170625.507"
  "Major mode for .lock files."
  ()
  :url "https://github.com/preetpalS/emacs-lockfile-mode"
  :commit "496b6035716df0582f879f9488f296947cabead2"
  :revdesc "496b6035716d")
