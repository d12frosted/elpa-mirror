(define-package "spdx" "20221216.114" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "878130a23379665534f89d3ab028bba9a545404e" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
