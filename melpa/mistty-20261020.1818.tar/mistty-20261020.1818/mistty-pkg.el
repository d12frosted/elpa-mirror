;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20261020.1818"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "1d7f9d2dd149bc6e56393743d0a4e2cacfefb2a4"
  :revdesc "1d7f9d2dd149"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
