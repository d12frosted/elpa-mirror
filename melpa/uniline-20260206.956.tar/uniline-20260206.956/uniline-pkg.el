;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260206.956"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "b199d9b47950c7ae10978078458dc2f93f1bd012"
  :revdesc "b199d9b47950"
  :keywords '("convenience" "text"))
