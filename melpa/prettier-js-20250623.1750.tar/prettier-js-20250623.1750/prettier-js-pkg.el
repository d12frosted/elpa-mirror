;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250623.1750"
  "Minor mode to format JS code on file save."
  ()
  :url "https://github.com/prettier/prettier-emacs"
  :commit "cc3ee190e0ae120e1132955091d65961841914df"
  :revdesc "cc3ee190e0ae"
  :keywords '("convenience" "wp" "edit" "js"))
