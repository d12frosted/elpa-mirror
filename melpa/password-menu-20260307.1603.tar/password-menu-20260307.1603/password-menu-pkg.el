;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-menu" "20260307.1603"
  "Password Menu for auth-source secrets."
  '((emacs "29.1"))
  :url "https://github.com/rnadler/password-menu"
  :commit "722469f033e01ea7ebe8abb456375c335576b812"
  :revdesc "722469f033e0"
  :keywords '("news")
  :authors '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainers '(("Robert Nadler" . "robert.nadler@gmail.com")))
