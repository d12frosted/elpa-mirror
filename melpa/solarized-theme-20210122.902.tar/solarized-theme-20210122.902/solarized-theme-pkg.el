(define-package "solarized-theme" "20210122.902" "The Solarized color theme"
  '((emacs "24.1")
    (dash "2.16"))
  :commit "893629b557095e3551eaf166db189e4abcbb7a7d" :authors
  '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.com")
  :keywords
  '("convenience" "themes" "solarized")
  :url "http://github.com/bbatsov/solarized-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
