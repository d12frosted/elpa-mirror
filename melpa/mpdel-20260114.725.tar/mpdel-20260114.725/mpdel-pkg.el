;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdel" "20260114.725"
  "Play and control your MPD music."
  '((emacs    "25.1")
    (libmpdel "1.2.0")
    (navigel  "0.7.0"))
  :url "https://github.com/mpdel/mpdel"
  :commit "64cf50aca68064c2857ed0e5a8fddb2075d97090"
  :revdesc "64cf50aca680"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
