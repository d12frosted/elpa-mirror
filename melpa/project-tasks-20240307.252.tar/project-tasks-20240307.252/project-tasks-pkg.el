(define-package "project-tasks" "20240307.252" "Efficient task management for your project"
  '((emacs "26.1")
    (project "0.6.0"))
  :commit "6a97747d53ba1e0c2cb7cfc7f4e9e3011e8e4208" :authors
  '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers
  '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainer
  '("Giap Tran" . "txgvnn@gmail.com")
  :keywords
  '("project" "workflow" "tools")
  :url "https://github.com/TxGVNN/project-tasks")
;; Local Variables:
;; no-byte-compile: t
;; End:
