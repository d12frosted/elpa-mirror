(define-package "darkman" "20231124.1554" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "2b5eb6610026e5ae02ae9e8d26d2030cbb0fbd38" :authors
  '(("Taha Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainers
  '(("Taha Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Taha Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://darkman.grtcdr.tn")
;; Local Variables:
;; no-byte-compile: t
;; End:
