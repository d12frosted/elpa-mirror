;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "puni" "20260228.1808"
  "Parentheses Universalistic."
  '((emacs "26.1"))
  :url "https://github.com/AmaiKinono/puni"
  :commit "5ade44436d9f671da8cfc0f1f82a41731f030dee"
  :revdesc "5ade44436d9f"
  :keywords '("convenience" "lisp" "tools")
  :authors '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainers '(("Hao Wang" . "amaikinono@gmail.com")))
