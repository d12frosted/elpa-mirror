(define-package "god-mode" "20210102.515" "Minor mode for God-like command entering"
  '((emacs "25.1"))
  :commit "1d7d647bb53a49fce03486eba90e97ccf35cf85a" :authors
  '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainer
  '("Chris Done" . "chrisdone@gmail.com")
  :url "https://github.com/emacsorphanage/god-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
