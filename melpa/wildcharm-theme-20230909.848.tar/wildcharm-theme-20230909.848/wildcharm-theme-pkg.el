(define-package "wildcharm-theme" "20230909.848" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "50fdc2d803e8d7db953ed041c86168f7ef4db492" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
