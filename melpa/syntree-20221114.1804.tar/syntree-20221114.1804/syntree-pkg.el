(define-package "syntree" "20221114.1804" "Draw plain text constituency trees"
  '((emacs "27.1")
    (org "9.2"))
  :commit "a36e5eeaeef2a179184883fc0a91b63d653d3cd9" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/syntree")
;; Local Variables:
;; no-byte-compile: t
;; End:
