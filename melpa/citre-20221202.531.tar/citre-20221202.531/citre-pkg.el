(define-package "citre" "20221202.531" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "03f7c3eeb0526c49ea2e659b4262ec070aa6413a" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
