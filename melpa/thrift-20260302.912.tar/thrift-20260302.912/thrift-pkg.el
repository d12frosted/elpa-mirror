;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260302.912"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "1fcbcb06f09f70bdd53edb3c76b5b111b56313e0"
  :revdesc "1fcbcb06f09f"
  :keywords '("languages"))
