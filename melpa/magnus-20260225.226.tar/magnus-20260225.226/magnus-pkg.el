;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260225.226"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "93b9ce741a94ce1b675f8514a9fea25c55031085"
  :revdesc "93b9ce741a94"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
