(define-package "mistty" "20231118.1206" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "32eef48e64faa3ab6c81a32e9da0d721790d0f86" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
