;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20260629.1929"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "bee8fa1bb0180e3ec770d9e7292bf3dce98241d8"
  :revdesc "bee8fa1bb018"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
