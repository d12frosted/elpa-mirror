;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frameshot" "20261001.1616"
  "Take screenshots of a frame."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/frameshot"
  :commit "076ce7da3b4f0df55bfb509ce0de42119a8c2ebf"
  :revdesc "076ce7da3b4f"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev")))
