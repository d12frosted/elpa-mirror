;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260821.1703"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "9ed770ea32395db9dbc1260185759e2927abaa6e"
  :revdesc "9ed770ea3239"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
