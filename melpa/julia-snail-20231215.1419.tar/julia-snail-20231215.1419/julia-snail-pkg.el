(define-package "julia-snail" "20231215.1419" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (popup "0.5.9"))
  :commit "53666fabb14e35677d6e0b201cddf14a52911b79" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
