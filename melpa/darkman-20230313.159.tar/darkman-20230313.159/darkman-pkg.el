(define-package "darkman" "20230313.159" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "cfbfae139bb14bbc4e1e69df2699d8a3c36e1682" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://grtcdr.tn/darkman.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
