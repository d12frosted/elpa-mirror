(define-package "immaterial-theme" "20220209.1252" "A flexible theme based on material design principles"
  '((emacs "25"))
  :commit "e8cc9383d10bf567a274bf8fd683580d3f56c82b" :authors
  '(("Peter Gardfjäll"))
  :maintainer
  '("Peter Gardfjäll")
  :keywords
  '("themes")
  :url "https://github.com/petergardfjall/emacs-immaterial-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
