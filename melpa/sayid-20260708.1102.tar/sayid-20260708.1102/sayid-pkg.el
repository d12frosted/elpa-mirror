;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "20260708.1102"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.23"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "5b044d2b4d4423c5195fe46a4d497c106e4b1cc2"
  :revdesc "5b044d2b4d44"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
