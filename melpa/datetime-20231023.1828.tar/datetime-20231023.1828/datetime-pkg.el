(define-package "datetime" "20231023.1828" "Parsing, formatting and matching timestamps"
  '((emacs "25.1")
    (extmap "1.1.1"))
  :commit "d81290b8824d3901e69a70bc0ea7825af5840877" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
