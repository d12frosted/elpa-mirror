;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asilea" "20150105.1525"
  "Find best compiler options using simulated annealing."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/Fanael/asilea"
  :commit "2aab1cc63b64ef08d12e84fd7ba5c94065f6039f"
  :revdesc "2aab1cc63b64"
  :authors '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Fanael Linithien" . "fanael4@gmail.com")))
