;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250315.637"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "4bcf209ee56f31dd541a162214084ff208da2d67"
  :revdesc "4bcf209ee56f"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
