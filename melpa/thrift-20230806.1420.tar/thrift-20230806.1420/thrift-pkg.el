(define-package "thrift" "20230806.1420" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "d03f7c740cacf9184e8741f7e559dde7e2cd3ba4" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
