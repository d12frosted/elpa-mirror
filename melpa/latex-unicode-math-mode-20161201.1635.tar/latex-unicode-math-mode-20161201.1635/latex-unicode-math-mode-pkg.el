(define-package "latex-unicode-math-mode" "20161201.1635" "Input method for Unicode math symbols" 'nil :commit "3b82347291edcb32e4062b0048c367a3079b3e8c" :authors
  '(("Christoph Dittmann" . "github@christoph-d.de"))
  :maintainer
  '("Christoph Dittmann" . "github@christoph-d.de")
  :url "https://github.com/Christoph-D/latex-unicode-math-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
