;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reaper" "20260117.43"
  "Interact with Harvest time tracking app."
  '((emacs "26.2"))
  :url "https://github.com/xendk/reaper"
  :commit "8acd7788b4abb833c112f50b1269888238fa8f0d"
  :revdesc "8acd7788b4ab"
  :keywords '("tools")
  :authors '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers '(("Thomas Fini Hansen" . "xen@xen.dk")))
