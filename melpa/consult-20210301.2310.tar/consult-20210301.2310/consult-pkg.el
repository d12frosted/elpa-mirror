(define-package "consult" "20210301.2310" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f2bf17847dfb19852b0c4499e72ea29570b578bb" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
