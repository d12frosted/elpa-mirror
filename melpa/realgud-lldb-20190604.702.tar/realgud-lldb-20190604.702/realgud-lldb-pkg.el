(define-package "realgud-lldb" "20190604.702" "Realgud front-end to lldb"
  '((load-relative "1.3.1")
    (realgud "1.5.0")
    (emacs "25"))
  :commit "f2f77d6ddfa42430ead400eaf81c605c3a04dead" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :url "http://github.com/realgud/realgud-lldb")
;; Local Variables:
;; no-byte-compile: t
;; End:
