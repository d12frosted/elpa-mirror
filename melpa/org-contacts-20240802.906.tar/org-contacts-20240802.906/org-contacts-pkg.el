(define-package "org-contacts" "20240802.906" "Contacts management system for Org mode"
  '((emacs "27.1")
    (org "9.7"))
  :commit "30d137fbac8b9b908ad978ba588f1d47e8ca59cd" :authors
  '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :url "https://repo.or.cz/org-contacts.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
