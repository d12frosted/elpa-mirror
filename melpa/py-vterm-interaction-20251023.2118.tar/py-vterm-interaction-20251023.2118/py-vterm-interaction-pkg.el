;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-vterm-interaction" "20251023.2118"
  "A mode for Python REPL using vterm."
  '((emacs  "27.1")
    (vterm  "0.0.2")
    (python "0.28"))
  :url "https://github.com/vale981/py-vterm-interaction.el"
  :commit "15871314ba51633d605f5fd00b659b9b7a13bb89"
  :revdesc "15871314ba51"
  :keywords '("languages" "python")
  :maintainers '(("Valentin Boettcher" . "hiroatprotagon.space")))
