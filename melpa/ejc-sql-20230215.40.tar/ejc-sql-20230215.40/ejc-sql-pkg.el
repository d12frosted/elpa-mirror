(define-package "ejc-sql" "20230215.40" "Emacs SQL client uses Clojure JDBC."
  '((clomacs "0.0.5")
    (dash "2.16.0")
    (spinner "1.7.3"))
  :commit "76fc36410c1f242b7aebdf63b9b54d11431ce127" :authors
  '(("Kostafey" . "kostafey@gmail.com"))
  :maintainer
  '("Kostafey" . "kostafey@gmail.com")
  :keywords
  '("sql" "jdbc")
  :url "https://github.com/kostafey/ejc-sql")
;; Local Variables:
;; no-byte-compile: t
;; End:
