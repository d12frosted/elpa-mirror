;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260420.1434"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "075dc1f32336878453b628373e8e0b29775a60d3"
  :revdesc "075dc1f32336"
  :keywords '("languages"))
