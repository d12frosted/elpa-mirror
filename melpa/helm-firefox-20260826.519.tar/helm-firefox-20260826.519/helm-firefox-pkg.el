;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-firefox" "20260826.519"
  "Firefox bookmarks."
  '((helm   "1.5")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-firefox"
  :commit "e91c290574df3ad514fc2bb3ffb3851fcadd0157"
  :revdesc "e91c290574df")
