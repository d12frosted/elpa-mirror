(define-package "selectrum" "20210109.1558" "Easily select item from list"
  '((emacs "25.1"))
  :commit "b0d39eeaa3ec0df780f35c31a3c251bd4b57246d" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
