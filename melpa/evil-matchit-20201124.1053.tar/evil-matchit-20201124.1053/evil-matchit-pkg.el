(define-package "evil-matchit" "20201124.1053" "Vim matchit ported to Evil"
  '((evil "1.2.0")
    (emacs "25.1"))
  :commit "b24a7232a2de114cb09774111c2ff8462451894f" :keywords
  ("matchit" "vim" "evil")
  :authors
  (("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  ("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
