(define-package "asyncloop" "20231110.1334" "Non-blocking series of functions"
  '((emacs "28.1"))
  :commit "10e38a1b603ee0dfee69c25e7f10a4b1b66f3a8d" :authors
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainers
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainer
  '(nil . "<meedstrom91@gmail.com>")
  :keywords
  '("tools")
  :url "https://github.com/meedstrom/asyncloop")
;; Local Variables:
;; no-byte-compile: t
;; End:
