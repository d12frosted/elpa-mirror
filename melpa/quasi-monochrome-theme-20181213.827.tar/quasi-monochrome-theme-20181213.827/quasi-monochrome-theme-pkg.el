(define-package "quasi-monochrome-theme" "20181213.827" "Quasi Monochrome theme" 'nil :commit "68060dbbc0bbfe4924387392874186c5a29bb434" :authors
  '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainer
  '("Lorenzo Bolla" . "lbolla@gmail.com")
  :keywords
  '("color-theme" "monochrome" "high contrast")
  :url "https://github.com/lbolla/emacs-quasi-monochrome")
;; Local Variables:
;; no-byte-compile: t
;; End:
