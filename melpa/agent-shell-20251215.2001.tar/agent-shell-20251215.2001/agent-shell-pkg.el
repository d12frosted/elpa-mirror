;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251215.2001"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6eae9d859cce21749bb6c9658dcc5d59ab877792"
  :revdesc "6eae9d859cce")
