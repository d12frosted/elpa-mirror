(define-package "hl-prog-extra" "20220626.536" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "233d7636b299556854db78e7e0667e6257dc2a52" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
