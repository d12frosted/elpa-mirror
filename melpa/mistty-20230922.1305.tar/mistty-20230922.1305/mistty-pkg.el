(define-package "mistty" "20230922.1305" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "1962da030a4ea16ac86766ee11f2ac2027005201" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
