;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250309.1534"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "515b599696b262300508480aaa65ad27dc6e25d7"
  :revdesc "515b599696b2"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
