(define-package "org2blog" "20220811.51" "Blog from Org mode to WordPress"
  '((htmlize "1.54")
    (hydra "0.15.0")
    (xml-rpc "1.6.12")
    (metaweblog "1.1.1"))
  :commit "6ee1b59e0a83b6a855f583743287e801cbdc1e09" :authors
  '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainer
  '("Grant Rettke" . "grant@wisdomandwonder.com")
  :keywords
  '("comm" "convenience" "outlines" "wp")
  :url "https://github.com/org2blog/org2blog")
;; Local Variables:
;; no-byte-compile: t
;; End:
