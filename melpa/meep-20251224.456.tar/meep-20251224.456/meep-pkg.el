;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251224.456"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "8f0532b9606b1036df869b8d298dbff3c55102c7"
  :revdesc "8f0532b9606b"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
