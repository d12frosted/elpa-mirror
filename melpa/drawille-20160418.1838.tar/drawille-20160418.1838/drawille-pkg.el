;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "drawille" "20160418.1838"
  "Drawille implementation in elisp."
  '((cl-lib "0.5"))
  :url "https://github.com/sshbio/elisp-drawille"
  :commit "d582b455c01432bc80933650c52a1f586bd1b5ad"
  :revdesc "d582b455c014"
  :keywords '("graphics")
  :authors '(("Josuah Demangeon" . "josuah.demangeon@gmail.com"))
  :maintainers '(("Josuah Demangeon" . "josuah.demangeon@gmail.com")))
