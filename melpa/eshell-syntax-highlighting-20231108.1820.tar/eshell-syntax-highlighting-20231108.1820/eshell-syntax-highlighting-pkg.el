(define-package "eshell-syntax-highlighting" "20231108.1820" "Highlight eshell commands"
  '((emacs "25.1"))
  :commit "05073d3ec1934f9c2804bd016e5de45b1c49b6eb" :authors
  '(("Alex Kreisher" . "akreisher18@gmail.com"))
  :maintainers
  '(("Alex Kreisher" . "akreisher18@gmail.com"))
  :maintainer
  '("Alex Kreisher" . "akreisher18@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/akreisher/eshell-syntax-highlighting")
;; Local Variables:
;; no-byte-compile: t
;; End:
