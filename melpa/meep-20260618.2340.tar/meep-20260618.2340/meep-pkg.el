;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260618.2340"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "01fe824c36db1ea6011cb4942b6b30fe587ff275"
  :revdesc "01fe824c36db"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
