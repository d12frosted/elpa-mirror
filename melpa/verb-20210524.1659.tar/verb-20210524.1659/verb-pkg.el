(define-package "verb" "20210524.1659" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "7c7c719565842420a5d03e6a8689f7a46df05741" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
