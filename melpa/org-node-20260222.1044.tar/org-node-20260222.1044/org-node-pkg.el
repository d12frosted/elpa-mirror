;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260222.1044"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f9ef31aa212b33b79383c0c749e0003a69e697a2"
  :revdesc "f9ef31aa212b"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
