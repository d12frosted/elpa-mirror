(define-package "polymode" "20220120.1016" "Extensible framework for multiple major modes"
  '((emacs "25"))
  :commit "61e2326731cad373432126e7b12a153bed7d1e89" :authors
  '(("Vitalie Spinu"))
  :maintainer
  '("Vitalie Spinu")
  :keywords
  '("languages" "multi-modes" "processes")
  :url "https://github.com/polymode/polymode")
;; Local Variables:
;; no-byte-compile: t
;; End:
