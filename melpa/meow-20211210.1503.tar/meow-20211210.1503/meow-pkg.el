(define-package "meow" "20211210.1503" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "812d1d47fe3d2b060573a2d6991d44661ca5ecc8" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
