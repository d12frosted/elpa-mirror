;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-ring-search" "20140422.1555"
  "Incremental search for the kill ring."
  ()
  :url "http://nschum.de/src/emacs/kill-ring-search/"
  :commit "23535b4a01a1cb1574604e36c49614e84e85c883"
  :revdesc "23535b4a01a1"
  :keywords '("convenience" "matching")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
