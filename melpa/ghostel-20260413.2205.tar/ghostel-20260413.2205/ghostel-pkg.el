;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260413.2205"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "057fb1f7cc74ecb82eecd11b86be44d76d902dfc"
  :revdesc "057fb1f7cc74"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
