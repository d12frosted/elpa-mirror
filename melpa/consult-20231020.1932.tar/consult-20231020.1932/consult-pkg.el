(define-package "consult" "20231020.1932" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "8f22fbce8d645b9ed45c9ca62c4151644f338a22" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
