(define-package "proof-general" "20230317.2001" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "4a4a5cc8f4be16c1748ac81f0213ee981ffc42f9" :maintainer
  '(nil . "proof-general-maintainers@groupes.renater.fr")
  :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
