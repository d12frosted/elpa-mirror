(define-package "hammy" "20230516.505" "Programmable, interactive interval timers"
  '((emacs "28.1")
    (ts "0.2.2"))
  :commit "5469d2d6f6f7ccb521ea0e3ada9b6531ac2e1a70" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/hammy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
