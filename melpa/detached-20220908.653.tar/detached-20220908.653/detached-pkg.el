(define-package "detached" "20220908.653" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "a19d0cd1c1a5f96284c2a30abe7d1832a19d582f" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
