(define-package "docstr" "20210410.1249" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "67a219425d1fe9a29ad3beae0677d5ca0047bd53" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
