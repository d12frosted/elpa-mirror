;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "20260115.1341"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "f69f331e767109bf456bf7780d2a8982f9d23b22"
  :revdesc "f69f331e7671"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
