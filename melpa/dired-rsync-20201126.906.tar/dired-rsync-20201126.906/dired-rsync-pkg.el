(define-package "dired-rsync" "20201126.906" "Allow rsync from dired buffers"
  '((s "1.12.0")
    (dash "2.0.0")
    (emacs "24"))
  :commit "db7b7d54398766e2a5168f757970e8739fab34b1" :authors
  (("Alex Bennée" . "alex@bennee.com"))
  :maintainer
  ("Alex Bennée" . "alex@bennee.com")
  :url "https://github.com/stsquad/dired-rsync")
;; Local Variables:
;; no-byte-compile: t
;; End:
