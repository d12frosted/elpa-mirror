;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260428.10"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "4111560e5b102d12f065511787022a792f4f0414"
  :revdesc "4111560e5b10")
