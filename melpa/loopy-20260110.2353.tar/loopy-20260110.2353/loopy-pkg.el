;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260110.2353"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "7996ae466a321c1244903f2c579056d86a9db7a4"
  :revdesc "7996ae466a32"
  :keywords '("extensions"))
