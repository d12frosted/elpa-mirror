;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251103.2353"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a1885ddaab19fe0d2aece8bbae9bb6f6406536dd"
  :revdesc "a1885ddaab19"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
