(define-package "latex-table-wizard" "20230424.2045" "Magic editing of LaTeX tables"
  '((emacs "27.1")
    (auctex "12.1")
    (transient "0.3.7"))
  :commit "c496237fa11b57c4700f3db5a1f69e7f1ac0a912" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :keywords
  '("convenience")
  :url "https://github.com/enricoflor/latex-table-wizard")
;; Local Variables:
;; no-byte-compile: t
;; End:
