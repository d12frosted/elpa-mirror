;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20250604.2027"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "e4e75bc724f9a520ead27f439f5042166e93b6b1"
  :revdesc "e4e75bc724f9"
  :keywords '("convenience" "comm" "hypermedia"))
