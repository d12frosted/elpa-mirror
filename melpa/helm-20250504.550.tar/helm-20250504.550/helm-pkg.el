;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250504.550"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.2")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "b16f1e63b2800597c898004f3907c8d1c403f9a6"
  :revdesc "b16f1e63b280"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
