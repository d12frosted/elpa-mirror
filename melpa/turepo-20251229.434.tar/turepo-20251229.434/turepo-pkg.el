;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turepo" "20251229.434"
  "Open git repository in browser."
  '((emacs "28.1"))
  :url "https://github.com/swarnimcodes/turepo"
  :commit "ff78a987a7cb61a08e390bef3d720d0707246ac1"
  :revdesc "ff78a987a7cb"
  :keywords '("vc" "git" "convenience" "github")
  :authors '(("Swarnim Barapatre" . "swarnim14.9@hotmail.com"))
  :maintainers '(("Swarnim Barapatre" . "swarnim14.9@hotmail.com")))
