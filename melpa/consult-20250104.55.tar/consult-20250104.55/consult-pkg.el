;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250104.55"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "64bfe07576e9716a3488d07b15758b239306d898"
  :revdesc "64bfe07576e9"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
