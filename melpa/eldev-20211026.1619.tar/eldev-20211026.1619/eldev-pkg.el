(define-package "eldev" "20211026.1619" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "406e5949fffbd2776994f346db121b0c501c043d" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
