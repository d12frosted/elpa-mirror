(define-package "spdx" "20220225.102" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "fba53cc8d05d768dc7835b06d0fb857d7f13d5ea" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
