(define-package "elisp-autofmt" "20231025.2318" "Emacs lisp auto-format"
  '((emacs "29.1"))
  :commit "fda0edddddc003d021aead261f0e8040cfb5a7c4" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
