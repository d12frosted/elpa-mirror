(define-package "popper" "20220706.557" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "7ea13618c82d759247054c7630ee142bbe706cc7" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
