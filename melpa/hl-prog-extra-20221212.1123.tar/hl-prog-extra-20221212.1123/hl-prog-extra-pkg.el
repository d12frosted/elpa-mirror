(define-package "hl-prog-extra" "20221212.1123" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "507bf2793a5c61f5c0427b098f3b8f142421feee" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
