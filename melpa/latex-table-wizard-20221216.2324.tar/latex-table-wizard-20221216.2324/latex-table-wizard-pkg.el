(define-package "latex-table-wizard" "20221216.2324" "Magic editing of LaTeX tables"
  '((emacs "27.1")
    (auctex "12.1")
    (transient "0.3.7"))
  :commit "3bafcbefebd961ce9ebb479b60cdb1461cae8aa0" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :keywords
  '("convenience")
  :url "https://github.com/enricoflor/latex-table-wizard")
;; Local Variables:
;; no-byte-compile: t
;; End:
