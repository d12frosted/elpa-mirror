(define-package "skeletor" "20210117.2200" "Provides project skeletons for Emacs"
  '((s "1.7.0")
    (f "0.14.0")
    (dash "2.2.0")
    (cl-lib "0.3")
    (let-alist "1.0.3")
    (emacs "24.1"))
  :commit "aab0f854eea8ed3452bf2eead085d314a0bbf572" :authors
  '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainer
  '("Chris Barrett" . "chris.d.barrett@me.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
