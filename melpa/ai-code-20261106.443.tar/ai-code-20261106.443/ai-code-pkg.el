;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261106.443"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "83640ea40e43c27cf91e747c8b7de3d699d69bce"
  :revdesc "83640ea40e43"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
