;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode-extra-font-locking" "20260219.1640"
  "Extra font-locking for Clojure mode."
  '((clojure-mode "3.0"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "937c38663a6114ca15962e4ebd651547ddc17e28"
  :revdesc "937c38663a61"
  :keywords '("languages" "lisp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
