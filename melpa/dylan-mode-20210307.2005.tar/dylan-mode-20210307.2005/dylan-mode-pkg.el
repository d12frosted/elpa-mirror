(define-package "dylan-mode" "20210307.2005" "Major mode for the Dylan programming language"
  '((emacs "25.1"))
  :commit "2ed35d57fe9e4d4ee548a9252a61712c9e4ef0c0" :authors
  '(("Robert Stockton" . "rgs@cs.cmu.edu"))
  :maintainer
  '("Chris Page" . "cpage@opendylan.org")
  :url "https://opendylan.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
