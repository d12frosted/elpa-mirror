;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser" "20260509.2218"
  "GNU Emacs and Scheme talk to each other."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://gitlab.com/emacs-geiser/"
  :commit "6071202dfec784d53e5e9a6946e9ee06be8e34c6"
  :revdesc "6071202dfec7"
  :keywords '("languages" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
