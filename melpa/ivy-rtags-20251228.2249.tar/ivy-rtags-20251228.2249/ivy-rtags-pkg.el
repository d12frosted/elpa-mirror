;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-rtags" "20251228.2249"
  "RTags completion back-end for ivy."
  '((ivy   "0.7.0")
    (rtags "2.10"))
  :url "https://github.com/Andersbakken/rtags"
  :commit "829a6298d6bfba8ed541570fcbe3daf5ce3135d0"
  :revdesc "829a6298d6bf"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
