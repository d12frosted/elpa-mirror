;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "20250107.1312"
  "Wrapper for difftastic."
  '((emacs     "28.1")
    (compat    "29.1.4.2")
    (magit     "4.0.0")
    (transient "0.4.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "d07cf324792449c91ae5b6931dda4ea46c2f22e1"
  :revdesc "d07cf3247924"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
