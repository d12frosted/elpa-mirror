;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greger" "20250704.1233"
  "Agentic coding environment with tool use, using Claude."
  '((emacs "29.1"))
  :url "https://github.com/andreasjansson/greger.el"
  :commit "51af78afab04c6394e743a14c2e8939cf7407456"
  :revdesc "51af78afab04"
  :keywords '("agent" "agentic" "ai" "chat" "language-models" "tools")
  :authors '(("Andreas Jansson" . "andreas@jansson.me.uk"))
  :maintainers '(("Andreas Jansson" . "andreas@jansson.me.uk")))
