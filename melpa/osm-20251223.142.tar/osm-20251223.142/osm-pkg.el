;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251223.142"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "daebb33b629b162898397a62ba2e92c8d8070734"
  :revdesc "daebb33b629b"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
