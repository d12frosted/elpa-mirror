;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260602.1201"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "5f32b02e4679b2a98308f5431f0f14066156d81f"
  :revdesc "5f32b02e4679"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
