(define-package "dired-gitignore" "20230909.1008" "A minor mode to hide gitignored files in a dired buffer"
  '((emacs "27.1"))
  :commit "09e620e69c660f1468b2652832ff579512cc0f47" :authors
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainer
  '("Johannes Mueller" . "github@johannes-mueller.org")
  :keywords
  '("dired" "convenience" "git")
  :url "https://github.com/johannes-mueller/dired-gitignore.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
