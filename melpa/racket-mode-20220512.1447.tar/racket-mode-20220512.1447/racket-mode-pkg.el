(define-package "racket-mode" "20220512.1447" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "3b351fbb0d3e81bf260cb3fc7b623f1b782550cc" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
