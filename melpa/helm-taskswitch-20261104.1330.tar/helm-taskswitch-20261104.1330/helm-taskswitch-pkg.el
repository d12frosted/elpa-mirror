;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-taskswitch" "20261104.1330"
  "Use helm to switch windows, browser tabs and buffers."
  '((emacs     "28.1")
    (helm      "3.0")
    (websocket "1.15"))
  :url "https://github.com/bdc34/helm-taskswitch"
  :commit "3ddcda3c02b522162e79c9e5844228514c89694e"
  :revdesc "3ddcda3c02b5"
  :keywords '("frames")
  :authors '(("Brian Caruso" . "briancaruso@gmail.com"))
  :maintainers '(("Brian Caruso" . "briancaruso@gmail.com")))
