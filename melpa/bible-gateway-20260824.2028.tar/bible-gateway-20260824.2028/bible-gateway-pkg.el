;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260824.2028"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "e3d8e596097a9b23654ff0d4088100c284bd474e"
  :revdesc "e3d8e596097a"
  :keywords '("convenience" "comm" "hypermedia"))
