;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250627.1721"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "443aafae0a63e5ea09efd2ddbf1b189389a2d96e"
  :revdesc "443aafae0a63"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
