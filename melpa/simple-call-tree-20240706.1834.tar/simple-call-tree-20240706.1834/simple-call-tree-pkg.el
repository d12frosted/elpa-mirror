(define-package "simple-call-tree" "20240706.1834" "analyze source code based on font-lock text-properties"
  '((emacs "24.3")
    (anaphora "1.0.0"))
  :commit "a545e184a3afaae38213ca5b0bc6eb146f970755" :authors
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("programming")
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
