(define-package "fanyi" "20210908.437" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "11e3716073b0715182fd195f6469e5f3be07f62c" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
