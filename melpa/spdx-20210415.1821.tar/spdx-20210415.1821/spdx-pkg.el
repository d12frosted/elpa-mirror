(define-package "spdx" "20210415.1821" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "86c223a2db529768fd815dc0635ed432c1a215e8" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
