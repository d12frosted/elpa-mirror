;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260505.530"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://codeberg.org/thanosapollo/emacs-gnosis"
  :commit "fb810bd535ae35eb01ee1072f485a426708cc146"
  :revdesc "fb810bd535ae"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
