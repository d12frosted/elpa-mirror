(define-package "eldev" "20221121.2223" "Elisp development tool"
  '((emacs "24.4"))
  :commit "d73221074fc9572cd01adbff49117c79d3e71654" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
