;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251204.1718"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "de08a43be4a3cb2fe96e1ad8e5842819c1e346d0"
  :revdesc "de08a43be4a3"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
