(define-package "dirvish" "20211220.1820" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (posframe "1.1.2"))
  :commit "4174e7958b9aee6a8d3c80b8eeb1f59cf719f66d" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
