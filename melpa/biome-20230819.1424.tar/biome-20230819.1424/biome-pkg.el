(define-package "biome" "20230819.1424" "Bountiful Interface to Open Meteo for Emacs"
  '((emacs "27.1")
    (transient "0.3.7")
    (ct "0.2")
    (request "0.3.3")
    (compat "29.1.4.1"))
  :commit "fc52a2b7ac1a08050499c5eb378d012cd26d0856" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/biome")
;; Local Variables:
;; no-byte-compile: t
;; End:
