;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260509.1615"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "cef22253fac6325a355b52ebd5f020789ecc175d"
  :revdesc "cef22253fac6"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
