;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241201.1139"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini, Ollama) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.72.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "78c980435e02e3fecacb84762cc6cb729ee1c63f"
  :revdesc "78c980435e02")
