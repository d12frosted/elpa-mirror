;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesky" "20260618.147"
  "A Bluesky client."
  '((emacs "30.1")
    (plz   "0.9.0")
    (futur "1.7")
    (vui   "1.0.0"))
  :url "https://github.com/ahyatt/emacs-bluesky"
  :commit "b4b7957a3af0533918535486f44afcb808d38d24"
  :revdesc "b4b7957a3af0"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
