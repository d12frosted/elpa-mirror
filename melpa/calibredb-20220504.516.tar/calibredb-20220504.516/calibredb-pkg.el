(define-package "calibredb" "20220504.516" "Yet another calibre client"
  '((emacs "25.1")
    (org "9.3")
    (transient "0.1.0")
    (s "1.12.0")
    (dash "2.17.0")
    (request "0.3.3")
    (esxml "0.3.7"))
  :commit "a59e8ab65601e30073fa55bef76e95c964c678d8" :authors
  '(("Damon Chan" . "elecming@gmail.com"))
  :maintainer
  '("Damon Chan" . "elecming@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/chenyanming/calibredb.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
