;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mutype" "20260302.636"
  "Type into stillness."
  '((emacs "25.1"))
  :url "https://github.com/suxiaogang223/mutype"
  :commit "37bbd1de17a1980651b1a72c6861d57c21b816fe"
  :revdesc "37bbd1de17a1"
  :keywords '("convenience" "typing")
  :authors '(("Xiaogang Su" . "https://github.com/suxiaogang223"))
  :maintainers '(("Xiaogang Su" . "https://github.com/suxiaogang223")))
