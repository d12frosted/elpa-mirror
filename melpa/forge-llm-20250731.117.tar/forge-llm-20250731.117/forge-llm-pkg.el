;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forge-llm" "20250731.117"
  "LLM integration for generating PR descriptions in Forge."
  '((emacs "25.1")
    (forge "0.3.0")
    (llm   "0.16.1"))
  :url "https://gitlab.com/rogs/forge-llm"
  :commit "ebd59266fd68bfd55a8115efc65817ba3e31c235"
  :revdesc "ebd59266fd68"
  :keywords '("convenience" "forge" "git" "llm" "github" "gitlab" "pull-request")
  :authors '(("Roger Gonzalez" . "roger@rogs.me"))
  :maintainers '(("Roger Gonzalez" . "roger@rogs.me")))
