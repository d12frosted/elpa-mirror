(define-package "clojure-mode" "20231012.514" "Major mode for Clojure code"
  '((emacs "25.1"))
  :commit "3e9c6d1cd95759457565809d313ff832e36b7e7a" :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.dev")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "https://github.com/clojure-emacs/clojure-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
