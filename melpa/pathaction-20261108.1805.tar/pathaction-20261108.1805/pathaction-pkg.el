;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20261108.1805"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "c3114857fd1db0f570f6776ae63d9fa2e29472c8"
  :revdesc "c3114857fd1d"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
