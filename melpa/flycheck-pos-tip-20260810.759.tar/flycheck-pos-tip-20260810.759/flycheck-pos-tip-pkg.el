;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pos-tip" "20260810.759"
  "Display Flycheck errors in GUI tooltips."
  '((emacs    "24.1")
    (flycheck "0.22")
    (pos-tip  "0.4.6"))
  :url "https://github.com/flycheck/flycheck-pos-tip"
  :commit "16f1757a76320ae6082d06f9a18195a316d81258"
  :revdesc "16f1757a7632"
  :keywords '("tools" "convenience")
  :authors '(("Akiha Senda" . "senda.akiha@gmail.com")
             ("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
