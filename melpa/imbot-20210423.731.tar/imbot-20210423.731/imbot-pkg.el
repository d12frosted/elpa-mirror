(define-package "imbot" "20210423.731" "Automatic system input method switcher"
  '((emacs "25.1"))
  :commit "a90183954522876ebbf1ce96d88b80e6a31b9d34" :keywords
  '("convenience")
  :url "https://github.com/QiangF/imbot")
;; Local Variables:
;; no-byte-compile: t
;; End:
