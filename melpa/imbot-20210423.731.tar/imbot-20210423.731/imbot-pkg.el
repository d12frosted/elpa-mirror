(define-package "imbot" "20210423.731" "Automatic system input method switcher"
  '((emacs "25.1"))
  :commit "be56d85b6f44fee569eaaf1f4bbce7dbc098a20c" :keywords
  '("convenience")
  :url "https://github.com/QiangF/imbot")
;; Local Variables:
;; no-byte-compile: t
;; End:
