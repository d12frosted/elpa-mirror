(define-package "eldev" "20230501.1439" "Elisp development tool"
  '((emacs "24.4"))
  :commit "506b02eb9aa62d93fbb11e63554353a2816ba946" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
