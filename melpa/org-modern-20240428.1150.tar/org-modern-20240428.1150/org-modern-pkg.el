(define-package "org-modern" "20240428.1150" "Modern looks for Org"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "5621060178ad081e3633d326b4f2452006988dcc" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "text")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
