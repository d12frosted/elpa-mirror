;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251107.2044"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "69f84fed953d8d95f999ebe75f43e8a358c25b03"
  :revdesc "69f84fed953d"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
