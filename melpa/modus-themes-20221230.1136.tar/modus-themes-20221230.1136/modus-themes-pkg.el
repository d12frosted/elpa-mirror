(define-package "modus-themes" "20221230.1136" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "9c9347683bfe6bbdfe118583355fbb603e6a54e7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
