(define-package "khoj" "20230828.2146" "AI personal assistant for your digital brain"
  '((emacs "27.1")
    (transient "0.3.0")
    (dash "2.19.1"))
  :commit "e592f6eac88c1acc9c134077e0a4eea1fd99f234" :authors
  '(("Debanjum Singh Solanky" . "debanjum@gmail.com"))
  :maintainers
  '(("Debanjum Singh Solanky" . "debanjum@gmail.com"))
  :maintainer
  '("Debanjum Singh Solanky" . "debanjum@gmail.com")
  :keywords
  '("search" "chat" "org-mode" "outlines" "markdown" "pdf" "image")
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
