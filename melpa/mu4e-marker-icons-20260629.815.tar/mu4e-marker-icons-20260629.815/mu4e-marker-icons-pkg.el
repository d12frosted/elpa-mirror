;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-marker-icons" "20260629.815"
  "Display icons for mu4e markers."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/mu4e-marker-icons.git"
  :commit "2d048729ab106aebf1acb99e1ccfd002a0f2ec4a"
  :revdesc "2d048729ab10"
  :keywords '("mail")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
