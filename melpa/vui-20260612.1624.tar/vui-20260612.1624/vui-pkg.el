;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260612.1624"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "5c476a92940a819d78baf0a75955188da12df386"
  :revdesc "5c476a92940a"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
