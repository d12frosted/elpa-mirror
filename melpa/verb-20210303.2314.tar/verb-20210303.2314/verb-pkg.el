(define-package "verb" "20210303.2314" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "b8d2ecbf84b2a9b6a31124e7e4fc22f13e48e18e" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
