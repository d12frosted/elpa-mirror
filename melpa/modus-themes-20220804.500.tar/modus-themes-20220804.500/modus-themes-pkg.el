(define-package "modus-themes" "20220804.500" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "a9399d08ce2199b31f7e64a3f4740156e8f501eb" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
