(define-package "emms" "20210303.2142" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (seq "0"))
  :commit "caa744dd2c05ad16eaebf19f54d57fb670af96c5" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
