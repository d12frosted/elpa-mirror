;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260504.2225"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "702a7984c8b194fa92efe34a4f9b26bf6fd52d0b"
  :revdesc "702a7984c8b1"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
