(define-package "hl-indent-scope" "20230113.1034" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "91e30f4cf15f3a9eb137ef52c385724cf2b0dcf8" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
