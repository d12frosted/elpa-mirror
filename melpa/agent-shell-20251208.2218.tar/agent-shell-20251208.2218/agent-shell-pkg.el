;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251208.2218"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.2")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "003c9dec0934984b4e3b5d46985edf7a3a25d499"
  :revdesc "003c9dec0934")
