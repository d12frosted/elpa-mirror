;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250612.339"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "baa11121b71425352b6c044bbd97bb3da42cecba"
  :revdesc "baa11121b714"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
