(define-package "i-ching" "20220619.817" "The Book of Changes"
  '((emacs "25.1")
    (request "0.3"))
  :commit "54f19e2dcb1d16735b94fc7e06a2aa8b1b6f165a" :authors
  '(("nik gaffney" . "nik@fo.am"))
  :maintainer
  '("nik gaffney" . "nik@fo.am")
  :keywords
  '("games" "divination" "stochastism" "cleromancy" "change")
  :url "https://github.com/zzkt/i-ching")
;; Local Variables:
;; no-byte-compile: t
;; End:
