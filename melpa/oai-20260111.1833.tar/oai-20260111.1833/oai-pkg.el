;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260111.1833"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "f836c2c38c096a41bf622c21b140b8a2969bfd24"
  :revdesc "f836c2c38c09"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
