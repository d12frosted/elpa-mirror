(define-package "transient" "20240509.915" "Transient commands"
  '((emacs "26.1")
    (compat "29.1.4.4")
    (seq "2.24"))
  :commit "dc967e07fea2663845187dc1399bc8504da855e1" :authors
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
