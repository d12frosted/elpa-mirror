;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260323.31"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "b9d5e0cb04be70d89e1a6682e00cd7d65696e3e1"
  :revdesc "b9d5e0cb04be"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
