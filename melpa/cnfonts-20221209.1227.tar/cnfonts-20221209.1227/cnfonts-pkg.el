(define-package "cnfonts" "20221209.1227" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "68340c63360105b763e293595ccd70681559c05e" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
