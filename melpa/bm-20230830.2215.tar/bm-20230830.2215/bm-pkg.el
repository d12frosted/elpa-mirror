(define-package "bm" "20230830.2215" "Visible bookmarks in buffer." 'nil :commit "e5b9fadb2d34969597e180ce9a4b93ca1de543fb" :authors
  '(("Jo Odland <jo.odland(at)gmail.com>"))
  :maintainers
  '(("Jo Odland <jo.odland(at)gmail.com>"))
  :maintainer
  '("Jo Odland <jo.odland(at)gmail.com>")
  :keywords
  '("bookmark" "highlight" "faces" "persistent")
  :url "https://github.com/joodland/bm")
;; Local Variables:
;; no-byte-compile: t
;; End:
