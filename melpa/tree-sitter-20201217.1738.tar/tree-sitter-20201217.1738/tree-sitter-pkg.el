(define-package "tree-sitter" "20201217.1738" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.12.1"))
  :commit "4c46854b716e9efee62df3d794b3a10313525f0b" :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
