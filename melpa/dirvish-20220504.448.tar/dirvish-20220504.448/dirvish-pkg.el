(define-package "dirvish" "20220504.448" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "15981b685cdb4948219a9db2da71ac9f7d60723c" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
