;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251127.251"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "f4344b8a7950fd6b969b32f84f0fe427a9bc925b"
  :revdesc "f4344b8a7950"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
