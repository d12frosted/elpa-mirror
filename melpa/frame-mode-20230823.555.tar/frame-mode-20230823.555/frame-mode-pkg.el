(define-package "frame-mode" "20230823.555" "Use frames instead of windows"
  '((s "1.9.0")
    (emacs "24.4"))
  :commit "53e8f0b7f2ce650f8d86d5eb1d407729c33920c4" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/IvanMalison/frame-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
