;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20260406.118"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "dc88dd79b016c90297912a81035b6ca685cc9136"
  :revdesc "dc88dd79b016"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
