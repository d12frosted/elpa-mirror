(define-package "magit-section" "20220513.1429" "Sections for read-only buffers."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (dash "20210826"))
  :commit "1c16b99ba47c8ccd04ac41fccf1853e746d4fd70" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
