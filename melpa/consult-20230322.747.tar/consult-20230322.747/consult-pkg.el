(define-package "consult" "20230322.747" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "28b74703113765137cc4639285e511bd73fd99e6" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
