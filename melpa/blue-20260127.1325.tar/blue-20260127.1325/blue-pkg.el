;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260127.1325"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "822e973a018ff4a1ee70f61b26adf5afbbc27415"
  :revdesc "822e973a018f"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
