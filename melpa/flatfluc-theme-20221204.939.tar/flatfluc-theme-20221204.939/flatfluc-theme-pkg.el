(define-package "flatfluc-theme" "20221204.939" "Custom merge of flucui and flatui themes"
  '((emacs "26.1"))
  :commit "553167d27725d078f5c66ed7a31ca8ec9376dfd0" :authors
  '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainers
  '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainer
  '("Sébastien Le Maguer" . "lemagues@tcd.ie")
  :keywords
  '("lisp")
  :url "https://github.com/seblemaguer/flatfluc-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
