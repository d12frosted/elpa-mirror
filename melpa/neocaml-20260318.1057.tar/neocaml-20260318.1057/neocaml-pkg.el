;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260318.1057"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "e74b0f235657cdb2eb4a269dfa10c11c73b96437"
  :revdesc "e74b0f235657"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
