;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bqn-mode" "20261116.1753"
  "Emacs mode for BQN."
  '((emacs  "26.1")
    (compat "30.0.0.0")
    (eros   "0.1.0"))
  :url "https://github.com/museoa/bqn-mode"
  :commit "41390551b2fcc03ec067460a14268ed7462d4d0d"
  :revdesc "41390551b2fc"
  :authors '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainers '(("Marshall Lochbaum" . "mwlochbaum@gmail.com")))
