;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20261029.1427"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "54d604bd1ab94bc5ec46aacfb5b2e99cf31c9d2c"
  :revdesc "54d604bd1ab9"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
