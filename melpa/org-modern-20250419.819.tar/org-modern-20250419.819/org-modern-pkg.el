;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern" "20250419.819"
  "Modern looks for Org."
  '((emacs  "28.1")
    (org    "9.5")
    (compat "30"))
  :url "https://github.com/minad/org-modern"
  :commit "20b80b9d320f9e1bef13d7375e719a5ae8175e4c"
  :revdesc "20b80b9d320f"
  :keywords '("outlines" "hypermedia" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")
                 ("J.D. Smith" . "jdtsmith+elpa@gmail.com")))
