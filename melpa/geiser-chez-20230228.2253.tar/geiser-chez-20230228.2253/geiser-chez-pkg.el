(define-package "geiser-chez" "20230228.2253" "Chez and Geiser talk to each other"
  '((emacs "26.1")
    (geiser "0.19"))
  :commit "04ab4387fed68659f21377dbe74513edac2fd134" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainers
  '(("Jose A Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chez" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chez")
;; Local Variables:
;; no-byte-compile: t
;; End:
