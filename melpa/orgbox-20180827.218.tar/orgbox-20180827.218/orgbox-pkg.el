;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgbox" "20180827.218"
  "Mailbox-like task scheduling Org."
  '((org    "8.0")
    (cl-lib "0.5"))
  :url "https://github.com/yasuhito/orgbox"
  :commit "609e5e37348815ec3ba53ab6d643e38b0cc4fe17"
  :revdesc "609e5e373488"
  :keywords '("org")
  :authors '(("Yasuhito Takamiya" . "yasuhito@gmail.com"))
  :maintainers '(("Yasuhito Takamiya" . "yasuhito@gmail.com")))
