(define-package "dashboard" "20230102.1749" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "594f2d96d5adb68313210611d0d729d161e85f19" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
