;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260826.556"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "f8bbe10237ddaf051ccfe5e542cd348e9bb31b8b"
  :revdesc "f8bbe10237dd"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
