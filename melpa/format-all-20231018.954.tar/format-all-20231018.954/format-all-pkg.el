(define-package "format-all" "20231018.954" "Auto-format C, C++, JS, Python, Ruby and 50 other languages"
  '((emacs "24.4")
    (inheritenv "0.1")
    (language-id "0.19"))
  :commit "5f5980d762682dae07af00a1cc338a30dedad124" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/lassik/emacs-format-all-the-code")
;; Local Variables:
;; no-byte-compile: t
;; End:
