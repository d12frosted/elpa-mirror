;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251103.2346"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "fffa7eddcb9b2302086f2c21cccbc292e9af7b04"
  :revdesc "fffa7eddcb9b"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
