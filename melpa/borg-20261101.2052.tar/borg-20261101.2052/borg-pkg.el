;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20261101.2052"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "fa2d62803b4b9db30d8fb68a1ec9765224203c33"
  :revdesc "fa2d62803b4b"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
