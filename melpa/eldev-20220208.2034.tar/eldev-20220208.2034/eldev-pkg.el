(define-package "eldev" "20220208.2034" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "e3c514da17177c40af19a92080c834cc7b8ac390" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
