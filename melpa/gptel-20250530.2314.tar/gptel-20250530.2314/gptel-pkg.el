;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250530.2314"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "45814df5dca127cc2b0ec6d4e3daa1b7e57d8a5b"
  :revdesc "45814df5dca1"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
