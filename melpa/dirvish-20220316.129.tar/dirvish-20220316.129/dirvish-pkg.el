(define-package "dirvish" "20220316.129" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "92c20dda3aac9bc483c98b3956a74ce387a977e2" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
