(define-package "processing-snippets" "20140426.1428" "Snippets for processing-mode"
  '((yasnippet "0.8.0"))
  :commit "448aba82970c98322629eaf2746e73be6c30c98e")
;; Local Variables:
;; no-byte-compile: t
;; End:
