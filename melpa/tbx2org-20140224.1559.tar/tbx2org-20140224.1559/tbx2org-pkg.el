;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tbx2org" "20140224.1559"
  "Tinderbox to org-mode conversion."
  '((dash   "2.5.0")
    (s      "1.8.0")
    (cl-lib "0.4"))
  :url "https://github.com/istib/tbx2org"
  :commit "08e9816ba6066f56936050b58d07ceb2187ae6f7"
  :revdesc "08e9816ba606"
  :keywords '("org-mode"))
