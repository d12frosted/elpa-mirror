;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260315.1528"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "4eb329cf27adf40b38976df76433f260081cd48a"
  :revdesc "4eb329cf27ad"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
