(define-package "embark" "20210212.1743" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "3a9c581cb7518f738dce8d6a0f1d1eb6c78b6622" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
