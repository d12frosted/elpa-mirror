(define-package "ox-hugo" "20211024.40" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "ac5cb9ed3b3ba4e211672fc62324e6c6a0c1e7f9" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
