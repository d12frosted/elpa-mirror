;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jape-mode" "20140903.1506"
  "An Emacs editing mode mode for GATE's JAPE files."
  ()
  :url "https://github.com/tanzoniteblack/jape-mode"
  :commit "27dbebc4de93eb887038fda7a11671349efe8dbb"
  :revdesc "27dbebc4de93"
  :keywords '("languages" "jape" "gate")
  :authors '(("Ryan Smith" . "rnsmith2@gmail.com"))
  :maintainers '(("Ryan Smith" . "rnsmith2@gmail.com")))
