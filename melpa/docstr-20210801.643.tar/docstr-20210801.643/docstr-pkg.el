(define-package "docstr" "20210801.643" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "aa8c20d162d5e0b3a8677f2f4f3519ce6fdbe2e5" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
