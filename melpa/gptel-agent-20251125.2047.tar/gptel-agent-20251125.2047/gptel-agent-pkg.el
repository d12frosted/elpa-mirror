;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20251125.2047"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "4e012af36f3699cdec5587da56120f6826716995"
  :revdesc "4e012af36f36"
  :keywords '("comm"))
