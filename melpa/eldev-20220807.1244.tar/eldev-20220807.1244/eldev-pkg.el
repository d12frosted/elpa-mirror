(define-package "eldev" "20220807.1244" "Elisp development tool"
  '((emacs "24.4"))
  :commit "a9d5607372b0935fb1b84a81bfcbdf60a7bf7ca8" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
