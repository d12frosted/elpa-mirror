;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20240929.642"
  "OpenStreetMap viewer."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "2ba02faed5d57da97c1f6e13df36091d68ddefee"
  :revdesc "2ba02faed5d5"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
