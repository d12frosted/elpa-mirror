;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250214.332"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "7425ec9f6c3ec5627b15b6c218650f9cccecaa95"
  :revdesc "7425ec9f6c3e"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
