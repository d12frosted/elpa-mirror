(define-package "apheleia" "20231123.2211" "Reformat buffer stably"
  '((emacs "27"))
  :commit "731edd2954ae213548ec4459c7db6d5db9e251b8" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
