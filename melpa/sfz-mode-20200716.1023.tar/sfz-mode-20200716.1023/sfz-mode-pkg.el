;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sfz-mode" "20200716.1023"
  "Major mode for SFZ files."
  '((emacs "25.1"))
  :url "https://github.com/sfztools/emacs-sfz-mode"
  :commit "aaf31d1b68817251affed7da719dfcb2acd4b51a"
  :revdesc "aaf31d1b6881"
  :keywords '("languages")
  :authors '(("Jean Pierre Cimalando" . "jp-dev@inbox.ru"))
  :maintainers '(("Jean Pierre Cimalando" . "jp-dev@inbox.ru")))
