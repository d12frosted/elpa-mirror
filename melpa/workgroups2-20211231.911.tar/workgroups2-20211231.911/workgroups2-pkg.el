(define-package "workgroups2" "20211231.911" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "a65694c6fc45e12ad721da233b90dc28ad39a19e" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
