;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250530.2234"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "f78da5b3394439f8f4f30a4aa30637eaf2bec63b"
  :revdesc "f78da5b33944"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
