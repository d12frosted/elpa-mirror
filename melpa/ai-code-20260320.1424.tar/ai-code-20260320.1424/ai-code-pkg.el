;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260320.1424"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "db8ae5ad4d94c1af3cde2ce7861f26d6013a3fbb"
  :revdesc "db8ae5ad4d94"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
