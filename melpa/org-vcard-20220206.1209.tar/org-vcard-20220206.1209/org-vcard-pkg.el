(define-package "org-vcard" "20220206.1209" "org-mode support for vCard export and import." 'nil :commit "bdaebcb4ef44c155a92d9c89a21a1d29019ee026" :authors
  '(("Alexis" . "flexibeast@gmail.com")
    ("Will Dey" . "will123dey@gmail.com"))
  :maintainer
  '("Alexis" . "flexibeast@gmail.com")
  :keywords
  '("outlines" "org" "vcard")
  :url "https://github.com/flexibeast/org-vcard")
;; Local Variables:
;; no-byte-compile: t
;; End:
