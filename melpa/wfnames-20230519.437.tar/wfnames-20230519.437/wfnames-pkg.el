(define-package "wfnames" "20230519.437" "Edit filenames"
  '((emacs "24.3"))
  :commit "7202294447e3f6e894fe8a1ae88c96ca010ccccd" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://github.com/thierryvolpiatto/wfnames")
;; Local Variables:
;; no-byte-compile: t
;; End:
