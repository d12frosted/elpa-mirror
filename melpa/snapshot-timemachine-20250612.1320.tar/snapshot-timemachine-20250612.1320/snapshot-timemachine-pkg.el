;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snapshot-timemachine" "20250612.1320"
  "Step through (Btrfs, ZFS, ...) snapshots of files."
  '((emacs "28.1"))
  :url "https://github.com/mrBliss/snapshot-timemachine"
  :commit "88af8c045e5274b06ddd6ca5e8c6a746cef776e0"
  :revdesc "88af8c045e52"
  :authors '(("Thomas Winant" . "dewinant@gmail.com"))
  :maintainers '(("Thomas Winant" . "dewinant@gmail.com")))
