;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260228.1511"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "07b3b2249b3e0838eccdc2860cbd5b2f94199481"
  :revdesc "07b3b2249b3e"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
