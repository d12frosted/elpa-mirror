(define-package "json-par" "20220815.1101" "Minor mode for structural editing of JSON"
  '((emacs "24.4")
    (json-mode "1.7.0"))
  :commit "4f1fffd2595be3e3af0b5fb1e0c499ecee698273" :authors
  '(("taku0 (http://github.com/taku0)"))
  :maintainer
  '("taku0 (http://github.com/taku0)")
  :keywords
  '("abbrev" "convenience" "files")
  :url "https://github.com/taku0/json-par")
;; Local Variables:
;; no-byte-compile: t
;; End:
