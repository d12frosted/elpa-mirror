;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260416.125"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "f2f565dd967148cb20a965f145e95f68666d7012"
  :revdesc "f2f565dd9671"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
