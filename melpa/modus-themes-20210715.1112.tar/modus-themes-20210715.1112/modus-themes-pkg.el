(define-package "modus-themes" "20210715.1112" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "b6fb7cda01a665f9369f2c6a29f3bf26c8cc8019" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
