;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260528.1557"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "7e5774e6fa0eec522e62cea1b47ef7feb08eb3ff"
  :revdesc "7e5774e6fa0e"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
