;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-dark-theme" "20260101.1429"
  "Visual Studio IDE dark theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-dark-theme"
  :commit "ce1442aa8ee8cdc37f29011fb0f88401918bb889"
  :revdesc "ce1442aa8ee8"
  :keywords '("faces"))
