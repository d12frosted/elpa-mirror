;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-eval" "20260323.1823"
  "Execute named org-mode blocks on load/save."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-eval"
  :commit "8f98e5412e9eed6d6567f3610cd13e7d149782a7"
  :revdesc "8f98e5412e9e"
  :keywords '("org" "outlines")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
