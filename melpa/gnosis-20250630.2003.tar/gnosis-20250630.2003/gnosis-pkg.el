;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20250630.2003"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "326f6445ba84abcb54c665c63443d0cb0d92733d"
  :revdesc "326f6445ba84"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
