;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "20260710.2252"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "a39f13525d62993bd39ecbe992a06f50853d9d1d"
  :revdesc "a39f13525d62"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
