;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh" "20250712.1559"
  "Consulting GitHub Client."
  '((emacs         "29.4")
    (consult       "2.0")
    (markdown-mode "2.6")
    (ox-gfm        "1.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "6e2fa75dbe51b689f5a87a7052953d113fd54137"
  :revdesc "6e2fa75dbe51"
  :keywords '("convenience" "matching" "tools" "vc"))
