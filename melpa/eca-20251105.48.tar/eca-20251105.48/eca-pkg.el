;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251105.48"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "c7b1f2729f2dc7e2c5c6ee1fc53d1ac1dd0e72c5"
  :revdesc "c7b1f2729f2d"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
