(define-package "go-translate" "20240720.353" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "68b028c48531ec05284fc81666f0906182d79067" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
