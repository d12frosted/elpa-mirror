(define-package "modus-themes" "20220223.1656" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "7773a4ec72d346d6cf4123b574c74507a3dab97f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
