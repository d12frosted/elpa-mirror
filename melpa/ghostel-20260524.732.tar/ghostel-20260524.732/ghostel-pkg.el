;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260524.732"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "1c2f555e04ab8304cb07cbce9bb1dd89d347733b"
  :revdesc "1c2f555e04ab"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
