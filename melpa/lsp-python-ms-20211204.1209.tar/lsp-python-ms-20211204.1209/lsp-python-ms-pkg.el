(define-package "lsp-python-ms" "20211204.1209" "The lsp-mode client for Microsoft python-language-server"
  '((emacs "25.1")
    (lsp-mode "6.1"))
  :commit "abf4d89ecf2fa0871130df5fce6065b7cf0a2721" :authors
  '(("Charl Botha"))
  :maintainers
  '(("Andrew Christianson, Vincent Zhang"))
  :maintainer
  '("Andrew Christianson, Vincent Zhang")
  :keywords
  '("languages" "tools")
  :url "https://github.com/emacs-lsp/lsp-python-ms")
;; Local Variables:
;; no-byte-compile: t
;; End:
