(define-package "pgdevenv" "20150105.2236" "Manage your PostgreSQL development envs" 'nil :commit "7f1d5bc734750aca98cf67a9491cdbd5615fd132" :authors
  '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainer
  '("Dimitri Fontaine" . "dim@tapoueh.org")
  :keywords
  '("emacs" "postgresql" "development" "environment" "shell" "debug" "gdb"))
;; Local Variables:
;; no-byte-compile: t
;; End:
