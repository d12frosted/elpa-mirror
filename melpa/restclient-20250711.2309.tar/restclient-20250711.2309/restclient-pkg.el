;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restclient" "20250711.2309"
  "An interactive HTTP client for Emacs."
  '((emacs  "26.1")
    (compat "30.1.0.0"))
  :url "https://github.com/emacsorphanage/restclient"
  :commit "3b0a63780ff4e0bae049c565473aa1eefb3ba5e5"
  :revdesc "3b0a63780ff4"
  :keywords '("http" "comm" "tools")
  :authors '(("Pavel Kurnosov" . "pashky@gmail.com"))
  :maintainers '(("Peder O. Klingenberg" . "peder@klingenberg.no")))
