;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minions" "20250426.913"
  "A minor-mode menu for the mode line."
  '((emacs  "26.1")
    (compat "30.1.0.0"))
  :url "https://github.com/tarsius/minions"
  :commit "161f0408469e151325caaad8befe3a5693c9bcac"
  :revdesc "161f0408469e"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev")))
