;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hammy" "20240917.212"
  "Programmable, interactive interval timers."
  '((emacs   "28.1")
    (svg-lib "0.2.5")
    (ts      "0.2.2"))
  :url "https://github.com/alphapapa/hammy.el"
  :commit "5d33d41f0aa019719f9568e20b9599aed80d7db6"
  :revdesc "5d33d41f0aa0"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
