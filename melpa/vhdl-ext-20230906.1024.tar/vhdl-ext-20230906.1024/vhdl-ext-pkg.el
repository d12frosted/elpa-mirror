(define-package "vhdl-ext" "20230906.1024" "VHDL Extensions"
  '((emacs "29.1")
    (eglot "1.9")
    (lsp-mode "8.0.1")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "33snapshot")
    (company "0.9.13")
    (outshine "3.1pre")
    (async "1.9.7"))
  :commit "18e32c045889ab7e7b5d5d76352102c776439e31" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
