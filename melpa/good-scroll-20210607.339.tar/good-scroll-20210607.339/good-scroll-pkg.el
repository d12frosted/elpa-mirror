(define-package "good-scroll" "20210607.339" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "b4233500bbbdb64758283ba8a4b7cef5a85181a2" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
