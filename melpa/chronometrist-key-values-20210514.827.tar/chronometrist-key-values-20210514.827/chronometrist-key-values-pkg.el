(define-package "chronometrist-key-values" "20210514.827" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "d0d065a7d99ac77d0379ae630018b7bc2d6663b1" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "gemini://tilde.team/~contrapunctus/software.gmi")
;; Local Variables:
;; no-byte-compile: t
;; End:
