;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260411.1458"
  "Major mode for Godot's GDScript language."
  '((emacs "28.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "a0d4b0a11a50b9cfeaf013e8855b6c636e914065"
  :revdesc "a0d4b0a11a50"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
