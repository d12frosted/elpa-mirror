;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250625.523"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "e4e0cf074d8ccd4520069bcdc5e645fa60f2ede4"
  :revdesc "e4e0cf074d8c"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
