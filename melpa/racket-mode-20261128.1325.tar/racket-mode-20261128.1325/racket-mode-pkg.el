;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "racket-mode" "20261128.1325"
  "Racket editing, REPL, and more."
  '((emacs  "25.1")
    (compat "30.0.2.0"))
  :url "https://www.racket-mode.com/"
  :commit "e129a55709d5a00dbb13af72ba296061920c93aa"
  :revdesc "e129a55709d5"
  :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")))
