;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-prettify-mode" "20260422.732"
  "Hide `if err != nil' and prettify them."
  '((emacs "28.1"))
  :url "https://codeberg.org/snyssfx/go-prettify-mode.el"
  :commit "6aafd440383931b368901de66bf974bbd37a45f9"
  :revdesc "6aafd4403839"
  :keywords '("languages" "go" "tools")
  :authors '(("Gleb Zakharov" . "snyssfx@posteo.net"))
  :maintainers '(("Gleb Zakharov" . "snyssfx@posteo.net")))
