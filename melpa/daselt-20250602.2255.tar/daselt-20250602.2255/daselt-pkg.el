;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20250602.2255"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "86775cba6562f4c34c2ee1cba394deb01bbf6a6b"
  :revdesc "86775cba6562"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
