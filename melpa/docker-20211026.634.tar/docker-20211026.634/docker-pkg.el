(define-package "docker" "20211026.634" "Emacs interface to Docker"
  '((dash "2.14.1")
    (docker-tramp "0.1")
    (emacs "24.5")
    (json-mode "1.7.0")
    (s "1.12.0")
    (tablist "0.70")
    (transient "0.2.0"))
  :commit "5ee4905d81b3fc9993ca55faff24642c2128d2a5" :authors
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainer
  '("Philippe Vaucher" . "philippe.vaucher@gmail.com")
  :keywords
  '("filename" "convenience")
  :url "https://github.com/Silex/docker.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
