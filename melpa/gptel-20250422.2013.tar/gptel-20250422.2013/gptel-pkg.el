;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250422.2013"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "f08065ddcf18486b94f024ee7a0fe944b42bbfa7"
  :revdesc "f08065ddcf18"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
