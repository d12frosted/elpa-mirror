(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "f50c14d3a4e92ed695783e26dbe11ad1ad7b73f7")
;; Local Variables:
;; no-byte-compile: t
;; End:
