(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "0caec01c225972bd594470f919a8533f9a4bfd6a")
;; Local Variables:
;; no-byte-compile: t
;; End:
