(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "cb1ea6808e5a458b16a50772ab8b17435ec04c19")
;; Local Variables:
;; no-byte-compile: t
;; End:
