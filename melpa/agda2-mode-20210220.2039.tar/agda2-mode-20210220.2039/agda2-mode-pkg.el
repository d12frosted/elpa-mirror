(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "9d08edbbabc22c93b47fb17d452b3b35d591b87d")
;; Local Variables:
;; no-byte-compile: t
;; End:
