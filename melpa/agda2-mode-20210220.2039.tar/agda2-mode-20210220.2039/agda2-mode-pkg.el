(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "8d2c172cc2bc700e6eed993557ae11b19cedf682")
;; Local Variables:
;; no-byte-compile: t
;; End:
