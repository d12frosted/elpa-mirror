(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "aea2c53340f509c2c67157caeac360400ea6afbc")
;; Local Variables:
;; no-byte-compile: t
;; End:
