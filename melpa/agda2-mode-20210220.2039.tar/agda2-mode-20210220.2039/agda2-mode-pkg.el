(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "7716754f2ae5501d595821a89c98f3061fafb6ce")
;; Local Variables:
;; no-byte-compile: t
;; End:
