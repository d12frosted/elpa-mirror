(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "9599ddf38c4c91b93618893d39e439b488f11945")
;; Local Variables:
;; no-byte-compile: t
;; End:
