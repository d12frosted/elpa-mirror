(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "72e3aac0d63f8a53ca77a8dce2e339363c550334")
;; Local Variables:
;; no-byte-compile: t
;; End:
