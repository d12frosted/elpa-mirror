(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "b63b0ad0e4f1af7e001342bebb0c3daaf542f328")
;; Local Variables:
;; no-byte-compile: t
;; End:
