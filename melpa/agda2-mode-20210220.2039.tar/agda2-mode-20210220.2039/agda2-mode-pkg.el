(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "4f4f1fe37a26b38627e3323480b4bcc69b7e13a9")
;; Local Variables:
;; no-byte-compile: t
;; End:
