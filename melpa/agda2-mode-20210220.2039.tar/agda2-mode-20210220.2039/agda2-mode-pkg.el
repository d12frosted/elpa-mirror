(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "a309a8ac28915506ca6ac2f8976af8e708b9e95b")
;; Local Variables:
;; no-byte-compile: t
;; End:
