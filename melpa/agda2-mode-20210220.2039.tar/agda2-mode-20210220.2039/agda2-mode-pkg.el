(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "0eaf4390361dce47e1200c4676d4b67c17710085")
;; Local Variables:
;; no-byte-compile: t
;; End:
