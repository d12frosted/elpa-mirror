(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "12ba4038629784eec568bde6d6a795e515df3e18")
;; Local Variables:
;; no-byte-compile: t
;; End:
