(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "a96724385f3fd54f3a38a25ebeea69c6c598640c")
;; Local Variables:
;; no-byte-compile: t
;; End:
