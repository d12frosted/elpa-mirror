(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "3e079614f2b4810ff5920ae69a389da91c855217")
;; Local Variables:
;; no-byte-compile: t
;; End:
