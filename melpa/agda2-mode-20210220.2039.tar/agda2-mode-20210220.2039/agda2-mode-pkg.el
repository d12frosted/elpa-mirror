(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "adf366f2d8a55ff78d59d5f7979dca6ca91985f8")
;; Local Variables:
;; no-byte-compile: t
;; End:
