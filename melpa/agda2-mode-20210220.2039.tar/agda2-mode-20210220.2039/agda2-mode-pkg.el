(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "02f2bf5976dc18325bc9a73903909d2ea356f62a")
;; Local Variables:
;; no-byte-compile: t
;; End:
