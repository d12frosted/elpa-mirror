(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "bf7acefa717507c93f3bb1a56f0786a95b95c11d")
;; Local Variables:
;; no-byte-compile: t
;; End:
