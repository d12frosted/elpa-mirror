(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "bfff1de33be8c6121f089c4065dce0ef6c948b4f")
;; Local Variables:
;; no-byte-compile: t
;; End:
