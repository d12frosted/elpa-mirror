(define-package "dired-rsync" "20230714.1459" "Allow rsync from dired buffers"
  '((s "1.12.0")
    (dash "2.0.0")
    (emacs "25.1"))
  :commit "95607fc7eb84e792122b52d2b1d62f49199a2a37" :authors
  '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers
  '(("Alex Bennée" . "alex@bennee.com"))
  :maintainer
  '("Alex Bennée" . "alex@bennee.com")
  :url "https://github.com/stsquad/dired-rsync")
;; Local Variables:
;; no-byte-compile: t
;; End:
