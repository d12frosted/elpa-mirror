(define-package "doom-themes" "20230907.1657" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "a5d86e2068aeb9485f54e1f520fee16363fbbc26" :authors
  '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainers
  '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainer
  '("Henrik Lissner" . "contact@henrik.io")
  :keywords
  '("themes" "faces")
  :url "https://github.com/doomemacs/themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
