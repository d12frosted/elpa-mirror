;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260323.452"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "827ad8056d12cb21e38d2f9000212cf74353615e"
  :revdesc "827ad8056d12"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
