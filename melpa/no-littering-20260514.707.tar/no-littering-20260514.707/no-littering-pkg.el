;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260514.707"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "420647d49f7436462af2abee493d0efc828c43e6"
  :revdesc "420647d49f74"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
