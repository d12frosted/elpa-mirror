;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251125.617"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "0088add0ad5c742e2d3ec227c1d6feb283914088"
  :revdesc "0088add0ad5c"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
