(define-package "dwim-shell-command" "20221101.855" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "8ef3bd799687eec8ad2d919c9f38d56b02b5e4cb" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
