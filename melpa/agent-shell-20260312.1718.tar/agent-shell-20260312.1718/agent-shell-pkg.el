;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260312.1718"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a7908cb2576a636f6da40e2ace3404036da80f76"
  :revdesc "a7908cb2576a")
