(define-package "live-py-mode" "20220129.1757" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "d8ee3b121186165cab01fe8f8c7585b618e22428" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
