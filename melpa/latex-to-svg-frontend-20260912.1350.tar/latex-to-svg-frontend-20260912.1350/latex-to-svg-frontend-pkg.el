;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20260912.1350"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.9.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "e395700ca77f54a2140fb701b1251fded6e96af2"
  :revdesc "e395700ca77f"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
