;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-org-roam" "20260917.441"
  "Consult integration for org-roam."
  '((emacs    "27.1")
    (org-roam "2.2.0")
    (consult  "0.16"))
  :url "https://github.com/jgru/consult-org-roam"
  :commit "832c5f754229698961345582356a6a4d13bc785a"
  :revdesc "832c5f754229"
  :authors '(("jgru" . "https://github.com/jgru"))
  :maintainers '(("jgru" . "https://github.com/jgru")))
