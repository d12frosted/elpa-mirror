(define-package "eldev" "20230514.1809" "Elisp development tool"
  '((emacs "24.4"))
  :commit "8e89f62c5b62ece7f295c24c5d2bc7f4cb27eeb9" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
