;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fpga" "20251112.1926"
  "FPGA & ASIC Utils."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/fpga"
  :commit "8b3ace934b9c2605aa3be446abc27947d6e7ebae"
  :revdesc "8b3ace934b9c"
  :keywords '("tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
