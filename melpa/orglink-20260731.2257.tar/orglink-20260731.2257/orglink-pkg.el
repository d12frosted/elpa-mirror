;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglink" "20260731.2257"
  "Use Org Mode links in other modes."
  '((emacs  "28.1")
    (compat "31.0")
    (llama  "1.0")
    (org    "9.8")
    (seq    "2.24"))
  :url "https://github.com/tarsius/orglink"
  :commit "2e66d4cae10e54a49380fd7b552b641ebd731a15"
  :revdesc "2e66d4cae10e"
  :keywords '("hypermedia")
  :authors '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev")))
