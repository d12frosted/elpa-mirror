(define-package "mini-echo" "20231029.217" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "bbbbde4c8f1e14a1917e6bdc25cadd858c724937" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
