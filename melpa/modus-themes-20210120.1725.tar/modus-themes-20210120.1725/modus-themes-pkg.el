(define-package "modus-themes" "20210120.1725" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "3b177143da199b79900e32c44a4e5bca48c87f2b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
