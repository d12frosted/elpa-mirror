(define-package "consult" "20210806.808" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "8e90f2db6952a337d524a6cd21999d1c10d349b3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
