(define-package "mew" "20240429.534" "Messaging in the Emacs World" 'nil :commit "e68cd29e86e65b30a76f836973b0e1efe3b11e9e" :authors
  '(("Mew developing team"))
  :maintainers
  '(("Mew developing team"))
  :maintainer
  '("Mew developing team"))
;; Local Variables:
;; no-byte-compile: t
;; End:
