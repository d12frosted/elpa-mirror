(define-package "ac-php-core" "20210617.747" "The core library of the ac-php."
  '((dash "1")
    (php-mode "1")
    (s "1")
    (f "0.17.0")
    (popup "0.5.0")
    (xcscope "1.0"))
  :commit "a2d5e00355303bbc87dee60a6559ce214f9be75d" :authors
  '(("jim" . "xcwenn@qq.com")
    ("Serghei Iakovlev" . "sadhooklay@gmail.com"))
  :maintainer
  '("jim")
  :keywords
  '("completion" "convenience" "intellisense")
  :url "https://github.com/xcwen/ac-php")
;; Local Variables:
;; no-byte-compile: t
;; End:
