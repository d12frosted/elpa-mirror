(define-package "hyperbole" "20240416.412" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.1"))
  :commit "fba4d6b6d4840b3aa47df38bfb6469c988f6b3bb" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Mats Lidell" . "matsl@gnu.org"))
  :maintainer
  '("Mats Lidell" . "matsl@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
