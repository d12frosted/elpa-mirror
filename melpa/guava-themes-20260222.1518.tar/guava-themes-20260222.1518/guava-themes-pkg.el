;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260222.1518"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "1a8e3aa0f999a378344da0cf82ee843773526f9c"
  :revdesc "1a8e3aa0f999"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
