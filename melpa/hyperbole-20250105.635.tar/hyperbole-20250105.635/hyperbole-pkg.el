;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250105.635"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "895da1a4a6d14bafd928f88bdbe7e0c95d827639"
  :revdesc "895da1a4a6d1"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
