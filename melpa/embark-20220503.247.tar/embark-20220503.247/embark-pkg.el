(define-package "embark" "20220503.247" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d4e4498c871f7edf32b59a731c582a74059157c5" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
