;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20251122.209"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "5e5969d7c8afa4c40948d95dc41fe66e30f3a282"
  :revdesc "5e5969d7c8af"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
