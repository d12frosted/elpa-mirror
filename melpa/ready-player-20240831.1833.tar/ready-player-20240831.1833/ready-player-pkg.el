(define-package "ready-player" "20240831.1833" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "e6774be27654062e9ea2c528520eff96461157b0" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
