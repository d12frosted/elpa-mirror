(define-package "pet" "20230824.1919" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0"))
  :commit "eb0c01380f1930825844027d9af6f4a263238a89" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
