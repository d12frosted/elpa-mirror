(define-package "syslog-mode" "20210903.2322" "Major-mode for viewing log files & strace output"
  '((hide-lines "20130623")
    (ov "20150311")
    (hsluv "20181127"))
  :commit "8c508e2f9d290ed81e3624928dd28b628e90b6f1" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
