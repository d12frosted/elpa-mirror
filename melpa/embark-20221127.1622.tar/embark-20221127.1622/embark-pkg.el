(define-package "embark" "20221127.1622" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "fa5a59cf55d570d41f5da04d2a4951bb3ef10eaf" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
