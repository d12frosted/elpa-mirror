;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persp-mode-projectile-bridge" "20170315.1120"
  "Persp-mode + projectile integration."
  '((persp-mode "2.9")
    (projectile "0.13.0")
    (cl-lib     "0.5"))
  :url "https://github.com/Bad-ptr/persp-mode-projectile-bridge.el"
  :commit "f6453cd7b8b4352c06e771706f2c5b7e2cdff1ce"
  :revdesc "f6453cd7b8b4"
  :keywords '("persp-mode" "projectile")
  :authors '(("Constantin Kulikov" . "zxnotdead@gmail.com"))
  :maintainers '(("Constantin Kulikov" . "zxnotdead@gmail.com")))
