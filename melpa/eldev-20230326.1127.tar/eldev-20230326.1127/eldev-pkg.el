(define-package "eldev" "20230326.1127" "Elisp development tool"
  '((emacs "24.4"))
  :commit "3162ae8015ec37ae8560bedc7e0b28f0695dd4d3" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
