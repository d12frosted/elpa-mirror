;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260323.730"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "419ba4b842a1d0a6bd3f9dbb2a376dfda4f4be76"
  :revdesc "419ba4b842a1"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
