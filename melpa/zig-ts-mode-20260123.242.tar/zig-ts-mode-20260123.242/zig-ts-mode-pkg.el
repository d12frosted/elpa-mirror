;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-ts-mode" "20260123.242"
  "Tree Sitter support for Zig."
  '((emacs "29.1"))
  :url "https://codeberg.org/meow_king/zig-ts-mode"
  :commit "64611c6d512e4c15e8d1e3fd0fde6bd47c6c8f50"
  :revdesc "64611c6d512e"
  :keywords '("zig" "languages" "tree-sitter")
  :authors '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers '(("meowking" . "mr.meowking@tutamail.com")))
