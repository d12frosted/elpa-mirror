(define-package "modus-themes" "20220118.1928" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "581ada01203c13758060852b758706565290935b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
