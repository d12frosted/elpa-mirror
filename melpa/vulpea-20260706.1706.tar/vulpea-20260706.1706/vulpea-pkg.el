;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260706.1706"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "7ddf6eb711b76d0c50d4bfbdf7627bf4f9e7a066"
  :revdesc "7ddf6eb711b7"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
