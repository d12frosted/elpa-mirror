;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251125.1215"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "3b0bbaa77962ea6f68adb5c7ca929953c55b0992"
  :revdesc "3b0bbaa77962"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
