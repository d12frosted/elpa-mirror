;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "drupal-mode" "20240816.1236"
  "Advanced minor mode for Drupal development."
  '((php-mode "1.5.0"))
  :url "https://github.com/arnested/drupal-mode"
  :commit "3f91d1d44df11ebd0137a896055fca6a1bb2f554"
  :revdesc "3f91d1d44df1"
  :keywords '("programming" "php" "drupal")
  :authors '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainers '(("Arne Jørgensen" . "arne@arnested.dk")))
