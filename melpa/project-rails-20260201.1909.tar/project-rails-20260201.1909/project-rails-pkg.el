;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-rails" "20260201.1909"
  "Rails support for project.el."
  '((emacs       "28.1")
    (inflections "2.6"))
  :url "https://github.com/harrybournis/project.el-rails"
  :commit "653e31a0b7b08445fa3efc41d741d642a46f9903"
  :revdesc "653e31a0b7b0"
  :keywords '("languages" "project.el" "rails")
  :authors '(("Harry Bournis" . "harrybournis@gmail.com"))
  :maintainers '(("Harry Bournis" . "harrybournis@gmail.com")))
