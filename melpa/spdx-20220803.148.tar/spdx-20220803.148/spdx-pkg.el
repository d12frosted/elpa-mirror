(define-package "spdx" "20220803.148" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "cefebe6215b4065827553f2e0cb87c31c5893e5e" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
