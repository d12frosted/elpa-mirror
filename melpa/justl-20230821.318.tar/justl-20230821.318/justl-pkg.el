(define-package "justl" "20230821.318" "Major mode for driving just files"
  '((transient "0.1.0")
    (emacs "27.1")
    (s "1.2.0")
    (f "0.20.0")
    (inheritenv "0.2"))
  :commit "30350ded297b74980e0cafb75030001a21531acf" :authors
  '(("Sibi Prabakaran"))
  :maintainers
  '(("Sibi Prabakaran"))
  :maintainer
  '("Sibi Prabakaran")
  :keywords
  '("just" "justfile" "tools" "processes")
  :url "https://github.com/psibi/justl.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
