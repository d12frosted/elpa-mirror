(define-package "embark" "20231004.1423" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "de7999e5b2b8849fb4c2f43369f1975ccd545a68" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
