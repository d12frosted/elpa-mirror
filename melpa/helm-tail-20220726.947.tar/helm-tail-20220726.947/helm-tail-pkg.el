;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-tail" "20220726.947"
  "Read recent output from various sources."
  '((emacs "25.1")
    (helm  "2.7.0"))
  :url "https://github.com/akirak/helm-tail"
  :commit "8dc44a87fa1a52199e43b73b55c8ef8fe8069e79"
  :revdesc "8dc44a87fa1a"
  :keywords '("maint" "tools")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
