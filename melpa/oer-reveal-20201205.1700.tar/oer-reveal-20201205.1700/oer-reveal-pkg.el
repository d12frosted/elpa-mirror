(define-package "oer-reveal" "20201205.1700" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "0b9687e6558cca3afc4058c1fbfe5d1a036ce722" :keywords
  ("hypermedia" "tools" "slideshow" "presentation" "oer")
  :authors
  (("Jens Lechtenbörger"))
  :maintainer
  ("Jens Lechtenbörger")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
