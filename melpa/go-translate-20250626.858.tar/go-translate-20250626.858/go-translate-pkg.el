;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250626.858"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "d861e1a66c19b32f27e35faa555799336a6d6f8f"
  :revdesc "d861e1a66c19"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
