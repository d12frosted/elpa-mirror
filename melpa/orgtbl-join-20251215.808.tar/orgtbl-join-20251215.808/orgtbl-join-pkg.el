;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20251215.808"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "419909d264402a5260ca63288c46b3df0b236106"
  :revdesc "419909d26440"
  :keywords '("data" "extensions"))
