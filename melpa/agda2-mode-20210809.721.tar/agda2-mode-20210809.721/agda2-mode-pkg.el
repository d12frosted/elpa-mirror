(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "8aec1e6d655c082de3a3239f528015760862fd2f")
;; Local Variables:
;; no-byte-compile: t
;; End:
