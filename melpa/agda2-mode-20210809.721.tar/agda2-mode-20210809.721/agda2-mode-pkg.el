(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "6250c3d997f9e77562390f850a86b7511f1e7003")
;; Local Variables:
;; no-byte-compile: t
;; End:
