(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "e2a6f2d21392360413d7ce86854d825657ce827e")
;; Local Variables:
;; no-byte-compile: t
;; End:
