(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "a9d5d1683bd2ce24939656b174d2bbcde5a5116e")
;; Local Variables:
;; no-byte-compile: t
;; End:
