(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "3376fcd27edebfa90a3267cb26187f4bc6318c96")
;; Local Variables:
;; no-byte-compile: t
;; End:
