(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "b44a0bd8289ff2c5babac6ca9156d08eba812de1")
;; Local Variables:
;; no-byte-compile: t
;; End:
