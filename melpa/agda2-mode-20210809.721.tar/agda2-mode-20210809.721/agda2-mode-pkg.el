(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "d7455a69e1e6e3b89fdd36ea623300fedb98b9ed")
;; Local Variables:
;; no-byte-compile: t
;; End:
