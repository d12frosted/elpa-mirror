(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "2f80f35182a548396f0099e49874e714af522038")
;; Local Variables:
;; no-byte-compile: t
;; End:
