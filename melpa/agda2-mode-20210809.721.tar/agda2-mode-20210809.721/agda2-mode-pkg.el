(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c35ddfe5aa2f64bca5fe01b40dffa3c87a233d0e")
;; Local Variables:
;; no-byte-compile: t
;; End:
