(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "e7f1c56f071fc1d738a873edb929e40322f24ce8")
;; Local Variables:
;; no-byte-compile: t
;; End:
