(define-package "modus-themes" "20210522.1727" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "072f1119081bc282ba2995abf877aeb4cde7b1ec" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
