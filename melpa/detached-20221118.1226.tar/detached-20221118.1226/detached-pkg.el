(define-package "detached" "20221118.1226" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "8c7a2e1129b254946d86a7b7ae1c8378afab7b69" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
