;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solaire-mode" "20251223.43"
  "Make certain buffers grossly incandescent."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-solaire-mode"
  :commit "d9baa1a0d1799db941ed08a81c0768b8ad19d1b5"
  :revdesc "d9baa1a0d179"
  :keywords '("dim" "bright" "window" "buffer" "faces")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
