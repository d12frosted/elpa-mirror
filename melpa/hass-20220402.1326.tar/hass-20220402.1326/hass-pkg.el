(define-package "hass" "20220402.1326" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3"))
  :commit "c6bded14ae4b68194bd9e35428e9973ca144569b" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
