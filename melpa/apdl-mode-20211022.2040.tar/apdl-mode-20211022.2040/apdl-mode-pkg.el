(define-package "apdl-mode" "20211022.2040" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "bdffe5c910cab1636b98754997e720ba1a15d7de" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
