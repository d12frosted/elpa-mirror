(define-package "gptai" "20230316.809" "Integrate with the OpenAI API"
  '((emacs "24.1"))
  :commit "d57c60af9d5ea03b3e835c14e7102f5f65785f41" :authors
  '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainer
  '("Anton Hibl" . "antonhibl11@gmail.com")
  :keywords
  '("comm" "convenience")
  :url "https://github.com/antonhibl/gptai")
;; Local Variables:
;; no-byte-compile: t
;; End:
