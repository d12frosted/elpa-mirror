;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20261031.30"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "f4b8c21eea95e0cd6312683c0ac96b82c9105f80"
  :revdesc "f4b8c21eea95"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
