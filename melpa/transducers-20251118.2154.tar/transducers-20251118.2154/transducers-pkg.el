;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transducers" "20251118.2154"
  "Ergonomic, efficient data processing."
  '((emacs "28.1"))
  :url "https://github.com/fosskers/transducers.el"
  :commit "7d36c9cdbd2179479314e4c277ecaa8020481078"
  :revdesc "7d36c9cdbd21"
  :keywords '("lisp")
  :authors '(("Colin Woodbury" . "colin@fosskers.ca"))
  :maintainers '(("Colin Woodbury" . "colin@fosskers.ca")))
