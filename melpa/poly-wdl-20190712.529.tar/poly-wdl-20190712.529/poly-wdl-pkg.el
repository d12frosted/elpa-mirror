;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-wdl" "20190712.529"
  "Polymode for WDL."
  '((emacs    "25")
    (polymode "0.2")
    (wdl-mode "20170709"))
  :url "https://github.com/jmonlong/poly-wdl"
  :commit "fe2ee0c441795c35a8c127fa1f7006a5f251f564"
  :revdesc "fe2ee0c44179"
  :keywords '("languages")
  :authors '(("Jean Monlong" . "jean.monlong@gmail.com"))
  :maintainers '(("Jean Monlong" . "jean.monlong@gmail.com")))
