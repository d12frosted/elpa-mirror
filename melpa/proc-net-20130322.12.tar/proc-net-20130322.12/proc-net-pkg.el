;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proc-net" "20130322.12"
  "Network process tools."
  ()
  :url "https://github.com/nicferrier/emacs-procnet"
  :commit "00bfc92a381787ec387974ed17070118ced6d9ad"
  :revdesc "00bfc92a3817"
  :keywords '("processes")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
