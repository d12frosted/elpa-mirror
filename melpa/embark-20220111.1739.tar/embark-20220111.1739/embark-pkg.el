(define-package "embark" "20220111.1739" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "1842d6b182c4fe7b6aa4d06f4957fbeabaa96de3" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
