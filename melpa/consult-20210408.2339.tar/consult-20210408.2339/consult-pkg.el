(define-package "consult" "20210408.2339" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "70403247a2637a02b2e45156251c6c0f937163c8" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
