(define-package "devil" "20230730.832" "Minor mode for translating key sequences"
  '((emacs "24.4"))
  :commit "1985300ce84abd712be93b271b27c3bdb164231d" :authors
  '(("Susam Pal" . "susam@susam.net"))
  :maintainers
  '(("Susam Pal" . "susam@susam.net"))
  :maintainer
  '("Susam Pal" . "susam@susam.net")
  :keywords
  '("convenience" "abbrev")
  :url "https://github.com/susam/devil")
;; Local Variables:
;; no-byte-compile: t
;; End:
