;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-mode" "20201223.719"
  "A major mode for creating anki cards."
  '((emacs         "24.4")
    (dash          "2.12.0")
    (markdown-mode "2.2")
    (s             "1.11.0")
    (request       "0.3.0"))
  :url "https://github.com/davidshepherd7/anki-mode"
  :commit "7cde5a68c9d0ef3811b0bd480274ea79909d2ddc"
  :revdesc "7cde5a68c9d0"
  :keywords '("tools")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
