(define-package "consult" "20201213.306" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f30fcaa2e161d272f5a7cd82d26ace0431a27ac5" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
