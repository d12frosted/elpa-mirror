(define-package "mistty" "20230917.1928" "Shell/Comint alternative based on term.el"
  '((emacs "29.1")
    (iter2 "1.4"))
  :commit "70c4d9eafbf26cd90d8538e1389854c7d4ef227a" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
