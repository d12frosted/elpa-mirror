(define-package "dirvish" "20220610.2136" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "b469079f18d77560ea0534708a212ecbc99b68a9" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
