;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241227.1755"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "0da97d76671572b6b7cf4aee444a9afa7c33ecf7"
  :revdesc "0da97d766715"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
