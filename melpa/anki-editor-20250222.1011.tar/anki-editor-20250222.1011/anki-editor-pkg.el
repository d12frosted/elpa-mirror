;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20250222.1011"
  "Minor mode for making Anki cards with Org."
  '((emacs "29.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "49c1f75843b69254381f7066ef3aca22fe5f20df"
  :revdesc "49c1f75843b6")
