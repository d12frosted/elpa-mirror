(define-package "lsp-mode" "20201204.1617" "LSP mode"
  '((emacs "26.1")
    (dash "2.14.1")
    (dash-functional "2.14.1")
    (f "0.20.0")
    (ht "2.0")
    (spinner "1.7.3")
    (markdown-mode "2.3")
    (lv "0"))
  :commit "e1c42412eac0d742196efe64a82699326e72b391" :keywords
  ("languages")
  :authors
  (("Vibhav Pant, Fangrui Song, Ivan Yonchovski"))
  :maintainer
  ("Vibhav Pant, Fangrui Song, Ivan Yonchovski")
  :url "https://github.com/emacs-lsp/lsp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
