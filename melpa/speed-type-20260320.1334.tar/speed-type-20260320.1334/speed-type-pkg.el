;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260320.1334"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "257fec4d1ed5637300bf0457df8d7e0bbc5b5226"
  :revdesc "257fec4d1ed5"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
