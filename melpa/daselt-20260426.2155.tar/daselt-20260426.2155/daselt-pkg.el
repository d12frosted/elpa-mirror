;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260426.2155"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "8ffadc0200fef9d01cbb9b80f00c76ab806f5db1"
  :revdesc "8ffadc0200fe"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
