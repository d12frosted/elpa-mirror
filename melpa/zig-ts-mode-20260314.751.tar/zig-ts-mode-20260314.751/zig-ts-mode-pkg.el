;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-ts-mode" "20260314.751"
  "Major mode for Zig code."
  '((emacs "29.1"))
  :url "https://codeberg.org/meow_king/zig-ts-mode"
  :commit "d02a23c11f697ff1aa8e5b64b440bb7798cefdf5"
  :revdesc "d02a23c11f69"
  :keywords '("zig" "languages" "tree-sitter")
  :authors '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers '(("meowking" . "mr.meowking@tutamail.com")))
