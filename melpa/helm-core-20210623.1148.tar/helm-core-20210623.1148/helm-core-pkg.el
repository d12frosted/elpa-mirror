(define-package "helm-core" "20210623.1148" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "d72d4ef1a5cead62ab99072ca5a476422b024f43")
;; Local Variables:
;; no-byte-compile: t
;; End:
