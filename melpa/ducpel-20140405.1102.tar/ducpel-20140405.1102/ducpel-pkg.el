(define-package "ducpel" "20140405.1102" "Logic game with sokoban elements"
  '((cl-lib "0.5"))
  :commit "ece785baaa102bd2e9d54257af3a92bacc5757bc" :authors
  '(("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  '("Alex Kost" . "alezost@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/alezost/ducpel")
;; Local Variables:
;; no-byte-compile: t
;; End:
