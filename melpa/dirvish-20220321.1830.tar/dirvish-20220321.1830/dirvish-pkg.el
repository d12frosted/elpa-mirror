(define-package "dirvish" "20220321.1830" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "ced778f22e7a140350958f5d436303a9f84be622" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
