;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kiwix" "20220316.847"
  "Searching offline Wikipedia through Kiwix."
  '((emacs   "25.1")
    (request "0.3.0"))
  :url "https://repo.or.cz/kiwix.el.git"
  :commit "444f686a7f75db788d54f544b923a3532732eb8b"
  :revdesc "444f686a7f75"
  :keywords '("kiwix" "wikipedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
