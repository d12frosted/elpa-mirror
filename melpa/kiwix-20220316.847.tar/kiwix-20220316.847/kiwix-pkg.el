(define-package "kiwix" "20220316.847" "Searching offline Wikipedia through Kiwix."
  '((emacs "25.1")
    (request "0.3.0"))
  :commit "444f686a7f75db788d54f544b923a3532732eb8b" :authors
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("kiwix" "wikipedia")
  :url "https://repo.or.cz/kiwix.el.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
