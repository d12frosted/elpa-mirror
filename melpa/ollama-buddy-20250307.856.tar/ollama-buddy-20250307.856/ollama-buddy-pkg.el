;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250307.856"
  "Ollama Buddy: Your Friendly AI Assistant."
  '((emacs "26.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "b7241d2967eebccc57d1a69168dde215f88aa76a"
  :revdesc "b7241d2967ee"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
