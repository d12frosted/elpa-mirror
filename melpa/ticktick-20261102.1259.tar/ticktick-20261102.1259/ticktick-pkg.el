;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ticktick" "20261102.1259"
  "Sync Org Mode tasks with TickTick."
  '((emacs        "27.1")
    (request      "0.3.0")
    (simple-httpd "1.5.0"))
  :url "https://github.com/polhuang/ticktick.el"
  :commit "48973e636ce0bb7ade8eed92e64eec9b0d20fa43"
  :revdesc "48973e636ce0"
  :keywords '("tools" "ticktick" "org" "tasks" "todo"))
