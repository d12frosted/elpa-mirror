(define-package "pg" "20240627.1705" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "28.1")
    (peg "1.0"))
  :commit "91405b00575645a7b85e66264fd000d729f177fe" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
