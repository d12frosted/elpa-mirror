;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adif" "20260930.250"
  "Major mode for viewing and editing ADIF log files."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/adif-mode"
  :commit "fb129a2dbb6e4d985a6c078d8759682baa722575"
  :revdesc "fb129a2dbb6e"
  :keywords '("comm" "hamradio" "adif" "logging"))
