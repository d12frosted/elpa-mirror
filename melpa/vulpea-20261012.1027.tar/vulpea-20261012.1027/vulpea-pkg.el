;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261012.1027"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "0edc7614f1dc4e3bccb30a0f3ca9952b25709287"
  :revdesc "0edc7614f1dc"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
