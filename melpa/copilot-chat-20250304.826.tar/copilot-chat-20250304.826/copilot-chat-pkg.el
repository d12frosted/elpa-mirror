;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20250304.826"
  "Copilot chat interface."
  '((request       "0.3.2")
    (markdown-mode "2.6")
    (emacs         "27.1")
    (magit         "4.0.0")
    (transient     "0.8.3")
    (org           "9.4.6")
    (polymode      "0.2.2")
    (shell-maker   "0.76.2"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "be54464281d9184561a47e9ea1d901bf2d08790b"
  :revdesc "be54464281d9"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
