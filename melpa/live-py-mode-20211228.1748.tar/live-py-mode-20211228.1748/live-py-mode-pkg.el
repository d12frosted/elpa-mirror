(define-package "live-py-mode" "20211228.1748" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "0fbbd6cccf5e841db17d18ac78c5f100d504dc78" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
