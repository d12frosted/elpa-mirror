;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-mode" "20260119.217"
  "Major mode for General Algebraic Modeling System (GAMS)."
  '((emacs "25.1"))
  :url "https://github.com/ShiroTakeda/gams-mode"
  :commit "519c64f186515157b6a01143f438dc24148d8e58"
  :revdesc "519c64f18651"
  :keywords '("languages" "tools" "gams"))
