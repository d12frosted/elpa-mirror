;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clips-mode" "20170909.823"
  "Major mode for editing CLIPS code and REPL."
  ()
  :url "https://github.com/clips-mode/clips-mode"
  :commit "dd38e2822640a38f7d8bfec4f69d8dd24be27074"
  :revdesc "dd38e2822640"
  :keywords '("clips")
  :authors '(("David E. Young" . "david.young@fnc.fujitsu.com")
             ("Andrey Kotlarski" . "m00naticus@gmail.com")
             ("Grant Rettke" . "grettke@acm.org"))
  :maintainers '(("Grant Rettke" . "grettke@acm.org")))
