;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bash-completion" "20261105.2239"
  "Bash completion for the shell buffer."
  '((emacs "25.3"))
  :url "https://github.com/szermatt/emacs-bash-completion"
  :commit "67d51f2c2345d9b33c1a1049b8898749d3b91c0a"
  :revdesc "67d51f2c2345"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
