;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20260716.1425"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "af030703c54004d28794c9b259d8fa6c7eaeec19"
  :revdesc "af030703c540"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
