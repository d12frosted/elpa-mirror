;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "koishi-theme" "20260125.1452"
  "A sweet theme inspired by Koishi's color tone."
  '((emacs "24.1"))
  :url "https://github.com/gynamics/koishi-theme.el"
  :commit "d31264d0954c95eae0773913454fda6b115e8396"
  :revdesc "d31264d0954c"
  :keywords '("faces"))
