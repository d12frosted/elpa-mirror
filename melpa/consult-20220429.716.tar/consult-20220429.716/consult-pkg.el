(define-package "consult" "20220429.716" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "df68639766c1c6c6bfa39249719f98c22a6c9534" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
