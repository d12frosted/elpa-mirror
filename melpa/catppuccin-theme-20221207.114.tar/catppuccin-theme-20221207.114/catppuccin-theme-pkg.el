(define-package "catppuccin-theme" "20221207.114" "Catppuccin Theme"
  '((emacs "25.1"))
  :commit "5da39a2ae403d66938058ce88662e4f976b64bd5" :authors
  '(("pspiagicw"))
  :maintainer
  '("Name" . "namesexistsinemails@gmail.com")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
