(define-package "tok-theme" "20220201.621" "My theme"
  '((emacs "24.3"))
  :commit "a4aeb2284d708577754234a9ba7d381adb3224fd" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
