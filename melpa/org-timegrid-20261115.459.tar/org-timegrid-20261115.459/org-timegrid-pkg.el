;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261115.459"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "730b6910ac5a394a08466c854f41ebfb89dc0327"
  :revdesc "730b6910ac5a"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
