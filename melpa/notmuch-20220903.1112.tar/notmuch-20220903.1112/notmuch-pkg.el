(define-package "notmuch" "20220903.1112" "run notmuch within emacs" 'nil :commit "a3b46fa8bbfaf6651f5055bb27aa52a0ef0d3ba2" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
