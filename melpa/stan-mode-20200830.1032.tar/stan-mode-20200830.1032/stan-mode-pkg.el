(define-package "stan-mode" "20200830.1032" "Major mode for editing Stan files"
  '((emacs "24.4"))
  :commit "2dd330604563d143031fc8ffd516266217aa1f9b" :authors
  '(("Jeffrey Arnold" . "jeffrey.arnold@gmail.com")
    ("Daniel Lee" . "bearlee@alum.mit.edu")
    ("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainer
  '("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")
  :keywords
  '("languages" "c")
  :url "https://github.com/stan-dev/stan-mode/tree/master/stan-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
