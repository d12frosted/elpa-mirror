;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smblog" "20200424.938"
  "Samba log viewer."
  '((emacs "24.3"))
  :url "https://github.com/aaptel/smblog-mode"
  :commit "fc949cff7051b31f0dbc7169774144533a27b92f"
  :revdesc "fc949cff7051"
  :authors '(("Aurélien Aptel" . "aaptel@suse.com"))
  :maintainers '(("Aurélien Aptel" . "aaptel@suse.com")))
