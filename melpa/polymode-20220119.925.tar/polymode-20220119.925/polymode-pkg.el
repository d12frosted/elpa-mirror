(define-package "polymode" "20220119.925" "Extensible framework for multiple major modes"
  '((emacs "25"))
  :commit "667f45e8f62a1b3dfa0e564b845375faf32049b0" :authors
  '(("Vitalie Spinu"))
  :maintainer
  '("Vitalie Spinu")
  :keywords
  '("languages" "multi-modes" "processes")
  :url "https://github.com/polymode/polymode")
;; Local Variables:
;; no-byte-compile: t
;; End:
