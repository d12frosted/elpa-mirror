(define-package "company-box" "20220909.1814" "Company front-end with icons"
  '((emacs "26.0.91")
    (dash "2.19.0")
    (company "0.9.6")
    (frame-local "0.0.1"))
  :commit "4dc0d9841aca2437f68f07aa540a3fab365ecff1" :authors
  '(("Sebastien Chapuis" . "sebastien@chapu.is"))
  :maintainer
  '("Sebastien Chapuis" . "sebastien@chapu.is")
  :keywords
  '("company" "completion" "front-end" "convenience")
  :url "https://github.com/sebastiencs/company-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
