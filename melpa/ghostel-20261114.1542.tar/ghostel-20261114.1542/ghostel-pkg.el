;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261114.1542"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "98be9d95ecad8135a160696980338c9e2cc24fdb"
  :revdesc "98be9d95ecad"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
