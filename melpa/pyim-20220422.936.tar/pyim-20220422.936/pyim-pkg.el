(define-package "pyim" "20220422.936" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "25.1")
    (async "1.6")
    (xr "1.13"))
  :commit "cd1bfd2bbc10fe0ac47d0ec383cde453f6019e6c" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
