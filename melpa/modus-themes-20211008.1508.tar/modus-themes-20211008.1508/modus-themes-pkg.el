(define-package "modus-themes" "20211008.1508" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "3c853058fa675fc6e858057635b4481df6741388" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
