(define-package "hl-prog-extra" "20220726.5" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "6f05c4152dbbec033deb9c0ef7b4c9b6971a7173" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
