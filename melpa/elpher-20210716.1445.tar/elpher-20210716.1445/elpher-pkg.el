(define-package "elpher" "20210716.1445" "A friendly gopher and gemini client"
  '((emacs "26.2"))
  :commit "7e0919bd74952fb229862f1280e01817721b7fc2" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "http://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
