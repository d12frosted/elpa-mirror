;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261123.1607"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "71b3681ee0d4111994d78ee822d0d5e81da3b05f"
  :revdesc "71b3681ee0d4"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
