;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260414.150"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "b19f15c019740f884487602560c904914cf2c48b"
  :revdesc "b19f15c01974"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
