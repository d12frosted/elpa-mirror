;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260228.1839"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "24.4")
    (dash  "2.9.0"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "036526523db7518e838cfc8a15cd7a7778472256"
  :revdesc "036526523db7"
  :keywords '("programming"))
