(define-package "msvc" "20221015.1610" "Microsoft Visual C/C++ mode"
  '((emacs "24")
    (cl-lib "0.5")
    (cedet "1.0")
    (ac-clang "2.0.0"))
  :commit "1bf173b5da3fbf2bdb799116e2a1f31916c1e16e" :authors
  '(("yaruopooner [https://github.com/yaruopooner]"))
  :maintainer
  '("yaruopooner [https://github.com/yaruopooner]")
  :keywords
  '("languages" "completion" "syntax check" "mode" "intellisense")
  :url "https://github.com/yaruopooner/msvc")
;; Local Variables:
;; no-byte-compile: t
;; End:
