(define-package "electric-spacing" "20210430.1714" "Insert operators with surrounding spaces smartly" 'nil :commit "800e09af7b0cd5d78d22f857dbce10fb080637df" :authors
  '(("William Xu" . "william.xwl@gmail.com"))
  :maintainer
  '("William Xu" . "william.xwl@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
