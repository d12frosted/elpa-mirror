(define-package "kurecolor" "20220816.1419" "color editing goodies"
  '((emacs "28.1")
    (s "1.12"))
  :commit "59e90bbb43f71ec9ba5abf74d5d4fb10f6f10ed1" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
