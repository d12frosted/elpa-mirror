(define-package "macports" "20240808.151" "A porcelain for MacPorts"
  '((emacs "26.1")
    (transient "0.1.0"))
  :commit "b07bdaa7a224f9539aa15cb2dfdb985b2e199e43" :keywords
  '("convenience")
  :url "https://github.com/amake/macports.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
