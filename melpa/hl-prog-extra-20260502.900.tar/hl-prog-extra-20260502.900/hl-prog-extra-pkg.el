;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-prog-extra" "20260502.900"
  "Customizable highlighting for source-code."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra"
  :commit "2eac9eb5a428b23f87cfa1373f5f8fd634a72e48"
  :revdesc "2eac9eb5a428"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
