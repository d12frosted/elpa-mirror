;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20251209.1510"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "a60ac6330b0f657be523c74cd2aaf7bb2be6673b"
  :revdesc "a60ac6330b0f"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
