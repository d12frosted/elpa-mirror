(define-package "git-cliff" "20231013.1036" "Generate and update changelog using git-cliff"
  '((emacs "27.1")
    (transient "0.4.3"))
  :commit "aa5f8709e10c5864e3408489a34fafd20874063c" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/liuyinz/git-cliff.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
