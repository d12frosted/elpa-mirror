;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-vterm" "20251229.335"
  "A mode for Julia REPL using vterm."
  '((emacs "25.1")
    (vterm "0.0.1"))
  :url "https://github.com/shg/julia-vterm.el"
  :commit "1cf2958448df40ca3508964d0d1a78cf8be2453f"
  :revdesc "1cf2958448df"
  :keywords '("languages" "julia"))
