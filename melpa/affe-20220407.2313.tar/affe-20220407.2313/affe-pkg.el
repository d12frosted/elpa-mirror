(define-package "affe" "20220407.2313" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.16"))
  :commit "cc029d7510f6a569f1e61cd1d809e04a163360f6" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
