(define-package "affe" "20220407.2313" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.16"))
  :commit "5dd63fd156577aa7e9a3a631e2f48444565f463e" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
