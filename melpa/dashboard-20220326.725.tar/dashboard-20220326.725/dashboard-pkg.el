(define-package "dashboard" "20220326.725" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "1d3fce6e8e8605f770f2b23184b055029128c477" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
