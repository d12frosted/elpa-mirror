(define-package "flymake-languagetool" "20240302.242" "Flymake support for LanguageTool"
  '((emacs "27.1"))
  :commit "55ceb6d0895a71fea6c8c82ac3155d57d9b54815" :keywords
  '("convenience" "grammar" "check")
  :url "https://github.com/emacs-languagetool/flymake-languagetool")
;; Local Variables:
;; no-byte-compile: t
;; End:
