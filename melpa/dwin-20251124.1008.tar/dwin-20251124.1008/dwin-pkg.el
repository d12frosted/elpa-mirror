;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwin" "20251124.1008"
  "Navigate and arrange desktop windows."
  '((emacs "30.2"))
  :url "https://github.com/lsth/dwin"
  :commit "960cc46d65cf3301d8d452cad917dad995b87bb0"
  :revdesc "960cc46d65cf"
  :keywords '("frames" "processes" "convenience")
  :authors '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de"))
  :maintainers '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de")))
