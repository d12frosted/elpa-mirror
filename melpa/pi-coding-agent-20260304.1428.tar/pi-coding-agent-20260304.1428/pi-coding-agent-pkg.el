;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260304.1428"
  "Emacs frontend for pi coding agent."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "fd23d1a5a035d9734b3f7cb23b2d7584aa87f01b"
  :revdesc "fd23d1a5a035"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
