(define-package "nexus" "20210903.1743" "REST Client for Nexus Maven Repository servers" 'nil :commit "9603fd3d8ef34d4b3dcad3292c4ac743500d4946" :authors
  '(("Juergen Hoetzel" . "juergen@archlinux.org"))
  :maintainer
  '("Juergen Hoetzel" . "juergen@archlinux.org")
  :keywords
  '("comm"))
;; Local Variables:
;; no-byte-compile: t
;; End:
