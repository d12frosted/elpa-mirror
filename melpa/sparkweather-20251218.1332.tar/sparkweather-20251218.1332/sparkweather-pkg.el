;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sparkweather" "20251218.1332"
  "Weather forecasts with sparklines."
  '((emacs "29.1"))
  :url "https://github.com/aglet/sparkweather"
  :commit "7564acd78ab48aa8f2195cf5669e9bde62795acc"
  :revdesc "7564acd78ab4"
  :keywords '("convenience" "weather")
  :authors '(("Robin Stephenson" . "robin@aglet.net"))
  :maintainers '(("Robin Stephenson" . "robin@aglet.net")))
