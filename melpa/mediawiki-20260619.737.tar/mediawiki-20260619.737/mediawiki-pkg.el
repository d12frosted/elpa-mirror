;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20260619.737"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "8002f2fea253b5c2f601325c5b4968e568a3aa2a"
  :revdesc "8002f2fea253"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
