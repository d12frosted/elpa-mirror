(define-package "dwim-shell-command" "20220727.708" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "412bde80ed2f636d1f6c599786d21d4a3f68287b" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
