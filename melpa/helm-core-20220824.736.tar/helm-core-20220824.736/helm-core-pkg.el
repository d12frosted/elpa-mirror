(define-package "helm-core" "20220824.736" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "b778e722bd3613792661da527f16f99cfde23794" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
