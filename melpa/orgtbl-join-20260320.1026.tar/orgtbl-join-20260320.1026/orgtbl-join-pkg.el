;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260320.1026"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "250935aaf41793f855e42bc86896ecf5b7bdd694"
  :revdesc "250935aaf417"
  :keywords '("data" "extensions"))
