;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "one-time-pad-encrypt" "20160329.1513"
  "One time pad encryption within file."
  ()
  :url "https://github.com/garvinguan/emacs-one-time-pad/"
  :commit "87cc1f124024ce3d277299ca0ac703f182937d9f"
  :revdesc "87cc1f124024"
  :keywords '("convenience")
  :authors '(("Garvin Guan" . "garvin.guan@gmail.com"))
  :maintainers '(("Garvin Guan" . "garvin.guan@gmail.com")))
