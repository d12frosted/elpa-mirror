(define-package "org-ref" "20211209.1428" "citations, cross-references and bibliographies in org-mode"
  '((dash "0")
    (s "0")
    (f "0")
    (htmlize "0")
    (hydra "0")
    (avy "0")
    (parsebib "0")
    (bibtex-completion "0")
    (citeproc "0"))
  :commit "1d58fd057d5212173453377dbbe96530a0fa5e58" :authors
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainer
  '("John Kitchin" . "jkitchin@andrew.cmu.edu")
  :keywords
  '("org-mode" "cite" "ref" "label")
  :url "https://github.com/jkitchin/org-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
