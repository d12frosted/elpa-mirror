;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241027.929"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "5b5b55e6238d2e79c836889e1ab02ae698475ad4"
  :revdesc "5b5b55e6238d"
  :keywords '("convenience" "modal-editing"))
