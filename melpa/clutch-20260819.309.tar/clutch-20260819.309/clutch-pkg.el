;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260819.309"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "833fcb0709959281a713da0d262a2e7d70640cff"
  :revdesc "833fcb070995"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
