(define-package "apheleia" "20231017.2020" "Reformat buffer stably"
  '((emacs "27"))
  :commit "51b8a796b666c6ec7f961e5cb2e05c6aa60475f6" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
