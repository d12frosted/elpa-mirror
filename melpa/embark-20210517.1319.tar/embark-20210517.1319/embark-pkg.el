(define-package "embark" "20210517.1319" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "0086413ef295025bde774157763e00746ee8fbf6" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
