;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verdict" "20260413.752"
  "Generic test runner with treemacs results UI."
  '((emacs    "29.1")
    (treemacs "3.0")
    (dash     "2.0"))
  :url "https://github.com/tjarvstrand/verdict.el"
  :commit "be86a87c8098ca01c9bc8fce54a94f969bbc5762"
  :revdesc "be86a87c8098"
  :keywords '("tools" "processes")
  :authors '(("Thomas Järvstrand" . "https://github.com/tjarvstrand"))
  :maintainers '(("Thomas Järvstrand" . "https://github.com/tjarvstrand")))
