;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yara-mode" "20260609.52"
  "Major mode for editing yara rule file."
  '((emacs "24"))
  :url "not distributed yet"
  :commit "b3b78516a879dd77a92aa9f31d4d0ce0549e49e4"
  :revdesc "b3b78516a879"
  :keywords '("yara")
  :authors '((nil . "binjo.cn@gmail.com"))
  :maintainers '((nil . "binjo.cn@gmail.com")))
