;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250412.537"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "9349d90ffbb9cc067ae1553485f7391199c5ca74"
  :revdesc "9349d90ffbb9"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
