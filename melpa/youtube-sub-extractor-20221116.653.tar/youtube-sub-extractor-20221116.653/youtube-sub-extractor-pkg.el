;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youtube-sub-extractor" "20221116.653"
  "Extract YouTube video subtitles."
  '((emacs "27.1"))
  :url "https://github.com/agzam/youtube-sub-extractor.el"
  :commit "d69f732299fdf256504e15767c1d7e5de771220e"
  :revdesc "d69f732299fd"
  :keywords '("convenience" "multimedia")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
