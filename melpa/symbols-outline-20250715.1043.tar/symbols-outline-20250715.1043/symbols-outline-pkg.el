;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symbols-outline" "20250715.1043"
  "Display symbols (functions, variables, etc) in outline view."
  '((emacs "27.1"))
  :url "https://github.com/liushihao456/symbols-outline.el"
  :commit "63370b9dbf7ed042ddbf7b270a1a6a7e7e950901"
  :revdesc "63370b9dbf7e"
  :keywords '("outlines"))
