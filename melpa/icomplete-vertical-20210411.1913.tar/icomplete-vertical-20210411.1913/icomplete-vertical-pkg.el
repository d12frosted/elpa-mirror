(define-package "icomplete-vertical" "20210411.1913" "Display icomplete candidates vertically"
  '((emacs "26.1"))
  :commit "a258ff1033dd3d3cb894a039ac13ff3a85b96f57" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
