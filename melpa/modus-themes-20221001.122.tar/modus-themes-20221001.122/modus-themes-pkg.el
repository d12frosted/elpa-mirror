(define-package "modus-themes" "20221001.122" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "c65ea67673c501066b7ae260bddd8c1af1cafbbf" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
