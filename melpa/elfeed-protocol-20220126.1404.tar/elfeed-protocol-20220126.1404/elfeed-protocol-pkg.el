(define-package "elfeed-protocol" "20220126.1404" "Provide fever/newsblur/owncloud/ttrss protocols for elfeed"
  '((emacs "24.4")
    (elfeed "2.1.1")
    (cl-lib "0.5"))
  :commit "d2e22f5506bc75dbf4ca42ac87257fd1b259dd66" :authors
  '(("Xu Fasheng <fasheng[AT]fasheng.info>"))
  :maintainer
  '("Xu Fasheng <fasheng[AT]fasheng.info>")
  :keywords
  '("news")
  :url "https://github.com/fasheng/elfeed-protocol")
;; Local Variables:
;; no-byte-compile: t
;; End:
