(define-package "for" "20220905.1622" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "575e5878828a651f0cf1f2760a2240fa20696c0e" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
