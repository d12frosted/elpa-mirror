(define-package "modus-themes" "20220421.704" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "173c6685acc3040d298bc96494116bbab467b73f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
