(define-package "cycle-at-point" "20221015.435" "Cycle (rotate) the thing under the cursor"
  '((emacs "28.1")
    (recomplete "0.2"))
  :commit "c0437fb6dc15e4384fbd826375989616e8768a6f" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-cycle-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
