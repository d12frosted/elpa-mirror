;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260104.143"
  "[No description available]."
  ()
  :url "https://github.com/QiangF/imbot"
  :commit "6438c55d50283f869a91cd38f28c32cd1fc4fb21"
  :revdesc "6438c55d5028")
