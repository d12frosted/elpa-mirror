(define-package "flycheck-hledger" "20230626.1939" "Flycheck module to check hledger journals"
  '((emacs "27.1")
    (flycheck "31"))
  :commit "87ed9d4ce448f84f10a5348d8d89d9467ee720ff" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://github.com/DamienCassou/flycheck-hledger/")
;; Local Variables:
;; no-byte-compile: t
;; End:
