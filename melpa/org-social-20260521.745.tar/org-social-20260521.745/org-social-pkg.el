;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20260521.745"
  "An Org-social client for Emacs."
  '((emacs            "30.1")
    (org              "9.0")
    (request          "0.3.0")
    (seq              "2.20")
    (emojify          "1.2")
    (async-http-queue "0.1"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "69cd465c62e2a478faf3f9f8e811efa24a28ad75"
  :revdesc "69cd465c62e2"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
