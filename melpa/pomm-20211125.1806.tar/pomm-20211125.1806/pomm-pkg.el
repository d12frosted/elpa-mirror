(define-package "pomm" "20211125.1806" "Yet another Pomodoro timer implementation"
  '((emacs "27.1")
    (alert "1.2")
    (seq "2.22")
    (transient "0.2.0"))
  :commit "2b58c3cad0106299d98e4a12de4f78dbd96fe67b" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/pomm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
