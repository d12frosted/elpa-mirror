(define-package "demap" "20220303.333" "Detachable minimap package"
  '((emacs "24.4")
    (dash "2.18.0"))
  :commit "9987f4b5f921c862d548c973111182f3bd34f29c" :authors
  '(("Sawyer Gardner <https://gitlab.com/sawyerjgardner>"))
  :maintainer
  '("Sawyer Gardner <https://gitlab.com/sawyerjgardner>")
  :keywords
  '("lisp" "tools" "convenience")
  :url "https://gitlab.com/sawyerjgardner/demap.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
