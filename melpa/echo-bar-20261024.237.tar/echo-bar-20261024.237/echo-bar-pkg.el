;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "echo-bar" "20261024.237"
  "Turn the echo area into a custom status bar."
  ()
  :url "https://github.com/qaiviq/echo-bar.el"
  :commit "458256176583f8f6c9089eb59603267e8c0e5f4d"
  :revdesc "458256176583"
  :keywords '("convenience" "tools")
  :authors '(("Adam Tillou" . "qaiviq@gmail.com"))
  :maintainers '(("Adam Tillou" . "qaiviq@gmail.com")))
