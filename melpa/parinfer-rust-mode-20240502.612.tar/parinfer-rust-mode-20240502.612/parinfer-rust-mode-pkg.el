(define-package "parinfer-rust-mode" "20240502.612" "An interface for the parinfer-rust library"
  '((emacs "26.1"))
  :commit "ef99d4229add1608e81453ef99acf1c844f017fd" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
