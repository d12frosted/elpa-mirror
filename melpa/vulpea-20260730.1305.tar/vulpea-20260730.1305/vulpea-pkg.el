;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260730.1305"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "cb844caf7194092c590e4c35b86436e94775e81d"
  :revdesc "cb844caf7194"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
