;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241228.1651"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.76.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "ec58fa006bb9f45d262607cc08f45af341fb9a88"
  :revdesc "ec58fa006bb9")
