(define-package "dall-e-shell" "20231111.2324" "Interaction mode for DALL-E"
  '((emacs "27.1")
    (shell-maker "0.43.1"))
  :commit "03f8edabb95c6ffc64050d79fdb3091532711b59" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
