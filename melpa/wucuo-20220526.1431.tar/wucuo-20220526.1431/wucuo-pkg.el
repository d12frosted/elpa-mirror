(define-package "wucuo" "20220526.1431" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "412cab0c4a9ce987c1b109b6cdd3de2f7b9bd6d6" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
