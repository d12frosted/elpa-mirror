(define-package "jinx" "20230413.1136" "Enchanted Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "37474c6a2a785674ddc8f13f5428d66f37612ede" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "wp")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
