;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20251220.1407"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "e18cdcb5b2f326ee606ff8be4c427d00c66f316b"
  :revdesc "e18cdcb5b2f3"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
