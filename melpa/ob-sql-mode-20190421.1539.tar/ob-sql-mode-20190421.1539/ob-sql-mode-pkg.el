;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-sql-mode" "20190421.1539"
  "SQL code blocks evaluated by sql-mode."
  '((emacs "24.4"))
  :url "https://github.com/nikclayton/ob-sql-mode"
  :commit "b31a016585324ad91f1742ff6205bcb76f3ece6e"
  :revdesc "b31a01658532"
  :keywords '("languages" "org" "org-babel" "sql")
  :authors '((nil . "NikClaytonnik@google.com"))
  :maintainers '((nil . "NikClaytonnik@google.com")))
