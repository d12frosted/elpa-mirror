;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241228.1155"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "10d7203a2692e315d31119986a18750ee5eb6c48"
  :revdesc "10d7203a2692"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
