;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260411.917"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "efe1ccc68b213ad05d503b6794affeae4e8d6c2c"
  :revdesc "efe1ccc68b21"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
