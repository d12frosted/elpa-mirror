;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260216.2231"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "bc76b84e96c9812afb739d3fe43c66cf7342eaed"
  :revdesc "bc76b84e96c9"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
