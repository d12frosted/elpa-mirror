;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241204.1444"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.74.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "448793544028cfbe6a0c8e55cd0208e8297ce8fc"
  :revdesc "448793544028")
