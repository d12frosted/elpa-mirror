;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nu-ts-mode" "20260721.1414"
  "Major mode for Nushell scripts, powered by treesitter."
  '((emacs "29.1"))
  :url "https://github.com/ItsOleks/nu-ts-mode"
  :commit "088c09c86bb1cfb04329828922b893bcfff308bd"
  :revdesc "088c09c86bb1"
  :keywords '("nushell" "nu" "languages" "tree-sitter")
  :authors '(("Oleksandr Makhmudov" . "oleksandr.makhmudov@proton.me"))
  :maintainers '(("Oleksandr Makhmudov" . "oleksandr.makhmudov@proton.me")))
