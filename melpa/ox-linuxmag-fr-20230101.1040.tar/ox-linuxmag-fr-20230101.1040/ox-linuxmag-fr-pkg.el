(define-package "ox-linuxmag-fr" "20230101.1040" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "9deedb17b3a2d9bc7dd857a639da382f04c5514c" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
