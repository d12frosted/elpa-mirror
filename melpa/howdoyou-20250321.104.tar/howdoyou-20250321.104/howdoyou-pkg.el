;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "howdoyou" "20250321.104"
  "A stackoverflow and its sisters' sites reader."
  '((emacs   "25.1")
    (promise "1.1")
    (request "0.3.3")
    (org     "9.2"))
  :url "https://github.com/thanhvg/howdoyou/"
  :commit "ebecc51c4c1db598d2303d001553ee74fc8fc49a"
  :revdesc "ebecc51c4c1d"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
