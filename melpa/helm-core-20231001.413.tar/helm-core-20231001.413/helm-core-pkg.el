(define-package "helm-core" "20231001.413" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "9a14bb46700f88b61c72de93c06ba0a525ecbf91" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
