;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261004.208"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ae31cf850b3a06178d28e6be72311991ee680ee9"
  :revdesc "ae31cf850b3a")
