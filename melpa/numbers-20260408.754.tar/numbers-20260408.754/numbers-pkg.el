;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "numbers" "20260408.754"
  "Display information and trivia about numbers."
  '((emacs "24"))
  :url "https://github.com/davep/numbers.el"
  :commit "cc9a3d5183f305634e5a5285b1f5e410fe8602c5"
  :revdesc "cc9a3d5183f3"
  :keywords '("games" "trivia" "maths" "numbers")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
