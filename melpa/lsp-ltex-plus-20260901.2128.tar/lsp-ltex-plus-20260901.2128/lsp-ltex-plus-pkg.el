;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "20260901.2128"
  "Grammar and spell checking for LaTeX, Markdown, Org and more."
  '((emacs    "29.1")
    (lsp-mode "10.0.0"))
  :url "https://github.com/ltex-plus/emacs-ltex-plus"
  :commit "77543b26ba95c6e7686a72a78fe55abdd8efe9c4"
  :revdesc "77543b26ba95"
  :keywords '("lsp" "grammar" "spelling" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
