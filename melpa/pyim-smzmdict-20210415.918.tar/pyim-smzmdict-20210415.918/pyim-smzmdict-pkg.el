(define-package "pyim-smzmdict" "20210415.918" "Sanma(triple) Zhengma dict for pyim"
  '((pyim "1.0"))
  :commit "f4129a3c1a4f2e70e7d24225fc10e42cafa17a0b" :authors
  '(("Yue Shi (Zhizhi)"))
  :maintainer
  '("Yuanchen Xie")
  :keywords
  '("convenience" "i18n" "pyim" "chinese" "zhengma")
  :url "https://github.com/p1uxtar/pyim-smzmdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
