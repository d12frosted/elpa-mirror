(define-package "forge" "20230922.1334" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "29.1.4.1")
    (closql "20230407")
    (dash "2.19.1")
    (emacsql "20230409")
    (ghub "20220621")
    (let-alist "1.0.6")
    (magit "20230319")
    (markdown-mode "2.4")
    (seq "2.24")
    (transient "0.4.0")
    (yaml "0.5.2"))
  :commit "f6cede0f7df451b8aa3bf80751a9be1a14823425" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
