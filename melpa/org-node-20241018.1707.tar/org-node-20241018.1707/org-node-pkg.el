;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241018.1707"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "cfd3aa7cadbff4d0a4fa4d74a28252468a9fa4e7"
  :revdesc "cfd3aa7cadbf"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
