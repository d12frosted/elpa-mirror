(define-package "mew" "20230209.1231" "Messaging in the Emacs World" 'nil :commit "2f9143f5865cdbd31701be58093961b41def0edc" :authors
  '(("Kazu Yamamoto" . "Kazu@Mew.org"))
  :maintainer
  '("Kazu Yamamoto" . "Kazu@Mew.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
