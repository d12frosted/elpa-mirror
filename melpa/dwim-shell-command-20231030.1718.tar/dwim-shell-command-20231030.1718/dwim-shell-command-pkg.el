(define-package "dwim-shell-command" "20231030.1718" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "8b90a964f09e69b1c55258e91710b0488e0bf135" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
