(define-package "dwim-shell-command" "20240807.1509" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "38c893a87dc9d458f5fb2cd8bd6a60b58d307cb9" :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
