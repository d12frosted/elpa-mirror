(define-package "org-anki" "20230618.1059" "Synchronize org-mode entries to Anki"
  '((emacs "27.1")
    (request "0.3.2")
    (dash "2.17")
    (promise "1.1"))
  :commit "b9a6ec16696a79c319131b8d683d4caae0be90d6" :authors
  '(("Markus Läll" . "markus.l2ll@gmail.com"))
  :maintainers
  '(("Markus Läll" . "markus.l2ll@gmail.com"))
  :maintainer
  '("Markus Läll" . "markus.l2ll@gmail.com")
  :keywords
  '("outlines" "flashcards" "memory")
  :url "https://github.com/eyeinsky/org-anki")
;; Local Variables:
;; no-byte-compile: t
;; End:
