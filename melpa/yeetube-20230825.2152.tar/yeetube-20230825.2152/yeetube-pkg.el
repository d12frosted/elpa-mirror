(define-package "yeetube" "20230825.2152" "YouTube & Invidious Front End"
  '((emacs "27.2"))
  :commit "11c85c1daf0684ff074fd1decdf5eda3b7caf309" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
