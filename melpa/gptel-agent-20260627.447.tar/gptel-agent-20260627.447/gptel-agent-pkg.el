;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260627.447"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "37a2220b558137a8abce5be64471b3e675f0b2c8"
  :revdesc "37a2220b5581"
  :keywords '("comm"))
