;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20241205.1608"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "f31d4f1a3bc07ef029c76b267ed1737084211cc7"
  :revdesc "f31d4f1a3bc0"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
