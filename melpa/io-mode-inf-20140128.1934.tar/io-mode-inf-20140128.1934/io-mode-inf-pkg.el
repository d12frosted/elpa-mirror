;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "io-mode-inf" "20140128.1934"
  "Interaction with an Io interpreter."
  ()
  :url "https://github.com/slackorama/io-emacs"
  :commit "6dd2bac3fd87484bb7d97e135b06c29d70b444b6"
  :revdesc "6dd2bac3fd87"
  :keywords '("io" "languages"))
