;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pr-review" "20260509.1433"
  "Review github PR."
  '((emacs         "27.1")
    (magit-section "4.0")
    (magit         "4.0")
    (markdown-mode "2.5")
    (ghub          "5.0"))
  :url "https://github.com/blahgeek/emacs-pr-review"
  :commit "938db766007f3444a2899b2457d9e2f4b4ffbebf"
  :revdesc "938db766007f"
  :keywords '("tools")
  :authors '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainers '(("Yikai Zhao" . "yikai@z1k.dev")))
