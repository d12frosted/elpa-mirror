(define-package "ready-player" "20240728.1218" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "1de5aab8a13de4986154a76945f295b0304cb183" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
