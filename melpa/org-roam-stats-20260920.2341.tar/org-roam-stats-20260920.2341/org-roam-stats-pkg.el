;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-stats" "20260920.2341"
  "Personal Knowledge Management Dashboard."
  '((emacs        "27.1")
    (org-roam     "2.0")
    (simple-httpd "1.6"))
  :url "https://github.com/GerardoCendejas/org-roam-stats"
  :commit "f0ae7641656baaf8d0ed67d34ee71bf3e3a9ce5e"
  :revdesc "f0ae7641656b"
  :keywords '("outlines" "tools")
  :authors '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu"))
  :maintainers '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu")))
