(define-package "kotlin-mode" "20220517.2030" "Major mode for kotlin"
  '((emacs "24.3"))
  :commit "f8b7b3648e230368fc019b63263dff874ac255cd" :authors
  '(("Shodai Yokoyama" . "quantumcars@gmail.com"))
  :maintainer
  '("Shodai Yokoyama" . "quantumcars@gmail.com")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
