(define-package "dtk" "20230516.1745" "access SWORD content via diatheke"
  '((emacs "24.4")
    (cl-lib "0.6.1")
    (dash "2.12.0")
    (seq "1.9")
    (s "1.9"))
  :commit "9d494f8281d5cdf166b91a219a8b9a1558fb51db" :authors
  '(("David Thompson"))
  :maintainers
  '(("David Thompson"))
  :maintainer
  '("David Thompson")
  :keywords
  '("hypermedia")
  :url "https://github.com/dtk01/dtk.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
