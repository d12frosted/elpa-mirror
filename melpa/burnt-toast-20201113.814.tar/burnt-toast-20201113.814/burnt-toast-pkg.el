(define-package "burnt-toast" "20201113.814" "Elisp integration with the BurntToast PowerShell module"
  '((emacs "25.1")
    (dash "2.10")
    (alert "1.2"))
  :commit "e9cf41928b7b502fdfa43718c35a24e503db32e2" :authors
  '(("Sam Cedarbaum" . "scedarbaum@gmail.com"))
  :maintainer
  '("Sam Cedarbaum" . "scedarbaum@gmail.com")
  :keywords
  '("alert" "notifications" "powershell" "comm")
  :url "https://github.com/cedarbaum/burnt-toast.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
