(define-package "burnt-toast" "20201113.814" "Elisp integration with the BurntToast PowerShell module"
  '((emacs "25.1")
    (dash "2.10")
    (alert "1.2"))
  :commit "d4b1fc8f6d32eb69c066775558442dcc84208ba0" :keywords
  ("alert" "notifications" "powershell" "comm")
  :authors
  (("Sam Cedarbaum" . "scedarbaum@gmail.com"))
  :maintainer
  ("Sam Cedarbaum" . "scedarbaum@gmail.com")
  :url "https://github.com/cedarbaum/burnt-toast.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
