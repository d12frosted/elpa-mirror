;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20241204.515"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0")
    (wfnames   "1.2"))
  :url "https://github.com/emacs-helm/helm"
  :commit "52ea8e924fdda0fd5b7a6d37d49f542a90dd58c8"
  :revdesc "52ea8e924fdd"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
