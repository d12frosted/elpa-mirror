;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol" "20260519.1629"
  "Provide fever/newsblur/owncloud/ttrss protocols for elfeed."
  '((emacs  "24.4")
    (elfeed "2.1.1")
    (cl-lib "0.5"))
  :url "https://github.com/fasheng/elfeed-protocol"
  :commit "ce6bc6f3bf8f55acf62143d8130bf1e4139acc7c"
  :revdesc "ce6bc6f3bf8f"
  :keywords '("news")
  :authors '(("Xu Fasheng" . "fasheng[AT]fasheng.info"))
  :maintainers '(("Xu Fasheng" . "fasheng[AT]fasheng.info")))
