(define-package "latex-table-wizard" "20230516.1857" "Magic editing of LaTeX tables"
  '((emacs "27.1")
    (auctex "12.1")
    (transient "0.3.7"))
  :commit "2998be936aa31415051ee2a8d2912424045d966c" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :keywords
  '("convenience")
  :url "https://github.com/enricoflor/latex-table-wizard")
;; Local Variables:
;; no-byte-compile: t
;; End:
