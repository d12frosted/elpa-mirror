(define-package "electric-spacing" "20210418.1134" "Insert operators with surrounding spaces smartly" 'nil :commit "562e1a37908d106523f6c9a05cb06d2997c32bd0" :authors
  '(("William Xu" . "william.xwl@gmail.com"))
  :maintainer
  '("William Xu" . "william.xwl@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
