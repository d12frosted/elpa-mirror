;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20261102.334"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "75b73d96b91832399182893fd13265d7d695cf67"
  :revdesc "75b73d96b918"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
