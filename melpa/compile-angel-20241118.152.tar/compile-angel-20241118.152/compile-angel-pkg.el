;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20241118.152"
  "Compile Emacs Lisp libraries automatically."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "8534b325536cd0ff52a831dfe150317ff2287498"
  :revdesc "8534b325536c"
  :keywords '("convenience"))
