(define-package "buttercup" "20221227.1857" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "21ded874f7af380b593776eac06a87cf7f7ae439" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
