(define-package "cl-format" "20210824.2016" "CL format routine." 'nil :commit "7ecf37e2d80307a72800e843d9669ec89b3094c4" :authors
  '(("Andreas Politz" . "politza@fh-trier.de"))
  :maintainer
  '("Andreas Politz" . "politza@fh-trier.de")
  :keywords
  '("extensions"))
;; Local Variables:
;; no-byte-compile: t
;; End:
