;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260607.1633"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "439cb86d1c6938740ff9fc1882b1460c8029892e"
  :revdesc "439cb86d1c69"
  :keywords '("languages"))
