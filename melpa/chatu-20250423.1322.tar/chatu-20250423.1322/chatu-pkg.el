;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatu" "20250423.1322"
  "Convert and insert any images to org-mode or markdown buffer."
  '((org           "9.6.6")
    (emacs         "29.1")
    (plantuml-mode "1.2.9"))
  :url "https://github.com/kimim/chatu"
  :commit "352bf3d67c80e0a3681cf3dce8a0eddb8a795d5d"
  :revdesc "352bf3d67c80"
  :keywords '("multimedia" "convenience")
  :authors '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers '(("Kimi Ma" . "kimi.im@outlook.com")))
