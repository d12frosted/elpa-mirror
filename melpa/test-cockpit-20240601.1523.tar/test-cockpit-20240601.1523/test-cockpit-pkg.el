(define-package "test-cockpit" "20240601.1523" "A command center to run tests of a software project"
  '((emacs "28.1")
    (projectile "2.7")
    (toml "20230411.1449"))
  :commit "26fe59347aac1d6cfac9372d6d234d76314f3511" :authors
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainer
  '("Johannes Mueller" . "github@johannes-mueller.org")
  :url "https://github.com/johannes-mueller/test-cockpit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
