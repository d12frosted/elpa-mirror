;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260309.1859"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "d87e01df6d766060cdd372d10f6b13d8d0c18859"
  :revdesc "d87e01df6d76"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
