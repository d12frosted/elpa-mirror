(define-package "modus-themes" "20221016.1516" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "59da1b35112e1becb6e2c3912a417d28a22ac8ce" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
