;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-call-tree" "20260321.1821"
  "Analyze source code based on font-lock text-properties."
  '((emacs    "24.3")
    (anaphora "1.0.0"))
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el"
  :commit "e25817d4ee692ec32b637dfc5c0989aa7ada546d"
  :revdesc "e25817d4ee69"
  :keywords '("programming")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
