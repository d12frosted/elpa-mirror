;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-command-redo" "20260504.2116"
  "Repeat commands with automatic undo."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-with-command-redo"
  :commit "d1c4be4bb3fb22dff8fcfb562912760be3a685e8"
  :revdesc "d1c4be4bb3fb"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
