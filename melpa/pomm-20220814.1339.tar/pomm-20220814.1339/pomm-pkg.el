(define-package "pomm" "20220814.1339" "Pomodoro and Third Time timers"
  '((emacs "27.1")
    (alert "1.2")
    (seq "2.22")
    (transient "0.3.0"))
  :commit "0942131ac3f2d20cc1004eecdb99ec0db1271c31" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/pomm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
