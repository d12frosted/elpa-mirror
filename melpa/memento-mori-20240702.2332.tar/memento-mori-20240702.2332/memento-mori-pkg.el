;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "memento-mori" "20240702.2332"
  "Reminder of our mortality."
  '((emacs "24.4"))
  :url "https://github.com/gvol/emacs-memento-mori"
  :commit "c53707871aa5aeb551c6b9c02bdca6f477bc9c5b"
  :revdesc "c53707871aa5"
  :keywords '("help")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Ivan Andrus" . "darthandrus@gmail.com")))
