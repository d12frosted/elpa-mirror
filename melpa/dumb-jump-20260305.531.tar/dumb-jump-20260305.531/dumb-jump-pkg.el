;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260305.531"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "26.1"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "24eaad87ca583c76337e53fa29b98c80968f53e8"
  :revdesc "24eaad87ca58"
  :keywords '("programming"))
