;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-charinfo" "20170810.1231"
  "A helm source for character information."
  '((emacs  "24")
    (helm   "1.7.0")
    (cl-lib "0.5"))
  :url "https://github.com/cwittern/helm-charinfo"
  :commit "91798a49dc115342a7e01e48b264e9a0bf5ea414"
  :revdesc "91798a49dc11"
  :keywords '("convenience")
  :authors '(("Christian Wittern" . "cwittern@gmail.com"))
  :maintainers '(("Christian Wittern" . "cwittern@gmail.com")))
