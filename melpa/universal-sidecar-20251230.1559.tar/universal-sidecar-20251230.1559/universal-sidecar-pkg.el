;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "universal-sidecar" "20251230.1559"
  "A universal sidecar buffer."
  '((emacs         "26.1")
    (magit-section "3.0.0"))
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar"
  :commit "fa985774c0cf67d3beaf2fd650a2d104dd760cf4"
  :revdesc "fa985774c0cf"
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
