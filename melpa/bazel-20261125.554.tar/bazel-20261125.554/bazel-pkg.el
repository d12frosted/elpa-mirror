;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261125.554"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "da396d291a02a498a0e8acbc88de42083d509965"
  :revdesc "da396d291a02"
  :keywords '("build tools" "languages"))
