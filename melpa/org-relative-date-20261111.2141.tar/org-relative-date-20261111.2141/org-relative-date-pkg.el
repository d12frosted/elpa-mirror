;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-relative-date" "20261111.2141"
  "Live relative-date overlays on org timestamps."
  '((emacs "27.1")
    (org   "9.1"))
  :url "https://github.com/RobertPlant/org-relative-date"
  :commit "7a3647eeadad4bf55e53626356ddfa8101d84bc3"
  :revdesc "7a3647eeadad"
  :keywords '("calendar" "org" "convenience")
  :authors '(("Rob Plant" . "rob@robertplant.io"))
  :maintainers '(("Rob Plant" . "rob@robertplant.io")))
