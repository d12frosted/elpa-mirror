;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260327.1037"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "16b8e99eec7f4cf6dd645faad85e7d9a7069d89e"
  :revdesc "16b8e99eec7f"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
