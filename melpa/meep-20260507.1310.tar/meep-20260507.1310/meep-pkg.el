;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260507.1310"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "01441807a29fd902a9f1c08167781d85cb330a6b"
  :revdesc "01441807a29f"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
