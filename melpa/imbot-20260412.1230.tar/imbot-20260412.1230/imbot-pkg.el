;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260412.1230"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "8ebad97c649df5a616e9691af68cb11a87b8c086"
  :revdesc "8ebad97c649d"
  :keywords '("convenience" "input method" "dbus"))
