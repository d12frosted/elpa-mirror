;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uml-mode" "20200129.1147"
  "Minor mode for ascii uml sequence diagrams."
  '((emacs "24.4")
    (seq   "0"))
  :url "https://github.com/ianxm/emacs-uml"
  :commit "0ef88c74b48b5400d83ab93e3e089bbe45538fd7"
  :revdesc "0ef88c74b48b"
  :keywords '("docs")
  :authors '(("Ian Martins" . "ianxm@jhu.edu"))
  :maintainers '(("Ian Martins" . "ianxm@jhu.edu")))
