(define-package "consult-ls-git" "20230831.826" "Consult integration for git"
  '((emacs "27.1")
    (consult "0.16"))
  :commit "081bd9f4f8ecdafc11dab6b5379deea81654b00a" :authors
  '(("Robin Joy"))
  :maintainers
  '(("Robin Joy"))
  :maintainer
  '("Robin Joy")
  :keywords
  '("convenience")
  :url "https://github.com/rcj/consult-ls-git")
;; Local Variables:
;; no-byte-compile: t
;; End:
