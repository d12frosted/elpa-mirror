;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "renpy" "20250707.1816"
  "Major mode for editing Ren'Py files."
  '((emacs "27.1"))
  :url "https://github.com/Reagankm/renpy-mode"
  :commit "6755d59b5153b61829a2ccf266d89c5b69bc0c21"
  :revdesc "6755d59b5153"
  :keywords '("languages")
  :authors '(("Dave Love" . "fx@gnu.org")
             ("PyTom" . "pytom@bishoujo.us"))
  :maintainers '(("Reagan Middlebrook" . "reagankm@gmail.com")))
