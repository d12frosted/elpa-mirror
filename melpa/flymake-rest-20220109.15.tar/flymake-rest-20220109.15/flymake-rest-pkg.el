(define-package "flymake-rest" "20220109.15" "Core features for flymake-rest"
  '((emacs "28.1")
    (let-alist "1.0")
    (flymake "1.2.1"))
  :commit "fd9928801cf601a221cf45508e254f405d19c819" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("language" "tools")
  :url "https://github.com/mohkale/flymake-rest")
;; Local Variables:
;; no-byte-compile: t
;; End:
