;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uwu-theme" "20260701.318"
  "An awesome dark color scheme."
  '((emacs "24.1"))
  :url "https://github.com/kborling/uwu-theme"
  :commit "4f92eedc453ca5cb1d1cac486f57a1f828ed55ef"
  :revdesc "4f92eedc453c"
  :keywords '("custom themes" "dark" "faces"))
