;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gildas-mode" "20181022.649"
  "Major mode for Gildas."
  '((polymode "0.1.5")
    (emacs    "25"))
  :url "https://github.com/smaret/gildas-mode"
  :commit "d0c9e997e2aa0bcd9b8b7db082d69100448cb1b2"
  :revdesc "d0c9e997e2aa"
  :keywords '("languages" "gildas")
  :authors '(("Sébastien Maret" . "sebastien.maret@icloud.com"))
  :maintainers '(("Sébastien Maret" . "sebastien.maret@icloud.com")))
