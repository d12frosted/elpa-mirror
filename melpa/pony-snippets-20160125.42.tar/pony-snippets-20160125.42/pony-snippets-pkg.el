(define-package "pony-snippets" "20160125.42" "Yasnippets for Pony"
  '((yasnippet "0.8.0"))
  :commit "56018b23a11563c6766ed706024b22aa5a4556b4" :keywords
  '("snippets" "pony")
  :url "https://github.com/seantallen/pony-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
