(define-package "spdx" "20230306.121" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "510679fd72ace18c5fc0c7d5f25c1fe67ba14c6f" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
