;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260331.2145"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "0e3cbb6fbd17be6bf19a6db6b9a9dac9e0f592c3"
  :revdesc "0e3cbb6fbd17"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
