(define-package "cerbere" "20140417.1113" "Unit testing in Emacs for several programming languages"
  '((s "1.9.0")
    (f "0.16.0")
    (go-mode "20140409")
    (pkg-info "0.5"))
  :commit "11de1e7ec5126083ae697f5a9993facdb9895f9d" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("python" "go" "php" "tests" "tdd")
  :url "https://github.com/nlamirault/cerbere")
;; Local Variables:
;; no-byte-compile: t
;; End:
