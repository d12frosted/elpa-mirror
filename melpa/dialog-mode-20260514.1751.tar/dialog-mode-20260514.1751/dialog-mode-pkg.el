;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260514.1751"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "dccebae691b641b321d77cb7813627699c066aa1"
  :revdesc "dccebae691b6"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
