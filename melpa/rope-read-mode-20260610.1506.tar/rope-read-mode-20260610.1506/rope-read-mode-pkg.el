;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rope-read-mode" "20260610.1506"
  "Rearrange lines to read text smoothly."
  '((emacs "24"))
  :url "https://gitlab.com/marcowahl/rope-read-mode"
  :commit "01403ba93c78518c07d749a4347a8deb5e809dc7"
  :revdesc "01403ba93c78"
  :keywords '("reading" "convenience" "chill")
  :authors '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainers '(("Marco Wahl" . "marcowahlsoft@gmail.com")))
