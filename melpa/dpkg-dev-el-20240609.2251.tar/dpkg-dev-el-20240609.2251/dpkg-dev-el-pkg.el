(define-package "dpkg-dev-el" "20240609.2251" "startup file for the elpa-dpkg-dev-el package"
  '((emacs "27.1")
    (debian-el "37.0"))
  :commit "5500e9c846a4690355b7c6cc6b13b8e2cd247604" :authors
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainer
  '("Peter S Galbraith" . "psg@debian.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
