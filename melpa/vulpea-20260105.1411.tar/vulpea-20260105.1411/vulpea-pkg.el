;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260105.1411"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "d0cdd31002c47b42deec69c2fec661c87b1b4abc"
  :revdesc "d0cdd31002c4"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
