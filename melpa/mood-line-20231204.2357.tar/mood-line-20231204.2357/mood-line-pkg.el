(define-package "mood-line" "20231204.2357" "A minimal mode line inspired by doom-modeline"
  '((emacs "26.1"))
  :commit "ff0a35672e57169bc004ccd8f4a7b6fceec5e93d" :authors
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainers
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainer
  '("Jessie Hildebrandt <jessieh.net>")
  :keywords
  '("mode-line" "faces")
  :url "https://gitlab.com/jessieh/mood-line")
;; Local Variables:
;; no-byte-compile: t
;; End:
