(define-package "soccer" "20211018.1357" "Fixtures, results, table etc for soccer"
  '((emacs "26.1")
    (dash "2.19.1"))
  :commit "7461fbcb5c738ca3d0dfbba0bd6c99517ca940b0" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("games" "soccer" "football")
  :url "https://github.com/md-arif-shaikh/soccer")
;; Local Variables:
;; no-byte-compile: t
;; End:
