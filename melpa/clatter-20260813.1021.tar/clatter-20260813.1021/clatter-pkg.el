;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260813.1021"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "d28abf72e52558027f125f988bf8e8db55405970"
  :revdesc "d28abf72e525"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
