(define-package "elcord" "20230519.9" "Allows you to integrate Rich Presence from Discord"
  '((emacs "25.1"))
  :commit "6ef59349e0cdaccc712235b2e9a328469c9c0e6c" :authors
  '(("heatingdevice")
    ("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com"))
  :maintainers
  '(("heatingdevice"))
  :maintainer
  '("heatingdevice")
  :keywords
  '("games")
  :url "https://github.com/Mstrodl/elcord")
;; Local Variables:
;; no-byte-compile: t
;; End:
