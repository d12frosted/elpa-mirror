(define-package "dwim-shell-command" "20220908.1241" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "9cb67af0bf0f521e1dfc9d9b83e345326992352d" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
