(define-package "mykie" "20150808.2205" "Command multiplexer: Register multiple functions to a keybind"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "91f222b4f2b2b4285b0bc306905eb960826a67ed" :authors
  '(("Yuta Yamada <cokesboy\"at\"gmail.com>"))
  :maintainer
  '("Yuta Yamada <cokesboy\"at\"gmail.com>")
  :keywords
  '("emacs" "configuration" "keybind")
  :url "https://github.com/yuutayamada/mykie-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
