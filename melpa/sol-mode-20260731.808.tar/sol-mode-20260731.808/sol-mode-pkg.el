;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sol-mode" "20260731.808"
  "Major mode for editing Solidity code."
  '((emacs "30.1"))
  :url "https://github.com/nlordell/sol-mode"
  :commit "0d66f4ea4a113520e17ed60ddc237395392402e9"
  :revdesc "0d66f4ea4a11"
  :keywords '("solidity" "languages")
  :authors '(("Nicholas Rodrigues Lordello" . "n@lordello.net"))
  :maintainers '(("Nicholas Rodrigues Lordello" . "n@lordello.net")))
