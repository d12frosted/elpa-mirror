;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-trash" "20220913.1736"
  "System trash for OS X."
  '((emacs "24.1"))
  :url "https://github.com/lunaryorn/osx-trash.el"
  :commit "90f0c99206022fec646206018fcd63d9d2e57325"
  :revdesc "90f0c9920602"
  :keywords '("files" "convenience" "tools" "unix")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
