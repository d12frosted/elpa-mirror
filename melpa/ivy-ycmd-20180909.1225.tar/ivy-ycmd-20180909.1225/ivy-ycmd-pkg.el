;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-ycmd" "20180909.1225"
  "Ivy interface to ycmd."
  '((ycmd  "1.3")
    (emacs "24")
    (ivy   "0.10.0")
    (dash  "2.14.1"))
  :url "https://github.com/abingham/emacs-ivy-ycmd"
  :commit "25bfee8f676e4ecbb645e4f30b47083410a00c58"
  :revdesc "25bfee8f676e"
  :keywords '("tools")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
