(define-package "tok-theme" "20220103.1319" "My theme"
  '((emacs "24.3"))
  :commit "506f2c5aea10815ccb985f72bc6fc11ebb06a7ea" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
