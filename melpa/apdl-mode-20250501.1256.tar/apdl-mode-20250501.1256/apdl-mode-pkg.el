;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apdl-mode" "20250501.1256"
  "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :url "https://github.com/dieter-wilhelm/apdl-mode"
  :commit "4be7dbb252c58c19cd8a8ebf9d736821fa16a98c"
  :revdesc "4be7dbb252c5"
  :keywords '("languages" "convenience" "tools" "ansys" "apdl")
  :authors '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de")))
