(define-package "helm-core" "20210318.1327" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "01592be8dedc2ae7f2b33ae43a38f4916145e0e9")
;; Local Variables:
;; no-byte-compile: t
;; End:
