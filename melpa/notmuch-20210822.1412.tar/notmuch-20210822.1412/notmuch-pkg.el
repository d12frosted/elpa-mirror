(define-package "notmuch" "20210822.1412" "run notmuch within emacs" 'nil :commit "84347ffcad24b48390c622e5a96c31c97c094daa" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
