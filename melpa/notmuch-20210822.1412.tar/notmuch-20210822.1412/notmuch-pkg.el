(define-package "notmuch" "20210822.1412" "run notmuch within emacs" 'nil :commit "d25dafb4c2f26d9f7ae67ca603181238514e6e97" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
