;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20261115.906"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "788d22a8a492a22661981cf6bf1bf8ba8774b254"
  :revdesc "788d22a8a492"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
