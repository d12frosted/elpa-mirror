;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250529.343"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "e87d7c2bd1380d302f4452b75c6c705a7fdcbcd8"
  :revdesc "e87d7c2bd138"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
