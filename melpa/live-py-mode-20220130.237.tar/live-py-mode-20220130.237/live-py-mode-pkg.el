(define-package "live-py-mode" "20220130.237" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "d6efd5dbecd873b65da5c55270cfa8fe09ff6f07" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
