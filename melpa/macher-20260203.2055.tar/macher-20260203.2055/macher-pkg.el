;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20260203.2055"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.3"))
  :url "https://github.com/kmontag/macher"
  :commit "16672b88967c3ea452d8670285e2ab7fc705ce17"
  :revdesc "16672b88967c"
  :keywords '("convenience" "gptel" "llm"))
