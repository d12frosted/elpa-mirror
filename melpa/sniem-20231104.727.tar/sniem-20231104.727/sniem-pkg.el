(define-package "sniem" "20231104.727" "Hands-eased united editing method"
  '((emacs "27.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "7d4bc22666b2a6d4c789dd6a13fedb35cea6bfc3" :authors
  '(("SpringHan"))
  :maintainers
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
