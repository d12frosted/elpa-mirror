(define-package "corfu" "20231107.2027" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "362d1f61dfb4ab30c28db55745ace89fdb00e535" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
