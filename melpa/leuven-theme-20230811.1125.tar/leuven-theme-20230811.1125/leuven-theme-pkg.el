(define-package "leuven-theme" "20230811.1125" "Elegant Emacs color theme for a white background" 'nil :commit "4665a2dfc15510451cd9dd5a5086935045f1c4f8" :authors
  '(("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>"))
  :maintainers
  '(("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>"))
  :maintainer
  '("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>")
  :keywords
  '("color" "theme")
  :url "https://github.com/fniessen/emacs-leuven-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
