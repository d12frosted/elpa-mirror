(define-package "lsp-dart" "20210929.1620" "Dart support lsp-mode"
  '((emacs "26.1")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (dart-mode "1.0.5"))
  :commit "38906bb3e69c16b3e8d328fd6ae764f1d4369b9f" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
