;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dag-draw" "20251117.1330"
  "Draw directed graphs using the GKNV algorithm."
  '((emacs "26.1")
    (dash  "2.19.1")
    (ht    "2.3"))
  :url "https://codeberg.org/trevoke/dag-draw.el"
  :commit "665d98db9cc415ba5694cd06dccdd448c17daedf"
  :revdesc "665d98db9cc4"
  :keywords '("tools" "extensions"))
