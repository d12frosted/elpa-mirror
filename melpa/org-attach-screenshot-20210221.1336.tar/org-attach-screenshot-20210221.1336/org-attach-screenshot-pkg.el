;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-attach-screenshot" "20210221.1336"
  "Screenshots integrated with org attachment dirs."
  '((emacs "24.3"))
  :url "https://github.com/dfeich/org-screenshot"
  :commit "14240909b64605fa966955a14c6045df0f402367"
  :revdesc "14240909b646"
  :keywords '("org" "multimedia")
  :authors '(("Derek Feichtinger" . "derek.feichtinger@psi.ch"))
  :maintainers '(("Derek Feichtinger" . "derek.feichtinger@psi.ch")))
