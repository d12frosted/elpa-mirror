;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yequake" "20200219.2323"
  "Drop-down frames, like Yakuake."
  '((emacs "25.2")
    (dash  "2.14.1"))
  :url "https://github.com/alphapapa/yequake"
  :commit "d18166e597414350117d0b82a29e509fc53c636d"
  :revdesc "d18166e59741"
  :keywords '("convenience" "window-system" "frames")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
