;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-jdb" "20260725.1431"
  "Realgud front-end to Java's jdb debugger\"."
  '((realgud       "1.5.0")
    (load-relative "1.3.1")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud-jdb"
  :commit "af014859343e77f5eea408398314a066db92e253"
  :revdesc "af014859343e"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
