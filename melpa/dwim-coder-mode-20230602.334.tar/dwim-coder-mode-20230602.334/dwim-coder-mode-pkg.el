(define-package "dwim-coder-mode" "20230602.334" "DWIM keybindings for programming modes"
  '((emacs "29"))
  :commit "c8c5b3981bd44bee7ab59eb0a686c8841975a2c3" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
