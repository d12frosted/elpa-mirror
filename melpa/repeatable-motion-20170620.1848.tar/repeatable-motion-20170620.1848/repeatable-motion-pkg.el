(define-package "repeatable-motion" "20170620.1848" "Make repeatable versions of motions"
  '((emacs "24"))
  :commit "77aa35b27c8a76dc8deef87c9f71ef7e6fd289ee" :authors
  '(("William Hatch" . "willghatch@gmail.com"))
  :maintainer
  '("William Hatch" . "willghatch@gmail.com")
  :keywords
  '("motion" "repeatable")
  :url "https://github.com/willghatch/emacs-repeatable-motion")
;; Local Variables:
;; no-byte-compile: t
;; End:
