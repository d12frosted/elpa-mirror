(define-package "loopy" "20231008.19" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22")
    (compat "29.1.3"))
  :commit "5771ef573b50aa3541c3919d08594ad6918026c3" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
