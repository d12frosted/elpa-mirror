(define-package "for" "20221218.1023" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "3556d3693288a552a0962ee01ad7ec71caeb0dc8" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
