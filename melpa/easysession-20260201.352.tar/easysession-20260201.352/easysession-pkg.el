;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260201.352"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "991753df2e6e4d426cb6297de650e792ab832fbe"
  :revdesc "991753df2e6e"
  :keywords '("convenience"))
