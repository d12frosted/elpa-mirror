(define-package "modus-themes" "20220202.1408" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "59422c05e00d65582a005ccb06c3767622d14e03" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
