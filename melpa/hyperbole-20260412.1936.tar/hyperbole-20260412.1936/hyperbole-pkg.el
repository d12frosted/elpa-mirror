;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260412.1936"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b1005e74a364d825ab97928618ddc7b1c05cd66d"
  :revdesc "b1005e74a364"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
