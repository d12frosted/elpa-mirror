;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20241231.153"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "80ab72dcbafba421b98d4ba5646c0197d885ae1a"
  :revdesc "80ab72dcbafb"
  :keywords '("languages" "lisp" "slime"))
