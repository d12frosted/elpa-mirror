(define-package "racket-mode" "20220515.1531" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "2477f07e779cceb034d62a79f8afae92e0e794ff" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
