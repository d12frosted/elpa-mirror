(define-package "dwim-shell-command" "20220728.2214" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "b5997ef4df907937e7d22b4b76263bef61927616" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
