;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250318.1731"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "67f7ae89800b53f9368b61b5713d74b03433fb34"
  :revdesc "67f7ae89800b"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
