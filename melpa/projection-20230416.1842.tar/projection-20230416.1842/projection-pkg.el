(define-package "projection" "20230416.1842" "Project specific compilation commands"
  '((emacs "29")
    (project "0.9.8")
    (compat "29.1.4.1")
    (compile-multi "0.1"))
  :commit "a543618a9d06ebe4a8a04f6e1067f3f4cbd49fbb" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
