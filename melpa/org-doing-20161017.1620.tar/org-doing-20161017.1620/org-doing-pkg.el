(define-package "org-doing" "20161017.1620" "Keep track of what you're doing" 'nil :commit "4819e75c827c2115bd28f3b3148d846aa64ccd9b" :authors
  '(("Rudolf Olah"))
  :maintainer
  '("Rudolf Olah")
  :keywords
  '("tools" "org")
  :url "https://github.com/omouse/org-doing")
;; Local Variables:
;; no-byte-compile: t
;; End:
