;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-doing" "20161017.1620"
  "Keep track of what you're doing."
  ()
  :url "https://github.com/omouse/org-doing"
  :commit "4819e75c827c2115bd28f3b3148d846aa64ccd9b"
  :revdesc "4819e75c827c"
  :keywords '("tools" "org"))
