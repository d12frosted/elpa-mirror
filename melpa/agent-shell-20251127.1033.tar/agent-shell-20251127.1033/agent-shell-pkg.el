;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251127.1033"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2c64201a6a9c4333988524087cd5a02ad433eb89"
  :revdesc "2c64201a6a9c")
