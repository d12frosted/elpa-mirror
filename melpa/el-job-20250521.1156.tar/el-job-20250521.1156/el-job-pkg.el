;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250521.1156"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "2cab7bc61b331633a722ed372c085fd086886710"
  :revdesc "2cab7bc61b33"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
