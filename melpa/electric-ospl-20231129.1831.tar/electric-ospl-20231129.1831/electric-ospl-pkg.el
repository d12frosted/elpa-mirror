(define-package "electric-ospl" "20231129.1831" "Electric OSPL Mode"
  '((emacs "26.1"))
  :commit "1fb0f23905bd8f1cccb50786d0d34f23caf61e4c" :authors
  '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers
  '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainer
  '("Samuel W. Flint" . "swflint@flintfam.org")
  :keywords
  '("convenience" "text")
  :url "https://git.sr.ht/~swflint/electric-ospl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
