(define-package "company" "20231115.122" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "06b1ebe9a1ca38740788fc98dd40f932fb3bb9a7" :authors
  '(("Nikolaj Schumacher"))
  :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
