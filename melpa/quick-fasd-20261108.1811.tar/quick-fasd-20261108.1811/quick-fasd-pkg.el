;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20261108.1811"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "199649d8ded160946107ff3099cb2ebaa37e731f"
  :revdesc "199649d8ded1"
  :keywords '("convenience" "files" "tools"))
