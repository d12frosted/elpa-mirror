(define-package "parseclj" "20210927.703" "Clojure/EDN parser"
  '((emacs "25"))
  :commit "507720a6322078e9f0325b7fb2d5afd862e02f28" :authors
  '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainer
  '("Arne Brasseur" . "arne@arnebrasseur.net")
  :keywords
  '("lisp" "clojure" "edn" "parser"))
;; Local Variables:
;; no-byte-compile: t
;; End:
