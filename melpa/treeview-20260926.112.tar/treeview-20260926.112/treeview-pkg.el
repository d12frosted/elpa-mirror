;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treeview" "20260926.112"
  "A generic tree navigation library."
  '((emacs "29.1"))
  :url "https://github.com/tilmanrassy/emacs-treeview"
  :commit "23f34fb3bc3ed7c9f6bad39b942b520cd20675f3"
  :revdesc "23f34fb3bc3e"
  :keywords '("lisp" "tools" "internal" "convenience")
  :authors '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainers '(("Tilman Rassy" . "tilman.rassy@googlemail.com")))
