;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-server" "20261101.1132"
  "Speaks HTTP for you."
  '((emacs "30.1"))
  :url "https://codeberg.org/martenlienen/http-server.el"
  :commit "3743b5f43273bb42bb329b87cca99654b0c6c00b"
  :revdesc "3743b5f43273"
  :keywords '("comm")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
