(define-package "consult" "20220502.1450" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "87a9499c7b11fe230ee38b88a1606554132824dd" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
