;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doctest" "20260620.2225"
  "Doctests for Emacs Lisp."
  '((emacs "28.1"))
  :url "https://github.com/ag91/doctest"
  :commit "cdf41b5185dcd502f92722297f4361eab4ef1d13"
  :revdesc "cdf41b5185dc"
  :keywords '("lisp" "maint" "docs" "help")
  :authors '(("Chris Rayner" . "(dchrisrayner@gmail.com)")
             ("Andrea -- current maintainer" . "(andrea-dev@hotmail.com) "))
  :maintainers '(("Chris Rayner" . "(dchrisrayner@gmail.com)")
                 ("Andrea -- current maintainer" . "(andrea-dev@hotmail.com) ")))
