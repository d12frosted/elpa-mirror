;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kanagawa-themes" "20260413.1643"
  "Elegant theme inspired by The Great Wave off Kanagawa."
  '((emacs "24.3"))
  :url "https://github.com/Fabiokleis/kanagawa-emacs"
  :commit "c0ec6694a6574ad2d54ca671de2093c81b54888a"
  :revdesc "c0ec6694a657"
  :keywords '("themes" "faces")
  :authors '(("Mrjtjmn" . "meritamen@sdf.org"))
  :maintainers '(("Fabio Kleis" . "fabiohkrc@gmail.com")
                 ("Mrjtjmn" . "meritamen@sdf.org")))
