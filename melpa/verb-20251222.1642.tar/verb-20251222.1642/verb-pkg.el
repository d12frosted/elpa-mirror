;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verb" "20251222.1642"
  "Organize and send HTTP requests."
  '((emacs "26.3"))
  :url "https://github.com/federicotdn/verb"
  :commit "824343ae65c1c42baeebb34179774e2eadedb7dc"
  :revdesc "824343ae65c1"
  :keywords '("tools")
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
