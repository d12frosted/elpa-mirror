;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260125.2119"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "6edfb0b06f3054c2ce8c1d19b25c918c12df7723"
  :revdesc "6edfb0b06f30"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
