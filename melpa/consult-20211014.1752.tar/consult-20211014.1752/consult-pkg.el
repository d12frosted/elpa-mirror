(define-package "consult" "20211014.1752" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f757c17cfc3850fb25d28c90ebf19db0976895fe" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
