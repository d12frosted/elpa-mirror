;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20260621.1843"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "13e2dc610cb5c572e26e58241d6ff667fc07bdba"
  :revdesc "13e2dc610cb5"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
