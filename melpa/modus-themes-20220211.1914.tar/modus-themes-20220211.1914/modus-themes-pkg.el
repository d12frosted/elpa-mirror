(define-package "modus-themes" "20220211.1914" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "cea0db51c52f6aefcb98bc3d71c2e63df7b2ddfc" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
