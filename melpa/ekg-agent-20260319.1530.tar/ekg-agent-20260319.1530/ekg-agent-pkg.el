;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260319.1530"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "df6e11d3df6bfd026fd514de22a863cdc2e4cc5e"
  :revdesc "df6e11d3df6b"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
