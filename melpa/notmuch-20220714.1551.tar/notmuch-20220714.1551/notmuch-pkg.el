(define-package "notmuch" "20220714.1551" "run notmuch within emacs" 'nil :commit "5e17495ab78937015de45704fff8300a37ca6508" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
