;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yarn-mode" "20200208.2332"
  "Major mode for yarn.lock files."
  '((emacs "24.3"))
  :url "https://github.com/anachronic/yarn-mode"
  :commit "8239d4dc7d8a52fa1e3fa81bd32c904a359fcfc1"
  :revdesc "8239d4dc7d8a"
  :keywords '("convenience")
  :authors '(("Nicolás Salas V." . "nikosalas@gmail.com"))
  :maintainers '(("Nicolás Salas V." . "nikosalas@gmail.com")))
