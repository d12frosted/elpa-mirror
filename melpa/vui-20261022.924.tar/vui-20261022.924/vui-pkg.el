;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261022.924"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "0fdc1b18794e13c2088ca97e9fa01d9220c985e6"
  :revdesc "0fdc1b18794e"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
