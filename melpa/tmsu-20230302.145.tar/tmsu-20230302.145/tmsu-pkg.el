(define-package "tmsu" "20230302.145" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "5745682cff56a89712a8a1c7e69423b3580d23f2" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
