;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260110.243"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "e4d4e7b86f86bc1e2750d03ad7292570e35d640d"
  :revdesc "e4d4e7b86f86"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
