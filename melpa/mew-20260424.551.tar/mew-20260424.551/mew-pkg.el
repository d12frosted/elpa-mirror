;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260424.551"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "b53e86e1a9bd7db8634387ee54e5af62e35925ad"
  :revdesc "b53e86e1a9bd")
