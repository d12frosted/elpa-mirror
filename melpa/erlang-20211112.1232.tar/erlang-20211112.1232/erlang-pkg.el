(define-package "erlang" "20211112.1232" "Erlang major mode"
  '((emacs "24.1"))
  :commit "abe8285f0b4c594d610f72df6890f6851b89f248" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
