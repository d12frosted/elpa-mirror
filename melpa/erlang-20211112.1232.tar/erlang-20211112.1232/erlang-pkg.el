(define-package "erlang" "20211112.1232" "Erlang major mode"
  '((emacs "24.1"))
  :commit "81677d175b3e88d7bc79a1899d05992a557ea9f1" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
