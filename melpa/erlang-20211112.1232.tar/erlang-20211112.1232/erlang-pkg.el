(define-package "erlang" "20211112.1232" "Erlang major mode"
  '((emacs "24.1"))
  :commit "4b94d7001205336b42641c651c37f2a1ec10dbf1" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
