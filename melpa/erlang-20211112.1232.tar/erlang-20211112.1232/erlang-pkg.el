(define-package "erlang" "20211112.1232" "Erlang major mode"
  '((emacs "24.1"))
  :commit "1f937cebfd4d62e4a139fea8738227498ea6fad0" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
