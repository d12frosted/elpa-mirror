(define-package "racket-mode" "20211024.1323" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "5b6ac3ff995004bc055c1d33cc65a02558a10599" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
