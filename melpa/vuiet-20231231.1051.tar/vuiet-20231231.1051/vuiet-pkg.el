;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vuiet" "20231231.1051"
  "The music player and explorer for Emacs."
  '((emacs    "26.1")
    (lastfm   "1.1")
    (versuri  "1.0")
    (s        "1.12.0")
    (bind-key "2.4")
    (mpv      "0.1.0")
    (ivy      "0.14.2"))
  :url "https://github.com/mihaiolteanu/vuiet"
  :commit "25d79860b165f04d7d39395138ed4f23e982132f"
  :revdesc "25d79860b165"
  :keywords '("multimedia")
  :authors '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")))
