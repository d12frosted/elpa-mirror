(define-package "spdx" "20221111.143" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "7119e66ae16c68685e29a02cb2780425b82db781" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
