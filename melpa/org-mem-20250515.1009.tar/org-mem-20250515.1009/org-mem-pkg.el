;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250515.1009"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "725cf6ca0b756425b1068114d8e5efaff863e66a"
  :revdesc "725cf6ca0b75"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
