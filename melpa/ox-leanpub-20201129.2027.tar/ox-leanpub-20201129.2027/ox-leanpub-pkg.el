(define-package "ox-leanpub" "20201129.2027" "Export Org documents to Leanpub book format"
  '((org "9.1")
    (ox-gfm "1.0")
    (emacs "26.1")
    (s "1.12.0"))
  :commit "4adf97dd195f0a777b952b97888b77cdd9479629" :authors
  '(("Diego Zamboni" . "diego@zzamboni.org"))
  :maintainer
  '("Diego Zamboni" . "diego@zzamboni.org")
  :keywords
  '("files" "org" "leanpub")
  :url "https://gitlab.com/zzamboni/ox-leanpub")
;; Local Variables:
;; no-byte-compile: t
;; End:
