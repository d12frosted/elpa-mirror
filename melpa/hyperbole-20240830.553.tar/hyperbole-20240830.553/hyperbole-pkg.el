(define-package "hyperbole" "20240830.553" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.2"))
  :commit "5dbd852f10161c4a5b7043bf7be319432232d8d0" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainer
  '("Robert Weiner" . "rsw@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
