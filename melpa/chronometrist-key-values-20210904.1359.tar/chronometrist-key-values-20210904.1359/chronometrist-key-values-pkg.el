(define-package "chronometrist-key-values" "20210904.1359" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "3e7c41c9f710e21e9aa22854462e905737284e2d" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
