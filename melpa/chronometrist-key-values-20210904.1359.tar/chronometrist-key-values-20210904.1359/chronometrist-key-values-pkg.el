(define-package "chronometrist-key-values" "20210904.1359" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "d673f00e5a43f8ac276b89c85622dcdf4cbd8148" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
