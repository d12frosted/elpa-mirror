;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ah" "20220730.1058"
  "Additional hooks."
  '((emacs "25.1"))
  :url "https://github.com/takaxp/ah"
  :commit "8e12223f0f423e7fa882cc049a25af6db755902d"
  :revdesc "8e12223f0f42"
  :keywords '("convenience")
  :authors '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg"))
  :maintainers '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg")))
