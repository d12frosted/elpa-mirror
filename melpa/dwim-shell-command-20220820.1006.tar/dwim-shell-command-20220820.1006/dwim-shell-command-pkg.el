(define-package "dwim-shell-command" "20220820.1006" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "ed5aff8f1176de141cadbd1be6771ef1ce2795f4" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
