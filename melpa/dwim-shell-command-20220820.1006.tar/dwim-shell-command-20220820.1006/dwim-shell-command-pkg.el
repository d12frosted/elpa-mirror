(define-package "dwim-shell-command" "20220820.1006" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "064af9227d6be97d9c4d18ee0d114ccefdb9d414" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
