(define-package "osa-chrome" "20201122.1639" "Google Chrome remote tab control"
  '((emacs "25.1")
    (osa "1.0"))
  :commit "9148e21cf2e91b357f5ea3a349975e8b89c8d5e4" :authors
  (("xristos" . "xristos@sdf.org"))
  :maintainer
  ("xristos" . "xristos@sdf.org")
  :keywords
  ("comm")
  :url "https://github.com/atomontage/osa-chrome")
;; Local Variables:
;; no-byte-compile: t
;; End:
