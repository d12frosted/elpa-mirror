;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timonier" "20170411.800"
  "Manage Kubernetes Applications."
  '((emacs         "24.4")
    (s             "1.11.0")
    (f             "0.19.0")
    (dash          "2.12.0")
    (pkg-info      "0.5.0")
    (hydra         "0.13.6")
    (request       "0.2.0")
    (all-the-icons "2.0.0"))
  :url "https://github.com/nlamirault/timonier"
  :commit "3460a878269424c8d19b7d5d8e04749d0a8bf203"
  :revdesc "3460a8782694"
  :keywords '("kubernetes" "docker")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
