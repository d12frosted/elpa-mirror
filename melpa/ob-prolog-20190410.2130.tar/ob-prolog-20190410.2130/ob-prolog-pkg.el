;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-prolog" "20190410.2130"
  "Org-babel functions for prolog evaluation."
  ()
  :url "https://github.com/ljos/ob-prolog"
  :commit "149abd3832fc5a6a1cb01a586a1622a8f25887dc"
  :revdesc "149abd3832fc"
  :keywords '("literate programming" "reproducible research"))
