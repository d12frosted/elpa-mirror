;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260125.1156"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "b9c38acd1969838cca26e9b10d4c6321bc033931"
  :revdesc "b9c38acd1969"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
