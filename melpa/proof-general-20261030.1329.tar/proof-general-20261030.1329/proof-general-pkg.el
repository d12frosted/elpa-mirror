;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261030.1329"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "88254cb3550c4fce04797e6f218c1b79c9b17d71"
  :revdesc "88254cb3550c"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
