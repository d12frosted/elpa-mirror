;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ical-form" "20251106.746"
  "A widget form for editing ical events."
  '((emacs "29.1"))
  :url "https://github.com/haji-ali/maccalfw"
  :commit "fce42746bdaa1f5770282dfc4ec85241c2f5bdd7"
  :revdesc "fce42746bdaa"
  :keywords '("calendar")
  :authors '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
