(define-package "tok-theme" "20220201.1112" "My theme"
  '((emacs "24.3"))
  :commit "e7bfe48d684d79fe02fe7639a9e138443eba5b38" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
