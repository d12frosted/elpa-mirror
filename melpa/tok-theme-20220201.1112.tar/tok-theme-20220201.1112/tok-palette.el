;;; tok-palette.el --- Palette for my theme -*- lexical-binding: t; -*-

;; Copyright (C) 2021, Topi Kettunen <topi@topikettunen.com>

;; Author: Topi Kettunen <topi@topikettunen.com>
;; URL: https://github.com/topikettunen/tok-theme
;; Version: 0.1
;; Package-Requires: ((emacs "24.3"))

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <http://www.gnu.org/licenses/>.

;; This file is not part of Emacs.

;;; Commentary:

;; Color palette for the my theme.

;;; Code:

(defvar tok-theme-color-palette-alist
  '((primary . "#f8d152")
    (primary2 . "#b3963b")
    (primary3 . "#403614")
    (primary4 . "#26200c")
    (primary5 . "#191508")
    (bg . "#ffffff")
    (fg . "#202122")
    (fg-highlight . fg)
    (bg-highlight . "#ffe285")
    (fg-active . primary)
    (bg-active . primary3)
    (fg-inactive . primary2)
    (bg-inactive . primary4)
    (hl-line . "#fff5d4")
    (region . "#fff0bf")
    (comment . primary2)
    (link . primary))
  "My theme's palette")

(provide 'tok-palette)

;;; tok-palette.el ends here
