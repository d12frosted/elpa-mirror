(define-package "binky" "20231008.2014" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "98e4922fe5038ac5fe61cdc624ec07c60680923a" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
