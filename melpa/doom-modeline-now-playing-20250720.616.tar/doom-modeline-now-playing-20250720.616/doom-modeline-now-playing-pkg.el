;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline-now-playing" "20250720.616"
  "Segment for Doom Modeline to show media player information."
  '((emacs         "26.1")
    (doom-modeline "3.0.0"))
  :url "https://github.com/elken/doom-modeline-now-playing"
  :commit "21560d11990110f16c48dd98b8beb103e5f3167e"
  :revdesc "21560d119901"
  :authors '(("Ellis Kenyő" . "me@elken.dev"))
  :maintainers '(("Ellis Kenyő" . "me@elken.dev")))
