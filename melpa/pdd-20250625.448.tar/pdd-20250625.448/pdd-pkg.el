;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250625.448"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "b3b2fe5e72a3cfe8e60571616e3673b0d6baa590"
  :revdesc "b3b2fe5e72a3"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
