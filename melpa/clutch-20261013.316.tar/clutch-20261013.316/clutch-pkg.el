;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261013.316"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "93bd4ec9b0bb1da708e8888b9b197f796705187b"
  :revdesc "93bd4ec9b0bb"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
