;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260825.913"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "497cb4498add27c2cfb667ccbb265d947f751edb"
  :revdesc "497cb4498add"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
