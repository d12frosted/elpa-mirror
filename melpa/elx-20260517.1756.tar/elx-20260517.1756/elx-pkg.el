;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "20260517.1756"
  "Extract information from Emacs Lisp libraries."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "83c65d5cf1758fed26cde658e143d4699645d857"
  :revdesc "83c65d5cf175"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
