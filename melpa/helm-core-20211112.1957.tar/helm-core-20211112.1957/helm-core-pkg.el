(define-package "helm-core" "20211112.1957" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "52dcf9e27c1a10be058efa0cf790510bbfeb89e7")
;; Local Variables:
;; no-byte-compile: t
;; End:
