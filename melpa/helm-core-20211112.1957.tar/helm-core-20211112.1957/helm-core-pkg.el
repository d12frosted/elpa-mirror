(define-package "helm-core" "20211112.1957" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "e0ca595a9952c9924cab1f5c02e2ea9423e6d591")
;; Local Variables:
;; no-byte-compile: t
;; End:
