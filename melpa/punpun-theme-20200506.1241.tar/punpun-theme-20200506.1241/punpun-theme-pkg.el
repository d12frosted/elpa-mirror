(define-package "punpun-theme" "20200506.1241" "A bleak theme" 'nil :commit "57c2c87b72336e5dee2165c6b0010022f6e7e51d")
;; Local Variables:
;; no-byte-compile: t
;; End:
