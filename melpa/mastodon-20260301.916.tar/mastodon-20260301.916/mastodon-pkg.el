;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260301.916"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "edea11cc69c7fc45cb3606b9bff90c89372bdea1"
  :revdesc "edea11cc69c7"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
