;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20260123.1113"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "5c1e1f632b8b8963d7f5fec449d2dc7da96aadbf"
  :revdesc "5c1e1f632b8b"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
