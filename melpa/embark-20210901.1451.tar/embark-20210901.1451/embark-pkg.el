(define-package "embark" "20210901.1451" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d4bd8b989373c1c08923421a5748f90621e60fa1" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
