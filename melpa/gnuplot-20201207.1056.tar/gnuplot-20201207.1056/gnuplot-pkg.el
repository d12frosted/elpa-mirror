(define-package "gnuplot" "20201207.1056" "Major-mode and interactive frontend for gnuplot"
  '((emacs "24.1"))
  :commit "24dd2d088bf32444643b70d8e0033d56f8b54107" :keywords
  ("data" "gnuplot" "plotting")
  :authors
  (("Jon Oddie")
   ("Bruce Ravel")
   ("Phil Type"))
  :maintainer
  ("Bruce Ravel" . "bruceravel1@gmail.com")
  :url "https://github.com/emacsorphanage/gnuplot")
;; Local Variables:
;; no-byte-compile: t
;; End:
