(define-package "gnuplot" "20201207.1056" "Major-mode and interactive frontend for gnuplot"
  '((emacs "24.1"))
  :commit "fbb15b630de35b8f1396db6f26e966e9996a5a4f" :keywords
  ("data" "gnuplot" "plotting")
  :authors
  (("Jon Oddie")
   ("Bruce Ravel")
   ("Phil Type"))
  :maintainer
  ("Bruce Ravel" . "bruceravel1@gmail.com")
  :url "https://github.com/emacsorphanage/gnuplot")
;; Local Variables:
;; no-byte-compile: t
;; End:
