;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260719.728"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "1b4d3d93c1922e0067596ddc8060a875d8b5dc43"
  :revdesc "1b4d3d93c192"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
