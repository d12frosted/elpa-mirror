(define-package "alchemist" "20170330.753" "Elixir tooling integration into Emacs"
  '((elixir-mode "2.2.5")
    (dash "2.11.0")
    (emacs "24.4")
    (company "0.8.0")
    (pkg-info "0.4"))
  :commit "34caeed1bd231c7dfa8d2b9aa5c5de2b2a059601" :authors
  '(("Samuel Tonini" . "tonini.samuel@gmail.com"))
  :maintainer
  '("Samuel Tonini" . "tonini.samuel@gmail.com")
  :keywords
  '("languages" "elixir" "elixirc" "mix" "hex" "alchemist")
  :url "http://www.github.com/tonini/alchemist.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
