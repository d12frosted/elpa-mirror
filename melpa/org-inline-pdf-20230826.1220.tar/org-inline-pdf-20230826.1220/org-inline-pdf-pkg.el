;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-inline-pdf" "20230826.1220"
  "Inline PDF previewing for Org."
  '((emacs "25.1")
    (org   "9.4"))
  :url "https://github.com/shg/org-inline-pdf.el"
  :commit "2460c429e0977587863f41176aafe1ca858c13e8"
  :revdesc "2460c429e097"
  :keywords '("org" "outlines" "hypermedia"))
