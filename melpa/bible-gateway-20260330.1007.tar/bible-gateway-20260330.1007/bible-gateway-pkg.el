;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260330.1007"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "53a1ebd846b1b5f7591f142fab18058848bb4a98"
  :revdesc "53a1ebd846b1"
  :keywords '("convenience" "comm" "hypermedia"))
