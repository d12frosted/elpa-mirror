;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polish-holidays" "20250613.2245"
  "Polish holidays."
  '((emacs "24.1"))
  :url "https://github.com/przemarbor/polish-holidays"
  :commit "3a1e11f53b0fa41bc511c65ae1699394f49cbb08"
  :revdesc "3a1e11f53b0f"
  :keywords '("calendar"))
