;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20261104.1424"
  "Nucleo-backed completion style."
  '((emacs "29.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "156aaa96fa584a941b958bf0ca0e73b971f02247"
  :revdesc "156aaa96fa58"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
