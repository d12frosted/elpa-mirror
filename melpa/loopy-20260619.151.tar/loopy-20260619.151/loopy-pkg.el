;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260619.151"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "e7b05b7a4d0d3dba1935c0bd70db34ec65510959"
  :revdesc "e7b05b7a4d0d"
  :keywords '("extensions"))
