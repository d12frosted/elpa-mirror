(define-package "flymake-perlcritic" "20120328.814" "Flymake handler for Perl to invoke Perl::Critic"
  '((flymake "0.3"))
  :commit "06d819c6d1292f8c87ebc0681c83c9fb48620bbe" :authors
  '(("Sam Graham <libflymake-perlcritic-emacs BLAHBLAH illusori.co.uk>"))
  :maintainer
  '("Sam Graham <libflymake-perlcritic-emacs BLAHBLAH illusori.co.uk>")
  :url "https://github.com/illusori/emacs-flymake-perlcritic")
;; Local Variables:
;; no-byte-compile: t
;; End:
