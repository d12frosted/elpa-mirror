(define-package "flymake-perlcritic" "20120328.814" "Flymake handler for Perl to invoke Perl::Critic"
  '((flymake "0.3"))
  :commit "cfb4ea6dddd444af01a95efb915a91537b6031f1" :authors
  '(("Sam Graham <libflymake-perlcritic-emacs BLAHBLAH illusori.co.uk>"))
  :maintainer
  '("Sam Graham <libflymake-perlcritic-emacs BLAHBLAH illusori.co.uk>")
  :url "https://github.com/illusori/emacs-flymake-perlcritic")
;; Local Variables:
;; no-byte-compile: t
;; End:
