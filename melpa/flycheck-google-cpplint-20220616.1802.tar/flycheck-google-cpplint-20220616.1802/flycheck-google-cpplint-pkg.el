(define-package "flycheck-google-cpplint" "20220616.1802" "Help to comply with the Google C++ Style Guide"
  '((flycheck "0.20snapshot1"))
  :commit "93c5b26ec55d0df54bc230e2de0890fe074f35d3" :authors
  '(("Akiha Senda" . "senda.akiha@gmail.com"))
  :maintainers
  '(("Jen-Chieh Shen" . "jcs090218@gmail.com"))
  :maintainer
  '("Jen-Chieh Shen" . "jcs090218@gmail.com")
  :keywords
  '("flycheck" "c" "c++")
  :url "https://github.com/flycheck/flycheck-google-cpplint/")
;; Local Variables:
;; no-byte-compile: t
;; End:
