;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260306.1838"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "ed9cd4e61aa64a0fc68582eb13747219ab1067ce"
  :revdesc "ed9cd4e61aa6"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
