;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261007.133"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "dce218673fc517068b8793ccd5d40ee13674b2b9"
  :revdesc "dce218673fc5"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
