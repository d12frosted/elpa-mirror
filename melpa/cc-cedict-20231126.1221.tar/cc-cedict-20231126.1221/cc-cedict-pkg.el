(define-package "cc-cedict" "20231126.1221" "Interface to CC-CEDICT (a Chinese-English dictionary)"
  '((emacs "26.1"))
  :commit "0d69f3018e3f263c16961e2fdcb1fcc4222697b0" :authors
  '(("Xu Chunyang"))
  :maintainers
  '(("Xu Chunyang"))
  :maintainer
  '("Xu Chunyang")
  :url "https://github.com/xuchunyang/cc-cedict.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
