;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260506.1407"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "c79120ecaaa0fefcea5b05d49e52208f9bc62c3f"
  :revdesc "c79120ecaaa0"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
