;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20261021.2220"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "52513cfbe79cb8c4e5ef2ef61e9f4aa47ce56a1f"
  :revdesc "52513cfbe79c"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
