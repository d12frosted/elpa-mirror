(define-package "magit-section" "20240307.1635" "Sections for read-only buffers."
  '((emacs "25.1")
    (compat "29.1.4.4")
    (dash "20221013"))
  :commit "76c14efc787306a9d2d45a74a8e6754db89c4813" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
