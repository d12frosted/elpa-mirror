(define-package "cacoo" "20120319.2359" "Minor mode for Cacoo : http://cacoo.com"
  '((concurrent "0.3.1"))
  :commit "c9fa04fbe97639b24698709530361c2bb5f3273c" :authors
  (("SAKURAI Masashi <m.sakurai atmark kiwanami.net>"))
  :maintainer
  ("SAKURAI Masashi <m.sakurai atmark kiwanami.net>")
  :keywords
  ("convenience" "diagram")
  :url "https://github.com/kiwanami/emacs-cacoo/")
;; Local Variables:
;; no-byte-compile: t
;; End:
