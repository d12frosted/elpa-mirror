;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cacoo" "20120319.2359"
  "Minor mode for Cacoo : http://cacoo.com."
  '((concurrent "0.3.1"))
  :url "https://github.com/kiwanami/emacs-cacoo/"
  :commit "c9fa04fbe97639b24698709530361c2bb5f3273c"
  :revdesc "c9fa04fbe976"
  :keywords '("convenience" "diagram")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net")))
