(define-package "cacoo" "20120319.2359" "Minor mode for Cacoo : http://cacoo.com"
  '((concurrent "0.3.1"))
  :commit "c9fa04fbe97639b24698709530361c2bb5f3273c")
;; Local Variables:
;; no-byte-compile: t
;; End:
