(define-package "consult" "20210721.2058" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "6a4df175aa5ee5cf5a6bda765f8fa0e7be7c33f1" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
