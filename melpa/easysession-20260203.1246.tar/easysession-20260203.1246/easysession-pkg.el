;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260203.1246"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "f15c52f0cde303111d106a0b41db97fa1b123147"
  :revdesc "f15c52f0cde3"
  :keywords '("convenience"))
