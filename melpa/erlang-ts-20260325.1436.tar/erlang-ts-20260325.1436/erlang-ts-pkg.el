;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang-ts" "20260325.1436"
  "Major modes for editing Erlang."
  '((emacs  "29.2")
    (erlang "27.2"))
  :url "https://github.com/erlang/emacs-erlang-ts"
  :commit "d1f2a6fbc83449a70d227474bbf186f7ffbfc77e"
  :revdesc "d1f2a6fbc834"
  :keywords '("erlang" "languages" "treesitter"))
