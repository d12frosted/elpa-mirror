(define-package "robe" "20240326.1815" "Code navigation, documentation lookup and completion for Ruby"
  '((inf-ruby "2.5.1")
    (emacs "25.1"))
  :commit "e693fd3aaab20439dddf51d4713dfd99d340c82c" :authors
  '(("Dmitry Gutov"))
  :maintainers
  '(("Dmitry Gutov"))
  :maintainer
  '("Dmitry Gutov")
  :keywords
  '("ruby" "convenience" "rails")
  :url "https://github.com/dgutov/robe")
;; Local Variables:
;; no-byte-compile: t
;; End:
