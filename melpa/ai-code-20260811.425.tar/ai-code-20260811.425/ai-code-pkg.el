;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260811.425"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "6e9da1ad6126614867e4efde4af8327dca347382"
  :revdesc "6e9da1ad6126"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
