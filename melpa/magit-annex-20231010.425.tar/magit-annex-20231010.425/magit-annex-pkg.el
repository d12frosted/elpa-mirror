(define-package "magit-annex" "20231010.425" "Control git-annex from Magit"
  '((cl-lib "0.3")
    (magit "3.0.0"))
  :commit "7c308decfc56270a0cf3cc8292c3bf7122103331" :authors
  '(("Kyle Meyer" . "kyle@kyleam.com")
    ("Rémi Vanicat" . "vanicat@debian.org"))
  :maintainers
  '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainer
  '("Kyle Meyer" . "kyle@kyleam.com")
  :keywords
  '("vc" "tools")
  :url "https://github.com/magit/magit-annex")
;; Local Variables:
;; no-byte-compile: t
;; End:
