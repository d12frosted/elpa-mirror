(define-package "citre" "20210716.403" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "813e8c32a41f84ff099feddb5a4d5a51c5c200b5" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
