;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "j-mode" "20251003.805"
  "Major mode for editing J programs."
  ()
  :url "https://github.com/zellio/j-mode"
  :commit "1365e5a3fe772609685b3787bbd2960331c1a02f"
  :revdesc "1365e5a3fe77"
  :keywords '("j" "languages"))
