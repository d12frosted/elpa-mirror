;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-better-visual-line" "20200123.2045"
  "Gj and gk visual line mode fix."
  '((evil "1.2.13"))
  :url "https://github.com/yourfin/evil-better-visual-line"
  :commit "7a65dfb17ab93857eb4c7a39d4018d9399705293"
  :revdesc "7a65dfb17ab9"
  :keywords '("evil" "vim" "motion")
  :authors '((nil . "nuckollspatgmail.com"))
  :maintainers '((nil . "nuckollspatgmail.com")))
