(define-package "affe" "20220308.1016" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.16"))
  :commit "0982fbfee5877b2492568cce2d746b263f198db3" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
