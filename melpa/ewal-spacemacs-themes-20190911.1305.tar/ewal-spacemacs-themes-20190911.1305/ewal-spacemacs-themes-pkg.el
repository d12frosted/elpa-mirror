(define-package "ewal-spacemacs-themes" "20190911.1305" "Ride the rainbow spaceship"
  '((emacs "25")
    (ewal "0.1")
    (spacemacs-theme "0.1"))
  :commit "e2a04f5c97b7d5e087af26e646c0b45a24522e56" :keywords
  ("faces")
  :authors
  (("Uros Perisic"))
  :maintainer
  ("Uros Perisic")
  :url "https://gitlab.com/jjzmajic/ewal")
;; Local Variables:
;; no-byte-compile: t
;; End:
