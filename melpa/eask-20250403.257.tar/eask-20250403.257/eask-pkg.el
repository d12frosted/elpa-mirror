;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20250403.257"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "7faf67d059a8271c4b9e2eb23f8e1dc807a974e7"
  :revdesc "7faf67d059a8"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
