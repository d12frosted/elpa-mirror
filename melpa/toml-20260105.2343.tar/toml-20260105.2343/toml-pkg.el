;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260105.2343"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "aa222ff8864f14410a042b822f59c588f6f60b05"
  :revdesc "aa222ff8864f"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
