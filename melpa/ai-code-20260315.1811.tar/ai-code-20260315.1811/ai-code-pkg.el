;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260315.1811"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "f01c19c2b9425ccd0e5a093999069ef3d624fac7"
  :revdesc "f01c19c2b942"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
