;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-w3m" "20210315.723"
  "W3m bookmark - helm interface."
  '((helm   "1.5")
    (w3m    "0.0")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-w3m"
  :commit "0a25a2b1df9bc660a90d633beb301b3815556e4e"
  :revdesc "0a25a2b1df9b")
