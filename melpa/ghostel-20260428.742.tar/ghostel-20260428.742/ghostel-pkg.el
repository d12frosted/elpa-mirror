;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260428.742"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "90f1f71d022910a5f86da1d413ea155422eac5dc"
  :revdesc "90f1f71d0229"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
