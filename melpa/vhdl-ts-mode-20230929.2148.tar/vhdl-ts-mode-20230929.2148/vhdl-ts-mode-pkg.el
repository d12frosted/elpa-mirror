(define-package "vhdl-ts-mode" "20230929.2148" "VHDL Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "32695347c778f9d16968f84d7d9ce3c58cc7e38c" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
