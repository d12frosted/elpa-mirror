(define-package "ob-swiftui" "20231008.2123" "Org babel functions for SwiftUI evaluation"
  '((emacs "25.1")
    (swift-mode "8.2.0")
    (org "9.2.0"))
  :commit "1f4e2162fb296764250f3d6f2816c2c2b71ae474" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/ob-swiftui")
;; Local Variables:
;; no-byte-compile: t
;; End:
