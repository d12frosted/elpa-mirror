;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperdrive" "20241022.913"
  "P2P filesystem."
  '((emacs              "28.1")
    (map                "3.0")
    (compat             "30.0.0.0")
    (org                "9.7.6")
    (plz                "0.9.1")
    (persist            "0.6.1")
    (taxy-magit-section "0.14")
    (transient          "0.7.7"))
  :url "https://git.sr.ht/~ushin/hyperdrive.el"
  :commit "c1efca834be035fcb733a5cc1b5f13aa993eb28e"
  :revdesc "c1efca834be0"
  :authors '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht")))
