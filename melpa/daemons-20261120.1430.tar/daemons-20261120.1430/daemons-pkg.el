;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daemons" "20261120.1430"
  "UI for managing init system daemons (services)."
  '((emacs  "25.1")
    (s      "1.13.0")
    (compat "29.1.4.2"))
  :url "https://github.com/cbowdon/daemons.el"
  :commit "418ff69da73c97d3763e8dbdadec4aa73583f28b"
  :revdesc "418ff69da73c"
  :keywords '("unix" "convenience"))
