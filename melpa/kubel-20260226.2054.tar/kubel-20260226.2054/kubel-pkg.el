;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "20260226.2054"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "e32ee261fc5f20110c82746e6d106ada8411b813"
  :revdesc "e32ee261fc5f"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
