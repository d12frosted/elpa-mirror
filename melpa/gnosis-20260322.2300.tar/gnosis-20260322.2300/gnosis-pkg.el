;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260322.2300"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "2ed2254b6f1e9e2c7a1a493e9a688b22f1c96680"
  :revdesc "2ed2254b6f1e"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
