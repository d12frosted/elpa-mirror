(define-package "apdl-mode" "20210913.1840" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "933b6b974599834b3c61b4fd312615037d5665bb" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
