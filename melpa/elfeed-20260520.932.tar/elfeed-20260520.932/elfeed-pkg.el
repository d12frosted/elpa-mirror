;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260520.932"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "5cf6165925cf82df32c148c7535b52ac5aa28854"
  :revdesc "5cf6165925cf"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
