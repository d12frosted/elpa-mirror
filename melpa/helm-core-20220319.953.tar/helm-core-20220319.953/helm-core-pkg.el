(define-package "helm-core" "20220319.953" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "2f89214b0b387f21f3a5753539ab7460559c6f17" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
