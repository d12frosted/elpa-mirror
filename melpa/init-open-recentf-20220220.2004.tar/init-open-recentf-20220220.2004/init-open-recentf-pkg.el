;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "init-open-recentf" "20220220.2004"
  "Invoke a command immediately after startup."
  '((emacs "24.4"))
  :url "https://github.com/zonuexe/init-open-recentf.el"
  :commit "51463effe54ca9390ec339b9678968f35a40dbfd"
  :revdesc "51463effe54c"
  :keywords '("files" "recentf" "after-init-hook")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
