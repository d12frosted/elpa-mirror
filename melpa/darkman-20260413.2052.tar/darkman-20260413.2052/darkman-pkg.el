;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darkman" "20260413.2052"
  "Seamless integration with Darkman."
  '((emacs "28.1"))
  :url "https://darkman.grtcdr.tn"
  :commit "2a1b584827c1f47a5b08bb1748dba982d8c3de91"
  :revdesc "2a1b584827c1"
  :keywords '("convenience")
  :authors '(("Taha Aziz Ben Ali" . "ba.tahaaziz@gmail.com"))
  :maintainers '(("Taha Aziz Ben Ali" . "ba.tahaaziz@gmail.com")))
