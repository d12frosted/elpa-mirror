(define-package "evil-matchit" "20220524.1237" "Vim matchit ported to Evil"
  '((emacs "25.1"))
  :commit "f8edde41be44fe2a2c44908090613e726e0efbf2" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
