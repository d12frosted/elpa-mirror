;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "20261005.1426"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "01ae94eff6ae78f784ca6e1231408ee0df8216e8"
  :revdesc "01ae94eff6ae"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
