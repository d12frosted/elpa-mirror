;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250316.1706"
  "AI pair programming with Aider."
  '((emacs "29.1"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "254a802d62629ea4d8165f1d39967ba7e987c2e7"
  :revdesc "254a802d6262"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
