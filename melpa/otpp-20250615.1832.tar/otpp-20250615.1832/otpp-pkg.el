;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20250615.1832"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "e3c6e3120a636d86c30054ba6f491d4309c8774a"
  :revdesc "e3c6e3120a63"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
