;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20260302.1640"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "f7e20ce831ce342c457bb6860ca3d41eb183152c"
  :revdesc "f7e20ce831ce")
