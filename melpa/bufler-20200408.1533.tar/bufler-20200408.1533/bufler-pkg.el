(define-package "bufler" "20200408.1533" "Group buffers into workspaces with programmable rules"
  '((emacs "26.3")
    (dash "2.17")
    (dash-functional "2.17")
    (f "0.17")
    (pretty-hydra "0.2.2")
    (magit-section "0.1"))
  :commit "d6c79f04b7d288174d8294fb30488b567586364d" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/bufler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
