;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260307.1417"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "2e9bd45584ffcce5611a6ba962f729120fb94ca8"
  :revdesc "2e9bd45584ff"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
