(define-package "helm-core" "20220731.856" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "d7e7075c3cd72e8ffc59f0a68baa58e34a321b52" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
