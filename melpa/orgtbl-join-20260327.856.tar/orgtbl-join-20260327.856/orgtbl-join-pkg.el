;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260327.856"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "aa6627536013ddcbf6ce6a9a2278da3a345ff94b"
  :revdesc "aa6627536013"
  :keywords '("data" "extensions"))
