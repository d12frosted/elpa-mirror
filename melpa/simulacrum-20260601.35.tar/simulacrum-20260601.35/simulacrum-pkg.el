;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simulacrum" "20260601.35"
  "Inject custom event types into the event stream."
  '((emacs "29.1"))
  :url "https://github.com/ErikPrantare/simulacrum.el"
  :commit "ad01fcf054f9fc573b7023e2fc86566d27ae45b1"
  :revdesc "ad01fcf054f9"
  :keywords '("convenience"))
