;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260302.1911"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "d69bbd9e565f5bf97683d88668dc408d99d6db92"
  :revdesc "d69bbd9e565f"
  :keywords '("outlines" "contacts" "people"))
