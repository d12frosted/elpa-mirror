;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260622.1012"
  "Friendly AI assistant for Ollama and cloud LLMs."
  '((emacs     "29.1")
    (transient "0.4.0"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "109cedd973c0b8c7afb6a4a89c2bba3c3a0c0583"
  :revdesc "109cedd973c0"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
