(define-package "ox-hugo" "20210129.2241" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "be1d5ddd8622d369cb5196b7f9e7d4b21a71a8f1" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
