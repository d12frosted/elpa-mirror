(define-package "dwim-shell-command" "20231029.1905" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "853318d58a9060c17538eaeacc00e4e6eb4fd642" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
