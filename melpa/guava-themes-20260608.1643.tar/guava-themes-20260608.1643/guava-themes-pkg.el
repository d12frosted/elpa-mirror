;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260608.1643"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "f38e48eafe467ef0e626ef9e5888125b982d34f8"
  :revdesc "f38e48eafe46"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
