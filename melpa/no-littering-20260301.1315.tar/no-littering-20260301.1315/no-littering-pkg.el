;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260301.1315"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "3b1d39d6b37f1f6f7dbda46712e40bc700ac79d2"
  :revdesc "3b1d39d6b37f"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
