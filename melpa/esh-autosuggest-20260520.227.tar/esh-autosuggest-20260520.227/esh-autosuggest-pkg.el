;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esh-autosuggest" "20260520.227"
  "History autosuggestions for eshell."
  '((emacs   "24.4")
    (company "0.9.4"))
  :url "https://github.com/dieggsy/esh-autosuggest"
  :commit "4c86c4103d83a3cbf9a6aff05972fd7ce1a3318e"
  :revdesc "4c86c4103d83"
  :keywords '("completion" "company" "matching" "convenience" "abbrev")
  :authors '(("Diego A. Mundo" . "dieggsy@pm.me"))
  :maintainers '(("Diego A. Mundo" . "dieggsy@pm.me")))
