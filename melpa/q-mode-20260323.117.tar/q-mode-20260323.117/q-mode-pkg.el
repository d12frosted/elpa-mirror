;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260323.117"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "47b6004bddfd6e82f63f0ba02a99c399f5476f1b"
  :revdesc "47b6004bddfd"
  :keywords '("faces" "files" "q"))
