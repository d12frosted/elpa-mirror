(define-package "sly" "20210222.1117" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "edd45f0d4f952b684f1b29c1805f3aee560ce965" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
