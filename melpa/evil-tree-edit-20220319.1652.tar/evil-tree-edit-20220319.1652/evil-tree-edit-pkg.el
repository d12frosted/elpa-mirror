(define-package "evil-tree-edit" "20220319.1652" "Evil structural editing for any language!"
  '((emacs "27.1")
    (tree-edit "0.1.0")
    (tree-sitter "0.15.0")
    (evil "1.0.0")
    (avy "0.5.0")
    (s "0.0.0"))
  :commit "774a1e9598617f334fcd31aa606c5e738012fb60" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
