(define-package "for" "20220926.403" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "deb92b5d7f795304b9e9f08161a746ca2d650427" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
