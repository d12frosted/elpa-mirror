;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "usage-memo" "20170926.37"
  "Integration of Emacs help system and memo."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/usage-memo.el"
  :commit "88e15a9942a3e0a6e36e9c3e51e3edb746067b1a"
  :revdesc "88e15a9942a3"
  :keywords '("convenience" "languages" "lisp" "help" "tools" "docs")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
