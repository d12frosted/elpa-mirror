(define-package "bbdb" "20220221.403" "The Insidious Big Brother Database for GNU Emacs" 'nil :commit "a6f2ebcdb0c521990e034815de37ceaab5b13495" :maintainer
  '("Roland Winkler" . "winkler@gnu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
