;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260607.2236"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "0bd7268f92362ac4bc88fc45501d20e57c9a1695"
  :revdesc "0bd7268f9236"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
