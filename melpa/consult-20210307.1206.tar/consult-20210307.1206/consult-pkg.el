(define-package "consult" "20210307.1206" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "5daee9e8046e400dca68ab87417957faae2b5ddc" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
