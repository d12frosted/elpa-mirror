(define-package "selectrum" "20210114.1651" "Easily select item from list"
  '((emacs "25.1"))
  :commit "8c9621371c49754f05eebb5d0486e19ef65b8452" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
