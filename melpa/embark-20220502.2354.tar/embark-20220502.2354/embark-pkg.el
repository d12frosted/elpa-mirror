(define-package "embark" "20220502.2354" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "254609cb6c685e65ec276140ad6aa7c96cff9509" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
