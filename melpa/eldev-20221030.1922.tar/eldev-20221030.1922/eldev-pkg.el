(define-package "eldev" "20221030.1922" "Elisp development tool"
  '((emacs "24.4"))
  :commit "3efbf8f5d5f54d6486e830c53e0e85615f9d69a3" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
