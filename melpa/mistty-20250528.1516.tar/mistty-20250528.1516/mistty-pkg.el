;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250528.1516"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "8f4ca3224fca36179e8182b9d3e19ebbf58b6d62"
  :revdesc "8f4ca3224fca"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
