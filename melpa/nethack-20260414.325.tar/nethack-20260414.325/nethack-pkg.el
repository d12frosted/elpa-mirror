;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20260414.325"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "98fe3369b0d3786efab5080b855a922186e4d9ad"
  :revdesc "98fe3369b0d3"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
