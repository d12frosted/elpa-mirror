(define-package "detached" "20220603.1446" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "24b925435c5fb7d5927fd4db5217fbfd4f8ed9c8" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
