;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser" "20260502.2308"
  "GNU Emacs and Scheme talk to each other."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://gitlab.com/emacs-geiser/"
  :commit "55b4b7847902d626a76e110a862d0fde1d1ff297"
  :revdesc "55b4b7847902"
  :keywords '("languages" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
