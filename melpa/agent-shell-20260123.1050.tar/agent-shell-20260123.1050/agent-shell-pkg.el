;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260123.1050"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2586fde875bbadacf6d1076eb778ce1d9814aaf3"
  :revdesc "2586fde875bb")
