;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devdocs-browser" "20260813.1553"
  "Browse devdocs.io documents using EWW."
  '((emacs "27.1"))
  :url "https://github.com/blahgeek/emacs-devdocs-browser"
  :commit "a49adc1f20b745338db34b729a7c94394c1c1689"
  :revdesc "a49adc1f20b7"
  :keywords '("docs" "help" "tools")
  :authors '(("blahgeek" . "i@blahgeek.com"))
  :maintainers '(("blahgeek" . "i@blahgeek.com")))
