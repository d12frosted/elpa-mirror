;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-cmake" "20260529.1744"
  "A cmake backend for project.el."
  '((emacs "30.1"))
  :url "https://github.com/lucius-martius/project-cmake"
  :commit "a1888d8ef6c32a8cf39e0056594179be1e9865ee"
  :revdesc "a1888d8ef6c3"
  :keywords '("tools" "convenience")
  :authors '(("Lucius Martius" . "lucius.martius@mailbox.org"))
  :maintainers '(("Lucius Martius" . "lucius.martius@mailbox.org")))
