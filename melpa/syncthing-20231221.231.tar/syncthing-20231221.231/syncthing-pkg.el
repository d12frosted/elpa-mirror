(define-package "syncthing" "20231221.231" "Client for Syncthing"
  '((emacs "27.1"))
  :commit "e0d16b90ce110d6088b3c82d2ef9e9237787972b" :authors
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainer
  '("Peter Badida" . "keyweeusr@gmail.com")
  :keywords
  '("convenience" "syncthing" "sync" "client" "view")
  :url "https://github.com/KeyWeeUsr/emacs-syncthing")
;; Local Variables:
;; no-byte-compile: t
;; End:
