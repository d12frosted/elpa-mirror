(define-package "pg" "20231214.1514" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "28.1"))
  :commit "80ce2de9d3705a481afa76bd2536a5bf36e3850e" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
