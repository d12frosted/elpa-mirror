;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cool-mode" "20231026.456"
  "Major mode for cool compiler language."
  '((emacs "25"))
  :url "https://github.com/nverno/cool-mode"
  :commit "46b6a38a99a954c5e77e90506eafec4092690692"
  :revdesc "46b6a38a99a9"
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
