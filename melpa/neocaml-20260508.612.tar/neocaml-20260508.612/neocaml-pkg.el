;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260508.612"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "18f549a2e52c625b5739a54d97dadcad31c37604"
  :revdesc "18f549a2e52c"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
