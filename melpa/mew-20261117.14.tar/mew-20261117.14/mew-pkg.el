;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261117.14"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "b9acbe48c553110e7d287d99871f14616ded7c71"
  :revdesc "b9acbe48c553")
