;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260411.2046"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "cc48ae34365feac56e014409bc99bf975bb1a80e"
  :revdesc "cc48ae34365f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
