;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20250401.1521"
  "An unofficial Copilot plugin."
  '((emacs        "27.2")
    (editorconfig "0.8.2")
    (jsonrpc      "1.0.14")
    (f            "0.20.0"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "0951cc6444bb89fd7c7adfd986457d9c92d7eac2"
  :revdesc "0951cc6444bb"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Rakotomandimby Mihamina" . "mihamina.rakotomandimby@rktmb.org")))
