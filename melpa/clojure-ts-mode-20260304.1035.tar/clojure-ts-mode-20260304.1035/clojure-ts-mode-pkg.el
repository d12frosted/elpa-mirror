;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20260304.1035"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "https://github.com/clojure-emacs/clojure-ts-mode"
  :commit "551a3bafa07457d7b78b34b60abe67b43f334545"
  :revdesc "551a3bafa074"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
