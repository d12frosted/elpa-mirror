(define-package "js2-mode" "20210712.202" "Improved JavaScript editing mode"
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "be49133767ea9e0210f15ba631dc731ec9eabd64" :authors
  '(("Steve Yegge" . "steve.yegge@gmail.com")
    ("mooz" . "stillpedant@gmail.com")
    ("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Steve Yegge" . "steve.yegge@gmail.com")
  :keywords
  '("languages" "javascript")
  :url "https://github.com/mooz/js2-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
