(define-package "dix" "20200108.1057" "Apertium XML editing minor mode"
  '((cl-lib "0.5")
    (emacs "24.4"))
  :commit "391832823f3f9835d957bc0224e122b376e5d825" :keywords
  ("languages")
  :authors
  (("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  ("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :url "http://wiki.apertium.org/wiki/Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
