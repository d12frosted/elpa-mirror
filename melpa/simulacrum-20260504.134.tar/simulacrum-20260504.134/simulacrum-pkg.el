;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simulacrum" "20260504.134"
  "Inject custom event types into the event stream."
  '((emacs "29.1"))
  :url "https://github.com/ErikPrantare/simulacrum.el"
  :commit "3a42993a3793160b532fc30d88d76b2965822f65"
  :revdesc "3a42993a3793"
  :keywords '("convenience"))
