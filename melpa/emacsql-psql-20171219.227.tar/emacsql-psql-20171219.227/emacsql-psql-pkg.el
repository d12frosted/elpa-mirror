(define-package "emacsql-psql" "20171219.227" "EmacSQL back-end for PostgreSQL via psql"
  '((emacs "25.1")
    (emacsql "2.0.0"))
  :commit "9dca5996168c4963eb67e61c7f17fdcb8228e314" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
