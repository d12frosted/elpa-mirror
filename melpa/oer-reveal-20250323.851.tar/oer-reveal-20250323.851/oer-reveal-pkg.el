;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "20250323.851"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.35.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "0110a87ea5b0a7a98bc591de984b394eccaa7d4a"
  :revdesc "0110a87ea5b0"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
