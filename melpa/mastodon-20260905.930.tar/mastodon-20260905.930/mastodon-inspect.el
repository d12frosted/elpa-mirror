;;; mastodon-inspect.el --- Client for Mastodon  -*- lexical-binding: t -*-

;; Copyright (C) 2017-2019 Johnson Denen
;; Copyright (C) 2020-2024 Marty Hiatt
;; Author: Johnson Denen <johnson.denen@gmail.com>
;;         Marty Hiatt <martianh@disroot.org>
;; Maintainer: Marty Hiatt <martianh@disroot.org>
;; Homepage: https://codeberg.org/martianh/mastodon.el

;; This file is not part of GNU Emacs.

;; This file is part of mastodon.el.

;; mastodon.el is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; mastodon.el is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with mastodon.el.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; Some tools to help inspect / debug mastodon.el

;;; Code:
(autoload 'mastodon-http--api "mastodon-http")
(autoload 'mastodon-http--get-json "mastodon-http")
(autoload 'mastodon-http--get-search-json "mastodon-http")
(autoload 'mastodon-media--inline-images "mastodon-media")
(autoload 'mastodon-mode "mastodon")
(autoload 'mastodon-tl--as-string "mastodon-tl")
(autoload 'mastodon-tl--property "mastodon-tl")
(autoload 'mastodon-tl--toot "mastodon-tl")

(defvar mastodon-instance-url)

(defgroup mastodon-inspect nil
  "Tools to help inspect toots."
  :prefix "mastodon-inspect-"
  :group 'external)

(defcustom mastodon-inspect-profile-requests nil
  "Whether to profile requests info.
Parses outpout of function `url-debug' to list what requests a given
timeline entails."
  :type '(boolean))

(defun mastodon-inspect--dump-json-in-buffer (name json)
  "Buffer NAME is opened and JSON in printed into it."
  (switch-to-buffer-other-window name)
  (erase-buffer)
  (let ((print-level nil)
        (print-length nil))
    (pp json (current-buffer))
    (goto-char (point-min))
    (emacs-lisp-mode)
    (message "success")))

(defun mastodon-inspect--toot ()
  "Find next toot and dump its meta data into new buffer."
  (interactive)
  (mastodon-inspect--dump-json-in-buffer
   (concat "*mastodon-inspect-toot-"
           (mastodon-tl--as-string (mastodon-tl--property 'item-id))
           "*")
   (mastodon-tl--property 'item-json)))

(defun mastodon-inspect--download-single-toot (item-id)
  "Download the toot/status represented by ITEM-ID."
  (mastodon-http--get-json
   (mastodon-http--api (concat "statuses/" item-id))))

(defun mastodon-inspect--view-single-toot (item-id)
  "View the toot/status represented by ITEM-ID."
  (interactive "s Toot ID: ")
  (let ((buffer (get-buffer-create (concat "*mastodon-status-" item-id "*"))))
    (with-current-buffer buffer
      (let ((toot (mastodon-inspect--download-single-toot item-id )))
        (mastodon-tl--toot toot)
        (goto-char (point-min))
        (while (search-forward "\n\n\n | " nil t)
          (replace-match "\n | "))
        (mastodon-media--inline-images (point-min) (point-max))))
    (switch-to-buffer-other-window buffer)
    (mastodon-mode)))

(defun mastodon-inspect--view-single-toot-source (item-id)
  "View the ess source of a toot/status represented by ITEM-ID."
  (interactive "s Toot ID: ")
  (mastodon-inspect--dump-json-in-buffer
   (concat "*mastodon-status-raw-" item-id "*")
   (mastodon-inspect--download-single-toot item-id)))


(defvar mastodon-inspect--search-query-accounts-result)
(defvar mastodon-inspect--single-account-json)

(defvar mastodon-inspect--search-query-full-result)
(defvar mastodon-inspect--search-result-tags)

(defun mastodon-inspect--get-search-result (query)
  "Inspect function for a search result for QUERY."
  (interactive)
  (setq mastodon-inspect--search-query-full-result
        (append ; convert vector to list
         (mastodon-http--get-search-json
         (format "%s/api/v2/search" mastodon-instance-url)
         query)
         nil))
  (setq mastodon-inspect--search-result-tags
        (append (cdr
                 (caddr mastodon-inspect--search-query-full-result))
                nil)))

(defun mastodon-inspect--get-search-account (query)
  "Return JSON for a single account after search QUERY."
  (interactive)
  (setq mastodon-inspect--search-query-accounts-result
        (append ; convert vector to list
         (mastodon-http--get-search-json
          (format "%s/api/v1/accounts/search" mastodon-instance-url)
          query)
         nil))
  (setq mastodon-inspect--single-account-json
        (car mastodon-inspect--search-query-accounts-result)))

(require 'url-util)

(defun mastodon-inspect-profile-requests (&optional endpoint host)
  "Enable variable `url-debug' and call `mastodon-inspect-requests'.
Function to insert into timeline and other view loading functions.
Deletes contents of *URL-DEBUG* after calling `mastodon-inspect-requests'.
ENDPOINT is a string, to create a heading for a group of
requests.
HOST is a top level domain to filter requests for."
  (setq url-debug t)
  (when (get-buffer "*URL-DEBUG*")
    ;; before the new request: list previous set:
    (mastodon-inspect-requests endpoint (or host
                            (url-host
                             (url-generic-parse-url
                              mastodon-instance-url))))
    (with-current-buffer "*URL-DEBUG*"
      ;; then delete previous set:
      (erase-buffer))))

(defun mastodon-inspect-reqs-by-host (reqs host)
  "Return only the REQS whose host equals HOST."
  (cl-remove-if-not
   (lambda (x) ;; list of all reqs
     (let ((req-host (car (member-if
                           (lambda (y) (string-prefix-p "Host: " y))
                           x))))
       (when req-host
         (string= host (cadr (split-string req-host))))))
   reqs))

(defun mastodon-inspect-reqs-by-verb (reqs)
  "Filter all REQS for their Verb/Endpoint line.
Return a list."
  (flatten-list
   (mapcar
    (lambda (x) ;; reqs list
      (mapcar
       (lambda (y) ;; req strs
         (when (member (car (split-string y))
                       '("GET" "PUT" "POST" "PATCH" "DELETE"))
           y))
       x))
    reqs)))

(defun mastodon-inspect-requests (&optional endpoint host)
  "Collect recent url.el requests into a buffer.
Filters *URL-DEBUG* for requests, dumps them into *masto-requests*. Note
that for simplicity's sake in handling async requests, we collect all
the requests made until just *before* the page being loaded (and since
the last one).
ENDPOINT is a string, to create a heading for a group of
requests.
HOST is a top level domain to filter requests for."
  (with-current-buffer "*URL-DEBUG*"
    (let* ((list (split-string (buffer-string) "http -> Request is:"))
           (split-lists (mapcar (lambda (x)
                                  (split-string x "\n"))
                                list))
           (by-host (mastodon-inspect-reqs-by-host split-lists host))
           (verbs (mastodon-inspect-reqs-by-verb by-host)))
      (with-current-buffer
          (get-buffer-create "*masto-requests*")
        (goto-char (point-max))
        (insert
         (format "\n\n***\nCalls *before* hitting endpoint: %s\n%s"
                 (or endpoint "")
                 (mapconcat #'identity verbs "\n")))))))

(provide 'mastodon-inspect)
;;; mastodon-inspect.el ends here
