;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260905.930"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "47438191baf258ad0b53d47b0845c47eccf0300b"
  :revdesc "47438191baf2"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
