(define-package "loopy" "20210725.1541" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "0f0093f6319ad1ddc5e36b3999fc1061b7d96da9" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
