;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260720.923"
  "Major mode for Godot's GDScript language."
  '((emacs "29.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "5ea9bb0a2ee3b3845918084bbb422391dfcc852c"
  :revdesc "5ea9bb0a2ee3"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
