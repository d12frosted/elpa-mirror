;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260217.724"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.10.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "81d48fba6830f6d2de801e66512fe1ddb2835725"
  :revdesc "81d48fba6830")
