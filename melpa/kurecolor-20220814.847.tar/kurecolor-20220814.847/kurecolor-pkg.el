(define-package "kurecolor" "20220814.847" "color editing goodies"
  '((emacs "28.1")
    (s "1.12"))
  :commit "ad75b8bc40144322b9d0477368f45c05eada1c5d" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
