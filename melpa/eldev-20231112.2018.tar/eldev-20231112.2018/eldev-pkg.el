(define-package "eldev" "20231112.2018" "Elisp development tool"
  '((emacs "24.4"))
  :commit "f6fdcf8031e5cdf9e92c1ec77ee06f0114c66b27" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/emacs-eldev/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
