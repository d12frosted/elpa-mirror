;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20251117.1355"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.5"))
  :url "https://github.com/joaotavora/sly"
  :commit "daefb5384cf4836842c215ba990a31cce49bd9c3"
  :revdesc "daefb5384cf4"
  :keywords '("languages" "lisp" "sly"))
