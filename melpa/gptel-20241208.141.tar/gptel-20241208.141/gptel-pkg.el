;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241208.141"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "983a9dfbf87f526efe2cfcf8a749f51ce466beaa"
  :revdesc "983a9dfbf87f"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
