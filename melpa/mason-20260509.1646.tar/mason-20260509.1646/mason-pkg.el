;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20260509.1646"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/mason-org/mason.el"
  :commit "7ac4f01f8ace020cf19c41544722421d3e8f26df"
  :revdesc "7ac4f01f8ace"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
