;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-toggle" "20150226.1411"
  "Toggle to and from the shell buffer."
  ()
  :url "https://github.com/knu/shell-toggle.el"
  :commit "0d01bd9a780fdb7fe6609c552523f4498649a3b9"
  :revdesc "0d01bd9a780f"
  :keywords '("processes")
  :authors '(("Mikael Sjödin" . "mic@docs.uu.se")
             ("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Mikael Sjödin" . "mic@docs.uu.se")
                 ("Akinori MUSHA" . "knu@iDaemons.org")))
