;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251020.959"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "217e8961d3f82eca64684c4245f5448b1af3d4e6"
  :revdesc "217e8961d3f8"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
