;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pomm" "20251223.1344"
  "Pomodoro and Third Time timers."
  '((emacs     "27.1")
    (alert     "1.2")
    (seq       "2.22")
    (transient "0.3.0"))
  :url "https://github.com/SqrtMinusOne/pomm.el"
  :commit "f198afa7519c365d1d929e7f468caed415df1c43"
  :revdesc "f198afa7519c"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
