;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsdoc" "20241227.1219"
  "Insert JSDoc comments."
  '((emacs "29.1")
    (dash  "2.11.0")
    (s     "1.12.0"))
  :url "https://github.com/isamert/jsdoc.el"
  :commit "623994bb50d845de487c100f5cd393ce1d792460"
  :revdesc "623994bb50d8"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
