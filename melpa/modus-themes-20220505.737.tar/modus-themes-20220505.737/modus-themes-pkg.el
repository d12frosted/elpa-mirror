(define-package "modus-themes" "20220505.737" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "842c672a81cf976b47f0fb6ae13bcf13ee774024" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
