;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260820.2036"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "90c3ace5f00f6388473c8f02f10b3e450db05803"
  :revdesc "90c3ace5f00f"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
