;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "po-mode" "20260102.409"
  "Major mode for GNU gettext PO files."
  '((emacs "23"))
  :url "https://github.com/emacsmirror/po-mode"
  :commit "5500e864a5aab5254efd7da11b57faefec08134e"
  :revdesc "5500e864a5aa"
  :keywords '("i18n" "gettext"))
