(define-package "ekg" "20240721.426" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.17.0"))
  :commit "d54ddd2a18f54434cde78cc1be09d0d4cfe5def2" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
