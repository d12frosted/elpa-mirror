;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marron-gold-theme" "20250224.923"
  "A rich marron-gold theme."
  '((emacs "24.1"))
  :url "https://github.com/madara123pain/unique-emacs-theme-pack"
  :commit "ae9a0c318c371ed70ec568f3a618d47124817fe7"
  :revdesc "ae9a0c318c37"
  :keywords '("faces" "theme" "marron" "gold" "warm" "elegant"))
