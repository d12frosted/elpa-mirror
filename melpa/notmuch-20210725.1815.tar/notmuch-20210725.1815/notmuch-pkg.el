(define-package "notmuch" "20210725.1815" "run notmuch within emacs" 'nil :commit "7415b53fa568a3156ae3e3a47544a4784e024653" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
