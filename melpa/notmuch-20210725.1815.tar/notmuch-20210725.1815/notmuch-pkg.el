(define-package "notmuch" "20210725.1815" "run notmuch within emacs" 'nil :commit "e8fa42a97a2e98fecb5cabdbeac6c7ad0b936b7d" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
