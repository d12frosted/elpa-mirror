(define-package "detached" "20221013.1315" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "e02efdbfd87580907b847d5d069a40dd6520a23b" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
