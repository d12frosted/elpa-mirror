(define-package "spdx" "20230622.118" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "7181521e7a6e725d8816a993f8364f8e0fd7d6f4" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
