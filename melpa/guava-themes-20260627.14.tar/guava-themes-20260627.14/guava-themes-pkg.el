;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260627.14"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "30480e4397098c2019a8f30b025f70f7ca4e8961"
  :revdesc "30480e439709"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
