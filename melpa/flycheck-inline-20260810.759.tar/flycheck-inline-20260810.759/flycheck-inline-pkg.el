;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-inline" "20260810.759"
  "Display Flycheck errors inline."
  '((emacs    "25.1")
    (flycheck "32"))
  :url "https://github.com/flycheck/flycheck-inline"
  :commit "ac651c6b3101c32eb615d454a4214c4fbd9e1260"
  :revdesc "ac651c6b3101"
  :keywords '("tools" "convenience"))
