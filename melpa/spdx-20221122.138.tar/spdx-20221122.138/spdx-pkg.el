(define-package "spdx" "20221122.138" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "0ad354dd6d113cab4943dcad6c18e3c73bff9e64" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
