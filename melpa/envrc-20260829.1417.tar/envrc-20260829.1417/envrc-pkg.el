;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "20260829.1417"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "914b2e51945eb356b7b7fef552acd3c54ff23f14"
  :revdesc "914b2e51945e"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
