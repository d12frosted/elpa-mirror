;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nordic-night-theme" "20251129.409"
  "A darker, more colorful version of the lovely Nord theme."
  '((emacs "24.1"))
  :url "https://codeberg.org/ashton314/nordic-night"
  :commit "5d35f9c9da0ab7138b0a4897daaf52d78f4a1a37"
  :revdesc "5d35f9c9da0a"
  :authors '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers '(("Ashton Wiersdorf" . "mail@wiersdorf.dev")))
