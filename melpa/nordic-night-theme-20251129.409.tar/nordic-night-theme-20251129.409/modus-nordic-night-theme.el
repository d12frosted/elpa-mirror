;; -*- lexical-binding: t; -*-

(require 'modus-themes)

(defgroup nordic-night-themes ()
  "Darkness."
  :group 'faces
  :group 'modus-themes
  :prefix "nordic-night-themes-")

(defconst nordic-night-dark-themes '(nordic-night nordic-midnight))

(modus-themes-register 'nordic-night)
(modus-themes-register 'nordic-midnight)

(defconst modus-nordic-night-base-colors
  '((bg-07 "#3f4f4f")
    (bg-08 "#3d5056")
    (bg-09 "#3b4551")
    (bg-10 "#233949")
    (bg-11 "#512e31")
    (bg-12 "#573d35")
    (bg-13 "#61553d")
    (bg-14 "#46503e")
    (bg-15 "#4c3e4a")))

;; Shared palette elements
(defconst modus-nordic-night-palette-shared
  '((cursor "#d8dee9")
    (fg-main "#d8dee9")
    (fg-dim "#8892a4")
    (fg-alt "#b5bdcc")
    (border "#6b7386")

    (red "#bf616a")
    (green "#a3be8c")
    (yellow "#ebcb8b")
    (yellow-warmer "#d08770")
    (blue "#5e81ac")
    (blue-warmer "#81a1c1")
    (blue-cooler "#88c0d0")
    (blue-faint "#8fbcbb")
    (magenta "#b48ead")

    (bg-red-subtle "#512e31")
    (bg-green-subtle "#46503e")
    (bg-yellow-subtle "#61553d")
    (bg-blue-subtle "#233949")
    (bg-magenta-subtle "#4c3e4a")
    (bg-cyan-subtle "#3d5056")

    (bg-added "#00381f")
    (bg-added-faint "#002910")
    (bg-added-refine "#034f2f")
    (fg-added "#a0e0a0")

    (bg-changed "#363300")
    (bg-changed-faint "#2a1f00")
    (bg-changed-refine "#4a4a00")
    (fg-changed "#efef80")

    (bg-removed "#4f1119")
    (bg-removed-faint "#380a0f")
    (bg-removed-refine "#781a1f")
    (fg-removed "#ffbfbf")

    (bg-completion "#0f2d4a")
    (bg-hover "#004a5f")
    (bg-hover-secondary "#551f5a")
    (bg-paren-match "#20577a")
    (bg-err "#461210")
    (bg-warning "#3a3004")
    (bg-info "#10350a")

    (err red)
    (warning yellow)
    (info green)

    (fg-link cyan)
    (fg-link-alt magenta)
    (name blue-warmer)
    (keybind blue-cooler)
    (identifier magenta)
    (prompt green)

    (builtin blue-warmer)
    (comment fg-dim)
    (constant blue-cooler)
    (fnname magenta)
    (fnname-call magenta)
    (keyword magenta)
    (preprocessor blue)
    (docstring green)
    (string green)
    (type green)
    (variable blue-cooler)
    (variable-use blue-warmer)
    (rx-escape yellow)
    (rx-construct yellow-warmer)

    (accent-0 blue)
    (accent-1 magenta)
    (accent-2 green)
    (accent-3 red)

    (date-common green)
    (date-deadline red)
    (date-deadline-subtle red)
    (date-event fg-alt)
    (date-holiday magenta)
    (date-now fg-main)
    (date-range fg-alt)
    (date-scheduled yellow)
    (date-scheduled-subtle yellow)
    (date-weekday cyan)
    (date-weekend red)

    (prose-code magenta)
    (prose-done green)
    (prose-macro green)
    (prose-metadata fg-dim)
    (prose-metadata-value fg-alt)
    (prose-table fg-alt)
    (prose-table-formula err)
    (prose-tag yellow)
    (prose-todo red)
    (prose-verbatim blue)

    (mail-cite-0 blue)
    (mail-cite-1 magenta)
    (mail-cite-2 green)
    (mail-cite-3 yellow)
    (mail-part magenta)
    (mail-recipient blue-warmer)
    (mail-subject blue-cooler)
    (mail-other cyan)

    (bg-search-static bg-green-subtle)
    (bg-search-current bg-cyan-subtle)
    (bg-search-lazy bg-blue-subtle)
    (bg-search-replace bg-magenta-subtle)

    (bg-search-rx-group-0 bg-magenta-intense)
    (bg-search-rx-group-1 bg-green-intense)
    (bg-search-rx-group-2 bg-red-subtle)
    (bg-search-rx-group-3 bg-cyan-subtle)

    (bg-space-err bg-yellow-intense)

    (rainbow-0 green)
    (rainbow-1 blue)
    (rainbow-2 magenta)
    (rainbow-3 cyan)
    (rainbow-4 yellow)
    (rainbow-5 magenta)
    (rainbow-6 red)
    (rainbow-7 green)
    (rainbow-8 yellow)))

;; ;; Nordic-Night specific (lighter background)
;; (defconst modus-nordic-night-palette-partial
;;   (append
;;    '((bg-main "#121212")
;;      (bg-dim "#181818")
;;      (bg-alt "#202024")
;;      (bg-active "#434c5e")
;;      (bg-inactive "#2e3440")

;;      (bg-mode-line-active "#434c5e")
;;      (fg-mode-line-active "#d8dee9")
;;      (bg-mode-line-inactive "#2e3440")
;;      (fg-mode-line-inactive "#5e81ac")
;;      (border-mode-line-active unspecified)
;;      (border-mode-line-inactive unspecified)

;;      (bg-tab-bar current)
;;      (bg-tab-current "#2e3440")
;;      (bg-tab-other bg-tab-bar)

;;      (bg-region "#3d5056")
;;      (bg-hl-line "#202024"))
;;    modus-nordic-night-palette-shared))

(defvar modus-nordic-night-palette
  (modus-themes-generate-palette
   '(

     ;; Background colors
     (bg-07 "#3f4f4f")
     (bg-08 "#3d5056")
     (bg-09 "#3b4551")
     (bg-10 "#233949")
     (bg-11 "#512e31")
     (bg-12 "#573d35")
     (bg-13 "#61553d")
     (bg-14 "#46503e")
     (bg-15 "#4c3e4a")

     ;; Extended nord colors
     (nn-dark1 "#121212")
     (nn-dark2 "#18181a")
     (nn-dark3 "#202024")
     (nn-light1 "#6b7386")
     (nn-light2 "#8892a4")
     (nn-light3 "#b5bdcc")

     ;; Main theme colors
     (bg-main "#121212")		; nn-dark1
     (bg-dim  "#18181a")		; nn-dark2
     (bg-alt  "#202024")
     (fg-main "#d8dee9")
     (fg-dim  "#8892a4")
     (fg-alt  "#b5bdcc")

     ;; Base theme colors
     (red "#bf616a")
     (green "#a3be8c")
     (yellow "#ebcb8b")
     (yellow-warmer "#d08770")
     (blue "#5e81ac")
     (blue-warmer "#81a1c1")
     (blue-faint "#8fbcbb")
     (cyan "#88c0d0")
     (magenta "#b48ead"))
   'cool))

(defconst modus-nordic-night-palette-partial
  '(
    (bg-mode-line-active "#434c5e")
    (fg-mode-line-active "#d8dee9")
    (bg-mode-line-inactive "#2e3440")
    (fg-mode-line-inactive blue)
    (border-mode-line-active unspecified)
    (border-mode-line-inactive unspecified)

    (bg-completion bg-10)

    (builtin blue-warmer)
    (comment fg-dim)
    (constant blue-cooler)
    (fnname magenta)
    (fnname-call magenta)
    (keyword magenta)
    (preprocessor blue)
    (docstring green)
    (string green)
    (type green)
    (variable blue-cooler)
    (variable-use blue-warmer)
    (rx-escape yellow)
    (rx-construct yellow-warmer)

    (bg-tab-bar bg-mode-line-inactive)
    (bg-tab-current bg-mode-line-active)
    (bg-tab-other bg-tab-bar)

    (bg-region "#3d5056")
    (bg-hl-line "#202024")
    ))

(defcustom modus-nordic-night-palette-overrides nil
  "Overrides for nordic-night palette.")

(defconst modus-nordic-night-custom-faces
  '(
    `(tab-bar ((,c (:background ,bg-tab-bar))))
    `(tab-bar-tab-inactive ((,c :foreground ,blue))))
  )

(modus-themes-theme
 'modus-nordic-night
 'nordic-themes
 "Darker, higher-contrast version of the Nord theme."
 'dark                                  ; this is a dark theme
 'modus-nordic-night-palette            ; base
 'modus-nordic-night-palette-partial    ; theme definitions
 'modus-nordic-night-palette-overrides  ; overrides
 'modus-nordic-night-custom-faces)      ; extra theme tweaks

;;;###autoload
(when (and (boundp 'custom-theme-load-path) load-file-name)
  (add-to-list 'custom-theme-load-path
               (file-name-as-directory (file-name-directory load-file-name))))

(provide 'modus-nordic-night-theme)
