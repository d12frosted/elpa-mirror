;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260719.56"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "4b8e56ce6545de9b33ddb841f535c5f1ec301e00"
  :revdesc "4b8e56ce6545"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
