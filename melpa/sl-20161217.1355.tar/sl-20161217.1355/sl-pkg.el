(define-package "sl" "20161217.1355" "An Emacs clone of sl(1)"
  '((cl-lib "0.5"))
  :commit "51d92f820f3e93776fff6cdb9690458816888bdc" :authors
  '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainer
  '("Chunyang Xu" . "mail@xuchunyang.me")
  :url "https://github.com/xuchunyang/sl.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
