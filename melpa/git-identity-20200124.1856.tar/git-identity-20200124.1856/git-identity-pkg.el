(define-package "git-identity" "20200124.1856" "Identity management for (ma)git"
  '((emacs "25.1")
    (dash "2.10")
    (hydra "0.14")
    (f "0.20"))
  :commit "d5b8dcfc9f93aecfcd9c6fb212742c165d48173f" :authors
  '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainer
  '("Akira Komamura" . "akira.komamura@gmail.com")
  :keywords
  '("git" "vc" "convenience")
  :url "https://github.com/akirak/git-identity.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
