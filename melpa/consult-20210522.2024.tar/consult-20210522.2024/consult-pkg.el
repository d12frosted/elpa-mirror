(define-package "consult" "20210522.2024" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "5fd1db621a7dad35734791c27846653d4dea65d6" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
