(define-package "vertico" "20231107.2028" "VERTical Interactive COmpletion"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "a7e1f53dd1e79f9102c3c03681d2e6980cd2cbb4" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "files" "matching" "completion")
  :url "https://github.com/minad/vertico")
;; Local Variables:
;; no-byte-compile: t
;; End:
