(define-package "org-projectile" "20230813.1939" "Repository todo management for org-mode"
  '((projectile "0.11.0")
    (dash "2.10.0")
    (emacs "24")
    (s "1.9.0")
    (org-category-capture "0.0.0"))
  :commit "b904009a4f2f28ce9748e55730b6a419a516549e" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "projectile" "todo" "tools" "outlines")
  :url "https://github.com/IvanMalison/org-projectile")
;; Local Variables:
;; no-byte-compile: t
;; End:
