;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "20261112.725"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "6140c5b23e39891311304e70d0f933e9dcd0cc50"
  :revdesc "6140c5b23e39"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
