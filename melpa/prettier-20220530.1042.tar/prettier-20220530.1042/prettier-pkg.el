(define-package "prettier" "20220530.1042" "Code formatting with Prettier"
  '((emacs "26.1")
    (iter2 "0.9")
    (nvm "0.2"))
  :commit "5c0304876b68a4faf125a039451098bd448a49bf" :authors
  '(("Julian Scheid" . "julians37@gmail.com"))
  :maintainer
  '("Julian Scheid" . "julians37@gmail.com")
  :keywords
  '("convenience" "languages" "files")
  :url "https://github.com/jscheid/prettier.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
