;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20250313.1652"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.22.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "306073dae3b72a41140256f390e5374b7203e61e"
  :revdesc "306073dae3b7"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
