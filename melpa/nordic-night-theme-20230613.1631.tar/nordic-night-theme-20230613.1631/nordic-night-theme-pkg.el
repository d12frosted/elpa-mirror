(define-package "nordic-night-theme" "20230613.1631" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "0506e26c99a040fc8d2672401b40820bce2ea455" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
