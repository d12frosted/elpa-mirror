(define-package "modus-themes" "20220731.642" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "966a526006c003b3ae275bce28e711af2ea4c389" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
