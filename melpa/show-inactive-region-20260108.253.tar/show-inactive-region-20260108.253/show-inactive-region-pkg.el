;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-inactive-region" "20260108.253"
  "Highlight the inactive region."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-show-inactive-region"
  :commit "e73aac8dd1b3ef690722afe6f8f3a444f2a1a3e0"
  :revdesc "e73aac8dd1b3"
  :keywords '("convenience" "faces")
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
