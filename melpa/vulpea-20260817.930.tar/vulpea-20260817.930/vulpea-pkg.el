;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260817.930"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "2277d70c80f47ea892e9030aed0462e2ff29003b"
  :revdesc "2277d70c80f4"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
