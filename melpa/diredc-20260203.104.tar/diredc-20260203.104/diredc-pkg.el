;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260203.104"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "1c8820a81f48998d661d2867b41802f441514ab1"
  :revdesc "1c8820a81f48"
  :keywords '("files"))
