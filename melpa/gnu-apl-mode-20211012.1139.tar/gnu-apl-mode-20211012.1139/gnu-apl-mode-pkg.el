(define-package "gnu-apl-mode" "20211012.1139" "Integrate GNU APL with Emacs"
  '((emacs "27"))
  :commit "5d998206a963f2205dc6c4eddb41fb34187cb527" :authors
  '(("Elias Mårtenson" . "lokedhs@gmail.com"))
  :maintainer
  '("Elias Mårtenson" . "lokedhs@gmail.com")
  :keywords
  '("languages")
  :url "http://www.gnu.org/software/apl/")
;; Local Variables:
;; no-byte-compile: t
;; End:
