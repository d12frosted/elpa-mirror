(define-package "liberime" "20211203.244" "Rime elisp binding"
  '((emacs "25.1"))
  :commit "79b709debe036f98d74ac129934e59c4d08c1dd5" :authors
  '(("A.I."))
  :maintainer
  '("A.I.")
  :keywords
  '("convenience" "chinese" "input-method" "rime")
  :url "https://github.com/merrickluo/liberime")
;; Local Variables:
;; no-byte-compile: t
;; End:
