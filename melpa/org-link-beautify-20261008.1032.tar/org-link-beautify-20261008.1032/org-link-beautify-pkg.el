;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20261008.1032"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "3815a7b7cb56181f63af118d832fe7317656c7c1"
  :revdesc "3815a7b7cb56"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
