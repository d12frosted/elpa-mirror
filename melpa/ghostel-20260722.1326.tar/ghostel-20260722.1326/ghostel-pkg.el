;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260722.1326"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "14c399002f47405a623604170314e27d260efb30"
  :revdesc "14c399002f47"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
