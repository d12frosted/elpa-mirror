;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "preview-dvisvgm" "20211225.635"
  "SVG output for LaTeX preview."
  '((emacs  "27.1")
    (auctex "13.0.12"))
  :url "https://github.com/TobiasZawada/preview-dvisvgm"
  :commit "630e2f008c4a6c67a01824b7ad6b844977b28f87"
  :revdesc "630e2f008c4a"
  :keywords '("tex")
  :authors '(("Tobias Zawada" . "i@tn-home.de"))
  :maintainers '(("Tobias Zawada" . "i@tn-home.de")))
