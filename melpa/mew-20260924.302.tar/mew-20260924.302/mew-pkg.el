;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260924.302"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "2bc105b712b2894bfeb3f23c3eee0987b9fa6977"
  :revdesc "2bc105b712b2")
