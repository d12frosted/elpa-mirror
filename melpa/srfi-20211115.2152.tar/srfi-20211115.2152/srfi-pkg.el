(define-package "srfi" "20211115.2152" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "511ddc9af06b1b29d033d95674479269990564dc" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
