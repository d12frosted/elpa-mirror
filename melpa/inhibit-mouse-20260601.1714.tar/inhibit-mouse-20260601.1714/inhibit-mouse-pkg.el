;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "20260601.1714"
  "Deactivate mouse input (alternative to disable-mouse)."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "0cf06ed22cd416f89e641cdc35ff4b8ad805f216"
  :revdesc "0cf06ed22cd4"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
