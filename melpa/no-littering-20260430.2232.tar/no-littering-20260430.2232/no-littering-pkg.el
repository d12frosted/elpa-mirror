;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260430.2232"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "1109ba226c2c1a1ce47ce4e6ddeabf3de53858e4"
  :revdesc "1109ba226c2c"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
