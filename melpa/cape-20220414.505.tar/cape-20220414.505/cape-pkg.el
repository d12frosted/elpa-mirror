(define-package "cape" "20220414.505" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "0a618040aa4adaa4f42bcc9cd65491453e2e6253" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
