(define-package "yatex" "20220929.123" "Yet Another tex-mode for emacs //野鳥//" 'nil :commit "923a6c0183be469fb4f94b1258527f2ca1cc5b79")
;; Local Variables:
;; no-byte-compile: t
;; End:
