;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250509.1325"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f2220314dd02c8766c436e0dc365957a75f62c7a"
  :revdesc "f2220314dd02"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
