;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260729.1933"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "417b38fdb8ba810e981c1aa25288ccfb82df63a3"
  :revdesc "417b38fdb8ba")
