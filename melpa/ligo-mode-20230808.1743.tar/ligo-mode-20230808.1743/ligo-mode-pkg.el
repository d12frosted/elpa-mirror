(define-package "ligo-mode" "20230808.1743" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "2d557873ccd14e03e3ad42ed46a88571f4eeafab" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
