(define-package "tzc" "20240402.1953" "Converts time between different time zones"
  '((emacs "28.1"))
  :commit "3ed8bf4462438595cab47141d6bce529ac7594b3" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/md-arif-shaikh/tzc")
;; Local Variables:
;; no-byte-compile: t
;; End:
