;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260627.1603"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e6711626d949584b5f8d787b381372b5ee4bb95e"
  :revdesc "e6711626d949"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
