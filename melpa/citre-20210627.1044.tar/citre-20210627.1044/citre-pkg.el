(define-package "citre" "20210627.1044" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "ed26e100d58811b5e6f4bffd3f3490fd5725e9f8" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
