;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "20261026.1409"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "4d971b14fbccacd04c8ec9290b694c8ad1bacac6"
  :revdesc "4d971b14fbcc"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
