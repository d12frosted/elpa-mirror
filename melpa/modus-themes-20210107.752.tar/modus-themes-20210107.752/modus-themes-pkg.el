(define-package "modus-themes" "20210107.752" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "a6ccffe0c166daec6906b3b9cdbfa82176eb971c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
