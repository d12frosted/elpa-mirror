;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "20260203.1935"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "5f5cb16dc76c22d80f69fb9413aa0d877bf13746"
  :revdesc "5f5cb16dc76c"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
