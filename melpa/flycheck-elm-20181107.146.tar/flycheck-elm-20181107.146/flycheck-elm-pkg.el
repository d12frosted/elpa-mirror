;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-elm" "20181107.146"
  "Flycheck support for the elm language."
  '((flycheck  "0.29-cvs")
    (emacs     "24.4")
    (let-alist "1.0.5")
    (seq       "2.20"))
  :url "https://github.com/bsermons/flycheck-elm"
  :commit "debd0af563cb6c2944367a691c7fa3021d9378c1"
  :revdesc "debd0af563cb")
