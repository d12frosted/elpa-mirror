(define-package "for" "20220906.1226" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "94dbfe7a2fbef46372b99ce8207ff129f2482425" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
