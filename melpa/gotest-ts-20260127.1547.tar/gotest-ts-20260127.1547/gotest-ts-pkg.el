;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gotest-ts" "20260127.1547"
  "Go test runner with tree-sitter support."
  '((emacs  "29.1")
    (gotest "0.16.0"))
  :url "https://github.com/chmouel/gotest-ts.el"
  :commit "b12e08d925bab705792f14b29acdca9af550d9a8"
  :revdesc "b12e08d925ba"
  :keywords '("languages" "go" "tests" "tree-sitter"))
