;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sniem" "20250204.1138"
  "Hands-eased united editing method."
  '((emacs "27.1")
    (s     "2.12.0")
    (dash  "1.12.0"))
  :url "https://github.com/SpringHan/sniem.git"
  :commit "89161d8b3c19ffba8b52411de36f28aec1e401f2"
  :revdesc "89161d8b3c19"
  :keywords '("convenience" "united-editing-method"))
