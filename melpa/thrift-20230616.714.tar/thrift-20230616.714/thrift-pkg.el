(define-package "thrift" "20230616.714" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "37e3b8f02da0c43287dd47cde4efdf5daff0a193" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
