;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-caldav" "20261115.1819"
  "Sync org files with external calendar through CalDAV."
  '((emacs "26.3")
    (org   "9.1"))
  :url "https://github.com/dengste/org-caldav/"
  :commit "d4e26d956f68fb5c6a30b30bd85d76ed8acb99f7"
  :revdesc "d4e26d956f68"
  :keywords '("calendar" "caldav")
  :authors '(("David Engster" . "deng@randomsample.de"))
  :maintainers '(("David Engster" . "deng@randomsample.de")))
