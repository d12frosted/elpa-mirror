(define-package "vhdl-ext" "20230917.1440" "VHDL Extensions"
  '((emacs "29.1")
    (vhdl-ts-mode "0.1.0")
    (eglot "1.9")
    (lsp-mode "8.0.0")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "32")
    (outshine "3.0.1")
    (async "1.9.7"))
  :commit "e6b27c716cfe62a2506c8c334ba292d0976874a6" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
