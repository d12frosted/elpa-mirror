;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsrs" "20251119.1629"
  "Free Spaced Repetition Scheduler."
  '((emacs "25.1"))
  :url "https://github.com/open-spaced-repetition/lisp-fsrs"
  :commit "3260544388b9239dc3710eb16ff202a279391260"
  :revdesc "3260544388b9"
  :keywords '("tools"))
