(define-package "detached" "20220701.1343" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "70ebb9488f2abe6b133101a696155106c7a44998" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
