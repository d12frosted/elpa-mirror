;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcord" "20260902.44"
  "Allows you to integrate Rich Presence from Discord."
  '((emacs "25.1"))
  :url "https://github.com/Mstrodl/elcord"
  :commit "e151753674883cc1420279981c0f719332122ea1"
  :revdesc "e15175367488"
  :keywords '("games")
  :authors '(("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com"))
  :maintainers '(("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com")))
