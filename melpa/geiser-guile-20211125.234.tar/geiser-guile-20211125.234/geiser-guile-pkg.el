(define-package "geiser-guile" "20211125.234" "Guile's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.18"))
  :commit "d24e673c5e2095f8add1fc1a72a5020f6fd18f33" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
