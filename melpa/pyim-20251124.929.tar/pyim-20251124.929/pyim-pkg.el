;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim" "20251124.929"
  "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "27.1")
    (async "1.6")
    (xr    "1.13"))
  :url "https://github.com/tumashu/pyim"
  :commit "9a6a4299e1312ed17d074072a0199eae5a583e85"
  :revdesc "9a6a4299e131"
  :keywords '("convenience" "chinese" "pinyin" "input-method")
  :authors '(("Ye Wenbin" . "wenbinye@163.com")
             ("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
