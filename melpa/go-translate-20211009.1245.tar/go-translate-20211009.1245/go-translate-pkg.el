(define-package "go-translate" "20211009.1245" "Translation"
  '((emacs "26.1"))
  :commit "249dd8b39fcc45de22b26ae08d19ce895aefcfab" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
