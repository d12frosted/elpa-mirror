(define-package "org-roam-ql" "20230820.2138" "Interface to query and view results from org-roam"
  '((emacs "28")
    (org-roam "2.2.0")
    (s "1.12.0")
    (magit-section "3.3.0")
    (transient "0.4")
    (org-super-agenda "1.2"))
  :commit "65dfb7da102e126f933e528e6b531cd77af96e6d" :authors
  '(("Shariff AM Faleel"))
  :maintainers
  '(("Shariff AM Faleel"))
  :maintainer
  '("Shariff AM Faleel")
  :url "https://github.com/ahmed-shariff/org-roam-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
