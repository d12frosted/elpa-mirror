(define-package "pygn-mode" "20210922.1338" "Major-mode for chess PGN files, powered by Python"
  '((emacs "26.1")
    (tree-sitter "0.15.2")
    (tree-sitter-langs "0.10.7")
    (uci-mode "0.5.4")
    (nav-flash "1.0.0")
    (ivy "0.10.0"))
  :commit "fed7b84350aab3aba27b0fca2ee53e4094307f7b" :authors
  '(("Dodge Coates and Roland Walker"))
  :maintainer
  '("Dodge Coates and Roland Walker")
  :keywords
  '("data" "games" "chess")
  :url "https://github.com/dwcoates/pygn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
