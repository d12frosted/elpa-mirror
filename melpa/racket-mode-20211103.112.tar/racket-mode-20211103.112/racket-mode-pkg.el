(define-package "racket-mode" "20211103.112" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "d78c7381bd47bae8e5f9ae14681935f08206240a" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
