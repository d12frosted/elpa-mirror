(define-package "wildcharm-theme" "20230817.450" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "7b7155cc6aaa73b1f1874c8537b6f28dd7722316" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
