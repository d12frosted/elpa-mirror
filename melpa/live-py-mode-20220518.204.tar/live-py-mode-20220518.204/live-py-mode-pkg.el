(define-package "live-py-mode" "20220518.204" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "ed8e93aaf77339e1b3d3133487c2b3670f884bdc" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
