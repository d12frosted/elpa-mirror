(define-package "live-py-mode" "20220518.204" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "a15df8b7076554077ade092c841cc7e61d68da5f" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
