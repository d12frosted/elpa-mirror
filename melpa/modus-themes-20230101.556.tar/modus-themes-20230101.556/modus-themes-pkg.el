(define-package "modus-themes" "20230101.556" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "70c6ae438619b3c6b59742c897ef769094f89165" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
