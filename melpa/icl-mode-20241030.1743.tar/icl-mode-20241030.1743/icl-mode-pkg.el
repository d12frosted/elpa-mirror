;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "icl-mode" "20241030.1743"
  "Support for IEEE 1687 ICL/PDL."
  '((emacs "25.2"))
  :url "https://github.com/CeleritasCelery/icl-mode"
  :commit "9cc7fbb7f290fd8c63795765cf309e8a57a49b14"
  :revdesc "9cc7fbb7f290"
  :authors '(("Troy Hinckley" . "troy.hinckley@dabrev.com"))
  :maintainers '(("Troy Hinckley" . "troy.hinckley@dabrev.com")))
