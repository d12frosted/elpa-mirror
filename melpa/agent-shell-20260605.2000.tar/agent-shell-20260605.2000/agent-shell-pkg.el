;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260605.2000"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "bfc3e727ec0eb20a0a9467b835ad0e6134e65c25"
  :revdesc "bfc3e727ec0e")
