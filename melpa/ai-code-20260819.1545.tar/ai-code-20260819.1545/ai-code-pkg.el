;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260819.1545"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "6c515b3061806240f64fd4d21954b543c077d21f"
  :revdesc "6c515b306180"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
