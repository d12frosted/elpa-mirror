(define-package "racket-mode" "20220330.1951" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "af9b760e7baca91e26723df6a31400cbfe6a627d" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
