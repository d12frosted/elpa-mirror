;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "20260128.1309"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "2962578f17494c4cfb3e1481a0cdd85de6b129d9"
  :revdesc "2962578f1749"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
