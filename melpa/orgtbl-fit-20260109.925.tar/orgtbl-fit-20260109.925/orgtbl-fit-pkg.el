;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-fit" "20260109.925"
  "Fit an Org Mode column using Calc regression methods."
  '((emacs "24.4"))
  :url "https://github.com/tbanel/orgtblfit/blob/master/README.org"
  :commit "987e1a8de9debb416c61a3e2e35b79c1bd9fa568"
  :revdesc "987e1a8de9de"
  :keywords '("data" "extensions"))
