(define-package "consult" "20210919.1618" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "dc6e45586194cb30b3ba7614189718f3db1391c3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
