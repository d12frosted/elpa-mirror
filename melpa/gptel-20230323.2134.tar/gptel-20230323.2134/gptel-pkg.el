(define-package "gptel" "20230323.2134" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "2b2dbe2664851cde53f4f03be41c158c5c45df0d" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
