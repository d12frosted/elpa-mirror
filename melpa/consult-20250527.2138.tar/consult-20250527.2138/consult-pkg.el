;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250527.2138"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "704eb983cc801ac0d403a6deb1b102698e65c26f"
  :revdesc "704eb983cc80"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
