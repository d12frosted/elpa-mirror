;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "20260216.52"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "cee2cadc5fbe05bd35eee916f2f13b97cab85147"
  :revdesc "cee2cadc5fbe"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
