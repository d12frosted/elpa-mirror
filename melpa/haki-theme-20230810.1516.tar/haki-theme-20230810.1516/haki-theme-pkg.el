(define-package "haki-theme" "20230810.1516" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "1508a65590aecb306d5cd5e740c243ec5fc6c503" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
