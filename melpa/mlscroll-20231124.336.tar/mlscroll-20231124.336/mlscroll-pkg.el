(define-package "mlscroll" "20231124.336" "A scroll bar for the modeline"
  '((emacs "27.1"))
  :commit "01ea3f85c3bd58f9c3d286947272ea69bd7db69e" :authors
  '(("J.D. Smith"))
  :maintainers
  '(("J.D. Smith"))
  :maintainer
  '("J.D. Smith")
  :keywords
  '("convenience")
  :url "https://github.com/jdtsmith/mlscroll")
;; Local Variables:
;; no-byte-compile: t
;; End:
