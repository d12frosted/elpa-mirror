(define-package "org-gtd" "20211229.214" "An implementation of GTD."
  '((emacs "27.1")
    (org-edna "1.1.2")
    (f "0.20.0")
    (org "9.3.1")
    (org-agenda-property "1.3.1")
    (transient "0.3.7"))
  :commit "2fdaeb0d16719b95e842079f502ac3cf78c74bdd" :authors
  '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainer
  '("Aldric Giacomoni" . "trevoke@gmail.com")
  :url "https://github.com/Trevoke/org-gtd.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
