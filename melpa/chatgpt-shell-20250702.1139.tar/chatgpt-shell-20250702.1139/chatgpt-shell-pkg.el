;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250702.1139"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.78.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "6fe897c417b23325151929708a85ede91d3708aa"
  :revdesc "6fe897c417b2")
