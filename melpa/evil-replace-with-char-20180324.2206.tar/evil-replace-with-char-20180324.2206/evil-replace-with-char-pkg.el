;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-replace-with-char" "20180324.2206"
  "Replace chars of a text object with a char."
  '((evil  "1.2.13")
    (emacs "24"))
  :url "https://github.com/ninrod/evil-replace-with-char"
  :commit "ed4a12d5bff11163eb03ad2826c52fd30f51a8d3"
  :revdesc "ed4a12d5bff1"
  :authors '(("Filipe Silva" . "filipe.silva@gmail.com"))
  :maintainers '(("Filipe Silva" . "filipe.silva@gmail.com")))
