(define-package "wildcharm-light-theme" "20230818.718" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "2cc6542f31393c3927929ee821fd8072a53e4f80" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
