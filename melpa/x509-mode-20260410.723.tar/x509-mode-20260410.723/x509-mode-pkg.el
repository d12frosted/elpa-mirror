;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20260410.723"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "c5dc5a97469166b5a4e835b878ca3c0ed2df055a"
  :revdesc "c5dc5a974691"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
