(define-package "kotlin-mode" "20221206.1910" "Major mode for kotlin"
  '((emacs "24.3"))
  :commit "55eed95033a59d7448a4b2bc11879e62c05e361b" :authors
  '(("Shodai Yokoyama" . "quantumcars@gmail.com"))
  :maintainer
  '("Shodai Yokoyama" . "quantumcars@gmail.com")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
