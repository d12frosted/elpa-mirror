;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "20260719.202"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "70c52b2b1b7a531a7a014bc3b1efb030539eb2e6"
  :revdesc "70c52b2b1b7a"
  :keywords '("wp" "convenience"))
