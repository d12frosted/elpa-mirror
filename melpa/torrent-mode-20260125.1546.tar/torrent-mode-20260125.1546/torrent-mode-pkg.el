;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "torrent-mode" "20260125.1546"
  "Display torrent files in a tabulated view."
  '((emacs     "26.1")
    (tablist   "1.0")
    (bencoding "1.0"))
  :url "https://github.com/sarg/torrent-mode.el"
  :commit "6a3d09e8c5c75b127bfc22048593d6ee2cfeb7be"
  :revdesc "6a3d09e8c5c7"
  :authors '(("Sergey Trofimov" . "sarg@sarg.org.ru"))
  :maintainers '(("Sergey Trofimov" . "sarg@sarg.org.ru")))
