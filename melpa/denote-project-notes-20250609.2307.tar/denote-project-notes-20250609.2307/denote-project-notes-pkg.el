;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-project-notes" "20250609.2307"
  "Link Denote notes to a project."
  '((emacs  "28.1")
    (denote "3.0.0"))
  :url "https://git.sr.ht/~swflint/denote-project-notes"
  :commit "7bbffb015a1c301eb39cc4a92dafc477db932710"
  :revdesc "7bbffb015a1c"
  :keywords '("convenience")
  :authors '(("Samuel W. Flint" . "swflint@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "swflint@samuelwflint.com")))
