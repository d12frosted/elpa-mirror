;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tok-theme" "20251006.2119"
  "Minimal monochromatic theme for Emacs in the spirit of Zmacs and Smalltalk-80."
  '((emacs "27.0"))
  :url "https://github.com/topikettunen/tok-theme"
  :commit "cf9b5584be30f5297fa338f96afd0e461d88f524"
  :revdesc "cf9b5584be30"
  :authors '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers '(("Topi Kettunen" . "topi@topikettunen.com")))
