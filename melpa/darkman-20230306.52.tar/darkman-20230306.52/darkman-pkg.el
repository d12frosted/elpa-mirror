(define-package "darkman" "20230306.52" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "47ae0f5bbd71477e5a242fecd4c86edc8aa26155" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://grtcdr.tn/darkman.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
