;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260117.104"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "96f79c96b9d7eabdf1a2be306e1b206f84df2ddc"
  :revdesc "96f79c96b9d7"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
