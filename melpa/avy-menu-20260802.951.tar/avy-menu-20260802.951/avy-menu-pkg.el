;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-menu" "20260802.951"
  "Library providing avy-powered popup menu."
  '((emacs "24.4")
    (avy   "0.4.0"))
  :url "https://github.com/mrkkrp/avy-menu"
  :commit "881a7018e2de41bc98ac011e4b345a1750dc1e95"
  :revdesc "881a7018e2de"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
