;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260930.1110"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "d2b07bdeed5bbf899349ee0bdd57e68b2dc507b8"
  :revdesc "d2b07bdeed5b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
