;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "20260216.1641"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "5f9fa0d3f7ba778c9804591562841abfcf246c43"
  :revdesc "5f9fa0d3f7ba")
