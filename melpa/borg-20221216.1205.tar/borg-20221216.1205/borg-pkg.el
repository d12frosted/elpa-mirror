(define-package "borg" "20221216.1205" "Assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "fdce5ecc122afb7f4a4b56d11778d2d2e0de78a7" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
