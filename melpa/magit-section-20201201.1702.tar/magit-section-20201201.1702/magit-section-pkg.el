(define-package "magit-section" "20201201.1702" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "acfe22ab60a56c61aae3ca6d4f2b7b826fe3b071" :keywords
  ("tools")
  :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
