(define-package "magit-section" "20201201.1702" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "318fa8fd39033d2dd4648542db0d5e47a8583882" :keywords
  ("tools")
  :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
