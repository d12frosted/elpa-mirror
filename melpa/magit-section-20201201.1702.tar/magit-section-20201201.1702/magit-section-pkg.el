(define-package "magit-section" "20201201.1702" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "2e0c697188ca728c240b5aa677f4a5e853692b6e" :keywords
  ("tools")
  :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
