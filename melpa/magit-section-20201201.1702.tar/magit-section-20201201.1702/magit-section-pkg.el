(define-package "magit-section" "20201201.1702" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "1f1a8c0de24899a217d45fcdf64439f14e3a540b" :keywords
  ("tools")
  :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
