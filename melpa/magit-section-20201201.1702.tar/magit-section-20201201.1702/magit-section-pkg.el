(define-package "magit-section" "20201201.1702" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "a9c4371a0375140bcc49f9f46626f3c5d256a960" :keywords
  ("tools")
  :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
