(define-package "simple-indentation" "20221111.1848" "Simplify writing indentation functions, alternative to SMIE"
  '((emacs "24.3")
    (dash "2.18.0")
    (s "1.12.0"))
  :commit "06c3d16849f011ae492d190b5ddb0d7484967286" :authors
  '(("Semen Khramtsov" . "hrams205@gmail.com"))
  :maintainer
  '("Semen Khramtsov" . "hrams205@gmail.com")
  :url "https://github.com/semenInRussia/simple-indentation.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
