(define-package "ekg" "20240901.2134" "A system for recording and linking information"
  '((triples "0.4.0")
    (emacs "28.1")
    (llm "0.17.0"))
  :commit "583f6176acac02d5bbf69ee52db59f829951d83c" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
