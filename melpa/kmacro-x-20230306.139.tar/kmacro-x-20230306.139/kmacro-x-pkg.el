(define-package "kmacro-x" "20230306.139" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "a351644a691cf9ef83a819daf8a5ba91b1c1865d" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
