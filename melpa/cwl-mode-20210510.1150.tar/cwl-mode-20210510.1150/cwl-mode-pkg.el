;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cwl-mode" "20210510.1150"
  "A major mode for editing CWL."
  '((yaml-mode "0.0.13")
    (emacs     "24.4"))
  :url "https://github.com/tom-tan/cwl-mode"
  :commit "23a333119efaac78453cba95d316109805bd6aec"
  :revdesc "23a333119efa"
  :keywords '("languages" "cwl" "common workflow language")
  :authors '(("Tomoya Tanjo" . "ttanjo@gmail.com"))
  :maintainers '(("Tomoya Tanjo" . "ttanjo@gmail.com")))
