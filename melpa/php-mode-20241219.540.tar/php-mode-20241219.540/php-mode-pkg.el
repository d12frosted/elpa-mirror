;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20241219.540"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "69e9c16fda61c3aef9219bf55adadcbba62c0586"
  :revdesc "69e9c16fda61"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
