(define-package "tmsu" "20230807.1224" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "9b8d650a2b135da1a516a16b94a98eba3301c0bc" :authors
  '(("Wojciech Siewierski"))
  :maintainers
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
