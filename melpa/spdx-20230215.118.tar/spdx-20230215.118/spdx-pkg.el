(define-package "spdx" "20230215.118" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "73f5e836b9863288f76c59db3144378a9213fdc5" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
