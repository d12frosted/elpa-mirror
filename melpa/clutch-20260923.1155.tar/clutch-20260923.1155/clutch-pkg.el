;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260923.1155"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "bfe30d6541baa61173c197e95c9026db3f11be1a"
  :revdesc "bfe30d6541ba"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
