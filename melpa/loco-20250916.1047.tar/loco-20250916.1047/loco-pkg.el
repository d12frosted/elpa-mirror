;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loco" "20250916.1047"
  "Enter complex key sequences with ease!."
  '((emacs "29.1"))
  :url "https://github.com/csmclaren/loco"
  :commit "d0eb8933ffc90d4e8f727de54a89636f063b4e97"
  :revdesc "d0eb8933ffc9"
  :keywords '("abbrev" "convenience")
  :authors '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainers '(("Chris McLaren" . "csmclaren@me.com")))
