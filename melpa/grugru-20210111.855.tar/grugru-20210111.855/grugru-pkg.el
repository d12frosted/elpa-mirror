(define-package "grugru" "20210111.855" "Rotate text at point"
  '((emacs "24.4"))
  :commit "92e588e9749614ef6cb68b76b1d3aaadf7731406" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
