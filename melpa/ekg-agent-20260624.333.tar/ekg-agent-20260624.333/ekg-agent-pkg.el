;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260624.333"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "2330740b43cd68063499a8e71b9b07e66dc74082"
  :revdesc "2330740b43cd"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
