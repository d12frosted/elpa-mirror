;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251014.804"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "36aff3ea03905ce265a9b262a7c268753b68f814"
  :revdesc "36aff3ea0390"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
