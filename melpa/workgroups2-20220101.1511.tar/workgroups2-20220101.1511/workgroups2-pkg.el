(define-package "workgroups2" "20220101.1511" "save&load multiple named workspaces (or \"workgroups\")"
  '((emacs "25.1"))
  :commit "2601c3578a3ca34847626d0ac4b391f19cea62d6" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
