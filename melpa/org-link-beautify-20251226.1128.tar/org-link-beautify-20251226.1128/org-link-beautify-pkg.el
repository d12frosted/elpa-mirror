;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20251226.1128"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "d15ee0a511d47949d71879a4aaf2d32587143d24"
  :revdesc "d15ee0a511d4"
  :keywords '("hypermedia"))
