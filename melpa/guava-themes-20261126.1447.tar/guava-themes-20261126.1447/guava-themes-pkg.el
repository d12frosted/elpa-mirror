;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261126.1447"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "98883d57703b5711f86b3b77d0d623e15f439477"
  :revdesc "98883d57703b"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
