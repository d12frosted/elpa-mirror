;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20261124.1820"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "855d3ef911e2bb8ec662259b97e43e2288b5c2c8"
  :revdesc "855d3ef911e2"
  :keywords '("calendar" "holidays"))
