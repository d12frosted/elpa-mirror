;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-playground" "20250107.1451"
  "Local Golang playground for short snippets."
  '((emacs   "24")
    (go-mode "1.4.0")
    (gotest  "0.13.0"))
  :url "https://github.com/grafov/go-playground"
  :commit "50a59198aafc8f03df4de82ecd07b31290f7e05a"
  :revdesc "50a59198aafc"
  :keywords '("tools" "golang")
  :authors '(("Alexander I.Grafov" . "grafov@inet.name"))
  :maintainers '(("Alexander I.Grafov" . "grafov@inet.name")))
