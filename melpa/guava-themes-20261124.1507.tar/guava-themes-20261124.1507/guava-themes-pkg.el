;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261124.1507"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "260baf4dbc3d0d5123ef595c99d3cf372698bd8e"
  :revdesc "260baf4dbc3d"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
