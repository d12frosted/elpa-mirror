(define-package "firrtl-mode" "20200329.2002" "mode for working with FIRRTL files"
  '((emacs "24.3"))
  :commit "fa40141411a876ce7a1a9d6d3fe47134bc1fa954" :authors
  '(("Schuyler Eldridge" . "schuyler.eldridge@ibm.com"))
  :maintainers
  '(("Schuyler Eldridge" . "schuyler.eldridge@ibm.com"))
  :maintainer
  '("Schuyler Eldridge" . "schuyler.eldridge@ibm.com")
  :keywords
  '("languages" "firrtl")
  :url "https://github.com/ibm/firrtl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
