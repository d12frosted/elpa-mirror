(define-package "paimon" "20220323.2015" "A major mode for Splunk"
  '((aio "1.0")
    (closql "1.2.0")
    (emacs "27.1")
    (emacsql "3.0.0")
    (emacsql-sqlite "3.0.0")
    (f "0.20.0")
    (ht "2.4")
    (transient "0.3.7")
    (request "0.3.3"))
  :commit "b29ccfcedefd03cc05d98cd06a5935ecf4bd6917" :authors
  '(("r0man" . "roman@burningswell.com"))
  :maintainer
  '("r0man" . "roman@burningswell.com")
  :keywords
  '("paimon" "search" "tools")
  :url "https://github.com/r0man/paimon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
