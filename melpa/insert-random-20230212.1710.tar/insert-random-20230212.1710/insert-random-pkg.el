;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-random" "20230212.1710"
  "Insert random characters from various character sets."
  '((emacs "24.5"))
  :url "https://github.com/lassik/emacs-insert-random"
  :commit "a13827fd68457f939e46f95a662752f6f344107c"
  :revdesc "a13827fd6845"
  :keywords '("convenience")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
