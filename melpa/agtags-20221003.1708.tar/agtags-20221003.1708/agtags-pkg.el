(define-package "agtags" "20221003.1708" "A frontend to GNU Global"
  '((emacs "25"))
  :commit "e3f187a23032b3b84c67090a6c55a251ff9e9642" :authors
  '(("Vietor Liu" . "vietor.liu@gmail.com"))
  :maintainer
  '("Vietor Liu" . "vietor.liu@gmail.com")
  :keywords
  '("tools" "convenience")
  :url "https://github.com/vietor/agtags")
;; Local Variables:
;; no-byte-compile: t
;; End:
