(define-package "embark" "20220505.615" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d07cb30c0a08c5845a96cfdff82e5f42ce2eaef0" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
