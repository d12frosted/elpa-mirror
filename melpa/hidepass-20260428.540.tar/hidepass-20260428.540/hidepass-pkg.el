;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hidepass" "20260428.540"
  "Hide passwords at one or multiple lines."
  '((emacs "27.2"))
  :url "https://codeberg.org/Anoncheg/emacs-hidepass"
  :commit "be0dd65847c845a690ee85d6d0be26af89a0b0af"
  :revdesc "be0dd65847c8"
  :keywords '("hide" "hidden" "password" "faces")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
