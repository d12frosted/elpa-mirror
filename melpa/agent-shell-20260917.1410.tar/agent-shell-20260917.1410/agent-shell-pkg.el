;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260917.1410"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "278a8e191155d6ae151e1a56af99c65b7cb18c99"
  :revdesc "278a8e191155")
