(define-package "consult" "20201225.2023" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9be8dd35a6f92a0e9786ddb3f2a9319e06a6b166" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
