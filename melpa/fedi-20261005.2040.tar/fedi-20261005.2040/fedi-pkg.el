;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fedi" "20261005.2040"
  "Helper functions for fediverse clients."
  '((emacs         "28.1")
    (markdown-mode "2.5"))
  :url "https://codeberg.org/martianh/fedi.el"
  :commit "c79f66c8196723fc135053b4a8eec085fcc613ca"
  :revdesc "c79f66c81967"
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
