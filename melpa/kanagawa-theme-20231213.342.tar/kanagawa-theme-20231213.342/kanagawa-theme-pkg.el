(define-package "kanagawa-theme" "20231213.342" "An elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa"
  '((emacs "24.3"))
  :commit "5806cf0040bc44eae54eefb4fc3909f1bb89e933" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/meritamen/emacs-kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
