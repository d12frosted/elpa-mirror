;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260823.722"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "70dfb1c6989685875f2e3f8b5b427a27f01eb7d4"
  :revdesc "70dfb1c69896"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
