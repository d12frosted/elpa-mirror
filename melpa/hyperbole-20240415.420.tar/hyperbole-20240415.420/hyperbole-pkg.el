(define-package "hyperbole" "20240415.420" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.1"))
  :commit "4026c7cefd9820b4478d71bc1ccf97b9c139adf8" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Mats Lidell" . "matsl@gnu.org"))
  :maintainer
  '("Mats Lidell" . "matsl@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
