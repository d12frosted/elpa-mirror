;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-meta-edit" "20251118.2156"
  "Edit PDF metadata via pdftk."
  '((emacs  "24.3")
    (compat "29.1"))
  :url "https://github.com/krisbalintona/pdf-meta-edit"
  :commit "0e8698c00a4b57509b1d6408d6f367325e740893"
  :revdesc "0e8698c00a4b"
  :keywords '("files" "data")
  :authors '(("Kristoffer Balintona" . "krisbalintona@gmail.com"))
  :maintainers '(("Kristoffer Balintona" . "krisbalintona@gmail.com")))
