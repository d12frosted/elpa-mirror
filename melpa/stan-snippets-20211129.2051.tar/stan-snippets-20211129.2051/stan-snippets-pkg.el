;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stan-snippets" "20211129.2051"
  "Yasnippets for Stan."
  '((emacs     "24.3")
    (stan-mode "10.3.0")
    (yasnippet "0.8.0"))
  :url "https://github.com/stan-dev/stan-mode/tree/master/stan-snippets"
  :commit "150bbbe5fd3ad2b5a3dbfba9d291e66eeea1a581"
  :revdesc "150bbbe5fd3a"
  :keywords '("languages" "tools")
  :authors '(("Jeffrey Arnold" . "jeffrey.arnold@gmail.com")
             ("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")))
