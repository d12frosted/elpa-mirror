(define-package "sculpture-themes" "20220311.2122" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "407cbed4145af8feb5232b1161a5f79b6a9878fb" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
