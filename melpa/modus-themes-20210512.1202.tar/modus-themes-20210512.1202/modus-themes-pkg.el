(define-package "modus-themes" "20210512.1202" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "ea3c277db14cfefaf54383c7b3e34bffe90150e8" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
