(define-package "gptel" "20230401.104" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "c2ad1c004d7f5406f5eb302c533e7c7c14ea2ce0" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
