(define-package "consult" "20220528.812" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "21ccad0e75db4098befc592168002b03f2d663ec" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
