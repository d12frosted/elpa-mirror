;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyramid" "20230114.1049"
  "Minor mode for working with pyramid projects."
  '((emacs    "25.2")
    (pythonic "0.1.1")
    (tablist  "0.70"))
  :url "https://github.com/dakra/pyramid.el"
  :commit "c8a8b36725d85664e74f59600fe5d18d06ea907d"
  :revdesc "c8a8b36725d8"
  :keywords '("python" "pyramid" "pylons" "convenience" "tools" "processes")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
