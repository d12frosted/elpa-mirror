; inherits: bash
