;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-tree-sitter" "20261102.902"
  "Provides evil textobjects using tree-sitter."
  '((emacs "25.1"))
  :url "https://github.com/meain/evil-textobj-tree-sitter"
  :commit "5447be6c019b92bb6378b65b70b67c105fc7f14e"
  :revdesc "5447be6c019b"
  :keywords '("evil" "tree-sitter" "text-object" "convenience"))
