; inherits: ecma,jsx

