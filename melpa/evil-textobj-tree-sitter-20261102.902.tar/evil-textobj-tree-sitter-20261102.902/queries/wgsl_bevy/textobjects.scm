; inherits wgsl

