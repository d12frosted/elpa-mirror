(define-package "nndiscourse" "20210926.1845" "Gnus backend for Discourse"
  '((emacs "25.1")
    (dash "2.18.1")
    (anaphora "1.0.4")
    (rbenv "0.0.3")
    (json-rpc "0.0.1"))
  :commit "168b5ff1d8d8c39ac2db31e56fbab0927d557d7f" :keywords
  '("news")
  :url "https://github.com/dickmao/nndiscourse")
;; Local Variables:
;; no-byte-compile: t
;; End:
