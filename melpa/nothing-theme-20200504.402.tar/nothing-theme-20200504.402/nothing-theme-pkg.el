;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nothing-theme" "20200504.402"
  "Monochrome theme."
  '((emacs "24.1"))
  :url "https://github.com/jaredgorski/nothing.el"
  :commit "17fc9ecc94af0c919a24c4fe92bb48890bb4c3b0"
  :revdesc "17fc9ecc94af"
  :authors '((nil . "jaredgorski6@gmail.com"))
  :maintainers '((nil . "jaredgorski6@gmail.com")))
