(define-package "burly" "20201211.58" "Save and restore frame/window configurations with buffers"
  '((emacs "26.3")
    (map "2.1"))
  :commit "291c2b34eee255f64c0fd889b67dc11a3b69ef12" :keywords
  ("convenience")
  :authors
  (("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  ("Adam Porter" . "adam@alphapapa.net")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
