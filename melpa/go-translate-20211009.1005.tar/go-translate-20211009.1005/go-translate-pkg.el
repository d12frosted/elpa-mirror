(define-package "go-translate" "20211009.1005" "Translation"
  '((emacs "26.1"))
  :commit "2ebe5493d8898dc7f6430278dd54a34b56399981" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
