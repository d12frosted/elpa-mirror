;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "20260104.1120"
  "A major mode for editing OpenSCAD code."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "23e4a92342f97935221687256304d4f1767124f7"
  :revdesc "23e4a92342f9"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
