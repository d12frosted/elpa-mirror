(define-package "projection" "20231231.1526" "Project type support for `project'"
  '((emacs "29.1")
    (project "0.9.8")
    (compat "29.1.4.1")
    (f "0.20")
    (s "1.13"))
  :commit "1c3464e6ebb362cb3f89ff793e042953b45db325" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
