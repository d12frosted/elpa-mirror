;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261119.306"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "0978531eac53290ce162cd157d0c4af1552b8c59"
  :revdesc "0978531eac53")
