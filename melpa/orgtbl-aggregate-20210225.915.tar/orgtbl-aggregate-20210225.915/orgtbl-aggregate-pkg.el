(define-package "orgtbl-aggregate" "20210225.915" "Create an aggregated Org table from another one" 'nil :commit "bcb38ada8469a7f6f9a915c36760a05b2c68ad88" :keywords
  '("org" "table" "aggregation" "filtering"))
;; Local Variables:
;; no-byte-compile: t
;; End:
