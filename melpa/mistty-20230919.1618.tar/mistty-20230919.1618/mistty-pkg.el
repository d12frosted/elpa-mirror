(define-package "mistty" "20230919.1618" "Shell/Comint alternative based on term.el"
  '((emacs "29.1")
    (iter2 "1.4"))
  :commit "eb97776756469297b50124922a363eedffba9268" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
