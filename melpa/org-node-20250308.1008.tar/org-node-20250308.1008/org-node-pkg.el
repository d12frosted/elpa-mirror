;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250308.1008"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (el-job        "1.0.5")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "57f0502892d2a2d48a0b533a031fa41a3e074383"
  :revdesc "57f0502892d2"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
