(define-package "live-py-mode" "20210701.1955" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "23e674f8572f3189fbe3917af6f22e6ec8708818" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
