;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recently" "20210930.207"
  "Track recently opened files to visit them again."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/10sr/recently-el"
  :commit "94b31f6bf1dab6af942948fec975e37424938a62"
  :revdesc "94b31f6bf1da"
  :keywords '("utility" "files")
  :authors '(("10sr" . "8.slashes[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8.slashes[at]gmail[dot]com")))
