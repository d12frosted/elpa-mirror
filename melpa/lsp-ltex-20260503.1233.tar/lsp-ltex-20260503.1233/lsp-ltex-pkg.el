;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex" "20260503.1233"
  "LSP Clients for LTEX."
  '((emacs    "29.1")
    (lsp-mode "6.1"))
  :url "https://github.com/emacs-languagetool/lsp-ltex"
  :commit "a7014677b10ddc1127f9e6ed4ffaf9c5ab18922c"
  :revdesc "a7014677b10d"
  :keywords '("convenience" "lsp" "languagetool" "checker")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
