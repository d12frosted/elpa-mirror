;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phony" "20260531.1207"
  "Speech bindings for Elisp."
  '((emacs      "29.1")
    (simulacrum "1.0.0"))
  :url "https://github.com/ErikPrantare/phony.el"
  :commit "c8d84d80dba14e4d93bc1a1f0d89b0e36ea16cc7"
  :revdesc "c8d84d80dba1"
  :keywords '("files"))
