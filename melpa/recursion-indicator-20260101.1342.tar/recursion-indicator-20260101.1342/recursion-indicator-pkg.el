;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recursion-indicator" "20260101.1342"
  "Recursion indicator."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/recursion-indicator"
  :commit "0f5fc36ea6c1312708b00ee3ac9817511150fc0b"
  :revdesc "0f5fc36ea6c1"
  :keywords '("convenience")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
