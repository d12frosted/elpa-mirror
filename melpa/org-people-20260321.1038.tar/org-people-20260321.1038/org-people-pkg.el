;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260321.1038"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "e1e77f4bd81398eaa64bf9f95ccd8c5c54d19d0d"
  :revdesc "e1e77f4bd813"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
