;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk" "20260322.1431"
  "Daredevil SKK (Simple Kana to Kanji conversion program)."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :url "https://github.com/skk-dev/ddskk"
  :commit "9189bbd2615fbc71fab89b743f80c2e890a900e6"
  :revdesc "9189bbd2615f"
  :keywords '("japanese" "mule" "input method")
  :authors '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp")))
