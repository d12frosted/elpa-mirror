;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241016.718"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "b312d90d19571c9eec8414b415936d41b3c695cf"
  :revdesc "b312d90d1957"
  :keywords '("convenience" "modal-editing"))
