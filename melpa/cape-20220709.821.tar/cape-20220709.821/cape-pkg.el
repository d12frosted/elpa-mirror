(define-package "cape" "20220709.821" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "6409bb43c8a7826186699572e4a5fe9356ca4351" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
