;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20260502.950"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "286f42c3f1b0946ee39b044fba8b176d8270821d"
  :revdesc "286f42c3f1b0"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
