(define-package "axiom-environment" "20211120.1015" "An environment for using Axiom/OpenAxiom/FriCAS"
  '((emacs "24.2"))
  :commit "0c8b6f2b8ce887888f4f2bb182534689a3219dcb" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("axiom" "openaxiom" "fricas"))
;; Local Variables:
;; no-byte-compile: t
;; End:
