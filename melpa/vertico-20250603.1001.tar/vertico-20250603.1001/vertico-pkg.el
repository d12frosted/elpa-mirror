;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20250603.1001"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "8e7fabe1254fff22d6edf9bdf0d523d045ccfdd3"
  :revdesc "8e7fabe1254f"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
