(define-package "embark" "20210407.23" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "32e3a6bf4ea6261acbe5cab28cee1a4484858747" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
