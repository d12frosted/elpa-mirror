(define-package "eldev" "20220825.1842" "Elisp development tool"
  '((emacs "24.4"))
  :commit "1b63378d3a6b103d994d723321e4049d33cd73d0" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
