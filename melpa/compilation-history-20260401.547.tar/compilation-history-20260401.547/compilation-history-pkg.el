;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compilation-history" "20260401.547"
  "Track compilation history in SQLite."
  '((emacs "29.1"))
  :url "https://github.com/djgoku/compilation-history"
  :commit "dba6568dc2c56131d811ff951855e6fb69447ed8"
  :revdesc "dba6568dc2c5"
  :keywords '("processes" "tools")
  :authors '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainers '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com")))
