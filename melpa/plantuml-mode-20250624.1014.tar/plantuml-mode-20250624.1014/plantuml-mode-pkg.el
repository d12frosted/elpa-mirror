;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plantuml-mode" "20250624.1014"
  "Major mode for PlantUML."
  '((dash  "2.0.0")
    (emacs "25.1"))
  :url "https://github.com/skuro/plantuml-mode"
  :commit "7fb062912832d0a8201d9f8e1381e060548c1abf"
  :revdesc "7fb062912832"
  :keywords '("files" "text" "processes" "tools"))
