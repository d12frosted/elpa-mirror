;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-clojure" "20250525.859"
  "Run an external Clojure process in an Emacs buffer."
  '((emacs        "27")
    (clojure-mode "5.11"))
  :url "http://github.com/clojure-emacs/inf-clojure"
  :commit "616c40f9e4c7d18e96ebbe303edca14e0e90a090"
  :revdesc "616c40f9e4c7"
  :keywords '("processes" "comint" "clojure")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
