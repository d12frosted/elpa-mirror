(define-package "wanderlust" "20210131.1217" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "ffcbee99cdc8ce495fcdabef880fb9ab7dd546c8")
;; Local Variables:
;; no-byte-compile: t
;; End:
