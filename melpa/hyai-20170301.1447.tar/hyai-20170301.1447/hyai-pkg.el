;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyai" "20170301.1447"
  "Haskell Yet Another Indentation."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/iquiw/hyai"
  :commit "e9a7e945fed12d8e664e898cf8b434b0376d5d80"
  :revdesc "e9a7e945fed1"
  :authors '(("Iku Iwasa" . "iku.iwasa@gmail.com"))
  :maintainers '(("Iku Iwasa" . "iku.iwasa@gmail.com")))
