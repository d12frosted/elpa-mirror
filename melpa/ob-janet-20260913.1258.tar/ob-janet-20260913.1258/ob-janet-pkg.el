;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-janet" "20260913.1258"
  "Org-Babel support for the Janet language."
  '((emacs "26.1")
    (org   "9.1"))
  :url "https://codeberg.org/zzkt/ob-janet"
  :commit "f972eb760f3293b9883ffcd3b19ab05cbb8f9404"
  :revdesc "f972eb760f32"
  :keywords '("languages" "tools" "literate programming" "janet")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
