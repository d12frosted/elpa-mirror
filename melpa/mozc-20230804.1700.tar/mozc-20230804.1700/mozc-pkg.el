(define-package "mozc" "20230804.1700" "minor mode to input Japanese with Mozc" 'nil :commit "e6bc2b6c959758bbec5125e6f478aad437572699" :keywords
  '("mule" "multilingual" "input method"))
;; Local Variables:
;; no-byte-compile: t
;; End:
