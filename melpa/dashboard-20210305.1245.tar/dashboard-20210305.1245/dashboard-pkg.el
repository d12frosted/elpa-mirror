(define-package "dashboard" "20210305.1245" "A startup screen extracted from Spacemacs"
  '((emacs "25.3")
    (page-break-lines "0.11"))
  :commit "52a4e33cb2a1a7405c951a9494b89ef10000563b" :authors
  '(("Rakan Al-Hneiti"))
  :maintainer
  '("Rakan Al-Hneiti")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
