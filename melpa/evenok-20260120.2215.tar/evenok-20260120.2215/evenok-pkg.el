;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evenok" "20260120.2215"
  "Themes with perceptively evenly distributed colors."
  '((emacs "28.1"))
  :url "https://codeberg.org/mekeor/evenok"
  :commit "541c44d35c8f2e8e8ba4a0f1faf9da9466db9ed6"
  :revdesc "541c44d35c8f"
  :keywords '("faces" "theme")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
