(define-package "devdocs-browser" "20230423.444" "Browse devdocs.io documents using EWW"
  '((emacs "27.1"))
  :commit "ef7686e4ff4ecab42e1b4a1a5d079bcf947a5b71" :authors
  '(("blahgeek" . "i@blahgeek.com"))
  :maintainers
  '(("blahgeek" . "i@blahgeek.com"))
  :maintainer
  '("blahgeek" . "i@blahgeek.com")
  :keywords
  '("docs" "help" "tools")
  :url "https://github.com/blahgeek/emacs-devdocs-browser")
;; Local Variables:
;; no-byte-compile: t
;; End:
