;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lf" "20261013.1600"
  "A Language Features library for Emacs Lisp."
  '((s     "1.12.0")
    (dash  "2.16.0")
    (emacs "27.1"))
  :url "https://alhassy.github.io/lf.el/"
  :commit "ff4db1be94c08dc0ff2ca58fb07bb210909f298c"
  :revdesc "ff4db1be94c0"
  :keywords '("convenience" "programming")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
