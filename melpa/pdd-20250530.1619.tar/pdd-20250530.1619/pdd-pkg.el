;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250530.1619"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "34963a26443270fa0d409c3bd900ab7dae92523a"
  :revdesc "34963a264432"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
