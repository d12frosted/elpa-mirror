;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250530.325"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "13612b1b5165f28220b4604e3fea5bb0667b3913"
  :revdesc "13612b1b5165"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
