;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-alert" "20260117.1413"
  "Notifications when commands complete in term.el and eat."
  '((emacs    "24.0")
    (term-cmd "1.1")
    (alert    "1.1")
    (f        "0.18.2"))
  :url "https://github.com/calliecameron/term-alert"
  :commit "093afcb21c79dc5c3ada1e7bed92325dd4dde701"
  :revdesc "093afcb21c79"
  :keywords '("notifications" "processes")
  :authors '(("Callie Cameron" . "cjcameron7@gmail.com"))
  :maintainers '(("Callie Cameron" . "cjcameron7@gmail.com")))
