;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260621.1311"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "eaabae3b01b8bdc05a5892492c06a8131c195a45"
  :revdesc "eaabae3b01b8"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
