(define-package "fpga" "20230913.2057" "FPGA & ASIC Utils"
  '((emacs "29.1"))
  :commit "40ef2cb616f66ba14c6caeec6170b189a2079028" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/gmlarumbe/fpga")
;; Local Variables:
;; no-byte-compile: t
;; End:
