;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260702.1606"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ba0918f6d8e502ff4d8dc6aa871bc8be5e50808f"
  :revdesc "ba0918f6d8e5")
