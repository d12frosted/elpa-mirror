;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250225.750"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "4cc95582b2c45d89397322bd7c0fc4492607b96d"
  :revdesc "4cc95582b2c4"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
