;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260819.2359"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "d95170a90b86ad1a4550e579f7379a3f40bd1c0d"
  :revdesc "d95170a90b86"
  :keywords '("build tools" "languages"))
