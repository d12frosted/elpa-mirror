;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package+" "20240823.2307"
  "Extensions for the package library."
  '((emacs "24.3"))
  :url "https://github.com/zenspider/package"
  :commit "c677513c61b273f3c688464b6005149aeed700ff"
  :revdesc "c677513c61b2"
  :keywords '("extensions" "tools")
  :authors '(("Ryan Davis" . "ryand-ruby@zenspider.com"))
  :maintainers '(("Ryan Davis" . "ryand-ruby@zenspider.com")))
