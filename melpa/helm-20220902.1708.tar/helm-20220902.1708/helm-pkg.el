(define-package "helm" "20220902.1708" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.7")
    (popup "0.5.3"))
  :commit "e28c9fcfeb5a5f5d8093f17e0715efa07001d3e7" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
