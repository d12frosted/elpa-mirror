;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esa" "20180403.1525"
  "Interface to esa.io."
  '((cl-lib "0.5"))
  :url "https://github.com/nabinno/esa.el"
  :commit "417e0ac55abe9b17e0b7165d0df26bc018aff42e"
  :revdesc "417e0ac55abe"
  :keywords '("tools" "esa")
  :authors '(("Nab Inno" . "nab@blahfe.com"))
  :maintainers '(("Nab Inno" . "nab@blahfe.com")))
