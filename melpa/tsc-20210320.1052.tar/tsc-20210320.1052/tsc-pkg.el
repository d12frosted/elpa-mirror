(define-package "tsc" "20210320.1052" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "4d453aed51d78fb733d74be22ed201d901773df9" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
    ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
