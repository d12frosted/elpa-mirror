(define-package "julia-ts-mode" "20230920.2011" "Major mode for Julia source code using tree-sitter"
  '((emacs "29.1")
    (julia-mode "0.4"))
  :commit "e730c311fb11b1fb6038ce61bfc4c6ae142f5ebf" :authors
  '(("Ronan Arraes Jardim Chagas"))
  :maintainers
  '(("Ronan Arraes Jardim Chagas"))
  :maintainer
  '("Ronan Arraes Jardim Chagas")
  :keywords
  '("julia" "languages" "tree-sitter")
  :url "https://github.com/ronisbr/julia-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
