;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20241211.1109"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "b32bf17d8f3745a69cb808f684881596de592ee5"
  :revdesc "b32bf17d8f37"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
