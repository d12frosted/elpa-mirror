(define-package "go-translate" "20211006.1654" "Google Translate"
  '((emacs "26.1"))
  :commit "eb67ccc59bec4fbf2897dc57bee68c3244c2332e" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
