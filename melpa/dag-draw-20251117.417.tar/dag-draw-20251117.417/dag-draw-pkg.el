;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dag-draw" "20251117.417"
  "Draw directed graphs using the GKNV algorithm."
  '((emacs "26.1")
    (dash  "2.19.1")
    (ht    "2.3"))
  :url "https://codeberg.org/trevoke/dag-draw.el"
  :commit "02c0c0dec5b75210e20a412ba180d99324470860"
  :revdesc "02c0c0dec5b7"
  :keywords '("tools" "extensions"))
