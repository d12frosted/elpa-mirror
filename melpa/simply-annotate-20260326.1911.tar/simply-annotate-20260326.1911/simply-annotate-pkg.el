;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260326.1911"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "d418b09bcb68836abab9bd41054558dc26d59941"
  :revdesc "d418b09bcb68"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
