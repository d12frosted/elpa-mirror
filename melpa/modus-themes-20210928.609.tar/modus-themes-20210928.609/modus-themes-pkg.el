(define-package "modus-themes" "20210928.609" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "421cb99cf2dac2f4bcf0439cdaed56a9100b8c07" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
