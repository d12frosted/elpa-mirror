(define-package "tc" "20220122.1443" "a Japanese input method with T-Code on Emacs" 'nil :commit "d0adf22f5aed4d9608778108b60a06c9ea58b289" :authors
  '(("Kaoru Maeda" . "maeda@src.ricoh.co.jp")
    ("Yasushi Saito" . "yasushi@cs.washington.edu")
    ("KITAJIMA Akira" . "kitajima@isc.osakac.ac.jp"))
  :maintainer
  '("KITAJIMA Akira"))
;; Local Variables:
;; no-byte-compile: t
;; End:
