;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fix-input" "20230606.1523"
  "Make input methods play nicely with alternative layouts."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/fix-input"
  :commit "439c1ce8c0a66ecdee4a4b25a1b96197d926b1c3"
  :revdesc "439c1ce8c0a6"
  :keywords '("convenience" "input")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
