(define-package "ligo-mode" "20230815.1212" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "d59593717f7600faba4d20d4a2a2fe851df96317" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
