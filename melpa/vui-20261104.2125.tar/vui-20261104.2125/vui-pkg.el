;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261104.2125"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "80a31b6810a31ccd0b2190b4a7d526996e4a76da"
  :revdesc "80a31b6810a3"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
