;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260622.741"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "765ddf0a39bd3f7c38718d218679458541bcae21"
  :revdesc "765ddf0a39bd"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
