;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260831.434"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "615ba952d27b1b9246bfe4d144f28b6379a3ef66"
  :revdesc "615ba952d27b"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
