(define-package "meow" "20220217.1046" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "2cbb794904002362ab342d8b6b27addbb119998d" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
