;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250116.1452"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "602367206b71104d43ab6047ea1cb5c781ef1db0"
  :revdesc "602367206b71"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
