;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "20251117.1953"
  "IDE features made available out of the box."
  '((emacs "26.1"))
  :url "https://forge.tedomum.net/hjuvi/eide"
  :commit "f85052a1e41422019fdb661bbe3ae8b8de1aa3af"
  :revdesc "f85052a1e414"
  :authors '(("Cédric Marie" . "hjuvi@tedomum.fr"))
  :maintainers '(("Cédric Marie" . "hjuvi@tedomum.fr")))
