;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20260902.1014"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "919f0655e796892d23cc16003d5fadc9c66db3ed"
  :revdesc "919f0655e796"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
