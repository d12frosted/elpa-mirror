(define-package "hl-indent-scope" "20221129.355" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "68420aa92947427ef71ef848c37a8e94e850f6f0" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
