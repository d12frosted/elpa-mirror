(define-package "verilog-ts-mode" "20230821.1737" "Verilog Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "560d4693c51b944e4800f5e670c179bdfee74a73" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
