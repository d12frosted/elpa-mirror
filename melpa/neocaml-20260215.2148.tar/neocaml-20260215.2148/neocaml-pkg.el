;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260215.2148"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "http://github.com/bbatsov/neocaml"
  :commit "f68f3ef0c1a8d5c0b881e0602690065792a92b39"
  :revdesc "f68f3ef0c1a8"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
