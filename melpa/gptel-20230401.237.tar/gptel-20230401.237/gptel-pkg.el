(define-package "gptel" "20230401.237" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "f7ba368c38e0a8d9a67f7cf158741b41288a2cb9" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
