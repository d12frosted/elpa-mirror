(define-package "racket-mode" "20231207.1950" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "e4a5dffe2e2e381fbdcc082c707b08d597e3d0a0" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
