;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260615.802"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "4091cdf48d79523da59b918f48238f8c1f636e4e"
  :revdesc "4091cdf48d79"
  :keywords '("convenience" "text"))
