(define-package "erlang" "20201112.1915" "Erlang major mode"
  '((emacs "24.1"))
  :commit "8fc06415329c72a1e2b8293e98b0317d28152ce0")
;; Local Variables:
;; no-byte-compile: t
;; End:
