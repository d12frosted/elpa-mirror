(define-package "erlang" "20201112.1915" "Erlang major mode"
  '((emacs "24.1"))
  :commit "fe1a2cecd6f937a2c6e1795a6130a204a4f5f5ba")
;; Local Variables:
;; no-byte-compile: t
;; End:
