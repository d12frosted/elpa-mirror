(define-package "erlang" "20201112.1915" "Erlang major mode"
  '((emacs "24.1"))
  :commit "b98d1ca79f0bf603af35e7bf2461ebc78cd161e5")
;; Local Variables:
;; no-byte-compile: t
;; End:
