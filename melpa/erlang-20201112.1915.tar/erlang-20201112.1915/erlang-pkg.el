(define-package "erlang" "20201112.1915" "Erlang major mode"
  '((emacs "24.1"))
  :commit "55242c2bfca855f596f1f9133d162739e36d4aea")
;; Local Variables:
;; no-byte-compile: t
;; End:
