(define-package "erlang" "20201112.1915" "Erlang major mode"
  '((emacs "24.1"))
  :commit "2921c005429dd04d39edd1e9deb8ab30722cf38f")
;; Local Variables:
;; no-byte-compile: t
;; End:
