(define-package "erlang" "20201112.1915" "Erlang major mode"
  '((emacs "24.1"))
  :commit "1bb9e8d09470eda6162d02a2b340f620fd496cfe")
;; Local Variables:
;; no-byte-compile: t
;; End:
