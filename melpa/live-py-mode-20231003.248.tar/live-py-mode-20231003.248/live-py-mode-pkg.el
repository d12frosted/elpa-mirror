(define-package "live-py-mode" "20231003.248" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "600ae9801977f19648caeec9fbaca4631567ea4e" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainers
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
