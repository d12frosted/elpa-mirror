(define-package "pdf-tools" "20211231.658" "Support library for PDF documents"
  '((emacs "24.3")
    (nadvice "0.3")
    (tablist "1.0")
    (let-alist "1.0.4"))
  :commit "5621164d47b0e59676edad252b514f5c3c15824f" :authors
  '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainer
  '("Vedang Manerikar" . "vedang.manerikar@gmail.com")
  :keywords
  '("files" "multimedia")
  :url "http://github.com/vedang/pdf-tools/")
;; Local Variables:
;; no-byte-compile: t
;; End:
