(define-package "autocrypt" "20220215.1204" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "c439cbe029f7ffeca6de0ea72258069c41350509" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
