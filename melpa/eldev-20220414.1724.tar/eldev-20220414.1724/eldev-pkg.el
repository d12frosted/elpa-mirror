(define-package "eldev" "20220414.1724" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "1ee497f7feb4fbef9bc59554d0bd7a0fa3b144f8" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
