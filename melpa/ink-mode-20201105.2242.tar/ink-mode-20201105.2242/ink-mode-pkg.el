(define-package "ink-mode" "20201105.2242" "Major mode for writing interactive fiction in Ink"
  '((emacs "26.1"))
  :commit "63c7ef39acf434a1682951bcf352e8fe1e1ac6d9" :authors
  '(("Erik Sjöstrand")
    ("Damien Picard"))
  :maintainer
  '("Damien Picard")
  :keywords
  '("languages" "wp" "hypermedia")
  :url "https://github.com/Kungsgeten/ink-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
