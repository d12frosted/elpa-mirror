(define-package "vhdl-ts-mode" "20230921.2224" "VHDL Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "169b3f061f73c4cf28909602a76e3d653ddc5eed" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
