;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20260731.724"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "77808caeaa658e95e04b1c6a519be1722e9f1a70"
  :revdesc "77808caeaa65"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
