;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260603.1005"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b3066ae63b78f39bbbc053f61accd7fbfb5c52cc"
  :revdesc "b3066ae63b78")
