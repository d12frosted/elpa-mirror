;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdel" "20261023.730"
  "Play and control your MPD music."
  '((emacs    "28.0")
    (libmpdel "1.2.0")
    (navigel  "0.7.0"))
  :url "https://github.com/mpdel/mpdel"
  :commit "863c884f02c93b5cb1fcce079112c8d7e9705d8b"
  :revdesc "863c884f02c9"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
