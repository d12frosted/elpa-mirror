;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250918.244"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "03e67bc061e6d3a618a7b385e8503e6a0cec4b0c"
  :revdesc "03e67bc061e6"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
