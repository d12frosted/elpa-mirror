;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20261029.1209"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "848f2d34acda59bdb5456667c3f509a187b3a354"
  :revdesc "848f2d34acda"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
