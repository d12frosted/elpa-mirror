(define-package "thrift" "20231014.28" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "aed0ba17906360dd1ec566a6184ef02f96c919cd" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
