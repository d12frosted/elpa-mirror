(define-package "universal-sidecar" "20230919.1813" "A universal sidecar buffer"
  '((emacs "26.1")
    (magit-section "3.0.0"))
  :commit "b31c87e5bb13e47d6371a832b4122875fb2d967c" :authors
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainer
  '("Samuel W. Flint" . "me@samuelwflint.com")
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar")
;; Local Variables:
;; no-byte-compile: t
;; End:
