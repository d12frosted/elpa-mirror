(define-package "vs-dark-theme" "20240520.105" "Visual Studio IDE dark theme"
  '((emacs "24.1"))
  :commit "1b4be39677c321fa019d63b44cfa099790e34e1c" :authors
  '(("Jen-Chieh Shen"))
  :maintainers
  '(("Jen-Chieh Shen"))
  :maintainer
  '("Jen-Chieh Shen")
  :url "https://github.com/emacs-vs/vs-dark-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
