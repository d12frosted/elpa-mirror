;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-invoice-table" "20250408.456"
  "Invoicing table formatter for org-mode."
  '((emacs "26.1"))
  :url "https://codeberg.org/trevdev/org-invoice-table"
  :commit "73dbed9c00b1e5b8dc7fdd55b7c6222cf9422c22"
  :revdesc "73dbed9c00b1"
  :authors '(("Trevor Richards" . "trev@trevdev.ca"))
  :maintainers '(("Trevor Richards" . "trev@trevdev.ca")))
