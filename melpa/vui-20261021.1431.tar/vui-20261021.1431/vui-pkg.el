;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261021.1431"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "05205f5df175ab0bc806d83d5f5f934935d7a300"
  :revdesc "05205f5df175"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
