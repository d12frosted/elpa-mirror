;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260919.1611"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "829ac98a3e3183249028f9f4e029e7e9c0869be3"
  :revdesc "829ac98a3e31"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
