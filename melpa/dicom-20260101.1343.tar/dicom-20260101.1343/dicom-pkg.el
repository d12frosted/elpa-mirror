;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20260101.1343"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/dicom"
  :commit "483463750f81338d7dab53d8b38c205c352f44c5"
  :revdesc "483463750f81"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
