;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241125.1919"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.70.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "e9e931440def38be3d265cbcdde1f8e109d55e8a"
  :revdesc "e9e931440def")
