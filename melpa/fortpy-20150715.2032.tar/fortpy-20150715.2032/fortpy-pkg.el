;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fortpy" "20150715.2032"
  "A Fortran auto-completion for Emacs."
  '((epc                "0.1.0")
    (auto-complete      "1.4")
    (python-environment "0.0.2")
    (pos-tip            "0.4.5"))
  :url "https://github.com/rosenbrockc/fortpy-el"
  :commit "c614517e9396ef7a78be3b8786fbf303879cf43b"
  :revdesc "c614517e9396"
  :authors '(("Conrad Rosenbrock" . "rosenbrockcatgmail.com"))
  :maintainers '(("Conrad Rosenbrock" . "rosenbrockcatgmail.com")))
