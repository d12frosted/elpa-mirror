;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibrowse" "20230926.2056"
  "Interact with your browser."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~ngraves/ibrowse.el"
  :commit "addfec54f2c33d505d10bb5f17c084876db5baed"
  :revdesc "addfec54f2c3"
  :keywords '("comm" "data" "files" "tools")
  :authors '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainers '(("Nicolas Graves" . "ngraves@ngraves.fr")))
