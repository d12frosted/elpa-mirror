(define-package "org-make-toc" "20230904.911" "Automatic tables of contents for Org files"
  '((emacs "26.1")
    (dash "2.12")
    (s "1.10.0")
    (org "9.0"))
  :commit "e6da481729a103a081b1b6bbca7202a21cb7321a" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("org" "convenience")
  :url "http://github.com/alphapapa/org-make-toc")
;; Local Variables:
;; no-byte-compile: t
;; End:
