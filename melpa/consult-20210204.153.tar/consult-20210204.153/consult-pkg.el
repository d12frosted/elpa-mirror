(define-package "consult" "20210204.153" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f2960d6e958de83f16daf171b6c6397084721061" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
