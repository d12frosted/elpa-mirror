;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260918.344"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "2d9b30853a274f7b9a13070942451f8d23d2d9ca"
  :revdesc "2d9b30853a27"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
