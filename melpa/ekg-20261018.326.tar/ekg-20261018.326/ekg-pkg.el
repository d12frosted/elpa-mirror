;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261018.326"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "0773ae7cc3e748c8a2dda97b1da57007062f510c"
  :revdesc "0773ae7cc3e7"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
