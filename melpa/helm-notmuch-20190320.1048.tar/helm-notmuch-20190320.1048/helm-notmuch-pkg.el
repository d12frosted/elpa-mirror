;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-notmuch" "20190320.1048"
  "Search emails with Notmuch and Helm."
  '((helm    "1.9.3")
    (notmuch "0.21"))
  :url "https://github.com/emacs-helm/helm-notmuch"
  :commit "97a01497e079a7b6505987e9feba6b603bbec288"
  :revdesc "97a01497e079"
  :keywords '("mail")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
