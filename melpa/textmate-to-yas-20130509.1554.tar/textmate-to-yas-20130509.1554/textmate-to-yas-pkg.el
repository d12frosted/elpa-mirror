(define-package "textmate-to-yas" "20130509.1554" "Import Textmate macros into yasnippet syntax" 'nil :commit "8805e5159329e1b74629b7b584373fc446f57d31" :authors
  '(("Matthew L. Fidler"))
  :maintainer
  '("Matthew L. Fidler")
  :keywords
  '("yasnippet" "textmate")
  :url "https://github.com/mlf176f2/textmate-to-yas.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
