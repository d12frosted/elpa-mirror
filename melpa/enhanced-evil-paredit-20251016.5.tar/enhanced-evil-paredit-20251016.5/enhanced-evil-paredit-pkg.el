;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20251016.5"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "7ca82138881a5efacacf0494b898fb1201311fc8"
  :revdesc "7ca82138881a"
  :keywords '("convenience"))
