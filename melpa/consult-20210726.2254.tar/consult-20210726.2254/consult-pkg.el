(define-package "consult" "20210726.2254" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "74c8ab56fd343a5a2f6dea7f2f9c4b1358a6c282" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
