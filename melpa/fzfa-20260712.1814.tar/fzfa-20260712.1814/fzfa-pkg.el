;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260712.1814"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "8689d37bae9c6dddc5472265efce8dd311e15c02"
  :revdesc "8689d37bae9c"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
