;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260313.224"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "369e6fd96b0b8f8e6d8316c14aa39d0f44681e88"
  :revdesc "369e6fd96b0b"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
