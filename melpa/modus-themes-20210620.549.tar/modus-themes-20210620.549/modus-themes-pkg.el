(define-package "modus-themes" "20210620.549" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "c3e78f784eea4edb66167b6e5893e99c09d590e5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
