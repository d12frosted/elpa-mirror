(define-package "nerd-icons-corfu" "20231002.1545" "Icons for Corfu via nerd-icons"
  '((emacs "27.1")
    (nerd-icons "0.1.0"))
  :commit "a26bb491181f94d2818b8129c74e92a8dc08af5f" :authors
  '(("Luigi Sartor Piucco" . "luigipiucco@gmail.com"))
  :maintainers
  '(("Luigi Sartor Piucco" . "luigipiucco@gmail.com"))
  :maintainer
  '("Luigi Sartor Piucco" . "luigipiucco@gmail.com")
  :keywords
  '("convenience" "files" "icons")
  :url "https://github.com/LuigiPiucco/nerd-icons-corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
