(define-package "parinfer-rust-mode" "20240504.150" "An interface for the parinfer-rust library"
  '((emacs "26.1")
    (track-changes "1.1"))
  :commit "1b37b9d7644b8a0bda32e2d4afeee6edb635032c" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
