;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-invoice-table" "20250409.402"
  "Invoicing table formatter for org-mode."
  '((emacs "26.1"))
  :url "https://codeberg.org/trevdev/org-invoice-table"
  :commit "3fe481f54050bb98493a0e3a1eb2a0693cda36d6"
  :revdesc "3fe481f54050"
  :authors '(("Trevor Richards" . "trev@trevdev.ca"))
  :maintainers '(("Trevor Richards" . "trev@trevdev.ca")))
