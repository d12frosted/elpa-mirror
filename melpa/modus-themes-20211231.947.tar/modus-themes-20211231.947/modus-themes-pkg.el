(define-package "modus-themes" "20211231.947" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "8375a4b93b7a552f0902d6a89e16501c66f4eeca" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
