;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awk-ts-mode" "20240517.1251"
  "Major mode for awk using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/awk-ts-mode"
  :commit "343d19c5b3c99f1a665d0c6bddb7b18278306b06"
  :revdesc "343d19c5b3c9"
  :keywords '("awk" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
