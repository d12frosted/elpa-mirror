;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250522.138"
  "Mordern HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "10397f16b8276035e3b0c6c5d9474b37c2930fe0"
  :revdesc "10397f16b827"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
