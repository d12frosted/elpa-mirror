;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251201.1914"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "d7fadb684971d49631e3a58a9ccbbb542783bdbc"
  :revdesc "d7fadb684971"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
