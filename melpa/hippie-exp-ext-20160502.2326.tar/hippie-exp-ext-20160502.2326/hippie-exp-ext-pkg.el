;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hippie-exp-ext" "20160502.2326"
  "Extension of hippie-expand."
  ()
  :url "http://www.emacswiki.org/emacs/download/hippie-exp-ext.el"
  :commit "4eda13f90da51ab217d024701f4c30f91ffcb90e"
  :revdesc "4eda13f90da5"
  :keywords '("abbrev" "convenience" "completions" "hippie-expand")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
