;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261030.956"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "3ae7bb3c0ce4ac22aecc109f721dddba6a4b0db0"
  :revdesc "3ae7bb3c0ce4")
