;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visible-mark" "20251227.2227"
  "Make marks visible."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-visible-mark"
  :commit "f2328c3bcbf2bac68c2a5ebebaad06e561a7f6b6"
  :revdesc "f2328c3bcbf2"
  :keywords '("marking" "color" "faces")
  :authors '(("Ian Kelling" . "ian@iankelling.org"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
