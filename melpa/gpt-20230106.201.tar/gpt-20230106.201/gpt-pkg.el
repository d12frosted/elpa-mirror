(define-package "gpt" "20230106.201" "Run instruction-following language models"
  '((emacs "24.4"))
  :commit "b5e555f702b1ebe877cbeef27757618963fa41da" :authors
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainer
  '("Andreas Stuhlmueller" . "andreas@ought.org")
  :keywords
  '("gpt3" "language" "copilot" "convenience" "tools")
  :url "https://github.com/stuhlmueller/gpt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
