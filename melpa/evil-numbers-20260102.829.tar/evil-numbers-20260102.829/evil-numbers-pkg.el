;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-numbers" "20260102.829"
  "Increment/decrement numbers like in VIM."
  '((emacs "24.1")
    (evil  "1.2.0"))
  :url "http://github.com/juliapath/evil-numbers"
  :commit "e7adac70a076ae381c03960d9d669071c1177f3a"
  :revdesc "e7adac70a076"
  :keywords '("convenience" "tools")
  :authors '(("Michael Markert" . "markert.michael@googlemail.com"))
  :maintainers '(("Julia Path" . "julia@jpath.de")))
