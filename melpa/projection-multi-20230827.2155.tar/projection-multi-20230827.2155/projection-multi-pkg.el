(define-package "projection-multi" "20230827.2155" "Projection integration for `compile-multi'"
  '((emacs "29.1")
    (projection "0.1")
    (compile-multi "0.5"))
  :commit "a0e533342c9721ab4ed5f2518ec54130b319df93" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
