;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eproject" "20180312.1642"
  "Assign files to projects, programatically."
  '((helm "1.6.4"))
  :url "https://github.com/jrockway/eproject"
  :commit "068218d2cf2138cb2e8fc29b57e773a0097a7e8b"
  :revdesc "068218d2cf21"
  :keywords '("programming" "projects")
  :authors '(("Jonathan Rockway" . "jon@jrock.us"))
  :maintainers '(("Jonathan Rockway" . "jon@jrock.us")))
