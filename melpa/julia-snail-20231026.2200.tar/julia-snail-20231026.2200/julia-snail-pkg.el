(define-package "julia-snail" "20231026.2200" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (popup "0.5.9"))
  :commit "97ca00411e16a2c1815090ca5aa05b3a36776a75" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
