(define-package "modus-themes" "20220830.125" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "562ebb7e49274ed8cc4f607c6506354a44f90dde" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
