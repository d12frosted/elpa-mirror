;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260317.1053"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "66cd7be3149baeb27a453623080e8f8062a6af29"
  :revdesc "66cd7be3149b"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
