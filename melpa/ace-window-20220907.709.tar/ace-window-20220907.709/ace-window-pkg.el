(define-package "ace-window" "20220907.709" "Quickly switch windows."
  '((avy "0.5.0"))
  :commit "0d9a89edafca53a09946e3a59ed64a0b975a0b8a" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("window" "location")
  :url "https://github.com/abo-abo/ace-window")
;; Local Variables:
;; no-byte-compile: t
;; End:
