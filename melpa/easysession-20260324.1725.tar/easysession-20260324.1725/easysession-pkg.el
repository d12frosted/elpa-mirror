;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260324.1725"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "be6e41a4b12bf8e26aa9928f3482f2fe4f1fe5bc"
  :revdesc "be6e41a4b12b"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
