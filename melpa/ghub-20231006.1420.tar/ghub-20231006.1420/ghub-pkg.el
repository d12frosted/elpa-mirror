(define-package "ghub" "20231006.1420" "Client libraries for Git forge APIs."
  '((emacs "25.1")
    (compat "29.1.4.1")
    (let-alist "1.0.6")
    (treepy "0.1.2"))
  :commit "78a370f4c62016f9812cfdeef19d29b6dffd943a" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
