;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20260131.1251"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "ebdfa25f896c6af15c62b3f6e51eade60e37a7d2"
  :revdesc "ebdfa25f896c"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
