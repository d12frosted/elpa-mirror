;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-aws-iam-role" "20251130.1655"
  "Browse, modify, and simulate AWS IAM Roles in Org Babel."
  '((emacs   "29.1")
    (async   "1.9")
    (promise "1.1"))
  :url "https://github.com/will-abb/org-aws-iam-role"
  :commit "7f77ae62449198251ccf19c4df224f5915dff82a"
  :revdesc "7f77ae624491"
  :keywords '("aws" "iam" "org" "babel" "tools")
  :authors '(("William Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("William Bosch-Bello" . "williamsbosch@gmail.com")))
