;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frecentf" "20231125.201"
  "Pervasive recentf using frecency."
  '((emacs    "26.1")
    (frecency "0.1-pre")
    (persist  "0.4")
    (async    "1.9.4"))
  :url "https://launchpad.net/frecentf.el"
  :commit "ef788b2af412311fbc6f52d639810746e5c0fa93"
  :revdesc "ef788b2af412"
  :keywords '("files" "maint")
  :authors '(("Felipe Lema" . "felipel@mortemale.org"))
  :maintainers '(("Felipe Lema" . "felipel@mortemale.org")))
