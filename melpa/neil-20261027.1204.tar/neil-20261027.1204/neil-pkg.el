;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neil" "20261027.1204"
  "Companion for Babashka Neil."
  '((emacs "29.4"))
  :url "https://github.com/babashka/neil"
  :commit "78e11f7e9df93ef1bfb15744a99b52afc08f3113"
  :revdesc "78e11f7e9df9"
  :keywords '("convenience" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
