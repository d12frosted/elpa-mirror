(define-package "redis" "20220429.1758" "Redis integration"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "a6ad30d6a43b7be083c13f8725b45571d623001a" :authors
  '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers
  '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainer
  '("Mario Rodas" . "marsam@users.noreply.github.com")
  :keywords
  '("convenience")
  :url "https://github.com/emacs-pe/redis.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
