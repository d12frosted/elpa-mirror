(define-package "osx-dictionary" "20210308.632" "Interface for OSX Dictionary.app"
  '((cl-lib "0.5"))
  :commit "953456711c5bc2fdfcd853eb6cae018867ebc066" :authors
  '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainer
  '("Chunyang Xu" . "mail@xuchunyang.me")
  :keywords
  '("mac" "dictionary")
  :url "https://github.com/xuchunyang/osx-dictionary.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
