(define-package "wanderlust" "20210104.1655" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "a52b8ab95ae68a9233c64a70dd9550c1ebd26e93")
;; Local Variables:
;; no-byte-compile: t
;; End:
