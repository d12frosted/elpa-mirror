;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260201.1256"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "50f6f577ae0041cc768947a7e32bcfa601cc3c85"
  :revdesc "50f6f577ae00"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
