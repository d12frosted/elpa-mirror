;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260319.2358"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "62f12d077522d1f80f5b06bf28a31d292ec24a3d"
  :revdesc "62f12d077522")
