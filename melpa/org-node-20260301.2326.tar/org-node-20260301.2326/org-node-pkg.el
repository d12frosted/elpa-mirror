;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260301.2326"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.32.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "5dfeb80274754874e99b25d11782b256a5aa6f93"
  :revdesc "5dfeb8027475"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
