(define-package "helm" "20230804.1005" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.2")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "c5a9299ccda3f90d21051af76d400fa84dbb9f79" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
