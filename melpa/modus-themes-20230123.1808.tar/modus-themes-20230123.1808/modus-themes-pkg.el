(define-package "modus-themes" "20230123.1808" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "2dacdf901304be95a86786135a4f3e797d3cb4fe" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
