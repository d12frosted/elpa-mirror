;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-todo" "20250123.752"
  "Search hl-todo keywords in consult."
  '((emacs   "29.1")
    (consult "1.9")
    (hl-todo "3.8.2"))
  :url "https://github.com/liuyinz/consult-todo"
  :commit "d454a50e9f3847b7cddaaec38e085678dcb8a894"
  :revdesc "d454a50e9f38"
  :authors '(("liuyinz" . "liuyinz@gmail.com"))
  :maintainers '(("liuyinz" . "liuyinz@gmail.com")))
