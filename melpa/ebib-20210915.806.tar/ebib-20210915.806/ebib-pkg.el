(define-package "ebib" "20210915.806" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "e318d486c0a1efcb3086ca3fec9f0c87ed4426d2" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
