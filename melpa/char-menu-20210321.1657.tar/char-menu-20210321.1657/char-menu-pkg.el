;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "char-menu" "20210321.1657"
  "Create your own menu for fast insertion of arbitrary symbols."
  '((emacs    "24.3")
    (avy-menu "0.1"))
  :url "https://github.com/mrkkrp/char-menu"
  :commit "d77c4d64fc8acc386a0fb9727d346c838e75f011"
  :revdesc "d77c4d64fc8a"
  :keywords '("convenience" "editing")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
