;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260306.2100"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "18d2a0c35e30352c173a308c9cce6c62188e7ccd"
  :revdesc "18d2a0c35e30"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
