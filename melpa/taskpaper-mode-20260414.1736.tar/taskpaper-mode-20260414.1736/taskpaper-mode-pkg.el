;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskpaper-mode" "20260414.1736"
  "Major mode for TaskPaper files."
  '((emacs "25.1"))
  :url "https://github.com/saf-dmitry/taskpaper-mode"
  :commit "b16b3ac389321538ab0e9bf9db68650a3be0afb0"
  :revdesc "b16b3ac38932"
  :keywords '("outlines" "notetaking" "task management" "productivity" "taskpaper")
  :authors '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainers '(("Dmitry Safronov" . "saf.dmitry@gmail.com")))
