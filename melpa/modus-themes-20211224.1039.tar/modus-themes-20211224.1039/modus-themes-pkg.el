(define-package "modus-themes" "20211224.1039" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "8485dba0b11edec5a887ecac448067c0aa38a20d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
