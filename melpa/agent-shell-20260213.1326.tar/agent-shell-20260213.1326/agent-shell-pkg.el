;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260213.1326"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "da60db0c46beefcf3299bc6452589534b542c083"
  :revdesc "da60db0c46be")
