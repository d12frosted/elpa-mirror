(define-package "helm" "20230221.819" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.0")
    (popup "0.5.3"))
  :commit "fb3df89c7b0a68c79d6725beb20d3dc6ccd348a1" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
