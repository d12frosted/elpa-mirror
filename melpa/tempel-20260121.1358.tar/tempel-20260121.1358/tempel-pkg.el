;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260121.1358"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "57bd20da7d86c03b61a378d7a164dccbfad5aab7"
  :revdesc "57bd20da7d86"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
