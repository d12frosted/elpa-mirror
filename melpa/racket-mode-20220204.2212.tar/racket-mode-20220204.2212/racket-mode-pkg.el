(define-package "racket-mode" "20220204.2212" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "cef5a55d2b766973db92f9d9ab2210c03fa8ba02" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
