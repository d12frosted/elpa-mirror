(define-package "ddskk" "20230319.758" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "fb29a01e3f1e759ad6a7e35af388f6bbdff79309" :authors
  '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp"))
  :maintainer
  '("SKK Development Team")
  :keywords
  '("japanese" "mule" "input method")
  :url "https://github.com/skk-dev/ddskk")
;; Local Variables:
;; no-byte-compile: t
;; End:
