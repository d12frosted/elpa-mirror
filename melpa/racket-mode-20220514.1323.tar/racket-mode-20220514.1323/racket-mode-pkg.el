(define-package "racket-mode" "20220514.1323" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "5ecebcf34068cae6df2e4be175d453c9cf2eacdd" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
