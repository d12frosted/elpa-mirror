(define-package "enh-ruby-mode" "20220707.1949" "Major mode for editing Ruby files"
  '((emacs "25.1"))
  :commit "23ee0e8690a157d9c81d7aec179c82f0bba309b8" :authors
  '(("Geoff Jacobsen"))
  :maintainer
  '("Ryan Davis")
  :keywords
  '("languages" "elisp" "ruby")
  :url "http://github.com/zenspider/Enhanced-Ruby-Mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
