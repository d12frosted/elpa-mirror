(define-package "dirvish" "20220430.436" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "5e2335601608f230f166d7f3a5418d43206141d7" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
