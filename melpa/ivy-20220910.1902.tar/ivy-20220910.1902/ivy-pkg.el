(define-package "ivy" "20220910.1902" "Incremental Vertical completYon"
  '((emacs "24.5"))
  :commit "e32289080957e4f6ee48dcb879c437eea62a1133" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("matching")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
