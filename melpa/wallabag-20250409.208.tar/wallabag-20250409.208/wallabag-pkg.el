;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wallabag" "20250409.208"
  "Save and manage articles with wallabag."
  '((emacs   "27.1")
    (request "0.3.3")
    (s       "1.12.0")
    (emacsql "3.0.0")
    (gptel   "0.8.6"))
  :url "https://github.com/chenyanming/wallabag.el"
  :commit "18d91e4f3b5287796f5733cf7b4607cf57e56062"
  :revdesc "18d91e4f3b52"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
