(define-package "undo-fu" "20240616.2345" "Undo helper with redo"
  '((emacs "25.1"))
  :commit "6e9b2895af94fcb3c494727d031d97d02cb8ab6a" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-undo-fu")
;; Local Variables:
;; no-byte-compile: t
;; End:
