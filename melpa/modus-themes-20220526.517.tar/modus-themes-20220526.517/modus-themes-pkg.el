(define-package "modus-themes" "20220526.517" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "810a035768085167440c07f99bd7b64e6894d1b7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
