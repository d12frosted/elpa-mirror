(define-package "thrift" "20231110.2354" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "ebc7d0f77dd49abe280000409954f7672eedd36d" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
