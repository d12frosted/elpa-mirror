(define-package "names" "20151201.1204" "Namespaces for emacs-lisp. Avoid name clobbering without hiding symbols."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "00862c57ae6363ba86d1e5ce138929a1b6d5c7e6" :authors
  '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainer
  '("Artur Malabarba" . "emacs@endlessparentheses.com")
  :keywords
  '("extensions" "lisp")
  :url "https://github.com/Malabarba/names")
;; Local Variables:
;; no-byte-compile: t
;; End:
