(define-package "elcontext" "20201129.1203" "Create context specific actions"
  '((ht "2.3")
    (hydra "0.14.0")
    (emacs "24.3")
    (f "0.20.0")
    (osx-location "0.4")
    (uuidgen "0.3"))
  :commit "077d36928993950c01bcdb92102a3d3c18d06bac" :authors
  '(("Thomas Sojka"))
  :maintainer
  '("Thomas Sojka")
  :keywords
  '("calendar" "convenience")
  :url "https://github.com/rollacaster/elcontext")
;; Local Variables:
;; no-byte-compile: t
;; End:
