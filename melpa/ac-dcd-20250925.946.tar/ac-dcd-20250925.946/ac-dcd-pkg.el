;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-dcd" "20250925.946"
  "Auto Completion source for dcd for GNU Emacs."
  '((auto-complete    "1.3.1")
    (flycheck-dmd-dub "0.7"))
  :url "https://github.com/atilaneves/ac-dcd"
  :commit "b95dfc61b9f2597e17f9a4a59b1745afd46a02d6"
  :revdesc "b95dfc61b9f2"
  :keywords '("languages")
  :authors '((nil . "atila.neves@gmail.com"))
  :maintainers '((nil . "atila.neves@gmail.com")))
