(define-package "dirvish" "20220203.1118" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "bc278f42110fe34e14ebfce0cda036b3ce17730a" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
