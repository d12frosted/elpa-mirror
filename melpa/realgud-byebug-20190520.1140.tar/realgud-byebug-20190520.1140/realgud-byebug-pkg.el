;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-byebug" "20190520.1140"
  "Realgud front-end to the Ruby byebug debugger."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "24"))
  :url "https://github.com/rocky/realgud-byebug"
  :commit "f8f20b92c6b13f75cc9797921c0e28d3def48b1c"
  :revdesc "f8f20b92c6b1")
