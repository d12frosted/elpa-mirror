;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turepo" "20251222.2054"
  "Open git repository in browser."
  '((emacs "28.1"))
  :url "https://github.com/swarnimcodes/turepo"
  :commit "de22eb6752834f94104b0133e1d4115e2429e4c6"
  :revdesc "de22eb675283"
  :keywords '("vc" "git" "convenience")
  :authors '(("Swarnim Barapatre" . "swarnim14.9@hotmail.com"))
  :maintainers '(("Swarnim Barapatre" . "swarnim14.9@hotmail.com")))
