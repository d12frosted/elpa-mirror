(define-package "nexus" "20210903.1605" "REST Client for Nexus Maven Repository servers" 'nil :commit "23f058248fbe1071df1da3910b9e56b434023b67" :authors
  '(("Juergen Hoetzel" . "juergen@archlinux.org"))
  :maintainer
  '("Juergen Hoetzel" . "juergen@archlinux.org")
  :keywords
  '("comm"))
;; Local Variables:
;; no-byte-compile: t
;; End:
