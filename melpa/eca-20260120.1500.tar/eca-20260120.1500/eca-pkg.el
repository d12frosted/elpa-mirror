;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260120.1500"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "86ec6abbe45fa105d218527ed643f56c146c5b24"
  :revdesc "86ec6abbe45f"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
