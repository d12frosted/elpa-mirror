;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-paredit" "20150413.2048"
  "Paredit support for evil keybindings."
  '((evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/roman/evil-paredit"
  :commit "e058fbdcf9dbf7ad6cc77f0172d7517ef233d55f"
  :revdesc "e058fbdcf9db"
  :keywords '("paredit" "evil")
  :authors '(("Roman Gonzalez" . "romanandreg@gmail.com"))
  :maintainers '(("Roman Gonzalez" . "romanandreg@gmail.com")))
