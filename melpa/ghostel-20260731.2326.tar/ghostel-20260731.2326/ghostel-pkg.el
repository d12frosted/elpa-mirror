;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260731.2326"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "9af3ba8e2ef8b1512c8a103d84ebe71a53e95fd6"
  :revdesc "9af3ba8e2ef8"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
