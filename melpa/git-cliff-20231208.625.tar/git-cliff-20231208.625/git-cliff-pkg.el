(define-package "git-cliff" "20231208.625" "Generate and update changelog using git-cliff"
  '((emacs "27.1")
    (transient "0.4.3"))
  :commit "b96f59217c55f2ed8a8b441acb6d67169582360b" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/liuyinz/git-cliff.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
