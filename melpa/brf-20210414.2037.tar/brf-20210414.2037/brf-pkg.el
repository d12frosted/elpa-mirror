(define-package "brf" "20210414.2037" "Add functionality from the editor Brief"
  '((fringe-helper "0.1.1")
    (emacs "24.3"))
  :commit "32a6b1cfe1a73da7c4b4324775e05420b54f40e9" :authors
  '(("Mike Woolley" . "mike@bulsara.com"))
  :maintainer
  '("Mike Woolley" . "mike@bulsara.com")
  :keywords
  '("brief" "crisp" "emulations")
  :url "https://bitbucket.org/MikeWoolley/brf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
