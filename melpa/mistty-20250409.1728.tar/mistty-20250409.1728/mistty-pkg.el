;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250409.1728"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "ad4bc9b4a94ae6c0e9b5afc70554c46a112692d3"
  :revdesc "ad4bc9b4a94a"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
