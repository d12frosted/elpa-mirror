;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rom-party" "20250609.1816"
  "Rendition of jklm.fun's \"Bomb Party\" game."
  '((emacs  "28")
    (dash   "2.17.0")
    (f      "0.2.0")
    (s      "1.12.0")
    (ht     "2.3")
    (extmap "1.3")
    (compat "29.1.4.4")
    (async  "1.9.7"))
  :url "https://github.com/LaurenceWarne/rom-party.el"
  :commit "78ddc5a5973afd82675c952f9e856b8a700d0dca"
  :revdesc "78ddc5a5973a")
