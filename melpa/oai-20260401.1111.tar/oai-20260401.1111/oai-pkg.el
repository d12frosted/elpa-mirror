;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260401.1111"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "efa53537469c708a3b62bbf373a6350c4f2bb090"
  :revdesc "efa53537469c"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
