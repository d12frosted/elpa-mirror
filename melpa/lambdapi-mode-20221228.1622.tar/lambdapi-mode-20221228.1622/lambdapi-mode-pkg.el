(define-package "lambdapi-mode" "20221228.1622" "A major mode for editing Lambdapi source code"
  '((emacs "26.1")
    (eglot "1.5")
    (math-symbol-lists "1.2.1")
    (highlight "20190710.1527"))
  :commit "1f4e1a024bb0b0f3a0fdd8b5428e737adf1a68d7" :maintainers
  '(("Deducteam" . "dedukti-dev@inria.fr"))
  :maintainer
  '("Deducteam" . "dedukti-dev@inria.fr")
  :keywords
  '("languages")
  :url "https://github.com/Deducteam/lambdapi")
;; Local Variables:
;; no-byte-compile: t
;; End:
