;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fb2-reader" "20250326.2240"
  "Read FB2 and FB2.ZIP documents."
  '((emacs              "26.2")
    (f                  "0.17")
    (s                  "1.11.0")
    (dash               "2.12.0")
    (visual-fill-column "2.2")
    (async              "1.9.4"))
  :url "https://github.com/jumper047/fb2-reader"
  :commit "5244d481ed19fc9c4dff7f6394fd68e400b828a3"
  :revdesc "5244d481ed19"
  :keywords '("multimedia" "ebook" "fb2")
  :authors '(("Dmitriy Pshonko" . "jumper047@gmail.com"))
  :maintainers '(("Dmitriy Pshonko" . "jumper047@gmail.com")))
