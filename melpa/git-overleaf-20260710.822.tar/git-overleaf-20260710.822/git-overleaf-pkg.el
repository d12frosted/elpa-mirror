;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "20260710.822"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs         "29.4")
    (websocket     "1.15")
    (webdriver     "0.1")
    (magit-section "4.5"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "a18fbf3941013aa74220d80c2b90d3c7dafe7cc5"
  :revdesc "a18fbf394101"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
