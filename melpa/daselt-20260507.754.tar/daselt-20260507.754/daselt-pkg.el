;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260507.754"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "2e500f60be8e7cd930c9baf4bb782da9cbe4cfa8"
  :revdesc "2e500f60be8e"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
