(define-package "modus-themes" "20211202.832" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "5fd94ecaad594db3b851a1ca7730da0f5f32e3ce" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
