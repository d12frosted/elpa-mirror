(define-package "wildcharm-light-theme" "20230819.356" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "84dd33592018964db029d3a4bc928b8a4493457c" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
