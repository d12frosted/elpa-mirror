;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251002.1829"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "4c6546238cc72484b57b63223d90ac6ccfec619d"
  :revdesc "4c6546238cc7"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
