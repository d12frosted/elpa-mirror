(define-package "syslog-mode" "20210818.2200" "Major-mode for viewing log files & strace output"
  '((hide-lines "20130623")
    (ov "20150311"))
  :commit "975e45ec7ef33c5588c7dfe7764a11508af7480d" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
