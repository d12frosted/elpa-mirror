(define-package "gdscript-mode" "20230426.1923" "Major mode for Godot's GDScript language"
  '((emacs "26.3"))
  :commit "a48ad045024d34aee28607ee0afc572308b6e1f6" :authors
  '(("Nathan Lovato <nathan@gdquest.com>, Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers
  '((nil . "nathan@gdquest.com"))
  :maintainer
  '(nil . "nathan@gdquest.com")
  :keywords
  '("languages")
  :url "https://github.com/godotengine/emacs-gdscript-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
