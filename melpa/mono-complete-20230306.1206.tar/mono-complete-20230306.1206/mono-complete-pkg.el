(define-package "mono-complete" "20230306.1206" "Completion suggestions with multiple back-ends"
  '((emacs "28.1"))
  :commit "376268b6429ad2296913b03faccd0ac9dfdd465c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mono-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
