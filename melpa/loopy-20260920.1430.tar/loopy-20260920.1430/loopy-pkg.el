;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260920.1430"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://codeberg.org/okamsn/loopy"
  :commit "c50c15d87709ece2bee7f45d6a6d906bb8524aac"
  :revdesc "c50c15d87709"
  :keywords '("extensions"))
