(define-package "evil-tutor-sc" "20230619.429" "Simplified Chinese Evil-tutor"
  '((evil "1.0.9")
    (evil-tutor "0.1"))
  :commit "259d7276479159d9b628354c6c5578b42263e6e9" :authors
  '(("clsty" . "ph-tyhu@outlook.com"))
  :maintainers
  '(("clsty" . "ph-tyhu@outlook.com"))
  :maintainer
  '("clsty" . "ph-tyhu@outlook.com")
  :keywords
  '("convenience" "editing" "evil" "chinese")
  :url "https://github.com/clsty/evil-tutor-sc")
;; Local Variables:
;; no-byte-compile: t
;; End:
