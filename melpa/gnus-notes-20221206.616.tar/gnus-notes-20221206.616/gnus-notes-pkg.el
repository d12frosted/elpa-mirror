(define-package "gnus-notes" "20221206.616" "Keep handy notes of read Gnus articles with helm and org"
  '((emacs "27.1")
    (bbdb "3.1")
    (helm "3.1")
    (hydra "0.13.0")
    (org "8.3")
    (s "0.0")
    (lv "0.0")
    (async "1.9.1"))
  :commit "9996b382c5c7b4f944a716baac69b556ef181462" :authors
  '(("Deus Max" . "deusmax@gmx.com"))
  :maintainer
  '("Deus Max" . "deusmax@gmx.com")
  :keywords
  '("convenience" "mail" "bbdb" "gnus" "helm" "org" "hydra")
  :url "https://github.com/deusmax/gnus-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
