;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-shell-keybind" "20230927.1036"
  "Interactively bind a key to shell commands."
  '((emacs "24"))
  :url "https://github.com/eyeinsky/quick-shell-keybind"
  :commit "be830a69cf7eec92d4ea269fd389ac39b0c162f1"
  :revdesc "be830a69cf7e"
  :keywords '("maint" "convenience" "processes")
  :authors '(("eyeinsky" . "eyeinsky9@gmail.com"))
  :maintainers '(("eyeinsky" . "eyeinsky9@gmail.com")))
