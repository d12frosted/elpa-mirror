(define-package "fanyi" "20210820.423" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "5f4fd0dbee514bada012ab3ecc9c767b8910828e" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
