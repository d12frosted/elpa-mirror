(define-package "ob-restclient" "20231020.522" "org-babel functions for restclient-mode"
  '((restclient "0"))
  :commit "940e74493da55665cc5d807865f0cebf8ee137b2" :authors
  '(("Alf Lervåg"))
  :maintainers
  '(("Alf Lervåg"))
  :maintainer
  '("Alf Lervåg")
  :keywords
  '("literate programming" "reproducible research")
  :url "https://github.com/alf/ob-restclient.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
