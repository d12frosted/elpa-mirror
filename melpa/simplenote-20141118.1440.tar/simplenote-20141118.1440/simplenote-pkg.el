;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simplenote" "20141118.1440"
  "Interact with simple-note.appspot.com."
  ()
  :url "https://github.com/dotemacs/simplenote.el"
  :commit "734603e877b2d642162ca45f799d2f7b956d2ea0"
  :revdesc "734603e877b2"
  :keywords '("simplenote")
  :authors '(("Konstantinos Efstathiou" . "konstantinos@efstathiou.gr"))
  :maintainers '(("Konstantinos Efstathiou" . "konstantinos@efstathiou.gr")))
