;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260514.6"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "2032da4acd0c73f1d09df9a31a7af2f8a9a74cf8"
  :revdesc "2032da4acd0c"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
