(define-package "snap-indent" "20221220.1908" "Simple automatic indentation"
  '((emacs "24.1"))
  :commit "6020a1784015ba28f439f41d4d8c261c3481079f" :authors
  '(("Jeff Valk" . "jv@jeffvalk.com"))
  :maintainers
  '(("Jeff Valk" . "jv@jeffvalk.com"))
  :maintainer
  '("Jeff Valk" . "jv@jeffvalk.com")
  :keywords
  '("indent" "tools" "convenience")
  :url "https://github.com/jeffvalk/snap-indent")
;; Local Variables:
;; no-byte-compile: t
;; End:
