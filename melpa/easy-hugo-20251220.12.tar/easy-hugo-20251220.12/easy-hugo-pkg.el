;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-hugo" "20251220.12"
  "Write blogs made with hugo by markdown or org-mode."
  '((emacs     "25.1")
    (request   "0.3.0")
    (transient "0.3.6"))
  :url "https://github.com/masasam/emacs-easy-hugo"
  :commit "c738ec015a9763d0dbfa44b3bfbfd17e41802943"
  :revdesc "c738ec015a97")
