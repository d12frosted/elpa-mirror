;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claudia" "20241104.1552"
  "Claude AI integration."
  '((emacs         "29.1")
    (uuidgen       "0.3")
    (markdown-mode "2.3"))
  :url "https://github.com/mzacho/claudia"
  :commit "c86f741f77953a46cdd0472402768b218b0d2165"
  :revdesc "c86f741f7795"
  :keywords '("ai" "tools" "productivity" "codegen")
  :authors '(("Martin Zacho" . "hi@martinzacho.net"))
  :maintainers '(("Martin Zacho" . "hi@martinzacho.net")))
