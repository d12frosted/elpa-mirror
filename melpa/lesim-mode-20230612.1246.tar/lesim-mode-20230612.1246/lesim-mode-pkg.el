(define-package "lesim-mode" "20230612.1246" "Major mode for Learning Simulator scripts"
  '((emacs "28.1"))
  :commit "214989864d3499f5c6e96dfa67ba7b3cf06a085e" :authors
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainer
  '("Stefano Ghirlanda" . "drghirlanda@gmail.com")
  :keywords
  '("languages" "faces")
  :url "https://github.com/drghirlanda/lesim-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
