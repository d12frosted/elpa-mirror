;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scala-ts-mode" "20260826.1159"
  "An tree-sitter based major-mode for Scala."
  '((emacs "29.1"))
  :url "https://github.com/KaranAhlawat/scala-ts-mode"
  :commit "e14bc7c6a2a7404111ee124b83b4acf55c80321e"
  :revdesc "e14bc7c6a2a7"
  :keywords '("emacs" "scala" "languages" "tree-sitter" "scala-ts-mode")
  :authors '(("Karan Ahlawat" . "ahlawatkaran12@gmail.com"))
  :maintainers '(("Karan Ahlawat" . "ahlawatkaran12@gmail.com")))
