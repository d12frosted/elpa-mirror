;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250428.718"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "6cfe19e85bfa73df89c2a99f3206a8f27355ab85"
  :revdesc "6cfe19e85bfa"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
