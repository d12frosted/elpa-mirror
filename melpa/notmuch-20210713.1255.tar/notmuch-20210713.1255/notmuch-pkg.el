(define-package "notmuch" "20210713.1255" "run notmuch within emacs" 'nil :commit "1a7f9fe055fb40b9646bb8efac107601009723bd" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
