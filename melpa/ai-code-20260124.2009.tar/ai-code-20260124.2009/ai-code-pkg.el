;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260124.2009"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "408000a1684e2571877bd237f722d86e70c12a47"
  :revdesc "408000a1684e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
