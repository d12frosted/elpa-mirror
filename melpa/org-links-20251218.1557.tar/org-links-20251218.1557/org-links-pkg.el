;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20251218.1557"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "9c7f532c233daa50aa60a5719eeda837410d5fce"
  :revdesc "9c7f532c233d"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
