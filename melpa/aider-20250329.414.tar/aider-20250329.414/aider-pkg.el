;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250329.414"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "4aa24f139dfd5d77f17c7fff8d14fca750e2e7ce"
  :revdesc "4aa24f139dfd"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
