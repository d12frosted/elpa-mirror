(define-package "burly" "20210621.653" "Save and restore frame/window configurations with buffers"
  '((emacs "26.3")
    (map "2.1"))
  :commit "b97b519e5e1b5b0b0e37f708b853da5206e8219c" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
