(define-package "magit-section" "20210806.1607" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "2.18.1"))
  :commit "456735401b6524f822fecc3fbb49a5c9199f9d4d" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
