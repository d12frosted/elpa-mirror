(define-package "gnosis" "20240221.2216" "Spaced Repetition System For Note Taking & Self Testing"
  '((emacs "27.2")
    (compat "29.1.4.2")
    (emacsql "20240124"))
  :commit "f226d964d3393a3f7c3e52c43ab8cfe27929e5c5" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions")
  :url "https://thanosapollo.org/projects/gnosis")
;; Local Variables:
;; no-byte-compile: t
;; End:
