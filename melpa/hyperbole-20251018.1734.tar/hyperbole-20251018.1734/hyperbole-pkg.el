;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251018.1734"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "a9ccfa94b6724b614d4c019172b6a694003c7e8f"
  :revdesc "a9ccfa94b672"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
