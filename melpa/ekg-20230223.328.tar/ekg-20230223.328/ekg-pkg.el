(define-package "ekg" "20230223.328" "A system for recording and linking information"
  '((triples "0.2.5")
    (emacs "28.1"))
  :commit "a4c03f170a6aa0e691e4732f34204952ccef03f8" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
