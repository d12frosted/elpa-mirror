(define-package "dirvish" "20211214.451" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (posframe "1.1.2"))
  :commit "2290f1bd3cc2731e8a89232213c8231818210d72" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
