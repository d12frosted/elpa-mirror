(define-package "dirvish" "20211214.451" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (posframe "1.1.2"))
  :commit "9af3610072a3b8e990afdb0f8a7d6e48f2bbf8ec" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
