(define-package "bqn-mode" "20230422.1128" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "d66fe13e5cf98550997aef7e6856677e7199d31d" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
