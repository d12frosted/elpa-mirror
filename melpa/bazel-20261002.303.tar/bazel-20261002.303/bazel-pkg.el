;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261002.303"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "dd177b3f4f85b2c88f093aa037718e63665a332e"
  :revdesc "dd177b3f4f85"
  :keywords '("build tools" "languages"))
