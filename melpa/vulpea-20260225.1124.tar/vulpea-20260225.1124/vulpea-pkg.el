;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260225.1124"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "2d2bd7339e21091f22cbce27a5d9884a872392f8"
  :revdesc "2d2bd7339e21"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
