;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sidebuf" "20260415.2249"
  "Buffer list sidebar panel."
  '((emacs "27.1"))
  :url "https://github.com/rain-64/sidebuf"
  :commit "89ca26d1859e89759f00065c07904d3ef5c80a4f"
  :revdesc "89ca26d1859e"
  :keywords '("convenience" "buffers")
  :authors '(("rain-64" . "https://github.com/rain-64"))
  :maintainers '(("rain-64" . "https://github.com/rain-64")))
