(define-package "kiwix" "20210113.1834" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (request "0.3.0"))
  :commit "e5821f5ccb34262aedcb4ea3a19e583c6a97e2f8" :authors
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
