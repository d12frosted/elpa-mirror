;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conflict-buttons" "20260223.740"
  "Clickable buttons for smerge-mode conflicts."
  '((emacs "26.1"))
  :url "https://git.andros.dev/andros/conflict-buttons.el"
  :commit "22af851d6a0cdd226ef7ba0db54fa096c8ddf235"
  :revdesc "22af851d6a0c"
  :keywords '("vc" "tools" "convenience")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
