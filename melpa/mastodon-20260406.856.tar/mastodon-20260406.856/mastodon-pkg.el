;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260406.856"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "5bba23045efda9f63c36ac431bec8f318a55e76a"
  :revdesc "5bba23045efd"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
