;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nael" "20251230.1417"
  "Major mode for Lean."
  '((emacs "29.1"))
  :url "https://codeberg.org/mekeor/nael"
  :commit "858444193a932611b5df77f25ced56eac69d19a3"
  :revdesc "858444193a93"
  :keywords '("languages")
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
