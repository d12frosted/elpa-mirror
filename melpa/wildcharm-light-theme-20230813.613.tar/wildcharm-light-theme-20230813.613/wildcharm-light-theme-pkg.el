(define-package "wildcharm-light-theme" "20230813.613" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "7cec771ff276e51ee191f1362e1c314ca243fb36" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
