;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ext" "20261113.1537"
  "VHDL Extensions."
  '((emacs        "29.1")
    (vhdl-ts-mode "0.3.3")
    (lsp-mode     "8.0.0")
    (rg           "2.3.0")
    (hydra        "0.15.0")
    (flycheck     "32")
    (async        "1.9.7"))
  :url "https://github.com/gmlarumbe/vhdl-ext"
  :commit "e07c4945283f6fccc644f292f44cf9993d0fcb4c"
  :revdesc "e07c4945283f"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
