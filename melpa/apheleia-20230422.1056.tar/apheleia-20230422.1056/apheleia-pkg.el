(define-package "apheleia" "20230422.1056" "Reformat buffer stably"
  '((emacs "26"))
  :commit "e9e595f003605a7e366776c7a1715dc7093e29d5" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/raxod502/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
