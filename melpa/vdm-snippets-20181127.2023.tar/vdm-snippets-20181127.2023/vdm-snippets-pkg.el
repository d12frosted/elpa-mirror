(define-package "vdm-snippets" "20181127.2023" "YASnippets for VDM mode"
  '((emacs "24")
    (yasnippet "0.13.0"))
  :commit "e131edb0d35de28bd47d6128dd70d9a6fc46e0fa" :authors
  '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com"))
  :maintainer
  '("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/peterwvj/vdm-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
