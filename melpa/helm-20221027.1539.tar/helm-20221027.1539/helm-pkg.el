(define-package "helm" "20221027.1539" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.8")
    (popup "0.5.3"))
  :commit "612b64b6ca18e7f51ec3636e0d2655e77cd59f6a" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
