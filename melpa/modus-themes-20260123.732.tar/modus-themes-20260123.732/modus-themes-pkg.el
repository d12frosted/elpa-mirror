;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260123.732"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "c57f158886c3c102b8a4c60afed5d10acef22f51"
  :revdesc "c57f158886c3"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
