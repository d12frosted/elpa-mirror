;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh" "20260623.1820"
  "Consulting GitHub Client."
  '((emacs         "29.4")
    (consult       "2.0")
    (markdown-mode "2.6")
    (ox-gfm        "1.0")
    (yaml          "1.2.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "7b0fba0dc81a446c95cd39fa2a6adcd39501df9d"
  :revdesc "7b0fba0dc81a"
  :keywords '("convenience" "matching" "tools" "vc"))
