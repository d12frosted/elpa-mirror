(define-package "ac-html-bootstrap" "20150724.950" "auto complete bootstrap3/fontawesome classes for `ac-html' and `company-web'"
  '((web-completion-data "0.1"))
  :commit "591e1e996c820da218ea1eee0a500c556769f128" :authors
  '(("Olexandr Sydorchuk" . "olexandr.syd@gmail.com"))
  :maintainer
  '("Olexandr Sydorchuk" . "olexandr.syd@gmail.com")
  :keywords
  '("html" "auto-complete" "bootstrap" "cssx")
  :url "https://github.com/osv/ac-html-bootstrap")
;; Local Variables:
;; no-byte-compile: t
;; End:
