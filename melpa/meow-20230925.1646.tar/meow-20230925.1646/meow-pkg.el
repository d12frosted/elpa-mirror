(define-package "meow" "20230925.1646" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "ec94fa609bcbf7a3ad29bb09a9bf39943cc254e9" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
