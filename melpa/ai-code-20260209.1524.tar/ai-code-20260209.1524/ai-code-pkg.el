;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260209.1524"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a5143fce3d8e789630389b11c657b4355123c72e"
  :revdesc "a5143fce3d8e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
