(define-package "osm" "20230429.924" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "65f7874919548d54f4785ae90f11a8782517fd71" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
