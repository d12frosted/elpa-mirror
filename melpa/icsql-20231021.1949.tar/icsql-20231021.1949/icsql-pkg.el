;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "icsql" "20231021.1949"
  "Interactive iSQL iteraface to ciSQL."
  '((emacs          "26")
    (choice-program "0.13")
    (buffer-manage  "0.12"))
  :url "https://github.com/plandes/icsql"
  :commit "24c013486fd56386946eadc9a2f653e9f0d3f4de"
  :revdesc "24c013486fd5"
  :keywords '("isql" "sql" "rdbms" "data"))
