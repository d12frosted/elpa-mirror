(define-package "srfi" "20231030.539" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "eafeda97eb8942e5e2f1fe6ebf7472de9ce405dd" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
