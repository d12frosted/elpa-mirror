;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260531.1658"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6f2e6dcc002c71ea342663ed54b80c5d35a49e85"
  :revdesc "6f2e6dcc002c")
