(define-package "proof-general" "20220707.758" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "0ee2b759391fbd5f82a5831c891aab1890aa2ea4" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
