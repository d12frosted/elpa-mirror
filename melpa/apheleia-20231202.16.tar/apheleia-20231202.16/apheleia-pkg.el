(define-package "apheleia" "20231202.16" "Reformat buffer stably"
  '((emacs "27"))
  :commit "8f512dba3ee2eabae0dbfd8289b89d54c132cb87" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
