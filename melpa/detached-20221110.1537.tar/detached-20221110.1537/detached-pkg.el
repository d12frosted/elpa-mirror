(define-package "detached" "20221110.1537" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "91d57497aa2c138ed191c165b68d04e0c56d2c8e" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
