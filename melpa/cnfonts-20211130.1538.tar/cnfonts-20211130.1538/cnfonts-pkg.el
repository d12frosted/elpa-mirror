(define-package "cnfonts" "20211130.1538" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "bfc67e02f593d747532ec39284b771ec05df58d3" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
