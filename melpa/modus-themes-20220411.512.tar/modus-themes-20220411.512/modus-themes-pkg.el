(define-package "modus-themes" "20220411.512" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "df59b4ca8d850722845a125722aa0949a5603a26" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
