;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260122.1320"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "d6126f95e019825f5c7a47440c07a2e3045662f7"
  :revdesc "d6126f95e019"
  :keywords '("convenience"))
