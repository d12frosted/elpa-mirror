(define-package "mode-line-idle" "20230116.951" "Evaluate mode line content when idle"
  '((emacs "28.1"))
  :commit "be393eb5c60382ed297b59f69292917bfc9bf60f" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mode-line-idle")
;; Local Variables:
;; no-byte-compile: t
;; End:
