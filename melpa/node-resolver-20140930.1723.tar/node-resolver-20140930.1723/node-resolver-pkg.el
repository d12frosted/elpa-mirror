;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "node-resolver" "20140930.1723"
  "Hook to install node modules in background."
  '((cl-lib "0.5"))
  :url "https://github.com/meandavejustice/node-resolver.el"
  :commit "ef9d0486907a746a80b02ffc6208a09c168a9f7c"
  :revdesc "ef9d0486907a"
  :keywords '("convenience" "nodejs" "javascript" "npm"))
