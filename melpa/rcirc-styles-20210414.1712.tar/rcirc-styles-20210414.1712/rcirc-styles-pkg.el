;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rcirc-styles" "20210414.1712"
  "Support mIRC-style color and attribute codes."
  '((cl-lib "0.5"))
  :url "https://github.com/aaron-em/rcirc-styles.el"
  :commit "dd06ec5fa455131788bbc885fcfaaec16b08f13b"
  :revdesc "dd06ec5fa455")
