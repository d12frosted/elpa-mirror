(define-package "kubernetes" "20211114.420" "Magit-like porcelain for Kubernetes."
  '((emacs "25.1")
    (dash "2.12.0")
    (magit-section "3.1.1")
    (magit-popup "2.13.0")
    (with-editor "3.0.4")
    (transient "0.3.0"))
  :commit "4b740d88c6dcb091d701f74ddcf53e3732999ac9" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool"))
;; Local Variables:
;; no-byte-compile: t
;; End:
