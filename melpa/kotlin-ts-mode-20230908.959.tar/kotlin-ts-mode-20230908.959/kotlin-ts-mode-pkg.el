(define-package "kotlin-ts-mode" "20230908.959" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "8e7ce76db12e917dafb3650342447691b2fd0497" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
