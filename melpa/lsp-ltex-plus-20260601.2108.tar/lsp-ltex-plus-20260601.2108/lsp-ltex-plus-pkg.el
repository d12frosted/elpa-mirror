;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "20260601.2108"
  "Grammar and spell checking for LaTeX, Markdown, Org and more."
  '((emacs    "27.1")
    (lsp-mode "6.0"))
  :url "https://github.com/ltex-plus/emacs-ltex-plus"
  :commit "03f00db7f3030f47f3fe21709835a153df22f030"
  :revdesc "03f00db7f303"
  :keywords '("lsp" "grammar" "spelling" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
