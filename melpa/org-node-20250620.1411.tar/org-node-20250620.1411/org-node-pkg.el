;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250620.1411"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.16.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "59f13df750bbf3cfcfd6bed4bd6d780b182f2e19"
  :revdesc "59f13df750bb"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
