(define-package "dwim-shell-command" "20220814.1143" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "f4667883e7dad0e4b3318459fb0e634ec7b8ceac" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
