(define-package "dirvish" "20230519.706" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "b835e85d029be6af322881f22106923e4be1f5bf" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainers
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
