;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260316.203"
  "A q editing mode."
  '((emacs "24"))
  :url "https://github.com/psaris/q-mode"
  :commit "f0e2418d660f48d793a8ba2887df8e854e778741"
  :revdesc "f0e2418d660f"
  :keywords '("faces" "files" "q"))
