;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "20261005.1637"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "a258ba88cf55e22fa67ff9c50538dd71dd0d4683"
  :revdesc "a258ba88cf55"
  :keywords '("convenience"))
