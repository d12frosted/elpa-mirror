;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250311.1054"
  "Ollama Buddy: Your Friendly AI Assistant."
  '((emacs "26.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "fbf03fc2b2a9ec1f9691528d9288f4a4f261bc09"
  :revdesc "fbf03fc2b2a9"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
