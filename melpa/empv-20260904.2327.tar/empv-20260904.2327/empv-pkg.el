;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260904.2327"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "876f9d39077216d5bcec9d96e1f5dfad8be2a60d"
  :revdesc "876f9d390772"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
