;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "angular-snippets" "20140514.523"
  "Yasnippets for AngularJS."
  '((s    "1.4.0")
    (dash "1.2.0"))
  :url "https://github.com/magnars/angular-snippets.el"
  :commit "af5ae0a4a8603b040446c28afcf6ca01a8b4bd7b"
  :revdesc "af5ae0a4a860"
  :keywords '("snippets")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
