(define-package "weblorg" "20220312.2008" "Static Site Generator for org-mode"
  '((templatel "0.1.6")
    (emacs "26.1"))
  :commit "b2bb79ed2c532cad5b03455d8cae887ddb803db3" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
