;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250317.1411"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (llama  "0.5.0")
    (el-job "2.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "ae5eeb008c0a878f1e6f8eded3bdbd15b396b93a"
  :revdesc "ae5eeb008c0a"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
