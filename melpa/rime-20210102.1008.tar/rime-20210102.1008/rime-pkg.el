(define-package "rime" "20210102.1008" "Rime input method"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1")
    (popup "0.5.3")
    (posframe "0.1.0"))
  :commit "2bc3035c626d65d9e3d5b54814bc28f8db18ab3e" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "input-method")
  :url "https://www.github.com/DogLooksGood/emacs-rime")
;; Local Variables:
;; no-byte-compile: t
;; End:
