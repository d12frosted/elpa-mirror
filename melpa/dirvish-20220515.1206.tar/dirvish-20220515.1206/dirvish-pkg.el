(define-package "dirvish" "20220515.1206" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "3b0533ede1be2408296db028a5df76d4a98184f0" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
