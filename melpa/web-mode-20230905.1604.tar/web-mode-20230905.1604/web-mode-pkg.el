(define-package "web-mode" "20230905.1604" "major mode for editing web templates"
  '((emacs "23.1"))
  :commit "325e1c9398fe727ace3605a989f8c4088dc477a4" :authors
  '(("François-Xavier Bois"))
  :maintainers
  '(("François-Xavier Bois" . "fxbois@gmail.com"))
  :maintainer
  '("François-Xavier Bois" . "fxbois@gmail.com")
  :keywords
  '("languages")
  :url "https://web-mode.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
