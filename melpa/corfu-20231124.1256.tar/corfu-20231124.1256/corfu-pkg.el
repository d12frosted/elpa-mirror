(define-package "corfu" "20231124.1256" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "007437dc81b41d7165cf1d84772e602b6193726c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
