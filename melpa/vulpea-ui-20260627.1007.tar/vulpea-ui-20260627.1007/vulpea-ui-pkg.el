;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20260627.1007"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.4.0")
    (vui    "1.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "2a6a5cdce6111e3d1642d3a4b7d8b62eab229fcc"
  :revdesc "2a6a5cdce611"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
