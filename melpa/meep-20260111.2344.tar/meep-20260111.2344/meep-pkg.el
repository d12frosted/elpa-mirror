;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260111.2344"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "3e3dce277d2164a17eb5ea7bb200249c65e7c100"
  :revdesc "3e3dce277d21"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
