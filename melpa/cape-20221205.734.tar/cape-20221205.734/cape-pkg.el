(define-package "cape" "20221205.734" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "6d7303e300dceb717c69b29f702fc636f9cac4e8" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
