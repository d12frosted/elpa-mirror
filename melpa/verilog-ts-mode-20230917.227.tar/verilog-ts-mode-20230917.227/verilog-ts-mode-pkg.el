(define-package "verilog-ts-mode" "20230917.227" "Verilog Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "316db4b087e363ccc5f1b7e58bce8e1976347a40" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
