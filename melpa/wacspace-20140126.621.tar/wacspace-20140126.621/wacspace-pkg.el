(define-package "wacspace" "20140126.621" "The WACky WorkSPACE manager for emACS"
  '((dash "1.2.0")
    (cl-lib "0.2"))
  :commit "b951995c204ff23699d2bda515a96221147a725d" :authors
  '(("Emanuel Evans" . "emanuel.evans@gmail.com"))
  :maintainer
  '("Emanuel Evans" . "emanuel.evans@gmail.com")
  :keywords
  '("workspace")
  :url "http://github.com/shosti/wacspace.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
