;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250221.838"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "ea4d1ed66b1f7d4b59c8e4e4c13495208ee09f95"
  :revdesc "ea4d1ed66b1f"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
