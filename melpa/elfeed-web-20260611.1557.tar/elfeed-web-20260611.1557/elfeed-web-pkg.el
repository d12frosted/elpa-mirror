;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-web" "20260611.1557"
  "Web interface to Elfeed."
  '((emacs        "28.1")
    (compat       "31")
    (elfeed       "4.0.0")
    (simple-httpd "1.6"))
  :url "https://github.com/emacs-elfeed/elfeed-web"
  :commit "0bef963f7eaccee21571844730586d8dafa4249f"
  :revdesc "0bef963f7eac"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
