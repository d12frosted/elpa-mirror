(define-package "lsp-grammarly" "20221231.1655" "LSP Clients for Grammarly"
  '((emacs "27.1")
    (lsp-mode "6.1")
    (grammarly "0.3.0")
    (request "0.3.0")
    (s "1.12.0")
    (ht "2.3"))
  :commit "6d111728f9d062d723bb88bd462b6eafe5cafe3f" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "lsp" "grammarly" "checker")
  :url "https://github.com/emacs-grammarly/lsp-grammarly")
;; Local Variables:
;; no-byte-compile: t
;; End:
