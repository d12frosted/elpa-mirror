(define-package "keg" "20220307.936" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "c28ce03bbaee51874246aa798c8532a1c0df7495" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
