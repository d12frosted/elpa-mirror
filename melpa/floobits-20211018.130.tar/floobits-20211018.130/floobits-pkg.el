(define-package "floobits" "20211018.130" "Floobits plugin for real-time collaborative editing"
  '((json "1.2")
    (highlight "0"))
  :commit "ce84783dffb8768b2b81af3b341649e336e8e956" :authors
  '(("Matt Kaniaris")
    ("Geoff Greer"))
  :maintainer
  '("Matt Kaniaris")
  :keywords
  '("comm" "tools")
  :url "http://github.com/Floobits/floobits-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
