(define-package "transient" "20231102.1149" "Transient commands"
  '((emacs "26.1")
    (compat "29.1.4.1")
    (seq "2.24"))
  :commit "0dda40e8b6c0ed2bcc27597d07a5897547654072" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
