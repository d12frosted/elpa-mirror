(define-package "eldev" "20210404.1603" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "02cc57945a4ffdca89e86e6195ce8446c166f836" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
