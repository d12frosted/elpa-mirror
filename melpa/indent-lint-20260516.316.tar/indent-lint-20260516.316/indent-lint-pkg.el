;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-lint" "20260516.316"
  "Async indentation checker."
  '((emacs       "27.1")
    (async-await "1.0")
    (async       "1.9.4")
    (promise     "1.1"))
  :url "https://github.com/conao3/indent-lint.el"
  :commit "f821a2426e78e7b04a6b45c2d8fa734fc0e52fd6"
  :revdesc "f821a2426e78"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
