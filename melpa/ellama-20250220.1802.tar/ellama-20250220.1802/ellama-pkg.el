;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20250220.1802"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.22.0")
    (spinner   "1.7.4")
    (transient "0.7")
    (compat    "29.1")
    (posframe  "1.4.0"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "231c2600a5164ece34b65f2c3aa97c577f1227eb"
  :revdesc "231c2600a516"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
