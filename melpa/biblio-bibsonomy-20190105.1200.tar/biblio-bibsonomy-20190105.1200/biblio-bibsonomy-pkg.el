;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biblio-bibsonomy" "20190105.1200"
  "Lookup bibliographic entries from Bibsonomy."
  '((emacs       "24.4")
    (biblio-core "0.2"))
  :url "https://github.com/andreasjansson/biblio-bibsonomy/"
  :commit "fbdb3ecfcd88c179a2358d7967f7ecafef725835"
  :revdesc "fbdb3ecfcd88"
  :keywords '("bib" "tex" "bibsonomy"))
