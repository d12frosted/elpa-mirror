;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251020.803"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "a492dbe38022a4e029111bcc83a96ed6e189d02c"
  :revdesc "a492dbe38022"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
