;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250625.1253"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.17.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "03ec7311af247302460413ddf4f9810fb6f9085f"
  :revdesc "03ec7311af24"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
