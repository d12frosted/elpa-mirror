;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251020.1525"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "7c3d359a97efae246fde3f643718179b224002f8"
  :revdesc "7c3d359a97ef"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
