(define-package "python-mode" "20201125.2101" "Python major mode" 'nil :commit "3c29bfebc2f60e854e0e2ac0214f2d20db274cbd")
;; Local Variables:
;; no-byte-compile: t
;; End:
