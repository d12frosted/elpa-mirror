;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-table-highlight" "20250717.945"
  "Highlight Org table columns and rows."
  '((emacs "27.1"))
  :url "https://github.com/llcc/org-table-highlight"
  :commit "684b3eb75d22eebe036abb8992fa93e8d8f382d9"
  :revdesc "684b3eb75d22"
  :keywords '("org-table" "convenience"))
