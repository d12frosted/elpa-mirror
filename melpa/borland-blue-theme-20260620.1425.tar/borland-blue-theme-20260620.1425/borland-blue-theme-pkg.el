;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borland-blue-theme" "20260620.1425"
  "Blue/yellow theme based on old DOS Borland/Turbo C IDE."
  '((emacs "24.1"))
  :url "https://github.com/fourier/borland-blue-theme"
  :commit "c24ef5aa16fed6727696b0ea71bf154889e4ee0a"
  :revdesc "c24ef5aa16fe"
  :keywords '("themes")
  :authors '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom"))
  :maintainers '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom")))
