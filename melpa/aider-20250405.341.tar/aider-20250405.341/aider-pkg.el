;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250405.341"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "c9e72138d1fe41eca4eb37207037fd51981d0e83"
  :revdesc "c9e72138d1fe"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
