;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyfun-mode" "20261122.1734"
  "Major mode for the Pyfun language."
  '((emacs "29.1"))
  :url "https://github.com/simontreanor/Pyfun"
  :commit "3203c8456afbf6b7ba641b0e754aa934ec5df7e9"
  :revdesc "3203c8456afb"
  :keywords '("languages")
  :authors '(("Simon Treanor" . "https://github.com/simontreanor"))
  :maintainers '(("Simon Treanor" . "https://github.com/simontreanor")))
