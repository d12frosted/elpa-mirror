;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20260215.2013"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "1d2983986a32da95c878ce05929f43ecc370c82c"
  :revdesc "1d2983986a32"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
