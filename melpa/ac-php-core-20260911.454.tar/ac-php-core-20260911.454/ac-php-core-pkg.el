;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20260911.454"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "b626cc6b3a343b2431f2e13b241b1612da5fc3f4"
  :revdesc "b626cc6b3a34"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
