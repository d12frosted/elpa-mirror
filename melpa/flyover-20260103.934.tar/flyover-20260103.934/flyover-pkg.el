;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20260103.934"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "e3a9d4fb269832cf53dd3cc5cc13b0941ac8af29"
  :revdesc "e3a9d4fb2698"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
