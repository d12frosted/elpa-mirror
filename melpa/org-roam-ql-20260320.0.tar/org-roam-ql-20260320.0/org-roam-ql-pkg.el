;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "20260320.0"
  "Interface to query and view results from org-roam."
  '((emacs         "28")
    (org-roam      "2.2.0")
    (s             "1.12.0")
    (magit-section "3.3.0")
    (transient     "0.4")
    (dash          "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "a1ce63cabf6a9352098750fcbc4a719f676717be"
  :revdesc "a1ce63cabf6a")
