;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260326.830"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "dc5048c0dc0743b3b64ab5cf08fdb28173a57ad2"
  :revdesc "dc5048c0dc07"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
