;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "20260704.2353"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "bbc28a629405de628880d8fb485fce23ff7fab69"
  :revdesc "bbc28a629405"
  :keywords '("languages" "tools"))
