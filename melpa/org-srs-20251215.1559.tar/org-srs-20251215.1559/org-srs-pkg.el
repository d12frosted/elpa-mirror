;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251215.1559"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "b7ccef47278f7f39b39b6bf48aa3fe95d2f9a2ec"
  :revdesc "b7ccef47278f"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
