;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260212.2202"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "d36f3281a04a659080f02d5173b369d1c93f96a0"
  :revdesc "d36f3281a04a"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
