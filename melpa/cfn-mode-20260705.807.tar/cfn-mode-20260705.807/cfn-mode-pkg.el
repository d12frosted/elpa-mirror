;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260705.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "407094bd072103d43fddb3e186077d65f4f62f26"
  :revdesc "407094bd0721"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
