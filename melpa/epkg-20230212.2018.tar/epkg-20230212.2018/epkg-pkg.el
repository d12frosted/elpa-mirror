(define-package "epkg" "20230212.2018" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "29.1.3.4")
    (closql "20210927")
    (llama "0.2.0"))
  :commit "c101e3458fb458f6a57dc811966e28df3fe06c2a" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
