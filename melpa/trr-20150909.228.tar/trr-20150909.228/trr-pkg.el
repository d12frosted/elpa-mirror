(define-package "trr" "20150909.228" "a type-writing training program on GNU Emacs." 'nil :commit "7500ae0a05a3e26888949208afcd0185cc1b1404" :authors
  '(("YAMAMOTO Hirotaka" . "ymmt@is.s.u-tokyo.ac.jp")
    ("KATO Kenji" . "kato@suri.co.jp")
    ("	*Original Author")
    ("INAMURA You" . "inamura@icot.or.jp")
    ("	*Original Author"))
  :maintainer
  '("YAMAMOTO Hirotaka" . "ymmt@is.s.u-tokyo.ac.jp")
  :keywords
  '("games" "faces"))
;; Local Variables:
;; no-byte-compile: t
;; End:
