;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nice-org-html" "20241210.1138"
  "Prettier org-to-html export."
  '((emacs   "25.1")
    (s       "1.13.0")
    (dash    "2.19.1")
    (htmlize "1.58")
    (uuidgen "1.0"))
  :url "https://github.com/ewantown/nice-org-html"
  :commit "3127f12db7fb294d196fc9722cd411361ceca7f1"
  :revdesc "3127f12db7fb"
  :keywords '("org" "org-export" "html" "css" "js" "tools")
  :authors '(("Ewan Townshend" . "ewan@etown.dev"))
  :maintainers '(("Ewan Townshend" . "ewan@etown.dev")))
