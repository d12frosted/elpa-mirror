(define-package "pyim" "20210316.300" "A Chinese input method support quanpin, shuangpin, wubi and cangjie."
  '((emacs "24.4")
    (async "1.6")
    (xr "1.13"))
  :commit "051903524d7656a1e31f028fdbf378e6b34297e8" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
