;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260507.719"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "8018b2c855fbb871293c3a32d64837e265cd2a56"
  :revdesc "8018b2c855fb"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
