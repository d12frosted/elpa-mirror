;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260425.1602"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "96540e3ab4dd38821cd0061f83e3cf2212559813"
  :revdesc "96540e3ab4dd"
  :keywords '("hypermedia"))
