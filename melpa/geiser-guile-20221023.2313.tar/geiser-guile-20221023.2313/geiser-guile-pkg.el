(define-package "geiser-guile" "20221023.2313" "Guile and Geiser talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (geiser "0.26.1"))
  :commit "68fb9f4724440ddb854421f51a37ee88e1044af2" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
