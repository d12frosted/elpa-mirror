(define-package "jest" "20220629.1825" "helpers to run jest"
  '((emacs "24.4")
    (dash "2.18.0")
    (magit-popup "2.12.0")
    (projectile "0.14.0")
    (s "1.12.0")
    (js2-mode "20180301")
    (cl-lib "0.6.1"))
  :commit "0bb565aa86454bb5b24ba61f83e73d6476505f1e" :authors
  '(("Edmund Miller" . "edmund.a.miller@gmail.com"))
  :maintainer
  '("Edmund Miller" . "edmund.a.miller@gmail.com")
  :keywords
  '("jest" "javascript" "testing")
  :url "https://github.com/emiller88/emacs-jest/")
;; Local Variables:
;; no-byte-compile: t
;; End:
