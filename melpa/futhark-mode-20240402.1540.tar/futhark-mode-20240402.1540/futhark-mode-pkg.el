(define-package "futhark-mode" "20240402.1540" "major mode for editing Futhark source files"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "ebc4a5cce499e601e9e80dc79cf3e450dccd07e8" :keywords
  '("languages")
  :url "https://github.com/diku-dk/futhark-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
