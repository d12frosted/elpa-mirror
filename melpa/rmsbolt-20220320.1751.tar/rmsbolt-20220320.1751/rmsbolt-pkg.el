(define-package "rmsbolt" "20220320.1751" "A compiler output viewer"
  '((emacs "25.1"))
  :commit "7a964319baad91ebbbb90aa5262bd136ef358347" :authors
  '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainer
  '("Jay Kamat" . "jaygkamat@gmail.com")
  :keywords
  '("compilation" "tools")
  :url "http://gitlab.com/jgkamat/rmsbolt")
;; Local Variables:
;; no-byte-compile: t
;; End:
