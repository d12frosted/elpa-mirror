;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260131.2116"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "849312bf57b8733719019a592661506d93ad807c"
  :revdesc "849312bf57b8"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
