(define-package "loopy" "20230812.1837" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22")
    (compat "29.1.3"))
  :commit "9cae74c01fff32b02e8b4ac082a8fca5d8da7a7d" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
