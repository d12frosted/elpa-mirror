;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "burnish" "20261109.617"
  "Automate Org export and view."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/burnish"
  :commit "aa7dc231a3f6d9f52a7bf3ee22313a42808d3eaf"
  :revdesc "aa7dc231a3f6"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
