;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260318.1155"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "94cb67a85b83f2d7a5f517bba3b020a31e1389e0"
  :revdesc "94cb67a85b83"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
