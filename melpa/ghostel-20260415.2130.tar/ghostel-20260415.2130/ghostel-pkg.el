;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260415.2130"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "31bdc9cf923279e62c8ab1b8627dfb72689a8e65"
  :revdesc "31bdc9cf9232"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
