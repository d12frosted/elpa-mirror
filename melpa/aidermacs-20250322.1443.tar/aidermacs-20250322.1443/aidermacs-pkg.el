;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250322.1443"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "249aaf254ebfca9d01f31950616b085e60baf333"
  :revdesc "249aaf254ebf"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
