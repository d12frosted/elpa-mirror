;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260201.2048"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "f44545ae7364ed9c63da57f9d10e183be45005cd"
  :revdesc "f44545ae7364"
  :keywords '("data" "extensions"))
