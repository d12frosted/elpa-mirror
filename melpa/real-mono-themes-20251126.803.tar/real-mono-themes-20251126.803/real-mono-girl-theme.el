;;; real-mono-girl-theme.el --- A monochrome girl variant theme -*- lexical-binding: t; -*-

;; Copyright (C) 2025 Qingsong Liao

;; Author: Qingsong Liao <llqingsong@qq.com>
;; Maintainer: Qingsong Liao <llqingsong@qq.com>
;; URL: https://github.com/NestorLiao/real-mono-themes
;; Created: 15th Nov 2025
;; Keywords: faces
;; Package-Requires: ((emacs "28.1"))

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published
;; by the Free Software Foundation, either version 3 of the License,
;; or (at your option) any later version.

;; This file is distributed in the hope that it will be useful, but
;; WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
;; General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;  real-mono's girl theme

;;; Code:

(require 'real-mono-themes)
(real-mono-themes--define-theme girl)

(provide-theme 'real-mono-girl)
;;; real-mono-girl-theme.el ends here
