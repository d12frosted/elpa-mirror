(define-package "tree-sitter-langs" "20210228.948" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.12.2"))
  :commit "17206f8ef61aea93b3e8e99742191289fb2eb69d" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/tree-sitter-langs")
;; Local Variables:
;; no-byte-compile: t
;; End:
