(define-package "tr-ime" "20201128.928" "Emulator of IME patch for Windows"
  '((emacs "27.1")
    (w32-ime "0.0.1"))
  :commit "9406b498e6a256a5928f03cd089fdd2823b03876" :authors
  (("Masamichi Hosoda" . "trueroad@trueroad.jp"))
  :maintainer
  ("Masamichi Hosoda" . "trueroad@trueroad.jp")
  :url "https://github.com/trueroad/tr-emacs-ime-module")
;; Local Variables:
;; no-byte-compile: t
;; End:
