(define-package "closql" "20240531.1836" "Store EIEIO objects using EmacSQL"
  '((emacs "26.1")
    (compat "29.1.4.5")
    (emacsql "20240124"))
  :commit "c591e6b310e1e583ca466a8f2c42d3c5d1ada435" :authors
  '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev")
  :keywords
  '("extensions")
  :url "https://github.com/emacscollective/closql")
;; Local Variables:
;; no-byte-compile: t
;; End:
