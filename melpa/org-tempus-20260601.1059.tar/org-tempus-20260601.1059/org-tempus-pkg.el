;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tempus" "20260601.1059"
  "Enhance Org time tracking."
  '((emacs "27.1"))
  :url "https://github.com/rul/org-tempus"
  :commit "2226ef0ae21022b9a343983847bce3e6bb07d63f"
  :revdesc "2226ef0ae210"
  :keywords '("calendar")
  :authors '(("Raul Benencia" . "id@rbenencia.name"))
  :maintainers '(("Raul Benencia" . "id@rbenencia.name")))
