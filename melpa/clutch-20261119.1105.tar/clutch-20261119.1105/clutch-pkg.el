;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261119.1105"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "3893bd40ee0347f862938a06eafd75584ba57d7c"
  :revdesc "3893bd40ee03"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
