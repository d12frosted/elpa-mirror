(define-package "consult-ghq" "20231111.417" "Ghq interface using consult"
  '((emacs "26.1")
    (consult "0.8")
    (affe "0.1"))
  :commit "8a1253bc8fc3bd5e51a430f4a1670dd53dbb2cad" :authors
  '(("Tomoya Otake" . "tomoya.ton@gmail.com"))
  :maintainers
  '(("Tomoya Otake" . "tomoya.ton@gmail.com"))
  :maintainer
  '("Tomoya Otake" . "tomoya.ton@gmail.com")
  :keywords
  '("convenience" "usability" "consult" "ghq")
  :url "https://github.com/tomoya/consult-ghq")
;; Local Variables:
;; no-byte-compile: t
;; End:
