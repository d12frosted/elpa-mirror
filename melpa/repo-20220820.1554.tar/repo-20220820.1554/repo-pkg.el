(define-package "repo" "20220820.1554" "Running repo from Emacs"
  '((emacs "24.3"))
  :commit "e504aa831bfa38ddadce293face28b3c9d9ff9b7" :authors
  '(("Damien Merenne"))
  :maintainers
  '(("Damien Merenne"))
  :maintainer
  '("Damien Merenne")
  :keywords
  '("convenience")
  :url "https://github.com/canatella/repo-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
