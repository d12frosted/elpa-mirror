;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nael" "20251215.1233"
  "Major mode for Lean."
  '((emacs "29.1"))
  :url "https://codeberg.org/mekeor/nael"
  :commit "82bd9a2141f9dc18945b5a8f530c94bbc5fef3ac"
  :revdesc "82bd9a2141f9"
  :keywords '("languages")
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
