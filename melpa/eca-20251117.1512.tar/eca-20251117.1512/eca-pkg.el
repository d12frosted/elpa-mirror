;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251117.1512"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "46ad8fe1e3d3638cbe58ce8bcb8338551598da0d"
  :revdesc "46ad8fe1e3d3"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
