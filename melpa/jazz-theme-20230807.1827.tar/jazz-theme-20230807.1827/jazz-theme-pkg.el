(define-package "jazz-theme" "20230807.1827" "A warm color theme for Emacs 24+." 'nil :commit "099429a7811a7529cba66088ab71716d76658f8e" :authors
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainers
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainer
  '("Roman Parykin" . "donderom@ymail.com")
  :url "https://github.com/donderom/jazz-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
