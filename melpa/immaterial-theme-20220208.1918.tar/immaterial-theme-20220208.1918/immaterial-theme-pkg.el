(define-package "immaterial-theme" "20220208.1918" "A flexible theme based on material design principles"
  '((emacs "25"))
  :commit "51f861cd6543b33d61c45f2d9c82d6d13e0f4a93" :authors
  '(("Peter Gardfjäll"))
  :maintainer
  '("Peter Gardfjäll")
  :keywords
  '("themes")
  :url "https://github.com/petergardfjall/emacs-immaterial-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
