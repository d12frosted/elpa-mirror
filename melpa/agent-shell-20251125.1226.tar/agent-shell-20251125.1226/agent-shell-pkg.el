;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251125.1226"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "f797b730bc618af89c5174c21180ff0c8e167254"
  :revdesc "f797b730bc61")
