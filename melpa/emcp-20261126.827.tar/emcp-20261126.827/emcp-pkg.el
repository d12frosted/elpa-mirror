;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20261126.827"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.2.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "631addeb07fedbf9ddb3a54c10e291f5884f913d"
  :revdesc "631addeb07fe"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
