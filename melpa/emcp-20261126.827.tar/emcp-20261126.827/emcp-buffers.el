;;; emcp-buffers.el --- Resources for Emacs buffers -*- lexical-binding: t -*-

;; Author: Marten Lienen <ml@martenlienen.com>

;;; License

;; This file is part of EMCP.

;; EMCP is free software: you can redistribute it and/or modify it
;; under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; EMCP is distributed in the hope that it will be useful, but WITHOUT
;; ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
;; or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
;; License for more details.

;; You should have received a copy of the GNU General Public License
;; along with EMCP.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; A resource template that lets agents read any buffer by name,
;; e.g. *Messages* or *Warnings* to debug errors that the user ran
;; into.

;;; Code:

(require 'emcp-core)

(defun emcp-buffers--complete (_param value _arguments)
  "Complete a buffer name from VALUE like `read-buffer'."
  (emcp-complete-in-table value #'internal-complete-buffer
                          :history 'buffer-name-history))

;; {+name} because uniquified buffer names can contain /
(emcp-defresource emcp-resource-buffer "buffer://{+name}"
  "Read the text of a buffer."
  :name "buffer"
  :title "Buffer"
  :summary "Text of a buffer, e.g. buffer://*Messages*"
  :description "Text of an Emacs buffer by name, e.g. buffer://*Messages* for the messages that Emacs showed in the echo area or buffer://*Warnings* for warnings."
  :mime-type "text/plain"
  :complete #'emcp-buffers--complete
  (if-let* ((buffer (get-buffer name)))
      (let ((text (with-current-buffer buffer
                    (save-restriction
                      (widen)
                      (buffer-substring-no-properties (point-min) (point-max))))))
        `((contents . [((uri . ,uri)
                        (mimeType . "text/plain")
                        (text . ,text))])))
    (signal 'emcp-resource-not-found (list name))))

(provide 'emcp-buffers)
;;; emcp-buffers.el ends here
