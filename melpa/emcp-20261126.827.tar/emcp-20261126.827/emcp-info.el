;;; emcp-info.el --- Info manual tool and resource for EMCP -*- lexical-binding: t -*-

;; Author: Marten Lienen <ml@martenlienen.com>

;;; License

;; This file is part of EMCP.

;; EMCP is free software: you can redistribute it and/or modify it
;; under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; EMCP is distributed in the hope that it will be useful, but WITHOUT
;; ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
;; or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
;; License for more details.

;; You should have received a copy of the GNU General Public License
;; along with EMCP.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Everything about Emacs Info manuals: the search-manuals tool and
;; the info://{manual}/{node} resource template, see the spec for
;; tools [1] and resources [2].
;;
;; [1] https://modelcontextprotocol.io/specification/2026-07-28/server/tools
;; [2] https://modelcontextprotocol.io/specification/2026-07-28/server/resources

;;; Code:

(require 'cl-lib)
(require 'info)
(require 'seq)
(require 'url-util)

(require 'emcp-core)
(require 'emcp-uri)

;;; Manuals

(defun emcp-info--manuals ()
  "Return the names of all manuals in the Info directory."
  (with-temp-buffer
    (Info-mode)
    (Info-directory)
    (goto-char (point-min))
    (re-search-forward "\\* Menu: *\n" nil t)
    (let (manuals)
      ;; Menu entries look like "* Emacs: (emacs).  The extensible editor."
      (while (re-search-forward "\\*.*: *(\\([^)]+\\))" nil t)
        (cl-pushnew (match-string-no-properties 1) manuals :test #'equal))
      (nreverse manuals))))

(defun emcp-info--nodes (manual)
  "Return the names of the nodes in MANUAL, or nil if it cannot be read."
  (with-temp-buffer
    (Info-mode)
    (condition-case nil
        (let ((Info-history-list Info-history-list))
          (delete "*" (mapcar #'car (Info-build-node-completions
                                     (Info-find-file manual)))))
      (error nil))))


;;; Search tool

(defun emcp-info--search-manuals (pattern manuals &optional on-manual)
  "Search the indices of MANUALS for PATTERN.

Return a list of (MANUAL ENTRY NODE) triples.  Skip manuals that cannot
be read.  After each manual, call ON-MANUAL, if non-nil, with the number
of manuals searched so far and the name of the manual."
  ;; Index entry format: "* ENTRY:  NODE." - same pattern as Info-apropos-matches
  (let ((re (format "\n\\* +\\([^\n]*%s[^\n]*\\):[ \t]+\\([^\n]+\\)\\." pattern))
        ;; Skip fontifying menus like `Info-apropos-matches' does,
        ;; because it takes half of the time
        (Info-fontify-maximum-menu-size nil)
        matches)
    (with-temp-buffer
      (Info-mode)
      (cl-loop
       for manual in manuals
       for searched from 1
       do
       (condition-case nil
           ;; Resolve the file once, because looking it up in all Info
           ;; directories for every node is slow
           (let ((file (Info-find-file manual)))
             (dolist (index-node (Info-index-nodes file))
               (Info-find-node file index-node)
               (goto-char (point-min))
               (while (re-search-forward re nil t)
                 (push (list manual (match-string 1) (match-string 2))
                       matches))))
         (error nil))
       (when on-manual
         (funcall on-manual searched manual))))
    (nreverse matches)))

(emcp-deftool emcp-tools-search-manuals
    ((pattern "Regular expression to search for in Info indices")
     (manual "Restrict search to this manual name, e.g. \"elisp\" or \"emacs\""
             :default nil))
  "Search Info manual indices for a regular expression."
  :name "search-manuals"
  :title "Search Manuals"
  :summary "Search the Emacs, Emacs Lisp and package manuals"
  :description "Search the indices of the Emacs, Emacs Lisp and package manuals for a regular expression and return links to the matching nodes."
  :annotations (:read-only t :open-world nil)
  (let ((matches
         ;; Search in temporary Info buffers instead of with
         ;; `Info-apropos-matches', which shows the *info* buffer,
         ;; writes to the echo area and pauses on broken manuals
         (let* ((Info-history-list Info-history-list)
                (inhibit-message t)
                (manuals (if manual (list manual) (emcp-info--manuals))))
           (emcp-info--search-manuals
            pattern manuals
            (lambda (searched name)
              (emcp-context-progress context searched (length manuals)
                                     (format "Searched the %s manual" name)))))))
    (if matches
        `((content . ,(vconcat
                       (mapcar
                        (lambda (m)
                          (pcase-let ((`(,man ,entry ,node) m))
                            `((type . "resource_link")
                              (uri . ,(format "info://%s/%s"
                                              (url-hexify-string man)
                                              (url-hexify-string node)))
                              (name . ,(substring-no-properties entry))
                              (description . ,(format "(%s)%s" man node))
                              (mimeType . "text/plain"))))
                        matches))))
      `((content . [((type . "text")
                     (text . "No matching entries found."))])))))

;;; Node resource

(defun emcp-info--replace-xrefs (text manual)
  "Replace *note cross-references in TEXT with info:// URIs.

MANUAL is the current manual for same-manual references."
  (replace-regexp-in-string
   "\\*[Nn]ote[ \t\n]+\\([^:]*\\):\\(?::\\|[ \t\n]+\\(?:(\\([^)]+\\))\\)?\\([^.,\t]*\\)[.,]\\)"
   (lambda (match)
     (let* ((raw-label (match-string 1 match))
            (xref-manual (match-string 2 match))
            (node-ref (match-string 3 match)))
       (save-match-data
         (let* ((label (replace-regexp-in-string "[ \t\n]+" " " raw-label))
                (m (or xref-manual manual))
                (n (if (or (null node-ref) (string-empty-p (string-trim node-ref)))
                       label
                     (string-trim node-ref))))
           ;; Parse (manual)Node from label or node reference
           (when (string-match "^(\\([^)]+\\))\\(.*\\)" n)
             (setq m (match-string 1 n))
             (let ((node-part (match-string 2 n)))
               (setq n (if (string-empty-p node-part) "Top" node-part)))
             ;; Clean up label if it contains the (manual) prefix
             (when (string-match "^(\\([^)]+\\))\\(.*\\)" label)
               (setq label (match-string 2 label))
               (when (string-empty-p label) (setq label n))))
           (format "%s (%s)" label
                   (emcp-uri--build
                    "info://{manual}/{node}"
                    `((manual . ,m) (node . ,n))))))))
   text t))

(defun emcp-info--read-node (manual node)
  "Read NODE from MANUAL and return formatted text with navigation URIs."
  (with-temp-buffer
    (Info-mode)
    (condition-case err
        ;; Keep the node out of the user's Info history
        (let ((Info-history-list Info-history-list))
          (Info-find-node manual node))
      (user-error
       (signal 'emcp-resource-not-found (cdr err))))
    (let* ((text (buffer-substring-no-properties (point-min) (point-max)))
           (text (emcp-info--replace-xrefs text manual))
           (nav (emcp-info--extract-nav))
           (menu (emcp-info--extract-menu manual))
           (uris (emcp-info--format-nav-uris manual nav menu)))
      (if uris (concat text "\n\n" uris) text))))

(defun emcp-info--extract-nav ()
  "Extract navigation pointers from the current Info buffer.

Return an alist with keys `next', `prev', `up' where present."
  (save-excursion
    (goto-char (point-min))
    (let ((header (buffer-substring-no-properties
                   (point) (line-end-position)))
          nav)
      (dolist (pointer '(next prev up))
        (let ((name (capitalize (symbol-name pointer))))
          (when (string-match (format "%s: \\([^,\t\n]+\\)" name) header)
            (push (cons pointer (string-trim (match-string 1 header))) nav))))
      (nreverse nav))))

(defun emcp-info--extract-menu (current-manual)
  "Extract menu items from the current Info buffer.

CURRENT-MANUAL is used to construct URIs for same-manual links.
Return a list of (LABEL MANUAL NODE) triples."
  (save-excursion
    (goto-char (point-min))
    (let (items)
      (when (re-search-forward "^\\* Menu:" nil t)
        (while (re-search-forward
                "^\\* +\\([^:\t\n]+\\):\\(:\\|[ \t]+\\([^.,\t\n]+\\)[.,]\\)"
                nil t)
          (let* ((label (string-trim (match-string 1)))
                 (node-ref (if (match-string 3)
                               (string-trim (match-string 3))
                             label)))
            ;; Handle cross-manual references: (manual)Node
            (if (string-match "^(\\([^)]+\\))\\(.*\\)" node-ref)
                (let ((m (match-string 1 node-ref))
                      (n (match-string 2 node-ref)))
                  (push (list label m (if (string-empty-p n) "Top" n)) items))
              (push (list label current-manual node-ref) items)))))
      (nreverse items))))

(defun emcp-info--nav-uri (manual node)
  "Build an info:// URI for NODE in MANUAL.

NODE may contain a cross-manual reference like \"(other)Top\"."
  (if (string-match "^(\\([^)]+\\))\\(.*\\)" node)
      (let ((m (match-string 1 node))
            (n (match-string 2 node)))
        (emcp-uri--build
         "info://{manual}/{node}"
         `((manual . ,m) (node . ,(if (string-empty-p n) "Top" n)))))
    (emcp-uri--build
     "info://{manual}/{node}"
     `((manual . ,manual) (node . ,node)))))

(defun emcp-info--format-nav-uris (manual nav menu)
  "Format navigation URIs for an Info node.

MANUAL is the current manual.  NAV is from
`emcp-info--extract-nav'.  MENU is from
`emcp-info--extract-menu'.  Return a string or nil."
  (let (lines)
    (when nav
      (push "Navigation:" lines)
      (dolist (entry nav)
        (push (format "  %s: %s"
                      (capitalize (symbol-name (car entry)))
                      (emcp-info--nav-uri manual (cdr entry)))
              lines)))
    (when menu
      (when lines (push "" lines))
      (push "Menu:" lines)
      (pcase-dolist (`(,label ,m ,node) menu)
        (push (format "  %s: %s" label
                      (emcp-uri--build
                       "info://{manual}/{node}"
                       `((manual . ,m) (node . ,node))))
              lines)))
    (when lines
      (string-join (nreverse lines) "\n"))))

(defun emcp-info--complete (param value arguments)
  "Complete the parameter PARAM of an info:// URI from VALUE.

ARGUMENTS is an alist of the other parameters.  Complete manuals like
`info-display-manual' and nodes like `Info-goto-node'."
  (pcase param
    ('manual (emcp-complete-in-table value (emcp-info--manuals)))
    ('node (when-let* ((manual (alist-get 'manual arguments)))
             (let ((completion-ignore-case t))
               (emcp-complete-in-table value (emcp-info--nodes manual)
                                       :history 'Info-minibuf-history))))))

(emcp-defresource emcp-resource-info-node "info://{manual}/{node}"
  "Read a node from an Emacs Info manual."
  :name "info-node"
  :title "Info Node"
  :summary "Text of an Info manual node"
  :description "Emacs Info manual node, e.g. info://elisp/Buffer%20Contents"
  :mime-type "text/plain"
  :complete #'emcp-info--complete
  (let ((text (emcp-info--read-node manual node)))
    `((contents . [((uri . ,uri)
                    (mimeType . "text/plain")
                    (text . ,text))]))))

(provide 'emcp-info)
;;; emcp-info.el ends here
