;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260304.1646"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "81d8dd5bc59c2bcf6a509e315ae446cc715474b7"
  :revdesc "81d8dd5bc59c"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
