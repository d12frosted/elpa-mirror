(define-package "project-tasks" "20230801.258" "Efficient task management for your project"
  '((emacs "26.1"))
  :commit "0a2578ec5f59ea5bb69cf09e6bf5049f21b12a7f" :authors
  '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers
  '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainer
  '("Giap Tran" . "txgvnn@gmail.com")
  :keywords
  '("project" "workflow" "tools")
  :url "https://github.com/TxGVNN/project-tasks")
;; Local Variables:
;; no-byte-compile: t
;; End:
