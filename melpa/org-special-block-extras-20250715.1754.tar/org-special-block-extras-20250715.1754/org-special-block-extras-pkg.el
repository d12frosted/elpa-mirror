;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20250715.1754"
  "30 new custom blocks & 34 link types for Org-mode."
  '((s        "1.13.1")
    (dash     "2.18.1")
    (emacs    "27.1")
    (org      "9.1")
    (lf       "1.0")
    (dad-joke "1.4")
    (seq      "2.0")
    (lolcat   "0"))
  :url "https://alhassy.github.io/org-special-block-extras"
  :commit "1a236c783958782a4027e29dafc1efe488f443f1"
  :revdesc "1a236c783958"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
