;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ciel" "20180914.815"
  "A command that is clone of \"ci\" in vim."
  '((emacs "24"))
  :url "https://github.com/cs14095/ciel.el"
  :commit "429773a3c551691a463ecfddd634b8bae2f48503"
  :revdesc "429773a3c551"
  :keywords '("convinience")
  :authors '(("Takuma Matsushita" . "cs14095@gmail.com"))
  :maintainers '(("Takuma Matsushita" . "cs14095@gmail.com")))
