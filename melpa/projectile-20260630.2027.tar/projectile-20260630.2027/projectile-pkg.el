;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260630.2027"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "2099756c6f72c42988d8e444d43402725d134cc8"
  :revdesc "2099756c6f72"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
