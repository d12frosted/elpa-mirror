(define-package "sly-hello-world" "20200225.1755" "A template SLY contrib"
  '((sly "1.0.0beta2"))
  :commit "be257e9ad354db690c7378e89899335597348a0d" :authors
  '(("João Távora" . "joaotavora@gmail.com"))
  :maintainer
  '("João Távora" . "joaotavora@gmail.com")
  :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/capitaomorte/sly-hello-world")
;; Local Variables:
;; no-byte-compile: t
;; End:
