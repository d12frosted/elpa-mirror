;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260411.1547"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "5dd18dbb0c3f9ec9fc34a2927616993250887885"
  :revdesc "5dd18dbb0c3f"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
