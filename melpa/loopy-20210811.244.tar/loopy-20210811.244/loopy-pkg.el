(define-package "loopy" "20210811.244" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "ff5a884ed94f750d2f40e79e4777c3420883fdbe" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
