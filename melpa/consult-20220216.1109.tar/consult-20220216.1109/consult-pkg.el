(define-package "consult" "20220216.1109" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "19aa0d03025de2f4afaaca4d3ac5e4e7c1f68608" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
