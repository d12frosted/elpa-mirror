;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250530.1248"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "efad758b85b9b8af6d92e8c8d896eaba0623b8c3"
  :revdesc "efad758b85b9"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
