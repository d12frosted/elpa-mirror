(define-package "eldev" "20230605.2044" "Elisp development tool"
  '((emacs "24.4"))
  :commit "28d9f68c7732181928fd8fc87789532a493b5b2a" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
