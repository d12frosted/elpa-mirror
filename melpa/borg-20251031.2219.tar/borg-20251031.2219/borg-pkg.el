;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20251031.2219"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "27.1")
    (epkg  "4.1")
    (magit "4.4"))
  :url "https://github.com/emacscollective/borg"
  :commit "9166c2b9a7b848e0a3af3b3ee954a0004ff487f1"
  :revdesc "9166c2b9a7b8"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
