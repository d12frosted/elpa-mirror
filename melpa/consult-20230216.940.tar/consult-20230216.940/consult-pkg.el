(define-package "consult" "20230216.940" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "0c73f24459492c26df159cefd8db73aeac133015" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
