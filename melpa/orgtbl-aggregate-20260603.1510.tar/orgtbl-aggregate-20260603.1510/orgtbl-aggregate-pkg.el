;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260603.1510"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "5b1aa78ac6bd50ada483cb4d38dc0086983c8b4d"
  :revdesc "5b1aa78ac6bd"
  :keywords '("data" "extensions"))
