;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260323.1911"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "0601453c5c7d9a74449c1401a7f02be51b978497"
  :revdesc "0601453c5c7d"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
