;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "equake" "20261128.403"
  "Drop-down console for (e)shell & terminal emulation."
  '((emacs "27.1"))
  :url "https://github.com/emacsomancer/equake"
  :commit "0367ba2227fa18872d521d0b22d92bc48be836e3"
  :revdesc "0367ba2227fa"
  :keywords '("convenience" "frames" "terminals" "tools" "window-system")
  :authors '(("Benjamin Slade" . "LfLg.gg.Lx.f.xx@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "LfLg.gg.Lx.f.xx@lambda-y.net")))
