;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-svg-clock" "20150106.1306"
  "E2wm plugin for svg-clock."
  '((e2wm      "20130225.1602")
    (svg-clock "0.4"))
  :url "https://github.com/myuhe/e2wm-svg-clock.el"
  :commit "d425925e3afffcbe2ff74edc80b714e4319d4c94"
  :revdesc "d425925e3aff"
  :keywords '("convenience" "e2wm")
  :authors '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com")))
