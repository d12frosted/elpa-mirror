;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "total-recall" "20250425.2154"
  "Spaced repetition system."
  '((emacs "30.1"))
  :url "https://github.com/phf-1/total-recall"
  :commit "4314f3939082dafb3a6d83fd1322e0821c072bf4"
  :revdesc "4314f3939082"
  :authors '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com"))
  :maintainers '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com")))
