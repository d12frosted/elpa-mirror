;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-pass" "20210221.1655"
  "Helm interface of pass, the standard Unix password manager."
  '((emacs            "25")
    (helm             "0")
    (password-store   "0")
    (auth-source-pass "4.0.0"))
  :url "https://github.com/emacs-helm/helm-pass"
  :commit "4ce46f1801f2e76e53482c65aa0619d427a3fbf9"
  :revdesc "4ce46f1801f2"
  :authors '(("J. Alexander Branham" . "branham@utexas.edu"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
