;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang-ts" "20260323.927"
  "Major modes for editing Erlang."
  '((emacs  "29.2")
    (erlang "27.2"))
  :url "https://github.com/erlang/emacs-erlang-ts"
  :commit "40181f7af005cbfed20a942a901ebc360743b56e"
  :revdesc "40181f7af005"
  :keywords '("erlang" "languages" "treesitter"))
