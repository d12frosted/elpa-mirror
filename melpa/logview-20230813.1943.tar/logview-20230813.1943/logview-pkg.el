(define-package "logview" "20230813.1943" "Major mode for viewing log files"
  '((emacs "25.1")
    (datetime "0.8")
    (extmap "1.0"))
  :commit "cc870eef58476ac9023e7f3c6866899c2cee134c" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("files" "tools")
  :url "https://github.com/doublep/logview")
;; Local Variables:
;; no-byte-compile: t
;; End:
