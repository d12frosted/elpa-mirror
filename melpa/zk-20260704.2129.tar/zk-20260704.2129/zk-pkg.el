;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk" "20260704.2129"
  "Functions for working with Zettelkasten-style linked notes."
  '((emacs "28.1"))
  :url "https://github.com/localauthor/zk"
  :commit "ad82465a4a65fba7cff07da419455947507080cc"
  :revdesc "ad82465a4a65"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
