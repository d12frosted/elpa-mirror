;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260611.1500"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "a8b4fe52a0d875a7589b2a6aae57c5a58868197d"
  :revdesc "a8b4fe52a0d8"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
