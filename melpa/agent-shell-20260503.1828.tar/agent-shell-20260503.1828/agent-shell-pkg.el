;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260503.1828"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "411c9042f1ea55ee515c7e5918e056fe3ff1f2a8"
  :revdesc "411c9042f1ea")
