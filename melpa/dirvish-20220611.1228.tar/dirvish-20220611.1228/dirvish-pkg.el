(define-package "dirvish" "20220611.1228" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "6c2eb85cbd64a314351e277a42d781dbdd431f04" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
