;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251018.1103"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "98279aa29c159159da75c0a990778d848278c482"
  :revdesc "98279aa29c15"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
