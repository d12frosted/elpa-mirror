;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241022.631"
  "Major mode for MATLAB(R) dot-m files."
  ()
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "26401b9a555091aa4f059aa5714d8fe3d164b648"
  :revdesc "26401b9a5550"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")))
