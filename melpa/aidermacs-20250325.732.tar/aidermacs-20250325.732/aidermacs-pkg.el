;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250325.732"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "8c813413d7bfdf22dbd6ea9eaa41c33bdbc91640"
  :revdesc "8c813413d7bf"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
