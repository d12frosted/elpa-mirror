;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241122.1111"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.70.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "05712d9c3108a1f73f222125bc3923f7dd915a19"
  :revdesc "05712d9c3108")
