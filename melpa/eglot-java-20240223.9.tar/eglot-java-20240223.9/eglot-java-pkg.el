(define-package "eglot-java" "20240223.9" "Java extension for the eglot LSP client"
  '((emacs "26.1")
    (eglot "1.0")
    (jsonrpc "1.0.0"))
  :commit "2ec7266e2322e5577ee96bf261305e79c6aa698a" :authors
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainers
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainer
  '("Yves Zoundi" . "yves_zoundi@hotmail.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/yveszoundi/eglot-java")
;; Local Variables:
;; no-byte-compile: t
;; End:
