;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260324.1554"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "6b620cf0d6367a45b453df88db53da98c8db92d1"
  :revdesc "6b620cf0d636"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
