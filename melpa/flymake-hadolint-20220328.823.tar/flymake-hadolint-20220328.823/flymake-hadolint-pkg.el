;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-hadolint" "20220328.823"
  "Flymake backend for hadolint, a Dockerfile linter."
  '((emacs "26.1"))
  :url "https://github.com/buzztaiki/flymake-hadolint"
  :commit "82a6df7f6cc95e1ab95c5d28f2edcd8c1d4c7382"
  :revdesc "82a6df7f6cc9"
  :keywords '("convenience" "processes" "docker" "flymake")
  :authors '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainers '(("Taiki Sugawara" . "buzz.taiki@gmail.com")))
