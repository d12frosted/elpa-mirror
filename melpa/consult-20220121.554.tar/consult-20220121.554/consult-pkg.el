(define-package "consult" "20220121.554" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "0276cafa97cd09635ba906804a7941f9b0c5cb3f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
