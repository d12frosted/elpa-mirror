;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20260209.1847"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/deirn/mason.el"
  :commit "fe149182385e1f4c957c783e7c78fa6dc837809f"
  :revdesc "fe149182385e"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
