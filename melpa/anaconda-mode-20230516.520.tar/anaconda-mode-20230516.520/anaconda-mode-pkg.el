(define-package "anaconda-mode" "20230516.520" "Code navigation, documentation lookup and completion for Python"
  '((emacs "25.1")
    (pythonic "0.1.0")
    (dash "2.6.0")
    (s "1.9")
    (f "0.16.2"))
  :commit "87805be43d052d76f2fa5b951518f4944a0eef5b" :authors
  '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers
  '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainer
  '("Artem Malyshev" . "proofit404@gmail.com")
  :url "https://github.com/proofit404/anaconda-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
