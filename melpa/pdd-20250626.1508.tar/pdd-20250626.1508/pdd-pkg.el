;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250626.1508"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "f4e7e6241192717c5a7eaa2d78ee85f5b6d0366b"
  :revdesc "f4e7e6241192"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
