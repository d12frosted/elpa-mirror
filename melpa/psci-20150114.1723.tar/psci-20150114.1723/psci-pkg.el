(define-package "psci" "20150114.1723" "Major mode for purescript repl psci"
  '((purescript-mode "13.10")
    (dash "2.9.0")
    (s "1.9.0")
    (f "0.17.1")
    (deferred "0.3.2"))
  :commit "8c2d5a0ba604ec593f83f632b2830a87f41f84d4" :authors
  '(("Antoine R. Dumont <eniotna.t AT gmail.com>"))
  :maintainer
  '("Antoine R. Dumont <eniotna.t AT gmail.com>")
  :keywords
  '("purescript" "psci" "repl" "major" "mode")
  :url "https://github.com/ardumont/emacs-psci")
;; Local Variables:
;; no-byte-compile: t
;; End:
