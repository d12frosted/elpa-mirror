(define-package "boon" "20210216.1846" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "913905bc8dff5675893a018cbfff4e6306cb7aa7")
;; Local Variables:
;; no-byte-compile: t
;; End:
