(define-package "dirvish" "20220115.1845" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "754e2594a85cc12bc9de1fead41d510ee0f2a564" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
