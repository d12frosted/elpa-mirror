;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260227.654"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "7d38bafd263ea07d56853948e13af0f847635eac"
  :revdesc "7d38bafd263e"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
