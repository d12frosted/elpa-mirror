;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "blog-minimal" "20181021.849"
  "A simple static site generator based on org mode."
  '((ht           "1.5")
    (simple-httpd "1.4.6")
    (mustache     "0.22")
    (s            "1.11.0")
    (org          "9.0.3"))
  :url "https://github.com/thiefuniverse/blog-minimal"
  :commit "a634a2db0b80cb445ef0b072d1a1482ced91f9ad"
  :revdesc "a634a2db0b80"
  :keywords '("tools")
  :authors '(("Thank Fly" . "thiefuniverses@gmail.com"))
  :maintainers '(("Thank Fly" . "thiefuniverses@gmail.com")))
