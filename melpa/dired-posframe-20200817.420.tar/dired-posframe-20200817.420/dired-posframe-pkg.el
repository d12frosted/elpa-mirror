;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-posframe" "20200817.420"
  "Peep dired items using posframe."
  '((emacs    "26.1")
    (posframe "0.7"))
  :url "https://github.com/conao3/dired-posframe.el"
  :commit "1a21eb9ad956a0371dd3c9e1bec53407d685f705"
  :revdesc "1a21eb9ad956"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
