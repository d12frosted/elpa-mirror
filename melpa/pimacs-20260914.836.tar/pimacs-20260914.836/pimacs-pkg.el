;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260914.836"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "d3e7f58cb8a959e6d0c7a7a55bf422a374575f19"
  :revdesc "d3e7f58cb8a9"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
