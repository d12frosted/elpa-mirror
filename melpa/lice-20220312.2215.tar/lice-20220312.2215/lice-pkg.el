;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lice" "20220312.2215"
  "License And Header Template."
  ()
  :url "https://github.com/buzztaiki/lice-el"
  :commit "0b69ba54057146f1473e85c0760029e584e3eb13"
  :revdesc "0b69ba540571"
  :keywords '("template" "license" "tools")
  :authors '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainers '(("Taiki Sugawara" . "buzz.taiki@gmail.com")))
