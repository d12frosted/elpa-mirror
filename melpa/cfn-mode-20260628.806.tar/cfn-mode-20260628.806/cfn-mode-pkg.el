;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260628.806"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "6981d36a547d6f9a9d9f2c1851eb402ae9d3c034"
  :revdesc "6981d36a547d"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
