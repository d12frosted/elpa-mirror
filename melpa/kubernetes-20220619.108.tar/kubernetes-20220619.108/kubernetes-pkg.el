(define-package "kubernetes" "20220619.108" "Magit-like porcelain for Kubernetes"
  '((emacs "25.1")
    (dash "2.12.0")
    (magit-section "3.1.1")
    (magit-popup "2.13.0")
    (with-editor "3.0.4")
    (request "0.3.2")
    (s "1.12.0")
    (transient "0.3.0"))
  :commit "de2d49122605d9b055f06ab6f1aeb2be794f41b4" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool")
  :keywords
  '("kubernetes")
  :url "https://github.com/kubernetes-el/kubernetes-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
