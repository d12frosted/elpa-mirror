;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260222.1931"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "85e4507e6584a14f669b2346b527559b79eaac02"
  :revdesc "85e4507e6584"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
