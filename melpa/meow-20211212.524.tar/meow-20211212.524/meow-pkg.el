(define-package "meow" "20211212.524" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "fe9975a6b78732de3a93737d666407acf1351fdf" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
