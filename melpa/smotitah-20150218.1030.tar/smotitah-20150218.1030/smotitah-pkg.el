(define-package "smotitah" "20150218.1030" "Modular emacs configuration framework" 'nil :commit "f9ab562128a5460549d016913533778e8c94bcf3")
;; Local Variables:
;; no-byte-compile: t
;; End:
