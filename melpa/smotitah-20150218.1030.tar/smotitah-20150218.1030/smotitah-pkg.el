;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smotitah" "20150218.1030"
  "Modular configuration framework for Emacs."
  ()
  :url "https://github.com/laynor/smotitah"
  :commit "f9ab562128a5460549d016913533778e8c94bcf3"
  :revdesc "f9ab562128a5"
  :keywords '("configuration")
  :authors '(("Alessandro Piras" . "laynor@gmail.com"))
  :maintainers '(("Alessandro Piras" . "laynor@gmail.com")))
