;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260228.1757"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "c9e9d938deeede5689d59f9437f4afcccf5ad190"
  :revdesc "c9e9d938deee"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
