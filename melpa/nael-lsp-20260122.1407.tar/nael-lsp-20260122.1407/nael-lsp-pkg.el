;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nael-lsp" "20260122.1407"
  "Nael and lsp-mode."
  '((emacs    "29.1")
    (lsp-mode "9")
    (nael     "0.8.1"))
  :url "https://codeberg.org/mekeor/nael"
  :commit "3ee1cf286dc1ee3c9f99357079288ce1285c10c0"
  :revdesc "3ee1cf286dc1"
  :keywords '("languages")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
