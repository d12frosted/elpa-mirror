;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-walk" "20251128.1520"
  "Send email addresses for a walk."
  '((emacs "29.1"))
  :url "https://codeberg.org/timmli/mu4e-walk"
  :commit "7750c1cb9e5a0f0f2997604594d74e320d2a50d7"
  :revdesc "7750c1cb9e5a"
  :keywords '("convenience" "mail")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
