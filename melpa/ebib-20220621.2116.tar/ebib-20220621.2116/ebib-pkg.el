(define-package "ebib" "20220621.2116" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "26.1"))
  :commit "d882c2e9ea1bf4cc7dc98bc426e3b3fe563149fd" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
