;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-fill-paragraph" "20260331.646"
  "Fancy paragraph fill."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-fancy-fill-paragraph"
  :commit "9f409bf7838d5aa06fc7c5ba7d2aef1fb32cabc2"
  :revdesc "9f409bf7838d"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
