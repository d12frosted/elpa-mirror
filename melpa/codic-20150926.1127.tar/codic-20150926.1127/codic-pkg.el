(define-package "codic" "20150926.1127" "Search Codic (codic.jp) naming dictionaries"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "52bbb6997ef4ab9fb7fea43bbfff7f04671aa557" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-codic")
;; Local Variables:
;; no-byte-compile: t
;; End:
