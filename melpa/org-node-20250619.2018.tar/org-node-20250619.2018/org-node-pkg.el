;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250619.2018"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.16.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "9fab6c8c0d8e24d2b242b40a31b73170a4843705"
  :revdesc "9fab6c8c0d8e"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
