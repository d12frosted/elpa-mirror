;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261010.1430"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "cba82e8a8af1aafb07cc3ff6e511f5e8d9acc7c9"
  :revdesc "cba82e8a8af1")
