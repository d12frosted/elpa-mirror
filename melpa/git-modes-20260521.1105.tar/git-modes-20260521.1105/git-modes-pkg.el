;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-modes" "20260521.1105"
  "Major modes for editing Git configuration files."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/magit/git-modes"
  :commit "8c6e5b01feddd0c3da624941c8a4b20bb60f3656"
  :revdesc "8c6e5b01fedd"
  :keywords '("convenience" "vc" "git")
  :authors '(("Sebastian Wiesner" . "lunaryorn@gmail.com")
             ("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")
             ("Jonas Bernoulli" . "emacs.git-modes@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.git-modes@jonas.bernoulli.dev")))
