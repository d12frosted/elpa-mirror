;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260115.422"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3cea9725dff25d07ebef4e3803c04c29c59cf71f"
  :revdesc "3cea9725dff2"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
