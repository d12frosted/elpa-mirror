(define-package "gptel" "20240905.439" "Interact with ChatGPT or other LLMs"
  '((emacs "27.1")
    (transient "0.4.0")
    (compat "29.1.4.1"))
  :commit "defe48bb8c56e678d8c1e7b5e278cccd95f9bc3d" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
