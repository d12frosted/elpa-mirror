(define-package "modus-themes" "20210202.2024" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "8839c91460eb30df1090bb6769647338d458de18" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
