(define-package "tok-theme" "20211217.1757" "My theme"
  '((emacs "24.3"))
  :commit "de304b468798a6f575adcd0473e929b4406e9706" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
