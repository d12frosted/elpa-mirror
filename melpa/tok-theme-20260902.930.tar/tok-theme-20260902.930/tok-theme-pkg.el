;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tok-theme" "20260902.930"
  "Minimal monochromatic theme with restrained color highlights."
  '((emacs "27.0"))
  :url "https://github.com/topikettunen/tok-theme"
  :commit "8f69cc911866ac2520da6b9a10db80970b744541"
  :revdesc "8f69cc911866"
  :authors '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers '(("Topi Kettunen" . "topi@topikettunen.com")))
