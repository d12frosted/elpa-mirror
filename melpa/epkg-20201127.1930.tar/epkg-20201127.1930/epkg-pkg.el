(define-package "epkg" "20201127.1930" "browse the Emacsmirror package database"
  '((closql "1.0.1")
    (emacs "25.1"))
  :commit "a946ba5de7cfdcd1dab1de676b23d644c02ee981" :keywords
  ("tools")
  :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
