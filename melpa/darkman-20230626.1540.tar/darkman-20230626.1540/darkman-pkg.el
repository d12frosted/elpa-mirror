(define-package "darkman" "20230626.1540" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "5c610f3af9b9f18f4d378fe21a2d0ecd5a76089b" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainers
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://darkman.grtcdr.tn")
;; Local Variables:
;; no-byte-compile: t
;; End:
