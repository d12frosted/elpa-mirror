(define-package "consult" "20230127.627" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "c407a73b1377ebc76ef6e1104428868abb0e5926" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
