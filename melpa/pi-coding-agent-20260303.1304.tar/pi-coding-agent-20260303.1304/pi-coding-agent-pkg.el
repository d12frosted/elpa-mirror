;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260303.1304"
  "Emacs frontend for pi coding agent."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "a5fe982e4dde139ff937a72a0c80a65c9d3b839a"
  :revdesc "a5fe982e4dde"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
