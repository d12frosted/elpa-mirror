(define-package "mini-echo" "20231107.809" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "dfea407a5d8a395a359b36899c30e2b5ae547227" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
