(define-package "brutal-theme" "20211128.2317" "Brutalist theme"
  '((emacs "24.1"))
  :commit "560f67765b421bad20f940033e53004c99712689" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
