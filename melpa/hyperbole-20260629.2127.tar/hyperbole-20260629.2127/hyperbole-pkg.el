;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260629.2127"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "a6b4f36369efeaef4dd1590d4680c4a45078de57"
  :revdesc "a6b4f36369ef"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
