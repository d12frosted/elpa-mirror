(define-package "tmux-mode" "20231022.1753" "Major mode for tmux configuration"
  '((emacs "26.1"))
  :commit "afff36c9af444fb25fc123181973b0540f093a8e" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :url "https://github.com/nverno/tmux-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
