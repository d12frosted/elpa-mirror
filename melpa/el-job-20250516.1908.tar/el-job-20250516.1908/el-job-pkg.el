;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250516.1908"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "9258e707ad154170a8beae3f84b25161f42aa200"
  :revdesc "9258e707ad15"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
