(define-package "modus-themes" "20210318.1519" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "771f58deef6b617aa7f4e6017fa312dff36c27b2" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
