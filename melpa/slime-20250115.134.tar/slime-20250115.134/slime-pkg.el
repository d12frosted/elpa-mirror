;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20250115.134"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "e95f690022d8d76306ee1ed34dc37f83675f5ae0"
  :revdesc "e95f690022d8"
  :keywords '("languages" "lisp" "slime"))
