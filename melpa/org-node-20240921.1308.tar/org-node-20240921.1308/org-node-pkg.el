(define-package "org-node" "20240921.1308" "Link org-id entries into a network"
  '((emacs "28.1")
    (compat "30")
    (llama "0"))
  :commit "0745fccdaa0eec9fff593fac96ecaec74a14bcd1" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node")
;; Local Variables:
;; no-byte-compile: t
;; End:
