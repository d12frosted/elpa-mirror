;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250104.1018"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "95ae1688d602a8274e6217c321682c58d684aa4a"
  :revdesc "95ae1688d602"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
