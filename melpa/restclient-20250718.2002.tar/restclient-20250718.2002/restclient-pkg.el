;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restclient" "20250718.2002"
  "An interactive HTTP client for Emacs."
  '((emacs  "26.1")
    (compat "30.1.0.0"))
  :url "https://github.com/emacsorphanage/restclient"
  :commit "6e734e55796349b8ac01e7eea2c605946eaad847"
  :revdesc "6e734e557963"
  :keywords '("http" "comm" "tools")
  :authors '(("Pavel Kurnosov" . "pashky@gmail.com"))
  :maintainers '(("Peder O. Klingenberg" . "peder@klingenberg.no")))
