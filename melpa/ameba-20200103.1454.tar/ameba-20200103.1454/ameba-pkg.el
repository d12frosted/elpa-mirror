;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ameba" "20200103.1454"
  "An interface to Crystal Ameba linter."
  '((emacs "24.4"))
  :url "https://github.com/crystal-ameba/ameba.el"
  :commit "0c4925ae0e998818326adcb47ed27ddf9761c7dc"
  :revdesc "0c4925ae0e99"
  :keywords '("convenience"))
