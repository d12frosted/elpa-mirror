;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20260823.431"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "https://github.com/clojure-emacs/clojure-ts-mode"
  :commit "2bce67a68c270157d940ac9374ab393804c7e00d"
  :revdesc "2bce67a68c27"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :authors '(("Danny Freeman" . "danny@dfreeman.email")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
