;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abs-mode" "20260415.813"
  "Major mode for the modeling language Abs."
  '((emacs      "27.1")
    (erlang     "2.8")
    (maude-mode "0.3")
    (flymake    "1.0")
    (yasnippet  "0.14.0"))
  :url "https://github.com/abstools/abs-mode"
  :commit "a4b8d0caa61db2f37b77e15055fad8324c35f4ae"
  :revdesc "a4b8d0caa61d"
  :keywords '("languages")
  :authors '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainers '(("Rudi Schlatte" . "rudi@constantly.at")))
