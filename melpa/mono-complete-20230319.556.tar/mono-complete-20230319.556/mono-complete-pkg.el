(define-package "mono-complete" "20230319.556" "Completion suggestions with multiple back-ends"
  '((emacs "28.1"))
  :commit "9a408bc19fdd878d1ca9b8881a2bb30e84e4f517" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mono-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
