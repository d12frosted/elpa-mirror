(define-package "oer-reveal" "20201122.1339" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "d2fe2e03c992f47ec1f3cc58c109b2faf236dc70" :keywords
  ("hypermedia" "tools" "slideshow" "presentation" "oer")
  :authors
  (("Jens Lechtenbörger"))
  :maintainer
  ("Jens Lechtenbörger")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
