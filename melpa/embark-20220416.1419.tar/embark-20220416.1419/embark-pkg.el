(define-package "embark" "20220416.1419" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "7a32b9342221327ea71233404441b5e2466ee0a9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
