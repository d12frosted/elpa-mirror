;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250506.134"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "1aa5f1c10df34aeb08f677cd4aa4ef1fc12e87df"
  :revdesc "1aa5f1c10df3"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
