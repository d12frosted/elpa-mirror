;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "composer" "20241016.1900"
  "Interface to PHP Composer."
  '((emacs       "25.1")
    (seq         "1.9")
    (php-runtime "0.1.0"))
  :url "https://github.com/zonuexe/composer.el"
  :commit "6c7e19256ff964546cea682edd21446c465a663c"
  :revdesc "6c7e19256ff9"
  :keywords '("tools" "php" "dependency" "manager")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
