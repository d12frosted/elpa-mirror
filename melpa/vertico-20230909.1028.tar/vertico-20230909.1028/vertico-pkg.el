(define-package "vertico" "20230909.1028" "VERTical Interactive COmpletion"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "17ecd0376512ae0bdbb35764114cb82529543bd2" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "files" "matching" "completion")
  :url "https://github.com/minad/vertico")
;; Local Variables:
;; no-byte-compile: t
;; End:
