(define-package "kiwix" "20210722.1555" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (request "0.3.0")
    (elquery "0.1.0"))
  :commit "716f3c43ccf5c1d0ced2ff362fe2d68767c506cb" :authors
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
