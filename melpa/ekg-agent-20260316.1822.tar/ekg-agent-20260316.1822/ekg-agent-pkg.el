;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260316.1822"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "292e126017153378e3d6799cb6e0f59cbe3757bb"
  :revdesc "292e12601715"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
