(define-package "nordic-night-theme" "20230822.606" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "d39ded7f2de525b47a21835db9dfb9fe7e0f33bc" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
