;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260526.2156"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "b2beae5c01032445d0910a06e2d08d4c8fab1bd7"
  :revdesc "b2beae5c0103"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
