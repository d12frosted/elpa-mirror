(define-package "ligo-mode" "20230912.2145" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "8698d2d952c2495a54ddf171b37c415a946190eb" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
