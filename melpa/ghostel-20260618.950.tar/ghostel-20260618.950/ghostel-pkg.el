;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260618.950"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "cd67d113f9ab041727cf9dc67b96fd655f930d2c"
  :revdesc "cd67d113f9ab"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
