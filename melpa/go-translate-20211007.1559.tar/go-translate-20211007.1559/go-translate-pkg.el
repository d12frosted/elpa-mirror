(define-package "go-translate" "20211007.1559" "Translation"
  '((emacs "26.1"))
  :commit "2ab59c121ca8648edddf4ec14c1fa1d40512353c" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
