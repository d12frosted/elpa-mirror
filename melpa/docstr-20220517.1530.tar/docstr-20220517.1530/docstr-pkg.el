(define-package "docstr" "20220517.1530" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "35910a11306ce2ec42ce0ff4a20c8b799c179d64" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
