(define-package "docstr" "20220517.1530" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "5eb3c98eb85a0a9e89db9aa128617b79371b7a64" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
