(define-package "docstr" "20220517.1530" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "fee47ce3fe81a1539c1eb165593387e67d4bf376" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
