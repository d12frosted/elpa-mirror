(define-package "docstr" "20220517.1530" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "9233d2785c24b9fc3ac4ae83ba54355703c569b3" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
