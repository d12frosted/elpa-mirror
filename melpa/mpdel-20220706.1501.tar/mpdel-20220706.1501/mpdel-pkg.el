(define-package "mpdel" "20220706.1501" "Play and control your MPD music"
  '((emacs "25.1")
    (libmpdel "1.2.0")
    (navigel "0.7.0"))
  :commit "0a06789e9f74bf6bb23f9097dd8072fb7c545d96" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("multimedia")
  :url "https://github.com/mpdel/mpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
