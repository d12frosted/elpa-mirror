;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250522.2110"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "850391b0e1ea7cebb222f318ba4e9f1f5a5284a5"
  :revdesc "850391b0e1ea"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
