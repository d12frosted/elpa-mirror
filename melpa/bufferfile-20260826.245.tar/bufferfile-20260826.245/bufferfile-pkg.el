;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20260826.245"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "52c1af463cdd29f8f36250189a489e8ad6ac30fe"
  :revdesc "52c1af463cdd"
  :keywords '("convenience" "files" "tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
