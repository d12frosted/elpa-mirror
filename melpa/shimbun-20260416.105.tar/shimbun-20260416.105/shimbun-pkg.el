;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shimbun" "20260416.105"
  "Interfacing with web newspapers."
  ()
  :url "https://github.com/emacs-w3m/emacs-w3m"
  :commit "d62c1225a1a9634eb5c6a76ba2b1460961befd08"
  :revdesc "d62c1225a1a9"
  :keywords '("news")
  :authors '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
             ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
             ("Yuuichi Teranishi" . "teranisi@gohome.org")
             ("Katsumi Yamaoka" . "yamaoka@jpl.org"))
  :maintainers '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
                 ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
                 ("Yuuichi Teranishi" . "teranisi@gohome.org")
                 ("Katsumi Yamaoka" . "yamaoka@jpl.org")))
