;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260201.16"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "adaa27e7785781f58bf1f4238a0a618ae861640c"
  :revdesc "adaa27e77857"
  :keywords '("convenience"))
