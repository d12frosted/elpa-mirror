(define-package "toggle-term" "20240616.542" "Quickly toggle persistent term and shell buffers"
  '((emacs "24.3"))
  :commit "5451c67b8f67ea6af2e4615707dbb49ce2203f76" :authors
  '(("justinlime"))
  :maintainers
  '(("justinlime"))
  :maintainer
  '("justinlime")
  :keywords
  '("frames" "convenience" "terminals")
  :url "https://github.com/justinlime/toggle-term.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
