;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-generate" "20260516.826"
  "Generate template files/folders from org document."
  '((emacs    "26.1")
    (org      "9.3")
    (mustache "0.23"))
  :url "https://github.com/conao3/org-generate.el"
  :commit "e77b9cc063fdc035110ac2feea0799316e7e5339"
  :revdesc "e77b9cc063fd"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
