;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fwb-cmds" "20260521.1204"
  "Misc frame, window and buffer commands."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/fwb-cmds"
  :commit "6e29dc83c2da41b2b4042c97ce6b0cc190df3edb"
  :revdesc "6e29dc83c2da"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.fwb-cmds@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.fwb-cmds@jonas.bernoulli.dev")))
