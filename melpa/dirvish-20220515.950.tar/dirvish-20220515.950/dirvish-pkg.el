(define-package "dirvish" "20220515.950" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "d054cb84c5bd586e3b6497ccdfcaefd2a4d0654b" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
