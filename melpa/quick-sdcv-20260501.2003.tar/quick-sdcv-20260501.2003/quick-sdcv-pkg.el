;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20260501.2003"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "de7dc1a263cc5980d0697490e6f1c2cea7471c9b"
  :revdesc "de7dc1a263cc"
  :keywords '("docs" "startdict" "sdcv"))
