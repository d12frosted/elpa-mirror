(define-package "tok-theme" "20220118.2058" "My theme"
  '((emacs "24.3"))
  :commit "763c141ee79d67d8f57bfe8960f4691a357067c6" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
