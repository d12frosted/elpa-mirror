(define-package "bbdb-vcard" "20100421.958" "vCard import/export for BBDB" 'nil :commit "9e11fafef1a94bc6395bd1eeacd00f94848ac560" :authors
  '(("Bert Burgemeister" . "trebbu@googlemail.com"))
  :maintainer
  '("Bert Burgemeister" . "trebbu@googlemail.com")
  :keywords
  '("data" "calendar" "mail" "news")
  :url "http://github.com/trebb/bbdb-vcard")
;; Local Variables:
;; no-byte-compile: t
;; End:
