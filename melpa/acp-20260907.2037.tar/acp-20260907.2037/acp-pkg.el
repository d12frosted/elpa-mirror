;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20260907.2037"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "2a6f2d4600860bd2ab1988253b241f5a39ba59e5"
  :revdesc "2a6f2d460086")
