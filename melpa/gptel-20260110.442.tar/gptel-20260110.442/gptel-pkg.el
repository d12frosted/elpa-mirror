;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260110.442"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "0b1fe86b5c22dab470d88b01799505222fe8a269"
  :revdesc "0b1fe86b5c22"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
