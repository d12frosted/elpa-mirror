(define-package "titlecase" "20220510.331" "Title-case phrases"
  '((emacs "25.1"))
  :commit "8f609e46d4d0c06cd442352ca7d296e2ccb1b62a" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://github.com/duckwork/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
