;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenburn-theme" "20260601.548"
  "A low contrast color theme for Emacs."
  ()
  :url "https://github.com/bbatsov/zenburn-emacs"
  :commit "6453e5318ceceb70ce6dc1ea61009e864c937aca"
  :revdesc "6453e5318cec"
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
