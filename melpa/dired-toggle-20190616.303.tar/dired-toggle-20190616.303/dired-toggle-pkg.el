;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-toggle" "20190616.303"
  "Show dired as sidebar and will not create new buffers when changing dir."
  ()
  :url "https://github.com/fasheng/dired-toggle"
  :commit "b694ba91a45d0762bd032ff1bb4109e4c62ca686"
  :revdesc "b694ba91a45d"
  :keywords '("dired" "sidebar")
  :authors '(("Xu FaSheng" . "fasheng[AT]fasheng.info")))
