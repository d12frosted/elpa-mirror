;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greek-polytonic" "20190303.1358"
  "Quail package for inputting polytonic Greek."
  '((emacs "24"))
  :url "https://github.com/jhanschoo/greek-polytonic"
  :commit "114cba0f57cc077871693c799b807df2292341ec"
  :revdesc "114cba0f57cc"
  :keywords '("i18n" "multilingual" "input method" "greek")
  :authors '(("Johannes Choo" . "jhanschoo@gmail.com"))
  :maintainers '(("Johannes Choo" . "jhanschoo@gmail.com")))
