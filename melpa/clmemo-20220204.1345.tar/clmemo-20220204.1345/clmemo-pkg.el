(define-package "clmemo" "20220204.1345" "Change Log MEMO" 'nil :commit "f695c38c551f72f6ac5e1a82badc540c80d3b33b" :authors
  '(("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainers
  '(("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainer
  '("Masayuki Ataka" . "masayuki.ataka@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ataka/clmemo")
;; Local Variables:
;; no-byte-compile: t
;; End:
