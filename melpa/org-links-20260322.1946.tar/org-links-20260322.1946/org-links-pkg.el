;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260322.1946"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "a18b7f8c3357e984e356f461708ff77d341d2126"
  :revdesc "a18b7f8c3357"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
