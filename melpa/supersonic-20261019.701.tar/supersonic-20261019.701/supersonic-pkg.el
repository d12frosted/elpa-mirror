;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "supersonic" "20261019.701"
  "Music client for Subsonic servers and Music Assistant."
  '((emacs     "28.1")
    (transient "0.2")
    (aio       "1.2"))
  :url "https://github.com/systemfreund/supersonic.el"
  :commit "625aa94ca30dea20bbe52728c1451df2c3807f57"
  :revdesc "625aa94ca30d"
  :keywords '("multimedia")
  :authors '(("systemfreund" . "github@o9z.de"))
  :maintainers '(("systemfreund" . "github@o9z.de")))
