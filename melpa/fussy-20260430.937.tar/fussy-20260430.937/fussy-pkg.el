;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260430.937"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "ce8c93c13a921ef4eadff3505cf95ec8e63bf05b"
  :revdesc "ce8c93c13a92"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
