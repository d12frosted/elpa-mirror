(define-package "eldoc-box" "20230729.540" "Display documentation in childframe"
  '((emacs "27.1"))
  :commit "f6ae0e7a7b95727beddeb031a53724985f00030e" :authors
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainer
  '("Yuan Fu" . "casouri@gmail.com")
  :url "https://github.com/casouri/eldoc-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
