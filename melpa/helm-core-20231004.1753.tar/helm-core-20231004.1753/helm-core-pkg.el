(define-package "helm-core" "20231004.1753" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "bb084b4386b5aedc14ce6e7d7c9fe7676351f9e3" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
