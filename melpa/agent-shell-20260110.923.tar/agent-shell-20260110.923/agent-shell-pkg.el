;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260110.923"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "f832c8237cabb81f7249769d7696f930bff62d91"
  :revdesc "f832c8237cab")
