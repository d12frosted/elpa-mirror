;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20241122.625"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "37d332f8685b015f6a0cca1c122d9ac341427d67"
  :revdesc "37d332f8685b"
  :keywords '("convenience"))
