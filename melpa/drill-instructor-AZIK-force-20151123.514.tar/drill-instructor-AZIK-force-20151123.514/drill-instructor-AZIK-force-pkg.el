(define-package "drill-instructor-AZIK-force" "20151123.514" "Support AZIK input"
  '((popup "0.5"))
  :commit "008cea202dc31d7d6fb1e7d8e6334d516403b7a5")
;; Local Variables:
;; no-byte-compile: t
;; End:
