(define-package "omni-log" "20200304.2229" "Logging utilities"
  '((emacs "24")
    (ht "2.0")
    (s "1.6.1")
    (dash "2.13.0"))
  :commit "0a240660ccdd0b6588b4e3c322743b5ab1161338" :authors
  (("Adrien Becchis" . "adriean.khisbe@live.fr"))
  :maintainer
  ("Adrien Becchis" . "adriean.khisbe@live.fr")
  :keywords
  ("convenience" "languages" "tools")
  :url "https://github.com/AdrieanKhisbe/omni-log.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
