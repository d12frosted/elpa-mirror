(define-package "poetry" "20230304.1540" "Interface to Poetry"
  '((transient "0.2.0")
    (pyvenv "1.2")
    (emacs "25.1"))
  :commit "5ca52b221e57bb9dce7c89f62e7b01da1346a273" :authors
  '(("Gaby Launay" . "gaby.launay@protonmail.com"))
  :maintainers
  '(("Gaby Launay" . "gaby.launay@protonmail.com"))
  :maintainer
  '("Gaby Launay" . "gaby.launay@protonmail.com")
  :keywords
  '("python" "tools")
  :url "https://github.com/galaunay/poetry.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
