;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bpr" "20180220.1844"
  "Background Process Runner."
  '((emacs "24"))
  :url "https://github.com/ilya-babanov/emacs-bpr"
  :commit "af84a83dea09d86e77d87ac30604f2c5b4bf4117"
  :revdesc "af84a83dea09"
  :keywords '("background" "async" "process" "management")
  :authors '(("Ilya Babanov" . "ilya-babanov@ya.ru"))
  :maintainers '(("Ilya Babanov" . "ilya-babanov@ya.ru")))
