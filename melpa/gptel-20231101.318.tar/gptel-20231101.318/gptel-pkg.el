(define-package "gptel" "20231101.318" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "d7a89d7575e5d0f5148d7498536e470fda628f1e" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
