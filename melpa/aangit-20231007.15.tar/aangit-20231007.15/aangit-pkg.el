(define-package "aangit" "20231007.15" "Quickly scaffold new Angular apps with Aangit"
  '((emacs "29.1")
    (transient "0.4"))
  :commit "45f7c2660e871777395d570e66c260cf3da78fb0" :authors
  '(("Steven Edwards" . "steven@stephenwithav.io"))
  :maintainers
  '(("Steven Edwards" . "steven@stephenwithav.io"))
  :maintainer
  '("Steven Edwards" . "steven@stephenwithav.io")
  :keywords
  '("angular" "tools")
  :url "https://github.com/stephenwithav/aangit")
;; Local Variables:
;; no-byte-compile: t
;; End:
