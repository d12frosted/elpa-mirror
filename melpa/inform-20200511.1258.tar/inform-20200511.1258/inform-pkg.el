(define-package "inform" "20200511.1258" "Symbol links in Info buffers to their help documentation."
  '((emacs "25.1"))
  :commit "5e096549632b2691fe1f975394d07a31cf603fc6" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("help" "docs" "convenience")
  :url "https://github.com/dieter-wilhelm/inform")
;; Local Variables:
;; no-byte-compile: t
;; End:
