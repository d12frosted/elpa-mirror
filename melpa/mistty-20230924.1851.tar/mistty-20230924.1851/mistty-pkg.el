(define-package "mistty" "20230924.1851" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "98f874960380b8875f71ded1bf87f8ae1eae7260" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
