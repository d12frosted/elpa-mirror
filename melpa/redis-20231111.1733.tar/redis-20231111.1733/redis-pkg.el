;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redis" "20231111.1733"
  "Redis integration."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/emacs-pe/redis.el"
  :commit "84382456beae70677aed2f9558a0b446f8ccc17a"
  :revdesc "84382456beae"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
