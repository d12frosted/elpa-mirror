;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20260905.1851"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "2d985b50c7c34aee4fddea8742a8754b9c248790"
  :revdesc "2d985b50c7c3"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
