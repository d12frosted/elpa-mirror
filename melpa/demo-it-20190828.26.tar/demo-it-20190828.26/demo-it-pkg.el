(define-package "demo-it" "20190828.26" "Create demonstrations" 'nil :commit "9cfa5c3f92a0dca7eebb1f1a2011643c9b009d26" :keywords
  ("demonstration" "presentation" "test")
  :authors
  (("Howard Abrams" . "howard.abrams@gmail.com"))
  :maintainer
  ("Howard Abrams" . "howard.abrams@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
