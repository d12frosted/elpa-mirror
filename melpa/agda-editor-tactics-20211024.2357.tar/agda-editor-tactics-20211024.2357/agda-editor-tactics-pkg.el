;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agda-editor-tactics" "20211024.2357"
  "An editor tactic to produce Σ-types from Agda records."
  '((s     "1.12.0")
    (dash  "2.16.0")
    (emacs "27.1")
    (org   "9.1"))
  :url "https://github.com/alhassy/next-700-module-systems"
  :commit "06e374516cb2ab17018985f3dc4fccdc4acefd08"
  :revdesc "06e374516cb2"
  :keywords '("abbrev" "convenience" "languages" "agda" "tools")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
