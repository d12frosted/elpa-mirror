;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "control-mode" "20160624.1710"
  "A \"control\" mode, similar to vim's \"normal\" mode."
  ()
  :url "https://github.com/stephendavidmarsh/control-mode"
  :commit "6bf487144119b03f9cc54168f70e3d7d8d84e22b"
  :revdesc "6bf487144119"
  :keywords '("convenience" "emulations")
  :authors '(("Stephen Marsh" . "stephen.david.marsh@gmail.com"))
  :maintainers '(("Stephen Marsh" . "stephen.david.marsh@gmail.com")))
