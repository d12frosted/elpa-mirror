(define-package "nix-mode" "20210522.348" "Major mode for editing .nix files"
  '((emacs "25.1"))
  :commit "df4ba688a7cf0f59cc0292f92bd5bf0af2398b4d" :maintainer
  '("Matthew Bauer" . "mjbauer95@gmail.com")
  :keywords
  '("nix" "languages" "tools" "unix")
  :url "https://github.com/NixOS/nix-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
