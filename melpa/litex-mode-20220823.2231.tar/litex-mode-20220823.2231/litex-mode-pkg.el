(define-package "litex-mode" "20220823.2231" "Minor mode for converting lisp to LaTeX"
  '((emacs "24.4"))
  :commit "c4a1071fcf6d2bec9eb367ede8c33b190e9ff802" :authors
  '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainer
  '("Gaurav Atreya" . "allmanpride@gmail.com")
  :keywords
  '("calculator" "lisp" "latex")
  :url "https://github.com/Atreyagaurav/litex-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
