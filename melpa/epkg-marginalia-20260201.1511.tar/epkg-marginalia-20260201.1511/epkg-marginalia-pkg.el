;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg-marginalia" "20260201.1511"
  "Show Epkg information in completion annotations."
  '((emacs      "28.1")
    (compat     "30.1")
    (epkg       "4.1")
    (marginalia "2.9"))
  :url "https://github.com/emacscollective/epkg-marginalia"
  :commit "1fda65cebc0d53319f2972ae52d182bdf5470702"
  :revdesc "1fda65cebc0d"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev")))
