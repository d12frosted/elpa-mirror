(define-package "spdx" "20220325.106" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "914df7fa483825d813e7aaeb9dffce629aae2a52" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
