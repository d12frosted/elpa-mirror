;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250531.2042"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e6ec885b1c70b27ed20e4899fc8273dd4870b158"
  :revdesc "e6ec885b1c70"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
