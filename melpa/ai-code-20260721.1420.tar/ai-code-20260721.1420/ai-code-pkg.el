;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260721.1420"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3398814b60e55628b291d2c2ffe754f4d6cfad62"
  :revdesc "3398814b60e5"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
