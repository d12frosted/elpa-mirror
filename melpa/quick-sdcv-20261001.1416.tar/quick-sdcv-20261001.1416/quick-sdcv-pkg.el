;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20261001.1416"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "74a36584a186ad88a5296cd4c1d614dedf275f65"
  :revdesc "74a36584a186"
  :keywords '("tools" "convenience" "text"))
