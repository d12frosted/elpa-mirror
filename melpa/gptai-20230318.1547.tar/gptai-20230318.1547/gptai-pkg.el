(define-package "gptai" "20230318.1547" "Integrate with the OpenAI API"
  '((emacs "24.1"))
  :commit "5cdea5c85b102e1e57904ea6bb826cccd506067f" :authors
  '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainer
  '("Anton Hibl" . "antonhibl11@gmail.com")
  :keywords
  '("comm" "convenience")
  :url "https://github.com/antonhibl/gptai")
;; Local Variables:
;; no-byte-compile: t
;; End:
