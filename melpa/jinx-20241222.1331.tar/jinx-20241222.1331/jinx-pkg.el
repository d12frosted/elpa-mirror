;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20241222.1331"
  "Enchanted Spell Checker."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "ca8c68a9affd690d50d2696ef16e5b6d392d07ec"
  :revdesc "ca8c68a9affd"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
