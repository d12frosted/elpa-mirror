;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual-symbol-overlay" "20261030.1550"
  "Transient UI for Symbol Overlay."
  '((emacs          "30.1")
    (casual         "3.0.0")
    (symbol-overlay "4.2"))
  :url "https://github.com/kickingvegas/casual-symbol-overlay"
  :commit "33636422cedd0cf777e58e630124feb0c9508dfc"
  :revdesc "33636422cedd"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
