(define-package "notmuch" "20210719.1132" "run notmuch within emacs" 'nil :commit "bed62eb8bee4aeca1fabfa5e302b515849f50b31" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
