(define-package "mandm-theme" "20230805.739" "An M&M color theme." 'nil :commit "8f3d6497aca7b0e6a8dc759b307d20fcb68920d9" :authors
  '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainers
  '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainer
  '("Christian Hopps" . "chopps@gmail.com")
  :url "https://github.com/choppsv1/emacs-mandm-theme.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
