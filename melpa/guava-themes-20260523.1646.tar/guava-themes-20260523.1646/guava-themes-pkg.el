;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260523.1646"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "a43a1f53d7ebccc701b2e23601a5b7a134887bbe"
  :revdesc "a43a1f53d7eb"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
