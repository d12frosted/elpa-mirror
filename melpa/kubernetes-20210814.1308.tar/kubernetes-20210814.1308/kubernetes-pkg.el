(define-package "kubernetes" "20210814.1308" "Magit-like porcelain for Kubernetes."
  '((emacs "25.1")
    (dash "2.12.0")
    (magit-section "3.1.1")
    (magit-popup "2.13.0")
    (with-editor "3.0.4"))
  :commit "80ac32e1af6f877d0d79b8abd06e29a4d7052b0c" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool"))
;; Local Variables:
;; no-byte-compile: t
;; End:
