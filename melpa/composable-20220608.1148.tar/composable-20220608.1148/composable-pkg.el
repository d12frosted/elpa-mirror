(define-package "composable" "20220608.1148" "composable editing"
  '((emacs "25.1"))
  :commit "205a69c64ea95ef67070423c31ed70ec44ec980c" :authors
  '(("Simon Friis Vindum" . "simon@vindum.io"))
  :maintainer
  '("Simon Friis Vindum" . "simon@vindum.io")
  :keywords
  '("lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
