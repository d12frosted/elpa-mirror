(define-package "package-lint" "20240923.931" "A linting library for elisp package authors"
  '((emacs "24.4")
    (let-alist "1.0.6"))
  :commit "e3d3fb254221d053c75edfd9f0ebfa58d1eb52f9" :authors
  '(("Steve Purcell" . "steve@sanityinc.com")
    ("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com")
    ("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("lisp")
  :url "https://github.com/purcell/package-lint")
;; Local Variables:
;; no-byte-compile: t
;; End:
