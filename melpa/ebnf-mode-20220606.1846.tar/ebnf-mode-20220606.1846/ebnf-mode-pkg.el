(define-package "ebnf-mode" "20220606.1846" "Major mode for EBNF files"
  '((emacs "25.1"))
  :commit "9bc7242557dcef797afdcb4a50c70bf153aa221d" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :url "https://github.com/nverno/ebnf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
