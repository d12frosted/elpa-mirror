(define-package "matlab-mode" "20230408.1210" "Major mode for MATLAB(R) dot-m files" 'nil :commit "bda900fd75ee2e507f56e411f54dc1512675559f")
;; Local Variables:
;; no-byte-compile: t
;; End:
