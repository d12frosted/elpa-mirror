(define-package "clojure-ts-mode" "20230829.2110" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "623c98292f9207a95169cdeae6f8595c016c6320" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
