;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "choice-program" "20260107.1854"
  "Parameter based program."
  '((emacs "27.1")
    (dash  "2.19.1"))
  :url "https://github.com/plandes/choice-program"
  :commit "acacd3409d60b7aa5c53d07290a8dfc31b919971"
  :revdesc "acacd3409d60"
  :keywords '("execution" "processes" "unix" "lisp"))
