;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shazam" "20261107.1941"
  "Shazam Interface (macOS only)."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/shazam"
  :commit "fdc0b3c2dafe8d70ac645a5766b957d1bf594de7"
  :revdesc "fdc0b3c2dafe"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
