;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260404.134"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "537715b98f547d2f4e857b08bb36272108f28328"
  :revdesc "537715b98f54"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
