;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250323.1451"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "513cefc6dd9d02c15c1c4bb3ed9cd894f50e543a"
  :revdesc "513cefc6dd9d"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
