(define-package "srfi" "20221110.2251" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "d8b801b192debb72c22506e8391bc35ccca822ff" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
