(define-package "maxima" "20210520.2021" "Major mode for Maxima"
  '((emacs "25.1")
    (s "1.11.0")
    (test-simple "1.3.0"))
  :commit "394ad5fec08d001a4aa5a28bc6a7fa2bc89579f8" :authors
  '(("William F. Schelter")
    ("Jay Belanger")
    ("Fermin Munoz"))
  :maintainer
  '("Fermin Munoz" . "fmfs@posteo.net")
  :keywords
  '("maxima" "tools" "math")
  :url "https://gitlab.com/sasanidas/maxima")
;; Local Variables:
;; no-byte-compile: t
;; End:
