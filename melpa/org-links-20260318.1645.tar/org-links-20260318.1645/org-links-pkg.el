;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260318.1645"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "fa60c3a7a272ad4227337827f17c13d3cf970b33"
  :revdesc "fa60c3a7a272"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
