(define-package "dirvish" "20220203.1022" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "f820ca5d6539d54d582f086458e00eb016d69b02" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
