(define-package "citre" "20210705.1053" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "91772444e9f44206927c29c6d77724309f07a753" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
