;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "r-ts-mode" "20260804.336"
  "R treesitter mode."
  '((emacs "30.1"))
  :url "https://codeberg.org/R-for-emacs/r-ts-mode"
  :commit "0a86bdd3083095576810dfa586be5b712d838332"
  :revdesc "0a86bdd30830"
  :authors '(("Manuel Teodoro" . "ttm@teoten.me"))
  :maintainers '(("Manuel Teodoro" . "ttm@teoten.me")))
