;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260129.1800"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "6d1d2129f5950127ee694e0ff4ab8ef3e7e4a124"
  :revdesc "6d1d2129f595"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
