;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260803.1557"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "40c0bc69aa078f3fac407ca023e95e41fdbbecda"
  :revdesc "40c0bc69aa07"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
