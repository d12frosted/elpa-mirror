;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "20241211.632"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "cce9d445688070b77c676dc60b9d73ffbcada063"
  :revdesc "cce9d4456880"
  :keywords '("hypermedia"))
