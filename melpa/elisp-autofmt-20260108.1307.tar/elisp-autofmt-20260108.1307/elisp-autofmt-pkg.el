;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-autofmt" "20260108.1307"
  "Emacs lisp auto-format."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt"
  :commit "4e8f5d4721827a5c8eb70060d93a96d9e43bb5bb"
  :revdesc "4e8f5d472182"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
