;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-wild-notifier" "20260122.2249"
  "Customizable org-agenda notifications."
  '((alert "1.2")
    (async "1.9.3")
    (dash  "2.18.0")
    (emacs "27.1"))
  :url "https://github.com/emacsorphanage/org-wild-notifier.el"
  :commit "6353a574fac6bb850d9fe8a7f7b4943d433bcd42"
  :revdesc "6353a574fac6"
  :keywords '("calendar" "convenience")
  :authors '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainers '(("Artem Khramov" . "akhramov+emacs@pm.me")))
