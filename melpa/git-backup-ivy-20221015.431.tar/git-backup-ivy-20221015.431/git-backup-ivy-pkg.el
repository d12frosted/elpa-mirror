(define-package "git-backup-ivy" "20221015.431" "An ivy interface to git-backup"
  '((ivy "0.12.0")
    (git-backup "0.0.1")
    (emacs "25.1"))
  :commit "e54a3c4b95023c58664a2c59b95a95a07759a1f8" :authors
  '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers
  '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainer
  '("Sebastian Wålinder" . "s.walinder@gmail.com")
  :keywords
  '("backup" "convenience" "files" "tools" "vc")
  :url "https://github.com/walseb/git-backup-ivy")
;; Local Variables:
;; no-byte-compile: t
;; End:
