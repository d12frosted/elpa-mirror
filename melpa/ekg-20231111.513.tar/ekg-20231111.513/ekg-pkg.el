(define-package "ekg" "20231111.513" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.4.0"))
  :commit "adbe9bfb6faf603fcd4958d4b4d6473829d4e7f2" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
