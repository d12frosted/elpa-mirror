(define-package "ox-tufte" "20160926.1607" "Tufte HTML org-mode export backend"
  '((org "8.2")
    (emacs "24"))
  :commit "ca1b16eb91b25bb4f05e58e9b6692e8486c8c619" :authors
  '(("M. Lee Hinman"))
  :maintainers
  '(("M. Lee Hinman"))
  :maintainer
  '("M. Lee Hinman")
  :keywords
  '("org" "tufte" "html")
  :url "https://github.com/dakrone/ox-tufte")
;; Local Variables:
;; no-byte-compile: t
;; End:
