;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260120.207"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "e3a549092d47e5407d6f0259aae9f883327d3a67"
  :revdesc "e3a549092d47"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
