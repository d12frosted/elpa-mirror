;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20260309.29"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "6d6ccdc7528c4eaf820bfceac8c4de7c7eaa07bd"
  :revdesc "6d6ccdc7528c"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
