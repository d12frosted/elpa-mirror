;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260727.1415"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "268a7fe46ce6887be406ed4c668bd51ab8a16e67"
  :revdesc "268a7fe46ce6"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
