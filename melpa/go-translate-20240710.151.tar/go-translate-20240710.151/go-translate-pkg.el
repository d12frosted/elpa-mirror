(define-package "go-translate" "20240710.151" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "a2fa7d26b92f1abc75487fcaefbbec3cb72f5985" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
