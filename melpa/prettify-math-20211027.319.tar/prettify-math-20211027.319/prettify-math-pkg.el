(define-package "prettify-math" "20211027.319" "Prettify math formula"
  '((emacs "27.1")
    (dash "2.19.0")
    (s "1.12.0")
    (jsonrpc "1.0.9"))
  :commit "9076d8c5f77b0b7ab0be488e90d5e2e5fb7ea9e8" :authors
  '(("Shaq Xu" . "shaqxu@163.com"))
  :maintainer
  '("Shaq Xu" . "shaqxu@163.com")
  :keywords
  '("math" "asciimath" "tex" "latex" "prettify" "mathjax")
  :url "https://gitee.com/shaqxu/prettify-math")
;; Local Variables:
;; no-byte-compile: t
;; End:
