;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sbt-mode" "20261102.1615"
  "Interactive support for sbt projects."
  '((emacs "24.4"))
  :url "https://github.com/hvesalai/emacs-sbt-mode"
  :commit "3da084aa438179913f1fdd770f0be136c6f66322"
  :revdesc "3da084aa4381"
  :keywords '("languages"))
