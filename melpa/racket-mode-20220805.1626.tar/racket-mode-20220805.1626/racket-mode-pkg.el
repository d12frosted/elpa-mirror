(define-package "racket-mode" "20220805.1626" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "092a6be063a0fc9955a83b0bf0814f2d0eb01018" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
