;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250716.934"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "d70c64f015615213fb15e9f7c931e0aea2c7fa91"
  :revdesc "d70c64f01561"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
