;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boxquote" "20260415.1949"
  "Quote text with a semi-box."
  '((emacs "28.1"))
  :url "https://github.com/davep/boxquote.el"
  :commit "eb14169161ddeba9a703c42f7352cb52f732cc86"
  :revdesc "eb14169161dd"
  :keywords '("convenience" "editing" "quoting")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
