(define-package "modus-themes" "20210516.249" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "6657bb287ce3c39eeceadb19ea4b359f004e94ff" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
