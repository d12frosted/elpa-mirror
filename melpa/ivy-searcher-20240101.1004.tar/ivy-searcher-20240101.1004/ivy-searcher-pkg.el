;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-searcher" "20240101.1004"
  "Ivy interface to use searcher."
  '((emacs    "25.1")
    (ivy      "0.8.0")
    (searcher "0.1.8")
    (s        "1.12.0")
    (f        "0.20.0"))
  :url "https://github.com/jcs-elpa/ivy-searcher"
  :commit "1b6f6aed1b371c45b5d8be8aaf6d6e89eba5e0f1"
  :revdesc "1b6f6aed1b37"
  :keywords '("convenience" "ivy" "interface" "searcher" "search" "replace" "grep" "ag" "rg")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
