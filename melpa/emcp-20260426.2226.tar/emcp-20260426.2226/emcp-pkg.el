;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260426.2226"
  "Lets your agent talk to Emacs."
  '((emacs       "30.1")
    (http-server "0.1.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "2363287cffb1b694387d3aabbae9be863bf4e549"
  :revdesc "2363287cffb1"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
