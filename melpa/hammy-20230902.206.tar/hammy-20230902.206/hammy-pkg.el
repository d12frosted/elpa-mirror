(define-package "hammy" "20230902.206" "Programmable, interactive interval timers"
  '((emacs "28.1")
    (svg-lib "0.2.5")
    (ts "0.2.2"))
  :commit "f4b22c488bf5d04166eb107ea091ce9919a68b92" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/hammy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
