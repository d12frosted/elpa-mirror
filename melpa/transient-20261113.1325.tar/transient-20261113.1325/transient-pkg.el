;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20261113.1325"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "632653b591419dafc021195e30375fb9a2baa130"
  :revdesc "632653b59141"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
