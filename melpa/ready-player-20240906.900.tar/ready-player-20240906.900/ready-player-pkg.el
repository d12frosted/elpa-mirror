(define-package "ready-player" "20240906.900" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "a4f8471ac6cef7b05cdd7313b9a7eec97d864c08" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
