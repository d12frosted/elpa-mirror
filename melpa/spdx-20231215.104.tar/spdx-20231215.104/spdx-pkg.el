(define-package "spdx" "20231215.104" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "401f1aaf118c82287507b5b18004d59ff906308f" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
