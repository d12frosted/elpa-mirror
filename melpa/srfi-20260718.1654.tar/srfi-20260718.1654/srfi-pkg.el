;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260718.1654"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "46fbc405796d193962629127129630f4421483cd"
  :revdesc "46fbc405796d"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
