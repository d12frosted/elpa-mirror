;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-sidebar" "20260717.2306"
  "Sidebar for `ibuffer'."
  '((emacs "29.1"))
  :url "https://github.com/jojojames/ibuffer-sidebar"
  :commit "2781453a6967a7d16a1dddb04cfba6b907110d3e"
  :revdesc "2781453a6967"
  :keywords '("ibuffer" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
