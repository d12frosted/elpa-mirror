;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20260607.1943"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "cfa0bd48cb71fbf3c729aced2f78115728e5ca95"
  :revdesc "cfa0bd48cb71"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
