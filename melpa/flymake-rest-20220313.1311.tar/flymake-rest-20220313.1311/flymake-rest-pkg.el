(define-package "flymake-rest" "20220313.1311" "Core features for flymake"
  '((emacs "28.1")
    (let-alist "1.0")
    (flymake "1.2.1"))
  :commit "6c0f39ae1e8b476b195adfe477b40cf6c4a162b6" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("language" "tools")
  :url "https://github.com/mohkale/flymake-rest")
;; Local Variables:
;; no-byte-compile: t
;; End:
