(define-package "company" "20231014.2355" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "909ae49665dbb5b435e8939af2c1e7b55123c1b1" :authors
  '(("Nikolaj Schumacher"))
  :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
