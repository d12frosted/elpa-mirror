;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-phpstan" "20250331.1336"
  "Flycheck integration for PHPStan."
  '((emacs    "24.3")
    (flycheck "26")
    (phpstan  "0.7.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "7fb12964750f65d3c4b7e75cd7ffa7c72923e70c"
  :revdesc "7fb12964750f"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
