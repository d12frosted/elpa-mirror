;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20260409.1306"
  "Light Emacs color theme on cornsilk3 background."
  ()
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "671a6f8350c75fd0b6c68d275db2fde705cb4ecd"
  :revdesc "671a6f8350c7"
  :keywords '("color" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
