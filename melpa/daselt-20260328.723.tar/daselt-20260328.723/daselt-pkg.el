;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260328.723"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "0927b9b30d5544671abed08451ecb57336512e9e"
  :revdesc "0927b9b30d55"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
