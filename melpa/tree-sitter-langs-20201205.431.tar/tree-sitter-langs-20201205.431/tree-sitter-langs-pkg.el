(define-package "tree-sitter-langs" "20201205.431" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.9.2"))
  :commit "887ad56d5c755d0007905d874e48eeedb2e8a383" :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
