(define-package "modus-themes" "20220316.857" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "0ee774001c89d4ff88b4afd6f9ad9a912106986a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
