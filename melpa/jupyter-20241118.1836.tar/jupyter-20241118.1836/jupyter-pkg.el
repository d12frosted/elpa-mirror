;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jupyter" "20241118.1836"
  "Jupyter."
  '((emacs        "27")
    (cl-lib       "0.5")
    (org          "9.1.6")
    (zmq          "0.10.10")
    (simple-httpd "1.5.0")
    (websocket    "1.9"))
  :url "https://github.com/emacs-jupyter/jupyter"
  :commit "be52a622b904439eca0e133a4aceb33fdd5a5f8f"
  :revdesc "be52a622b904"
  :authors '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainers '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")))
