(define-package "lab" "20230819.1456" "An interface for GitLab"
  '((emacs "27.1")
    (memoize "1.1")
    (request "0.3.2")
    (s "1.10.0"))
  :commit "44cc2630adaa02f902bcf28fa05f3a9039dda005" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/lab.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
