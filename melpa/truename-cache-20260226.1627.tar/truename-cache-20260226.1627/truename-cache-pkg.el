;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260226.1627"
  "Efficiently de-dup file-names."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "b72b0db3506584ec274db438795a66c13c4e20b6"
  :revdesc "b72b0db35065"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
