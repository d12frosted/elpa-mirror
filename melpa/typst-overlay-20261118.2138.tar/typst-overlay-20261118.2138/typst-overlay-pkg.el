;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typst-overlay" "20261118.2138"
  "Overlay Typst equations."
  '((emacs "29.1"))
  :url "https://github.com/hesampakdaman/typst-overlay"
  :commit "3b69366a435a9b4df45ed8fda01af3fca511e999"
  :revdesc "3b69366a435a"
  :keywords '("tools")
  :authors '(("Hesam Pakdaman" . "https://github.com/hesampakdaman"))
  :maintainers '(("Hesam Pakdaman" . "https://github.com/hesampakdaman")))
