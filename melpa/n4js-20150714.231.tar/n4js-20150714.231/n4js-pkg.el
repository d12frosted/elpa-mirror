;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "n4js" "20150714.231"
  "Neo4j Shell."
  '((emacs       "24")
    (cypher-mode "0"))
  :url "https://github.com/tmtxt/n4js.el"
  :commit "3991ed8975151d5e8d568e952362df810f7ffab7"
  :revdesc "3991ed897515"
  :keywords '("neo4j" "shell" "comint")
  :authors '(("TruongTx" . "me@truongtx.me"))
  :maintainers '(("TruongTx" . "me@truongtx.me")))
