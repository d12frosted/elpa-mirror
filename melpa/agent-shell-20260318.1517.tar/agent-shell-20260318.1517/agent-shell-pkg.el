;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260318.1517"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.2")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "693c70b8ebcda7a50f820bc111faa4c627b5bdfb"
  :revdesc "693c70b8ebcd")
