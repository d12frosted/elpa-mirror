(define-package "spdx" "20230220.118" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "7ae6710a95a02c90b0f13486e8f20be3a746bee2" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
