;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260129.1839"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "3636b9a9f8c2e7cf83ea587d291822a59443dff8"
  :revdesc "3636b9a9f8c2"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
