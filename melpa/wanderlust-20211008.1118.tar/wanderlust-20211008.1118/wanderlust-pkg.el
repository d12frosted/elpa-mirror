(define-package "wanderlust" "20211008.1118" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "92ded1534ce7143f379b92a4029db275f3e22ee8")
;; Local Variables:
;; no-byte-compile: t
;; End:
