;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260511.1106"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "da848c42e69e4775de391f9e2c53e3dc52084351"
  :revdesc "da848c42e69e"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
