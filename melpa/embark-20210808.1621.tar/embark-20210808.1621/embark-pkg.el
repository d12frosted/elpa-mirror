(define-package "embark" "20210808.1621" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "502e1e6a64319c43200535b84630bad83ae13548" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
