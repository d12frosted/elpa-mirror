(define-package "racket-mode" "20221107.1233" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "3b92a5bfcb42334b53a591d87967cb600e5b8a33" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
