;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbdb-csv-import" "20140802.1142"
  "Import csv to bbdb version 3+."
  '((pcsv "1.3.3")
    (dash "2.5.0")
    (bbdb "20140412.1949"))
  :url "https://gitlab.com/iankelling/bbdb-csv-import"
  :commit "7739d10ebe1787a72aa74085e9baedd0f4988b00"
  :revdesc "7739d10ebe17"
  :keywords '("csv" "util" "bbdb")
  :authors '(("Ian Kelling" . "ian@iankelling.org"))
  :maintainers '(("Ian Kelling" . "ian@iankelling.org")))
