(define-package "csharp-mode" "20210114.2018" "C# mode derived mode" 'nil :commit "1d02a54f71b0c6ae0b5be9f764271ac31b1b0167" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
