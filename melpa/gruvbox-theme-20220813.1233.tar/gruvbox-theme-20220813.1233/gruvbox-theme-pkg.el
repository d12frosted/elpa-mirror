(define-package "gruvbox-theme" "20220813.1233" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "3929f29674ac1cb59efaa017e3c534e0d8d72a2d" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
