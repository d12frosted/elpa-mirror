(define-package "mistty" "20231121.1957" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "7b0548b178526881c3b9f9db8648b3e000d560d5" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
