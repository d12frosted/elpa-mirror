;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20260905.1007"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "c9dd19aed2276d80a7d6ff79cb5a7489b78a3cd5"
  :revdesc "c9dd19aed227"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
