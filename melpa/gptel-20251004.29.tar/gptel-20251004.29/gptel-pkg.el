;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251004.29"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "7c51c6680e4c070095a231ff7cf9734ea7d5ecfb"
  :revdesc "7c51c6680e4c"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
