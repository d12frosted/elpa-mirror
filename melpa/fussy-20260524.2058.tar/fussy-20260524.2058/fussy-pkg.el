;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260524.2058"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "077eadba04e30a8fd60bf67cb7d84ac6f478b350"
  :revdesc "077eadba04e3"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
