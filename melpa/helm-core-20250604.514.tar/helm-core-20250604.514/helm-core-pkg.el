;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250604.514"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "82d35e2cd674b3ac2bced7477e3dd162720ab436"
  :revdesc "82d35e2cd674"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
