(define-package "wanderlust" "20201119.1135" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "b0953d1a2cfaa5d7a762758f90e4fbe0b14adc12")
;; Local Variables:
;; no-byte-compile: t
;; End:
