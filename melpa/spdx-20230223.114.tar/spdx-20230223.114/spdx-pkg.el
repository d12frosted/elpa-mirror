(define-package "spdx" "20230223.114" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "fc7e36a24cb02617586849ce36c9ebe9a9a9c30f" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
