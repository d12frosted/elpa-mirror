(define-package "indent-control" "20230831.957" "Management for indentation level"
  '((emacs "26.1"))
  :commit "4ba467cd54037ff4aa184b8417e2328a9b238ba8" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "control" "indent" "tab" "generic" "level")
  :url "https://github.com/jcs-elpa/indent-control")
;; Local Variables:
;; no-byte-compile: t
;; End:
