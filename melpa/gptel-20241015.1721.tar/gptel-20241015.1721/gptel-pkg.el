;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241015.1721"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "8b129c57bb78ce2c4d26e183a01bc28631c3c68a"
  :revdesc "8b129c57bb78"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
