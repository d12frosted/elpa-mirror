;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260706.905"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "0fe8747e8f748b50493114abd45b9aabcdae26a3"
  :revdesc "0fe8747e8f74"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
