(define-package "syntree" "20220615.2331" "Draw plain text constituency trees"
  '((emacs "27.1"))
  :commit "1ad84a7905959b1d2c4f2fee37fbccc87d711864" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/syntree")
;; Local Variables:
;; no-byte-compile: t
;; End:
