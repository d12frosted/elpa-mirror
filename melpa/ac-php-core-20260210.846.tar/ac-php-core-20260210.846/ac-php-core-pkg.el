;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20260210.846"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "b053bd3723acf13a6c1a3e9cec221f4e0b24ea2c"
  :revdesc "b053bd3723ac"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
