;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "20260906.1251"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "06df011aee369d8c9a5cf6d7bc67ab8d3f65570c"
  :revdesc "06df011aee36"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
