;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20260101.1340"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "93694ae3c1862bd835195669a55a3c817a8e7c58"
  :revdesc "93694ae3c186"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
