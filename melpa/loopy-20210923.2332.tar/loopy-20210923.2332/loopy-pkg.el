(define-package "loopy" "20210923.2332" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22"))
  :commit "57542718c108e959c1577a0ea6531badc8221d01" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
