;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250711.55"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "c4510cee3927d5ecb535e9e696d45d14dd5fd865"
  :revdesc "c4510cee3927"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
