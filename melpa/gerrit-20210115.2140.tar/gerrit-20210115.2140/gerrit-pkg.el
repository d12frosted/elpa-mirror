(define-package "gerrit" "20210115.2140" "Gerrit client"
  '((emacs "25.1")
    (hydra "0.15.0")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "13cd8be45e3ec500edd4e0bf9a93338cd5c0e3a6" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
