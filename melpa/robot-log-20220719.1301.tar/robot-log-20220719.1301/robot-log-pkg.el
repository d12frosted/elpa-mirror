;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "robot-log" "20220719.1301"
  "Major mode for viewing RobotFramework debug log files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~apteryx/emacs-robot-log"
  :commit "26da47597aa97be9649cb60f4da6d94d47d0c0ac"
  :revdesc "26da47597aa9"
  :keywords '("convenience" "files"))
