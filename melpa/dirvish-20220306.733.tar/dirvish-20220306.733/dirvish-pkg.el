(define-package "dirvish" "20220306.733" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "5164f0ecec95930a30fa67737f387874a84fe0da" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
