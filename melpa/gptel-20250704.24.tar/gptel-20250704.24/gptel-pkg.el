;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250704.24"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "d967f9d66f6d2d857278a00ecc95bd87c7a4ed1e"
  :revdesc "d967f9d66f6d"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
