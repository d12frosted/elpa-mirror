;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dall-e-shell" "20241031.1124"
  "Interaction mode for DALL-E."
  '((emacs       "27.1")
    (shell-maker "0.58.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "3020c28eb899e84ada8fc41e9b7e87389777530b"
  :revdesc "3020c28eb899")
