(define-package "gumshoe" "20220831.2055" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "008e8fdec489a28e8cf807b3b511a9561c64268c" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
