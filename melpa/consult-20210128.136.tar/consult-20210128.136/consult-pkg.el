(define-package "consult" "20210128.136" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "4db4129024cd77b3c4ae706fdd963ae28288f69b" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
