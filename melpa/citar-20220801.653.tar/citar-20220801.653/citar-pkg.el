(define-package "citar" "20220801.653" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "3.0")
    (org "9.5")
    (citeproc "0.9"))
  :commit "ce0be815864326b4d446d84e10dcc6e0352811bb" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/emacs-citar/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
