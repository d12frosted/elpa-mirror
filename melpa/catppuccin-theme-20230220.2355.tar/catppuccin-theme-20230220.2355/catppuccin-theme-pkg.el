(define-package "catppuccin-theme" "20230220.2355" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "49f86fcc1b900fa9132149367248964a6e1604a5" :authors
  '(("nyxkrage"))
  :maintainer
  '("Carsten Kragelund" . "carsten@kragelund.me")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
