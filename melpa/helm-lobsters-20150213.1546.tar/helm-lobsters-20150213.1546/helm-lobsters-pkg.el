(define-package "helm-lobsters" "20150213.1546" "helm front-end for lobste.rs"
  '((helm "1.0")
    (cl-lib "0.5"))
  :commit "4121b232aeded2f82ad2c8a85c7dda17ef9d97bb" :authors
  '(("Julien BLANCHARD" . "julien@sideburns.eu"))
  :maintainers
  '(("Julien BLANCHARD" . "julien@sideburns.eu"))
  :maintainer
  '("Julien BLANCHARD" . "julien@sideburns.eu")
  :url "https://github.com/julienXX/helm-lobste.rs")
;; Local Variables:
;; no-byte-compile: t
;; End:
