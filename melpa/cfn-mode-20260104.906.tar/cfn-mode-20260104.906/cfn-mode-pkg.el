;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260104.906"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "643bec1175acc71dc8b246a0b32fe1e3f3fc7ede"
  :revdesc "643bec1175ac"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
