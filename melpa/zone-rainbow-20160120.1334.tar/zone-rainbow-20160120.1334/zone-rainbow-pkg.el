;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zone-rainbow" "20160120.1334"
  "Zone out with rainbow."
  '((emacs "24.3"))
  :url "https://github.com/kawabata/zone-rainbow"
  :commit "2ba4f1a87c69c4712124ebf12c1f3ea171e1af36"
  :revdesc "2ba4f1a87c69"
  :keywords '("games")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
