;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260505.1147"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "eb3b1b4d86c8f63fcded3f8c579e8b05b4cb4e0a"
  :revdesc "eb3b1b4d86c8"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
