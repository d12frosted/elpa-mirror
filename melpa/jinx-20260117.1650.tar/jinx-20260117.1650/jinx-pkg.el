;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260117.1650"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "b412673dec759131fe0abb346998b55225fbe771"
  :revdesc "b412673dec75"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
