(define-package "evil-collection" "20210102.223" "A set of keybindings for Evil mode"
  '((emacs "25.1")
    (evil "1.2.13")
    (annalist "1.0"))
  :commit "ac18f6cd4434eaf4346ae55a2035f1fb6c5be638" :authors
  (("James Nguyen" . "james@jojojames.com"))
  :maintainer
  ("James Nguyen" . "james@jojojames.com")
  :keywords
  ("evil" "tools")
  :url "https://github.com/emacs-evil/evil-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
