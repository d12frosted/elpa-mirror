;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260701.916"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "090df7670fc3c8f002bc62a357b56a455b177cd0"
  :revdesc "090df7670fc3"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
