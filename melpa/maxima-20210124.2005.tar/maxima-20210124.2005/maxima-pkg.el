(define-package "maxima" "20210124.2005" "Major mode for Maxima"
  '((emacs "25.1")
    (s "1.11.0")
    (test-simple "1.3.0"))
  :commit "9ebb2cab9c0272c8b957407ac2a5cff233d1d660" :authors
  '(("William F. Schelter")
    ("Jay Belanger")
    ("Fermin Munoz"))
  :maintainer
  '("Fermin Munoz" . "fmfs@posteo.net")
  :keywords
  '("maxima" "tools" "math")
  :url "https://gitlab.com/sasanidas/maxima")
;; Local Variables:
;; no-byte-compile: t
;; End:
