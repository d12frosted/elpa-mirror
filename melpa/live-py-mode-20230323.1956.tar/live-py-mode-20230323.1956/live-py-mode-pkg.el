(define-package "live-py-mode" "20230323.1956" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "2ea2fdcbdbc94859d34b9f6c0ad863e4209550cf" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
