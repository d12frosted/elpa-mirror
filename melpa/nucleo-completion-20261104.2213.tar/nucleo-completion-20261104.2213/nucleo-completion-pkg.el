;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20261104.2213"
  "Nucleo-backed completion style."
  '((emacs "29.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "9933657861ee46cf15b3e7e2700a14371fc39cd3"
  :revdesc "9933657861ee"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
