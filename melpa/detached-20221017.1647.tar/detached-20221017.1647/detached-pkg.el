(define-package "detached" "20221017.1647" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "a1075c64886d5d2b67a6f04079862c495c3fcd0c" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
