;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251211.2043"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "ef24f5f50bdad336ed0f28a0a8a7a0ef2b79c1bf"
  :revdesc "ef24f5f50bda"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
