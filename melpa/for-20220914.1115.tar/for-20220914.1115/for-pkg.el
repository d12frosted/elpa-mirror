(define-package "for" "20220914.1115" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "a6cbb22589801e03182f2c2c704f91592e52347e" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
