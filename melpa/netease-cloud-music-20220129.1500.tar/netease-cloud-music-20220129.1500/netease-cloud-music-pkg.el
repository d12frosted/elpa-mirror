(define-package "netease-cloud-music" "20220129.1500" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "a0af6f4f6043ffe3a3f84d66b341f02972b4b588" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
