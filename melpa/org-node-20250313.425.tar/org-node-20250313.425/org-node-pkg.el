;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250313.425"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (el-job        "1.0.5")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "2e95cdbfd50fa56e4646cd986e201b359140846a"
  :revdesc "2e95cdbfd50f"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
