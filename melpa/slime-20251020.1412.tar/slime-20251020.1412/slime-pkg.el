;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20251020.1412"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "69031d8ebffd0a9c0a43902da85a2f86c1df7ae9"
  :revdesc "69031d8ebffd"
  :keywords '("languages" "lisp" "slime"))
