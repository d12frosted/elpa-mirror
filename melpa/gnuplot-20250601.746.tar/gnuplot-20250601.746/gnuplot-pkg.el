;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250601.746"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "f3dd054c76e16262d0f9bfdce8cc44e22a831b1b"
  :revdesc "f3dd054c76e1"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
