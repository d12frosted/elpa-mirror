(define-package "npm" "20220428.839" "Run your npm workflows"
  '((emacs "25.1")
    (transient "0.1.0")
    (jest "20200625"))
  :commit "d0ba171f311e84a5c3e125f982a8d2718e49b662" :authors
  '(("Shane Kennedy"))
  :maintainer
  '("Shane Kennedy")
  :keywords
  '("tools")
  :url "https://github.com/shaneikennedy/npm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
