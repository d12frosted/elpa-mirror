(define-package "npm" "20220428.839" "Run your npm workflows"
  '((emacs "25.1")
    (transient "0.1.0")
    (jest "20200625"))
  :commit "ee1cd8340b737070cb649d367f0cd656e856feb3" :authors
  '(("Shane Kennedy"))
  :maintainer
  '("Shane Kennedy")
  :keywords
  '("tools")
  :url "https://github.com/shaneikennedy/npm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
