;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260331.1516"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "1dfd9ddb212ea867fccef33cbd141431036e49e6"
  :revdesc "1dfd9ddb212e"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
