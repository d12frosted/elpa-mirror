(define-package "dirvish" "20220415.1329" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "3d640589b47fb2724bd78390ddfa6dedda23e1ce" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
