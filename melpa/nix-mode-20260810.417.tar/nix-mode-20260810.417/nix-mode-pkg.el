;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-mode" "20260810.417"
  "Major mode for editing .nix files."
  '((emacs         "27.1")
    (magit-section "0")
    (reformatter   "0")
    (transient     "0.3"))
  :url "https://github.com/NixOS/nix-mode"
  :commit "4b66989ba2ac67b9f9dae7f89afe9fdc056c01fe"
  :revdesc "4b66989ba2ac"
  :keywords '("nix" "languages" "tools" "unix")
  :maintainers '(("Matthew Bauer" . "mjbauer95@gmail.com")))
