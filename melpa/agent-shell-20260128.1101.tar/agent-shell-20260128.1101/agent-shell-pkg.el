;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260128.1101"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "49e7eca4543f6387ed3ee145c32fc185ed084a17"
  :revdesc "49e7eca4543f")
