;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260602.356"
  "Unified interface for AI coding backends."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5adf0a9b2e7b7342ca9d5c26601e8ccac31f582f"
  :revdesc "5adf0a9b2e7b"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
