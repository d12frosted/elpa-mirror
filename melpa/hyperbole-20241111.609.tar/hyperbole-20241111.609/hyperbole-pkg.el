;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241111.609"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "9ebfcfe2e35e87c8df3c072c6b00ec4d63a5c47c"
  :revdesc "9ebfcfe2e35e"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
