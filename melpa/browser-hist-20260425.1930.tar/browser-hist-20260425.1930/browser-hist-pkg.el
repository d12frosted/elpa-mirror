;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browser-hist" "20260425.1930"
  "Search through the Browser history."
  '((emacs "28.1"))
  :url "https://github.com/agzam/browser-hist.el"
  :commit "aab0a364077bfbf5559085086545d30bbaf7ac5e"
  :revdesc "aab0a364077b"
  :keywords '("convenience" "hypermedia" "matching" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
