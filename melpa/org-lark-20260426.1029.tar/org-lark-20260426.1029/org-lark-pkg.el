;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "20260426.1029"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "9466add7b0076351864f676013e4cfd126acdd7b"
  :revdesc "9466add7b007"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
