(define-package "howdoyou" "20230816.1650" "A stackoverflow and its sisters' sites reader"
  '((emacs "25.1")
    (promise "1.1")
    (request "0.3.3")
    (org "9.2"))
  :commit "5a8d7878689d2c4fedbe040268bd5a43c169d16f" :authors
  '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers
  '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainer
  '("Thanh Vuong" . "thanhvg@gmail.com")
  :url "https://github.com/thanhvg/howdoyou/")
;; Local Variables:
;; no-byte-compile: t
;; End:
