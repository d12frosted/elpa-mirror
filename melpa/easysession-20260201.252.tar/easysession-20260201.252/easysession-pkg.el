;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260201.252"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "884c5d404f2b993de2ee7f0f6ea90b0465f5234d"
  :revdesc "884c5d404f2b"
  :keywords '("convenience"))
