;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260228.1011"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e5c8cd4a358b428d3810d197522a7483fc98585f"
  :revdesc "e5c8cd4a358b")
