;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "utimeclock" "20260108.1319"
  "Simple utility for manual time tracking."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-utimeclock"
  :commit "210b417d17770c7814c6177e9c787234807e65d0"
  :revdesc "210b417d1777"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
