(define-package "srfi" "20230503.34" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "d340e344cbc57b63952ba73c750986f8e13e616e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
