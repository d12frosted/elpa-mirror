(define-package "emacs-everywhere" "20240411.556" "System-wide popup windows for quick edits"
  '((emacs "26.3"))
  :commit "2f2521769ae90689c5370e7580553f5b1b8f6945" :authors
  '(("TEC <https://github.com/tecosaur>"))
  :maintainers
  '(("TEC" . "contact@tecosaur.net"))
  :maintainer
  '("TEC" . "contact@tecosaur.net")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/tecosaur/emacs-everywhere")
;; Local Variables:
;; no-byte-compile: t
;; End:
