(define-package "loopy" "20210630.1144" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "6d7bbcaab4addc2b2c751dd9d45caf5990698530" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
