;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacemacs-theme" "20250603.1412"
  "Color theme with a dark and light versions."
  ()
  :url "https://github.com/nashamri/spacemacs-theme"
  :commit "93938cfb21e62783f6073b87f9513f066aecc7d1"
  :revdesc "93938cfb21e6"
  :keywords '("color" "theme"))
