;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "20261108.211"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "5d843f712867dae5a223228df8eb50ab238e124f"
  :revdesc "5d843f712867"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
