;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-side-windows" "20260817.1434"
  "Simplified buffer management for side windows."
  '((emacs "30.1"))
  :url "https://github.com/MArpogaus/auto-side-windows"
  :commit "cf06db76c65aef2443557340cb06c3a6527186b2"
  :revdesc "cf06db76c65a"
  :keywords '("convenience" "windows" "buffers")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
