;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261117.1700"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "5eb5a06aaf65132f6065b74d636060db73f0045e"
  :revdesc "5eb5a06aaf65"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
