;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews-modern" "20261124.1200"
  "Hacker News client with modern widget UI."
  '((emacs              "28.1")
    (transient          "0.5.0")
    (visual-fill-column "2.2")
    (async-http-queue   "0.1.0"))
  :url "https://git.andros.dev/andros/hackernews-modern-el"
  :commit "409fb398b646655b88350beafb8f770abae4c161"
  :revdesc "409fb398b646"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
