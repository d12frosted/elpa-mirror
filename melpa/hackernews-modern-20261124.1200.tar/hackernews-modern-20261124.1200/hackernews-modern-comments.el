;;; hackernews-modern-comments.el --- Threaded comments view for hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Fetch the comment tree of a story from the Algolia Hacker News API
;; and display it as an indented, collapsible thread.

;;; Code:

(require 'async-http-queue)
(require 'hackernews-modern-core)
(require 'hackernews-modern-account)
(require 'hackernews-modern-reply)
(require 'hackernews-modern-vote)
(require 'hackernews-modern-edit)
(require 'hackernews-modern-actions)
(require 'hackernews-modern-menu)
(require 'hackernews-modern-user)

;; Forward declarations for controller symbols referenced in view.
(defvar hackernews-modern-comments-mode-map)
(declare-function visual-fill-column-mode "visual-fill-column")

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defconst hackernews-modern--comments-retries 5
  "Times a missing item is requested again, every two seconds.")

(defun hackernews-modern--algolia-normalize (node items)
  "Store Algolia NODE and its descendants in ITEMS.
Each node is converted to the item format of the official API so
that both sources render alike.  Return the number of descendants."
  (let ((id          (cdr (assq 'id node)))
        (author      (cdr (assq 'author node)))
        (text        (cdr (assq 'text node)))
        (kids        '())
        (descendants 0))
    (seq-doseq (child (cdr (assq 'children node)))
      (push (cdr (assq 'id child)) kids)
      (setq descendants
            (+ descendants 1 (hackernews-modern--algolia-normalize child items))))
    (puthash id
             `((id          . ,id)
               (by          . ,author)
               (time        . ,(cdr (assq 'created_at_i node)))
               (title       . ,(cdr (assq 'title node)))
               (url         . ,(cdr (assq 'url node)))
               (score       . ,(cdr (assq 'points node)))
               (text        . ,text)
               (kids        . ,(nreverse kids))
               (descendants . ,descendants)
               (deleted     . ,(and (null author) (null text))))
             items)
    descendants))

(defun hackernews-modern--fetch-comment-tree (id callback)
  "Fetch item ID and all its descendants asynchronously.
The whole tree is retrieved in a single request to the Algolia
Hacker News API.  Calls CALLBACK with a hash table mapping item
IDs to items."
  (async-http-queue
   (list (hackernews-modern--algolia-item-url id))
   :timeout 30
   :parser (lambda ()
             (json-parse-buffer :object-type 'alist
                                :null-object nil))
   :callback
   (lambda (results)
     (let ((items (make-hash-table))
           (tree  (aref results 0)))
       (when tree
         (hackernews-modern--algolia-normalize tree items))
       (funcall callback items)))))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--comment-prefix (depth)
  "Return the indentation prefix for a comment at DEPTH."
  (concat (make-string (* 2 depth) ?\s)
          (propertize "│ " 'face 'hackernews-modern-comment-indent)))

(defun hackernews-modern--toggle-subtree (overlay)
  "Toggle visibility of the comment subtree covered by OVERLAY."
  (let ((hidden (not (overlay-get overlay 'invisible)))
        (inhibit-read-only t))
    (overlay-put overlay 'invisible hidden)
    (widget-value-set (overlay-get overlay 'hackernews-modern-toggle)
                      (if hidden
                          (format "+%d" (overlay-get overlay 'hackernews-modern-count))
                        "-"))))

(defun hackernews-modern--render-comment (id items depth)
  "Render comment ID and its replies from ITEMS at DEPTH.
ITEMS is a hash table as returned by
`hackernews-modern--fetch-comment-tree'.  Deleted or dead comments
are only shown as a placeholder when they have replies.  Return
the number of comments rendered."
  (let* ((item (gethash id items))
         (kids (cdr (assq 'kids item)))
         (gone (or (cdr (assq 'deleted item)) (cdr (assq 'dead item)))))
    (if (or (null item) (and gone (seq-empty-p kids)))
        0
      (let* ((start   (point))
             (prefix  (hackernews-modern--comment-prefix depth))
             (by      (cdr (assq 'by item)))
             (time    (cdr (assq 'time item)))
             (text    (cdr (assq 'text item)))
             (own     (and by (equal by (hackernews-modern--current-user))))
             (count   1)
             (overlay nil)
             toggle body-start)
        (cond
         (gone (insert (propertize "[deleted]" 'face 'hackernews-modern-comment-time)))
         (own  (hackernews-modern--insert-author by 'hackernews-modern-own-author)
               (insert (propertize " (you)" 'face 'hackernews-modern-own-author)))
         (by   (hackernews-modern--insert-author by))
         (t    (insert (propertize "unknown" 'face 'hackernews-modern-author))))
        (when time
          (insert (propertize (format " · %s" (hackernews-modern--time-ago time))
                              'face 'hackernews-modern-comment-time)))
        (unless gone
          (hackernews-modern--insert-action-marks id))
        (insert " ")
        (add-text-properties start (point)
                             (list 'hackernews-modern-comment-depth depth
                                   'hackernews-modern-comment-id id))
        (setq toggle (widget-create 'push-button
                                    :notify (lambda (&rest _)
                                              (hackernews-modern--toggle-subtree overlay))
                                    :help-echo "Collapse or expand this thread"
                                    :format "%[%v%]"
                                    "-"))
        (unless gone
          (insert " ")
          (widget-create 'push-button
                         :notify (lambda (&rest _) (hackernews-modern--reply id))
                         :help-echo "Reply to this comment"
                         :format "%[%v%]"
                         "reply")
          (when (hackernews-modern--can-vote-p by)
            (insert " ")
            (hackernews-modern--insert-vote-button id))
          (insert " ")
          (hackernews-modern--insert-menu-button id))
        (insert "\n")
        (setq body-start (point))
        (when (and text (not gone))
          (hackernews-modern--insert-html text)
          (insert "\n"))
        (insert "\n")
        (add-text-properties start (point)
                             (list 'line-prefix prefix 'wrap-prefix prefix))
        (seq-doseq (kid kids)
          (setq count (+ count (hackernews-modern--render-comment kid items (1+ depth)))))
        (setq overlay (make-overlay body-start (point)))
        (overlay-put overlay 'hackernews-modern-toggle toggle)
        (overlay-put overlay 'hackernews-modern-count count)
        (put-text-property start body-start 'hackernews-modern-comment-subtree overlay)
        count))))

(defun hackernews-modern--insert-comments-header (story)
  "Insert the comments page header for STORY."
  (let* ((id       (cdr (assq 'id          story)))
         (title    (cdr (assq 'title       story)))
         (score    (cdr (assq 'score       story)))
         (by       (cdr (assq 'by          story)))
         (time     (cdr (assq 'time        story)))
         (text     (cdr (assq 'text        story)))
         (url      (cdr (assq 'url         story)))
         (total    (or (cdr (assq 'descendants story)) 0))
         (site-url (hackernews-modern--comments-url id)))
    (hackernews-modern--insert-logo)
    (widget-create 'push-button
                   :notify (lambda (&rest _) (quit-window))
                   :help-echo "Go back to the stories"
                   " ← Back ")
    (insert " ")
    (widget-create 'push-button
                   :notify (lambda (&rest _) (hackernews-modern-comments-reload))
                   :help-echo "Refresh comments"
                   " ↻ Refresh ")
    (insert " ")
    (widget-create 'push-button
                   :notify (lambda (&rest _) (hackernews-modern--browse-url site-url))
                   :help-echo site-url
                   " Open in browser ")
    (insert " ")
    (widget-create 'push-button
                   :notify (lambda (&rest _) (hackernews-modern--reply id))
                   :help-echo "Comment on this story"
                   " Add comment ")
    (insert "\n")
    (hackernews-modern--insert-account)
    (insert "\n\n")
    (hackernews-modern--insert-separator)
    (when title
      (widget-create 'push-button
                     :notify (lambda (&rest _) (hackernews-modern--browse-url (or url site-url)))
                     :help-echo (or url "No URL")
                     :format "%[%v%]"
                     (xml-substitute-special title))
      (insert "\n"))
    (insert "  ")
    (when score
      (insert (propertize (format "↑%d" score) 'face 'hackernews-modern-score-modern))
      (insert " | "))
    (insert (format "%d comment%s" total (if (= total 1) "" "s")))
    (when by
      (insert " | by ")
      (hackernews-modern--insert-author by))
    (when time
      (insert (propertize (format " | %s" (hackernews-modern--time-ago time))
                          'face 'hackernews-modern-comment-time)))
    (hackernews-modern--insert-action-marks id)
    (insert " | ")
    (when (hackernews-modern--can-vote-p by)
      (hackernews-modern--insert-vote-button id)
      (insert " "))
    (hackernews-modern--insert-menu-button id)
    (insert "\n")
    (when text
      (insert "\n")
      (hackernews-modern--insert-html text)
      (insert "\n"))
    (hackernews-modern--insert-separator)))

(defun hackernews-modern--display-comments (buffer items)
  "Render the comment tree ITEMS in BUFFER, keeping point when possible."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (let* ((window (get-buffer-window buffer t))
             (pos    (if window (window-point window) (point)))
             (story  (gethash hackernews-modern--comments-id items))
             (kids   (cdr (assq 'kids story)))
             (count  0)
             (inhibit-read-only t))
        (setq hackernews-modern--comments-items items)
        (erase-buffer)
        (remove-overlays)
        (if (null story)
            (insert "Could not load item.  Press g to try again.\n")
          (hackernews-modern--insert-comments-header story)
          (seq-doseq (kid kids)
            (setq count (+ count (hackernews-modern--render-comment kid items 0))))
          (when (= count 0)
            (insert "No comments yet.\n")))
        (use-local-map (make-composed-keymap
                        (list widget-keymap hackernews-modern-comments-mode-map)
                        special-mode-map))
        (widget-setup)
        (when (and (require 'visual-fill-column nil t)
                   (boundp 'visual-fill-column-width))
          (setq-local visual-fill-column-width hackernews-modern-display-width)
          (setq-local visual-fill-column-center-text t)
          (visual-fill-column-mode 1))
        (when (fboundp 'display-line-numbers-mode)
          (display-line-numbers-mode 0))
        (goto-char (min pos (point-max)))
        (when window
          (set-window-point window (point)))
        (message "Loaded %d comment%s" count (if (= count 1) "" "s"))))))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern-comments-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map "d" #'hackernews-modern-comments-delete)
    (define-key map "e" #'hackernews-modern-comments-edit)
    (define-key map "g" #'hackernews-modern-comments-reload)
    (define-key map "n" #'hackernews-modern-comments-next)
    (define-key map "o" #'hackernews-modern-comments-browse)
    (define-key map "p" #'hackernews-modern-comments-previous)
    (define-key map "r" #'hackernews-modern-comments-reply)
    (define-key map "t" #'hackernews-modern-comments-toggle)
    (define-key map "u" #'hackernews-modern-comments-parent)
    (define-key map "v" #'hackernews-modern-comments-vote)
    (define-key map "V" #'hackernews-modern-comments-downvote)
    (define-key map "x" #'hackernews-modern-comments-hide)
    (define-key map "F" #'hackernews-modern-comments-favorite)
    (define-key map "!" #'hackernews-modern-comments-flag)
    (define-key map "P" #'hackernews-modern-comments-profile)
    map)
  "Keymap used in hackernews-modern comments buffer.")

(define-derived-mode hackernews-modern-comments-mode special-mode "HN Comments"
  "Mode for reading the comments of a Hacker News story.

Key bindings:
\\<hackernews-modern-comments-mode-map>
\\[hackernews-modern-comments-next]		Move to next comment.
\\[hackernews-modern-comments-previous]		Move to previous comment.
\\[hackernews-modern-comments-parent]		Move to parent comment.
\\[hackernews-modern-comments-reply]		Reply to comment or story.
\\[hackernews-modern-comments-toggle]		Collapse or expand thread.
\\[hackernews-modern-comments-vote]		Upvote comment or story.
\\[hackernews-modern-comments-downvote]		Downvote comment.
\\[hackernews-modern-comments-favorite]		Favorite comment or story.
\\[hackernews-modern-comments-flag]		Flag comment or story.
\\[hackernews-modern-comments-hide]		Hide story.
\\[hackernews-modern-comments-profile]		View profile of author.
\\[hackernews-modern-comments-reload]		Reload comments.
\\[hackernews-modern-comments-browse]		Open in browser.
\\<special-mode-map>\\[quit-window]	Quit.

\\{hackernews-modern-comments-mode-map}"
  :interactive nil
  (setq hackernews-modern--redraw-function #'hackernews-modern--redraw-comments)
  (setq truncate-lines nil)
  (visual-line-mode 1)
  (buffer-disable-undo))

(defun hackernews-modern--redraw-comments ()
  "Render again the comments of the current buffer from its items."
  (when hackernews-modern--comments-items
    (let ((inhibit-message t))
      (hackernews-modern--display-comments (current-buffer)
                                           hackernews-modern--comments-items))))

(defun hackernews-modern--comment-header-p ()
  "Return the depth of the visible comment starting at point, if any."
  (and (not (invisible-p (point)))
       (get-text-property (point) 'hackernews-modern-comment-depth)))

(defun hackernews-modern--goto-comment (step &optional predicate)
  "Move point STEP lines at a time to the next matching comment.
PREDICATE is called with the comment depth and defaults to
accepting any comment.  Return non-nil if a comment was found."
  (let ((pos (save-excursion
               (beginning-of-line)
               (catch 'found
                 (while (zerop (forward-line step))
                   (let ((depth (hackernews-modern--comment-header-p)))
                     (when (and depth (or (null predicate) (funcall predicate depth)))
                       (throw 'found (point)))))))))
    (when pos
      (goto-char pos))))

(defun hackernews-modern-comments-next (&optional n)
  "Move to Nth next comment (previous if N is negative).
N defaults to 1."
  (declare (modes hackernews-modern-comments-mode))
  (interactive "p")
  (let ((count (or n 1)))
    (dotimes (_ (abs count))
      (unless (hackernews-modern--goto-comment (if (< count 0) -1 1))
        (message "No more comments")))))

(defun hackernews-modern-comments-previous (&optional n)
  "Move to Nth previous comment (next if N is negative).
N defaults to 1."
  (declare (modes hackernews-modern-comments-mode))
  (interactive "p")
  (hackernews-modern-comments-next (- (or n 1))))

(defun hackernews-modern--current-comment-depth ()
  "Move to the header of the comment at point and return its depth.
Return nil if point is not inside a comment."
  (beginning-of-line)
  (or (hackernews-modern--comment-header-p)
      (and (hackernews-modern--goto-comment -1)
           (hackernews-modern--comment-header-p))))

(defun hackernews-modern-comments-parent ()
  "Move to the parent of the comment at point."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (let ((depth (save-excursion (hackernews-modern--current-comment-depth))))
    (unless (and depth
                 (> depth 0)
                 (hackernews-modern--goto-comment
                  -1 (lambda (parent-depth) (< parent-depth depth))))
      (message "No parent comment"))))

(defun hackernews-modern-comments-toggle ()
  "Collapse or expand the comment thread at point."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (if (hackernews-modern--current-comment-depth)
      (hackernews-modern--toggle-subtree
       (get-text-property (point) 'hackernews-modern-comment-subtree))
    (message "No comment at point")))

(defun hackernews-modern--item-at-point ()
  "Return the ID of the comment at point, or of the story.
The story is used when point is not on a comment."
  (or (save-excursion
        (and (hackernews-modern--current-comment-depth)
             (get-text-property (point) 'hackernews-modern-comment-id)))
      hackernews-modern--comments-id))

(defun hackernews-modern-comments-reply ()
  "Reply to the comment at point, or comment on the story."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern--reply (hackernews-modern--item-at-point)))

(defun hackernews-modern-comments-vote ()
  "Upvote the comment at point, or the story when not on a comment.
Remove the vote instead if the item is already voted."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern--toggle-vote (hackernews-modern--item-at-point)))

(defun hackernews-modern-comments-downvote ()
  "Downvote the comment at point, or remove the downvote.
Hacker News only allows it with enough karma."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern--toggle-downvote (hackernews-modern--item-at-point)))

(defun hackernews-modern-comments-favorite ()
  "Add the comment at point to your favorites, or remove it.
Act on the story when point is not on a comment."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern--item-action (hackernews-modern--item-at-point) 'fave 'toggle))

(defun hackernews-modern-comments-flag ()
  "Flag the comment at point, or remove your flag.
Act on the story when point is not on a comment."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern--item-action (hackernews-modern--item-at-point) 'flag 'toggle))

(defun hackernews-modern-comments-hide ()
  "Hide the story of the current buffer, or show it again."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern--item-action hackernews-modern--comments-id 'hide 'toggle))

(defun hackernews-modern-comments-profile ()
  "View the profile of the author of the comment at point.
Use the author of the story when point is not on a comment."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern-user
   (or (cdr (assq 'by (gethash (hackernews-modern--item-at-point)
                               hackernews-modern--comments-items)))
       (user-error "This item has no author"))))

(defun hackernews-modern--own-item-at-point ()
  "Return the ID of your comment at point, or of your story.
The story is used when point is not on a comment."
  (let ((id (hackernews-modern--item-at-point)))
    (unless (equal (cdr (assq 'by (gethash id hackernews-modern--comments-items)))
                   (hackernews-modern--current-user))
      (user-error "You can only change your own comments and stories"))
    id))

(defun hackernews-modern-comments-edit ()
  "Edit your comment at point, or your story when not on a comment."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern--edit (hackernews-modern--own-item-at-point)))

(defun hackernews-modern-comments-delete ()
  "Delete your comment at point, or your story when not on a comment."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern--delete (hackernews-modern--own-item-at-point)))

;;;###autoload
(defun hackernews-modern-comments (id)
  "Display the comments of the Hacker News item with ID."
  (interactive (list (read-number "Hacker News item ID: ")))
  (let ((buffer (get-buffer-create (format "*hackernews-modern comments %s*" id))))
    (with-current-buffer buffer
      (unless (derived-mode-p #'hackernews-modern-comments-mode)
        (hackernews-modern-comments-mode)
        (setq hackernews-modern--comments-id id)
        (let ((inhibit-read-only t))
          (insert "Loading comments..."))))
    (pop-to-buffer buffer '((display-buffer-same-window)))
    (hackernews-modern-comments-reload)))

(defun hackernews-modern--load-comments (buffer attempt)
  "Fetch the comments of BUFFER and render them.
New items take a few seconds to reach the Algolia API, so a missing
item is requested again up to `hackernews-modern--comments-retries'
times.  ATTEMPT is the number of requests already made."
  (let ((id (buffer-local-value 'hackernews-modern--comments-id buffer)))
    (hackernews-modern--fetch-comment-tree
     id
     (lambda (items)
       (if (and (null (gethash id items))
                (< attempt hackernews-modern--comments-retries)
                (buffer-live-p buffer))
           (progn
             (message "Waiting for Hacker News to publish the item...")
             (run-at-time 2 nil #'hackernews-modern--load-comments buffer (1+ attempt)))
         (hackernews-modern--display-comments buffer items))))))

(defun hackernews-modern-comments-reload ()
  "Fetch and redisplay the comments of the current buffer."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (unless (derived-mode-p #'hackernews-modern-comments-mode)
    (user-error "Not a hackernews-modern comments buffer"))
  (let ((buffer (current-buffer)))
    (message "Retrieving comments...")
    (hackernews-modern--load-comments buffer 0)
    (when (hackernews-modern--current-user)
      (hackernews-modern--fetch-votes
       hackernews-modern--comments-id
       (lambda ()
         (when (buffer-live-p buffer)
           (with-current-buffer buffer
             (hackernews-modern--redraw #'hackernews-modern--redraw-comments))))))))

(defun hackernews-modern-comments-browse ()
  "Open the current comments page in the browser."
  (declare (modes hackernews-modern-comments-mode))
  (interactive)
  (hackernews-modern--browse-url (hackernews-modern--comments-url hackernews-modern--comments-id)))

(provide 'hackernews-modern-comments)

;;; hackernews-modern-comments.el ends here
