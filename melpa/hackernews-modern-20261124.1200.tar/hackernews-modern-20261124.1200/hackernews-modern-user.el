;;; hackernews-modern-user.el --- User profiles for hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; User profiles for hackernews-modern: karma, creation date and the
;; "about" text of a user, fetched from the API.  Author names are
;; clickable and open the profile of the author.

;;; Code:

(require 'button)
(require 'hackernews-modern-core)
(require 'hackernews-modern-account)

;; Forward declarations for controller symbols referenced in view.
(defvar hackernews-modern-user-mode-map)
(declare-function visual-fill-column-mode "visual-fill-column")

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar-local hackernews-modern--user-name nil
  "Name of the user whose profile is shown in the current buffer.")

(defvar-local hackernews-modern--user-data nil
  "Profile shown in the current buffer, as returned by the API.
It is nil while loading and `missing' when the user does not exist.")

(defun hackernews-modern--fetch-user (name callback)
  "Fetch the profile of user NAME from the API asynchronously.
Calls CALLBACK with the profile as an alist, `missing' when the user
does not exist or nil on errors."
  (url-retrieve
   (hackernews-modern--user-url name)
   (lambda (status)
     (let ((data (and (not (plist-get status :error))
                      (progn
                        (goto-char (point-min))
                        (re-search-forward "\r?\n\r?\n" nil t))
                      (condition-case err
                          (or (json-parse-buffer :object-type 'alist
                                                 :null-object nil)
                              'missing)
                        (json-error
                         (message "Error reading the profile of %s: %s"
                                  name (error-message-string err))
                         nil)))))
       (kill-buffer (current-buffer))
       (funcall callback data)))
   nil t))

(defun hackernews-modern--group-digits (number)
  "Return NUMBER as a string with its thousands separated by commas."
  (let ((digits (number-to-string number)))
    (while (string-match "\\([0-9]\\)\\([0-9]\\{3\\}\\)\\(,\\|\\'\\)" digits)
      (setq digits (replace-match "\\1,\\2\\3" t nil digits)))
    digits))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--insert-author (name &optional face)
  "Insert NAME as a link that opens the profile of the user.
FACE defaults to `hackernews-modern-author'."
  (insert-text-button name
                      'face (or face 'hackernews-modern-author)
                      'mouse-face 'highlight
                      'follow-link t
                      'help-echo (format "View the profile of %s" name)
                      'action (lambda (_button) (hackernews-modern-user name))))

(defun hackernews-modern--insert-site-link (label path)
  "Insert a button with LABEL that opens PATH of the website."
  (widget-create 'push-button
                 :notify (lambda (&rest _)
                           (hackernews-modern--browse-url (hackernews-modern--site-url path)))
                 :help-echo (format "Open %s in the browser"
                                    (hackernews-modern--site-url path))
                 (format " %s ↗ " label)))

(defun hackernews-modern--insert-user-profile (name data)
  "Insert the profile DATA of user NAME."
  (let ((karma   (cdr (assq 'karma data)))
        (created (cdr (assq 'created data)))
        (about   (cdr (assq 'about data)))
        (items   (length (cdr (assq 'submitted data))))
        (own     (equal name (hackernews-modern--current-user))))
    (insert (propertize name 'face (if own
                                       'hackernews-modern-own-author
                                     'hackernews-modern-author)))
    (when own
      (insert (propertize " (you)" 'face 'hackernews-modern-comment-time)))
    (insert "\n\n")
    (when karma
      (insert "  Karma:   ")
      (insert (propertize (hackernews-modern--group-digits karma)
                          'face 'hackernews-modern-score-modern))
      (insert "\n"))
    (when created
      (insert (format "  Joined:  %s " (format-time-string "%B %-d, %Y" created t)))
      (insert (propertize (format "(%s)" (hackernews-modern--time-ago created))
                          'face 'hackernews-modern-comment-time))
      (insert "\n"))
    (insert (format "  Posted:  %s item%s\n"
                    (hackernews-modern--group-digits items) (if (= items 1) "" "s")))
    (hackernews-modern--insert-separator)
    (if (and about (not (string-empty-p about)))
        (progn
          (hackernews-modern--insert-html about)
          (insert "\n"))
      (insert (propertize "No \"about\" text.\n" 'face 'hackernews-modern-comment-time)))
    (hackernews-modern--insert-separator)
    (insert "On the website: ")
    (hackernews-modern--insert-site-link "Submissions" (format "submitted?id=%s" name))
    (insert " ")
    (hackernews-modern--insert-site-link "Comments" (format "threads?id=%s" name))
    (insert " ")
    (hackernews-modern--insert-site-link "Favorites" (format "favorites?id=%s" name))
    (insert "\n")))

(defun hackernews-modern--display-user (buffer)
  "Render the profile stored in BUFFER, keeping point when possible."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (let* ((window (get-buffer-window buffer t))
             (pos    (if window (window-point window) (point)))
             (name   hackernews-modern--user-name)
             (data   hackernews-modern--user-data)
             (inhibit-read-only t))
        (erase-buffer)
        (remove-overlays)
        (hackernews-modern--insert-logo)
        (widget-create 'push-button
                       :notify (lambda (&rest _) (quit-window))
                       :help-echo "Go back"
                       " ← Back ")
        (insert " ")
        (widget-create 'push-button
                       :notify (lambda (&rest _) (hackernews-modern-user-reload))
                       :help-echo "Refresh the profile"
                       " ↻ Refresh ")
        (insert " ")
        (widget-create 'push-button
                       :notify (lambda (&rest _) (hackernews-modern-user-browse))
                       :help-echo (hackernews-modern--site-url (format "user?id=%s" name))
                       " Open in browser ")
        (insert "\n")
        (hackernews-modern--insert-account)
        (insert "\n")
        (hackernews-modern--insert-separator)
        (pcase data
          ('nil     (insert "Loading profile...\n"))
          ('missing (insert (format "There is no user called %s.\n" name)))
          (_        (hackernews-modern--insert-user-profile name data)))
        (use-local-map (make-composed-keymap
                        (list widget-keymap hackernews-modern-user-mode-map)
                        special-mode-map))
        (widget-setup)
        (when (and (require 'visual-fill-column nil t)
                   (boundp 'visual-fill-column-width))
          (setq-local visual-fill-column-width hackernews-modern-display-width)
          (setq-local visual-fill-column-center-text t)
          (visual-fill-column-mode 1))
        (when (fboundp 'display-line-numbers-mode)
          (display-line-numbers-mode 0))
        (goto-char (min pos (point-max)))
        (when window
          (set-window-point window (point)))))))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern-user-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map "g" #'hackernews-modern-user-reload)
    (define-key map "o" #'hackernews-modern-user-browse)
    map)
  "Keymap used in hackernews-modern user profile buffer.")

(define-derived-mode hackernews-modern-user-mode special-mode "HN User"
  "Mode for reading the profile of a Hacker News user.

\\<hackernews-modern-user-mode-map>
\\[hackernews-modern-user-reload]	Reload the profile.
\\[hackernews-modern-user-browse]	Open the profile in the browser.
\\<special-mode-map>\\[quit-window]	Quit.

\\{hackernews-modern-user-mode-map}"
  :interactive nil
  (setq hackernews-modern--redraw-function
        (lambda () (hackernews-modern--display-user (current-buffer))))
  (setq truncate-lines nil)
  (visual-line-mode 1)
  (buffer-disable-undo))

;;;###autoload
(defun hackernews-modern-user (name)
  "Display the profile of the Hacker News user NAME."
  (interactive
   (list (let ((default (hackernews-modern--current-user)))
           (read-string (format-prompt "Hacker News user" default) nil nil default))))
  (when (string-empty-p name)
    (user-error "No user name given"))
  (let ((buffer (get-buffer-create (format "*hackernews-modern user %s*" name))))
    (with-current-buffer buffer
      (unless (derived-mode-p #'hackernews-modern-user-mode)
        (hackernews-modern-user-mode)
        (setq hackernews-modern--user-name name)
        (hackernews-modern--display-user buffer)))
    (pop-to-buffer buffer '((display-buffer-same-window)))
    (hackernews-modern-user-reload)))

(defun hackernews-modern-user-reload ()
  "Fetch and redisplay the profile of the current buffer."
  (declare (modes hackernews-modern-user-mode))
  (interactive)
  (unless (derived-mode-p #'hackernews-modern-user-mode)
    (user-error "Not a hackernews-modern user buffer"))
  (let ((buffer (current-buffer)))
    (message "Retrieving profile...")
    (hackernews-modern--fetch-user
     hackernews-modern--user-name
     (lambda (data)
       (when (buffer-live-p buffer)
         (if (null data)
             (message "Could not load the profile, press g to try again")
           (with-current-buffer buffer
             (setq hackernews-modern--user-data data))
           (hackernews-modern--display-user buffer)
           (message nil)))))))

(defun hackernews-modern-user-browse ()
  "Open the profile of the current buffer in the browser."
  (declare (modes hackernews-modern-user-mode))
  (interactive)
  (hackernews-modern--browse-url
   (hackernews-modern--site-url (format "user?id=%s" hackernews-modern--user-name))))

(provide 'hackernews-modern-user)

;;; hackernews-modern-user.el ends here
