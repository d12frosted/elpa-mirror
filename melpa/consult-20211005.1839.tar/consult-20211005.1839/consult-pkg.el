(define-package "consult" "20211005.1839" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "24e5b4563b7203b5ec3626b71491ea390adf80b5" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
