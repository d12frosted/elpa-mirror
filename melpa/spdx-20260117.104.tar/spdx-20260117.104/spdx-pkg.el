;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260117.104"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "40c4691ed406ac2a905c94ec69c720f79a607389"
  :revdesc "40c4691ed406"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
