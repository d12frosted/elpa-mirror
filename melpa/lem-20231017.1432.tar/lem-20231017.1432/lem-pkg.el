(define-package "lem" "20231017.1432" "A basic lemmy client"
  '((emacs "29.1")
    (fedi "0.1")
    (markdown-mode "2.5"))
  :commit "44b9535698384851f93257fd132319fb62c13c9e" :authors
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainers
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainer
  '("martian hiatus <martianhiatus [a t] riseup [d o t] net>")
  :keywords
  '("multimedia" "comm" "web" "fediverse")
  :url "https://codeberg.org/martianh/lem.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
