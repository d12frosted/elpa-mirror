;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260102.1328"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "011344bc2e0605085ea0164e5d520702adafc261"
  :revdesc "011344bc2e06"
  :keywords '("hypermedia"))
