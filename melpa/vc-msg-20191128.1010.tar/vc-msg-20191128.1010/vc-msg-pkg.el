(define-package "vc-msg" "20191128.1010" "Show commit information of current line"
  '((emacs "24.4")
    (popup "0.5.0"))
  :commit "93794111daa95b809e46e6d961ad5f68eb8f78ed" :keywords
  ("git" "vc" "svn" "hg" "messenger")
  :authors
  (("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  ("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :url "http://github.com/redguardtoo/vc-msg")
;; Local Variables:
;; no-byte-compile: t
;; End:
