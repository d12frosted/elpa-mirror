(define-package "orderless" "20230920.114" "Completion style for matching regexps in any order"
  '((emacs "26.1"))
  :commit "83c2be6ec4ba73c761777bc13b41b87b98fa669b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("extensions")
  :url "https://github.com/oantolin/orderless")
;; Local Variables:
;; no-byte-compile: t
;; End:
