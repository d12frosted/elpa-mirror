(define-package "ebib" "20210930.1217" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "63b0700eefc982276002ae8d618e8a7fa1f68732" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
