(define-package "ncl-mode" "20180129.703" "Major Mode for editing NCL scripts and other goodies"
  '((emacs "24"))
  :commit "602292712a9e6b7e7c25155978999e77d06b7338" :authors
  (("Yagnesh Raghava Yakkala" . "hi@yagnesh.org"))
  :maintainer
  ("Yagnesh Raghava Yakkala" . "hi@yagnesh.org")
  :keywords
  ("ncl" "major mode" "ncl-mode" "atmospheric science.")
  :url "https://github.com/yyr/ncl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
