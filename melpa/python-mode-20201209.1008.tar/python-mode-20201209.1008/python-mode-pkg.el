(define-package "python-mode" "20201209.1008" "Python major mode" 'nil :commit "bbf7674526688d159069ed2a6b9bd4f4b440f350")
;; Local Variables:
;; no-byte-compile: t
;; End:
