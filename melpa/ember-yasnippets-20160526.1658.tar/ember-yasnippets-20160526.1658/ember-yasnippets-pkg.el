;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ember-yasnippets" "20160526.1658"
  "Snippets for Ember.js development."
  '((yasnippet "0.8.0"))
  :url "https://github.com/ronco/ember-yasnippets.el"
  :commit "3b5bd01569646237bf1b540d097e12f9118b67f4"
  :revdesc "3b5bd0156964"
  :keywords '("tools" "abbrev" "languages")
  :authors '(("Ron White" . "ronco@costite.com"))
  :maintainers '(("Ron White" . "ronco@costite.com")))
