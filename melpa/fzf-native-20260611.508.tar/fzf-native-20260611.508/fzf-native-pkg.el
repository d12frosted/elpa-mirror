;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260611.508"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "50af3949ec37f85690e75179cc3f999550ffe077"
  :revdesc "50af3949ec37"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
