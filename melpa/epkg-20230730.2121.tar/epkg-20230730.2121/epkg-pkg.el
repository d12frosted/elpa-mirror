(define-package "epkg" "20230730.2121" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "29.1.4.1")
    (closql "20230407")
    (emacsql "20230409")
    (llama "0.2.0"))
  :commit "dfb66853b1dabdbcda1c4565db418a644968da7d" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
