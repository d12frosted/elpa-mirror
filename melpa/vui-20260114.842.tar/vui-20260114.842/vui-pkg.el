;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260114.842"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "5bbbecd7fbdb8e4528705aeb40c58690237bd4c1"
  :revdesc "5bbbecd7fbdb"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
