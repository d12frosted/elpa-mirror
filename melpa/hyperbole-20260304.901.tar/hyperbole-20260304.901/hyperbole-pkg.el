;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260304.901"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "039fe8d0df54c6d38d33578c96b62a6deb7c0a2e"
  :revdesc "039fe8d0df54"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
