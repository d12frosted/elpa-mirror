(define-package "detached" "20220916.1331" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "21a8cb01bb6714dcab99c49fc6a92c31540358fa" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
