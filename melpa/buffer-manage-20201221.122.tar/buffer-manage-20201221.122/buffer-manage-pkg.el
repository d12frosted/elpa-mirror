(define-package "buffer-manage" "20201221.122" "Manage buffers"
  '((emacs "26.1")
    (choice-program "0.13")
    (dash "2.17.0"))
  :commit "800f22e024a2f364ac69d9efddd25ea0ac7c49c0" :keywords
  ("internal" "maint")
  :authors
  (("Paul Landes"))
  :maintainer
  ("Paul Landes")
  :url "https://github.com/plandes/buffer-manage")
;; Local Variables:
;; no-byte-compile: t
;; End:
