;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260513.1417"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f71fdcdda598e55914972b722ad01f735d8fa360"
  :revdesc "f71fdcdda598"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
