(define-package "org-mpv-notes" "20230907.530" "Take notes in org mode while watching videos in mpv"
  '((emacs "27.1")
    (mpv "0.2.0"))
  :commit "072cecf7097829c463fc38f4bb5026b2311036b6" :authors
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainers
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainer
  '("Bibek Panthi" . "bpanthi977@gmail.com")
  :url "https://github.com/bpanthi977/org-mpv-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
