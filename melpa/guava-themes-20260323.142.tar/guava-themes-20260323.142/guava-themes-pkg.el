;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260323.142"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "c3f11e6a8e8dae0fa258c181d637ca0e0bcd17b6"
  :revdesc "c3f11e6a8e8d"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
