(define-package "org-runbook" "20220512.1934" "Org mode for runbooks" 'nil :commit "253c2876446650249d59ac35200b373a0aee4e68" :authors
  '(("Tyler Dodge"))
  :maintainer
  '("Tyler Dodge")
  :keywords
  '("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
