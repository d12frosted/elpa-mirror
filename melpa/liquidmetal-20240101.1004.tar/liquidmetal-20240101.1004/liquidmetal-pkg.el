;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liquidmetal" "20240101.1004"
  "A mimetic poly-alloy of the Quicksilver scoring algorithm."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/liquidmetal"
  :commit "5d100f4371e0d10656a2bd23c0461781c3c1884b"
  :revdesc "5d100f4371e0"
  :keywords '("matching" "fuzzy")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
