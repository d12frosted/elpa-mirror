;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "20251222.1130"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "a889a37dbe96529b92372170092cc9bbf045fe83"
  :revdesc "a889a37dbe96"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
