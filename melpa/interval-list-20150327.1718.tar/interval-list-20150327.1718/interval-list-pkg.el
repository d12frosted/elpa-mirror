;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "interval-list" "20150327.1718"
  "Interval list data structure for 1D selections."
  '((dash   "2.4.0")
    (cl-lib "0.5")
    (emacs  "24.4"))
  :url "https://github.com/Fuco1/interval-list"
  :commit "38af7ecf0a493ad8f487074938a2a115f3531177"
  :revdesc "38af7ecf0a49"
  :keywords '("extensions" "data structure")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
