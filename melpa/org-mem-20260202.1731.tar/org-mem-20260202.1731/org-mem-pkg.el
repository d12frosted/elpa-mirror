;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260202.1731"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "58a6ae3f53e87c548ceeebae114230d7424a33ca"
  :revdesc "58a6ae3f53e8"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
