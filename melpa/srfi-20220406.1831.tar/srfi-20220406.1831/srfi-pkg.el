(define-package "srfi" "20220406.1831" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "dbcdc58d3ea9e0767b24bb0f05fc8de8849889fe" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
