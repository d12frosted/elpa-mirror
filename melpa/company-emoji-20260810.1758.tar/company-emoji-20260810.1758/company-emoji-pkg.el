;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-emoji" "20260810.1758"
  "Company-mode backend for emoji."
  '((cl-lib  "0.5")
    (company "0.8.0"))
  :url "https://codeberg.org/egirl/company-emoji"
  :commit "1cfed9f1eaba4210a9d3632d1123cca39a7d8c9a"
  :revdesc "1cfed9f1eaba"
  :keywords '("emoji" "company")
  :authors '(("Alex Dunn" . "git@garbage.world"))
  :maintainers '(("Alex Dunn" . "git@garbage.world")))
