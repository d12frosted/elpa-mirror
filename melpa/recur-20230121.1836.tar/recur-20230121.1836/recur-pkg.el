;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recur" "20230121.1836"
  "Tail call optimization."
  '((emacs "24.3"))
  :url "https://github.com/ROCKTAKEY/recur"
  :commit "043b3267125cb9fa273d0f0afee0dda1fc60c507"
  :revdesc "043b3267125c"
  :keywords '("lisp")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
