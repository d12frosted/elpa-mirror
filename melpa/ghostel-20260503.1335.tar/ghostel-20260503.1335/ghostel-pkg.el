;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260503.1335"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "6a6101a6a5f7cae8f12f0a2b909eaab881c9c1a2"
  :revdesc "6a6101a6a5f7"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
