(define-package "modus-themes" "20220407.959" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "874a2834b5bd3bb6c3702194e6e14dbe4e9c10b2" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
