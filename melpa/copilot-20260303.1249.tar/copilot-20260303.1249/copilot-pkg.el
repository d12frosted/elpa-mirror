;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260303.1249"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "5ba5ee222487e79da21ab0d71c87cd365bb825d9"
  :revdesc "5ba5ee222487"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
