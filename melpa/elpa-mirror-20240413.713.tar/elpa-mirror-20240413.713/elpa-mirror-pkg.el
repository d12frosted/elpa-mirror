(define-package "elpa-mirror" "20240413.713" "Create local package repository from installed packages"
  '((emacs "25.1"))
  :commit "98ed08e8bc55548326481204bc80267bd2eb4a58" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("tools")
  :url "http://github.com/redguardtoo/elpa-mirror")
;; Local Variables:
;; no-byte-compile: t
;; End:
