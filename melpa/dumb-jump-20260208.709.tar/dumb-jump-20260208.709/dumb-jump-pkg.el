;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260208.709"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.4")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "8c4df89c946c00d44955c0f5dda535b9bcaf8642"
  :revdesc "8c4df89c946c"
  :keywords '("programming"))
