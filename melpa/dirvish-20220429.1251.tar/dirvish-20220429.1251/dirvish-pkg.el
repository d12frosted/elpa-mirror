(define-package "dirvish" "20220429.1251" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "90adc0364cf43c1a1edb32452a3925ccf4083ef0" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
