;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20241229.939"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0"))
  :url "https://github.com/emarsden/pg-el"
  :commit "86d6fae334405fa08233f146ce932ae36fc96af4"
  :revdesc "86d6fae33440"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
