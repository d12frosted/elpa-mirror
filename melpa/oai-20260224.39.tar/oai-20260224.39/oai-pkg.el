;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260224.39"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "ef1a4ee5b7737734482bb2c6d3a9800d89a6fbcb"
  :revdesc "ef1a4ee5b773"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
