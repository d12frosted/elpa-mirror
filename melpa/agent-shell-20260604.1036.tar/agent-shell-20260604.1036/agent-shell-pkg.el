;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260604.1036"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e81dad492ce56f12021c7ca03fae238cefdcf0e0"
  :revdesc "e81dad492ce5")
