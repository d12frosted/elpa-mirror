(define-package "for" "20220829.957" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "cfe36764d6a5c44946236b45cfa576c106929743" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
