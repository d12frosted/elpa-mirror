;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20250617.1224"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "5247d657672f88ef27f8bec454be13adf7b9248a"
  :revdesc "5247d657672f"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
