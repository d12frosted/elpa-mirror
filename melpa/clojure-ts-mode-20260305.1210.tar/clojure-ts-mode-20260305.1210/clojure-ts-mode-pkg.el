;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20260305.1210"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "https://github.com/clojure-emacs/clojure-ts-mode"
  :commit "1c6a7203ff179bc828b11b133b42f67d699d919f"
  :revdesc "1c6a7203ff17"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
