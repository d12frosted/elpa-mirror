;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260601.1950"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "b60321d7330d4fc7b0390f3c6227252100c5d0d9"
  :revdesc "b60321d7330d"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
