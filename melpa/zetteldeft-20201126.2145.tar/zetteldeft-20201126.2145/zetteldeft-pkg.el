(define-package "zetteldeft" "20201126.2145" "Turn deft into a zettelkasten system"
  '((emacs "25.1")
    (deft "0.8")
    (ace-window "0.7.0"))
  :commit "da75753b20e55159ef57350e2d4e2892f157038f" :keywords
  ("deft" "zettelkasten" "zetteldeft" "wp" "files")
  :authors
  (("EFLS <Elias Storms>"))
  :maintainer
  ("EFLS <Elias Storms>")
  :url "https://efls.github.io/zetteldeft/")
;; Local Variables:
;; no-byte-compile: t
;; End:
