(define-package "company" "20210329.1517" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "b2a0993e61afd149c9ea3e2ca3a5268b2143af4a" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
