;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260315.2025"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "738dfc00f887e1dfb12743c34f5813447bfa269c"
  :revdesc "738dfc00f887"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
