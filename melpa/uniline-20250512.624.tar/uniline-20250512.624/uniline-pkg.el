;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250512.624"
  "Add ╭─╴UNICODE╶─╮ based ╭─╴diagrams╶─╮ to ╭▶╴text files╶●╮."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "45b6dc248ef756475d93e55793d522b6ef28bf3c"
  :revdesc "45b6dc248ef7"
  :keywords '("convenience" "text"))
