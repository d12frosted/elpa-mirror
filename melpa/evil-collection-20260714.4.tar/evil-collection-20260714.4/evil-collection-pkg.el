;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260714.4"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "a067dd64854113d01d5945796a7d29c923502d17"
  :revdesc "a067dd648541"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
