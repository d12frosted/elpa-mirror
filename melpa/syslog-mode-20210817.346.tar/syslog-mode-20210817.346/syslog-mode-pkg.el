(define-package "syslog-mode" "20210817.346" "Major-mode for viewing log files"
  '((hide-lines "20130623")
    (ov "20150311"))
  :commit "55a48ca1fd73c2a46dfa951369080e9f15750dff" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
