;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20251007.2026"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.8")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "d526da8160ad709a05795270ed1f0b2ae7151ec3"
  :revdesc "d526da8160ad"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
