;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260621.431"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "7a17cd36c3933ef149c5e205e5a1413a72dfc9b3"
  :revdesc "7a17cd36c393"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
