;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20250924.2133"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/casual"
  :commit "65e9a610381cd3cb6c0541fe450c65d33a84581f"
  :revdesc "65e9a610381c"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
