;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20251211.738"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "96caa030b55cc4a501bdd3245ec9ed99912b4660"
  :revdesc "96caa030b55c"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
