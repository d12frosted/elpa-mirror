;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdel-embark" "20230103.2021"
  "Integrate MPDel with Embark."
  '((emacs    "26.1")
    (mpdel    "2.0.0")
    (libmpdel "2.0.0")
    (embark   "0.19"))
  :url "https://github.com/mpdel/mpdel-embark"
  :commit "31d91a62b680fb4472ec34c04ac6af80bb3cf4b8"
  :revdesc "31d91a62b680"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
