;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swift-mode" "20260801.908"
  "Major-mode for Apple's Swift programming language."
  '((emacs "25.2"))
  :url "https://github.com/swift-emacs/swift-mode"
  :commit "5ee70779cd6d4f643016d6d0f4d5ed7d33766334"
  :revdesc "5ee70779cd6d"
  :keywords '("languages" "swift")
  :authors '(("taku0" . "mxxouy6x3m_github@tatapa.org")
             ("Chris Barrett" . "chris.d.barrett@me.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.com")
             ("Arthur Evstifeev" . "lod@pisem.net"))
  :maintainers '(("taku0" . "mxxouy6x3m_github@tatapa.org")))
