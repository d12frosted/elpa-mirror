(define-package "git-commit" "20240429.1323" "Edit Git commit messages."
  '((emacs "25.1")
    (compat "29.1.4.4")
    (transient "20231204")
    (with-editor "20230917"))
  :commit "150eed71b98597018cc4a47d1c50c3f56b747eef" :authors
  '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
