(define-package "bqn-mode" "20230718.141" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "cd7a9956a03bafbc4beff96246cad94779b953d1" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainers
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
