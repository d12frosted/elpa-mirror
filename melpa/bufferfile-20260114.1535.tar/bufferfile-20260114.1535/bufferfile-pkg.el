;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20260114.1535"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "6bcff99b4e78a83ffaa15f1ce95f4f0421db64b0"
  :revdesc "6bcff99b4e78"
  :keywords '("convenience"))
