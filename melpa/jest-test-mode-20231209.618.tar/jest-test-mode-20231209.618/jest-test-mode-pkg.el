(define-package "jest-test-mode" "20231209.618" "Minor mode for running Node.js tests using jest"
  '((emacs "25.1"))
  :commit "248f9019522cea83c91e8689f9effc77e7e1679d" :authors
  '(("Raymond Huang" . "rymndhng@gmail.com"))
  :maintainers
  '(("Raymond Huang" . "rymndhng@gmail.com"))
  :maintainer
  '("Raymond Huang" . "rymndhng@gmail.com")
  :url "https://github.com/rymndhng/jest-test-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
