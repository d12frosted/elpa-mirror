;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261109.1154"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "97363277e1ff700a0b0a85545531e1723fc81b2c"
  :revdesc "97363277e1ff"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
