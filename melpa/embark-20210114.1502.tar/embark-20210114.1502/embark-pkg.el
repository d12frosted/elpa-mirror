(define-package "embark" "20210114.1502" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "1a477924644cc8bf061a91a2b5935f1f0701b913" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
