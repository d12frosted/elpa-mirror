;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260430.942"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "1d29a7839c66a365dfae26c9f91dc01ced7e860b"
  :revdesc "1d29a7839c66"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
