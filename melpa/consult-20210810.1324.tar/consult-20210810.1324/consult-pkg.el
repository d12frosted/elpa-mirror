(define-package "consult" "20210810.1324" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7f0a8c72abf606624e5ced6070f864ed4c81723b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
