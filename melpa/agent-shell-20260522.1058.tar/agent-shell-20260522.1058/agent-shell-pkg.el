;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260522.1058"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ed6a1af1d4f4d4307d3c03c1c96189989c25a614"
  :revdesc "ed6a1af1d4f4")
