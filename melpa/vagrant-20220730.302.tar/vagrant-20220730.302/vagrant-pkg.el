;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vagrant" "20220730.302"
  "Manage a vagrant box from emacs."
  ()
  :url "https://github.com/ottbot/vagrant.el"
  :commit "eb4ec2053955eda1ac9e5ff92ded88f1919e13f2"
  :revdesc "eb4ec2053955"
  :keywords '("vagrant" "chef")
  :authors '(("Robert Crim" . "rob@servermilk.com"))
  :maintainers '(("Robert Crim" . "rob@servermilk.com")))
