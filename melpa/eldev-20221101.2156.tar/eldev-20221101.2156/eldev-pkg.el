(define-package "eldev" "20221101.2156" "Elisp development tool"
  '((emacs "24.4"))
  :commit "e6a88f479678ed76f4ab293c7f2473717bd68c8b" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
