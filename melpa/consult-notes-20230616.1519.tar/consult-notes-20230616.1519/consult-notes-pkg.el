(define-package "consult-notes" "20230616.1519" "Manage notes with consult"
  '((emacs "27.1")
    (consult "0.17")
    (s "1.12.0")
    (dash "2.19"))
  :commit "3eb27b5d92025fed127732a65141177113763915" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainers
  '(("Colin McLear"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience")
  :url "https://github.com/mclear-tools/consult-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
