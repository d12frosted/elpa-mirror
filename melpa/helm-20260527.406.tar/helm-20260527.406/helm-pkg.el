;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20260527.406"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "76bd4c6a34da2f776445c57e4135fb0f5b291b2b"
  :revdesc "76bd4c6a34da"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
