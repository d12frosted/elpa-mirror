(define-package "workroom" "20221120.1211" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0"))
  :commit "df9815832073b713693284c1204f536caa25cc39" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
