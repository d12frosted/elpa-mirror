;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "20261025.1545"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "15b2476c09324fba78f0cd253560fee4207c5cf2"
  :revdesc "15b2476c0932"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
