;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "khoj" "20250706.1910"
  "Your Second Brain."
  '((emacs     "27.1")
    (transient "0.3.0")
    (dash      "2.19.1"))
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs"
  :commit "bc6bbb4c9653f2233a0012b7878214fa804e8a39"
  :revdesc "bc6bbb4c9653"
  :keywords '("search" "chat" "ai" "org-mode" "outlines" "markdown" "pdf" "image")
  :authors '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
             ("Saba Imran" . "saba@khoj.dev"))
  :maintainers '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
                 ("Saba Imran" . "saba@khoj.dev")))
