(define-package "embark" "20220509.2259" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "a81c84a422a20ab3015aea351ee8d158e10d2623" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
