;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20260122.919"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "8b58e16cbd7322f616e9ffcdf18c605f1d68a855"
  :revdesc "8b58e16cbd73"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
