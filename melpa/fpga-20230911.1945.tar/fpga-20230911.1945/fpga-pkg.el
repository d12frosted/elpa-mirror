(define-package "fpga" "20230911.1945" "FPGA & ASIC Utils"
  '((emacs "29.1")
    (ggtags "0.9.0")
    (company "0.9.13"))
  :commit "a5d25bfeeea913aeb0057eb98e2a2350739b8d0e" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/gmlarumbe/fpga")
;; Local Variables:
;; no-byte-compile: t
;; End:
