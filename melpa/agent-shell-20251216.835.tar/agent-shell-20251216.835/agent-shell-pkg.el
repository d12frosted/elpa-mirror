;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251216.835"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "bd9deb59f772451498d0eebf616a941729537cab"
  :revdesc "bd9deb59f772")
