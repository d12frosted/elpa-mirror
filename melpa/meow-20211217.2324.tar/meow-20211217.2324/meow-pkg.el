(define-package "meow" "20211217.2324" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "adea0c1a76f15a84bea89f5756b2ba620f27482e" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
