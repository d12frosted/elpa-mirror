(define-package "meow" "20211217.2324" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "4c6a130ab958006ed9b445a1e21f53a41948e32c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
