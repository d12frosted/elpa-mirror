;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ligature" "20260714.655"
  "Display typographical ligatures in major modes."
  '((emacs "28"))
  :url "https://www.github.com/mickeynp/ligature.el"
  :commit "5ef919d3e3e2cf2c4622cbea28e429b29e86fc97"
  :revdesc "5ef919d3e3e2"
  :keywords '("tools" "faces")
  :authors '(("Mickey Petersen" . "mickey@masteringemacs.org"))
  :maintainers '(("Mickey Petersen" . "mickey@masteringemacs.org")))
