;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261020.1055"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "3f13cc767a61a41418a6013611171a779be6d0ce"
  :revdesc "3f13cc767a61"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
