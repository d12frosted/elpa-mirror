;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260220.1406"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "186633e2707e5aba18c85a050668a980394a8a9a"
  :revdesc "186633e2707e")
