;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20261031.30"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "a9a563cb6f501331e2664cc08886f7a60b6fe4b5"
  :revdesc "a9a563cb6f50"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
