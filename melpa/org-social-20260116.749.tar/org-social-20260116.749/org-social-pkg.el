;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20260116.749"
  "An Org-social client for Emacs."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "83015d1402c28cd1395b18a104dfbc4f1357a83c"
  :revdesc "83015d1402c2"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
