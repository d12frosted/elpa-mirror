(define-package "consult" "20211229.2231" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7c037cfda400c5bead6e551988efe5f0eb246ad2" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
