(define-package "consult" "20211229.2231" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "de1414af5c13b6a77a3d09c497df3b05871903c8" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
