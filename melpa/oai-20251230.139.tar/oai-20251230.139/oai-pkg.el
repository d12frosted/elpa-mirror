;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20251230.139"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "fccb0cbc82bada2ee22f77833ad7b7ac32027d44"
  :revdesc "fccb0cbc82ba"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
