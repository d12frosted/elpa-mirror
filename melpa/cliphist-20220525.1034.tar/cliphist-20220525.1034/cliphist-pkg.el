;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cliphist" "20220525.1034"
  "Paste from clipboard managers."
  '((emacs "25.1"))
  :url "https://github.com/redguardtoo/cliphist"
  :commit "d02b97a2aa0da13711d9a6f845649115de8ac11b"
  :revdesc "d02b97a2aa0d"
  :keywords '("clipboard" "manager" "history")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
