;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "20261016.1821"
  "Reveal Markdown source at point."
  '((emacs               "31.1")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "74458d09e84a47e831860d745596456413aaa604"
  :revdesc "74458d09e84a"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
