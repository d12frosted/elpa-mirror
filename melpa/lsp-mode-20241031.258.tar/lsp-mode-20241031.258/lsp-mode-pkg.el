;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20241031.258"
  "LSP mode."
  '((emacs         "27.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "7e2701db204e22989911a22aa35c094568a9c680"
  :revdesc "7e2701db204e"
  :keywords '("languages"))
