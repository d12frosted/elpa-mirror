;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pager-default-keybindings" "20130719.2057"
  "Add the default keybindings suggested for pager.el."
  '((pager "1.0"))
  :url "https://github.com/nflath/pager-default-keybindings"
  :commit "dbbd49c2ac5906d1dabf9e9c832bfebc1ab405b3"
  :revdesc "dbbd49c2ac59"
  :authors '(("Nathaniel Flath" . "nflath@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "nflath@gmail.com")))
