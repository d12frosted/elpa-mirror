(define-package "gptel" "20240626.340" "Interact with ChatGPT or other LLMs"
  '((emacs "27.1")
    (transient "0.4.0")
    (compat "29.1.4.1"))
  :commit "95a5716aa250d6321b17691abb035aa8acefbfbb" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
