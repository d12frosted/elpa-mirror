;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vulpea" "20260105.2319"
  "Use Consult in tandem with Vulpea."
  '((emacs   "28.1")
    (vulpea  "2.0.0")
    (consult "2.2"))
  :url "https://github.com/fabcontigiani/consult-vulpea"
  :commit "1596d44b17d39882e96d20e9a387eab3df6143a2"
  :revdesc "1596d44b17d3"
  :keywords '("convenience" "notes" "vulpea")
  :authors '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com"))
  :maintainers '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com")))
