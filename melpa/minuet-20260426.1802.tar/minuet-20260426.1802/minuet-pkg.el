;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260426.1802"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "d2f30624298f11edbae55c36f067bb44abae4785"
  :revdesc "d2f30624298f"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
