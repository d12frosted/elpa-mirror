(define-package "dirvish" "20220126.709" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "8f1c9bfa2fb57878da6bcac94cc10c8e2c0adf76" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
