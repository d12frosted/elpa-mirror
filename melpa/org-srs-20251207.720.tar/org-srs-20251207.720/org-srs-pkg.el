;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251207.720"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "9b0752a7147362542285ea1870a753b3ebc57451"
  :revdesc "9b0752a71473"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
