;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260524.1434"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "246b5a74640c9b0ff0202d4c9eb332e6daf8d82c"
  :revdesc "246b5a74640c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
