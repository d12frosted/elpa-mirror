;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-eldoc" "20140202.1941"
  "Eldoc backend for php."
  ()
  :url "https://github.com/sabof/php-eldoc"
  :commit "df05064146b884d9081e10657e32dc480f070cfe"
  :revdesc "df05064146b8")
