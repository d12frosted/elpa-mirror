;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "editorconfig" "20250219.1127"
  "EditorConfig Emacs Plugin."
  '((emacs "27.2"))
  :url "https://github.com/editorconfig/editorconfig-emacs#readme"
  :commit "72b8847275cb11c606747d962cdbebf4817052f8"
  :revdesc "72b8847275cb"
  :keywords '("convenience" "editorconfig")
  :authors '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainers '(("EditorConfig Team" . "editorconfig@googlegroups.com")))
