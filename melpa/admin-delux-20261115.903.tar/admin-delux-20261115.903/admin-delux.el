;;; admin-delux.el --- Run Clojure workflows interactively -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Mathias Iversen

;; Author: Mathias Iversen <mathias.iversen487@gmail.com>
;; Maintainer: Mathias Iversen <mathias.iversen487@gmail.com>
;; URL: https://codeberg.org/boosja/admin-delux.el
;; Package-Version: 20261115.903
;; Package-Revision: abb2f71ca59d
;; Package-Requires: ((emacs "27.1") (cider "1.0") (parseedn "1.2"))
;; Keywords: tools, convenience, clojure, cider

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; Admin Delux lets you run workflows in Clojure interactively from the comfort of
;; your Emacs.

;; Request user-input for any admin function and execute it.

;; `admin-delux-run` starts a loop collecting input from the user, accumulating a
;; history. On every iteration it calls your step-fn for the next interaction,
;; finally calling an `exec-fn` with the collected inputs.

;; Run interactive, guided, admin routines with a single pure and data-driven
;; function 😌

;; Usage:
;; Add `((clojure-mode . ((admin-delux-step-fn . "your.fully.qualified/step-fn"))))`
;; to your project's .dir-locals.el-file.

;; Implement `your.fully.qualified/step-fn` somewhere in your project.

;; The step-fn should return any of the following maps:
;;   {:type :select  :prompt "Action: "   :options ["add" "rename"] :require-match true}
;;   {:type :input   :prompt "New name: " :initial "foo"}
;;   {:type :message :message "Creating..."}
;;   {:type :error   :message "Name already taken"}
;;   {:type :submit  :exec-fn "some.namespace/function"}

;;; Code:

(require 'cider)
(require 'parseedn)
(require 'subr-x)

(defvar admin-delux-step-fn nil
  "Fully qualified Clojure fn that takes a single argument.
Set per project in .dir-locals.el.")

(defun admin-delux--string->keyword (s)
  "Parse possible stringified keyword S back to keyword."
  (if (and (stringp s) (string-match-p "\\`:[^[:space:]]+\\'" s))
      (intern s)
    s))

(defun admin-delux--unicode-symbol-char-p (orig char &optional alpha-only)
  "Around advice for `parseclj-lex-symbol-start-p' allowing Unicode letters.
Call ORIG with CHAR and ALPHA-ONLY.  If nil, also accept unicode characters
like æøå, so EDN returned from Clojure is parsed correctly.

The advice is only installed temporarily by `admin-delux--read-edn'."
  (or (funcall orig char alpha-only)
      (and char
           (> char 127)
           (memq (get-char-code-property char 'general-category)
                 '(Lu Ll Lt Lm Lo Mn Mc)))))

(defun admin-delux--read-edn (str)
  "Read STR as edn and parse it."
  (advice-add 'parseclj-lex-symbol-start-p :around
              #'admin-delux--unicode-symbol-char-p)
  (unwind-protect (parseedn-read-str str)
    (advice-remove 'parseclj-lex-symbol-start-p
                   #'admin-delux--unicode-symbol-char-p)))

(defun admin-delux--call (fn history)
  "Call FN in Clojure with HISTORY as argument."
  (let* ((form  (format "(do (require '[clojure.edn])
                             (binding [*print-namespace-maps* false
                                       *print-level* nil
                                       *print-length* nil]
                               (pr-str (%s (clojure.edn/read-string %s)))))"
                        fn
                        (parseedn-print-str
                         (parseedn-print-str (list :history (vconcat history))))))
         (resp  (cider-nrepl-sync-request:eval form (cider-current-repl 'clj 'ensure)))
         (value (nrepl-dict-get resp "value")))
    (when (or (nrepl-dict-get resp "ex") (null value))
      (user-error "Admin Delux: %s"
                  (string-trim (or (nrepl-dict-get resp "err") "no value returned"))))
    (admin-delux--read-edn
     (parseedn-read-str value))))

(defun admin-delux--select (resp)
  "Prompt for a selection of one of options defined by RESP."
  (let ((the-options (mapcar (lambda (c) (cider-font-lock-as-clojure (format "%s" c)))
                             (gethash :options resp))))
    (admin-delux--string->keyword
     (substring-no-properties
      (completing-read (gethash :prompt resp "Choose: ")
                       (lambda (string pred action)
                         (if (eq action 'metadata)
                             '(metadata (category . admin-delux-items))
                           (complete-with-action action the-options string pred)))
                       nil
                       (gethash :require-match resp))))))

(defun admin-delux--input (resp)
  "Prompt for text input defined by RESP."
  (admin-delux--string->keyword
   (read-string (gethash :prompt resp "Input: ")
                (gethash :initial resp))))

;;;###autoload
(defun admin-delux-run (&optional step-fn)
  "Run the interactive loop against STEP-FN (default `admin-delux-step-fn')."
  (interactive)
  (let ((fn (or step-fn
                admin-delux-step-fn
                (user-error "Admin Delux: no step-fn configured")))
        (history '()) ; newest first
        (done nil))
    (while (not done)
      (let ((resp (admin-delux--call fn (reverse history))))
        (if (hash-table-p resp)
            (pcase (gethash :type resp)
              (:select  (push (admin-delux--select resp) history))
              (:input   (push (admin-delux--input resp) history))
              (:message (message "%s" (gethash :message resp))
                        (push :message-posted history))
              (:error   (message "%s" (gethash :message resp))
                        (sit-for 1.5)
                        (pop history))  ; let the user re-answer
              (:submit  (setq done t)
                        (if-let* ((exec (gethash :exec-fn resp)))
                            (message "%s" (cider-font-lock-as-clojure
                                           (parseedn-print-str
                                            (admin-delux--call exec (reverse history)))))
                          (message "Finished with no exec-fn")))
              (_ (user-error "Admin Delux: unexpected response %S" resp)))
          (user-error "Admin Delux: returned value is not a Clojure map: %S" resp))))))

(provide 'admin-delux)
;;; admin-delux.el ends here
