;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "admin-delux" "20261115.903"
  "Run Clojure workflows interactively."
  '((emacs    "27.1")
    (cider    "1.0")
    (parseedn "1.2"))
  :url "https://codeberg.org/boosja/admin-delux.el"
  :commit "abb2f71ca59d2b5d5718c0d1329f6502e1506355"
  :revdesc "abb2f71ca59d"
  :keywords '("tools" "convenience" "clojure" "cider")
  :authors '(("Mathias Iversen" . "mathias.iversen487@gmail.com"))
  :maintainers '(("Mathias Iversen" . "mathias.iversen487@gmail.com")))
