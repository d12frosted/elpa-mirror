(define-package "magit-section" "20210124.1824" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "75ae42a5bb8a764c648be2af58c5843469dd8cf1" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
