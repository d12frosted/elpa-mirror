(define-package "magit-section" "20210124.1824" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "68f3753823aa1423b50d6a90e9fa2066361e8306" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
