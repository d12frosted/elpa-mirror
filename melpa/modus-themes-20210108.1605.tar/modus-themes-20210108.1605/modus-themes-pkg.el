(define-package "modus-themes" "20210108.1605" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "2a7228e09402f2f69aabf4fd8f367e5f6e8248b3" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
