(define-package "journalctl-mode" "20231110.1253" "Sample major mode for  viewing output journalctl"
  '((emacs "27.1"))
  :commit "cb3185081cc8eba06de30936efa227639fb8a60c" :authors
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainers
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainer
  '("Sebastian Meisel" . "sebastian.meisel@gmail.com")
  :keywords
  '("unix")
  :url "https://github.com/SebastianMeisel/journalctl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
