;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20250629.1346"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "63690547ce37f627b163c3138bcf28c8f07ef3bc"
  :revdesc "63690547ce37"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
