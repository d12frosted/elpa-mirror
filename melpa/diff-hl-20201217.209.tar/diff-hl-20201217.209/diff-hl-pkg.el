(define-package "diff-hl" "20201217.209" "Highlight uncommitted changes using VC"
  '((cl-lib "0.2")
    (emacs "24.3"))
  :commit "328e23e73edf69cf8cff420ad4ccb15b827e2b7a" :keywords
  ("vc" "diff")
  :authors
  (("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  ("Dmitry Gutov" . "dgutov@yandex.ru")
  :url "https://github.com/dgutov/diff-hl")
;; Local Variables:
;; no-byte-compile: t
;; End:
