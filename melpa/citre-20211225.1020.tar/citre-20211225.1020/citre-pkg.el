(define-package "citre" "20211225.1020" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "641f2f7f69de2c0f4f055efe55b3ecd899a60b24" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
