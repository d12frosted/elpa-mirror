(define-package "modus-themes" "20210513.2030" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "e34cd5bbe44e3ec0d428a9e6b7370c12d5bf9101" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
