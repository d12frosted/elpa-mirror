;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20250719.9"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "f2cb86aa0f5d33e5bd271dbc80359270cf4cf9c7"
  :revdesc "f2cb86aa0f5d"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
