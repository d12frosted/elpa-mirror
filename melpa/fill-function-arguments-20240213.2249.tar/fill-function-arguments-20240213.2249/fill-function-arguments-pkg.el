;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fill-function-arguments" "20240213.2249"
  "Convert function arguments to/from single line."
  '((emacs "24.4"))
  :url "https://github.com/davidshepherd7/fill-function-arguments"
  :commit "9def8ced5241b10067ae85c89ae34359c2e4847a"
  :revdesc "9def8ced5241"
  :keywords '("convenience")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
