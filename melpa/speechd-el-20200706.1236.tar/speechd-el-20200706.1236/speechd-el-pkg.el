(define-package "speechd-el" "20200706.1236" "Client to speech synthesizers and Braille displays." 'nil :commit "058f91b4d1b0350221218656202ea80cd6827d65")
;; Local Variables:
;; no-byte-compile: t
;; End:
