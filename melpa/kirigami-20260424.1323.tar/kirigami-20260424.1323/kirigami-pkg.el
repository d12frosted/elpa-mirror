;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260424.1323"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "43ba0e4ec993de7440ce0b2b592bd5988cbfd135"
  :revdesc "43ba0e4ec993"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
