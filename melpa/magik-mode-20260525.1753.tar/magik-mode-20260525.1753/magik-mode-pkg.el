;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260525.1753"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "a6c2731d80a32d5fa0b816c53f4b0edf90abf60b"
  :revdesc "a6c2731d80a3"
  :keywords '("languages"))
