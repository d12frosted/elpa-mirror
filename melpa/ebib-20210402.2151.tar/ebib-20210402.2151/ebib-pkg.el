(define-package "ebib" "20210402.2151" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "0ed4d91bb79fa8ea62178d92d1cb2faa00146a66" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
