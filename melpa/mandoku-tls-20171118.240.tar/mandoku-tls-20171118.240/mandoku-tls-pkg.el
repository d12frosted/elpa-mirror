;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mandoku-tls" "20171118.240"
  "A tool to access the TLS database."
  '((emacs         "24.4")
    (mandoku       "20170301")
    (github-clone  "0.2")
    (hydra         "0.13.6")
    (helm          "1.7.0")
    (org           "9.0")
    (helm-charinfo "20170601"))
  :url "https://github.com/mandoku/mandoku-tls"
  :commit "ffeebf5bd451ac1806ddfe1744fbbd036a56f902"
  :revdesc "ffeebf5bd451"
  :keywords '("convenience")
  :authors '(("Christian Wittern" . "cwittern@gmail.com"))
  :maintainers '(("Christian Wittern" . "cwittern@gmail.com")))
