;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20251014.1818"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "060748fe52a0696c7ea8f43f2cf7cdfdfd428efc"
  :revdesc "060748fe52a0"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
