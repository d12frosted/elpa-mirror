(define-package "modus-themes" "20210312.845" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "b54894725f0b4ebc6a1521ff9157140aab27290b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
