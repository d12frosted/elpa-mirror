;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codebug" "20140929.2137"
  "Interact with codebug."
  ()
  :url "http://www.shanedowling.com/"
  :commit "d95e5182fa1465406964873d9db1fdac77206f5b"
  :revdesc "d95e5182fa14")
