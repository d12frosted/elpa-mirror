(define-package "modus-themes" "20220414.922" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "15fe9503c3ac5bd41b840c6799bfc9e37db0ae74" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
