;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251116.1625"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "64eee9b9b7b0caa9d8407ebc96391f33437f5314"
  :revdesc "64eee9b9b7b0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
