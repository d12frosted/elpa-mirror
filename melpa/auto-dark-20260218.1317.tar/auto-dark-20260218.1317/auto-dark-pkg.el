;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-dark" "20260218.1317"
  "Automatically set the dark-mode theme based on system status."
  '((emacs "24.4"))
  :url "https://github.com/LionyxML/auto-dark-emacs"
  :commit "280d9a6e6ab0ccb833185761734585344ce22095"
  :revdesc "280d9a6e6ab0"
  :keywords '("macos" "windows" "linux" "themes" "tools" "faces")
  :authors '(("Tim Harper" . "timcharperatgmaildotcom")
             ("Vincent Zhang" . "seagle0128@gmail.com")
             ("Jonathan Arnett" . "jonathan.arnett@protonmail.com")
             ("Greg Pfeil" . "greg@technomadic.org"))
  :maintainers '(("Tim Harper" . "timcharperatgmaildotcom")
                 ("Vincent Zhang" . "seagle0128@gmail.com")
                 ("Jonathan Arnett" . "jonathan.arnett@protonmail.com")
                 ("Greg Pfeil" . "greg@technomadic.org")))
