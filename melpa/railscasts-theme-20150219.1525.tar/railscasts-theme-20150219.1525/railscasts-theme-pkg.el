;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "railscasts-theme" "20150219.1525"
  "Railscasts color theme for GNU Emacs."
  ()
  :url "https://github.com/mikenichols/railscasts-theme"
  :commit "1340c3f6c2717761cab95617cf8dcbd962b1095b"
  :revdesc "1340c3f6c271"
  :keywords '("railscasts" "color" "theme"))
