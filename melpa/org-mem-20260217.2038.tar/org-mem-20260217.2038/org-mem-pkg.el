;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260217.2038"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "9c7f3e1a624143c75603f2ea4e3b8129d3deb721"
  :revdesc "9c7f3e1a6241"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
