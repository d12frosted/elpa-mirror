;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbdb2erc" "20190822.907"
  "Make bbdb show if pal is online with ERC, click i to chat."
  '((bbdb "3.0"))
  :url "https://github.com/unhammer/bbdb2erc"
  :commit "40b89e961762af3e7ade3a1844a9fbcd4084ac65"
  :revdesc "40b89e961762"
  :keywords '("irc" "contacts" "chat" "client" "internet")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
