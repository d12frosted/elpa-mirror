;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20260124.1833"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "b301e0806aceb05251b4e8b5310fd886bec9dcfe"
  :revdesc "b301e0806ace"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
