(define-package "clojure-ts-mode" "20230909.1406" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "58f3c835aeafe0378ab9693731b95096827dbb24" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
