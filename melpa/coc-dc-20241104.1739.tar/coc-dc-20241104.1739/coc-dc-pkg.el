;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coc-dc" "20241104.1739"
  "A Clash of Clans damage calculator."
  '((emacs "27.2")
    (hydra "0.14.0"))
  :url "https://github.com/S0mbr3/coc-damage-calculator"
  :commit "097bc2496263fc1e69a04d0528b41baf2fd08115"
  :revdesc "097bc2496263"
  :keywords '("games")
  :authors '(("S0mbr3" . "0xf2f@proton.me"))
  :maintainers '(("S0mbr3" . "0xf2f@proton.me")))
