(define-package "igist" "20230809.1737" "List, create, update and delete GitHub gists"
  '((emacs "27.1")
    (ghub "3.6.0")
    (transient "0.4.1"))
  :commit "5ad45f50e45848d3dc29f74877badc16e44e7276" :authors
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainer
  '("Karim Aziiev" . "karim.aziiev@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/KarimAziev/igist")
;; Local Variables:
;; no-byte-compile: t
;; End:
