;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "standoff-mode" "20210810.1814"
  "Create stand-off markup, also called external markup."
  ()
  :url "https://github.com/lueck/standoff-mode"
  :commit "5e603092410d9c393d19050bcbed3014a379f0e6"
  :revdesc "5e603092410d"
  :keywords '("text" "annotations" "ner" "humanities")
  :authors '(("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de"))
  :maintainers '(("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de")))
