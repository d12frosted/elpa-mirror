(define-package "gumshoe" "20230115.2105" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "0ada8c575d4e94b4f3edb0092239cfa835b17726" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
