(define-package "pipewire" "20220725.1858" "PipeWire user interface"
  '((emacs "28.1"))
  :commit "ae7a95230f102e7430a80acb02850bc24430c3b2" :authors
  '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainer
  '("Milan Zamazal" . "pdm@zamazal.org")
  :keywords
  '("multimedia")
  :url "https://git.zamazal.org/pdm/pipewire-0")
;; Local Variables:
;; no-byte-compile: t
;; End:
