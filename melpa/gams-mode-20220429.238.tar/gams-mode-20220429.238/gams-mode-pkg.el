(define-package "gams-mode" "20220429.238" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "7505c59eecd3d42c2ce38aa08da196165eeb89d0" :authors
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
