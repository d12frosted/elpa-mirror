(define-package "sway" "20221211.1439" "Communication with the Sway window manager"
  '((emacs "27.1")
    (dash "2.18.1"))
  :commit "117eb40691e7a4d2dcd6b5a7fd9f803c7d42c32c" :authors
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainers
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainer
  '("Thibault Polge" . "thibault@thb.lt")
  :keywords
  '("frames")
  :url "https://github.com/thblt/sway.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
