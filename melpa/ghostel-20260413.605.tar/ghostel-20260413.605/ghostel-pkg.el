;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260413.605"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "33f7601c1d6cdb40d61888bf09b79eaf4972c2ac"
  :revdesc "33f7601c1d6c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
