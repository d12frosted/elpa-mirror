(define-package "diredc" "20240418.337" "Midnight Commander features (plus) for dired"
  '((emacs "26.1")
    (key-assist "1.0"))
  :commit "559feb8510ebaab24a7dd65c5106bb14807417b1" :keywords
  '("files")
  :url "https://github.com/Boruch-Baum/emacs-diredc")
;; Local Variables:
;; no-byte-compile: t
;; End:
