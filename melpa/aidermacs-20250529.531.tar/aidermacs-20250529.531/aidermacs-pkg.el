;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250529.531"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "1f4fe4e8ac05c12c310e6c32893b4ab519efbd47"
  :revdesc "1f4fe4e8ac05"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
