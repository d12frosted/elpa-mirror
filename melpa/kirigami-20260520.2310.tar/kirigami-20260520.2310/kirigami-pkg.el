;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260520.2310"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "b7069a4b0126321c263552d5f6133a503bf4a68f"
  :revdesc "b7069a4b0126"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
