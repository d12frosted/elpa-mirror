(define-package "wildcharm-theme" "20230805.1207" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "eb518d68956494396bfad5effb6b0b5ff24a4a70" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
