;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20250331.1421"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "55d4d1b0ad957657f215ffc349b55881bf73d7e9"
  :revdesc "55d4d1b0ad95"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")))
