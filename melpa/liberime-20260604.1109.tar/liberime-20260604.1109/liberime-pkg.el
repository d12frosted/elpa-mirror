;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260604.1109"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "fc26e41eeaf467f81798d7ff82fad7af5713edc2"
  :revdesc "fc26e41eeaf4"
  :keywords '("convenience" "chinese" "input-method" "rime"))
