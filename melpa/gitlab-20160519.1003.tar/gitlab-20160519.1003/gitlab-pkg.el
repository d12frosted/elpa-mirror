(define-package "gitlab" "20160519.1003" "Emacs client for Gitlab"
  '((s "1.9.0")
    (dash "2.9.0")
    (pkg-info "0.5.0")
    (request "0.1.0"))
  :commit "a1c1441ff5ffb290e695eb9ac05431e9385578f4" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("gitlab")
  :url "https://github.com/nlamirault/emacs-gitlab")
;; Local Variables:
;; no-byte-compile: t
;; End:
