(define-package "modus-themes" "20210904.1533" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "64c74ae0d4505426c6668468a688f9ea63c5088b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
