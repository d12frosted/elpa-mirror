;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250405.538"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "edb78e5f468c329aadab8f3cf82303cf1d6bb1e4"
  :revdesc "edb78e5f468c"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
