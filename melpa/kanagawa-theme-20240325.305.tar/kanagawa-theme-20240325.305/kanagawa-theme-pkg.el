(define-package "kanagawa-theme" "20240325.305" "An elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa"
  '((emacs "24.3"))
  :commit "fcc2960a911c74e041bc04a4c4b7fecf97f3d176" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/meritamen/emacs-kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
