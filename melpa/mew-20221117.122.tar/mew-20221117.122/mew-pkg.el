(define-package "mew" "20221117.122" "Messaging in the Emacs World" 'nil :commit "6b69ec4d075023cb0d6c7f60b16403e36c2c68ee" :authors
  '(("Kazu Yamamoto" . "Kazu@Mew.org"))
  :maintainer
  '("Kazu Yamamoto" . "Kazu@Mew.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
