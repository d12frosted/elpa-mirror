;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-aws-iam-role" "20260207.1643"
  "Browse, modify, and simulate AWS IAM Roles in Org Babel."
  '((emacs   "29.1")
    (async   "1.9")
    (promise "1.1"))
  :url "https://github.com/will-abb/org-aws-iam-role"
  :commit "4c6cdde1efd1f33a4e2434db7af7617ce590e90c"
  :revdesc "4c6cdde1efd1"
  :keywords '("aws" "iam" "org" "babel" "tools")
  :authors '(("William Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("William Bosch-Bello" . "williamsbosch@gmail.com")))
