;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20251117.347"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "358b82c26ed8a53729ac05789cb0b3465262a081"
  :revdesc "358b82c26ed8"
  :keywords '("languages"))
