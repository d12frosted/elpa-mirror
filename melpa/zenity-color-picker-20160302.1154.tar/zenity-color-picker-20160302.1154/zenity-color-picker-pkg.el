;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenity-color-picker" "20160302.1154"
  "Insert and adjust colors using Zenity."
  '((emacs "24.4"))
  :url "https://bitbucket.org/Soft/zenity-color-picker.el"
  :commit "bdece51052ef7037e0a3481fc1f487939f57777e"
  :revdesc "bdece51052ef"
  :keywords '("colors")
  :authors '(("Samuel Laurén" . "samuel.lauren@iki.fi"))
  :maintainers '(("Samuel Laurén" . "samuel.lauren@iki.fi")))
