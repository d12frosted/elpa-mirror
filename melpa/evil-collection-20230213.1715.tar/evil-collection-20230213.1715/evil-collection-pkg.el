(define-package "evil-collection" "20230213.1715" "A set of keybindings for Evil mode"
  '((emacs "26.3")
    (evil "1.2.13")
    (annalist "1.0"))
  :commit "692fb0fc8678c555e26961dea1db5df37e151cf6" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("evil" "tools")
  :url "https://github.com/emacs-evil/evil-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
