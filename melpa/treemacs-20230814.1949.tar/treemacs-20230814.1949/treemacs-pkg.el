(define-package "treemacs" "20230814.1949" "A tree style file explorer package"
  '((emacs "26.1")
    (cl-lib "0.5")
    (dash "2.11.0")
    (s "1.12.0")
    (ace-window "0.9.0")
    (pfuture "1.7")
    (hydra "0.13.2")
    (ht "2.2")
    (cfrs "1.3.2"))
  :commit "8a1d66f5d658e9d0c0e752b97849271ee6734198" :authors
  '(("Alexander Miller" . "alexanderm@web.de"))
  :maintainers
  '(("Alexander Miller" . "alexanderm@web.de"))
  :maintainer
  '("Alexander Miller" . "alexanderm@web.de")
  :url "https://github.com/Alexander-Miller/treemacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
