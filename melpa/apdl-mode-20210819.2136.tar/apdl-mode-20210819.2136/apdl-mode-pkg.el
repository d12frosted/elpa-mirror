(define-package "apdl-mode" "20210819.2136" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "9e80feb61a173d776495f8a36545b966acac21f2" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
