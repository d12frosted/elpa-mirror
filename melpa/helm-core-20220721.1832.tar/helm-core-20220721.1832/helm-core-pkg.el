(define-package "helm-core" "20220721.1832" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "da114dfc9c21f0ed6f42981ec06aa7dd8855836c" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
