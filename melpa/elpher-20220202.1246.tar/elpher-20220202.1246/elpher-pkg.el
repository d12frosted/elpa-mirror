(define-package "elpher" "20220202.1246" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "09f4d52c0f3ff9cdd4fbddbdc513c42f6650918a" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
