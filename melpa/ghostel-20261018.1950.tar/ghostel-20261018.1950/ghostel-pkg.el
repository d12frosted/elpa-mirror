;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261018.1950"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "3074dbe72c934524f43e25d2ae695b4a7d820551"
  :revdesc "3074dbe72c93"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
