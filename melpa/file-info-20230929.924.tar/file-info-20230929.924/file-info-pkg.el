(define-package "file-info" "20230929.924" "Show pretty information about current file"
  '((emacs "28.1")
    (hydra "0.15.0")
    (browse-at-remote "0.15.0"))
  :commit "21fb5d779be88364e464e54c8bb94d04518f6474" :authors
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainer
  '("Artur Yaroshenko" . "artawower@protonmail.com")
  :url "https://github.com/artawower/file-info.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
