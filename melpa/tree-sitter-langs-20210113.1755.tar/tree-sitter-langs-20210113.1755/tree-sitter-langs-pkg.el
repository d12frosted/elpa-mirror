(define-package "tree-sitter-langs" "20210113.1755" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.12.2"))
  :commit "e7f2f625c1b9a2dce4f6b16a5affbb4f57337ae0" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
