(define-package "modus-themes" "20220527.1425" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "9958ecd45abadc66b7da286ebd62b4fb9a339339" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
