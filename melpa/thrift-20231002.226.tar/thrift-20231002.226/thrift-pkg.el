(define-package "thrift" "20231002.226" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "411a16fea43ddbc5c55cf3dd5cfd438c0a78b49a" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
