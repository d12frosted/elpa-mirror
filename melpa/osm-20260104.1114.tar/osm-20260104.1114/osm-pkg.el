;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260104.1114"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "8873ab82ec9a665fa39657f0d014dd73bf65e12d"
  :revdesc "8873ab82ec9a"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
