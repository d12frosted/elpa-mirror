;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260527.2010"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "73849d685694ae84646c287fbdf51f71c7ca672e"
  :revdesc "73849d685694"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
