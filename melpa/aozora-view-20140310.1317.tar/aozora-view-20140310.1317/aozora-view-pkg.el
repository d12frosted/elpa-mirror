;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aozora-view" "20140310.1317"
  "Aozora Bunko text Emacs viewer."
  ()
  :url "https://github.com/kawabata/aozora-view"
  :commit "b0390616d19e45f15f9a2f5d5688274831e721fd"
  :revdesc "b0390616d19e"
  :keywords '("text")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
