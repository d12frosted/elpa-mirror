;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241108.1250"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "162f60bc686e9d106de93fa2057ce424393a66e8"
  :revdesc "162f60bc686e"
  :keywords '("convenience" "modal-editing"))
