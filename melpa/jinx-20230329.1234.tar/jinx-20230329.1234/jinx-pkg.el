(define-package "jinx" "20230329.1234" "Enchanted Just-in-time Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "181b712725b8dfb5d131ded0e420011dee27c789" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
