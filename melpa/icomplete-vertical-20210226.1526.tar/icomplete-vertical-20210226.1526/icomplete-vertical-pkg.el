(define-package "icomplete-vertical" "20210226.1526" "Display icomplete candidates vertically"
  '((emacs "26.1"))
  :commit "7346bdcd22ff44a7c875ad409b3cb5830f6ab2b8" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
