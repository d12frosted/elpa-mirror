;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260806.448"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "29b779c9b0fabae92a75cee72c54701a75f43e12"
  :revdesc "29b779c9b0fa")
