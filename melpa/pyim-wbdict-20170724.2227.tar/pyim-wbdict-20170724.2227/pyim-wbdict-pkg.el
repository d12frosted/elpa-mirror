(define-package "pyim-wbdict" "20170724.2227" "Some wubi dicts for pyim"
  '((pyim "1.0"))
  :commit "114489ed97e825ae11a8d09da6e873820cf23106" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/tumashu/pyim-wbdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
