;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20260714.1156"
  "Minor mode for making Anki cards with Org."
  '((emacs "29.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "4a55c3f937b176d31e36d484c196682cae9f9104"
  :revdesc "4a55c3f937b1")
