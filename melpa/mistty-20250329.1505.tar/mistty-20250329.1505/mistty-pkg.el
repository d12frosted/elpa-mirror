;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250329.1505"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "dde2a4873edde660a5116ae488390c440744c647"
  :revdesc "dde2a4873edd"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
