;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260824.1421"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "b85c8894eaf8416c8d98a99ada6fa76fffa004cd"
  :revdesc "b85c8894eaf8"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
