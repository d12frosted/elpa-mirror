(define-package "lab" "20230630.2005" "An interface for GitLab"
  '((emacs "27.1")
    (memoize "1.1")
    (request "0.3.2")
    (s "1.10.0"))
  :commit "771a98c48c657f7a883b664617f2bc0370575f99" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/lab.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
