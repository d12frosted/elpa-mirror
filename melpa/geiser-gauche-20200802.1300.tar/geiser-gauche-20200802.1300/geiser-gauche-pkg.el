(define-package "geiser-gauche" "20200802.1300" "Gauche scheme support for Geiser"
  '((emacs "26.1")
    (geiser "0.11.2"))
  :commit "66e51430bded0f0e2037f474818a7bbaafb2906c" :keywords
  ("languages" "gauche" "scheme" "geiser")
  :authors
  (("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainer
  ("András Simonyi" . "andras.simonyi@gmail.com")
  :url "https://gitlab.com/emacs-geiser/gauche")
;; Local Variables:
;; no-byte-compile: t
;; End:
