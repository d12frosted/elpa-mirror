(define-package "jinx" "20230419.1401" "Enchanted Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "f359e84776cb65fa9386b07070929bc8b975f80b" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "wp")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
