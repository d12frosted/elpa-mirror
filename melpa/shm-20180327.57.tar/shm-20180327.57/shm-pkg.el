(define-package "shm" "20180327.57" "Structured Haskell Mode" 'nil :commit "7f9df73f45d107017c18ce4835bbc190dfe6782e" :keywords
  ("development" "haskell" "structured")
  :authors
  (("Chris Done" . "chrisdone@gmail.com"))
  :maintainer
  ("Chris Done" . "chrisdone@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
