;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shm" "20180327.57"
  "Structured Haskell Mode."
  ()
  :url "https://github.com/projectional-haskell/structured-haskell-mode"
  :commit "7f9df73f45d107017c18ce4835bbc190dfe6782e"
  :revdesc "7f9df73f45d1"
  :keywords '("development" "haskell" "structured")
  :authors '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainers '(("Chris Done" . "chrisdone@gmail.com")))
