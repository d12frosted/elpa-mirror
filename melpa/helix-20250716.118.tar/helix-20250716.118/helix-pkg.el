;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "20250716.118"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "92322db84800024230aa9ce84bb8395218e7e5ec"
  :revdesc "92322db84800"
  :keywords '("convenience"))
