;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "govc" "20250702.120"
  "Interface to govc for managing VMware ESXi and vCenter."
  '((emacs       "24.3")
    (dash        "1.5.0")
    (s           "1.9.0")
    (magit-popup "2.0.50")
    (json-mode   "1.6.0"))
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs"
  :commit "bedcaadc5399abbaaaebac504718a1b043cd354d"
  :revdesc "bedcaadc5399"
  :keywords '("convenience"))
