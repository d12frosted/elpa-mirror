;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "msgpack" "20260706.1525"
  "Read and write MessagePack object."
  '((emacs "25.1"))
  :url "https://github.com/xuchunyang/msgpack.el"
  :commit "4c7d2cd93697f2097124939609ee038e7bdf9e3a"
  :revdesc "4c7d2cd93697"
  :keywords '("lisp"))
