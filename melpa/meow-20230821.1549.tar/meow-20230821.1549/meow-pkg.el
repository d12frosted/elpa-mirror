(define-package "meow" "20230821.1549" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "850fa13dffb8075f9e8eb3bdca576422a448088a" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
