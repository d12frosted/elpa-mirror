;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-catkin" "20190425.1520"
  "Package for compile ROS workspaces with catkin-tools."
  '((emacs       "24.3")
    (helm        "0")
    (xterm-color "0"))
  :url "https://github.com/gollth/helm-catkin"
  :commit "a3422346eb46e66a947a75f9e1b9975a672036be"
  :revdesc "a3422346eb46"
  :keywords '("catkin" "helm" "build" "tools" "ros")
  :authors '(("Thore Goll" . "thoregoll@googlemail.com"))
  :maintainers '(("Thore Goll" . "thoregoll@googlemail.com")))
