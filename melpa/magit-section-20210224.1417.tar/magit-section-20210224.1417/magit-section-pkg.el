(define-package "magit-section" "20210224.1417" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "1c60edc86512c53b15e753d6dca319a5e01f83a3" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
