(define-package "magit-section" "20210224.1417" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "577f16da3072a0ae85fba6b25a36a971a61ec6c2" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
