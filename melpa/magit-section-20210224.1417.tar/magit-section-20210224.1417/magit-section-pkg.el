(define-package "magit-section" "20210224.1417" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "8ebb05cb7c8f102581ec2d8b52f9e83841676a01" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
