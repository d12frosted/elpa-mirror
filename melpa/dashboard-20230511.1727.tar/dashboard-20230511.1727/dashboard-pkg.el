(define-package "dashboard" "20230511.1727" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "fd7819cc90e5381c3e7788325ef8f1fec3100201" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers
  '(("Jesús Martínez" . "jesusmartinez93@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
