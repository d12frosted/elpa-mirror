(define-package "ready-player" "20240904.1517" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "2bfeb22b0ae930cd47e44a191b73ea305ef4e5eb" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
