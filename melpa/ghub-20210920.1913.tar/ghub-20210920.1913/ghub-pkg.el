(define-package "ghub" "20210920.1913" "Minuscule client libraries for Git forge APIs."
  '((emacs "25.1")
    (let-alist "1.0.5")
    (treepy "0.1.1"))
  :commit "05810cd220c7c18ec7a8088426452e33979e9d04" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
