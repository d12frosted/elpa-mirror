(define-package "buttercup" "20210105.2255" "Behavior-Driven Emacs Lisp Testing" 'nil :commit "1cb7afcb0b6d87a3e623dc26ffcb2c7d4d6dd280" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Jorgen Schaefer" . "contact@jorgenschaefer.de")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
