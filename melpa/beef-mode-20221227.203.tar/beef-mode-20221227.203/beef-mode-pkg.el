;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beef-mode" "20221227.203"
  "A major mode for the Beef programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/beef-mode"
  :commit "20906b41630d74eba56504fbb9fabb79562e0d6e"
  :revdesc "20906b41630d"
  :keywords '("files" "beef"))
