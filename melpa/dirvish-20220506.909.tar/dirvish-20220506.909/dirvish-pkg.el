(define-package "dirvish" "20220506.909" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "25d02fa39e0ca84bee12b275d4f1f8116ce1ddcc" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
