;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verdict" "20260506.914"
  "Generic test runner with treemacs results UI."
  '((emacs    "29.1")
    (treemacs "3.0")
    (dash     "2.0"))
  :url "https://github.com/tjarvstrand/verdict.el"
  :commit "ff29a0681f7cca17c0e7b467229b2a8441559a2e"
  :revdesc "ff29a0681f7c"
  :keywords '("tools" "processes")
  :authors '(("Thomas Järvstrand" . "https://github.com/tjarvstrand"))
  :maintainers '(("Thomas Järvstrand" . "https://github.com/tjarvstrand")))
