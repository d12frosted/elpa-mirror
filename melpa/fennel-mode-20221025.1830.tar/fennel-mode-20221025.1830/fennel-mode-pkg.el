(define-package "fennel-mode" "20221025.1830" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "da958db7a6fdeeaf202cd8fdca630e85dbf6a455" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
