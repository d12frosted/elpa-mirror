;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erblint" "20200622.5"
  "An interface for checking HTML ERB files using Erblint."
  '((emacs "24"))
  :url "https://github.com/leodcs/erblint-emacs"
  :commit "43706afb09ec8de91651a832b703c81ced10ec4e"
  :revdesc "43706afb09ec"
  :keywords '("project" "convenience"))
