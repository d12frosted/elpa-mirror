(define-package "embark" "20220218.642" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "ed8cd7dc81026a9e123c52d8c78fdb5f9329ee33" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
