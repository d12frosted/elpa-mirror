;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250303.820"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "3878712215f5bacb56ebe5bb5faa6ac43777cd10"
  :revdesc "3878712215f5"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
