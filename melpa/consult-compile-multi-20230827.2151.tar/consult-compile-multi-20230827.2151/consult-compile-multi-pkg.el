(define-package "consult-compile-multi" "20230827.2151" "Consulting read support for `compile-multi'"
  '((emacs "29.1")
    (compile-multi "0.4")
    (consult "0.34"))
  :commit "8d3f5aef027d7e214705803bb2733386e658b23d" :authors
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("mohsin kaleem" . "mohkale@kisara.moe")
  :keywords
  '("tools" "compile" "build")
  :url "https://github.com/mohkale/compile-multi")
;; Local Variables:
;; no-byte-compile: t
;; End:
