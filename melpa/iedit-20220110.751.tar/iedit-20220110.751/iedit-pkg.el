(define-package "iedit" "20220110.751" "Edit multiple regions in the same way simultaneously." 'nil :commit "d62dc475750f3a8326613f0acbfbcb583baea063" :authors
  '(("Victor Ren" . "victorhge@gmail.com"))
  :maintainer
  '("Victor Ren" . "victorhge@gmail.com")
  :keywords
  '("occurrence" "region" "simultaneous" "refactoring")
  :url "https://github.com/victorhge/iedit")
;; Local Variables:
;; no-byte-compile: t
;; End:
