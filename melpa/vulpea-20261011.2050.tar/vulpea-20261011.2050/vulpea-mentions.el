;;; vulpea-mentions.el --- Unlinked mention detection -*- lexical-binding: t; -*-
;;
;; Copyright (c) 2015-2026 Boris Buliga <boris@d12frosted.io>
;;
;; Author: Boris Buliga <boris@d12frosted.io>
;; Maintainer: Boris Buliga <boris@d12frosted.io>
;;
;; This program is free software; you can redistribute it and/or
;; modify it under the terms of the GNU General Public License as
;; published by the Free Software Foundation, either version 3 of the
;; License, or (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful, but
;; WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
;; General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see
;; <http://www.gnu.org/licenses/>.
;;
;; This file is not part of GNU Emacs.
;;
;; Created: 17 Jun 2026
;;
;; URL: https://github.com/d12frosted/vulpea
;;
;; License: GPLv3
;;
;;; Commentary:
;;
;; Unlinked mention detection.
;;
;; An unlinked mention of a note is a place where the note's title or one
;; of its aliases appears as plain text in another note, without an
;; `id:' link pointing to it.  This module answers the "incoming"
;; question: which notes mention this one without linking?
;;
;; The scan is delegated to ripgrep (fast multi-pattern search over all
;; files) and the result is post-filtered in Emacs: occurrences already
;; inside an Org link are dropped, the note's own file is skipped, and
;; each hit is mapped back to the mentioning note.
;;
;; The "outgoing" question is the dual: which notes does this buffer
;; mention without linking?  There ripgrep searches one buffer for the
;; titles of the whole collection, so it is given the cheapest thing it
;; can match, plain strings with case already erased on both sides,
;; and everything else is decided in Emacs.
;;
;; Word boundaries are script-aware.  Scripts that separate words with
;; spaces (Latin, Cyrillic, ...) require a match to stand on its own:
;; "art" does not match inside "smart".  Scripts without word
;; separators (Han, Kana, Thai, ...) match as substrings: 金阁寺 is
;; found inside 又名金阁寺, since there is no boundary to respect.  See
;; `vulpea-mentions-word-boundaries' and
;; `vulpea-mentions-spaceless-scripts'.
;;
;; The entry point is asynchronous and follows a promise-style contract
;; (RESOLVE / REJECT callbacks), so it drops directly into reactive UIs -
;; e.g. as a `vui-use-async' loader via
;; `(apply-partially #\\='vulpea-note-unlinked-mentions-async note)'.
;;
;;; Code:

(require 'cl-lib)
(require 'seq)
(require 'subr-x)
(require 'json)
(require 'ol)
(require 'org)
(require 'vulpea-note)
(require 'vulpea-db-query)
(require 'vulpea-db-extract)
(require 'vulpea-utils)

(defvar vulpea-db-sync-directories)     ; defined in vulpea-db-sync

(defgroup vulpea-mentions nil
  "Unlinked mention detection for Vulpea."
  :group 'vulpea)

(defcustom vulpea-mentions-min-term-length 3
  "Minimum length of a title or alias to search for as a mention.

Very short titles (e.g. \"a\") produce too much noise, so titles and
aliases shorter than this are ignored when looking for unlinked
mentions.

Length is measured with `string-width', not `length': a CJK character
occupies two columns, so a 2-character title like 北京 (width 4)
clears the default of 3, while a 2-letter Latin title does not.  This
matters because 2-character titles are the norm in Chinese and
Japanese."
  :type 'integer
  :group 'vulpea-mentions)

(defcustom vulpea-mentions-word-boundaries 'auto
  "How word boundaries apply in the ripgrep pre-filter of the incoming scan.

This tunes recall and speed of the ripgrep pass of
`vulpea-note-unlinked-mentions-async' only.  The exact matching
semantics - \"Wine\" counts only as a standalone word, 金阁寺 counts
anywhere inside CJK text - are enforced in Emacs on every candidate
line either way (see `vulpea-mentions--line-unlinked-p' and
`vulpea-mentions-spaceless-scripts').

The outgoing scan (`vulpea-buffer-unlinked-mentions-async') does not
read this option.  It looks for the titles of a whole collection at
once, which ripgrep can only do quickly for plain strings, so its
pre-filter carries no boundaries and finds what nil finds here.

- `auto': each term edge gets a boundary assertion only when it can
  glue to neighboring text at all (see
  `vulpea-mentions--edge-boundary'): ASCII alphanumeric edges get a
  fast ASCII assertion, while spaceless-script edges (金阁寺),
  punctuation edges and non-ASCII spaced edges (Київ) get none and
  rely on the Emacs re-check.  A mixed term like Emacs入门 keeps the
  assertion only on its Latin edge.  The ASCII assertion treats
  non-ASCII text as a boundary, so a Latin title glued into CJK
  prose (\"Emacs\" inside 我爱用Emacs写作) is found as well.

- t: a strict Unicode \\=\\b on both sides of every term, the old
  behavior.  It misses mentions embedded in CJK prose, and it can
  be slower than `auto', because a Unicode \\=\\b over non-ASCII
  text forces the regex engine off its fast literal path.

- nil: no boundaries in the pre-filter at all.  Over `auto' this
  only adds matches next to an underscore (\"foo\" inside
  \"foo_bar\"), which `auto' leaves behind because ripgrep counts _
  as a word character.  The cost is that every glued occurrence of
  every Latin title (\"art\" inside \"smart\") travels to the Emacs
  re-check just to be rejected there."
  :type '(choice (const :tag "Per term edge (script-aware)" auto)
                 (const :tag "Always" t)
                 (const :tag "Never" nil))
  :group 'vulpea-mentions)

(defcustom vulpea-mentions-spaceless-scripts
  '(han kana cjk-misc bopomofo hangul thai lao khmer burmese)
  "Scripts whose text does not separate words with spaces.

Symbols are compared against `char-script-table'.  A term edge or a
neighboring character in one of these scripts never demands a word
boundary: boundaries are meaningless between, say, two Han characters,
and requiring them loses legitimate mentions (金阁寺 inside
又名金阁寺).  Hangul is included because Korean particles attach
directly to nouns.  Set to nil to demand strict word boundaries
everywhere, restoring the old behavior."
  :type '(repeat symbol)
  :group 'vulpea-mentions)

(defun vulpea-mentions-file-level-note-p (note)
  "Return non-nil when NOTE is a file-level note.
The default value of `vulpea-mentions-note-filter'."
  (= (vulpea-note-level note) 0))

(defcustom vulpea-mentions-note-filter #'vulpea-mentions-file-level-note-p
  "Predicate selecting which notes are searched for as candidates.

A function called with a `vulpea-note' that returns non-nil to keep the
note.  Its title and aliases are then searched for when looking for the
unlinked mentions a buffer makes (`vulpea-buffer-unlinked-mentions-async').

The default keeps only file-level notes, which avoids noise from
heading-level notes.  Set it to your own predicate to, say, exclude a
journal: (lambda (note) (not (member \"journal\" (vulpea-note-tags note)))),
or to `always' to consider every note."
  :type 'function
  :group 'vulpea-mentions)

(defcustom vulpea-mentions-exclude-linked t
  "Exclude mentions to and from notes that are already linked.

When non-nil, a note that links to the target no longer shows up
among the target's incoming unlinked mentions, and notes already
linked from a buffer are dropped from that buffer's outgoing
mentions.  The reasoning: once a link exists, further plain-text
occurrences are prose, not a missing connection.  Set to nil to see
every occurrence regardless of existing links."
  :type 'boolean
  :group 'vulpea-mentions)

(defcustom vulpea-mentions-ignore-property-key "MENTIONS"
  "Org property marking a note as excluded from mention detection.

A note whose property drawer sets this property to
`vulpea-mentions-ignore-property-value' opts out of mentions entirely:
no incoming mentions are searched for it, and its title and aliases
are not offered as outgoing mention candidates in other notes.  Useful
for notes whose titles are common words (e.g. \"Sets\") that would
otherwise produce mostly false positives."
  :type 'string
  :group 'vulpea-mentions)

(defcustom vulpea-mentions-ignore-property-value "ignore"
  "Value of `vulpea-mentions-ignore-property-key' that opts a note out."
  :type 'string
  :group 'vulpea-mentions)

(defcustom vulpea-mentions-per-note-ignore-property-key "IGNORE_MENTIONS_FROM"
  "Org property marking notes ignored from mention detection for this note.

Its value is a whitespace-separated list of note ids.  Mentions from
those notes to this note are excluded from mention lists.  An id
silences the whole file it lives in, so it does not matter whether it is
a file-level id or a heading id."
  :type 'string
  :group 'vulpea-mentions)

;;; Pure helpers

(defun vulpea-mentions--note-terms (note)
  "Return the search terms for NOTE: its title and aliases.

Terms are trimmed, de-duplicated case-insensitively, and those
narrower than `vulpea-mentions-min-term-length' are dropped."
  (let ((seen (make-hash-table :test 'equal))
        (result nil))
    (dolist (term (cons (vulpea-note-title note)
                        (vulpea-note-aliases note)))
      (let ((trimmed (and term (string-trim term))))
        (when (and trimmed
                   (> (length trimmed) 0)
                   (>= (string-width trimmed) vulpea-mentions-min-term-length))
          (let ((key (downcase trimmed)))
            (unless (gethash key seen)
              (puthash key t seen)
              (push trimmed result))))))
    (nreverse result)))

(defun vulpea-mentions--spaceless-char-p (char)
  "Return non-nil when CHAR belongs to a script without word separators.
See `vulpea-mentions-spaceless-scripts'."
  (and char
       (memq (aref char-script-table char)
             vulpea-mentions-spaceless-scripts)))

(defun vulpea-mentions--rg-quote (term)
  "Escape TERM for literal use in a ripgrep (Rust) regular expression."
  (replace-regexp-in-string "[][\\^$.|?*+(){}]" "\\\\\\&" term))

(defun vulpea-mentions--edge-boundary (edge-char)
  "Return the boundary assertion to place next to EDGE-CHAR, or nil.

Under `auto' (see `vulpea-mentions-word-boundaries') an edge gets an
assertion only when gluing is possible at all: the edge must be
alphanumeric - next to punctuation a \\=\\b inverts into demanding
adjacent text - and must not belong to a spaceless script, where a
boundary loses embedded mentions.

ASCII edges get the ASCII assertion (?-u:\\=\\b) rather than the
Unicode one.  It matches everywhere the Unicode assertion does (ASCII
word characters are a subset of Unicode word characters, so the
negated neighbor test is weaker), and it keeps ripgrep on its fast
literal engine: a Unicode \\=\\b over a non-ASCII haystack forces a
slow fallback.  Non-ASCII spaced edges (Cyrillic, Greek, ...) get no
pre-filter assertion for the same reason.  Either way the pre-filter
only over-approximates; `vulpea-mentions--line-unlinked-p' enforces
the exact boundary rules on every candidate line."
  (pcase vulpea-mentions-word-boundaries
    ('auto (cond
            ((vulpea-mentions--spaceless-char-p edge-char) nil)
            ((not (string-match-p "[[:alnum:]]" (char-to-string edge-char)))
             nil)
            ((< edge-char 128) "(?-u:\\b)")
            (t nil)))
    ('nil nil)
    (_ "\\b")))

(defun vulpea-mentions--rg-pattern (term)
  "Return the ripgrep regex searching for TERM.

The literal is escaped with `vulpea-mentions--rg-quote' and each side
gets the boundary assertion `vulpea-mentions--edge-boundary' picks for
its edge character."
  (concat
   (or (vulpea-mentions--edge-boundary (aref term 0)) "")
   (vulpea-mentions--rg-quote term)
   (or (vulpea-mentions--edge-boundary (aref term (1- (length term)))) "")))

(defun vulpea-mentions--rg-link-pattern (terms)
  "Return the ripgrep regex for an Org bracket link holding one of TERMS.

The link may cross line boundaries: filling a paragraph breaks a link's
description (or a path with spaces in it) like any other text.  Each
term is compiled by `vulpea-mentions--rg-pattern'.  Stricter than
`org-link-bracket-re': a link with a bracket inside its path or
description, or one continued by an empty line, is not matched."
  (let ((inner "(?:[^\\[\\]\\n]|\\]\\[|\\n(?:[^\\[\\]\\n]|\\]\\[))"))
    (concat "\\[\\[" inner "*?\\n?"
            "(?:" (mapconcat #'vulpea-mentions--rg-pattern terms "|") ")"
            inner "*\\]\\]")))

(defun vulpea-mentions--rg-command (rg terms dirs)
  "Build the ripgrep command, run as RG, for TERMS over DIRS.

Produces a JSON stream of case-insensitive matches restricted to Org
files.  Each term is compiled to a regex by
`vulpea-mentions--rg-pattern', which applies script-aware word
boundaries.

ripgrep searches line by line, so on its own it reports each line of a
link that wraps across lines separately, and none of them reads as a
link.  Multiline mode with `vulpea-mentions--rg-link-pattern' makes a
link holding a term a match of its own: the term inside it is no longer
matched, and the link arrives whole for `vulpea-mentions--parse-rg-json'
to tell which columns of each line it covers.  Links without a term
stay out of the output."
  (append
   (list rg "--json" "--ignore-case" "--glob" "*.org" "--multiline")
   (mapcan (lambda (term)
             (list "-e" (vulpea-mentions--rg-pattern term)))
           terms)
   (list "-e" (vulpea-mentions--rg-link-pattern terms))
   dirs))

(defvar vulpea-mentions--fold-table nil
  "Translation table erasing case, built by `vulpea-mentions--fold-table'.")

(defun vulpea-mentions--fold-table ()
  "Return the translation table that erases case.

It maps each character to the one a case-insensitive Emacs search
takes it for, as the standard case table has it."
  (or vulpea-mentions--fold-table
      (let ((table (make-char-table 'translation-table)))
        (map-char-table
         (lambda (key value)
           (when (characterp value)
             (if (consp key)
                 (cl-loop for char from (car key) to (cdr key)
                          unless (eq char value)
                          do (aset table char value))
               (unless (eq key value)
                 (aset table key value)))))
         (case-table-get-table (standard-case-table) 'canon))
        (setq vulpea-mentions--fold-table table))))

(defun vulpea-mentions--fold (string)
  "Return STRING with case erased, character for character.

Two strings fold to the same text exactly when a case-insensitive
Emacs search takes one for the other.  No character is added or
dropped on the way, which `downcase' does not promise (it writes a
dotted capital I as two characters), so a position in the folded text
is the same position in STRING."
  (with-temp-buffer
    (insert string)
    ;; Every changed character would announce itself to the change
    ;; hooks otherwise, which makes folding a megabyte of titles
    ;; several times slower.
    (let ((inhibit-modification-hooks t))
      (translate-region (point-min) (point-max) (vulpea-mentions--fold-table)))
    (buffer-substring-no-properties (point-min) (point-max))))

(defun vulpea-mentions--rg-file-command (rg patterns-file input-file)
  "Build the ripgrep command, run as RG, over the single INPUT-FILE.

PATTERNS-FILE holds one literal per line.  Both files are expected
case-folded (see `vulpea-mentions--fold'), which leaves ripgrep a
case-sensitive search for fixed strings: the one shape it hands to
its literal multi-pattern matcher, whose cost barely depends on how
many patterns there are or how long the input is.  Anything else is
compiled into one automaton that grows with every pattern, a
case-insensitive one fastest of all: seconds per search at ten
thousand titles, and past fifty thousand it overflows ripgrep's size
limit and the search fails.

--case-sensitive is spelled out because the user's ripgrep
configuration file may say --smart-case or --ignore-case.

INPUT-FILE is given as an explicit path, which ripgrep searches
whatever its extension and regardless of any ignore rules; \"-\" makes
it read standard input instead."
  (list rg "--json" "--fixed-strings" "--case-sensitive"
        "-f" patterns-file input-file))

(defun vulpea-mentions--snapshot-buffer-p ()
  "Return non-nil when the current buffer may be written to a temporary file.

A buffer with no file, or visiting a plain .org file, may be
snapshotted to disk for ripgrep to read.  An indirect buffer is judged
by its base buffer's file.  Any other extension is one
of `vulpea-db-extra-extensions', which exist for encrypted notes
\(.org.gpg, .org.age): their decrypted content must not leave the
buffer, so they are fed to ripgrep over a pipe instead."
  (let ((file (buffer-file-name (or (buffer-base-buffer) (current-buffer)))))
    (or (null file)
        (string-suffix-p ".org" file))))

(defun vulpea-mentions--clip-spans (spans beg end)
  "Return the parts of SPANS that fall between BEG and END.

SPANS is a list of (BEG . END) pairs.  The result is relative to BEG,
so for a line that starts at BEG it holds columns on that line."
  (let ((result nil))
    (dolist (span spans)
      (when (and (< (car span) end) (> (cdr span) beg))
        (push (cons (- (max (car span) beg) beg)
                    (- (min (cdr span) end) beg))
              result)))
    (nreverse result)))

(defun vulpea-mentions--split-hit (path line-no text matched)
  "Split a ripgrep match over several lines into one hit per line.

In multiline mode a match event carries every line its matches touch:
a link wrapped across lines (see `vulpea-mentions--rg-link-pattern')
comes with all of its lines, and matches on adjacent lines are merged
into one event.  TEXT is that block, starting at line LINE-NO of PATH,
and MATCHED the substrings matched in it.

A substring holding a newline is a wrapped link.  Each line becomes a
hit like the one a single-line match produces, with :matched listing
the other substrings of the whole block and :link-spans the
\(BEG . END) columns the wrapped links cover on that line."
  (let ((spans nil)
        (others nil)
        (start 0)
        (result nil))
    (dolist (match matched)
      (if (not (string-search "\n" match))
          (push match others)
        ;; Matches come in order and do not overlap, so each link is the
        ;; first occurrence of its text past the previous one.
        (when-let* ((beg (string-search match text start)))
          (setq start (+ beg (length match)))
          (push (cons beg start) spans))))
    (setq others (nreverse others)
          start 0)
    (dolist (line (split-string text "\n"))
      (let ((end (+ start (length line))))
        (push (list :path path
                    :line line-no
                    :line-text (string-trim-right line "\r+")
                    :matched others
                    :link-spans (vulpea-mentions--clip-spans spans start end))
              result)
        (setq start (1+ end)
              line-no (1+ line-no))))
    (nreverse result)))

(defun vulpea-mentions--parse-rg-json (output)
  "Parse ripgrep --json OUTPUT into a list of raw hit plists.

Each hit is a plist with :path, :line, :line-text, and :matched (the
list of matched substrings on the line).  A match over several lines
yields one hit per line, see `vulpea-mentions--split-hit'.  Non-match
events and unparseable lines are ignored, as are hits whose path or
line content ripgrep encodes as base64 bytes rather than text (the
value was not valid UTF-8, e.g. a mis-encoded file name); one such
file must not take down the rest of the scan."
  (let ((result nil))
    (dolist (line (split-string output "\n" t))
      (let ((obj (ignore-errors (json-parse-string line :object-type 'alist))))
        (when (and obj (equal (alist-get 'type obj) "match"))
          (let* ((data (alist-get 'data obj))
                 (path (alist-get 'text (alist-get 'path data)))
                 (line-no (alist-get 'line_number data))
                 (text (alist-get 'text (alist-get 'lines data)))
                 (submatches (alist-get 'submatches data))
                 (matched (and submatches
                               (delq nil
                                     (mapcar (lambda (sm)
                                               (alist-get 'text (alist-get 'match sm)))
                                             (append submatches nil))))))
            ;; A value that is not valid UTF-8 arrives as {"bytes":
            ;; base64} instead of {"text": ...}, leaving the binding
            ;; nil.  Such a path cannot name an indexed note (the
            ;; database holds decoded strings, and reconstructing a
            ;; file name from raw bytes means guessing its encoding),
            ;; so the hit is dropped rather than decoded.
            (when (and path text)
              (let ((text (string-trim-right text "[\n\r]+")))
                (if (string-search "\n" text)
                    (dolist (hit (vulpea-mentions--split-hit
                                  path line-no text matched))
                      (push hit result))
                  (push (list :path path
                              :line line-no
                              :line-text text
                              :matched matched)
                        result))))))))
    (nreverse result)))

(defun vulpea-mentions--link-spans (line)
  "Return the (BEG . END) character spans of Org bracket links in LINE."
  (let ((spans nil)
        (start 0))
    (while (string-match org-link-bracket-re line start)
      (push (cons (match-beginning 0) (match-end 0)) spans)
      (setq start (match-end 0)))
    (nreverse spans)))

(defun vulpea-mentions--in-link-p (pos spans)
  "Return non-nil when POS falls inside one of SPANS."
  (seq-some (lambda (span) (and (>= pos (car span)) (< pos (cdr span))))
            spans))

(defun vulpea-mentions--metadata-line-p (line)
  "Return non-nil when LINE is an Org keyword or property-drawer line.

Lines such as #+title:, #+filetags:, :PROPERTIES:, :ID:, or :END:
declare a note's own metadata rather than prose, so a title that appears
on them (often a same-titled note's own #+title:) is not a real mention."
  (string-match-p "\\`[ \t]*\\(#\\+\\|:[A-Za-z0-9_@%-]+:\\)" line))

(defun vulpea-mentions--glued-p (edge neighbor)
  "Return non-nil when NEIGHBOR glues to EDGE into one word.

EDGE is the first or last character of a match, NEIGHBOR the character
just outside it (nil at the start or end of a line).  They glue - the
match is not a standalone word - only when both are alphanumeric and
neither belongs to `vulpea-mentions-spaceless-scripts', whose scripts
have no word separators to respect."
  (and neighbor
       (not (vulpea-mentions--spaceless-char-p edge))
       (not (vulpea-mentions--spaceless-char-p neighbor))
       (string-match-p "[[:alnum:]]" (char-to-string edge))
       (string-match-p "[[:alnum:]]" (char-to-string neighbor))))

(defun vulpea-mentions--occurrences (line term &optional link-spans)
  "Return the occurrences of TERM in LINE.

Each one is a list (BEG END GLUED LINKED).  BEG and END delimit it in
LINE.  GLUED is non-nil when it is part of a longer word rather than a
word of its own: one of its edges touches spaced-script text (see
`vulpea-mentions--glued-p').  LINKED is non-nil when it starts inside
an Org link.  Matching is case-insensitive.

A link that crosses a line boundary cannot be recognized from LINE
alone.  LINK-SPANS is the list of (BEG . END) columns such links cover
on LINE; an occurrence that starts inside one is LINKED as well."
  (let ((spans (append (vulpea-mentions--link-spans line) link-spans))
        (case-fold-search t)
        (len (length line))
        (re (regexp-quote term))
        (start 0)
        (result nil))
    (unless (string-empty-p term)
      (while (and (<= start len) (string-match re line start))
        (let* ((beg (match-beginning 0))
               (end (match-end 0))
               (before (and (> beg 0) (aref line (1- beg))))
               (after (and (< end len) (aref line end))))
          (setq start (1+ beg))
          (push (list beg end
                      (and (or (vulpea-mentions--glued-p (aref line beg) before)
                               (vulpea-mentions--glued-p (aref line (1- end)) after))
                           t)
                      (and (vulpea-mentions--in-link-p beg spans) t))
                result))))
    (nreverse result)))

(defun vulpea-mentions--mention-p (occurrence)
  "Return non-nil when OCCURRENCE is neither glued nor linked.
OCCURRENCE is an element of `vulpea-mentions--occurrences'."
  (not (or (nth 2 occurrence) (nth 3 occurrence))))

(defun vulpea-mentions--line-unlinked-p (line terms &optional link-spans)
  "Return non-nil when some term in TERMS occurs in LINE outside any link.

Matching is case-insensitive.  A match must stand on its own where its
edges touch spaced-script text (see `vulpea-mentions--glued-p'), while
spaceless scripts match as substrings; occurrences inside an Org link
are not counted.  LINK-SPANS, the columns that links wrapped across
lines cover on LINE, is passed on to `vulpea-mentions--occurrences'."
  (seq-some (lambda (term)
              (seq-some #'vulpea-mentions--mention-p
                        (vulpea-mentions--occurrences line term link-spans)))
            terms))

(defun vulpea-mentions--boundary-p (line pos)
  "Return non-nil when a word of its own may start or end at POS in LINE."
  (or (= pos 0)
      (= pos (length line))
      (not (vulpea-mentions--glued-p (aref line pos) (aref line (1- pos))))))

(defun vulpea-mentions--compound-p (term)
  "Return non-nil when a word boundary falls inside TERM."
  (cl-loop for pos from 1 below (length term)
           thereis (vulpea-mentions--boundary-p term pos)))

(defun vulpea-mentions--line-terms (line dict max-length)
  "Return the terms of DICT that stand in LINE as words of their own.

LINE is read from left to right.  At each word boundary the longest
stretch that ends on another boundary and is a key of DICT is taken,
MAX-LENGTH characters at most, and reading goes on after it.  These
are the matches ripgrep would report if it knew what a word is, given
the patterns longest first."
  (let* ((len (length line))
         ;; A term starts and ends on a word boundary and never with
         ;; whitespace, which leaves few stretches worth looking up.
         (opens (make-bool-vector (1+ len) nil))
         (closes (make-bool-vector (1+ len) nil))
         (pos 0)
         (result nil))
    (dotimes (i (1+ len))
      (when (vulpea-mentions--boundary-p line i)
        (aset opens i (and (< i len)
                           (not (memq (aref line i) '(?\s ?\t)))))
        (aset closes i (and (> i 0)
                            (not (memq (aref line (1- i)) '(?\s ?\t)))))))
    (while (< pos len)
      (let ((end (and (aref opens pos)
                      (cl-loop for end downfrom (min len (+ pos max-length))
                               above pos
                               when (and (aref closes end)
                                         (gethash (substring line pos end) dict))
                               return end))))
        (if (not end)
            (setq pos (1+ pos))
          (push (substring line pos end) result)
          (setq pos end))))
    (delete-dups (nreverse result))))

(defun vulpea-mentions--file-notes (path cache)
  "Return the notes of file PATH, memoized in the CACHE hash table.

The result (possibly nil, also cached) is shared by
`vulpea-mentions--file-note' and `vulpea-mentions--file-note-ids', so a
mentioning file is queried once no matter how many hits it has."
  (let ((cached (gethash path cache 'miss)))
    (if (not (eq cached 'miss))
        cached
      (puthash path (vulpea-db-query-by-file-path path) cache))))

(defun vulpea-mentions--file-note (path cache)
  "Return a note representing file PATH, memoized in the CACHE hash table.

Prefers the file-level note; falls back to the first note in the file.
Returns nil when PATH holds no indexed note."
  (let ((notes (vulpea-mentions--file-notes path cache)))
    (or (seq-find (lambda (n) (= (vulpea-note-level n) 0)) notes)
        (car notes))))

(defun vulpea-mentions--file-note-ids (path cache)
  "Return the ids of every note in file PATH.

CACHE is the hash table used by `vulpea-mentions--file-notes'."
  (mapcar #'vulpea-note-id (vulpea-mentions--file-notes path cache)))

(defun vulpea-mentions--ignored-file-p (path cache ignored-ids)
  "Return non-nil when an id of a note in file PATH is in IGNORED-IDS.

CACHE is the hash table used by `vulpea-mentions--file-notes'.  Any id
of the file counts, so a heading id silences it just like a file-level
one does."
  (unless (zerop (hash-table-count ignored-ids))
    (seq-some (lambda (id) (gethash id ignored-ids))
              (vulpea-mentions--file-note-ids path cache))))

(defun vulpea-mentions--shares-name-p (note terms)
  "Return non-nil when NOTE's title or an alias matches one of TERMS.

Comparison is case-insensitive.  Used to drop a hit whose mentioning
note shares a name with the searched note (a title collision): an
occurrence in a same-named note's file is more likely that note's own
title in prose than a reference to a different note, so it is excluded -
the same reasoning as skipping the searched note's own file."
  (let ((names (mapcar #'downcase
                       (cons (or (vulpea-note-title note) "")
                             (vulpea-note-aliases note))))
        (lc-terms (mapcar #'downcase terms)))
    (seq-intersection names lc-terms #'string=)))

(defun vulpea-mentions--ignore-note-p (note)
  "Return non-nil when NOTE opts out of mention detection.

A note opts out by setting `vulpea-mentions-ignore-property-key' to
`vulpea-mentions-ignore-property-value' in its property drawer; it then
gets no incoming mention scan and is excluded from the outgoing
candidate dictionary."
  (equal vulpea-mentions-ignore-property-value
         (cdr (assoc
               (upcase vulpea-mentions-ignore-property-key)
               (vulpea-note-properties note)))))

(defun vulpea-mentions--paths-link-to-note (note)
  "Return a hash table of note paths that contain links to NOTE."
  (let* ((result (make-hash-table :test 'equal))
         (links (vulpea-db-query-links-to (vulpea-note-id note)))
         (ids (mapcar (lambda (link) (plist-get link :source)) links))
         (notes (vulpea-db-query-by-ids ids))
         (paths (mapcar #'vulpea-note-path notes)))
    (mapc (lambda (path) (puthash (expand-file-name path) t result)) paths)
    result))

(defun vulpea-mentions--ignore-mention-ids (note)
  "Return note ids that mentions from them are ignored by NOTE in a list."
  (when-let* ((properties (vulpea-note-properties note))
              (ignore-mentions
               (assoc (upcase vulpea-mentions-per-note-ignore-property-key)
                      properties))
              (ignored-ids (split-string (cdr ignore-mentions))))
    ignored-ids))

(defun vulpea-mentions--ignore-mention-ids-table (note)
  "Return note ids that mentions from them are ignored by NOTE in a table."
  (let ((result (make-hash-table :test 'equal))
        (ignored-ids (vulpea-mentions--ignore-mention-ids note)))
    (mapc (lambda (id) (puthash id t result)) ignored-ids)
    result))

(defun vulpea-mentions-ignore-from (note-or-id from-note-or-id)
  "Silence mentions of NOTE-OR-ID coming from FROM-NOTE-OR-ID.

Adds an id from FROM-NOTE-OR-ID, which is determined by
`vulpea-mentions--file-note', to
`vulpea-mentions-per-note-ignore-property-key' in NOTE-OR-ID's property
drawer, saves the file and syncs the database."
  (let* ((note (vulpea-utils-ensure-note note-or-id))
         (from-note (vulpea-utils-ensure-note from-note-or-id))
         (from-file-note (vulpea-mentions--file-note
                          (vulpea-note-path from-note)
                          (make-hash-table :test 'equal))))
    (vulpea-utils-with-note-sync note
      (org-entry-add-to-multivalued-property
       (point)
       vulpea-mentions-per-note-ignore-property-key
       (vulpea-note-id from-file-note)))))

(defun vulpea-mentions-unignore-from (note-or-id from-note-or-id)
  "Show mentions of NOTE-OR-ID coming from FROM-NOTE-OR-ID again.

Removes each id appears in FROM-NOTE-OR-ID's note file from
`vulpea-mentions-per-note-ignore-property-key' in NOTE-OR-ID's property
drawer, dropping the property once nothing is left, saves the file and
syncs the database."
  (let* ((note (vulpea-utils-ensure-note note-or-id))
         (from-note (vulpea-utils-ensure-note from-note-or-id))
         (note-ids (vulpea-mentions--file-note-ids
                    (vulpea-note-path from-note)
                    (make-hash-table :test 'equal))))
    (vulpea-utils-with-note-sync note
      (dolist (id note-ids)
        (org-entry-remove-from-multivalued-property
         (point)
         vulpea-mentions-per-note-ignore-property-key
         id))
      ;; Clean up the property line
      (when (null (org-entry-get-multivalued-property
                   (point)
                   vulpea-mentions-per-note-ignore-property-key))
        (org-delete-property vulpea-mentions-per-note-ignore-property-key)))))

(defun vulpea-mentions-ignored-notes (note)
  "Return the notes whose mentions are ignored by NOTE.

Each id in `vulpea-mentions-per-note-ignore-property-key' is resolved
to the note a mention from its file is attributed to: the file-level
note, or the first note in the file when there is none.  Two ids of one
file therefore yield one note.  Ids that no longer belong to any note
are dropped."
  (let* ((cache (make-hash-table :test 'equal))
         (ignored-ids (vulpea-mentions--ignore-mention-ids note))
         (ignored-notes (vulpea-db-query-by-ids ignored-ids))
         (result-table (make-hash-table :test 'equal))
         (result '()))
    (dolist (ignored-note ignored-notes)
      (let ((resolved-note (vulpea-mentions--file-note
                            (vulpea-note-path ignored-note)
                            cache)))
        (puthash resolved-note t result-table)))
    (maphash (lambda (key _) (push key result))
             result-table)
    result))

(defun vulpea-mentions--collect (output note own-path)
  "Collect unlinked mentions of NOTE from ripgrep OUTPUT.

OWN-PATH is NOTE's own expanded file path, whose hits are skipped.  Hits
whose mentioning note shares a name with NOTE (a title collision) are
skipped too.  Hits whose mentioning note contains at least one explicit
link to NOTE are skipped as well.  Set `vulpea-mentions-exclude-linked'
to nil to disable this behavior.  Hits are skipped as well when NOTE
ignores any note of the mentioning file through
`vulpea-mentions-per-note-ignore-property-key', so which id of that file
was written there does not matter.  Returns a list of plists with
:note (the mentioning note), :path, :line, and :context."
  (let* ((terms (vulpea-mentions--note-terms note))
         (path->notes (make-hash-table :test 'equal))
         (hits (vulpea-mentions--parse-rg-json output))
         (paths-link-to-note
          (when (and vulpea-mentions-exclude-linked hits)
            (vulpea-mentions--paths-link-to-note note)))
         (ignore-mention-ids (vulpea-mentions--ignore-mention-ids-table note))
         (result nil))
    (dolist (hit hits)
      (let* ((path (plist-get hit :path))
             (line-text (plist-get hit :line-text))
             (expanded-path (expand-file-name path)))
        (when (and (not (equal expanded-path own-path))
                   (not (and vulpea-mentions-exclude-linked
                             (gethash expanded-path paths-link-to-note)))
                   (not (vulpea-mentions--metadata-line-p line-text))
                   (vulpea-mentions--line-unlinked-p
                    line-text terms (plist-get hit :link-spans)))
          (let ((mentioning (vulpea-mentions--file-note path path->notes)))
            (when (and mentioning
                       (not (vulpea-mentions--shares-name-p mentioning terms))
                       (not (vulpea-mentions--ignored-file-p
                             path path->notes ignore-mention-ids)))
              (push (list :note mentioning
                          :path path
                          :line (plist-get hit :line)
                          :context (string-trim line-text))
                    result))))))
    (nreverse result)))

;;; Outgoing: mentions made by a buffer

(defun vulpea-mentions--title-dictionary ()
  "Return (DICT . TERMS) describing the candidate notes' names.

Candidates are the notes kept by `vulpea-mentions-note-filter', minus
those opting out via `vulpea-mentions--ignore-note-p'.  DICT is a hash
table mapping a case-folded title or alias (see `vulpea-mentions--fold')
to the list of note ids that bear it.  TERMS lists its keys, which are
the terms to search for, longest first: ripgrep reports the first
pattern that fits at a position, and a title must not lose its place
to a shorter one it starts with."
  (let ((dict (make-hash-table :test 'equal))
        (names nil)
        (ids nil)
        (filter (lambda (note)
                  (and (not (vulpea-mentions--ignore-note-p note))
                       (funcall vulpea-mentions-note-filter note)))))
    (dolist (note (vulpea-db-query filter))
      (let ((id (vulpea-note-id note)))
        (dolist (name (cons (vulpea-note-title note) (vulpea-note-aliases note)))
          (when (stringp name)
            (let ((trimmed (string-trim name)))
              ;; The names are folded together, one per line, so a
              ;; name spanning lines stays out.  It could not be
              ;; found anyway: the search goes line by line.
              (when (and (> (length trimmed) 0)
                         (>= (string-width trimmed)
                             vulpea-mentions-min-term-length)
                         (not (string-search "\n" trimmed)))
                (push trimmed names)
                (push id ids)))))))
    (setq names (nreverse names)
          ids (nreverse ids))
    (cl-loop for term in (split-string
                          (vulpea-mentions--fold (string-join names "\n"))
                          "\n")
             for id in ids
             do (push id (gethash term dict)))
    (cons dict (sort (hash-table-keys dict)
                     (lambda (a b) (> (length a) (length b)))))))

(defun vulpea-mentions--buffer-link-ids ()
  "Return a hash table keyed by the ids of `id:' links in the current buffer.

Only bracket links are considered: `vulpea-mentions--line-unlinked-p'
recognizes bracket links alone when deciding whether an occurrence is
already linked, so the exclusion set must match, and the literal
search for \"[[\" is also much cheaper than the plain-link regexp."
  (let ((result (make-hash-table :test 'equal))
        (vulpea-db-index-plain-links nil))
    (vulpea-db--region-links
     (point-min)
     (point-max)
     (lambda (link)
       (when (equal (plist-get link :type) "id")
         (puthash (plist-get link :dest) t result))))
    result))

(defun vulpea-mentions--buffer-wrapped-link-spans ()
  "Return a hash table of the links wrapped across lines in the current buffer.

Maps a line number to the list of (BEG . END) columns that bracket
links crossing a line boundary cover on that line, the shape
`vulpea-mentions--occurrences' takes.  Links that fit on one line are
left out: they are recognized from the line itself.  Lines are numbered
from the start of the accessible portion, which is the text ripgrep is
handed."
  (let ((result (make-hash-table :test 'eql))
        (line 1)
        (line-start (point-min)))
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward org-link-bracket-re nil t)
        (let ((beg (match-beginning 0))
              (end (match-end 0)))
          (goto-char beg)
          (when (< (line-end-position) end)
            ;; Count from the previous wrapped link, not from the top:
            ;; the buffer may hold thousands of them.
            (setq line (+ line (count-lines line-start (line-beginning-position)))
                  line-start (line-beginning-position))
            (while (< (point) end)
              (let ((bol (line-beginning-position)))
                (puthash line
                         (nconc (gethash line result)
                                (vulpea-mentions--clip-spans
                                 (list (cons beg end))
                                 bol (line-end-position)))
                         result))
              (forward-line 1)
              (when (< (point) end)
                (setq line (1+ line)
                      line-start (point)))))
          (goto-char end))))
    result))

(defun vulpea-mentions--ignored-by-note-p (ids note)
  "Return non-nil if at least one of IDS is ignored by NOTE."
  (let ((ignore-mentions-id (vulpea-mentions--ignore-mention-ids-table note)))
    (seq-some (lambda (id) (gethash id ignore-mentions-id)) ids)))

(defun vulpea-mentions--line-reader (text)
  "Return a function mapping a line number to that line of TEXT.

Lines are numbered from 1, and the function returns nil past the last
one.  It remembers where it stopped, so reading lines in increasing
order, which is how ripgrep reports them, costs a single pass over
TEXT."
  (let ((line 1)
        (pos 0))
    (lambda (n)
      (when (or (null pos) (< n line))
        (setq line 1
              pos 0))
      (while (and pos (< line n))
        (setq pos (when-let* ((eol (string-search "\n" text pos)))
                    (1+ eol))
              line (1+ line)))
      (when pos
        (substring text pos (string-search "\n" text pos))))))

(defun vulpea-mentions--collect-outgoing (output text dict self-ids linked-ids
                                                &optional wrapped-links)
  "Collect outgoing unlinked mentions from ripgrep OUTPUT over one buffer.

TEXT is the text of the buffer.  OUTPUT comes from searching the
case-folded copy of it (see `vulpea-mentions--fold') for case-folded
terms, so the lines and matches it quotes are folded as well.  What a
mention quotes is read back from TEXT, where a line keeps its number
and a match its position.

DICT maps a case-folded title/alias to candidate note ids (see
`vulpea-mentions--title-dictionary').  SELF-IDS are the note ids in the
buffer's own file, excluded as candidates.  If one of SELF-IDS are
explicitly ignored by the mentioned note, then the mention will be
dropped (see `vulpea-mentions-per-note-ignore-property-key').
LINKED-IDS is a hash table keyed by the note ids the buffer already
links to (see `vulpea-mentions--buffer-link-ids'); candidates found in
it are dropped.  Pass an empty table to keep them all.  WRAPPED-LINKS
is a hash table of the buffer's links that cross a line boundary (see
`vulpea-mentions--buffer-wrapped-link-spans'); an occurrence inside one
is dropped like one inside a link that fits its line.

Ripgrep matches plain strings, so it also reports \"red wine\" inside
\"red wines\".  Such a glued match is dropped here.  But ripgrep's
matches never overlap: the glued one has already used up the text of
anything starting inside it (\"red\", a mention in its own right), and
the search went on from the middle of a word.  Only a match of several
words can do that, and a line holding one is read again by
`vulpea-mentions--line-terms'.

Returns a list of plists with :note (a candidate note to link to),
:line, :context, and :matched (the text that matched)."
  (let ((id->note (make-hash-table :test 'equal))
        ;; The ignore check walks every one of SELF-IDS, and a candidate
        ;; can be hit on hundreds of lines: decide it once per candidate.
        (id->ignored (make-hash-table :test 'equal))
        (line-at (vulpea-mentions--line-reader text))
        (longest nil)
        (result nil))
    (cl-flet ((resolve-note (id)
                (let ((cached (gethash id id->note 'miss)))
                  (if (not (eq cached 'miss)) cached
                    (puthash id (vulpea-db-get-by-id id) id->note))))
              (ignored-p (id cand)
                (let ((cached (gethash id id->ignored 'miss)))
                  (if (not (eq cached 'miss)) cached
                    (puthash id (vulpea-mentions--ignored-by-note-p self-ids cand)
                             id->ignored))))
              (max-length ()
                (or longest
                    (progn
                      (setq longest 0)
                      (maphash (lambda (term _)
                                 (setq longest (max longest (length term))))
                               dict)
                      longest))))
      (dolist (hit (vulpea-mentions--parse-rg-json output))
        (let* ((line-no (plist-get hit :line))
               (folded (plist-get hit :line-text))
               (line (funcall line-at line-no))
               (link-spans (and wrapped-links
                                (gethash line-no wrapped-links))))
          (unless (vulpea-mentions--metadata-line-p line)
            (let* ((occurrences (lambda (term)
                                  (cons term (vulpea-mentions--occurrences
                                              folded term link-spans))))
                   (found (mapcar occurrences
                                  (seq-uniq (plist-get hit :matched)))))
              (when (seq-some (pcase-lambda (`(,term . ,spans))
                                (and (seq-some #'cl-third spans)
                                     (vulpea-mentions--compound-p term)))
                              found)
                (setq found (mapcar occurrences
                                    (vulpea-mentions--line-terms
                                     folded dict (max-length)))))
              (pcase-dolist (`(,term . ,spans) found)
                (when-let* ((span (seq-find #'vulpea-mentions--mention-p spans))
                            (matched (substring line (car span) (cadr span))))
                  (dolist (id (gethash term dict))
                    (unless (or (member id self-ids)
                                (gethash id linked-ids))
                      (when-let* ((cand (resolve-note id)))
                        (unless (ignored-p id cand)
                          (push (list :note cand :line line-no
                                      :context (string-trim line)
                                      :matched matched)
                                result))))))))))))
    (nreverse result)))

;;; Async entry point

;;;###autoload
(defun vulpea-note-unlinked-mentions-async (note resolve reject)
  "Find notes mentioning NOTE's title or aliases without linking to it.

Searches the files under `vulpea-db-sync-directories' with ripgrep for
NOTE's title and aliases, drops occurrences that are already inside an
Org link, that live in NOTE's own file or in the file of a note sharing
NOTE's title (a title collision), or that fall on an Org metadata
line (a keyword or property-drawer line), or that live in a file
already linking to NOTE (unless `vulpea-mentions-exclude-linked' is
nil), and maps each remaining hit to the mentioning note.  When NOTE
itself opts out of mention detection (see
`vulpea-mentions-ignore-property-key'), no search runs at all and
RESOLVE is called synchronously with nil.

This is asynchronous and promise-style: exactly one of RESOLVE or
REJECT is called.

- RESOLVE is called with a list of plists, each with :note (the
  mentioning `vulpea-note'), :path, :line, and :context (the matching
  line, trimmed).
- REJECT is called with an error message string when ripgrep is
  unavailable or fails.

The (NOTE RESOLVE REJECT) shape matches a reactive loader, so a UI can
use `(apply-partially #\\='vulpea-note-unlinked-mentions-async note)'
directly.

Returns the ripgrep process, so the caller can wait on or
`delete-process' it, or nil when the result is delivered synchronously
\(no ripgrep, no search terms, or no directories)."
  (let ((rg (executable-find "rg")))
    (cond
     ((not rg)
      (funcall reject "ripgrep (rg) not found on `exec-path'")
      nil)
     (t
      (let ((terms (vulpea-mentions--note-terms note))
            (dirs (seq-filter #'file-directory-p
                              (mapcar #'expand-file-name
                                      vulpea-db-sync-directories)))
            (own-path (expand-file-name (vulpea-note-path note))))
        (if (or (null terms) (null dirs)
                (vulpea-mentions--ignore-note-p note))
            (progn (funcall resolve nil) nil)
          (let ((output ""))
            (make-process
             :name "vulpea-mentions"
             :command (vulpea-mentions--rg-command rg terms dirs)
             :connection-type 'pipe
             :noquery t
             ;; Emacs encodes the :command arguments with the process
             ;; coding system, so this pins both the non-ASCII search
             ;; terms and the JSON output to UTF-8 no matter what
             ;; `default-process-coding-system' says.
             :coding 'utf-8
             :filter (lambda (_proc chunk)
                       (setq output (concat output chunk)))
             :sentinel
             (lambda (proc _event)
               (let ((status (process-status proc)))
                 (when (memq status '(exit signal))
                   (let ((code (process-exit-status proc)))
                     ;; rg exits 0 with matches, 1 with none, >1 on
                     ;; error.  For a signalled process the exit status
                     ;; is the signal number, and SIGHUP is 1: only an
                     ;; actual exit counts.
                     (cond
                      ((and (eq status 'exit) (memq code '(0 1)))
                       (condition-case err
                           (funcall resolve
                                    (vulpea-mentions--collect
                                     output note own-path))
                         (error (funcall reject (error-message-string err)))))
                      ((eq status 'exit)
                       (funcall reject
                                (format "ripgrep failed (exit %s)" code)))
                      (t
                       (funcall reject
                                (format "ripgrep killed (signal %s)"
                                        code))))))))))))))))

;;;###autoload
(defun vulpea-buffer-unlinked-mentions-async (resolve reject)
  "Find notes mentioned as plain text in the current buffer without a link.

Scans the current buffer's content with ripgrep for the titles and
aliases of the candidate notes (those kept by
`vulpea-mentions-note-filter', file-level notes by default), drops
occurrences inside an Org link or on an Org metadata line, ignores
notes in the buffer's own file and notes the buffer already links
to (unless `vulpea-mentions-exclude-linked' is nil), and maps each
remaining match to the candidate note(s) it could link to.  The
buffer's live content is searched, so unsaved edits are included -
both for the mentions and for the links that exclude them.

The accessible portion of the buffer is snapshotted to a temporary file
for ripgrep to read, so the call returns as soon as the process is
started.  A buffer visiting an encrypted note (any extension other
than .org, see `vulpea-mentions--snapshot-buffer-p') is fed to
ripgrep over a pipe instead, so its decrypted content never touches
the disk; for such a buffer the call blocks until ripgrep has
consumed the text.

Case is erased from that copy and from the names before ripgrep sees
them (see `vulpea-mentions--fold'), so it only has plain strings to
match.  That keeps the search fast with tens of thousands of names,
and its time hardly depends on the size of the buffer.

Asynchronous and promise-style: exactly one of RESOLVE or REJECT is
called.  RESOLVE receives a list of plists with :note (a candidate note
to link to), :line, :context, and :matched (the text that matched).
REJECT receives an error message string.

Returns the ripgrep process, or nil when answered synchronously.  As
with `vulpea-note-unlinked-mentions-async', the (RESOLVE REJECT) shape
is a ready-made reactive loader; wrap it in `with-current-buffer' to
target a specific buffer."
  (let ((rg (executable-find "rg")))
    (cond
     ((not rg)
      (funcall reject "ripgrep (rg) not found on `exec-path'")
      nil)
     (t
      (let* ((file (and buffer-file-name (expand-file-name buffer-file-name)))
             (self-ids (when file
                         (mapcar #'vulpea-note-id
                                 (vulpea-db-query-by-file-path file))))
             (dict-terms (vulpea-mentions--title-dictionary))
             (dict (car dict-terms))
             (terms (cdr dict-terms))
             (linked-ids (if vulpea-mentions-exclude-linked
                             (vulpea-mentions--buffer-link-ids)
                           (make-hash-table :test 'equal))))
        (if (null terms)
            (progn (funcall resolve nil) nil)
          ;; Three resources back the search: the patterns file, the
          ;; snapshot of the buffer, and a buffer for ripgrep's JSON
          ;; output (concatenating each chunk onto a string copied
          ;; everything received so far on every chunk).  One cleanup
          ;; serves both the sentinel and a setup that fails part way.
          ;;
          ;; Ripgrep reads the folded text; the text as written stays
          ;; here, for the sentinel to quote mentions from, along with
          ;; the links in it that ripgrep cannot see whole.
          (let ((snapshot (vulpea-mentions--snapshot-buffer-p))
                (text (buffer-substring-no-properties (point-min) (point-max)))
                (wrapped-links (vulpea-mentions--buffer-wrapped-link-spans))
                folded patterns-file input-file output-buffer proc)
            (cl-flet ((cleanup ()
                        (when patterns-file
                          (ignore-errors (delete-file patterns-file)))
                        (when input-file
                          (ignore-errors (delete-file input-file)))
                        (when (buffer-live-p output-buffer)
                          (kill-buffer output-buffer))))
              (condition-case err
                  (progn
                    (setq folded (vulpea-mentions--fold text)
                          patterns-file (make-temp-file "vulpea-mentions-pat-")
                          input-file (when snapshot
                                       (make-temp-file "vulpea-mentions-in-"))
                          output-buffer (generate-new-buffer
                                         " *vulpea-mentions-out*" t))
                    ;; rg rejects a patterns file that is not valid
                    ;; UTF-8, and the snapshot must decode as UTF-8 on
                    ;; the way back out, so the user's
                    ;; `coding-system-for-write' must not leak in.
                    (let ((coding-system-for-write 'utf-8))
                      (with-temp-file patterns-file
                        (insert (string-join terms "\n") "\n"))
                      (when input-file
                        (write-region folded nil input-file nil 'silent)))
                    (setq proc
                          (make-process
                           :name "vulpea-mentions-out"
                           :buffer output-buffer
                           :command (vulpea-mentions--rg-file-command
                                     rg patterns-file (or input-file "-"))
                           :connection-type 'pipe
                           :noquery t
                           ;; Pin the JSON output to UTF-8 no matter what
                           ;; `default-process-coding-system' says.
                           :coding 'utf-8
                           :sentinel
                           (lambda (proc _event)
                             (let ((status (process-status proc)))
                               (when (memq status '(exit signal))
                                 (let ((code (process-exit-status proc))
                                       (output (with-current-buffer output-buffer
                                                 (buffer-string))))
                                   (cleanup)
                                   ;; rg exits 0 with matches, 1 with none, >1
                                   ;; on error.  For a signalled process the
                                   ;; exit status is the signal number, and
                                   ;; SIGHUP is 1: only an actual exit counts.
                                   (cond
                                    ((and (eq status 'exit) (memq code '(0 1)))
                                     (condition-case err
                                         (funcall resolve
                                                  (vulpea-mentions--collect-outgoing
                                                   output text dict self-ids linked-ids
                                                   wrapped-links))
                                       (error
                                        (funcall reject (error-message-string err)))))
                                    ((eq status 'exit)
                                     (funcall reject
                                              (format "ripgrep failed (exit %s)" code)))
                                    (t
                                     (funcall reject
                                              (format "ripgrep killed (signal %s)"
                                                      code))))))))))
                    (unless input-file
                      ;; An encrypted note goes over the pipe, and the
                      ;; send blocks the caller.  If it fails, ripgrep
                      ;; is gone (a broken pipe) or has to go; if the
                      ;; user quits while it blocks, ripgrep has to go
                      ;; too, or it waits on stdin forever.  Either way
                      ;; the sentinel settles the promise.
                      (let ((sent nil))
                        (unwind-protect
                            (condition-case nil
                                (progn
                                  (process-send-string proc folded)
                                  (process-send-eof proc)
                                  (setq sent t))
                              (error nil))
                          (unless sent
                            (when (process-live-p proc)
                              (delete-process proc))))))
                    proc)
                ;; The promise settles even when the search never
                ;; starts - a full TMPDIR, ripgrep gone since
                ;; `executable-find' saw it - and nothing is left behind.
                (error
                 (cleanup)
                 (funcall reject (error-message-string err))
                 nil))))))))))

(provide 'vulpea-mentions)
;;; vulpea-mentions.el ends here
