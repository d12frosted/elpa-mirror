;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261011.2050"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "4c0d8d46fa23696dffd7142febc037616f7eeee6"
  :revdesc "4c0d8d46fa23"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
