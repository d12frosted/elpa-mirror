;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250301.1133"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "8ced71e586e64caee60c5b67c44795b48f0ab440"
  :revdesc "8ced71e586e6"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
