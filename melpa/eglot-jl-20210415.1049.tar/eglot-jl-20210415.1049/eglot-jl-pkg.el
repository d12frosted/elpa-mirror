(define-package "eglot-jl" "20210415.1049" "Julia support for eglot"
  '((emacs "25.1")
    (eglot "1.4")
    (julia-mode "0.3"))
  :commit "657693fede5dc68c8b001cc5d227e94afd6658e4" :authors
  '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz"))
  :maintainer
  '("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/non-Jedi/eglot-jl")
;; Local Variables:
;; no-byte-compile: t
;; End:
