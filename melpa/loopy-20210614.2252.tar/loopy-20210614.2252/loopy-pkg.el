(define-package "loopy" "20210614.2252" "A looping macro"
  '((emacs "27.1"))
  :commit "ad9f035d33658111a000a7e5d789a496b79dcfdb" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
