;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bookmarks" "20261111.2359"
  "Manage bookmarks in Org mode."
  '((emacs      "29.1")
    (nerd-icons "0.1.0")
    (seq        "2.24"))
  :url "https://repo.or.cz/org-bookmarks.git"
  :commit "ff090175f625ae6ffea9d5b3136d73a3c9960432"
  :revdesc "ff090175f625"
  :keywords '("outline" "matching" "hypermedia" "org")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
