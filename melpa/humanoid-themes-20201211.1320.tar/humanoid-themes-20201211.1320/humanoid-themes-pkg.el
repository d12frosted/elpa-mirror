(define-package "humanoid-themes" "20201211.1320" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "5a2638b95f93ededa625187dee76946a60e7b9d4" :keywords
  ("faces" "color" "theme")
  :authors
  (("Thomas Friese"))
  :maintainer
  ("Thomas Friese")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
