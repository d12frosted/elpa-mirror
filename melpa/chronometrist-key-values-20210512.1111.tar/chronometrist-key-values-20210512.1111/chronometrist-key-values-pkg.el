(define-package "chronometrist-key-values" "20210512.1111" "add key-values to Chronometrist data"
  '((chronometrist "0.5.0")
    (choice "0.0.1"))
  :commit "9a9cbde7430d097bc60bfffe80b6e5a4f9436173" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "gemini://tilde.team/~contrapunctus/software.gmi")
;; Local Variables:
;; no-byte-compile: t
;; End:
