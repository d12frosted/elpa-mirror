(define-package "hyperdrive" "20230604.332" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.3.2")
    (plz "0.6pre")
    (persist "0.5"))
  :commit "10fd83be43cc901cf03ef7bfa6a7320c48743351" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
