;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260329.1134"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "f91064433bf8273cd436d4b5d73db56256c47625"
  :revdesc "f91064433bf8"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
