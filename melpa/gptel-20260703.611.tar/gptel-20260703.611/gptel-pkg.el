;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260703.611"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "7bb1f4c48a2653cd1a6aad60c2beee07a6a91e48"
  :revdesc "7bb1f4c48a26"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
