(define-package "journalctl-mode" "20221119.1653" "Sample major mode for  viewing output journalctl"
  '((emacs "24.1"))
  :commit "baaffdfd22a19afb1997ec3715d063186b80d3f5" :authors
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainers
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainer
  '("Sebastian Meisel" . "sebastian.meisel@gmail.com")
  :keywords
  '("unix")
  :url "https://github.com/SebastianMeisel/journalctl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
