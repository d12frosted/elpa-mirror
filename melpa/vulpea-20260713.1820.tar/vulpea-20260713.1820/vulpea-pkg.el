;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260713.1820"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "c3db0a9deceb1b3f8371afc79b3d66d8f3fc457d"
  :revdesc "c3db0a9deceb"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
