;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250919.1543"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "705675a396931a3319a906916bffd58ed9f80de8"
  :revdesc "705675a39693"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
