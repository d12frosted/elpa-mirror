;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260426.2157"
  "Pure Elisp HTTP server."
  '((emacs  "26.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "ed1e3b2ad4830a234ac8b8e75d199378fab8d769"
  :revdesc "ed1e3b2ad483"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
