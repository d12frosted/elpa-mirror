(define-package "loopy" "20211017.213" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22"))
  :commit "5c6f204e36038100fa9945b09280fd62b31823d6" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
