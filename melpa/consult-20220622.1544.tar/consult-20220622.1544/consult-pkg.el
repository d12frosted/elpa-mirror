(define-package "consult" "20220622.1544" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "de94f2c7c1c9ec6ffebf77c94b1b5b6ab5b615cc" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
