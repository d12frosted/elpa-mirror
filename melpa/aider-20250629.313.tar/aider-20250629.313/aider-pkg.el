;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250629.313"
  "AI assisted programming with Aider and LLM."
  '((emacs         "26.1")
    (transient     "0.9.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "f4e4fb4439c0e9ca8161d07e999cffce16cb812a"
  :revdesc "f4e4fb4439c0"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
