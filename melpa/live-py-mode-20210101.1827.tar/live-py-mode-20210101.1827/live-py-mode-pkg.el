(define-package "live-py-mode" "20210101.1827" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "9844a088263415047c4dfa0455c2953c2c13472d" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
