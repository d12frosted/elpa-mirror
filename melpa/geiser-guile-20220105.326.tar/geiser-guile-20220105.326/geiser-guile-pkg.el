(define-package "geiser-guile" "20220105.326" "Guile's implementation of the geiser protocols"
  '((emacs "25.1")
    (geiser "0.21"))
  :commit "a2634fa2be4bce5042aaa14b33fc5246f78922d7" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
