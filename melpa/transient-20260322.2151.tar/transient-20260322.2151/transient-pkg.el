;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260322.2151"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "30.1")
    (cond-let "0.2")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "61ed3651df360e1a0c36ff70afbb9ee0f947252a"
  :revdesc "61ed3651df36"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
