;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260305.728"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "247b1371c5f824b74cf4c7e7fda96d53aa74cbae"
  :revdesc "247b1371c5f8"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
