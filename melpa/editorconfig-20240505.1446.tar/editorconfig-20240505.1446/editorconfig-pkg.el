(define-package "editorconfig" "20240505.1446" "EditorConfig Emacs Plugin"
  '((emacs "26.1")
    (nadvice "0.3"))
  :commit "2d6690e8d81ba65b27ab697e527a3ae2e03d95da" :authors
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainers
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainer
  '("EditorConfig Team" . "editorconfig@googlegroups.com")
  :keywords
  '("convenience" "editorconfig")
  :url "https://github.com/editorconfig/editorconfig-emacs#readme")
;; Local Variables:
;; no-byte-compile: t
;; End:
