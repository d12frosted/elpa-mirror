;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "koishi-theme" "20260123.1934"
  "A sweet theme inspired by Koishi's color tone."
  '((emacs "24.1"))
  :url "https://github.com/gynamics/koishi-theme.el"
  :commit "2d241a789bcd31819a5302c3fdc6361453b789df"
  :revdesc "2d241a789bcd"
  :keywords '("faces"))
