;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20261028.315"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "10b5d45ff68cd2f614a43a99e0db8cf07c17fc86"
  :revdesc "10b5d45ff68c"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
