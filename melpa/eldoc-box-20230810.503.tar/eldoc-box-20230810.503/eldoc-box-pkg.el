(define-package "eldoc-box" "20230810.503" "Display documentation in childframe"
  '((emacs "27.1"))
  :commit "73345daa47a5612f298896e5eb044e10a79496e7" :authors
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainer
  '("Yuan Fu" . "casouri@gmail.com")
  :url "https://github.com/casouri/eldoc-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
