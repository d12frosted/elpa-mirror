(define-package "hl-prog-extra" "20220422.541" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "40905568a040c1050941275cc9b970a45b77eb90" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
