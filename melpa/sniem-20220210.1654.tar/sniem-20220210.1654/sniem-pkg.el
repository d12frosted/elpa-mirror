(define-package "sniem" "20220210.1654" "Hands-eased united editing method"
  '((emacs "27.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "5824a3c33ee51acc1d3cba36ef6892ebb3a8df1c" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
