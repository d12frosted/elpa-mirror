(define-package "consult" "20210521.1420" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "4ca77477e980df954d75a5abde0e6584365bf404" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
