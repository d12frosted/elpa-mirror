;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pulseaudio-control" "20230316.1819"
  "Use `pactl' to manage PulseAudio volumes."
  ()
  :url "https://git.sr.ht/~flexibeast/pulseaudio-control"
  :commit "e917e84661b0e2496b295f1bbfba6ad32a656527"
  :revdesc "e917e84661b0"
  :keywords '("multimedia" "hardware" "sound" "pulseaudio")
  :authors '(("Alexis" . "flexibeast@gmail.com")
             ("Ellington Santos" . "ellingtonsantos@gmail.com")
             ("Sergey Trofimov" . "sarg@sarg.org.ru")
             ("conses" . "contact@conses.eu"))
  :maintainers '(("Alexis" . "flexibeast@gmail.com")))
