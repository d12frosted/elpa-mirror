(define-package "eldev" "20220308.2051" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "838ef1623b7eb0811adc5e2253be6f0edecfe541" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
