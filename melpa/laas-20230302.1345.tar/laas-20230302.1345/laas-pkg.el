(define-package "laas" "20230302.1345" "A bundle of as-you-type LaTeX snippets"
  '((emacs "26.3")
    (auctex "11.88")
    (aas "1.1"))
  :commit "7f4044918c4e0a9b71128f36f65f1d86842203f9" :maintainer
  '("Yoav Marco" . "yoavm448@gmail.com")
  :keywords
  '("tools" "tex")
  :url "https://github.com/tecosaur/LaTeX-auto-activating-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
