;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20251229.2005"
  "Light Emacs color theme on cornsilk3 background."
  ()
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "234889b84663e066eb8755528e8c35e2dd210704"
  :revdesc "234889b84663"
  :keywords '("color" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
