;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grip-mode" "20260213.1756"
  "Instant GitHub-flavored Markdown/Org preview using grip."
  '((emacs "24.4"))
  :url "https://github.com/seagle0128/grip-mode"
  :commit "b8b9e603edbb258ab38a94a0518c4a8c7a22e53c"
  :revdesc "b8b9e603edbb"
  :keywords '("convenience" "markdown" "preview")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
