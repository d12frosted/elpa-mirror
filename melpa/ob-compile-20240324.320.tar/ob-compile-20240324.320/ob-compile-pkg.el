;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-compile" "20240324.320"
  "Run compile by org-babel."
  '((emacs "24.4"))
  :url "https://github.com/TxGVNN/ob-compile"
  :commit "d9c3e446467badad571eef8832232ae5a6f9f05b"
  :revdesc "d9c3e446467b"
  :keywords '("literate programming" "reproducible" "processes" "compilation")
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
