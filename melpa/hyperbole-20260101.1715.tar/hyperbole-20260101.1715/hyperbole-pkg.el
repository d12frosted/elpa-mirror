;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260101.1715"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "82f7e0df2821a65a2be15be40005c4704594d4b4"
  :revdesc "82f7e0df2821"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
