;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260816.737"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "2a10eb42f95a5e9e96e7a39df982bab0d28cc383"
  :revdesc "2a10eb42f95a"
  :keywords '("convenience" "text"))
