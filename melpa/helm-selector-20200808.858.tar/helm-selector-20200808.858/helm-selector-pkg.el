(define-package "helm-selector" "20200808.858" "Helm buffer selector"
  '((emacs "26.1")
    (helm "3"))
  :commit "a1920a885830693dd9b1d6af3dd60f1915d976f4" :authors
  (("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainer
  ("Pierre Neidhardt" . "mail@ambrevar.xyz")
  :url "https://github.com/emacs-helm/helm-selector")
;; Local Variables:
;; no-byte-compile: t
;; End:
