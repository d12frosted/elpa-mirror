(define-package "clojure-ts-mode" "20230904.1416" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "b8c860d26a7e6794ce8e4af6063017d8ed02f0fd" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
