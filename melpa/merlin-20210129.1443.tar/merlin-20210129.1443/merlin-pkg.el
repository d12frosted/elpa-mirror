(define-package "merlin" "20210129.1443" "Mode for Merlin, an assistant for OCaml." 'nil :commit "5dae97414e4e4f68a9d71d79362e03416bb6e6ce" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
