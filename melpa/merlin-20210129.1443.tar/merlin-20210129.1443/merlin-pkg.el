(define-package "merlin" "20210129.1443" "Mode for Merlin, an assistant for OCaml." 'nil :commit "5643f5d928fec59f2fc22a7f3439d7809b68186b" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
