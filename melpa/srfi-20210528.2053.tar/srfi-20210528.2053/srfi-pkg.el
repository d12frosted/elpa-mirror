(define-package "srfi" "20210528.2053" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "c4ff94490dd8124e633f907f94955b30b7a4d8d4" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
