(define-package "tracking" "20171210.2102" "Buffer modification tracking" 'nil :commit "6ccd4b494cbae9d28091217654f052eaea321007" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
