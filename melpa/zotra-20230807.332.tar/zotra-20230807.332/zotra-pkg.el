(define-package "zotra" "20230807.332" "Library to use Zotero translators"
  '((emacs "27.1"))
  :commit "2e20fbed40f5b51bc3bd38e8193ceab5bb300005" :authors
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainers
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainer
  '("Mohammad Pedramfar <https://github.com/mpedramfar>")
  :url "https://github.com/mpedramfar/zotra")
;; Local Variables:
;; no-byte-compile: t
;; End:
