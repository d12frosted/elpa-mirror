(define-package "epkg" "20210616.2229" "browse the Emacsmirror package database"
  '((closql "1.0.6")
    (emacs "25.1"))
  :commit "44b7b2519f84056ee94a6c4ce21fce146532174c" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
