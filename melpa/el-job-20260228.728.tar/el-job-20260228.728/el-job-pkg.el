;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20260228.728"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "f38e5c59c5043c8d37cbd25ac99183083fc1b9ad"
  :revdesc "f38e5c59c504"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
