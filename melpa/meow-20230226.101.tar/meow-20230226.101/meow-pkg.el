(define-package "meow" "20230226.101" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "8754857b800e0bf22c85bebad07488e85146e81d" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
