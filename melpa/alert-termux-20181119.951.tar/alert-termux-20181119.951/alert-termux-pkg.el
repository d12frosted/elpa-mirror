;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alert-termux" "20181119.951"
  "Alert.el notifications on Termux."
  '((emacs "24.4"))
  :url "https://github.com/gergelypolonkai/alert-termux"
  :commit "8215cf1d86392738c35a90bbc0055359265dfc4d"
  :revdesc "8215cf1d8639"
  :keywords '("terminals")
  :authors '(("Gergely Polonkai" . "gergely@polonkai.eu"))
  :maintainers '(("Gergely Polonkai" . "gergely@polonkai.eu")))
