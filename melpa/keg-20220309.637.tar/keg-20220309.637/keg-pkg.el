(define-package "keg" "20220309.637" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "f2b66070264c1563933f53afb5c4b488df898d36" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
