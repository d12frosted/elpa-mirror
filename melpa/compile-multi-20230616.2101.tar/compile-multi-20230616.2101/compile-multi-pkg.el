(define-package "compile-multi" "20230616.2101" "A multi target interface to compile"
  '((emacs "28.0"))
  :commit "fbf513c2e427ec1880b47dfd578128dff0f2083e" :authors
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("mohsin kaleem" . "mohkale@kisara.moe")
  :keywords
  '("tools" "compile" "build")
  :url "https://github.com/mohkale/compile-multi")
;; Local Variables:
;; no-byte-compile: t
;; End:
