(define-package "posframe" "20210603.433" "Pop a posframe (just a frame) at point"
  '((emacs "26"))
  :commit "f89438b140e47688c56b2524b406c17bd708c25c" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
