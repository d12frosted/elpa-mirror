(define-package "bqn-mode" "20230421.119" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "5ce39f697a4ea8c3c2b00003c477f3d2fa2739ea" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
