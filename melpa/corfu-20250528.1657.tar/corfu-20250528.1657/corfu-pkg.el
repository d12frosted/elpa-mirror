;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250528.1657"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "42cadf78c72f181ca080e310b1bba0374f414953"
  :revdesc "42cadf78c72f"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
