;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alchemist" "20180312.1304"
  "Elixir tooling integration into Emacs."
  '((elixir-mode "2.2.5")
    (dash        "2.11.0")
    (emacs       "24.4")
    (company     "0.8.0")
    (pkg-info    "0.4")
    (s           "1.11.0"))
  :url "http://www.github.com/tonini/alchemist.el"
  :commit "6f99367511ae209f8fe2c990779764bbb4ccb6ed"
  :revdesc "6f99367511ae"
  :keywords '("languages" "elixir" "elixirc" "mix" "hex" "alchemist")
  :authors '(("Samuel Tonini" . "tonini.samuel@gmail.com"))
  :maintainers '(("Samuel Tonini" . "tonini.samuel@gmail.com")))
