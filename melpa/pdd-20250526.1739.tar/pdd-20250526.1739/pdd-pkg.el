;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250526.1739"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "f6dd0e06724578e4a9f2060bfd6e5b19d94e80c6"
  :revdesc "f6dd0e067245"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
