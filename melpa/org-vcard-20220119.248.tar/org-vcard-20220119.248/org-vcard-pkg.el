(define-package "org-vcard" "20220119.248" "org-mode support for vCard export and import." 'nil :commit "74fc34319ce26455f58c7ae476b482d323796276" :authors
  '(("Alexis" . "flexibeast@gmail.com")
    ("Will Dey" . "will123dey@gmail.com"))
  :maintainer
  '("Alexis" . "flexibeast@gmail.com")
  :keywords
  '("outlines" "org" "vcard")
  :url "https://github.com/flexibeast/org-vcard")
;; Local Variables:
;; no-byte-compile: t
;; End:
