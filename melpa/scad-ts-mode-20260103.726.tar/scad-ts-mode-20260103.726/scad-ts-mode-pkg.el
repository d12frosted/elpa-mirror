;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-ts-mode" "20260103.726"
  "Tree-sitter support for OpenSCAD."
  '((emacs "29.3"))
  :url "https://github.com/yoshinari-nomura/scad-ts-mode"
  :commit "0cf2aed540b9e380b3724247daf8917ed3563e57"
  :revdesc "0cf2aed540b9"
  :keywords '("openscad" "languages" "tree-sitter")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
