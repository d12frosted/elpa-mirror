(define-package "stgit" "20230525.1553" "major mode for StGit interaction" 'nil :commit "d34715b1f63643ed5f13516df614aa729bd65fd8" :authors
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainers
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainer
  '("David Kågedal" . "davidk@lysator.liu.se")
  :url "http://stacked-git.github.io")
;; Local Variables:
;; no-byte-compile: t
;; End:
