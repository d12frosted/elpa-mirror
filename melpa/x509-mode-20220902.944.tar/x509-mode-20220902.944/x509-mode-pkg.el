(define-package "x509-mode" "20220902.944" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "24.3"))
  :commit "b36972277db97efe00b3b54c43db7070177dc54c" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
