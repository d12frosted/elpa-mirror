(define-package "chezmoi" "20220310.2014" "A package for interacting with chezmoi"
  '((emacs "26.1"))
  :commit "781783c483bc8fcdba3a230bb774c3a8a5ebe396" :authors
  '(("Harrison Pielke-Lombardo"))
  :maintainer
  '("Harrison Pielke-Lombardo")
  :keywords
  '("vc")
  :url "http://www.github.com/tuh8888/chezmoi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
