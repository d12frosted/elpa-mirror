;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250217.1508"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "4dd221e506be3856d69fba1c6185eb0c7f5fa194"
  :revdesc "4dd221e506be"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
