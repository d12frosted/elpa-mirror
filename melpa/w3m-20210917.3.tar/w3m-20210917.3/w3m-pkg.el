(define-package "w3m" "20210917.3" "an Emacs interface to w3m" 'nil :commit "3925d1c98338bdca35bbc489239a89ad1eee3d90" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
