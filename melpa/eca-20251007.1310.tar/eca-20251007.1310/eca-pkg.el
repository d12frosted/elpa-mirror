;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251007.1310"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "ad351ee99e9d4392e1e4559a0864cae7d75bd176"
  :revdesc "ad351ee99e9d"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
