(define-package "modus-themes" "20220716.1452" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "d4148687be79f60da2c15eac7a45f1ae3dd8f017" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
