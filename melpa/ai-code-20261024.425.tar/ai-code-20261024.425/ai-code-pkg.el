;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261024.425"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "365afd5d8cbd97731fbab9ca7580c87d62dd2251"
  :revdesc "365afd5d8cbd"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
