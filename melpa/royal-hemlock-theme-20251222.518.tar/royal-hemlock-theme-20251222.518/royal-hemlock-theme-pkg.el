;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "20251222.518"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "d085e5382fcb2cf211f06ec7a2c88c12451d1041"
  :revdesc "d085e5382fcb"
  :keywords '("color" "theme" "faces"))
