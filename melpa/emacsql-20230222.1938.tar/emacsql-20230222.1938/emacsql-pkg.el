(define-package "emacsql" "20230222.1938" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "497971121afcadbae6246fb842d1e6d22e3c05ad" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
