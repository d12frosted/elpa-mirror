;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260604.1359"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "0f5e2f8579316d688bf68b88d0d6fcc38a6bfa39"
  :revdesc "0f5e2f857931"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
