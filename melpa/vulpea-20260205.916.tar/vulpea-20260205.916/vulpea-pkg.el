;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260205.916"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "4d308ab92708013378f9b7fdbde6f48cbde4fc7b"
  :revdesc "4d308ab92708"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
