;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260415.10"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "7c93d84251c855078600c2c6b1ec64e42ccc3874"
  :revdesc "7c93d84251c8"
  :keywords '("convenience" "chinese" "input-method" "rime"))
