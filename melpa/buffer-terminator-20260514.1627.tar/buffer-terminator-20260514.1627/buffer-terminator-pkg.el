;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260514.1627"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "e3b52f9e2db7079184f968bcf4716101fd563fef"
  :revdesc "e3b52f9e2db7"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
