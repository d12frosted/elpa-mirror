(define-package "graphviz-dot-mode" "20230201.1506" "Mode for the dot-language used by graphviz (att)."
  '((emacs "25.0"))
  :commit "ba26ee946f4a887f7473c0d42c8d61aaa08a1106" :maintainer
  '("Pieter Pareit" . "pieter.pareit@gmail.com")
  :keywords
  '("mode" "dot" "dot-language" "dotlanguage" "graphviz" "graphs" "att")
  :url "https://ppareit.github.io/graphviz-dot-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
