;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260602.2144"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "503907809112e5c7d4cd3f0b57248e8cd57c5976"
  :revdesc "503907809112"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
