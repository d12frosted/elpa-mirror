;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expui-icons" "20261116.332"
  "Icons from IntelliJ's New UI."
  '((emacs "29.1"))
  :url "https://github.com/wwulfric/expui-icons"
  :commit "9625cc10d5c588b7429cae6fa52a17d093f4d6ce"
  :revdesc "9625cc10d5c5"
  :keywords '("convenience" "files")
  :authors '(("Lufei Wang" . "wwulfric@gmail.com"))
  :maintainers '(("Lufei Wang" . "wwulfric@gmail.com")))
