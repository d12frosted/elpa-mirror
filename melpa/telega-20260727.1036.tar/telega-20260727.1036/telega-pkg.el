;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260727.1036"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "878ae3c7acdc3edcf6d7ac89695473888a4a0103"
  :revdesc "878ae3c7acdc"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
