(define-package "humanoid-themes" "20220112.1138" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "3871746b51772c95b4419e978af069570c914f95" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
