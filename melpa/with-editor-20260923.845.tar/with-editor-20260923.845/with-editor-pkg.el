;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-editor" "20260923.845"
  "Use the Emacsclient as $EDITOR."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/magit/with-editor"
  :commit "3195a545b6c9bec7f3fbb68eaba14a172e0ea3ef"
  :revdesc "3195a545b6c9"
  :keywords '("processes" "terminals")
  :authors '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev")))
