;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250620.233"
  "AI assisted programming with Aider and LLM."
  '((emacs         "26.1")
    (transient     "0.9.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "e9f97d226435bdf6c947294ed63a3f862aa9e2f5"
  :revdesc "e9f97d226435"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
