;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260704.619"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "614e035d1c8a617c53499b865a82779c957d6426"
  :revdesc "614e035d1c8a"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
