;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20261018.108"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.10.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "b57aec83ba231fcbcafff5e63a49d19eba98e06a"
  :revdesc "b57aec83ba23"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
