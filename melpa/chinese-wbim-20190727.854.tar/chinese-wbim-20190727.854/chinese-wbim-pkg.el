(define-package "chinese-wbim" "20190727.854" "Enable Wubi Input Method in Emacs." 'nil :commit "5d496364b0b6bbaaf0f9b37e5a6d260d4994f260")
;; Local Variables:
;; no-byte-compile: t
;; End:
