;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260305.455"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "87851da1fb3095359b2e595293b12e615f8685c5"
  :revdesc "87851da1fb30"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
