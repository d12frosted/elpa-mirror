(define-package "racket-mode" "20220527.1605" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "2a76aa04c0105b6d53ab71d6ffbd37196f77d9e5" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
