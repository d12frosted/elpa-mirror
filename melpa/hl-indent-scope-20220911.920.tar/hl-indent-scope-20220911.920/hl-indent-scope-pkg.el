(define-package "hl-indent-scope" "20220911.920" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "c8fd8bc602d71050d4e953ddd8922583081745ad" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
