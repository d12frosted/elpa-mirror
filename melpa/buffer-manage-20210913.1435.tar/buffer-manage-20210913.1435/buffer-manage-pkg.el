(define-package "buffer-manage" "20210913.1435" "Manage buffers"
  '((emacs "26.1")
    (choice-program "0.13")
    (dash "2.17.0"))
  :commit "08ae381c388acb0bf98866a7283986ef293fe780" :authors
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("internal" "maint")
  :url "https://github.com/plandes/buffer-manage")
;; Local Variables:
;; no-byte-compile: t
;; End:
