;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-spectacle" "20250218.1032"
  "Spectacle.js Presentation Back-End for Org Export Engine."
  '((emacs "28.1")
    (org   "8.3"))
  :url "https://github.com/lorniu/ox-spectacle"
  :commit "42bf787371560f89bdffafcec689f133a13b63ea"
  :revdesc "42bf78737156"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
