;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark-consult" "20260330.1903"
  "Consult integration for Embark."
  '((emacs   "29.1")
    (compat  "30")
    (embark  "1.1")
    (consult "3.2"))
  :url "https://github.com/oantolin/embark"
  :commit "3c49062623eab04da95bfb4f51cea4c61c8bcf94"
  :revdesc "3c49062623ea"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
