(define-package "zero-input" "20240527.437" "Zero Chinese input method framework"
  '((emacs "24.4")
    (s "1.2.0"))
  :commit "e8d7f3af0fb3a30464fe8239c29b152b3809369b" :url "https://gitlab.emacsos.com/sylecn/zero-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
