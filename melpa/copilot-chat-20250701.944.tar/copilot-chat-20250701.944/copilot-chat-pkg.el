;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20250701.944"
  "Copilot chat interface."
  '((emacs         "29.1")
    (aio           "1.0")
    (request       "0.3.2")
    (transient     "0.8.3")
    (polymode      "0.2.2")
    (org           "9.4.6")
    (markdown-mode "2.6")
    (shell-maker   "0.76.2"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "ddbaa2a5c4409853502bca795c508a11facc4bfa"
  :revdesc "ddbaa2a5c440"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
