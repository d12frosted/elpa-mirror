;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ycm" "20140904.1817"
  "Company-ycm."
  '((ycm "0.1"))
  :url "https://github.com/neuromage/ycm.el"
  :commit "b2cb611503cf8d256fa19fc76362d7d5d9449d01"
  :revdesc "b2cb611503cf"
  :keywords '("abbrev")
  :authors '(("Ajay Gopinathan" . "ajay@gopinathan.net"))
  :maintainers '(("Ajay Gopinathan" . "ajay@gopinathan.net")))
