(define-package "projection" "20230826.1902" "Project type support for `project'"
  '((emacs "29")
    (project "0.9.8")
    (compat "29.1.4.1")
    (f "0.20"))
  :commit "363d3f79386735ae224c3692d333bc9d2a98f7f3" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
