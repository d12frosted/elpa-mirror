;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260529.56"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "dae41e9856768e79eb47acf8cc1ae4dd33f6c9a1"
  :revdesc "dae41e985676"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
