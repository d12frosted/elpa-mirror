(define-package "dwim-shell-command" "20230407.1000" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "a4386911668eaccf726a3024d989863be49b62c4" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
