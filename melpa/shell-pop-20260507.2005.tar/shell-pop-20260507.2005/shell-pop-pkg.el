;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260507.2005"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "db3597ff8437755542d5ed5ceb44a5114ee5e01a"
  :revdesc "db3597ff8437"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
