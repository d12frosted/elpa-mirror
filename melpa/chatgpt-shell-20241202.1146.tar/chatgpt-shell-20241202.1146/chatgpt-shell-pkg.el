;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241202.1146"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.72.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "57d390eef75650246c6bbf1a3c519273bb4fccf0"
  :revdesc "57d390eef756")
