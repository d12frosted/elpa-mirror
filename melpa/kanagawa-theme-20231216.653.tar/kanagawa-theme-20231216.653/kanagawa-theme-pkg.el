(define-package "kanagawa-theme" "20231216.653" "An elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa"
  '((emacs "24.3"))
  :commit "1df3d7651b2251743b57c7844ff182d4e0c0d34d" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/meritamen/emacs-kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
