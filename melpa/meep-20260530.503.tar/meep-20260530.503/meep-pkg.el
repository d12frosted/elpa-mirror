;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260530.503"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a4a8f4c8960cc2884f239ca7901102e54fedc8e2"
  :revdesc "a4a8f4c8960c"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
