(define-package "dall-e-shell" "20231112.449" "Interaction mode for DALL-E"
  '((emacs "27.1")
    (shell-maker "0.44.1"))
  :commit "bca784daa620767b5e57a5020289cb547c40f8b3" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
