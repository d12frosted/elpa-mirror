;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ros-face" "20260327.1536"
  "Syntax highlighting for ROS files."
  '((emacs "27.1"))
  :url "https://github.com/smallwat3r/emacs-ros-mode"
  :commit "9278a711a8846b665b3e385f6cc8c51afd3f64cb"
  :revdesc "9278a711a884"
  :keywords '("languages" "ros" "robotics")
  :authors '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com"))
  :maintainers '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com")))
