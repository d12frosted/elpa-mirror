(define-package "org-runbook" "20201229.1905" "Org mode for runbooks"
  '((emacs "25.1")
    (seq "2.3")
    (f "0.20.0")
    (s "1.12.0")
    (dash "2.17.0")
    (mustache "0.24")
    (ht "0.9"))
  :commit "63cf17f35d81f78f9ce10f8c99288b978982d4dc" :authors
  (("Tyler Dodge"))
  :maintainer
  ("Tyler Dodge")
  :keywords
  ("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
