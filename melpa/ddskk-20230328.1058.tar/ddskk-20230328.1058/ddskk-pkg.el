(define-package "ddskk" "20230328.1058" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "98c103ed697e461439401f731c13b3bda02e5128" :authors
  '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp"))
  :maintainer
  '("SKK Development Team")
  :keywords
  '("japanese" "mule" "input method")
  :url "https://github.com/skk-dev/ddskk")
;; Local Variables:
;; no-byte-compile: t
;; End:
