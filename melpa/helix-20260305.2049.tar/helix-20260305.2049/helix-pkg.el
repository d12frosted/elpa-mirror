;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "20260305.2049"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "856c79810532a075a7fc8aff3d86802b2adbbedd"
  :revdesc "856c79810532"
  :keywords '("convenience"))
