(define-package "phi-search-mc" "20160324.1503" "multiple-cursors extension for phi-search"
  '((phi-search "2.0.0")
    (multiple-cursors "1.2.1"))
  :commit "7aa671910f766437089aec26c3aa7814222d1356" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("search" "cursors")
  :url "https://github.com/knu/phi-search-mc.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
