;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260930.742"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f1860ff4c0db2f63f5aa7b7d55d0eeec98c49453"
  :revdesc "f1860ff4c0db"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
