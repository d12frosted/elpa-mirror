;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idle-highlight-in-visible-buffers-mode" "20240107.1344"
  "Highlight the word the point is on."
  ()
  :url "https://github.com/ignacy/idle-highlight-in-visible-buffers"
  :commit "f1f7ed3148439398adc6c0fe8ecf100d976886e6"
  :revdesc "f1f7ed314843"
  :keywords '("convenience"))
