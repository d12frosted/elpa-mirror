;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-rails" "20260425.1314"
  "Rails support for project.el."
  '((emacs       "28.1")
    (inflections "2.6"))
  :url "https://github.com/harrybournis/project.el-rails"
  :commit "2c72764790f9f6f283f713bb72a9f4952ced690d"
  :revdesc "2c72764790f9"
  :keywords '("languages" "project.el" "rails")
  :authors '(("Harry Bournis" . "harrybournis@gmail.com"))
  :maintainers '(("Harry Bournis" . "harrybournis@gmail.com")))
