(define-package "org-anki" "20230617.850" "Synchronize org-mode entries to Anki"
  '((emacs "27.1")
    (request "0.3.2")
    (dash "2.17")
    (promise "1.1"))
  :commit "807f49607882abf38907b6290661b1b46e1f97cd" :authors
  '(("Markus Läll" . "markus.l2ll@gmail.com"))
  :maintainers
  '(("Markus Läll" . "markus.l2ll@gmail.com"))
  :maintainer
  '("Markus Läll" . "markus.l2ll@gmail.com")
  :keywords
  '("outlines" "flashcards" "memory")
  :url "https://github.com/eyeinsky/org-anki")
;; Local Variables:
;; no-byte-compile: t
;; End:
