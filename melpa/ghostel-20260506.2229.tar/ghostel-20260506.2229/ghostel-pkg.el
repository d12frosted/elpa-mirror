;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260506.2229"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5bce751687f3b33978a4244a1611648bbedb7124"
  :revdesc "5bce751687f3"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
