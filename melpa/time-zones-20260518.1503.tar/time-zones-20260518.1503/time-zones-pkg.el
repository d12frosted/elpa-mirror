;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-zones" "20260518.1503"
  "Time zone lookups."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/time-zones"
  :commit "4ec11f912d8af920d021c6189e59ab74fd404a2d"
  :revdesc "4ec11f912d8a")
