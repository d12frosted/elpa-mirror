(define-package "modaled" "20230617.130" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "8f51ea76542580cc8dc24781701c1c1e97ff4edf" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
