(define-package "epkg" "20211119.21" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "eac43b29286e05192cbeada4cad09774493e0ab7" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
