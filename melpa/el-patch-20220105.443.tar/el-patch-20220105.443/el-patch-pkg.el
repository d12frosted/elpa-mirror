(define-package "el-patch" "20220105.443" "Future-proof your Elisp"
  '((emacs "25"))
  :commit "f2739ec466ed438dad9c7bed46f4eff9aa379c5a" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/el-patch")
;; Local Variables:
;; no-byte-compile: t
;; End:
