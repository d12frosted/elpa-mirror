;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20250223.1046"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.22.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "ad88edf9edc313f10107c45a8a21ecf6b6b6d139"
  :revdesc "ad88edf9edc3"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
