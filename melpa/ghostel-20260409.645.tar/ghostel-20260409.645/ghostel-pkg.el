;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260409.645"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "512a4db0e6d330daab946853cf0bfbb5e9890139"
  :revdesc "512a4db0e6d3"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
