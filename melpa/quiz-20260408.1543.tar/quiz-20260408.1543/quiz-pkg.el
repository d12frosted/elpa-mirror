;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quiz" "20260408.1543"
  "Multiple choice quiz game."
  '((emacs "25.1"))
  :url "https://github.com/davep/quiz.el"
  :commit "9630cfbf0c2a0ee47d5ea146aeac0fe62e8d4a37"
  :revdesc "9630cfbf0c2a"
  :keywords '("games" "trivia" "quiz")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
