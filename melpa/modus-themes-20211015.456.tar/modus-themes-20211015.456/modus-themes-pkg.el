(define-package "modus-themes" "20211015.456" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "5ea090b223e8a83f7f3800a96bd4ed3ac9d62230" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
