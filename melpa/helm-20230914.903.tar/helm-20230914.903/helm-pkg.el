(define-package "helm" "20230914.903" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.4")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "d093dae2b0e69d0d5d8170575639d14711b7ad40" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
