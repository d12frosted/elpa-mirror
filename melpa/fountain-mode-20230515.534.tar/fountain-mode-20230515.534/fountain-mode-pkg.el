(define-package "fountain-mode" "20230515.534" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "e38fb7f13947aa9c61a109b25656176915c85b8e" :authors
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainers
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainer
  '("Paul W. Rankin" . "hello@paulwrankin.com")
  :keywords
  '("wp" "text")
  :url "https://github.com/rnkn/fountain-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
