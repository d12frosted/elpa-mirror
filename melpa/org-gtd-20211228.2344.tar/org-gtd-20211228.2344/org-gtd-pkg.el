(define-package "org-gtd" "20211228.2344" "An implementation of GTD."
  '((emacs "27.1")
    (org-edna "1.1.2")
    (f "0.20.0")
    (org "9.3.1")
    (org-agenda-property "1.3.1")
    (transient "0.3.7"))
  :commit "9ea3d97740233aa1e9c7a38a55556840d2ed1fed" :authors
  '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainer
  '("Aldric Giacomoni" . "trevoke@gmail.com")
  :url "https://github.com/Trevoke/org-gtd.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
