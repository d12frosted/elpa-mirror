;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260128.1335"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "9914611c8b431a55b33abe74392bf83ba5184cea"
  :revdesc "9914611c8b43"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
