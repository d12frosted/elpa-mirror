(define-package "cnfonts" "20230215.649" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "f2b05510223e73bf9ba9b2f5e144ba29d73778af" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
