(define-package "project-persist-drawer" "20151108.1222" "Use a project drawer with project-persist."
  '((project-persist "0.3"))
  :commit "35bbe132a4fab6a0fec15ce6c0fd2fe6a4aa9626")
;; Local Variables:
;; no-byte-compile: t
;; End:
