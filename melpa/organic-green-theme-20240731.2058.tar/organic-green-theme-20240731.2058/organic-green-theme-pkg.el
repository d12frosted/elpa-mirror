;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20240731.2058"
  "Low-contrast green color theme."
  ()
  :url "https://gitlab.com/kostafey/organic-green-theme"
  :commit "8ea2fea0aea27d67448440f22b4ccdf6f9e6e8f6"
  :revdesc "8ea2fea0aea2")
