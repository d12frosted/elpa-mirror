;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "temporary-persistent" "20230115.1425"
  "Keep temp notes buffers persistent."
  '((emacs "24.3")
    (names "20151201.0")
    (dash  "2.12.1")
    (s     "1.10.0"))
  :url "https://github.com/kostafey/temporary-persistent"
  :commit "edbde738769e79ac212ae84ae7898ffd5f19e0f1"
  :revdesc "edbde738769e"
  :keywords '("temp" "buffers" "notes")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
