(define-package "ibrowse" "20230810.2319" "Interact with your browser"
  '((emacs "27.1"))
  :commit "9601311998b493f29c7ed690d5f0341d4dd1d62b" :authors
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainers
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainer
  '("Nicolas Graves" . "ngraves@ngraves.fr")
  :keywords
  '("comm" "data" "files" "tools")
  :url "https://git.sr.ht/~ngraves/ibrowse.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
