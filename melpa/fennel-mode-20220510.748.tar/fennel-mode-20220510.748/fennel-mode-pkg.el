(define-package "fennel-mode" "20220510.748" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "0e9ed013a163d91993a2883ad5c37c02694c2b92" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
