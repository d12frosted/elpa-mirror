(define-package "maxima" "20201207.2204" "Major mode for Maxima"
  '((emacs "25.1")
    (s "1.11.0")
    (test-simple "1.3.0"))
  :commit "878132db3c9e0b5675888eedece1c7aa4246df43" :keywords
  ("maxima" "tools" "math")
  :authors
  (("William F. Schelter")
   ("Jay Belanger")
   ("Fermin Munoz"))
  :maintainer
  ("Fermin Munoz" . "fmfs@posteo.net")
  :url "https://gitlab.com/sasanidas/maxima")
;; Local Variables:
;; no-byte-compile: t
;; End:
