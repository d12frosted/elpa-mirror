;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soccer" "20260811.1656"
  "Fixtures, results, table etc for soccer."
  '((emacs "29.1"))
  :url "https://github.com/md-arif-shaikh/soccer"
  :commit "c4efa01659865e612354272d332daef62a779889"
  :revdesc "c4efa0165986"
  :keywords '("games" "soccer" "football")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
