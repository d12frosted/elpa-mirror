;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "suggest" "20251127.2010"
  "Suggest elisp functions that give the output requested."
  '((emacs   "24.4")
    (loop    "1.3")
    (dash    "2.13.0")
    (s       "1.11.0")
    (f       "0.18.2")
    (spinner "1.7.3"))
  :url "https://github.com/Wilfred/suggest.el"
  :commit "2bac1370c605edf004842d94bc094ff8ee7ab118"
  :revdesc "2bac1370c605"
  :keywords '("convenience")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
