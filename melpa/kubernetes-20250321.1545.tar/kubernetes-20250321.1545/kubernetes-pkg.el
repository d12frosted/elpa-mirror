;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubernetes" "20250321.1545"
  "Magit-like porcelain for Kubernetes."
  '((dash          "2.12.0")
    (magit-section "3.1.1")
    (magit-popup   "2.13.0")
    (with-editor   "3.0.4")
    (request       "0.3.2")
    (s             "1.12.0")
    (transient     "0.3.0"))
  :url "https://github.com/kubernetes-el/kubernetes-el"
  :commit "e571cb665bb8098e74aa54f1751af6ed518c55c0"
  :revdesc "e571cb665bb8"
  :keywords '("kubernetes")
  :authors '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainers '(("Chris Barrett" . "chris+emacs@walrus.cool")
                 ("Noorul Islam K M" . "noorul@noorul.com")
                 ("Jonathan Jin" . "me@jonathanj.in")))
