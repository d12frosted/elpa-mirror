;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260209.1631"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "63ff86eab61f484febcc61c280ad3f0441e32b88"
  :revdesc "63ff86eab61f"
  :keywords '("convenience"))
