(define-package "lsp-dart" "20210306.1653" "Dart support lsp-mode"
  '((emacs "26.1")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (pkg-info "0.4")
    (dart-mode "1.0.5"))
  :commit "d412387ae4520094e3767772a8fac019c64835e1" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
