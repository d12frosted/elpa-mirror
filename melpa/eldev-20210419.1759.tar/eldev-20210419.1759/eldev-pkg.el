(define-package "eldev" "20210419.1759" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "b2a797db9b7c74ce1a3c1a4b567c87afce6623e1" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
