;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-chatgpt-shell" "20241031.948"
  "Org babel functions for ChatGPT evaluation."
  '((emacs         "27.1")
    (chatgpt-shell "1.17.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "feb2c85d75a5cf3877aa351744390f16909a67ee"
  :revdesc "feb2c85d75a5")
