(define-package "weblorg" "20210211.255" "Static Site Generator for org-mode"
  '((templatel "0.1.4")
    (emacs "26.1"))
  :commit "95ee894dea36ac1f0d39266169123ee1ba7674ed" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
