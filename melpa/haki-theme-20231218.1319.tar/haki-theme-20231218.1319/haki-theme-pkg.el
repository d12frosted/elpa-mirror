(define-package "haki-theme" "20231218.1319" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "66444ae7b4b64a455f424258cf25b7e1371fe5ad" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
