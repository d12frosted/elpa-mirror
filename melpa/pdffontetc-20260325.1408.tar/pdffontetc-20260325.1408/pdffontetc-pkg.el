;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdffontetc" "20260325.1408"
  "Display `pdffont' and other PDF information."
  '((emacs     "24.4")
    (pdf-tools "1.2.0"))
  :url "https://github.com/emacsomancer/pdffontetc"
  :commit "b2db6c1377c080d9425836efa19690df3eb44516"
  :revdesc "b2db6c1377c0"
  :keywords '("files" "multimedia")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
