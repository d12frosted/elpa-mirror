(define-package "hl-prog-extra" "20220627.2301" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "c6f1ad55d12c5b726a797fa2216d4ddb3a261764" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
