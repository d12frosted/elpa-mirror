;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "le-gpt" "20260201.2209"
  "Emacs on steroids with GPT."
  '((emacs         "28.1")
    (markdown-mode "2.6"))
  :url "https://github.com/AnselmC/le-gpt.el"
  :commit "5524d16478ab020d6795dacbabd82e9cebfa06fd"
  :revdesc "5524d16478ab"
  :keywords '("openai" "anthropic" "deepseek" "gpt" "claude" "language" "copilot" "convenience" "tools" "llm")
  :authors '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainers '(("Anselm Coogan" . "anselm.coogan@gmail.com")))
