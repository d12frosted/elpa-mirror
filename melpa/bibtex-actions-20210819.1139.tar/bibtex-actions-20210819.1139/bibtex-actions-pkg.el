(define-package "bibtex-actions" "20210819.1139" "Biblographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0")
    (parsebib "3.0"))
  :commit "31d2d21f3b0e827368cb7655dba8645ee6b205d3" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
