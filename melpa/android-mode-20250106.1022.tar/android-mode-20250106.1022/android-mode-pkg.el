;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "android-mode" "20250106.1022"
  "Minor mode for Android application development."
  ()
  :url "https://codeberg.org/rwv/android-mode"
  :commit "67f7c0d7d37605efc7f055b76d731556861c3eb9"
  :revdesc "67f7c0d7d376"
  :keywords '("tools" "processes"))
