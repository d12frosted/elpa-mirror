;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260318.1740"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "9b6098e276f16a8f57dada1a4f93016df9409314"
  :revdesc "9b6098e276f1"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
