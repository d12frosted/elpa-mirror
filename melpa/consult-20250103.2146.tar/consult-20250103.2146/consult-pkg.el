;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250103.2146"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "ff4937ec7c311bc39542a31772c9b078a2f52041"
  :revdesc "ff4937ec7c31"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
