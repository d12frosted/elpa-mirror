;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260214.2007"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "4353258aca9ff63cd8f523a71965aea3d2d4685e"
  :revdesc "4353258aca9f"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
