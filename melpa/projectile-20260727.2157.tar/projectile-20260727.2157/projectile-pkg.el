;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260727.2157"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "13f9a59bf99d044d95de694bcc9d031d3198833c"
  :revdesc "13f9a59bf99d"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
