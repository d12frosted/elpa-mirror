;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250215.832"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "5e834b6fcfc56cb9cd32f45a5c2cd953b4e6d2fa"
  :revdesc "5e834b6fcfc5"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
