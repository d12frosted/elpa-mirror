;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261023.843"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "ecdd706515c588f9c0637dccc39943293c33c5c0"
  :revdesc "ecdd706515c5")
