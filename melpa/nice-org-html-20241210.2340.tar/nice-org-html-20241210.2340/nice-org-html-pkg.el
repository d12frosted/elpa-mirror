;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nice-org-html" "20241210.2340"
  "Prettier org-to-html export."
  '((emacs   "25.1")
    (s       "1.13.0")
    (dash    "2.19.1")
    (htmlize "1.58")
    (uuidgen "1.0"))
  :url "https://github.com/ewantown/nice-org-html"
  :commit "e9149a3712c4ebebe0c96c492d275ebb1872faf6"
  :revdesc "e9149a3712c4"
  :keywords '("org" "org-export" "html" "css" "js" "tools")
  :authors '(("Ewan Townshend" . "ewan@etown.dev"))
  :maintainers '(("Ewan Townshend" . "ewan@etown.dev")))
