(define-package "jinx" "20240309.2134" "Enchanted Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "8432ec301d62d5acf4558cd5ac5d518be7808af2" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "text")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
