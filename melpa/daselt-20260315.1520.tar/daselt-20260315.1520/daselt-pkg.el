;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260315.1520"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "2ab1d67a9970f4f410362921da2781e410d93290"
  :revdesc "2ab1d67a9970"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
