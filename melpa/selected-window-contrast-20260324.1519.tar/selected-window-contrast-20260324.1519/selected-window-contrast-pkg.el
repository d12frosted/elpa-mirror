;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260324.1519"
  "Highlight window and cursor at switching."
  '((emacs "26.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "63bbc256a582046e78b47f10410978f7afb94907"
  :revdesc "63bbc256a582"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
