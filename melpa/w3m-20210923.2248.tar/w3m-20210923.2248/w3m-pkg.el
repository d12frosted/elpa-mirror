(define-package "w3m" "20210923.2248" "an Emacs interface to w3m" 'nil :commit "f118e8c7bb23cf1d8303dfab5b8c51206b7bc970" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
