;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solaire-mode" "20260829.1840"
  "Make certain buffers grossly incandescent."
  '((emacs  "27.1")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-solaire-mode"
  :commit "1a4e5a93b3ec280cf05aa36e39ad4c3b4e115fd4"
  :revdesc "1a4e5a93b3ec"
  :keywords '("dim" "bright" "window" "buffer" "faces")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
