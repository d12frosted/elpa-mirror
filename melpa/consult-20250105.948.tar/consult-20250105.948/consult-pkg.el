;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250105.948"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "f7731508aa934364d48f593da8969d5ce0431f40"
  :revdesc "f7731508aa93"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
