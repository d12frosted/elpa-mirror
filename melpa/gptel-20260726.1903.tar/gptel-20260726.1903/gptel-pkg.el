;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260726.1903"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "c91454c7b955f3ca8285375e937aa9b50c91c206"
  :revdesc "c91454c7b955"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
