;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20241201.1739"
  "Fuzzy completion style using `flx'."
  '((emacs "28.2")
    (flx   "0.5"))
  :url "https://github.com/jojojames/fussy"
  :commit "545c61d41506f44a6fd1cedd9314d41833599c03"
  :revdesc "545c61d41506"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
