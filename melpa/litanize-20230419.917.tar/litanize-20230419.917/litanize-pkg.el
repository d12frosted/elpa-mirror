;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "litanize" "20230419.917"
  "Generate \"Latour Litanies\"."
  '((emacs  "24.1")
    (enlive "0.0.1")
    (s      "1.12.0"))
  :url "https://github.com/zzkt/litanizer"
  :commit "a45902fa29c16ef9606229cb01a5441ea754f11b"
  :revdesc "a45902fa29c1"
  :keywords '("tools" "latour litany" "alien phenomenology" "ontography" "metaphorism" "carpentry")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
