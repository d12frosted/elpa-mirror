(define-package "notmuch" "20210830.2334" "run notmuch within emacs" 'nil :commit "9c4037ff193a4015fc132ceb7918e6b8274cfb8c" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
