(define-package "notmuch" "20210830.2334" "run notmuch within emacs" 'nil :commit "005c6201184c539d23d076303bd360bdba412e48" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
