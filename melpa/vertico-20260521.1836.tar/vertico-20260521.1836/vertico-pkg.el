;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20260521.1836"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "9132ab8a7e294a04d411cbcd67902052210eb14d"
  :revdesc "9132ab8a7e29"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
