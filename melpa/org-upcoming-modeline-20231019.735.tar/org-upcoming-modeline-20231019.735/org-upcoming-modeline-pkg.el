(define-package "org-upcoming-modeline" "20231019.735" "Show next org event in mode line"
  '((emacs "26.1")
    (ts "0.2")
    (org-ql "0.6"))
  :commit "136a6a76d770d351559091c8d9ad5a189f1f2622" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("convenience" "calendar")
  :url "https://github.com/unhammer/org-upcoming-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
