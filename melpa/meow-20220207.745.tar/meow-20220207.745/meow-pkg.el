(define-package "meow" "20220207.745" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "cca4dd751a26715b60237c4904031a25a7c89216" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
