(define-package "alectryon" "20210925.414" "Toggle between Coq and reStructuredText"
  '((flycheck "31")
    (emacs "25.1"))
  :commit "0508d5a0e6e18cd6e489506d98730a9aaa6541a2" :authors
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://github.com/cpitclaudel/alectryon")
;; Local Variables:
;; no-byte-compile: t
;; End:
