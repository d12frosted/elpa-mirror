;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250526.1330"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "7fe870a97381c25846e5920d23262fed28d016cd"
  :revdesc "7fe870a97381"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
