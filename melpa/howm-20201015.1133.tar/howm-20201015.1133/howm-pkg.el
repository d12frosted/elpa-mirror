(define-package "howm" "20201015.1133" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "ce77dfbb50815d55081b2462541954d11a76f308" :authors
  (("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  ("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
