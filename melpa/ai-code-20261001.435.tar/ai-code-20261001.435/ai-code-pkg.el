;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261001.435"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "ae17d6215d9e5b441a03e7066a56413aa25da47c"
  :revdesc "ae17d6215d9e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
