(define-package "ob-ess-julia" "20201109.911" "Org babel support for Julia language"
  '((ess "20201004.1522")
    (julia-mode "0.4"))
  :commit "b97ebf19c3d68ff946584e78ab7943f8a691ebe5" :authors
  '(("Frédéric Santos"))
  :maintainer
  '("Frédéric Santos")
  :keywords
  '("languages")
  :url "https://github.com/frederic-santos/ob-ess-julia")
;; Local Variables:
;; no-byte-compile: t
;; End:
