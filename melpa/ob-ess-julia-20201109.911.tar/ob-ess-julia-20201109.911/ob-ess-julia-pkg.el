(define-package "ob-ess-julia" "20201109.911" "Org babel support for Julia language"
  '((ess "20201004.1522")
    (julia-mode "0.4"))
  :commit "862f34da39faae87fc0900bb7006fb20fbd2b61a" :authors
  (("Frédéric Santos"))
  :maintainer
  ("Frédéric Santos")
  :keywords
  ("languages")
  :url "https://github.com/frederic-santos/ob-ess-julia")
;; Local Variables:
;; no-byte-compile: t
;; End:
