(define-package "fanyi" "20210827.437" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "7925cbc0d2e1befb5136523c229482ff35ee061f" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
