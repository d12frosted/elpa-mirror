;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261112.2345"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "23caf0f9014aedfb4f714d96445e3a2d2f72a704"
  :revdesc "23caf0f9014a"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
