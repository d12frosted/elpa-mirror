(define-package "dirvish" "20220603.630" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a2ed0e7216da3200143d373ec60953779ab348b0" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
