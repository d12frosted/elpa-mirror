(define-package "f" "20220531.2234" "Modern API for working with files and directories"
  '((s "1.7.0")
    (dash "2.2.0"))
  :commit "feb6c2cb9f8e19ebdfdfde0d89edbdd5d7f51a96" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("files" "directories")
  :url "http://github.com/rejeep/f.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
