(define-package "emacsc" "20190917.1102" "helper for emacsc(1)" 'nil :commit "57940b93881efabb375df18093b99800bfb5d5f7" :authors
  (("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  ("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  ("tools")
  :url "https://github.com/knu/emacsc")
;; Local Variables:
;; no-byte-compile: t
;; End:
