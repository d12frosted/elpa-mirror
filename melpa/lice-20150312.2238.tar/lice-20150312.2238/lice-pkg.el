(define-package "lice" "20150312.2238" "License And Header Template" 'nil :commit "69f2d87984f3f3d469db35e241fbbe979384cd03" :authors
  '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainer
  '("Taiki Sugawara" . "buzz.taiki@gmail.com")
  :keywords
  '("template" "license" "tools")
  :url "https://github.com/buzztaiki/lice-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
