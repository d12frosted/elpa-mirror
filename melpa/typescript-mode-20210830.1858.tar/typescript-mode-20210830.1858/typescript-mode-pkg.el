(define-package "typescript-mode" "20210830.1858" "Major mode for editing typescript"
  '((emacs "24.3"))
  :commit "ab9c2e4fd0c544ed77e0537af936dc7388c556a2" :keywords
  '("typescript" "languages")
  :url "http://github.com/ananthakumaran/typescript.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
