;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-custom-cookies" "20240414.44"
  "Custom cookies for org-mode."
  '((emacs "25.1")
    (org   "9.4"))
  :url "https://github.com/gsingh93/org-custom-cookies"
  :commit "5650c73d20e53310dab62f6a65754a55aea9b40b"
  :revdesc "5650c73d20e5"
  :authors '(("Gulshan Singh" . "gsingh2011@gmail.com"))
  :maintainers '(("Gulshan Singh" . "gsingh2011@gmail.com")))
