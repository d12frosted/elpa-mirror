;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260602.602"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "59796c0cb42a2d73d3b8619679f96bc867334043"
  :revdesc "59796c0cb42a"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
