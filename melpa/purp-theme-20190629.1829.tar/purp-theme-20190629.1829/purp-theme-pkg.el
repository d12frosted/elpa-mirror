(define-package "purp-theme" "20190629.1829" "No description available." 'nil :commit "f821a7c30452d970ccb0ee08b68d56603860e31d")
;; Local Variables:
;; no-byte-compile: t
;; End:
