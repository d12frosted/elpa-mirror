(define-package "finito" "20211015.937" "View and collect books"
  '((emacs "27.1")
    (dash "2.17.0")
    (request "0.3.2")
    (f "0.2.0")
    (s "1.12.0")
    (transient "0.3.0")
    (graphql "0.1.1")
    (async "1.9.3"))
  :commit "21a492d3e67e5e3ab59b75107d345142a4c3ac02" :authors
  '(("Laurence Warne"))
  :maintainer
  '("Laurence Warne")
  :keywords
  '("outlines")
  :url "https://github.com/LaurenceWarne/finito.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
