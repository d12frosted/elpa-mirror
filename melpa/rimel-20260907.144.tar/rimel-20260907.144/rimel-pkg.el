;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260907.144"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.11"))
  :url "https://github.com/emacs-rime/rimel"
  :commit "af5cf35e0ed3f5cd3dc040bfc19051d564223e52"
  :revdesc "af5cf35e0ed3"
  :keywords '("convenience" "chinese" "input-method" "rime"))
