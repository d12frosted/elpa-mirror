;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260119.757"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d0e53d7171bcadf661c9242572cd75c7e8939382"
  :revdesc "d0e53d7171bc")
