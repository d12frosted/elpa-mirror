;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260926.1059"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "5cb062e183f93f5ebc03c1344255bbadc94f9b81"
  :revdesc "5cb062e183f9")
