(define-package "casual-isearch" "20240807.19" "Transient UI for I-Search"
  '((emacs "29.1")
    (casual-lib "1.1.0"))
  :commit "7ab1b52349d4968fdd766bcca86d28baa9325491" :authors
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainer
  '("Charles Choi" . "kickingvegas@gmail.com")
  :keywords
  '("wp")
  :url "https://github.com/kickingvegas/casual-isearch")
;; Local Variables:
;; no-byte-compile: t
;; End:
