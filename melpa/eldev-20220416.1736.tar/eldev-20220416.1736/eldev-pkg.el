(define-package "eldev" "20220416.1736" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "3f3feb94b426ade9f960f1a3a6d07e0b7a8dda80" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
