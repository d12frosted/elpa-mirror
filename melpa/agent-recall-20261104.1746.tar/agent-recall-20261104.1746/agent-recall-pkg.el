;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20261104.1746"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "eb61d58fcd13a8293474a4f2c0c16d487132f7bd"
  :revdesc "eb61d58fcd13"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
