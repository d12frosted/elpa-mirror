;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260727.800"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "daf6c3c0dd9ab5c2eec375dcfbadee9b1141639b"
  :revdesc "daf6c3c0dd9a"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
