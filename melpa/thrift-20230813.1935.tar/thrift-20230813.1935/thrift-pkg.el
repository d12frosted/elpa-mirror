(define-package "thrift" "20230813.1935" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "733edc209c7f7247a7ead46084346caa46c18867" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
