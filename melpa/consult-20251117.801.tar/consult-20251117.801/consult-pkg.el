;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20251117.801"
  "Consulting completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "3f22deae8ada064e94e91ff3bcf06fac90519667"
  :revdesc "3f22deae8ada"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
