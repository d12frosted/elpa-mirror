;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260713.2022"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "2191afe3049fc785c6fd2b1ab6b826daf500ffbe"
  :revdesc "2191afe3049f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
