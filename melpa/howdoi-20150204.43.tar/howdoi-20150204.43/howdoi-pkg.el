(define-package "howdoi" "20150204.43" "Instant coding answers via Emacs." 'nil :commit "5fbf7069ee160c597a328e5ce5fb32920e1ca88f")
;; Local Variables:
;; no-byte-compile: t
;; End:
