;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20250105.115"
  "LSP mode."
  '((emacs         "27.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "4a65b4bfc1698a740870e63d0ee8499740556ec1"
  :revdesc "4a65b4bfc169"
  :keywords '("languages"))
