;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241126.1501"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.71.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "16c678c117efc9ca0a606da0635a1a80093d2901"
  :revdesc "16c678c117ef")
