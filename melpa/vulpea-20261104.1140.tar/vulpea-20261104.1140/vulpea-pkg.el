;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261104.1140"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "be59d8f67a18cab4f09794031a55e7a0ae69087d"
  :revdesc "be59d8f67a18"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
