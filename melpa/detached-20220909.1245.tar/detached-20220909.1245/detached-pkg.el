(define-package "detached" "20220909.1245" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "e96156ab4a9540bd7d8e8e77af7773d52c7a001e" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
