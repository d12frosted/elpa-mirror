;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260725.754"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "7d25f9b2eab3d4b7267fb378084f53383d834b47"
  :revdesc "7d25f9b2eab3"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
