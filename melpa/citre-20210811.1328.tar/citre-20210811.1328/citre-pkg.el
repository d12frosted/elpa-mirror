(define-package "citre" "20210811.1328" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "200d402794c9404b571a533f726f18ff5a8cad55" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
