;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-octopress" "20170821.415"
  "Compose octopress articles using org-mode."
  '((org    "9.0")
    (orglue "0.1")
    (ctable "0.1.1"))
  :url "https://github.com/yoshinari-nomura/org-octopress"
  :commit "38598ef98d04076a8eb78d549907ddfde8d3a652"
  :revdesc "38598ef98d04"
  :keywords '("org" "jekyll" "octopress" "blog")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
