(define-package "org-octopress" "20170821.415" "Compose octopress articles using org-mode."
  '((org "9.0")
    (orglue "0.1")
    (ctable "0.1.1"))
  :commit "38598ef98d04076a8eb78d549907ddfde8d3a652" :keywords
  ("org" "jekyll" "octopress" "blog")
  :authors
  (("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainer
  ("Yoshinari Nomura" . "nom@quickhack.net"))
;; Local Variables:
;; no-byte-compile: t
;; End:
