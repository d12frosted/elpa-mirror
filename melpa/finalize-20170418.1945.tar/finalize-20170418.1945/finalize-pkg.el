(define-package "finalize" "20170418.1945" "finalizers for Emacs Lisp"
  '((emacs "24.1")
    (cl-generic "0.3")
    (cl-lib "0.3")
    (eieio "1.4"))
  :commit "846731531e7d1d80451787992e07bfe7dedbe9ff" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/elisp-finalize")
;; Local Variables:
;; no-byte-compile: t
;; End:
