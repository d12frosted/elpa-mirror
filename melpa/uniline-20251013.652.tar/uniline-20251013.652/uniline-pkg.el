;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20251013.652"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "cc53c929af7b52e38afdc793321e87049ccb043c"
  :revdesc "cc53c929af7b"
  :keywords '("convenience" "text"))
