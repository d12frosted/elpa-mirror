;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-gambit" "20220208.1356"
  "Gambit's implementation of the geiser protocols."
  '((emacs  "26.1")
    (geiser "0.18"))
  :url "https://gitlab.com/emacs-geiser/gambit"
  :commit "381d74ca5059b44fe3d8b5daf42214019c6d1a88"
  :revdesc "381d74ca5059"
  :keywords '("languages" "gambit" "scheme" "geiser")
  :maintainers '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
