(define-package "geiser-gambit" "20220208.1356" "Gambit's implementation of the geiser protocols"
  '((emacs "26.1")
    (geiser "0.18"))
  :commit "381d74ca5059b44fe3d8b5daf42214019c6d1a88" :authors
  '(("Daniel Leslie"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "gambit" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/gambit")
;; Local Variables:
;; no-byte-compile: t
;; End:
