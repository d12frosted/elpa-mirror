;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20250119.1512"
  "A q editing mode."
  '((emacs "24"))
  :url "https://github.com/psaris/q-mode"
  :commit "30a88340e72cda4f033a7e5f0e3a5aae8a1b195c"
  :revdesc "30a88340e72c"
  :keywords '("faces" "files" "q"))
