(define-package "eldev" "20220812.1735" "Elisp development tool"
  '((emacs "24.4"))
  :commit "66350f2711938ffebf2076018060da722478d9c1" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
