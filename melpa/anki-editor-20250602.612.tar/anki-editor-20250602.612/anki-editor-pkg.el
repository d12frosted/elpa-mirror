;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20250602.612"
  "Minor mode for making Anki cards with Org."
  '((emacs "29.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "24ff96ae9f625eedaa87737f9950e3a6e8bfc853"
  :revdesc "24ff96ae9f62")
