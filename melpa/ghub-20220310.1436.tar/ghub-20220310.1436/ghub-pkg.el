(define-package "ghub" "20220310.1436" "Minuscule client libraries for Git forge APIs."
  '((emacs "25.1")
    (let-alist "1.0.6")
    (treepy "0.1.1"))
  :commit "e3feb1befa2e8fa5376335ebaccdb06305a2c036" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
