(define-package "ghub" "20220310.1436" "Minuscule client libraries for Git forge APIs."
  '((emacs "25.1")
    (let-alist "1.0.6")
    (treepy "0.1.1"))
  :commit "fdbd339832fa0e6fbb6874993b3af40b4c6620e6" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
