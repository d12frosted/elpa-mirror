(define-package "gumshoe" "20210920.1523" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "be4dd10bc02be402498ceefe8df72dbe5dbc8ac5" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
