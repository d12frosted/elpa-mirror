(define-package "circe" "20210614.912" "Client for IRC in Emacs"
  '((emacs "24.4")
    (cl-lib "0.5"))
  :commit "d6f1fa18646f6ed2a1c0f06a4888130bd694ff19" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :keywords
  '("irc" "chat" "comm")
  :url "https://github.com/jorgenschaefer/circe")
;; Local Variables:
;; no-byte-compile: t
;; End:
