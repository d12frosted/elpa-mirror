;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260601.1941"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d6605ef85af545003c1c2f819578831518867086"
  :revdesc "d6605ef85af5")
