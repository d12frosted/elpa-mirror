;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-stages" "20210306.418"
  "Highlight staged (quasi-quoted) expressions."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "95daa710f3d8fc83f42c5da38003fc71ae0da1fc"
  :revdesc "95daa710f3d8")
