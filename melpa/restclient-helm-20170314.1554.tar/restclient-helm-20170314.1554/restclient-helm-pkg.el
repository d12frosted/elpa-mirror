;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restclient-helm" "20170314.1554"
  "Helm interface for restclient.el."
  '((restclient "0")
    (helm       "1.9.4"))
  :url "https://github.com/emacsorphanage/restclient"
  :commit "af7420085dd67ed08d199a2402e8ff3e996c3029"
  :revdesc "af7420085dd6"
  :keywords '("http" "helm")
  :authors '(("Pavel Kurnosov" . "pashky@gmail.com"))
  :maintainers '(("Pavel Kurnosov" . "pashky@gmail.com")))
