;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260625.510"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "4266923daf6f137fbe2897334b7669f7fb4633c8"
  :revdesc "4266923daf6f"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
