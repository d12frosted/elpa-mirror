;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260329.1552"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ad03affc4e799e2a1d75a0fbafb739a2da9c3bec"
  :revdesc "ad03affc4e79"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
