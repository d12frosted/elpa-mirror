(define-package "kurecolor" "20220815.438" "color editing goodies"
  '((emacs "28.1")
    (s "1.12"))
  :commit "903482e96f23e2c6cd833a6a93720df17874db5a" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
