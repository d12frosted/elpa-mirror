(define-package "notmuch" "20220616.1151" "run notmuch within emacs" 'nil :commit "d73ddec5b8c48c08d38e9e71666947aadafd3fb6" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
