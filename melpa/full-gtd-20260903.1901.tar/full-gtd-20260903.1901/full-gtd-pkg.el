;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "20260903.1901"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "e1395caa10fcb0516239831e3d6b87c6013b064b"
  :revdesc "e1395caa10fc"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
