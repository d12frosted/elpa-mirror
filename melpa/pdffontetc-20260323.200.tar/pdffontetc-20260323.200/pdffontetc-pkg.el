;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdffontetc" "20260323.200"
  "Display `pdffont' and other PDF information."
  '((emacs     "24.4")
    (pdf-tools "1.2.0"))
  :url "https://github.com/emacsomancer/pdffontetc"
  :commit "9dd320f36af2ce917c77233b7458d5f849924930"
  :revdesc "9dd320f36af2"
  :keywords '("files" "multimedia")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
