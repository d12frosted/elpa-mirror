(define-package "jupyter" "20230627.2030" "Jupyter"
  '((emacs "26")
    (cl-lib "0.5")
    (org "9.1.6")
    (zmq "0.10.10")
    (simple-httpd "1.5.0")
    (websocket "1.9"))
  :commit "2f14f2e2531fc4ebfde5c3b5ae60c1d9c7a2b26b" :authors
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainers
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainer
  '("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")
  :url "https://github.com/nnicandro/emacs-jupyter")
;; Local Variables:
;; no-byte-compile: t
;; End:
