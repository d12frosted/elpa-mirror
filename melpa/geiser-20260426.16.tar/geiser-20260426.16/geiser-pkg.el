;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser" "20260426.16"
  "GNU Emacs and Scheme talk to each other."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://gitlab.com/emacs-geiser/"
  :commit "2e9d5e04e7ddf2727555c74c468bd009ecbdbd92"
  :revdesc "2e9d5e04e7dd"
  :keywords '("languages" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
