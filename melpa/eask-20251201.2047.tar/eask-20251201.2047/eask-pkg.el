;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20251201.2047"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "ad6d7dbd258cc4bc08e83a72a6dc7d26589724b3"
  :revdesc "ad6d7dbd258c"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
