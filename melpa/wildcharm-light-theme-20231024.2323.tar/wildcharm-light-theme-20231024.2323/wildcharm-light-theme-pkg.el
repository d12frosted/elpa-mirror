(define-package "wildcharm-light-theme" "20231024.2323" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "83e902cfd9526cdefc973ce9b3f3d7415beb59f5" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
