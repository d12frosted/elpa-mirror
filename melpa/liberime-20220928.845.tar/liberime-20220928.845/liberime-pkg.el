(define-package "liberime" "20220928.845" "Rime elisp binding"
  '((emacs "25.1"))
  :commit "2217883b0ca3b308de4e2c670a0ac8c767fd633e" :authors
  '(("A.I."))
  :maintainer
  '("A.I.")
  :keywords
  '("convenience" "chinese" "input-method" "rime")
  :url "https://github.com/merrickluo/liberime")
;; Local Variables:
;; no-byte-compile: t
;; End:
