;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250925.1252"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "0631d6f01d2ffaa054d0dcabb7e2fd8be264f8b1"
  :revdesc "0631d6f01d2f"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
