;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260524.1417"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "ac7421615d4134d0c393e32a12e7decebb3b4838"
  :revdesc "ac7421615d41"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
