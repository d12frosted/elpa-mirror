;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-anki" "20260423.741"
  "Synchronize org-mode entries to Anki."
  '((emacs   "27.1")
    (request "0.3.2")
    (dash    "2.17")
    (promise "1.1"))
  :url "https://github.com/eyeinsky/org-anki"
  :commit "2f44330aa2cd0a1f58259c9d83bb697fb0f7b0cc"
  :revdesc "2f44330aa2cd"
  :keywords '("outlines" "flashcards" "memory")
  :authors '(("Markus Läll" . "markus.l2ll@gmail.com"))
  :maintainers '(("Markus Läll" . "markus.l2ll@gmail.com")))
