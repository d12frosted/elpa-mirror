(define-package "posframe" "20221213.405" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "c247f24bb182cee46df2fbb92c140fe2152e1989" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
