;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "20241219.542"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "fb2c9031ba52abbbfd39406aabfaca5be65382e0"
  :revdesc "fb2c9031ba52"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
