(define-package "lacquer" "20210922.848" "Switch theme/font by selecting from a cache"
  '((emacs "25.2")
    (ivy "0.13.4"))
  :commit "b9a56e22920a90318ee0f66a1d6edffbb85f6f6c" :authors
  '(("dingansich_kum0" . "zy.hua1122@outlook.com"))
  :maintainer
  '("dingansich_kum0" . "zy.hua1122@outlook.com")
  :keywords
  '("tools")
  :url "https://github.com/dingansichKum0/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
