;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winpulse" "20260815.1947"
  "Momentary window background flash animation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/winpulse"
  :commit "b130b86a57f8a2d8cb6c7a1088b202919f073a43"
  :revdesc "b130b86a57f8"
  :authors '(("Alvaro Ramirez" . "https://xenodium.com"))
  :maintainers '(("Alvaro Ramirez" . "https://xenodium.com")))
