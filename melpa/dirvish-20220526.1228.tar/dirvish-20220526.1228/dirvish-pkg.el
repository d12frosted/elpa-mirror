(define-package "dirvish" "20220526.1228" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "836983ebc8f6bdd8c3bbf04238fa24ac327f9ecd" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
