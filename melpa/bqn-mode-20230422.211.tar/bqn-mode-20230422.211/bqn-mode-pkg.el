(define-package "bqn-mode" "20230422.211" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "202e7e56f516d7e95775d0bc2222ad48f5beb4ff" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
