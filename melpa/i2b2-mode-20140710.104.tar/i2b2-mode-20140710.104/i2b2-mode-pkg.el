;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "i2b2-mode" "20140710.104"
  "Highlights corresponding PHI data in the text portion of an i2b2 XML Document."
  ()
  :url "https://github.com/danlamanna/i2b2-mode"
  :commit "db10efcfc8bed369a516bbf7526ede41f98cb95a"
  :revdesc "db10efcfc8be"
  :keywords '("xml" "phi" "i2b2" "deidi2b2")
  :authors '(("Dan LaManna" . "dan.lamanna@gmail.com"))
  :maintainers '(("Dan LaManna" . "dan.lamanna@gmail.com")))
