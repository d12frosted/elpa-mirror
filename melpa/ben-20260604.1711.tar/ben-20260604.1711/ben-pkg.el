;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ben" "20260604.1711"
  "Asynchronous buffer-local environments via `direnv'."
  '((emacs      "29.1")
    (inheritenv "0.1")
    (seq        "2.24"))
  :url "https://codeberg.org/pastor/ben.el"
  :commit "f9b236c990cc3951cca04e869a9d862e0ffc0a47"
  :revdesc "f9b236c990cc"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com")
             ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")
                 ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
