(define-package "consult" "20211111.843" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "afb0bc5b3d264ee1fdc1bc7ec41ad169483eb29d" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
