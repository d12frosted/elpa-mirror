;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dkmisc" "20131110.1115"
  "Miscellaneous functions required by dk* packages."
  '((emacs "24.1"))
  :url "https://github.com/davidkeegan/dkmisc"
  :commit "fe3d49c6f8322b6f89466361acd97585bdfe0608"
  :revdesc "fe3d49c6f832"
  :keywords '("utility" "time" "date" "file")
  :authors '(("David Keegan" . "dksw@eircom.net"))
  :maintainers '(("David Keegan" . "dksw@eircom.net")))
