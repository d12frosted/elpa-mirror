;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk" "20260322.1929"
  "Daredevil SKK (Simple Kana to Kanji conversion program)."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :url "https://github.com/skk-dev/ddskk"
  :commit "c2b0f8874dbba9a884c3a273e0cab0a132e4418c"
  :revdesc "c2b0f8874dbb"
  :keywords '("japanese" "mule" "input method")
  :authors '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp")))
