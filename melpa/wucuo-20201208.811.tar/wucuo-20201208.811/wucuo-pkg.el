(define-package "wucuo" "20201208.811" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "609bab2d72690c2eb1562e87dfa468b927eb1295" :authors
  (("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  ("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  ("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
