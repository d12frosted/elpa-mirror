;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shelldoc" "20230207.250"
  "Shell command editing support with man page."
  '((cl-lib "0.3")
    (s      "1.9.0"))
  :url "https://github.com/mhayashi1120/Emacs-shelldoc"
  :commit "178d78d08e94b273b23ab1a32c5be509fdfe2286"
  :revdesc "178d78d08e94"
  :keywords '("applications")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
