;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260617.543"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e54e99d19eb476b9badfd13ea84a8e8186bf1718"
  :revdesc "e54e99d19eb4"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
