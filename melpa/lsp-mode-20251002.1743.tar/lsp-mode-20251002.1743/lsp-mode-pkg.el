;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20251002.1743"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "9323ce94d3fd621484ac7d08933b621921222b71"
  :revdesc "9323ce94d3fd"
  :keywords '("languages"))
