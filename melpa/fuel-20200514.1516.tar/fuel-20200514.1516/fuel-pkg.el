(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "aad2d16bbf910466f6e89af6e250b57f9f39f4b7")
;; Local Variables:
;; no-byte-compile: t
;; End:
