(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2a6a420fdd680ba0d3ff65f0dd5666fbfc9c9911")
;; Local Variables:
;; no-byte-compile: t
;; End:
