(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "58c40fab267e8f5b112339dae9bdcda015096c0a")
;; Local Variables:
;; no-byte-compile: t
;; End:
