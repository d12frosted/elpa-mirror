(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "94a922af1f015da6c24ba6c81aeace0c7e6d80bf")
;; Local Variables:
;; no-byte-compile: t
;; End:
