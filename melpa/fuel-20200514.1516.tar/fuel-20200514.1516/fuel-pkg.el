(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "36c2cda8249d8619456efc29f06db03154120637")
;; Local Variables:
;; no-byte-compile: t
;; End:
