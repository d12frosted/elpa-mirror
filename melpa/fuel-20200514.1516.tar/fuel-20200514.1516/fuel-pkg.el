(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1b744404f3a19be816dc36334d070488e1f2b20e")
;; Local Variables:
;; no-byte-compile: t
;; End:
