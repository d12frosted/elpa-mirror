(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "af8064bfd4be7f0ca1a155a505d6999810f4f5c5")
;; Local Variables:
;; no-byte-compile: t
;; End:
