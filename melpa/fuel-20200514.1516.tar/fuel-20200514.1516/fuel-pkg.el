(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "47ae9b544b3d1b30b2aead0aad7b622b7c74723e")
;; Local Variables:
;; no-byte-compile: t
;; End:
