(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9dbb34fefbf392293b841b153a00538577a7cd64")
;; Local Variables:
;; no-byte-compile: t
;; End:
