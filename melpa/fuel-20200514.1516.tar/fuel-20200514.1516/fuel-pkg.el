(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c4eb4357167855bded6ed3567917896bc1b43412")
;; Local Variables:
;; no-byte-compile: t
;; End:
