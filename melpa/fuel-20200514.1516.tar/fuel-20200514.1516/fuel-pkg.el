(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d3bc892ec7b7049b72713b545803d7919ed993e6")
;; Local Variables:
;; no-byte-compile: t
;; End:
