(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3790d1b9d4bb12c27bed5a608c7de4ca826e8702")
;; Local Variables:
;; no-byte-compile: t
;; End:
