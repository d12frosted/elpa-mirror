(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2c46bc3d840f7fee489b2f632a928acc00680988")
;; Local Variables:
;; no-byte-compile: t
;; End:
