(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2575e2cb876a842543aae328b2ab589a2930bc31")
;; Local Variables:
;; no-byte-compile: t
;; End:
