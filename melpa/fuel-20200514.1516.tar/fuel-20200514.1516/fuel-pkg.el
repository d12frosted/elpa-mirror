(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f29a38f38a51420bee78cb676ca81ba47f87bbc8")
;; Local Variables:
;; no-byte-compile: t
;; End:
