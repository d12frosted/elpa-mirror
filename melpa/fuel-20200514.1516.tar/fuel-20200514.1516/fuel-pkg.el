(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5e6e838be8f45b081a4f933be880876048d80e72")
;; Local Variables:
;; no-byte-compile: t
;; End:
