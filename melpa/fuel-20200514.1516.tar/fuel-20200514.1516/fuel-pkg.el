(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "dee3bb75afaec53b1287e6cc453c5dba8a731d80")
;; Local Variables:
;; no-byte-compile: t
;; End:
