(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9bbf03d8907f4d8bff2a5e34dc29f3c66dad7cc4")
;; Local Variables:
;; no-byte-compile: t
;; End:
