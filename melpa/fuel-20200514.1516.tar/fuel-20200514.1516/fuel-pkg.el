(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5755ec763c78f289c64b664fc15c5209f3648ed1")
;; Local Variables:
;; no-byte-compile: t
;; End:
