(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "16c60c416dcaf58827b71f298012390d39518a8a")
;; Local Variables:
;; no-byte-compile: t
;; End:
