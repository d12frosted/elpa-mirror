(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "26510ba65a0ca8091ebfa82e909b6022ba0bb8ff")
;; Local Variables:
;; no-byte-compile: t
;; End:
