(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "81ba94cfcc7d4e47110f7b8e0ee8f1b64687c7a1")
;; Local Variables:
;; no-byte-compile: t
;; End:
