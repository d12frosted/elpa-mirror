(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c78aedaa3339eaee1752b8f2f32505545ed9c2d5")
;; Local Variables:
;; no-byte-compile: t
;; End:
