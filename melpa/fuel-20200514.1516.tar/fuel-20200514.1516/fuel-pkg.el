(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "7bf6215a5dc5a55d04014abedd3c5b23d442db71")
;; Local Variables:
;; no-byte-compile: t
;; End:
