(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2060c2a14c1723e3d5bec8f6bfc0880b211c9d71")
;; Local Variables:
;; no-byte-compile: t
;; End:
