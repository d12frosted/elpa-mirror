(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d3ed8fe473b02a935a9bba8fff4ad0977b23d4ed")
;; Local Variables:
;; no-byte-compile: t
;; End:
