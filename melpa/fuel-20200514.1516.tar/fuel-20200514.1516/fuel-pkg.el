(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "527567aa9f668e9fa63df7d258b82004473dd7e4")
;; Local Variables:
;; no-byte-compile: t
;; End:
