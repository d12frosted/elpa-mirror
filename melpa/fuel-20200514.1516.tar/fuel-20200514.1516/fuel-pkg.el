(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "af536f2a39a80a08495e16c069432ec5401c8285")
;; Local Variables:
;; no-byte-compile: t
;; End:
