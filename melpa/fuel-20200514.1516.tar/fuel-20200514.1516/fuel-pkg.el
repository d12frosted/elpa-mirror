(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d82bfd045a04b174212a3842d8f23a10a4bd813d")
;; Local Variables:
;; no-byte-compile: t
;; End:
