(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "8c93d8c054bd8ae19a9d8eca23192e5d74cc7979")
;; Local Variables:
;; no-byte-compile: t
;; End:
