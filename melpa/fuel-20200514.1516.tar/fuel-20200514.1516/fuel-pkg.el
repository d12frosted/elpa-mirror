(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2bb17497074dbeaff97f942fc60a49a59ecdd1d5")
;; Local Variables:
;; no-byte-compile: t
;; End:
