(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2c1c49302db5a810de92db97183c586a80f4c973")
;; Local Variables:
;; no-byte-compile: t
;; End:
