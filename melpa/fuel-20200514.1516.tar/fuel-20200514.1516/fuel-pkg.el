(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "fb8e897d9bb653fa3c5a4b7037e366daaef965f5")
;; Local Variables:
;; no-byte-compile: t
;; End:
