(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1f1a7be033aec1ad5b6bd65ef8431fc74836044e")
;; Local Variables:
;; no-byte-compile: t
;; End:
