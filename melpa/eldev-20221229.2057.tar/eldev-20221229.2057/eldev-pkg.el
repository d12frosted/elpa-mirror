(define-package "eldev" "20221229.2057" "Elisp development tool"
  '((emacs "24.4"))
  :commit "4b0f791f915616949776667a685b647f11e831af" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
