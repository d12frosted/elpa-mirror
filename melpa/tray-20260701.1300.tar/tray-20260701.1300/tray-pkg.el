;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tray" "20260701.1300"
  "Various transient menus."
  '((emacs     "28.1")
    (compat    "31.0")
    (transient "0.13"))
  :url "https://github.com/tarsius/tray"
  :commit "0e6f331dd7fcef6a591c4954808a6b262522fa40"
  :revdesc "0e6f331dd7fc"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.tray@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.tray@jonas.bernoulli.dev")))
