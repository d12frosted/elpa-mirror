;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-shader" "20251231.1653"
  "LSP Clients for ShaderLab."
  '((emacs    "28.1")
    (lsp-mode "6.1"))
  :url "https://github.com/shader-ls/lsp-shader"
  :commit "f8772e749d212adf95b901c3c94c9c96f9da3707"
  :revdesc "f8772e749d21"
  :keywords '("convenience" "shader")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
