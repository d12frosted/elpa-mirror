(define-package "igist" "20230421.1033" "List, create, update and delete GitHub gists"
  '((emacs "27.1")
    (ghub "3.5.6")
    (transient "0.3.7"))
  :commit "b8944d96746c3a77d7a6340b679c69025a6ee840" :authors
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainer
  '("Karim Aziiev" . "karim.aziiev@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/KarimAziev/igist")
;; Local Variables:
;; no-byte-compile: t
;; End:
