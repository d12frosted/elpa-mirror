(define-package "helm-core" "20230926.1817" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "8d208ac923bcba79c7c45e83b53c90ddf257e5d0" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
