(define-package "gptel" "20230318.1959" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "9f8a984729c0a96c5c923e6ab997f9895dd8026e" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
