;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20261025.911"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "262b9222d55038cd75b50fbdf3bb07199fce2968"
  :revdesc "262b9222d550"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
