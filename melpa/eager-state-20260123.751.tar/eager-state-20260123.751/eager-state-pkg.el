;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eager-state" "20260123.751"
  "Eagerly persist data onto disk."
  '((emacs "29.1")
    (llama "0.5.0"))
  :url "https://github.com/meedstrom/eager-state"
  :commit "53282709833021dfbe8605c9eadaa0fffe5da349"
  :revdesc "532827098330"
  :keywords '("convenience")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
