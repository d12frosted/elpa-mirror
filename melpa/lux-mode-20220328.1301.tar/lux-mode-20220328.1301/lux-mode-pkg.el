(define-package "lux-mode" "20220328.1301" "Major mode for editing lux files"
  '((emacs "24.3"))
  :commit "f9335e885611c2a5d65c449facdad72c28b3ff9c" :authors
  '(("Håkan Mattsson"))
  :maintainers
  '(("Håkan Mattsson"))
  :maintainer
  '("Håkan Mattsson")
  :url "https://github.com/hawk/lux")
;; Local Variables:
;; no-byte-compile: t
;; End:
