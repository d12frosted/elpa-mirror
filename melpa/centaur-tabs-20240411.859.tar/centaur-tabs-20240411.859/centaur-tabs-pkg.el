(define-package "centaur-tabs" "20240411.859" "Aesthetic, modern looking customizable tabs plugin"
  '((emacs "24.4")
    (powerline "2.4")
    (cl-lib "0.5"))
  :commit "6914d86558f31c2de9db90049627dc5f4c21eb61" :authors
  '(("Emmanuel Bustos" . "ema2159@gmail.com"))
  :maintainers
  '(("Jen-Chieh Shen" . "jcs090218@gmail.com"))
  :maintainer
  '("Jen-Chieh Shen" . "jcs090218@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/ema2159/centaur-tabs")
;; Local Variables:
;; no-byte-compile: t
;; End:
