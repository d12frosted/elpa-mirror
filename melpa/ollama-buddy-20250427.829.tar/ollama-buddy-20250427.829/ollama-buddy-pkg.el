;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250427.829"
  "Ollama LLM AI Assistant with ChatGPT, Claude, Gemini and Grok Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "f1b5898ee02920aee2eea2dd7e6deaaa08940aeb"
  :revdesc "f1b5898ee029"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
