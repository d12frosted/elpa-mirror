;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yafolding" "20250523.943"
  "Folding code blocks based on indentation."
  ()
  :url "https://github.com/emacsorphanage/yafolding"
  :commit "4050e576a560ff8a45c00c98bea71e68d2429083"
  :revdesc "4050e576a560"
  :keywords '("folding")
  :authors '(("Zeno Zeng" . "zenoofzeng@gmail.com"))
  :maintainers '(("Zeno Zeng" . "zenoofzeng@gmail.com")))
