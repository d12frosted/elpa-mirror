;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultra-scroll" "20250621.1635"
  "Fast and smooth scrolling."
  '((emacs "29.1"))
  :url "https://github.com/jdtsmith/ultra-scroll"
  :commit "f9213ee5f329528c4245db21c119fc9a9042110f"
  :revdesc "f9213ee5f329"
  :keywords '("convenience"))
