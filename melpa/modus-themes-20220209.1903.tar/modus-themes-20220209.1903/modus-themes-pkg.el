(define-package "modus-themes" "20220209.1903" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "2a977be08b2f963c10f110329bfefba5e56ad0fc" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
