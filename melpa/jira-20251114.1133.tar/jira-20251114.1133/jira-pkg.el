;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20251114.1133"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "e83864edacd7907cc64914d6d0684e0c6e9ccbfd"
  :revdesc "e83864edacd7"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
