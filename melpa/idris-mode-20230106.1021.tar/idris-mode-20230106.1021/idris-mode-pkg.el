(define-package "idris-mode" "20230106.1021" "Major mode for editing Idris code"
  '((emacs "24")
    (prop-menu "0.1")
    (cl-lib "0.5"))
  :commit "253e2ad90985c83c5cb06bae0b1cb931c88a6c89" :keywords
  '("languages")
  :url "https://github.com/idris-hackers/idris-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
