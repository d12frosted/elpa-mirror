(define-package "dirvish" "20220108.1527" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "aa94c57cc7faf1c6e3fc2257b489e374f07b889d" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
