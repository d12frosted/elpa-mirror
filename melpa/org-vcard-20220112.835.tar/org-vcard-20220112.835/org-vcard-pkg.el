(define-package "org-vcard" "20220112.835" "org-mode support for vCard export and import." 'nil :commit "079d6227147427c7f53471e57a56582a858ced13" :authors
  '(("Alexis" . "flexibeast@gmail.com")
    ("Will Dey" . "will123dey@gmail.com"))
  :maintainer
  '("Alexis" . "flexibeast@gmail.com")
  :keywords
  '("outlines" "org" "vcard")
  :url "https://github.com/flexibeast/org-vcard")
;; Local Variables:
;; no-byte-compile: t
;; End:
