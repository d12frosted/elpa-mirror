;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250609.1313"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "1109108bd68d65ebfd75e1faf144e3cb54df416e"
  :revdesc "1109108bd68d"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
