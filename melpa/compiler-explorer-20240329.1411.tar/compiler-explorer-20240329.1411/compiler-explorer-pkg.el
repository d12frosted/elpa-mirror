(define-package "compiler-explorer" "20240329.1411" "Compiler explorer client (godbolt.org)"
  '((emacs "26.1")
    (request "0.3.0"))
  :commit "76fc2b676313245f50526cb5f4742bb6f5d788de" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("c" "tools")
  :url "https://github.com/mkcms/compiler-explorer.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
