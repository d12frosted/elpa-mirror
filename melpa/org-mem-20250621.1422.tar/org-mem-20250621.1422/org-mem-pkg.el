;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250621.1422"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "6048fc50c1899fd3764d15d216592d2798edc8f5"
  :revdesc "6048fc50c189"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
