;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selectric-mode" "20200209.2107"
  "IBM Selectric mode for Emacs."
  ()
  :url "https://github.com/rbanffy/selectric-mode"
  :commit "bb9e66678f34e9bc23624ff6292cf5e7857e8e5f"
  :revdesc "bb9e66678f34"
  :keywords '("multimedia" "convenience" "typewriter" "selectric")
  :authors '(("Ricardo Bánffy" . "rbanffy@gmail.com"))
  :maintainers '(("Ricardo Banffy" . "rbanffy@gmail.com")))
