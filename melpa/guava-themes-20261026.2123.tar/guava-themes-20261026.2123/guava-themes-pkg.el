;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261026.2123"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "7c5afe4d938bbb0c5669fa4895c5d9c5a3e9d285"
  :revdesc "7c5afe4d938b"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
