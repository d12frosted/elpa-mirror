(define-package "kurecolor" "20220818.1211" "color editing goodies"
  '((emacs "24.1")
    (s "1.12"))
  :commit "296eaa26ee5e7967eabbcc0a0d56fd4e6e73ccb7" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
