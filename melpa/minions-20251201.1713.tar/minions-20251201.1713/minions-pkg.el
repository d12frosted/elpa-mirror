;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minions" "20251201.1713"
  "A minor-mode menu for the mode line."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/minions"
  :commit "29f7bf30abcfcc00eb5b7f7530d9b19645bf0ae0"
  :revdesc "29f7bf30abcf"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev")))
