;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20261013.1133"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "ab3aaeffebd61c23d127b0b0a0a1e9111a511208"
  :revdesc "ab3aaeffebd6"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
