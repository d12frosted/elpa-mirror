(define-package "perfect-margin" "20231214.1011" "Auto center windows, works with line numbers"
  '((emacs "24.3"))
  :commit "bee159e470bce5dd8743954eff38c545d4b5c16c" :authors
  '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainers
  '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainer
  '("Randall Wang" . "randall.wjz@gmail.com")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/mpwang/perfect-margin")
;; Local Variables:
;; no-byte-compile: t
;; End:
