;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260518.2023"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "de31793ad388fe4f897aad61a1efcaaba048d066"
  :revdesc "de31793ad388"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
