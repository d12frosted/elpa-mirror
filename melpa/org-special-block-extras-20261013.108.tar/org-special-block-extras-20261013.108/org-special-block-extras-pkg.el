;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20261013.108"
  "30 new custom blocks & 34 link types for Org-mode."
  '((s        "1.13.1")
    (dash     "2.18.1")
    (emacs    "27.1")
    (org      "9.1")
    (lf       "1.0")
    (dad-joke "1.4")
    (seq      "2.0")
    (lolcat   "0"))
  :url "https://alhassy.github.io/org-special-block-extras"
  :commit "37a8b0e8a04fad97b6aecfa7ac6985a5c74107af"
  :revdesc "37a8b0e8a04f"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
