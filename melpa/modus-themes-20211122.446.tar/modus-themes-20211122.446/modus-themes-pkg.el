(define-package "modus-themes" "20211122.446" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "59b82d3f5535713f6fbe08d7cbc154b621f6e57a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
