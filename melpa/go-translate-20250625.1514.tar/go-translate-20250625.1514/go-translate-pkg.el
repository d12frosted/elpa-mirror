;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250625.1514"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "256c111559a5e25f736154e5d2cdd6f500a3891d"
  :revdesc "256c111559a5"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
