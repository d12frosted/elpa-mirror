;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250625.1514"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "2b939e2762acd7d60bdfff95c7845d28b62bbbd7"
  :revdesc "2b939e2762ac"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
