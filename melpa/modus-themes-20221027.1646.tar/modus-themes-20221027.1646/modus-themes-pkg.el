(define-package "modus-themes" "20221027.1646" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "15f3ffa4511550502483c88ee7499bef16dc5ea1" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
