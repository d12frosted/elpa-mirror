;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "libelcouch" "20230903.800"
  "Communication with CouchDB."
  '((emacs   "26.1")
    (request "0.3.0"))
  :url "https://github.com/DamienCassou/libelcouch/"
  :commit "5202084caee9fd236a18afc6f83293f05168a4c3"
  :revdesc "5202084caee9"
  :keywords '("tools")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
