;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260517.552"
  "LSP mode."
  '((emacs         "29.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "8b04cf6354e55e99bd71d067862ac779510076cd"
  :revdesc "8b04cf6354e5"
  :keywords '("languages"))
