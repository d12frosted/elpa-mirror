(define-package "nerd-icons-corfu" "20231009.1337" "Icons for Corfu via nerd-icons"
  '((emacs "27.1")
    (nerd-icons "0.1.0"))
  :commit "2e546d12fd85b506561cdfb47b26f8c95b24d6cf" :authors
  '(("Luigi Sartor Piucco" . "luigipiucco@gmail.com"))
  :maintainers
  '(("Luigi Sartor Piucco" . "luigipiucco@gmail.com"))
  :maintainer
  '("Luigi Sartor Piucco" . "luigipiucco@gmail.com")
  :keywords
  '("convenience" "files" "icons")
  :url "https://github.com/LuigiPiucco/nerd-icons-corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
