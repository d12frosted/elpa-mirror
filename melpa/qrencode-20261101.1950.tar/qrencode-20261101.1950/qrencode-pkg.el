;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "20261101.1950"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "5f112da0c99e625e7fd3e265e18b511189b3944a"
  :revdesc "5f112da0c99e"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
