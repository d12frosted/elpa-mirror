;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcomp" "20260616.2212"
  "Compare version strings."
  '((emacs "26.1"))
  :url "https://github.com/tarsius/vcomp"
  :commit "7b3f93d1202bd9353ee6401c47fbc3cc0d6d76e3"
  :revdesc "7b3f93d1202b"
  :keywords '("versions")
  :authors '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
