;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260625.645"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "2944dfc420232afdc189c3bb7565a0ea2a1a0450"
  :revdesc "2944dfc42023"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
