;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20251223.2147"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "452ccc4ff5674df8da6c788e48abeeed6f3abd29"
  :revdesc "452ccc4ff567"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
