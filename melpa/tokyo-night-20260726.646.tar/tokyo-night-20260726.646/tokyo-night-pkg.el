;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20260726.646"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "f206662f6fb8f04b69fec1d8f64b731fbc5d425f"
  :revdesc "f206662f6fb8"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
