;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minizinc-ts-mode" "20241126.1730"
  "Major mode for the MiniZinc constraint modeling language."
  '((emacs "29.1"))
  :url "https://github.com/AjaiKN/minizinc-ts-mode"
  :commit "e9a7886671ab7e3dbfa9eaa84426c088b857ffb1"
  :revdesc "e9a7886671ab"
  :keywords '("languages")
  :authors '(("Ajai Khatri Nelson" . "emacs@ajai.dev"))
  :maintainers '(("Ajai Khatri Nelson" . "emacs@ajai.dev")))
