;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260705.755"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "02407c70b43a43d9c2373c92c5958d9fc1a3796d"
  :revdesc "02407c70b43a"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
