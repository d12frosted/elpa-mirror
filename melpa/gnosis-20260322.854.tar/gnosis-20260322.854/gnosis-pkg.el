;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260322.854"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "b9b5c8fee97a1590a2d19645975cbe5be9bf032b"
  :revdesc "b9b5c8fee97a"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
