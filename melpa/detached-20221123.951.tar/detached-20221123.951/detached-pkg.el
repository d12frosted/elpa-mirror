(define-package "detached" "20221123.951" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "8b1cae62af108c86c656c7c0f4f67c7bf175deea" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
