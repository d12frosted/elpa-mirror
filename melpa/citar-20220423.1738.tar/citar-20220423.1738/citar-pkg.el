(define-package "citar" "20220423.1738" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "3.0")
    (org "9.5")
    (citeproc "0.9"))
  :commit "4fbdbdddb7f564b19d2507cafbbe29e18938ee51" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
