;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250623.1317"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "6ee155fe311178dffd4896ce14653810619acb82"
  :revdesc "6ee155fe3111"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
