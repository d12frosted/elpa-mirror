;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "20260223.1935"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "e2664f040eb71dba8ba2cbd4fccfe64842f0efb5"
  :revdesc "e2664f040eb7"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
