(define-package "prettify-math" "20211107.38" "Prettify math formula"
  '((emacs "27.1")
    (dash "2.19.0")
    (s "1.12.0")
    (jsonrpc "1.0.9"))
  :commit "e1925aa3419b1b4d5670040fcc8543382489507f" :authors
  '(("Shaq Xu" . "shaqxu@163.com"))
  :maintainer
  '("Shaq Xu" . "shaqxu@163.com")
  :keywords
  '("math" "asciimath" "tex" "latex" "prettify" "mathjax")
  :url "https://gitee.com/shaqxu/prettify-math")
;; Local Variables:
;; no-byte-compile: t
;; End:
