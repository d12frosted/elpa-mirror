;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260114.1146"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "9482e00eb06dfbc599eac58bb73ec53700793b3e"
  :revdesc "9482e00eb06d"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
