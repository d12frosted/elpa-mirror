;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kele" "20251127.550"
  "Spritzy Kubernetes cluster management."
  '((emacs         "29.1")
    (async         "1.9.7")
    (dash          "2.19.1")
    (f             "0.20.0")
    (magit-section "4.0.0")
    (memoize       "0")
    (plz           "0.8.0")
    (s             "1.13.0")
    (yaml          "0.5.1"))
  :url "https://github.com/jinnovation/kele.el"
  :commit "c62cd4cd73a6c891b0921fd72c56037d8aad1295"
  :revdesc "c62cd4cd73a6"
  :keywords '("kubernetes" "tools")
  :authors '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers '(("Jonathan Jin" . "me@jonathanj.in")))
