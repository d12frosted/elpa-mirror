;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20251230.610"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.0.0")
    (vui    "0.1"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "181a712013def5cabb96f13d54566a40dd74bf94"
  :revdesc "181a712013de"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
