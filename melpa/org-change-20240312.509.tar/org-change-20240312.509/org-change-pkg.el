(define-package "org-change" "20240312.509" "Annotate changes in org-mode files"
  '((emacs "26.1")
    (org "9.3"))
  :commit "3ec32b40d61da72708bc8935e6394d397172c64f" :keywords
  '("wp" "convenience")
  :url "https://github.com/drghirlanda/org-change")
;; Local Variables:
;; no-byte-compile: t
;; End:
