(define-package "modus-themes" "20210406.551" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "33da21991851276fd9587767206bfd95a64638a9" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
