;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20241122.106"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "72a9c974310096c03ef8414cf3945f229c15bd28"
  :revdesc "72a9c9743100"
  :keywords '("convenience"))
