(define-package "live-py-mode" "20211228.717" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "11bbea72f14fe438c5ce45f74cdf596d7120a570" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
