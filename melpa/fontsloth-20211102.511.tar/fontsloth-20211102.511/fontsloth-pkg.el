(define-package "fontsloth" "20211102.511" "Elisp otf/ttf font loader/renderer"
  '((f "0.20.0")
    (logito "0.1")
    (pcache "0.5")
    (emacs "28.1"))
  :commit "e43c7ed8302841aefe45f2e6bf35f84d854868f5" :authors
  '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainer
  '("Jo Gay" . "jo.gay@mailfence.com")
  :keywords
  '("data" "font" "rasterization" "ttf" "otf")
  :url "https://github.com/jollm/fontsloth")
;; Local Variables:
;; no-byte-compile: t
;; End:
