(define-package "sculpture-themes" "20220512.2235" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "be3adaf9db276e899b44e5093316cae2014b22c9" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
