;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20251230.701"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "832dd509575fa2f6487ea2288af1ec1880464334"
  :revdesc "832dd509575f"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
