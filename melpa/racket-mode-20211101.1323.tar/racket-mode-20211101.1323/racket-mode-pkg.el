(define-package "racket-mode" "20211101.1323" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "afef7f0a29923c358590dfcde43aae416bb420e2" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
