(define-package "dall-e-shell" "20231212.2355" "Interaction mode for DALL-E"
  '((emacs "27.1")
    (shell-maker "0.44.1"))
  :commit "009fbf04ffb3dc89b6dc3729ac95b1c201c0a061" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
