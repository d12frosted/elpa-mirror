(define-package "eldev" "20210417.1824" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "a8458ab0e1d2fc8557f8aa4102a217298ffbbb1f" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
