(define-package "templatel" "20200905.121" "Templating language;"
  '((emacs "25.1"))
  :commit "77cbb852c3737f4738e106a51607bfdcd7727fd8" :authors
  (("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  ("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://clarete.li/templatel")
;; Local Variables:
;; no-byte-compile: t
;; End:
