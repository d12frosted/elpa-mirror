;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250530.905"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.14.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "28298f6cfc44fbc22be9e774796d0f04f6131471"
  :revdesc "28298f6cfc44"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
