;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260319.917"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "009bf5cb5d93555cb662b0869f5e27482fbf8f8b"
  :revdesc "009bf5cb5d93"
  :keywords '("data" "extensions"))
