(define-package "titlecase" "20220501.1456" "Title-case phrases"
  '((emacs "25.1"))
  :commit "5676da54210c739b583d841c6b957fbf09063861" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://github.com/duckwork/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
