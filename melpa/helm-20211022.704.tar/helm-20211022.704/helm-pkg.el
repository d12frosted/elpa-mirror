(define-package "helm" "20211022.704" "Helm is an Emacs incremental and narrowing framework"
  '((emacs "25.1")
    (async "1.9.4")
    (popup "0.5.3")
    (helm-core "3.8.0"))
  :commit "99de86329d948357e8f645bff6ac06a96fd801bc" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://github.com/emacs-helm/helm")
;; Local Variables:
;; no-byte-compile: t
;; End:
