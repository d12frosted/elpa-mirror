(define-package "youdao-dictionary" "20230929.402" "Youdao Dictionary interface for Emacs"
  '((popup "0.5.0")
    (pos-tip "0.4.6")
    (chinese-word-at-point "0.2")
    (names "0.5")
    (emacs "24"))
  :commit "3486a0d80b34d365b166ad0c5c3989bd4bc34e14" :authors
  '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers
  '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainer
  '("Chunyang Xu" . "xuchunyang56@gmail.com")
  :keywords
  '("convenience" "chinese" "dictionary")
  :url "https://github.com/xuchunyang/youdao-dictionary.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
