;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261029.1817"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "f7308e174abb97ab4a38170cedba4bb671eb768b"
  :revdesc "f7308e174abb"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
