(define-package "modus-themes" "20220127.823" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "056dbaf3833100ce177f512658f85a46efd00573" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
