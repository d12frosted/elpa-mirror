(define-package "expenses" "20211226.619" "Record and view expenses"
  '((emacs "26.1")
    (dash "2.19.1")
    (ht "2.3"))
  :commit "2df914bb214c30d07309f9269287922d5588a4f3" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("expense tracking" "convenience")
  :url "https://github.com/md-arif-shaikh/expenses")
;; Local Variables:
;; no-byte-compile: t
;; End:
