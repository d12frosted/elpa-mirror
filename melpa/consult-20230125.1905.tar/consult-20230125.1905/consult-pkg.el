(define-package "consult" "20230125.1905" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "a00e613bee2ca3982388fcb9d19a866f92acc87a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
