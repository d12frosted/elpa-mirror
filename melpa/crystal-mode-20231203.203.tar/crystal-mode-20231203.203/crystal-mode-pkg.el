(define-package "crystal-mode" "20231203.203" "Major mode for editing Crystal files"
  '((emacs "24.4"))
  :commit "17a3793581ed5f34591a5cbd50d91729a8dafb36" :keywords
  '("languages" "crystal")
  :url "https://github.com/crystal-lang-tools/emacs-crystal-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
