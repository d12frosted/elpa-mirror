;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-objc-clang" "20210911.1023"
  "Flycheck: Objective-C support using Clang."
  '((emacs    "24.4")
    (flycheck "26"))
  :url "https://github.com/GyazSquare/flycheck-objc-clang"
  :commit "5a441a31e58de17da94f933277150be39198d98c"
  :revdesc "5a441a31e58d"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Goichi Hirakawa" . "gooichi@gyazsquare.com"))
  :maintainers '(("Goichi Hirakawa" . "gooichi@gyazsquare.com")))
