;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260324.2104"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "1daa74ed196d6c94ce35a6124d8c57bb0eef256a"
  :revdesc "1daa74ed196d"
  :keywords '("convenience" "text"))
