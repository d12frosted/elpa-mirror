(define-package "chatgpt-shell" "20230621.2017" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.25.1"))
  :commit "1d7c570986e1c41a86c24896d75c7512a632ba08" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
