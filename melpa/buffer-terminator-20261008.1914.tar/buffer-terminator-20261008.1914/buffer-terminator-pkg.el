;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20261008.1914"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "b6799b7f16524cef2847f29390e415e031f1807c"
  :revdesc "b6799b7f1652"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
