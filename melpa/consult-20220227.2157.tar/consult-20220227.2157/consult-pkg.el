(define-package "consult" "20220227.2157" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "116e30998ef3d97fb194edaff0854ca5a0732447" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
