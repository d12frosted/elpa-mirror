(define-package "consult-compile-multi" "20230828.1034" "Consulting read support for `compile-multi'"
  '((emacs "28.1")
    (compile-multi "0.4")
    (consult "0.34"))
  :commit "870baff1d9e0ab199bfa7dfd3f54c2a81ee5ba46" :authors
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("mohsin kaleem" . "mohkale@kisara.moe")
  :keywords
  '("tools" "compile" "build")
  :url "https://github.com/mohkale/compile-multi")
;; Local Variables:
;; no-byte-compile: t
;; End:
