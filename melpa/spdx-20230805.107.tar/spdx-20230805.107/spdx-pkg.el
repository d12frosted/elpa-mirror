(define-package "spdx" "20230805.107" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "9faa42c161f18e79cdab6d796eaa33bfebbf9418" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
