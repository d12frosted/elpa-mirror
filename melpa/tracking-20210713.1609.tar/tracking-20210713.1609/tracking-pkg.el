(define-package "tracking" "20210713.1609" "Buffer modification tracking" 'nil :commit "054adb71f685f96cef6cb28381c0080af22e729a" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/emacs-circe/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
