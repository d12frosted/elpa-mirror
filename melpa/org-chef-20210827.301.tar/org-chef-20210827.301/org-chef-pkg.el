(define-package "org-chef" "20210827.301" "Cookbook and recipe management with org-mode."
  '((org "0")
    (emacs "24"))
  :commit "5ba0b3e2567c044862d87012a6441160778ed44d" :authors
  '(("Calvin Beck" . "hobbes@ualberta.ca"))
  :maintainer
  '("Calvin Beck" . "hobbes@ualberta.ca")
  :keywords
  '("convenience" "abbrev" "outlines" "org" "food" "recipes" "cooking")
  :url "https://github.com/Chobbes/org-chef")
;; Local Variables:
;; no-byte-compile: t
;; End:
