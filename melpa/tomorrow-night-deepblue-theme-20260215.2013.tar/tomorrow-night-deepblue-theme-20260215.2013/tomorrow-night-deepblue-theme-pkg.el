;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tomorrow-night-deepblue-theme" "20260215.2013"
  "The Tomorrow Night Deepblue color theme."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/tomorrow-night-deepblue-theme.el"
  :commit "5e688cde3fe91a929a3f36d9311eddc9e0dec0b0"
  :revdesc "5e688cde3fe9"
  :keywords '("faces" "themes")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
