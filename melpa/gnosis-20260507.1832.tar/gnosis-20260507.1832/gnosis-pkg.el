;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260507.1832"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://codeberg.org/thanosapollo/emacs-gnosis"
  :commit "5d46bc6242c6eb8b710b6b31a60d699a7482ca2d"
  :revdesc "5d46bc6242c6"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
