;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredfd" "20241209.223"
  "Dired functions and settings to mimic FD/FDclone."
  '((emacs "28.1"))
  :url "https://github.com/knu/diredfd.el"
  :commit "fe59ffc5471e65d66ced9cbbcdad25930cbe0333"
  :revdesc "fe59ffc5471e"
  :keywords '("unix" "directories" "dired")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
