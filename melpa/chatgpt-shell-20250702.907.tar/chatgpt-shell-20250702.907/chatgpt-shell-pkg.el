;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250702.907"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.77.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "c72d83c524a275b03b46594b399e697654aff723"
  :revdesc "c72d83c524a2")
