(define-package "elisp-autofmt" "20230131.1219" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "9b3d9e45039c31f79d520a5dcffdc9c609e10aa9" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
