(define-package "meow" "20220614.2011" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "adb5ac689863223d30cd8869f8a76fb8bdf7ab01" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
