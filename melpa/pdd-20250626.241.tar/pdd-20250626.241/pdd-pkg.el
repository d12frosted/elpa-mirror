;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250626.241"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "cda2b7e94b6dede0e72d38031f01ee0433f59eb0"
  :revdesc "cda2b7e94b6d"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
