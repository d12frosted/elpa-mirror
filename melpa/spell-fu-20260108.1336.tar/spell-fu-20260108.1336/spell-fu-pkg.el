;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spell-fu" "20260108.1336"
  "Fast & light spelling highlighter."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spell-fu"
  :commit "94686051261a065574fc6535979f8ff08a37f0ee"
  :revdesc "94686051261a"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
