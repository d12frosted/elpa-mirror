;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260416.1901"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "5236f011f420465c2abd853e7f16727c0c8eab7d"
  :revdesc "5236f011f420"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
