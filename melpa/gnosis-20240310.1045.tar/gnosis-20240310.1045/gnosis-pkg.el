(define-package "gnosis" "20240310.1045" "Spaced Repetition System For Note Taking & Self Testing"
  '((emacs "27.2")
    (emacsql "20240124")
    (compat "29.1.4.2"))
  :commit "d99b81b165450308a1f2290eb4d0b233fe0967e2" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions")
  :url "https://thanosapollo.org/projects/gnosis")
;; Local Variables:
;; no-byte-compile: t
;; End:
