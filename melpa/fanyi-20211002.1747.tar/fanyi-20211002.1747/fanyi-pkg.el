(define-package "fanyi" "20211002.1747" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "6dc355f747385b02ab3afed290a9f89059700b3c" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
