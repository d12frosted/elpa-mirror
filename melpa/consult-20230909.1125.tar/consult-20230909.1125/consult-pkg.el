(define-package "consult" "20230909.1125" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "e1dce9725b2fdf5c450d77bfb1ba93f97fd4d980" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
