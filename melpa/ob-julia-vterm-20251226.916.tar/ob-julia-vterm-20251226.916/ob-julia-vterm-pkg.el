;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-julia-vterm" "20251226.916"
  "Babel functions for Julia that work with julia-vterm."
  '((emacs       "26.1")
    (julia-vterm "0.26")
    (queue       "0.2"))
  :url "https://github.com/shg/ob-julia-vterm.el"
  :commit "dbcabdf4502a7b6089b0537bc7ea8ef4f4526233"
  :revdesc "dbcabdf4502a"
  :keywords '("julia" "org" "outlines" "literate programming" "reproducible research"))
