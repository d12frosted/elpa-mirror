(define-package "org-tag-beautify" "20231102.511" "Beautify Org mode tags"
  '((emacs "26.1")
    (nerd-icons "0.0.1"))
  :commit "39b8efc6e3786d2f9d191f9c299337534abb0eb9" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-tag-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
