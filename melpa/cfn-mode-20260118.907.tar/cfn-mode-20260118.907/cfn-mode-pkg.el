;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260118.907"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "e52b95671b6834395463096a9431149ecf0a1a20"
  :revdesc "e52b95671b68"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
