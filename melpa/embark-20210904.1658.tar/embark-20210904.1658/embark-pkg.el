(define-package "embark" "20210904.1658" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "1f8cf373ee5e308ec953315a5803c4e939b40556" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
