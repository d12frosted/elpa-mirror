(define-package "eldev" "20230829.1903" "Elisp development tool"
  '((emacs "24.4"))
  :commit "08db5ae31b1d4bf12a6d62b6d49a6fbd245d3d3e" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/emacs-eldev/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
