(define-package "i-ching" "20210119.1403" "The Book of Changes"
  '((emacs "25.1")
    (request "0.3"))
  :commit "729131ee04d4add1a0702e03893f1a5b9f3f8ec9" :authors
  '(("nik gaffney" . "nik@fo.am"))
  :maintainer
  '("nik gaffney" . "nik@fo.am")
  :keywords
  '("games" "divination" "stochastism" "cleromancy" "change")
  :url "https://github.com/zzkt/i-ching")
;; Local Variables:
;; no-byte-compile: t
;; End:
