(define-package "nix-ts-mode" "20230821.1334" "Major mode for Nix expressions, powered by tree-sitter"
  '((emacs "29.1"))
  :commit "670023ec3d4e2f667a387a27990b4879e06ef60b" :maintainers
  '(("Remi Gelinas" . "mail@remigelin.as"))
  :maintainer
  '("Remi Gelinas" . "mail@remigelin.as")
  :keywords
  '("nix" "languages")
  :url "https://github.com/remi-gelinas/nix-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
