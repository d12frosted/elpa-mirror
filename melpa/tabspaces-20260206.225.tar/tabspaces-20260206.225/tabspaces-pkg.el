;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260206.225"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://github.com/mclear-tools/tabspaces"
  :commit "3b801a7cc698574477d04b400a09d4324ff30118"
  :revdesc "3b801a7cc698"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
