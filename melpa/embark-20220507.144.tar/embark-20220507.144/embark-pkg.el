(define-package "embark" "20220507.144" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d88478b45f2d589339334dc8d40b07bce28aab0e" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
