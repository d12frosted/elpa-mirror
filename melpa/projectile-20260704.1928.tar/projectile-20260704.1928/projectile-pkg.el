;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260704.1928"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "e281754cf64a310276b9512cced2a31f98965f4c"
  :revdesc "e281754cf64a"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
