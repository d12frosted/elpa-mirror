;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260623.2148"
  "Support for Org links to Magit buffers."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.5")
    (org      "9.8"))
  :url "https://github.com/magit/orgit"
  :commit "1aa3a27b1cb6aec913f7365caebdd6ffbe178443"
  :revdesc "1aa3a27b1cb6"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
