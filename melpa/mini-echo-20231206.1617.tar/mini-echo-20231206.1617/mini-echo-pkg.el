(define-package "mini-echo" "20231206.1617" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "228cd1ca3433412347509ec2c6c065c5edfc2954" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
