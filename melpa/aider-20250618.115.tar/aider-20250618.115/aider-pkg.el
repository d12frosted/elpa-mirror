;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250618.115"
  "AI assisted programming with Aider and LLM."
  '((emacs         "26.1")
    (transient     "0.9.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "bdbe0c2ec7337f573f1f6426d20dbdd44b1c1670"
  :revdesc "bdbe0c2ec733"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
