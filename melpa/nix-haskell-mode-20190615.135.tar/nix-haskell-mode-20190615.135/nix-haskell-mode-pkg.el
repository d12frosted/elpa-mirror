;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-haskell-mode" "20190615.135"
  "Haskell-mode integrations for Nix."
  '((emacs        "25")
    (haskell-mode "16.0")
    (nix-mode     "1.3.0"))
  :url "https://github.com/matthewbauer/nix-haskell"
  :commit "68efbcbf949a706ecca6409506968ed2ef928a20"
  :revdesc "68efbcbf949a"
  :keywords '("nix" "haskell" "languages" "processes")
  :authors '(("Matthew Bauer" . "mjbauer95@gmail.com"))
  :maintainers '(("Matthew Bauer" . "mjbauer95@gmail.com")))
