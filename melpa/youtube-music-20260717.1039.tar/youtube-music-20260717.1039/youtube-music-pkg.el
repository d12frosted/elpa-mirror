;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youtube-music" "20260717.1039"
  "YouTube Music client."
  '((emacs "29.1"))
  :url "https://github.com/cyberkm/emacs-youtube-music"
  :commit "2a962d972d8a59fed718aec039c9c61ef3c0392d"
  :revdesc "2a962d972d8a"
  :keywords '("multimedia" "youtube" "music")
  :authors '(("Pavel Bibergal" . "pavel@keewano.com"))
  :maintainers '(("Pavel Bibergal" . "pavel@keewano.com")))
