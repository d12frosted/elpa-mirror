;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260105.115"
  "[No description available]."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "c76967403e285e4f475cfb3fb06f9e076b21d65d"
  :revdesc "c76967403e28"
  :keywords '("convenience"))
