;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "20260518.1359"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "8ee5bd67781604b1fb8832309db577e774e2d208"
  :revdesc "8ee5bd677816"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
