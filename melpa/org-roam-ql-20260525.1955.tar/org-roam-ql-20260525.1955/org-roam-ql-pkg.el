;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "20260525.1955"
  "Interface to query and view results from org-roam."
  '((emacs         "28")
    (org-roam      "2.2.0")
    (s             "1.12.0")
    (magit-section "3.3.0")
    (transient     "0.4")
    (dash          "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "2772ca4b08a41295c4e96fcbfe42501603759d0f"
  :revdesc "2772ca4b08a4")
