(define-package "proof-general" "20210601.1602" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.5"))
  :commit "4877034373559f6d63e28ae5429ac2a074fdafe7" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
