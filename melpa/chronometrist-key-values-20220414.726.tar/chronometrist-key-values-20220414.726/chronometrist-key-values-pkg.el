(define-package "chronometrist-key-values" "20220414.726" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "7ecf058d7c9dc4345a6511aa3252ca5eae6ffa8a" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
