(define-package "chronometrist-key-values" "20220414.726" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "594ab4a17130602507e78c6273a0c73cc986a932" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
