(define-package "chronometrist-key-values" "20220414.726" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "19624f0edc663f5cb29464e3fc82ea398d6f860a" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
