(define-package "datetime" "20231024.1848" "Parsing, formatting and matching timestamps"
  '((emacs "25.1")
    (extmap "1.1.1"))
  :commit "6a562be69f0893fc980df8923ba9cd34c564e5a2" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
