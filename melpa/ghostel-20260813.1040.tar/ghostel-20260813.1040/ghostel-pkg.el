;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260813.1040"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5be34cbbfd18c3e39fffc46bbc824d42bbe35f9b"
  :revdesc "5be34cbbfd18"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
