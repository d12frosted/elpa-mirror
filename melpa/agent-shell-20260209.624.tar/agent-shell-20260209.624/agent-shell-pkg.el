;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260209.624"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "9c7599c4d9fb29ab66d9a760effac26da97bbe32"
  :revdesc "9c7599c4d9fb")
