;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260429.128"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "2b1c3d36ce2ac219075b7f816082347d98a9851d"
  :revdesc "2b1c3d36ce2a"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
