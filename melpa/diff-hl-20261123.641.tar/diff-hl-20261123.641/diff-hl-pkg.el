;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20261123.641"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "768b8f16943a85e096930ac0b5982ef681fcef30"
  :revdesc "768b8f16943a"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
