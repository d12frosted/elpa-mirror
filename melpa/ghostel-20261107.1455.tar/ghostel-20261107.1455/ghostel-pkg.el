;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261107.1455"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "0874bee7b8d62695a2b0ed3f1c9994458d45b21c"
  :revdesc "0874bee7b8d6"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
