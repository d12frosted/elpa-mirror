;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mentor" "20230103.1146"
  "Frontend for the rTorrent bittorrent client."
  '((emacs    "25.1")
    (xml-rpc  "1.6.15")
    (seq      "1.11")
    (async    "1.9.3")
    (url-scgi "0.8"))
  :url "https://github.com/skangas/mentor"
  :commit "f51dd4f3f87c54b7cc92189924b9d873a53f5a75"
  :revdesc "f51dd4f3f87c"
  :keywords '("comm" "processes" "bittorrent")
  :authors '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainers '(("Stefan Kangas" . "stefankangas@gmail.com")))
