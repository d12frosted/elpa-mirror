(define-package "org-runbook" "20210825.1544" "Org mode for runbooks"
  '((emacs "26.1")
    (seq "2.3")
    (f "0.20.0")
    (s "1.12.0")
    (dash "2.17.0")
    (mustache "0.24")
    (ht "0.9")
    (ivy "0.8.0"))
  :commit "db59e2e9d4230997cca4cbf3a5bb1a89fd38f87f" :authors
  '(("Tyler Dodge"))
  :maintainer
  '("Tyler Dodge")
  :keywords
  '("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
