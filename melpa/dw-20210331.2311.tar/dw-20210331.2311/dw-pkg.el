;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dw" "20210331.2311"
  "Diceware passphrase generation commands."
  '((emacs "25.1"))
  :url "https://github.com/integral-dw/dw-passphrase-generator"
  :commit "61c5718ba64ace4c9e29de18aa2690ecc3f0f258"
  :revdesc "61c5718ba64a"
  :keywords '("convenience" "games")
  :authors '(("D. Williams" . "d.williams@posteo.net"))
  :maintainers '(("D. Williams" . "d.williams@posteo.net")))
