;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260516.1007"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "67babec2278f8ee1cf1c4dc605e976247388df51"
  :revdesc "67babec2278f")
