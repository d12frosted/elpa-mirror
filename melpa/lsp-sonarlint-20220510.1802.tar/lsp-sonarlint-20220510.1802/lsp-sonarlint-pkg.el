(define-package "lsp-sonarlint" "20220510.1802" "Emacs Sonarlint lsp client"
  '((emacs "25")
    (dash "2.12.0")
    (lsp-mode "6.3")
    (ht "2.3"))
  :commit "a429be2aea7797369a3c751ef54e3554733117be" :authors
  '(("Fermin MF" . "fmfs@posteo.net"))
  :maintainers
  '(("Fermin MF" . "fmfs@posteo.net"))
  :maintainer
  '("Fermin MF" . "fmfs@posteo.net")
  :keywords
  '("languages" "tools" "php" "javascript" "xml" "ruby" "html" "scala" "java" "python")
  :url "https://github.com/emacs-lsp/lsp-sonarlint")
;; Local Variables:
;; no-byte-compile: t
;; End:
