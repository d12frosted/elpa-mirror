(define-package "dwim-coder-mode" "20230815.641" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "beeba6664b1231caab2937bd1c8375fe559eeca6" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
