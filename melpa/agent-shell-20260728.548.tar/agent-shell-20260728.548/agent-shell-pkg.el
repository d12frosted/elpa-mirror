;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260728.548"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "25950ecc8d27491846aa92b7004de2e5a56d18b1"
  :revdesc "25950ecc8d27")
