;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "20241229.545"
  "Explore and visualise Denote files."
  '((emacs  "29.1")
    (denote "3.1")
    (dash   "2.19.1"))
  :url "https://github.com/pprevos/denote-explore"
  :commit "b5e84294d1ccd7d695b2f67e641e76134d360ae8"
  :revdesc "b5e84294d1cc"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
