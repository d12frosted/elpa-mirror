(define-package "consult" "20210517.418" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "a04b5e8db8b58c2600800403320f4804518e0608" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
