;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "real-auto-save" "20260104.324"
  "Automatically save your buffers/files at regular intervals."
  '((emacs "24.4"))
  :url "https://github.com/ChillarAnand/real-auto-save"
  :commit "43967684a5192ffd2f538bbd76b92bfc1576099e"
  :revdesc "43967684a519"
  :authors '(("Chaoji Li" . "lichaojiATgmailDOTcom")
             ("Anand Reddy Pandikunta" . "anand21nandaATgmailDOTcom"))
  :maintainers '(("Chaoji Li" . "lichaojiATgmailDOTcom")
                 ("Anand Reddy Pandikunta" . "anand21nandaATgmailDOTcom")))
