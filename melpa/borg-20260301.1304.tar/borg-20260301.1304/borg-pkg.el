;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260301.1304"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "e396a38138a3c991d34b6ab90eada83c3123536e"
  :revdesc "e396a38138a3"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
