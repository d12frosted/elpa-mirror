(define-package "modus-themes" "20220614.723" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "74e773a8a4c0d506bd64ee12b985eca96c2f6939" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
