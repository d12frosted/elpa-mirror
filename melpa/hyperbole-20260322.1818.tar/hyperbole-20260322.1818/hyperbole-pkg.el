;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260322.1818"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ff2dba3689e88ff67659b97b2acdb57ee195beb1"
  :revdesc "ff2dba3689e8"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
