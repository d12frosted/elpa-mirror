;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260629.1441"
  "Enhanced annotation system with threading."
  '((emacs     "28.1")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "75fdeec72dc7baa46c5bf2c0ad734bd94515353e"
  :revdesc "75fdeec72dc7"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
