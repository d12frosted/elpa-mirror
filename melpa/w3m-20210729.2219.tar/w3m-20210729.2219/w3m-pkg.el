(define-package "w3m" "20210729.2219" "an Emacs interface to w3m" 'nil :commit "c9d10534ce78fc863e63980a6324134e4f73c4cd" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
