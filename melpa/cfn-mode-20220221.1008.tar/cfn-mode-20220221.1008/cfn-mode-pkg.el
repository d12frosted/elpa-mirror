(define-package "cfn-mode" "20220221.1008" "AWS cloudformation mode"
  '((emacs "26.0")
    (f "0.20.0")
    (s "1.12.0")
    (yaml-mode "0.0.13"))
  :commit "e7cacde90d9b0258db1f7ea090c33aa49aac7d3d" :authors
  '(("William Orr" . "will@worrbase.com"))
  :maintainer
  '("William Orr" . "will@worrbase.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://gitlab.com/worr/cfn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
