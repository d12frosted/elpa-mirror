(define-package "biome" "20240103.2104" "Bountiful Interface to Open Meteo for Emacs"
  '((emacs "27.1")
    (transient "0.3.7")
    (ct "0.2")
    (request "0.3.3")
    (compat "29.1.4.1"))
  :commit "2f96d6de861da87797ae0ed79a6278718c1eb4e5" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/biome")
;; Local Variables:
;; no-byte-compile: t
;; End:
