;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260524.1500"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "e493b4dffe9152e5c430e1510a6297cdcf9bd54c"
  :revdesc "e493b4dffe91"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
