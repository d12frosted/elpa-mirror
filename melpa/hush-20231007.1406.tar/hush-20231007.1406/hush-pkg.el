(define-package "hush" "20231007.1406" "Pluggable secret manager"
  '((emacs "27.1"))
  :commit "56e55e69a05dbc64b8fffc708429135756498d91" :authors
  '(("Theodor-Alexandru Irimia"))
  :maintainers
  '(("Theodor-Alexandru Irimia"))
  :maintainer
  '("Theodor-Alexandru Irimia")
  :keywords
  '("extensions" "lisp" "local" "tools")
  :url "https://github.com/tirimia/hush")
;; Local Variables:
;; no-byte-compile: t
;; End:
