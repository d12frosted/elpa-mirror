;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "20260905.847"
  "Explore and visualise Denote files."
  '((emacs         "29.1")
    (denote        "4.2")
    (dash          "2.19.1")
    (denote-regexp "20250415.2202"))
  :url "https://github.com/pprevos/denote-explore/"
  :commit "45b61e1f312db37c4a1569dcebc02112ce3fea04"
  :revdesc "45b61e1f312d"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
