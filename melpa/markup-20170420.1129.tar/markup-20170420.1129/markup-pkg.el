;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markup" "20170420.1129"
  "Simple markup generation helpers."
  '((cl-lib "0.5"))
  :url "https://github.com/leoc/markup.el"
  :commit "876da2d3f23473475bb0fd0a1480ae11d2671291"
  :revdesc "876da2d3f234"
  :keywords '("convenience" "markup" "html")
  :authors '(("Arthur Leonard Andersen" . "leoc.git@gmail.com"))
  :maintainers '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")))
