(define-package "consult" "20210323.1627" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "19540d37783dc34bdb98d7cea24e8bb57090dab4" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
