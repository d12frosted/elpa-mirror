;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251024.1344"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "2c688e1c2c77afa9e8a6575a3dc51471b7c9c60e"
  :revdesc "2c688e1c2c77"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
