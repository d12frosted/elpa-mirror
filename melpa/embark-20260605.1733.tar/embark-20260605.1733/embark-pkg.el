;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark" "20260605.1733"
  "Conveniently act on minibuffer completions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/oantolin/embark"
  :commit "c2afd0ace3a5a0e995f07dccd97d84a68685c5c6"
  :revdesc "c2afd0ace3a5"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
