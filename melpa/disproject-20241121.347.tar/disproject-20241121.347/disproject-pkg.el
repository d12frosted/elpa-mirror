;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20241121.347"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.7.8"))
  :url "https://github.com/aurtzy/disproject"
  :commit "ad0d9a6f591b4ae13bd1dff006d3a4c776cee395"
  :revdesc "ad0d9a6f591b"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
