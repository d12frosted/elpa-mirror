(define-package "consult" "20220412.1243" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "af452dc5d429e15fb1228dd6967d592f1c483640" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
