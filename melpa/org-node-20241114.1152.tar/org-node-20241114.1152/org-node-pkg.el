;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241114.1152"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f11220bd85fe063531780a2a47413da0311d9e1d"
  :revdesc "f11220bd85fe"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
