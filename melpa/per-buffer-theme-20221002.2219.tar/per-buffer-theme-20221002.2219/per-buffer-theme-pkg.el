;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "per-buffer-theme" "20221002.2219"
  "Change theme and font according to buffer name or major mode."
  '((emacs "25.1"))
  :url "https://hg.serna.eu/emacs/per-buffer-theme"
  :commit "2cbb15c05edff4ce23ce61858cf16e8953cd58b3"
  :revdesc "2cbb15c05edf"
  :keywords '("themes")
  :authors '(("Iñigo Serna" . "inigoserna@gmx.com"))
  :maintainers '(("Iñigo Serna" . "inigoserna@gmx.com")))
