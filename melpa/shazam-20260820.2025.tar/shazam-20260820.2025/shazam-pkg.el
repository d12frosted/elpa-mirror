;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shazam" "20260820.2025"
  "Shazam Interface (macOS only)."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/shazam"
  :commit "a2488513bfb2df0fc125c51a2b1f5655a0ebbe26"
  :revdesc "a2488513bfb2"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
