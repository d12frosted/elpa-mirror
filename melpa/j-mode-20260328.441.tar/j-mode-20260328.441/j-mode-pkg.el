;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "j-mode" "20260328.441"
  "Major mode for editing J programs."
  ()
  :url "https://github.com/zellio/j-mode"
  :commit "9cb346ea3245d4416a8cae813bdf882630fcebd1"
  :revdesc "9cb346ea3245"
  :keywords '("j" "languages"))
