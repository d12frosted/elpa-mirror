;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250318.953"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (llama  "0.5.0")
    (el-job "2.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "3195ed87b476ab92fa5b1cf17f36f2a085ea42d6"
  :revdesc "3195ed87b476"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
