;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "20251222.933"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "e31295dc931b13004548b5e6acec2d13511115b9"
  :revdesc "e31295dc931b"
  :keywords '("color" "theme" "faces"))
