;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251105.1745"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "a77927a08df0f3fdf725d3832d5bc56aa3ea5e07"
  :revdesc "a77927a08df0"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
