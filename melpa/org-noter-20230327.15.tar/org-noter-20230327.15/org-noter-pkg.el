(define-package "org-noter" "20230327.15" "A synchronized, Org-mode, document annotator"
  '((emacs "24.4")
    (cl-lib "0.6")
    (org "9.0"))
  :commit "9a1722c5db45450780a782a8714cbb5b64d272d8" :authors
  '(("Gonçalo Santos (github.com/weirdNox)" . "in@bsentia")
    ("   Maintainer Dmitry M" . "dmitrym@gmail.com"))
  :maintainer
  '("Peter Mao" . "peter.mao@gmail.com")
  :keywords
  '("lisp" "pdf" "interleave" "annotate" "external" "sync" "notes" "documents" "org-mode")
  :url "https://github.com/org-noter/org-noter")
;; Local Variables:
;; no-byte-compile: t
;; End:
