(define-package "embark" "20230130.209" "Conveniently act on minibuffer completions"
  '((emacs "26.1")
    (compat "29.1.3.0"))
  :commit "5d9fc9c56261cf0cdebeead19cc2702098fe5138" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
