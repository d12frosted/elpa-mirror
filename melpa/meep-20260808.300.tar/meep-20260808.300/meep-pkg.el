;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260808.300"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "8782f2d2f39ebd06958ebe144fa33e08f9699c20"
  :revdesc "8782f2d2f39e"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
