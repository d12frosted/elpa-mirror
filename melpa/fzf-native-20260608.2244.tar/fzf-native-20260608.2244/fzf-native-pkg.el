;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260608.2244"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "c2ea8fabe15577ffcff43a4641dbea69a718dd14"
  :revdesc "c2ea8fabe155"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
