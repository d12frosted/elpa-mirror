;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-jslint" "20170723.146"
  "A flymake handler for javascript using jslint."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-jslint"
  :commit "8edb82be605542b0ef62d38d818adcdde335eecb"
  :revdesc "8edb82be6055"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
