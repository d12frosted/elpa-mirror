(define-package "embark" "20220219.1757" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "6683d7023c4128b4d62df2df56cdb7168f4844ed" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
