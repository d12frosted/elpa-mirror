;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260725.854"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "24ce68421067f8a46d223dff927ab460cdbad33b"
  :revdesc "24ce68421067"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
