(define-package "embark" "20220321.250" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "3a9e5e1744033511ca32beeea42f228c7948448e" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
