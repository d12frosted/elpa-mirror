;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "call-graph" "20251224.1727"
  "Generate call graph for c/c++ functions."
  '((emacs     "26.1")
    (tree-mode "1.0.0")
    (ivy       "0.10.0")
    (beacon    "1.3.4"))
  :url "https://github.com/beacoder/call-graph"
  :commit "a4b1004aa9428776d18b41cadea27da6143308bb"
  :revdesc "a4b1004aa942"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
