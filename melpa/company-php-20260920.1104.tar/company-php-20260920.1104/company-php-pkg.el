;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-php" "20260920.1104"
  "A company back-end for PHP."
  '((cl-lib      "0.5")
    (ac-php-core "2.0")
    (company     "0.9"))
  :url "https://github.com/xcwen/ac-php"
  :commit "07f008af2c04dc396454be560640e47c83b033c9"
  :revdesc "07f008af2c04"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
