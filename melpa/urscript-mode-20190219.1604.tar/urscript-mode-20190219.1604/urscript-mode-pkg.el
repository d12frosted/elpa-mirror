;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "urscript-mode" "20190219.1604"
  "Major mode for editing URScript."
  '((emacs "24.4"))
  :url "https://github.com/guidoschmidt/urscript-mode"
  :commit "b341f96b129ead8fb74d680cb4f546985bf110a9"
  :revdesc "b341f96b129e"
  :keywords '("languages")
  :authors '(("Guido Schmidt" . "(git@guidoschmidt.cc)"))
  :maintainers '(("Guido Schmidt" . "(git@guidoschmidt.cc)")))
