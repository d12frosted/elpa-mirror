;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260925.1542"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "6bcb626f1a7e2b4f39146f6f9c3d9460858f7ab1"
  :revdesc "6bcb626f1a7e"
  :keywords '("languages" "lisp" "slime"))
