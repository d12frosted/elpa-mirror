;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "20260901.1147"
  "Slack client."
  '((websocket "1.12")
    (request   "0.3.2")
    (circe     "2.11")
    (alert     "1.2")
    (emojify   "1.2.0")
    (emacs     "25.1")
    (dash      "2.19.1")
    (s         "1.13.0")
    (ts        "0.3"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "a7c971ef6f92ec1b9dca164512cd276a95cdfaa5"
  :revdesc "a7c971ef6f92"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
