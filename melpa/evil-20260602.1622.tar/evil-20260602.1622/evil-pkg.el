;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil" "20260602.1622"
  "Extensible vi layer."
  '((emacs    "24.1")
    (cl-lib   "0.5")
    (goto-chg "1.6")
    (nadvice  "0.3"))
  :url "https://github.com/emacs-evil/evil"
  :commit "30c88945002b2a734ebb778054b19b2e58995723"
  :revdesc "30c88945002b"
  :keywords '("emulations")
  :maintainers '(("Tom Dalziel" . "tom.dalziel@gmail.com")))
