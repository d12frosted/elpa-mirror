;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liblouis" "20220426.657"
  "Mode for editing liblouis braille translation tables."
  '((emacs "26.1"))
  :url "https://github.com/liblouis/liblouis-mode"
  :commit "a341a0c434cdbe7f46956c8db13203c3fc941a34"
  :revdesc "a341a0c434cd"
  :keywords '("languages")
  :authors '(("Christian Egli" . "christian.egli@sbs.ch"))
  :maintainers '(("Christian Egli" . "christian.egli@sbs.ch")))
