;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontsloth" "20261114.1352"
  "Elisp otf/ttf font loader/renderer."
  '((async  "1.9.7")
    (f      "0.20.0")
    (logito "0.1")
    (pcache "0.5")
    (emacs  "28.1"))
  :url "https://github.com/jollm/fontsloth"
  :commit "3f04b58f1696df5472b4d036b4dd1c4a52bb119f"
  :revdesc "3f04b58f1696"
  :keywords '("data" "font" "rasterization" "ttf" "otf")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")))
