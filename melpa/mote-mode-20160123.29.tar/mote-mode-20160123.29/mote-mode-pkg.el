;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mote-mode" "20160123.29"
  "Mote minor mode."
  '((ruby-mode "1.1"))
  :url "http://inkel.github.com/mote-mode/"
  :commit "666c6641addbd3b337a7aa01fd2742ded2f41b83"
  :revdesc "666c6641addb"
  :authors '(("Leandro López" . "inkel.ar@gmail.com"))
  :maintainers '(("Leandro López" . "inkel.ar@gmail.com")))
