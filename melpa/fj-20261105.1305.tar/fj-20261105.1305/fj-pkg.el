;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20261105.1305"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.5")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "817eceb81812819d1c1c57f3db567af0e7233734"
  :revdesc "817eceb81812"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
