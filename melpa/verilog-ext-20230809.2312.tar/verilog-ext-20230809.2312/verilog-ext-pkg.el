(define-package "verilog-ext" "20230809.2312" "SystemVerilog Extensions"
  '((emacs "28.1")
    (verilog-mode "2022.12.18.181110314")
    (eglot "1.9")
    (lsp-mode "8.0.1")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (apheleia "3.1")
    (yasnippet "0.14.0")
    (company "0.9.13")
    (flycheck "33snapshot")
    (outshine "3.1pre")
    (async "1.9.7"))
  :commit "907cab548c0cf6373a5ad640a74c37f9970f4dc0" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
