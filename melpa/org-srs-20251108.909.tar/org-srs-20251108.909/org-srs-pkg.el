;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251108.909"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "bcf5d844e85c5065ee1e5dfe67fc3afbd48f51b7"
  :revdesc "bcf5d844e85c"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
