;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250617.208"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "7dae4d566703e043b4d66044256c12a463735a6f"
  :revdesc "7dae4d566703"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
