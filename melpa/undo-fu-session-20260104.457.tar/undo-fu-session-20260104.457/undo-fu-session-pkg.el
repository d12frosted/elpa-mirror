;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu-session" "20260104.457"
  "Persistent undo, available between sessions."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu-session"
  :commit "fedd4730ffa0b984436a22d395d3ee6cafd56548"
  :revdesc "fedd4730ffa0"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
