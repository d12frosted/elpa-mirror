;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-ts-defs" "20251118.504"
  "Find JavaScript variable definitions using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/jacksonrayhamilton/js-ts-defs"
  :commit "6e6d052855133534c9a175a813f01aea428a6a68"
  :revdesc "6e6d05285513"
  :keywords '("languages" "javascript" "tree-sitter")
  :authors '(("Jackson Ray Hamilton" . "jackson@jacksonrayhamilton.com"))
  :maintainers '(("Jackson Ray Hamilton" . "jackson@jacksonrayhamilton.com")))
