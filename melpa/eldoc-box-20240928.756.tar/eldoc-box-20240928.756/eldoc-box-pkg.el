(define-package "eldoc-box" "20240928.756" "Display documentation in childframe"
  '((emacs "27.1"))
  :commit "25a61874059a8046be7d32855299998790f4ef0f" :authors
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainer
  '("Yuan Fu" . "casouri@gmail.com")
  :url "https://github.com/casouri/eldoc-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
