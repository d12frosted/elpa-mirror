;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250705.1734"
  "Add ╭─╴UNICODE╶─╮ based ╭─╴diagrams╶─╮ to ╭▶╴text files╶●╮."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "d8dd23ba079ac3fba12297958f995ac45879f0bd"
  :revdesc "d8dd23ba079a"
  :keywords '("convenience" "text"))
