(define-package "modus-themes" "20220705.757" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "ef0e3f5229422f3e7da285e3cfe121ed90101902" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
