(define-package "cape" "20230819.1735" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "11cc35cc890c4789a12ca32e35917a15ec2bc1c5" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
