(define-package "consult" "20210309.1757" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "e0449110d8b132161a3abc3d77caa6e1bbd34948" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
