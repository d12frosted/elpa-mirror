;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260111.2226"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "df465dfb01eb3a457b564b843f940fd9470fd4e8"
  :revdesc "df465dfb01eb"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
