;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20260413.1309"
  "Light cornsilk theme with warm, earthy colors."
  '((emacs        "28.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "6aa1032159f4d6108add567f7f1270788e1dcec8"
  :revdesc "6aa1032159f4"
  :keywords '("faces" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
