;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251028.1410"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "4ca238e8f90b1687d9405f001690c9aa76b3ac21"
  :revdesc "4ca238e8f90b"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
