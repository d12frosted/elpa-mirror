;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-repo-todo" "20171228.119"
  "Simple repository todo management with org-mode."
  ()
  :url "https://github.com/waymondo/org-repo-todo"
  :commit "f73ebd91399c5760ad52c6ad9033de1066042003"
  :revdesc "f73ebd91399c"
  :keywords '("convenience")
  :authors '(("justin talbott" . "justin@waymondo.com"))
  :maintainers '(("justin talbott" . "justin@waymondo.com")))
