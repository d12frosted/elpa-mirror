;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260605.743"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "c168b06e408adc4b3ac03163e96e3dcbaac884bc"
  :revdesc "c168b06e408a"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
