;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magic-latex-buffer" "20260908.843"
  "Magically enhance LaTeX-mode font-locking for semi-WYSIWYG editing."
  '((cl-lib "0.5")
    (emacs  "25.1"))
  :url "http://zk-phi.github.io/"
  :commit "31eb152b61b33a4017dd254a560be67e4b5ddd3c"
  :revdesc "31eb152b61b3")
