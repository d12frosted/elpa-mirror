;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-dictionary" "20261009.1257"
  "Interface for OSX Dictionary.app."
  '((cl-lib "0.5"))
  :url "https://github.com/xuchunyang/osx-dictionary.el"
  :commit "5974032809692eb1166d57b55dd6390ffe3acd7f"
  :revdesc "597403280969"
  :keywords '("mac" "dictionary")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
