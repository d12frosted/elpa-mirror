;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20260901.1442"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (treepy   "1.0.0"))
  :url "https://github.com/magit/ghub"
  :commit "9e86c1cdc3f16fc5b622a18d868ace85a9764dce"
  :revdesc "9e86c1cdc3f1"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
