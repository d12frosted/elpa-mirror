(define-package "clojure-mode" "20230623.2048" "Major mode for Clojure code"
  '((emacs "25.1"))
  :commit "47ce793466768e97065cf7afc4cf95804d648415" :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.dev")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
