(define-package "embark" "20210827.551" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "5f157be8f0de5c003f061033549894c5c89d9d25" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
