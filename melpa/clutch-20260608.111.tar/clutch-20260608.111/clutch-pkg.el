;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260608.111"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "3efc82a7ca4c58da3a07321fe2a57dc87d77f105"
  :revdesc "3efc82a7ca4c"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
