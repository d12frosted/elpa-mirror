(define-package "modus-themes" "20210207.1515" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "e244038fd8a054799852e851e99e96cfb2b86890" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
