;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mise" "20250123.1837"
  "Support for `mise' cli."
  '((emacs      "29.1")
    (inheritenv "0.2")
    (dash       "2.19.1"))
  :url "https://github.com/eki3z/mise.el"
  :commit "eab4e60b2aae46eb2dcd1a3b5df08d8e128adf2f"
  :revdesc "eab4e60b2aae"
  :keywords '("tools" "processes")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
