;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aria2" "20230314.2131"
  "Control aria2c commandline tool from Emacs."
  '((emacs "25.1"))
  :url "https://bitbucket.org/ukaszg/aria2-mode"
  :commit "1f2cbe624f3a4e0109b5dc123bb4bbed496b15a7"
  :revdesc "1f2cbe624f3a"
  :keywords '("download" "bittorrent" "aria2")
  :authors '(("ukasz Gruner" . "lukasz@gruner.lu"))
  :maintainers '(("ukasz Gruner" . "lukasz@gruner.lu")))
