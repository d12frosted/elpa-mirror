(define-package "mentor" "20221030.1355" "Frontend for the rTorrent bittorrent client"
  '((emacs "25.1")
    (xml-rpc "1.6.15")
    (seq "1.11")
    (async "1.9.3")
    (url-scgi "0.8"))
  :commit "089df9b6d0cb8289cb1226ca6dce45ab6c9ce43b" :authors
  '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainer
  '("Stefan Kangas" . "stefankangas@gmail.com")
  :keywords
  '("comm" "processes" "bittorrent")
  :url "https://github.com/skangas/mentor")
;; Local Variables:
;; no-byte-compile: t
;; End:
