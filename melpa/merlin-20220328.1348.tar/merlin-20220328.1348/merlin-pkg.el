(define-package "merlin" "20220328.1348" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "5225600f95b48efd729b500693079087cfd90ed8" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
