;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom" "20180301.2308"
  "DOM implementation and manipulation library."
  '((cl-lib "0.5"))
  :url "http://www.github.com/kensanata/doom.el/"
  :commit "e59040aefc92dd9b3134eb623624307fb9e4327b"
  :revdesc "e59040aefc92"
  :keywords '("xml" "dom")
  :authors '(("Alex Schroeder" . "alex@gnu.org")
             ("Henrik.Motakef" . "elisp@henrik-motakef.de")
             ("Katherine Whitlock" . "toroidal-code@gmail.com")
             ("Syohei YOSHIDA" . "syohex@gmail.com")))
