;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260814.2134"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "a40da551f3a948209e1cc8dbb9a151dc429bb3e5"
  :revdesc "a40da551f3a9"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
