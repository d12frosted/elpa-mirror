;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260602.2239"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "673b38022b8bb36185b6d54aff3f444335a032fb"
  :revdesc "673b38022b8b"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
