;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260123.1616"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "595ca131343a6fc964442bc8c36af3a6bf145c95"
  :revdesc "595ca131343a"
  :keywords '("convenience"))
