(define-package "embark" "20210120.1715" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "9c37c5e9db1c8024dca5624f50c003335f047368" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
