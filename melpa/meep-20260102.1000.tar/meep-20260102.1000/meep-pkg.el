;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260102.1000"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "cadabdf0d3478ca154c33d070c4540fa1cecc63d"
  :revdesc "cadabdf0d347"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
