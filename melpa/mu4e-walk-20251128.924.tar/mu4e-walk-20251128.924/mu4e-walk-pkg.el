;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-walk" "20251128.924"
  "Send email addresses for a walk."
  '((emacs "29.1"))
  :url "https://codeberg.org/timmli/mu4e-walk"
  :commit "077b25d42f7fff5c5cf7d71ad961daa598dc2a8e"
  :revdesc "077b25d42f7f"
  :keywords '("convenience" "mail")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
