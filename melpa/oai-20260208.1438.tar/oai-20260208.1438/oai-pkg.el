;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260208.1438"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "9a81604a95c2ae8a27641273f171eecd76548f09"
  :revdesc "9a81604a95c2"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
