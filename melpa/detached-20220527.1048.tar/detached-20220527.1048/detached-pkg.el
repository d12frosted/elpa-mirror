(define-package "detached" "20220527.1048" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "f08110df5761c5803197ecce8b70eeb1c05e61db" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
