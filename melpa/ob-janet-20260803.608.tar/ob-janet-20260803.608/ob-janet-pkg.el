;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-janet" "20260803.608"
  "Org-Babel support for the Janet language."
  '((emacs "26.1")
    (org   "9.1"))
  :url "https://codeberg.org/zzkt/ob-janet"
  :commit "5ff5091602b9085d0e1ed071a42805448e93546f"
  :revdesc "5ff5091602b9"
  :keywords '("languages" "tools" "literate programming" "janet")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
