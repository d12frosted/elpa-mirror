(define-package "geiser-guile" "20220316.2111" "Guile's implementation of the geiser protocols"
  '((emacs "25.1")
    (geiser "0.23.1"))
  :commit "aa48110d69b018f03dbff0aa9e830111fef71da4" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
