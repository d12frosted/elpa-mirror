(define-package "pyim" "20230116.1237" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "27.1")
    (async "1.6")
    (xr "1.13"))
  :commit "0d17895ef2e1d091080dacc3a72ecbb3bd7580ff" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
