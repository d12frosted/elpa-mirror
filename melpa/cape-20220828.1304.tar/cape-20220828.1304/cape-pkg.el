(define-package "cape" "20220828.1304" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "0361400a3affad43b8eb4972a942fee8dfe0c649" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
