(define-package "indian-ext" "20190424.1547" "Extension to Indian language utilities"
  '((emacs "24"))
  :commit "a5450fe467393194bc2458c0d5e0a06c91bf117a" :authors
  '(("Patrick McAllister" . "pma@rdorte.org"))
  :maintainers
  '(("Patrick McAllister" . "pma@rdorte.org"))
  :maintainer
  '("Patrick McAllister" . "pma@rdorte.org")
  :keywords
  '("i18n" "tools" "wp" "indian" "devanagari" "encoding")
  :url "https://github.com/paddymcall/indian-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
