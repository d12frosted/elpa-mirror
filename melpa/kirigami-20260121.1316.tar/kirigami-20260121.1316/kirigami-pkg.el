;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260121.1316"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "1bd0f1cceac01af55a9231d20c594d12261bbc80"
  :revdesc "1bd0f1cceac0"
  :keywords '("convenience"))
