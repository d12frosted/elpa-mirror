(define-package "harpoon" "20230521.1907" "Bookmarks on steroids"
  '((emacs "27.2")
    (f "0.20.0")
    (hydra "0.14.0")
    (project "0.8.1"))
  :commit "7b64b701e46b9117217c8b01e49e00db78463985" :authors
  '(("Otávio Schwanck" . "otavioschwanck@gmail.com"))
  :maintainers
  '(("Otávio Schwanck" . "otavioschwanck@gmail.com"))
  :maintainer
  '("Otávio Schwanck" . "otavioschwanck@gmail.com")
  :keywords
  '("tools" "languages")
  :url "https://github.com/otavioschwanck/harpoon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
