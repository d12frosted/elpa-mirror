;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dactyl-mode" "20140906.1725"
  "Major mode for editing Pentadactyl config files."
  ()
  :url "https://github.com/luxbock/dactyl-mode"
  :commit "cc55fe6b987271d9647492b8df4c812d884f661f"
  :revdesc "cc55fe6b9872"
  :keywords '("languages" "vim")
  :authors '(("Alpha Tan" . "alphatan.zh@gmail.com"))
  :maintainers '(("Alpha Tan" . "alphatan.zh@gmail.com")))
