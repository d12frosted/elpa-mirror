(define-package "vulpea" "20210304.800" "A collection of org-roam note-taking functions"
  '((emacs "27.1")
    (org "9.4.4")
    (org-roam "1.2.3")
    (s "1.12"))
  :commit "2d145e74ad3de770ee5a35b5cb5afd9d7f1afa99" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
