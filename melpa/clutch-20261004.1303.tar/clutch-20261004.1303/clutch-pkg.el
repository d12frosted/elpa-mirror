;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261004.1303"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "3b256b80dd06dcde25d78f601368a32dbf39c236"
  :revdesc "3b256b80dd06"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
