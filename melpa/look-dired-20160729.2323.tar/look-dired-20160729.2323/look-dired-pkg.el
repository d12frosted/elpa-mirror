;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "look-dired" "20160729.2323"
  "Extensions to look-mode for dired buffers."
  '((look-mode "1.0"))
  :url "https://github.com/vapniks/look-dired"
  :commit "9bfa4e5e6f3810705b6426c88493ea0bf6b15640"
  :revdesc "9bfa4e5e6f38"
  :keywords '("convenience")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
