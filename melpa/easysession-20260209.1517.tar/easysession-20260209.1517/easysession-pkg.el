;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260209.1517"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "f758e12c9736ef85adc2a498e6dc5df1e9249a4c"
  :revdesc "f758e12c9736"
  :keywords '("convenience"))
