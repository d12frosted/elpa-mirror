;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260702.1513"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "9101db52a29c4276b45f85e63924008f0e41c39c"
  :revdesc "9101db52a29c"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
