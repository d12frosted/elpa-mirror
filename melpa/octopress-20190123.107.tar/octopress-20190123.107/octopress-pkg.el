;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "octopress" "20190123.107"
  "A lightweight wrapper for Jekyll and Octopress."
  ()
  :url "https://github.com/aaronbieber/octopress.el"
  :commit "f2c92d5420f14fc9167c7de1873836510e652de2"
  :revdesc "f2c92d5420f1"
  :keywords '("octopress" "blog")
  :authors '(("Aaron Bieber" . "aaron@aaronbieber.com"))
  :maintainers '(("Aaron Bieber" . "aaron@aaronbieber.com")))
