(define-package "hl-prog-extra" "20220708.211" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "67813ae7b81c9e14f077937cd6fbbad0cc0e6a91" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
