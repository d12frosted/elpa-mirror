;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260829.131"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "1f39b0b9587251441f7cfb751d47ac1a4f133e42"
  :revdesc "1f39b0b95872"
  :keywords '("languages"))
