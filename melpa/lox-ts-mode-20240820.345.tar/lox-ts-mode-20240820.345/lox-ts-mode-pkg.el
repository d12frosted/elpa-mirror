;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lox-ts-mode" "20240820.345"
  "Major mode for Lox using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/lox-ts-mode"
  :commit "3a482f6a96318d617d35683089d5edb405cd0752"
  :revdesc "3a482f6a9631"
  :keywords '("lox" "tree-sitter" "languages")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
