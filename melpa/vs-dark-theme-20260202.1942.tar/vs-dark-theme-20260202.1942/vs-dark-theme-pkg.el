;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-dark-theme" "20260202.1942"
  "Visual Studio IDE dark theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-dark-theme"
  :commit "d9d35fe53e42cd3126c6c42a7aa519fc57e46b2e"
  :revdesc "d9d35fe53e42"
  :keywords '("faces"))
