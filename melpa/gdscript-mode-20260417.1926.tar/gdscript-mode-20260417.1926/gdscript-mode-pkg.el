;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260417.1926"
  "Major mode for Godot's GDScript language."
  '((emacs "28.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "f6ee6891e15b4aaf4e159ecf3ab8482da6fe0ea7"
  :revdesc "f6ee6891e15b"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
