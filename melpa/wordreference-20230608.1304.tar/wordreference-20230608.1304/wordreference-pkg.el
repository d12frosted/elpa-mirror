(define-package "wordreference" "20230608.1304" "Interface for wordreference.com"
  '((emacs "28.1"))
  :commit "10f29c530c5f7584dc524111689f98a2a6a63f12" :authors
  '(("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainers
  '(("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainer
  '("Marty Hiatt <martianhiatus AT riseup.net>")
  :keywords
  '("convenience" "translate" "wp" "dictionary")
  :url "https://codeberg.org/martianh/wordreference.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
