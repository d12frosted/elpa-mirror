(define-package "matlab-mode" "20230424.1248" "Major mode for MATLAB(R) dot-m files" 'nil :commit "ba655a6e1375fb251796e2fe16d14d5228e6de35")
;; Local Variables:
;; no-byte-compile: t
;; End:
