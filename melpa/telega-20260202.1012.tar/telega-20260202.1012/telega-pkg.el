;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260202.1012"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "805819bf81dffe2922e9e06ae02d58429d03aa1a"
  :revdesc "805819bf81df"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
