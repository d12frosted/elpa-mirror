(define-package "citre" "20220521.1145" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "093722a4ba4e339d5c85fa6a56b5cfb0777a5cc5" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
