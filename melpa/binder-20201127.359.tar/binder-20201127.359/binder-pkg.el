(define-package "binder" "20201127.359" "Global minor mode to facilitate multi-file writing projects"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "e1f5dea7dfb4fc14d1f34ace3d8a049e51d1b4f4" :keywords
  ("files" "outlines" "wp" "text")
  :authors
  (("Paul W. Rankin" . "pwr@skeletons.cc"))
  :maintainer
  ("Paul W. Rankin" . "pwr@skeletons.cc")
  :url "https://git.skeletons.cc/binder")
;; Local Variables:
;; no-byte-compile: t
;; End:
