;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "votd" "20250420.2028"
  "Bible Verse Of The Day."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/votd"
  :commit "3fae453640d172bebf01e6a639cf7287117fc668"
  :revdesc "3fae453640d1"
  :keywords '("convenience" "comm" "hypermedia"))
