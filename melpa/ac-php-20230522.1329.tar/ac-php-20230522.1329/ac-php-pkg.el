(define-package "ac-php" "20230522.1329" "Auto Completion source for PHP."
  '((ac-php-core "2.0")
    (auto-complete "1.4.0")
    (yasnippet "0.8.0"))
  :commit "4c678709e1e1f1673a83b9eb01875e457c6ca658" :authors
  '(("jim" . "xcwenn@qq.com"))
  :maintainers
  '(("jim"))
  :maintainer
  '("jim")
  :keywords
  '("completion" "convenience" "intellisense")
  :url "https://github.com/xcwen/ac-php")
;; Local Variables:
;; no-byte-compile: t
;; End:
