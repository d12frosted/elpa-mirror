(define-package "mame" "20231021.1522" "A MAME front-end"
  '((emacs "27.1"))
  :commit "04322e0b036198112417cf688ddf6b711010561e" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
