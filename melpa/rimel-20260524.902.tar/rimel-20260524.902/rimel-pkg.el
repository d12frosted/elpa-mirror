;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260524.902"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "ea78ca3a1fd0396b57948ed3b69a1f4f2582eb27"
  :revdesc "ea78ca3a1fd0"
  :keywords '("convenience" "chinese" "input-method" "rime"))
