;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260721.157"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "98aef2f0d116c73062f588b3c4490510780b1ced"
  :revdesc "98aef2f0d116"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
