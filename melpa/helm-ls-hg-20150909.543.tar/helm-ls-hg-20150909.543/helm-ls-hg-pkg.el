;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ls-hg" "20150909.543"
  "List hg files in hg project."
  '((helm "1.7.8"))
  :url "https://github.com/emacs-helm/helm-ls-hg"
  :commit "61b91a22fcfb62d0fc56e361ec01ce96973c7165"
  :revdesc "61b91a22fcfb")
