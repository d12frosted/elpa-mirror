;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "20251107.319"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "568ae1af3277ed43a22c84280d788b37b00986d1"
  :revdesc "568ae1af3277"
  :keywords '("hypermedia"))
