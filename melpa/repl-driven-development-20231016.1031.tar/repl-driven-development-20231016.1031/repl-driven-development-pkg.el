(define-package "repl-driven-development" "20231016.1031" "Send arbitrary code to a REPL in the background"
  '((s "1.12.0")
    (lf "1.0")
    (dash "2.16.0")
    (eros "0.1.0")
    (bind-key "2.4.1")
    (emacs "29")
    (f "0.20.0")
    (devdocs "0.5")
    (pulsar "1.0.1")
    (peg "1.0.1")
    (hierarchy "0.6.0")
    (json-navigator "0.1.1"))
  :commit "640415e0d1a7bba2e7d739a1fb52d00c643213e9" :authors
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainer
  '("Musa Al-hassy" . "alhassy@gmail.com")
  :keywords
  '("repl-driven-development" "rdd" "repl" "lisp" "eval" "java" "python" "ruby" "programming" "convenience")
  :url "http://alhassy.com/repl-driven-development")
;; Local Variables:
;; no-byte-compile: t
;; End:
