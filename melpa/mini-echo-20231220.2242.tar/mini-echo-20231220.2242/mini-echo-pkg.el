(define-package "mini-echo" "20231220.2242" "Echo buffer status in minibuffer window"
  '((emacs "29.1"))
  :commit "0559dd59b8e122d15225a8763bdfcdc173129570" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
