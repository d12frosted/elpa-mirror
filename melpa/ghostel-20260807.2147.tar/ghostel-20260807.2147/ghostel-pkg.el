;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260807.2147"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "037378b44ceedf1c8bf15e365fc62c7f5c92363d"
  :revdesc "037378b44cee"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
