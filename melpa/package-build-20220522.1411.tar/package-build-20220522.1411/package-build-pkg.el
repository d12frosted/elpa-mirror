(define-package "package-build" "20220522.1411" "Tools for assembling a package archive"
  '((emacs "25.1"))
  :commit "710e538ad1d104f4059b5cf7edad4c91e9ad4c83" :authors
  '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
    ("Steve Purcell" . "steve@sanityinc.com")
    ("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainer
  '("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
  :keywords
  '("maint" "tools")
  :url "https://github.com/melpa/package-build")
;; Local Variables:
;; no-byte-compile: t
;; End:
