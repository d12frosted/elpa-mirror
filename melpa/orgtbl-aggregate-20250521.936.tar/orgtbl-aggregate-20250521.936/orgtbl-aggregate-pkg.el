;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20250521.936"
  "Create an Org Mode aggregated table from another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "7130c4627c1cfde14f7b9943c68c7149031d024a"
  :revdesc "7130c4627c1c"
  :keywords '("data" "extensions"))
