;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250528.1423"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "54bcfefddd6a8b3f2d31220c4f2087ebe3c16b3a"
  :revdesc "54bcfefddd6a"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
