(define-package "helm-core" "20220809.1446" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "9855b843f3b17f00936d84139548718b7d1979c3" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
