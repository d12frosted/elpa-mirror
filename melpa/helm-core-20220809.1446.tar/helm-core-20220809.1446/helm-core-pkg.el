(define-package "helm-core" "20220809.1446" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "b72589386f00f07fdd4f06b9c83a79c27a4faca9" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
