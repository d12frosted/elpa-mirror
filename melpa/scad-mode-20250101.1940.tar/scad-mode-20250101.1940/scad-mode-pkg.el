;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "20250101.1940"
  "A major mode for editing OpenSCAD code."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "5dfec8f8dcf587c15b616b9dc840c55b38a9dba9"
  :revdesc "5dfec8f8dcf5"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
