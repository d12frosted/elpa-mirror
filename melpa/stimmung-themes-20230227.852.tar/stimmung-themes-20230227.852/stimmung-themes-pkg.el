(define-package "stimmung-themes" "20230227.852" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "85bee715164c186114d986332b7d694a0c9c068c" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
