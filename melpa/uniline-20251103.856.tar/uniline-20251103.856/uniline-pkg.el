;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20251103.856"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "ad4aa28b3700b23cab161fba3660b11d0b33de05"
  :revdesc "ad4aa28b3700"
  :keywords '("convenience" "text"))
