;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-autofmt" "20260329.55"
  "Emacs lisp auto-format."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt"
  :commit "4436178ae0954c5c52d27571e7f2c5c31f5638b2"
  :revdesc "4436178ae095"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
