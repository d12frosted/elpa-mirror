(define-package "diff-hl" "20230409.2256" "Highlight uncommitted changes using VC"
  '((cl-lib "0.2")
    (emacs "25.1"))
  :commit "ed34450246598af02299053feb9d85d6675114dd" :authors
  '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("vc" "diff")
  :url "https://github.com/dgutov/diff-hl")
;; Local Variables:
;; no-byte-compile: t
;; End:
