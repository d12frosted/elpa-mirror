;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flim" "20251102.2052"
  "Basic message representation and encoding features."
  '((emacs  "24.5")
    (apel   "0")
    (oauth2 "0.17"))
  :url "https://github.com/emacsmirror/flim"
  :commit "b7265bae4b11a1434f5c0acf78ba13580bf00cfc"
  :revdesc "b7265bae4b11"
  :keywords '("mime" "multimedia" "mail" "news"))
