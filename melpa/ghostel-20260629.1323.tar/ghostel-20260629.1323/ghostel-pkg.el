;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260629.1323"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "c6437ed79cc7a02c6feee0595fd04d78638ac8c7"
  :revdesc "c6437ed79cc7"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
