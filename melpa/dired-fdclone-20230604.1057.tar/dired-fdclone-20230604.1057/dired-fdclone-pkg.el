(define-package "dired-fdclone" "20230604.1057" "dired functions and settings to mimic FDclone" 'nil :commit "38555dc5a9427664b9b24af352de7550939625de" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("unix" "directories" "dired")
  :url "https://github.com/knu/dired-fdclone.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
