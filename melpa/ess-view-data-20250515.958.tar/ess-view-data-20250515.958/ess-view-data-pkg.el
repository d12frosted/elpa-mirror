;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-view-data" "20250515.958"
  "View Data."
  '((emacs     "26.1")
    (ess       "18.10.1")
    (csv-mode  "1.12")
    (transient "0.3.7"))
  :url "https://github.com/ShuguangSun/ess-view-data"
  :commit "dc1355d838eeac47143790b2745ae826400609ab"
  :revdesc "dc1355d838ee"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
