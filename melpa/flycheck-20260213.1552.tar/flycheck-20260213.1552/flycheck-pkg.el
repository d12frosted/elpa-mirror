;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260213.1552"
  "On-the-fly syntax checking."
  '((emacs "27.1")
    (seq   "2.24"))
  :url "https://www.flycheck.org"
  :commit "dc39d6dea16c4b1859025a41895769b72665c4b1"
  :revdesc "dc39d6dea16c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
