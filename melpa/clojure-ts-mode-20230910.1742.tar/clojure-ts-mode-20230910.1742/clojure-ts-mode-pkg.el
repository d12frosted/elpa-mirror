(define-package "clojure-ts-mode" "20230910.1742" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "d6ac60f17a702ee74b87ce3785b1fccb37a95e03" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
