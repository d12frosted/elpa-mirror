;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xwidgete" "20171118.2116"
  "Enhances usability of current xwidget browser."
  '((emacs "25"))
  :url "https://github.com/tuhdo/xwidgete"
  :commit "e4e8410fe32176df85b46234717824519443fb04"
  :revdesc "e4e8410fe321"
  :keywords '("xwidgete" "tools")
  :authors '(("Do Hoang" . "tuhdo1710@gmail.com")))
