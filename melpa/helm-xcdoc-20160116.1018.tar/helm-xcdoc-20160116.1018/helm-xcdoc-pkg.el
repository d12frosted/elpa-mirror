;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-xcdoc" "20160116.1018"
  "Search Xcode Document by docsetutil and eww with helm interface."
  '((helm  "1.5")
    (emacs "24.4"))
  :url "https://github.com/fujimisakari/emacs-helm-xcdoc"
  :commit "a85612149a6d8e18ab309b3db2d222ce39c42049"
  :revdesc "a85612149a6d"
  :authors '(("Ryo Fujimoto" . "fujimisakri@gmail.com"))
  :maintainers '(("Ryo Fujimoto" . "fujimisakri@gmail.com")))
