(define-package "hyperdrive" "20240806.219" "P2P filesystem"
  '((emacs "28.1")
    (map "3.0")
    (compat "30.0.0.0")
    (org "9.7.6")
    (plz "0.9.0")
    (persist "0.6.1")
    (taxy-magit-section "0.13")
    (transient "0.7.2"))
  :commit "e2803b2290b4eb36232ff03631acf0367dabb763" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
