(define-package "annotate" "20230401.1613" "annotate files without changing them" 'nil :commit "69d7e2138c35f8c8adb33cf27b440eee2591810d" :authors
  '(("Bastian Bechtold"))
  :maintainers
  '(("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it"))
  :maintainer
  '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it")
  :url "https://github.com/bastibe/annotate.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
