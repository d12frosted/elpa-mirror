(define-package "consult" "20210726.733" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "eddc6d3d69457c4a03fb2c59f186bc8a5a6b7fe8" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
