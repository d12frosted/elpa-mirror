;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251103.1434"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "a41c9e94fcaa614154da7017a3428346c12b212f"
  :revdesc "a41c9e94fcaa"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
