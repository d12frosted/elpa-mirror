(define-package "insert-kaomoji" "20200325.2248" "Easily insert kaomojis"
  '((emacs "24.4"))
  :commit "d18423f78cc02ba866b1a1dfb0617476cd941c54" :authors
  '(("Philip K." . "philip@warpmail.net"))
  :maintainer
  '("Philip K." . "philip@warpmail.net")
  :keywords
  '("wp")
  :url "https://git.sr.ht/~zge/kaomoji")
;; Local Variables:
;; no-byte-compile: t
;; End:
