;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260227.1853"
  "Unified interface for AI coding backends such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5b911130aa54f67b2df2f9c72254528fa5bf2aeb"
  :revdesc "5b911130aa54"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
