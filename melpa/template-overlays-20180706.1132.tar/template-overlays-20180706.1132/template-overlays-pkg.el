;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "template-overlays" "20180706.1132"
  "Display template regions using overlays."
  '((emacs "24.4")
    (ov    "1.0.6"))
  :url "http://www.github.com/mmontone/template-overlays"
  :commit "3cbc9a4882dcbbddf9b168883d119a6af0848784"
  :revdesc "3cbc9a4882dc"
  :keywords '("faces" "convenience" "templates" "overlays")
  :authors '(("Mariano Montone" . "marianomontone@gmail.com"))
  :maintainers '(("Mariano Montone" . "marianomontone@gmail.com")))
