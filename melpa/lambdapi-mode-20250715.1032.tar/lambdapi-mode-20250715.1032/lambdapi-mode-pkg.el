;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambdapi-mode" "20250715.1032"
  "A major mode for editing Lambdapi source code."
  '((emacs             "27.1")
    (eglot             "1.6")
    (math-symbol-lists "1.2.1")
    (highlight         "20190710.1527"))
  :url "https://github.com/Deducteam/lambdapi"
  :commit "4329ff6d7f3978c43b0e0dd227c330c5bdc71856"
  :revdesc "4329ff6d7f39"
  :keywords '("languages")
  :maintainers '(("Deducteam" . "dedukti-dev@inria.fr")))
