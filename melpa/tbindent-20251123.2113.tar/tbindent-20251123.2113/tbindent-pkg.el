;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tbindent" "20251123.2113"
  "Tab Based Indentation Converter."
  '((emacs "24.3"))
  :url "https://github.com/pierre-rouleau/tab-based-indent"
  :commit "d36da81fda9e297d657c0d3d1093f820f966ff4e"
  :revdesc "d36da81fda9e"
  :keywords '("convenience" "languages")
  :authors '(("Pierre Rouleau" . "prouleau001@gmail.com"))
  :maintainers '(("Pierre Rouleau" . "prouleau001@gmail.com")))
