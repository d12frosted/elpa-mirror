;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260623.1857"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "3eda20d42f1588f54b7abb6766c8710a5756270e"
  :revdesc "3eda20d42f15"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
