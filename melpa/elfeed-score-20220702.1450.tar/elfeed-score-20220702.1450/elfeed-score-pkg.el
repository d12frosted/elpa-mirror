(define-package "elfeed-score" "20220702.1450" "Gnus-style scoring for Elfeed"
  '((emacs "26.1")
    (elfeed "3.3.0"))
  :commit "9ec591c02a948605e90b498fbce1bf6a70ff47b6" :authors
  '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainer
  '("Michael Herstine" . "sp1ff@pobox.com")
  :keywords
  '("news")
  :url "https://github.com/sp1ff/elfeed-score")
;; Local Variables:
;; no-byte-compile: t
;; End:
