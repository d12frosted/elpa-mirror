(define-package "corfu" "20231206.1548" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "dd0d88f52fd9f1edd38f541706ab03c8ca5b9f5c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
