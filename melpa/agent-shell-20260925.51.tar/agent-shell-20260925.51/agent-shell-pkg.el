;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260925.51"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "53577d5f9e461c4db4690bb24c6e1337a98c7609"
  :revdesc "53577d5f9e46")
