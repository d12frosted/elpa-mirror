;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-side-windows" "20260904.2152"
  "Simplified buffer management for side windows."
  '((emacs "30.1"))
  :url "https://github.com/MArpogaus/auto-side-windows"
  :commit "30c526ede4a3613e4aad5922722b1ab839a0293f"
  :revdesc "30c526ede4a3"
  :keywords '("convenience" "windows" "buffers")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
