;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250424.1323"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "0f0eb92c7701130bed2cda09bbeb45231fd9eded"
  :revdesc "0f0eb92c7701"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
