;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260502.952"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/tempel"
  :commit "6364dc83937b46341226f0f57f2911cdba1ac50c"
  :revdesc "6364dc83937b"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
