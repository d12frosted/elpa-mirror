(define-package "phi-search" "20150807.812" "another incremental search & replace, compatible with \"multiple-cursors\"" 'nil :commit "40b86bfe9ae15377fbee842b1de3d93c2eb7dd69" :authors
  '(("zk_phi"))
  :maintainer
  '("zk_phi")
  :url "http://hins11.yu-yake.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
