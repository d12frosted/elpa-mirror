;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250917.1534"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "3069a1a6332332de7b3a78f3933b59a337bca59e"
  :revdesc "3069a1a63323"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
