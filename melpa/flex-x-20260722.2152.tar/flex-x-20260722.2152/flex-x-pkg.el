;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "20260722.2152"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "e75c9fd9760fbdc6d8c89d7880076d02cca1dd5b"
  :revdesc "e75c9fd9760f"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
