(define-package "lfe-mode" "20220102.1653" "Lisp Flavoured Erlang mode" 'nil :commit "993a76da94472d0bf7b378f56070c4e77f20aefa")
;; Local Variables:
;; no-byte-compile: t
;; End:
