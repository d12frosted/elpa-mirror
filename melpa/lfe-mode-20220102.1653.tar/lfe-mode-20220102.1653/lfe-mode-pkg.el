(define-package "lfe-mode" "20220102.1653" "Lisp Flavoured Erlang mode" 'nil :commit "4c9f2ede47f710dfb0548d4e32793ad5766ca8fa")
;; Local Variables:
;; no-byte-compile: t
;; End:
