(define-package "lfe-mode" "20220102.1653" "Lisp Flavoured Erlang mode" 'nil :commit "b830877fa3cef0e1890e2d90ef54cbb4829934ea")
;; Local Variables:
;; no-byte-compile: t
;; End:
