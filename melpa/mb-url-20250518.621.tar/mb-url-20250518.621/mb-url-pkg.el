;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mb-url" "20250518.621"
  "Multiple Backends for Emacs URL package."
  '((emacs "25"))
  :url "https://github.com/dochang/mb-url"
  :commit "3d714075ad31c7c0e119c289b074f143575e86b7"
  :revdesc "3d714075ad31"
  :keywords '("comm" "data" "processes" "hypermedia")
  :authors '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers '(("ZHANG Weiyi" . "dochang@gmail.com")))
