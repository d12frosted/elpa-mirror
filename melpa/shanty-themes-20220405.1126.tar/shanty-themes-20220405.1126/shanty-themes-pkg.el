(define-package "shanty-themes" "20220405.1126" "The themes for digital workers"
  '((emacs "27.2"))
  :commit "55b6a2653e43187559ff8b5103bcb9dc54e68ab6" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
