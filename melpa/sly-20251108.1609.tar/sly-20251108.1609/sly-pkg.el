;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20251108.1609"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.3"))
  :url "https://github.com/joaotavora/sly"
  :commit "b57e32049a283ac5390178e46877752db83b7d0b"
  :revdesc "b57e32049a28"
  :keywords '("languages" "lisp" "sly"))
