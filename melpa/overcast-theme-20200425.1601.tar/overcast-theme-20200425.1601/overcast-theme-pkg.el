;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overcast-theme" "20200425.1601"
  "A dark but vibrant color theme for Emacs."
  '((emacs "24"))
  :url "http://ismail.teamfluxion.com"
  :commit "e02b835a08919ead079d7221d513348ac02ba92e"
  :revdesc "e02b835a0891"
  :keywords '("theme")
  :authors '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com"))
  :maintainers '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com")))
