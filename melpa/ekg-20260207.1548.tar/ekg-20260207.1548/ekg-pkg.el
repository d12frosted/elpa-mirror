;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260207.1548"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "8bdfffc729aa4020c8ab5a178731d35594a676f4"
  :revdesc "8bdfffc729aa"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
