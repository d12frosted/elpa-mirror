;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260106.747"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "c51608683d228e3f1da83eee1f60619d70958b84"
  :revdesc "c51608683d22"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
