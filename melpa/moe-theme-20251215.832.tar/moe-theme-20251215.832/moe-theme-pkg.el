;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moe-theme" "20251215.832"
  "A colorful eye-candy theme. Moe, moe, kyun!."
  ()
  :url "https://github.com/kuanyui/moe-theme.el"
  :commit "0cae555799db0d124f66e1a1223d6e51f02b854d"
  :revdesc "0cae555799db"
  :keywords '("themes")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
