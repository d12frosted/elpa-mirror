(define-package "consult" "20211231.939" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f9170bb75f9b4362b42cebee9cd8643b04093342" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
