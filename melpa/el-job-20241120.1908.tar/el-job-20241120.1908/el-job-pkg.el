;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20241120.1908"
  "Call a function using all CPU cores."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/meedstrom/el-job"
  :commit "c0598fb26b0ec95fdf7707616f4efc09d26984ad"
  :revdesc "c0598fb26b0e"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
