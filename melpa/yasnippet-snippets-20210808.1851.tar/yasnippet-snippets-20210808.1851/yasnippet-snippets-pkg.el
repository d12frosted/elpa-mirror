(define-package "yasnippet-snippets" "20210808.1851" "Collection of yasnippet snippets"
  '((yasnippet "0.8.0"))
  :commit "20cb29990f9635fc7ee4ea4ec794227690592fdc" :authors
  '(("Andrea Crotti" . "andrea.crotti.0@gmail.com"))
  :maintainer
  '("Andrea Crotti" . "andrea.crotti.0@gmail.com")
  :keywords
  '("snippets")
  :url "https://github.com/AndreaCrotti/yasnippet-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
