(define-package "smudge" "20231214.1430" "Control the Spotify app"
  '((emacs "27.1")
    (simple-httpd "20230821.1458")
    (request "0.3")
    (oauth2 "0.16"))
  :commit "96878338f53114c0454da3985d8487b2f3699bcf" :keywords
  '("multimedia" "music" "spotify" "smudge")
  :url "https://github.com/danielfm/smudge")
;; Local Variables:
;; no-byte-compile: t
;; End:
