(define-package "modus-themes" "20210601.640" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "ace22caf888ca11def83b8645bcacbbb3a0af30a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
