;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotate" "20250512.1620"
  "Annotate files without changing them."
  '((emacs "27.1"))
  :url "https://github.com/bastibe/annotate.el"
  :commit "2db6d5ef31aeacaaffe21d159401014c899feb76"
  :revdesc "2db6d5ef31ae"
  :maintainers '(("Bastian Bechtold" . "bastibe.dev@mailbox.org")
                 ("cage" . "cage-dev@twistfold.it")))
