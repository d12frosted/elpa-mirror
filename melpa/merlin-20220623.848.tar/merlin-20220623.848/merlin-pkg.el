(define-package "merlin" "20220623.848" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "cc0ef799302c45478a09bc1e9749e3b61188b325" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
