;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-flycheck" "20160720.1500"
  "Jump to and fix syntax errors using `flycheck' with `avy' interface."
  '((emacs    "24.1")
    (flycheck "0.14")
    (seq      "1.11")
    (avy      "0.4.0"))
  :url "https://github.com/magicdirac/avy-flycheck"
  :commit "5522f3bbbed1801d9278ed696ec0cbba38352985"
  :revdesc "5522f3bbbed1"
  :keywords '("tools" "convenience" "avy" "flycheck")
  :authors '(("Xu Ma" . "magicdirac@gmail.com"))
  :maintainers '(("Xu Ma" . "magicdirac@gmail.com")))
