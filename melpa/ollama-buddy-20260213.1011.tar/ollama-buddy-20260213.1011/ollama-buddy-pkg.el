;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260213.1011"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "f85d264c64aed54f440a10de5a89a15123fe62c7"
  :revdesc "f85d264c64ae"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
