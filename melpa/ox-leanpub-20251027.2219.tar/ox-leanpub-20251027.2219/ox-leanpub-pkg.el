;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-leanpub" "20251027.2219"
  "Export Org documents to Leanpub book format."
  '((org    "9.1")
    (ox-gfm "1.0")
    (emacs  "26.1")
    (s      "1.12.0"))
  :url "https://gitlab.com/zzamboni/ox-leanpub"
  :commit "927c6ca00ff48b45c4093f19f8dd8a17ba75a532"
  :revdesc "927c6ca00ff4"
  :keywords '("files" "org" "leanpub")
  :authors '(("Diego Zamboni" . "diego@zzamboni.org"))
  :maintainers '(("Diego Zamboni" . "diego@zzamboni.org")))
