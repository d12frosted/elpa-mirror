(define-package "dashboard" "20221116.1155" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "48860b18b3b6ffac87b281c417ab11dd0578efc8" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
