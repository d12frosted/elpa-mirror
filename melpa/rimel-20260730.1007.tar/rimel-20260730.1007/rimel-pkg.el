;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260730.1007"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "4fbc1977713704c7fe452195b377bc67e5de846a"
  :revdesc "4fbc19777137"
  :keywords '("convenience" "chinese" "input-method" "rime"))
