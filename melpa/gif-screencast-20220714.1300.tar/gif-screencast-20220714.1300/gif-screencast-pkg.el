(define-package "gif-screencast" "20220714.1300" "One-frame-per-action GIF recording"
  '((emacs "25.1"))
  :commit "adec408e6adab2e8e057fe0ad828749f473bfb83" :authors
  '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers
  '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainer
  '("Pierre Neidhardt" . "mail@ambrevar.xyz")
  :keywords
  '("multimedia" "screencast")
  :url "https://gitlab.com/ambrevar/emacs-gif-screencast")
;; Local Variables:
;; no-byte-compile: t
;; End:
