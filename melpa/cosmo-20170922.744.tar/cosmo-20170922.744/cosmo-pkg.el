;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cosmo" "20170922.744"
  "Cosmological Calculator."
  '((emacs "24.4"))
  :url "https://gitlab.com/montanari/cosmo-el"
  :commit "dd83b09a49a2843606b28279b674b2207040b36b"
  :revdesc "dd83b09a49a2"
  :keywords '("tools")
  :authors '(("Francesco Montanari" . "fmnt@fmnt.info"))
  :maintainers '(("Francesco Montanari" . "fmnt@fmnt.info")))
