(define-package "fanyi" "20220306.2010" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "d82a298cb76175108f2f76987ef3e86771e49ec5" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
