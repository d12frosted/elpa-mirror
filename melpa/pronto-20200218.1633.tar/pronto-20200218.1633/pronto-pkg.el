;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pronto" "20200218.1633"
  "Compilation mode for pronto stylechecks."
  '((emacs "24"))
  :url "https://github.com/julianrubisch/pronto.el"
  :commit "c0cd13d8219879610b7fe284b182a9db4d3d40b3"
  :revdesc "c0cd13d82198"
  :keywords '("processes" "tools")
  :authors '(("Julian Rubisch" . "julian@julianrubisch.at"))
  :maintainers '(("Julian Rubisch" . "julian@julianrubisch.at")))
