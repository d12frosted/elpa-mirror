;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260430.313"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "c415cabcd23cbd046ceb3afbaaf674a268fd78b9"
  :revdesc "c415cabcd23c"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
