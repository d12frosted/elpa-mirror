;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forge" "20260620.2146"
  "Access Git forges from Magit."
  '((emacs         "29.1")
    (compat        "31.0")
    (closql        "2.4")
    (cond-let      "1.1")
    (emacsql       "4.4")
    (ghub          "5.2.1")
    (llama         "1.0")
    (magit         "4.5")
    (markdown-mode "2.8")
    (seq           "2.24")
    (transient     "0.13")
    (yaml          "1.2"))
  :url "https://github.com/magit/forge"
  :commit "d9df7000627694df04a095c1f76432e5c0614e49"
  :revdesc "d9df70006276"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev")))
