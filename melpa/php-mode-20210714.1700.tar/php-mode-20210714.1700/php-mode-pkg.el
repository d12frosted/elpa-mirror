(define-package "php-mode" "20210714.1700" "Major mode for editing PHP code"
  '((emacs "25.2"))
  :commit "241bd82ea65db5642704cda1742e978a109a069d" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
