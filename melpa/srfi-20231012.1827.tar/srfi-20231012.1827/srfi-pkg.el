(define-package "srfi" "20231012.1827" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "ed1615bac716e0af73ae348c85d26a0f6e23160e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
