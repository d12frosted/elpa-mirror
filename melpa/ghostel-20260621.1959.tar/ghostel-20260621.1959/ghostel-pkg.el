;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260621.1959"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "c4557b8bb1d5d6184cc1fecc70c5d8b409510061"
  :revdesc "c4557b8bb1d5"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
