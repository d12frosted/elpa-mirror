(define-package "cape" "20221204.2316" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "2e4e97868dad4385056c233d7832352678cd8d4f" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
