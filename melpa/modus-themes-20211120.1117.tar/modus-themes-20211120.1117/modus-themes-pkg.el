(define-package "modus-themes" "20211120.1117" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "5c96aacb714cabc0d2721d6dd07adee1890191df" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
