(define-package "mini-echo" "20231117.1532" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "040d3f4ed02191a6f38830c2b27bc8e83c51d0e1" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
