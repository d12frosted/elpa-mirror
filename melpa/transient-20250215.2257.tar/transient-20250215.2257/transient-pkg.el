;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20250215.2257"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.0.0.0")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "04dab99dc9bc8788ed17473118421e6ee291091d"
  :revdesc "04dab99dc9bc"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
