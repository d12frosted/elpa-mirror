(define-package "dirvish" "20220612.1746" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "553cab696bfb49b2af684d1b9b1e09b278e83662" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
