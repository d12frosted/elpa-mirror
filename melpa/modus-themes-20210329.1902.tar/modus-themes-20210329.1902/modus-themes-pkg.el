(define-package "modus-themes" "20210329.1902" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "fe856a950fb451af4c8f1ae095270851dd70f200" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
