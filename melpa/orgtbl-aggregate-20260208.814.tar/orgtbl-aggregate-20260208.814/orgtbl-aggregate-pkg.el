;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260208.814"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "83121add125b8ec79f66bffde6c65e029a7cfab8"
  :revdesc "83121add125b"
  :keywords '("data" "extensions"))
