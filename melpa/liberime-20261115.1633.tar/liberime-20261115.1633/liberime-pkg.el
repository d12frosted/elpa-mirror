;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20261115.1633"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "2a87beb5966c1af0c5ec77385b0e590639cef9b5"
  :revdesc "2a87beb5966c"
  :keywords '("convenience" "chinese" "input-method" "rime"))
