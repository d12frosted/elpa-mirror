(define-package "srfi" "20220920.345" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "f564f380f037a0ba877eed6e7b52fb910956c04f" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
