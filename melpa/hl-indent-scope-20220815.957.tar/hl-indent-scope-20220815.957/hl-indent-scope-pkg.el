(define-package "hl-indent-scope" "20220815.957" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "ed6b648c06ddff0b60616082f5c6faf189659d46" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
