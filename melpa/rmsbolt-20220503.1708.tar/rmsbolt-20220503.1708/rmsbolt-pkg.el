(define-package "rmsbolt" "20220503.1708" "A compiler output viewer"
  '((emacs "25.1"))
  :commit "de28f7903a3b895c3bf9628ac6d4db4378748fa8" :authors
  '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainer
  '("Jay Kamat" . "jaygkamat@gmail.com")
  :keywords
  '("compilation" "tools")
  :url "http://gitlab.com/jgkamat/rmsbolt")
;; Local Variables:
;; no-byte-compile: t
;; End:
