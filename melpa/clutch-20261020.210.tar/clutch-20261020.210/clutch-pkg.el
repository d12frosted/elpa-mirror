;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261020.210"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "4441990e5f1cdf39ff89e9a6e117d42f1b8ca724"
  :revdesc "4441990e5f1c"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
