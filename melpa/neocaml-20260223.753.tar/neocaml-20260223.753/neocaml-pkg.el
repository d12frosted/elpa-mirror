;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260223.753"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "93ec7073a44d6e407121fd1190d3de2a97e15f9a"
  :revdesc "93ec7073a44d"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
