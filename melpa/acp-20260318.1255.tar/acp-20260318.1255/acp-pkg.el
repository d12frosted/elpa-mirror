;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20260318.1255"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "7b2b3809f34a7c73f05c02ceee47bf4cb17302c6"
  :revdesc "7b2b3809f34a")
