;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-julia-vterm" "20250615.703"
  "Babel functions for Julia that work with julia-vterm."
  '((emacs       "26.1")
    (julia-vterm "0.26")
    (queue       "0.2"))
  :url "https://github.com/shg/ob-julia-vterm.el"
  :commit "12fb70d232fb8775453ece8f3d29fae22c8a5471"
  :revdesc "12fb70d232fb"
  :keywords '("julia" "org" "outlines" "literate programming" "reproducible research"))
