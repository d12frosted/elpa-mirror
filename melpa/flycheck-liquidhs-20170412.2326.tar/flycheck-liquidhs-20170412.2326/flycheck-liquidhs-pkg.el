;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-liquidhs" "20170412.2326"
  "A flycheck checker for Haskell using liquid (i.e. liquidhaskell)."
  '((flycheck "0.15"))
  :url "https://github.com/ucsd-progsys/liquidhaskell/flycheck-liquid.el"
  :commit "c27252ac24d77f4b6eec76a4ba9cd61761a3fba9"
  :revdesc "c27252ac24d7"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Ranjit Jhala" . "jhala@cs.ucsd.edu"))
  :maintainers '(("Ranjit Jhala" . "jhala@cs.ucsd.edu")))
