;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261030.1722"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "2b5b9aba75b19a9dd7b6d0989d934baf9b8d0191"
  :revdesc "2b5b9aba75b1"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
