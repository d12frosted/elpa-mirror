;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261028.2301"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "2e645d478aafd65a13ae1faf9828c1b2f352971a"
  :revdesc "2e645d478aaf")
