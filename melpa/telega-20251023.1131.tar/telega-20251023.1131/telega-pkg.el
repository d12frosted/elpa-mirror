;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251023.1131"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "c8000bb5a9549297d51bf95f24056b44990d1ecc"
  :revdesc "c8000bb5a954"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
