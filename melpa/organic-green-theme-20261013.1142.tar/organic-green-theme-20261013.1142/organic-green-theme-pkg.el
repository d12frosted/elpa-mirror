;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20261013.1142"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "4bc8e1e6a4988dcc3845a695b24c5d907a6371a2"
  :revdesc "4bc8e1e6a498"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
