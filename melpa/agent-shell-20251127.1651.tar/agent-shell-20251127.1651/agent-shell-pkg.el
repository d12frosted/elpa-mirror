;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251127.1651"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "829e2284bcc60e86c987f32ee90e112f04b2d079"
  :revdesc "829e2284bcc6")
