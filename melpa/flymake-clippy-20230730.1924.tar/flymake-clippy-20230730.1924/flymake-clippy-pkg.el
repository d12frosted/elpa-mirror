(define-package "flymake-clippy" "20230730.1924" "Flymake backend for Clippy"
  '((emacs "26.1"))
  :commit "fb4ce2e9b9f7703bd38a2acc2595a02f3822cac7" :authors
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainers
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainer
  '("Graham Marlow" . "info@mgmarlow.com")
  :keywords
  '("tools")
  :url "https://sr.ht/~mgmarlow/flymake-clippy/")
;; Local Variables:
;; no-byte-compile: t
;; End:
