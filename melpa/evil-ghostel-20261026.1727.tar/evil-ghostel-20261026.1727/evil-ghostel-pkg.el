;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20261026.1727"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "c0c34d740c50a5514f4dc30ae1f4214679a96e49"
  :revdesc "c0c34d740c50"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
