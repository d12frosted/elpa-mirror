;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251104.1003"
  "A single native shell experience to interact with agentic providers (Claude Code, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.82.2")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "33064ed8da09881ac5b88496214594200617ab4c"
  :revdesc "33064ed8da09")
