(define-package "dirvish" "20220410.1704" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "5966b0587449d0f0b3c57ee987b2b411ce446b6c" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
