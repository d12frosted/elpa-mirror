(define-package "eldev" "20211211.1809" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "8ced25116e4eab6792513307cf0e41d9a4b12528" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
