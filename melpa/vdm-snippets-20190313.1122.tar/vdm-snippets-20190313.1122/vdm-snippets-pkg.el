;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vdm-snippets" "20190313.1122"
  "YASnippets for VDM mode."
  '((emacs     "24")
    (yasnippet "0.13.0"))
  :url "https://github.com/peterwvj/vdm-mode"
  :commit "dc1756dd151752b3f538d68326059f8861e4ac66"
  :revdesc "dc1756dd1517"
  :keywords '("languages")
  :authors '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com"))
  :maintainers '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com")))
