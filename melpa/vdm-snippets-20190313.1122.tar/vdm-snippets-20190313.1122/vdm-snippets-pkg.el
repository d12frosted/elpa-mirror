(define-package "vdm-snippets" "20190313.1122" "YASnippets for VDM mode"
  '((emacs "24")
    (yasnippet "0.13.0"))
  :commit "dc1756dd151752b3f538d68326059f8861e4ac66" :authors
  '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com"))
  :maintainer
  '("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/peterwvj/vdm-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
