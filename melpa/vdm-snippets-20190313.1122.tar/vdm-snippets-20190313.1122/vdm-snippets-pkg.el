(define-package "vdm-snippets" "20190313.1122" "YASnippets for VDM mode"
  '((emacs "24")
    (yasnippet "0.13.0"))
  :commit "56336930555df91787f196acac15680498d17d5e" :authors
  '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com"))
  :maintainer
  '("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/peterwvj/vdm-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
