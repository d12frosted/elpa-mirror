;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251104.2311"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "8c053a61489a2cf2f5cd27d1e1738caef918fde3"
  :revdesc "8c053a61489a"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
