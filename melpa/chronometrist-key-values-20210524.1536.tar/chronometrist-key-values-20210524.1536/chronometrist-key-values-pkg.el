(define-package "chronometrist-key-values" "20210524.1536" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "29b6fd4c6805b717bfee49440720300c61b382c4" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "gemini://tilde.team/~contrapunctus/software.gmi")
;; Local Variables:
;; no-byte-compile: t
;; End:
