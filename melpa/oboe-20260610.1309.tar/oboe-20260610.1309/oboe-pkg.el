;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260610.1309"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "11addb8aa56525479c1df5775f0d3993b40dbd33"
  :revdesc "11addb8aa565"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
