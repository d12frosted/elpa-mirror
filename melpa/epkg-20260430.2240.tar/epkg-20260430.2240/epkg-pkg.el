;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260430.2240"
  "Browse the Emacsmirror package database."
  '((emacs   "28.1")
    (compat  "30.1")
    (closql  "2.4")
    (emacsql "4.3")
    (llama   "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "533a76dacd09f4af6f04d4a068fa6f606b21f0a4"
  :revdesc "533a76dacd09"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
