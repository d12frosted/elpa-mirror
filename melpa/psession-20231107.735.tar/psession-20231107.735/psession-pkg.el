(define-package "psession" "20231107.735" "Persistent save of elisp objects."
  '((emacs "24")
    (cl-lib "0.5")
    (async "1.9.3"))
  :commit "76101f8a5afe705e4a815ab51b87aff03a64cb91" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://github.com/thierryvolpiatto/psession")
;; Local Variables:
;; no-byte-compile: t
;; End:
