;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "20260803.1048"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "ce734ac25ffb06994a4530426bb06ee8cda19e50"
  :revdesc "ce734ac25ffb")
