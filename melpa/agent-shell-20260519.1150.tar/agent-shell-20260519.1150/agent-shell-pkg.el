;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260519.1150"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7485abb0a47c6c5a5218d965cf19da3956c1d4e6"
  :revdesc "7485abb0a47c")
