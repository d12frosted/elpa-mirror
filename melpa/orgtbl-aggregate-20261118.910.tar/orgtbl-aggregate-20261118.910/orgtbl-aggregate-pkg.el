;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20261118.910"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "32e06e741de05e476ebd080ac3d8208ca1821fa1"
  :revdesc "32e06e741de0"
  :keywords '("data" "extensions"))
