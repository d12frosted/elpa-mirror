;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20261028.1752"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "af74958268102cc6ad9c99129be4d05e4de57acb"
  :revdesc "af7495826810"
  :keywords '("convenience" "files" "tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
