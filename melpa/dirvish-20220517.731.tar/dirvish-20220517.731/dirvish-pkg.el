(define-package "dirvish" "20220517.731" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e7ec4f3c90cd4abeb8a4be83c0194a4979b5c92d" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
