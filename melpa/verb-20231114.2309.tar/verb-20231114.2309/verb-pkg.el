(define-package "verb" "20231114.2309" "Organize and send HTTP requests"
  '((emacs "26.3"))
  :commit "1edcf0c3758c70acb9393fda7dfbc5957bb0fbeb" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
