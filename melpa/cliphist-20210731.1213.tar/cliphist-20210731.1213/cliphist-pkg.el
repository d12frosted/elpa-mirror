(define-package "cliphist" "20210731.1213" "paste from clipboard managers"
  '((emacs "25.1"))
  :commit "1ea424e904da0b60101cd6f88cea971285defb53" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("clipboard" "manager" "history")
  :url "http://github.com/redguardtoo/cliphist")
;; Local Variables:
;; no-byte-compile: t
;; End:
