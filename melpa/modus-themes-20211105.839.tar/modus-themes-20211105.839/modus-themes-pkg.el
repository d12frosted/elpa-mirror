(define-package "modus-themes" "20211105.839" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "ed4926a30a9d5bbca350557381f4534eb135aaba" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
