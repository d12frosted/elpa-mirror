(define-package "diff-hl" "20211031.213" "Highlight uncommitted changes using VC"
  '((cl-lib "0.2")
    (emacs "25.1"))
  :commit "f051fbeb21564c448150b49f1631732ee35d815d" :authors
  '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("vc" "diff")
  :url "https://github.com/dgutov/diff-hl")
;; Local Variables:
;; no-byte-compile: t
;; End:
