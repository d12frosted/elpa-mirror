(define-package "srfi" "20210318.2242" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "512d51e8b6f912857d484095defd7b89535edfbb" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
