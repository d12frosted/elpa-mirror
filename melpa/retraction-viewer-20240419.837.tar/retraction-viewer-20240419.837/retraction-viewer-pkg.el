(define-package "retraction-viewer" "20240419.837" "View retraction information for current citation"
  '((emacs "26.1")
    (plz "0.7"))
  :commit "87efb813a0dd3b320299d771779e68efe4344cf0" :authors
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainer
  '("Samuel W. Flint" . "me@samuelwflint.com")
  :keywords
  '("bib" "tex" "data")
  :url "https://git.sr.ht/~swflint/retraction-viewer")
;; Local Variables:
;; no-byte-compile: t
;; End:
