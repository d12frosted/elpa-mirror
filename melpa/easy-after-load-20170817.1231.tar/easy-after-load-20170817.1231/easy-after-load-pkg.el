;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-after-load" "20170817.1231"
  "Eval-after-load for all files in a directory."
  ()
  :url "https://github.com/pd/easy-after-load"
  :commit "29e20145da49ac9ea40463c552130777408040de"
  :revdesc "29e20145da49")
