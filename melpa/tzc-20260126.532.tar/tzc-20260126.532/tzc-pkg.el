;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260126.532"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "4df941e3684121276bb7ef48af80cc564562d340"
  :revdesc "4df941e36841"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
