(define-package "magit-libgit" "20220422.1903" "."
  '((emacs "25.1")
    (compat "28.1.0.4")
    (libgit "0")
    (magit "20211004"))
  :commit "b4d54d3f8ee047479980b6d8079f3ce1a93bb6a4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
