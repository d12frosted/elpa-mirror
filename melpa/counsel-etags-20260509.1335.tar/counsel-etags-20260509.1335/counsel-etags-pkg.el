;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-etags" "20260509.1335"
  "Fast and complete Ctags solution using ivy."
  '((emacs   "28.1")
    (counsel "0.15.1"))
  :url "https://github.com/redguardtoo/counsel-etags"
  :commit "5c9672defabfb4767b9a087d4c603f9b3606f550"
  :revdesc "5c9672defabf"
  :keywords '("tools" "convenience"))
