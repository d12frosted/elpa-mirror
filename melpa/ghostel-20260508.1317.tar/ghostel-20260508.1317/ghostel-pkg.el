;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260508.1317"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "6fae92d42f667e6cbb5643ca1b05d83573e7759a"
  :revdesc "6fae92d42f66"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
