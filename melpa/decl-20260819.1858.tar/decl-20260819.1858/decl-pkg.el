;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "decl" "20260819.1858"
  "Library for organizing code declaratively."
  '((dash   "2.5.0")
    (emacs  "24.3")
    (cl-lib "0.3"))
  :url "https://github.com/preetpalS/decl.el"
  :commit "491fab9d6a8debe266e0f7ed8590becfa2157353"
  :revdesc "491fab9d6a8d")
