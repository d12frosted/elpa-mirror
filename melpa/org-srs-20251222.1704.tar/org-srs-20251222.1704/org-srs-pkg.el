;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251222.1704"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "8b64a98e833be34ad177296d1317e6d3daeaf722"
  :revdesc "8b64a98e833b"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
