(define-package "tok-theme" "20230901.1139" "Minimal monochromatic theme for Emacs in the spirit of Zmacs and Smalltalk-80."
  '((emacs "27.0"))
  :commit "78d4e147951019d2b110d9af3d90e8eef7e4f79c" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
