(define-package "websearch" "20230113.2228" "Query search engines"
  '((emacs "24.4"))
  :commit "e00bf63cfa6a9080c70b8438ff85a74752773181" :authors
  '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainer
  '("Maciej Barć" . "xgqt@riseup.net")
  :keywords
  '("convenience" "hypermedia")
  :url "https://gitlab.com/xgqt/emacs-websearch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
