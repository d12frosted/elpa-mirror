(define-package "gap-mode" "20220503.1555" "Major mode for editing files in the GAP programing language." 'nil :commit "99237f714c28981142674e8cfeb155863c834858" :authors
  '(("Michael Smith" . "smith@pell.anu.edu.au")
    ("Gary Zablackis")
    ("Goetz Pfeiffer")
    ("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainer
  '("Ivan Andrus" . "darthandrus@gmail.com")
  :keywords
  '("gap")
  :url "https://gitlab.com/gvol/gap-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
