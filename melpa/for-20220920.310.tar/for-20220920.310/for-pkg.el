(define-package "for" "20220920.310" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "6d41f5d631d01509d95a1866b81c93b2a380ed08" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
