;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mime" "20251123.2342"
  "Org html export for text/html MIME emails."
  '((emacs "27.1"))
  :url "http://github.com/org-mime/org-mime"
  :commit "1d9e95e7ccbdacb6b3d6ef983c0c91c1fbcbe750"
  :revdesc "1d9e95e7ccbd"
  :keywords '("mime" "mail" "email" "html")
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
