;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debian-el" "20250408.1759"
  "Startup file for the debian-el package."
  ()
  :commit "e1ac30680bf391c68169f8623398e9b77b7b9f0c"
  :revdesc "e1ac30680bf3"
  :keywords '("debian" "apt" "elisp")
  :authors '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org"))
  :maintainers '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org")))
