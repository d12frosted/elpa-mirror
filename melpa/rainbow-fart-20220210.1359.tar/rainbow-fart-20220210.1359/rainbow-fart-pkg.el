(define-package "rainbow-fart" "20220210.1359" "Checks the keywords of code to play suitable sounds"
  '((emacs "25.1")
    (flycheck "32snapshot"))
  :commit "4e5d3cca6cdc667e5da3300c04e1b3d1b00664a8" :keywords
  '("tools")
  :url "https://repo.or.cz/emacs-rainbow-fart.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
