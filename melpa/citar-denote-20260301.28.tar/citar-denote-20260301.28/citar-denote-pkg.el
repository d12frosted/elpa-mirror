;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-denote" "20260301.28"
  "Minor mode integrating Citar and Denote."
  '((emacs  "29.1")
    (citar  "1.4")
    (denote "4.1")
    (dash   "2.19.1"))
  :url "https://github.com/pprevos/citar-denote"
  :commit "3ea1e65615f3a01ae2b15a33c706ba36a9285d80"
  :revdesc "3ea1e65615f3"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
