(define-package "consult" "20240323.808" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "f3564741892dc88f5148334ae08efacd6e98c3e0" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
