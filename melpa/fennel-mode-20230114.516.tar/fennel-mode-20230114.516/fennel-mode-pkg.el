(define-package "fennel-mode" "20230114.516" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "ca690aaa21dac20cd9018411ef0c02b2f96c844d" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
