;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arduino-cli-mode" "20250405.1202"
  "Arduino-CLI command wrapper."
  '((emacs "25.1"))
  :url "https://github.com/motform/arduino-cli-mode"
  :commit "499e3a2f95575c561d9dff7926397077bcafea21"
  :revdesc "499e3a2f9557"
  :keywords '("processes" "tools"))
