(define-package "sqlite3" "20231124.433" "Direct access to the core SQLite3 API"
  '((emacs "25.1"))
  :commit "0aa2b039259b63c592e09ea815def52c95521c3f" :authors
  '(("Y. N. Lo" . "elisp@fastmail.com"))
  :maintainers
  '(("Y. N. Lo" . "elisp@fastmail.com"))
  :maintainer
  '("Y. N. Lo" . "elisp@fastmail.com")
  :keywords
  '("comm" "data" "sql")
  :url "https://github.com/pekingduck/emacs-sqlite3-api")
;; Local Variables:
;; no-byte-compile: t
;; End:
