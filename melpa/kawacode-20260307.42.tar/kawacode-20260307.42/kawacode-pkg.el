;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kawacode" "20260307.42"
  "Kawa Code collaboration package."
  '((emacs "27.1"))
  :url "https://github.com/codeawareness/kawa.emacs"
  :commit "72e1998df1e079e69e317998b33fad835019df32"
  :revdesc "72e1998df1e0"
  :keywords '("tools" "convenience" "vc")
  :authors '(("Mark Vasile" . "mark@codeawareness.com"))
  :maintainers '(("Mark Vasile" . "mark@codeawareness.com")))
