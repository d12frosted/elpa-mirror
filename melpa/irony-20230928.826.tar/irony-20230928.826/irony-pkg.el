(define-package "irony" "20230928.826" "C/C++ minor mode powered by libclang"
  '((cl-lib "0.5")
    (json "1.2"))
  :commit "f23f568cfd1996c7518de57a12748f68c4114e96" :authors
  '(("Guillaume Papin" . "guillaume.papin@epitech.eu"))
  :maintainers
  '(("Guillaume Papin" . "guillaume.papin@epitech.eu"))
  :maintainer
  '("Guillaume Papin" . "guillaume.papin@epitech.eu")
  :keywords
  '("c" "convenience" "tools")
  :url "https://github.com/Sarcasm/irony-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
