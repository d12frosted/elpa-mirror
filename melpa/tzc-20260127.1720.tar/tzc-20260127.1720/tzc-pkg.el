;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260127.1720"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "f1af9e012563f1c916dfa578c09eeb6d712ebe31"
  :revdesc "f1af9e012563"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
