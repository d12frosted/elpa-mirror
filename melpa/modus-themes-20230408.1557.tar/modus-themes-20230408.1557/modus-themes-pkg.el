(define-package "modus-themes" "20230408.1557" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "fd81d2c2ea33f0fd163141503cf68d65d46a7d33" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
