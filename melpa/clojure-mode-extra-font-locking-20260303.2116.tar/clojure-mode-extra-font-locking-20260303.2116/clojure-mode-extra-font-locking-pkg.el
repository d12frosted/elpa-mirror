;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode-extra-font-locking" "20260303.2116"
  "Extra font-locking for Clojure mode."
  '((clojure-mode "5.22.0"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "6314697ed8042db9341a11d1a330c305a3c36f37"
  :revdesc "6314697ed804"
  :keywords '("languages" "lisp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
