(define-package "meow" "20220218.2024" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "2a822b78e0483f2f32995c72870a16e43d3f0c92" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
