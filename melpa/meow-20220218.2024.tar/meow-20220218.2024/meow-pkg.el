(define-package "meow" "20220218.2024" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "7d3139c9f55ba85c00e5f5b1a396be98fea1762a" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
