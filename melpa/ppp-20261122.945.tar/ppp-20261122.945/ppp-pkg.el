;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ppp" "20261122.945"
  "Extended pretty printer for Emacs Lisp."
  '((emacs "25.1"))
  :url "https://github.com/conao3/ppp.el"
  :commit "cf1df66a55cfa7f6b3bc6a90ca66fd7c38c4090b"
  :revdesc "cf1df66a55cf"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
