;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "libbcel" "20230826.1233"
  "Library to connect to basecamp 3 API."
  '((emacs   "26.1")
    (request "0.3.1"))
  :url "https://gitlab.petton.fr/bcel/libbcel"
  :commit "35679c86b6d73817fef17df4119a7a45dfc9f33d"
  :revdesc "35679c86b6d7"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
