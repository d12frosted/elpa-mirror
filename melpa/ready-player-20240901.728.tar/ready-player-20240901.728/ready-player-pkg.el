(define-package "ready-player" "20240901.728" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "babb6ed6966628bc97be594cdd9b3edeb0c7873c" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
