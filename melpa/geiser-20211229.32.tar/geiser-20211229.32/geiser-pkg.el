(define-package "geiser" "20211229.32" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3"))
  :commit "e5357e6dcd221ba734423c68dc7a823c034d49d2" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
