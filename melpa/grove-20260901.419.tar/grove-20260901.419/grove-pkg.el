;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "20260901.419"
  "Obsidian-like Org and Markdown notes."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "2f062a992c730b75782458ee679ca894aa679935"
  :revdesc "2f062a992c73"
  :keywords '("notes" "outlines" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
