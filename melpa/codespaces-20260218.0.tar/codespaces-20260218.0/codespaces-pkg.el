;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260218.0"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "542c029b38d70613ba3a0ae551bfa0c99be2f17a"
  :revdesc "542c029b38d7"
  :keywords '("comm")
  :authors '(("Patrick Thomson" . "patrickt@github.com"))
  :maintainers '(("Patrick Thomson" . "patrickt@github.com")))
