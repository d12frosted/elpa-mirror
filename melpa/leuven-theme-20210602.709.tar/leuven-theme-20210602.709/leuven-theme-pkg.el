(define-package "leuven-theme" "20210602.709" "Awesome Emacs color theme on white background" 'nil :commit "fb8f971c1b1b9d413399ccd3be8685fc5ed0a4c5" :authors
  '(("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>"))
  :maintainer
  '("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>")
  :keywords
  '("color" "theme")
  :url "https://github.com/fniessen/emacs-leuven-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
