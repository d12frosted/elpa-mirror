(define-package "org-change" "20231025.2340" "Annotate changes in org-mode files"
  '((emacs "26.1")
    (org "9.3"))
  :commit "c90b5fedbda08d805654d5dc05ca676be1187f23" :keywords
  '("wp" "convenience")
  :url "https://github.com/drghirlanda/org-change")
;; Local Variables:
;; no-byte-compile: t
;; End:
