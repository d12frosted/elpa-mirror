(define-package "eldev" "20211104.2253" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "ce43b1b7116f91cc9abbe07fb394fb1389a079a8" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
