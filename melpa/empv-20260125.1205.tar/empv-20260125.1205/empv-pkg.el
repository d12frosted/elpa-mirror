;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260125.1205"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "11245762388c03ecdfb550fb1b96978459d68a4f"
  :revdesc "11245762388c"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
