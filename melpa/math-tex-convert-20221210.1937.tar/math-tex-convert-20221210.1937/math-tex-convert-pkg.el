(define-package "math-tex-convert" "20221210.1937" "Convert LaTeX macros to unicode and back"
  '((emacs "26.1")
    (math-symbol-lists "1.3")
    (auctex "12.1"))
  :commit "8b174d05e8e5269322a1ee90f94cf1ed018d4976" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/math-tex-convert")
;; Local Variables:
;; no-byte-compile: t
;; End:
