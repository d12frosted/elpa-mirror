;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "math-tex-convert" "20221210.1937"
  "Convert LaTeX macros to unicode and back."
  '((emacs             "26.1")
    (math-symbol-lists "1.3")
    (auctex            "12.1"))
  :url "https://github.com/enricoflor/math-tex-convert"
  :commit "8b174d05e8e5269322a1ee90f94cf1ed018d4976"
  :revdesc "8b174d05e8e5"
  :authors '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers '(("Enrico Flor" . "enrico@eflor.net")))
