;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20261002.909"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "a6abce419828fc63c7698c7d4951614e8d12d2ff"
  :revdesc "a6abce419828"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
