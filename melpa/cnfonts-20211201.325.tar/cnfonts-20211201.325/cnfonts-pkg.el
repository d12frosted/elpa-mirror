(define-package "cnfonts" "20211201.325" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "fd92401d29a1d07cd16010938be7d95990938f4d" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
