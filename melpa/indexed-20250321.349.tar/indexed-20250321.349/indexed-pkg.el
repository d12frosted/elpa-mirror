;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250321.349"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (llama  "0.5.0")
    (el-job "2.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "b6d33e06b657b45ac830dcc5575d7451340ae955"
  :revdesc "b6d33e06b657"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
