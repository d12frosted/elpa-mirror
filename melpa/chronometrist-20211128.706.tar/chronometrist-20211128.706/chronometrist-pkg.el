(define-package "chronometrist" "20211128.706" "A time tracker with a nice interface"
  '((emacs "25.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "14f02ff402ba501d93c6e241450aad37789bf9b4" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
