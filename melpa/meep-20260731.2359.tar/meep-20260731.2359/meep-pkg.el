;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260731.2359"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "8cb0381150c29b1535f556065cd6cbadb3891208"
  :revdesc "8cb0381150c2"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
