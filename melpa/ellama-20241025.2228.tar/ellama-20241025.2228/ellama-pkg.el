;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20241025.2228"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.6.0")
    (spinner   "1.7.4")
    (transient "0.7.6")
    (compat    "29.1"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "8c41486b1bb9c1ad11a5bfb356b7e5e9e48337f3"
  :revdesc "8c41486b1bb9"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
