;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260327.2228"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "429d191801c5e2e7f4a2ab78017f84d1c983eb78"
  :revdesc "429d191801c5")
