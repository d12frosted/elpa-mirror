;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260913.2233"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "1044565ea1aba5ee46447840717bbda368fd81ff"
  :revdesc "1044565ea1ab"
  :keywords '("faces" "files" "q"))
