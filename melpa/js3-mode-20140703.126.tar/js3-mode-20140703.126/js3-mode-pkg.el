(define-package "js3-mode" "20140703.126" "An improved JavaScript editing mode" 'nil :commit "5ccda46ba39998a74bd724fdffb34634be5b6563" :authors
  '(("Thom Blake" . "webmaster@thomblake.com"))
  :maintainer
  '("Thom Blake" . "webmaster@thomblake.com")
  :keywords
  '("javascript" "languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
