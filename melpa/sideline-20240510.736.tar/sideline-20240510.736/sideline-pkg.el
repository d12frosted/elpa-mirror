(define-package "sideline" "20240510.736" "Show information on the side"
  '((emacs "27.1")
    (ht "2.4"))
  :commit "da18e465d0d53e0f664193443d2ba3d2df022bdc" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/emacs-sideline/sideline")
;; Local Variables:
;; no-byte-compile: t
;; End:
