;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250409.2137"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "c3fc5efd38b15524adfa41a23eda0fe2799cd42d"
  :revdesc "c3fc5efd38b1"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
