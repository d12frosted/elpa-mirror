(define-package "boon" "20221106.2025" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "106f842df7f68cbffbb2bb63f7f99f34fe7d3edf")
;; Local Variables:
;; no-byte-compile: t
;; End:
