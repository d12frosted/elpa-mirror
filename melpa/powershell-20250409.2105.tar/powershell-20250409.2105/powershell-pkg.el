;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "powershell" "20250409.2105"
  "Mode for editing PowerShell scripts."
  '((emacs "24"))
  :url "http://github.com/jschaf/powershell.el"
  :commit "42d587fc51aa8ff9888d7de3ea6b21f695a20c1a"
  :revdesc "42d587fc51aa"
  :keywords '("powershell" "languages")
  :authors '(("Frédéric Perrin" . "fredericperrinreselfr"))
  :maintainers '(("Frédéric Perrin" . "fredericperrinreselfr")))
