;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphql-doc" "20240716.38"
  "GraphQL Documentation Explorer."
  '((emacs   "26.1")
    (request "0.3.2")
    (promise "1.1"))
  :url "https://github.com/ifitzpatrick/graphql-doc.el"
  :commit "17755a2466a1acef68eac664093fcd13cd51494a"
  :revdesc "17755a2466a1")
