(define-package "robe" "20221106.140" "Code navigation, documentation lookup and completion for Ruby"
  '((inf-ruby "2.5.1")
    (emacs "25.1"))
  :commit "a4085d7329d771b5cba02c8fe9bca2622ea31ed7" :authors
  '(("Dmitry Gutov"))
  :maintainer
  '("Dmitry Gutov")
  :keywords
  '("ruby" "convenience" "rails")
  :url "https://github.com/dgutov/robe")
;; Local Variables:
;; no-byte-compile: t
;; End:
