;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260312.1521"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "012f31b2a799faf7bf2250ba684260156e7c05de"
  :revdesc "012f31b2a799"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
