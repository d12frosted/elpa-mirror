(define-package "ob-swiftui" "20231008.1228" "Org babel functions for SwiftUI evaluation"
  '((emacs "25.1")
    (swift-mode "8.2.0")
    (org "9.2.0"))
  :commit "0855f426cdba12bb02bf35c154fd3cc8a03894ba" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/ob-swiftui")
;; Local Variables:
;; no-byte-compile: t
;; End:
