(define-package "mame" "20230515.1303" "A MAME front-end"
  '((emacs "27.1"))
  :commit "1c03def518f80dd1a7cafa9d73cc75878c4afe37" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
