;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tagged" "20220926.2048"
  "Dynamic block for tagged org-mode todos."
  '((s     "1.13.0")
    (dash  "2.19.1")
    (emacs "28.1")
    (org   "9.5.2"))
  :url "https://github.com/gizmomogwai/org-tagged"
  :commit "4b0174473772fca976426e982bb3f4a3037c1e37"
  :revdesc "4b0174473772"
  :keywords '("org-mode" "org" "gtd" "tools")
  :authors '(("Christian Köstlin" . "christian.koestlin@gmail.com"))
  :maintainers '(("Christian Köstlin" . "christian.koestlin@gmail.com")))
