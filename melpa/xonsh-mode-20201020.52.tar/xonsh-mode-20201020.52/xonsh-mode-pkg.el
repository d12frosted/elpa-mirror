;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xonsh-mode" "20201020.52"
  "Major mode for editing xonshrc files."
  '((emacs "24.3"))
  :url "https://github.com/seanfarley/xonsh-mode"
  :commit "7fa581524533a9b6b770426e4445e571a69e469d"
  :revdesc "7fa581524533"
  :keywords '("languages")
  :authors '(("Sean Farley" . "sean@farley.io"))
  :maintainers '(("Sean Farley" . "sean@farley.io")))
