(define-package "magit-libgit" "20220615.1159" "(POC) Teach Magit to use Libgit2."
  '((emacs "25.1")
    (compat "28.1.1.2")
    (libgit "0")
    (magit "20211004"))
  :commit "2f0efa9f58c3e8ff05dd87fb4d3f992c23798207" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
