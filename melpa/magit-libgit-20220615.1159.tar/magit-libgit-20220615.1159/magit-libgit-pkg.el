(define-package "magit-libgit" "20220615.1159" "(POC) Teach Magit to use Libgit2."
  '((emacs "25.1")
    (compat "28.1.1.2")
    (libgit "0")
    (magit "20211004"))
  :commit "712be4632b0ddc7899ca90db8f9be20d90b4326f" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
