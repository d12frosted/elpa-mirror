(define-package "magit-libgit" "20220615.1159" "(POC) Teach Magit to use Libgit2."
  '((emacs "25.1")
    (compat "28.1.1.2")
    (libgit "0")
    (magit "20211004"))
  :commit "124a5ad8d7c078aa851203896493617005aad253" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
