(define-package "magit-libgit" "20220615.1159" "(POC) Teach Magit to use Libgit2."
  '((emacs "25.1")
    (compat "28.1.1.2")
    (libgit "0")
    (magit "20211004"))
  :commit "5e2d12615223a24a959a8c38854a146dda6a6d74" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
