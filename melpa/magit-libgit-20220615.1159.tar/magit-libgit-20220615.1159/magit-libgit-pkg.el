(define-package "magit-libgit" "20220615.1159" "(POC) Teach Magit to use Libgit2."
  '((emacs "25.1")
    (compat "28.1.1.2")
    (libgit "0")
    (magit "20211004"))
  :commit "1f7a29371395dbfe6d6fbdc1aaa901638eb8ad45" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
