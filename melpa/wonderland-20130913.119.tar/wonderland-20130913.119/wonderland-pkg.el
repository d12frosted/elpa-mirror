;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wonderland" "20130913.119"
  "Declarative configuration for Emacsen."
  '((dash            "2.0.0")
    (dash-functional "1.0.0")
    (multi           "2.0.0")
    (emacs           "24"))
  :url "https://github.com/kurisuwhyte/emacs-wonderland"
  :commit "28cf6b37000c395ece9519db53147fb826a42bc4"
  :revdesc "28cf6b37000c"
  :keywords '("configuration" "profile" "wonderland")
  :authors '(("Christina Whyte" . "kurisu.whyte@gmail.com"))
  :maintainers '(("Christina Whyte" . "kurisu.whyte@gmail.com")))
