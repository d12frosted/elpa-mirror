;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-review" "20250416.802"
  "Schedule reviews for Org entries."
  ()
  :url "https://github.com/brabalan/org-review"
  :commit "1f24fa504d58d619bb81a2c16058f685d85c2151"
  :revdesc "1f24fa504d58"
  :keywords '("calendar")
  :authors '(("Alan Schmitt" . "alan.schmitt@polytechnique.org"))
  :maintainers '(("Alan Schmitt" . "alan.schmitt@polytechnique.org")))
