;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20260502.955"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "4e20939c163195beed6dd239e3c64becd9acc63d"
  :revdesc "4e20939c1631"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
