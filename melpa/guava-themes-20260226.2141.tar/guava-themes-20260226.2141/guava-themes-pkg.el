;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260226.2141"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "cfd2cdcb78a8b3b09eb88fa8cd3f242a26343c33"
  :revdesc "cfd2cdcb78a8"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
