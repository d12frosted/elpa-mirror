(define-package "gnu-apl-mode" "20210904.509" "Integrate GNU APL with Emacs"
  '((emacs "24"))
  :commit "c1203e8ff655ba776ecdc49b3420aaed4bd37952" :authors
  '(("Elias Mårtenson" . "lokedhs@gmail.com"))
  :maintainer
  '("Elias Mårtenson" . "lokedhs@gmail.com")
  :keywords
  '("languages")
  :url "http://www.gnu.org/software/apl/")
;; Local Variables:
;; no-byte-compile: t
;; End:
