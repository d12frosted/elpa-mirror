;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20251218.2145"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "42c65d0001746b19fc1fa300e43818c23d6d1669"
  :revdesc "42c65d000174"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
