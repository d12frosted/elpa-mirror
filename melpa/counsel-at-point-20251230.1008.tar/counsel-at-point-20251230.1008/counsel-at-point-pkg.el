;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-at-point" "20251230.1008"
  "Context-sensitive project search."
  '((emacs   "29.1")
    (counsel "0.13.0"))
  :url "https://codeberg.org/ideasman42/emacs-counsel-at-point"
  :commit "09d186641edf7b83aa6b9a063f70c201cd9bbbc6"
  :revdesc "09d186641edf"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
