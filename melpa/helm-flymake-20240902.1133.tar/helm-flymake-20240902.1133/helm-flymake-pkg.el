;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-flymake" "20240902.1133"
  "Helm sources for flymake."
  '((helm "1.0"))
  :url "https://github.com/emacs-helm/helm-flymake"
  :commit "3df968f45b066bc284b0bcce718c8493104d3f3b"
  :revdesc "3df968f45b06"
  :authors '(("Akira Tamamori" . "tamamori5917@gmail.com"))
  :maintainers '(("zbelial" . "zjyzhaojiyang@gmail.com")))
