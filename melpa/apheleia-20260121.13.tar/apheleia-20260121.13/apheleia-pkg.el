;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20260121.13"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "143c1dffed15f1cab3eb06e148fe11224e39471c"
  :revdesc "143c1dffed15"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
