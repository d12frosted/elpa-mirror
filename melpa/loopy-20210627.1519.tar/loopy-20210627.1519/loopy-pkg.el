(define-package "loopy" "20210627.1519" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "b0740ff15ab42207d9a5f8d571eb7607012699f1" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
