;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modtime-skip-mode" "20140128.2201"
  "Minor mode for disabling modtime and supersession checks on files."
  ()
  :url "http://www.github.com/jordonbiondo/modtime-skip-mode"
  :commit "c0e49523aa26b2263a8693691ac775988015f592"
  :revdesc "c0e49523aa26"
  :authors '(("Jordon Biondo" . "biondoj@mail.gvsu.edu"))
  :maintainers '(("Jordon Biondo" . "biondoj@mail.gvsu.edu")))
