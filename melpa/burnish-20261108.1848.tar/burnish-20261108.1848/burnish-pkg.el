;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "burnish" "20261108.1848"
  "Automate Org export and view."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/burnish"
  :commit "27e321d03820d7174aa220be1a9e1b7de91d3034"
  :revdesc "27e321d03820"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
