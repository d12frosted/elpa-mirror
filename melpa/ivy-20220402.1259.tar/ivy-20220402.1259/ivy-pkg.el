(define-package "ivy" "20220402.1259" "Incremental Vertical completYon"
  '((emacs "24.5"))
  :commit "40e017dc1bc4655f7c3cf4bbbe3a827ce2fff213" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("matching")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
