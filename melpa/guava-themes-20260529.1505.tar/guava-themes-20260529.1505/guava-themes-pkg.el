;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260529.1505"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "302ba7191044c70477a17ae64badae814be902e9"
  :revdesc "302ba7191044"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
