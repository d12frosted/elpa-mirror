(define-package "json-par" "20220814.240" "Minor mode for structural editing of JSON"
  '((emacs "24.4")
    (json-mode "1.7.0"))
  :commit "90d7746fdb915e71baa6bff76889b51092b03207" :authors
  '(("taku0 (http://github.com/taku0)"))
  :maintainer
  '("taku0 (http://github.com/taku0)")
  :keywords
  '("abbrev" "convenience" "files")
  :url "https://github.com/taku0/json-par")
;; Local Variables:
;; no-byte-compile: t
;; End:
