;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250427.1749"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "9eef7a26e50669b5fea16ede7bbf9a11848dba4d"
  :revdesc "9eef7a26e506"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
