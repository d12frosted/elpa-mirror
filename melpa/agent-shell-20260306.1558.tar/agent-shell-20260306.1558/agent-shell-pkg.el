;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260306.1558"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.86.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4fcc247b19e19ffdbc9798d57e86854c60fef57b"
  :revdesc "4fcc247b19e1")
