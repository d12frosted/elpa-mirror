;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260412.1142"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "b235b75cbba3827371670f5636b716101906a9e5"
  :revdesc "b235b75cbba3"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
