(define-package "ebib" "20211210.128" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "8f4884f270ecffc0272d777b4aac54ea57977816" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
