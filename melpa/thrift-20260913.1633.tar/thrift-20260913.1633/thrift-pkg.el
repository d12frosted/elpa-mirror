;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260913.1633"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "6f3635d555882533049059060e2e041378edef8a"
  :revdesc "6f3635d55588"
  :keywords '("languages"))
