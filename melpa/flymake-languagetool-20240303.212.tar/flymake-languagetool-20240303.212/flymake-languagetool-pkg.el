(define-package "flymake-languagetool" "20240303.212" "Flymake support for LanguageTool"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "870012d34daba5d2ca44c8c060fd74f1ed48e28f" :keywords
  '("convenience" "grammar" "check")
  :url "https://github.com/emacs-languagetool/flymake-languagetool")
;; Local Variables:
;; no-byte-compile: t
;; End:
