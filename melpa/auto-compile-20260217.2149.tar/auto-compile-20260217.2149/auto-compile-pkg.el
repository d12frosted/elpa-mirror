;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-compile" "20260217.2149"
  "Automatically compile Emacs Lisp libraries."
  '((emacs "27.1"))
  :url "https://github.com/emacscollective/auto-compile"
  :commit "bd9fa40219df3e6c29bc3441b33b1e4d4929cb68"
  :revdesc "bd9fa40219df"
  :keywords '("compile" "convenience" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev")))
