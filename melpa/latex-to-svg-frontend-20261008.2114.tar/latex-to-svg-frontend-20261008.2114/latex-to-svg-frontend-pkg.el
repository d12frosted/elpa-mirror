;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261008.2114"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.11.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "38af3f5c05fb4afa555d6a22d3ecb45d251dd3ae"
  :revdesc "38af3f5c05fb"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
