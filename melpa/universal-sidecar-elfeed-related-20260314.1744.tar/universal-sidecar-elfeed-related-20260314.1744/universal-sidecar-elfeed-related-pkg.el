;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "universal-sidecar-elfeed-related" "20260314.1744"
  "Related Papers Sidecar Section for Elfeed."
  '((emacs             "25.1")
    (universal-sidecar "1.0.0")
    (bibtex-completion "1.0.0")
    (elfeed            "3.4.1"))
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar"
  :commit "3b6bd928f7adb840e62a63dd5bf1236ece912b13"
  :revdesc "3b6bd928f7ad"
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
