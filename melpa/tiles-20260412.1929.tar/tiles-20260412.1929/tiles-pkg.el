;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiles" "20260412.1929"
  "Tagged Instant Lightweight Emacs Snippets."
  '((emacs "27.1"))
  :url "https://github.com/ctanas/tiles"
  :commit "149a5015b3d2a2ebdd15660cab9c736549af7532"
  :revdesc "149a5015b3d2"
  :keywords '("files" "text" "convenience")
  :authors '(("Claudiu Tănăselia" . "https://www.tanaselia.ro"))
  :maintainers '(("Claudiu Tănăselia" . "https://www.tanaselia.ro")))
