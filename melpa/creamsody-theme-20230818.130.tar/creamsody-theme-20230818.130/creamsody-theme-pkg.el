(define-package "creamsody-theme" "20230818.130" "Straight from the soda fountain"
  '((autothemer "0.2")
    (emacs "24"))
  :commit "f00210c2d7a85f88c604916c5e619c6270775f96" :url "http://github.com/emacsfodder/emacs-theme-creamsody")
;; Local Variables:
;; no-byte-compile: t
;; End:
