;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260816.2202"
  "Manage multiple AI coding agents."
  '((emacs         "28.1")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (magit-section "3.3.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "8470a035426ecb10b6960ade8a7cbb39c99be148"
  :revdesc "8470a035426e"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
