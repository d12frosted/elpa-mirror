;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250420.1838"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "bbf70dbf44e004d58a497d544907bbd05c43af93"
  :revdesc "bbf70dbf44e0"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
