(define-package "live-py-mode" "20231001.459" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "a8c712d87c33a3455e1049cc5f72c0eb1dbed0e2" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainers
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
