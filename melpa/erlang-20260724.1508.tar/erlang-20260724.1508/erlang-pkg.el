;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20260724.1508"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "1259612946cb36a8bf9614b289090bb32fbcbeb2"
  :revdesc "1259612946cb"
  :keywords '("erlang" "languages" "processes"))
