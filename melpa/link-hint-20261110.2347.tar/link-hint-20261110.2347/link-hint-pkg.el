;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "link-hint" "20261110.2347"
  "Use avy to open, copy, etc. visible links."
  '((avy   "0.4.0")
    (emacs "24.4"))
  :url "https://github.com/noctuid/link-hint.el"
  :commit "ec2381aa8e210a3238c55810b37c8c4454a065bd"
  :revdesc "ec2381aa8e21"
  :keywords '("convenience" "url" "avy" "link" "links" "hyperlink")
  :authors '(("Fox Kiester" . "noct@posteo.net"))
  :maintainers '(("Fox Kiester" . "noct@posteo.net")))
