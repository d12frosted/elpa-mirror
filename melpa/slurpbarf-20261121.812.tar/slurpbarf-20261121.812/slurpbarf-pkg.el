;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slurpbarf" "20261121.812"
  "Commands for slurping and barfing."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "734ebf438c0a56b4047663580fa1bde717ac9b95"
  :revdesc "734ebf438c0a"
  :keywords '("convenience" "lisp" "xml"))
