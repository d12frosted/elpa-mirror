;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260121.311"
  "A minimal Jabber client."
  '((emacs "27.1")
    (fsm   "0.2.0")
    (srv   "0.2"))
  :url "https://codeberg.org/emacs-jabber/emacs-jabber"
  :commit "6691665144807e7b2a81ea62a268b8b8e4a5066e"
  :revdesc "669166514480"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("wgreenhouse" . "wgreenhouse@tilde.club")))
