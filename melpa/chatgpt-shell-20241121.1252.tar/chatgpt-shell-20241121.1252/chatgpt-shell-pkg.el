;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241121.1252"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.69.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "01bfb0cddff1d5612d7dacebba251e3f98fd5746"
  :revdesc "01bfb0cddff1")
