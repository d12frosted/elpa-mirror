;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20260403.2056"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "ac2bf8a6e10408e1f270c754ef8262785f428efa"
  :revdesc "ac2bf8a6e104"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
