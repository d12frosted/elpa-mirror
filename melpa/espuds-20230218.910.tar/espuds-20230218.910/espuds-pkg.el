;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "espuds" "20230218.910"
  "Ecukes step definitions."
  '((emacs "25")
    (s     "1.7.0")
    (dash  "2.2.0")
    (f     "0.12.1"))
  :url "https://github.com/ecukes/espuds"
  :commit "57c18a48f1a01d8174298eaab4fcf3b2c6549291"
  :revdesc "57c18a48f1a0"
  :keywords '("test")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
