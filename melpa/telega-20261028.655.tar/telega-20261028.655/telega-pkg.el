;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20261028.655"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "dc06b97d3f5ae7faab27e79ad946077ad1441362"
  :revdesc "dc06b97d3f5a"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
