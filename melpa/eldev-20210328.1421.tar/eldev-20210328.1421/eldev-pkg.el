(define-package "eldev" "20210328.1421" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "8cc33d17686867c12540d5c07a031cc8c94e288f" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
