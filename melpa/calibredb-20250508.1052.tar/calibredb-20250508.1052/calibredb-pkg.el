;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calibredb" "20250508.1052"
  "Yet another calibre client."
  '((emacs     "29.1")
    (org       "9.3")
    (transient "0.1.0")
    (s         "1.12.0")
    (dash      "2.17.0")
    (request   "0.3.3")
    (esxml     "0.3.7"))
  :url "https://github.com/chenyanming/calibredb.el"
  :commit "373cb3633f1cdc812597b353ddf32b89fb36035b"
  :revdesc "373cb3633f1c"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
