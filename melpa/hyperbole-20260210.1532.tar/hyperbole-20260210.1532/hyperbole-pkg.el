;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260210.1532"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "7a10e39a55fe7b989913b072e10951725c182e86"
  :revdesc "7a10e39a55fe"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
