;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-decompiler" "20220103.1746"
  "Clojure Java decompiler expansion."
  '((emacs        "26.1")
    (clojure-mode "5.12")
    (cider        "1.2.0"))
  :url "https://www.github.com/bsless/clj-decompiler.el"
  :commit "8c0c53f87e6e33f2be7e7aff6095eb586b50be1a"
  :revdesc "8c0c53f87e6e"
  :keywords '("languages" "clojure" "cider" "java" "decompiler")
  :authors '(("Ben Sless" . "ben.sless@gmail.com"))
  :maintainers '(("Ben Sless" . "ben.sless@gmail.com")))
