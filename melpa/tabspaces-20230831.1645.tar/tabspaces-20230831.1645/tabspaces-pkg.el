(define-package "tabspaces" "20230831.1645" "Leverage tab-bar and project for buffer-isolated workspaces"
  '((emacs "27.1")
    (project "0.8.1"))
  :commit "4c4ee483ff18f3ae04214f0d07efd8175c66f6d0" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainers
  '(("Colin McLear"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/mclear-tools/tabspaces")
;; Local Variables:
;; no-byte-compile: t
;; End:
