;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260318.938"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.2")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c974b58cdf2f5051658cd20cda3216d708259927"
  :revdesc "c974b58cdf2f")
