;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260215.1818"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "9e13bb51ccb2a8d66331ee83d5aef45bf30b9843"
  :revdesc "9e13bb51ccb2"
  :keywords '("convenience"))
