;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vc-modified-files" "20250226.1041"
  "Show git modified files in a vc project with consult."
  '((emacs   "28.1")
    (consult "0.9"))
  :url "https://github.com/chmouel/consult-vc-modified-files"
  :commit "4c0e426d798e1fa600f757297d6a25332138ab2b"
  :revdesc "4c0e426d798e"
  :keywords '("vc" "convenience")
  :authors '(("Chmouel Boudjnah" . "chmouel@chmouel.com"))
  :maintainers '(("Chmouel Boudjnah" . "chmouel@chmouel.com")))
