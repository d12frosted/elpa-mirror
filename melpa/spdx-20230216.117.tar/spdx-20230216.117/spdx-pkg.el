(define-package "spdx" "20230216.117" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "90ebb7a84677414c5e8affc257ed535af89a9d28" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
