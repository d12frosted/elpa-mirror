;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-ess-r" "20241120.649"
  "R with tree-sitter."
  '((emacs             "26.1")
    (ess               "18.10.1")
    (tree-sitter       "0.12.1")
    (tree-sitter-langs "0.12.0"))
  :url "https://github.com/ShuguangSun/tree-sitter-ess-r"
  :commit "9999f4e6450f858493d9aac2c93e3bea65e3c6c2"
  :revdesc "9999f4e6450f"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
