(define-package "hl-indent-scope" "20230113.1254" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "bcb33696c8a127d554d68a0a96db2b1a25efb76e" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
