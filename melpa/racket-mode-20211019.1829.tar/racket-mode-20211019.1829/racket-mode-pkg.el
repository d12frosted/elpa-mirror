(define-package "racket-mode" "20211019.1829" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "991f98cfd3e8d5dcebeeadb900cd279e39850ada" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
