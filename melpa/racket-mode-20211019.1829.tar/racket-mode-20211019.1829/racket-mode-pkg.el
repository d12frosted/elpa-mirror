(define-package "racket-mode" "20211019.1829" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "4662792625dadcf9ed3c09c83185431738be29a1" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
