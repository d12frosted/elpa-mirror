;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglink" "20260521.1111"
  "Use Org Mode links in other modes."
  '((emacs  "28.1")
    (compat "31.0")
    (llama  "1.0")
    (org    "9.7")
    (seq    "2.24"))
  :url "https://github.com/tarsius/orglink"
  :commit "22be77113bcd2eb704a0e8a49cec21136afdffa0"
  :revdesc "22be77113bcd"
  :keywords '("hypermedia")
  :authors '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev")))
