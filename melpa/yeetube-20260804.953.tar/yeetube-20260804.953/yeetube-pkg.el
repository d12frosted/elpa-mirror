;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260804.953"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "f26e5db739af35c99d44607ef0fe992bf69bb8dd"
  :revdesc "f26e5db739af"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
