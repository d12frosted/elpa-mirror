;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20251122.1835"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "b7fd795c6cca2b209dcf93664ad23463430152fc"
  :revdesc "b7fd795c6cca"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
