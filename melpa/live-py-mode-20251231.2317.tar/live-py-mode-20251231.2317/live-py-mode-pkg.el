;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-py-mode" "20251231.2317"
  "Live Coding in Python."
  '((emacs "24.3"))
  :url "http://donkirkby.github.io/live-py-plugin/"
  :commit "cf6ef26bf4219d0cd1dd550f777cb6b5642aee1e"
  :revdesc "cf6ef26bf421"
  :keywords '("live" "coding"))
