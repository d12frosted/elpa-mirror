;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261109.2157"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "210c2c6189f9cdc0aa2e2cfe0508ca6c90796e3f"
  :revdesc "210c2c6189f9"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
