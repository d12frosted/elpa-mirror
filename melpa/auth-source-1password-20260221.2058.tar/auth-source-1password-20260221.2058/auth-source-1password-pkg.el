;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auth-source-1password" "20260221.2058"
  "1password integration for auth-source."
  '((emacs "24.4"))
  :url "https://github.com/dlobraico"
  :commit "10961bdc8a3ed551dde29fde416843058bea2374"
  :revdesc "10961bdc8a3e"
  :authors '(("Dominick LoBraico" . "auth-source-1password@lobrai.co"))
  :maintainers '(("Dominick LoBraico" . "auth-source-1password@lobrai.co")))
