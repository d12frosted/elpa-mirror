(define-package "sculpture-themes" "20220331.1101" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "55baf9fa457069edbb76502a41fd5ca54ccd39fc" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
