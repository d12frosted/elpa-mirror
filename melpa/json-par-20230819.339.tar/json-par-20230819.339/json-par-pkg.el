(define-package "json-par" "20230819.339" "Minor mode for structural editing of JSON"
  '((emacs "24.4")
    (json-mode "1.7.0"))
  :commit "9fff40e04a1956af6fcf48b5206e81143aec23f3" :authors
  '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainers
  '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainer
  '("taku0" . "mxxouy6x3m_github@tatapa.org")
  :keywords
  '("abbrev" "convenience" "files")
  :url "https://github.com/taku0/json-par")
;; Local Variables:
;; no-byte-compile: t
;; End:
