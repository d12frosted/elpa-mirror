;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-cpp-complete" "20260102.253"
  "GPTel-powered C++ completion."
  '((emacs "30.1")
    (eglot "1.19")
    (gptel "0.9.8"))
  :url "https://github.com/beacoder/gptel-cpp-complete"
  :commit "457a12eff440a038c52c9c951dbb4a3e337688ab"
  :revdesc "457a12eff440"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
