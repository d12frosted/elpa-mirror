(define-package "zk" "20230609.742" "Functions for working with Zettelkasten-style linked notes"
  '((emacs "25.1"))
  :commit "6ba90de2b33a8717fb1e263fe6df7b3831d3bd8e" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/zk")
;; Local Variables:
;; no-byte-compile: t
;; End:
