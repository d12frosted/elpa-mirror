;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-scrum" "20241231.1311"
  "Org mode extensions for scrum planning and reporting."
  '((emacs  "24.5")
    (org    "8.2")
    (seq    "2.3")
    (cl-lib "1.0"))
  :url "https://github.com/ianxm/emacs-scrum"
  :commit "b1b8d92927ed6f3360109597a86a1c567f120e30"
  :revdesc "b1b8d92927ed"
  :authors '(("Ian Martins" . "ianxm@jhu.edu"))
  :maintainers '(("Ian Martins" . "ianxm@jhu.edu")))
