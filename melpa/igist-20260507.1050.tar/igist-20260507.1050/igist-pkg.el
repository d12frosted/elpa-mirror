;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "igist" "20260507.1050"
  "List, create, update and delete GitHub gists."
  '((emacs     "29.1")
    (ghub      "4.2.2")
    (transient "0.8.5"))
  :url "https://github.com/KarimAziev/igist"
  :commit "4d7a2116281b55114156c6089988a601766da845"
  :revdesc "4d7a2116281b"
  :keywords '("tools")
  :authors '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers '(("Karim Aziiev" . "karim.aziiev@gmail.com")))
