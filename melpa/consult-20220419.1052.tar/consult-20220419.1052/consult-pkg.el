(define-package "consult" "20220419.1052" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "663bfbcb968a3b3918be2d8cd4c41b31d237b08c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
