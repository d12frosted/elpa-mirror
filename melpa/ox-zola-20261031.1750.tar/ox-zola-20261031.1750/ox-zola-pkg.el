;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-zola" "20261031.1750"
  "Org export to Zola static site generator."
  '((emacs   "27.2")
    (ox-hugo "0.8"))
  :url "https://github.com/gicrisf/ox-zola"
  :commit "669312c1b0beabc4c1fe520d7e7398bd7cce3c0a"
  :revdesc "669312c1b0be"
  :keywords '("wp" "hypermedia" "org" "zola")
  :authors '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com")))
