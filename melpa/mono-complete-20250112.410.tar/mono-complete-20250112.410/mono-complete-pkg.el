;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mono-complete" "20250112.410"
  "Completion suggestions with multiple back-ends."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-mono-complete"
  :commit "a8869c0cac18816df33be768af127024f423a77e"
  :revdesc "a8869c0cac18"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
