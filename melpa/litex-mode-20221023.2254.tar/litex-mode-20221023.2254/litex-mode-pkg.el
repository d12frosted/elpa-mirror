(define-package "litex-mode" "20221023.2254" "Minor mode for converting lisp to LaTeX"
  '((emacs "24.4")
    (units-mode "0.1.1"))
  :commit "8141679de6779b13d1ee50102f43f8637ce8243d" :authors
  '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainer
  '("Gaurav Atreya" . "allmanpride@gmail.com")
  :keywords
  '("calculator" "lisp" "latex")
  :url "https://github.com/Atreyagaurav/litex-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
