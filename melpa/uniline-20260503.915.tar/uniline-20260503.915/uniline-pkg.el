;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260503.915"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "3d674fe9ffaa8b6afa5507087f4e7fe7dbf1156a"
  :revdesc "3d674fe9ffaa"
  :keywords '("convenience" "text"))
