;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amber-mode" "20261003.711"
  "A major mode for the Amber programming language."
  '((emacs "28.1"))
  :url "https://codeberg.org/GeorgGD/amber-mode"
  :commit "0848359c32c230194a708d7c572a54cc47e771dd"
  :revdesc "0848359c32c2"
  :keywords '("amber" "languages")
  :authors '(("Georgios Davakos" . "georgios.davakos@protonmail.com"))
  :maintainers '(("Georgios Davakos" . "georgios.davakos@protonmail.com")))
