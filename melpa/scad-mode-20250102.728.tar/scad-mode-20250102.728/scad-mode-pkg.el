;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "20250102.728"
  "A major mode for editing OpenSCAD code."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "8bc0bbb7ab770ec81d7ce460984a000bf7a3c112"
  :revdesc "8bc0bbb7ab77"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
