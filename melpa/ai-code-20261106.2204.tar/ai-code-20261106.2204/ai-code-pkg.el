;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261106.2204"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a976e61523224307092fde297314a60c1a547c47"
  :revdesc "a976e6152322"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
