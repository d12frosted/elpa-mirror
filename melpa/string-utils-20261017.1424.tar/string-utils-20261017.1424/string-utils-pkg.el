;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "string-utils" "20261017.1424"
  "String-manipulation utilities."
  '((list-utils "0.4.2"))
  :url "https://github.com/rolandwalker/string-utils"
  :commit "d9403eeb5b0093f7cb519bf0be42f6b30b894ec0"
  :revdesc "d9403eeb5b00"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
