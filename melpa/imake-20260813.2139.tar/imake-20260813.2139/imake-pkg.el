;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imake" "20260813.2139"
  "Simple, opinionated make target runner."
  '((emacs      "28.1")
    (compat     "31.0")
    (marginalia "2.11"))
  :url "https://github.com/tarsius/imake"
  :commit "8a5cfb021de517027492c77acf772823425cbc12"
  :revdesc "8a5cfb021de5"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev")))
