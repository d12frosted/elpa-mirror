(define-package "mame" "20230906.1549" "A MAME front-end"
  '((emacs "27.1"))
  :commit "a0656eae4152ae30a0ec62284843afa3a5ec4be2" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
