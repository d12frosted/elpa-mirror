(define-package "brec-mode" "20240425.1650" "A major mode for editing Breccian text"
  '((emacs "24.3"))
  :commit "72331e339fd757f942de45897040430a58dee320" :authors
  '(("Michael Allan" . "mike@reluk.ca"))
  :maintainers
  '(("Michael Allan" . "mike@reluk.ca"))
  :maintainer
  '("Michael Allan" . "mike@reluk.ca")
  :keywords
  '("outlines" "wp")
  :url "http://reluk.ca/project/Breccia/Emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
