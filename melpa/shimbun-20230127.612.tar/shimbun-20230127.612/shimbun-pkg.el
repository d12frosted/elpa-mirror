(define-package "shimbun" "20230127.612" "interfacing with web newspapers" 'nil :commit "e556f82247918bdc33acf01b29917314b8b9e22b" :authors
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
    ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
    ("Yuuichi Teranishi " . "teranisi@gohome.org")
    ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  '("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  '("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
