;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-athena" "20260404.1816"
  "Run AWS Athena queries from Org Babel."
  '((emacs "26.1"))
  :url "https://github.com/will-abb/aws-athena-babel"
  :commit "132ccc35c13e772ed39813d949d0089ea0c66a66"
  :revdesc "132ccc35c13e"
  :keywords '("aws" "athena" "org" "babel" "sql" "tools")
  :authors '(("Williams Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Williams Bosch-Bello" . "williamsbosch@gmail.com")))
