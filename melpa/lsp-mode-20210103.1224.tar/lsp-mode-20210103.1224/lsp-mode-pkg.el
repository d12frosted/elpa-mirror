(define-package "lsp-mode" "20210103.1224" "LSP mode"
  '((emacs "26.1")
    (dash "2.14.1")
    (dash-functional "2.14.1")
    (f "0.20.0")
    (ht "2.0")
    (spinner "1.7.3")
    (markdown-mode "2.3")
    (lv "0"))
  :commit "01fc0bb9a6db1b3b82aec3fdcff6ad1935d43466" :authors
  (("Vibhav Pant, Fangrui Song, Ivan Yonchovski"))
  :maintainer
  ("Vibhav Pant, Fangrui Song, Ivan Yonchovski")
  :keywords
  ("languages")
  :url "https://github.com/emacs-lsp/lsp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
