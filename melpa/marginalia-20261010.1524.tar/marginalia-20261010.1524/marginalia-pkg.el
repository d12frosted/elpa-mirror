;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marginalia" "20261010.1524"
  "Enrich existing commands with completion annotations."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/marginalia"
  :commit "381af583d2530796b9955ff2fe0cba3ad3119943"
  :revdesc "381af583d253"
  :keywords '("docs" "help" "matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
