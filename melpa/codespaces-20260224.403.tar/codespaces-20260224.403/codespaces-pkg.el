;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260224.403"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "16e5fc290532847c1dc3ced23533376880e44267"
  :revdesc "16e5fc290532"
  :keywords '("comm")
  :authors '(("Patrick Thomson" . "patrickt@github.com"))
  :maintainers '(("Patrick Thomson" . "patrickt@github.com")))
