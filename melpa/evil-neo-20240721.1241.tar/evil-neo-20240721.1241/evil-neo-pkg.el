;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-neo" "20240721.1241"
  "Minor mode for using the Neo keyboard layout with Evil."
  '((evil "1.0.0"))
  :url "https://git.sr.ht/~p-conrad/evil-neo"
  :commit "18f115a0ddc12a0930f0eb2f9f119b190c71017e"
  :revdesc "18f115a0ddc1"
  :keywords '("convenience" "emulations" "neo" "evil" "vim" "keymap")
  :authors '(("Peter Conrad" . "p.conrad@proton.me"))
  :maintainers '(("Peter Conrad" . "p.conrad@proton.me")))
