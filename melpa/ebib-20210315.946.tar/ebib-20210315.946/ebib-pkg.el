(define-package "ebib" "20210315.946" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "a0240a2dee2626be28f1c14c0ccb59679bbaa898" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
