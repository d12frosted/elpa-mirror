;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20251030.1641"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "27.1")
    (epkg  "4.1")
    (magit "4.4"))
  :url "https://github.com/emacscollective/borg"
  :commit "1d17f62262e7f25bf6f048e9356027bb88acb1e6"
  :revdesc "1d17f62262e7"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
