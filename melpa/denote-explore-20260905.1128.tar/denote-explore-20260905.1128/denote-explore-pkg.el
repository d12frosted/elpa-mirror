;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "20260905.1128"
  "Explore and visualise Denote files."
  '((emacs         "29.1")
    (denote        "4.2")
    (dash          "2.19.1")
    (denote-regexp "20250415.2202"))
  :url "https://github.com/pprevos/denote-explore/"
  :commit "2668190363ca7e2ee4f7a1d0055655cc49a60189"
  :revdesc "2668190363ca"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
