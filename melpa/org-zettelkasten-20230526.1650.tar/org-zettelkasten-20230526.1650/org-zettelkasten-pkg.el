(define-package "org-zettelkasten" "20230526.1650" "A Zettelkasten mode leveraging Org"
  '((emacs "25.1")
    (org "9.3"))
  :commit "44e13ec043ad726f6a16ea36bfb43d985912e746" :authors
  '(("Yann Herklotz" . "git@yannherklotz.com"))
  :maintainers
  '(("Yann Herklotz" . "git@yannherklotz.com"))
  :maintainer
  '("Yann Herklotz" . "git@yannherklotz.com")
  :keywords
  '("files" "hypermedia" "org" "notes")
  :url "https://sr.ht/~ymherklotz/org-zettelkasten")
;; Local Variables:
;; no-byte-compile: t
;; End:
