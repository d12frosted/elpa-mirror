;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260306.1721"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "b4185785096007a70dc661d183c962be123410af"
  :revdesc "b41857850960"
  :keywords '("data" "extensions"))
