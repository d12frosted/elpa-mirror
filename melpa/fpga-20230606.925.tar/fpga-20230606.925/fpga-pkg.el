(define-package "fpga" "20230606.925" "FPGA & ASIC Utils"
  '((emacs "28.1")
    (ggtags "0.9.0")
    (company "0.9.13"))
  :commit "37303621e6026da3f2d084b6c0fc72c37e77f8bf" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/gmlarumbe/fpga")
;; Local Variables:
;; no-byte-compile: t
;; End:
