(define-package "consult" "20220901.1903" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "ad6cceb95eaa72f996bb8f0ccd6054f626d35f3b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
