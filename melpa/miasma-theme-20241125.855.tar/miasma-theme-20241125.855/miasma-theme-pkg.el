;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20241125.855"
  "Miasma: color theme inspired by the woods."
  ()
  :url "https://github.com/daut/miasma-theme.el"
  :commit "862e151962ece301e6bf3f68fb913943f08f2909"
  :revdesc "862e151962ec")
