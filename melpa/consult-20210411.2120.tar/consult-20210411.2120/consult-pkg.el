(define-package "consult" "20210411.2120" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "812204b647b1f45cc9d04d7d2f565061940f5e70" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
