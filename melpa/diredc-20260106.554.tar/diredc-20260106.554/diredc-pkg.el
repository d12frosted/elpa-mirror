;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260106.554"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "812a0e1892a318cf6cfd69d1296480e810e5d790"
  :revdesc "812a0e1892a3"
  :keywords '("files"))
