(define-package "company-spell" "20230813.1849" "Autocompleting spelling for Company"
  '((emacs "24.4")
    (company "0.9.13"))
  :commit "67505e492def67ae7bcf438882977fd857e94785" :keywords
  '("wp")
  :url "https://github.com/enzuru/company-spell")
;; Local Variables:
;; no-byte-compile: t
;; End:
