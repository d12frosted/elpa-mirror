(define-package "embark" "20211229.400" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "82475bb826b21b90b3c61c1d7772ecddd136d870" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
