;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "professional-theme" "20150315.1100"
  "Emacs port of Vim's professional theme."
  ()
  :url "https://github.com/juanjux/emacs-professional-theme"
  :commit "0927d1474049a193f9f366bde5eb1887b9ba20ed"
  :revdesc "0927d1474049"
  :keywords '("theme" "light" "professional")
  :authors '(("Juanjo Alvarez" . "juanjo@juanjoalvarez.net"))
  :maintainers '(("Juanjo Alvarez" . "juanjo@juanjoalvarez.net")))
