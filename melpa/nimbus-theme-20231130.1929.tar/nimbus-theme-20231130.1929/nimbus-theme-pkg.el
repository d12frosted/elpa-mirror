(define-package "nimbus-theme" "20231130.1929" "Nimbus dark theme"
  '((emacs "24.1"))
  :commit "73335a45f7303cb791e7df0129fca612183809fe" :authors
  '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers
  '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainer
  '("Marcin Swieczkowski" . "marcin@realemail.net")
  :keywords
  '("faces")
  :url "https://github.com/mrcnski/nimbus-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
