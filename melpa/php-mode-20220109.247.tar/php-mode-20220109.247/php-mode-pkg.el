(define-package "php-mode" "20220109.247" "Major mode for editing PHP code"
  '((emacs "25.2"))
  :commit "8a61f9dd3d804f779444a351342fb616260f6145" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
