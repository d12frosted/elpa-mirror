;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ycmd" "20181016.618"
  "Flycheck integration for ycmd."
  '((emacs     "24")
    (dash      "2.13.0")
    (flycheck  "0.22")
    (ycmd      "1.2")
    (let-alist "1.0.5"))
  :url "https://github.com/abingham/emacs-ycmd"
  :commit "ef87d020d3314efbac2e8925c115d0ac5c128c2a"
  :revdesc "ef87d020d331"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
