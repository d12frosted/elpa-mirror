;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "subsonic" "20260126.1705"
  "Browse and play music from subsonic servers with mpv."
  '((emacs     "27.1")
    (transient "0.2"))
  :url "https://git.sr.ht/~amk/subsonic.el"
  :commit "d4f7502783fa06ba624ddc2314082340cea4ec9e"
  :revdesc "d4f7502783fa"
  :keywords '("multimedia")
  :authors '(("Alex McGrath" . "amk@amk.ie"))
  :maintainers '(("Alex McGrath" . "amk@amk.ie")))
