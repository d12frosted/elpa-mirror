;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twilight-anti-bright-theme" "20160622.848"
  "A soothing Emacs 24 light-on-dark theme."
  ()
  :url "https://github.com/jimeh/twilight-anti-bright-theme.el"
  :commit "523b95fcdbf4a6a6483af314ad05354a3d80f23f"
  :revdesc "523b95fcdbf4"
  :keywords '("themes")
  :authors '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainers '(("Jim Myhrberg" . "contact@jimeh.me")))
