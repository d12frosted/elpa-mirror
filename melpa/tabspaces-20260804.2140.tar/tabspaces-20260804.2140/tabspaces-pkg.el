;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260804.2140"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "12178ee68b42fabf975e23c6bb1fda6fd318ee07"
  :revdesc "12178ee68b42"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
