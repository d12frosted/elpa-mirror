(define-package "julia-vterm" "20230811.247" "A mode for Julia REPL using vterm"
  '((emacs "25.1")
    (vterm "0.0.1"))
  :commit "3e0ce9fc1465cad786903a5281c4a103e6b4b7ac" :authors
  '(("Shigeaki Nishina"))
  :maintainers
  '(("Shigeaki Nishina"))
  :maintainer
  '("Shigeaki Nishina")
  :keywords
  '("languages" "julia")
  :url "https://github.com/shg/julia-vterm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
