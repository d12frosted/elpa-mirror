(define-package "cnfonts" "20220715.409" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "3732ada115cae269e0fa5e3434f92f3e6e6823d9" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
