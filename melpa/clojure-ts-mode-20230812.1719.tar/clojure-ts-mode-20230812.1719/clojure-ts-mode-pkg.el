(define-package "clojure-ts-mode" "20230812.1719" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "866e815f8e295184842ba9ab763f53e4310cf066" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
