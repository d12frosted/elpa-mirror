(define-package "hyperdrive" "20240430.1942" "P2P filesystem"
  '((emacs "28.1")
    (map "3.0")
    (compat "29.1.4.4")
    (plz "0.7.2")
    (persist "0.6")
    (taxy-magit-section "0.13")
    (transient "0.6.0"))
  :commit "59b7dcf10b802f595c58be9301d923b28fb5123c" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
