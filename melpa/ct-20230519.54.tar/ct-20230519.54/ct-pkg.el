(define-package "ct" "20230519.54" "Color Tools - a color api"
  '((emacs "26.1")
    (dash "2.18.0")
    (hsluv "1.0.0"))
  :commit "b4415d75cb934bcdd90cd27c4bd8d3498cde220a" :authors
  '(("neeasade"))
  :maintainers
  '(("neeasade"))
  :maintainer
  '("neeasade")
  :keywords
  '("convenience" "color" "theming" "rgb" "hsv" "hsl" "cie-lab" "background")
  :url "https://github.com/neeasade/ct.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
