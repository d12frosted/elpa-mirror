(define-package "clojure-mode-extra-font-locking" "20230823.1453" "Extra font-locking for Clojure mode"
  '((clojure-mode "3.0"))
  :commit "dae21f8807c80297b9d69aefac4c3864c56d50af" :authors
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.dev")
  :keywords
  '("languages" "lisp")
  :url "http://github.com/clojure-emacs/clojure-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
