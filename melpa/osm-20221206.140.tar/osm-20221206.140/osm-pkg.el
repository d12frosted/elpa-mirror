(define-package "osm" "20221206.140" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "9f717ca40efc3f05ed9cafd4589baa887559edb5" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
