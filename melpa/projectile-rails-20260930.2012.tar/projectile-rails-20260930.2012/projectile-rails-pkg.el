;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-rails" "20260930.2012"
  "Minor mode for Rails projects based on projectile-mode."
  '((emacs       "28.1")
    (projectile  "0.12.0")
    (inflections "1.1")
    (inf-ruby    "2.2.6")
    (f           "0.13.0")
    (rake        "0.3.2")
    (dash        "2.18.1"))
  :url "https://github.com/asok/projectile-rails"
  :commit "6a3181160c951d25d5e4e2cd6bf7f83b29c1b94b"
  :revdesc "6a3181160c95"
  :keywords '("rails" "tools" "projectile")
  :authors '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com"))
  :maintainers '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com")))
