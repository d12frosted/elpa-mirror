;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260608.2247"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "de6ac18b12b9a0ec025e88b5cd762c5fe0563019"
  :revdesc "de6ac18b12b9"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
