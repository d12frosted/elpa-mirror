;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20261122.906"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "8be6aebd95425d4079d980a115d60c81fd6d0242"
  :revdesc "8be6aebd9542"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
