;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trailing-newline-indicator" "20261122.2258"
  "Show an indicator for the trailing newline."
  '((emacs "26.1"))
  :url "https://github.com/saulotoledo/trailing-newline-indicator"
  :commit "957ee009d62e158abcfd9dc7335aa17a7fdc5e49"
  :revdesc "957ee009d62e"
  :keywords '("convenience" "display" "editing")
  :authors '(("Saulo S. de Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo S. de Toledo" . "saulotoledo@gmail.com")))
