(define-package "chezmoi" "20220221.1556" "A package for interacting with chezmoi"
  '((emacs "26.1"))
  :commit "0b25d312a84868d6cf76f2016cd0dbc70c9312a0" :authors
  '(("Harrison Pielke-Lombardo"))
  :maintainer
  '("Harrison Pielke-Lombardo")
  :keywords
  '("vc")
  :url "http://www.github.com/tuh8888/chezmoi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
