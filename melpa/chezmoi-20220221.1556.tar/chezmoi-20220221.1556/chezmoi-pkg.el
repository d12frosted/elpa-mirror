(define-package "chezmoi" "20220221.1556" "A package for interacting with chezmoi"
  '((emacs "26.1"))
  :commit "d7acbf7deaef77011b6d67c954d9257eba7ad9fd" :authors
  '(("Harrison Pielke-Lombardo"))
  :maintainer
  '("Harrison Pielke-Lombardo")
  :keywords
  '("vc")
  :url "http://www.github.com/tuh8888/chezmoi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
