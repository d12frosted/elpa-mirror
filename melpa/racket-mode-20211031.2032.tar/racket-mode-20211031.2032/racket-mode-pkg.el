(define-package "racket-mode" "20211031.2032" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "99a6aac13e3928cbff281ccbaebb3a2ea32404ab" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
