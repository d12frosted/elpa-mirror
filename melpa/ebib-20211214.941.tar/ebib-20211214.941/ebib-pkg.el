(define-package "ebib" "20211214.941" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "16797a9577e5055f0d9bd5a492a9d87b8ec6b7c9" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
