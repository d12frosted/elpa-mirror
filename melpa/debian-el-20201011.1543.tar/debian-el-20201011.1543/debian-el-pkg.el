(define-package "debian-el" "20201011.1543" "Emacs helpers specific to Debian users" 'nil :commit "6f09126b2e97b2e195145204caba11d0d4f871df")
;; Local Variables:
;; no-byte-compile: t
;; End:
