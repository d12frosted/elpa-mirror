;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "20260507.757"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "1ef8ae0cff094cfba750e72b897e03eaeebbc117"
  :revdesc "1ef8ae0cff09"
  :keywords '("languages" "tools"))
