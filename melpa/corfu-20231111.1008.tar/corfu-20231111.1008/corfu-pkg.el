(define-package "corfu" "20231111.1008" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "4107f80581fbdce2fed98371df05f6586a27a0c5" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
