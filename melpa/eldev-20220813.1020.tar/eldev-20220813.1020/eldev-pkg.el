(define-package "eldev" "20220813.1020" "Elisp development tool"
  '((emacs "24.4"))
  :commit "cff175a866084c3795abaf83a00fac6e68a10f5b" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
