(define-package "eask" "20230927.2314" "Core Eask APIs, for Eask CLI development"
  '((emacs "26.1")
    (dash "2.14.1"))
  :commit "84ceaaed587a0d62b2bf8b8a6767be43b2a7e4ad" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("lisp" "eask" "api")
  :url "https://github.com/emacs-eask/eask")
;; Local Variables:
;; no-byte-compile: t
;; End:
