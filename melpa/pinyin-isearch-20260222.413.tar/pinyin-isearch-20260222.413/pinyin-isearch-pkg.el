;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260222.413"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "a48376f1c48b827e3c373905621a669b98fa354c"
  :revdesc "a48376f1c48b"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
