(define-package "mu4e-overview" "20231021.46" "Show overview of maildir"
  '((emacs "26"))
  :commit "18b74e26616f7fe4d2db13d9def4b5a0fa44ddcd" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("mail" "tools")
  :url "https://github.com/mkcms/mu4e-overview")
;; Local Variables:
;; no-byte-compile: t
;; End:
