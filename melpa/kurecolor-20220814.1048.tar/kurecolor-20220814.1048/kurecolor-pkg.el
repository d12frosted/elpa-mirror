(define-package "kurecolor" "20220814.1048" "color editing goodies"
  '((emacs "28.1")
    (s "1.12"))
  :commit "ac535a35716d666948d94975345079efd195ffcf" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
