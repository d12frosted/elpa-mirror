;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20260316.936"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "ffd6b69933e362a29967ed2967f12d474e39f887"
  :revdesc "ffd6b69933e3"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
