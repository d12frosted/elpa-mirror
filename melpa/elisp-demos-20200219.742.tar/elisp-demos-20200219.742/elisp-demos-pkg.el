(define-package "elisp-demos" "20200219.742" "Elisp API Demos"
  '((emacs "24.4"))
  :commit "7cc5ae4eac5bd8f38ade9ba1c28ad6faaba82160" :authors
  '(("Xu Chunyang"))
  :maintainer
  '("Xu Chunyang")
  :keywords
  '("lisp" "docs")
  :url "https://github.com/xuchunyang/elisp-demos")
;; Local Variables:
;; no-byte-compile: t
;; End:
