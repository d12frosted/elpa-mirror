;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20261008.1913"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "eb9d30f667040ade8f546470af463b79a9c0a3b5"
  :revdesc "eb9d30f66704"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
