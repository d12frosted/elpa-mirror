(define-package "vterm" "20220822.1158" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "f104e3a11c9ff33ccc0e086cffaadc9549e9e8b1" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
