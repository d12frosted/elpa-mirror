(define-package "erk" "20231024.441" "Elisp (GitHub) Repository Kit"
  '((emacs "28.1")
    (auto-compile "1.2.0")
    (dash "2.18.0")
    (license-templates "0.1.3"))
  :commit "6e5eaa8b6317d596d0721a3d7656bfb89ff2f847" :authors
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainers
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainer
  '("Positron Solutions" . "contact@positron.solutions")
  :keywords
  '("convenience" "programming")
  :url "http://github.com/positron-solutions/elisp-repo-kit")
;; Local Variables:
;; no-byte-compile: t
;; End:
