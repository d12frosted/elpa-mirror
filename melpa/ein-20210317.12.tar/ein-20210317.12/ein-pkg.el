(define-package "ein" "20210317.12" "Emacs IPython Notebook"
  '((emacs "25")
    (websocket "20190620")
    (anaphora "20180618")
    (request "20200117")
    (deferred "0.5")
    (polymode "20190714")
    (dash "2.13.0")
    (with-editor "20200522"))
  :commit "147940d5d734b22e8dc6fc24d1d7423766ceed0c" :keywords
  '("jupyter" "literate programming" "reproducible research")
  :url "https://github.com/dickmao/emacs-ipython-notebook")
;; Local Variables:
;; no-byte-compile: t
;; End:
