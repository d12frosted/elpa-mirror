(define-package "lem" "20231217.1701" "A basic lemmy client"
  '((emacs "29.1")
    (fedi "0.1")
    (markdown-mode "2.5"))
  :commit "d4cb29800ed3e844a7742591e30871bc329a1432" :authors
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainers
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainer
  '("martian hiatus <martianhiatus [a t] riseup [d o t] net>")
  :keywords
  '("multimedia" "comm" "web" "fediverse")
  :url "https://codeberg.org/martianh/lem.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
