;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260101.1428"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "f314f54e025d3c78280c402df9bdbf15a0797702"
  :revdesc "f314f54e025d")
