(define-package "elisp-autofmt" "20230223.2328" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "70f7070f4e79db4117892a2c5291d101b84c0710" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
