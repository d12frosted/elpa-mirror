(define-package "evil-textobj-tree-sitter" "20210907.1234" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1")
    (evil "1.0.0")
    (tree-sitter "0.15.0"))
  :commit "069dcd9e30c12f1b19a9d2b3babed4372309767c" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
