(define-package "chronometrist-key-values" "20210615.1056" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "fd8aa226461ff14568ecf847e84d35fd1f846a1b" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
