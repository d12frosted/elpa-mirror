;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot-mode" "20171013.1616"
  "Major mode for editing gnuplot scripts."
  ()
  :url "https://github.com/mkmcc/gnuplot-mode"
  :commit "601f6392986f0cba332c87678d31ae0d0a496ce7"
  :revdesc "601f6392986f"
  :keywords '("gnuplot" "plotting")
  :authors '(("Mike McCourt" . "mkmcc@astro.berkeley.edu"))
  :maintainers '(("Mike McCourt" . "mkmcc@astro.berkeley.edu")))
