(define-package "dwim-shell-command" "20221102.811" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "412f292b0c596f7e626569d6ffd32cc78a4e77b0" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
