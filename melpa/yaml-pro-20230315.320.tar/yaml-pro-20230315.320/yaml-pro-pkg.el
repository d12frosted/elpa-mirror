(define-package "yaml-pro" "20230315.320" "Parser-aided YAML editing features"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "50fc911b9015708b77872dc60c53f4a4740bef1b" :authors
  '(("Zachary Romero"))
  :maintainers
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("tools")
  :url "https://github.com/zkry/yaml-pro")
;; Local Variables:
;; no-byte-compile: t
;; End:
