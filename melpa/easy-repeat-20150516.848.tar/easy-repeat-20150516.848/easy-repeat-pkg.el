;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-repeat" "20150516.848"
  "Repeat easily."
  '((emacs "24.4"))
  :url "https://github.com/xuchunyang/easy-repeat.el"
  :commit "060f0e6801c82c40c06961dc0528a00e18947a8c"
  :revdesc "060f0e6801c8"
  :keywords '("repeat" "convenience")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
