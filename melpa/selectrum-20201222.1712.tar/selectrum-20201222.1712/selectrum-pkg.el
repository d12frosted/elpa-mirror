(define-package "selectrum" "20201222.1712" "Easily select item from list"
  '((emacs "25.1"))
  :commit "2010230286b6aa817a32a479a810bdd7f4858345" :authors
  (("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  ("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  ("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
