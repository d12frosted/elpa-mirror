;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-sage" "20160514.751"
  "An auto-complete source for sage-shell-mode."
  '((auto-complete   "1.5.1")
    (sage-shell-mode "0.1.0"))
  :url "https://github.com/stakemori/auto-complete-sage"
  :commit "51b8e3905196d266e1f8aa47881189833151b398"
  :revdesc "51b8e3905196"
  :keywords '("sage" "math" "auto-complete")
  :authors '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers '(("Sho Takemori" . "stakemorii@gmail.com")))
