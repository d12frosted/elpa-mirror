;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260621.723"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "402d7a3af778e22b87ace6b4489314ceb6202d4f"
  :revdesc "402d7a3af778"
  :keywords '("data" "extensions"))
