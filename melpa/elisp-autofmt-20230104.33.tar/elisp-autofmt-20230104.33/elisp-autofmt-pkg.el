(define-package "elisp-autofmt" "20230104.33" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "b598351891e6dd656dd19b0047ca53aa032a6f14" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
