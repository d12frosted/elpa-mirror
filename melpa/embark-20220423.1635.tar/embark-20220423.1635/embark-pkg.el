(define-package "embark" "20220423.1635" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "cd40fe19c2b06eb0eae0177aaf1946410dd5e69e" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
