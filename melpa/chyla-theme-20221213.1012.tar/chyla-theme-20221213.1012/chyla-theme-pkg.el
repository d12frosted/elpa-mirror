(define-package "chyla-theme" "20221213.1012" "chyla.org - green color theme." 'nil :commit "b24d0379516857ccf75caff9ae1d00b820c9a6f6" :authors
  '(("Adam Chyła" . "adam@chyla.org"))
  :maintainers
  '(("Adam Chyła" . "adam@chyla.org"))
  :maintainer
  '("Adam Chyła" . "adam@chyla.org")
  :url "https://github.com/chyla/ChylaThemeForEmacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
