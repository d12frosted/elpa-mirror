;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arxiv-citation" "20261030.1126"
  "Utility functions for dealing with arXiv papers."
  '((emacs "25.1")
    (dash  "2.19.1")
    (s     "1.12.0"))
  :url "https://gitlab.com/slotThe/arXiv-citation"
  :commit "a55cc92cf61b1f48cc8a97d6ae97f4d612619804"
  :revdesc "a55cc92cf61b"
  :keywords '("convenience")
  :authors '(("Tony Zorman" . "soliditsallgood@mailbox.org"))
  :maintainers '(("Tony Zorman" . "soliditsallgood@mailbox.org")))
