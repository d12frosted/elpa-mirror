(define-package "weather-metno" "20141005.1538" "Weather data from met.no in Emacs"
  '((emacs "24")
    (cl-lib "0.3"))
  :commit "b59680c1ab908b32513954034ba894dfb8564dd8" :authors
  '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.de"))
  :maintainer
  '("Rüdiger Sonderfeld" . "ruediger@c-plusplus.de")
  :keywords
  '("comm")
  :url "https://github.com/ruediger/weather-metno-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
