;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20260818.1234"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "4f44db115e8ab34e4721c0a46d81b902b320477d"
  :revdesc "4f44db115e8a"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
