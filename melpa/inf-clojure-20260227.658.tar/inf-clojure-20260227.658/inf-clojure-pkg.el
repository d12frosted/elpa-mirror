;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-clojure" "20260227.658"
  "Basic interaction with a Clojure REPL."
  '((emacs        "28.1")
    (clojure-mode "5.11"))
  :url "https://github.com/clojure-emacs/inf-clojure"
  :commit "4d3b8fae32caf91e0f9432004bbe861f54ce9c0c"
  :revdesc "4d3b8fae32ca"
  :keywords '("processes" "comint" "clojure")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev")
             ("Olin Shivers" . "shivers@cs.cmu.edu"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
