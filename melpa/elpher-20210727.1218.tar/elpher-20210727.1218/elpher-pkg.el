(define-package "elpher" "20210727.1218" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "3d2817e533e03d2d0eb9e0dd5d573083127bc055" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
