;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vegetative-theme" "20220822.353"
  "A Theme based on green CRT terminals."
  '((autothemer "0.2")
    (emacs      "24"))
  :url "https://github.com/emacsfodder/emacs-theme-vegetative"
  :commit "db60ce0fe327ae7e4371545179ed94483b1132a8"
  :revdesc "db60ce0fe327"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
