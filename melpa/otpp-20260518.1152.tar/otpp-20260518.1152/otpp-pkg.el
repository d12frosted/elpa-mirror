;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260518.1152"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "577181fbf7888c8bcf551d6818505653a19092d5"
  :revdesc "577181fbf788"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
