(define-package "gptel" "20230409.1122" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "3bf44478955d29837b8fcd7832d82226e5dcc1dd" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
