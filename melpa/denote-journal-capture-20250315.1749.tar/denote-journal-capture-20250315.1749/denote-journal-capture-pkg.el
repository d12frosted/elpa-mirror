;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-journal-capture" "20250315.1749"
  "Better Integration for Denote Journal and Org Capture."
  '((emacs          "24.1")
    (denote-journal "0"))
  :url "https://git.sr.ht/~swflint/denote-journal-capture"
  :commit "3c6a22f7ff8d72eae5bba52d6a841c6c89b2458c"
  :revdesc "3c6a22f7ff8d"
  :keywords '("convenience")
  :authors '(("Samuel W. Flint" . "swflint@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "swflint@samuelwflint.com")))
