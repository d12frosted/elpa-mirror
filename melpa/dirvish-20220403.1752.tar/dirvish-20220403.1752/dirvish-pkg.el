(define-package "dirvish" "20220403.1752" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "fdd350baaed8cf4e72dcc124c1eac9cd1113223e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
