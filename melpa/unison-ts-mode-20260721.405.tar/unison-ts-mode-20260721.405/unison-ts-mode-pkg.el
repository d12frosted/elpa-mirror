;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-ts-mode" "20260721.405"
  "Tree-sitter support for Unison."
  '((emacs "29.1"))
  :url "https://github.com/fmguerreiro/unison-ts-mode"
  :commit "00cc3b64854afaec6d4ef38afd28ec06ffaa81ed"
  :revdesc "00cc3b64854a"
  :keywords '("languages" "unison" "tree-sitter")
  :authors '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com"))
  :maintainers '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com")))
