;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "starlit-theme" "20251221.2342"
  "Deep blue dark theme with bright colors from the starlit sky."
  '((emacs "25.1"))
  :url "https://github.com/SFTtech/starlit-emacs"
  :commit "fe825da76006ba92ed5752f3d573c49014ab8107"
  :revdesc "fe825da76006"
  :keywords '("faces")
  :authors '(("Jonas Jelten" . "jj@sft.lol"))
  :maintainers '(("Jonas Jelten" . "jj@sft.lol")))
