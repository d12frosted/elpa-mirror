;;; kanagawa-theme.el --- Elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa -*- lexical-binding: t -*-

;; Copyright (C) 2023 Mikael Konradsson
;; Copyright (C) 2023-2024 Raime Filianore <meritamen@sdf.org>

;; Author: Raime Filianore <meritamen@sdf.org>
;; URL: https://github.com/meritamen/emacs-kanagawa-theme
;; Version: 1.0.0
;; Package-Requires: ((emacs "24.3"))
;; Created: 16 September 2023
;; Keywords: themes faces

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Kanagawa is a theme inspired by the colors of the famous painting
;; The Great Wave off Kanagawa by Katsushika Hokusa.
;; Original theme created by rebelot see: https://github.com/rebelot/kanagawa.nvim

;;; Code:

(unless (>= emacs-major-version 24)
  (error "Requires Emacs 24 or later"))

;;; Customizations:

(defgroup kanagawa-theme nil
  "Kanagawa-theme options."
  :group 'faces)

(defcustom kanagawa-theme-comment-italic t
  "Enable italics for comments and also disable background."
  :type 'boolean
  :group 'kanagawa-theme)

(defcustom kanagawa-theme-keyword-italic t
  "Enable italics for keywords."
  :type 'boolean
  :group 'kanagawa-theme)

(defcustom kanagawa-theme-org-height t
  "Use varying text heights for org headings."
  :type 'boolean
  :group 'kanagawa-theme)

(defcustom kanagawa-theme-org-bold t
  "Inherit text bold for org headings."
  :type 'boolean
  :group 'kanagawa-theme)

(defcustom kanagawa-theme-org-priority-bold t
  "Inherit text bold for priority items in agenda view."
  :type 'boolean
  :group 'kanagawa-theme)

(defcustom kanagawa-theme-org-highlight nil
  "Highlight org headings."
  :type 'boolean
  :group 'kanagawa-theme)

(defcustom kanagawa-theme-underline-parens t
  "If non-nil, underline matching parens when using `show-paren-mode' or similar."
  :type 'boolean
  :group 'kanagawa-theme)

(defcustom kanagawa-theme-custom-colors nil
  "Specify a list of custom colors."
  :type 'alist
  :group 'kanagawa-theme)

(cl-eval-when (compile load eval)
  (defconst kanagawa-dark-palette
    `((fuji-white      "#DCD7BA")
      (old-white       "#C8C093")
      (sumi-ink-0      "#16161D")
      (sumi-ink-1b     "#1f1f28")
      (sumi-ink-1      "#1F1F28")
      (sumi-ink-2      "#2A2A37")
      (sumi-ink-3      "#363646")
      (sumi-ink-4      "#54546D")
      (wave-blue-1     "#223249")
      (wave-blue-2     "#2D4F67")
      (wave-aqua-1     "#6A9589")
      (wave-aqua-2     "#7AA89F")
      (winter-green    "#2B3328")
      (winter-yellow   "#49443C")
      (winter-red      "#43242B")
      (winter-blue     "#252535")
      (autumn-green    "#76946A")
      (autumn-red      "#C34043")
      (autumn-yellow   "#DCA561")
      (samurai-red     "#E82424")
      (ronin-yellow    "#FF9E3B")
      (dragon-blue     "#658594")
      (fuji-gray       "#727169")
      (spring-violet-1 "#938AA9")
      (oni-violet      "#957FB8")
      (crystal-blue    "#7E9CD8")
      (spring-violet-2 "#9CABCA")
      (spring-blue     "#7FB4CA")
      (light-blue      "#A3D4D5")
      (spring-green    "#98BB6C")
      (boat-yellow-1   "#938056")
      (boat-yellow-2   "#C0A36E")
      (carp-yellow     "#E6C384")
      (sakura-pink     "#D27E99")
      (wave-red        "#E46876")
      (peach-red       "#FF5D62")
      (surimi-orange   "#FFA066")
      (katana-gray     "#717C7C")
      (comet           "#54536D"))))

(defmacro kanagawa-theme--faces-spec ()
  "Provide the faces specification."
  '(mapcar
    #'(lambda (entry) (list (car entry) `((t ,@(cdr entry)))))
    `((default                                       (:background ,sumi-ink-1b :foreground ,fuji-white))
      (border                                        (:background ,sumi-ink-1b :foreground ,sumi-ink-0))
      (button                                        (:foreground ,wave-aqua-2))
      (child-frame                                   (:background ,sumi-ink-0 :foreground ,sumi-ink-0))
      (child-frame-border                            (:background ,sumi-ink-0 :foreground ,sumi-ink-0))
      (cursor                                        (:background ,light-blue :foreground ,sumi-ink-0 :weight bold))
      (error                                         (:foreground ,samurai-red))
      (fringe                                        (:foreground ,sumi-ink-3))
      (glyph-face                                    (:background ,sumi-ink-4))
      (glyphless-char                                (:foreground ,sumi-ink-4))
      (header-line                                   (:background ,sumi-ink-0))
      (highlight                                     (:background ,comet :foreground ,spring-violet-1))
      (hl-line                                       (:background ,sumi-ink-2))
      (homoglyph                                     (:foreground ,light-blue))
      (internal-border                               (:background ,sumi-ink-1b))
      (line-number                                   (:foreground ,sumi-ink-4))
      (line-number-current-line                      (:foreground ,spring-violet-2 :background ,sumi-ink-2 :weight bold))
      (lv-separator                                  (:foreground ,wave-blue-2 :background ,sumi-ink-2))
      (match                                         (:background ,carp-yellow :foreground ,sumi-ink-0))
      (menu                                          (:background ,sumi-ink-0 :foreground ,fuji-white))
      (mode-line                                     (:background ,sumi-ink-0))
      (mode-line-inactive                            (:background unspecified :foreground ,sumi-ink-4))
      (mode-line-active                              (:background ,sumi-ink-0 :foreground ,old-white))
      (mode-line-highlight                           (:foreground ,boat-yellow-2))
      (mode-line-buffer-id                           (:foreground ,wave-aqua-2 :weight bold))
      (numbers                                       (:background ,sakura-pink))
      (region                                        (:background ,wave-blue-2))
      (separator-line                                (:background ,sumi-ink-0))
      (shadow                                        (:background ,sumi-ink-0))
      (success                                       (:foreground ,wave-aqua-2))
      (vertical-border                               (:foreground ,sumi-ink-4))
      (warning                                       (:foreground ,ronin-yellow))
      (window-border                                 (:background ,sumi-ink-1b))
      (window-divider                                (:foreground ,sumi-ink-2))
      (hi-yellow                                     (:background ,carp-yellow :foreground ,sumi-ink-1b))

      ; Font lock
      (font-lock-type-face                           (:foreground ,wave-aqua-2))
      (font-lock-regexp-grouping-backslash           (:foreground ,boat-yellow-2))
      (font-lock-keyword-face                        (:foreground ,oni-violet :weight semi-bold :slant ,(if kanagawa-theme-keyword-italic 'italic 'normal)))
      (font-lock-warning-face                        (:foreground ,ronin-yellow))
      (font-lock-string-face                         (:foreground ,spring-green :slant italic))
      (font-lock-builtin-face                        (:foreground ,spring-blue))
      (font-lock-reference-face                      (:foreground ,peach-red))
      (font-lock-constant-face                       (:foreground ,carp-yellow))
      (font-lock-function-name-face                  (:foreground ,crystal-blue))
      (font-lock-variable-name-face                  (:foreground ,wave-red))
      (font-lock-negation-char-face                  (:foreground ,peach-red))
      (font-lock-comment-face                        (:foreground ,fuji-gray :slant ,(if kanagawa-theme-keyword-italic 'italic 'normal)))
      (font-lock-comment-delimiter-face              (:foreground ,fuji-gray :slant ,(if kanagawa-theme-keyword-italic 'italic 'normal)))
      (font-lock-doc-face                            (:foreground ,comet))
      (font-lock-doc-markup-face                     (:foreground ,comet))
      (font-lock-preprocessor-face                   (:foreground ,boat-yellow-2))
      (elisp-shorthand-font-lock-face                (:foreground ,fuji-white))
      (info-xref                                     (:foreground ,carp-yellow))
      (minibuffer-prompt-end                         (:foreground ,autumn-red :background ,winter-red))
      (minibuffer-prompt                             (:foreground ,carp-yellow :background ,winter-yellow))
      (epa-mark                                      (:foreground ,wave-red))
      (dired-mark                                    (:foreground ,wave-red))
      (trailing-whitespace                           (:background ,comet))
      (mode-line                                     (:background ,sumi-ink-0 :foreground ,fuji-white :weight bold))

      ; Battery colors
      (doom-modeline-battery-critical                (:foreground ,peach-red))
      (doom-modeline-battery-warning                 (:foreground ,spring-green))
      (doom-modeline-battery-charging                (:foreground ,fuji-gray))
      (doom-modeline-battery-error                   (:foreground ,peach-red))
      (doom-modeline-battery-normal                  (:foreground ,spring-violet-1))
      (doom-modeline-battery-full                    (:foreground ,wave-aqua-2))

      ; Doom visual state
      (doom-modeline-evil-motion-state               (:foreground ,light-blue))
      (doom-modeline-evil-emacs-state                (:foreground ,crystal-blue))
      (doom-modeline-evil-insert-state               (:foreground ,peach-red))
      (doom-modeline-evil-normal-state               (:foreground ,light-blue))
      (doom-modeline-evil-visual-state               (:foreground ,spring-green))
      (doom-modeline-evil-replace-state              (:foreground ,ronin-yellow))
      (doom-modeline-evil-operator-state             (:foreground ,crystal-blue))

      (doom-modeline-project-dir                     (:weight bold :foreground ,wave-aqua-2))
      (doom-modeline-buffer-path                     (:inherit bold :foreground ,wave-aqua-2))
      (doom-modeline-buffer-file                     (:inherit bold :foreground ,oni-violet))
      (doom-modeline-buffer-modified                 (:inherit bold :foreground ,carp-yellow))
      (doom-modeline-error                           (:background ,peach-red))
      (doom-modeline-buffer-major-mode               (:foreground ,wave-aqua-2 :weight bold))
      (doom-modeline-info                            (:weight bold :foreground ,light-blue))
      (doom-modeline-project-dir                     (:weight bold :foreground ,surimi-orange))
      (doom-modeline-bar                             (:weight bold :background ,spring-violet-1))
      (doom-modeline-panel                           (:inherit bold :background ,boat-yellow-2 :foreground ,sumi-ink-2))
      (doom-themes-visual-bell                       (:background ,autumn-red))

      ; elfeed
      (elfeed-search-feed-face                       (:foreground ,spring-violet-1))
      (elfeed-search-tag-face                        (:foreground ,wave-aqua-2))

      ; message colors
      (message-header-name                           (:foreground ,sumi-ink-4))
      (message-header-other                          (:foreground ,surimi-orange))
      (message-header-subject                        (:foreground ,carp-yellow))
      (message-header-to                             (:foreground ,old-white))
      (message-header-cc                             (:foreground ,wave-aqua-2))
      (message-header-xheader                        (:foreground ,old-white))
      (custom-link                                   (:foreground ,crystal-blue))
      (link                                          (:foreground ,crystal-blue))

      ; org-mode
      (org-done                                      (:foreground ,dragon-blue))
      (org-code                                      (:background ,sumi-ink-0))
      (org-meta-line                                 (:background ,winter-green :foreground ,spring-green))
      (org-block                                     (:background ,sumi-ink-0 :foreground ,sumi-ink-4))
      (org-block-begin-line                          (:background ,winter-blue :foreground ,spring-blue))
      (org-block-end-line                            (:background ,winter-red :foreground ,peach-red))
      (org-headline-done                             (:foreground ,dragon-blue :strike-through t))
      (org-todo                                      (:foreground ,surimi-orange :weight bold))
      (org-headline-todo                             (:foreground ,sumi-ink-2))
      (org-upcoming-deadline                         (:foreground ,peach-red))
      (org-footnote                                  (:foreground ,wave-aqua-2))
      (org-indent                                    (:background ,sumi-ink-1b :foreground ,sumi-ink-1b))
      (org-hide                                      (:background ,sumi-ink-1b :foreground ,sumi-ink-1b))
      (org-date                                      (:foreground ,wave-blue-2))
      (org-ellipsis                                  (:foreground ,wave-blue-2 :weight bold))
      (org-level-1                                   (:inherit bold :foreground ,peach-red :height ,(if kanagawa-theme-org-height 1.3 1.0) :weight ,(if kanagawa-theme-org-bold 'unspecified 'normal)))
      (org-level-2                                   (:inherit bold :foreground ,spring-violet-2 :height ,(if kanagawa-theme-org-height 1.2 1.0) :weight ,(if kanagawa-theme-org-bold 'unspecified 'normal)))
      (org-level-3                                   (:foreground ,boat-yellow-2 :height ,(if kanagawa-theme-org-height 1.1 1.0)))
      (org-level-4                                   (:foreground ,fuji-white))
      (org-level-5                                   (:foreground ,fuji-white))
      (org-level-6                                   (:foreground ,carp-yellow))
      (org-level-7                                   (:foreground ,surimi-orange))
      (org-level-8                                   (:foreground ,spring-green))
      (org-priority                                  (:foreground ,peach-red :inherit bold :weight ,(if kanagawa-theme-org-priority-bold 'unspecified 'normal)))

      ; which-key
      (which-key-key-face                            (:inherit font-lock-variable-name-face))
      (which-func                                    (:inherit font-lock-function-name-face :weight bold))
      (which-key-group-description-face              (:foreground ,wave-red))
      (which-key-command-description-face            (:foreground ,crystal-blue))
      (which-key-local-map-description-face          (:foreground ,carp-yellow))
      (which-key-posframe                            (:background ,wave-blue-1))
      (which-key-posframe-border                     (:background ,wave-blue-1))

      ; swiper
      (swiper-line-face                              (:foreground ,carp-yellow))
      (swiper-background-match-face-1                (:background ,surimi-orange :foreground ,sumi-ink-0))
      (swiper-background-match-face-2                (:background ,crystal-blue :foreground ,sumi-ink-0))
      (swiper-background-match-face-3                (:background ,boat-yellow-2 :foreground ,sumi-ink-0))
      (swiper-background-match-face-4                (:background ,peach-red :foreground ,sumi-ink-0))
      (swiper-match-face-1                           (:inherit swiper-background-match-face-1))
      (swiper-match-face-2                           (:inherit swiper-background-match-face-2))
      (swiper-match-face-3                           (:inherit swiper-background-match-face-3))
      (swiper-match-face-4                           (:inherit swiper-background-match-face-4))

      (counsel-outline-default                       (:foreground ,carp-yellow))
      (info-header-xref                              (:foreground ,carp-yellow))
      (xref-file-header                              (:foreground ,carp-yellow))
      (xref-match                                    (:foreground ,carp-yellow))

      ; rainbow delimiters
      (rainbow-delimiters-mismatched-face            (:foreground ,peach-red))
      (rainbow-delimiters-unmatched-face             (:foreground ,wave-aqua-2))
      (rainbow-delimiters-base-error-face            (:foreground ,peach-red))
      (rainbow-delimiters-base-face                  (:foreground ,sumi-ink-4))

      (rainbow-delimiters-depth-1-face               (:foreground ,spring-violet-2))
      (rainbow-delimiters-depth-2-face               (:foreground ,dragon-blue))
      (rainbow-delimiters-depth-3-face               (:foreground ,spring-violet-1))
      (rainbow-delimiters-depth-4-face               (:foreground ,spring-green))
      (rainbow-delimiters-depth-5-face               (:foreground ,wave-aqua-2))
      (rainbow-delimiters-depth-6-face               (:foreground ,carp-yellow))
      (rainbow-delimiters-depth-7-face               (:foreground ,wave-red))
      (rainbow-delimiters-depth-8-face               (:foreground ,light-blue))
      (rainbow-delimiters-depth-9-face               (:foreground ,spring-violet-2))

      ; show-paren
      (show-paren-match                              (:background ,wave-aqua-1 :foreground ,sumi-ink-0 :weight bold :underline ,(when kanagawa-theme-underline-parens t)))
      (show-paren-match-expression                   (:background ,wave-aqua-1 :foreground ,sumi-ink-0 :weight bold))
      (show-paren-mismatch                           (:background ,peach-red :foreground ,old-white :underline ,(when kanagawa-theme-underline-parens t)))
      (tooltip                                       (:foreground ,sumi-ink-0 :background ,carp-yellow :weight bold))

      ; company-box
      (company-tooltip                               (:background ,sumi-ink-2))
      (company-tooltip-common                        (:foreground ,autumn-yellow))
      (company-tooltip-quick-access                  (:foreground ,spring-violet-2))
      (company-tooltip-scrollbar-thumb               (:background ,autumn-red))
      (company-tooltip-scrollbar-track               (:background ,sumi-ink-2))
      (company-tooltip-search                        (:background ,carp-yellow :foreground ,sumi-ink-0 :distant-foreground ,fuji-white))
      (company-tooltip-selection                     (:background ,peach-red :foreground ,winter-red :weight bold))
      (company-tooltip-mouse                         (:background ,sumi-ink-2 :foreground ,sumi-ink-0 :distant-foreground ,fuji-white))
      (company-tooltip-annotation                    (:foreground ,peach-red :distant-foreground ,sumi-ink-1))
      (company-scrollbar-bg                          (:inherit tooltip))
      (company-scrollbar-fg                          (:background ,peach-red))
      (company-preview                               (:foreground ,carp-yellow))
      (company-preview-common                        (:foreground ,peach-red :weight bold))
      (company-preview-search                        (:inherit company-tooltip-search))
      (company-template-field                        (:inherit match))

      ; flycheck
      (flycheck-posframe-background-face             (:background ,sumi-ink-0))
      (flycheck-posframe-face                        (:background ,sumi-ink-0))
      (flycheck-posframe-info-face                   (:background ,sumi-ink-0 :foreground ,autumn-green))
      (flycheck-posframe-warning-face                (:background ,sumi-ink-0 :foreground ,light-blue))
      (flycheck-posframe-error-face                  (:background ,sumi-ink-0 :foreground ,samurai-red))
      (flycheck-fringe-warning                       (:foreground ,light-blue))
      (flycheck-fringe-error                         (:foreground ,samurai-red))
      (flycheck-fringe-info                          (:foreground ,autumn-green))
      (flycheck-error-list-warning                   (:foreground ,ronin-yellow :weight bold))
      (flycheck-error-list-error                     (:foreground ,samurai-red :weight bold))
      (flycheck-error-list-info                      (:foreground ,wave-aqua-1 :weight bold))
      (flycheck-inline-error                         (:foreground ,samurai-red :background ,winter-red :slant italic :weight bold :height 138))
      (flycheck-inline-info                          (:foreground ,light-blue :background ,winter-blue :slant italic  :weight bold :height 138))
      (flycheck-inline-warning                       (:foreground ,winter-yellow :background ,carp-yellow :slant italic :weight bold :height 138))

      ; indent dots
      (highlight-indent-guides-character-face        (:foreground ,sumi-ink-3))
      (highlight-indent-guides-stack-character-face  (:foreground ,sumi-ink-3))
      (highlight-indent-guides-stack-odd-face        (:foreground ,sumi-ink-3))
      (highlight-indent-guides-stack-even-face       (:foreground ,comet))
      (highlight-indent-guides-stack-character-face  (:foreground ,sumi-ink-3))
      (highlight-indent-guides-even-face             (:foreground ,sumi-ink-2))
      (highlight-indent-guides-odd-face              (:foreground ,comet))

      (highlight-operators-face                      (:foreground ,boat-yellow-2))
      (highlight-quoted-symbol                       (:foreground ,spring-green))
      (highlight-numbers-face                        (:foreground ,sakura-pink))
      (highlight-symbol-face                         (:background ,wave-blue-1 :foreground ,light-blue))

      ; ivy
      (ivy-current-match                             (:background ,crystal-blue :foreground ,sumi-ink-0 :weight bold))
      (ivy-action                                    (:background unspecified :foreground ,fuji-white))
      (ivy-grep-line-number                          (:background unspecified :foreground ,spring-green))
      (ivy-minibuffer-match-face-1                   (:background unspecified :foreground ,wave-red))
      (ivy-minibuffer-match-face-2                   (:background unspecified :foreground ,spring-green))
      (ivy-minibuffer-match-highlight                (:foreground ,light-blue))
      (ivy-grep-info                                 (:foreground ,light-blue))
      (ivy-grep-line-number                          (:foreground ,spring-violet-2))
      (ivy-confirm-face                              (:foreground ,wave-aqua-2))

      ; posframe's
      (ivy-posframe                                  (:background ,sumi-ink-2))
      (ivy-posframe-border                           (:background ,sumi-ink-3))

      ;treemacs
      (treemacs-directory-collapsed-face             (:foreground ,fuji-white))
      (treemacs-directory-face                       (:foreground ,fuji-white))

      (treemacs-file-face                            (:foreground ,fuji-white))

      (treemacs-git-added-face                       (:foreground ,surimi-orange))
      (treemacs-git-renamed-face                     (:foreground ,fuji-white))
      (treemacs-git-ignored-face                     (:foreground ,sumi-ink-4))
      (treemacs-git-unmodified-face                  (:foreground ,fuji-white))
      (treemacs-git-renamed-face                     (:foreground ,fuji-white))
      (treemacs-git-modified-face                    (:foreground ,spring-green))

      ; lsp and lsp-ui
      (lsp-headerline-breadcrumb-path-error-face     (:underline (:color ,spring-green :style wave) :foreground ,sumi-ink-4 :background ,sumi-ink-0))
      (lsp-headerline-breadcrumb-path-face           (:background ,sumi-ink-0))
      (lsp-headerline-breadcrumb-path-hint-face      (:background ,sumi-ink-0))
      (lsp-headerline-breadcrumb-path-info-face      (:background ,sumi-ink-0))
      (lsp-headerline-breadcrumb-separator-face      (:background ,sumi-ink-0))
      (lsp-headerline-breadcrumb-symbols-face        (:background ,sumi-ink-0))
      (lsp-headerline-breadcrumb-project-prefix-face (:background ,sumi-ink-0))
      (lsp-headerline-breadcrumb-symbols-error-face  (:foreground ,peach-red))

      (lsp-ui-doc-background                         (:background ,sumi-ink-0 :foreground ,peach-red))
      (lsp-ui-doc-header                             (:background ,sumi-ink-0 :foreground ,peach-red))
      (lsp-ui-doc-border                             (:background unspecified :foreground unspecified))
      (lsp-ui-peek-filename                          (:foreground ,light-blue))
      (lsp-ui-sideline-code-action                   (:foreground ,carp-yellow))
      (lsp-ui-sideline-current-symbol                (:foreground ,spring-blue))
      (lsp-ui-sideline-symbol                        (:foreground ,dragon-blue))

      ; dashboard
      (dashboard-heading                             (:foreground ,spring-violet-2 :weight bold))
      (dashboard-items-face                          (:bold unspecified :foreground ,fuji-white))
      (dashboard-banner-logo-title                   (:weight bold :height 200))
      (dashboard-no-items-face                       (:foreground ,sumi-ink-4))

      ; all-the-icons
      (all-the-icons-dgreen                          (:foreground ,wave-aqua-2))
      (all-the-icons-green                           (:foreground ,wave-aqua-2))
      (all-the-icons-dpurple                         (:foreground ,spring-violet-2))
      (all-the-icons-purple                          (:foreground ,spring-violet-2))

      ; evil
      (evil-ex-lazy-highlight                        (:foreground ,winter-green :background ,autumn-green :weight bold))
      (evil-ex-substitute-matches                    (:foreground ,winter-red :background ,autumn-red :weight bold))
      (evil-ex-substitute-replacement                (:foreground ,surimi-orange :strike-through unspecified :inherit evil-ex-substitute-matches))
      (evil-search-highlight-persist-highlight-face  (:background ,carp-yellow))

      ; term
      (term                                          (:background ,sumi-ink-0 :foreground ,fuji-white))
      (term-color-blue                               (:background ,crystal-blue :foreground ,crystal-blue))
      (term-color-bright-blue                        (:inherit term-color-blue))
      (term-color-green                              (:background ,wave-aqua-2 :foreground ,wave-aqua-2))
      (term-color-bright-green                       (:inherit term-color-green))
      (term-color-black                              (:background ,sumi-ink-0 :foreground ,fuji-white))
      (term-color-bright-black                       (:background ,sumi-ink-1b :foreground ,sumi-ink-1b))
      (term-color-white                              (:background ,fuji-white :foreground ,fuji-white))
      (term-color-bright-white                       (:background ,old-white :foreground ,old-white))
      (term-color-red                                (:background ,peach-red :foreground ,peach-red))
      (term-color-bright-red                         (:background ,spring-green :foreground ,spring-green))
      (term-color-yellow                             (:background ,carp-yellow :foreground ,carp-yellow))
      (term-color-bright-yellow                      (:background ,carp-yellow :foreground ,carp-yellow))
      (term-color-cyan                               (:background ,spring-blue :foreground ,spring-blue))
      (term-color-bright-cyan                        (:background ,spring-blue :foreground ,spring-blue))
      (term-color-magenta                            (:background ,spring-violet-2 :foreground ,spring-violet-2))
      (term-color-bright-magenta                     (:background ,spring-violet-2 :foreground ,spring-violet-2))

      ; popup
      (popup-face                                    (:inherit tooltip))
      (popup-selection-face                          (:inherit tooltip))
      (popup-tip-face                                (:inherit tooltip))

      ; anzu
      (anzu-match-1                                  (:foreground ,wave-aqua-2 :background ,sumi-ink-2))
      (anzu-match-2                                  (:foreground ,carp-yellow :background ,sumi-ink-2))
      (anzu-match-3                                  (:foreground ,light-blue :background ,sumi-ink-2))

      (anzu-mode-line                                (:foreground ,sumi-ink-0 :background ,spring-violet-2))
      (anzu-mode-no-match                            (:foreground ,fuji-white :background ,peach-red))
      (anzu-replace-to                               (:foreground ,spring-blue :background ,winter-blue))
      (anzu-replace-highlight                        (:foreground ,peach-red :background ,winter-red :strike-through t))

      ; ace
      (ace-jump-face-background                      (:foreground ,wave-blue-2))
      (ace-jump-face-foreground                      (:foreground ,peach-red :background ,sumi-ink-0 :weight bold))

      ; vertico
      (vertico-multiline                             (:background ,samurai-red))
      (vertico-group-title                           (:background ,winter-blue :foreground ,light-blue :weight bold))
      (vertico-group-separator                       (:background ,winter-blue :foreground ,light-blue :strike-through t))
      (vertico-current                               (:foreground ,carp-yellow :weight bold :slant italic :background ,wave-blue-1))

      (vertico-posframe-border                       (:background ,sumi-ink-3))
      (vertico-posframe                              (:background ,sumi-ink-2))
      (orderless-match-face-0                        (:foreground ,crystal-blue :weight bold))

      (comint-highlight-prompt                       (:background ,spring-violet-2 :foreground ,sumi-ink-1))
      (completions-annotations                       (:background unspecified :foreground ,dragon-blue :slant italic))
      (marginalia-file-priv-no                       (:background unspecified))

      ; hydra
      (hydra-face-amaranth                           (:foreground ,autumn-red))
      (hydra-face-blue                               (:foreground ,spring-blue))
      (hydra-face-pink                               (:foreground ,sakura-pink))
      (hydra-face-red                                (:foreground ,peach-red))
      (hydra-face-teal                               (:foreground ,light-blue))

      ; tab-bar
      (tab-bar                                       (:background ,sumi-ink-1b))
      (tab-bar-tab-inactive                          (:foreground ,sumi-ink-4 :background ,sumi-ink-1b))

      ; centaur-tabs
      (centaur-tabs-active-bar-face                  (:background ,spring-blue :foreground ,fuji-white))
      (centaur-tabs-selected                         (:background ,sumi-ink-1b :foreground ,fuji-white :weight bold))
      (centaur-tabs-selected-modified                (:background ,sumi-ink-1b :foreground ,fuji-white))
      (centaur-tabs-modified-marker-selected         (:background ,sumi-ink-1b :foreground ,autumn-yellow))
      (centaur-tabs-close-selected                   (:inherit centaur-tabs-selected))
      (tab-line                                      (:background ,sumi-ink-0))

      (centaur-tabs-unselected                       (:background ,sumi-ink-0 :foreground ,sumi-ink-4))
      (centaur-tabs-default                          (:background ,sumi-ink-0 :foreground ,sumi-ink-4))
      (centaur-tabs-unselected-modified              (:background ,sumi-ink-0 :foreground ,peach-red))
      (centaur-tabs-modified-marker-unselected       (:background ,sumi-ink-0 :foreground ,sumi-ink-4))
      (centaur-tabs-close-unselected                 (:background ,sumi-ink-0 :foreground ,sumi-ink-4))

      (centaur-tabs-close-mouse-face                 (:background unspecified :foreground ,peach-red))
      (centaur-tabs-default                          (:background ,ronin-yellow ))
      (centaur-tabs-name-mouse-face                  (:foreground ,spring-blue :weight bold))

      (git-gutter:added                              (:foreground ,autumn-green))
      (git-gutter:deleted                            (:foreground ,wave-red))
      (git-gutter:modified                           (:foreground ,spring-blue))

      (diff-hl-margin-change                         (:foreground ,spring-blue :background ,winter-blue))
      (diff-hl-margin-delete                         (:foreground ,peach-red :background ,winter-red))
      (diff-hl-margin-insert                         (:foreground ,comet :background ,winter-blue))

      (bm-fringe-face                                (:background ,peach-red :foreground ,sumi-ink-3))
      (bm-fringe-persistent-face                     (:background ,peach-red :foreground ,sumi-ink-3))

      (ansi-color-green                              (:foreground ,spring-green))
      (ansi-color-black                              (:background ,sumi-ink-0))
      (ansi-color-cyan                               (:foreground ,wave-aqua-2))
      (ansi-color-magenta                            (:foreground ,sakura-pink))
      (ansi-color-blue                               (:foreground ,crystal-blue))
      (ansi-color-red                                (:foreground ,peach-red))
      (ansi-color-white                              (:foreground ,fuji-white))
      (ansi-color-yellow                             (:foreground ,autumn-yellow))
      (ansi-color-bright-white                       (:foreground ,old-white))
      (ansi-color-bright-white                       (:foreground ,old-white))

      (tree-sitter-hl-face:attribute                 (:foreground ,surimi-orange))
      (tree-sitter-hl-face:escape                    (:foreground ,wave-red))
      (tree-sitter-hl-face:constructor               (:foreground ,wave-red :weight semi-bold))

      (tree-sitter-hl-face:constant                  (:foreground ,surimi-orange))
      (tree-sitter-hl-face:constant.builtin          (:foreground ,carp-yellow :weight semi-bold))

      (tree-sitter-hl-face:embedded                  (:foreground ,boat-yellow-2))


      (tree-sitter-hl-face:function.builtin          (:foreground ,peach-red :slant italic :background ,winter-red))
      (tree-sitter-hl-face:function.call             (:foreground ,spring-violet-2))
      (tree-sitter-hl-face:function.macro            (:foreground ,samurai-red))
      (tree-sitter-hl-face:function.special          (:foreground ,sakura-pink))
      (tree-sitter-hl-face:function.label            (:foreground ,surimi-orange))

      (tree-sitter-hl-face:method                    (:foreground ,light-blue))
      (tree-sitter-hl-face:method.call               (:foreground ,light-blue))

      (tree-sitter-hl-face:property                  (:foreground ,carp-yellow))
      (tree-sitter-hl-face:property.definition       (:foreground ,old-white :slant italic))

      (tree-sitter-hl-face:tag                       (:foreground ,peach-red))

      (tree-sitter-hl-face:type                      (:foreground ,wave-aqua-2 :weight semi-bold))
      (tree-sitter-hl-face:type.argument             (:foreground ,surimi-orange))
      (tree-sitter-hl-face:type.builtin              (:foreground ,autumn-red))
      (tree-sitter-hl-face:type.parameter            (:foreground ,surimi-orange))
      (tree-sitter-hl-face:type.super                (:foreground ,samurai-red :weight bold))

      (tree-sitter-hl-face:variable                  (:foreground ,spring-blue :slant italic))
      (tree-sitter-hl-face:variable.builtin          (:foreground ,wave-red))
      (tree-sitter-hl-face:variable.parameter        (:foreground ,spring-violet-2 :slant italic))
      (tree-sitter-hl-face:variable.special          (:foreground ,surimi-orange))
      (tree-sitter-hl-face:variable.synthesized      (:foreground ,light-blue))

      (tree-sitter-hl-face:number                    (:foreground ,sakura-pink))
      (tree-sitter-hl-face:operator                  (:foreground ,sakura-pink :weight bold))

      (tree-sitter-hl-face:punctuation               (:foreground ,light-blue))
      (tree-sitter-hl-face:punctuation.bracket       (:foreground ,spring-violet-2 :slant italic))
      (tree-sitter-hl-face:punctuation.delimiter     (:foreground ,spring-violet-2 :slant italic))
      (tree-sitter-hl-face:punctuation.special       (:foreground ,peach-red))

      (tree-sitter-hl-face:case-pattern              (:foreground ,wave-red))
      (tree-sitter-hl-face:variable.synthesized      (:foreground ,wave-red))
      (tree-sitter-hl-face:keyword.compiler          (:foreground ,peach-red :slant italic))

      (focus-unfocused                               (:foreground ,sumi-ink-4)))))

(defmacro define-kanagawa-theme ()
  "Define kanagawa theme."
  `(let ,kanagawa-dark-palette
     (cl-loop for (cvar . val) in kanagawa-theme-custom-colors
              do (set cvar val))
     (deftheme kanagawa "Elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa.")
     (apply 'custom-theme-set-faces 'kanagawa (kanagawa-theme--faces-spec))))

(define-kanagawa-theme)
 
;;;###autoload
(and load-file-name
     (boundp 'custom-theme-load-path)
     (add-to-list 'custom-theme-load-path
                  (file-name-as-directory
                   (file-name-directory load-file-name))))

(provide-theme 'kanagawa)
;;; kanagawa-theme.el ends here
