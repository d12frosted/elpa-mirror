(define-package "kanagawa-theme" "20240524.618" "Elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa"
  '((emacs "24.3"))
  :commit "55b6c7087a4d71612889261a5ada65ed9a6d98b6" :authors
  '(("Raime Filianore" . "meritamen@sdf.org"))
  :maintainers
  '(("Raime Filianore" . "meritamen@sdf.org"))
  :maintainer
  '("Raime Filianore" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/meritamen/emacs-kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
