;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20250216.951"
  "Copilot chat interface."
  '((request       "0.3.2")
    (markdown-mode "2.6")
    (emacs         "27.1")
    (magit         "4.0.0")
    (transient     "0.8.3")
    (org           "9.4.6")
    (polymode      "0.2.2")
    (shell-maker   "0.76.2"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "54cea8a4878df4045de8c9ebb44f1cc972931898"
  :revdesc "54cea8a4878d"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
