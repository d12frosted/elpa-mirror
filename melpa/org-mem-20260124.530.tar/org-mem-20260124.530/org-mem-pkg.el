;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260124.530"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.6.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "1ed384d55945518d3ac898df83b8bf3f78fc689d"
  :revdesc "1ed384d55945"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
