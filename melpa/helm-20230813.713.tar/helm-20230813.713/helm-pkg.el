(define-package "helm" "20230813.713" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.3")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "be0b88584b26cdff4ff508b002d3abd57955a779" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
