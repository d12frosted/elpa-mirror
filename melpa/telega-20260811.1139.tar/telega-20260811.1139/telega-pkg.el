;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260811.1139"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "97406c7aab68dabb7d72a3394f7bbfa0470fbd8b"
  :revdesc "97406c7aab68"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
