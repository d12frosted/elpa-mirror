(define-package "term-manager" "20160922.2002" "Contextual terminal management"
  '((dash "2.12.0")
    (emacs "24.4"))
  :commit "0bca2e7e3b6e906ec67696bc0be952988ca7f733" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("term" "manager")
  :url "https://www.github.com/IvanMalison/term-manager")
;; Local Variables:
;; no-byte-compile: t
;; End:
