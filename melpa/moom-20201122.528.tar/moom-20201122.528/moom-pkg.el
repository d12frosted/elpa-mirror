(define-package "moom" "20201122.528" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "56a6a11b612aa295ef250e5a9879dc5df3b3234d" :authors
  (("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  ("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  ("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
