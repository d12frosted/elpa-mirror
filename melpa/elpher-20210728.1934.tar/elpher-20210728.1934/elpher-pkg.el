(define-package "elpher" "20210728.1934" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "8c20802c5f2262440dadbdca60b7901d09ca022f" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
