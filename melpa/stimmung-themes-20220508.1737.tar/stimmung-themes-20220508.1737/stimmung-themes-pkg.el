(define-package "stimmung-themes" "20220508.1737" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "d03558c2aeac781c65c4137839362790f8b36b3d" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
