;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynamic-graphs" "20250701.853"
  "Manipulation with graphviz graphs."
  '((emacs "26.1"))
  :url "https://github.com/zellerin/dynamic-graphs"
  :commit "5aa3182174de28b6c034a43cd9ef2f26024911b1"
  :revdesc "5aa3182174de"
  :keywords '("tools")
  :authors '(("Tomas Zellerin" . "tomas@zellerin.cz"))
  :maintainers '(("Tomas Zellerin" . "tomas@zellerin.cz")))
