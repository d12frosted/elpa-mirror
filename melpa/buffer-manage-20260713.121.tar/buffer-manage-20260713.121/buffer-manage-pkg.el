;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-manage" "20260713.121"
  "Manage buffers."
  '((emacs          "26.1")
    (choice-program "0.16.0")
    (dash           "2.17.0"))
  :url "https://github.com/plandes/buffer-manage"
  :commit "f32c756a261aebca0a864e41958097b30690e171"
  :revdesc "f32c756a261a"
  :keywords '("internal" "maint"))
