(define-package "kakoune" "20201111.2159" "A simulation, but not emulation, of kakoune"
  '((ryo-modal "0.4")
    (multiple-cursors "1.4")
    (expand-region "0.11.0")
    (emacs "25.1"))
  :commit "fa27e48b49d42ed6d8b4492d7c734b0f1e647fc1" :authors
  (("Joseph Morag" . "jm4157@columbia.edu"))
  :maintainer
  ("Joseph Morag" . "jm4157@columbia.edu")
  :url "https://github.com/jmorag/kakoune.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
