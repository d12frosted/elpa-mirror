;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250426.805"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "cd391cfe01924962e398eeff9c90ce8ede1b3709"
  :revdesc "cd391cfe0192"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
