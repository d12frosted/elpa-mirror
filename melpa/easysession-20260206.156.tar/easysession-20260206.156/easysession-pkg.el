;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260206.156"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "7595cf425a7131fa2be7bc149c13f6106b5dfe95"
  :revdesc "7595cf425a71"
  :keywords '("convenience"))
