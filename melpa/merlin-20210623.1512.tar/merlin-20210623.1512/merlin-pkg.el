(define-package "merlin" "20210623.1512" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "1ad8f53b37e637c288b73d69746d7e4c051033d0" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
