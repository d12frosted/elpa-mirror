(define-package "merlin" "20210623.1512" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "d2b1a0fcb78f214472ffba1eec6ce17dadba2e8b" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
