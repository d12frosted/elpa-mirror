(define-package "merlin" "20210623.1512" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "8a3704628a35deb6b1b41e819f2a148361bbe936" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
