;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251027.637"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "fa87499f2d1a025b3188c64e361805b15170a5d3"
  :revdesc "fa87499f2d1a"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
