;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ext" "20241205.1610"
  "SystemVerilog Extensions."
  '((emacs           "29.1")
    (verilog-mode    "2024.3.1.121933719")
    (verilog-ts-mode "0.3.0")
    (lsp-mode        "8.0.0")
    (ag              "0.48")
    (ripgrep         "0.4.0")
    (hydra           "0.15.0")
    (apheleia        "3.1")
    (yasnippet       "0.14.0")
    (flycheck        "32")
    (outshine        "3.0.1")
    (async           "1.9.7"))
  :url "https://github.com/gmlarumbe/verilog-ext"
  :commit "f7e70560d817125721aa7e02a2f527fce15bcf30"
  :revdesc "f7e70560d817"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
