(define-package "simplenote2" "20161130.1409" "Interact with simple-note.appspot.com"
  '((request-deferred "0.2.0"))
  :commit "070aa311b0a08b530394c53d0c52c6438efbc20c" :authors
  '(("alpha22jp" . "alpha22jp@gmail.com"))
  :maintainer
  '("alpha22jp" . "alpha22jp@gmail.com")
  :keywords
  '("simplenote"))
;; Local Variables:
;; no-byte-compile: t
;; End:
