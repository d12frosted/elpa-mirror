(define-package "dirvish" "20220523.1338" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "68e562200853dc76a748d3820cf599aaa7fd8eed" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
