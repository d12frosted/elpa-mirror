(define-package "jtsx" "20231207.1049" "Extends default support for JSX/TSX"
  '((emacs "29.1"))
  :commit "2c86735bc9616edcca98bcd30fee9a4b4b0f7285" :authors
  '(("Loïc Lemaître" . "loic.lemaitre@gmail.com"))
  :maintainers
  '(("Loïc Lemaître" . "loic.lemaitre@gmail.com"))
  :maintainer
  '("Loïc Lemaître" . "loic.lemaitre@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/llemaitre19/jtsx")
;; Local Variables:
;; no-byte-compile: t
;; End:
