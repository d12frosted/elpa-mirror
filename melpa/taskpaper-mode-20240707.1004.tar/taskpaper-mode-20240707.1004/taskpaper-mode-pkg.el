(define-package "taskpaper-mode" "20240707.1004" "Major mode for working with TaskPaper files"
  '((emacs "25.1"))
  :commit "a4147a13c57580cef842693534043e1416f4c22b" :authors
  '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainers
  '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainer
  '("Dmitry Safronov" . "saf.dmitry@gmail.com")
  :keywords
  '("outlines" "notetaking" "task management" "productivity" "taskpaper")
  :url "https://github.com/saf-dmitry/taskpaper-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
