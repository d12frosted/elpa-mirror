;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260616.1111"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.8.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "b197c1695b7cd887dd72b2aab8ff575be68cd5d3"
  :revdesc "b197c1695b7c"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
