(define-package "gpt" "20221202.2343" "Run instruction-following language models"
  '((emacs "24.1"))
  :commit "fc662ffbc826e4aa7526d805d6024d218ceaef93" :authors
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainer
  '("Andreas Stuhlmueller" . "andreas@ought.org")
  :keywords
  '("gpt3" "language" "copilot" "convenience" "tools")
  :url "https://github.com/stuhlmueller/gpt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
