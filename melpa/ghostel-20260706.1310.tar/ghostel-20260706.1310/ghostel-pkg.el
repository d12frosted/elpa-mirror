;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260706.1310"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "eb806d158df4ff302aee68e91caf257f11d66320"
  :revdesc "eb806d158df4"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
