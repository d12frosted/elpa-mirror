(define-package "emacsql" "20220917.1646" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "9e48d12e4295abcda3f5baff5219f116b2224e5d" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
