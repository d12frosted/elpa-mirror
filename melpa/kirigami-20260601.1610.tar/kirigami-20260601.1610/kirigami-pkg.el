;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260601.1610"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "7e175bd5f7e9a54c72900a33d1bbba9433ad214a"
  :revdesc "7e175bd5f7e9"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
