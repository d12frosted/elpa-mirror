(define-package "etable" "20161028.2009" "Implementation of javax.swing.JTable for Emacs."
  '((dash "2.9.0")
    (interval-list "0.1")
    (emacs "24.4"))
  :commit "d502141f0c69bf95256ba5cb9cd15350c7e942d2")
;; Local Variables:
;; no-byte-compile: t
;; End:
