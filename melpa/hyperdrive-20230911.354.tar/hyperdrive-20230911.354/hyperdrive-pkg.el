(define-package "hyperdrive" "20230911.354" "P2P filesystem"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5"))
  :commit "61e0c7817c422160ca81e3c650591f36829d550b" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
