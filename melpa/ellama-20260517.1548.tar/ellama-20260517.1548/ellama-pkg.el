;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260517.1548"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.30.2")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "d6e7603f0218ec4e089e2957da1dd31d1d39ec5c"
  :revdesc "d6e7603f0218"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
