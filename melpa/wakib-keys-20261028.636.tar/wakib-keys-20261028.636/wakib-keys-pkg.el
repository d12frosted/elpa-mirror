;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wakib-keys" "20261028.636"
  "Minor Mode for Modern Keybindings."
  '((emacs "27.1"))
  :url "https://github.com/darkstego/wakib-keys/"
  :commit "846c71f30f766b7798ec26f4e5349a7c38d2eaae"
  :revdesc "846c71f30f76"
  :keywords '("convenience" "keybindings" "keys"))
