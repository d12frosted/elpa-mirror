(define-package "call-graph" "20220214.1251" "Library to generate call graph for c/c++ functions"
  '((emacs "25.1")
    (cl-lib "0.6.1")
    (hierarchy "0.7.0")
    (tree-mode "1.0.0")
    (ivy "0.10.0")
    (anaconda-mode "0.1.13")
    (beacon "1.3.3"))
  :commit "aa5ffb15cec39920012aa526e932d48e5c74bbb0" :authors
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainer
  '("Huming Chen" . "chenhuming@gmail.com")
  :keywords
  '("programming" "convenience")
  :url "https://github.com/beacoder/call-graph")
;; Local Variables:
;; no-byte-compile: t
;; End:
