;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260205.838"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "81736bbe5b4dcf7939633b976fa58198e46ba638"
  :revdesc "81736bbe5b4d"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
