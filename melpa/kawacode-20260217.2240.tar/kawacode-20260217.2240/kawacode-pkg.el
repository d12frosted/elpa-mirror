;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kawacode" "20260217.2240"
  "Kawa Code collaboration package."
  '((emacs "27.1"))
  :url "https://github.com/codeawareness/kawa.emacs"
  :commit "713cb959fe82bbc7ca6d96cce7d5779e74f7839c"
  :revdesc "713cb959fe82"
  :keywords '("tools" "convenience" "vc")
  :authors '(("Mark Vasile" . "mark@codeawareness.com"))
  :maintainers '(("Mark Vasile" . "mark@codeawareness.com")))
