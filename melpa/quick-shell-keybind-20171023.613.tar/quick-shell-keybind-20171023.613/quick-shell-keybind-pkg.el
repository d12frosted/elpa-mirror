(define-package "quick-shell-keybind" "20171023.613" "Interactively bind a key to shell commands"
  '((emacs "24"))
  :commit "5f4541a5a5554d108bf16b5fd1713e962161ca1b" :authors
  '(("eyeinsky" . "eyeinsky9@gmail.com"))
  :maintainers
  '(("eyeinsky" . "eyeinsky9@gmail.com"))
  :maintainer
  '("eyeinsky" . "eyeinsky9@gmail.com")
  :keywords
  '("maint" "convenience" "processes")
  :url "https://github.com/eyeinsky/quick-shell-keybind")
;; Local Variables:
;; no-byte-compile: t
;; End:
