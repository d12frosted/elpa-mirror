(define-package "archive-rpm" "20220527.632" "RPM and CPIO support for archive-mode"
  '((emacs "24.4"))
  :commit "cb48fee04cb0cbb26f760a3b95649f7dac78c6ec" :authors
  '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainer
  '("Magnus Henoch" . "magnus.henoch@gmail.com")
  :keywords
  '("files"))
;; Local Variables:
;; no-byte-compile: t
;; End:
