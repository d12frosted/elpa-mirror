;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ytdl" "20241025.1913"
  "Emacs Interface for youtube-dl."
  '((emacs     "26.1")
    (async     "1.9.4")
    (transient "0.2.0")
    (dash      "2.17.0"))
  :url "https://gitlab.com/tuedachu/ytdl"
  :commit "309ad5ce95368ad2e35d1c1701a1f3c0043415a3"
  :revdesc "309ad5ce9536"
  :keywords '("comm" "multimedia")
  :authors '(("Arnaud Hoffmann" . "tuedachu@gmail.com"))
  :maintainers '(("Arnaud Hoffmann" . "tuedachu@gmail.com")))
