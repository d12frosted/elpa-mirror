;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250525.1451"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "e9f37469253dd3a657514d04ba2f0df5b6805810"
  :revdesc "e9f37469253d"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
