;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20260902.1430"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "90712c571f21ccf024b7eb6dcb9ccb5bffbad073"
  :revdesc "90712c571f21"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
