(define-package "vlf" "20170830.1848" "View Large Files" 'nil :commit "a01e9ed416cd81ccddebebbf05d4ca80060b07dc" :maintainer
  '("Andrey Kotlarski" . "m00naticus@gmail.com")
  :keywords
  '("large files" "utilities")
  :url "https://github.com/m00natic/vlfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
