;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260224.209"
  "Efficiently de-dup file-names."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "7221e53aaed2526417de06aa9241b1168595d35e"
  :revdesc "7221e53aaed2"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
