;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20250218.2320"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.8.0"))
  :url "https://github.com/aurtzy/disproject"
  :commit "9967ebddb863cf7e72e252b57f2c8a8472bad96c"
  :revdesc "9967ebddb863"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
