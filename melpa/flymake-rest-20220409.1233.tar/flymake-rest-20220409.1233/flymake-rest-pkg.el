(define-package "flymake-rest" "20220409.1233" "Core features for flymake"
  '((emacs "28.1")
    (let-alist "1.0")
    (flymake "1.2.1"))
  :commit "4b7051222b64650e2ec8c8340fdbe792138ede83" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("language" "tools")
  :url "https://github.com/mohkale/flymake-rest")
;; Local Variables:
;; no-byte-compile: t
;; End:
