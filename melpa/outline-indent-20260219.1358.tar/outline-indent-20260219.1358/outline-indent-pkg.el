;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260219.1358"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "91d6d1c7a15f1c1a9575870ef2f564ad3f053589"
  :revdesc "91d6d1c7a15f"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
