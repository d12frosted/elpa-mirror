;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "20260113.1505"
  "Compiler explorer client (godbolt.org)."
  '((emacs "28.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "79a4c4be96a3210ccc85d2e7f1acbc1a4bcf86d5"
  :revdesc "79a4c4be96a3"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
