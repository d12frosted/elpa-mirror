(define-package "tempel-collection" "20230227.1536" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "6491da4588690ce229014de7f1de6edd5b9fa14d" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
