(define-package "fingers" "20160817.829" "Modal editing with universal text manipulation helpers." 'nil :commit "7de351448a6f5ea7aa7a25db6c90d5138f87eb16" :authors
  '(("Felix Geller" . "fgeller@gmail.com"))
  :maintainer
  '("Felix Geller" . "fgeller@gmail.com")
  :keywords
  '("fingers" "modal" "editing" "workman")
  :url "http://github.com/fgeller/fingers.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
