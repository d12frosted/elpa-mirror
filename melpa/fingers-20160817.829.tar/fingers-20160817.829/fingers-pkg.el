(define-package "fingers" "20160817.829" "Modal editing with universal text manipulation helpers." 'nil :commit "fed0f742afb1d72eaef29d8da394467550a030fa" :keywords
  ("fingers" "modal" "editing" "workman")
  :authors
  (("Felix Geller" . "fgeller@gmail.com"))
  :maintainer
  ("Felix Geller" . "fgeller@gmail.com")
  :url "http://github.com/fgeller/fingers.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
