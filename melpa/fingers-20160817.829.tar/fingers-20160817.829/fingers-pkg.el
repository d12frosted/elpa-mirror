;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fingers" "20160817.829"
  "Modal editing with universal text manipulation helpers."
  ()
  :url "https://github.com/fgeller/fingers.el"
  :commit "7de351448a6f5ea7aa7a25db6c90d5138f87eb16"
  :revdesc "7de351448a6f"
  :keywords '("fingers" "modal" "editing" "workman")
  :authors '(("Felix Geller" . "fgeller@gmail.com"))
  :maintainers '(("Felix Geller" . "fgeller@gmail.com")))
