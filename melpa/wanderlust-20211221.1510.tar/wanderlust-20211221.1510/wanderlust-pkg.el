(define-package "wanderlust" "20211221.1510" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "08bb4449582515655a6acb36917624f69813b138")
;; Local Variables:
;; no-byte-compile: t
;; End:
