(define-package "elcord" "20210316.107" "Allows you to integrate Rich Presence from Discord"
  '((emacs "25.1"))
  :commit "dc6896b819d6e7fa26fab1068864b77936886856" :authors
  '(("heatingdevice")
    ("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com"))
  :maintainer
  '("heatingdevice")
  :keywords
  '("games")
  :url "https://github.com/Mstrodl/elcord")
;; Local Variables:
;; no-byte-compile: t
;; End:
