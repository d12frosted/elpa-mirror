(define-package "racket-mode" "20220118.1424" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "e9b40d2902e2fe7a46757a4fc64c780a18c94169" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
