;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "numeri" "20260304.2239"
  "Roman Numeral Conversion Library."
  '((emacs "29.1"))
  :url "https://github.com/kickingvegas/numeri"
  :commit "a6a7c0ab050e6bda191372792572096d3fe33134"
  :revdesc "a6a7c0ab050e"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
