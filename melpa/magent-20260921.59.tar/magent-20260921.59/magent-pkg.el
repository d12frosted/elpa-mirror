;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magent" "20260921.59"
  "AI coding agent."
  '((emacs       "29.1")
    (gptel       "0.9.8")
    (yaml        "1.0.0")
    (compat      "30.1.0.0")
    (acp         "0.13.1")
    (agent-shell "0.66.1"))
  :url "https://github.com/jamie-cui/magent"
  :commit "1846b20134164a5831a076ddbb0b0c9399f8c80d"
  :revdesc "1846b2013416"
  :keywords '("tools" "ai" "copilot")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
