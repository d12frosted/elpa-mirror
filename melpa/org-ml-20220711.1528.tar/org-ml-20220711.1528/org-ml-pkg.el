(define-package "org-ml" "20220711.1528" "Functional Org Mode API"
  '((emacs "27.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "385e3bee497f858705144d7ab5e6570d31d3ffe8" :authors
  '(("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  '("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :keywords
  '("org-mode" "outlines")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
