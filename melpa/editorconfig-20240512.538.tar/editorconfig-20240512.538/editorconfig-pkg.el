(define-package "editorconfig" "20240512.538" "EditorConfig Emacs Plugin"
  '((emacs "26.1")
    (nadvice "0.3"))
  :commit "d882f00a1fc7c6bff1dde376c116f8f519e40439" :authors
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainers
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainer
  '("EditorConfig Team" . "editorconfig@googlegroups.com")
  :keywords
  '("convenience" "editorconfig")
  :url "https://github.com/editorconfig/editorconfig-emacs#readme")
;; Local Variables:
;; no-byte-compile: t
;; End:
