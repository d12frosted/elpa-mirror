(define-package "dap-mode" "20220514.1535" "Debug Adapter Protocol mode"
  '((emacs "26.1")
    (dash "2.18.0")
    (lsp-mode "6.0")
    (bui "1.1.0")
    (f "0.20.0")
    (s "1.12.0")
    (lsp-treemacs "0.1")
    (posframe "0.7.0")
    (ht "2.3"))
  :commit "98190a310c2385716a6d4a1c1f65d7132f8cfd96" :authors
  '(("Ivan Yonchovski" . "yyoncho@gmail.com"))
  :maintainer
  '("Ivan Yonchovski" . "yyoncho@gmail.com")
  :keywords
  '("languages" "debug")
  :url "https://github.com/emacs-lsp/dap-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
