(define-package "nerd-icons-corfu" "20231015.1731" "Icons for Corfu via nerd-icons"
  '((emacs "27.1")
    (nerd-icons "0.1.0"))
  :commit "cbc14c73032ebe1b2043757221d198ff6be1b670" :authors
  '(("Luigi Sartor Piucco" . "luigipiucco@gmail.com"))
  :maintainers
  '(("Luigi Sartor Piucco" . "luigipiucco@gmail.com"))
  :maintainer
  '("Luigi Sartor Piucco" . "luigipiucco@gmail.com")
  :keywords
  '("convenience" "files" "icons")
  :url "https://github.com/LuigiPiucco/nerd-icons-corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
