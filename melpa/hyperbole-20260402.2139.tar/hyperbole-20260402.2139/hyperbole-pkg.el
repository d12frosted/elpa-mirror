;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260402.2139"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "88429e3d26e663f498b8398b362f046b82a93dc1"
  :revdesc "88429e3d26e6"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
