(define-package "modus-themes" "20210916.703" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "370a80634a9cdedac715beff087cadb7d6046f62" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
