;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20241210.1511"
  "Spaced Repetition System."
  '((emacs     "27.2")
    (emacsql   "4.0.1")
    (compat    "29.1.4.2")
    (transient "0.7.2"))
  :url "https://git.thanosapollo.org/gnosis"
  :commit "112693dd653ea6ea8bbdf05506ac8aacc4f5e3df"
  :revdesc "112693dd653e"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
