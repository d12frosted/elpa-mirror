(define-package "hl-indent-scope" "20221228.438" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "46a75be374217f6ec9eee31f37bc3068c558308c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
