(define-package "diredc" "20240414.2215" "Midnight Commander features (plus) for dired"
  '((emacs "26.1")
    (key-assist "1.0"))
  :commit "d511f63397a72b4f50643cb78919f0703a4b16d5" :keywords
  '("files")
  :url "https://github.com/Boruch-Baum/emacs-diredc")
;; Local Variables:
;; no-byte-compile: t
;; End:
