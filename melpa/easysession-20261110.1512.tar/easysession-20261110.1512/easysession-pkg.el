;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20261110.1512"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "2afad794f4426a0c0db3501a7173e594b1260a05"
  :revdesc "2afad794f442"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
