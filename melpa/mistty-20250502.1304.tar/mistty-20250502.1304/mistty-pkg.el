;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250502.1304"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "583d84d9e1a3baf728c3f42a115d6671017563c6"
  :revdesc "583d84d9e1a3"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
