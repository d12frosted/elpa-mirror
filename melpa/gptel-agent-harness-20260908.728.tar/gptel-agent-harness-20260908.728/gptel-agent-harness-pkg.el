;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent-harness" "20260908.728"
  "Autonomous coding-agent harness for gptel-agent."
  '((emacs       "29.1")
    (compat      "30.1.0.0")
    (gptel       "0.9.9")
    (gptel-agent "0.0.1"))
  :url "https://github.com/beacoder/gptel-agent-harness"
  :commit "fcf76fb74961b8086a0c9280b43cc66c425c1454"
  :revdesc "fcf76fb74961"
  :keywords '("programming" "convenience" "ai" "agent")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
