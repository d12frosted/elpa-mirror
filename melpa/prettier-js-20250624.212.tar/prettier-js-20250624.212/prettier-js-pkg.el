;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250624.212"
  "Minor mode to format JS code on file save."
  ()
  :url "https://github.com/prettier/prettier-emacs"
  :commit "6aae2e8b209abdfb19d7084565d1fdb8f4a00508"
  :revdesc "6aae2e8b209a"
  :keywords '("convenience" "wp" "edit" "js"))
