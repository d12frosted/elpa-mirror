;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250630.802"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "f77f5fb89664a78a4adf38e6d7ac2f533b6f24ec"
  :revdesc "f77f5fb89664"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
