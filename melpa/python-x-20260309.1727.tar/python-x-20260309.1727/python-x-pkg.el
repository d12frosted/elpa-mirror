;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-x" "20260309.1727"
  "Python.el extras for interactive evaluation."
  '((python  "0.24")
    (folding "0.0")
    (emacs   "24.5")
    (compat  "26.1"))
  :url "https://gitlab.com/wavexx/python-x.el"
  :commit "c7c1986753f112e3bf0e8f25bf74de1f422a5121"
  :revdesc "c7c1986753f1"
  :keywords '("languages" "processes" "python" "eval" "folding")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
