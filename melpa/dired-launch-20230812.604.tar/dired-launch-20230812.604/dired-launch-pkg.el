(define-package "dired-launch" "20230812.604" "Use dired as a launcher"
  '((emacs "24.3"))
  :commit "b2639051a2cbc56be7f9b5df2f4391c159770a6d" :authors
  '(("David Thompson"))
  :maintainers
  '(("David Thompson"))
  :maintainer
  '("David Thompson")
  :keywords
  '("dired" "launch")
  :url "https://github.com/thomp/dired-launch")
;; Local Variables:
;; no-byte-compile: t
;; End:
