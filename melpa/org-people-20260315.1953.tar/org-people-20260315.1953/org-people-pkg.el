;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260315.1953"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "692e84b8a101ade92a767b0333b25f4fc2219b5a"
  :revdesc "692e84b8a101"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
