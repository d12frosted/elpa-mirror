(define-package "geiser-chibi" "20210405.1924" "Chibi Scheme's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.12"))
  :commit "54e7f384618c73d8fb675b5289d443a8ee3e4dc8" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chibi" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chibi")
;; Local Variables:
;; no-byte-compile: t
;; End:
