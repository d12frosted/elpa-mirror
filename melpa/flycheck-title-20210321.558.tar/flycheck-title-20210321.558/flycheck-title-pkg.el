;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-title" "20210321.558"
  "Show flycheck errors in the frame title."
  '((flycheck "30")
    (emacs    "24"))
  :url "https://github.com/Wilfred/flycheck-title"
  :commit "74e4375f372f7b9ce0fdfa34dc74a048376679ae"
  :revdesc "74e4375f372f"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
