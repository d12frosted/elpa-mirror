(define-package "reason-mode" "20170510.1734" "A major emacs mode for editing Reason (based on rust-mode)"
  '((emacs "24.0"))
  :commit "6b53815a0405be1f364a082d22fe5c900409a01a" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages" "ocaml")
  :url "https://github.com/arichiardi/reason-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
