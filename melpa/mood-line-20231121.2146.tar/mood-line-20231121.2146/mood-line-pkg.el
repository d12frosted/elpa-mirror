(define-package "mood-line" "20231121.2146" "A minimal mode line inspired by doom-modeline"
  '((emacs "26.1"))
  :commit "c3ff35a807ba55dc3e66871abfeef3e84e571666" :authors
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainers
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainer
  '("Jessie Hildebrandt <jessieh.net>")
  :keywords
  '("mode-line" "faces")
  :url "https://gitlab.com/jessieh/mood-line")
;; Local Variables:
;; no-byte-compile: t
;; End:
