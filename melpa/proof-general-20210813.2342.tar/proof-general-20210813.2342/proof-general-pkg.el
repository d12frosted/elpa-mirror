(define-package "proof-general" "20210813.2342" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.5"))
  :commit "e2ee96b209e740afd9349bfaab8410d98e1eaccd" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
