;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ado-mode" "20260909.1524"
  "Major mode for editing Stata-related files."
  '((emacs "25.1"))
  :url "https://github.com/louabill/ado-mode"
  :commit "9013526a79e8da59aa192431850a9efb711f0a98"
  :revdesc "9013526a79e8"
  :keywords '("tools" "languages" "files" "convenience" "stata" "mata" "ado")
  :authors '(("Bill Rising" . "brising@alum.mit.edu"))
  :maintainers '(("Bill Rising" . "brising@alum.mit.edu")))
