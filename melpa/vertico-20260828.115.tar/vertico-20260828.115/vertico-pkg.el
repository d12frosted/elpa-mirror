;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20260828.115"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "024365aced4d6f316d20e5ce65cf3fd9659d3b4e"
  :revdesc "024365aced4d"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
