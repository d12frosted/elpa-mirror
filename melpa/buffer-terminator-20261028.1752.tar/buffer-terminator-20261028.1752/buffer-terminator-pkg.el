;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20261028.1752"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "5a5589348aa9a4310593cf139be2f53ea9de626c"
  :revdesc "5a5589348aa9"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
