;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "klere-theme" "20250225.130"
  "A dark theme with lambent color highlights and incremental grays."
  '((emacs "24"))
  :url "https://codeberg.org/Nzgg/emacs-klere-theme"
  :commit "b0373f24f761e732619a6d1d3d6726bad02b6cf5"
  :revdesc "b0373f24f761"
  :authors '(("Nzgg" . "jaft.r@mail.mayfirst.org"))
  :maintainers '(("Nzgg" . "jaft.r@mail.mayfirst.org")))
