(define-package "docstr" "20211003.1602" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "c7d4f94ea3125d542fb88ee64b45fd3acbda0d0f" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
