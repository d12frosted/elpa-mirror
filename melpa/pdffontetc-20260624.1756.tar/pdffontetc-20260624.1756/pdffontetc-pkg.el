;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdffontetc" "20260624.1756"
  "Display `pdffont' and other PDF information."
  '((emacs     "24.4")
    (pdf-tools "1.2.0"))
  :url "https://github.com/emacsomancer/pdffontetc"
  :commit "063529d92f833ca4342f88a4928f6ec74826ccd0"
  :revdesc "063529d92f83"
  :keywords '("files" "multimedia")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
