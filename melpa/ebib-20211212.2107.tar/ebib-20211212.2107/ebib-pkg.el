(define-package "ebib" "20211212.2107" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "37b9c4ec7a57ffdda53f3345cc99cf6819e94863" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
