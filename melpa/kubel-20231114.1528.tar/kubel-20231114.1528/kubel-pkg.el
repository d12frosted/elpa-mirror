(define-package "kubel" "20231114.1528" "Control Kubernetes with limited permissions"
  '((transient "0.1.0")
    (emacs "25.3")
    (dash "2.12.0")
    (s "1.2.0")
    (yaml-mode "0.0.14"))
  :commit "4e3d362b2df2307f7b13140810a3142b835bc9ff" :authors
  '(("Adrien Brochard"))
  :maintainers
  '(("Adrien Brochard"))
  :maintainer
  '("Adrien Brochard")
  :keywords
  '("kubernetes" "k8s" "tools" "processes")
  :url "https://github.com/abrochard/kubel")
;; Local Variables:
;; no-byte-compile: t
;; End:
