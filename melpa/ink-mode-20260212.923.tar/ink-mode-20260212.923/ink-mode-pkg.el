;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ink-mode" "20260212.923"
  "Major mode for writing interactive fiction in Ink."
  '((emacs "29.1"))
  :url "https://github.com/Kungsgeten/ink-mode"
  :commit "da2e7144837606f27ea6a5ea6d26229aeb0dd77e"
  :revdesc "da2e71448376"
  :keywords '("languages" "wp" "hypermedia"))
