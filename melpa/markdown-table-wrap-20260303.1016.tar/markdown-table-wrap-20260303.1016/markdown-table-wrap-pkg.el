;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-table-wrap" "20260303.1016"
  "Word-wrap GFM pipe tables to fit window width."
  '((emacs "28.1"))
  :url "https://github.com/dnouri/markdown-table-wrap"
  :commit "204b6d8818ff97ca0d5bc40182989ccc59628a37"
  :revdesc "204b6d8818ff"
  :keywords '("text" "markdown" "tables")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
