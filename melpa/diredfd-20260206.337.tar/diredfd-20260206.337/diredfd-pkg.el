;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredfd" "20260206.337"
  "Dired functions and settings to mimic FD/FDclone."
  '((emacs "28.1"))
  :url "https://github.com/knu/diredfd.el"
  :commit "a3eb656d2bd201a193fdb1ac547c075717ee7561"
  :revdesc "a3eb656d2bd2"
  :keywords '("unix" "directories" "dired")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
