;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-sync-mode" "20260101.2353"
  "Automatically commit and sync local changes."
  '((emacs       "29.1")
    (async-await "0"))
  :url "https://github.com/justinbarclay/git-sync-mode"
  :commit "9e602ebb0fa3c02a7987bb94ccfa0142fe00d1a9"
  :revdesc "9e602ebb0fa3"
  :keywords '("vc" "convenience")
  :authors '(("Justin Barclay" . "github@justincbarclay.ca"))
  :maintainers '(("Justin Barclay" . "github@justincbarclay.ca")))
