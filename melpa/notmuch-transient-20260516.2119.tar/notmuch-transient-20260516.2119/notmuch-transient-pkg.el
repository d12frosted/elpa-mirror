;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-transient" "20260516.2119"
  "Command dispatchers for Notmuch."
  '((emacs     "29.1")
    (compat    "30.1")
    (notmuch   "0.39")
    (transient "0.12"))
  :url "https://github.com/tarsius/notmuch-transient"
  :commit "dc77cb285b26ce8ed9f7cb3b78893f9f78526fe1"
  :revdesc "dc77cb285b26"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev")))
