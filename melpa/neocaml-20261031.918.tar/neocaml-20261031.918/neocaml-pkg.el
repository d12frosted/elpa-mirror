;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261031.918"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "9bf790d5f41609e86442b85bc714e11817fe44d3"
  :revdesc "9bf790d5f416"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
