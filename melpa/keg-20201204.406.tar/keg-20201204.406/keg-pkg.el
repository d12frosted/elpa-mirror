(define-package "keg" "20201204.406" "Modern Elisp package development system"
  '((emacs "24.1")
    (cl-lib "0.6"))
  :commit "18c675aa2ff1749eb42f081f0549398b82cd4540" :keywords
  ("convenience")
  :authors
  (("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  ("Naoya Yamashita" . "conao3@gmail.com")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
