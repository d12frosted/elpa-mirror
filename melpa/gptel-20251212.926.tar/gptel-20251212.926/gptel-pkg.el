;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251212.926"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "030b22ba13db8f05ebc821a35417de46e1a7fd5b"
  :revdesc "030b22ba13db"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
