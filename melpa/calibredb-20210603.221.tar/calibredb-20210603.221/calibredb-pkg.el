(define-package "calibredb" "20210603.221" "Yet another calibre client"
  '((emacs "25.1")
    (transient "0.1.0")
    (s "1.12.0")
    (dash "2.17.0"))
  :commit "933140a3227ee61cfccf3cf0c567b5c9e64f1ded" :authors
  '(("Damon Chan" . "elecming@gmail.com"))
  :maintainer
  '("Damon Chan" . "elecming@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/chenyanming/calibredb.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
