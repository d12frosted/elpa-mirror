;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cppinsights" "20250519.101"
  "Integration with cppinsights tool."
  '((emacs "28.1"))
  :url "https://github.com/chrischen3121/cppinsights.el"
  :commit "941e48a0d5c4a6aed865d8be30ebca006b5a6e3f"
  :revdesc "941e48a0d5c4"
  :keywords '("c++" "tools" "cppinsights")
  :authors '(("Chris Chen" . "chrischen@ignity.xyz"))
  :maintainers '(("Chris Chen" . "chrischen@ignity.xyz")))
