(define-package "modus-themes" "20210204.2035" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "91a65311b2246d93e7997100a84fba800fe5c5b0" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
