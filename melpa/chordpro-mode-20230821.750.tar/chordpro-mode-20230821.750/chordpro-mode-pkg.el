(define-package "chordpro-mode" "20230821.750" "Major mode for ChordPro lead sheet file format"
  '((emacs "28.1")
    (compat "29.1.4.1"))
  :commit "819a0913ca7967d4069f02fbfb24654352cb2a89" :authors
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainer
  '("Howard Ding" . "hading2@gmail.com")
  :keywords
  '("convenience")
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
