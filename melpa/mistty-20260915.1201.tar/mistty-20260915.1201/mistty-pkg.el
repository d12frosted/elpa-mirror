;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20260915.1201"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "0416ca23423a33ce0ac32b5b8ed8443d20e82fea"
  :revdesc "0416ca23423a"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
