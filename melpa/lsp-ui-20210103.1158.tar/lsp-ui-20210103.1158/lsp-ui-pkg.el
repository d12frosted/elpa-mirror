(define-package "lsp-ui" "20210103.1158" "UI modules for lsp-mode"
  '((emacs "26.1")
    (dash "2.14")
    (dash-functional "1.2.0")
    (lsp-mode "6.0")
    (markdown-mode "2.3"))
  :commit "0947844c8065f2bff841e3ff8bc6f4b807c1c0cb" :authors
  (("Sebastien Chapuis <sebastien@chapu.is>, Fangrui Song" . "i@maskray.me"))
  :maintainer
  ("Sebastien Chapuis <sebastien@chapu.is>, Fangrui Song" . "i@maskray.me")
  :keywords
  ("languages" "tools")
  :url "https://github.com/emacs-lsp/lsp-ui")
;; Local Variables:
;; no-byte-compile: t
;; End:
