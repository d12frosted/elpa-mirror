(define-package "dirvish" "20220107.1045" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "44aef9dd0f6ce29b2cf654ddd92e1f89a19b5fb2" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
