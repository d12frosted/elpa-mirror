(define-package "dirvish" "20220318.431" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "10d2af55f7b6c02b40f153389cdabd76769501fb" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
