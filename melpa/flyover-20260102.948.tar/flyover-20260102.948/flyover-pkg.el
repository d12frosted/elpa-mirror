;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20260102.948"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "275e361fa493db6e1ba9d1b1bb64df94878956b0"
  :revdesc "275e361fa493"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
