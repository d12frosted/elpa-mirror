(define-package "flymake-collection" "20220410.1343" "Collection of checkers for flymake, bringing flymake to the level of flycheck"
  '((emacs "28.1")
    (let-alist "1.0")
    (flymake "1.2.1"))
  :commit "297406f601daffbec2b3305013442b2829451416" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("language" "tools")
  :url "https://github.com/mohkale/flymake-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
