(define-package "consult" "20220303.1408" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "8547e336142e74449b59a6b018e3c96a2b205fd2" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
