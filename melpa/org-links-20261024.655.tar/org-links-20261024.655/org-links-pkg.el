;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20261024.655"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "c1f9318ffc3129169d9e9c0e59d01d5b1e3abbba"
  :revdesc "c1f9318ffc31"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
