(define-package "gptel" "20230410.557" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "00abbf7597d7c4a5a5d9d4b8b4273afb89040a24" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
