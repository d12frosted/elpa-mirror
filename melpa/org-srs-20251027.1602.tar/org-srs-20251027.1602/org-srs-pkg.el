;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251027.1602"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "1e7da4e97e1e0e16706d3b53d53bce4e748fc2d2"
  :revdesc "1e7da4e97e1e"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
