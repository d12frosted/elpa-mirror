(define-package "base16-theme" "20220621.905" "Collection of themes built on combinations of 16 base colors" 'nil :commit "283f461969b9c29055e9e2aa1547b605c096949b" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/base16-project/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
