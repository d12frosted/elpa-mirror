;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250625.1757"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "9c475b1ffb153a05fde25e10262bb07c4e5129a4"
  :revdesc "9c475b1ffb15"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
