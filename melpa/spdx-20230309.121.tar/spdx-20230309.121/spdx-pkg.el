(define-package "spdx" "20230309.121" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "2ce013b934a985677cb84c705720889abcda3cfe" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
