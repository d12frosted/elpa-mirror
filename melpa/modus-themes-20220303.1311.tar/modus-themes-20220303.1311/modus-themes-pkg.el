(define-package "modus-themes" "20220303.1311" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "67880ff914da9ee6c43ab3a26c039b2091c453f1" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
