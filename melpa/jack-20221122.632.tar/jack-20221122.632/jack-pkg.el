;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jack" "20221122.632"
  "HTML generator library."
  '((emacs "28.1"))
  :url "https://github.com/tonyaldon/jack"
  :commit "3b4ea97fcc107d0ffd201ea695129af52f390113"
  :revdesc "3b4ea97fcc10"
  :keywords '("lisp" "html")
  :authors '(("Tony Aldon" . "tony.aldon.adm@gmail.com"))
  :maintainers '(("Tony Aldon" . "tony.aldon.adm@gmail.com")))
