;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "merlin-iedit" "20221123.1408"
  "Merlin and iedit integration."
  '((emacs  "25.1")
    (merlin "3")
    (iedit  "0.9"))
  :url "https://github.com/ocaml/merlin"
  :commit "8bcab034a680f57ddf58092fda6288dc4caddd2a"
  :revdesc "8bcab034a680"
  :keywords '("ocaml" "languages")
  :authors '(("Simon Castellan" . "simon.castellaniuwt.fr")
             ("Frédéric Bour" . "frederic.bourlakaban.net")
             ("Thomas Refis" . "thomas.refisgmail.com"))
  :maintainers '(("Simon Castellan" . "simon.castellaniuwt.fr")
                 ("Frédéric Bour" . "frederic.bourlakaban.net")
                 ("Thomas Refis" . "thomas.refisgmail.com")))
