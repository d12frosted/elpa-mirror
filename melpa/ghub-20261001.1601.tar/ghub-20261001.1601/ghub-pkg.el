;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20261001.1601"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "01e2bc064ab4965d332efa11fafeda2a43f338d1"
  :revdesc "01e2bc064ab4"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
