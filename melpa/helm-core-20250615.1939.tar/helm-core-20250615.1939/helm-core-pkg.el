;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250615.1939"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "469a8934861e12d0ce50dff2330395c78a45cb3d"
  :revdesc "469a8934861e"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
