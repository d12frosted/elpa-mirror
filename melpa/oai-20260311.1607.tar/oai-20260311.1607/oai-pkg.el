;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260311.1607"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "66041b585fe41bf291605a7a13c909f65f5fa581"
  :revdesc "66041b585fe4"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
