(define-package "geiser" "20220821.344" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (project "0.8.1"))
  :commit "b03bad3e5dfa8f8a74167f78f25d7b664284a9ae" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
