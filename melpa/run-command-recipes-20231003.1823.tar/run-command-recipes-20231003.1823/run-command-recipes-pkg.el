(define-package "run-command-recipes" "20231003.1823" "This is collection of recipes to `run-command'"
  '((emacs "25.1")
    (dash "2.18.0")
    (f "0.20.0")
    (run-command "0.1.0"))
  :commit "3d4c05225d54c97a4aef375113e6f4de9ea3aaef" :authors
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainers
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainer
  '("semenInRussia" . "hrams205@gmail.com")
  :keywords
  '("extensions" "run-command")
  :url "https://github.com/semenInRussia/emacs-run-command-recipes")
;; Local Variables:
;; no-byte-compile: t
;; End:
