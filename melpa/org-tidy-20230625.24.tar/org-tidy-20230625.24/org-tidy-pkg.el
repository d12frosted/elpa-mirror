(define-package "org-tidy" "20230625.24" "A minor mode to tidy org-mode buffers"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "11aeb5f92abfed08d835e89e248023ef782bbe0d" :authors
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainers
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainer
  '("Xuqing Jia" . "jxq@jxq.me")
  :keywords
  '("convenience" "org")
  :url "https://github.com/jxq0/org-tidy")
;; Local Variables:
;; no-byte-compile: t
;; End:
