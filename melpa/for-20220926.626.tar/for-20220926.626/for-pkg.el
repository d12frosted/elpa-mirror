(define-package "for" "20220926.626" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "938cc7be8e3c3bd14b681bab66e00e06308b56fc" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
