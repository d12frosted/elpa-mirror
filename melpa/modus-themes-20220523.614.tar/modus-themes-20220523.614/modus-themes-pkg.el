(define-package "modus-themes" "20220523.614" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "cf4f308ad1e054d6a1aefa2c4f703c18ccfeeacf" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
