;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20260502.1102"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "67eb8564c6b974bc8f9a22053d1ff7ebec2e7dc3"
  :revdesc "67eb8564c6b9"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
