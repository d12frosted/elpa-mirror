(define-package "circe" "20210525.1331" "Client for IRC in Emacs"
  '((emacs "24.4")
    (cl-lib "0.5"))
  :commit "31ac6ba777a92715ce8b0150854a38586de491ff" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :keywords
  '("irc" "chat" "comm")
  :url "https://github.com/jorgenschaefer/circe")
;; Local Variables:
;; no-byte-compile: t
;; End:
