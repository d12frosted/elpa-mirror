;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260209.527"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.28.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "9d96f7d760ef9bfa1e91bd659bd33945eda7b318"
  :revdesc "9d96f7d760ef"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
