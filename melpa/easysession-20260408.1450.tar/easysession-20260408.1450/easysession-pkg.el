;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260408.1450"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "962cf2c6465acc7ef2d7d260240058a98ec2342d"
  :revdesc "962cf2c6465a"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
