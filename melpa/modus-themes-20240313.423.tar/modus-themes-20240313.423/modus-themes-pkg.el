(define-package "modus-themes" "20240313.423" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "114ffb4141f2ed430d3e179c4827b19a33bffc0d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
