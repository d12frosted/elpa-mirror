(define-package "dirvish" "20220316.620" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "2ef309eb6a8bfb23d02e5352515f9f1d07538120" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
