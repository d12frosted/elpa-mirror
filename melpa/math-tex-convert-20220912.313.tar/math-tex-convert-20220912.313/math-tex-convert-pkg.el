(define-package "math-tex-convert" "20220912.313" "Convert LaTeX macros to unicode and back"
  '((emacs "26.1")
    (math-symbol-lists "1.3")
    (auctex "12.1"))
  :commit "93daa5c64ac6bbf2f634e1dd19678a9dd70c3444" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/math-tex-convert")
;; Local Variables:
;; no-byte-compile: t
;; End:
