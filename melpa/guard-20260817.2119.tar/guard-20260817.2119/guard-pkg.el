;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guard" "20260817.2119"
  "Custom modular init framework."
  '((emacs "29.1"))
  :url "https://github.com/Dspil/guard.el"
  :commit "2cce0f78b5a743e493e0defc8191df9c15b06019"
  :revdesc "2cce0f78b5a7"
  :keywords '("convenience" "initialization" "profiles" "tools")
  :authors '(("Dionisis Spiliopoulos" . "dennisspiliopoylos@gmail.com"))
  :maintainers '(("Dionisis Spiliopoulos" . "dennisspiliopoylos@gmail.com")))
