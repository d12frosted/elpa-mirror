;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20250509.1659"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "5fc65bb88d9a20ea3542492e08968d65081cbff4"
  :revdesc "5fc65bb88d9a"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
