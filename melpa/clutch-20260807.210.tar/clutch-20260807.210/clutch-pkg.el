;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260807.210"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "2e50906947e17908f49e6c29e626a29bf3ac538f"
  :revdesc "2e50906947e1"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
