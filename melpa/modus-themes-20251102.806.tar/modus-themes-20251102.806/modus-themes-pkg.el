;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251102.806"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "67b6db32fb75aa257d354142ec4547bccc4bf98f"
  :revdesc "67b6db32fb75"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
