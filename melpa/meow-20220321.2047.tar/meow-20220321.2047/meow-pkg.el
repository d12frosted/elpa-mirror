(define-package "meow" "20220321.2047" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "979acca991cdada7438f360ef0fec573b20f4f96" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
