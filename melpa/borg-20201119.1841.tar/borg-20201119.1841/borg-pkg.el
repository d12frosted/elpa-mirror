(define-package "borg" "20201119.1841" "assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.2.2")
    (magit "2.90.1"))
  :commit "79bfdbdf0b4a81ee3bab2c853040e57e5454e164" :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  ("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
