(define-package "proof-general" "20201120.34" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.3"))
  :commit "702f5b90ce36e17493fbd5390db7c35097ae8149")
;; Local Variables:
;; no-byte-compile: t
;; End:
