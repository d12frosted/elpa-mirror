;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lyrics" "20220206.116"
  "Show lyrics."
  '((emacs "25.1")
    (seq   "2.15"))
  :url "https://github.com/emacs-pe/lyrics.el"
  :commit "c3d42f1e039941f32f49252e1b1610de337b4470"
  :revdesc "c3d42f1e0399"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
