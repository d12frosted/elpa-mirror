(define-package "moom" "20210216.1044" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "ced3c949073e0bc37d8b6091a2c19da1c9b74228" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
