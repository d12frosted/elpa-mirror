;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260530.1649"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "dcc3e878a60d82ad665de91bbcb323037329a948"
  :revdesc "dcc3e878a60d")
