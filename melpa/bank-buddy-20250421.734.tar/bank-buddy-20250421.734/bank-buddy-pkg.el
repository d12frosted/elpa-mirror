;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bank-buddy" "20250421.734"
  "Financial analysis and reporting."
  '((emacs "26.1")
    (async "1.9.4"))
  :url "https://github.com/captainflasmr/bank-buddy"
  :commit "b6e6b54ba1dd7aab4aba05accb3269caf0640876"
  :revdesc "b6e6b54ba1dd"
  :keywords '("matching")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
