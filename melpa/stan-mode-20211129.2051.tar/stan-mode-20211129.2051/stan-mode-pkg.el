;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stan-mode" "20211129.2051"
  "Major mode for editing Stan files."
  '((emacs "24.4"))
  :url "https://github.com/stan-dev/stan-mode/tree/master/stan-mode"
  :commit "150bbbe5fd3ad2b5a3dbfba9d291e66eeea1a581"
  :revdesc "150bbbe5fd3a"
  :keywords '("languages" "c")
  :authors '(("Jeffrey Arnold" . "jeffrey.arnold@gmail.com")
             ("Daniel Lee" . "bearlee@alum.mit.edu")
             ("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")))
