(define-package "consult" "20210516.850" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "cdc097d65e7b6d95daa187c9a7497679347c75bc" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
