;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pushbullet" "20140809.1232"
  "Emacs client for the PushBullet Android app."
  '((grapnel "0.5.2")
    (json    "1.2"))
  :url "http://www.github.com/theanalyst/revolver"
  :commit "73c59a0f1dc04875b3e5a2c8afbc26c32128e445"
  :revdesc "73c59a0f1dc0"
  :keywords '("convenience")
  :authors '(("Abhishek L" . "abhishek.lekshmanan@gmail.com"))
  :maintainers '(("Abhishek L" . "abhishek.lekshmanan@gmail.com")))
