;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260305.242"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "f55feb91ca542c1445e78c3c4c0d7aee052bf1a7"
  :revdesc "f55feb91ca54"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
