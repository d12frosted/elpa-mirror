(define-package "immersive-translate" "20230910.851" "Translate the current buffer immersively"
  '((emacs "28.2"))
  :commit "b68d8c111e730ba5fde8a8dcff08d3c270f04f6f" :authors
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainers
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainer
  '("Eli Qian" . "eli.q.qian@gmail.com")
  :keywords
  '("convenience" "help" "translate")
  :url "https://github.com/Elilif/emacs-immersive-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
