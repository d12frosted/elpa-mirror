;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-exit-target" "20170717.1851"
  "Commands and keys for selecting other window and frame targets within ido."
  '((emacs "24.4"))
  :url "https://github.com/waymondo/ido-exit-target"
  :commit "e56fc6928649c87ccf39d56d84ab53ebaced1f73"
  :revdesc "e56fc6928649"
  :keywords '("convenience" "tools" "extensions")
  :authors '(("justin talbott" . "justin@waymondo.com"))
  :maintainers '(("justin talbott" . "justin@waymondo.com")))
