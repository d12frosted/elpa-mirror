(define-package "yeetube" "20230801.1745" "YouTube/Invidious Front End"
  '((emacs "27.2"))
  :commit "1940f3fd2e0b7b2d75b4095537fdb5184b53b955" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
