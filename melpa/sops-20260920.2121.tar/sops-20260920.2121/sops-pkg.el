;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sops" "20260920.2121"
  "Edit SOPS-encrypted files transparently."
  '((emacs "29.1"))
  :url "https://github.com/djgoku/sops"
  :commit "07fd550969fe164f71aab89c93338f8993fbd9e6"
  :revdesc "07fd550969fe"
  :keywords '("convenience" "files" "tools" "sops" "encrypt" "decrypt")
  :authors '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainers '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com")))
