(define-package "dwim-shell-command" "20220813.1750" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "3c42dfe855f2aac138d3a5896f7296387c1ffe4d" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
