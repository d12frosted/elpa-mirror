(define-package "modus-themes" "20220503.1528" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "94f39c7c6f4473836c88eb3f000468c0f25c4b3d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
