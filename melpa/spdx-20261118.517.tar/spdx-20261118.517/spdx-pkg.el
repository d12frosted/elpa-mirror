;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20261118.517"
  "Insert SPDX license and copyright headers."
  '((emacs "29.1"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "2be59ece8ce80241cda1313749bc03f98222314d"
  :revdesc "2be59ece8ce8"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
