;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-command-not-found" "20260408.844"
  "Integrate command-not-found in eshell."
  '((emacs "25.1"))
  :url "https://github.com/jaeyeom/eshell-command-not-found"
  :commit "b50003d36f63c8520f85fcbdfb0cefa7bd170db6"
  :revdesc "b50003d36f63"
  :keywords '("convenience")
  :authors '(("Jaehyun Yeom" . "jae.yeom@gmail.com"))
  :maintainers '(("Jaehyun Yeom" . "jae.yeom@gmail.com")))
