;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260718.1445"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3e191c70eeac61a9734e59a3264eec2c0b7d5f9f"
  :revdesc "3e191c70eeac"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
