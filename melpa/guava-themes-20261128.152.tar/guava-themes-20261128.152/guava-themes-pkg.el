;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261128.152"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "b0a0f01f2e1b25c03faf36673f214dffe42bd3b5"
  :revdesc "b0a0f01f2e1b"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
