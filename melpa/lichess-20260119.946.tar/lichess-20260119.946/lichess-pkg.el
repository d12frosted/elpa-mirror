;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "20260119.946"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "c0bd061a8759f436fb57a7f8a7ed379749dee6f0"
  :revdesc "c0bd061a8759"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
