;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251109.343"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "7f2d1e4bb299d529d7b9066620cadbeb331c2ef8"
  :revdesc "7f2d1e4bb299"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
