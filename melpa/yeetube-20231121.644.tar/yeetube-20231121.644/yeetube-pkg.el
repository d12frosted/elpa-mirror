(define-package "yeetube" "20231121.644" "YouTube Front End"
  '((emacs "27.2")
    (compat "29.1.4.2"))
  :commit "be16eef6901fbe9d9b900d6a1db6be41b36d6cdb" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.org/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
