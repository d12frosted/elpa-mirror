;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wisp-mode" "20260711.758"
  "Tools for wisp: the Whitespace-to-Lisp preprocessor."
  '((emacs "24.4"))
  :url "http://www.draketo.de/english/wisp"
  :commit "f1f1249af010efc1a016d4b9481f88286b7694da"
  :revdesc "f1f1249af010"
  :keywords '("languages" "lisp" "scheme")
  :authors '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainers '(("Arne Babenhauserheide" . "arne_bab@web.de")))
