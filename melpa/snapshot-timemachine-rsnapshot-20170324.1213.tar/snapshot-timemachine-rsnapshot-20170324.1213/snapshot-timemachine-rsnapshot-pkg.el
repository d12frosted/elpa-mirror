;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snapshot-timemachine-rsnapshot" "20170324.1213"
  "Rsnapshot backend for snapshot-timemachine."
  '((snapshot-timemachine "20160222.132")
    (seq                  "2.19"))
  :url "https://github.com/NicolasPetton/snapshot-timemachine-rsnapshot"
  :commit "72b0b700d80f1a0442e62bbbb6a0c8c59182f97f"
  :revdesc "72b0b700d80f"
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
