(define-package "embark" "20210315.1537" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "2d85252ccc18e07c83e0298b0802350bb696efef" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
