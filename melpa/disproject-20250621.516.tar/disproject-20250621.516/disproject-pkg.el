;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20250621.516"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.9.2"))
  :url "https://github.com/aurtzy/disproject"
  :commit "03e00422ba71bef2e51069082869336edfcae046"
  :revdesc "03e00422ba71"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
