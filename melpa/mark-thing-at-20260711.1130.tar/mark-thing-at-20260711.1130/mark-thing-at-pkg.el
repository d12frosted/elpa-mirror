;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-thing-at" "20260711.1130"
  "Mark a pattern at the current point."
  '((emacs          "26")
    (choice-program "0.14"))
  :url "https://github.com/plandes/mark-thing-at"
  :commit "7829d89ba7da560adb4236fd26fc6ed5813b7173"
  :revdesc "7829d89ba7da"
  :keywords '("mark" "point" "lisp"))
