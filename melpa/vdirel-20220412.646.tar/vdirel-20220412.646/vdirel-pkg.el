(define-package "vdirel" "20220412.646" "Manipulate vdir (i.e., vCard) repositories"
  '((emacs "24.4")
    (org-vcard "0.1.0")
    (helm "1.7.0")
    (seq "1.11"))
  :commit "4eebcf91bdb9ee10fbbba198c4995ae070442f26" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://github.com/DamienCassou/vdirel")
;; Local Variables:
;; no-byte-compile: t
;; End:
