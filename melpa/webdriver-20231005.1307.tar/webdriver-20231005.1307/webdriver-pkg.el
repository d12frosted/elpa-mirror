(define-package "webdriver" "20231005.1307" "WebDriver local end implementation"
  '((emacs "27.1"))
  :commit "c14fefd4bab76339dbd321d8d37985c3fc2bb3be" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/mauroaranda/emacs-webdriver")
;; Local Variables:
;; no-byte-compile: t
;; End:
