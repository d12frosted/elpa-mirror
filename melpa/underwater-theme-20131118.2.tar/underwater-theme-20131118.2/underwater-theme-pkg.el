;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "underwater-theme" "20131118.2"
  "A gentle, deep blue color theme."
  ()
  :url "https://github.com/jmdeldin/underwater-theme.el"
  :commit "1fbd4ecd4538256c6c46f9638f883072c73ac927"
  :revdesc "1fbd4ecd4538"
  :keywords '("faces")
  :authors '(("Jon-Michael Deldin" . "dev@jmdeldin.com"))
  :maintainers '(("Jon-Michael Deldin" . "dev@jmdeldin.com")))
