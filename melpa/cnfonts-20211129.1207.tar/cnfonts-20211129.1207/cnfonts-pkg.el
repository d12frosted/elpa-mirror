(define-package "cnfonts" "20211129.1207" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "1f67ec282460c402be3ad21342d92c1f3b0e50f0" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
