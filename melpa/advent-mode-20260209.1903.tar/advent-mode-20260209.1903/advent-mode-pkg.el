;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20260209.1903"
  "Advent of Code mode."
  '((emacs "29.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "68c149aad8e5844d87fbf5f703479cded641ef49"
  :revdesc "68c149aad8e5"
  :keywords '("lisp")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
