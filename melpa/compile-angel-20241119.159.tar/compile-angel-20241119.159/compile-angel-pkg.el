;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20241119.159"
  "Compile Emacs Lisp libraries automatically."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "3acb251c303f15fb08b86ac310b71818826bd388"
  :revdesc "3acb251c303f"
  :keywords '("convenience"))
