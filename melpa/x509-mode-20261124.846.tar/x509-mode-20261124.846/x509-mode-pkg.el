;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261124.846"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "ed6b2a06007f6b2b6ad75373b0278be86c4aae5a"
  :revdesc "ed6b2a06007f"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
