(define-package "cape" "20230409.1219" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "c88e1ee3026af6d1734c0e171555c1ae9152f07a" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
