;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250318.1327"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (llama  "0.5.0")
    (el-job "2.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "84b28ce6f3f5032f79b159cd1e7b2508773e783a"
  :revdesc "84b28ce6f3f5"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
