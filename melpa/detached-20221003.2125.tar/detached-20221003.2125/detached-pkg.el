(define-package "detached" "20221003.2125" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "1ac5d3a25b96e544e108c94d3f485c4d36b8bc4b" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
