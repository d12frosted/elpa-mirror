(define-package "related-files" "20221125.1824" "Easily find files related to the current one"
  '((emacs "28.2"))
  :commit "0c2e38d0bb0db45a50a082d3e8362c07fc60a1f2" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("tools")
  :url "https://www.gnu.org/software/emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
