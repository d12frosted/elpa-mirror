;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash" "20260225.801"
  "Flash-style navigation."
  '((emacs "27.1"))
  :url "https://github.com/Prgebish/flash"
  :commit "faa32ab3486668b62b7f4bf86411fd694720dab5"
  :revdesc "faa32ab34866"
  :keywords '("convenience" "navigation")
  :authors '(("Vadim Pavlov" . "https://github.com/Prgebish"))
  :maintainers '(("Vadim Pavlov" . "https://github.com/Prgebish")))
