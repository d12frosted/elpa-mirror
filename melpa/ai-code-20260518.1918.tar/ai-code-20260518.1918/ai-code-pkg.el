;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260518.1918"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "2fec290ca0d004680c5855f3ba38d0906214a2e5"
  :revdesc "2fec290ca0d0"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
