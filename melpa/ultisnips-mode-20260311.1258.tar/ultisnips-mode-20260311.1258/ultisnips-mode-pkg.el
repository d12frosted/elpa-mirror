;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "20260311.1258"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "17b62058aceeb593d3241a9eda2cc12638162862"
  :revdesc "17b62058acee"
  :keywords '("languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
