(define-package "mic" "20230123.944" "Minimal and combinable configuration manager"
  '((emacs "26.1"))
  :commit "7d0a31ace0b801cb8b58a7bb61a981b67508208d" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ROCKTAKEY/mic")
;; Local Variables:
;; no-byte-compile: t
;; End:
