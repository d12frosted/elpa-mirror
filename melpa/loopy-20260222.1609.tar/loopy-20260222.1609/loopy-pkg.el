;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260222.1609"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "07ff6c900fbe9fd218a5602974507e81c3165f6d"
  :revdesc "07ff6c900fbe"
  :keywords '("extensions"))
