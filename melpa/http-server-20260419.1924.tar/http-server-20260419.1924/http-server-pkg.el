;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-server" "20260419.1924"
  "Speaks HTTP for you."
  '((emacs "30.1"))
  :url "https://codeberg.org/martenlienen/http-server.el"
  :commit "973c87b418e59404dcdfe823254e5094adf290f7"
  :revdesc "973c87b418e5"
  :keywords '("comm")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
