;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-imenu" "20230904.1810"
  "Imenu binding for dired mode."
  ()
  :url "https://github.com/DamienCassou/dired-imenu"
  :commit "4f6169f9056fe5f9b9a97e9e75f27825a15e05b9"
  :revdesc "4f6169f9056f"
  :keywords '("dired" "imenu")
  :authors '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainers '(("Damien Cassou" . "damien.cassou@gmail.com")))
