(define-package "erlang" "20220110.807" "Erlang major mode"
  '((emacs "24.1"))
  :commit "462c1df96be5f2c1a60373770839c43ca9a7a619" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
