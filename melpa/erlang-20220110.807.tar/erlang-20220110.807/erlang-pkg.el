(define-package "erlang" "20220110.807" "Erlang major mode"
  '((emacs "24.1"))
  :commit "9f25c868c272176a919fabc53e8a06e7f4f16a7c" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
