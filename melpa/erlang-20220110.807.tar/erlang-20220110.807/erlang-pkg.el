(define-package "erlang" "20220110.807" "Erlang major mode"
  '((emacs "24.1"))
  :commit "74801b899d518a382150e77c911701146a7c392c" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
