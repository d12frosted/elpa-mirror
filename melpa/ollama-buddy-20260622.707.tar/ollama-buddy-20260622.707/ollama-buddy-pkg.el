;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260622.707"
  "Friendly AI assistant for Ollama and cloud LLMs."
  '((emacs     "29.1")
    (transient "0.4.0"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "c3dd289b9be5c8baa390696421f2537bc54b3d85"
  :revdesc "c3dd289b9be5"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
