;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil" "20250121.635"
  "Extensible vi layer."
  '((emacs    "24.1")
    (cl-lib   "0.5")
    (goto-chg "1.6")
    (nadvice  "0.3"))
  :url "https://github.com/emacs-evil/evil"
  :commit "423c4b98588ef3219d69a3d0a985f24c705e4eb9"
  :revdesc "423c4b98588e"
  :keywords '("emulations")
  :maintainers '(("Tom Dalziel" . "tom.dalziel@gmail.com")))
