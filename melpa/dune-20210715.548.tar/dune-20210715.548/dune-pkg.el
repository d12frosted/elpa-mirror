(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "d1e683b1489ff830d61566876a94b1da35bc2aaa" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
