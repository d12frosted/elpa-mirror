(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "36e4f4deced4bd06b3b5fbe6d5b0a216036401fa" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
