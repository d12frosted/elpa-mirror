(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "d6e490c24dfb4607080b6a41930bb9d378bc2a43" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
