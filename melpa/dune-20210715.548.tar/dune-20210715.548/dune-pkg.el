(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "b8b28188c92aae6596e42256eb91cea2208555df" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
