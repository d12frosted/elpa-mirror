(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "c71f33619645269ed85950f4c27740d012494b99" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
