(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "e27d53b262233f52575f3667afa03bfa63734228" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
