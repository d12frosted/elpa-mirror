(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "a1ea3ddc56678cd1e54512283133eb004a2e4102" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
