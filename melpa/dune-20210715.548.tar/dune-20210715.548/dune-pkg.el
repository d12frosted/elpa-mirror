(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "a61341147526eec8ac9b3d559fc9246fedf130a3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
