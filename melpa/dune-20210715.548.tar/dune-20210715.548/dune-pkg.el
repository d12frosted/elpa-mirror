(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "0e534f8d4d1a88d7e005b63a559b97c651a236ea" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
