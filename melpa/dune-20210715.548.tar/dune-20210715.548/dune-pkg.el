(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "38131edb4ea7539fa0f3713d955eab5899a6d56a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
