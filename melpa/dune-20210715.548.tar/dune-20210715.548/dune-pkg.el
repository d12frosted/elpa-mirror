(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "f77a8c67e52031506815008a28d9e3106626c332" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
