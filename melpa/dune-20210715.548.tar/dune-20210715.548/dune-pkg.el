(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "ca16d623f48a1191947e95ed49e783953db85a6a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
