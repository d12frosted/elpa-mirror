(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "8e8063f8733b9b41514e3f4bb535de67ba2e4fc1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
