(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "ec87f93f04054c9fd01b382b57ca22872fb22cef" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
