(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "07dd21abc029f50c6a3a96f2867d31102366faba" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
