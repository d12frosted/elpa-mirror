(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "97fb11b601bdddee88c97615c04a1dacdc603857" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
