;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qwen-chat-shell" "20240612.343"
  "Qwen-chat shell + buffer insert commands."
  '((emacs       "27.1")
    (shell-maker "0.50.1"))
  :url "https://github.com/Pavinberg/qwen-chat-shell"
  :commit "2d6562c8a75aebf7a59e554011571ba5883cf4fd"
  :revdesc "2d6562c8a75a"
  :authors '(("Pavinberg" . "pavin0702@gmail.com"))
  :maintainers '(("Pavinberg" . "pavin0702@gmail.com")))
