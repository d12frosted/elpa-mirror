(define-package "clojure-ts-mode" "20230908.2219" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "881756c8f5f90a763f3c7cbd765c56228f99e1cd" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
