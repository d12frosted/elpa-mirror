;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260408.531"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "d8b4f8aadebebcc77459030fc4e4df34e16dda2d"
  :revdesc "d8b4f8aadebe"
  :keywords '("languages"))
