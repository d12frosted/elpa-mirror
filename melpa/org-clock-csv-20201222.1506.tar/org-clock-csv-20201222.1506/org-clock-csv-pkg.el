;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-csv" "20201222.1506"
  "Export `org-mode' clock entries to CSV format."
  '((org "8.3")
    (s   "1.0"))
  :url "https://github.com/atheriel/org-clock-csv"
  :commit "af94b58c2e179a5bcc938f339e93de0eee3da99c"
  :revdesc "af94b58c2e17"
  :keywords '("calendar" "data" "org")
  :authors '(("Aaron Jacobs" . "atheriel@gmail.com"))
  :maintainers '(("Aaron Jacobs" . "atheriel@gmail.com")))
