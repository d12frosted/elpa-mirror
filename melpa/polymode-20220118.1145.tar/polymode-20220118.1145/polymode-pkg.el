(define-package "polymode" "20220118.1145" "Extensible framework for multiple major modes"
  '((emacs "25"))
  :commit "5e730d58101ba3fd7933a0e0f65bb1d5b09e3745" :authors
  '(("Vitalie Spinu"))
  :maintainer
  '("Vitalie Spinu")
  :keywords
  '("languages" "multi-modes" "processes")
  :url "https://github.com/polymode/polymode")
;; Local Variables:
;; no-byte-compile: t
;; End:
