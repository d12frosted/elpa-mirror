;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20260327.906"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "3697ac2847180bd307e70ff0fb9ef086f59dec24"
  :revdesc "3697ac284718"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
