(define-package "skewer-reload-stylesheets" "20160725.1220" "live-edit CSS, SCSS, Less, and friends."
  '((skewer-mode "1.5.3"))
  :commit "b9cc5635230ac3c0603a6da690c6e632d0a7490a" :authors
  (("Nate Eagleson" . "nate@nateeag.com"))
  :maintainer
  ("Nate Eagleson" . "nate@nateeag.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
