;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apdl-mode" "20250502.1842"
  "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :url "https://github.com/dieter-wilhelm/apdl-mode"
  :commit "89d7bf40c53717041c73084ab01f16adfc0513c8"
  :revdesc "89d7bf40c537"
  :keywords '("languages" "convenience" "tools" "ansys" "apdl")
  :authors '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de")))
