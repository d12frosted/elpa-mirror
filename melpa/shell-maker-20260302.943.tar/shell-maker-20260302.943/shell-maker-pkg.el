;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260302.943"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "47c73c6465959b563bc2c3f0aa7e9de4d8d623bd"
  :revdesc "47c73c646595")
