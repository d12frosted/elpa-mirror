(define-package "evil-textobj-treesitter" "20210815.708" "Provides evil textobjects using treesitter"
  '((emacs "25.1")
    (evil "1.0.0")
    (tree-sitter "0.15.0"))
  :commit "ae465a107f4a62551ebb5c00f18a2c1d23a7aed2" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-treesitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
