(define-package "org2blog" "20220824.148" "Blog from Org mode to WordPress"
  '((htmlize "1.54")
    (hydra "0.15.0")
    (xml-rpc "1.6.12")
    (metaweblog "1.1.12"))
  :commit "b641fbcf33ac2b8a0de7b80536b42ce035428625" :authors
  '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainer
  '("Grant Rettke" . "grant@wisdomandwonder.com")
  :keywords
  '("comm" "convenience" "outlines" "wp")
  :url "https://github.com/org2blog/org2blog")
;; Local Variables:
;; no-byte-compile: t
;; End:
