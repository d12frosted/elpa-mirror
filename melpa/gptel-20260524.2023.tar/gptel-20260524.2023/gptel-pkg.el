;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260524.2023"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "88e4999fcc352b1d72bc07e230dda86d1bc9f37b"
  :revdesc "88e4999fcc35"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
