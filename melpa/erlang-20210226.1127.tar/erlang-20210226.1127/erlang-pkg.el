(define-package "erlang" "20210226.1127" "Erlang major mode"
  '((emacs "24.1"))
  :commit "e5612b615c1c22f802e30d3155845d56a7490e56" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
