(define-package "erlang" "20210226.1127" "Erlang major mode"
  '((emacs "24.1"))
  :commit "13f941d2ed90b3dcb0f8fc97bbad79bcdc474f64" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
