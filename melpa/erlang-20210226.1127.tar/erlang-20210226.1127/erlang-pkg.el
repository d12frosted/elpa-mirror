(define-package "erlang" "20210226.1127" "Erlang major mode"
  '((emacs "24.1"))
  :commit "0a787390be771f5ae1fd44fcea25ab9bf9dfb833" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
