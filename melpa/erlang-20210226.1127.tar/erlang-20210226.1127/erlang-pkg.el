(define-package "erlang" "20210226.1127" "Erlang major mode"
  '((emacs "24.1"))
  :commit "f1c6ac892ff7d51ecc43e6dc65964707981ae707" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
