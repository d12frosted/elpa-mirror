(define-package "mistty" "20231004.1732" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "5ece19b5de407f5281305a58da7eeb5209ed51a8" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
