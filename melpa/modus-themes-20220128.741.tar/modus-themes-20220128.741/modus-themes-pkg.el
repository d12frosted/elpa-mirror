(define-package "modus-themes" "20220128.741" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "cf04581880ba6efdfb6e4eb603fd6b04c996a425" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
