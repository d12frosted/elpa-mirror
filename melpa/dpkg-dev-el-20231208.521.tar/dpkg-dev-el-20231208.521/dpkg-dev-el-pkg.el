(define-package "dpkg-dev-el" "20231208.521" "startup file for the elpa-dpkg-dev-el package" 'nil :commit "4319c2b6964fb16bb39398460b37dd4238c86faa" :authors
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainer
  '("Peter S Galbraith" . "psg@debian.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
