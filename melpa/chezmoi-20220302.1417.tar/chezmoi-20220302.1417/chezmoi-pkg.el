(define-package "chezmoi" "20220302.1417" "A package for interacting with chezmoi"
  '((emacs "26.1"))
  :commit "2ea5e63d04cd8a0db8824ddad1fe1078d4a4e9bb" :authors
  '(("Harrison Pielke-Lombardo"))
  :maintainer
  '("Harrison Pielke-Lombardo")
  :keywords
  '("vc")
  :url "http://www.github.com/tuh8888/chezmoi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
