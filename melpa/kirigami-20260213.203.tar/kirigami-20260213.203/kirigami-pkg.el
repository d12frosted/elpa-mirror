;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260213.203"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "25db2e6636f177dfb11f2f0b66152eed88df0b61"
  :revdesc "25db2e6636f1"
  :keywords '("convenience"))
