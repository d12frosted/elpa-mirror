(define-package "liberime" "20201106.858" "Rime elisp binding"
  '((emacs "25.1"))
  :commit "8d4d1d4f2924dc560bce1d79680df36dcc086d49" :authors
  '(("A.I."))
  :maintainer
  '("A.I.")
  :keywords
  '("convenience" "chinese" "input-method" "rime")
  :url "https://github.com/merrickluo/liberime")
;; Local Variables:
;; no-byte-compile: t
;; End:
