;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260705.1341"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "4b18586c975900ebf7eb88fcaebdf44f43074772"
  :revdesc "4b18586c9759"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
