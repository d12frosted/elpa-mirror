(define-package "direnv" "20220812.956" "direnv integration"
  '((emacs "25.1")
    (dash "2.12.0"))
  :commit "268536f564b7eba99264a89a9149268eb4bc67ac" :authors
  '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers
  '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainer
  '("wouter bolsterlee" . "wouter@bolsterl.ee")
  :keywords
  '("direnv" "environment" "processes" "unix" "tools")
  :url "https://github.com/wbolster/emacs-direnv")
;; Local Variables:
;; no-byte-compile: t
;; End:
