;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neil" "20241209.946"
  "Companion for Babashka Neil."
  '((emacs "27.1"))
  :url "https://github.com/babashka/neil"
  :commit "935190c46f4209107c38480a5fd420569a7b0909"
  :revdesc "935190c46f42"
  :keywords '("convenience" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
