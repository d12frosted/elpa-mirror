(define-package "kmacro-x" "20230303.2339" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "913e08cfa377eb1537ed066e2a4f08b8d8d59a5e" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
