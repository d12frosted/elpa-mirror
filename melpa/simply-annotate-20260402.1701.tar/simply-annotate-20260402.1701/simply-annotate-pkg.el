;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260402.1701"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "ece21769e2407523b008c1e333a9e2cbc6cfdaad"
  :revdesc "ece21769e240"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
