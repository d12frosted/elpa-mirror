;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260304.112"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "c341061ad034fb0acaf606d6bc9da6403a7e38a1"
  :revdesc "c341061ad034"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
