(define-package "osm" "20230101.1110" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "0404b6bc56ff7262f99296e6a40d894177a08d7d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
