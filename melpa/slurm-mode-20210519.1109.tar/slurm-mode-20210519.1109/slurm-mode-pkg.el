(define-package "slurm-mode" "20210519.1109" "Interaction with the SLURM job scheduling system" 'nil :commit "4e6ac09245313cf4018b8e5784b2fca8604269d7" :url "https://github.com/ffevotte/slurm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
