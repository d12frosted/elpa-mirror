;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260406.2204"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "4808e3fc9c83615880fa7d201b2f088ebacaed98"
  :revdesc "4808e3fc9c83"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
