;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auth-source-kwallet" "20250419.1330"
  "KWallet integration for auth-source."
  '((emacs "24.4"))
  :url "https://github.com/vaartis/auth-source-kwallet"
  :commit "1e1bff2403966c3a0683ee65fb28cb8d8ff2c389"
  :revdesc "1e1bff240396"
  :authors '(("Ekaterina Vaartis" . "vaartis@kotobank.ch"))
  :maintainers '(("Ekaterina Vaartis" . "vaartis@kotobank.ch")))
