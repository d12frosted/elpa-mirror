;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smudge" "20251222.1613"
  "Control the Spotify app."
  '((emacs        "27.1")
    (simple-httpd "1.5.1")
    (request      "0.3")
    (oauth2       "0.18"))
  :url "https://github.com/danielfm/smudge"
  :commit "3a0657580feab7dd4dd4ed0ddc84edc12e410a93"
  :revdesc "3a0657580fea"
  :keywords '("multimedia" "music" "spotify" "smudge"))
