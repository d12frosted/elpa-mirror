(define-package "arxiv-mode" "20230121.842" "Read and search for articles on arXiv.org"
  '((emacs "27.1")
    (hydra "0"))
  :commit "06000ceb5a12b0f95bc7e89de03685f7ada4e8c3" :authors
  '(("Alex Chen (fizban007)" . "fizban007@gmail.com")
    ("Simon Lin (Simon-Lin)" . "n.sibetz@gmail.com"))
  :maintainer
  '("Alex Chen (fizban007)" . "fizban007@gmail.com")
  :keywords
  '("bib" "convenience" "hypermedia")
  :url "https://github.com/fizban007/arxiv-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
