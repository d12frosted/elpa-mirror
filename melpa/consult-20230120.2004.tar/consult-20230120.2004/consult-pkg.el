(define-package "consult" "20230120.2004" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.1.1"))
  :commit "380ea827918b41166a1ce2abf60a326288d6f1ad" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
