(define-package "for" "20220910.950" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "7c75ee88a12d245ae692be57fe8dfd3a0d4cc9d2" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
