;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-tailwindcss" "20241017.1410"
  "A lsp-mode client for tailwindcss."
  '((lsp-mode "7.1")
    (f        "0.20.0")
    (emacs    "26.1"))
  :url "https://github.com/merrickluo/lsp-tailwindcss"
  :commit "a93238d069646d20e67146f154bb2a0556cc9fb2"
  :revdesc "a93238d06964"
  :keywords '("language" "tools")
  :authors '(("A.I." . "merrick@luois.me"))
  :maintainers '(("A.I." . "merrick@luois.me")))
