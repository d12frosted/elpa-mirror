;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260702.959"
  "MCP server for Org-mode."
  '((emacs          "28.2")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "de3be79e7e260b9eac1d6e86475a594aeedbc0be"
  :revdesc "de3be79e7e26"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
