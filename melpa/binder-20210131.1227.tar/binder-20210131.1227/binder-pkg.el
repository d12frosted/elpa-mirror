(define-package "binder" "20210131.1227" "Global minor mode to facilitate multi-file writing projects"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "9cec78c685dbca51ab9d1014eb535a541083effc" :authors
  '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainer
  '("Paul W. Rankin" . "pwr@bydasein.com")
  :keywords
  '("files" "outlines" "wp" "text")
  :url "https://github.com/rnkn/binder")
;; Local Variables:
;; no-byte-compile: t
;; End:
