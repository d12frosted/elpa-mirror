(define-package "binder" "20210131.1227" "Global minor mode to facilitate multi-file writing projects"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "52f1c11b01a5f7e7a470a73dec4c3335dea4124b" :authors
  '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainer
  '("Paul W. Rankin" . "pwr@bydasein.com")
  :keywords
  '("files" "outlines" "wp" "text")
  :url "https://github.com/rnkn/binder")
;; Local Variables:
;; no-byte-compile: t
;; End:
