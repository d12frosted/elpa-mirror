;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260522.2049"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "9adcd5f3c68cdfc4468c9560edf9c7a8646742a2"
  :revdesc "9adcd5f3c68c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
