;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nushell-mode" "20231204.1233"
  "Major mode for Nushell scripts."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/nushell-mode"
  :commit "e92791e06ea13b93be38874111b83172d6de67c1"
  :revdesc "e92791e06ea1"
  :keywords '("languages" "unix")
  :authors '(("Azzam S.A" . "vcs@azzamsa.com"))
  :maintainers '(("Azzam S.A" . "vcs@azzamsa.com")))
