(define-package "embark" "20210509.1849" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "7c850c07bfe29f3232ebb22793e8421772f820f1" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
