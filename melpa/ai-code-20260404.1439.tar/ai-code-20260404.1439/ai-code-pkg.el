;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260404.1439"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a42e9bbd9657afd1363510e6c6ba670ffcbc0343"
  :revdesc "a42e9bbd9657"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
