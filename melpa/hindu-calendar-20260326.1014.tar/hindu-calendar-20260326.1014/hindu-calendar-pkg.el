;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hindu-calendar" "20260326.1014"
  "Astronomical traditional Hindu calendar (panchanga)."
  '((emacs "24.3"))
  :url "https://github.com/bdsatish/hindu-calendar"
  :commit "a527f82fe2a780d3d22c018f1d4f5fac9807b88e"
  :revdesc "a527f82fe2a7"
  :keywords '("calendar" "panchanga" "hindu" "indian")
  :authors '(("B.D.Satish" . "bdsatish@gmail.com"))
  :maintainers '(("B.D.Satish" . "bdsatish@gmail.com")))
