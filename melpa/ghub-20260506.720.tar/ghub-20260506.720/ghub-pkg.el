;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20260506.720"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.0")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "db7fd61b2c2840c16670a0b5a6d390bf31d7da6a"
  :revdesc "db7fd61b2c28"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
