(define-package "term+" "20170509.17" "term-mode enhancement"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "c3c9239b339c127231860de43abfa08c44c0201a" :keywords
  ("terminal" "emulation")
  :authors
  (("INA Lintaro <tarao.gnn at gmail.com>"))
  :maintainer
  ("INA Lintaro <tarao.gnn at gmail.com>")
  :url "https://github.com/tarao/term-plus-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
