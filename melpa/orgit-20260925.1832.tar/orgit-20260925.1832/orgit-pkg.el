;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260925.1832"
  "Support for Org links to Magit buffers."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.7")
    (org      "9.8"))
  :url "https://github.com/magit/orgit"
  :commit "417986691dffb29f673a9d14f3c2aea13a326f88"
  :revdesc "417986691dff"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
