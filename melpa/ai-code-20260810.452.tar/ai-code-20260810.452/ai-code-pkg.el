;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260810.452"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "253bf2c550a2e08d4af837d3e7818b340e49791f"
  :revdesc "253bf2c550a2"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
