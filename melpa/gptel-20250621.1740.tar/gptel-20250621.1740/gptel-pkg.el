;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250621.1740"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "7e65ea10a7626d652f1625894ee16761885787cb"
  :revdesc "7e65ea10a762"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
