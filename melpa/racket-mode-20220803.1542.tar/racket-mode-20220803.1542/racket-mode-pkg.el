(define-package "racket-mode" "20220803.1542" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "e86ff2c865f1cd28bc047542eedfb55b32588b04" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
