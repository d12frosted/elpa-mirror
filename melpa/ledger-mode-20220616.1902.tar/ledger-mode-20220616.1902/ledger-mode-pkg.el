(define-package "ledger-mode" "20220616.1902" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "13d5b4802c447f0cd798b7fd23aba837b8b4b678")
;; Local Variables:
;; no-byte-compile: t
;; End:
