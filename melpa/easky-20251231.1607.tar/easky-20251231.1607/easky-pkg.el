;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easky" "20251231.1607"
  "Control the Eask command-line interface."
  '((emacs          "27.1")
    (eask-mode      "0.1.0")
    (eask           "0.1.0")
    (ansi           "0.4.1")
    (lv             "0.0")
    (marquee-header "0.1.0"))
  :url "https://github.com/emacs-eask/easky"
  :commit "efe25f0c1ba483378854795fcfe7fa0367cebf27"
  :revdesc "efe25f0c1ba4"
  :keywords '("maint" "easky")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
