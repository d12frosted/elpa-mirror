;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "catmacs" "20170826.1157"
  "Simple CAT interface for Yaesu Transceivers."
  '((emacs "24"))
  :url "https://bitbucket.org/pymaximus/catmacs"
  :commit "6ea9ee195661fe95355413856476c45dcc8e24e8"
  :revdesc "6ea9ee195661"
  :keywords '("comm" "hardware")
  :authors '(("Frank Singleton" . "b17flyboy@gmail.com"))
  :maintainers '(("Frank Singleton" . "b17flyboy@gmail.com")))
