(define-package "librera-sync" "20210810.529" "Sync document's position with Librera Reader for Android"
  '((emacs "26.1")
    (f "0.17"))
  :commit "b36ab4f3d8c9df1ed28d78b7d517e90195c97244" :authors
  '(("Dmitriy Pshonko" . "jumper047@gmail.com"))
  :maintainer
  '("Dmitriy Pshonko" . "jumper047@gmail.com")
  :keywords
  '("multimedia" "sync")
  :url "https://github.com/jumper047/librera-sync")
;; Local Variables:
;; no-byte-compile: t
;; End:
