(define-package "mistty" "20231007.1446" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "8ab38c1144a5498696a45e88c7f136685df565f5" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
