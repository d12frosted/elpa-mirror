(define-package "kconfig-ref" "20230805.737" "A simple package for looking up kconfig symbol quickly"
  '((emacs "24.4")
    (projectile "2.7.0"))
  :commit "d2f27295053805c5ef4eea5f74e1920f4a24cb25" :authors
  '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers
  '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainer
  '("Jason Kim" . "sukbeom.kim@gmail.com")
  :keywords
  '("tools" "kconfig" "linux" "kernel")
  :url "https://github.com/seokbeomkim/kconfig-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
