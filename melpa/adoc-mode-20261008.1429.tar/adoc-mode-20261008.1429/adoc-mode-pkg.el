;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20261008.1429"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "e4a5333de9d87e4d128153d94f7b74fd6173a204"
  :revdesc "e4a5333de9d8"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
