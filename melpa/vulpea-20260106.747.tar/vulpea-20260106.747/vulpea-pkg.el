;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260106.747"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "8a7ffece1b683e7c7439e05419e942d93d536348"
  :revdesc "8a7ffece1b68"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
