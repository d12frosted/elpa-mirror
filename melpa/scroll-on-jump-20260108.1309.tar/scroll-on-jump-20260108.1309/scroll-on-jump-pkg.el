;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scroll-on-jump" "20260108.1309"
  "Scroll when jumping to a new point."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-scroll-on-jump"
  :commit "3e4e13fab04ab5acc7653d0474bf7b8b685d07d3"
  :revdesc "3e4e13fab04a"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
