;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260710.2247"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "98951bd98eac791c2b4f85780bcf8e1b30b632d0"
  :revdesc "98951bd98eac"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
