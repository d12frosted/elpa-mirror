(define-package "autodisass-llvm-bitcode" "20150411.125" "Automatically disassemble LLVM bitcode" 'nil :commit "14bb1bfe2be3b04d6e0c87a7a9d1e88ce15506d0" :authors
  '(("George Balatsouras <gbalats(at)gmail(dot)com>"))
  :maintainer
  '("George Balatsouras <gbalats(at)gmail(dot)com>")
  :keywords
  '("convenience" "data" "files"))
;; Local Variables:
;; no-byte-compile: t
;; End:
