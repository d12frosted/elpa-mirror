;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260430.2024"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "4d67b8932b37c11ed3773b042b225d12cc63c1e0"
  :revdesc "4d67b8932b37"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
