;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260107.1625"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "76a2ee4979a73b241a91ea65af15f95e00d96d5b"
  :revdesc "76a2ee4979a7"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
