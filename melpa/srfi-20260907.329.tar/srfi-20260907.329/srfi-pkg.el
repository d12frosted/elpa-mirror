;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260907.329"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "6b77411c4191dc26113658bae101a92828427c46"
  :revdesc "6b77411c4191"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
