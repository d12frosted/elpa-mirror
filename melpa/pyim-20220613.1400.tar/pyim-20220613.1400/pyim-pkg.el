(define-package "pyim" "20220613.1400" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "25.1")
    (async "1.6")
    (xr "1.13"))
  :commit "ade6a1f5c7dd5e983a4a6d5ea0ada6ef418043de" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
