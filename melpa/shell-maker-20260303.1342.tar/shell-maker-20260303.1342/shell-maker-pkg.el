;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260303.1342"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "21db0ddcd1043f0445cc73d95f9bef2d16a29c6d"
  :revdesc "21db0ddcd104")
