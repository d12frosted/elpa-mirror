;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260311.1431"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "8205f2c6ea747179382423ec5317b70126faaeb2"
  :revdesc "8205f2c6ea74"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
