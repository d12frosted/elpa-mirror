(define-package "dwim-shell-command" "20221218.1054" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "776710a429845a0eeeebe975fd2d5d5624f54346" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
