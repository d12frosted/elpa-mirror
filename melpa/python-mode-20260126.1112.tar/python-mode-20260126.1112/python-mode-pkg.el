;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20260126.1112"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "5f24abbf12863567188212f134025387167438ac"
  :revdesc "5f24abbf1286"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
