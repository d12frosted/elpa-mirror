(define-package "buffer-manage" "20210913.547" "Manage buffers"
  '((emacs "26.1")
    (choice-program "0.13")
    (dash "2.17.0"))
  :commit "23e708f0cf30f1c8c2a54c3c791bbe94cf25542f" :authors
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("internal" "maint")
  :url "https://github.com/plandes/buffer-manage")
;; Local Variables:
;; no-byte-compile: t
;; End:
