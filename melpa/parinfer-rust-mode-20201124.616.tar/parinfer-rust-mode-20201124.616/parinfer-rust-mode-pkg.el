(define-package "parinfer-rust-mode" "20201124.616" "An interface for the parinfer-rust library"
  '((emacs "26.1"))
  :commit "67eed38129c28f087c0b5dffe8a790978d41a8c1" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
