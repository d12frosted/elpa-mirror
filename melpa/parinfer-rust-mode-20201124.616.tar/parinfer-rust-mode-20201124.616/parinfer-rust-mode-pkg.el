(define-package "parinfer-rust-mode" "20201124.616" "An interface for the parinfer-rust library"
  '((emacs "26.1"))
  :commit "ca9e7b6f8c3c70daf6a933952955b6931a24af83" :keywords
  ("lisp" "tools")
  :authors
  (("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  ("Justin Barclay" . "justinbarclay@gmail.com")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
