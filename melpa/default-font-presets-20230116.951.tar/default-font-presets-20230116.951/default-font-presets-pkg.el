(define-package "default-font-presets" "20230116.951" "Support selecting fonts from a list of presets"
  '((emacs "26.1"))
  :commit "d52a31ba0860188ab27c58d1a3e2de62346700d5" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-default-font-presets")
;; Local Variables:
;; no-byte-compile: t
;; End:
