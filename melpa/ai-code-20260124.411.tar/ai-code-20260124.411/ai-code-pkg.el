;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260124.411"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5dab97bb391fcbf19209d5d718a7b69570f44aac"
  :revdesc "5dab97bb391f"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
