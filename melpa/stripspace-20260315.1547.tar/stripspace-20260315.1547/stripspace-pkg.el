;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260315.1547"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "da2f6ffcbd88e43859d8c397753a0fc90b4b8c9f"
  :revdesc "da2f6ffcbd88"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
