;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260317.410"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "feeabce7451a543359b0ad12475c3bfa00e5e3f2"
  :revdesc "feeabce7451a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
