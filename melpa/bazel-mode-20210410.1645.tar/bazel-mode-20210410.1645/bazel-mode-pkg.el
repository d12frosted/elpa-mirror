(define-package "bazel-mode" "20210410.1645" "Emacs major mode for editing Bazel BUILD and WORKSPACE files"
  '((emacs "26.1"))
  :commit "fd1a8c53fabdf2ee1ada9338b3feb08d154ccbc9" :keywords
  '("build tools" "languages")
  :url "https://github.com/bazelbuild/emacs-bazel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
