;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260605.902"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "18a73ff154879d88ba2b42535e5273f3e8b3afe9"
  :revdesc "18a73ff15487"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
