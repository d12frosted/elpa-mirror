(define-package "telega" "20231129.2142" "Telegram client (unofficial)"
  '((emacs "27.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "1a292c01f4e3e488c306538e2c41b43f6c12580f" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
