;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260410.141"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a15f64f697604818a3c769a6034dde8d13f6f89d"
  :revdesc "a15f64f69760"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
