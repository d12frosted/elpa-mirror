(define-package "racket-mode" "20221015.1615" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "8077ab7783c5f17e3a3f96fdf901a74541e810c8" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
