;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241123.1810"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.70.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "8b2670e987b21abbd00cb1d7448b9efb8e7443a2"
  :revdesc "8b2670e987b2")
