(define-package "chatgpt-shell" "20230614.719" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.25.1"))
  :commit "8aafcaf3d661306407c9a8e839736ba1f3824069" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
