;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hal-mode" "20160704.1746"
  "Major mode for editing HAL files."
  ()
  :url "https://github.com/strahlex/hal-mode/"
  :commit "cd2f66f219ee520198d4586fb6b169cef7ad3f21"
  :revdesc "cd2f66f219ee"
  :keywords '("language"))
