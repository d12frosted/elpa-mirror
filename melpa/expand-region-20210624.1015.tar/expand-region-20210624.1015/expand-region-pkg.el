(define-package "expand-region" "20210624.1015" "Increase selected region by semantic units." 'nil :commit "519e92eabc470fe1792d8d4a37c98e76cf195840" :authors
  '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainer
  '("Magnar Sveen" . "magnars@gmail.com")
  :keywords
  '("marking" "region"))
;; Local Variables:
;; no-byte-compile: t
;; End:
