(define-package "geiser-chez" "20221019.2027" "Chez and Geiser talk to each other"
  '((emacs "26.1")
    (geiser "0.19"))
  :commit "5d9baf231bb4a7289585f88fcb168a81cd6ce7e7" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chez" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chez")
;; Local Variables:
;; no-byte-compile: t
;; End:
