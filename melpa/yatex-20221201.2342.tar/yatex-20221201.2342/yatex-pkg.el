(define-package "yatex" "20221201.2342" "Yet Another tex-mode for emacs //野鳥//" 'nil :commit "38a414d755c1b25097898224170d6ce6891dd863")
;; Local Variables:
;; no-byte-compile: t
;; End:
