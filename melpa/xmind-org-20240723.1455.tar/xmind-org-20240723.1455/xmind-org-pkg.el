;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xmind-org" "20240723.1455"
  "Import XMind mindmaps into Org."
  '((emacs  "27.1")
    (org-ml "5.3")
    (dash   "2.12"))
  :url "https://github.com/akirak/xmind-org-el"
  :commit "01055f0b9a53d40c9ce6a7b1c259a3a73b4ff413"
  :revdesc "01055f0b9a53"
  :keywords '("outlines" "wp" "files")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
