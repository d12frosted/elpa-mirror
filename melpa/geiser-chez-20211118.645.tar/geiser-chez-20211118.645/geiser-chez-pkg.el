(define-package "geiser-chez" "20211118.645" "Chez Scheme's implementation of the geiser protocols"
  '((emacs "26.1")
    (geiser "0.16"))
  :commit "6a675460f896431a3ca933b74f4e8f08a91c0869" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chez" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chez")
;; Local Variables:
;; no-byte-compile: t
;; End:
