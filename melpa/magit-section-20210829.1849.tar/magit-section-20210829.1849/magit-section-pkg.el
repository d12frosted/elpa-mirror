(define-package "magit-section" "20210829.1849" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "2.18.1"))
  :commit "e404aa75a791fa577973176a7eb2f2da3b572b87" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
