(define-package "extend-dnd" "20130328.1734" "R drag and Drop" 'nil :commit "a1923d57f8f5e862cc66c189b5e6627bc84a2119" :authors
  '(("Matthew L. Fidler"))
  :maintainer
  '("Matthew L. Fidler")
  :keywords
  '("extend" "drag and drop")
  :url "https://github.com/mlf176f2/extend-dnd")
;; Local Variables:
;; no-byte-compile: t
;; End:
