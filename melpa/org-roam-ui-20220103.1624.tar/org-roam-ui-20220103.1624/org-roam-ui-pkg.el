(define-package "org-roam-ui" "20220103.1624" "User Interface for Org-roam"
  '((emacs "27.1")
    (org-roam "2.0.0")
    (simple-httpd "20191103.1446")
    (websocket "1.13"))
  :commit "efe619f5ff1f227f223c9269ff8eed90a7cb481e" :authors
  '(("Kirill Rogovoy, Thomas Jorna"))
  :maintainer
  '("Kirill Rogovoy, Thomas Jorna")
  :keywords
  '("files" "outlines")
  :url "https://github.com/org-roam/org-roam-ui")
;; Local Variables:
;; no-byte-compile: t
;; End:
