;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gh" "20260216.535"
  "GitHub CLI integration for Magit."
  '((emacs     "29.1")
    (magit     "4.0.0")
    (transient "0.5.0"))
  :url "https://github.com/jonathanchu/magit-gh"
  :commit "0c6fa86698cc20082fe2d31d091b5dd233c1abb7"
  :revdesc "0c6fa86698cc"
  :keywords '("git" "tools" "vc" "github")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
