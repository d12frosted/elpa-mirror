(define-package "sculpture-themes" "20230728.1045" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "b6267c23afc1c40d7ba477f4c8db319c5dfa51a8" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainers
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
