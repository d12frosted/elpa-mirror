(define-package "cnfonts" "20211102.2232" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "46c9034f28cc559f8c93650baa1a64a42b06c535" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
