;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elogcat" "20260423.851"
  "Logcat interface."
  '((s    "1.9.0")
    (dash "2.10.0"))
  :url "https://github.com/youngker/elogcat.el"
  :commit "6bd7bfd75134d615bd49e5eba8a6e639ee0814ac"
  :revdesc "6bd7bfd75134"
  :keywords '("tools")
  :authors '(("Youngjoo Lee" . "youngker@gmail.com"))
  :maintainers '(("Youngjoo Lee" . "youngker@gmail.com")))
