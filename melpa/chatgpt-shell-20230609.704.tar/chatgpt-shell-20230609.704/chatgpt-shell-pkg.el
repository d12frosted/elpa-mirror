(define-package "chatgpt-shell" "20230609.704" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.25.1"))
  :commit "c91e111f94117dd574b5c3d0945c9c0d87c0d839" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
