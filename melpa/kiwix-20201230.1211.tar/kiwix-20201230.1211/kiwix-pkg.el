(define-package "kiwix" "20201230.1211" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (request "0.3.0"))
  :commit "e3b9b50a75b8d1377f6cd139d8a4aeaf3e7d1dc5" :authors
  (("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  ("stardiviner" . "numbchild@gmail.com")
  :keywords
  ("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
