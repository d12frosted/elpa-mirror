;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260822.1141"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "02aa8c5ab237181ac264ba977e75bd28332ced22"
  :revdesc "02aa8c5ab237"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
