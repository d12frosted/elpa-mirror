;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260306.2236"
  "Emacs frontend for pi coding agent."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "1f0f2c64512be63f84a3d2c314d19c6d97237c9b"
  :revdesc "1f0f2c64512b"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
