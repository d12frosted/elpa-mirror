(define-package "hl-prog-extra" "20230105.932" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "7e6613c3651bf82c1a963066e861ecc616dac52c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
