;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260531.2249"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "ea6e04722eb69aa84cf26bc9453f0171be3058bc"
  :revdesc "ea6e04722eb6"
  :keywords '("languages"))
