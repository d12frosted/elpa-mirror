(define-package "rime" "20211210.1806" "Rime input method"
  '((emacs "26.3")
    (dash "2.17.0")
    (cl-lib "0.6.1")
    (popup "0.5.3")
    (posframe "0.1.0"))
  :commit "5c2ade217134f6f20cd405447af20825e5b44513" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "input-method")
  :url "https://www.github.com/DogLooksGood/emacs-rime")
;; Local Variables:
;; no-byte-compile: t
;; End:
