(define-package "org-gcal" "20220221.2338" "Org sync with Google Calendar"
  '((request "20190901")
    (request-deferred "20181129")
    (alert "0")
    (persist "0")
    (emacs "26")
    (org "9.3"))
  :commit "d700950b89b92ca330b4efea0f8f7b64812e29ff" :authors
  '(("myuhe <yuhei.maeda_at_gmail.com>"))
  :maintainer
  '("Raimon Grau" . "raimonster@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/kidd/org-gcal.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
