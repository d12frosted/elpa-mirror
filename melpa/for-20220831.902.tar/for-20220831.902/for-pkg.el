(define-package "for" "20220831.902" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "a4d430457987c4292c2ff8b806270d1a5752fbfb" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
