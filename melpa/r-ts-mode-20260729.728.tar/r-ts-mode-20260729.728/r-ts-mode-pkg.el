;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "r-ts-mode" "20260729.728"
  "R treesitter mode."
  '((emacs "30.1"))
  :url "https://codeberg.org/R-for-emacs/r-ts-mode"
  :commit "b53a9ca883cfd94c7e4b581ebb97e9dd866ffa72"
  :revdesc "b53a9ca883cf"
  :authors '(("Manuel Teodoro" . "ttm@teoten.me"))
  :maintainers '(("Manuel Teodoro" . "ttm@teoten.me")))
