(define-package "suomalainen-kalenteri" "20200830.1107" "Finnish national and Christian holidays for calendar" 'nil :commit "5b209ff7b7d3dcd09b623915aba1e137c875fa0e")
;; Local Variables:
;; no-byte-compile: t
;; End:
