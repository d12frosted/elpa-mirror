;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20261027.2120"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "32ca0ac5cbdcee537ff991d803d26269e8e36e53"
  :revdesc "32ca0ac5cbdc"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
