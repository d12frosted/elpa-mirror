(define-package "tok-theme" "20220409.1346" "Simple dark theme with cyberpunk aesthetics"
  '((emacs "24.3"))
  :commit "511083e43dd4402b0a6bdd1c4f0f678c35ee0904" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
