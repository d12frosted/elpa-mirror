;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "luarocks" "20170430.2305"
  "Luarocks tools."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/emacs-pe/luarocks.el"
  :commit "cee27ba0716edf338077387969883226dd2b7484"
  :revdesc "cee27ba0716e"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
