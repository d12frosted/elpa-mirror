;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250626.539"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "36e5b767d9e1827750287c3b6d046c4f0c9eaa98"
  :revdesc "36e5b767d9e1"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
