;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglotx" "20261025.453"
  "Native LSP multiplexer for Eglot."
  '((emacs   "29.1")
    (eglot   "1.24")
    (jsonrpc "1.0.29"))
  :url "https://github.com/cxa/eglotx"
  :commit "79affcc86904839a452ab09e68c176739faa4a59"
  :revdesc "79affcc86904"
  :keywords '("tools" "languages")
  :authors '(("CHEN Xian'an" . "xianan.chen@gmail.com"))
  :maintainers '(("CHEN Xian'an" . "xianan.chen@gmail.com")))
