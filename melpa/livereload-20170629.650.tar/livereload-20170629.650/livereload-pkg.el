(define-package "livereload" "20170629.650" "Livereload server"
  '((emacs "25")
    (websocket "1.8"))
  :commit "1e501d7e46dbd476c2c7cc9d20b5ac9d41fb1955" :keywords
  ("convenience")
  :authors
  (("João Távora" . "joaotavora@gmail.com"))
  :maintainer
  ("João Távora" . "joaotavora@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
