;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-overview" "20261114.1025"
  "Show overview of maildir."
  '((emacs "29"))
  :url "https://github.com/mkcms/mu4e-overview"
  :commit "e786fcf99e33f5142db327a0cfcc82bf4665c5cb"
  :revdesc "e786fcf99e33"
  :keywords '("mail" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
