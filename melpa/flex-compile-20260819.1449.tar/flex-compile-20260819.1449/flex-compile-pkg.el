;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-compile" "20260819.1449"
  "Run, evaluate and compile across many languages."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.2.1"))
  :url "https://github.com/plandes/flex-compile"
  :commit "6e56021cfa5a9f1e2f3fa063ba610331eb20047d"
  :revdesc "6e56021cfa5a"
  :keywords '("compilation" "integration" "processes"))
