;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260104.1717"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "e54c4b77df7bea77e96333a238b31fa2ed16d99b"
  :revdesc "e54c4b77df7b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
