(define-package "attrap" "20230707.1457" "ATtempt To Repair At Point"
  '((dash "2.12.0")
    (emacs "25.1")
    (f "0.19.0")
    (s "1.11.0"))
  :commit "1019b86f5398dadef61efc76fefe8fa8be1193a8" :authors
  '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainers
  '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainer
  '("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com")
  :keywords
  '("programming" "tools")
  :url "https://github.com/jyp/attrap")
;; Local Variables:
;; no-byte-compile: t
;; End:
