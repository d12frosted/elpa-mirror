;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "racket-mode" "20250603.1504"
  "Racket editing, REPL, and more."
  '((emacs  "25.1")
    (compat "30.0.2.0"))
  :url "https://www.racket-mode.com/"
  :commit "972373bada4de65a01940a76eb6fcb02afdaf1bc"
  :revdesc "972373bada4d"
  :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")))
