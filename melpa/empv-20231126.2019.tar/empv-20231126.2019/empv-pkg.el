(define-package "empv" "20231126.2019" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0")
    (compat "29.1.4.4"))
  :commit "335a62c11d3ba7125639c455bd0f1f618afbf584" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
