;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20250702.1257"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "04439e982d38021f3e19d4c6cb2f503f44a6fa41"
  :revdesc "04439e982d38"
  :keywords '("data" "extensions"))
