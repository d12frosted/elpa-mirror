;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260330.2247"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "ba0fea51eaed4ccbccb204e7122be8d7f5a509cd"
  :revdesc "ba0fea51eaed"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
