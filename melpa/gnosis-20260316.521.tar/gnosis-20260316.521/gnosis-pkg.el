;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260316.521"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "27d7370e9006c8cadd186df3e253f8fe33f6081e"
  :revdesc "27d7370e9006"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
