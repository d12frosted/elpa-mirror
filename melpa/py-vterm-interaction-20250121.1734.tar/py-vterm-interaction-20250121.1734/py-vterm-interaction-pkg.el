;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-vterm-interaction" "20250121.1734"
  "A mode for Python REPL using vterm."
  '((emacs  "27.1")
    (vterm  "0.0.2")
    (python "0.28"))
  :url "https://github.com/vale981/py-vterm-interaction.el"
  :commit "27dc1af6713b129bc433e0750844390c95aee54b"
  :revdesc "27dc1af6713b"
  :keywords '("languages" "python")
  :maintainers '(("Valentin Boettcher" . "hiroatprotagon.space")))
