(define-package "embark" "20230130.1249" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "ccb7e3a718e43a8b056208ece4646d0b921668e5" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
