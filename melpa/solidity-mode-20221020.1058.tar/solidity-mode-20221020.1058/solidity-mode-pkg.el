(define-package "solidity-mode" "20221020.1058" "Major mode for ethereum's solidity language" 'nil :commit "6aa8b0aef128754b775a165e269879832d5a60e5" :authors
  '(("Lefteris Karapetsas " . "lefteris@refu.co"))
  :maintainer
  '("Lefteris Karapetsas " . "lefteris@refu.co")
  :keywords
  '("languages" "solidity"))
;; Local Variables:
;; no-byte-compile: t
;; End:
