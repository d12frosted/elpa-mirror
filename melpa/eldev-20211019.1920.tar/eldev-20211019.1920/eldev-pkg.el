(define-package "eldev" "20211019.1920" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "2209694a758e27519cc3f03df14232bb7dbb0ce8" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
