;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260429.208"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "ce4cc356e91ad96f315e0d00159fb546d71e7893"
  :revdesc "ce4cc356e91a"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
