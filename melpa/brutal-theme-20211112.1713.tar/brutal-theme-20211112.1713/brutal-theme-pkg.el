(define-package "brutal-theme" "20211112.1713" "Brutalist theme"
  '((emacs "24.1"))
  :commit "f9bba56199e861bc405703286ac3378bda496898" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
