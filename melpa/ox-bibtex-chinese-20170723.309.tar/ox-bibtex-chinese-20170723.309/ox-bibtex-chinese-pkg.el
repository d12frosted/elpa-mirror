(define-package "ox-bibtex-chinese" "20170723.309" "Let ox-bibtex work well for Chinese users"
  '((emacs "24.4"))
  :commit "2ad2364399229144110db7ef6365ad0461d6a38c")
;; Local Variables:
;; no-byte-compile: t
;; End:
