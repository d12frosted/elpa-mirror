;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260416.102"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "359d335c0f54a81d18ffbdd73366d1038709b1de"
  :revdesc "359d335c0f54"
  :keywords '("faces" "files" "q"))
