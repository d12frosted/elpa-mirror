(define-package "consult" "20240224.2002" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "6c1bd8e3830bc8fa09d053ca7d16d005d6c249b4" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
