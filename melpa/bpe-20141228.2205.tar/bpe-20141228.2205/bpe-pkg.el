;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bpe" "20141228.2205"
  "Blog from Org mode to Blogger."
  '((emacs "24.1"))
  :url "https://github.com/yuutayamada/bpe"
  :commit "7b5b25f83506e6c9f4075d3803fa32404943a189"
  :revdesc "7b5b25f83506"
  :keywords '("blogger" "blog")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
