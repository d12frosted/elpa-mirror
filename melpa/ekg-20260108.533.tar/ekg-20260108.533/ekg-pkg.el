;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260108.533"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "797bdfd422bb81982c984b60fbe9e2432e9b6cc6"
  :revdesc "797bdfd422bb"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
