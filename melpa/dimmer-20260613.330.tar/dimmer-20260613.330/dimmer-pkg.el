;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "20260613.330"
  "Visually highlight the selected buffer."
  '((emacs "27.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "6ce67fdcae1a41e5c7b03a9d6f271d3fc1b24a71"
  :revdesc "6ce67fdcae1a"
  :keywords '("faces" "editing"))
