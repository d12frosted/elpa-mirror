(define-package "dirvish" "20220214.655" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a51cf33293abbb2a72003ca1e43e2419fa9dc526" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
