(define-package "buffer-name-relative" "20230622.1358" "Relative buffer names"
  '((emacs "28.1"))
  :commit "5f031bf0c800469155daf2e12c4c4b92f1c38458" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-buffer-name-relative")
;; Local Variables:
;; no-byte-compile: t
;; End:
