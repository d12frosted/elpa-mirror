(define-package "consult" "20221114.2110" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "0dbae1059c6bc0e4291730b32d84eb04a6ead148" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
