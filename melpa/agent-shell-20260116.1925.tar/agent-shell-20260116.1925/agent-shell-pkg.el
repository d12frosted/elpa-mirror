;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260116.1925"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "562df616a8aa4723462010d3c0994549f9b1d40e"
  :revdesc "562df616a8aa")
