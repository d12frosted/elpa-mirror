(define-package "ursa-ts-mode" "20231113.2331" "Major mode for Ursa, using tree-sitter"
  '((emacs "29.1"))
  :commit "b4afa0c2f2a06fca4fcba8772989e4ca09bab7b9" :authors
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("ursalang" "languages" "tree-sitter")
  :url "https://github.com/ursalang/ursa-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
