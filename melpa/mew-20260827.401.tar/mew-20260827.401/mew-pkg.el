;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260827.401"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "40e58f0098a2cc00eb20494af858746a1486d5ec"
  :revdesc "40e58f0098a2")
