;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20251230.1832"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "b3c3850e3025efeeff12e8fc1efe25d00a96a58d"
  :revdesc "b3c3850e3025"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
