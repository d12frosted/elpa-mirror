;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-quick-repls" "20150814.736"
  "Quickly create Clojure and ClojureScript repls for a project."
  '((cider "0.8.1")
    (dash  "2.9.0"))
  :url "https://github.com/symfrog/clojure-quick-repls"
  :commit "8fe4e44939e8a01a4cdf60c0001d9a6abf8a73c3"
  :revdesc "8fe4e44939e8"
  :keywords '("languages" "clojure" "cider" "clojurescript"))
