;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250223.1657"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "1bdcab6c9b4f74e426423ac283a73aac3c6f31d2"
  :revdesc "1bdcab6c9b4f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
