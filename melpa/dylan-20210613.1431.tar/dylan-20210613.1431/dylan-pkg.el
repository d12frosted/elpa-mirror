(define-package "dylan" "20210613.1431" "Dylan editing modes"
  '((emacs "25.1"))
  :commit "d85409dc3cba57a390ca85da95822f8078ecbfa2" :url "https://opendylan.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
