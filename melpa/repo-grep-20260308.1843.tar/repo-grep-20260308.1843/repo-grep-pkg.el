;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "20260308.1843"
  "Project-wide grep search."
  '((emacs "27.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "c680c35bf04d58529498e8e46bed3f6d8847805e"
  :revdesc "c680c35bf04d"
  :keywords '("tools" "search" "grep" "convenience" "project"))
