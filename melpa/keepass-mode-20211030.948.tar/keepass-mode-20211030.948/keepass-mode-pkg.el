(define-package "keepass-mode" "20211030.948" "Mode for KeePass DB."
  '((emacs "27"))
  :commit "f432bb60f9f3bd027025140d723906dcabeefaef" :authors
  '(("Ignasi Fosch" . "natx@y10k.ws"))
  :maintainer
  '("Ignasi Fosch" . "natx@y10k.ws")
  :keywords
  '("data" "files" "tools")
  :url "https://github.com/ifosch/keepass-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
