(define-package "org-category-capture" "20230817.816" "Contextualy capture of org-mode TODOs."
  '((org "9.0.0")
    (emacs "24"))
  :commit "ad8daa991698df265a21b161e62a41e04979d98f" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "todo" "tools" "outlines")
  :url "https://github.com/IvanMalison/org-project-capture")
;; Local Variables:
;; no-byte-compile: t
;; End:
