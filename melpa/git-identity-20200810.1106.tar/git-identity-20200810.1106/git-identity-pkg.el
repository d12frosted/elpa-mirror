(define-package "git-identity" "20200810.1106" "Identity management for (ma)git"
  '((emacs "25.1")
    (dash "2.10")
    (hydra "0.14")
    (f "0.20"))
  :commit "6bf8b2cd72061eac5a4d247ba2fabdd8deafdea7" :keywords
  ("git" "vc" "convenience")
  :authors
  (("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainer
  ("Akira Komamura" . "akira.komamura@gmail.com")
  :url "https://github.com/akirak/git-identity.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
