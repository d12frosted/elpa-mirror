(define-package "org-vcard" "20220118.1102" "org-mode support for vCard export and import." 'nil :commit "3a73d6e1f54fda807ffa7b978884ea7efc09b55e" :authors
  '(("Alexis" . "flexibeast@gmail.com")
    ("Will Dey" . "will123dey@gmail.com"))
  :maintainer
  '("Alexis" . "flexibeast@gmail.com")
  :keywords
  '("outlines" "org" "vcard")
  :url "https://github.com/flexibeast/org-vcard")
;; Local Variables:
;; no-byte-compile: t
;; End:
