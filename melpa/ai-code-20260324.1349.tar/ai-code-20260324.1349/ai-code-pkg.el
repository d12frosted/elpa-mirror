;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260324.1349"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "0b0437e417f065edf77669bf3b4c11e5d59b6f5d"
  :revdesc "0b0437e417f0"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
