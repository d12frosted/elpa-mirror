(define-package "dwim-shell-command" "20221217.2326" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "9f7d1ef29fd9422db6cf11789381217e3a56c80f" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
