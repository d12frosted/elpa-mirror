;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20260522.1457"
  "Nucleo-backed completion style."
  '((emacs "27.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "a0669e2676c516544e141c2591fa80e27bf2d659"
  :revdesc "a0669e2676c5"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
