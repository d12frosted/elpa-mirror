(define-package "loopy" "20210609.2317" "A looping macro"
  '((emacs "27.1"))
  :commit "96763b1b1dad11273d63158dbd7186a0ef3c134b" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
