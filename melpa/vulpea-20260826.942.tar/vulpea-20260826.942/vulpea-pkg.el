;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260826.942"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "db0f08fe836067296d494ca90e5888930832cb06"
  :revdesc "db0f08fe8360"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
