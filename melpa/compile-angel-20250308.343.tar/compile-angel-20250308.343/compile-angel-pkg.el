;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20250308.343"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "7a29008747d0c265dc499082dd4fb278e545a736"
  :revdesc "7a29008747d0"
  :keywords '("convenience"))
