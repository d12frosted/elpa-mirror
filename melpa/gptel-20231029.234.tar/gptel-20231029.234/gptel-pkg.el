(define-package "gptel" "20231029.234" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "61c0df5e19e44f50f96002c8c7a75c8a2d3112bb" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
