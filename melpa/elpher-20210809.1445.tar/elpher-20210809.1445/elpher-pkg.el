(define-package "elpher" "20210809.1445" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "2ebb812f7d0df8f0e338355f1722a6bb0950befa" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
