(define-package "cape" "20230410.1743" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "94e7f813b0d8230fb3e26edabfc5746f87fa08ed" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "wp")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
