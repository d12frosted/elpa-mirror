;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20260224.918"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "835050814e6ab5bc68763793be86b6a99bdf247a"
  :revdesc "835050814e6a"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
