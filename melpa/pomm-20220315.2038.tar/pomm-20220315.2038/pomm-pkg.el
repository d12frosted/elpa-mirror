(define-package "pomm" "20220315.2038" "Yet another Pomodoro timer implementation"
  '((emacs "27.1")
    (alert "1.2")
    (seq "2.22")
    (transient "0.3.0"))
  :commit "2a2673bdc8e2c2af99040b14e97b39271806bf79" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/pomm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
