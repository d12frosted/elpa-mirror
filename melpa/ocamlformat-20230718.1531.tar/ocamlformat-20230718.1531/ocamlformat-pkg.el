(define-package "ocamlformat" "20230718.1531" "Utility functions to format ocaml code"
  '((emacs "24.3"))
  :commit "fe70498a8982bef951311b37aa8568218ce8801a" :keywords
  '("languages" "ocaml")
  :url "https://github.com/ocaml-ppx/ocamlformat")
;; Local Variables:
;; no-byte-compile: t
;; End:
