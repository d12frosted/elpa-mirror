;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250502.1100"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "28.1")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "b2bc984df3f855e280680df8123d6a24aac16897"
  :revdesc "b2bc984df3f8"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
