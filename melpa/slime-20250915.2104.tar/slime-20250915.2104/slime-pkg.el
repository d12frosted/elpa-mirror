;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20250915.2104"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "d1a6ac5f5c6e97243816f68ffb539e5226a9dc3f"
  :revdesc "d1a6ac5f5c6e"
  :keywords '("languages" "lisp" "slime"))
