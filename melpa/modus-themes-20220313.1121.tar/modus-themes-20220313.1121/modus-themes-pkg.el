(define-package "modus-themes" "20220313.1121" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "ab8cbe3beacb4588d8b46b4b801184e1a08109eb" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
