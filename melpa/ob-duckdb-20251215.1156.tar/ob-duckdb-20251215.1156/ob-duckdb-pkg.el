;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-duckdb" "20251215.1156"
  "Org Babel integration for DuckDB CLI."
  '((emacs "28.1")
    (org   "9.5"))
  :url "https://github.com/gggion/ob-duckdb"
  :commit "45176eeb57812a8465aae274b1e03c92e518dfeb"
  :revdesc "45176eeb5781"
  :keywords '("languages" "org" "babel" "duckdb" "sql" "data" "analytics")
  :maintainers '(("gggion" . "gggion123@gmail.com")))
