(define-package "cnfonts" "20211130.218" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "dbfc69f9a6cf3bf0c1480e4841cbc5bc1d935845" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
