;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "20260711.608"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "7ca3e115f159f22ddb4bcea85a22246ee03c422c"
  :revdesc "7ca3e115f159"
  :keywords '("convenience"))
