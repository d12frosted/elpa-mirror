;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-cmake" "20260427.2129"
  "A cmake backend for project.el."
  '((emacs "30.1"))
  :url "https://github.com/lucius-martius/project-cmake"
  :commit "7ff0096d423b326eb8995e9adef83f560463485b"
  :revdesc "7ff0096d423b"
  :keywords '("tools" "convenience")
  :authors '(("Lucius Martius" . "lucius.martius@mailbox.org"))
  :maintainers '(("Lucius Martius" . "lucius.martius@mailbox.org")))
