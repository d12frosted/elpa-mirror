;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-consult" "20251215.1140"
  "Consult integration for zk."
  '((emacs   "27.1")
    (zk      "0.4")
    (consult "0.14"))
  :url "https://github.com/localauthor/zk"
  :commit "5b7fcbdd7bcfd0903e3844d0b4b28826bfb7ef5d"
  :revdesc "5b7fcbdd7bcf"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
