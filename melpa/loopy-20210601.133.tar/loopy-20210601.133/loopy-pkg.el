(define-package "loopy" "20210601.133" "A looping macro"
  '((emacs "27.1"))
  :commit "50494b545b9a909fc6570216230beda1ebeedf36" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
