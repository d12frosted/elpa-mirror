;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verona-mode" "20200823.536"
  "A major mode for the Verona programming language."
  '((emacs "25.1")
    (dash  "2.17.0")
    (hydra "0.15.0"))
  :url "https://github.com/damon-kwok/verona-mode"
  :commit "72dd31ef847344d79409503f3c42169041eb3da4"
  :revdesc "72dd31ef8473"
  :keywords '("languages" "programming")
  :authors '(("Damon Kwok" . "damon-kwok@outlook.com"))
  :maintainers '(("Damon Kwok" . "damon-kwok@outlook.com")))
