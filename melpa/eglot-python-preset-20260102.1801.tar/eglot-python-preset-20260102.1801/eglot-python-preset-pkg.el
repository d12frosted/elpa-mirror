;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-python-preset" "20260102.1801"
  "Eglot preset for Python."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-python-preset"
  :commit "e18a0ea0a176dcb308bd77aeeb72c22954d87433"
  :revdesc "e18a0ea0a176"
  :keywords '("python" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
