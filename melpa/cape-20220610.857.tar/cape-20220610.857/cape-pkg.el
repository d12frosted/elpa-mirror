(define-package "cape" "20220610.857" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "913f68859d0cf6a02a71ddde48bc8454564a2efd" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
