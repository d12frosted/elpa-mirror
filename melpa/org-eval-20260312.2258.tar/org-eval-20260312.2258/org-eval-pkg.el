;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-eval" "20260312.2258"
  "Execute named org-mode blocks on load/save."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-eval"
  :commit "1c029ba35098d1405995933437df7cf83eaf3302"
  :revdesc "1c029ba35098"
  :keywords '("org" "outlines")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
