;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250527.1504"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "40c1b005468dadea98fb238b522ac9665f17d20a"
  :revdesc "40c1b005468d"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
