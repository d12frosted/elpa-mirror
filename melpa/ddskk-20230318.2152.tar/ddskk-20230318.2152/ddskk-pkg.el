(define-package "ddskk" "20230318.2152" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "3820fa6bb0d53132aafb611a643c1e41e444052b" :authors
  '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp"))
  :maintainer
  '("SKK Development Team")
  :keywords
  '("japanese" "mule" "input method")
  :url "https://github.com/skk-dev/ddskk")
;; Local Variables:
;; no-byte-compile: t
;; End:
