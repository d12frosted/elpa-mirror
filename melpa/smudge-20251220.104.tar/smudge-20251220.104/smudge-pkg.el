;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smudge" "20251220.104"
  "Control the Spotify app."
  '((emacs        "27.1")
    (simple-httpd "1.5.1")
    (request      "0.3")
    (oauth2       "0.17"))
  :url "https://github.com/danielfm/smudge"
  :commit "9594592a46b1c6adfccae3d9f01405d28b93d4b2"
  :revdesc "9594592a46b1"
  :keywords '("multimedia" "music" "spotify" "smudge"))
