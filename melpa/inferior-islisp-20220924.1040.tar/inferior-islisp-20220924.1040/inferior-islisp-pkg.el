;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inferior-islisp" "20220924.1040"
  "Run inferior ISLisp processes."
  '((emacs       "26.3")
    (islisp-mode "0.2"))
  :url "https://gitlab.com/sasanidas/islisp-mode"
  :commit "423b84fe4cc6944e36971225b3e19c888e7e4690"
  :revdesc "423b84fe4cc6"
  :keywords '("islisp" "lisp" "programming")
  :maintainers '(("Fermin Munoz" . "fmfs@posteo.net")))
