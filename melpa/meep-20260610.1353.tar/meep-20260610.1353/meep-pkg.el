;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260610.1353"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "041699ea121e07a67420985b1a2b987f2f1be965"
  :revdesc "041699ea121e"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
