(define-package "meyvn" "20221206.2219" "Meyvn client"
  '((emacs "25.1")
    (cider "0.23")
    (projectile "2.1")
    (s "1.12")
    (dash "2.17")
    (parseedn "1.1.0")
    (parseclj "1.1.0")
    (geiser "0.12"))
  :commit "493e652b8fffcbed226f69a2ea82e6f9fc51ab08" :authors
  '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainers
  '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainer
  '("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")
  :url "https://github.com/danielsz/meyvn-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
