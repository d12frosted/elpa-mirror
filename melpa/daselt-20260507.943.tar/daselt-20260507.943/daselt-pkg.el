;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260507.943"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "c3fd938d247c919c55793c9b814dac4958a24f62"
  :revdesc "c3fd938d247c"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
