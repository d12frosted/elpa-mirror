;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260125.1511"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "9fb82fffc9a0017aead40b34ade046205bfb59eb"
  :revdesc "9fb82fffc9a0"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
