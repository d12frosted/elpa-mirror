;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewal-doom-themes" "20200922.325"
  "Dread the colors of darkness."
  '((emacs       "25")
    (ewal        "0.1")
    (doom-themes "0.1"))
  :url "https://gitlab.com/jjzmajic/ewal"
  :commit "e2a04f5c97b7d5e087af26e646c0b45a24522e56"
  :revdesc "e2a04f5c97b7"
  :keywords '("faces"))
