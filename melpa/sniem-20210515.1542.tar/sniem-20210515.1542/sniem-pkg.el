(define-package "sniem" "20210515.1542" "Simple united editing method"
  '((emacs "26.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "e42d88b1b1c121b0bcfa1869c3338d7b159172a3" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
