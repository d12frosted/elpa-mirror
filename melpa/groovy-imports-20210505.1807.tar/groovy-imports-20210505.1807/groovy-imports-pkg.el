;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "groovy-imports" "20210505.1807"
  "Code for dealing with Groovy imports."
  '((emacs  "24.4")
    (s      "1.10.0")
    (pcache "0.3.2"))
  :url "http://www.github.com/mbezjak/emacs-groovy-imports"
  :commit "a60c3202973e3185091db623d960f71840a22205"
  :revdesc "a60c3202973e"
  :keywords '("groovy"))
