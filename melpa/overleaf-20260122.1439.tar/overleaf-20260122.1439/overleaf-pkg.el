;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20260122.1439"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "933a0185e9d13d9ae7fc5271f0b4a4113aab6eca"
  :revdesc "933a0185e9d1"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
