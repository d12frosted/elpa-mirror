;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-popup-menu" "20260802.938"
  "Replace GUI popup menu with something more efficient."
  '((emacs    "24.4")
    (avy-menu "0.1"))
  :url "https://github.com/mrkkrp/ace-popup-menu"
  :commit "b86a26be8edc8b0e71f971f2201cfff71084e983"
  :revdesc "b86a26be8edc"
  :keywords '("convenience" "popup" "menu")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
