(define-package "consult-gh" "20240928.604" "Consulting GitHub Client"
  '((emacs "29.1")
    (consult "1.0")
    (markdown-mode "2.6"))
  :commit "a5f71ac45ee52148d39c6d2759587c04f12f2654" :keywords
  '("convenience" "matching" "tools" "vc")
  :url "https://github.com/armindarvish/consult-gh")
;; Local Variables:
;; no-byte-compile: t
;; End:
