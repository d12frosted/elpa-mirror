(define-package "sequential-yank" "20231114.818" "Minor mode to copy and paste strings sequentially"
  '((emacs "24.4"))
  :commit "7d04f9ccdf3000d82b8ac8821fd3f4276ab328ce" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/sequential-yank.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
