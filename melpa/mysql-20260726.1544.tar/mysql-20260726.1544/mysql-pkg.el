;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20260726.1544"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "c1c813d65ef4a3d9647441b57600b8fba14f826b"
  :revdesc "c1c813d65ef4"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
