(define-package "pov-mode" "20161115.743" "Major mode for editing POV-Ray scene files." 'nil :commit "9fc1db3aab7c27155674dd1a87ec62606035d074")
;; Local Variables:
;; no-byte-compile: t
;; End:
