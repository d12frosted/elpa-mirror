(define-package "elpher" "20210802.940" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "fff9ab154af67a4698b6daf77f05457131b22271" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
