(define-package "grugru" "20211116.850" "Rotate text at point"
  '((emacs "24.4"))
  :commit "7b63aa731bf7df528bb7d680ca3efe42ab4ead38" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
