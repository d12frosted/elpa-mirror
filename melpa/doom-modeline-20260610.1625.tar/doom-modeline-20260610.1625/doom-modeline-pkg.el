;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260610.1625"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "ef31532e26c97cae48d45351f463bdcabca33225"
  :revdesc "ef31532e26c9"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
