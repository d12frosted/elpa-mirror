;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-accent-mode" "20261110.1118"
  "Accent Selected Window."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/selected-window-accent-mode"
  :commit "58344874150e1085fd33b34d1adab4caf8e836c8"
  :revdesc "58344874150e"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
