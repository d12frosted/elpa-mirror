;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20241120.505"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "359069adbd67e713782a08ae2554032cf1477703"
  :revdesc "359069adbd67"
  :keywords '("convenience"))
