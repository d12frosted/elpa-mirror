(define-package "consult" "20231206.824" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "6d46ab9a03f4b69075219efcac0551c1934014f2" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
