;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250616.932"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "3d059bda1e68f32f11ff04782b782b1f491c50ec"
  :revdesc "3d059bda1e68"
  :keywords '("languages"))
