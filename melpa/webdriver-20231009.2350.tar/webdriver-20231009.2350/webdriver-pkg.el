(define-package "webdriver" "20231009.2350" "WebDriver local end implementation"
  '((emacs "27.1"))
  :commit "ae0ae90ad8d0bd53a2fba4361438d980222509a4" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/mauroaranda/emacs-webdriver")
;; Local Variables:
;; no-byte-compile: t
;; End:
