(define-package "ready-player" "20240911.1215" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "012f45fa977d50fd4348bdbc2ecd3afd3266eb45" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
