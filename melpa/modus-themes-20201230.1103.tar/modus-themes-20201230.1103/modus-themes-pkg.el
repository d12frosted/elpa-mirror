(define-package "modus-themes" "20201230.1103" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "49f149e9b0554bb3dfcfe2b32894dbff84a94f70" :authors
  (("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  ("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  ("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
