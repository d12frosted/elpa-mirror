(define-package "ox-tufte" "20230808.1443" "Tufte HTML org-mode export backend"
  '((org "9.5")
    (emacs "27.1"))
  :commit "3e77785ead32477bb752ef3ed11d38d874815345" :authors
  '(("M. Lee Hinman"))
  :maintainers
  '(("The Bayesians Inc."))
  :maintainer
  '("The Bayesians Inc.")
  :keywords
  '("org" "tufte" "html" "outlines" "hypermedia" "calendar" "wp")
  :url "https://github.com/ox-tufte/ox-tufte")
;; Local Variables:
;; no-byte-compile: t
;; End:
