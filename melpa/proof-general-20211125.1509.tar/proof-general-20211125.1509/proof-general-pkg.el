(define-package "proof-general" "20211125.1509" "PG init file for package.el and ELPA compatibility"
  '((emacs "25.1"))
  :commit "1b1083e86e0cddc20ff2f1a6b25c7a7eee2edf02" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
