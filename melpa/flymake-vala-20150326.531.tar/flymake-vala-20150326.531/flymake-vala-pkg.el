;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-vala" "20150326.531"
  "A flymake handler for vala-mode files."
  '((flymake-easy "0.1"))
  :url "https://github.com/daniellawrence/flymake-vala"
  :commit "c3674f461fc84fb0300cd3a562fb903a59782745"
  :revdesc "c3674f461fc8"
  :keywords '("convenience" "vala")
  :authors '(("Daniel Lawrence" . "dannyla@linux.com"))
  :maintainers '(("Daniel Lawrence" . "dannyla@linux.com")))
