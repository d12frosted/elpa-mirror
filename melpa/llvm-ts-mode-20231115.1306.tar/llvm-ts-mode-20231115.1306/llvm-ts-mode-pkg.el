(define-package "llvm-ts-mode" "20231115.1306" "LLVM major mode using tree-sitter"
  '((emacs "29.1"))
  :commit "f2dcfe0a3d99472d69394981b88fcdd6a11ed283" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("languages" "tree-sitter" "llvm")
  :url "https://github.com/nverno/llvm-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
