;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "express" "20260202.1155"
  "Alternatives to `message'."
  '((emacs        "24.3")
    (string-utils "0.3.2"))
  :url "http://github.com/rolandwalker/express"
  :commit "f98932f43771eea3cadd36002670d2099a0258f8"
  :revdesc "f98932f43771"
  :keywords '("extensions" "message" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
