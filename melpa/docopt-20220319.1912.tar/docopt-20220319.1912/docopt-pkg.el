(define-package "docopt" "20220319.1912" "A Docopt implementation in Elisp"
  '((emacs "26.3")
    (dash "2.17.0")
    (emacs "26.1")
    (f "0.20.0")
    (parsec "0.1.3")
    (s "1.12.0")
    (transient "0.3.0"))
  :commit "525b5d42c51995f52f0f82fb41ba8e1d246532d1" :authors
  '(("r0man" . "roman@burningswell.com"))
  :maintainer
  '("r0man" . "roman@burningswell.com")
  :keywords
  '("docopt" "tools" "processes")
  :url "https://github.com/r0man/docopt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
