;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260625.1757"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "7656681cb79ccc5539026e913c928aa4b73c1d9e"
  :revdesc "7656681cb79c"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
