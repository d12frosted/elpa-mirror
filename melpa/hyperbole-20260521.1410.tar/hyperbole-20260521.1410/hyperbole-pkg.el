;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260521.1410"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ffbcb2bb79ef54f8d067861be27784bfdb46add9"
  :revdesc "ffbcb2bb79ef"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
