(define-package "dirvish" "20220416.1825" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "28fb2b927d3e3f38eb3c55e145933cee05765b4c" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
