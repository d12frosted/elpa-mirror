;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elysium" "20250115.3"
  "Automatically apply LLM-created code-suggestions."
  '((emacs "27.1")
    (gptel "0.9.0"))
  :url "https://github.com/lanceberge/elysium/"
  :commit "149398813bbda0366203304bbb7db6ffe73befa6"
  :revdesc "149398813bbd"
  :authors '(("Lance Bergeron" . "bergeron.lance6@gmail.com"))
  :maintainers '(("Lance Bergeron" . "bergeron.lance6@gmail.com")))
