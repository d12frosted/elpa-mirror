(define-package "evil-textobj-tree-sitter" "20220116.1346" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1")
    (evil "1.0.0")
    (tree-sitter "0.15.0"))
  :commit "1f1decd46d1cd6e1551c25101428966d8c4a87af" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
