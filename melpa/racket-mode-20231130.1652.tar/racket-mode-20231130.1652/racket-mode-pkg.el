(define-package "racket-mode" "20231130.1652" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "3cadfa322d8036234a6427a8687869e6657c00fa" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
