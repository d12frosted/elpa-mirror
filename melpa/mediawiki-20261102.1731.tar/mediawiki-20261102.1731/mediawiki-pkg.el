;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20261102.1731"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "2a8df8a9c9c8507955c4351ceca29f671842d87a"
  :revdesc "2a8df8a9c9c8"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
