(define-package "norns" "20220821.1614" "Interactive development environment for monome norns"
  '((emacs "27.1")
    (dash "2.17.0")
    (s "1.12.0")
    (f "0.20.0")
    (request "0.3.2")
    (websocket "1.13"))
  :commit "387c7ae65383f7e9ff7ae93250ef6cf0e2b1b71a" :keywords
  '("processes" "terminals")
  :url "https://github.com/p3r7/norns.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
