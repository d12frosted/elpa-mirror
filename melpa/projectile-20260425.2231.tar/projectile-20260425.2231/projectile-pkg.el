;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260425.2231"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "6bb29099114cf68077c4a15f1bde1b323cba5fe6"
  :revdesc "6bb29099114c"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
