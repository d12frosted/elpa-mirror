(define-package "dired-open-with" "20240527.1855" "And \"Open with\" dialog for Dired"
  '((emacs "27.1")
    (s "1.13.0"))
  :commit "e75bc673d11ecc1385e53c378c8f31d85d157113" :authors
  '(("Jakub Kadlčík" . "frostyx@email.cz"))
  :maintainers
  '(("Jakub Kadlčík" . "frostyx@email.cz"))
  :maintainer
  '("Jakub Kadlčík" . "frostyx@email.cz")
  :keywords
  '("files" "dired" "xdg" "open-with")
  :url "https://github.com/FrostyX/dired-open-with")
;; Local Variables:
;; no-byte-compile: t
;; End:
