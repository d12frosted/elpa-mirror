;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261030.655"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "d929efe5a17c99b69dcb9c19173f82c18f871ff9"
  :revdesc "d929efe5a17c"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
