;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260422.1711"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "5aa950cf07c3f16528232a81dcedd792f74c0471"
  :revdesc "5aa950cf07c3"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
