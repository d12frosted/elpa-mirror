(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "23e07c0389182121332ca89b92390497aa95504e")
;; Local Variables:
;; no-byte-compile: t
;; End:
