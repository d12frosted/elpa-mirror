(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c1c20b8d29838b4e0708b768d98e2edce933d15d")
;; Local Variables:
;; no-byte-compile: t
;; End:
