(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "1f7932e3efb26a8ba58528e7e652c77780ee8108")
;; Local Variables:
;; no-byte-compile: t
;; End:
