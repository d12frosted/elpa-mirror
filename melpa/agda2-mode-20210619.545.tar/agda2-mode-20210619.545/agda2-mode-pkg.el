(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "286bbef128cb3194f8bd63cd5e497bea621c709a")
;; Local Variables:
;; no-byte-compile: t
;; End:
