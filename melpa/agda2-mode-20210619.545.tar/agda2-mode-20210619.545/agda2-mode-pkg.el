(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "376c9941f9b2723bacc5db410759a023117a2e5e")
;; Local Variables:
;; no-byte-compile: t
;; End:
