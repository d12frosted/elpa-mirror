(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "007a26fb5f7d9eb54db16484fb116d6e47c8cc5e")
;; Local Variables:
;; no-byte-compile: t
;; End:
