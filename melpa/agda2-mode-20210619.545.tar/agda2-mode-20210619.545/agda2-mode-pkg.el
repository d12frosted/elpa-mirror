(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "8e4a198399a0455ff121a224021de043ea6313d3")
;; Local Variables:
;; no-byte-compile: t
;; End:
