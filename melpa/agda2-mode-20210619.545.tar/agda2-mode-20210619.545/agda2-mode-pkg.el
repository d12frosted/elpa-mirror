(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "ef433beed7f4c22e1bff02b9a09afa2ff2cd90ac")
;; Local Variables:
;; no-byte-compile: t
;; End:
