;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260706.1711"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (compat      "31.0.0.0")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "14c16909506344606425be9e48a2a5bf0fc6f559"
  :revdesc "14c169095063")
