;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syncthing" "20250610.2306"
  "Client for Syncthing."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/emacs-syncthing"
  :commit "9d7dfde77abcd0c58abc601540a32ea97db7653b"
  :revdesc "9d7dfde77abc"
  :keywords '("convenience" "syncthing" "sync" "client" "view")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
