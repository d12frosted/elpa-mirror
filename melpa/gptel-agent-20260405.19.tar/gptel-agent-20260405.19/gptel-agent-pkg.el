;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260405.19"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "0d1534b203ea756c76d5161dfcd57ddc146f774e"
  :revdesc "0d1534b203ea"
  :keywords '("comm"))
