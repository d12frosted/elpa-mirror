;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250429.715"
  "Add UNICODE based diagrams to text files."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "5d1929ec9f5eb43ce22112801cbfa0232c21394b"
  :revdesc "5d1929ec9f5e"
  :keywords '("convenience" "text"))
