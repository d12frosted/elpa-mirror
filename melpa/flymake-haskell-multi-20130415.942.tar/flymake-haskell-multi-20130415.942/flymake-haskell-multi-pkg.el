(define-package "flymake-haskell-multi" "20130415.942" "Syntax-check haskell-mode using both ghc and hlint"
  '((flymake-easy "0.1"))
  :commit "d2c9aeffd33440d360c1ea0c5aef6d1f171599f9" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :url "https://github.com/purcell/flymake-haskell-multi")
;; Local Variables:
;; no-byte-compile: t
;; End:
