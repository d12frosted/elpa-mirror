;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260617.716"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "53f54720262fe2bc1671a06d0e9d7cd779174092"
  :revdesc "53f54720262f"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
