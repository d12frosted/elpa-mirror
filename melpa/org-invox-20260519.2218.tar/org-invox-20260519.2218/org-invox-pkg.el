;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-invox" "20260519.2218"
  "Invoice management for contractors using Org mode."
  '((emacs "27.1")
    (org   "9.0"))
  :url "https://github.com/a-manumohan/org-invox"
  :commit "ce9dc8f1f05d2965f2ceb21ea497d601ce87209d"
  :revdesc "ce9dc8f1f05d"
  :keywords '("outlines" "tools")
  :authors '(("Manu Mohan" . "me@manumohan.net"))
  :maintainers '(("Manu Mohan" . "me@manumohan.net")))
