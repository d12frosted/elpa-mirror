;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bind-key" "20141109.515"
  "Helm-source for for bind-key."
  '((bind-key "1.0")
    (helm     "1.6.4"))
  :url "https://github.com/myuhe/helm-bind-key.el"
  :commit "9da6ad8b7530e72fb4ac67be8c6a482898dddc25"
  :revdesc "9da6ad8b7530"
  :keywords '("convenience" "emulation")
  :authors '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com")))
