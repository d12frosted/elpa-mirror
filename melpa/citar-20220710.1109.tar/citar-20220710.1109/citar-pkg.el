(define-package "citar" "20220710.1109" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "3.0")
    (org "9.5")
    (citeproc "0.9"))
  :commit "96a567d70bae00118187c77051159df95c33f2dc" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/emacs-citar/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
