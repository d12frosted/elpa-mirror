;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260908.1042"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "4b9236e8cd1e9f9f3aaf5f2ebf83f1fc5995d38d"
  :revdesc "4b9236e8cd1e"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
