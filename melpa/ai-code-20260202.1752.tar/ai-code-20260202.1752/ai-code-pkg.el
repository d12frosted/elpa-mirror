;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260202.1752"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "ca1e8df31721015ed9582d8d461fa3fa706057db"
  :revdesc "ca1e8df31721"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
