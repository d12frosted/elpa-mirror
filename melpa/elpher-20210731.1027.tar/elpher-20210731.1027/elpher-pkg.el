(define-package "elpher" "20210731.1027" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "55151332e7c376f9a8766c89ae93fec84b3ead1e" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
