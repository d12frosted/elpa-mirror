;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20261114.1826"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "1ce9cd8aba6dd65b8f8b437523399a7a577d91d1"
  :revdesc "1ce9cd8aba6d"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
