;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260511.1910"
  "Lets your agent talk to Emacs."
  '((emacs       "30.1")
    (http-server "0.1.0")
    (elisp-refs  "1.6"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "49a927de2cc9afeb949b3b43ce5ef3ae31141276"
  :revdesc "49a927de2cc9"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
