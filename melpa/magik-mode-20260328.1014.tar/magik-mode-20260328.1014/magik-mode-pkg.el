;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260328.1014"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "caeb52d21d5cdb2b1e3550cd95d68568479d0dbb"
  :revdesc "caeb52d21d5c"
  :keywords '("languages"))
