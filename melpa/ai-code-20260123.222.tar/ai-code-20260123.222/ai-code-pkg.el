;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260123.222"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "7f1abb07c045a25a88353bf9b6f20494f4389b83"
  :revdesc "7f1abb07c045"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
