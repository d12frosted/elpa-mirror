(define-package "abs-mode" "20230402.1422" "Major mode for the modeling language Abs"
  '((emacs "26.1")
    (erlang "2.8")
    (maude-mode "0.3")
    (flymake "1.0")
    (yasnippet "0.14.0"))
  :commit "bfeeb70964ee03f7d29ff44959951c713318dee5" :authors
  '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainer
  '("Rudi Schlatte" . "rudi@constantly.at")
  :keywords
  '("languages")
  :url "https://github.com/abstools/abs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
