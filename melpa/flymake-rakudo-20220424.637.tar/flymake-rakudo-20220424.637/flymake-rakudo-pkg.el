;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-rakudo" "20220424.637"
  "Flymake syntax checker for Rakudo."
  '((emacs              "28.1")
    (flymake-collection "2.0.0")
    (let-alist          "1.0"))
  :url "https://github.com/Raku/flymake-rakudo"
  :commit "f8e3d03a7207876cd891174702efd572d74f2e49"
  :revdesc "f8e3d03a7207"
  :keywords '("language" "tools" "convenience")
  :authors '(("Siavash Askari Nasr" . "ciavash@proton.me"))
  :maintainers '(("Siavash Askari Nasr" . "ciavash@proton.me")))
