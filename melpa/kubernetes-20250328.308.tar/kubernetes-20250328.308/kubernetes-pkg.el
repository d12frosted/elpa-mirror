;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubernetes" "20250328.308"
  "Magit-like porcelain for Kubernetes."
  '((dash          "2.12.0")
    (magit-section "3.1.1")
    (magit-popup   "2.13.0")
    (with-editor   "3.0.4")
    (request       "0.3.2")
    (s             "1.12.0")
    (transient     "0.3.0"))
  :url "https://github.com/kubernetes-el/kubernetes-el"
  :commit "7cb9779de290b53b181f6c32099ccbe6fd5c654f"
  :revdesc "7cb9779de290"
  :keywords '("kubernetes")
  :authors '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainers '(("Chris Barrett" . "chris+emacs@walrus.cool")
                 ("Noorul Islam K M" . "noorul@noorul.com")
                 ("Jonathan Jin" . "me@jonathanj.in")))
