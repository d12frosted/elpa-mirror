(define-package "consult-project-extra" "20221013.1014" "Consult integration for project.el"
  '((emacs "27.1")
    (consult "0.17")
    (project "0.8.1"))
  :commit "9fdf45fa40471900b0b158d73c4b1521a13d47ef" :authors
  '(("Enrique Kessler Martínez"))
  :maintainers
  '(("Enrique Kessler Martínez"))
  :maintainer
  '("Enrique Kessler Martínez")
  :keywords
  '("convenience" "project" "management")
  :url "https://github.com/Qkessler/consult-project-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
