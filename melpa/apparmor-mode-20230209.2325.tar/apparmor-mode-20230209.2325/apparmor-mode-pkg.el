(define-package "apparmor-mode" "20230209.2325" "Major mode for editing AppArmor policy files"
  '((emacs "26.1"))
  :commit "3b641de4e34fb4a0594a461254f1454973b6b7aa" :authors
  '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers
  '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainer
  '("Alex Murray" . "murray.alex@gmail.com")
  :url "https://github.com/alexmurray/apparmor-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
