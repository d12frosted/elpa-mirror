;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuffer-complete-cycle" "20130813.1645"
  "Cycle through the *Completions* buffer."
  ()
  :url "https://github.com/knu/minibuffer-complete-cycle"
  :commit "3df80135887d0169e02294a948711f6dfeca4a6f"
  :revdesc "3df80135887d"
  :keywords '("completion")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org")
             ("Kevin Rodgers" . "ihs_4664@yahoo.com"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
