;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241228.719"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "d07dd190de3c1100641312e00b929f599106afd6"
  :revdesc "d07dd190de3c"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
