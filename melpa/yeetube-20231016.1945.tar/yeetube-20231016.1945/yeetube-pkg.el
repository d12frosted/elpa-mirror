(define-package "yeetube" "20231016.1945" "YouTube Front End"
  '((emacs "27.2"))
  :commit "f0ab7dfe3b020a294798dd77a8f4c194e1528db2" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.com/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
