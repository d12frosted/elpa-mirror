;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260315.802"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "3367a5d89b70bc0ff490593047ef194a55c5acd9"
  :revdesc "3367a5d89b70"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
