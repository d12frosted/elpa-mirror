(define-package "mentor" "20220922.1248" "Frontend for the rTorrent bittorrent client"
  '((emacs "25.1")
    (xml-rpc "1.6.15")
    (seq "1.11")
    (async "1.9.3"))
  :commit "f48aeeb8be00bb15d7ddd03e7d970a6f9235a125" :authors
  '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainer
  '("Stefan Kangas" . "stefankangas@gmail.com")
  :keywords
  '("comm" "processes" "bittorrent")
  :url "https://github.com/skangas/mentor")
;; Local Variables:
;; no-byte-compile: t
;; End:
