;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "20260318.2120"
  "Project-wide grep search."
  '((emacs "27.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "a2908fda33afd2b72dea645702568aa9f013b731"
  :revdesc "a2908fda33af"
  :keywords '("tools" "search" "grep" "convenience" "project"))
