;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20260804.1415"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "4bc3f18bc93574f4bd0575fc9642a5e92b60c59a"
  :revdesc "4bc3f18bc935"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
