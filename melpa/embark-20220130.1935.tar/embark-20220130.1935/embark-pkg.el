(define-package "embark" "20220130.1935" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "36872170b0a632c4ff922249648656e2a91fdd04" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
