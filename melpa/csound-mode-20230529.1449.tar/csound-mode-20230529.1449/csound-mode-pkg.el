(define-package "csound-mode" "20230529.1449" "A major mode for interacting and coding Csound"
  '((emacs "25")
    (shut-up "0.3.2")
    (multi "2.0.1")
    (dash "2.16.0")
    (highlight "0"))
  :commit "38e814bd961a7d29b9a47a8e9dc069762e18eba4" :authors
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainer
  '("Hlöðver Sigurðsson" . "hlolli@gmail.com")
  :url "https://github.com/hlolli/csound-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
