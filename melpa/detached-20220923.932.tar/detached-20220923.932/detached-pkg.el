(define-package "detached" "20220923.932" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "776f4e45216ed61cf82885dc7332e3954e369dd1" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
