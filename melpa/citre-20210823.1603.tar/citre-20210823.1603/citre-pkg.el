(define-package "citre" "20210823.1603" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "9a0dcc5dad0b0796c8febba1470db49b3e845f2b" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
