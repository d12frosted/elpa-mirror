;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-web" "20260519.2101"
  "Web interface to Elfeed."
  '((emacs        "28.1")
    (compat       "31")
    (elfeed       "3.4.2")
    (simple-httpd "1.6"))
  :url "https://github.com/emacs-elfeed/elfeed-web"
  :commit "48ff7b095dcc065ae937b3f364ef3edb6deee97a"
  :revdesc "48ff7b095dcc"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
