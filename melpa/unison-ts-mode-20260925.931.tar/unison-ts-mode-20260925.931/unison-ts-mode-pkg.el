;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-ts-mode" "20260925.931"
  "Tree-sitter support for Unison."
  '((emacs "29.1"))
  :url "https://github.com/fmguerreiro/unison-ts-mode"
  :commit "76e1ad8bbda8f3dd1a48f64ea2bd50043bd6a63c"
  :revdesc "76e1ad8bbda8"
  :keywords '("languages" "unison" "tree-sitter")
  :authors '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com"))
  :maintainers '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com")))
