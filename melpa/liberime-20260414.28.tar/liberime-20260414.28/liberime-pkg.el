;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260414.28"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "43069396e9a5ccbbfcb7aa7bbff47b84b482d576"
  :revdesc "43069396e9a5"
  :keywords '("convenience" "chinese" "input-method" "rime"))
