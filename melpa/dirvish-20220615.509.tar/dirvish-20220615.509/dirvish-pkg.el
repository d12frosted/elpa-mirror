(define-package "dirvish" "20220615.509" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "96fbfee450f2283a01d58ac8f2f8e700b798b835" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
