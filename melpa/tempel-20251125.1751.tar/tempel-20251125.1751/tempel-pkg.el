;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20251125.1751"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "f89a57ac413892c03a46f36e62b219434ba6f850"
  :revdesc "f89a57ac4138"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
