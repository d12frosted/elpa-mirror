(define-package "literate-calc-mode" "20230916.611" "Inline results from calc"
  '((emacs "25.1")
    (dash "2.19.1")
    (s "1.12.0"))
  :commit "3beadbeccdce30da7957a219690ff653f2f6c4fc" :authors
  '(("Robin Schroer"))
  :maintainers
  '(("Robin Schroer"))
  :maintainer
  '("Robin Schroer")
  :keywords
  '("calc" "languages" "tools")
  :url "https://github.com/sulami/literate-calc-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
