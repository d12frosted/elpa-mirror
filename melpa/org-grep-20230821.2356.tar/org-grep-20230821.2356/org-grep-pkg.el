;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-grep" "20230821.2356"
  "Kind of M-x rgrep adapted for Org mode."
  '((emacs "26.1"))
  :url "https://sr.ht/~minshall/org-grep/"
  :commit "64d23c2ca11ca68db85fc2c500377c9151e8e40b"
  :revdesc "64d23c2ca11c"
  :authors '(("François Pinard" . "pinard@iro.umontreal.ca"))
  :maintainers '(("Greg Minshall" . "minshall@umich.edu")))
