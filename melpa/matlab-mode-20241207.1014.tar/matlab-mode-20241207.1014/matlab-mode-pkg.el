;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241207.1014"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "7f2a48d85c4a0e87ebe5ed117f8351dd668444e3"
  :revdesc "7f2a48d85c4a"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")))
