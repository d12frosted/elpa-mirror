(define-package "paradox" "20190413.2355" "A modern Packages Menu. Colored, with package ratings, and customizable."
  '((emacs "24.4")
    (seq "1.7")
    (let-alist "1.0.3")
    (spinner "1.7.3")
    (hydra "0.13.2"))
  :commit "d24fe4a329a939ffa1983886d77a6937e05149e4" :authors
  '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainer
  '("Artur Malabarba" . "emacs@endlessparentheses.com")
  :keywords
  '("package" "packages")
  :url "https://github.com/Malabarba/paradox")
;; Local Variables:
;; no-byte-compile: t
;; End:
