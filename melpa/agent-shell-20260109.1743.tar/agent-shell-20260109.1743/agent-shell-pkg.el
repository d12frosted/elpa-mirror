;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260109.1743"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "cb0f923e2445323f9ff2f84792b25366a3e2d5a9"
  :revdesc "cb0f923e2445")
