(define-package "meow" "20220124.1022" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "2561c79f3021f4959d135c56dc212e7eb972289c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
