;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiktionary-bro" "20260824.2344"
  "Lookup Wiktionary entries."
  '((emacs   "29.4")
    (request "0.3.3"))
  :url "https://github.com/agzam/wiktionary-bro.el"
  :commit "3e76e8171e306b6b1105b1dd63cc27f673b5f204"
  :revdesc "3e76e8171e30"
  :keywords '("convenience" "multimedia")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
