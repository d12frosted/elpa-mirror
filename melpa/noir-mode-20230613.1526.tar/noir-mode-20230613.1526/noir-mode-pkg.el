(define-package "noir-mode" "20230613.1526" "Description"
  '((emacs "25.1")
    (rust-mode "1.0.5"))
  :commit "412a7807e569ee08fff8fe1197b699fb29c0f49d" :authors
  '(("Hamza Hamud"))
  :maintainers
  '(("Hamza Hamud"))
  :maintainer
  '("Hamza Hamud")
  :keywords
  '("languages")
  :url "https://github.com/hhamud/noir-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
