;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20241216.457"
  "Beautify Org Links."
  '((emacs      "29.1")
    (org        "9.7.14")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "0f6c2e97728f847c46b87758f8ea7a7339d5e693"
  :revdesc "0f6c2e97728f"
  :keywords '("hypermedia"))
