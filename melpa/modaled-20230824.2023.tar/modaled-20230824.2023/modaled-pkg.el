(define-package "modaled" "20230824.2023" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "6cece47abd2a24b0f3238ae1789c05cc8b35ccb6" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
