(define-package "buttercup" "20221016.2239" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "001adc064170b1e5beff3bc5a50c40f6c1949bbb" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
