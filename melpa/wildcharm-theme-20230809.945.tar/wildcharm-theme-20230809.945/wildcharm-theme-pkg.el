(define-package "wildcharm-theme" "20230809.945" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "cc76e709b634eacb744fc19442418d54e65ad765" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
