;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260911.42"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "9716a9e6cdaf72429fcab3f4eae6e076d966404e"
  :revdesc "9716a9e6cdaf")
