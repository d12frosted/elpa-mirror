;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "20251118.1455"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "5961f5f3bc22611d14469447cf5115d0539aeee4"
  :revdesc "5961f5f3bc22")
