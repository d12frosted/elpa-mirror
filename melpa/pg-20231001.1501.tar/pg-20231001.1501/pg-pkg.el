(define-package "pg" "20231001.1501" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "26.1"))
  :commit "842c3b88abaa4bbe7300db84d3c70e1719f5659d" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
