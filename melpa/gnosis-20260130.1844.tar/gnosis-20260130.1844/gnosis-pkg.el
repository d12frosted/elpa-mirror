;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260130.1844"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "a30e09a3ea4a9bf9d6997b8ca2c16ee6e62717ab"
  :revdesc "a30e09a3ea4a"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
