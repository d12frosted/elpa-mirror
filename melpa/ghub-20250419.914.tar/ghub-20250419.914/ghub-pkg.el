;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20250419.914"
  "Client libraries for Git forge APIs."
  '((emacs     "29.1")
    (compat    "30.0.2.0")
    (let-alist "1.0.6")
    (llama     "0.6.1")
    (treepy    "0.1.2"))
  :url "https://github.com/magit/ghub"
  :commit "7467c905cd11199538e96403d1c58ae3b268d852"
  :revdesc "7467c905cd11"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
