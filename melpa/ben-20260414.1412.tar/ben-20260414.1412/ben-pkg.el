;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ben" "20260414.1412"
  "Asynchronous buffer-local environments via `direnv'."
  '((emacs      "29.1")
    (inheritenv "0.1")
    (seq        "2.24"))
  :url "https://codeberg.org/pastor/ben.el"
  :commit "11e08794b1f5cd933a38cd6a5ecf9aba962dc669"
  :revdesc "11e08794b1f5"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com")
             ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")
                 ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
