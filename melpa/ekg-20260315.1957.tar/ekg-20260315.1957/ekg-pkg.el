;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260315.1957"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "75cb9e31c10b34beb17b244c335decc008a8727e"
  :revdesc "75cb9e31c10b"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
