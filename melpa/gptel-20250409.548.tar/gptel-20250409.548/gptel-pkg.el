;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250409.548"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "c818ce3426a7ebac78c737cf6106282f26dcbb80"
  :revdesc "c818ce3426a7"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
