(define-package "kubernetes" "20211216.644" "Magit-like porcelain for Kubernetes"
  '((emacs "25.1")
    (dash "2.12.0")
    (magit-section "3.1.1")
    (magit-popup "2.13.0")
    (with-editor "3.0.4")
    (transient "0.3.0"))
  :commit "d32522d3c77706bf1fc53d55d87fdf33eb093513" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool")
  :keywords
  '("kubernetes")
  :url "https://github.com/kubernetes-el/kubernetes-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
