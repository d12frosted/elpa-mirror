;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "20250707.1006"
  "Slack client."
  '((websocket "1.12")
    (request   "0.3.2")
    (circe     "2.11")
    (alert     "1.2")
    (emojify   "1.2.1")
    (emacs     "25.1")
    (dash      "2.19.1")
    (s         "1.13.1")
    (ts        "0.3"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "eaca139eac3eb75178b9770eed62422aa074e8c4"
  :revdesc "eaca139eac3e"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
