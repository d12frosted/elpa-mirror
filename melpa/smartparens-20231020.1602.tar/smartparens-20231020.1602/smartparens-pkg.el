(define-package "smartparens" "20231020.1602" "Automatic insertion, wrapping and paredit-like navigation with user defined pairs."
  '((dash "2.13.0")
    (cl-lib "0.3"))
  :commit "dd22a3e6c5219a0905fc306fb16210cc36fd8a5b" :authors
  '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matus Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("abbrev" "convenience" "editing")
  :url "https://github.com/Fuco1/smartparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
