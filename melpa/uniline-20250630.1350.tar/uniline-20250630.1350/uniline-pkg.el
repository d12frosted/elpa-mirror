;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250630.1350"
  "Add ╭─╴UNICODE╶─╮ based ╭─╴diagrams╶─╮ to ╭▶╴text files╶●╮."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "aa5f054bfc02486376f1f68b0c7cc0df28a361db"
  :revdesc "aa5f054bfc02"
  :keywords '("convenience" "text"))
