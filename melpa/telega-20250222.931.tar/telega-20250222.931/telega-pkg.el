;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250222.931"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "8327a140213df11c0085eca02700b962dbf03930"
  :revdesc "8327a140213d"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
