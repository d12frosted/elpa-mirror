;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260321.144"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "0c33fc7311d8c5bdb0b7d118853d3f19e3268bff"
  :revdesc "0c33fc7311d8"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
