(define-package "company" "20220101.38" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "699a45ccdacb0ed2e1a01483a04ea2bce87068d0" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
