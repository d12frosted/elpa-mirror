;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsql" "20260601.1538"
  "High-level SQL database front-end."
  '((emacs "28.1"))
  :url "https://github.com/magit/emacsql"
  :commit "af71afdd0866defedd65a54059ca1644f68de9fc"
  :revdesc "af71afdd0866"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev")))
