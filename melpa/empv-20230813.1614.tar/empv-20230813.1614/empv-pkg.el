(define-package "empv" "20230813.1614" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0"))
  :commit "fa8cec7467ef70baf2642970819b576524882bb3" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
