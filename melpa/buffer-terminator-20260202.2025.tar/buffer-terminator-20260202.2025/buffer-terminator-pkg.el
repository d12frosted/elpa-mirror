;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260202.2025"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "1f9867766da371f8137a4e6b1177730cb8c4550d"
  :revdesc "1f9867766da3"
  :keywords '("convenience"))
