(define-package "f" "20230112.1114" "Modern API for working with files and directories"
  '((emacs "24.1")
    (s "1.7.0")
    (dash "2.2.0"))
  :commit "36720e8622ad0207c4112f62656f380588395cfb" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Lucien Cartier-Tilet" . "lucien@phundrak.com")
  :keywords
  '("files" "directories")
  :url "http://github.com/rejeep/f.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
