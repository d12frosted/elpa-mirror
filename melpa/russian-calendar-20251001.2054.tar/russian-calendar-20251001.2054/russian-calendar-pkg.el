;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20251001.2054"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "23bc82093556a2bd045621c9964ba9162aac9937"
  :revdesc "23bc82093556"
  :keywords '("calendar" "holidays"))
