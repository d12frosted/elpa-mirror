(define-package "pocket-reader" "20230904.402" "Client for Pocket reading list"
  '((emacs "25.1")
    (dash "2.13.0")
    (kv "0.0.19")
    (pocket-lib "0.1")
    (s "1.10")
    (ov "1.0.6")
    (rainbow-identifiers "0.2.2")
    (org-web-tools "0.1")
    (ht "2.2"))
  :commit "383aaf04c81fcc798580c1847f4c52b3dae28f44" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("pocket")
  :url "https://github.com/alphapapa/pocket-reader.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
