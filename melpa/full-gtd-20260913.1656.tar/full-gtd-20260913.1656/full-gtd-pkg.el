;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "20260913.1656"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "91a4bea06d93cfec81657d9dec8688f2b70e33ba"
  :revdesc "91a4bea06d93"
  :keywords '("outlines" "tools" "convenience" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
