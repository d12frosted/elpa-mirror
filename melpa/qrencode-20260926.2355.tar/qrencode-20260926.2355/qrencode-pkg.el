;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "20260926.2355"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "06b9be56aff40072b54d211261998b24f0c3cf9b"
  :revdesc "06b9be56aff4"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
