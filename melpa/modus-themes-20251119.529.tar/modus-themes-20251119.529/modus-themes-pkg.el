;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251119.529"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "53717d16070bf83eaa0259d6cadfd995da928ea4"
  :revdesc "53717d16070b"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
