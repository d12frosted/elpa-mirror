;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260629.848"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "5b85690d87ca3fdbfa97b8ab7b48d2fa318d7ba7"
  :revdesc "5b85690d87ca"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
