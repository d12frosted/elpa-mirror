(define-package "flymake-collection" "20221113.1" "Collection of checkers for flymake, bringing flymake to the level of flycheck"
  '((emacs "28.1")
    (let-alist "1.0")
    (flymake "1.2.1"))
  :commit "274e5ec3e614e73fd0d7c3e1ffc652461bf5b5f3" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("language" "tools")
  :url "https://github.com/mohkale/flymake-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
