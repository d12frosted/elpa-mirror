(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b6b0887c9b0a2bc793ec4a9d7bd753485025550f")
;; Local Variables:
;; no-byte-compile: t
;; End:
