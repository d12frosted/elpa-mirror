(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ce227d91d83f5214215596e53cd8b4deb4210218")
;; Local Variables:
;; no-byte-compile: t
;; End:
