(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "cae14adeb8a21e05166d6813e1efa34848e71a49")
;; Local Variables:
;; no-byte-compile: t
;; End:
