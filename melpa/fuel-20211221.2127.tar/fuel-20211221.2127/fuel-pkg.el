(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ab92b86d8b370fdd30c83d329178e4ee2fd2566f")
;; Local Variables:
;; no-byte-compile: t
;; End:
