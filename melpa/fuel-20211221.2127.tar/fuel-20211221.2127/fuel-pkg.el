(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "73d221dd055d8546d525a8c61adcab8d481ab5ad")
;; Local Variables:
;; no-byte-compile: t
;; End:
