(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a92e0ccd14bedc50716fdc0e680ddfdb64fb2a50")
;; Local Variables:
;; no-byte-compile: t
;; End:
