(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "997daa0fac325159078f62cc159643f851994ddb")
;; Local Variables:
;; no-byte-compile: t
;; End:
