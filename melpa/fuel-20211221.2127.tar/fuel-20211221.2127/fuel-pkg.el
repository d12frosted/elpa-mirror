(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "05ea137b6c6b472dbfd9d6715a8437392ef8d7b5")
;; Local Variables:
;; no-byte-compile: t
;; End:
