(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "28ca8117c76685f87b24ec8a2ecf1ccd4b0e3255")
;; Local Variables:
;; no-byte-compile: t
;; End:
