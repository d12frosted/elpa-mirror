(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "409b07e8722cd58b28dd40e13ddf3cbe86d95985")
;; Local Variables:
;; no-byte-compile: t
;; End:
