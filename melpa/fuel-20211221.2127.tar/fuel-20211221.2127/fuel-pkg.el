(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ccbac0d593fcb0e7817ec4a01212e976bbd55d73")
;; Local Variables:
;; no-byte-compile: t
;; End:
