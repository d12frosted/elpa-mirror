(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "6ac61fa697c11688177899105abdf9dde6336713")
;; Local Variables:
;; no-byte-compile: t
;; End:
