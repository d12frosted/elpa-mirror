(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "50123e587c1026efe82c5053d9cb947e6ef51c45")
;; Local Variables:
;; no-byte-compile: t
;; End:
