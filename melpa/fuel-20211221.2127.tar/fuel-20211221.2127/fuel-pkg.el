(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "09e6ae236ae94fe845f26d0e2b1f40b666ef3791")
;; Local Variables:
;; no-byte-compile: t
;; End:
