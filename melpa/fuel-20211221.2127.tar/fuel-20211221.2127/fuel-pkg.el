(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2a9d89fe742c5ddd5f477eb868dbbbbe2b26cde1")
;; Local Variables:
;; no-byte-compile: t
;; End:
