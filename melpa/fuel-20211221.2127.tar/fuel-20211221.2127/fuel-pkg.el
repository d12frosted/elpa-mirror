(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "6937faa9c10d5884a6d57b14e67d7dc78c9437fd")
;; Local Variables:
;; no-byte-compile: t
;; End:
