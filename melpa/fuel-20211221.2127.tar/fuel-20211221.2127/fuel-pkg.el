(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5219bcf400922c32f56dc0bd1219bcbc42459496")
;; Local Variables:
;; no-byte-compile: t
;; End:
