(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a52dd48b04e9131dacf944e6af32798e9779ccf1")
;; Local Variables:
;; no-byte-compile: t
;; End:
