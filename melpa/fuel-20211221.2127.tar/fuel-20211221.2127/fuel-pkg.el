(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3a61666bf9e54036287950b71c0bb43c94543304")
;; Local Variables:
;; no-byte-compile: t
;; End:
