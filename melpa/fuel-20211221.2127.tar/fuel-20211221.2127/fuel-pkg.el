(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c49a30d587a33d3800773cb345d208049f998a02")
;; Local Variables:
;; no-byte-compile: t
;; End:
