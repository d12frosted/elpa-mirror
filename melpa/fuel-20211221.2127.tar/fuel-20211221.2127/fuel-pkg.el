(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "714c6d2b9464e193e24cb45fab1961d96a9d422c")
;; Local Variables:
;; no-byte-compile: t
;; End:
