(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c530fc7dfa0521bc1670c4f9bfc40a14b49be677")
;; Local Variables:
;; no-byte-compile: t
;; End:
