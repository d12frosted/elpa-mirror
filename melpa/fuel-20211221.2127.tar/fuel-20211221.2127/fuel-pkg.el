(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f16f97ba5905e285d914a9e0dc9291728c6d2c06")
;; Local Variables:
;; no-byte-compile: t
;; End:
