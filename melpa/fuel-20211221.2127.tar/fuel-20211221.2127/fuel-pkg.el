(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b5cadec0cf55412112bc95a4dd19ba1158993dc8")
;; Local Variables:
;; no-byte-compile: t
;; End:
