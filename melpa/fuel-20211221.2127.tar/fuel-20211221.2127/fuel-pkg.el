(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1ce2e105919d17c3582612e744d59f0bac758671")
;; Local Variables:
;; no-byte-compile: t
;; End:
