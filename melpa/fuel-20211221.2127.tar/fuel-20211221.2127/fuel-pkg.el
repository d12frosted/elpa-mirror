(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1b9590d28f71ae0ffe6ee26e5275db2fae59f084")
;; Local Variables:
;; no-byte-compile: t
;; End:
