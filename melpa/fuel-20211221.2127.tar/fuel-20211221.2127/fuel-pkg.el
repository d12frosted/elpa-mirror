(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1675f6de9f8134b9cda3c191642cd16534f5578b")
;; Local Variables:
;; no-byte-compile: t
;; End:
