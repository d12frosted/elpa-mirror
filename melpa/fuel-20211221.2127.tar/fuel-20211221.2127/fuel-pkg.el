(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b532a1113decfc97228e6d23d495c2b92f556ab4")
;; Local Variables:
;; no-byte-compile: t
;; End:
