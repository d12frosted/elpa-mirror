(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "6cd4e60af78d7a086891011978d69edb1ea38b7b")
;; Local Variables:
;; no-byte-compile: t
;; End:
