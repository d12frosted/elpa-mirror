(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "8389b11258d0850a357afe4f52b541f917496a1f")
;; Local Variables:
;; no-byte-compile: t
;; End:
