(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "fc74498a9c4b6b1e7570f1d903272348be4bc05f")
;; Local Variables:
;; no-byte-compile: t
;; End:
