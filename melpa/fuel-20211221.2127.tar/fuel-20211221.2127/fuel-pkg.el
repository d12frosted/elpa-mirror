(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "631610a8e164447b51d1fa94081c06a39494f059")
;; Local Variables:
;; no-byte-compile: t
;; End:
