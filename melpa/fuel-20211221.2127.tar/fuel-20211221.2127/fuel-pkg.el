(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f56a1b318a8201cce287723d72bd79540c9a4ced")
;; Local Variables:
;; no-byte-compile: t
;; End:
