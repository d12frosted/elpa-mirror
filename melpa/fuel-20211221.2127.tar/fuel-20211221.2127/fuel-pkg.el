(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1c870d7a156494141fab8bf776e0131367b91298")
;; Local Variables:
;; no-byte-compile: t
;; End:
