(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "08e1de1d5afffa5ceeac08549abb3a5debbbe7a4")
;; Local Variables:
;; no-byte-compile: t
;; End:
