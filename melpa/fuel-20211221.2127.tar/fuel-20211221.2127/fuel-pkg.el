(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "041430cda31c73fd51d7c16e736dcf08db13eb11")
;; Local Variables:
;; no-byte-compile: t
;; End:
