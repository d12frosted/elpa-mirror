(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "6b9dd453879eeaf33540f2f539458c7951fe794a")
;; Local Variables:
;; no-byte-compile: t
;; End:
