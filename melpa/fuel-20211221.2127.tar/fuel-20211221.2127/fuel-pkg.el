(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d5bb13b9880bcee669738426adaa10b429673c00")
;; Local Variables:
;; no-byte-compile: t
;; End:
