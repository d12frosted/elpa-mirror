(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a4441c09afdfca90fde06d43b93a24a225f693c0")
;; Local Variables:
;; no-byte-compile: t
;; End:
