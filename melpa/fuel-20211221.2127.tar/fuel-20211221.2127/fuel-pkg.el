(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f7ba514a709cada4a1cc8d4c2799ba55d7c1daa5")
;; Local Variables:
;; no-byte-compile: t
;; End:
