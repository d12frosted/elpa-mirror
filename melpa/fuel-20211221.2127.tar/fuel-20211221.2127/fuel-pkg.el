(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "0bc380612c5df92ee013902a442fcf440115d4c0")
;; Local Variables:
;; no-byte-compile: t
;; End:
