(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4ae4164a85eb1c1e8c6a7cb726027127481f2769")
;; Local Variables:
;; no-byte-compile: t
;; End:
