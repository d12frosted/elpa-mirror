(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "50266286b9f98e333a3c82c0183d17d160aec649")
;; Local Variables:
;; no-byte-compile: t
;; End:
