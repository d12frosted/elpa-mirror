(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "cd194eebbf3bfc8ab795b41f99613faae342df34")
;; Local Variables:
;; no-byte-compile: t
;; End:
