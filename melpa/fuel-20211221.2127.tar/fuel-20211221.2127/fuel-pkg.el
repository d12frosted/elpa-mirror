(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ca33bca4e93d48e3e3f06785c3ffb028182f32c5")
;; Local Variables:
;; no-byte-compile: t
;; End:
