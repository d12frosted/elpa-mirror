(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1249d293d069b3ced06b48f836931984a49d0412")
;; Local Variables:
;; no-byte-compile: t
;; End:
