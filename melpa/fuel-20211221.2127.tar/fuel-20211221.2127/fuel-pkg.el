(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "8c1d95871c63296dd8ceff1d6b8652367a4daecf")
;; Local Variables:
;; no-byte-compile: t
;; End:
