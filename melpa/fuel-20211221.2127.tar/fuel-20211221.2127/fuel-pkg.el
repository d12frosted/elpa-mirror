(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4ae6e6f147dfb429aefe9ccf0c1cd506ee96d981")
;; Local Variables:
;; no-byte-compile: t
;; End:
