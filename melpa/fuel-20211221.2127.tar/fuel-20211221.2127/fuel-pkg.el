(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "659aca75802afaf5bc92ca1ce8b8eb3620321395")
;; Local Variables:
;; no-byte-compile: t
;; End:
