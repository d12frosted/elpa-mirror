(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3052215fee7721e68b76e846e8b6d0baa3611252")
;; Local Variables:
;; no-byte-compile: t
;; End:
