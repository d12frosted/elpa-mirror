(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "bab4d06982e17621f2581d194038a6995ae5d1ed")
;; Local Variables:
;; no-byte-compile: t
;; End:
