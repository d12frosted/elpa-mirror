(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3175af6a779e9f112c9cc8fb7f7cb930ac4061ca")
;; Local Variables:
;; no-byte-compile: t
;; End:
