(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ea4d6790b9519d96b897bdb800f33410815588e4")
;; Local Variables:
;; no-byte-compile: t
;; End:
