(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a93a047aa0b9bcf6b08907b5041a1064695e4817")
;; Local Variables:
;; no-byte-compile: t
;; End:
