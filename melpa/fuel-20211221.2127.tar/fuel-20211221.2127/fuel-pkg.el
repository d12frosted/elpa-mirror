(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b33c7decc4e51858af82f627b56011cbae4a6bc8")
;; Local Variables:
;; no-byte-compile: t
;; End:
