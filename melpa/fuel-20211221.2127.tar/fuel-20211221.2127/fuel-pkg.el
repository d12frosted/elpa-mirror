(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b0f39e3617f5adf8ac9ecdbdaa6b0ee997cab020")
;; Local Variables:
;; no-byte-compile: t
;; End:
