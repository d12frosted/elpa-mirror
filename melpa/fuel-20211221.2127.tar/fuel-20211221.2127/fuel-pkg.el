(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4e7b820b40daaaca93d4ee40172e0bdf2e229898")
;; Local Variables:
;; no-byte-compile: t
;; End:
