(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3b1c0fb52c905dd0aab5624b9d249fa1b6d04eb7")
;; Local Variables:
;; no-byte-compile: t
;; End:
