(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a6eeda90eaabb759ed9a6a79771b133c6d56c25d")
;; Local Variables:
;; no-byte-compile: t
;; End:
