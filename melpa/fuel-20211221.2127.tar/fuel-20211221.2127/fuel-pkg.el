(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5dadec4612aafb99a6640dce71c081f5d19e0a42")
;; Local Variables:
;; no-byte-compile: t
;; End:
