(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ac7e79ae9b625d4c3067ed85cb170714a5425c59")
;; Local Variables:
;; no-byte-compile: t
;; End:
