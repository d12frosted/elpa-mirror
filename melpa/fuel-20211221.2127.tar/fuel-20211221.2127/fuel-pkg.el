(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5af79078c6bcf925c2eb18feb7686b5aad63a966")
;; Local Variables:
;; no-byte-compile: t
;; End:
