(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "420157ce9a3c7c4a487e7191c281b8fe34dec39b")
;; Local Variables:
;; no-byte-compile: t
;; End:
