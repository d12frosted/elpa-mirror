(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "45535b482bf3e9c9e0d83d8a42ee5ff871afb0b1")
;; Local Variables:
;; no-byte-compile: t
;; End:
