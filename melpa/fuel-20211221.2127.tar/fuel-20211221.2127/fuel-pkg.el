(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1a38af18faa1cb6cbdc53b4970ce16bbc3ab60db")
;; Local Variables:
;; no-byte-compile: t
;; End:
