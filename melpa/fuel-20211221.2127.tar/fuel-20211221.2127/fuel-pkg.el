(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4984d1766c441d1dc2fa74f4f1f5ec794556c045")
;; Local Variables:
;; no-byte-compile: t
;; End:
