(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "258839ae638ce4eabcce6fa8a854c0f457f79f7c")
;; Local Variables:
;; no-byte-compile: t
;; End:
