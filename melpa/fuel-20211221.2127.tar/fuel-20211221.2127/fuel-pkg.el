(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f6131749259f997b222b0cd44bd2b055a71cd39c")
;; Local Variables:
;; no-byte-compile: t
;; End:
