(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "43113a3b4773da6553da84c6bbe9ef493099e3c0")
;; Local Variables:
;; no-byte-compile: t
;; End:
