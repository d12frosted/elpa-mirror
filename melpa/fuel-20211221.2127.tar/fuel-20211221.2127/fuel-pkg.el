(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "628f578f915da7b3cd66a0f72c50aaa571248936")
;; Local Variables:
;; no-byte-compile: t
;; End:
