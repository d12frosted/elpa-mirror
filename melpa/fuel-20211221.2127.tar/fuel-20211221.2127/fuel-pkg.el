(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "e1568f285d9e87af7f57fcce6938c5876c1c034f")
;; Local Variables:
;; no-byte-compile: t
;; End:
