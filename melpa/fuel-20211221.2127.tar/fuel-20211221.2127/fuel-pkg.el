(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "afd782663dbe84054efb2205d18bec1e0b61eb04")
;; Local Variables:
;; no-byte-compile: t
;; End:
