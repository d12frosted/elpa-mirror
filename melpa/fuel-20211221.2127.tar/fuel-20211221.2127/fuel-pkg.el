(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b7b433a6cd407e7cc2978fcee6385c9035127c54")
;; Local Variables:
;; no-byte-compile: t
;; End:
