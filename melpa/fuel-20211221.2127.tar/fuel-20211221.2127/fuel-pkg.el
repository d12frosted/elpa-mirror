(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "013071538c8e5ab1ebffc5ceff39acfce4637155")
;; Local Variables:
;; no-byte-compile: t
;; End:
