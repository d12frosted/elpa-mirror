(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d78d0d2f6c5da33e6da509f217a80a14012782ee")
;; Local Variables:
;; no-byte-compile: t
;; End:
