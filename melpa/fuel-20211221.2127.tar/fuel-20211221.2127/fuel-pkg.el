(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c43972203189a2a3743146b30b39b57c68b572d3")
;; Local Variables:
;; no-byte-compile: t
;; End:
