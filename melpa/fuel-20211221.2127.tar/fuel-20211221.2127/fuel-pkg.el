(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "bf98bf3bf7436e8c7aa0ed7e6d523a56b4ef7d12")
;; Local Variables:
;; no-byte-compile: t
;; End:
