(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "78c421e19e35a0aebf0d0babd045f3cb79ddd819")
;; Local Variables:
;; no-byte-compile: t
;; End:
