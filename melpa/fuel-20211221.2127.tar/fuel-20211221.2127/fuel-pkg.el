(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "e8ebddf48ca3cc611c6d7e3afc13cb1bb5b1fd1b")
;; Local Variables:
;; no-byte-compile: t
;; End:
