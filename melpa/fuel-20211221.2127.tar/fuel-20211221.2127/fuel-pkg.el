(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "59466a891c3f387f2b287b43b7091ecb361a9a57")
;; Local Variables:
;; no-byte-compile: t
;; End:
