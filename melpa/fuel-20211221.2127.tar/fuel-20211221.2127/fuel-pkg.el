(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "726a8b784b91bb5e5d1ee01af46a6b91cf0ff438")
;; Local Variables:
;; no-byte-compile: t
;; End:
