(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3e69b18d360e3d38de015d1c123c7c4e9f9d8b87")
;; Local Variables:
;; no-byte-compile: t
;; End:
