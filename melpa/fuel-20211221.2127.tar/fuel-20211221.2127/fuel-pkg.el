(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ab2670392ab4b1064c20c5f6ca4ed78868f27cb2")
;; Local Variables:
;; no-byte-compile: t
;; End:
