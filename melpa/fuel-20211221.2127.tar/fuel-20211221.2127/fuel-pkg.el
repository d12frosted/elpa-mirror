(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "667bb341dc99ccb78dd67832fa296a87936e51e9")
;; Local Variables:
;; no-byte-compile: t
;; End:
