(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9e08ee114e5d99dba0360a52795ba191ae0f8ec1")
;; Local Variables:
;; no-byte-compile: t
;; End:
