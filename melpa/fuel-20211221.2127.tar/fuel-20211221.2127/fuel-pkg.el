(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "72e409138e38f663954e0031759bd8185ef2c67f")
;; Local Variables:
;; no-byte-compile: t
;; End:
