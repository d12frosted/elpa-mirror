(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5da98729265f023e624cbb2e84f19bd97258fee2")
;; Local Variables:
;; no-byte-compile: t
;; End:
