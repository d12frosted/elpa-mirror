(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1aeafdb87bb8937035d06c59d8c997a58b5e53ae")
;; Local Variables:
;; no-byte-compile: t
;; End:
