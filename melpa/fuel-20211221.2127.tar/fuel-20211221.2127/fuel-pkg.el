(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "56e08eabfad4d70ec9b5bfe125798ce16396fe40")
;; Local Variables:
;; no-byte-compile: t
;; End:
