(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "095530edc65725c5b93606fb4eb7fdd95d9d3495")
;; Local Variables:
;; no-byte-compile: t
;; End:
