(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "85c7bb51bea30687fb972de65994ce0166c1e32f")
;; Local Variables:
;; no-byte-compile: t
;; End:
