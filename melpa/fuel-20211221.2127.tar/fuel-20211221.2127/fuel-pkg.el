(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d48a2b195b0536b4d7ff44280afe731b13e2106b")
;; Local Variables:
;; no-byte-compile: t
;; End:
