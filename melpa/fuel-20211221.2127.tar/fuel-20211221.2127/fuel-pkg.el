(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "44dcd739d6a369aaae8b358607cbdca332cdb411")
;; Local Variables:
;; no-byte-compile: t
;; End:
