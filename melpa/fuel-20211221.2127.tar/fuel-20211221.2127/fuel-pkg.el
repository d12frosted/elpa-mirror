(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "6d147943f7166557d30f19cc54daa74fd1ce3529")
;; Local Variables:
;; no-byte-compile: t
;; End:
