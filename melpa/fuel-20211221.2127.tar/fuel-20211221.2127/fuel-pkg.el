(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "64c0082cd17d7e32d97e490819075c859326c900")
;; Local Variables:
;; no-byte-compile: t
;; End:
