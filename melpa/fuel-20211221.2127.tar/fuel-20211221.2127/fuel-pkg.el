(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "44d403230f8ccca79c95116ee57504a134e9e502")
;; Local Variables:
;; no-byte-compile: t
;; End:
