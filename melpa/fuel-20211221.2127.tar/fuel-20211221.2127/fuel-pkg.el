(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ea044aeeecf026db29fea9a31ea0d6674f2456e3")
;; Local Variables:
;; no-byte-compile: t
;; End:
