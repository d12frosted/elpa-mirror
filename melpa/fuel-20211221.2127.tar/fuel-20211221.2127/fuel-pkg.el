(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3279067f6cc61c5333f339735b2ec50747de6fed")
;; Local Variables:
;; no-byte-compile: t
;; End:
