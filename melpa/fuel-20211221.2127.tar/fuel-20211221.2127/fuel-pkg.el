(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "93f73227da0573d457872c9232bb4993a5e0edae")
;; Local Variables:
;; no-byte-compile: t
;; End:
