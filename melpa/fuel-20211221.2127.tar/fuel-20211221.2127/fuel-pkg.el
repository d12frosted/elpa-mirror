(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "65796a3e3121bc0212a42fc0ac0cb4d1b8c7da7d")
;; Local Variables:
;; no-byte-compile: t
;; End:
