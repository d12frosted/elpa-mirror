(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a12051582288923c9e66845e1f44b216e614b108")
;; Local Variables:
;; no-byte-compile: t
;; End:
