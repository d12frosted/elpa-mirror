(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4c1ea52d1531b492ce880e77fb3e9623a900fdf1")
;; Local Variables:
;; no-byte-compile: t
;; End:
