(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b90d529eacb643421991f94288151e72ed573b55")
;; Local Variables:
;; no-byte-compile: t
;; End:
