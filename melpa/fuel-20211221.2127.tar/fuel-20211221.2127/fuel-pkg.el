(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1b09f93777bb30cffc7af9314a51446bf9b06408")
;; Local Variables:
;; no-byte-compile: t
;; End:
