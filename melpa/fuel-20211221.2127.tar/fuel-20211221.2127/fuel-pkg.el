(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "48bd065e19c341ffd853241a51a5faf9fb776de6")
;; Local Variables:
;; no-byte-compile: t
;; End:
