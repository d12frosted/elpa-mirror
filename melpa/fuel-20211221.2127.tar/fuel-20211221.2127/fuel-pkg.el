(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9bcc653677e6314d82c049250885cf5e8cbc58f4")
;; Local Variables:
;; no-byte-compile: t
;; End:
