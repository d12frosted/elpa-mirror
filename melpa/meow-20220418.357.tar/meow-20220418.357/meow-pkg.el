(define-package "meow" "20220418.357" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "6fbf6b192c9d348ff3599af2c153d4c7d4254224" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
