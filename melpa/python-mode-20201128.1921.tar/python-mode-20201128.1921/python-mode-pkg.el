(define-package "python-mode" "20201128.1921" "Python major mode" 'nil :commit "cae5907a4e04d781a2cfb1ae46faf29563717093")
;; Local Variables:
;; no-byte-compile: t
;; End:
