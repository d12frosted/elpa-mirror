(define-package "mpdel" "20201231.1612" "Play and control your MPD music"
  '((emacs "25.1")
    (libmpdel "1.2.0")
    (navigel "0.7.0"))
  :commit "6aec060a80dc8f517922773bddcee2d348a1e001" :authors
  (("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  ("Damien Cassou" . "damien@cassou.me")
  :keywords
  ("multimedia")
  :url "https://gitea.petton.fr/mpdel/mpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
