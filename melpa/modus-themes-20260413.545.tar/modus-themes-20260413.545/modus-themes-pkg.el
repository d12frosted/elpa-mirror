;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260413.545"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "9e87779b5e1d1e5e4c5a838a04c1bb8a38e78df1"
  :revdesc "9e87779b5e1d"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
