;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260623.443"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "ff85034cf50c2b552c2dc06b9d5f1582c0022e39"
  :revdesc "ff85034cf50c"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
