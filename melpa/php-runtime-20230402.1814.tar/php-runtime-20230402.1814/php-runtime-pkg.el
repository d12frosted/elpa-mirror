(define-package "php-runtime" "20230402.1814" "Language binding bridge to PHP"
  '((emacs "25.1")
    (compat "29"))
  :commit "325add6f697a665c99acb43a2cc5509b023a3ced" :authors
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("processes" "php" "lisp")
  :url "https://github.com/emacs-php/php-runtime.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
