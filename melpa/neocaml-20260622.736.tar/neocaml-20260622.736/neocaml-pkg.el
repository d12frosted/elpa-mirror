;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260622.736"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "f46ba69f8c44bbf9daa695cea627991b1713ad3a"
  :revdesc "f46ba69f8c44"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
