(define-package "consult" "20210130.1827" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "ef2869d9d36218d8cea9436bcce63cb0eb81fe12" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
