(define-package "treebundel" "20230911.2103" "Bundle related git-worktrees together"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "7c7fe656e2b33cd25629f16f5d2b41a13f47f53a" :authors
  '(("Ben Whitley"))
  :maintainers
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/treebundel")
;; Local Variables:
;; no-byte-compile: t
;; End:
