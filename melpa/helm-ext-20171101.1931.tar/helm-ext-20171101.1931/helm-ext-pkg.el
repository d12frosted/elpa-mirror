(define-package "helm-ext" "20171101.1931" "A few extensions to Helm"
  '((emacs "24.4")
    (helm "2.5.3"))
  :commit "c8ac56918b200239b3f73a4e6a031deecc2c5646" :authors
  '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainer
  '("Junpeng Qiu" . "qjpchmail@gmail.com")
  :keywords
  '("extensions"))
;; Local Variables:
;; no-byte-compile: t
;; End:
