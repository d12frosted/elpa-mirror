;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vc-modified-files" "20241216.553"
  "Show git modified files in a vc project with consult."
  '((emacs   "28.1")
    (consult "0.9"))
  :url "https://github.com/chmouel/consult-vc-modified-files"
  :commit "8dfd8e334b924c59673ddf71cc38f158c5c71ae1"
  :revdesc "8dfd8e334b92"
  :keywords '("vc" "convenience")
  :authors '(("Chmouel Boudjnah" . "chmouel@chmouel.com"))
  :maintainers '(("Chmouel Boudjnah" . "chmouel@chmouel.com")))
