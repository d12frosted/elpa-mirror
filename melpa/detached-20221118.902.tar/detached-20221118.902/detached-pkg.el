(define-package "detached" "20221118.902" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "be2a8f4d8c2077b6a16063c40845dee920715ed8" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
