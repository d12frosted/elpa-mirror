;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blackjack" "20260705.2046"
  "The game of Blackjack."
  '((emacs "26.2"))
  :url "https://github.com/gdonald/blackjack-el"
  :commit "7f98c9d15fa2d42abb2643235f73a9513b46c227"
  :revdesc "7f98c9d15fa2"
  :keywords '("card" "game" "games" "blackjack" "21")
  :authors '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers '(("Greg Donald" . "gdonald@gmail.com")))
