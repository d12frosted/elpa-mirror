;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-uuid-mode" "20261024.1743"
  "Minor mode for previewing time uuids as an overlay."
  '((emacs "27.1"))
  :url "https://github.com/RobertPlant/time-uuid-mode"
  :commit "eb43b94f18f3e468dde15c5de55ee7a1474915ed"
  :revdesc "eb43b94f18f3"
  :keywords '("extensions" "convenience" "data" "tools")
  :authors '(("Robert Plant" . "rob@robertplant.io"))
  :maintainers '(("Robert Plant" . "rob@robertplant.io")))
