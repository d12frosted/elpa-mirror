(define-package "lsp-scheme" "20220805.1939" "Scheme support for lsp-mode"
  '((emacs "25.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "2e7196c1e6915069f6ee7bb492f6c6987c9847ab" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
