(define-package "modus-themes" "20220322.1801" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "524d5ca33b7741a23d5f35229c0d329f165bdc18" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
