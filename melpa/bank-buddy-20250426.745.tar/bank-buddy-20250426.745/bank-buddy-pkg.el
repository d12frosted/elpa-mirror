;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bank-buddy" "20250426.745"
  "Financial analysis and reporting."
  '((emacs "26.1")
    (async "1.9.4"))
  :url "https://github.com/captainflasmr/bank-buddy"
  :commit "4b1f9e746583a02a0fc7e11b2a1a044ccc1a8ffd"
  :revdesc "4b1f9e746583"
  :keywords '("matching")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
