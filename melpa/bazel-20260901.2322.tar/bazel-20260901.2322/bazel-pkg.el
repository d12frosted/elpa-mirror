;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260901.2322"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "27afdb862c2f5266a7f9d621a43f8af75df34712"
  :revdesc "27afdb862c2f"
  :keywords '("build tools" "languages"))
