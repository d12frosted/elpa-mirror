(define-package "modus-themes" "20220420.854" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "5738d159d70e9d843ecf2e69ec2ab512d7ebef15" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
