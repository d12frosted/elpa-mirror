;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250926.1727"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "1d3e9b14d1f90229ab3c0663ae552e9dd1df6bdf"
  :revdesc "1d3e9b14d1f9"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
