(define-package "meow" "20221206.156" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "2eb74b0921d246f952c2cb549eeed8fde574a900" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
