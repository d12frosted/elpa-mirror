(define-package "flymake-eslint" "20231001.1252" "A Flymake backend for Javascript using eslint"
  '((emacs "26.1"))
  :commit "579f20f56e0d9ccb6c0618dc89ff0609e7be3743" :authors
  '(("Dan Orzechowski"))
  :maintainers
  '(("Dan Orzechowski"))
  :maintainer
  '("Dan Orzechowski")
  :keywords
  '("languages" "tools")
  :url "https://github.com/orzechowskid/flymake-eslint")
;; Local Variables:
;; no-byte-compile: t
;; End:
