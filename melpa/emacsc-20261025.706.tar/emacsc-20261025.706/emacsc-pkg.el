;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsc" "20261025.706"
  "Helper for emacsc(1)."
  ()
  :url "https://github.com/knu/emacsc"
  :commit "ee29327b6f4617fbd68e49ea91f9d4bfc9d65225"
  :revdesc "ee29327b6f46"
  :keywords '("tools")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
