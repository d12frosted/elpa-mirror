;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-statistics" "20261113.2041"
  "Sort candidates using completion history."
  '((emacs   "24.3")
    (company "0.8.5"))
  :url "https://github.com/company-mode/company-statistics"
  :commit "b46d7df38b2f5cec63c29e4f71f40610db0ca93d"
  :revdesc "b46d7df38b2f"
  :keywords '("abbrev" "convenience" "matching")
  :authors '(("Ingo Lohmar" . "i.lohmar@gmail.com"))
  :maintainers '(("Ingo Lohmar" . "i.lohmar@gmail.com")))
