;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dedukti-mode" "20171103.1212"
  "Major mode for Dedukti files."
  ()
  :url "https://github.com/rafoo/dedukti-mode"
  :commit "d7c3505a1046187de3c3aeb144455078d514594e"
  :revdesc "d7c3505a1046"
  :keywords '("languages" "dedukti"))
