;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250215.847"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "fa6fe6ac03d098d9a71816ea91a4dbdc7c3946d6"
  :revdesc "fa6fe6ac03d0"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
