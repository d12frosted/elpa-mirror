(define-package "boon" "20230223.1528" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "9462b245ad0c75442eecef07493f01f929145ddc")
;; Local Variables:
;; no-byte-compile: t
;; End:
