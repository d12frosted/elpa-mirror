;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "raku-mode" "20250930.1151"
  "Major mode for editing Raku code."
  '((emacs "24.4"))
  :url "https://github.com/hinrik/perl6-mode"
  :commit "d06baaa2e881470dddb97193713f9f0a278942ad"
  :revdesc "d06baaa2e881"
  :keywords '("languages")
  :authors '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com"))
  :maintainers '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com")))
