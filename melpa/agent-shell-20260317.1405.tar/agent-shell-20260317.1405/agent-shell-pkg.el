;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260317.1405"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "89aaccea221c79b7c0268e15574443860c4d1a6a"
  :revdesc "89aaccea221c")
