;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260612.1724"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "5fef3bd4ff5df5a452aca35b4921025aa271a61d"
  :revdesc "5fef3bd4ff5d"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
