(define-package "go-translate" "20211025.443" "Translation framework supports multiple engines such as Google/Bing/DeepL"
  '((emacs "27.1"))
  :commit "5bc52d326a7168e22a61542f9b48a053d14aca87" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
