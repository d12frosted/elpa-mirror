(define-package "embark" "20210516.1421" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "a178ffd83e9514651a2b3b0fa064f84452849250" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
