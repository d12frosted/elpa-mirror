;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-rss" "20260512.2231"
  "RSS 2.0 Back-End for Org Export Engine."
  '((emacs "26.1")
    (org   "9.3"))
  :url "https://github.com/bhw-foss/ox-rss"
  :commit "c83db3dc521d0dd423b0f24e57b7eaa798ab5e40"
  :revdesc "c83db3dc521d"
  :keywords '("org" "wp" "blog" "feed" "rss")
  :authors '(("Bastien Guerry" . "bzg@gnu.org"))
  :maintainers '(("Benedict Wang" . "foss@bhw.name")))
