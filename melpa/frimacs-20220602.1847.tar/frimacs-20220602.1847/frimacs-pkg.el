(define-package "frimacs" "20220602.1847" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "4713aa13c96183bccaeccc135b932f94522c2c05" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
