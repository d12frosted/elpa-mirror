(define-package "racket-mode" "20211020.1440" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "c68700806faa4b16f14ab61d7f009c8bc08e0fc8" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
