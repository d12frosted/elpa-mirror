;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260220.1119"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "75fa6336dbfba5cd29a479e59a7dc7ce7f7f4fc2"
  :revdesc "75fa6336dbfb"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
