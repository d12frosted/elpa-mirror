(define-package "chatgpt-shell" "20230623.1800" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.25.1"))
  :commit "14faf1e171b0fd5ec0df86e27499da58ce1a56ea" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
