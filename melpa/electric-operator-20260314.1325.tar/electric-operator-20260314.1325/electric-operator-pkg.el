;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-operator" "20260314.1325"
  "Automatically add spaces around operators."
  '((dash  "2.10.0")
    (emacs "24.4"))
  :url "https://github.com/davidshepherd7/electric-operator"
  :commit "ef39e07158cdfc1c2a461287fef17972d1985b0c"
  :revdesc "ef39e07158cd"
  :keywords '("electric")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
