;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260224.1703"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral DeepSeek OpenRouter Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "5040bce6893b5da43e9ea8600b83e537c4167fac"
  :revdesc "5040bce6893b"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
