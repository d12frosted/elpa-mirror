;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250919.838"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "1de05e271fc667547a18d306a516e3392b14de48"
  :revdesc "1de05e271fc6"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
