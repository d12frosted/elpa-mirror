(define-package "org-re-reveal" "20220520.718" "Org export to reveal.js presentations"
  '((emacs "24.4")
    (org "8.3")
    (htmlize "1.34"))
  :commit "ac67832e7b342326deef650db6601b95127627bc" :keywords
  '("tools" "outlines" "hypermedia" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/org-re-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
