(define-package "howm" "20201231.1042" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "c11a6b7ad3d683d2910572fa7f2a87ffdf503317" :authors
  '(("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
