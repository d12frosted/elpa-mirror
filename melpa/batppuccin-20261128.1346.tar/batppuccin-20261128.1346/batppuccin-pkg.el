;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "20261128.1346"
  "Batppuccin (Catppuccin) color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "10d19e9762091726f0ade38c6a4488d07ac50d47"
  :revdesc "10d19e976209"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
