;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-terminal-cursor-changer" "20260523.1907"
  "Change cursor shape and color in terminal."
  ()
  :url "https://github.com/7696122/evil-terminal-cursor-changer"
  :commit "fb824f657fb4325c1124f3e1b61f0de7ed062adf"
  :revdesc "fb824f657fb4"
  :keywords '("terminal" "cursor" "evil"))
