;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260118.610"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "7535d658c23b08abfe68835e8fdc649078c1f666"
  :revdesc "7535d658c23b"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
