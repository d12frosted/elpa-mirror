;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241120.1025"
  "A multi-llm comint Emacs shell (plus other goodies)."
  '((emacs       "28.1")
    (shell-maker "0.68.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "7132a3d718941493818df47a61f6d6006a513ac1"
  :revdesc "7132a3d71894")
