;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20241207.2221"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "f90c9b78785034b5b0527197c01e351d11226fbe"
  :revdesc "f90c9b787850"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
