(define-package "erlang" "20220213.554" "Erlang major mode"
  '((emacs "24.1"))
  :commit "304772e0c38b3a7d248b75c76735d8b447f46ce0" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
