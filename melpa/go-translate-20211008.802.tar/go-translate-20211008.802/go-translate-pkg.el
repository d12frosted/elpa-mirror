(define-package "go-translate" "20211008.802" "Translation"
  '((emacs "26.1"))
  :commit "333da635185eaaf30073f396df7483e3cff8518d" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
