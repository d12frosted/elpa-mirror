(define-package "zetteldeft" "20210214.1135" "Turn deft into a zettelkasten system"
  '((emacs "25.1")
    (deft "0.8")
    (ace-window "0.7.0"))
  :commit "8ea36747ff499e82a911c367eba8f7423c6301a4" :authors
  '(("EFLS <Elias Storms>"))
  :maintainer
  '("EFLS <Elias Storms>")
  :keywords
  '("deft" "zettelkasten" "zetteldeft" "wp" "files")
  :url "https://efls.github.io/zetteldeft/")
;; Local Variables:
;; no-byte-compile: t
;; End:
