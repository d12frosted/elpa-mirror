(define-package "stimmung-themes" "20220808.1150" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "9c8391cbc69bb44576b333af5caec84221d7b596" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
