;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-mode" "20250310.245"
  "Major mode for Markdown-formatted text."
  '((emacs "28.1"))
  :url "https://jblevins.org/projects/markdown-mode/"
  :commit "6fc5904257531fef6a7b48bd9fb3b6e6b6c3af8b"
  :revdesc "6fc590425753"
  :keywords '("markdown" "github flavored markdown" "itex")
  :authors '(("Jason R. Blevins" . "jblevins@xbeta.org"))
  :maintainers '(("Jason R. Blevins" . "jblevins@xbeta.org")))
