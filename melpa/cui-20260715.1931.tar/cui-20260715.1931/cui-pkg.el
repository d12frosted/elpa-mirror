;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260715.1931"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "f68f1261f4618fee1d061b22a3a4155589b52259"
  :revdesc "f68f1261f461"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
