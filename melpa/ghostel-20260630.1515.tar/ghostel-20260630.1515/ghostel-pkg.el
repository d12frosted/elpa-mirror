;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260630.1515"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "0a539fb20faf38eb45c89bc8a2752ea0b447fc41"
  :revdesc "0a539fb20faf"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
