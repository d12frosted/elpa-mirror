(define-package "verilog-ts-mode" "20231010.1044" "Verilog Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "81cf686b4280734d447bcf841bb53898f3a76931" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
