;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260331.1536"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "a3e765082a41c5a536d6c72af1202b30399444af"
  :revdesc "a3e765082a41"
  :keywords '("convenience" "text"))
