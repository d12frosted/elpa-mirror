;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260524.1045"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "7cd51a1488f512ee499a4a42d0acba845c3259c5"
  :revdesc "7cd51a1488f5"
  :keywords '("languages"))
