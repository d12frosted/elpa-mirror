;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260311.1327"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "46140ae78db755b70810240648c80865f01841f8"
  :revdesc "46140ae78db7"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
