(define-package "jazz-theme" "20230722.1307" "A warm color theme for Emacs 24+." 'nil :commit "1905841af1df7b7075dcc8e1e3df4a9b5022f4a8" :authors
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainers
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainer
  '("Roman Parykin" . "donderom@ymail.com")
  :url "https://github.com/donderom/jazz-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
