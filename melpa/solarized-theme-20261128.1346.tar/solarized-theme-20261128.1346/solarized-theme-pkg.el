;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "20261128.1346"
  "The Solarized color theme."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "b213a83eb734b09fd9b9239da44dbe819e26f103"
  :revdesc "b213a83eb734"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
