;;; vulpea-db-worker.el --- Async extraction worker -*- lexical-binding: t; -*-
;;
;; Copyright (c) 2015-2026 Boris Buliga <boris@d12frosted.io>
;;
;; Author: Boris Buliga <boris@d12frosted.io>
;; Maintainer: Boris Buliga <boris@d12frosted.io>
;;
;; This program is free software; you can redistribute it and/or
;; modify it under the terms of the GNU General Public License as
;; published by the Free Software Foundation, either version 3 of the
;; License, or (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful, but
;; WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
;; General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see
;; <http://www.gnu.org/licenses/>.
;;
;; Created: 05 Jul 2026
;;
;; URL: https://github.com/d12frosted/vulpea
;;
;; License: GPLv3
;;
;; This file is not part of GNU Emacs.
;;
;;; Commentary:
;;
;; Off-main-thread extraction for issue #359.
;;
;; The sync queue is scheduled asynchronously, but parsing and
;; extraction run on the main thread once a timer fires, freezing the
;; UI for as long as a file takes to index.  This module moves that
;; work into a persistent `emacs --batch' subprocess:
;;
;;   main                              worker
;;   ----                              ------
;;   spawn, send (settings ...)   -->  apply settings
;;   send (parse "path")          -->  vulpea-db--parse-file
;;                                <--  (begin "path")
;;                                <--  (file-node <plist>)
;;                                <--  (heading-node <plist>) ...
;;                                <--  (done "path" HASH MTIME SIZE)
;;   freshness check, then
;;   vulpea-db--apply-parse-ctx
;;
;; Only extracted data crosses the boundary - printable plists, never
;; the AST - so results flow through the exact same write path as
;; synchronous updates (`vulpea-db--apply-parse-ctx').  The wire
;; format is pure ASCII: everything is printed with
;; `print-escape-nonascii', so process coding can never corrupt it.
;; The worker's stderr goes to a separate buffer; in batch mode
;; `message' writes to stderr, keeping stdout clean for the protocol.
;;
;; The worker mirrors an explicit allowlist of settings (vulpea
;; customs, org link types, tag inheritance, org-attach
;; configuration).  Like `vulpea-db-parse-method' `single-temp-buffer',
;; it does not run the user's `org-mode-hook'.  Requests the worker
;; cannot handle faithfully - AST-reading extractor plugins,
;; function-valued `vulpea-db-index-heading-level', non-.org files
;; that need decryption - are rejected by
;; `vulpea-db-worker-can-handle-p' and the caller falls back to the
;; synchronous path.
;;
;;; Code:

(require 'vulpea-db)
(require 'vulpea-db-extract)
;; The worker needs the user's org-attach settings, and with async
;; extraction the session may never load org-attach on its own; load
;; it here so its defaults, and any `with-eval-after-load' setup, are
;; in place before the first settings message
(require 'org-attach)

(declare-function vulpea-db-sync--enqueue "vulpea-db-sync"
                  (path &optional force))

;;; Customization

(defcustom vulpea-db-async-extraction t
  "Whether the sync queue extracts files in a background process.

When t (the default), `vulpea-db-sync' sends changed files to a
persistent `emacs --batch' worker instead of parsing them on the
main thread.  The UI then only blocks for the database write of the
results, not for reading, hashing, parsing, or extraction - the bulk
of indexing time.  The database is updated a moment after a save;
code that reacts to indexed changes should listen on
`vulpea-db-updated-functions'.  Programmatic APIs such as
`vulpea-create' stay synchronous.

When nil, files are parsed on the main thread, and saving a large
file freezes Emacs for as long as indexing takes.

When `full', the worker also writes the results to the database
through its own connection, so the main thread only registers the
note IDs with org-id - the save-path freeze disappears at any file
size.  This switches the database to WAL journaling (persistent;
-wal/-shm sidecar files appear next to it), which is not suitable
for databases on network filesystems.  While
`vulpea-db-note-index-filter-functions' are registered (schema
validation actions), `full' behaves like t, since those filters run
in the main process.

The worker mirrors vulpea and org settings from an allowlist and,
like `vulpea-db-parse-method' \\='single-temp-buffer, does not run
`org-mode-hook'.  `vulpea-doctor' reports hook functions that change
settings extraction reads; if indexing depends on them, set this to
nil.  Files the worker cannot handle
faithfully (extractor plugins declaring :requires-ast t,
function-valued `vulpea-db-index-heading-level', non-.org files)
are processed synchronously as before."
  :type '(choice (const :tag "Off (parse on the main thread)" nil)
          (const :tag "Extract in worker, write in main" t)
          (const :tag "Extract and write in worker (WAL)" full))
  :group 'vulpea-db-sync)

(defcustom vulpea-db-async-extraction-threshold nil
  "Minimum file size in bytes for extraction in the worker.

Files smaller than this are processed synchronously even when
`vulpea-db-async-extraction' is enabled; nil sends files of any size
to the worker.

Measurements do not demand a threshold - the worker blocks the main
thread less at every size, and bulk syncs complete faster through it
\(worker parsing overlaps writes in the main process).  The reason to set one
is consistency semantics: a synchronously indexed file is queryable
the moment the sync queue has run, while a worker-extracted file
becomes queryable a moment later.  If code queries small notes right
after saving them, a threshold like 102400 keeps those synchronous."
  :type '(choice (const :tag "All sizes through the worker" nil)
          (integer :tag "Minimum size in bytes"))
  :group 'vulpea-db-sync)

(defcustom vulpea-db-worker-prestart t
  "Whether to start the worker before the first change of a session.

When non-nil (the default), enabling `vulpea-db-autosync-mode' with
`vulpea-db-async-extraction' on starts the worker once Emacs has been
idle for a moment, so the first save of a session is not held up by
the worker starting (an `emacs --batch' that loads vulpea and Org,
about a second).  The cost is an idle worker process, around 70MB,
from the start of the session instead of from the first change.

When nil, the worker starts on the first file it has to extract."
  :type 'boolean
  :group 'vulpea-db-sync)

(defcustom vulpea-db-worker-debug nil
  "When non-nil, log worker lifecycle and protocol to a buffer.

The log lands in `vulpea-db-worker-log-buffer' with millisecond
timestamps: process spawns (including the full command), settings
sent, every request and reply (truncated), completion outcomes with
time spent in the main process, process deaths with the tail of the worker's
stderr, and WAL negotiation results.  Enable it when async extraction
misbehaves and attach the buffer to a bug report."
  :type 'boolean
  :group 'vulpea-db-sync)

(defconst vulpea-db-worker-log-buffer "*vulpea-worker-log*"
  "Name of the worker debug log buffer.")

(defun vulpea-db-worker--log (format-string &rest args)
  "Append a timestamped line to the worker log when debugging.
FORMAT-STRING and ARGS are passed to `format'."
  (when vulpea-db-worker-debug
    (with-current-buffer (get-buffer-create vulpea-db-worker-log-buffer)
      (goto-char (point-max))
      (insert (format-time-string "%H:%M:%S.%3N ")
              (apply #'format format-string args)
              "\n"))))

(defun vulpea-db-worker--log-truncate (string &optional limit)
  "Return STRING truncated to LIMIT characters (default 180) for logs."
  (let ((limit (or limit 180)))
    (if (> (length string) limit)
        (concat (substring string 0 limit)
                (format "... [%d chars]" (length string)))
      string)))

(defvar vulpea-db-worker-done-functions nil
  "Abnormal hook run when the worker finishes a file.

Each function is called with (PATH STATUS COUNT) where STATUS is one
of `applied' (notes written), `unchanged' (content hash matched, only
the file stamp was refreshed), `stale' (file changed while parsing;
result discarded and the file re-enqueued), `requeued' (worker died
with the file in flight; re-enqueued), `missing' (file deleted while
parsing), or `error'.  COUNT is the number of notes written for
`applied', nil otherwise.

This is a worker-lifecycle hook: it reports what happened to a
worker request, including outcomes that changed nothing.  To react
to database content changes, use `vulpea-db-updated-functions'
instead - it fires exactly when notes were rewritten, and also
covers synchronous updates, which never touch the worker.

This is an extension point, not a setting: attach to it with
`add-hook', which is why it is deliberately not a `defcustom'.")

;;; Wire format

(defun vulpea-db-worker--print (form)
  "Return FORM printed for the wire: one ASCII-only line."
  (let ((print-escape-newlines t)
        (print-escape-control-characters t)
        (print-escape-nonascii t)
        (print-length nil)
        (print-level nil)
        (print-circle nil))
    (prin1-to-string form)))

(defun vulpea-db-worker--printable-p (value)
  "Return non-nil when VALUE survives a print/read round trip."
  (condition-case nil
      (equal value (car (read-from-string (vulpea-db-worker--print value))))
    (error nil)))

;;; Settings allowlist

(defconst vulpea-db-worker--settings-vars
  '(vulpea-db-parse-method
    vulpea-db-parse-granularity
    vulpea-db-index-plain-links
    vulpea-db-index-heading-level
    vulpea-db-exclude-archived
    vulpea-db-exclude-property
    vulpea-db-exclude-children-property
    vulpea-buffer-alias-property
    vulpea-db-path-normalization
    org-archive-tag
    org-use-tag-inheritance
    org-tags-exclude-from-inheritance
    org-use-property-inheritance
    org-category
    enable-local-variables
    enable-dir-local-variables
    safe-local-variable-values
    ignored-local-variables
    ignored-local-variable-values
    safe-local-variable-directories
    enable-local-eval
    org-attach-id-dir
    org-attach-id-to-path-function-list
    org-attach-use-inheritance
    org-link-abbrev-alist
    org-todo-keywords
    org-plain-list-ordered-item-terminator
    org-list-allow-alphabetical)
  "Variables mirrored into the extraction worker.

The worker is a clean `emacs --batch' process, so any setting
extraction reads must be listed here, or the worker extracts with
its default.  For vulpea-db- and vulpea-buffer- options, and for
options the worker's code names, the settings classification test
fails until each is listed here or in
`vulpea-db-worker--settings-not-mirrored'.  Org and Emacs settings
read inside their own functions (for example `org-todo-keywords'
through `org-element-parse-buffer', or `org-link-abbrev-alist') are
invisible to that test: they are listed by hand, and the tests pin
them so none is dropped by accident.")

(defconst vulpea-db-worker--settings-not-mirrored
  '((case-fold-search
     . "bound by extraction code around each use")
    (directory-abbrev-alist
     . "only spells paths for org-id, registered in the main process")
    (org-id-track-globally
     . "org-id registration runs in the main process")
    (org-link-parameters
     . "link types travel separately in the settings message")
    (vulpea-db-extra-extensions
     . "the worker only takes .org files")
    (vulpea-db-location
     . "sent with each full-write request")
    (vulpea-db-schema-validation-action
     . "index filters run in the main process; full degrades to t")
    (vulpea-buffer-meta-change-functions
     . "editing hook, not read by extraction")
    (vulpea-db-async-extraction . "worker control, main process")
    (vulpea-db-async-extraction-threshold . "worker control, main process")
    (vulpea-db-worker-debug . "worker control, main process")
    (vulpea-db-worker-hang-timeout . "worker control, main process")
    (vulpea-db-worker-max-in-flight . "worker control, main process")
    (vulpea-db-worker-prestart . "worker control, main process")
    (vulpea-db-autosync-mode . "sync scheduling, main process")
    (vulpea-db-autosync-mode-hook . "sync scheduling, main process")
    (vulpea-db-sync-batch-delay . "sync scheduling, main process")
    (vulpea-db-sync-batch-size . "sync scheduling, main process")
    (vulpea-db-sync-debug . "sync scheduling, main process")
    (vulpea-db-sync-directories . "sync scheduling, main process")
    (vulpea-db-sync-external-method . "sync scheduling, main process")
    (vulpea-db-sync-fswatch-path-style . "sync scheduling, main process")
    (vulpea-db-sync-idle-delay . "sync scheduling, main process")
    (vulpea-db-sync-poll-interval . "sync scheduling, main process")
    (vulpea-db-sync-progress-interval . "sync scheduling, main process")
    (vulpea-db-sync-reindex-on-dir-locals-change
     . "sync scheduling, main process")
    (vulpea-db-sync-scan-on-enable . "sync scheduling, main process")
    (vulpea-db-sync-verbose . "sync scheduling, main process"))
  "Options deliberately left out of `vulpea-db-worker--settings-vars'.

An alist of (SYMBOL . REASON).  Each entry is a vulpea option or an
option named in the worker's code that does not change what the
worker extracts or writes.")

(defun vulpea-db-worker--portable-link-abbrevs (abbrevs)
  "Return ABBREVS, an `org-link-abbrev-alist', ready for the worker.
An abbreviation that expands through a function needs that function,
which exists only in the session: a function value, or a string
calling one with %(...).  It is sent by name, as
`:vulpea-session-function', so the worker can hand the files using
it back instead of expanding the link differently."
  (mapcar (lambda (entry)
            (if (and (stringp (cdr entry))
                     (not (string-search "%(" (cdr entry))))
                entry
              (cons (car entry) :vulpea-session-function)))
          abbrevs))

(defun vulpea-db-worker--settings-form ()
  "Build the settings message for the worker.

Unprintable values (closures, buffers) are silently dropped; the
worker keeps its default for those variables.  Callers that need a
faithful result for such settings must use
`vulpea-db-worker-can-handle-p', which rejects the known-critical
cases."
  (let (vars)
    (dolist (sym vulpea-db-worker--settings-vars)
      ;; Capture the default value: extraction reads settings from
      ;; fresh parse buffers, where an automatically-buffer-local
      ;; variable (org-category) resolves to its default - the value
      ;; of whatever buffer happens to be current here must not leak.
      ;; For the other, never-buffer-local settings this is identical
      ;; to symbol-value.
      (when (default-boundp sym)
        (let ((value (default-value sym)))
          (when (eq sym 'org-link-abbrev-alist)
            (setq value (vulpea-db-worker--portable-link-abbrevs value)))
          (when (vulpea-db-worker--printable-p value)
            (push (cons sym value) vars)))))
    ;; Which settings may come from dir-locals without a prompt: users
    ;; mark org options safe in their init, which the worker never read
    (let ((safe (delq nil
                      (mapcar (lambda (sym)
                                (let ((prop (get sym 'safe-local-variable)))
                                  (when (and prop
                                             (vulpea-db-worker--printable-p prop))
                                    (cons sym prop))))
                              vulpea-db-worker--settings-vars))))
      (when safe
        (push (cons 'vulpea-db-worker--safe-local-properties safe) vars)))
    `(settings ,(nreverse vars) ,(org-link-types)
               ,(vulpea-db-worker--extractor-specs)
               (:db-version ,vulpea-db-version
                :parser-epoch ,vulpea-db-parser-epoch))))

(defun vulpea-db-worker--extractor-specs ()
  "Build wire specs for worker-safe extractors.

Only extractors declared :worker-safe with a symbol :extract-fn can
cross the process boundary; the worker loads :worker-lib and
registers them locally.  Anything it cannot resolve makes it fall
back to streaming results, so the extractor runs in the main process
instead."
  (let (specs)
    (dolist (extractor vulpea-db--extractors)
      (when (vulpea-extractor-worker-safe extractor)
        (push (list :name (vulpea-extractor-name extractor)
                    :fn (let ((fn (vulpea-extractor-extract-fn extractor)))
                          (and (symbolp fn) fn))
                    :lib (vulpea-extractor-worker-lib extractor)
                    :priority (vulpea-extractor-priority extractor)
                    :requires-ast (vulpea-extractor-requires-ast extractor))
              specs)))
    (nreverse specs)))

(defvar vulpea-db-worker--process)

(defvar vulpea-db-worker--refresh-timer nil
  "Debounce timer for pushing settings to a live worker.")

(defvar vulpea-db-worker--sent-settings nil
  "The last settings message sent to the worker.
Changes made in place - `org-link-set-parameters' on
`org-link-parameters', `setf' on an `alist-get' - fire no variable
watcher; comparing against this catches them.")

(defvar vulpea-db-worker--sent-link-types nil
  "Link types in the last settings message sent to the worker.
Requests compare against this, a cheap check for the most common
in-place change: a link type registered after the worker started.")

(defun vulpea-db-worker--send-settings ()
  "Send current settings to the worker and return the message."
  (let ((settings (vulpea-db-worker--settings-form)))
    (vulpea-db-worker--send settings)
    ;; A deep copy: the message shares structure with the live
    ;; settings, and an in-place edit would change the record too
    (setq vulpea-db-worker--sent-settings (copy-tree settings t)
          vulpea-db-worker--sent-link-types (nth 2 settings))
    settings))

(defun vulpea-db-worker-refresh-if-changed ()
  "Send settings to a running worker when they changed since the last.
Builds and compares the whole settings message, so the sync queue
calls it once per batch rather than per file."
  (when (and (process-live-p vulpea-db-worker--process)
             (not (equal (vulpea-db-worker--settings-form)
                         vulpea-db-worker--sent-settings)))
    (vulpea-db-worker-refresh-settings)))

(defun vulpea-db-worker-refresh-settings ()
  "Send current settings to a running worker, if any.
Called by `vulpea-db-register-extractor', by the variable watchers
on the settings allowlist, and by requests that find new link types,
so a live worker mirrors setting changes made mid-session."
  (when (process-live-p vulpea-db-worker--process)
    (vulpea-db-worker--log "settings refresh")
    (vulpea-db-worker--send-settings)))

(defun vulpea-db-worker--schedule-refresh (&rest _)
  "Debounced settings refresh, triggered by a watched variable change.
Debounced because a user init file may set several watched variables
in a row; one refresh after the dust settles is enough."
  (when (process-live-p vulpea-db-worker--process)
    (when vulpea-db-worker--refresh-timer
      (cancel-timer vulpea-db-worker--refresh-timer))
    (setq vulpea-db-worker--refresh-timer
          (run-with-timer 0.5 nil
                          (lambda ()
                            (setq vulpea-db-worker--refresh-timer nil)
                            (vulpea-db-worker-refresh-settings))))))

(defvar vulpea-db-worker--watchers-installed nil
  "Non-nil once variable watchers for the settings allowlist exist.")

(defun vulpea-db-worker--install-watchers ()
  "Watch the settings allowlist to keep a live worker current.
Without this, a setting changed mid-session (for example
`vulpea-db-index-plain-links') applied only to files parsed in the
main process; the worker kept extracting with the values it saw at
spawn, silently splitting behavior between the two paths."
  (unless vulpea-db-worker--watchers-installed
    (setq vulpea-db-worker--watchers-installed t)
    (dolist (sym vulpea-db-worker--settings-vars)
      (add-variable-watcher sym #'vulpea-db-worker--schedule-refresh))))

;;; Client: process management

(defvar vulpea-db-worker--process nil
  "The extraction worker process, or nil.")

(defvar vulpea-db-worker--output ""
  "Buffered incomplete output line from the worker.")

(defvar vulpea-db-worker--output-pending nil
  "Reversed list of chunks of the current incomplete protocol line.
Accumulated as a list instead of string concatenation: a single
protocol line can be megabytes (a large file node), and re-concating
it per 4KB process chunk would cost quadratic time in the main process.")

(defvar vulpea-db-worker--wal-failed nil
  "Non-nil when WAL journaling could not be enabled on the database.
Without WAL, a worker write transaction blocks main-process reads -
the exact freeze full-write mode exists to avoid - so full-write is
refused and requests degrade to extract-only (see
`vulpea-db-worker--full-write-p').  Happens on filesystems without
shared-memory support (some network or FUSE mounts).")

(defvar vulpea-db-worker--in-flight nil
  "Paths sent to the worker and not yet completed, oldest first.")

(defvar vulpea-db-worker--in-flight-tail nil
  "Tail cons of `vulpea-db-worker--in-flight' for O(1) appends.")

(defcustom vulpea-db-worker-hang-timeout 300
  "Seconds of worker silence with work in flight before it is killed.

A hung parse (pathological file, wedged subprocess) would otherwise
stall all background indexing forever while the queue waits on the
flow-control window.  When the worker produces no output for this
long despite having requests in flight, it is killed; the salvage
path re-enqueues its files.  Two consecutive hang kills without a
successful completion in between mark the worker broken (see
`vulpea-db-worker-reset'), so a file that reliably hangs the parser
cannot loop forever.

The default is generous: a 100MB file parses in under a minute on
2020s hardware.  Set to nil to disable the watchdog."
  :type '(choice (const :tag "Disabled" nil) (integer :tag "Seconds"))
  :group 'vulpea-db-sync)

(defcustom vulpea-db-worker-max-in-flight 128
  "Maximum requests in flight to the worker at once.

Flow control for bulk syncs: without a window, the queue stuffs the
worker's stdin pipe until `process-send-string' blocks the main
thread waiting for the worker to drain it - measured as multi-hundred
millisecond UI stalls during full rebuilds.  The sync queue keeps the
overflow queued and retries as completions free the window."
  :type 'integer
  :group 'vulpea-db-sync)

(defvar vulpea-db-worker--in-flight-count 0
  "Length of `vulpea-db-worker--in-flight', maintained incrementally.")

(defun vulpea-db-worker-in-flight-count ()
  "Return the number of requests currently in flight."
  vulpea-db-worker--in-flight-count)

(defvar vulpea-db-worker--results-count 0
  "Length of `vulpea-db-worker--results'.")

(defun vulpea-db-worker--window-used ()
  "Return how much of the request window is taken.
That is the requests in flight, or the results waiting to be applied
when there are more of those.  Results normally wait a moment and
take no room, which keeps the worker fed; once a main thread applying
more slowly than the worker parses has a full window of them waiting,
no more requests go out, instead of parsed results piling up."
  (max vulpea-db-worker--in-flight-count vulpea-db-worker--results-count))

(defun vulpea-db-worker-saturated-p ()
  "Return non-nil when the worker request window is full.
Callers should keep their files queued and retry later instead of
requesting more (see `vulpea-db-worker-max-in-flight')."
  (>= (vulpea-db-worker--window-used) vulpea-db-worker-max-in-flight))

(defun vulpea-db-worker-free-slots ()
  "Return how many more requests fit in the worker request window."
  (max 0 (- vulpea-db-worker-max-in-flight (vulpea-db-worker--window-used))))

(defvar vulpea-db-worker--results nil
  "Worker results waiting to be applied, oldest first.
Each is a list (PATH HASH MTIME SIZE FILE-NODE HEADING-NODES FORCE):
the file as the worker read it, the nodes it extracted (headings in
document order), and whether the request was forced.")

(defvar vulpea-db-worker--results-tail nil
  "Last cons of `vulpea-db-worker--results', for O(1) appends.")

(defvar vulpea-db-worker--results-timer nil
  "Timer to apply `vulpea-db-worker--results'.")

(defvar vulpea-db-worker--current nil
  "Assembly state for the file currently streaming in.
A plist with :path, :file-node and :heading-nodes (reversed).")

(defvar vulpea-db-worker--last-activity nil
  "Timestamp of the last output received from the worker.")

(defvar vulpea-db-worker--watchdog-timer nil
  "Repeating timer that detects a hung worker.")

(defvar vulpea-db-worker--hang-kills 0
  "Consecutive watchdog kills without a successful completion.")

(defvar vulpea-db-worker--extractors-warned nil
  "Non-nil after warning about worker-unresolvable extractors once.")

(defvar vulpea-db-worker--spawn-time nil
  "Timestamp of the most recent worker spawn.")

(defvar vulpea-db-worker--crash-times nil
  "Timestamps of recent early worker deaths (died within 10s of spawn).
Used to detect crash loops: a worker that keeps dying right after
spawning would otherwise be respawned in a tight loop that starves
the UI.")

(defvar vulpea-db-worker--broken nil
  "Non-nil after a worker crash loop was detected.
While set, `vulpea-db-worker-can-handle-p' refuses everything, so the
sync queue falls back to synchronous processing.  Reset with
`vulpea-db-worker-reset' (or by re-enabling `vulpea-db-autosync-mode',
which stops the worker).")

(defun vulpea-db-worker-reset ()
  "Forget a detected crash loop and allow the worker again."
  (interactive)
  (setq vulpea-db-worker--broken nil
        vulpea-db-worker--crash-times nil)
  (message "Vulpea: extraction worker re-enabled"))

(defvar vulpea-db-worker--force (make-hash-table :test 'equal)
  "In-flight paths requested with force re-indexing.

Forced results skip the unchanged-content shortcut: force exists for
parser or settings changes, where content is identical but extraction
output is not.")

(defun vulpea-db-worker--command ()
  "Build the worker process command line."
  (let ((emacs (expand-file-name invocation-name invocation-directory))
        (lib (locate-library "vulpea-db-worker")))
    (unless lib
      (error "Cannot locate vulpea-db-worker library for the worker process"))
    (append (list emacs "--batch" "-Q")
            (mapcan (lambda (dir) (list "-L" dir))
                    (seq-filter #'stringp load-path))
            ;; -Q leaves `load-prefer-newer' nil, so a stale .elc next
            ;; to a newer .el would load in the worker while the main
            ;; process runs the source - two processes silently
            ;; executing different versions of vulpea.  Prefer the
            ;; newer file, whatever it is, before anything loads.
            (list "--eval" "(setq load-prefer-newer t)"
                  "-l" lib "-f" "vulpea-db-worker-batch-main"))))

(defun vulpea-db-worker--salvage ()
  "Re-enqueue in-flight work of a dead worker and reset client state.

Emacs reports a child's death through `process-live-p' immediately,
but runs its sentinel only at the next wait point - and timers run
first.  Any code that observes a dead worker before its sentinel has
run must salvage through this function; the sentinel itself also
lands here.  Idempotent: the second caller finds no pending work."
  (let ((pending vulpea-db-worker--in-flight)
        (forced (copy-hash-table vulpea-db-worker--force)))
    (when vulpea-db-worker--process
      ;; The deferred sentinel of this process must not run its own
      ;; salvage against the replacement's state later
      (set-process-sentinel vulpea-db-worker--process #'ignore))
    (setq vulpea-db-worker--process nil
          vulpea-db-worker--output ""
          vulpea-db-worker--output-pending nil
          vulpea-db-worker--in-flight nil
          vulpea-db-worker--in-flight-tail nil
          vulpea-db-worker--in-flight-count 0
          vulpea-db-worker--current nil)
    (clrhash vulpea-db-worker--force)
    (when pending
      (message "Vulpea: extraction worker died, re-queueing %d file%s"
               (length pending) (if (= (length pending) 1) "" "s"))
      ;; Deferred: salvage may run inside vulpea-db-worker--ensure,
      ;; and re-requesting synchronously would recurse into the spawn
      ;; path and orphan the process being created
      (run-at-time 0 nil #'vulpea-db-worker--salvage-requeue
                   pending forced))))

(defun vulpea-db-worker--salvage-requeue (pending forced)
  "Re-enqueue salvaged PENDING paths, restoring their FORCED flags."
  (dolist (path pending)
    (vulpea-db-worker--reenqueue path (gethash path forced))
    ;; Terminal for this dispatch: the re-enqueued entry counts
    ;; anew when the queue dispatches it again
    (run-hook-with-args 'vulpea-db-worker-done-functions
                        path 'requeued nil)))

(defun vulpea-db-worker--watchdog ()
  "Kill the worker when it has been silent too long with work pending."
  (when (and vulpea-db-worker-hang-timeout
             vulpea-db-worker--in-flight
             (process-live-p vulpea-db-worker--process)
             vulpea-db-worker--last-activity
             (> (- (float-time) vulpea-db-worker--last-activity)
                vulpea-db-worker-hang-timeout))
    (setq vulpea-db-worker--hang-kills (1+ vulpea-db-worker--hang-kills))
    (vulpea-db-worker--log "watchdog: killing silent worker (%d in flight, hang #%d)"
                           vulpea-db-worker--in-flight-count
                           vulpea-db-worker--hang-kills)
    (message "Vulpea: extraction worker unresponsive for %ss, restarting"
             vulpea-db-worker-hang-timeout)
    (when (>= vulpea-db-worker--hang-kills 2)
      ;; The retry hung too: something reliably wedges the parser.
      ;; Stop feeding it; the sync queue falls back to synchronous.
      (setq vulpea-db-worker--broken t)
      (display-warning
       'vulpea
       "Extraction worker hangs repeatedly; falling back to synchronous indexing.  Run M-x vulpea-db-worker-reset to retry."
       :error))
    ;; delete-process triggers the sentinel -> salvage re-enqueues
    (delete-process vulpea-db-worker--process)))

(defun vulpea-db-worker--ensure ()
  "Return a live worker process, spawning one if needed."
  (unless (process-live-p vulpea-db-worker--process)
    ;; A dead-but-not-yet-sentineled worker still owns in-flight work;
    ;; salvage it instead of silently discarding it
    (vulpea-db-worker--salvage)
    ;; This spawn is the one an idle start ahead of time would make
    (vulpea-db-worker--cancel-prestart)
    (setq vulpea-db-worker--spawn-time (float-time))
    (setq vulpea-db-worker--last-activity (float-time))
    (vulpea-db-worker--install-watchers)
    (unless vulpea-db-worker--watchdog-timer
      (setq vulpea-db-worker--watchdog-timer
            (run-with-timer 30 30 #'vulpea-db-worker--watchdog)))
    ;; A worker that cannot start at all (Emacs binary gone after an
    ;; upgrade, library not on the load path) never reaches the
    ;; sentinel's crash-loop detection.  Mark it broken here, so the
    ;; queue stops retrying per file and indexes synchronously.
    (condition-case err
        (let ((command (vulpea-db-worker--command)))
          (vulpea-db-worker--log "spawn: %s ... (%d args)"
                                 (vulpea-db-worker--log-truncate
                                  (string-join (seq-take command 6) " "))
                                 (length command))
          (setq vulpea-db-worker--process
                (make-process
                 :name "vulpea-worker"
                 :command command
                 :connection-type 'pipe
                 :noquery t
                 :coding 'utf-8-unix
                 :stderr (get-buffer-create " *vulpea-worker-stderr*")
                 :filter #'vulpea-db-worker--filter
                 :sentinel #'vulpea-db-worker--sentinel)))
      (error
       (setq vulpea-db-worker--broken t)
       (display-warning
        'vulpea
        (format (concat "Extraction worker cannot start (%s); falling "
                        "back to synchronous indexing.  Run "
                        "M-x vulpea-db-worker-diagnose to investigate, "
                        "M-x vulpea-db-worker-reset to retry.")
                (error-message-string err))
        :error)
       (signal (car err) (cdr err))))
    (let ((settings (vulpea-db-worker--send-settings)))
      (vulpea-db-worker--log "settings: %d vars, %d link types"
                             (length (nth 1 settings))
                             (length (nth 2 settings)))))
  vulpea-db-worker--process)

(defvar vulpea-db-worker--prestart-timer nil
  "Idle timer that starts the worker ahead of the first request.")

(defconst vulpea-db-worker--prestart-delay 2
  "Seconds of idle time before the worker is started ahead of time.
Long enough for init code to finish, so the worker starts with the
settings of the session.")

(defun vulpea-db-worker--cancel-prestart ()
  "Cancel a pending start of the worker ahead of time."
  (when (timerp vulpea-db-worker--prestart-timer)
    (cancel-timer vulpea-db-worker--prestart-timer))
  (setq vulpea-db-worker--prestart-timer nil))

(defun vulpea-db-worker-schedule-prestart ()
  "Start the worker in idle time, ahead of the first request.
Does nothing unless both `vulpea-db-async-extraction' and
`vulpea-db-worker-prestart' are non-nil.  Called when autosync is
enabled; `vulpea-db-worker-stop' cancels a start still pending."
  (vulpea-db-worker--cancel-prestart)
  (when (and vulpea-db-async-extraction vulpea-db-worker-prestart)
    (setq vulpea-db-worker--prestart-timer
          (run-with-idle-timer vulpea-db-worker--prestart-delay nil
                               #'vulpea-db-worker--prestart))))

(defun vulpea-db-worker--prestart ()
  "Start the worker if it is not running and would accept .org files.
A worker that would refuse every .org file (see
`vulpea-db-worker-rejection-reasons') is not started: it would sit
idle all session.  A failure to start is reported by
`vulpea-db-worker--ensure' and not raised from the timer."
  (setq vulpea-db-worker--prestart-timer nil)
  (when (and vulpea-db-async-extraction
             vulpea-db-worker-prestart
             (not (process-live-p vulpea-db-worker--process))
             (not (vulpea-db-worker-rejection-reasons "probe.org")))
    (let ((t0 (float-time)))
      (condition-case err
          (progn
            (vulpea-db-worker--ensure)
            (vulpea-db-worker--log "prestart: spawned in %.1fms"
                                   (* 1000 (- (float-time) t0))))
        (error
         (vulpea-db-worker--log "prestart failed: %s"
                                (error-message-string err)))))))

(defun vulpea-db-worker--send (form)
  "Send FORM to the worker as one line."
  (process-send-string vulpea-db-worker--process
                       (concat (vulpea-db-worker--print form) "\n")))

(defvar vulpea-db-worker--fallback-queue nil
  "Files the worker failed on, waiting to be indexed synchronously.
One entry per dispatch: a file dispatched twice appears twice, since
each dispatch expects its own completion.")

(defvar vulpea-db-worker--fallback-timer nil
  "Timer indexing the next file of `vulpea-db-worker--fallback-queue'.")

(defvar vulpea-db-worker--fallback-attempts (make-hash-table :test #'equal)
  "Times each queued fallback found the database locked.")

(defconst vulpea-db-worker--fallback-max-attempts 20
  "How often a fallback retries a locked database before giving up.
Retries are a quarter second apart, so a few seconds in all: enough
to outlast a commit of the full-write worker.")

(defun vulpea-db-worker-stop ()
  "Stop the extraction worker, discarding any in-flight work."
  (when (process-live-p vulpea-db-worker--process)
    ;; Suppress the sentinel's re-enqueueing: an explicit stop
    ;; means the caller does not want the work back.
    (set-process-sentinel vulpea-db-worker--process #'ignore)
    (delete-process vulpea-db-worker--process))
  (vulpea-db-worker--cancel-prestart)
  (when vulpea-db-worker--watchdog-timer
    (cancel-timer vulpea-db-worker--watchdog-timer)
    (setq vulpea-db-worker--watchdog-timer nil))
  (setq vulpea-db-worker--process nil
        vulpea-db-worker--output ""
        vulpea-db-worker--output-pending nil
        vulpea-db-worker--in-flight nil
        vulpea-db-worker--in-flight-tail nil
        vulpea-db-worker--in-flight-count 0
        vulpea-db-worker--current nil)
  ;; Results not applied yet are in-flight work too: applied later,
  ;; they could land in whatever database is current by then
  (when (timerp vulpea-db-worker--results-timer)
    (cancel-timer vulpea-db-worker--results-timer))
  (setq vulpea-db-worker--results-timer nil
        vulpea-db-worker--results nil
        vulpea-db-worker--results-tail nil
        vulpea-db-worker--results-count 0)
  ;; Files waiting for the synchronous fallback are in-flight work too
  (when (timerp vulpea-db-worker--fallback-timer)
    (cancel-timer vulpea-db-worker--fallback-timer))
  (setq vulpea-db-worker--fallback-timer nil
        vulpea-db-worker--fallback-queue nil)
  (clrhash vulpea-db-worker--fallback-attempts)
  (clrhash vulpea-db-worker--force))

(defun vulpea-db-worker-busy-p ()
  "Return non-nil while the worker has unfinished requests.
Results waiting to be applied and files waiting for the synchronous
fallback count too."
  (and (or vulpea-db-worker--in-flight
           vulpea-db-worker--results
           vulpea-db-worker--fallback-queue)
       t))

(defun vulpea-db-worker--org-attach-function-p (fn)
  "Return non-nil when FN is defined by `org-attach' itself.
Those exist in the worker too; anything else is the session's own.
Compares with the file `org-attach' was loaded from, which may be
.elc, .el or compressed source depending on the installation."
  (and (symbolp fn)
       (when-let* ((file (symbol-file fn 'defun))
                   (org-attach-file (symbol-file 'org-attach-dir-from-id
                                                 'defun)))
         (equal file org-attach-file))))

(defvar vulpea-db-worker--attach-functions-cache nil
  "Last attach path decision, as (FUNCTIONS LOAD-HISTORY . FOREIGN).
FUNCTIONS is a copy of the `org-attach-id-to-path-function-list' it
was made for, LOAD-HISTORY the `load-history' it was made under, and
FOREIGN non-nil when some function was not org-attach's own.")

(defun vulpea-db-worker--foreign-attach-functions-p ()
  "Return non-nil when attach paths need functions only the session has.
See `vulpea-db-worker--org-attach-function-p'.  Where a function comes
from is looked up in `load-history', which takes a walk through
everything loaded; the sync queue asks for every file, so the answer
is kept until the function list or `load-history' changes (any load
pushes a new entry to it)."
  (let ((functions (bound-and-true-p org-attach-id-to-path-function-list))
        (cache vulpea-db-worker--attach-functions-cache))
    (if (and cache
             (eq (cadr cache) load-history)
             (equal (car cache) functions))
        (cddr cache)
      (let ((foreign (not (seq-every-p #'vulpea-db-worker--org-attach-function-p
                                       functions))))
        (setq vulpea-db-worker--attach-functions-cache
              (cons (copy-sequence functions) (cons load-history foreign)))
        foreign))))

(defun vulpea-db-worker-rejection-reasons (path)
  "Return the reasons PATH cannot be extracted in the worker, if any.

A list of symbols, nil when the worker can handle PATH faithfully:
- `broken': the worker crash-looped (see `vulpea-db-worker-reset')
- `ast-extractors': registered extractors declare :requires-ast t
  and read the AST, which never crosses the process boundary (all
  other extractors are fine - they run in the main process during
  apply, against a context whose AST slot is nil)
- `heading-level-predicate': `vulpea-db-index-heading-level' is a
  function, which is not serializable
- `attach-path-functions': `org-attach-id-to-path-function-list'
  holds functions that are not org's own; the worker cannot call
  them, and every note with an id needs them
- `extension': PATH is not a plain .org file (decryption may require
  user interaction)"
  (let (reasons)
    (when vulpea-db-worker--broken
      (push 'broken reasons))
    (when (seq-some #'vulpea-extractor-requires-ast-p vulpea-db--extractors)
      (push 'ast-extractors reasons))
    (unless (booleanp vulpea-db-index-heading-level)
      (push 'heading-level-predicate reasons))
    (when (vulpea-db-worker--foreign-attach-functions-p)
      (push 'attach-path-functions reasons))
    (unless (string-suffix-p ".org" path)
      (push 'extension reasons))
    (nreverse reasons)))

(defun vulpea-db-worker-can-handle-p (path)
  "Return non-nil when PATH can be extracted in the worker faithfully.
See `vulpea-db-worker-rejection-reasons' for what disqualifies a
file."
  (null (vulpea-db-worker-rejection-reasons path)))

(defun vulpea-db-worker-should-handle-p (path)
  "Return non-nil when PATH should be extracted in the worker.

Combines `vulpea-db-worker-can-handle-p' (faithfulness) with
`vulpea-db-async-extraction-threshold' (size routing policy)."
  (and (vulpea-db-worker-can-handle-p path)
       (or (null vulpea-db-async-extraction-threshold)
           (let ((attrs (file-attributes path)))
             (and attrs
                  (>= (file-attribute-size attrs)
                      vulpea-db-async-extraction-threshold))))))

(defun vulpea-db-worker--filters-inert-p ()
  "Return non-nil when index filters cannot affect indexing.

`vulpea-db-note-index-filter-functions' run in the main process, so
full-write mode is only faithful while they can make no difference.
The schema-validation filter installs itself unconditionally at
load, but fast-exits allowing everything unless schemas are
registered with a non-silent action - that state is inert.  Any
other filter, or active non-silent schema validation, is not: even
the `warning' action must run in the main process to be seen."
  (let ((filters vulpea-db-note-index-filter-functions))
    (or (null filters)
        (and (equal filters '(vulpea-db-schema-validation--filter))
             (or (eq (bound-and-true-p vulpea-db-schema-validation-action)
                     'silent)
                 (not (and (fboundp 'vulpea-schema-list)
                           (vulpea-schema-list))))))))

(defun vulpea-db-worker--full-write-p ()
  "Return non-nil when the worker should write results itself.

Requires `vulpea-db-async-extraction' to be `full' and inert
`vulpea-db-note-index-filter-functions' (see
`vulpea-db-worker--filters-inert-p'); active filters live in the
main process, so their presence degrades `full' to extract-only."
  (and (eq vulpea-db-async-extraction 'full)
       (not vulpea-db-worker--wal-failed)
       ;; Extractors run during apply; only ones declared :worker-safe
       ;; can do that inside the worker.  If the worker turns out
       ;; unable to resolve one, it falls back to streaming per file.
       (seq-every-p #'vulpea-extractor-worker-safe vulpea-db--extractors)
       (vulpea-db-worker--filters-inert-p)))

(defvar vulpea-db-worker--wal-connection nil
  "Connection object whose WAL pragmas were already applied.
The pragmas contend with the worker's write transactions, so running
them once per request stalls the main thread during bulk syncs; once
per connection is enough (WAL persists in the database, the busy
timeout persists on the connection).")

(defun vulpea-db-worker--wal-ready-p ()
  "Ensure WAL pragmas on the current connection, once."
  (let ((connection (vulpea-db)))
    (if (eq connection vulpea-db-worker--wal-connection)
        t
      (when (vulpea-db-worker--enable-wal connection)
        (setq vulpea-db-worker--wal-connection connection)
        t))))

(defun vulpea-db-worker--enable-wal (connection)
  "Enable WAL journaling and a busy timeout on CONNECTION.

WAL lets the worker write while the main process reads (and vice
versa); the busy timeout makes concurrent write transactions wait
for each other instead of failing.  Returns non-nil when the
database is in WAL mode afterwards; a failure (filesystem without
shared-memory support) marks `vulpea-db-worker--wal-failed'."
  (let ((handle (oref connection handle)))
    (sqlite-pragma handle "busy_timeout=5000")
    (sqlite-pragma handle "journal_mode=WAL")
    (let ((mode (caar (sqlite-select handle "PRAGMA journal_mode"))))
      (if (equal mode "wal")
          t
        (unless vulpea-db-worker--wal-failed
          (setq vulpea-db-worker--wal-failed t)
          (vulpea-db-worker--log "WAL refused, journal_mode=%s" mode)
          (display-warning
           'vulpea
           (format (concat "Could not enable WAL journaling "
                           "(journal_mode stays %S); full-write mode "
                           "degrades to extract-only so worker writes "
                           "cannot block the UI.")
                   mode)
           :warning))
        nil))))

(defun vulpea-db-worker-request (path &optional force)
  "Ask the worker to extract PATH.

The result is applied to the database when it arrives; see
`vulpea-db-worker-done-functions'.  Callers should check
`vulpea-db-worker-can-handle-p' first.

With FORCE non-nil the unchanged-content shortcut is skipped and the
result is applied even when the content hash matches - required when
extraction output changed while content did not (parser epoch or
settings changes)."
  (vulpea-db-worker--ensure)
  ;; A package that registered a link type since the last settings
  ;; message would otherwise have its links indexed as fuzzy ones
  (unless (equal (org-link-types) vulpea-db-worker--sent-link-types)
    (vulpea-db-worker-refresh-settings))
  (when force
    (puthash path t vulpea-db-worker--force))
  ;; Track the path BEFORE sending: a send that errors on a dying
  ;; worker must leave the path recorded so the salvage path (or the
  ;; caller's fallback) recovers it instead of silently losing it
  (let ((node (list path)))
    (if vulpea-db-worker--in-flight
        (setcdr vulpea-db-worker--in-flight-tail node)
      (setq vulpea-db-worker--in-flight node))
    (setq vulpea-db-worker--in-flight-tail node)
    (setq vulpea-db-worker--in-flight-count
          (1+ vulpea-db-worker--in-flight-count)))
  (condition-case err
      (if (and (vulpea-db-worker--full-write-p)
               ;; WAL is a hard requirement for full-write: without it a
               ;; worker write transaction blocks main-process reads.
               ;; Failure degrades this and future requests to extract-only.
               (vulpea-db-worker--wal-ready-p))
          (progn
            (vulpea-db-worker--log "request parse-and-write%s: %s"
                                   (if force " (force)" "") path)
            (vulpea-db-worker--send
             `(parse-and-write ,path ,(expand-file-name vulpea-db-location)
                               ,(and force t))))
        (vulpea-db-worker--log "request parse%s: %s"
                               (if force " (force)" "") path)
        (vulpea-db-worker--send `(parse ,path)))
    (error
     ;; The send failed (worker died mid-send); un-track and re-raise
     ;; so the caller can fall back
     (vulpea-db-worker--forget path)
     (signal (car err) (cdr err)))))

;;; Client: response handling

(defun vulpea-db-worker--filter (proc output)
  "Process protocol OUTPUT lines from the worker PROC.

Output from a process that is no longer the current worker (a
replaced worker still draining its pipe) is discarded - the shared
assembly state belongs to the current worker only.  A dispatch error
on one line is confined to that line: later lines in the same chunk
still dispatch, so one failing apply cannot wedge every in-flight
file behind it."
  (when (eq proc vulpea-db-worker--process)
    (setq vulpea-db-worker--last-activity (float-time))
    (let ((start 0)
          (t0 (current-time))
          line-end)
      (while (setq line-end (string-match "\n" output start))
        (let* ((tail (substring output start line-end))
               (line (if vulpea-db-worker--output-pending
                         (apply #'concat
                                (nreverse (cons tail
                                                vulpea-db-worker--output-pending)))
                       tail)))
          (setq vulpea-db-worker--output-pending nil)
          (setq start (1+ line-end))
          (when (string-prefix-p "(" line)
            (let ((msg (condition-case nil
                           (car (read-from-string line))
                         (error nil))))
              (when msg
                (condition-case err
                    (vulpea-db-worker--dispatch msg)
                  (error
                   (vulpea-db-worker--log "dispatch error on %S: %s"
                                          (car-safe msg)
                                          (error-message-string err))
                   (message "Vulpea: error handling worker reply: %s"
                            (error-message-string err)))))))))
      (when (< start (length output))
        (push (substring output start) vulpea-db-worker--output-pending))
      (when vulpea-db-worker-debug
        (let ((ms (* 1000 (float-time (time-subtract (current-time) t0)))))
          (when (> ms 50)
            (vulpea-db-worker--log "filter: %.0fms on %d bytes (slow)"
                                   ms (length output))))))))

(defvar vulpea-db-worker--reported-failures (make-hash-table :test #'equal)
  "Worker failure messages already shown, so each is shown once.")

(defun vulpea-db-worker--dispatch (msg)
  "Handle one protocol MSG from the worker."
  (pcase msg
    (`(begin ,path)
     (setq vulpea-db-worker--current (list :path path)))
    (`(file-node ,data)
     (setq vulpea-db-worker--current
           (plist-put vulpea-db-worker--current :file-node data)))
    (`(heading-node ,data)
     (setq vulpea-db-worker--current
           (plist-put vulpea-db-worker--current :heading-nodes
                      (cons data (plist-get vulpea-db-worker--current
                                            :heading-nodes)))))
    (`(done ,path ,hash ,mtime ,size)
     (vulpea-db-worker--note-success)
     (let ((current vulpea-db-worker--current)
           (force (gethash path vulpea-db-worker--force)))
       (setq vulpea-db-worker--current nil)
       (vulpea-db-worker--forget path)
       (vulpea-db-worker--log "done %s" path)
       (vulpea-db-worker--queue-result
        (list path hash mtime size
              (plist-get current :file-node)
              (nreverse (plist-get current :heading-nodes))
              force))))
    ;; Full-write mode: the worker wrote the database itself; the
    ;; main process only maintains org-ids and re-checks freshness.
    ;; The trailing elements (claimants, then the ids the write
    ;; released) are matched as a rest so a reply from a worker
    ;; running older code (a mid-session upgrade) still lands here
    ;; instead of being silently dropped - with fewer elements, the
    ;; missing ones read as nil.
    (`(written ,path ,_hash ,mtime ,size ,count ,ids . ,rest)
     (vulpea-db-worker--note-success)
     (vulpea-db-worker--log "written %s: %s notes" path count)
     (vulpea-db-worker--forget path)
     ;; Files whose pending id claim the worker's write released:
     ;; only this process can queue their re-index (forced - their
     ;; change-detection row is already gone, this makes the retry
     ;; survive queue paths that consult a stale hash cache).
     (dolist (claimant (car rest))
       (vulpea-db-worker--reenqueue claimant 'force))
     (let ((attrs (file-attributes path)))
       (cond
        ;; File vanished while the worker was writing (deleted or
        ;; renamed after the worker's stat, before its commit): what
        ;; just landed are ghost notes for a nonexistent path - remove
        ;; them.  The removal event handler was a no-op if it ran
        ;; before the commit.
        ((null attrs)
         (vulpea-db--forget-file path)
         (run-hook-with-args 'vulpea-db-worker-done-functions
                             path 'missing nil))
        (t
         (vulpea-db--register-id-locations ids path)
         ;; Ids the re-parse no longer found: the worker's apply ran
         ;; with SKIP-ORG-ID, so their registrations are dropped here.
         (vulpea-db--unregister-id-locations (cadr rest) path)
         (when (or (not (equal (float-time
                                (file-attribute-modification-time attrs))
                               mtime))
                   (not (equal (file-attribute-size attrs) size)))
           ;; Changed again while the worker was writing: what landed
           ;; reflects older content, re-parse to catch up.
           (vulpea-db-worker--reenqueue path))
         ;; The apply ran in the worker process, where the
         ;; data-changed hook is empty - announce it here.  The
         ;; streamed path needs no counterpart: its apply runs in
         ;; this process and announces itself.
         (run-hook-with-args 'vulpea-db-updated-functions path count)
         (run-hook-with-args 'vulpea-db-worker-done-functions
                             path 'applied count)))))
    (`(stamped ,path ,ids)
     (vulpea-db-worker--note-success)
     (vulpea-db-worker--forget path)
     ;; Repair org-id registrations a lost written reply never made
     (vulpea-db--register-id-locations ids path)
     (run-hook-with-args 'vulpea-db-worker-done-functions
                         path 'unchanged nil))
    (`(stale ,path)
     (let ((force (gethash path vulpea-db-worker--force)))
       (vulpea-db-worker--forget path)
       (vulpea-db-worker--reenqueue path force))
     (run-hook-with-args 'vulpea-db-worker-done-functions
                         path 'stale nil))
    (`(extractors ,resolved ,missing)
     (vulpea-db-worker--log "worker extractors: resolved %S, missing %S"
                            resolved missing)
     (when (and missing (not vulpea-db-worker--extractors-warned))
       (setq vulpea-db-worker--extractors-warned t)
       (display-warning
        'vulpea
        (format (concat "Worker could not resolve extractor(s) %S; "
                        "their files fall back to main-process apply.  "
                        "Check :worker-lib on the extractor definition.")
                missing)
        :warning)))
    (`(handback ,path ,reason)
     ;; Not a failure: the file needs something only the session has
     (setq vulpea-db-worker--current nil)
     (vulpea-db-worker--forget path)
     (vulpea-db-worker--log "handback %s: %s" path reason)
     (unless (gethash reason vulpea-db-worker--reported-failures)
       (puthash reason t vulpea-db-worker--reported-failures)
       (message "Vulpea: %s needs your session (%s); files like it are indexed synchronously"
                (file-name-nondirectory path) reason))
     (vulpea-db-worker--queue-fallback path))
    (`(error ,path ,message)
     (setq vulpea-db-worker--current nil)
     (vulpea-db-worker--forget path)
     (vulpea-db-worker--log "error %s: %s" path message)
     ;; The worker can fail where the session would not (a setting
     ;; naming a function only the session defines, a package it does
     ;; not load); index the file here rather than leave it out
     (if (not (file-exists-p path))
         (run-hook-with-args 'vulpea-db-worker-done-functions
                             path 'error nil)
       (unless (gethash message vulpea-db-worker--reported-failures)
         (puthash message t vulpea-db-worker--reported-failures)
         (message "Vulpea: worker failed on %s (%s); files it fails on are indexed synchronously"
                  path message))
       (vulpea-db-worker--queue-fallback path)))))

(defun vulpea-db-worker--queue-fallback (path)
  "Index PATH synchronously soon, outside the worker's reply handler.
The handler runs with quitting inhibited, and a setting that breaks
every file would make it parse one file after another; a timer takes
one file per tick instead."
  (setq vulpea-db-worker--fallback-queue
        (append vulpea-db-worker--fallback-queue (list path)))
  (unless (timerp vulpea-db-worker--fallback-timer)
    (setq vulpea-db-worker--fallback-timer
          (run-with-timer 0 nil #'vulpea-db-worker--run-fallback))))

(defun vulpea-db-worker--fallback-done (path status count)
  "Announce that the fallback finished PATH with STATUS and COUNT.
A hook function that signals is reported, not propagated: it must not
cost the files still waiting in the queue."
  (condition-case err
      (run-hook-with-args 'vulpea-db-worker-done-functions path status count)
    (error
     (message "Vulpea: error in vulpea-db-worker-done-functions: %s"
              (error-message-string err)))))

(defun vulpea-db-worker--run-fallback ()
  "Index the next file the worker failed on, in this process.
Further entries for the same file are served by the same parse, but
each still gets its own completion, reported as unchanged.  The next
tick is scheduled whatever happens here, a signalling hook included,
so the queue never strands."
  (setq vulpea-db-worker--fallback-timer nil)
  (unwind-protect
      (when-let* ((path (pop vulpea-db-worker--fallback-queue)))
        ;; Take this file's other entries now: the parse below can let
        ;; the reply handler run, and whatever it queues meanwhile must
        ;; get a run of its own
        (let* ((extra (prog1 (seq-count (lambda (p) (equal p path))
                                        vulpea-db-worker--fallback-queue)
                        (setq vulpea-db-worker--fallback-queue
                              (delete path vulpea-db-worker--fallback-queue))))
               (locked nil)
               (count (condition-case err
                          (when (file-exists-p path)
                            (vulpea-db-update-file path))
                        ;; The full-write worker may be committing: try
                        ;; again shortly rather than leave the file out
                        ((sqlite-locked-error emacsql-locked)
                         (let ((attempts (1+ (gethash path vulpea-db-worker--fallback-attempts 0))))
                           (if (< attempts vulpea-db-worker--fallback-max-attempts)
                               (progn
                                 (puthash path attempts vulpea-db-worker--fallback-attempts)
                                 (setq locked t))
                             (message "Vulpea: failed to index %s: %s"
                                      path (error-message-string err))))
                         nil)
                        (error
                         (message "Vulpea: failed to index %s: %s"
                                  path (error-message-string err))
                         nil))))
          (if locked
              ;; Back to the queue, entries and all, for a later tick
              (progn
                (setq vulpea-db-worker--fallback-queue
                      (append vulpea-db-worker--fallback-queue
                              (make-list (1+ extra) path)))
                ;; A file queued during the parse scheduled a tick of
                ;; its own; one timer at a time keeps the retries apart
                (when (timerp vulpea-db-worker--fallback-timer)
                  (cancel-timer vulpea-db-worker--fallback-timer))
                (setq vulpea-db-worker--fallback-timer
                      (run-with-timer 0.25 nil #'vulpea-db-worker--run-fallback)))
            (remhash path vulpea-db-worker--fallback-attempts)
            (vulpea-db-worker--fallback-done
             path (if count 'applied 'error) count)
            (dotimes (_ extra)
              (vulpea-db-worker--fallback-done
               path (if count 'unchanged 'error) nil)))))
    (when (and vulpea-db-worker--fallback-queue
               (not (timerp vulpea-db-worker--fallback-timer)))
      (setq vulpea-db-worker--fallback-timer
            (run-with-timer 0 nil #'vulpea-db-worker--run-fallback)))))

(defun vulpea-db-worker--reenqueue (path &optional force)
  "Schedule PATH for another pass, via the sync queue when active.
FORCE is carried along so a forced re-index cannot be lost to the
unchanged-content shortcut on the retry.

Without the sync queue, falls back to a direct worker request - or,
when the worker cannot take it (crash-looped and marked broken, or
unable to start at all), a synchronous `vulpea-db-update-file', so the
file is never dropped.  Salvage calls this once per file, so nothing
here may signal: the files after this one depend on it."
  (let ((reindex (lambda ()
                   (condition-case err
                       (when (file-exists-p path)
                         (vulpea-db-update-file path))
                     (error
                      (message "Vulpea: failed to re-index %s: %s"
                               path (error-message-string err)))))))
    (cond
     ((and (bound-and-true-p vulpea-db-autosync-mode)
           (fboundp 'vulpea-db-sync--enqueue))
      (vulpea-db-sync--enqueue path force))
     ((vulpea-db-worker-can-handle-p path)
      ;; A respawn that fails marks the worker broken and signals;
      ;; the file then goes the synchronous way like any other
      (condition-case nil
          (vulpea-db-worker-request path force)
        (error (funcall reindex))))
     (t
      (funcall reindex)))))

(defun vulpea-db-worker--note-success ()
  "Record a successful completion: the worker is demonstrably alive."
  (setq vulpea-db-worker--hang-kills 0))

(defun vulpea-db-worker--forget (path)
  "Drop PATH from the in-flight list.
The worker answers in request order, so PATH is almost always the
head; falling back to a full scan keeps this correct either way."
  (remhash path vulpea-db-worker--force)
  (if (equal (car vulpea-db-worker--in-flight) path)
      ;; Every reply lands here: no walk over the window
      (progn
        (pop vulpea-db-worker--in-flight)
        (setq vulpea-db-worker--in-flight-count
              (max 0 (1- vulpea-db-worker--in-flight-count)))
        (unless vulpea-db-worker--in-flight
          (setq vulpea-db-worker--in-flight-tail nil)))
    (setq vulpea-db-worker--in-flight
          (delete path vulpea-db-worker--in-flight))
    (setq vulpea-db-worker--in-flight-tail
          (last vulpea-db-worker--in-flight))
    (setq vulpea-db-worker--in-flight-count
          (length vulpea-db-worker--in-flight))))

(defun vulpea-db-worker--complete (path hash mtime size current &optional force)
  "Apply a completed extraction of PATH to the database right away.

HASH, MTIME and SIZE describe the file as the worker read it;
CURRENT carries the extracted nodes (see `vulpea-db-worker--current').
With FORCE non-nil the unchanged-content shortcut is skipped.  The
result is applied on its own, in a transaction of its own; see
`vulpea-db-worker--apply-result' for what happens to it."
  (vulpea-db-worker--apply-batch
   (list (list path hash mtime size
               (plist-get current :file-node)
               (reverse (plist-get current :heading-nodes))
               force))
   nil))

;;; Client: applying results
;;
;; Results are applied in batches, one transaction for as many files
;; as fit in a short time slice: a transaction per file spends most
;; of the main thread's indexing time committing.

(defvar vulpea-db-worker--results-delay 0.05
  "Seconds a result waits for others while more requests are in flight.
Replies of a bulk sync arrive a few at a time; waiting a moment lets
them share a transaction.  A result arriving when nothing else is in
flight - the usual save - is applied at once.")

(defvar vulpea-db-worker--results-budget 0.05
  "Seconds of applying after which a batch commits and yields.
The rest of a backlog is applied from a timer, so input is handled
in between.  A batch always takes at least one file, however long
that file takes.")

(defvar vulpea-db-worker--applying nil
  "Non-nil while results are being applied.
Hooks run after a batch commits may let the filter run; results it
queues then wait for the timer instead of starting a batch inside
this one.")

(defun vulpea-db-worker--queue-result (result)
  "Queue RESULT for `vulpea-db-worker--apply-results'.
Applies at once when no other request is in flight, otherwise within
`vulpea-db-worker--results-delay'."
  (let ((node (list result)))
    (if vulpea-db-worker--results
        (setcdr vulpea-db-worker--results-tail node)
      (setq vulpea-db-worker--results node))
    (setq vulpea-db-worker--results-tail node)
    (setq vulpea-db-worker--results-count
          (1+ vulpea-db-worker--results-count)))
  (cond
   ((null vulpea-db-worker--in-flight)
    (vulpea-db-worker--apply-results))
   ((not (timerp vulpea-db-worker--results-timer))
    (vulpea-db-worker--schedule-results vulpea-db-worker--results-delay))))

(defun vulpea-db-worker--schedule-results (delay)
  "Apply waiting results in DELAY seconds, replacing any armed timer."
  (when (timerp vulpea-db-worker--results-timer)
    (cancel-timer vulpea-db-worker--results-timer))
  (setq vulpea-db-worker--results-timer
        (run-with-timer delay nil #'vulpea-db-worker--apply-results)))

(defun vulpea-db-worker--apply-results ()
  "Apply waiting worker results, one batch per time slice.

Results that do not fit `vulpea-db-worker--results-budget' are left
for a timer.  Nothing is applied while a transaction is open: the
filter can run inside one (code holding it waited for input), and
results applied there would be announced before their data is
committed, or rolled back along with that transaction."
  (when (timerp vulpea-db-worker--results-timer)
    (cancel-timer vulpea-db-worker--results-timer))
  (setq vulpea-db-worker--results-timer nil)
  (when vulpea-db-worker--results
    (if (or vulpea-db-worker--applying
            (> emacsql--transaction-level 0))
        (vulpea-db-worker--schedule-results vulpea-db-worker--results-delay)
      (let ((batch vulpea-db-worker--results)
            (t0 (float-time))
            rest)
        (setq vulpea-db-worker--results nil
              vulpea-db-worker--results-tail nil
              vulpea-db-worker--results-count 0)
        (unwind-protect
            (let ((vulpea-db-worker--applying t))
              (setq rest (vulpea-db-worker--apply-batch
                          batch vulpea-db-worker--results-budget)))
          (when vulpea-db-worker-debug
            (let ((applied (- (length batch) (length rest))))
              (vulpea-db-worker--log "applied %d result%s in %.0fms (main)"
                                     applied (if (= applied 1) "" "s")
                                     (* 1000 (- (float-time) t0)))))
          ;; Unapplied results go back ahead of those that arrived
          ;; while hooks ran, so a file's results stay in order
          (when rest
            (setq vulpea-db-worker--results
                  (nconc rest vulpea-db-worker--results)))
          (setq vulpea-db-worker--results-tail (last vulpea-db-worker--results)
                vulpea-db-worker--results-count
                (length vulpea-db-worker--results))
          (when vulpea-db-worker--results
            (vulpea-db-worker--schedule-results 0)))))))

(defun vulpea-db-worker--apply-batch (results budget)
  "Apply RESULTS in one transaction, until BUDGET seconds have passed.

Returns the results not attempted.  BUDGET nil applies them all; a
batch always takes at least one.  Each result is applied as
`vulpea-db-worker--apply-result' describes, and announced once the
transaction has committed, in order: `vulpea-db-updated-functions'
for a file whose notes were written, then
`vulpea-db-worker-done-functions'.

When the transaction itself fails - the write lock or the commit
not obtained within the busy timeout - nothing was written, and the
results are applied again one transaction per file, as each would
have been on its own."
  (let ((start (float-time))
        (rest results)
        taken outcomes claimants removals failure)
    (condition-case err
        (let ((vulpea-db--deferred-claimants nil)
              (vulpea-db--pending-removal-announcements nil))
          (vulpea-db--with-transaction (vulpea-db)
            (while (and rest
                        (or (null taken)
                            (null budget)
                            (< (- (float-time) start) budget)))
              (let ((result (pop rest)))
                (push result taken)
                (push (vulpea-db-worker--apply-result result) outcomes))))
          (setq claimants vulpea-db--deferred-claimants
                removals vulpea-db--pending-removal-announcements))
      (error (setq failure (error-message-string err))))
    (cond
     ((null failure)
      (vulpea-db-worker--announce (nreverse outcomes) removals claimants))
     ((cdr taken)
      (vulpea-db-worker--log "batch of %d failed (%s), applying one by one"
                             (length taken) failure)
      (dolist (result (nreverse taken))
        (vulpea-db-worker--apply-batch (list result) nil)))
     (t
      ;; One file, or none taken because the transaction never began
      (let ((path (car (or (car taken) (pop rest)))))
        (message "Vulpea: failed to apply %s: %s" path failure)
        (vulpea-db-worker--announce (list (list path 'error)) nil nil))))
    rest))

(defun vulpea-db-worker--apply-result (result)
  "Apply RESULT inside the open transaction and return its outcome.

RESULT is an entry of `vulpea-db-worker--results'.  A stale result -
the file changed or disappeared since the worker read it - is not
applied; a changed file is re-enqueued once the batch commits.  For
content identical to what is indexed only the stored stamp is
refreshed, so the cheap mtime/size check passes next time; a forced
result skips that shortcut, since extraction output changed even
though content did not.  Anything else is written through
`vulpea-db--apply-parse-ctx'.

The file's writes are undone if applying it fails, leaving the rest
of the batch alone.  Returns (PATH STATUS COUNT FORCE UPDATES), where
STATUS is one `vulpea-db-worker-done-functions' reports and UPDATES
are the held announcements of `vulpea-db-updated-functions'."
  (pcase-let ((`(,path ,hash ,mtime ,size ,file-node ,heading-nodes ,force)
               result))
    (let ((attrs (file-attributes path)))
      (cond
       ;; File vanished while parsing: the deletion event handles the
       ;; database; nothing to apply
       ((null attrs)
        (list path 'missing))
       ;; File changed while parsing: discard and re-parse
       ((or (not (equal (float-time (file-attribute-modification-time attrs))
                        mtime))
            (not (equal (file-attribute-size attrs) size)))
        (list path 'stale nil force))
       (t
        (let ((held (list 'held)))
          (condition-case err
              (vulpea-db--with-savepoint (vulpea-db)
                (if (and (not force)
                         (equal (plist-get (vulpea-db--get-file-hash path) :hash)
                                hash))
                    (progn
                      (vulpea-db--update-file-hash path hash mtime size)
                      (list path 'unchanged))
                  (let ((count
                         (let ((vulpea-db--held-updates held))
                           (vulpea-db--apply-parse-ctx
                            (make-vulpea-parse-ctx
                             :path path
                             :ast nil
                             :file-node file-node
                             :heading-nodes heading-nodes
                             :hash hash
                             :mtime mtime
                             :size size)))))
                    (list path 'applied count nil (reverse (cdr held))))))
            (error
             (message "Vulpea: failed to apply %s: %s"
                      path (error-message-string err))
             (list path 'error)))))))))

(defun vulpea-db-worker--run-hook (hook &rest args)
  "Run HOOK with ARGS, reporting an error instead of signalling it.
One failing handler must not cost the files announced after it."
  (condition-case err
      (apply #'run-hook-with-args hook args)
    (error
     (message "Vulpea: error in %s: %s" hook (error-message-string err)))))

(defun vulpea-db-worker--announce (outcomes removals claimants)
  "Announce committed OUTCOMES of `vulpea-db-worker--apply-result'.

REMOVALS are paths forgotten inside the transaction, announced
first.  Stale files are re-enqueued with their force flag.
CLAIMANTS are files whose pending claim the batch released and that
could not be re-indexed inside the transaction (see
`vulpea-db--deferred-claimants'); they are re-indexed last, as the
same claim resolution outside a transaction would do."
  (let ((vulpea-db--pending-removal-announcements removals))
    (condition-case err
        (vulpea-db--flush-removal-announcements)
      (error
       (message "Vulpea: error in vulpea-db-updated-functions: %s"
                (error-message-string err)))))
  (pcase-dolist (`(,path ,status ,count ,force ,updates) outcomes)
    (when (eq status 'stale)
      (vulpea-db-worker--reenqueue path force))
    (pcase-dolist (`(,updated . ,notes) updates)
      (vulpea-db-worker--run-hook 'vulpea-db-updated-functions updated notes))
    (vulpea-db-worker--run-hook 'vulpea-db-worker-done-functions
                                path status count))
  (dolist (claimant (reverse claimants))
    (when (file-exists-p claimant)
      (condition-case err
          (let ((vulpea-db--claims-resolving
                 (cons claimant vulpea-db--claims-resolving)))
            (vulpea-db-update-file claimant))
        (error
         (message "Vulpea: failed to re-index %s: %s"
                  claimant (error-message-string err)))))))

(defun vulpea-db-worker--crash-loop-p ()
  "Record the current death and detect a crash loop.
A crash loop is three deaths within 10 seconds of their spawn,
inside one minute.  Long-lived workers dying (or being killed) do
not count."
  (when (and vulpea-db-worker--spawn-time
             (< (- (float-time) vulpea-db-worker--spawn-time) 10))
    (push (float-time) vulpea-db-worker--crash-times))
  (setq vulpea-db-worker--crash-times
        (seq-filter (lambda (time) (< (- (float-time) time) 60))
                    vulpea-db-worker--crash-times))
  (>= (length vulpea-db-worker--crash-times) 3))

(defun vulpea-db-worker--stderr-tail ()
  "Return the last few lines of the worker's stderr, for diagnostics."
  (if-let* ((buffer (get-buffer " *vulpea-worker-stderr*")))
      (with-current-buffer buffer
        (save-excursion
          (goto-char (point-max))
          (forward-line -10)
          (string-trim (buffer-substring-no-properties
                        (point) (point-max)))))
    ""))

(defun vulpea-db-worker--sentinel (proc event)
  "Handle worker PROC death (EVENT): re-enqueue in-flight work.

Only acts while PROC is still the current worker: a deferred
sentinel firing after `vulpea-db-worker--ensure' already salvaged
and replaced the process must not clobber the replacement's state
\(orphaning the live process, double re-enqueueing its files).

Detects crash loops: a worker that keeps dying right after spawning
marks itself broken (see `vulpea-db-worker--broken') instead of
respawning forever, and the sync queue falls back to synchronous
processing."
  (when (and (not (process-live-p proc))
             (eq proc vulpea-db-worker--process))
    (vulpea-db-worker--log "worker died: %s; stderr tail: %s"
                           (string-trim event)
                           (vulpea-db-worker--log-truncate
                            (vulpea-db-worker--stderr-tail) 500))
    (when (vulpea-db-worker--crash-loop-p)
      (setq vulpea-db-worker--broken t)
      (display-warning
       'vulpea
       (format (concat "Extraction worker keeps dying; falling back to "
                       "synchronous indexing.  Last stderr:\n%s\n"
                       "Run M-x vulpea-db-worker-diagnose to investigate, "
                       "M-x vulpea-db-worker-reset to retry.")
               (vulpea-db-worker--stderr-tail))
       :error))
    (vulpea-db-worker--salvage)))

;;; Worker side (runs in emacs --batch)

(defun vulpea-db-worker--reply (form)
  "Print FORM as one protocol line on stdout."
  (princ (vulpea-db-worker--print form))
  (princ "\n"))

(defvar vulpea-db-worker--unresolved-extractors nil
  "Names of declared worker-safe extractors this worker cannot run.
Non-nil makes `parse-and-write' requests fall back to streaming, so
those extractors run in the main process instead.")

(defvar vulpea-db-worker--version-mismatch nil
  "Non-nil when this worker's vulpea differs from the main process's.

Set from the db constants in the settings message.  A worker running
different code must never open the database: `vulpea-db--init' deletes
and rebuilds the database file on a schema version mismatch, which
would destroy the main process's data from underneath it.  While set,
`parse-and-write' requests fall back to streaming results.")

(defvar vulpea-db-worker--session-abbrev-tags nil
  "Link abbreviations that expand through a function of the session.
Worker side; see `vulpea-db-worker--portable-link-abbrevs'.")

(defun vulpea-db-worker--apply-session-abbrevs ()
  "Split session-only link abbreviations out of `org-link-abbrev-alist'.
Worker side: keeps the portable ones for org and remembers the others
in `vulpea-db-worker--session-abbrev-tags'."
  (when (boundp 'org-link-abbrev-alist)
    (setq vulpea-db-worker--session-abbrev-tags
          (mapcar #'car (seq-filter
                         (lambda (entry)
                           (eq (cdr entry) :vulpea-session-function))
                         (default-value 'org-link-abbrev-alist))))
    (set-default 'org-link-abbrev-alist
                 (seq-remove (lambda (entry)
                               (eq (cdr entry) :vulpea-session-function))
                             (default-value 'org-link-abbrev-alist)))))

(defun vulpea-db-worker--session-abbrev-used-p (path)
  "Return non-nil when PATH links through a session-only abbreviation.
See `vulpea-db-worker--session-abbrev-tags'.  Reads PATH only when
there are such abbreviations."
  (when vulpea-db-worker--session-abbrev-tags
    (with-temp-buffer
      (insert-file-contents path)
      (let ((case-fold-search nil))
        (re-search-forward
         (concat "\\[\\[" (regexp-opt vulpea-db-worker--session-abbrev-tags)
                 "[]:]")
         nil t)))))

(defvar vulpea-db-worker--session-abbrev-expanded nil
  "Non-nil once the current parse expanded a %(...) link abbreviation.
Worker side; see `vulpea-db-worker--note-abbrev-expansion'.")

(defun vulpea-db-worker--note-abbrev-expansion (link)
  "Note when LINK expands through a %(...) link abbreviation.
Installed in the worker as advice before `org-link-expand-abbrev'.
Org calls the function named in %(...), which exists only in the
session, and on failure drops the abbreviation without a trace, so
the worker watches the expansion itself.  That covers abbreviations
from the settings, the file's own #+LINK: keywords and setup files
alike, and only those the parse actually uses.  Mirrors the lookup
of `org-link-expand-abbrev'."
  (save-match-data
    (when (and (stringp link)
               (string-match "^\\([^:]*\\)\\(::?\\(.*\\)\\)?$" link))
      (let* ((key (match-string 1 link))
             (entry (or (assoc key (bound-and-true-p org-link-abbrev-alist-local))
                        (assoc key org-link-abbrev-alist))))
        (when (and entry
                   (stringp (cdr entry))
                   (string-search "%(" (cdr entry)))
          (setq vulpea-db-worker--session-abbrev-expanded t))))))

(define-error 'vulpea-db-worker-handback
  "File needs the session to be indexed faithfully")

(defun vulpea-db-worker--parse-file (path)
  "Parse PATH in the worker, as `vulpea-db--parse-file' does.
Signals `vulpea-db-worker-handback' when the result would differ
from the session's because the file needs one of its functions; the
handlers answer with a `handback' reply, and the main process indexes
the file synchronously."
  (let* ((vulpea-db-worker--session-abbrev-expanded nil)
         (ctx (vulpea-db--parse-file path)))
    (when vulpea-db-worker--session-abbrev-expanded
      (signal 'vulpea-db-worker-handback
              '("it links through an abbreviation that expands with a function from your session")))
    ctx))

(defun vulpea-db-worker--apply-settings (vars link-types extractors
                                              &optional db-constants)
  "Set allowlisted VARS, register LINK-TYPES and EXTRACTORS here.

DB-CONSTANTS is a plist with the main process's :db-version and
:parser-epoch; a mismatch against this worker's constants disables
full-write mode (see `vulpea-db-worker--version-mismatch').

EXTRACTORS are wire specs of worker-safe extractors (see
`vulpea-db-worker--extractor-specs').  Each is resolved by loading
its :lib and checking its :fn; resolved ones are installed in this
worker's extractor registry (without schema - the main process owns
DDL), unresolved ones are reported back and disable full-write for
this worker."
  ;; set-default, not set: an automatically-buffer-local variable
  ;; (org-category) would otherwise be set locally in whatever buffer
  ;; is current here, invisible to the parse buffers extraction uses.
  (pcase-dolist (`(,sym . ,value) vars)
    (if (eq sym 'vulpea-db-worker--safe-local-properties)
        (pcase-dolist (`(,var . ,prop) value)
          (put var 'safe-local-variable prop))
      (set-default sym value)))
  (vulpea-db-worker--apply-session-abbrevs)
  ;; With t, one variable the worker does not know to be safe (packages
  ;; mark theirs with a property, and the worker does not load them)
  ;; sends the whole set to a prompt, which batch answers with no.  The
  ;; session applies it; applying what is known safe and skipping the
  ;; rest is the closest the worker can get
  (when (eq enable-local-variables t)
    (setq-default enable-local-variables :safe))
  ;; A code-version mismatch (main upgraded vulpea while running, or
  ;; stale byte-code) forbids opening the database from this worker:
  ;; vulpea-db--init would delete and rebuild it on a schema mismatch
  (setq vulpea-db-worker--version-mismatch
        (not (and (equal (plist-get db-constants :db-version)
                         vulpea-db-version)
                  (equal (plist-get db-constants :parser-epoch)
                         vulpea-db-parser-epoch))))
  (when vulpea-db-worker--version-mismatch
    (message "vulpea worker: version mismatch (main %S/%S, worker %S/%S), full-write disabled"
             (plist-get db-constants :db-version)
             (plist-get db-constants :parser-epoch)
             vulpea-db-version vulpea-db-parser-epoch))
  (require 'ol)
  (dolist (type link-types)
    (unless (assoc type org-link-parameters)
      (org-link-set-parameters type)))
  (org-link-make-regexps)
  (when (fboundp 'org-element-update-syntax)
    (org-element-update-syntax))
  ;; Resolve worker-safe extractors
  (let (resolved missing)
    (dolist (spec extractors)
      (let ((name (plist-get spec :name))
            (fn (plist-get spec :fn))
            (lib (plist-get spec :lib)))
        (when lib
          (condition-case nil
              (if (stringp lib)
                  (load lib nil t)
                (require lib))
            (error nil)))
        (if (and fn (fboundp fn))
            (push (make-vulpea-extractor
                   :name name
                   :priority (or (plist-get spec :priority) 100)
                   :extract-fn fn
                   :requires-ast (plist-get spec :requires-ast)
                   :worker-safe t)
                  resolved)
          (push name missing))))
    (setq vulpea-db--extractors
          (sort (nreverse resolved)
                (lambda (a b)
                  (< (vulpea-extractor-priority a)
                     (vulpea-extractor-priority b)))))
    (setq vulpea-db-worker--unresolved-extractors (nreverse missing))
    (vulpea-db-worker--reply
     `(extractors ,(mapcar #'vulpea-extractor-name vulpea-db--extractors)
                  ,vulpea-db-worker--unresolved-extractors))))

(defvar vulpea-db-worker--db-location nil
  "Database location this worker currently has open, or nil.")

(defun vulpea-db-worker--ensure-db (db)
  "Open (or reuse) a connection to the database at DB in this worker.
Enables WAL journaling and a busy timeout so writes interleave
safely with the main process."
  (unless (equal db vulpea-db-worker--db-location)
    (when vulpea-db--connection
      (vulpea-db-close))
    (setq vulpea-db-location db
          vulpea-db-worker--db-location db))
  (vulpea-db-worker--wal-ready-p))

(defun vulpea-db-worker--ctx-ids (ctx)
  "Return the note IDs carried by CTX.
Only used in full-write mode, where no index filters are active, so
every extracted note is written."
  (let (ids)
    (when-let* ((id (plist-get (vulpea-parse-ctx-file-node ctx) :id)))
      (push id ids))
    (dolist (node (vulpea-parse-ctx-heading-nodes ctx))
      (when-let* ((id (plist-get node :id)))
        (push id ids)))
    (nreverse ids)))

(defun vulpea-db-worker--apply-guarded (ctx stored)
  "Apply CTX unless the stored file stamp moved from STORED.

Compare-and-swap for full-write mode: the main process may have
re-indexed the same file (a programmatic `vulpea-db-update-file',
e.g. from `vulpea-meta-set') between this worker's checks and its
write.  Re-reading the stored stamp inside the write transaction
detects that; a moved stamp means our result is outdated and must
not clobber the newer data.  A transaction that fails to commit
under write contention counts as a conflict too - retrying via the
queue is always safe.

Returns the number of notes written, `conflict', or (error . MSG)
for a deterministic failure - only lock contention retries; anything
else must surface instead of looping through silent retries forever."
  (condition-case err
      (vulpea-db--with-transaction (vulpea-db)
        (if (not (equal (vulpea-db--get-file-hash
                         (vulpea-parse-ctx-path ctx))
                        stored))
            'conflict
          (vulpea-db--apply-parse-ctx ctx 'skip-org-id)))
    ((emacsql-locked sqlite-locked-error) 'conflict)
    (sqlite-error
     ;; SQLITE_BUSY surfaces as a generic sqlite-error whose message
     ;; mentions locking; treat those as contention, the rest as real
     (if (string-match-p "locked\\|busy"
                         (downcase (error-message-string err)))
         'conflict
       (cons 'error (error-message-string err))))
    (error (cons 'error (error-message-string err)))))

(defun vulpea-db-worker--handle-parse-and-write (path db &optional force)
  "Extract PATH and write the results to the database at DB.

Full-write mode: this worker owns the database write; the reply
tells the main process what happened so it can register org-ids and
unregister the ones the write released (`written'), note the no-op
\(`stamped'), or re-queue a file whose
result became outdated (`stale') - because the file changed
mid-parse, or because the main process indexed newer content
concurrently (see `vulpea-db-worker--apply-guarded').

With FORCE non-nil the unchanged-content shortcut is skipped and the
result is written even when the content hash matches."
  (if (or vulpea-db-worker--unresolved-extractors
          ;; Version mismatch: opening the db from here could destroy
          ;; it (vulpea-db--init rebuilds on schema mismatch)
          vulpea-db-worker--version-mismatch)
      ;; Stream the results instead; the main process applies them
      (vulpea-db-worker--handle-parse path)
    (condition-case err
      (progn
        (vulpea-db-worker--ensure-db db)
        (let* ((stored (vulpea-db--get-file-hash path))
               (ctx (vulpea-db-worker--parse-file path))
               (attrs (file-attributes path)))
          (cond
           ;; File changed or vanished while parsing: the result
           ;; does not represent the file anymore
           ((or (null attrs)
                (not (equal (float-time
                             (file-attribute-modification-time attrs))
                            (vulpea-parse-ctx-mtime ctx)))
                (not (equal (file-attribute-size attrs)
                            (vulpea-parse-ctx-size ctx))))
            (vulpea-db-worker--reply `(stale ,path)))
           ;; Content identical to what is indexed: refresh the stamp.
           ;; Skipped when forced - extraction output changed even
           ;; though content did not.
           ((and (not force)
                 (equal (plist-get stored :hash)
                        (vulpea-parse-ctx-hash ctx)))
            (vulpea-db--update-file-hash path
                                         (vulpea-parse-ctx-hash ctx)
                                         (vulpea-parse-ctx-mtime ctx)
                                         (vulpea-parse-ctx-size ctx))
            ;; Carry the note IDs: if a previous written reply was
            ;; lost (worker crash after commit), the retry lands here
            ;; and the main process can still register org-ids
            (vulpea-db-worker--reply
             `(stamped ,path ,(vulpea-db-worker--ctx-ids ctx))))
           (t
            ;; Claim resolution inside the write transaction cannot
            ;; re-index another file from this process; collect the
            ;; deferred claimants and let the main process queue them.
            (let* ((vulpea-db--deferred-claimants nil)
                   (vulpea-db--released-ids nil)
                   (count (vulpea-db-worker--apply-guarded ctx stored))
                   (claimants vulpea-db--deferred-claimants)
                   (released vulpea-db--released-ids))
              (cond
               ((eq count 'conflict)
                (vulpea-db-worker--reply `(stale ,path)))
               ((eq (car-safe count) 'error)
                (vulpea-db-worker--reply `(error ,path ,(cdr count))))
               (t
                (vulpea-db-worker--reply
                 `(written ,path
                           ,(vulpea-parse-ctx-hash ctx)
                           ,(vulpea-parse-ctx-mtime ctx)
                           ,(vulpea-parse-ctx-size ctx)
                           ,count
                           ,(vulpea-db-worker--ctx-ids ctx)
                           ,claimants
                           ,released)))))))))
      (vulpea-db-worker-handback
       (vulpea-db-worker--reply `(handback ,path ,(cadr err))))
      (error
       (vulpea-db-worker--reply
        `(error ,path ,(error-message-string err)))))))

(defun vulpea-db-worker--handle-parse (path)
  "Extract PATH and stream the results to stdout."
  (condition-case err
      (let ((ctx (vulpea-db-worker--parse-file path)))
        (vulpea-db-worker--reply `(begin ,path))
        (vulpea-db-worker--reply
         `(file-node ,(vulpea-parse-ctx-file-node ctx)))
        (dolist (node (vulpea-parse-ctx-heading-nodes ctx))
          (vulpea-db-worker--reply `(heading-node ,node)))
        (vulpea-db-worker--reply
         `(done ,path
                ,(vulpea-parse-ctx-hash ctx)
                ,(vulpea-parse-ctx-mtime ctx)
                ,(vulpea-parse-ctx-size ctx))))
    (vulpea-db-worker-handback
     (vulpea-db-worker--reply `(handback ,path ,(cadr err))))
    (error
     (vulpea-db-worker--reply
      `(error ,path ,(error-message-string err))))))

(defun vulpea-db-worker-batch-main ()
  "Protocol loop for the extraction worker.

Runs in `emacs --batch': reads one request per line from stdin,
writes protocol lines to stdout.  Exits when stdin closes."
  (require 'org-attach)
  (advice-add 'org-link-expand-abbrev :before
              #'vulpea-db-worker--note-abbrev-expansion)
  (while t
    (let* ((line (condition-case nil
                     (read-from-minibuffer "")
                   (error (kill-emacs 0))))
           (msg (condition-case nil
                    (car (read-from-string line))
                  (error nil))))
      (pcase msg
        (`(settings ,vars ,link-types ,extractors ,db-constants)
         (vulpea-db-worker--apply-settings vars link-types extractors
                                           db-constants))
        ;; A file linking through a session-only abbreviation goes
        ;; back to the main process, which indexes it synchronously
        ((and `(,(or 'parse 'parse-and-write) ,path . ,_)
              (guard (ignore-errors
                       (vulpea-db-worker--session-abbrev-used-p path))))
         (vulpea-db-worker--reply
          `(handback ,path
                  ,(format "it links through %s, which expands with a function from your session"
                           (string-join
                            (mapcar (lambda (tag) (format "[[%s:...]]" tag))
                                    vulpea-db-worker--session-abbrev-tags)
                            ", ")))))
        (`(parse ,path)
         (vulpea-db-worker--handle-parse path))
        (`(parse-and-write ,path ,db ,force)
         (vulpea-db-worker--handle-parse-and-write path db force))
        (_ nil)))))

;;; Session vs worker comparison

(defun vulpea-db-worker--plist-diff (a b)
  "Return the keys whose values differ between plists A and B."
  (let (keys)
    (dolist (plist (list a b))
      (cl-loop for key in plist by #'cddr
               do (unless (or (memq key keys)
                              (equal (plist-get a key) (plist-get b key)))
                    (push key keys))))
    (nreverse keys)))

(defun vulpea-db-worker--nodes-diff (ours theirs)
  "Return the fields that differ between two extraction results.
OURS and THEIRS are (FILE-NODE . HEADING-NODES).  Headings are
compared in order; a different number of them adds `:headings'."
  (let ((fields (vulpea-db-worker--plist-diff (car ours) (car theirs))))
    (unless (= (length (cdr ours)) (length (cdr theirs)))
      (push :headings fields))
    (cl-mapc (lambda (a b)
               (dolist (key (vulpea-db-worker--plist-diff a b))
                 (unless (memq key fields)
                   (setq fields (append fields (list key))))))
             (cdr ours) (cdr theirs))
    fields))

(defun vulpea-db-worker--parse-in-fresh-worker (paths)
  "Parse PATHS in a new, short-lived worker and collect the results.

The worker gets the same settings message as the live one, runs
synchronously, and exits when its input ends; the live worker and
the database are not touched.  Returns a hash table mapping each
path to (FILE-NODE . HEADING-NODES), to an error message, or to
`:handback' for a file the worker leaves to the session.
Signals an error, with the tail of the worker's stderr, when the
worker exits abnormally or answers nothing: a broken worker is not
a difference in the files."
  (let ((command (vulpea-db-worker--command))
        (input (make-temp-file "vulpea-compare-" nil ".eld"))
        (stderr (make-temp-file "vulpea-compare-" nil ".err"))
        (results (make-hash-table :test #'equal))
        status)
    (unwind-protect
        (progn
          (with-temp-file input
            (insert (vulpea-db-worker--print (vulpea-db-worker--settings-form))
                    "\n")
            (dolist (path paths)
              (insert (vulpea-db-worker--print `(parse ,path)) "\n")))
          (with-temp-buffer
            (setq status (apply #'call-process (car command) input
                                (list t stderr) nil (cdr command)))
            (goto-char (point-min))
            (let (file-node headings)
              (while (not (eobp))
                (pcase (ignore-errors
                         (car (read-from-string
                               (buffer-substring (line-beginning-position)
                                                 (line-end-position)))))
                  (`(begin ,_) (setq file-node nil headings nil))
                  (`(file-node ,node) (setq file-node node))
                  (`(heading-node ,node) (push node headings))
                  (`(done ,path . ,_)
                   (puthash path (cons file-node (reverse headings)) results))
                  (`(error ,path ,message) (puthash path message results))
                  (`(handback ,path ,_) (puthash path :handback results)))
                (forward-line 1))))
          (unless (and (eql status 0)
                       (or (null paths) (> (hash-table-count results) 0)))
            (let ((last-line
                   ;; Batch Emacs prints the error last, after any
                   ;; backtrace; one line keeps the report readable
                   (with-temp-buffer
                     (insert-file-contents stderr)
                     (when-let* ((line (car (last (split-string
                                                   (buffer-string)
                                                   "\n" t "[ \t]+")))))
                       (truncate-string-to-width
                        (replace-regexp-in-string "[ \t]+" " " line)
                        200 nil nil "...")))))
              (if (and (eql status 0) (null last-line))
                  (error "The worker exited without answering")
                (error "The worker exited with %s%s"
                       status
                       (if last-line (concat ": " last-line) ""))))))
      (delete-file input)
      (delete-file stderr))
    results))

(defvar vulpea-db-worker--compare-session-indexed 0
  "How many files the last comparison left to the session.
See `vulpea-db-worker-compare-files'.")

(defun vulpea-db-worker-compare-files (paths)
  "Parse PATHS in this session and in a fresh worker; return differences.

Detects files the worker indexes differently from the session - a
mode hook it does not run, a setting it does not mirror, a feature
it does not load - whatever the cause.  The session side parses
through `vulpea-db--parse-file', as synchronous indexing does.
Nothing is written to the database.

Returns a list of (PATH . FIELDS) for the files that differ, where
FIELDS lists the extracted fields that do (`:headings' when the
number of heading notes differs), or (PATH . MESSAGE) when the
session could not parse PATH.  Returns nil when every file matches.

Files the worker hands back or fails on are indexed in the session
on the live path, so they match by definition; their number is left
in `vulpea-db-worker--compare-session-indexed'."
  (let ((worker (vulpea-db-worker--parse-in-fresh-worker paths))
        result)
    (setq vulpea-db-worker--compare-session-indexed 0)
    (dolist (path paths)
      (let ((theirs (gethash path worker 'missing)))
        (cond
         ((eq theirs 'missing)
          (push (cons path "no result from the worker") result))
         ;; Handed back: the session indexes it
         ((eq theirs :handback)
          (setq vulpea-db-worker--compare-session-indexed
                (1+ vulpea-db-worker--compare-session-indexed)))
         ;; Failed in the worker: the synchronous fallback indexes it,
         ;; as long as the session can
         ((stringp theirs)
          (let ((ours (condition-case err
                          (progn (vulpea-db--parse-file path) nil)
                        (error (error-message-string err)))))
            (if ours
                (push (cons path ours) result)
              (setq vulpea-db-worker--compare-session-indexed
                    (1+ vulpea-db-worker--compare-session-indexed)))))
         (t
          (let ((ours (condition-case err
                          (let ((ctx (vulpea-db--parse-file path)))
                            (cons (vulpea-parse-ctx-file-node ctx)
                                  (vulpea-parse-ctx-heading-nodes ctx)))
                        (error (error-message-string err)))))
            (if (stringp ours)
                (push (cons path ours) result)
              (when-let* ((fields (vulpea-db-worker--nodes-diff ours theirs)))
                (push (cons path fields) result))))))))
    (nreverse result)))

;;; Diagnostics

;;;###autoload
(defun vulpea-db-worker-diagnose ()
  "Run an end-to-end health check of async extraction and report.

Spawns a fresh worker, round-trips a small file through the current
`vulpea-db-async-extraction' mode against the real database location,
and reports every stage - spawn time, journal mode, mode degradations
and why, round-trip time, and the worker's stderr if anything went
wrong - in a dedicated buffer.  Refuses to run while background
extraction is in flight (it restarts the worker, which would discard
that work); the check file is temporary and removed from the
database afterwards."
  (interactive)
  (when (vulpea-db-worker-busy-p)
    (user-error
     "Vulpea: %d file%s still extracting in background; run the diagnosis once the worker is idle"
     vulpea-db-worker--in-flight-count
     (if (= vulpea-db-worker--in-flight-count 1) "" "s")))
  (let ((report (get-buffer-create "*vulpea-worker-diagnose*"))
        (vulpea-db-worker-debug t))
    (with-current-buffer report
      (erase-buffer)
      (insert (format "vulpea async extraction diagnosis (%s)\n\n"
                      (format-time-string "%F %T")))
      (insert (format "emacs          : %s\n" emacs-version))
      (insert (format "mode           : %S\n" vulpea-db-async-extraction))
      (insert (format "threshold      : %S\n"
                      vulpea-db-async-extraction-threshold))
      (insert (format "db location    : %s\n" vulpea-db-location))
      (insert (format "extractors     : %S\n" vulpea-db--extractors))
      (insert (format "index filters  : %S\n"
                      vulpea-db-note-index-filter-functions))
      (insert (format "filters inert  : %S\n"
                      (vulpea-db-worker--filters-inert-p)))
      (insert (format "worker broken  : %S\n" vulpea-db-worker--broken))
      (let ((reasons (vulpea-db-worker-rejection-reasons "probe.org")))
        (insert (format "can handle .org: %s\n"
                        (if reasons
                            (format "NO - %S - production files will use the SYNCHRONOUS path!"
                                    reasons)
                          "yes")))))
    (vulpea-db-worker-stop)
    (setq vulpea-db-worker--broken nil
          vulpea-db-worker--crash-times nil
          vulpea-db-worker--wal-failed nil)
    ;; Journal mode of the real database
    (let ((mode (caar (sqlite-select (oref (vulpea-db) handle)
                                     "PRAGMA journal_mode"))))
      (with-current-buffer report
        (insert (format "journal mode   : %s\n" mode))))
    ;; Round trip
    (let* ((path (make-temp-file "vulpea-diagnose-" nil ".org"
                                 ":PROPERTIES:\n:ID: vulpea-diagnose-id\n:END:\n#+TITLE: Diagnose\n"))
           (t0 (current-time))
           (status nil)
           (vulpea-db-worker-done-functions
            (list (lambda (_path s _count) (setq status s)))))
      (unwind-protect
          (progn
            (condition-case err
                (progn
                  (vulpea-db-worker-request path)
                  (with-current-buffer report
                    (insert (format "spawn + request: ok (%.0fms)\n"
                                    (* 1000 (float-time
                                             (time-subtract (current-time) t0))))
                            (format "full-write     : %S\n"
                                    (vulpea-db-worker--full-write-p))
                            (format "wal failed     : %S\n"
                                    vulpea-db-worker--wal-failed)))
                  (let ((deadline (+ (float-time) 30)))
                    (while (and (not status) (< (float-time) deadline))
                      (accept-process-output vulpea-db-worker--process 0.1)))
                  (with-current-buffer report
                    (insert (format "round trip     : %s in %.0fms\n"
                                    (or status "TIMEOUT after 30s")
                                    (* 1000 (float-time
                                             (time-subtract (current-time) t0)))))))
              (error
               (with-current-buffer report
                 (insert (format "FAILED         : %s\n"
                                 (error-message-string err))))))
            (with-current-buffer report
              (insert (format "\nworker process : %S\n"
                              vulpea-db-worker--process))
              (let ((stderr (vulpea-db-worker--stderr-tail)))
                (unless (string-empty-p stderr)
                  (insert "\nworker stderr tail:\n" stderr "\n")))
              (when-let* ((log (get-buffer vulpea-db-worker-log-buffer)))
                (insert "\nprotocol log:\n"
                        (with-current-buffer log (buffer-string))))))
        ;; Cleanup: temp note out of the database, worker down
        (ignore-errors (vulpea-db--forget-file path))
        (delete-file path)
        (vulpea-db-worker-stop)
        ;; The worker was stopped for the check, not for good
        (when (bound-and-true-p vulpea-db-autosync-mode)
          (vulpea-db-worker-schedule-prestart))))
    (pop-to-buffer report)))

(provide 'vulpea-db-worker)
;;; vulpea-db-worker.el ends here
