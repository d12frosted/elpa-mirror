;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250527.1926"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "7de8d1f2bf9c88638d06e84c2ed6fb41b05c02ac"
  :revdesc "7de8d1f2bf9c"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
