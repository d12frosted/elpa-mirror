(define-package "tempel-collection" "20230430.1842" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "ba2ae39e66804337f604de69df6ae9b34b821e85" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
