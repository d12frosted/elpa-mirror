(define-package "essgd" "20240412.633" "Show R plots from ESS within a buffer"
  '((websocket "1.15")
    (ess "24.1.1")
    (emacs "29.1"))
  :commit "5eb3f9ba31f080e2564f4de33b1acfd1cdd04774" :authors
  '(("Stephen Eglen" . "sje30@cam.ac.uk"))
  :maintainers
  '(("Stephen Eglen" . "sje30@cam.ac.uk"))
  :maintainer
  '("Stephen Eglen" . "sje30@cam.ac.uk")
  :url "https://github.com/sje30/essgd")
;; Local Variables:
;; no-byte-compile: t
;; End:
