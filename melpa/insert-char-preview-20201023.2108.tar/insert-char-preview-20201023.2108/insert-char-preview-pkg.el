;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-char-preview" "20201023.2108"
  "Insert Unicode char."
  '((emacs "24.1"))
  :url "https://gitlab.com/matsievskiysv/insert-char-preview"
  :commit "8f13262ebcb3f271f1d188584d04ca6d87214111"
  :revdesc "8f13262ebcb3"
  :keywords '("convenience"))
