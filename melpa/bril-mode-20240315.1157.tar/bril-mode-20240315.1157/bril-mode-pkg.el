;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bril-mode" "20240315.1157"
  "Major mode for Bril text format."
  '((emacs "27.1"))
  :url "https://github.com/nverno/bril-mode"
  :commit "da61316385e31973c462a1e8a3213327b34df3ff"
  :revdesc "da61316385e3"
  :keywords '("languages" "bril")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
