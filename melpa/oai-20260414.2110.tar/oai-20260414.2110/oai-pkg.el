;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260414.2110"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "bb746532034c55e5ad07185020fe57c159342c7f"
  :revdesc "bb746532034c"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
