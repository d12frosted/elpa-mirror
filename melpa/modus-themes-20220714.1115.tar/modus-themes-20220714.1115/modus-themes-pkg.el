(define-package "modus-themes" "20220714.1115" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "abe2047067fe4be527a1dc0ddca27035e19980ca" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
