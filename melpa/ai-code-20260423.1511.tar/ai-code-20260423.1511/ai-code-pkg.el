;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260423.1511"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "bb725e376479d0c6ac50f47fd89b7f8972db2465"
  :revdesc "bb725e376479"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
