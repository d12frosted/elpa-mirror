;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-py-mode" "20260126.417"
  "Live Coding in Python."
  '((emacs "24.3"))
  :url "http://donkirkby.github.io/live-py-plugin/"
  :commit "8ab0cd071eb768b334bd587eb98b01cfc1153623"
  :revdesc "8ab0cd071eb7"
  :keywords '("live" "coding"))
