;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-backup" "20191209.2144"
  "Backup each file change using git."
  '((emacs "24.3")
    (s     "1.8.0"))
  :url "https://github.com/antham/git-backup"
  :commit "e28d7af2d1c58fa5b8068223eb83a73f044e6a6c"
  :revdesc "e28d7af2d1c5"
  :keywords '("backup" "files" "tools" "git")
  :authors '(("Anthony HAMON" . "hamon.anth@gmail.com"))
  :maintainers '(("Anthony HAMON" . "hamon.anth@gmail.com")))
