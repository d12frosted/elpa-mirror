(define-package "wildcharm-light-theme" "20230824.324" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "1e541be813a67d85f6bd8267f9bf7c164e17000e" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
