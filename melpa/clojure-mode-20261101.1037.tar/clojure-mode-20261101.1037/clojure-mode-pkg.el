;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20261101.1037"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "8060fc85ae60c1742dd5599d530cb06401e08023"
  :revdesc "8060fc85ae60"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :authors '(("Jeffrey Chu" . "jochu0@gmail.com")
             ("Lennart Staflin" . "lenst@lysator.liu.se")
             ("Phil Hagelberg" . "technomancy@gmail.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev")
             ("Artur Malabarba" . "bruce.connor.am@gmail.com")
             ("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
