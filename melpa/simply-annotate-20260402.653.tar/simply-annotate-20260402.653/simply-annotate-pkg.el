;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260402.653"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "0785881bb243a5edad305517e618dfd3cfe9652c"
  :revdesc "0785881bb243"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
