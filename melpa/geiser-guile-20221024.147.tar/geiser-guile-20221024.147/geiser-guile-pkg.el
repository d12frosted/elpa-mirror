(define-package "geiser-guile" "20221024.147" "Guile and Geiser talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (geiser "0.26.1"))
  :commit "8e4ee5ccb6dc970f75c385cff2603fa3862b9611" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
