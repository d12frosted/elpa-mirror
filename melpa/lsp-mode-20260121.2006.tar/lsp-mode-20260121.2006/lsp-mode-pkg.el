;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260121.2006"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "d480d5ff87057484b816c2e7a3055244b17d0e01"
  :revdesc "d480d5ff8705"
  :keywords '("languages"))
