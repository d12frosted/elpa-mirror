;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250709.1128"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.17.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "5247c1ffaf9d374421dba22bfcd66acb4d304406"
  :revdesc "5247c1ffaf9d"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
