;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "20261116.1821"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.64.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "bc0346ec249b61d0ff27905caf4400c399325c93"
  :revdesc "bc0346ec249b"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
