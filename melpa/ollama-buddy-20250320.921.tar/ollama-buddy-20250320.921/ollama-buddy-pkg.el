;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250320.921"
  "Ollama Buddy: Your Friendly AI Assistant."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "69cd516c2596138f3a4bb0d97e92c3b73e75d517"
  :revdesc "69cd516c2596"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
