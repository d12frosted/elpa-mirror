(define-package "tok-theme" "20220130.1658" "My theme"
  '((emacs "24.3"))
  :commit "bf5c5381bb1c10af816bb362067648c10d176399" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
