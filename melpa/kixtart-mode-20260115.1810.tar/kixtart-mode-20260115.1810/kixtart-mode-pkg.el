;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "20260115.1810"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "a09f91c6dda7a5eda5f5f0cd382bdcef1519720f"
  :revdesc "a09f91c6dda7"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
