(define-package "sniem" "20220122.1543" "Hands-eased united editing method"
  '((emacs "27.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "9edf24d0c23bac0321e08711546401c6d7eee081" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
