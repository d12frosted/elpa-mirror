(define-package "orderless" "20220111.1736" "Completion style for matching regexps in any order"
  '((emacs "26.1"))
  :commit "3678f8460662f5f042e67f642b5dd4bd3bb85ed4" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("extensions")
  :url "https://github.com/oantolin/orderless")
;; Local Variables:
;; no-byte-compile: t
;; End:
