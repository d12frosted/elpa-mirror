(define-package "brutalist-theme" "20230914.2107" "Brutalist theme" 'nil :commit "8961bea9902ff8548bd771ed3492731630420bdd" :authors
  '(("Gergely Nagy"))
  :maintainers
  '(("Gergely Nagy"))
  :maintainer
  '("Gergely Nagy")
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
