(define-package "eldev" "20211213.1900" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "182170f076ccd90f601df8af5e8dcf75c5703743" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
