;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "myrddin-mode" "20191225.2120"
  "Major mode for editing Myrddin source files."
  '((emacs "24.3"))
  :url "https://git.sr.ht/~jakob/myrddin-mode"
  :commit "51c0a2cb9dfc9526cd47e71313f5a745c99cadcc"
  :revdesc "51c0a2cb9dfc"
  :keywords '("languages")
  :authors '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org"))
  :maintainers '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org")))
