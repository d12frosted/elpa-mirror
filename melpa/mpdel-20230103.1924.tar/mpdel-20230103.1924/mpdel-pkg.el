(define-package "mpdel" "20230103.1924" "Play and control your MPD music"
  '((emacs "25.1")
    (libmpdel "1.2.0")
    (navigel "0.7.0"))
  :commit "365b2661e56165c53eadd28d3e0a5f9d594412c7" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("multimedia")
  :url "https://github.com/mpdel/mpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
