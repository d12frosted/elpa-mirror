(define-package "kaolin-themes" "20210301.1533" "A set of eye pleasing themes"
  '((emacs "25.1")
    (autothemer "0.2.2")
    (cl-lib "0.6"))
  :commit "1f8204a40ab24cb54f22bc89345d7f603084688a" :authors
  '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainer
  '("Ogden Webb" . "ogdenwebb@gmail.com")
  :keywords
  '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
