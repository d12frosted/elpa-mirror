(define-package "osm" "20220325.2356" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "881b1c969fcf3dae5c020ce520e5a16f8f2b6f18" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
