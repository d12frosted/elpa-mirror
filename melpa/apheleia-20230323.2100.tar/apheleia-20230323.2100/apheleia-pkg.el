(define-package "apheleia" "20230323.2100" "Reformat buffer stably"
  '((emacs "26"))
  :commit "43ffed789064db2c59fe3fe8e1c1c2e142b3e483" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/raxod502/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
