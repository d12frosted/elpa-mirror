;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260422.1527"
  "Enhanced annotation system with threading."
  '((emacs     "27.2")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "fe7ed2ebcda0d1899f97f06191adbf260cc5b1eb"
  :revdesc "fe7ed2ebcda0"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
