(define-package "gruvbox-theme" "20220822.459" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "06674899435910231b1a7e3ffad2a058c21a33f2" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
