;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "20260424.1403"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "2161e9ae06d2944b5ad313c642948d752f69add0"
  :revdesc "2161e9ae06d2"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
