(define-package "treebundel" "20230906.142" "Bundle related git-worktrees together"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "bfce013b6a5564e5ab21304e08f63152e0de5d8b" :authors
  '(("Ben Whitley"))
  :maintainers
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/treebundel.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
