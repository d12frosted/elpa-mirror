;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250712.437"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "d01073d53e2efc22750e60a353c7e3e1aa23df29"
  :revdesc "d01073d53e2e"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
