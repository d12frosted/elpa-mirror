;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20260105.1209"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "795409e9e18327c18afa6738bbb7a3d721345090"
  :revdesc "795409e9e183"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
