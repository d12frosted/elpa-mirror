(define-package "raku-mode" "20210913.1000" "Major mode for editing Raku code"
  '((emacs "24.4"))
  :commit "eaac071f1779b6545d6593f6a05f09b4e58c98db" :authors
  '(("Hinrik Örn Sigurðsson" . "hinrik.sig@gmail.com"))
  :maintainer
  '("Hinrik Örn Sigurðsson" . "hinrik.sig@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/hinrik/perl6-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
