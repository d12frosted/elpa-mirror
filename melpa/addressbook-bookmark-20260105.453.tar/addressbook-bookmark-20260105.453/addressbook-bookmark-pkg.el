;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "addressbook-bookmark" "20260105.453"
  "An address book based on Standard Emacs bookmarks."
  '((emacs "24"))
  :url "https://github.com/thierryvolpiatto/addressbook-bookmark"
  :commit "469faa4206e6503d9c045fecb2ec0af8e1dcf504"
  :revdesc "469faa4206e6"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
