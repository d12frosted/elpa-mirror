(define-package "python-cell" "20230426.1602" "Support for MATLAB-like cells in python mode"
  '((emacs "25.1"))
  :commit "0428186af2fac1252ec62e9be4f7bf3664682e83" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainers
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions" "python" "matlab" "cell")
  :url "https://github.com/thisch/python-cell.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
