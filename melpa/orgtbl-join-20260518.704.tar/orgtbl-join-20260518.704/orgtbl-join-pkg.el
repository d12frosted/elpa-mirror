;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260518.704"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "8d341a0ec288ac20b45433dfa106cb474554526e"
  :revdesc "8d341a0ec288"
  :keywords '("data" "extensions"))
