(define-package "consult" "20220217.1627" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "44580944f95d52bcd5a3ed79adef57e51aca7e31" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
