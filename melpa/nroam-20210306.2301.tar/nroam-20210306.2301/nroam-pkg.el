(define-package "nroam" "20210306.2301" "Org-roam backlinks within org-mode buffers"
  '((emacs "26.1")
    (org-roam "1.2.3"))
  :commit "c150603a25445d65b7b08d658793a6019fd763ea" :authors
  '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainer
  '("Nicolas Petton" . "nicolas@petton.fr")
  :keywords
  '("outlines" "convenience")
  :url "https://github.com/NicolasPetton/nroam")
;; Local Variables:
;; no-byte-compile: t
;; End:
