(define-package "embark" "20220527.2228" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "7eab6ea6182581f508c20e9a60c40c106a3539bd" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
