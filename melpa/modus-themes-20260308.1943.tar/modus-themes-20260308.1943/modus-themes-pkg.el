;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260308.1943"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "ed36e34132bacaf8e87c7310837f57757a43b0c9"
  :revdesc "ed36e34132ba"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
