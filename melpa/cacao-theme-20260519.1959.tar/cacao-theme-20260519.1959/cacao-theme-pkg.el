;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cacao-theme" "20260519.1959"
  "Based on a image reversal."
  '((emacs "24.1"))
  :url "https://github.com/Michael-Garibaldi/cacao-theme"
  :commit "73d8f81b7c9d2957cf7201d89a7a81bb673af03f"
  :revdesc "73d8f81b7c9d")
