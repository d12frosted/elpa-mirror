(define-package "burly" "20210709.415" "Save and restore frame/window configurations with buffers"
  '((emacs "26.3")
    (map "2.1"))
  :commit "a67a026db0937b26c0b7a2fcf81bf44498ad2dd1" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
