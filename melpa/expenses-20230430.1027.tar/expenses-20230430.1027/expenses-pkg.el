(define-package "expenses" "20230430.1027" "Record and view expenses"
  '((emacs "26.1")
    (dash "2.19.1")
    (ht "2.3"))
  :commit "9bf8f690880b64c1f9a29543156446b9b800cc72" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("expense tracking" "convenience")
  :url "https://github.com/md-arif-shaikh/expenses")
;; Local Variables:
;; no-byte-compile: t
;; End:
