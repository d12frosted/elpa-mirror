;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literate-elisp" "20260621.1253"
  "Load Emacs Lisp code blocks from Org files."
  '((emacs "30.1"))
  :url "https://github.com/jingtaozf/literate-elisp"
  :commit "6cbe22aab87886cf61c4866653e24ebdb88b1523"
  :revdesc "6cbe22aab878"
  :keywords '("lisp" "docs" "extensions" "tools")
  :authors '(("Jingtao Xu" . "jingtaozf@gmail.com"))
  :maintainers '(("Jingtao Xu" . "jingtaozf@gmail.com")))
