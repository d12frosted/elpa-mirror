;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250413.1408"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "ab73713a04cbb47cfee9808550a44528041e2096"
  :revdesc "ab73713a04cb"
  :keywords '("agent" "ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
