;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-typescript-preset" "20260403.1656"
  "Eglot preset for TypeScript."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-typescript-preset"
  :commit "97c673f6408fa35fe859330f6014c35f9dce15a8"
  :revdesc "97c673f6408f"
  :keywords '("typescript" "javascript" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
