;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proxy-mode" "20230303.706"
  "A minor mode to toggle proxy."
  '((emacs "25"))
  :url "https://repo.or.cz/proxy-mode.git"
  :commit "eca6f0b8a17fcf9eb961ed0426f57a5b7ca4e1f6"
  :revdesc "eca6f0b8a17f"
  :keywords '("comm" "proxy")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
