[
  (integer)
  (float)
] @number.inner

