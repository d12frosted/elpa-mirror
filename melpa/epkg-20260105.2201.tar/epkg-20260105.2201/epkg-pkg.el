;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260105.2201"
  "Browse the Emacsmirror package database."
  '((emacs   "28.1")
    (compat  "30.1")
    (closql  "2.4")
    (emacsql "4.3")
    (llama   "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "522b00c64aaf230215c6dde8f992e79ed38b9e42"
  :revdesc "522b00c64aaf"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
