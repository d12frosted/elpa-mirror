(define-package "pocket-reader" "20220630.844" "Client for Pocket reading list"
  '((emacs "25.1")
    (dash "2.13.0")
    (kv "0.0.19")
    (pocket-lib "0.1")
    (s "1.10")
    (ov "1.0.6")
    (rainbow-identifiers "0.2.2")
    (org-web-tools "0.1")
    (ht "2.2"))
  :commit "88d1e6019a3408835745e117cb5b83a8e31f11fe" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("pocket")
  :url "https://github.com/alphapapa/pocket-reader.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
