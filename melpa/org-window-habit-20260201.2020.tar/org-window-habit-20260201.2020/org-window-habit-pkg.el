;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20260201.2020"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "6e83615bb5b3d523c33ac9161175b17d2ea6836d"
  :revdesc "6e83615bb5b3"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
