;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pygn-mode" "20260604.2252"
  "Major-mode for chess PGN files, powered by Python."
  '((emacs             "27.1")
    (tree-sitter       "0.18.0")
    (tree-sitter-langs "0.12.242")
    (uci-mode          "0.5.4")
    (nav-flash         "1.0.0")
    (ivy               "0.10.0"))
  :url "https://github.com/dwcoates/pygn-mode"
  :commit "76aba38fa82158d09548729b834a8766073720c8"
  :revdesc "76aba38fa821"
  :keywords '("data" "games" "chess"))
