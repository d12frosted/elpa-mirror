;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20261021.1258"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "bec18cea48962277e1c14275d183159911b132ed"
  :revdesc "bec18cea4896"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
