;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260607.2330"
  "Unified interface for AI coding backends."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "16779f2dc61c68346c93ee7101637cbd18e26dc0"
  :revdesc "16779f2dc61c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
