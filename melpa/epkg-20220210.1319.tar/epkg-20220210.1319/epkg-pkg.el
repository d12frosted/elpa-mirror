(define-package "epkg" "20220210.1319" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "478bf213cfac110a601494caf532cb3271c314ab" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
