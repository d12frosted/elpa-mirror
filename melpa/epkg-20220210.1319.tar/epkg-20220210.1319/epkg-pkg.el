(define-package "epkg" "20220210.1319" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "beaf643468372cf24250b60449dfa788c8633cad" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
