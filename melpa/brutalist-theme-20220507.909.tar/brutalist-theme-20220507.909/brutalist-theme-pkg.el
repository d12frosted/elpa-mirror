(define-package "brutalist-theme" "20220507.909" "Brutalist theme" 'nil :commit "bee6cb25819007e20cde2782a6fcb577028dd038" :authors
  '(("Gergely Nagy"))
  :maintainers
  '(("Gergely Nagy"))
  :maintainer
  '("Gergely Nagy")
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
