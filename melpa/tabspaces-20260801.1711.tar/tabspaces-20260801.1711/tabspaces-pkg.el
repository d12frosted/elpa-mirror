;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260801.1711"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "f39e75148d978cefaabadc213f031bde34d34d9e"
  :revdesc "f39e75148d97"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
