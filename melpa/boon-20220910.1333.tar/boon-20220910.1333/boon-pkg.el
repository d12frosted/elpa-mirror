(define-package "boon" "20220910.1333" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "41ad3363c2810cdda5ed08b2d83381843780a15f")
;; Local Variables:
;; no-byte-compile: t
;; End:
