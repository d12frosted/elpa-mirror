(define-package "spdx" "20230826.56" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "b0f6e16790c723a0d19e2eb9e4772192c85b3609" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
