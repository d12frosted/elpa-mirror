(define-package "scopeline" "20230521.614" "Show scope info of blocks in buffer at end of scope"
  '((emacs "26.1"))
  :commit "6733f0f7ca33aa5c8ad83099dcb7b7ff8bc46a68" :keywords
  '("scope" "context" "tree-sitter" "convenience")
  :url "https://github.com/meain/scopeline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
