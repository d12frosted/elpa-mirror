;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ppd-sr-speedbar" "20151108.1224"
  "Sr Speedbar Adaptor for project-persist-drawer."
  ()
  :url "https://github.com/rdallasgrayppd-sr-speedbar"
  :commit "19d3e924407f40a6bb38c8fe427a159af755adce"
  :revdesc "19d3e924407f"
  :keywords '("projects" "drawer"))
