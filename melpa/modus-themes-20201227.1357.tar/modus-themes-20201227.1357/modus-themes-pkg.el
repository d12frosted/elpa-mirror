(define-package "modus-themes" "20201227.1357" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "3cf38a50f3b406518466b326c718085c5cdd38ae" :authors
  (("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  ("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  ("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
