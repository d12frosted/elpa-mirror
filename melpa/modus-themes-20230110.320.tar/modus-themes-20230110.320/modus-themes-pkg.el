(define-package "modus-themes" "20230110.320" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "4e9c88bdb527599eec3dd39639ca4be15dba81da" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
