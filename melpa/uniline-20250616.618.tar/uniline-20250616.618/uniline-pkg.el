;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250616.618"
  "Add ╭─╴UNICODE╶─╮ based ╭─╴diagrams╶─╮ to ╭▶╴text files╶●╮."
  '((emacs "29.1"))
  :url "https://github.com/tbanel/uniline"
  :commit "175fe8eaa1b4cedfb19e0cd95daa1a7a81752f56"
  :revdesc "175fe8eaa1b4"
  :keywords '("convenience" "text"))
