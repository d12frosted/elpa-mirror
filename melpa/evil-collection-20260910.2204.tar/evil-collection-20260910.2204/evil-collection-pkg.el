;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260910.2204"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "1513aae3652101caf3227bcf7349e2e6fded3210"
  :revdesc "1513aae36521"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
