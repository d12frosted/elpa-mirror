(define-package "dall-e-shell" "20231209.1215" "Interaction mode for DALL-E"
  '((emacs "27.1")
    (shell-maker "0.44.1"))
  :commit "354ad6bae13a1a7323d5450aae94bef576e9998c" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
