(define-package "magit-section" "20211012.1845" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "ceab3124fb6b590d3cecefe381b6e2d29dcc2bf8" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
