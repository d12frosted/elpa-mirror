(define-package "meow" "20220108.12" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "0d63977e7251f82960d12f07edd32e16d7e2ae9f" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
