;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flutter" "20261010.2349"
  "Tools for working with Flutter SDK."
  '((emacs "28.1"))
  :url "https://github.com/amake/flutter.el"
  :commit "b7ca9515ce04c68d5fa580c0b1a1cec5aed7c5a6"
  :revdesc "b7ca9515ce04"
  :keywords '("languages"))
