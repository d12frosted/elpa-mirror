(define-package "autocrypt" "20210412.1127" "Autocrypt implementation"
  '((emacs "25.1")
    (cl-generic "0.3"))
  :commit "1dc4e5983382093fc74c81d84a45cd2b53adfd90" :authors
  '(("Philip K." . "philip@warpmail.net"))
  :maintainer
  '("Philip K." . "philip@warpmail.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~zge/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
