(define-package "modus-themes" "20210713.1540" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "cbde5425615db4c9e668a9270067b27915ffde99" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
