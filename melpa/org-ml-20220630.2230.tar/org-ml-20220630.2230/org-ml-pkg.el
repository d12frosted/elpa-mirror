(define-package "org-ml" "20220630.2230" "Functional Org Mode API"
  '((emacs "27.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "4fd3feb65b93819e2bddc506f3c425aa7972a9d6" :authors
  '(("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  '("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :keywords
  '("org-mode" "outlines")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
