(define-package "elisp-autofmt" "20230221.1124" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "153785d7e7d392ae07fe0f91a8ba3af6dd6d7df6" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
