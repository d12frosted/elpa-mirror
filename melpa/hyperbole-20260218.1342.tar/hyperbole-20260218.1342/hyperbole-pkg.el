;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260218.1342"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "645e8341ecfed3284eba05b713fc4f9039edb524"
  :revdesc "645e8341ecfe"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
