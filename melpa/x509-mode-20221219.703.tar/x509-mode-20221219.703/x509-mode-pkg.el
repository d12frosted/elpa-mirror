(define-package "x509-mode" "20221219.703" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "eebc0066e781a38cd43fc3e10d2061a3a55cf9d5" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
