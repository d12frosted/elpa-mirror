(define-package "racket-mode" "20221107.1846" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "74999273195dfeed98bfbe63114df1002e53eee6" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
