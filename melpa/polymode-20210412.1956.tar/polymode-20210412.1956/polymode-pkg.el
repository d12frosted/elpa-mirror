(define-package "polymode" "20210412.1956" "Extensible framework for multiple major modes"
  '((emacs "25"))
  :commit "9367c27e4eaa9e65cf02bb8c4f1e78620240e286" :authors
  '(("Vitalie Spinu"))
  :maintainer
  '("Vitalie Spinu")
  :keywords
  '("languages" "multi-modes" "processes")
  :url "https://github.com/polymode/polymode")
;; Local Variables:
;; no-byte-compile: t
;; End:
