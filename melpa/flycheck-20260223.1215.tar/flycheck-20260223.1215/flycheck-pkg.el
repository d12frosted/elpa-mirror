;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260223.1215"
  "On-the-fly syntax checking."
  '((emacs "27.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "d09fc46350aadd17c8ae0ceafbdf9a26e4d4810a"
  :revdesc "d09fc46350aa"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
