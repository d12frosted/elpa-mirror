(define-package "magik-mode" "20230807.912" "mode for editing Magik + some utils."
  '((emacs "24.4")
    (compat "28.1"))
  :commit "1f395999f2ad25f96f10b766f939d180d860ad89" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
