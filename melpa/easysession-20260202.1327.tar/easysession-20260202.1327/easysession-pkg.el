;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260202.1327"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "525ecd181521f93a7565b3a6f7f345105b6d3f4d"
  :revdesc "525ecd181521"
  :keywords '("convenience"))
