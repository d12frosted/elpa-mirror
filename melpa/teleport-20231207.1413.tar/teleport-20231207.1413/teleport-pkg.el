(define-package "teleport" "20231207.1413" "Integration for tsh (goteleport.com)"
  '((emacs "27.1")
    (dash "2.18.0"))
  :commit "d9789159b621ed343d34f2465a2474614160039b" :authors
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainers
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainer
  '("Caramel Hooves" . "caramel.hooves@protonmail.com")
  :keywords
  '("tools")
  :url "https://github.com/caramelhooves/teleport.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
