;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snippy" "20260727.1742"
  "Vscode snippet support with Yasnippet."
  '((emacs     "30.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/MiniApollo/snippy"
  :commit "62ae0641a2a7872b891122d7fbe1451df89cb907"
  :revdesc "62ae0641a2a7"
  :keywords '("convenience" "emulations")
  :authors '(("Mark Surmann" . "surmannmark@gmail.com"))
  :maintainers '(("Mark Surmann" . "surmannmark@gmail.com")))
