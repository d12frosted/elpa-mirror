;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260114.1604"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "9f5b72d22be8cccc1873f7b65ca9e0acad0b1e10"
  :revdesc "9f5b72d22be8"
  :keywords '("outlines"))
