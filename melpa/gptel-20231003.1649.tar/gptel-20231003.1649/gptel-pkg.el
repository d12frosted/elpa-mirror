(define-package "gptel" "20231003.1649" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "24add6445548f8f3083d5aa855bffbf51ae0847e" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
