;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251126.227"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "028402df7bb32b7ef471e6bfb32725ae27c318a1"
  :revdesc "028402df7bb3"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
