;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettify-greek" "20160603.908"
  "Greek letters for prettify-symbols."
  ()
  :url "https://gitlab.com/fommil/emacs-prettify-greek"
  :commit "698d07a6ffe85f6fb53f3bfec4f49380c25cfd90"
  :revdesc "698d07a6ffe8"
  :keywords '("faces"))
