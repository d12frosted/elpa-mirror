(define-package "ert-runner" "20220513.1142" "Opinionated Ert testing workflow"
  '((s "1.6.1")
    (dash "1.8.0")
    (f "0.10.0")
    (commander "0.2.0")
    (ansi "0.1.0")
    (shut-up "0.1.0"))
  :commit "69d66b934223d5f1801ba3a4c8dbfb3453f2a041" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("test")
  :url "http://github.com/rejeep/ert-runner.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
