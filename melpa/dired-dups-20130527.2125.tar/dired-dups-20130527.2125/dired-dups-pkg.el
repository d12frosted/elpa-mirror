;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-dups" "20130527.2125"
  "Find duplicate files and display them in a dired buffer."
  ()
  :url "https://github.com/vapniks/dired-dups"
  :commit "694ad128c822c59348ced16c4a0c1356d43da47a"
  :revdesc "694ad128c822"
  :keywords '("unix")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
