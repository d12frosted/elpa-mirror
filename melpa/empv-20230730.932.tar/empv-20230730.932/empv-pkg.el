(define-package "empv" "20230730.932" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0"))
  :commit "7a57fa24e618b05dbc73f96d3a4679d3211a9f09" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
