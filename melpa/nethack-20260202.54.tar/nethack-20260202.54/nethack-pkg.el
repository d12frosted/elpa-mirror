;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20260202.54"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "c17e18049da8ddff3c5772cae3aac813e70dd2d3"
  :revdesc "c17e18049da8"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
