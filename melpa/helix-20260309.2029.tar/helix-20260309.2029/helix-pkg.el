;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "20260309.2029"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "75a3e9e8025e7c2421b079c37a8848b16a6aff95"
  :revdesc "75a3e9e8025e"
  :keywords '("convenience"))
