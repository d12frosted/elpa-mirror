;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pass-coffin" "20251231.1407"
  "Interface to \"pass coffin\"."
  '((emacs "28.1"))
  :url "https://codeberg.org/rch/emacs-pass-coffin"
  :commit "202c9e3b67c5e0fe8d3631436c8c95f61586f88f"
  :revdesc "202c9e3b67c5"
  :keywords '("tools")
  :authors '(("Robert Charusta" . "rch-public@posteo.net"))
  :maintainers '(("Robert Charusta" . "rch-public@posteo.net")))
