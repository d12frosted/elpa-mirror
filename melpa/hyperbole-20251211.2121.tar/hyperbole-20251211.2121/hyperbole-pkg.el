;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251211.2121"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "105f1836ec3de9ac841d8cf819eea4dbace8bcc1"
  :revdesc "105f1836ec3d"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
