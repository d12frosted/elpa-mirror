(define-package "gumshoe" "20210921.2005" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "23630fdf48efe94fe7fdcf589a310e0b65a97021" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
