;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frecency" "20240111.628"
  "Library for sorting items by frequency and recency of access."
  '((emacs "25.1")
    (a     "0.1")
    (dash  "2.13.0"))
  :url "https://github.com/alphapapa/frecency.el"
  :commit "4293bf4c8d571b0914e16a5aa05a6d657fdff551"
  :revdesc "4293bf4c8d57"
  :keywords '("extensions")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
