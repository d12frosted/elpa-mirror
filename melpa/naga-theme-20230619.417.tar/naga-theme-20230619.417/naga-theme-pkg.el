(define-package "naga-theme" "20230619.417" "Dark color theme with green foreground color"
  '((emacs "24.1"))
  :commit "ae4f53eac2c16024f845faace9f43d9a656489b5" :authors
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainers
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainer
  '("Johannes Maier" . "johannes.maier@mailbox.org")
  :keywords
  '("faces" "themes")
  :url "https://github.com/kenranunderscore/emacs-naga-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
