;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260128.152"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "7bed93e50f3e2e61f0bc0cae02970d3c5dff6909"
  :revdesc "7bed93e50f3e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
