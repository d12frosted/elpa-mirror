(define-package "llama-cpp" "20231128.755" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "764cc519cc3ea5d39ee8e9e22a48f4850653a1b0" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
