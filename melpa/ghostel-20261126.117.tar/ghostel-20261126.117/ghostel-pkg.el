;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261126.117"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "87c8b8c6c3791482471d17eedb4927900182994d"
  :revdesc "87c8b8c6c379"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
