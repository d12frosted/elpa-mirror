(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "099c3578e270c4d24db670c518fb8d63aa256ee3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
