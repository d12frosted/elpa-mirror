(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "6095f6fbf58ea44248703a612f0de9edff092150" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
