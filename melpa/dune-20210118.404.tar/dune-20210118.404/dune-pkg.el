(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "78c57fe05097d9e61370e104d79491c35080bc3a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
