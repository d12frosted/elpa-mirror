(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "4b4157aa2d23f2a8b123219f22a720103736b8e6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
