(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "a849f79b4866c5f14944e1b1f5076b5feb1856bf" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
