;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260515.2115"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "6d9078c7193d2592f88e22a1c980601ccdb8762c"
  :revdesc "6d9078c7193d"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
