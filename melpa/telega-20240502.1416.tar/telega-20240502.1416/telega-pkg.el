(define-package "telega" "20240502.1416" "Telegram client (unofficial)"
  '((emacs "27.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2")
    (transient "0.3.0"))
  :commit "30615199c76333af9f71992e0992ac691ca5e197" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
