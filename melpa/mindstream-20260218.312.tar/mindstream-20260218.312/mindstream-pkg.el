;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mindstream" "20260218.312"
  "Start writing, stay focused, don't worry."
  '((emacs "28.1"))
  :url "https://github.com/countvajhula/mindstream"
  :commit "6b51036a069379d18538a7cca5274c21666a5979"
  :revdesc "6b51036a0693"
  :keywords '("convenience" "files" "languages" "outlines" "tools" "vc" "wp")
  :authors '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Siddhartha Kasivajhula" . "sid@countvajhula.com")))
