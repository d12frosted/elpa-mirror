(define-package "consult" "20230126.2147" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "53673a2985e84cc35d0d4603caa53f4c4dc71a30" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
