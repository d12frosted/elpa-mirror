;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251021.525"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "a6db89ac1812dbaf955878944902be6f0dfe0bd8"
  :revdesc "a6db89ac1812"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
