(define-package "snakemake-mode" "20220223.218" "Major mode for editing Snakemake files"
  '((emacs "26.1")
    (transient "0.3.0"))
  :commit "849a74c24597c72818f194cf410087fc7c07f3d1" :authors
  '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainer
  '("Kyle Meyer" . "kyle@kyleam.com")
  :keywords
  '("tools")
  :url "https://git.kyleam.com/snakemake-mode/about")
;; Local Variables:
;; no-byte-compile: t
;; End:
