(define-package "easy-kill-extras" "20230829.526" "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :commit "677435739c698ed81c3732188c29aa98bd9ffb08" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/easy-kill-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
