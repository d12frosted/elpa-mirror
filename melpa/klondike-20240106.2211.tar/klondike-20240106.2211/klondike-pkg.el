(define-package "klondike" "20240106.2211" "Klondike"
  '((emacs "28.1"))
  :commit "fbf02e9eac4d6b608dd7db7c54234ef61c04859b" :authors
  '(("Wamm K. D." . "jaft.r@outlook.com"))
  :maintainers
  '(("Wamm K. D." . "jaft.r@outlook.com"))
  :maintainer
  '("Wamm K. D." . "jaft.r@outlook.com")
  :keywords
  '("games" "cards" "solitaire" "klondike")
  :url "https://codeberg.org/WammKD/Emacs-Klondike")
;; Local Variables:
;; no-byte-compile: t
;; End:
