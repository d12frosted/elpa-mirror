(define-package "racket-mode" "20231128.1829" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "fc3f83ca777e4ffa9939ddf244c9663c5cf4326d" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
