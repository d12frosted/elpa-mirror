;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260101.1344"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "9abc0d503799743de53c8fe9ab66f32e6f3892e7"
  :revdesc "9abc0d503799"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
