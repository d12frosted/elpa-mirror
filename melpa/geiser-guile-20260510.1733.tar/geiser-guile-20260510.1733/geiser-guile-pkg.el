;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-guile" "20260510.1733"
  "Guile and Geiser talk to each other."
  '((emacs     "26.1")
    (transient "0.3")
    (geiser    "0.28.1"))
  :url "https://gitlab.com/emacs-geiser/guile"
  :commit "31d2ab5fc4c4dc589e69dbfa7ad3a6f77410ead7"
  :revdesc "31d2ab5fc4c4"
  :keywords '("languages" "guile" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
