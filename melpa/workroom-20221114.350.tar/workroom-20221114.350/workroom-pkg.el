(define-package "workroom" "20221114.350" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0"))
  :commit "b81e76e0a39937b7544bf77cbff16cc8c239b58f" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
