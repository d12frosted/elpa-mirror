;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-indicator" "20200331.1142"
  "A fancy mode line indicator for `flycheck-mode'."
  '((flycheck "0.15"))
  :url "https://github.com/gexplorer/flycheck-indicator"
  :commit "e00d9a20cbc21d6814c27cc9206296da394478e8"
  :revdesc "e00d9a20cbc2"
  :keywords '("convenience" "language" "tools")
  :authors '(("Eder Elorriaga" . "gexplorer8@gmail.com"))
  :maintainers '(("Eder Elorriaga" . "gexplorer8@gmail.com")))
