(define-package "consult-tex" "20240808.1048" "Consult powered completion for tex"
  '((emacs "28.2")
    (consult "0.35"))
  :commit "e7e5db681fce79f20eb17c7609263ca8e64f5310" :maintainers
  '(("Titus Pinta" . "titus.pinta@gmail.com"))
  :maintainer
  '("Titus Pinta" . "titus.pinta@gmail.com")
  :keywords
  '("consult" "tex" "latex")
  :url "https://gitlab.com/titus.pinta/consult-TeX")
;; Local Variables:
;; no-byte-compile: t
;; End:
