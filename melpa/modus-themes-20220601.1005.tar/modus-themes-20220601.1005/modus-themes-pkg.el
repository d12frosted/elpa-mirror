(define-package "modus-themes" "20220601.1005" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "191f2a68569ba611898b630cdb94042033baa5a8" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
