(define-package "dired-gitignore" "20230425.1223" "A minor mode to hide gitignored files in a dired buffer"
  '((emacs "27.1"))
  :commit "9e7678533b132f73057f2cb3839a9f00aff97ac3" :authors
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainer
  '("Johannes Mueller" . "github@johannes-mueller.org")
  :keywords
  '("dired" "convenience" "git")
  :url "https://github.com/johannes-mueller/dired-gitignore.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
