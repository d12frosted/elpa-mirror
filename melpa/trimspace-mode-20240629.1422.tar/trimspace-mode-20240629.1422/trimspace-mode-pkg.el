(define-package "trimspace-mode" "20240629.1422" "A minor mode to trim trailing whitespace and newlines"
  '((emacs "24.3"))
  :commit "be02f324abcd0283d5f6dab00112cd60d285ebee" :authors
  '(("Björn Lindström" . "bkhl@elektrubadur.se"))
  :maintainers
  '(("Björn Lindström" . "bkhl@elektrubadur.se"))
  :maintainer
  '("Björn Lindström" . "bkhl@elektrubadur.se")
  :keywords
  '("files" "convenience")
  :url "https://git.sr.ht/~bkhl/trimspace-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
