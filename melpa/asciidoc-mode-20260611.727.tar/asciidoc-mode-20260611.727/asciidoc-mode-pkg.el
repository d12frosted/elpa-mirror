;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asciidoc-mode" "20260611.727"
  "Major mode for AsciiDoc markup."
  '((emacs "30.1"))
  :url "https://github.com/bbatsov/asciidoc-mode"
  :commit "397d69ef4b43411272365a0773453c4933794292"
  :revdesc "397d69ef4b43"
  :keywords '("text" "asciidoc" "languages" "tree-sitter")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
