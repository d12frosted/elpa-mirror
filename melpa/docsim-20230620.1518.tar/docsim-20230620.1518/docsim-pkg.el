(define-package "docsim" "20230620.1518" "Search and compare notes with a local search engine"
  '((emacs "24.4")
    (org "8.0"))
  :commit "fb9dd7f2d7aa3d09823701d923ed7bff12cabb5d" :authors
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainers
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainer
  '("Harry R. Schwartz" . "hello@harryrschwartz.com")
  :url "https://github.com/hrs/docsim.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
