(define-package "modus-themes" "20211007.1358" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "86ce981066010f4f17de567546ed7151ce5aa4cc" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
