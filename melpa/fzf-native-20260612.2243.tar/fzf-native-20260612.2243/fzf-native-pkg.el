;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260612.2243"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "c67035e8bf18402ceb8de3f1b1ad94f9ce24d947"
  :revdesc "c67035e8bf18"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
