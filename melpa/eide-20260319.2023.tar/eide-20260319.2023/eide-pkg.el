;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "20260319.2023"
  "IDE features made available out of the box."
  '((emacs "26.1"))
  :url "https://forge.tedomum.net/hjuvi/eide"
  :commit "2e7abd954ffa496b3ed0029e60bd0e2ff49125ec"
  :revdesc "2e7abd954ffa"
  :authors '(("Cédric Marie" . "hjuvi@tedomum.fr"))
  :maintainers '(("Cédric Marie" . "hjuvi@tedomum.fr")))
