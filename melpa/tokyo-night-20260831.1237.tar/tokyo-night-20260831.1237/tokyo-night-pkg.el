;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20260831.1237"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "da85075d0d3aa6dbcd247def72f5e232523c3245"
  :revdesc "da85075d0d3a"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
