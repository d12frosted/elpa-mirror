;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260603.721"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "da99827ff7d5ac93a89ed7b1e993349729c17131"
  :revdesc "da99827ff7d5"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
