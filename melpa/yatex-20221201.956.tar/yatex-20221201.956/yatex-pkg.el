(define-package "yatex" "20221201.956" "Yet Another tex-mode for emacs //野鳥//" 'nil :commit "9ec429ace1c5c28a533cdeb0f72efea396ab7890")
;; Local Variables:
;; no-byte-compile: t
;; End:
