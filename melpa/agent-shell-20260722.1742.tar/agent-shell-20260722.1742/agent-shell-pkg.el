;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260722.1742"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0a8678d83cb672cfc184b84fa306d5dbfa821afc"
  :revdesc "0a8678d83cb6")
