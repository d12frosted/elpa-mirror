(define-package "multi-run" "20190507.2349" "Efficiently manage multiple remote nodes"
  '((emacs "24")
    (window-layout "1.4"))
  :commit "c6256b0cc2876c29faf381d8324b31b911045a27" :authors
  '(("Sagar Jha"))
  :maintainer
  '("Sagar Jha")
  :keywords
  '("multiple shells" "multi-run" "remote nodes")
  :url "https://www.github.com/sagarjha/multi-run")
;; Local Variables:
;; no-byte-compile: t
;; End:
