;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh" "20250711.2032"
  "Consulting GitHub Client."
  '((emacs         "29.4")
    (consult       "2.0")
    (markdown-mode "2.6")
    (ox-gfm        "1.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "8d850877c0b6b9352f4a50b991942e6de8262fcd"
  :revdesc "8d850877c0b6"
  :keywords '("convenience" "matching" "tools" "vc"))
