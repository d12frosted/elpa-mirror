;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250616.435"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "6636c91b886841cd3401684db08b5c98e0c3eae1"
  :revdesc "6636c91b8868"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
