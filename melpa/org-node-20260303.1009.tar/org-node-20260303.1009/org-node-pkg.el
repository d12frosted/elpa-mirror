;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260303.1009"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.32.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "6709007b4ae29600dfe97978c31a67c54dcf4b26"
  :revdesc "6709007b4ae2"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
