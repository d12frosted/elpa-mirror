;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260308.844"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "57fba7990f79b725aa39b954449114913d71340c"
  :revdesc "57fba7990f79"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
