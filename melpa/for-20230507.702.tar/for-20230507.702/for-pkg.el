(define-package "for" "20230507.702" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "81f97e3f10c3ea9eb29759c2442dcf919d95d842" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainers
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
