;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20250929.126"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "1cd0a53011d162684f7172559540f5d97c11c392"
  :revdesc "1cd0a53011d1"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
