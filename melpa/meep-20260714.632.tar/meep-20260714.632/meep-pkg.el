;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260714.632"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "7b458143706f05b97451fa5e9cd19727d9d58384"
  :revdesc "7b458143706f"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
