;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261012.1218"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "1e0802cd06f2dc468491f6ccfe1981e865518597"
  :revdesc "1e0802cd06f2"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
