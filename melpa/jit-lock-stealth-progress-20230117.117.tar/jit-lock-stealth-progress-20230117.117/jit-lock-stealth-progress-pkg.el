(define-package "jit-lock-stealth-progress" "20230117.117" "JIT lock stealth mode-line progress"
  '((emacs "28.1"))
  :commit "0a6881b887f846f224c939c598bf0807bde2018e" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-jit-lock-stealth-progress")
;; Local Variables:
;; no-byte-compile: t
;; End:
