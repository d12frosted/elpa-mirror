;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261013.1444"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "07e2ca23799c0f352f2b87cb1751a86034079da5"
  :revdesc "07e2ca23799c"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
