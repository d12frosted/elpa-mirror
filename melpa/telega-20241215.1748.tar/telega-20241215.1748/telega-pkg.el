;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20241215.1748"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "80f5d49782f5207630fada86785f5024f73bd5df"
  :revdesc "80f5d49782f5"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
