;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycast" "20260504.1725"
  "Show current command and its binding."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/keycast"
  :commit "f9f396bcd3ed8ea4b64178383099872438ccdfb0"
  :revdesc "f9f396bcd3ed"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev")))
