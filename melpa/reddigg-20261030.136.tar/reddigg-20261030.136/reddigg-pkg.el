;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "20261030.136"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2")
    (json    "1.4"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "bdcdf4de7bb54c49999a8d7e210aa3c4c40f2ca0"
  :revdesc "bdcdf4de7bb5"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
