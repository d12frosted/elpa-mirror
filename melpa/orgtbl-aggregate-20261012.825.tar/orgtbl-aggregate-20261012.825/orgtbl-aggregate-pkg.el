;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20261012.825"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "d16e84f9c96ebad6fbfdba99d7c0c2363dab4f1f"
  :revdesc "d16e84f9c96e"
  :keywords '("data" "extensions"))
