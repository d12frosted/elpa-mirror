(define-package "wanderlust" "20211028.1330" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "475514f22c0869d7b84cdf0b957f9ae75a45605b")
;; Local Variables:
;; no-byte-compile: t
;; End:
