;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-mode" "20260810.31"
  "Major mode for editing .nix files."
  '((emacs         "27.1")
    (magit-section "0")
    (reformatter   "0")
    (transient     "0.3"))
  :url "https://github.com/NixOS/nix-mode"
  :commit "ff19db94c392a4299f89fe4778911ed02e435d35"
  :revdesc "ff19db94c392"
  :keywords '("nix" "languages" "tools" "unix")
  :maintainers '(("Matthew Bauer" . "mjbauer95@gmail.com")))
