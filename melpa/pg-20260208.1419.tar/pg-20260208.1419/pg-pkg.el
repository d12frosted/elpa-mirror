;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20260208.1419"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "52888cb6120407654f248877b2a78a75f7df0d99"
  :revdesc "52888cb61204"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
