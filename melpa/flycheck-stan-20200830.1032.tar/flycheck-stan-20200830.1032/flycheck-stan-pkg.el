(define-package "flycheck-stan" "20200830.1032" "Add Stan support for Flycheck"
  '((emacs "25.1")
    (flycheck "0.16.0")
    (stan-mode "10.1.0"))
  :commit "2dd330604563d143031fc8ffd516266217aa1f9b" :authors
  (("Jeffrey Arnold" . "jeffrey.arnold@gmail.com")
   ("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainer
  ("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")
  :keywords
  ("c" "languages")
  :url "https://github.com/stan-dev/stan-mode/tree/master/flycheck-stan")
;; Local Variables:
;; no-byte-compile: t
;; End:
