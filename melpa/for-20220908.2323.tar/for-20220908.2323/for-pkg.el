(define-package "for" "20220908.2323" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "740402cc9d34725137e53a766f04e545f49bed28" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
