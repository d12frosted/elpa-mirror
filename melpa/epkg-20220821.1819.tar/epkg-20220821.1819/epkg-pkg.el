(define-package "epkg" "20220821.1819" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "28.1.1.0")
    (closql "20210927"))
  :commit "2ebb5e5f7b69a580b586de1a0d112e3fa03e0813" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
