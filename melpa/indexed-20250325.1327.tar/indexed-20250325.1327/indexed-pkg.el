;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250325.1327"
  "Cache metadata on all Org files."
  '((emacs   "29.1")
    (el-job  "2.2.0")
    (llama   "0.5.0")
    (emacsql "4.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "9fe77b6035862f124bde7b65711a0349dd91f386"
  :revdesc "9fe77b603586"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
