;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-keg" "20200726.218"
  "Flycheck for Keg projects."
  '((emacs    "24.3")
    (keg      "0.1")
    (flycheck "0.1"))
  :url "https://github.com/conao3/keg.el"
  :commit "926de8f43842380e7150d99971eb73ff84cb59cb"
  :revdesc "926de8f43842"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
