(define-package "telega" "20201227.1442" "Telegram client (unofficial)"
  '((emacs "26.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "5595f60d75d33fb4e28b7424e79f9f0fd1eaac48" :authors
  (("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  ("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  ("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
