;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang-ts" "20260330.849"
  "Major modes for editing Erlang."
  '((emacs  "29.2")
    (erlang "27.2"))
  :url "https://github.com/erlang/emacs-erlang-ts"
  :commit "dc59e5a451f86d1ed533703486dfbad6efc1445d"
  :revdesc "dc59e5a451f8"
  :keywords '("erlang" "languages" "treesitter"))
