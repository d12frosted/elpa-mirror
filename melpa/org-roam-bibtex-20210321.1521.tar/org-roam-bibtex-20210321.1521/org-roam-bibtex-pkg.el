(define-package "org-roam-bibtex" "20210321.1521" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "1.2.2")
    (bibtex-completion "2.0.0"))
  :commit "e064ee9ac5304991f1f31e5b1e2907998d94f782" :authors
  '(("Leo Vivier" . "leo.vivier+dev@gmail.com")
    ("Mykhailo Shevchuk" . "mail@mshevchuk.com"))
  :maintainer
  '("Leo Vivier" . "leo.vivier+dev@gmail.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
