;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261119.2322"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "2bcb42550076a5343ecf08b8682f36df160c20e4"
  :revdesc "2bcb42550076")
