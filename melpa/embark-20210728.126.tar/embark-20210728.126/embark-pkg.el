(define-package "embark" "20210728.126" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "52bd3fd9153790f58e530547ff54b8232fda9715" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
