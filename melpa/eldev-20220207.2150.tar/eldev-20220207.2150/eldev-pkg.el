(define-package "eldev" "20220207.2150" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "b60abf67dfa9d64cab8087df008003db64982ca9" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
