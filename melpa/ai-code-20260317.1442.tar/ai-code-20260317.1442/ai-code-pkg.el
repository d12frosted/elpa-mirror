;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260317.1442"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "6d69fbc73452f9ee03b0c39808cd1982bc137f79"
  :revdesc "6d69fbc73452"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
