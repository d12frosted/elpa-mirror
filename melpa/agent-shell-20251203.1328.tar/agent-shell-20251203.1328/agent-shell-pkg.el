;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251203.1328"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "de19d78141cf27808e54f2894b197b9d46b991d9"
  :revdesc "de19d78141cf")
