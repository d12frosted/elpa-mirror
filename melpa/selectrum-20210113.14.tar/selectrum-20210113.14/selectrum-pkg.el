(define-package "selectrum" "20210113.14" "Easily select item from list"
  '((emacs "25.1"))
  :commit "bbb355d2db1ddbf2276ee9714909af541ff7c0af" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
