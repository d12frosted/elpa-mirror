;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260322.2306"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "6df3413964e6a127a404292929795dca0d0819ef"
  :revdesc "6df3413964e6"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
