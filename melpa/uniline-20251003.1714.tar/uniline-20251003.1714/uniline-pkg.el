;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20251003.1714"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "365778ed8d2382a614e409e29640f64ee625092c"
  :revdesc "365778ed8d23"
  :keywords '("convenience" "text"))
