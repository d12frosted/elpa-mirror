(define-package "brutal-theme" "20211109.1355" "Brutalist theme"
  '((emacs "24.1"))
  :commit "7afdcff388c2cd5309326531d59bd7b09b44dc8f" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
