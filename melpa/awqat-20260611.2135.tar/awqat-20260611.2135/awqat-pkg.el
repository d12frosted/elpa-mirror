;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awqat" "20260611.2135"
  "Islamic prayer times."
  '((emacs "28.1")
    (alert "1.2"))
  :url "https://github.com/zkry/awqat"
  :commit "c7ef627b2302983623587a30ef4ce87c770b7817"
  :revdesc "c7ef627b2302"
  :authors '(("Zachary Romero" . "zacromero@posteo.net"))
  :maintainers '(("Zachary Romero" . "zacromero@posteo.net")))
