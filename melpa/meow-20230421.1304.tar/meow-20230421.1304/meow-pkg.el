(define-package "meow" "20230421.1304" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "5b51f87a8898cc225e2fb0f35d194d4a3f684dbc" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
