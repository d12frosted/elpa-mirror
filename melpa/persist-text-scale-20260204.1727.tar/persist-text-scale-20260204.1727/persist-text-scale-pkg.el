;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20260204.1727"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "11a77f63a0cf7aa8ac836dab077e0dbb11e8f332"
  :revdesc "11a77f63a0cf"
  :keywords '("convenience"))
