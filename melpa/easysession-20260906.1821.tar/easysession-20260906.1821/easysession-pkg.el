;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260906.1821"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "7904fd83afcacedfdabe59a99356c92efc9b49f6"
  :revdesc "7904fd83afca"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
