(define-package "symbols-outline" "20231110.633" "Display symbols (functions, variables, etc) in outline view"
  '((emacs "27.1"))
  :commit "970961c63c5949599f684d7b663608e4fe5de635" :authors
  '(("Shihao Liu"))
  :maintainers
  '(("Shihao Liu"))
  :maintainer
  '("Shihao Liu")
  :keywords
  '("outlines")
  :url "https://github.com/liushihao456/symbols-outline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
