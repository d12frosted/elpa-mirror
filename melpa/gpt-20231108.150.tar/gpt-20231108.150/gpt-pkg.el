(define-package "gpt" "20231108.150" "Run instruction-following language models"
  '((emacs "24.4"))
  :commit "fb0ab4b1e95a6ba97c09ff072fc91ac7c7f22afa" :authors
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainers
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainer
  '("Andreas Stuhlmueller" . "andreas@ought.org")
  :keywords
  '("gpt3" "language" "copilot" "convenience" "tools")
  :url "https://github.com/stuhlmueller/gpt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
