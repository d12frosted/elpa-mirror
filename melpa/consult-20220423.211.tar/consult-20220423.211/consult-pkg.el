(define-package "consult" "20220423.211" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "a96ec24784291153cff731deb4024dd3d3bd9967" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
