(define-package "transient" "20211024.1439" "Transient commands"
  '((emacs "25.1")
    (compat "28.1.0.0"))
  :commit "e7b02466830df33c45f76b3423c84b2af7baa863" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("bindings")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
