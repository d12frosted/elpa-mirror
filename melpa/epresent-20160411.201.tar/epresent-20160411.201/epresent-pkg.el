;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epresent" "20160411.201"
  "Simple presentation mode for Emacs Org-mode."
  '((org    "8")
    (cl-lib "0.5"))
  :url "https://github.com/dakrone/epresent"
  :commit "bc3443879bb0111dcde2abd2f9c578e2cd438186"
  :revdesc "bc3443879bb0"
  :keywords '("gui")
  :authors '(("Tom Tromey" . "tromey@redhat.com")
             ("Eric Schulte" . "schulte.eric@gmail.com")
             ("Lee Hinman" . "lee@writequit.org"))
  :maintainers '(("Tom Tromey" . "tromey@redhat.com")
                 ("Eric Schulte" . "schulte.eric@gmail.com")
                 ("Lee Hinman" . "lee@writequit.org")))
