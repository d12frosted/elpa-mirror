(define-package "chronometrist-spark" "20220210.1321" "Show sparklines in Chronometrist buffers"
  '((emacs "25.1")
    (chronometrist "0.7.0")
    (spark "0.1"))
  :commit "66d747d27c952d7b71a5d27f1b353a8a575d1085" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
