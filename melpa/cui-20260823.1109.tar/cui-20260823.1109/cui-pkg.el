;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260823.1109"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "39d6585dd837e9c88852859562d6b5fe3832d1f2"
  :revdesc "39d6585dd837"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
