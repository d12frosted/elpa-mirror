;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20250329.58"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "42fabf83c63c369713075d5af6a6c81830fbfb5f"
  :revdesc "42fabf83c63c"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")))
