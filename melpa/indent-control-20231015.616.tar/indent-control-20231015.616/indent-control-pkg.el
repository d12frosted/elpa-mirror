(define-package "indent-control" "20231015.616" "Management for indentation level"
  '((emacs "26.1"))
  :commit "5d83d5fb581db8eaeb7f200ddc53c15a9b9a8b62" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "control" "indent" "tab" "generic" "level")
  :url "https://github.com/jcs-elpa/indent-control")
;; Local Variables:
;; no-byte-compile: t
;; End:
