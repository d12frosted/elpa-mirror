;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260115.2150"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "e3a5280bb1212d13fc5a07992ac0ca4ae1be23b8"
  :revdesc "e3a5280bb121"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
