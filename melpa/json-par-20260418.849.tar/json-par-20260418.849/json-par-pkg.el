;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "json-par" "20260418.849"
  "Minor mode for structural editing of JSON."
  '((emacs "24.4"))
  :url "https://github.com/taku0/json-par"
  :commit "9e1876e0c2a43d5350307bd834a856ebed54dcc4"
  :revdesc "9e1876e0c2a4"
  :keywords '("abbrev" "convenience" "files")
  :authors '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainers '(("taku0" . "mxxouy6x3m_github@tatapa.org")))
