;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "websearch" "20251225.1437"
  "Query search engines."
  '((emacs "24.4"))
  :url "https://gitlab.com/xgqt/xgqt-elisp-lib-websearch"
  :commit "d3403903f54d0ff5dd88d6675dae9bc9d738a32b"
  :revdesc "d3403903f54d"
  :keywords '("convenience" "hypermedia")
  :authors '(("Maciej Barć" . "xgqt@xgqt.org"))
  :maintainers '(("Maciej Barć" . "xgqt@xgqt.org")))
