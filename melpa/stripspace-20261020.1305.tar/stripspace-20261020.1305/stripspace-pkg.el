;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20261020.1305"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "7ccd4f0ae037b74d98de1a47d0fe2008c6b1dc92"
  :revdesc "7ccd4f0ae037"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
