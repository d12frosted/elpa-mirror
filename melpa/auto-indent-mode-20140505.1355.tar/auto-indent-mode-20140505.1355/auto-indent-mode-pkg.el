(define-package "auto-indent-mode" "20140505.1355" "Auto indent Minor mode" 'nil :commit "ad7032ee058a74405d04d775b0b384351536bc53" :authors
  '(("Matthew L. Fidler, Le Wang & Others"))
  :maintainer
  '("Matthew L. Fidler")
  :keywords
  '("auto" "indentation")
  :url "https://github.com/mlf176f2/auto-indent-mode.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
