(define-package "live-py-mode" "20220104.613" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "a5f1953904ae6ad7d347f15975d905b7f74ef16a" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
