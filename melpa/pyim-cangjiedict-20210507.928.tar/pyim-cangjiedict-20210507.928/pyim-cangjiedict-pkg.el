(define-package "pyim-cangjiedict" "20210507.928" "Some cangjie dicts for pyim"
  '((pyim "3.7"))
  :commit "455e20e90044a1fcd6c4b45252745fa233e0107d" :authors
  '(("Yuanchen Xie" . "yuanchen.gm@gmail.com"))
  :maintainer
  '("Yuanchen Xie" . "yuanchen.gm@gmail.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/p1uxtar/pyim-cangjiedict")
;; Local Variables:
;; no-byte-compile: t
;; End:
