(define-package "lsp-dart" "20221107.1539" "Dart support lsp-mode"
  '((emacs "26.3")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (dart-mode "1.0.5")
    (jsonrpc "1.0.15")
    (ht "2.2"))
  :commit "1cd9e746789ba3bd9a838bb52ea43026b092a103" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
