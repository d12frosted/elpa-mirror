;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "makefile-executor" "20260722.1556"
  "Commands for conveniently running makefile targets."
  '((emacs "27.1")
    (dash  "2.11.0")
    (f     "0.11.0")
    (s     "1.10.0"))
  :url "https://github.com/Olivia5k/makefile-executor.el"
  :commit "6514a34f21ffba5746cb0c7b3148bc656fd7c811"
  :revdesc "6514a34f21ff"
  :keywords '("processes")
  :authors '(("Olivia Thiderman" . "olivia@thiderman.org"))
  :maintainers '(("Olivia Thiderman" . "olivia@thiderman.org")))
