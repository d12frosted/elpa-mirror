(define-package "modus-themes" "20220921.1323" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "ee35a9af344d2b2920589ec4d66e9cb513bdfb80" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
