;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enclose" "20121008.1614"
  "Enclose cursor within punctuation pairs."
  ()
  :url "https://github.com/rejeep/enclose"
  :commit "2fff3d4fcc1089f87647042d7164ba04282766ae"
  :revdesc "2fff3d4fcc10"
  :keywords '("speed" "convenience")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
