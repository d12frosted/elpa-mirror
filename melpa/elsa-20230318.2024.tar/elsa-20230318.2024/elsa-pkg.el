(define-package "elsa" "20230318.2024" "Emacs Lisp Static Analyser"
  '((emacs "25.1")
    (trinary "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3")
    (lsp-mode "0"))
  :commit "2aa912dcc7d3732ba04eb96ab1cd186565a48f98" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp")
  :url "https://github.com/emacs-elsa/Elsa")
;; Local Variables:
;; no-byte-compile: t
;; End:
