(define-package "magik-mode" "20210903.1038" "mode for editing Magik + some utils." 'nil :commit "a60a0233ffc75776e4f4d1d779ac5af0ce0bb085" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
