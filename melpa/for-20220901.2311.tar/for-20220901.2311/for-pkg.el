(define-package "for" "20220901.2311" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "60220a371fe4d924d8ec11e1e7082bf23cb36132" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
