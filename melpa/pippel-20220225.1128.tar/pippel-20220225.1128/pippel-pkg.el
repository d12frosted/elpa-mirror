(define-package "pippel" "20220225.1128" "Frontend to python package manager pip"
  '((emacs "25.1")
    (s "1.11.0")
    (dash "2.12.0"))
  :commit "2a4628675597872acf1c3984e80e30b9abc5ea82" :authors
  '(("Fritz Stelzer" . "brotzeitmacher@gmail.com"))
  :maintainer
  '("Arif Er" . "arifer612@protonmail.me")
  :url "https://github.com/arifer612/pippel")
;; Local Variables:
;; no-byte-compile: t
;; End:
