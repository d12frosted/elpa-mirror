;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snippy" "20261128.50"
  "Vscode snippet support with Yasnippet."
  '((emacs     "30.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/MiniApollo/snippy"
  :commit "861a0356ed5c79225269e67cec1555c89b72b2a1"
  :revdesc "861a0356ed5c"
  :keywords '("convenience" "emulations")
  :authors '(("Mark Surmann" . "surmannmark@gmail.com"))
  :maintainers '(("Mark Surmann" . "surmannmark@gmail.com")))
