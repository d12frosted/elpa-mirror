;;; snippy.el --- Vscode snippet support with Yasnippet  -*- lexical-binding:t -*-

;; Copyright (C) 2026 Mark Surmann

;; Author: Mark Surmann <surmannmark@gmail.com>
;; Assisted-by: Claude:Opus 5.5
;; Created: 28 Jan 2026

;; Keywords: convenience, emulations
;; Package-Requires: ((emacs "30.1") (yasnippet "0.14.0"))
;; Package-Version: 20261128.50
;; Package-Revision: 861a0356ed5c
;; URL: https://github.com/MiniApollo/snippy

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Snippy is a snippet translation and completion engine that uses
;; YASnippet under the hood.

;; This package translates LSP/VSCode-style snippets into YASnippet
;; format, allowing you to use all modern, external snippets seamlessly.
;; It can optionally fix LSP snippets that Eglot retrieves from servers
;; (e.g., Java), working alongside YASnippet so you can use both
;; simultaneously.

;;; Code:

(require 'cl-lib)
(require 'yasnippet)
(require 'project)

;;; User customizable variables

(defgroup snippy nil
  "Custom snippet management utilities."
  :group 'editing)

(defcustom snippy-install-dir (expand-file-name user-emacs-directory)
  "Directory where to install/clone snippets."
  :type 'directory
  :group 'snippy)

(defcustom snippy-source '("https://github.com/rafamadriz/friendly-snippets.git" . "friendly-snippets")
  "The source details for downloading snippets."
  :type '(cons (string :tag "Repository URL")
               (string :tag "Directory Name"))
  :group 'snippy)

(defcustom snippy-global-languages nil
  "List of languages to enable globally across all major modes."
  :type '(repeat string)
  :group 'snippy)

;;; Internal Variables

(defconst snippy--min-vscode-version "1.11.0"
  "The minimum VSCode engine version required.")

(defvar snippy-minor-mode) ; Defined by `define-minor-mode' below.

(defvar snippy--package-json-content nil
  "Package json file content parsed as an alist.")

(defvar snippy--file-cache (make-hash-table :test 'equal)
  "Global cache storing parsed snippet files.
Keys are file paths, values are parsed alists.")

(defvar snippy--language-cache (make-hash-table :test 'equal)
  "Cache of (MERGED-SNIPPETS . CANDIDATES) shared between buffers.
Keys are values of `snippy--buffer-language', so buffers using the same
languages reuse one merged snippet list and one candidate list.")

(defvar-local snippy--buffer-language nil
  "The language currently used by snippy in the local buffer.")

(defvar-local snippy--merged-snippets nil
  "A merged alist of all snippets found in the snippets files.")

(defvar-local snippy--computed-candidates nil
  "List of completely propertized completion candidates for the current buffer.")

;;; Setup & Version Checking

(defun snippy--get-snippet-dir ()
  "Return snippet directory."
  (expand-file-name (cdr snippy-source)
                    (or snippy-install-dir user-emacs-directory)))

(defun snippy--clear-caches ()
  "Forget all parsed snippet data so the next refresh reads from disk."
  (clrhash snippy--file-cache)
  (clrhash snippy--language-cache)
  (setq snippy--package-json-content nil))

(defun snippy-install-or-update-snippets ()
  "Install or update snippet git repo in `snippy-install-dir'.
If `snippy-install-dir' is nil, it defaults to `user-emacs-directory'.
Updating runs `git pull' asynchronously; caches are cleared when it ends."
  (interactive)
  (let ((dest (snippy--get-snippet-dir)))
    (if (file-directory-p dest)
        (let ((default-directory dest)
              (output (generate-new-buffer " *snippy-git-pull*")))
          (message "Pulling updates in %s..." dest)
          (condition-case err
              (set-process-sentinel
               (start-process "Snippy-git-pull" output "git" "pull")
               (lambda (proc _event)
                 (when (memq (process-status proc) '(exit signal))
                   ;; Clear even on failure: a failed pull can still
                   ;; leave the working tree partly updated.
                   (snippy--clear-caches)
                   (if (zerop (process-exit-status proc))
                       (message "Snippy: Finished pulling updates in %s" dest)
                     (message "Snippy: git pull failed: %s"
                              (with-current-buffer output
                                (string-trim (buffer-string)))))
                   (when (buffer-live-p output)
                     (kill-buffer output)))))
            (error
             (kill-buffer output)
             (message "Snippy: Could not run git: %s"
                      (error-message-string err)))))
      (message "Cloning %s to %s..." (car snippy-source) dest)
      (with-temp-buffer
        (if (= 0 (call-process "git" nil t nil "clone" (car snippy-source) dest))
            (progn
              (message "Finished cloning to %s" dest)
              (snippy--clear-caches))
          (message "Git clone failed: %s" (string-trim (buffer-string))))))))

(defun snippy--get-package-data ()
  "Read and parse the package.json file.
Used for getting the snippet paths to read and the VScode engine version."
  (let ((file (expand-file-name "package.json" (snippy--get-snippet-dir))))
    (if (file-exists-p file)
        (progn
          (setq snippy--package-json-content
                (with-temp-buffer
                  (insert-file-contents file)
                  (json-parse-buffer :object-type 'alist :null-object nil)))
          (snippy--check-engine-version))
      (user-error "The package.json not found.  Run `M-x snippy-install-or-update-snippets' to install snippets"))))

;;; Vscode engine check

(defun snippy--clean-version (version)
  "Extract a clean semver string from VERSION, removing ^ or ~."
  (when (stringp version)
    (if (string-match "\\([0-9.]+\\)" version)
        (match-string 1 version)
      version)))

(defun snippy--check-engine-version ()
  "Check if the current VSCode engine version meets the minimum requirement."
  (let ((current-engine-version
         (snippy--clean-version (alist-get 'vscode (alist-get 'engines snippy--package-json-content)))))
    (cond
     ((null current-engine-version)
      (lwarn 'snippy :warning
             "Could not determine VSCode version from package.json."))
     ((version< current-engine-version snippy--min-vscode-version)
      (lwarn 'snippy :warning
             "Snippets target VSCode %s, which is older than the supported %s. Some snippets may not work"
             current-engine-version snippy--min-vscode-version)))))

;;; Language Remap

(defcustom snippy-emacs-to-vscode-lang-alist
  '((text-mode "plaintext")
    (markdown-mode "markdown")
    (markdown-ts-mode "markdown")
    (gfm-mode "markdown")

    ;; TeX / LaTeX (built-in modes and AUCTeX)
    (latex-mode "tex")
    (LaTeX-mode "tex")
    (tex-mode "tex")
    (plain-tex-mode "plaintex")
    (plain-TeX-mode "plaintex")
    (bibtex-mode "bib" "bibtex")

    ;; HTML
    (html-mode "html")
    (html-ts-mode "html")
    (mhtml-mode "html")
    (mhtml-ts-mode "html")
    (web-mode "html")

    ;; C / C++
    (c-mode "c" "cdoc")
    (c-ts-mode "c" "cdoc")
    (c++-mode "cpp" "cppdoc")
    (c++-ts-mode "cpp" "cppdoc")

    ;; C#
    (csharp-mode "csharp" "cs" "csharpdoc")
    (csharp-ts-mode "csharp" "cs" "csharpdoc")

    (editorconfig-conf-mode "editorconfig")
    (ejs-mode "ejs")
    (eruby-mode "eruby")
    (erlang-mode "erlang")

    ;; Elixir
    (elixir-mode "elixir")
    (elixir-ts-mode "elixir")
    (heex-ts-mode "heex")

    (f90-mode "fortran")
    (fortran-mode "fortran")
    (glsl-mode "glsl")
    (nix-mode "nix")

    ;; Lua
    (lua-mode "lua" "luadoc")
    (lua-ts-mode "lua" "luadoc")

    (go-mode "go")
    (go-ts-mode "go")
    (fennel-mode "fennel")

    ;; PHP
    (php-mode "php" "phpdoc")
    (php-ts-mode "php" "phpdoc")

    (quarto-mode "quarto")
    (rescript-mode "rescript")

    ;; Ruby
    (ruby-mode "ruby" "rails" "rdoc")
    (ruby-ts-mode "ruby" "rails" "rdoc")
    (rspec-mode "rspec")

    ;; Rust
    (rust-mode "rust" "rustdoc")
    (rust-ts-mode "rust" "rustdoc")

    (haskell-mode "haskell")
    (haskell-ts-mode "haskell")
    (scala-mode "scala")
    (solidity-mode "solidity")
    (swift-mode "swift")
    (sql-mode "sql")
    (verilog-mode "systemverilog" "verilog")

    ;; Shell / Bash
    (sh-mode "shellscript" "sh" "shell" "shelldoc" "zsh")
    (bash-ts-mode "shellscript" "sh" "shell" "shelldoc" "zsh")

    (plantuml-mode "plantuml")

    ;; Java
    (java-mode "java" "java-testing" "javadoc")
    (java-ts-mode "java" "java-testing" "javadoc")

    (julia-mode "julia")
    (astro-mode "astro")
    (astro-ts-mode "astro")

    ;; Clojure (no snippets in friendly-snippets; kept for other sources)
    (clojure-mode "clojure")
    (clojure-ts-mode "clojure")

    ;; CSS / Stylesheets
    (css-mode "css")
    (css-ts-mode "css")
    (scss-mode "scss")
    (sass-mode "sass")
    (less-css-mode "less")
    (stylus-mode "stylus")

    ;; JavaScript
    (js-mode "javascript" "jsdoc")
    (js2-mode "javascript")
    (js-ts-mode "javascript" "jsdoc")
    (rjsx-mode "javascriptreact")

    ;; TypeScript
    (typescript-mode "typescript" "jsdoc" "remix" "tsdoc")
    (typescript-ts-mode "typescript" "jsdoc" "remix" "tsdoc")
    (tsx-ts-mode "typescriptreact")

    (terraform-mode "terraform")
    (svelte-mode "svelte")
    (vue-mode "vue")
    (vue-ts-mode "vue")

    ;; Python
    (python-mode "python" "pydoc")
    (python-ts-mode "python" "pydoc")

    (cobol-mode "cobol")

    ;; Kotlin
    (kotlin-mode "kotlin" "kdoc")
    (kotlin-ts-mode "kotlin" "kdoc")

    (r-mode "r")
    (ess-r-mode "r")
    (org-mode "org")
    (gdscript-mode "gdscript")
    (gdscript-ts-mode "gdscript")

    ;; YAML
    (yaml-mode "yaml")
    (yaml-ts-mode "yaml")

    (makefile-mode "make")
    (dart-mode "dart" "flutter")
    (objc-mode "objc")
    (tcl-mode "tcl")
    (perl-mode "perl")
    (vhdl-mode "vhdl")

    ;; Dockerfile
    (dockerfile-mode "dockerfile")
    (dockerfile-ts-mode "dockerfile")

    (powershell-mode "powershell" "ps1")
    (reason-mode "reason")
    (ocaml-mode "ocaml")
    (tuareg-mode "ocaml.ocamllex" "ocamlinterface")
    (purescript-mode "purescript")
    (gleam-mode "gleam")
    (asciidoc-mode "asciidoc")
    (beancount-mode "beancount")
    (rst-mode "rst")

    ;; CMake
    (cmake-mode "cmake")
    (cmake-ts-mode "cmake")

    ;; Zig
    (zig-mode "zig")
    (zig-ts-mode "zig")

    (dune-mode "dune")
    (dune-project-mode "dune-project")
    (edge-mode "edge")
    (fsharp-mode "fsh")
    (jade-mode "jade")
    (pug-mode "pug")
    (jekyll-mode "jekyll")
    (kivy-mode "kivy")
    (liquid-mode "liquid")
    (mint-mode "mint")
    (norg-mode "norg")
    (nushell-mode "nu"))
  "Alist mapping Emacs major modes to a list of VS Code language identifiers.
Each entry is (MAJOR-MODE LANGUAGE...).  The lookup uses the exact value
of `major-mode', so derived modes need their own entry."
  :type '(alist :key-type symbol :value-type (repeat string))
  :group 'snippy)

(defun snippy--get-vscode-language-name ()
  "Return a list of all VSCode language strings for the current major mode."
  (alist-get major-mode snippy-emacs-to-vscode-lang-alist))

(defun snippy--update-buffer-language ()
  "Update `snippy--buffer-language` based on the current major mode."
  (setq snippy--buffer-language
        (append (snippy--get-vscode-language-name) snippy-global-languages)))

;;; Snippet Reading & Parsing

(defun snippy--get-all-paths-for-language (snippet-entries target-lang)
  "Return a list of all paths in SNIPPET-ENTRIES associated with TARGET-LANG."
  (when target-lang
    (let ((target (if (symbolp target-lang) (symbol-name target-lang) target-lang)))
      (cl-loop for entry across (or snippet-entries [])
               for val = (alist-get 'language entry)
               for val-strings = (mapcar (lambda (x) (if (symbolp x) (symbol-name x) x))
                                         (if (vectorp val) (append val nil) (list val)))
               when (member target val-strings)
               collect (alist-get 'path entry)))))

(defun snippy--get-all-snippets-paths ()
  "Return the snippets paths in package.json file for all languages."
  (alist-get 'snippets (alist-get 'contributes snippy--package-json-content)))

(defun snippy--get-current-language-path ()
  "Return a combined list of snippet paths for all languages."
  (delete-dups
   (cl-loop with all-dirs = (snippy--get-all-snippets-paths)
            for lang in (ensure-list snippy--buffer-language)
            append (snippy--get-all-paths-for-language all-dirs lang))))

(defun snippy--compute-candidates ()
  "Pre-compute and propertize all capf candidates for speed."
  (let (raw-candidates)
    (pcase-dolist (`(,name . ,data) snippy--merged-snippets)
      (let ((pref (alist-get 'prefix data))
            (desc (alist-get 'description data)))
        ;; Dedup within one snippet; different snippets may share a prefix.
        (dolist (key (delete-dups (if (stringp pref) (list pref) (append pref nil))))
          (push (propertize key
                            'snippy-name (format "%s" name)
                            'snippy-desc desc
                            'snippy-snippet data)
                raw-candidates))))
    (setq snippy--computed-candidates (nreverse raw-candidates))))

(defun snippy-refresh-snippets ()
  "Update the snippets for the current buffer.
If called interactively, it clears the cache to force a fresh disk read."
  (interactive)
  (when (called-interactively-p 'any)
    (snippy--clear-caches)
    (message "Snippy: Cache cleared."))
  (unless snippy--package-json-content
    (snippy--get-package-data))
  (snippy--update-buffer-language)
  (if-let* ((cached (gethash snippy--buffer-language snippy--language-cache)))
      (setq snippy--merged-snippets (car cached)
            snippy--computed-candidates (cdr cached))
    (setq snippy--merged-snippets
          (cl-loop with dir = (snippy--get-snippet-dir)
                   for suffix in (snippy--get-current-language-path)
                   for full-path = (expand-file-name suffix dir)
                   if (file-exists-p full-path)
                   append (or (gethash full-path snippy--file-cache)
                              (condition-case err
                                  (let ((parsed-data (with-temp-buffer
                                                       (insert-file-contents full-path)
                                                       (json-parse-buffer :object-type 'alist
                                                                          :null-object nil))))
                                    (puthash full-path parsed-data snippy--file-cache)
                                    parsed-data)
                                (error
                                 (message "Snippy: Skipping %s: %s"
                                          full-path (error-message-string err))
                                 nil)))
                   else
                   do (message "Snippy: Skipping %s (not found)" full-path)))
    (snippy--compute-candidates)
    (puthash snippy--buffer-language
             (cons snippy--merged-snippets snippy--computed-candidates)
             snippy--language-cache)))

(defun snippy--find-snippet-by-prefix (prefix)
  "Return the first snippet entry where the prefix matches PREFIX."
  (cl-find-if (lambda (snippet)
                (let ((target (alist-get 'prefix (cdr snippet))))
                  (cond
                   ((stringp target) (string= prefix target))
                   ((vectorp target) (cl-position prefix target :test #'string=))
                   ((listp target)   (member prefix target)))))
              snippy--merged-snippets))

;;; Snippet Expansion

(defun snippy--comment-syntax-p (opener)
  "Return non-nil if OPENER begins a comment in the current buffer's syntax table."
  (let ((table (syntax-table)))
    (with-temp-buffer
      (set-syntax-table table)
      (insert opener " x")
      (nth 4 (syntax-ppss)))))

(defun snippy--get-variable-value (var-name)
  "Return the Emacs string value of VS Code snippet variable VAR-NAME, or nil."
  (let* ((file-name (buffer-file-name))
         (dir (directory-file-name
               (if file-name (file-name-directory file-name) default-directory)))
         (project (and (member var-name '("WORKSPACE_NAME" "WORKSPACE_FOLDER"
                                          "RELATIVE_FILEPATH"))
                       (project-current)))
         (root (and project
                    (directory-file-name (expand-file-name (project-root project))))))
    (pcase var-name
      ;; Selection, line and word
      ("TM_SELECTED_TEXT"
       (if (use-region-p)
           (buffer-substring-no-properties (region-beginning) (region-end))
         ""))
      ("TM_CURRENT_LINE"
       (buffer-substring-no-properties (line-beginning-position) (line-end-position)))
      ("TM_CURRENT_WORD" (or (thing-at-point 'word t) ""))
      ("TM_LINE_INDEX"   (number-to-string (1- (line-number-at-pos nil t))))
      ("TM_LINE_NUMBER"  (number-to-string (line-number-at-pos nil t)))

      ;; Files and directories
      ("TM_FILENAME"      (if file-name (file-name-nondirectory file-name) (buffer-name)))
      ("TM_FILENAME_BASE" (if file-name (file-name-base file-name) (buffer-name)))
      ("TM_DIRECTORY"      dir)
      ("TM_DIRECTORY_BASE" (file-name-nondirectory dir))
      ("TM_FILEPATH"       (or file-name ""))
      ("RELATIVE_FILEPATH"
       (cond ((null file-name) "")
             (root (file-relative-name file-name root))
             (t (file-name-nondirectory file-name))))

      ;; Clipboard
      ("CLIPBOARD"
       (or (ignore-errors (substring-no-properties (current-kill 0))) ""))

      ;; Workspace
      ("WORKSPACE_NAME"   (if root (file-name-nondirectory root) "No Workspace"))
      ("WORKSPACE_FOLDER" (or root dir))

      ;; Comments
      ("LINE_COMMENT"
       (cond ((string-empty-p (string-trim (or comment-end "")))
              (string-trim (or comment-start "")))
             ((snippy--comment-syntax-p "//") "//")
             ;; Block-only language (CSS, HTML): no line comment exists.
             (t nil)))
      ("BLOCK_COMMENT_START"
       (if (snippy--comment-syntax-p "/*")
           "/*"
         (string-trim (or comment-start ""))))
      ("BLOCK_COMMENT_END"
       (if (snippy--comment-syntax-p "/*")
           "*/"
         (string-trim (or comment-end ""))))

      ;; Dates (localized according to `system-time-locale')
      ("CURRENT_YEAR"             (format-time-string "%Y"))
      ("CURRENT_YEAR_SHORT"       (format-time-string "%y"))
      ("CURRENT_MONTH"            (format-time-string "%m"))
      ("CURRENT_MONTH_NAME"       (format-time-string "%B"))
      ("CURRENT_MONTH_NAME_SHORT" (format-time-string "%b"))
      ("CURRENT_DATE"             (format-time-string "%d"))
      ("CURRENT_DAY_NAME"         (format-time-string "%A"))
      ("CURRENT_DAY_NAME_SHORT"   (format-time-string "%a"))
      ("CURRENT_HOUR"             (format-time-string "%H"))
      ("CURRENT_MINUTE"           (format-time-string "%M"))
      ("CURRENT_SECOND"           (format-time-string "%S"))
      ("CURRENT_SECONDS_UNIX"     (format-time-string "%s"))
      ("CURRENT_TIMEZONE_OFFSET"  (format-time-string "%:z"))

      ;; Randoms
      ("RANDOM"     (format "%06d" (random 1000000)))
      ("RANDOM_HEX" (format "%06x" (random #x1000000)))
      ("UUID" (format "%04x%04x-%04x-4%03x-%04x-%04x%04x%04x"
                      (random 65536) (random 65536)
                      (random 65536)
                      (random 4096)
                      (logior #x8000 (random 16384))
                      (random 65536) (random 65536) (random 65536)))

      ;; Unknown variable: let the caller leave it as-is
      (_ nil))))

(defun snippy--replace-matches (regexp fn string)
  "Replace every match of REGEXP in STRING with the result of FN.
FN receives the whole match followed by each subgroup (nil for a
group that did not match).  Its result is inserted literally."
  (let ((groups (number-sequence 0 (regexp-opt-depth regexp))))
    (replace-regexp-in-string
     regexp
     (lambda (match)
       (let ((args (mapcar (lambda (i) (match-string-no-properties i match))
                           groups)))
         (save-match-data (apply fn args))))
     string t t)))

(defun snippy--choice-to-elisp (choice)
  "Turn VSCode CHOICE into an Elisp string literal safe inside Yasnippet.
Escaped commas in CHOICE are expected to be hidden as NUL characters."
  (replace-regexp-in-string
   (rx (in "\\{}$`"))
   (lambda (c) (if (equal c "\\") "\\\\" (format "\\\\%03o" (aref c 0))))
   (prin1-to-string
    (replace-regexp-in-string (rx "\\" (group (in "\\,|`"))) "\\1"
                              (string-replace "\0" "," choice)))
   t t))

(defun snippy-transform-snippet-body (body-str)
  "Transform BODY-STR from VSCode snippet syntax to Yasnippet."
  ;; Backticks are literal in VSCode but evaluate Elisp in Yasnippet.
  (let ((result (string-replace "`" "\\`" body-str))
        (seen-ids '()))
    ;; A backslash before { ( ) " ' is literal in VSCode, but Yasnippet
    ;; treats it as an escape and drops it: double it to keep it.
    (setq result
          (snippy--replace-matches
           (rx "\\" (or (group (in "{()\"'")) anything))
           (lambda (match char) (if char (concat "\\" match) match))
           result))

    ;; Transforms like ${1/re/fmt/flags} aren't supported: drop them, keeping ${1}.
    (setq result
          (snippy--replace-matches
           (rx "${" (group (+ (in "a-zA-Z0-9_")))
               "/" (* (or (seq "\\" anything) (not (in "\\/"))))
               "/" (* (or (seq "\\" anything)
                          (seq "${" (* (not "}")) "}")
                          (not (in "\\/"))))
               "/" (* (in "a-z")) "}")
           (lambda (_match name) (format "${%s}" name))
           result))

    ;; Variables: $VAR, ${VAR} or ${VAR:default}.  Escape pairs like \\ and
    ;; \$ are skipped, so \$VAR stays literal but \\$VAR is substituted.
    (setq result
          (snippy--replace-matches
           (rx (or (seq "\\" anything)
                   (seq "$" (group (in "a-zA-Z_") (* (in "a-zA-Z0-9_"))))
                   (seq "${" (group (in "a-zA-Z_") (* (in "a-zA-Z0-9_")))
                        (? ":" (group (* (or (seq "\\" anything)
                                             (seq "${" (* (not "}")) "}")
                                             (not (in "\\}"))))))
                        "}")))
           (lambda (match name braced-name default)
             (let ((val (and (or name braced-name)
                             (snippy--get-variable-value (or name braced-name)))))
               (cond ((not (or name braced-name)) match)
                     ((and val (not (string-empty-p val)))
                      ;; Values are plain text: escape Yasnippet syntax.
                      (replace-regexp-in-string (rx (in "\\$`}")) "\\\\\\&" val))
                     (t (or default val match)))))
           result))

    ;; `$(' is literal text in VSCode, but Yasnippet runs `$(...)', and
    ;; also `$ (...)' or `$$ (...)', as Elisp: escape the `$'.  This runs
    ;; before the choices are turned into `$$(yas-choose-value ...)', so it
    ;; only sees the snippet's own text.  Escape pairs are kept, and so are
    ;; choices, whose text `snippy--choice-to-elisp' escapes later.
    (setq result
          (snippy--replace-matches
           (rx (or (seq "\\" anything)
                   (seq "${" (+ digit) "|"
                        (* (or (seq "\\" anything) (not (in "\\|"))))
                        "|}")
                   (group "$" (* (in " \t\n")) "(")))
           (lambda (match dollar) (if dollar (concat "\\" match) match))
           result))

    ;; Choices: ${1|a,b|}.  Escaped commas are hidden so they don't split.
    ;; Spaces around a choice are trimmed, unless the choice is only spaces.
    (setq result
          (snippy--replace-matches
           (rx "${" (group (+ digit)) "|"
               (group (* (or (seq "\\" anything) (not (in "\\|")))))
               "|}")
           (lambda (_match index text)
             (format "${%s:$$(yas-choose-value '(%s))}"
                     index
                     (mapconcat (lambda (choice)
                                  (let ((trimmed (string-trim choice)))
                                    (snippy--choice-to-elisp
                                     (if (string-empty-p trimmed) choice trimmed))))
                                (split-string (string-replace "\\," "\0" text) "," t)
                                " ")))
           result))

    ;; Placeholders: keep the first ${N:default}, mirror ${N} and later ones as $N.
    (setq result
          (snippy--replace-matches
           (rx "${" (group (+ digit))
               (? ":" (group (* (or (seq "\\" anything) (not (in "\\}"))))))
               "}")
           (lambda (match id default)
             (if (or (null default) (member id seen-ids))
                 (concat "$" id)
               (push id seen-ids)
               match))
           result))
    result))

(defun snippy-expand-snippet (snippet)
  "Convert VSCode SNIPPET to Yasnippet and expand it."
  (let ((body-raw (alist-get 'body snippet)))
    (yas-expand-snippet
     (snippy-transform-snippet-body
      (cond ((vectorp body-raw) (mapconcat #'identity body-raw "\n"))
            ((stringp body-raw) body-raw)
            (t ""))))))

(defun snippy-expand (prefix)
  "Expand snippet by PREFIX."
  (interactive "sEnter snippet prefix: ")
  (unless snippy-minor-mode
    (user-error "Snippy minor mode is not enabled in this buffer"))
  (unless (featurep 'yasnippet)
    (user-error "Yasnippet is not loaded.  Please install or require it first"))
  (let ((snippet (snippy--find-snippet-by-prefix prefix)))
    (unless snippet
      (user-error "No snippet with prefix %S for this buffer's language" prefix))
    (unless (bound-and-true-p yas-minor-mode)
      (yas-minor-mode t))
    (snippy-expand-snippet snippet)))

;;; Yasnippet Eglot Fix

(defun snippy--wrap-eglot-expansion-fn (fn)
  "Wrap Eglot's snippet expansion FN to convert VS Code syntax first."
  (when fn
    (lambda (snippet &rest args)
      (apply fn
             (if (stringp snippet)
                 (snippy-transform-snippet-body snippet)
               snippet)
             args))))

;;;###autoload
(define-minor-mode snippy-fix-lsp-snippet-mode
  "Toggle VSCode to Yasnippet transformation for Eglot snippets."
  :global t
  :group 'snippy
  (if snippy-fix-lsp-snippet-mode
      (advice-add 'eglot--snippet-expansion-fn :filter-return
                  #'snippy--wrap-eglot-expansion-fn)
    (advice-remove 'eglot--snippet-expansion-fn
                   #'snippy--wrap-eglot-expansion-fn)))

;;; Completion At Point (CAPF)

(defun snippy--doc-buffer (candidate)
  "Generate a documentation buffer for the snippet from CANDIDATE."
  (when-let* ((snippet  (get-text-property 0 'snippy-snippet candidate))
              (body-raw (alist-get 'body snippet)))
    (let ((desc (get-text-property 0 'snippy-desc candidate))
          (mode major-mode))
      (with-current-buffer (get-buffer-create "*snippy-doc*")
        (let ((inhibit-read-only t)
              (body-str (cond ((vectorp body-raw) (mapconcat #'identity body-raw "\n"))
                              ((stringp body-raw) body-raw)
                              (t ""))))
          (erase-buffer)
          (insert "Expands to:\n\n" body-str)
          (when (and desc (not (string-empty-p desc)))
            (insert "\n" (make-string 20 ?-) "\n" desc))
          (unless (eq major-mode mode)
            (condition-case nil
                (delay-mode-hooks (funcall mode))
              (error (delay-mode-hooks (fundamental-mode)))))
          (ignore-errors (font-lock-ensure))
          (setq-local cursor-type nil)
          (read-only-mode 1)
          (current-buffer))))))

(defvar snippy--capf-properties
  (list :annotation-function (lambda (cand)
                               (let ((name (get-text-property 0 'snippy-name cand)))
                                 (if name
                                     (format "  %s" name)
                                   "  Snippet")))
        :company-kind (lambda (_) 'snippet)
        :company-doc-buffer #'snippy--doc-buffer
        :exit-function (lambda (cand _status)
                         ;; Expand on any status, including `exact', so a
                         ;; prefix like "for" expands even when "fori" exists.
                         (let ((snippet (or (get-text-property 0 'snippy-snippet cand)
                                            (cdr (snippy--find-snippet-by-prefix cand)))))
                           (when snippet
                             (delete-region (- (point) (length cand)) (point))
                             (unless (bound-and-true-p yas-minor-mode)
                               (yas-minor-mode t))
                             (snippy-expand-snippet snippet))))
        :exclusive 'no)
  "Completion extra properties for Snippy.")

;;;###autoload
(define-minor-mode snippy-minor-mode
  "Toggle snippy in the current buffer."
  :group 'snippy
  (if snippy-minor-mode
      (condition-case err
          (progn
            (unless snippy--package-json-content
              (snippy--get-package-data))
            (snippy-refresh-snippets)
            (when (called-interactively-p 'any)
              (message "Snippy minor mode enabled")))
        (error
         (snippy-minor-mode -1)
         (message "Snippy: Failed to initialize: %s" (error-message-string err))))
    (setq snippy--buffer-language nil
          snippy--merged-snippets nil
          snippy--computed-candidates nil)
    (when (called-interactively-p 'any)
      (message "Snippy minor mode disabled"))))

;;;###autoload
(defun snippy-capf (&optional interactive)
  "Complete with snippy at point.
When INTERACTIVE is non-nil, as when called interactively, restrict
completion to snippy's candidates."
  (interactive (list t))
  (if interactive
      (let ((completion-at-point-functions (list #'snippy-capf)))
        (or (completion-at-point)
            (user-error "No snippy completions at point")))
    (when (and snippy-minor-mode snippy--computed-candidates)
      (let* ((end (point))
             (start (save-excursion
                      (skip-chars-backward "[:alnum:]!@#$%_&*\\^\\-")
                      (point))))
        `(,start ,end
                 ,snippy--computed-candidates
                 ,@snippy--capf-properties)))))

(defun snippy--turn-on ()
  "Enable `snippy-minor-mode' in programming, text or config buffers.
Also enable it in any mode listed in `snippy-emacs-to-vscode-lang-alist'."
  (when (and (not (minibufferp))
             ;; Only enable in "real" content buffers, or explicitly mapped modes
             (or (derived-mode-p 'prog-mode 'text-mode 'conf-mode)
                 (assq major-mode snippy-emacs-to-vscode-lang-alist))
             ;; Prevent infinite loops or redundant checks
             (not snippy-minor-mode))
    (snippy-minor-mode t)))

;;;###autoload
(define-globalized-minor-mode global-snippy-minor-mode
  snippy-minor-mode
  snippy--turn-on
  :group 'snippy)

(provide 'snippy)
;;; snippy.el ends here
