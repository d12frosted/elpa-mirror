(define-package "modus-themes" "20210206.958" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "bf2eaa9829831a7aacc97829ef0489f788980aa7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
