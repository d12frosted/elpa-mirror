;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260730.1941"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "c23d01652ce1b67f0acacbe4936c33792f256739"
  :revdesc "c23d01652ce1"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
