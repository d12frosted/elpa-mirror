(define-package "apdl-mode" "20210909.955" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "afdbcf3e1d24bd1534a0ab53ea978d01e8b4a505" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
