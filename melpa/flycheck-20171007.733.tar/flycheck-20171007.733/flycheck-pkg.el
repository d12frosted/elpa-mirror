(define-package "flycheck" "20171007.733" "On-the-fly syntax checking"
  '((dash "2.12.1")
    (pkg-info "0.4")
    (let-alist "1.0.4")
    (seq "1.11")
    (emacs "24.3"))
  :commit "401b115d10e202a1b31f57340438420081af21ce" :authors
  '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "http://www.flycheck.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
