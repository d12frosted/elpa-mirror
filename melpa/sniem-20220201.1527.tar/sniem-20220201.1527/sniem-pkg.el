(define-package "sniem" "20220201.1527" "Hands-eased united editing method"
  '((emacs "27.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "73f1dea98fa62c3a722a7640f1ddfe40678d78a9" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
