;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260123.621"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "9ec5241211072d8147965a1096342dfa437bc49f"
  :revdesc "9ec524121107"
  :keywords '("hypermedia"))
