;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260123.656"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.6.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "599b92afeb85ab6f0a178dad02d050d145f3c842"
  :revdesc "599b92afeb85"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
