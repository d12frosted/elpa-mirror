;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgstrap" "20250316.1815"
  "Bootstrap an Org file using file local variables."
  '((emacs "24.4"))
  :url "https://github.com/tgbugs/orgstrap"
  :commit "67f4f61716750b4cf4da715b40a19c5ed4bb505c"
  :revdesc "67f4f6171675"
  :keywords '("lisp" "org" "org-mode" "bootstrap"))
