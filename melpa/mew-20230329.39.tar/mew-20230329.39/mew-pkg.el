(define-package "mew" "20230329.39" "Messaging in the Emacs World" 'nil :commit "8c554e08f4ad5a023057af52b01c740727c454f4" :authors
  '(("Mew developing team"))
  :maintainer
  '("Mew developing team"))
;; Local Variables:
;; no-byte-compile: t
;; End:
