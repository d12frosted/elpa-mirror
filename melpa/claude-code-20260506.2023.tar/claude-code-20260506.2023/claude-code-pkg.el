;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code" "20260506.2023"
  "Run Claude Code sessions."
  '((emacs         "28.1")
    (projectile    "2.5.0")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (markdown-mode "2.5"))
  :url "https://github.com/yuya373/claude-code-emacs"
  :commit "2308cc819760e4163617210f883c1475a6c5fd59"
  :revdesc "2308cc819760"
  :keywords '("tools" "convenience"))
