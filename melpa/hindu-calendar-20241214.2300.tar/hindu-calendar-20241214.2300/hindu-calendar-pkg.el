;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hindu-calendar" "20241214.2300"
  "Arithmetical traditional Hindu calendar (panchanga)."
  '((emacs "24.3"))
  :url "https://github.com/bdsatish/hindu-calendar"
  :commit "637605c848888f4921cbda7083230f7125d123bf"
  :revdesc "637605c84888"
  :keywords '("calendar" "panchanga" "hindu" "indian")
  :authors '(("B.D.Satish" . "bdsatish@gmail.com"))
  :maintainers '(("B.D.Satish" . "bdsatish@gmail.com")))
