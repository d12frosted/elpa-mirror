;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260522.1356"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "22ad4f0d4611e3fa766aa316c9528af720e7a2d3"
  :revdesc "22ad4f0d4611"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
