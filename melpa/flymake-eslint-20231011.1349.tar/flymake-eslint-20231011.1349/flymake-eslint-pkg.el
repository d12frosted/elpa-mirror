(define-package "flymake-eslint" "20231011.1349" "A Flymake backend for Javascript using eslint"
  '((emacs "26.1"))
  :commit "e76071e3d8d941eedd106f13901fa5d904766973" :authors
  '(("Dan Orzechowski"))
  :maintainers
  '(("Dan Orzechowski"))
  :maintainer
  '("Dan Orzechowski")
  :keywords
  '("languages" "tools")
  :url "https://github.com/orzechowskid/flymake-eslint")
;; Local Variables:
;; no-byte-compile: t
;; End:
