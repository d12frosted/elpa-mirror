;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260310.1445"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "3a86ff6c49dc2a9ebaceabff24c1470edc5380eb"
  :revdesc "3a86ff6c49dc"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
