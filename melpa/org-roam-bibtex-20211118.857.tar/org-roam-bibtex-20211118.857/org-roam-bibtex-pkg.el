(define-package "org-roam-bibtex" "20211118.857" "Org Roam meets BibTeX"
  '((emacs "27.2")
    (org-roam "2.0.0")
    (bibtex-completion "2.0.0")
    (org-ref "3.0"))
  :commit "1034fedca880cf28b2d5d1442beb679d185036c0" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
