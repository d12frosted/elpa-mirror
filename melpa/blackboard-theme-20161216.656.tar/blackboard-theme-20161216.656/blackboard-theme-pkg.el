;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blackboard-theme" "20161216.656"
  "TextMate Blackboard Theme."
  '((emacs "24"))
  :url "https://github.com/don9z/blackboard-theme"
  :commit "d8b984f2541bb86eb4363a2b4c94631e49843d4a"
  :revdesc "d8b984f2541b")
