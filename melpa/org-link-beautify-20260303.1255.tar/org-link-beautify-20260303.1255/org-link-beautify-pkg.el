;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260303.1255"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "e6351a77366c58f4dd6022eda5fe89aa68bccd74"
  :revdesc "e6351a77366c"
  :keywords '("hypermedia"))
