(define-package "popper" "20211113.719" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "2650056e0e980a04c984b8d93abf20d35d13edcc" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
