;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260211.2014"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "45f82211ecf28b502c106c5ddd7373acbc94809e"
  :revdesc "45f82211ecf2"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
