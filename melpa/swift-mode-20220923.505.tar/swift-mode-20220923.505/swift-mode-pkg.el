(define-package "swift-mode" "20220923.505" "Major-mode for Apple's Swift programming language"
  '((emacs "24.4")
    (seq "2.3"))
  :commit "7552428931b5b8fe8b40e835484dc9d669bf2e87" :authors
  '(("taku0" . "mxxouy6x3m_github@tatapa.org")
    ("Chris Barrett" . "chris.d.barrett@me.com")
    ("Bozhidar Batsov" . "bozhidar@batsov.com")
    ("Arthur Evstifeev" . "lod@pisem.net"))
  :maintainer
  '("taku0" . "mxxouy6x3m_github@tatapa.org")
  :keywords
  '("languages" "swift")
  :url "https://github.com/swift-emacs/swift-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
