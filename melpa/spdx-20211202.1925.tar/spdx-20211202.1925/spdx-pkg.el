(define-package "spdx" "20211202.1925" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "4d1ce0ca8a4c84667301b3e347fe594989c25e60" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
