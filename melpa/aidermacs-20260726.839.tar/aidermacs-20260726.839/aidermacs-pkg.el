;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260726.839"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "a58f5b38de9c6db3a818edc24db513d8cc99313c"
  :revdesc "a58f5b38de9c"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
