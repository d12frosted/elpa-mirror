(define-package "ox-hugo" "20220512.1805" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "26.3")
    (tomelr "0.4.3"))
  :commit "2b169e5e83d608e80f4faee9d681b98d87041f58" :authors
  '(("Kaushal Modi" . "kaushal.modi@gmail.com")
    ("Matt Price" . "moptop99@gmail.com"))
  :maintainer
  '("Kaushal Modi" . "kaushal.modi@gmail.com")
  :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
