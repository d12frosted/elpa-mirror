(define-package "modus-themes" "20220628.634" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "5d35fed1ab7d2d59f64b2c5dcf77c05e64a0322e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
