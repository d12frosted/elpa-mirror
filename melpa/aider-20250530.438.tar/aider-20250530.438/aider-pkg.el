;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250530.438"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "20250520.1040")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "b470775e17075693d98591fedaf2feee530ade38"
  :revdesc "b470775e1707"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
