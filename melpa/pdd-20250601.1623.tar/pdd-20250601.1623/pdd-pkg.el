;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250601.1623"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "bb8278ca2c4a0af1fba56a0f17fb09dc64a0136b"
  :revdesc "bb8278ca2c4a"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
