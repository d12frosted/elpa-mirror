(define-package "telega" "20240228.1327" "Telegram client (unofficial)"
  '((emacs "27.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "3477e9df9df52db0f359bc83e7cc3e237ec3f739" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
