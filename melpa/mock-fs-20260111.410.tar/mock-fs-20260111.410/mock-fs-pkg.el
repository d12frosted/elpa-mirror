;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mock-fs" "20260111.410"
  "Virtual filesystem for Emacs Lisp tests."
  '((emacs "27.1"))
  :url "https://codeberg.org/Trevoke/mock-fs.el"
  :commit "c1a4b1f923bed627aea5579acd782e91243e7cdc"
  :revdesc "c1a4b1f923be"
  :keywords '("testing" "files"))
