;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vscode-dark-plus-theme" "20260219.422"
  "Default Visual Studio Code Dark+ theme."
  ()
  :url "https://github.com/ianpan870102/vscode-dark-plus-emacs-theme"
  :commit "0f6b41f9362590b56cc1d1fc4d2220fed72ebc8b"
  :revdesc "0f6b41f93625")
