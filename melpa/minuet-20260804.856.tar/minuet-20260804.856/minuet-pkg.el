;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260804.856"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "c22e773b6a9dcccdbeb901172d5e347d4c013984"
  :revdesc "c22e773b6a9d"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
