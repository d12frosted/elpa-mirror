;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250617.1522"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "a3e4566291b36af6861da0bdc9d7bf79d5443994"
  :revdesc "a3e4566291b3"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
