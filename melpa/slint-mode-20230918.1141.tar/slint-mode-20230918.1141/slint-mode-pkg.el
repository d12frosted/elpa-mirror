(define-package "slint-mode" "20230918.1141" "Major-mode for the Slint UI language"
  '((emacs "24.4")
    (lsp-mode "6.0"))
  :commit "9a4369714461ccdb22624744ea5e97dc61d2f01e" :authors
  '(("Niklas Cathor" . "niklas.cathor@gmx.de"))
  :maintainers
  '(("Niklas Cathor" . "niklas.cathor@gmx.de"))
  :maintainer
  '("Niklas Cathor" . "niklas.cathor@gmx.de")
  :keywords
  '("languages")
  :url "https://github.com/nilclass/slint-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
