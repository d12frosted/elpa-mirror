;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260119.2116"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b47e18587a5215231dcc94c9e44a7bbdc96135fe"
  :revdesc "b47e18587a52")
