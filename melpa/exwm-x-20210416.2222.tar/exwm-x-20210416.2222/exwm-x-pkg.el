(define-package "exwm-x" "20210416.2222" "A derivative wm based on EXWM (emacs x window manager)"
  '((cl-lib "0.5")
    (async "1.6")
    (exwm "0.22"))
  :commit "6a1393d94176b5edac69dcbde70107d572cfd10b" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("window-manager" "exwm")
  :url "https://github.com/tumashu/exwm-x")
;; Local Variables:
;; no-byte-compile: t
;; End:
