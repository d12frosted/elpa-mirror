(define-package "merlin" "20220628.1608" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "d6943ba5a4d918482e3193f63fa5399086e6fe63" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
