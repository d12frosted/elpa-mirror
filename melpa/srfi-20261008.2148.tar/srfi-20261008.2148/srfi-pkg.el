;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20261008.2148"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "46aa6fdaa75e7ddc2b0a519aaa561b1fe54d4f0a"
  :revdesc "46aa6fdaa75e"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
