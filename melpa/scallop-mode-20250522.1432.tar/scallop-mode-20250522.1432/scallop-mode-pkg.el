;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scallop-mode" "20250522.1432"
  "Major mode for editing Scallop programming language."
  '((emacs "24.3"))
  :url "https://github.com/taquangtrung/emacs-scallop-mode"
  :commit "ba416989c3ec64369fe2fe1dafc521ca6821b23d"
  :revdesc "ba416989c3ec"
  :keywords '("languages"))
