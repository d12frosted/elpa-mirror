(define-package "org-ai" "20230404.1819" "Your AI assistant with ChatGPT, DALL-E, Whisper"
  '((emacs "28.2"))
  :commit "9ff6b0a9e940e9f78702a40230ad7c9d2612559f" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
