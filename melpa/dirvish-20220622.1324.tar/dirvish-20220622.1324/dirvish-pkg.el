(define-package "dirvish" "20220622.1324" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "98ee3cbd5dbe8d90dd18bbb450739aff6591bc40" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
