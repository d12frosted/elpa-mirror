;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260427.2226"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ce966ebcb3bf5ed349c27cc0425fafec84f626e3"
  :revdesc "ce966ebcb3bf"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
