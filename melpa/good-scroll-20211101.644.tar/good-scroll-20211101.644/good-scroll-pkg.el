(define-package "good-scroll" "20211101.644" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "029de32f79a086b504f09334746970a2e9145fdf" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
