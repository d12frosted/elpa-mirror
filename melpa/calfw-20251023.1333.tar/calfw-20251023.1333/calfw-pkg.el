;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251023.1333"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "812660aff4851e7b5af64fa9fa6ec23ef80ee98a"
  :revdesc "812660aff485"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
