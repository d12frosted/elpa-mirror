(define-package "treemacs" "20211226.1135" "A tree style file explorer package"
  '((emacs "26.1")
    (cl-lib "0.5")
    (dash "2.11.0")
    (s "1.12.0")
    (ace-window "0.9.0")
    (pfuture "1.7")
    (hydra "0.13.2")
    (ht "2.2")
    (cfrs "1.3.2"))
  :commit "c33fb05b9b54c188f324323852d8d48317cfe3a7" :authors
  '(("Alexander Miller" . "alexanderm@web.de"))
  :maintainer
  '("Alexander Miller" . "alexanderm@web.de")
  :url "https://github.com/Alexander-Miller/treemacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
