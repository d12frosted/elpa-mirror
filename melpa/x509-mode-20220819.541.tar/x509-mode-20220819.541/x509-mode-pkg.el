(define-package "x509-mode" "20220819.541" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "24.3"))
  :commit "b71cbe8560c959ef45be05e49ebd4787f30b9436" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
