(define-package "x509-mode" "20220819.541" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "24.3"))
  :commit "64faa3d60f3db1da3bad4011654d5c2a70718b7c" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
