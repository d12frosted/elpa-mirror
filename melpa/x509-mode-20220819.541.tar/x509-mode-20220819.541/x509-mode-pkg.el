(define-package "x509-mode" "20220819.541" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "24.3"))
  :commit "a2ec552b454c22f027da5acc44f20f51a531e2e5" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
