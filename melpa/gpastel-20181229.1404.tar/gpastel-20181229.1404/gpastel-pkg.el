(define-package "gpastel" "20181229.1404" "Integrates GPaste with the kill-ring"
  '((emacs "25.1"))
  :commit "8a5522b274f79d55d7c9a0b2aaf062526f9253c7" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("tools")
  :url "https://gitlab.petton.fr/DamienCassou/desktop-environment")
;; Local Variables:
;; no-byte-compile: t
;; End:
