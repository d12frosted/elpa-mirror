;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260329.1809"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "a9b584944af19c912416a36a9d28dc4e06b2c99a"
  :revdesc "a9b584944af1"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
