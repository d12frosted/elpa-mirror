;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261111.1954"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "6a32b0a5e299a2a2196b6a5ddba3c49817731f42"
  :revdesc "6a32b0a5e299"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
