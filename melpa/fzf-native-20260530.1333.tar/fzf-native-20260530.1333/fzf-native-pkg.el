;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260530.1333"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "8f80acb2850a8ed7b0cb0be0e6a1c26f96a9e382"
  :revdesc "8f80acb2850a"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
