(define-package "helm-core" "20230908.1757" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "ffff39b542196565dcec5641e287265aaa5517ed" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
