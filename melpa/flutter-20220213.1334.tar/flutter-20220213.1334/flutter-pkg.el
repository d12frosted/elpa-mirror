(define-package "flutter" "20220213.1334" "Tools for working with Flutter SDK"
  '((emacs "24.4"))
  :commit "8cc0507cc6619cb9ec236c4eca7417ac081f1468" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("languages")
  :url "https://github.com/amake/flutter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
