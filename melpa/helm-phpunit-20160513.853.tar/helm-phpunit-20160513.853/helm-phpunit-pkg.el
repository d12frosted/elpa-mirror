;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-phpunit" "20160513.853"
  "Helm integration for phpunit.el."
  '((helm    "1.9.5")
    (phpunit "0.7.0"))
  :url "https://github.com/eric-hansen/phpunit-helm"
  :commit "739f26204ad2ba76c25f45e8eab1e5216f7c3518"
  :revdesc "739f26204ad2"
  :keywords '("phpunit" "helm" "php")
  :authors '(("Eric Hansen" . "hansen.c.eric@gmail.com"))
  :maintainers '(("Eric Hansen" . "hansen.c.eric@gmail.com")))
