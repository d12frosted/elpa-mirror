;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blackboard-bold-mode" "20241216.2353"
  "Quail package for Blackboard bold symbols."
  ()
  :url "https://github.com/grettke/blackboard-bold-mode"
  :commit "f4959eb0adca6b3096e5fea1f7e549533e4d8d79"
  :revdesc "f4959eb0adca"
  :keywords '("convenience" "i18n")
  :authors '(("Grant Rettke" . "grant@wisdomandwonder.com"))
  :maintainers '((nil . "grant@wisdomandwonder.com")))
