;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260930.14"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.8.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "84c9d9a9685f07b6988a618f11920ca063474fc8"
  :revdesc "84c9d9a9685f"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
