(define-package "python-docstring" "20220303.2235" "Smart Python docstring formatting" 'nil :commit "0dbc133cc9f207a448e59f3849c5e3ca51da7bd6")
;; Local Variables:
;; no-byte-compile: t
;; End:
