;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pest-mode" "20221231.15"
  "Major mode for editing Pest files."
  '((emacs "26.3"))
  :url "https://github.com/ksqsf/pest-mode"
  :commit "8023a92ce59c34dcd1587cbd85ed144f206ddb89"
  :revdesc "8023a92ce59c"
  :keywords '("languages")
  :authors '(("ksqsf" . "i@ksqsf.moe"))
  :maintainers '(("ksqsf" . "i@ksqsf.moe")))
