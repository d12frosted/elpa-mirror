(define-package "embark-consult" "20231126.305" "Consult integration for Embark"
  '((emacs "27.1")
    (embark "0.20")
    (consult "0.17"))
  :commit "c98bf2e9b57e273d9c9759abfc373bea98cf54f9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
