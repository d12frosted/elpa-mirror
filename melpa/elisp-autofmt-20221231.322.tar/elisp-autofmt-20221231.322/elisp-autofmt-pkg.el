(define-package "elisp-autofmt" "20221231.322" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "562aadd15b3004293a081faba582f4f36b079c75" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
