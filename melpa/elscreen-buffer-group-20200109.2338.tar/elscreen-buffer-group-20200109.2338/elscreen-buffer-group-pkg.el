;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-buffer-group" "20200109.2338"
  "Elscreen buffer group."
  '((emacs    "24.4")
    (elscreen "0")
    (cl-lib   "0.5"))
  :url "https://github.com/jeffgran/elscreen-buffer-group"
  :commit "b48e71d4782adfeb2958f227d78c04164d26e4bd"
  :revdesc "b48e71d4782a"
  :keywords '("buffer")
  :authors '(("Jeff Gran" . "jeff@jeffgran.com"))
  :maintainers '(("Jeff Gran" . "jeff@jeffgran.com")))
