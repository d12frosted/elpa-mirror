(define-package "consult" "20210315.740" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "ebf8ad9aa01a04c48f5af5aee41ee4d4e5fe57d6" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
