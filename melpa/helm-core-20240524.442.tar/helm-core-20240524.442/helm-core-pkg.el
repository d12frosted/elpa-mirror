(define-package "helm-core" "20240524.442" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "772313af34110ed0e712e7708967c18e6b1941f1" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
