;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asciidoc-mode" "20260603.1502"
  "Major mode for AsciiDoc markup."
  '((emacs "30.1"))
  :url "https://github.com/bbatsov/asciidoc-mode"
  :commit "cbc6d644ba3aefb5bd916d6f8922b82d0ec77e85"
  :revdesc "cbc6d644ba3a"
  :keywords '("text" "asciidoc" "languages" "tree-sitter")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
