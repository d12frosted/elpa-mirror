;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250317.631"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "99f91da7ff696fcc523f58d7991bb93128fb264a"
  :revdesc "99f91da7ff69"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
