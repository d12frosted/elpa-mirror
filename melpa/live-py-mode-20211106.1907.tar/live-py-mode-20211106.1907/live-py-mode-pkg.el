(define-package "live-py-mode" "20211106.1907" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "cf3dcb1d8e3503ae6208fb11ade5b9c8e2426578" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
