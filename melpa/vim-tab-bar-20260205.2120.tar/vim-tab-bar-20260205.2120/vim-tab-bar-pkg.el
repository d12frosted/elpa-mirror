;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20260205.2120"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "ce012cac00a63074803a0b8efaba123b8d8135a8"
  :revdesc "ce012cac00a6"
  :keywords '("frames"))
