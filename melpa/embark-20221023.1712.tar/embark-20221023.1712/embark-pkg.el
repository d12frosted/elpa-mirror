(define-package "embark" "20221023.1712" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "97f986b1589d0a3fd86f6ec82c0f593f0116828b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
