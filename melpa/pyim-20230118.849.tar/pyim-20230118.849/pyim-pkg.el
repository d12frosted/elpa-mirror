(define-package "pyim" "20230118.849" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "27.1")
    (async "1.6")
    (xr "1.13"))
  :commit "7a1fe3381ba301755ac6ed989954de47a6a1eb7f" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
