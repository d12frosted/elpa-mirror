(define-package "flexoki-themes" "20231114.1714" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "5305cc3deaf361f57c67c57d10ade2bd448603e9" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
