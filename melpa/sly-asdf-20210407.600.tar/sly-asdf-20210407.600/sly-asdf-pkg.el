(define-package "sly-asdf" "20210407.600" "ASDF system support for SLY"
  '((emacs "24.3")
    (sly "1.0.0beta2")
    (popup "0.5.3"))
  :commit "b95932a970f8edd4d1f3db0a62906111cc1ea6b3" :maintainer
  '("Matt George" . "mmge93@gmail.com")
  :keywords
  '("languages" "lisp" "sly" "asdf")
  :url "https://github.com/mmgeorge/sly-asdf")
;; Local Variables:
;; no-byte-compile: t
;; End:
