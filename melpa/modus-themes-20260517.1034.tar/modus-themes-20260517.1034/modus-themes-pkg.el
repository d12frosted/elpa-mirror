;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260517.1034"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "a47ed7af3fa0bf28893d3445fece6ce13c6526c8"
  :revdesc "a47ed7af3fa0"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
