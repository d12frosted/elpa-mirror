;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260504.546"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "c68a3196e7c7aaf113cb4f800ad5c6a9a5c3a5f5"
  :revdesc "c68a3196e7c7"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
