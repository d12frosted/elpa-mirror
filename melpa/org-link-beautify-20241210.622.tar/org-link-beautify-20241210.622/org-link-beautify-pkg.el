;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20241210.622"
  "Beautify Org Links."
  '((emacs      "29.1")
    (org        "9.7.14")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "0b57f07f3199c2cde7f677171773f460b12be561"
  :revdesc "0b57f07f3199"
  :keywords '("hypermedia"))
