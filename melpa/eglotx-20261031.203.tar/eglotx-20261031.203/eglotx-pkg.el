;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglotx" "20261031.203"
  "Native LSP multiplexer for Eglot."
  '((emacs   "29.1")
    (eglot   "1.24")
    (jsonrpc "1.0.29"))
  :url "https://github.com/cxa/eglotx"
  :commit "1c4dc8a5dad33b001c4474878b5eaa011e79451e"
  :revdesc "1c4dc8a5dad3"
  :keywords '("tools" "languages")
  :authors '(("CHEN Xian'an" . "xianan.chen@gmail.com"))
  :maintainers '(("CHEN Xian'an" . "xianan.chen@gmail.com")))
