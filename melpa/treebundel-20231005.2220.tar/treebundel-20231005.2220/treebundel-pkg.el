(define-package "treebundel" "20231005.2220" "Bundle related git-worktrees together"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "c1bf3a98c467b24cab8997964b85455defe636c9" :authors
  '(("Ben Whitley"))
  :maintainers
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/treebundel")
;; Local Variables:
;; no-byte-compile: t
;; End:
