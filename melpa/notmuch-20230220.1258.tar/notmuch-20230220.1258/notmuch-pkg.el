(define-package "notmuch" "20230220.1258" "run notmuch within emacs" 'nil :commit "f63d14a8c12ad76024d2865c0223a06f6f4bb372" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
