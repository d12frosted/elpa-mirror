(define-package "ayu-theme" "20230305.1840" "Ayu theme"
  '((emacs "24.1"))
  :commit "fadeec7dbd5fd44557addd88653c4d78a2002bea" :authors
  '(("Tran Anh Vu"))
  :maintainer
  '("Tran Anh Vu")
  :keywords
  '("lisp" "theme" "emacs")
  :url "https://github.com/vutran1710/Ayu-Theme-Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
