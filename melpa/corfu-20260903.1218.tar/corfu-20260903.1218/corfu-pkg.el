;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20260903.1218"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "4303506204bdf5df8f5e7d1457f6fca465a4da8e"
  :revdesc "4303506204bd"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
