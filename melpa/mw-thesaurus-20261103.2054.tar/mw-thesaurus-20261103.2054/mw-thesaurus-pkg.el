;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mw-thesaurus" "20261103.2054"
  "Merriam-Webster Thesaurus and Dictionary."
  '((emacs "27.1"))
  :url "https://github.com/agzam/mw-thesaurus.el"
  :commit "6bc8358abd0d1d43a513d888373ffa891e0fd306"
  :revdesc "6bc8358abd0d"
  :keywords '("wp" "matching")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
