(define-package "sentex" "20230411.1650" "Regex-based sentence navigation rules"
  '((emacs "27.1"))
  :commit "ab96ee0e9856222aaad6b085cf4ca0c5dda73789" :authors
  '(("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainer
  '("Marty Hiatt <martianhiatus AT riseup.net>")
  :keywords
  '("languages" "convenience" "translation" "sentences" "text" "wp")
  :url "https://codeberg.org/martianh/sentex")
;; Local Variables:
;; no-byte-compile: t
;; End:
