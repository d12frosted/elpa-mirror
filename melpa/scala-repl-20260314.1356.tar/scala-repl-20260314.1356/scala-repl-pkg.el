;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scala-repl" "20260314.1356"
  "Scala REPL Mode."
  '((emacs "29.1"))
  :url "https://github.com/sheepduke/scala-repl.el"
  :commit "fa3ead3c247b215d456b6f3aa67598e8bb61e79a"
  :revdesc "fa3ead3c247b"
  :keywords '("languages" "tools")
  :authors '(("Daian YUE" . "sheepduke@gmail.com"))
  :maintainers '(("Daian YUE" . "sheepduke@gmail.com")))
