;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "template-dumper" "20240630.2236"
  "Create files from yasnippet templates."
  '((emacs     "28.1")
    (yasnippet "0.14.0")
    (f         "0.20.0"))
  :url "https://resultsmotivated.com/"
  :commit "92fb170d572f044aaedaa2535990eba556347dfe"
  :revdesc "92fb170d572f"
  :keywords '("yasnippet" "templating" "convenience" "tools"))
