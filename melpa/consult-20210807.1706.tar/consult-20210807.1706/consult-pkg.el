(define-package "consult" "20210807.1706" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "5e6749ce6ccc82efa4737cd51db0f3e41037d563" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
