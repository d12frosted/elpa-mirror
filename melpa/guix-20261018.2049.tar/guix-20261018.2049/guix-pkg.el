;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20261018.2049"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3")
    (consult       "3.5"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "97b370d70e5e74dc0bb26f1c57a4f1c89ce956f1"
  :revdesc "97b370d70e5e"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
