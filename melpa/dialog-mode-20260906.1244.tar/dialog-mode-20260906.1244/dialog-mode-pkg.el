;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260906.1244"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "e3dd89b6a13efb5073b5a36f316a9e7c0f98aa4c"
  :revdesc "e3dd89b6a13e"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
