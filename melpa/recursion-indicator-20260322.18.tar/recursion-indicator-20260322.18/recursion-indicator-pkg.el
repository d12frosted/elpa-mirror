;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recursion-indicator" "20260322.18"
  "Recursion indicator."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/recursion-indicator"
  :commit "4805275937585102aba0047169f047032201c5b9"
  :revdesc "480527593758"
  :keywords '("convenience")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
