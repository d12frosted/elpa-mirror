(define-package "haki-theme" "20231103.1440" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "790686fd26681c9602b534075efa09a522a5847d" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
