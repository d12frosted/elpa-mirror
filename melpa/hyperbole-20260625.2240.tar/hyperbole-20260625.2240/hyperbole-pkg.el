;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260625.2240"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "968bb40736f9c7999ce30b37b723d97358901ba4"
  :revdesc "968bb40736f9"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
