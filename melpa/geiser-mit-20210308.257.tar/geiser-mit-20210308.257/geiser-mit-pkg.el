(define-package "geiser-mit" "20210308.257" "MIT/GNU Scheme's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.12"))
  :commit "1caea838ddbbf3d8e0c6f39656f8ff3b445e371a" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "mit" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/mit")
;; Local Variables:
;; no-byte-compile: t
;; End:
