(define-package "embark" "20210727.1256" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "3509503fa59c69f9c8545f27fb850c5ea1bd93b1" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
