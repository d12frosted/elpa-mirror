(define-package "spdx" "20221007.159" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "7bbe99a7b3f65fd96bf982b94e58033a96a3bb3c" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
