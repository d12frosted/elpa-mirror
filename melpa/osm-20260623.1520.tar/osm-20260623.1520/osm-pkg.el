;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260623.1520"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/osm"
  :commit "b0fceb1f8488abb577e5110676f50753ea35ee24"
  :revdesc "b0fceb1f8488"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
