;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "20261001.1445"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "64988dbc7d1f8232891d9c1d51510ba1b470fd83"
  :revdesc "64988dbc7d1f"
  :keywords '("tools" "languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
