;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250626.751"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "8f6ac7f59a8afe81a79ed2a8c5f7ce8ec0385f06"
  :revdesc "8f6ac7f59a8a"
  :keywords '("languages"))
