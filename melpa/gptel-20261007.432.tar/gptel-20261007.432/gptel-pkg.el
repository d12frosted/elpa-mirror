;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20261007.432"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "406432d83f8a76e7af54d88c97df1863bd9a9119"
  :revdesc "406432d83f8a"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
