(define-package "meow" "20220911.319" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "28ded780283085dcc27b33a8e0d7a93c4798c9a8" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
