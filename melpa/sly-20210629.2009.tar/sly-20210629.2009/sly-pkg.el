(define-package "sly" "20210629.2009" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "954e5dad72fb5712dfa968222e2b46dfdf9a476c" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
