(define-package "sly" "20210629.2009" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "41f4d650485217aa1f2afa7c159418f103a09231" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
