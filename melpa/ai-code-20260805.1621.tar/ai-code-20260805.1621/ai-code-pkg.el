;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260805.1621"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "4b17df0e71365c4b05aeccc608d8c401792d4817"
  :revdesc "4b17df0e7136"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
