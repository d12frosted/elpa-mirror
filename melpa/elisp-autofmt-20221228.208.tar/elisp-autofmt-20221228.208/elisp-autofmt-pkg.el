(define-package "elisp-autofmt" "20221228.208" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "8b9315492a956a05ca8b6400fade9a7e4652f69a" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
