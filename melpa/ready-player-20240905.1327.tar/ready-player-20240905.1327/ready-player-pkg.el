(define-package "ready-player" "20240905.1327" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "092a3d843d2ad96b3f9ccbbacc06b027a6d2a407" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
