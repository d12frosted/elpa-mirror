;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20251211.1753"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "d3bba3d83faff57c14db1e9b6ac70422530590f0"
  :revdesc "d3bba3d83faf"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
