;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20250717.1734"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "8a1e103fab8cf049ab6271bbff98e1b718cf298a"
  :revdesc "8a1e103fab8c"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
