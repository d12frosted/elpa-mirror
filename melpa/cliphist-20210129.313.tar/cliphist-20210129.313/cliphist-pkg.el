(define-package "cliphist" "20210129.313" "Read data from clipboard managers at Linux and Mac"
  '((emacs "24.3")
    (ivy "0.9.0"))
  :commit "3682a114e7651fc53155451afef0026f25f01f64" :authors
  '(("Chen Bin <chenin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenin DOT sh AT gmail DOT com>")
  :keywords
  '("clipboard" "manager" "history")
  :url "http://github.com/redguardtoo/cliphist")
;; Local Variables:
;; no-byte-compile: t
;; End:
