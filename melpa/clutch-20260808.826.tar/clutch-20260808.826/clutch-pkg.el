;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260808.826"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "9c622e9eef271d8a0ad37ce69c189eda6c770722"
  :revdesc "9c622e9eef27"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
