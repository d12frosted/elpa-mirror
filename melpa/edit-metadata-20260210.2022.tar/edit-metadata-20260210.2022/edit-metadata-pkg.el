;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-metadata" "20260210.2022"
  "Edit embedded metadata."
  '((exiftool "0.3.2")
    (emacs    "28.1")
    (compat   "29.1"))
  :url "https://gitlab.epfl.ch/michael.piotrowski/edit-metadata"
  :commit "903b6c0d7d8f6550dd91a56cd1cf9d880b5cbded"
  :revdesc "903b6c0d7d8f"
  :keywords '("files" "multimedia")
  :authors '(("Michael Piotrowski" . "mxp@dynalabs.de"))
  :maintainers '(("Michael Piotrowski" . "mxp@dynalabs.de")))
