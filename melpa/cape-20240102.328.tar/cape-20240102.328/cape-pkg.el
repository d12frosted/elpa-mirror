(define-package "cape" "20240102.328" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "273dc473a0016f75902d4802101f0f9d46f7b2e3" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "text")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
