(define-package "consult" "20221203.545" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "c3608b1f634aebf8770ecb1d933a1ae9c34ecdf8" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
