;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20261017.2353"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "abaa3d07cc05470ec471511a3626a48d25f198fd"
  :revdesc "abaa3d07cc05"
  :keywords '("languages" "lisp" "slime"))
