;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260210.930"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "70128aad898e666367e894f4f4de8a12294f2483"
  :revdesc "70128aad898e"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
