(define-package "modus-themes" "20211127.514" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "4d6ea03a36d4c52ad97ca53734103deab97ada82" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
