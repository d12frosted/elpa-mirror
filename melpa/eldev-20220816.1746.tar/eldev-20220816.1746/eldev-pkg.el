(define-package "eldev" "20220816.1746" "Elisp development tool"
  '((emacs "24.4"))
  :commit "067134a9bfe6326de258f0af666a53e13a9b4a93" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
