;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "servant" "20140216.1219"
  "ELPA server written in Emacs Lisp."
  '((s          "1.8.0")
    (dash       "2.2.0")
    (f          "0.11.0")
    (ansi       "0.3.0")
    (commander  "0.5.0")
    (epl        "0.2")
    (shut-up    "0.2.1")
    (web-server "0.0.1"))
  :url "https://github.com/rejeep/servant.el"
  :commit "4d2aa8250b54b28e6e7ee4cd5ebd98a33db2c134"
  :revdesc "4d2aa8250b54"
  :keywords '("elpa" "server")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com")
             ("Sebastian Wiesner" . "lunaryorn@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")
                 ("Sebastian Wiesner" . "lunaryorn@gmail.com")))
