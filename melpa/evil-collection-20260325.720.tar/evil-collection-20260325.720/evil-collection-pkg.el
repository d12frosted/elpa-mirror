;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260325.720"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "8f261eb0c284be23f534dbbef976d71a5ab5245f"
  :revdesc "8f261eb0c284"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
