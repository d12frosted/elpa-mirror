;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250319.242"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "dc3b4452a1e564e13082ece7e57f1ca72763adb6"
  :revdesc "dc3b4452a1e5"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
