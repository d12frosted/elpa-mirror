(define-package "sotclojure" "20170922.8" "Write clojure at the speed of thought."
  '((emacs "24.1")
    (clojure-mode "4.0.0")
    (cider "0.8")
    (sotlisp "1.3"))
  :commit "ceac82aa691e8d98946471be6aaff9c9a4603c32" :authors
  '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainer
  '("Artur Malabarba" . "emacs@endlessparentheses.com")
  :keywords
  '("convenience" "clojure")
  :url "https://github.com/Malabarba/speed-of-thought-clojure")
;; Local Variables:
;; no-byte-compile: t
;; End:
