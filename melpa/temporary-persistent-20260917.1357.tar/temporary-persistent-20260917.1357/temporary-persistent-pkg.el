;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "temporary-persistent" "20260917.1357"
  "Keep temp notes buffers persistent."
  '((emacs "24.3")
    (names "20151201.0")
    (dash  "2.12.1")
    (s     "1.10.0"))
  :url "https://github.com/kostafey/temporary-persistent"
  :commit "2e2e5d950de345f320bb419c5894a3aae26010d8"
  :revdesc "2e2e5d950de3"
  :keywords '("temp" "buffers" "notes")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
