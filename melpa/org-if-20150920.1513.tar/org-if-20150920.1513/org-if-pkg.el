(define-package "org-if" "20150920.1513" "Interactive Fiction Authoring System for Org-Mode." 'nil :commit "fab602cc1bbee7a4e99c0083e129219d3f9ed2e8")
;; Local Variables:
;; no-byte-compile: t
;; End:
