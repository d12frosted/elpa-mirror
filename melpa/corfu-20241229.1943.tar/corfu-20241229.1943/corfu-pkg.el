;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20241229.1943"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "9f0903387f0c9019dab8b91cf39b8c6ba2de9430"
  :revdesc "9f0903387f0c"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
