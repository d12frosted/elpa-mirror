;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20260114.1604"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "64917611b8223fdfe080882738b64f5a2c90ff98"
  :revdesc "64917611b822"
  :keywords '("frames"))
