;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "roc-ts-mode" "20250311.541"
  "Roc programming language mode."
  '((emacs "29.1"))
  :url "https://gitlab.com/tad-lispy/roc-ts-mode"
  :commit "ec6cb69d15ff92550e8c1c0dec685464fc92e293"
  :revdesc "ec6cb69d15ff"
  :keywords '("languages")
  :authors '(("Tad Lispy" . "tadeusz@lazurski.pl")
             ("Ajai Khatri Nelson" . "emacs@ajai.dev"))
  :maintainers '(("Tad Lispy" . "tadeusz@lazurski.pl")
                 ("Ajai Khatri Nelson" . "emacs@ajai.dev")))
