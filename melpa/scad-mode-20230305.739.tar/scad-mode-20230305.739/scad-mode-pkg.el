(define-package "scad-mode" "20230305.739" "A major mode for editing OpenSCAD code"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "9d12bb70dde41d0abd32eb9096183f585a33b996" :authors
  '(("Len Trigg, Łukasz Stelmach, zk_phi, Daniel Mendler"))
  :maintainer
  '("Len Trigg <lenbok@gmail.com>, Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("languages")
  :url "https://github.com/openscad/emacs-scad-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
