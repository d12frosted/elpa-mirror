(define-package "realgud-lldb" "20210417.1434" "Realgud front-end to lldb"
  '((load-relative "1.3.1")
    (realgud "1.5.0")
    (emacs "25"))
  :commit "abffd0d2d23f6c87be5dc5d36e948af92de5df86" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :url "http://github.com/realgud/realgud-lldb")
;; Local Variables:
;; no-byte-compile: t
;; End:
