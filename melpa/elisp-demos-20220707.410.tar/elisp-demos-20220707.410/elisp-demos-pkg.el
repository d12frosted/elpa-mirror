(define-package "elisp-demos" "20220707.410" "Elisp API Demos"
  '((emacs "24.4"))
  :commit "4b51dff1ee5b6cb9fac946431753489cd96a67b0" :authors
  '(("Xu Chunyang"))
  :maintainer
  '("Xu Chunyang")
  :keywords
  '("lisp" "docs")
  :url "https://github.com/xuchunyang/elisp-demos")
;; Local Variables:
;; no-byte-compile: t
;; End:
