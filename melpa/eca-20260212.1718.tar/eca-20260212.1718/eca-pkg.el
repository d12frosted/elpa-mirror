;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260212.1718"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "4570fc5a2e71cdedf9b310ddb20154f32fd2f7a3"
  :revdesc "4570fc5a2e71"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
