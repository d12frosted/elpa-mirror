(define-package "dix" "20181210.1200" "Apertium XML editing minor mode"
  '((cl-lib "0.5")
    (emacs "24.4"))
  :commit "b973de948deb7aa2995b1895e1e62bbe3129b5a5" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("languages")
  :url "http://wiki.apertium.org/wiki/Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
