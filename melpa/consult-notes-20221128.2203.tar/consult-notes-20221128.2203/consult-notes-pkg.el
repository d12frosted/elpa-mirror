(define-package "consult-notes" "20221128.2203" "Manage notes with consult"
  '((emacs "27.1")
    (consult "0.17")
    (s "1.12.0")
    (dash "2.19"))
  :commit "bfcc6b8e077cb0056b0cbd5cd602e61e4c0dad10" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience")
  :url "https://github.com/mclear-tools/consult-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
