(define-package "islisp-mode" "20220924.1043" "Major mode for ISLisp programming"
  '((emacs "26.3"))
  :commit "bbf45d02495f9455e91beed01676178dfa5d3561" :authors
  '(("Fermin Munoz"))
  :maintainer
  '("Fermin Munoz" . "fmfs@posteo.net")
  :keywords
  '("islisp" "lisp" "programming")
  :url "https://gitlab.com/sasanidas/islisp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
