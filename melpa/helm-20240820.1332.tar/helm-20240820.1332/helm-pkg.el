(define-package "helm" "20240820.1332" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.9")
    (wfnames "1.2"))
  :commit "4f45e9f3526bb8c94c62f3f9c906d84622d52b7e" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
