;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trope-mode" "20250120.2029"
  "Major mode to edit TV Tropes format \".trp\" files."
  '((emacs "29.1"))
  :url "https://github.com/TriAttack238/trope-mode"
  :commit "50ff6d4181a01115aa5a483eb16bc7bfc4b1aaa9"
  :revdesc "50ff6d4181a0"
  :keywords '("tv tropes" "trope" "wp")
  :authors '(("Sean Vo" . "triattack238@gmail.com"))
  :maintainers '(("Sean Vo" . "triattack238@gmail.com")))
