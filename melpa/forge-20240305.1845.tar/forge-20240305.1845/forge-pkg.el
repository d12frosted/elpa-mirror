(define-package "forge" "20240305.1845" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "29.1.4.4")
    (closql "20240125")
    (dash "2.19.1")
    (emacsql "20240124")
    (ghub "20240101")
    (let-alist "1.0.6")
    (magit "20240125")
    (markdown-mode "2.6")
    (seq "2.24")
    (transient "20240201")
    (yaml "0.5.5"))
  :commit "9f52b9142bca57ea2d6e49b0112c9626b24e1624" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
