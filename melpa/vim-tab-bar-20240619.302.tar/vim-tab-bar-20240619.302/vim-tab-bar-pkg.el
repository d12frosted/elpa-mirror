(define-package "vim-tab-bar" "20240619.302" "Vim-like tab bar"
  '((emacs "28.1"))
  :commit "a6228b5f855ea55828f8733c44a23c7d34734d49" :authors
  '(("James Cherti"))
  :maintainers
  '(("James Cherti"))
  :maintainer
  '("James Cherti")
  :keywords
  '("frames")
  :url "https://github.com/jamescherti/vim-tab-bar.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
