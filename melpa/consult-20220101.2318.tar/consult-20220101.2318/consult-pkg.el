(define-package "consult" "20220101.2318" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "0940ca016531f3412003c231b476e5023a510ff9" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
