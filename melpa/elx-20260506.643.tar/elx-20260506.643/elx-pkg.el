;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "20260506.643"
  "Extract information from Emacs Lisp libraries."
  '((emacs  "29.1")
    (compat "31.0")
    (llama  "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "4a64b89d66bb4a0965113b16c7b6d0a5170f008d"
  :revdesc "4a64b89d66bb"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
