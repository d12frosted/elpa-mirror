(define-package "corfu" "20231207.1420" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "9539528c45863e2a5fa6a1a0dd456c7acca2c2ca" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
