;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-dash" "20250101.2011"
  "Smart-Dash minor mode."
  ()
  :url "https://github.com/malsyned/smart-dash"
  :commit "98ea891a885fbe54a754a46730be3527dfe24af3"
  :revdesc "98ea891a885f"
  :authors '(("Dennis Lambe Jr." . "malsyned@malsyned.net"))
  :maintainers '(("Dennis Lambe Jr." . "malsyned@malsyned.net")))
