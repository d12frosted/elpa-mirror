;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-tdd-mode" "20250719.1438"
  "Modern TDD Mode for Python."
  '((emacs "27.1"))
  :url "https://github.com/marcwebbie/tdd-mode"
  :commit "e0c05730c76bfed1d819bc981c90ab16e681b55d"
  :revdesc "e0c05730c76b"
  :keywords '("tools" "convenience" "testing" "python" "tdd")
  :authors '(("Marcwebbie" . "marcwebbie@gmail.com"))
  :maintainers '(("Marcwebbie" . "marcwebbie@gmail.com")))
