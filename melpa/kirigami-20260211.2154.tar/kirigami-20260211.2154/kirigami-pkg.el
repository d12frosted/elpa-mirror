;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260211.2154"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "4e399db0b8f7e8ed5ec0e5fe8151bedeb464cc59"
  :revdesc "4e399db0b8f7"
  :keywords '("convenience"))
