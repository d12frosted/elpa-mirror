(define-package "lsp-ltex" "20210826.1034" "LSP Clients for LTEX"
  '((emacs "26.1")
    (lsp-mode "6.1")
    (f "0.20.0")
    (s "1.12.0"))
  :commit "59ecc6db3bcf80568241be2d99bb7ef60c58e502" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/emacs-languagetool/lsp-ltex")
;; Local Variables:
;; no-byte-compile: t
;; End:
