;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20260501.1737"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "82dac934650a0e167db7d1acaa52433878913e29"
  :revdesc "82dac934650a"
  :keywords '("convenience"))
