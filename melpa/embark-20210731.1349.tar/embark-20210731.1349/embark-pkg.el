(define-package "embark" "20210731.1349" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "0f71d82daef0add1b5f0572cb8791680ff5f9480" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
