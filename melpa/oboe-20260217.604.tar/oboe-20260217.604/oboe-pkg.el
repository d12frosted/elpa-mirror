;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260217.604"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "7829d308063b512531a32ac3dda9c31ef6eb68d2"
  :revdesc "7829d308063b"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
