(define-package "eldev" "20220717.1134" "Elisp development tool"
  '((emacs "24.4"))
  :commit "dbed17c339ec19da3b3f77849262e15a59ac9015" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
