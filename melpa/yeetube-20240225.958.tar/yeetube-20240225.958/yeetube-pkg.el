(define-package "yeetube" "20240225.958" "YouTube Front End | Interface for yt-dlp | mpv control |"
  '((emacs "27.2")
    (compat "29.1.4.2"))
  :commit "04c91989eefffb43a8dc1b5dd0267da50ade08f1" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://thanosapollo.org/projects/yeetube/")
;; Local Variables:
;; no-byte-compile: t
;; End:
