;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "20260118.756"
  "Lichess client."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "8f7d6f8e702256b2d8f5099928cd8558df253d36"
  :revdesc "8f7d6f8e7022"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
