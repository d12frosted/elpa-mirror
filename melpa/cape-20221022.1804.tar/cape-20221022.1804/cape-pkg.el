(define-package "cape" "20221022.1804" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "df9067ca3b9e80f53c31ff425561710a23e74721" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
