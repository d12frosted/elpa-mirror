;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20250614.44"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "37b61dcef3efffb473096d527cfba1fbdb2cec99"
  :revdesc "37b61dcef3ef"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
