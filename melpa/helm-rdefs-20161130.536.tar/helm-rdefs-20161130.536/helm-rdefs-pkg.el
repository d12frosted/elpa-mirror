;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rdefs" "20161130.536"
  "Rdefs with helm interface."
  '((emacs "24")
    (helm  "1.6.4"))
  :url "https://github.com/saidie/helm-rdefs"
  :commit "cd3a6b3af3015ee58ef30cb7c81c79ebe5fc867b"
  :revdesc "cd3a6b3af301"
  :keywords '("matching" "tools")
  :authors '(("Hiroshi Saito" . "monodie@gmail.com"))
  :maintainers '(("Hiroshi Saito" . "monodie@gmail.com")))
