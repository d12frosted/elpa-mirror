(define-package "tmsu" "20231113.2358" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "2b48d3898fef29609ac62ba8bee03acf8efb8ac7" :authors
  '(("Wojciech Siewierski"))
  :maintainers
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
