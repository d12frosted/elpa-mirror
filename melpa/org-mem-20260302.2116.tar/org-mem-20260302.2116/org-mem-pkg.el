;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260302.2116"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "8c9d5905dc018b58e392a3df3c602a999814685e"
  :revdesc "8c9d5905dc01"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
