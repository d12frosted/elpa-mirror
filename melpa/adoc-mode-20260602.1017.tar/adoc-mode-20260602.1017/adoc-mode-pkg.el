;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260602.1017"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "ba362d87d5970fa2c3287d46950063b2b686179c"
  :revdesc "ba362d87d597"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
