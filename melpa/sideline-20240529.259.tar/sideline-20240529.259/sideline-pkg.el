(define-package "sideline" "20240529.259" "Show information on the side"
  '((emacs "27.1")
    (ht "2.4"))
  :commit "4b293a781cb4294d2b9485ac8d111f30040ea677" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/emacs-sideline/sideline")
;; Local Variables:
;; no-byte-compile: t
;; End:
