;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260414.2056"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "61a8be7a766ccb9fc0231d430712568618506488"
  :revdesc "61a8be7a766c"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
