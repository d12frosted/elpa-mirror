;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-hide-drawers" "20250331.1229"
  "Hide drawers in Org using overlays."
  '((emacs "24.3"))
  :url "https://github.com/krisbalintona/org-hide-drawers.git"
  :commit "ae15d91066d9b021d06f7b9074b680adbbe48cce"
  :revdesc "ae15d91066d9"
  :keywords '("tools" "extensions")
  :authors '(("Kristoffer Balintona" . "krisbalintona@gmail.com"))
  :maintainers '(("Kristoffer Balintona" . "krisbalintona@gmail.com")))
