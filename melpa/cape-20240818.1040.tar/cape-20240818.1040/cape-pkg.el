(define-package "cape" "20240818.1040" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "30"))
  :commit "9476f6c38318bd762e749b0a33bdd4bf2073790c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "text")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
