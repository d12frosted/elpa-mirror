;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eprolog" "20260308.1428"
  "Native Prolog engine implementation."
  '((emacs "27.2"))
  :url "https://github.com/tani/eprolog"
  :commit "42842bdc9eb6468d95fc202d2aea5af0a81f6e29"
  :revdesc "42842bdc9eb6"
  :keywords '("languages" "prolog" "logic programming"))
