;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260624.1756"
  "Enhanced annotation system with threading."
  '((emacs     "27.2")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "df2cbebab2dd7c99c7b792c5d7e71c0ed4a8c42e"
  :revdesc "df2cbebab2dd"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
