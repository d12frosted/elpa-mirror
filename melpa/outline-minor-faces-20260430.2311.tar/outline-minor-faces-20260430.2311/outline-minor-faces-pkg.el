;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-minor-faces" "20260430.2311"
  "Highlight only section headings."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/outline-minor-faces"
  :commit "9bf54d02003c7866bc6d1c15495b018e3b4c678b"
  :revdesc "9bf54d02003c"
  :keywords '("faces" "outlines")
  :authors '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev")))
