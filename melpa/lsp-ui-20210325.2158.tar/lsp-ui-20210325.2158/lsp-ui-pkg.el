(define-package "lsp-ui" "20210325.2158" "UI modules for lsp-mode"
  '((emacs "26.1")
    (dash "2.18.0")
    (lsp-mode "6.0")
    (markdown-mode "2.3"))
  :commit "14de2a697e13fa151650296c9be053826378c9bd" :authors
  '(("Sebastien Chapuis <sebastien@chapu.is>, Fangrui Song" . "i@maskray.me"))
  :maintainer
  '("Sebastien Chapuis <sebastien@chapu.is>, Fangrui Song" . "i@maskray.me")
  :keywords
  '("languages" "tools")
  :url "https://github.com/emacs-lsp/lsp-ui")
;; Local Variables:
;; no-byte-compile: t
;; End:
