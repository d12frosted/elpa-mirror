;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261008.1835"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "1d7e210a383f4764734da072713dfd583101c2fd"
  :revdesc "1d7e210a383f"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
