(define-package "haskell-mode" "20210325.2112" "A Haskell editing mode"
  '((emacs "25.1"))
  :commit "657926188b099e4a449a33b24944e7bfcf8e250d" :authors
  '(("1992      Simon Marlow")
    ("1997-1998 Graeme E Moss" . "gem@cs.york.ac.uk")
    ("Tommy Thorn" . "thorn@irisa.fr")
    ("2001-2002 Reuben Thomas (>=v1.4)")
    ("2003      Dave Love" . "fx@gnu.org")
    ("2016      Arthur Fayzrakhmanov"))
  :maintainer
  '("1992      Simon Marlow")
  :keywords
  '("faces" "files" "haskell")
  :url "https://github.com/haskell/haskell-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
