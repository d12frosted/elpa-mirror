;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260201.513"
  "AI-LLM chat block for org-mode as a minor mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "9350b4fddd88541553bd1173a3f56c015bbd9f4d"
  :revdesc "9350b4fddd88"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
