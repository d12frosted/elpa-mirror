;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260720.1655"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.31.1")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "5d32a48a8d1797fec776ba56279dc99dd58f399a"
  :revdesc "5d32a48a8d17"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
