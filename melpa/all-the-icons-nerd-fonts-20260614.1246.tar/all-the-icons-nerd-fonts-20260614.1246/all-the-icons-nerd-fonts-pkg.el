;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-the-icons-nerd-fonts" "20260614.1246"
  "Nerd font integration for all-the-icons."
  '((emacs         "28.1")
    (all-the-icons "5.0")
    (nerd-icons    "0.0.1"))
  :url "https://github.com/mohkale/all-the-icons-nerd-fonts"
  :commit "4583cf5e8cce73c35e8ec3195915ce693d703bb1"
  :revdesc "4583cf5e8cce"
  :keywords '("convenience" "lisp")
  :authors '(("Mohsin Kaleem" . "mohkale@gmail.com"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@gmail.com")))
