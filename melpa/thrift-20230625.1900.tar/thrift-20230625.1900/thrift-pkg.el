(define-package "thrift" "20230625.1900" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "40100c1940b213193fd3a173cf7fb71401fef86e" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
