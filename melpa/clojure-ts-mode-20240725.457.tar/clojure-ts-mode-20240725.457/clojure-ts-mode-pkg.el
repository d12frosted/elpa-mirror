(define-package "clojure-ts-mode" "20240725.457" "Major mode for Clojure code"
  '((emacs "29.1"))
  :commit "eb9aab37163395d92ce4f950c802de31b91ee3a3" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
