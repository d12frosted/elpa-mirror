(define-package "dirvish" "20220328.522" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "3a9825c5cdafce6d214ae97cead0d660fb1c135a" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
