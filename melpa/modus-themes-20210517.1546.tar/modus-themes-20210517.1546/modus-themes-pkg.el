(define-package "modus-themes" "20210517.1546" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "47dff0bba514201b946779e5a4ccfb1c3a5fbc3e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
