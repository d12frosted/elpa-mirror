(define-package "mybigword" "20221216.124" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "26.1")
    (avy "0.5.0"))
  :commit "a6bfc8bf5cb264e8edd8cd6f913f6ccb036ca742" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
