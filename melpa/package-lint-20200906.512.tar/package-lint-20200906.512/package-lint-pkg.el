(define-package "package-lint" "20200906.512" "A linting library for elisp package authors"
  '((cl-lib "0.5")
    (emacs "24.1")
    (let-alist "1.0.6"))
  :commit "bed4e7f58f7984b720140bd4fee81a3e163f55c0" :authors
  '(("Steve Purcell" . "steve@sanityinc.com")
    ("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("lisp")
  :url "https://github.com/purcell/package-lint")
;; Local Variables:
;; no-byte-compile: t
;; End:
