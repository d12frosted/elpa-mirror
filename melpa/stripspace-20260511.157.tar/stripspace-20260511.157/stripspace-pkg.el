;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260511.157"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "e2ee32a5eca29218b621a77f580c83111eb5d160"
  :revdesc "e2ee32a5eca2"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
