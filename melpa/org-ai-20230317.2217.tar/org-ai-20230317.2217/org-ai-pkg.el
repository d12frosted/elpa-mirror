(define-package "org-ai" "20230317.2217" "Emacs org-mode integration for the OpenAI API"
  '((emacs "28.2"))
  :commit "8748ac5687b22b7e637505871125554ec727189e" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
