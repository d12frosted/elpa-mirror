(define-package "geiser-kawa" "20200501.520" "Kawa scheme support for Geiser"
  '((emacs "26.1")
    (geiser "0.11.2"))
  :commit "f76b53dbc1465dbd799e29bdcd2be34cc1603f50" :authors
  '(("spellcard199" . "spellcard199@protonmail.com"))
  :maintainer
  '("spellcard199" . "spellcard199@protonmail.com")
  :keywords
  '("languages" "kawa" "scheme" "geiser")
  :url "https://gitlab.com/spellcard199/geiser-kawa")
;; Local Variables:
;; no-byte-compile: t
;; End:
