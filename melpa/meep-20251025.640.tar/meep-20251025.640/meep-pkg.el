;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251025.640"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "e83e75f40e8c286e5d9703020aa7970429859888"
  :revdesc "e83e75f40e8c"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
