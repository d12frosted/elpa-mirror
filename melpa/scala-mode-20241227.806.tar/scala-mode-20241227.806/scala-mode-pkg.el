;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scala-mode" "20241227.806"
  "Major mode for editing Scala."
  '((emacs "25.1"))
  :url "https://github.com/hvesalai/emacs-scala-mode"
  :commit "f9a380a0d095b7383cc28f6636d81c9a27f00f6b"
  :revdesc "f9a380a0d095"
  :keywords '("languages"))
