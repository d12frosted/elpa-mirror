;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260329.2110"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "13e07942328acccb6c954c6de49a9733792adfe9"
  :revdesc "13e07942328a"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
