(define-package "org-roam-ui" "20220121.1345" "User Interface for Org-roam"
  '((emacs "27.1")
    (org-roam "2.0.0")
    (simple-httpd "20191103.1446")
    (websocket "1.13"))
  :commit "f1e1769d97e4f44d7336839db587b0acbb918d99" :authors
  '(("Kirill Rogovoy, Thomas Jorna"))
  :maintainer
  '("Kirill Rogovoy, Thomas Jorna")
  :keywords
  '("files" "outlines")
  :url "https://github.com/org-roam/org-roam-ui")
;; Local Variables:
;; no-byte-compile: t
;; End:
