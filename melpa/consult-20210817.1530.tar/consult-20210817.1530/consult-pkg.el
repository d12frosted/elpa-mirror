(define-package "consult" "20210817.1530" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "e0065ae06478adb8f63d9aa7fba425c15ca50c5e" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
