(define-package "dwim-coder-mode" "20230816.1431" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "55fbec69ff120b44d7126b160a5c7fc1d180b8a6" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
