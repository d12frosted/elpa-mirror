(define-package "spdx" "20230915.59" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "01aa58cf83d97329f456d29e57ed324cf1b2dca6" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
