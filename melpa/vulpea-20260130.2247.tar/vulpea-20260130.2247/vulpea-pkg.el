;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260130.2247"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "67aa3d206b5f3be60e5eb4d2eb3f00c727c959c9"
  :revdesc "67aa3d206b5f"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
