(define-package "notmuch-bookmarks" "20200322.1925" "Add bookmark handling for notmuch buffers"
  '((seq "2.20")
    (emacs "26.1")
    (notmuch "0.29.3"))
  :commit "37a0a46bc68f4b2fe0d456c24f22a703171eb0f8" :authors
  '(("Jörg Volbers" . "joerg@joergvolbers.de"))
  :maintainers
  '(("Jörg Volbers" . "joerg@joergvolbers.de"))
  :maintainer
  '("Jörg Volbers" . "joerg@joergvolbers.de")
  :keywords
  '("mail")
  :url "https://github.com/publicimageltd/notmuch-bookmarks")
;; Local Variables:
;; no-byte-compile: t
;; End:
