(define-package "consult" "20210117.47" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "42e90f3d4aee69fe7df2fa7f1dafcae957f58515" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
