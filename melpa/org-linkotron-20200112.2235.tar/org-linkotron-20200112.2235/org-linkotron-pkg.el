;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-linkotron" "20200112.2235"
  "Org-mode link selector."
  '((emacs "26.1")
    (org   "9.3"))
  :url "https://gitlab.com/perweij/org-linkotron"
  :commit "d0adc5247b205bc73d2f1a83d4a512d2be541eb5"
  :revdesc "d0adc5247b20"
  :keywords '("hypermedia" "org")
  :authors '(("Per Weijnitz" . "per.weijnitz@gmail.com"))
  :maintainers '(("Per Weijnitz" . "per.weijnitz@gmail.com")))
