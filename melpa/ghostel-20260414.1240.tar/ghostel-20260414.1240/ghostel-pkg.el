;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260414.1240"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b5d7b4d4c944f3a254e64cc79d43d9a28eb67a49"
  :revdesc "b5d7b4d4c944"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
