;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260302.2337"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "6bf9303dc39a0dd25cce1b0fa52b79e373732604"
  :revdesc "6bf9303dc39a"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
