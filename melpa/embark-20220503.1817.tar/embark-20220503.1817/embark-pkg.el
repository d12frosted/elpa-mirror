(define-package "embark" "20220503.1817" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "e9f0ea81a492f2e12971ad0e2f6c9771fc1f0ec9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
