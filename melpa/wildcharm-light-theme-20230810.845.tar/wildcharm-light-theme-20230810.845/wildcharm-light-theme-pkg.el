(define-package "wildcharm-light-theme" "20230810.845" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "12ee3accfaf77af9e8468e88134f54890a4a7a5b" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
