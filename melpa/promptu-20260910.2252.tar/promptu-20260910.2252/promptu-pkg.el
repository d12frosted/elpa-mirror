;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "20260910.2252"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "2a69977071fa7345e186eb0a187abb8b0a38224f"
  :revdesc "2a69977071fa"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
