;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20251125.100"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "e4bf39cbdff513d7c8bf568ec0bce58ea3a8eadf"
  :revdesc "e4bf39cbdff5"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
