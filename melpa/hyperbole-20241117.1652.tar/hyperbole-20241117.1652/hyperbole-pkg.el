;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241117.1652"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "d9f7c7fb7a34a153d636f809d91f5f94ea2dc4e7"
  :revdesc "d9f7c7fb7a34"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
