(define-package "consult" "20210328.1037" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "cf5a1845781ca57cb8b9e4af126d68d947f05127" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
