;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260129.2125"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "02b64c284cdb2813a8418f74680c9404dda057bb"
  :revdesc "02b64c284cdb")
