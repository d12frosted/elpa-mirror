(define-package "el-patch" "20230226.2230" "Future-proof your Elisp"
  '((emacs "26"))
  :commit "c4a1b435181596fe71e18b2422e07e693b75203c" :authors
  '(("Radian LLC" . "contact+el-patch@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+el-patch@radian.codes")
  :keywords
  '("extensions")
  :url "https://github.com/radian-software/el-patch")
;; Local Variables:
;; no-byte-compile: t
;; End:
