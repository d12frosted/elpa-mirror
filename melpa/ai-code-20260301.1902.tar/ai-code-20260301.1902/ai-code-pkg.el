;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260301.1902"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e76f10c87ad4b6a765ea00a3337f885a6a8190ee"
  :revdesc "e76f10c87ad4"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
