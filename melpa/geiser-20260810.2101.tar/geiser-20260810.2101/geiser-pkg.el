;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser" "20260810.2101"
  "GNU Emacs and Scheme talk to each other."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://gitlab.com/emacs-geiser/"
  :commit "efcf1939fd839e9ea22d68ff0ebbd8ca2e1b71e1"
  :revdesc "efcf1939fd83"
  :keywords '("languages" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
