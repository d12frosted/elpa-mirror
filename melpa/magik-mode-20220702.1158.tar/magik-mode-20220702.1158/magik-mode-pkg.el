(define-package "magik-mode" "20220702.1158" "mode for editing Magik + some utils." 'nil :commit "a7c5553d2780640630d31b469d522ecffdf052f5" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
