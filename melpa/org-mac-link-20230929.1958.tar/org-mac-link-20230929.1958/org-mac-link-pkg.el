(define-package "org-mac-link" "20230929.1958" "Insert org-mode links to items selected in various Mac apps"
  '((emacs "27.1"))
  :commit "04cace34542aaca5d729c68fb8a2d45717acf06f" :authors
  '(("Anthony Lander" . "anthony.lander@gmail.com")
    ("John Wiegley" . "johnw@gnu.org")
    ("Christopher Suckling <suckling at gmail dot com>")
    ("Daniil Frumin" . "difrumin@gmail.com")
    ("Alan Schmitt" . "alan.schmitt@polytechnique.org")
    ("Mike McLean" . "mike.mclean@pobox.com"))
  :maintainers
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainer
  '("Aimé Bertrand" . "aime.bertrand@macowners.club")
  :keywords
  '("files" "wp" "url" "org")
  :url "https://gitlab.com/aimebertrand/org-mac-link")
;; Local Variables:
;; no-byte-compile: t
;; End:
