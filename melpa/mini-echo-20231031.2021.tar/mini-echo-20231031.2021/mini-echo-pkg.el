(define-package "mini-echo" "20231031.2021" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "343729b6f84f9fd26759246e912286c28927fcc4" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
