;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251111.2300"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "f1cd66a5a9e844058e9f838827524af68cf9dd91"
  :revdesc "f1cd66a5a9e8"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
