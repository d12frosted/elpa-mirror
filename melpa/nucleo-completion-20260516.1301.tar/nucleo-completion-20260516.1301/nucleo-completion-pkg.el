;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20260516.1301"
  "Nucleo-backed completion style."
  '((emacs "27.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "4273c0d000c4fc0d121828fbba6f812a299ad79e"
  :revdesc "4273c0d000c4"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
