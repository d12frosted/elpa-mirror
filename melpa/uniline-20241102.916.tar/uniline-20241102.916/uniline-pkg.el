;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20241102.916"
  "Draw UNICODE lines, boxes, arrows onto existing text."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "077430a970525b55037e7ea03cd5679064cdaa26"
  :revdesc "077430a97052"
  :keywords '("convenience" "text"))
