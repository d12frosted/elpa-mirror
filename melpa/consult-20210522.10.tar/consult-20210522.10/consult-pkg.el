(define-package "consult" "20210522.10" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "3383bf824f59f3703f7f4182fbb95962bad1a232" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
