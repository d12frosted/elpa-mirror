(define-package "modus-themes" "20210321.846" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "255291873308f02c4eeaa13c5bdbba2e37ebcba6" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
