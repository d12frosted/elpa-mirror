;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261016.649"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "bed2cd4336cbfc9207370df6c678e4aa3ee7d7e7"
  :revdesc "bed2cd4336cb"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
