;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "20261014.1125"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.39.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "e66b37ab804f9332a7ed8711552cac8d6ef05c4c"
  :revdesc "e66b37ab804f"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
