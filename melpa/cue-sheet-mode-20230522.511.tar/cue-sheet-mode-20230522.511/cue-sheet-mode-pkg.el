;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cue-sheet-mode" "20230522.511"
  "Major mode for editing CUE sheet files."
  '((emacs "27.1"))
  :url "https://github.com/peterhoeg/cue-sheet-mode"
  :commit "016dfa8aeed264e15e2f55b0b34fcfdb7e14b9d9"
  :revdesc "016dfa8aeed2"
  :keywords '("languages")
  :authors '(("Peter Hoeg" . "(peter@hoeg.com)"))
  :maintainers '(("Peter Hoeg" . "(peter@hoeg.com)")))
