;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sema-mode" "20261005.1028"
  "Major mode for editing Sema files."
  '((emacs "25.1"))
  :url "https://github.com/sema-lisp/emacs-sema"
  :commit "6ecdc887be79960671b1014f9d6eed2caab35b88"
  :revdesc "6ecdc887be79"
  :keywords '("languages" "lisp")
  :authors '(("Helge Sverre" . "helge.sverre@gmail.com"))
  :maintainers '(("Helge Sverre" . "helge.sverre@gmail.com")))
