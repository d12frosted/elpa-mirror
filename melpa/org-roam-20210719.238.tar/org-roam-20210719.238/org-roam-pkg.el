(define-package "org-roam" "20210719.238" "Roam Research replica with Org-mode"
  '((emacs "26.1")
    (dash "2.13")
    (f "0.17.2")
    (org "9.4")
    (emacsql "3.0.0")
    (emacsql-sqlite "1.0.0")
    (magit-section "2.90.1"))
  :commit "f50e30dd5126408ce01db051b4fd8d2fdf3b245a" :authors
  '(("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  '("Jethro Kuan" . "jethrokuan95@gmail.com")
  :keywords
  '("org-mode" "roam" "convenience")
  :url "https://github.com/org-roam/org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
