;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edwina" "20221206.1610"
  "Dynamic window manager."
  '((emacs "25"))
  :url "https://gitlab.com/ajgrf/edwina"
  :commit "f95c31b1de95df7e83338a5d4daf3363df325862"
  :revdesc "f95c31b1de95"
  :keywords '("convenience")
  :authors '(("Alex Griffin" . "a@ajgrf.com"))
  :maintainers '(("Alex Griffin" . "a@ajgrf.com")))
