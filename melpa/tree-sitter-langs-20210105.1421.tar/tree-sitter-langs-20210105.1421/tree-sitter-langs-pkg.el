(define-package "tree-sitter-langs" "20210105.1421" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.12.2"))
  :commit "076865a6c879840ab61e0aa7b336a2e3e1f97cd4" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
