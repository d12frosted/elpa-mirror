;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20251125.1059"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "6363a46aaa2f5c4fef359cb90ce221aae9dce15b"
  :revdesc "6363a46aaa2f"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
