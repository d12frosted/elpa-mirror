(define-package "git-attr" "20180925.2003" "Git attributes of buffer file"
  '((emacs "24.3"))
  :commit "50df0630eba2a931146f676d349b29bde6b6b37b" :keywords
  ("vc")
  :authors
  (("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainer
  ("Arne Jørgensen" . "arne@arnested.dk")
  :url "https://github.com/arnested/emacs-git-attr")
;; Local Variables:
;; no-byte-compile: t
;; End:
