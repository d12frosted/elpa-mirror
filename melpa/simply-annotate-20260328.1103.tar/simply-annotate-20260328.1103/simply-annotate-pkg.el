;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260328.1103"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "c15198a11864d82f061a129479ad15e2cad74e87"
  :revdesc "c15198a11864"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
