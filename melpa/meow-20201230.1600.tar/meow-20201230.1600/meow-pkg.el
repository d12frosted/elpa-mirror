(define-package "meow" "20201230.1600" "Modal Editing On Wheel"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1"))
  :commit "ea923ac739fcc72a2f23606cfb9a091ad8ddde22" :authors
  (("Shi Tianshu"))
  :maintainer
  ("Shi Tianshu")
  :keywords
  ("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
