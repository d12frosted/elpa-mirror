(define-package "soothe-theme" "20220826.1301" "A dark colorful theme"
  '((emacs "24.3")
    (autothemer "0.2"))
  :commit "ba20a7b2f32dd8f7b53db5c72bde82650be35baf" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/emacs-soothe-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
