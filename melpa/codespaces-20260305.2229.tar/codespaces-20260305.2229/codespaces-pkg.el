;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260305.2229"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "33161d6ac6fd3b57df896f8969566f50f37bd3ce"
  :revdesc "33161d6ac6fd"
  :keywords '("comm")
  :authors '(("Fabian Markl" . "fabian@markl.dev"))
  :maintainers '(("Fabian Markl" . "fabian@markl.dev")))
