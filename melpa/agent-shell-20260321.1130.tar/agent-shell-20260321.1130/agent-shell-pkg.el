;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260321.1130"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0b2475403da8d91618bbfa693faccf2f910fae9f"
  :revdesc "0b2475403da8")
