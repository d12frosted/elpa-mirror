;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260129.2241"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "858b630b49a97030d5f828d1e7fddece4055a7a7"
  :revdesc "858b630b49a9"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
