;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260508.1601"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "805fbfe4583bcb3b1642e493923d2ba1b2f02d4f"
  :revdesc "805fbfe4583b"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
