;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-refactor" "20260712.1037"
  "A collection of commands for refactoring Clojure code."
  '((emacs        "28.1")
    (yasnippet    "0.6.1")
    (paredit      "24")
    (clojure-mode "5.18.0")
    (cider        "1.11.1")
    (parseedn     "1.2.0")
    (transient    "0.4.1")
    (spinner      "1.7"))
  :url "https://github.com/clojure-emacs/clj-refactor.el"
  :commit "9bdd019975fd2033d2c83e7129ddfeb9958c3739"
  :revdesc "9bdd019975fd"
  :keywords '("convenience" "clojure" "cider")
  :authors '(("Magnar Sveen" . "magnars@gmail.com")
             ("Lars Andersen" . "expez@expez.com")
             ("Benedek Fazekas" . "benedek.fazekas@gmail.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")
                 ("Lars Andersen" . "expez@expez.com")
                 ("Benedek Fazekas" . "benedek.fazekas@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
