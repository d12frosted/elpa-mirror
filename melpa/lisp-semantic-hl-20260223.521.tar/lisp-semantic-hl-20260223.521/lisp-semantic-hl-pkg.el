;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-semantic-hl" "20260223.521"
  "Semantic Syntax Highlighting for Lisp Languages."
  '((emacs "27.1"))
  :url "https://github.com/calsys456/lisp-semantic-hl.el"
  :commit "0474bfab3ae6b0d76425e117e6ae4fe9b0f04b54"
  :revdesc "0474bfab3ae6"
  :keywords '("languages" "lisp" "maint")
  :authors '(("The Calendrical System" . "us@calsys.org"))
  :maintainers '(("The Calendrical System" . "us@calsys.org")))
