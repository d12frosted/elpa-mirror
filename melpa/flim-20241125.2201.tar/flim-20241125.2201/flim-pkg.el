;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flim" "20241125.2201"
  "Basic message representation and encoding features."
  '((emacs  "24.5")
    (apel   "0")
    (oauth2 "0.17"))
  :url "https://github.com/emacsmirror/flim"
  :commit "4ffe9e88a80528be4d653563fe2ed0693a2738d1"
  :revdesc "4ffe9e88a805"
  :keywords '("mime" "multimedia" "mail" "news"))
