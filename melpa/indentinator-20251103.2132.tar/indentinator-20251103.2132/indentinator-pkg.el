;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indentinator" "20251103.2132"
  "Automatically indent code."
  '((emacs "25.1"))
  :url "https://github.com/xendk/indentinator.el"
  :commit "79ddeb38d9679616b7a843a88b22866f3b3cd9f6"
  :revdesc "79ddeb38d967"
  :keywords '("convenience")
  :authors '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers '(("Thomas Fini Hansen" . "xen@xen.dk")))
