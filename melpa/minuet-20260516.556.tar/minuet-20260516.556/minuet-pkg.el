;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260516.556"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "0b667ec4b4a3c9591ed10ba804130391194e8647"
  :revdesc "0b667ec4b4a3"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
