;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250419.448"
  "A modern file manager based on dired mode."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "f85a88216dfc6e952854595281b56c5b7b716557"
  :revdesc "f85a88216dfc"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
