(define-package "pg" "20240314.1049" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "28.1"))
  :commit "a577a8ee2739fa57fd8d98acc9eb2067b6cf043e" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
