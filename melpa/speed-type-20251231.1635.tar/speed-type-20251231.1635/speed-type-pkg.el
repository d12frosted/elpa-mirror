;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251231.1635"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "2f6276a35414881249688b3006b2ab8ee25b7cc3"
  :revdesc "2f6276a35414"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
