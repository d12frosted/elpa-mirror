;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251209.2150"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "cc4f32a97b97df7271248374a738582d4e286f8e"
  :revdesc "cc4f32a97b97"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
