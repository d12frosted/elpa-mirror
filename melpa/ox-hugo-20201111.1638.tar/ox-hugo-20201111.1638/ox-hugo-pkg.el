(define-package "ox-hugo" "20201111.1638" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "661eb223fd50b0f3bd683aba92d7fd661b78c2cf" :keywords
  ("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
