(define-package "julia-mode" "20211023.1434" "Major mode for editing Julia source code"
  '((emacs "24.3"))
  :commit "b1a7119843cb81677d15cba9df64d02b30ea08a8" :keywords
  '("languages")
  :url "https://github.com/JuliaEditorSupport/julia-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
