(define-package "dashboard" "20211221.1622" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "91da34c507f61e39e5a93dc12832bf639bf30b70" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
