;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-embark" "20250711.2032"
  "Embark Actions for consult-gh."
  '((emacs          "29.4")
    (consult        "2.0")
    (consult-gh     "2.5")
    (embark-consult "1.1"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "8d850877c0b6b9352f4a50b991942e6de8262fcd"
  :revdesc "8d850877c0b6"
  :keywords '("matching" "git" "repositories" "forges" "completion"))
