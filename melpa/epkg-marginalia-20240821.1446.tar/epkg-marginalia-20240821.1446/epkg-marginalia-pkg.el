(define-package "epkg-marginalia" "20240821.1446" "Show Epkg information in completion annotations"
  '((emacs "27.1")
    (compat "30.0.0.0")
    (epkg "4.0.0")
    (marginalia "1.7"))
  :commit "9fa13bff60433f1c67edba8c0d742f7f85b5c152" :authors
  '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg-marginalia")
;; Local Variables:
;; no-byte-compile: t
;; End:
