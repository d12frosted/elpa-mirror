(define-package "gptel" "20231215.422" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "d5949ef428be5feac2168223d091d1842085988c" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
