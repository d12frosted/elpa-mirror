;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cricbuzz" "20180804.2254"
  "Cricket scores from cricbuzz in emacs."
  '((enlive "0.0.1")
    (f      "0.19.0")
    (dash   "2.13.0")
    (s      "1.11.0"))
  :url "https://github.com/lepisma/cricbuzz.el"
  :commit "0b95d45991bbcd2fa58d96ce921f6a57ba42c153"
  :revdesc "0b95d45991bb"
  :keywords '("cricket" "score")
  :authors '(("Abhinav Tushar" . "abhinav.tushar.vs@gmail.com"))
  :maintainers '(("Abhinav Tushar" . "abhinav.tushar.vs@gmail.com")))
