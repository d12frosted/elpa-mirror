;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xhair" "20210801.222"
  "Highlight the current line and column."
  '((emacs "24.3")
    (vline "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-xhair"
  :commit "c7bd7c501c3545aa99dadac386c882fe7c5edd9c"
  :revdesc "c7bd7c501c35"
  :keywords '("convenience" "faces" "maint"))
