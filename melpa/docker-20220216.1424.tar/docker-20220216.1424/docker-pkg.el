(define-package "docker" "20220216.1424" "Emacs interface to Docker"
  '((aio "1.0")
    (dash "2.19.1")
    (docker-tramp "0.1")
    (emacs "26.1")
    (json-mode "1.8.0")
    (s "1.12.0")
    (tablist "1.0")
    (transient "0.3.7"))
  :commit "81f2b379af504428bf2c93a77c7aeb8e56a0f219" :authors
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainer
  '("Philippe Vaucher" . "philippe.vaucher@gmail.com")
  :keywords
  '("filename" "convenience")
  :url "https://github.com/Silex/docker.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
