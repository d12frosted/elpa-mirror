(define-package "lem" "20231220.1453" "A basic lemmy client"
  '((emacs "29.1")
    (fedi "0.1")
    (markdown-mode "2.5"))
  :commit "990c369853a77cfac42eea372c92d6d6152c372e" :authors
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainers
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainer
  '("martian hiatus <martianhiatus [a t] riseup [d o t] net>")
  :keywords
  '("multimedia" "comm" "web" "fediverse")
  :url "https://codeberg.org/martianh/lem.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
