(define-package "for" "20220929.1246" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "22de9e71e0b7f831da4e4a756c75abcc73a02fad" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
