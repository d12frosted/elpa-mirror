;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251009.508"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "50eea5dea4fdfb9fff46d71e3c3bcc6dbf09f26a"
  :revdesc "50eea5dea4fd"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
