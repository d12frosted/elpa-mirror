(define-package "eldev" "20220814.2011" "Elisp development tool"
  '((emacs "24.4"))
  :commit "f964c59bd28aeb42e60f72d4284dd07b50fbdcfd" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
