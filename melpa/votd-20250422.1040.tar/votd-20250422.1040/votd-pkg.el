;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "votd" "20250422.1040"
  "Bible Verse Of The Day."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/votd"
  :commit "6e91321a1aa4a541f5c7f64ead52bb45915d7893"
  :revdesc "6e91321a1aa4"
  :keywords '("convenience" "comm" "hypermedia"))
