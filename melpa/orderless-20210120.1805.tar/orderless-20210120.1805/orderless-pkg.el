(define-package "orderless" "20210120.1805" "Completion style for matching regexps in any order"
  '((emacs "24.4"))
  :commit "94d52640d4d8eed1a412907a4e4b6d4dea990b7f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("extensions")
  :url "https://github.com/oantolin/orderless")
;; Local Variables:
;; no-byte-compile: t
;; End:
