;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260114.1321"
  "Highlight by brightness of text and background."
  '((emacs "29.4"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "c64c770f9663c6d2651ade64766f15d439b542cc"
  :revdesc "c64c770f9663"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
