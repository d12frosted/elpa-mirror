;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260123.1716"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "963ea7db7491215185dfa2f10fc2bb1b145ae599"
  :revdesc "963ea7db7491"
  :keywords '("languages"))
