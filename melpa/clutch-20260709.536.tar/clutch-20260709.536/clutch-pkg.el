;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260709.536"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "65ad9e61217b06d9fac558b6cb85ae5bacdf8171"
  :revdesc "65ad9e61217b"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
