;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "20260108.1512"
  "Display diffs using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "98f1837840e9afedbff48969b2bd8468af7ceef3"
  :revdesc "98f1837840e9"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
