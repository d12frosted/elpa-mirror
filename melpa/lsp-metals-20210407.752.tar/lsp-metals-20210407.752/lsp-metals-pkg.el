(define-package "lsp-metals" "20210407.752" "Scala Client settings"
  '((emacs "26.1")
    (lsp-mode "7.0")
    (lsp-treemacs "0.2")
    (dap-mode "0.3")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.0")
    (treemacs "2.5"))
  :commit "5526fbd74e6fa436479e6e199e190e5e3088b503" :authors
  '(("Ross A. Baker" . "ross@rossabaker.com")
    ("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Ross A. Baker" . "ross@rossabaker.com")
  :keywords
  '("languages" "extensions")
  :url "https://github.com/emacs-lsp/lsp-metals")
;; Local Variables:
;; no-byte-compile: t
;; End:
