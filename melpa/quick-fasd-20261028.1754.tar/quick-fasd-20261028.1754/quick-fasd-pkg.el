;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20261028.1754"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "8bf3eca03f112127aaec15e0047d8b8196f50fd1"
  :revdesc "8bf3eca03f11"
  :keywords '("convenience" "files" "tools"))
