(define-package "modus-themes" "20220630.659" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "712a9f446b41b2c861e55946c37f4ecf1b927f76" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
