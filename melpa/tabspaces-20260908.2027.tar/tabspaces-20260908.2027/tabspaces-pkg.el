;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260908.2027"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "2bfb7361b8d82f660eca8bd2e131b5ca53d56916"
  :revdesc "2bfb7361b8d8"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
