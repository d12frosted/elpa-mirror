;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260704.18"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "565e1b6eb6a70e8a33814c45896db059003741a2"
  :revdesc "565e1b6eb6a7"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
