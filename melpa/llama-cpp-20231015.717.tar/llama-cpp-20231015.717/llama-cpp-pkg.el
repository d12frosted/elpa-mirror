(define-package "llama-cpp" "20231015.717" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "3e406c53cb82ec1be056dcef40ac37d474852524" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
