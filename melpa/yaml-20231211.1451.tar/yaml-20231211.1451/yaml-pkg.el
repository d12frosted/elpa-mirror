(define-package "yaml" "20231211.1451" "YAML parser for Elisp"
  '((emacs "25.1"))
  :commit "37a6b80ee306ea4ae3530343a5bf254bf26bacb6" :authors
  '(("Zachary Romero" . "zkry@posteo.org"))
  :maintainers
  '(("Zachary Romero" . "zkry@posteo.org"))
  :maintainer
  '("Zachary Romero" . "zkry@posteo.org")
  :keywords
  '("tools")
  :url "https://github.com/zkry/yaml.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
