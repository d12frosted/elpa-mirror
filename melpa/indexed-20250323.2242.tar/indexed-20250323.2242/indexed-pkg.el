;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250323.2242"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (el-job "2.2.0")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "ef82b9c5363fe616b6411218aa6c02451387f84b"
  :revdesc "ef82b9c5363f"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
