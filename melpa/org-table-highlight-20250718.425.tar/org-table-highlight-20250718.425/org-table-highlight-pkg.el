;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-table-highlight" "20250718.425"
  "Highlight Org table columns and rows."
  '((emacs "27.1"))
  :url "https://github.com/llcc/org-table-highlight"
  :commit "aea88c864a9c7d4280a8333383875c1d554ea7ca"
  :revdesc "aea88c864a9c"
  :keywords '("org-table" "convenience"))
