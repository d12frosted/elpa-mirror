(define-package "cape" "20230112.1447" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "8841d1d21c64061d34fe35c46c05b661421cdab1" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
