(define-package "speechd-el" "20210607.2032" "Client to speech synthesizers and Braille displays." 'nil :commit "2ffae385139936a03e1d1a96993d3bf5f9509bbf")
;; Local Variables:
;; no-byte-compile: t
;; End:
