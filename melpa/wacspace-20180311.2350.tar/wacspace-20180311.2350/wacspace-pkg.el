(define-package "wacspace" "20180311.2350" "The WACky WorkSPACE manager for emACS"
  '((dash "1.2.0")
    (cl-lib "0.2"))
  :commit "54d19aab6fd2bc5945b7ffc58104e695064927e2" :authors
  '(("Emanuel Evans" . "emanuel.evans@gmail.com"))
  :maintainer
  '("Emanuel Evans" . "emanuel.evans@gmail.com")
  :keywords
  '("workspace")
  :url "http://github.com/shosti/wacspace.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
