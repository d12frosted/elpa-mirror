(define-package "haki-theme" "20231222.608" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "5c7ac858a7ab5ebcdd09fdedbd07fa9fddbb547c" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
