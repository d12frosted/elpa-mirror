(define-package "geiser-guile" "20220113.235" "Guile's implementation of the geiser protocols"
  '((emacs "25.1")
    (geiser "0.21"))
  :commit "60e1b0e40cdf87586f9be2bef195cd24d36a2a77" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
