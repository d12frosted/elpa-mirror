;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-phpstan" "20250521.1459"
  "Flycheck integration for PHPStan."
  '((emacs    "25.1")
    (flycheck "26")
    (phpstan  "0.8.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "af600b9aff5f89aab5a0f5744c5734392414e013"
  :revdesc "af600b9aff5f"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
