;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20250930.1720"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "e7281fef04b157fd599c63d23dfbab63c6e11bf6"
  :revdesc "e7281fef04b1"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
