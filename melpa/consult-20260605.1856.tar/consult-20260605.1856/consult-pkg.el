;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260605.1856"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "ee0295b77e2d15f970622b33e2faeef17439c594"
  :revdesc "ee0295b77e2d"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
