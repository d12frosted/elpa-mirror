;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260310.1314"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "0279e0a9026566b31d8bea71d1f46b12cb1ffc2b"
  :revdesc "0279e0a90265"
  :keywords '("convenience" "comm" "hypermedia"))
