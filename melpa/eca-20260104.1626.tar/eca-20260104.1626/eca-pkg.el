;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260104.1626"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "c6c56a4cd55ad1792f19fa09bd39bc48c81b23c9"
  :revdesc "c6c56a4cd55a"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
