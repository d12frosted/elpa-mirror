(define-package "eldev" "20220219.2111" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "4bb088f2bc93ee72cb2d94d687512ad26193a594" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
