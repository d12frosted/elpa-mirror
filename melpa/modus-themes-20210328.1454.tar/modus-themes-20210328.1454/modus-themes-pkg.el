(define-package "modus-themes" "20210328.1454" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "7222ed36f193d134c7229dec59858753438c9ce2" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
