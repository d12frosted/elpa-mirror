;; base16-everforest-dark-soft-theme.el -- A base16 colorscheme

;;; Commentary:
;; Base16: (https://github.com/tinted-theming/home)

;;; Authors:
;; Scheme: Sainnhe Park (https://github.com/sainnhe)
;; Template: Kaleb Elwert <belak@coded.io>

;;; Code:

(require 'base16-theme)

(defvar base16-everforest-dark-soft-theme-colors
  '(:base00 "#333c43"
    :base01 "#3a464c"
    :base02 "#4d5960"
    :base03 "#859289"
    :base04 "#9da9a0"
    :base05 "#d3c6aa"
    :base06 "#ddd8be"
    :base07 "#f3ead3"
    :base08 "#e67e80"
    :base09 "#e69875"
    :base0A "#dbbc7f"
    :base0B "#a7c080"
    :base0C "#83c092"
    :base0D "#7fbbb3"
    :base0E "#d699b6"
    :base0F "#9da9a0")
  "All colors for Base16 Everforest Dark Soft are defined here.")

;; Define the theme
(deftheme base16-everforest-dark-soft)

;; Add all the faces to the theme
(base16-theme-define 'base16-everforest-dark-soft base16-everforest-dark-soft-theme-colors)

;; Mark the theme as provided
(provide-theme 'base16-everforest-dark-soft)

(provide 'base16-everforest-dark-soft-theme)

;;; base16-everforest-dark-soft-theme.el ends here
