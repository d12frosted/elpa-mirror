(define-package "chronometrist" "20210601.1307" "A time tracker with a nice interface"
  '((emacs "25.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "3c8be625ceefb5749921bc35de198ced22d1ae45" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
