;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "20241207.2108"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "98349e8591080cfd26882e784100bd3b12708d28"
  :revdesc "98349e859108"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
