;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261102.235"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "3d360a503c01f1f8c287495caef942ec5c5e7eae"
  :revdesc "3d360a503c01"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
