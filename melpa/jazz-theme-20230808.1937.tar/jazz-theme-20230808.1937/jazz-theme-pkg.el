(define-package "jazz-theme" "20230808.1937" "A warm color theme for Emacs 24+." 'nil :commit "0884e49c6a8fb7908398dfcaa259f8782cabbadf" :authors
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainers
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainer
  '("Roman Parykin" . "donderom@ymail.com")
  :url "https://github.com/donderom/jazz-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
