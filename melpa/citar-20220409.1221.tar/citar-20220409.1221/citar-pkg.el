(define-package "citar" "20220409.1221" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (s "1.12")
    (parsebib "3.0")
    (org "9.5")
    (citeproc "0.9"))
  :commit "f5291bddd999bb0ff9d05aa9f451f05712a03f06" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
