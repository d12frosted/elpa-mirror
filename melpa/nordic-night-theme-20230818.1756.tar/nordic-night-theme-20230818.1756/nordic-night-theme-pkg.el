(define-package "nordic-night-theme" "20230818.1756" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "4eece516fa1ce727fbcad70c6653c24b2091e7c4" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
