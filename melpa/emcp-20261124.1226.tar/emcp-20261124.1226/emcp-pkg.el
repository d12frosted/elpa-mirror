;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20261124.1226"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "b8d4c933d085bbc0ddabb77693f43cd2666d4c9d"
  :revdesc "b8d4c933d085"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
