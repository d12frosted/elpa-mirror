(define-package "helm-descbinds" "20240211.1303" "A convenient `describe-bindings' with `helm'"
  '((helm "1.5"))
  :commit "fe532566bcb29e4185f9a8cfb8d18c1e87d843b7" :authors
  '(("Taiki SUGAWARA" . "buzz.taiki@gmail.com"))
  :maintainers
  '(("Taiki SUGAWARA" . "buzz.taiki@gmail.com"))
  :maintainer
  '("Taiki SUGAWARA" . "buzz.taiki@gmail.com")
  :keywords
  '("helm" "help")
  :url "https://github.com/emacs-helm/helm-descbinds")
;; Local Variables:
;; no-byte-compile: t
;; End:
