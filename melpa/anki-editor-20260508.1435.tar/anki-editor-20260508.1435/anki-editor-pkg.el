;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20260508.1435"
  "Minor mode for making Anki cards with Org."
  '((emacs "29.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "a6cd1244465bdd350864f20648126712e241c99c"
  :revdesc "a6cd1244465b")
