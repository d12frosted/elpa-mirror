;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260220.1737"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "abe76a657dee27ba12c3018d44ca428fa52567ef"
  :revdesc "abe76a657dee")
