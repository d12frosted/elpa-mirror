;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260219.1755"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "a8a2fa305c0f95122d7068db985b155159e4aaf8"
  :revdesc "a8a2fa305c0f"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
