;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20251125.31"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.5"))
  :url "https://github.com/joaotavora/sly"
  :commit "6a303bae74537f9955fe08e0e28d6da2b2b4ee4e"
  :revdesc "6a303bae7453"
  :keywords '("languages" "lisp" "sly"))
