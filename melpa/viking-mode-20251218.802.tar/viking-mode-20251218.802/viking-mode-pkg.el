;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "viking-mode" "20251218.802"
  "Kill first, ask later."
  ()
  :url "https://codeberg.org/scip/viking-mode"
  :commit "de712eb6e7bb3958055868d73fe3dca1d639016b"
  :revdesc "de712eb6e7bb"
  :keywords '("kill" "delete")
  :authors '(("T.v.Dein" . "tlinden@cpan.org"))
  :maintainers '(("T.v.Dein" . "tlinden@cpan.org")))
