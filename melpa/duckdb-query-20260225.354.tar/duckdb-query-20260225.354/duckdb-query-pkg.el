;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "duckdb-query" "20260225.354"
  "DuckDB query results as native Elisp data structures."
  '((emacs "28.1"))
  :url "https://github.com/gggion/duckdb-query.el"
  :commit "b81c669859e201c4dcd1303033c0ee81134aca17"
  :revdesc "b81c669859e2"
  :keywords '("data" "sql")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
