;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260715.2318"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "35ad8c18bc32b790b9b6f5ba6c0f8367f35564de"
  :revdesc "35ad8c18bc32"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
