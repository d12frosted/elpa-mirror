(define-package "selectrum" "20201128.1052" "Easily select item from list"
  '((emacs "25.1"))
  :commit "3389c080bba26434d7d48c29065199bc070d6cec" :keywords
  ("extensions")
  :authors
  (("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  ("Radon Rosborough" . "radon.neon@gmail.com")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
