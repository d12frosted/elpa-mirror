;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250618.1327"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "1ed6e2a793c4db3665a21d71141c8d88d87074e2"
  :revdesc "1ed6e2a793c4"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
