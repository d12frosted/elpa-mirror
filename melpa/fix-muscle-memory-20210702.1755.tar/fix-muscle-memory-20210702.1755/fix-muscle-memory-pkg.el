;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fix-muscle-memory" "20210702.1755"
  "Simple hacks to fix muscle memory problems."
  ()
  :url "https://github.com/jonnay/fix-muscle-memory"
  :commit "b8d4b8025d758762f4459c70c3a7a209ead865ed"
  :revdesc "b8d4b8025d75"
  :keywords '("spelling" "typing")
  :authors '(("Jonathan Arkell" . "jonnay@jonnay.net"))
  :maintainers '(("Jonathan Arkell" . "jonnay@jonnay.net")))
