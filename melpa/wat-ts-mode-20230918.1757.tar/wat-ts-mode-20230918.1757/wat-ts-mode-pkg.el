(define-package "wat-ts-mode" "20230918.1757" "Major mode for webassembly text format"
  '((emacs "29.1"))
  :commit "4173d3813043de24337509c578d6e901b3bf9614" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("wasm" "wat" "wast" "languages" "tree-sitter")
  :url "https://github.com/nverno/wat-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
