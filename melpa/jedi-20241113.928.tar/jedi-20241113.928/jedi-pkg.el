;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jedi" "20241113.928"
  "A Python auto-completion for Emacs."
  '((emacs         "24")
    (jedi-core     "0.2.2")
    (auto-complete "1.4"))
  :url "https://github.com/tkf/emacs-jedi"
  :commit "ba98e5ad8ea0b2bbcd686166183c335ccc1dbafb"
  :revdesc "ba98e5ad8ea0"
  :authors '(("Takafumi Arakaki" . "aka.tkfatgmail.com"))
  :maintainers '(("Takafumi Arakaki" . "aka.tkfatgmail.com")))
