;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "20251103.514"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "cfa2f2f3367b32429a06d2c401a2b791a896bba6"
  :revdesc "cfa2f2f3367b"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
