(define-package "racket-mode" "20231222.1554" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "2ad39c6b76e412273719194f22ee77ece3189374" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
