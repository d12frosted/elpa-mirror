(define-package "modus-themes" "20220323.801" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "505d7f279a4b8a7f9aa23283100e765b7cf472a5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
