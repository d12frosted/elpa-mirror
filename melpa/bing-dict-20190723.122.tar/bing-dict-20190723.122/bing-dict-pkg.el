(define-package "bing-dict" "20190723.122" "Minimalists' English-Chinese Bing dictionary" 'nil :commit "52718ae3a3abfa5e5457239ee7ddf8f0c23a79a7" :authors
  '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainer
  '("Junpeng Qiu" . "qjpchmail@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/cute-jumper/bing-dict.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
