;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260111.1458"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "ba81bd939d79cc6999cf02d09cbeccf4dc9381ed"
  :revdesc "ba81bd939d79"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
