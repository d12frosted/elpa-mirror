(define-package "embark" "20211022.4" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "5faa208423d91c6ba936cf20a014eee8eab87a9f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
