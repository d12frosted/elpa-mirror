;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treebundel" "20260402.18"
  "Bundle related git-worktrees together."
  '((emacs  "27.1")
    (compat "29.1.4.2"))
  :url "https://github.com/purplg/treebundel"
  :commit "d06096dca9cf92b169be5d1dc05fcaaaae08ce28"
  :revdesc "d06096dca9cf"
  :keywords '("convenience" "vc"))
