(define-package "embark" "20211209.2219" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "7c502b00a505905f8d08140f55ac789c031e23a8" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
