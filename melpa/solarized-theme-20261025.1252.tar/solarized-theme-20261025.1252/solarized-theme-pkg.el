;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "20261025.1252"
  "The Solarized color theme."
  '((emacs "24.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "e696b811fd32d280ed8a2093d1f7a25b76d2133a"
  :revdesc "e696b811fd32"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
