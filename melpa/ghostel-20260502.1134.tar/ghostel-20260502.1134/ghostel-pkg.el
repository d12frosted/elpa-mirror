;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260502.1134"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "9278c2f614087807c2760cfc770dcf05ffd71a5c"
  :revdesc "9278c2f61408"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
