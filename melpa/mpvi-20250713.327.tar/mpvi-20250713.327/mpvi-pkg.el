;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250713.327"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "d4d9c37c596fd5ac50835b9daf73724a842fd41e"
  :revdesc "d4d9c37c596f"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
