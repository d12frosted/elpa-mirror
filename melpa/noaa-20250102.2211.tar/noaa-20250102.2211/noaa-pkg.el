;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noaa" "20250102.2211"
  "Get NOAA weather data."
  '((emacs   "27.1")
    (kv      "0.0.19")
    (request "0.2.0")
    (s       "1.12.0"))
  :url "https://codeberg.org/thomp/noaa"
  :commit "d162d19dd057430840a08ede0ce333fc30ea5ab9"
  :revdesc "d162d19dd057"
  :keywords '("calendar"))
