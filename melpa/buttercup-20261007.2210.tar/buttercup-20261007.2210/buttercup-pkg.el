;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buttercup" "20261007.2210"
  "Behavior-Driven Emacs Lisp Testing."
  '((emacs "24.4"))
  :url "https://github.com/jorgenschaefer/emacs-buttercup"
  :commit "3bcf6cf0e164d558072a484f467169a0e77bd791"
  :revdesc "3bcf6cf0e164"
  :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainers '(("Ola Nilsson" . "ola.nilsson@gmail.com")))
