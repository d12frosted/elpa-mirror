(define-package "apdl-mode" "20210913.1042" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "97e28ce46da81dcfb8847137dd7985ea5b028215" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
