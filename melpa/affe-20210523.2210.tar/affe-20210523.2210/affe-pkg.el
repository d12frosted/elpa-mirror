(define-package "affe" "20210523.2210" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.7"))
  :commit "3fbeeef309a8fa2e1380b8957a955a6beb120ba6" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
