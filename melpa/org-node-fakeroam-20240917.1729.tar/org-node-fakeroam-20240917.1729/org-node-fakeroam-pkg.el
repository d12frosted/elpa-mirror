(define-package "org-node-fakeroam" "20240917.1729" "Stand-ins for org-roam-autosync-mode"
  '((emacs "28.1")
    (compat "30")
    (org-node "0")
    (org-roam "2.2.2")
    (emacsql "4.0.0"))
  :commit "17807fa58e1e46b6e8206d0a921be0d9e28614ee" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node-fakeroam")
;; Local Variables:
;; no-byte-compile: t
;; End:
