(define-package "tao-theme" "20221217.719" "This package provides two parametrized uncoloured color themes for Emacs: tao-yin and tao-yang." 'nil :commit "c2babb86df190eb6a1fe0cedb26defa47bcbe52d" :authors
  '(("Peter Kosov" . "11111000000@email.com"))
  :maintainer
  '("Peter Kosov" . "11111000000@email.com")
  :url "http://github.com/11111000000/tao-theme-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
