;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260303.1428"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.32.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "69ed492102bc64de43d4f0d6ae4bb1c458a5c8ef"
  :revdesc "69ed492102bc"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
