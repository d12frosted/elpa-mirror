;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "20260918.2011"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "2260322bb94f6dad80074da2066e35986b3c275d"
  :revdesc "2260322bb94f"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
