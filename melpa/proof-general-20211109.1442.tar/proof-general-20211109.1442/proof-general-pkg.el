(define-package "proof-general" "20211109.1442" "PG init file for package.el and ELPA compatibility"
  '((emacs "25.1"))
  :commit "2376485828bbd6f151897fdac77dab84f360100e" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
