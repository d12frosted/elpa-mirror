;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "triode" "20261004.1820"
  "Interface to Triode app, macOS internet radio."
  '((emacs     "30.1")
    (transient "0.9.0")
    (restlib   "0.1.5")
    (shazam    "1.0.0"))
  :url "https://github.com/kickingvegas/triode"
  :commit "d6d332737ce960ce094c0cbfa193ecb43976a875"
  :revdesc "d6d332737ce9"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
