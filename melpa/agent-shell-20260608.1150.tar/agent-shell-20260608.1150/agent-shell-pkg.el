;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260608.1150"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "13ce65c49c532f859925ed8b3d1e4565b258800a"
  :revdesc "13ce65c49c53")
