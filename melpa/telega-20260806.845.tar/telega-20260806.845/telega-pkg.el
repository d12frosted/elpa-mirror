;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260806.845"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "c7273cce799d60b6c8bb470cfa26ed267324ff02"
  :revdesc "c7273cce799d"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
