(define-package "notmuch" "20220811.1025" "run notmuch within emacs" 'nil :commit "76c3147613d0cb624573a5ba1ac7d0a5f81113bc" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
