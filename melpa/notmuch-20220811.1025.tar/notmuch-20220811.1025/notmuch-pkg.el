(define-package "notmuch" "20220811.1025" "run notmuch within emacs" 'nil :commit "b76f73efe3a97c707b3b14ca41e7748e21938fea" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
