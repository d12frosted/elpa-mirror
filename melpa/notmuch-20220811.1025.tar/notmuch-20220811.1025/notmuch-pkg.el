(define-package "notmuch" "20220811.1025" "run notmuch within emacs" 'nil :commit "5a47b5a884d594e74bb967dd8bb0500c7051bd79" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
