(define-package "notmuch" "20220811.1025" "run notmuch within emacs" 'nil :commit "760431c0a3216605d3690e963bb8fa3e3c8788cb" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
