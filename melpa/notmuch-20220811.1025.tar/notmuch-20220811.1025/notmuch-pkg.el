(define-package "notmuch" "20220811.1025" "run notmuch within emacs" 'nil :commit "5ea2b25e331df1f16e03131911993f04a80496a4" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
