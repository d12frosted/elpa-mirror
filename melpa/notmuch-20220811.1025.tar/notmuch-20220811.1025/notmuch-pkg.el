(define-package "notmuch" "20220811.1025" "run notmuch within emacs" 'nil :commit "cf21ad2e790b2d078dd4b78f3c870b4f9107e451" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
