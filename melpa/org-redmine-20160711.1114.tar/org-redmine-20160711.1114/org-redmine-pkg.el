;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-redmine" "20160711.1114"
  "Redmine tools using Emacs OrgMode."
  ()
  :url "https://github.com/gongo/org-redmine"
  :commit "a526c3ac802634486bf10de9c2283ccb1a30ec8d"
  :revdesc "a526c3ac8026"
  :keywords '("redmine" "org")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
