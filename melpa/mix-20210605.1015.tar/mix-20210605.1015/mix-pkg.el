(define-package "mix" "20210605.1015" "Mix Major Mode. Build Elixir using Mix"
  '((emacs "25.1"))
  :commit "3d5dbc0ef01c4f6b3732f067e9ebc2d7be74a49e" :authors
  '(("Ayrat Badykov" . "ayratin555@gmail.com"))
  :maintainers
  '(("Ayrat Badykov" . "ayratin555@gmail.com"))
  :maintainer
  '("Ayrat Badykov" . "ayratin555@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/ayrat555/mix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
