;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20250612.338"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "354171f9aa5ede64dff18bfd9ba34eeff2fb641f"
  :revdesc "354171f9aa5e"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
