(define-package "sculpture-themes" "20210828.542" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "2ea6f4cc85b5cc015ea2a6cbb789827e9b4c3ed0" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
