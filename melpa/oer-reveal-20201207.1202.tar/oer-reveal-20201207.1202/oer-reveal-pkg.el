(define-package "oer-reveal" "20201207.1202" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "62c6d91bd5045f2ecb817fdea69d98b03126b715" :keywords
  ("hypermedia" "tools" "slideshow" "presentation" "oer")
  :authors
  (("Jens Lechtenbörger"))
  :maintainer
  ("Jens Lechtenbörger")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
