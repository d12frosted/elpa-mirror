(define-package "w3m" "20211025.2324" "an Emacs interface to w3m" 'nil :commit "619cb559c0d36c8c45ad1efdfc815f94ae7a2538" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
