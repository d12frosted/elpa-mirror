;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20251023.917"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "5a0c0c583c92054112cec553de2e193e72b4ceae"
  :revdesc "5a0c0c583c92"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
