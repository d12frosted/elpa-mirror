;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plain-org-wiki" "20201217.1027"
  "Simple jump-to-org-files in a directory package."
  '((emacs "24.3")
    (ivy   "0.12.0"))
  :url "https://github.com/abo-abo/plain-org-wiki"
  :commit "faeeb54ca808bbf0f4380a938e75805b7a78dbf7"
  :revdesc "faeeb54ca808"
  :keywords '("convenience")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
