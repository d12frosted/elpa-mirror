(define-package "detached" "20220718.2040" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "c34005564459c656fcb0d54b7aceb66aa72e8dd7" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
