(define-package "org-roam" "20210109.949" "Roam Research replica with Org-mode"
  '((emacs "26.1")
    (dash "2.13")
    (f "0.17.2")
    (s "1.12.0")
    (org "9.3")
    (emacsql "3.0.0")
    (emacsql-sqlite3 "1.0.2"))
  :commit "78a371cdc4facf58fb20b513eaf60b24f3aaa7f7" :authors
  '(("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  '("Jethro Kuan" . "jethrokuan95@gmail.com")
  :keywords
  '("org-mode" "roam" "convenience")
  :url "https://github.com/org-roam/org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
