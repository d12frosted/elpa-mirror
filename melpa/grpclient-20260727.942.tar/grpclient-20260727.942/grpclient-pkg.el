;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grpclient" "20260727.942"
  "Grpcurl interactive builder."
  '((emacs "29.1"))
  :url "https://github.com/Prikaz98/grpclient.el"
  :commit "da91349b3b6eccfdf7d318dbea3a54b36d38552d"
  :revdesc "da91349b3b6e"
  :keywords '("grpc" "grpcurl" "tools")
  :authors '(("Ivan Prikaznov" . "prikaznov555@gmail.com")
             ("Miloš Tepić" . "tepcmils@gmail.com"))
  :maintainers '(("Ivan Prikaznov" . "prikaznov555@gmail.com")
                 ("Miloš Tepić" . "tepcmils@gmail.com")))
