(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "2e63828555ef3d943043af8e631b47094583d7c0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
