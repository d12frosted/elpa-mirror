(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "641a95d2254ca7c51c97f07f2eed85b7a95db954" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
