(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "5a2e49be6d76e88b6ace7c6cbb53310ceeedbc62" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
