(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "bfe4dfe0c4441e91b955c9de20131f0a82c2626b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
