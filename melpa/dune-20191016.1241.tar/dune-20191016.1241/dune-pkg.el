(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "c3b73e6052de945e7afded13d11b75c7174a37a8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
