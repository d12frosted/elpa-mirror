(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "4d53aad7f8b91ec09a7c1691eb5392fa3d077a26" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
