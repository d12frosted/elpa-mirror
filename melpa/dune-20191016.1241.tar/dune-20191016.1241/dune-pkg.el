(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "51fc74e10ae35896d3df40986ea17381578e0e58" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
