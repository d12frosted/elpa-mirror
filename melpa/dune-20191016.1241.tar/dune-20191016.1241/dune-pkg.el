(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "d9df8b951ad3e43789b8715a42750f56e930b754" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
