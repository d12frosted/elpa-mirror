(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "13642e22a405de7c4361e94dd9aaa35ad1b09847" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
