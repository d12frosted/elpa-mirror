(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "40c91fe0df44c4a1f7a46d5d61a9f42743211bca" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
