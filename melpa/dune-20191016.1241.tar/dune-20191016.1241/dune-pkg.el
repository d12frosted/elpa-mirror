(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "cd7ea706bc3c56f8bf3bcd979515ddabb84e45e0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
