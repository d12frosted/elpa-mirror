(define-package "bqn-mode" "20230326.2100" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "eb39528fd8023fbe541918baf4ac64320d39b97a" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
