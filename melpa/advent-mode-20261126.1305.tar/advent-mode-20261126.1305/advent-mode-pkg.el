;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20261126.1305"
  "Advent of Code mode."
  '((emacs "30.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "a91d5e3ef568460892890c89dd14c4fa4139179e"
  :revdesc "a91d5e3ef568"
  :keywords '("tools")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
