;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261101.1610"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "23286ceaec1e2385f3339e2e11bac5d8c2f89419"
  :revdesc "23286ceaec1e"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
