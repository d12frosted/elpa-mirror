(define-package "vhdl-ext" "20230609.2131" "VHDL Extensions"
  '((emacs "28.1")
    (eglot "1.9")
    (lsp-mode "8.0.1")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "33snapshot")
    (company "0.9.13"))
  :commit "231cb1a7dd582625035b8768e37f5bb9d25ff1b0" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
