(define-package "live-py-mode" "20210404.1948" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "4f16d8e3e1e36ce6237f4ee458885ba995f083a5" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
