(define-package "live-py-mode" "20210404.1948" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "76244fcfdd73d3aad6a4e6fba9cb8d5d4a5aba9b" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
