;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "almost-mono-themes" "20250514.1538"
  "Almost monochromatic color themes."
  '((emacs "24"))
  :url "https://github.com/cryon/almost-mono-themes"
  :commit "bbb9f450578994029273c5d961f8f6287a8fb5c2"
  :revdesc "bbb9f4505789"
  :keywords '("faces")
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
