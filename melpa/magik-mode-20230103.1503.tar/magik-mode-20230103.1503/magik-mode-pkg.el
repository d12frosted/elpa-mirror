(define-package "magik-mode" "20230103.1503" "mode for editing Magik + some utils." 'nil :commit "a2ddc7cad487e6165c2e2ac26acec62b1f7bbeca" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
