;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mac-ime" "20260531.1044"
  "Seamless macOS IME integration without any IME patches."
  '((emacs "27.1"))
  :url "https://github.com/ma0001/mac-ime"
  :commit "cf7b6001b4fb5d33fa259364cfa8ec5f6aa73fb3"
  :revdesc "cf7b6001b4fb"
  :keywords '("i18n" "convenience"))
