;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251124.1114"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "c177cceefb72458e4a6a49d1e3c6f2543efff171"
  :revdesc "c177cceefb72"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
