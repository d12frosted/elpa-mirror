(define-package "lsp-julia" "20230414.2107" "Julia support for lsp-mode"
  '((emacs "25.1")
    (lsp-mode "6.3")
    (julia-mode "0.3"))
  :commit "c584f79c7fee6176bbb6120f4cb0f1001bcf8113" :authors
  '(("Martin Wolke" . "vibhavp@gmail.com")
    ("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")
    ("Guido Kraemer" . "gdkrmr@users.noreply.github.com"))
  :maintainer
  '("Guido Kraemer" . "gdkrmr@users.noreply.github.com")
  :keywords
  '("languages" "tools")
  :url "https://github.com/gdkrmr/lsp-julia")
;; Local Variables:
;; no-byte-compile: t
;; End:
