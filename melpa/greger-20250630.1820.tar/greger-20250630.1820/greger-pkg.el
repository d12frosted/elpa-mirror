;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greger" "20250630.1820"
  "Agentic coding environment with tool use, using Claude."
  '((emacs "29.1"))
  :url "https://github.com/andreasjansson/greger.el"
  :commit "5529911badee1edda7834e5961c3d00dd8bc50a6"
  :revdesc "5529911badee"
  :keywords '("agent" "agentic" "ai" "chat" "language-models" "tools")
  :authors '(("Andreas Jansson" . "andreas@jansson.me.uk"))
  :maintainers '(("Andreas Jansson" . "andreas@jansson.me.uk")))
