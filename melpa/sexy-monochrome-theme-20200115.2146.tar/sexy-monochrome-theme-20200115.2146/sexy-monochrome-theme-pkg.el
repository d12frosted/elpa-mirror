;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sexy-monochrome-theme" "20200115.2146"
  "A sexy dark Emacs >= 24 theme for your sexy code."
  ()
  :url "https://github.com/voloyev/sexy-monochrome-theme"
  :commit "f3ad07d60c966ef34cb11026eaba053e114bb8f1"
  :revdesc "f3ad07d60c96"
  :keywords '("themes")
  :authors '(("Volodymyr Yevtushenko" . "voloyev@vivaldi.net"))
  :maintainers '(("Volodymyr Yevtushenko" . "voloyev@vivaldi.net")))
