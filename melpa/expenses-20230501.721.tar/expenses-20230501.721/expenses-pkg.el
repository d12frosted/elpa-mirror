(define-package "expenses" "20230501.721" "Record and view expenses"
  '((emacs "28.1")
    (dash "2.19.1")
    (ht "2.3"))
  :commit "49da84fc8c0cdbc9c86586033d40455c9c80f6d0" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("expense tracking" "convenience")
  :url "https://github.com/md-arif-shaikh/expenses")
;; Local Variables:
;; no-byte-compile: t
;; End:
