;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260525.1719"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "5818c819bdf5ff37717c7140afaddd0398d2da48"
  :revdesc "5818c819bdf5"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
