(define-package "eldev" "20221114.1808" "Elisp development tool"
  '((emacs "24.4"))
  :commit "86c78e5e98b94ab61d04861d9d5fde7aad8ead5e" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
