;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20251031.1705"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "80d47ddbe6c1be59ded8327671653fb5bffad879"
  :revdesc "80d47ddbe6c1"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
