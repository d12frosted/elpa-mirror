;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-git-toolbelt" "20260201.1921"
  "A Magit interface for git-toolbelt."
  '((emacs     "26.1")
    (magit     "3.0.0")
    (transient "0.3.0"))
  :url "https://github.com/jonathanchu/magit-git-toolbelt"
  :commit "b629fdede79e7818ea5ca9c48e00989c015116ea"
  :revdesc "b629fdede79e"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
