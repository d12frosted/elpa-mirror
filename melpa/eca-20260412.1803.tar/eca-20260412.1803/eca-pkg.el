;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260412.1803"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "8e2c4296fd1ee8ca8bf73c77cebe39acb19cbdf1"
  :revdesc "8e2c4296fd1e"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
