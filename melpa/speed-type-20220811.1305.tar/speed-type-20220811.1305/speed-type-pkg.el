(define-package "speed-type" "20220811.1305" "Practice touch and speed typing"
  '((emacs "25.1"))
  :commit "a3540c37cf4d476b67b545a8339c1b4d3dc84ece" :authors
  '(("Gunther Hagleitner"))
  :maintainer
  '("Daniel Kraus" . "daniel@kraus.my")
  :keywords
  '("games")
  :url "https://github.com/dakra/speed-type")
;; Local Variables:
;; no-byte-compile: t
;; End:
