;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250303.942"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "939f44c70f283a73718f87d1344280cc4a6aa137"
  :revdesc "939f44c70f28"
  :keywords '("languages"))
