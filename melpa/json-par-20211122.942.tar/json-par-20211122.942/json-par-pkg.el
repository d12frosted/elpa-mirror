(define-package "json-par" "20211122.942" "Minor mode for structural editing of JSON"
  '((emacs "24.4")
    (json-mode "1.7.0"))
  :commit "2bc383c4f88a111202b4d00303f3345b32e4b8e9" :authors
  '(("taku0 (http://github.com/taku0)"))
  :maintainer
  '("taku0 (http://github.com/taku0)")
  :keywords
  '("abbrev" "convenience" "files")
  :url "https://github.com/taku0/json-par")
;; Local Variables:
;; no-byte-compile: t
;; End:
