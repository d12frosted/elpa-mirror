;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261013.914"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "bb3d9454595872cd4a13ceeae193f2f55c8dd02c"
  :revdesc "bb3d94545958"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
