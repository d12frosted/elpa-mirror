;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smudge" "20251219.2301"
  "Control the Spotify app."
  '((emacs        "27.1")
    (simple-httpd "1.5.1")
    (request      "0.3")
    (oauth2       "0.16"))
  :url "https://github.com/danielfm/smudge"
  :commit "d11b6f009f8b0dd76e45057a36a49168ef72a031"
  :revdesc "d11b6f009f8b"
  :keywords '("multimedia" "music" "spotify" "smudge"))
