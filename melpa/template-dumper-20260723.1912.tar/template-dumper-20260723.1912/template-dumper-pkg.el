;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "template-dumper" "20260723.1912"
  "Create files from yasnippet templates."
  '((emacs     "28.1")
    (yasnippet "0.14.0")
    (f         "0.20.0")
    (templatel "20210902.228"))
  :url "https://resultsmotivated.com/"
  :commit "a60b7f840ffc1f2908e06baeff794f4026a0ca45"
  :revdesc "a60b7f840ffc"
  :keywords '("yasnippet" "templating" "convenience" "tools"))
