;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260715.958"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "64db15eca098f3d3942e9f83422e12711dbe2ecb"
  :revdesc "64db15eca098"
  :keywords '("convenience" "chinese" "input-method" "rime"))
