(define-package "eldev" "20220213.1633" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "0d65a3f022e4cf2dec0b6aa313625b060e41ddb8" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
