;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loco" "20250917.1458"
  "Enter complex key sequences with ease!."
  '((emacs "29.1"))
  :url "https://github.com/csmclaren/loco"
  :commit "eb9f89221d10b946482a79493d63a6fac15fb9fc"
  :revdesc "eb9f89221d10"
  :keywords '("abbrev" "convenience")
  :authors '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainers '(("Chris McLaren" . "csmclaren@me.com")))
