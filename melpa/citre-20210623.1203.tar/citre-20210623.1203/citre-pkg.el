(define-package "citre" "20210623.1203" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "e9bd389bdc2968f070d77acd2def1a96ed3f03eb" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
