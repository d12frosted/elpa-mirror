;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260227.2352"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "53045ab27c3ebd2b7787aafbf9115e6718a3a229"
  :revdesc "53045ab27c3e")
