;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-overlay" "20230406.959"
  "Display eldoc with contextual documentation overlay."
  '((emacs       "24.4")
    (inline-docs "1.0.1")
    (quick-peek  "1.0"))
  :url "https://repo.or.cz/eldoc-overlay.git"
  :commit "14a9e141918c2e18a107920e8631e622c580b3ef"
  :revdesc "14a9e141918c"
  :keywords '("docs" "eldoc" "overlay")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
