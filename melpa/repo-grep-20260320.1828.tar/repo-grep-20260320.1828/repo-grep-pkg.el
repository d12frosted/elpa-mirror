;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "20260320.1828"
  "Project-wide grep search."
  '((emacs "27.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "5565cf5fa21aa3bb684ee55ccd89f5b3ac7ec897"
  :revdesc "5565cf5fa21a"
  :keywords '("tools" "search" "grep" "convenience" "project"))
