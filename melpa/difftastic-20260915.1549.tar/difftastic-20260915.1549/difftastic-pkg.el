;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "20260915.1549"
  "Wrapper for difftastic."
  '((emacs     "28.1")
    (compat    "29.1.4.2")
    (magit     "4.0.0")
    (transient "0.4.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "98c61e7dfac8d1ad4451423395da6bc14caa41df"
  :revdesc "98c61e7dfac8"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
