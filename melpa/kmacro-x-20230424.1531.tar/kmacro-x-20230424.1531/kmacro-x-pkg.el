(define-package "kmacro-x" "20230424.1531" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "ec708ac9a8a340a33460221dd5cb0a018f128b82" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
