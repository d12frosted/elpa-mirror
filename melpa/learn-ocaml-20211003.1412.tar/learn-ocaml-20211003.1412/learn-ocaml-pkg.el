;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "learn-ocaml" "20211003.1412"
  "Emacs frontend for learn-ocaml."
  '((emacs "25.1"))
  :url "https://github.com/pfitaxel/learn-ocaml.el"
  :commit "abdc263537a6a534152a4eaaa17b2c3e4e10418b"
  :revdesc "abdc263537a6")
