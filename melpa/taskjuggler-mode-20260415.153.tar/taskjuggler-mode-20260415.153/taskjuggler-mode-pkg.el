;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskjuggler-mode" "20260415.153"
  "Major mode for TaskJuggler project files."
  '((emacs "27.1"))
  :url "https://github.com/devrintalen/taskjuggler-mode.el"
  :commit "c17af93ee6f230e2688d3343defe4f9c0939d8e7"
  :revdesc "c17af93ee6f2"
  :keywords '("languages" "project-management")
  :authors '(("Devrin Talen" . "devrin@fastmail.com"))
  :maintainers '(("Devrin Talen" . "devrin@fastmail.com")))
