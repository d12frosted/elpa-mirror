;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260703.1934"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "54197735aa2557eb9dd9554aab06afbd13e6b4a4"
  :revdesc "54197735aa25"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
