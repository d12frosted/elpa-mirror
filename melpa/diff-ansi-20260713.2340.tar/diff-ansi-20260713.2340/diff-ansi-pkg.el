;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "20260713.2340"
  "Display diffs using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "86c0b3525b2793b585b548c6e975d6fe6a2cea2a"
  :revdesc "86c0b3525b27"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
