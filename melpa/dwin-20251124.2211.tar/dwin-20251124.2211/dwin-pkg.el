;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwin" "20251124.2211"
  "Navigate and arrange desktop windows."
  '((emacs "30.2"))
  :url "https://github.com/lsth/dwin"
  :commit "6535c9ee8932e4c2103823d27518d1839837dabe"
  :revdesc "6535c9ee8932"
  :keywords '("frames" "processes" "convenience")
  :authors '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de"))
  :maintainers '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de")))
