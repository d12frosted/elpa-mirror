(define-package "company" "20240713.303" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "31f7ad52e4d353a8b2f0ec7e2c3135c012e500e2" :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
