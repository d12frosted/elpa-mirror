(define-package "eldev" "20221116.2124" "Elisp development tool"
  '((emacs "24.4"))
  :commit "dc46059484cdd19274e70b73ca3962c26be2582e" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
