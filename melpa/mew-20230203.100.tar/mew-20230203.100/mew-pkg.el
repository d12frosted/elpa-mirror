(define-package "mew" "20230203.100" "Messaging in the Emacs World" 'nil :commit "f96266240586898ea44256f6b24743a50e1113cb" :authors
  '(("Kazu Yamamoto" . "Kazu@Mew.org"))
  :maintainer
  '("Kazu Yamamoto" . "Kazu@Mew.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
