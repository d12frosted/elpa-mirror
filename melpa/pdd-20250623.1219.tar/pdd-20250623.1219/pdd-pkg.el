;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250623.1219"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "f478ea5d7ab451874bfd7d8bc6ade5cf43181853"
  :revdesc "f478ea5d7ab4"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
