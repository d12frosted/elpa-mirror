;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "20260403.1420"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "490e54136cd223f416a971ed8de889b1f551db39"
  :revdesc "490e54136cd2"
  :keywords '("color" "theme" "faces"))
