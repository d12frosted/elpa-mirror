(define-package "sqlite-mode-extras" "20240319.653" "Extensions for sqlite-mode"
  '((emacs "29.1"))
  :commit "19d350ef77f8bd6ac75be082ab4ebb0cca1706e2" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/sqlite-mode-extras")
;; Local Variables:
;; no-byte-compile: t
;; End:
