(define-package "helm-core" "20210105.504" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "7de89da555a4cfc976bd9347bf1cfe511c0f3444")
;; Local Variables:
;; no-byte-compile: t
;; End:
