(define-package "gptel" "20231222.525" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "c9d362a3e9c713760239d51c992bb71b194b6ae7" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
