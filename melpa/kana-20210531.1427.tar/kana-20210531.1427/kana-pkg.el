;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kana" "20210531.1427"
  "Learn Japanese hiragana and katakana."
  '((emacs "24.4")
    (dash  "2.17.0"))
  :url "https://github.com/chenyanming/kana"
  :commit "d3d550aad67ef8625b3860598bf3622f5b2a7d32"
  :revdesc "d3d550aad67e"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
