;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260508.2147"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "ecbbae348eeb22f6470b8cd9b51b43522f3a1baf"
  :revdesc "ecbbae348eeb"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
