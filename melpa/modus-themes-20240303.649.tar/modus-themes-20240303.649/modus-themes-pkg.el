(define-package "modus-themes" "20240303.649" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "263e4f257246ee7c94ae4716bebc258320bd1e6f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
