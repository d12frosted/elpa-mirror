;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260129.128"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.4")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "07c05f8e531760cccb0af4f02db89f0d16257d7e"
  :revdesc "07c05f8e5317"
  :keywords '("programming"))
