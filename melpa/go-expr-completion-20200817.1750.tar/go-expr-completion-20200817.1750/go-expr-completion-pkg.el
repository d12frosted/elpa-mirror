;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-expr-completion" "20200817.1750"
  "Complement the return values for Go."
  '((emacs "24.1"))
  :url "https://github.com/fujimisakari/emacs-go-expr-completion"
  :commit "66bba78f52a732b978848e3a4c99fa2afeb6c25f"
  :revdesc "66bba78f52a7"
  :authors '(("Ryo Fujimoto" . "fujimisakri@gmail.com"))
  :maintainers '(("Ryo Fujimoto" . "fujimisakri@gmail.com")))
