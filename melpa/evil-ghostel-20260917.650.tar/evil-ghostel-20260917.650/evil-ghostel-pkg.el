;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260917.650"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "755c61a4bffa3d461d4c36d69c9f95cc9e31ea95"
  :revdesc "755c61a4bffa"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
