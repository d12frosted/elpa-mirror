;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260121.120"
  "A minimal Jabber client."
  '((emacs "27.1")
    (fsm   "0.2.0")
    (srv   "0.2"))
  :url "https://codeberg.org/emacs-jabber/emacs-jabber"
  :commit "44799344022e04489f1c380cf0ef82cea4f75a7b"
  :revdesc "44799344022e"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("wgreenhouse" . "wgreenhouse@tilde.club")))
