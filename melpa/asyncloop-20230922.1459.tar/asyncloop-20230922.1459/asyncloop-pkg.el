(define-package "asyncloop" "20230922.1459" "Non-blocking series of functions"
  '((emacs "28.1"))
  :commit "7f7009cce440dcf1710d8d9f5750342a362db1e4" :authors
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainers
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainer
  '(nil . "<meedstrom91@gmail.com>")
  :keywords
  '("tools")
  :url "https://github.com/meedstrom/asyncloop")
;; Local Variables:
;; no-byte-compile: t
;; End:
