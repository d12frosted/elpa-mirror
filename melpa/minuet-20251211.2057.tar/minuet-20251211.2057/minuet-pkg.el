;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20251211.2057"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "10638b986ee83b15856f89fafac4ea9a689bf67f"
  :revdesc "10638b986ee8"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
