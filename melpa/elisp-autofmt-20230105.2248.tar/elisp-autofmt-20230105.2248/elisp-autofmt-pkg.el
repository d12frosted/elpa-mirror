(define-package "elisp-autofmt" "20230105.2248" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "5ab06f409e58b81e6ae167f2bfb276345abf8f9d" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
