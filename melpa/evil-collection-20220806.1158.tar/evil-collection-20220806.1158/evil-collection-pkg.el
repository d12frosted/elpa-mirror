(define-package "evil-collection" "20220806.1158" "A set of keybindings for Evil mode"
  '((emacs "26.3")
    (evil "1.2.13")
    (annalist "1.0"))
  :commit "c005e07420d177e8d7be6c30939e5e1fa68bc2b8" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("evil" "tools")
  :url "https://github.com/emacs-evil/evil-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
