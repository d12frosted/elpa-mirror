(define-package "spdx" "20230929.59" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "12a1dc3bf4ed5c4617f91402ff2636ad4eaca8cf" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
