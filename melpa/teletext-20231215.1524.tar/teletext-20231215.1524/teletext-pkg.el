;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teletext" "20231215.1524"
  "Teletext broadcast viewer."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-teletext"
  :commit "d59ae5f9b79007646815a38f31882a114ca8aee0"
  :revdesc "d59ae5f9b790"
  :keywords '("comm" "help" "hypermedia")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
