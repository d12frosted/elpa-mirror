;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "20260203.236"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "3084a33f08dde90faffe39bda703b98d0ad006dd"
  :revdesc "3084a33f08dd"
  :keywords '("languages"))
