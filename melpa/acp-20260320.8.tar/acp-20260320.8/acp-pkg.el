;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20260320.8"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "863f2d62c4b4da8b229581be42d490a7403b2eb1"
  :revdesc "863f2d62c4b4")
