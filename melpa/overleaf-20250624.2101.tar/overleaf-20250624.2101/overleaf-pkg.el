;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250624.2101"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "4dfe2d3c23d3e43dfc6fbdf28f1348f104755db5"
  :revdesc "4dfe2d3c23d3"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
