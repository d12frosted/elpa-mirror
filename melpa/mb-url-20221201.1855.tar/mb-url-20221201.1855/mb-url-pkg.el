(define-package "mb-url" "20221201.1855" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "a6e5209a3569857836c5f6e58eb33ec98a9f6700" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
