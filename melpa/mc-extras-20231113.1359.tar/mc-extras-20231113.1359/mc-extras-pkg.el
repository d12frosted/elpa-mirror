(define-package "mc-extras" "20231113.1359" "Extra functions for multiple-cursors mode."
  '((multiple-cursors "1.2.1"))
  :commit "abd98a7c92e71d38494a6bf20853f3ff20e1f013" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("editing" "cursors")
  :url "https://github.com/knu/mc-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
