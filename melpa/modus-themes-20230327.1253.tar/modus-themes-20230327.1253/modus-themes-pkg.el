(define-package "modus-themes" "20230327.1253" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "f90def4d90534f353021ed4e7efced716fa019fb" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
