(define-package "consult" "20220421.1130" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "6df330a2856a5d4fc19c865d8839ce64f179bd89" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
