;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ansible-vault" "20251029.2146"
  "Minor mode for editing ansible vault files."
  '((emacs "26.1"))
  :url "https://github.com/freehck/ansible-vault-mode"
  :commit "74f96ce226f51bec203af343f73182ea132749a6"
  :revdesc "74f96ce226f5"
  :keywords '("ansible" "ansible-vault" "tools")
  :maintainers '(("Dmitrii Kashin" . "freehck@yandex.ru")))
