;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-agent-shell" "20261007.1612"
  "Org-babel backend for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.85.3")
    (org         "9.6"))
  :url "https://github.com/eddof13/ob-agent-shell"
  :commit "494608c80da381de93f0f9ef1fcabbf8aa371343"
  :revdesc "494608c80da3"
  :keywords '("tools" "convenience" "outlines")
  :authors '(("Eddie Jesinsky" . "eddie@jesinsky.com"))
  :maintainers '(("Eddie Jesinsky" . "eddie@jesinsky.com")))
