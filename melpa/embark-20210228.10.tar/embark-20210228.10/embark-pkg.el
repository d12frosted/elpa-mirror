(define-package "embark" "20210228.10" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "0c7323953e628c8797270a37c0f639fe23092175" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
