;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "20250620.1410"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.35.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "4723af27cc9c8958fd00a5b39745134babbc0d45"
  :revdesc "4723af27cc9c"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
