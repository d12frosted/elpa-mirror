;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit-forge" "20260701.1432"
  "Org links to Forge issue buffers."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (forge    "0.6")
    (magit    "4.6")
    (org      "9.8")
    (orgit    "2.2"))
  :url "https://github.com/magit/orgit-forge"
  :commit "c421620af3fb38ab4654f745f51370471b65cf4e"
  :revdesc "c421620af3fb"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev")))
