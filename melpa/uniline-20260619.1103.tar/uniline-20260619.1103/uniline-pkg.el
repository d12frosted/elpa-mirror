;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260619.1103"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "eaff70c71f17c85d3d26dd2c1dbf466b21c6c085"
  :revdesc "eaff70c71f17"
  :keywords '("convenience" "text"))
