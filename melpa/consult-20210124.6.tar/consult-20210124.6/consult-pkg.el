(define-package "consult" "20210124.6" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "fe1f5ecc99bc3e2eebb61df18ace1cff1b313bdf" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
