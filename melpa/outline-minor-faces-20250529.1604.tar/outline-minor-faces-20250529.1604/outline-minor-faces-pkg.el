;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-minor-faces" "20250529.1604"
  "Highlight only section headings."
  '((emacs  "26.1")
    (compat "30.0.1.0"))
  :url "https://github.com/tarsius/outline-minor-faces"
  :commit "4a67945e85f752c19ee6507d04dba4c12bae05a5"
  :revdesc "4a67945e85f7"
  :keywords '("faces" "outlines")
  :authors '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev")))
