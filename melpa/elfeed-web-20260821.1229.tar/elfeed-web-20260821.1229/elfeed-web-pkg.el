;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-web" "20260821.1229"
  "Web interface to Elfeed."
  '((emacs        "29.1")
    (compat       "31")
    (elfeed       "4.1.0")
    (simple-httpd "1.6"))
  :url "https://github.com/emacs-elfeed/elfeed-web"
  :commit "1f089663e7952c33512c37d2bd2544043e039e23"
  :revdesc "1f089663e795"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
