;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260123.1636"
  "Major mode for Godot's GDScript language."
  '((emacs "26.3"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "eac71fb88bc6313577908d5564961872cadbaff0"
  :revdesc "eac71fb88bc6"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
