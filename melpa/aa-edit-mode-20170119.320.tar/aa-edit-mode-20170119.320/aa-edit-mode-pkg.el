;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aa-edit-mode" "20170119.320"
  "Major mode for editing AA(S_JIS Art) and .mlt file."
  '((emacs   "24.3")
    (navi2ch "2.0.0"))
  :url "https://github.com/zonuexe/aa-edit-mode"
  :commit "1dd801225b7ad3c23ad09698f5e77f0df7012a65"
  :revdesc "1dd801225b7a"
  :keywords '("wp" "text" "shiftjis" "mlt" "yaruo")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
