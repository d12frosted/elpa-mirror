;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jupyter-ascending" "20250427.2101"
  "Edit Jupyter Notebooks in plain text."
  '((emacs "29.4"))
  :url "https://github.com/Duncan-Britt/jupyter-ascending"
  :commit "eea269cb3c340385521afecf5d92bbbecd80119e"
  :revdesc "eea269cb3c34"
  :keywords '("tools" "jupyter" "notebook" "python"))
