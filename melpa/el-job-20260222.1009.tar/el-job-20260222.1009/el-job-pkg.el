;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20260222.1009"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "5af4975c176477cfe5f864bb9b402d8a8f2a074a"
  :revdesc "5af4975c1764"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
