(define-package "circadian" "20221223.1734" "Theme-switching based on daytime"
  '((emacs "24.4"))
  :commit "9959e4b9d2ed9920b668fc229aab1f5fa5bd8584" :authors
  '(("Guido Schmidt"))
  :maintainers
  '(("Guido Schmidt" . "git@guidoschmidt.cc"))
  :maintainer
  '("Guido Schmidt" . "git@guidoschmidt.cc")
  :keywords
  '("themes")
  :url "https://github.com/GuidoSchmidt/circadian")
;; Local Variables:
;; no-byte-compile: t
;; End:
