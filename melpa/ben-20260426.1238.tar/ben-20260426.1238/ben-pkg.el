;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ben" "20260426.1238"
  "Asynchronous buffer-local environments via `direnv'."
  '((emacs      "29.1")
    (inheritenv "0.1")
    (seq        "2.24"))
  :url "https://codeberg.org/pastor/ben.el"
  :commit "c91cce703deb0cafb9f344cbc66d63791665fcb2"
  :revdesc "c91cce703deb"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com")
             ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")
                 ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
