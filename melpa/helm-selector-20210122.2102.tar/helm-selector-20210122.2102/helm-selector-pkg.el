(define-package "helm-selector" "20210122.2102" "Helm buffer selector"
  '((emacs "26.1")
    (helm "3"))
  :commit "5d5b830d6df3e93faed20d042e0dcdd6a083e815" :authors
  '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainer
  '("Pierre Neidhardt" . "mail@ambrevar.xyz")
  :url "https://github.com/emacs-helm/helm-selector")
;; Local Variables:
;; no-byte-compile: t
;; End:
