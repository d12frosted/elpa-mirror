(define-package "treesit-auto" "20240420.1421" "Automatically use tree-sitter enhanced major modes"
  '((emacs "29.0"))
  :commit "1b63bc5e50def3c14ab69e53ed6e7f65a7482016" :authors
  '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers
  '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainer
  '("Robb Enzmann" . "robbenzmann@gmail.com")
  :keywords
  '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :url "https://github.com/renzmann/treesit-auto.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
