(define-package "for" "20230330.2007" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "db14b5da78feecd5eb139eaadb2accb94eabc347" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainers
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
