(define-package "org-roam" "20210817.1540" "A database abstraction layer for Org-mode"
  '((emacs "26.1")
    (dash "2.13")
    (f "0.17.2")
    (org "9.4")
    (emacsql "3.0.0")
    (emacsql-sqlite "1.0.0")
    (magit-section "2.90.1"))
  :commit "b8a66deae99e0feab3106d7b7ec36af1631f2dff" :authors
  '(("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  '("Jethro Kuan" . "jethrokuan95@gmail.com")
  :keywords
  '("org-mode" "roam" "convenience")
  :url "https://github.com/org-roam/org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
