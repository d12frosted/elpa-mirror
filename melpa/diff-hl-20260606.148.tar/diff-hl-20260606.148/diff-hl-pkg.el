;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260606.148"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "b6d9e3ee60d1c8b1b9688a70b664abe9475c6dbe"
  :revdesc "b6d9e3ee60d1"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
