;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260713.333"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "066bc1c2c06493d10388f8a0ecd8e90f8cd28532"
  :revdesc "066bc1c2c064"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
