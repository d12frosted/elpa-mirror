;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20251105.252"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "f86322b428b9f9422549f023ec975e0311ea8606"
  :revdesc "f86322b428b9"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
