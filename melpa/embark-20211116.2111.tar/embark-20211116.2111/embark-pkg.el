(define-package "embark" "20211116.2111" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "edfd0a842a75ad25115f95f56b0c8a9351d3e248" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
