(define-package "weblorg" "20210430.2251" "Static Site Generator for org-mode"
  '((templatel "0.1.5")
    (emacs "26.1"))
  :commit "11ec801222eeb468878e6585efb55721592dbfe8" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
