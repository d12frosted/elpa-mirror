(define-package "meow" "20230213.200" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "1e69067c1647ea634c87c021c5acf4a81152f4b2" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
