(define-package "dirvish" "20220608.1805" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "8c5be46de6e5d94b377c18d5c04f0af4f26223fb" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
