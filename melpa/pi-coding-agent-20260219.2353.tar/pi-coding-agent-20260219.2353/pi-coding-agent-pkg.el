;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260219.2353"
  "Emacs frontend for pi coding agent."
  '((emacs         "28.1")
    (markdown-mode "2.6")
    (transient     "0.9.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "2044f8fb84f778afe269505310ebe7183879a13c"
  :revdesc "2044f8fb84f7"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
