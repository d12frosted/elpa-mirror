(define-package "elisp-autofmt" "20230109.536" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "57cc34aa2bd76f0c831c75dfd79881236dd0f0cd" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
