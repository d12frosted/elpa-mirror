(define-package "x509-mode" "20220705.757" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "24.3"))
  :commit "49fbab6166d03e5d4c8b856de6ef04b99ba16eb4" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
