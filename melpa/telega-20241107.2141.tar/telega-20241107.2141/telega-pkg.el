;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20241107.2141"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "aa8ebe362e1092a1603afc06e233bace6ce67476"
  :revdesc "aa8ebe362e10"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
