(define-package "magit-file-icons" "20240520.131" "Icons for file entries in Magit buffers"
  '((emacs "24.3")
    (magit "3.3.0")
    (nerd-icons "0.1.0")
    (el-patch "3.1"))
  :commit "33458112ae3701a82a02a4b88dd52baef48ababe" :authors
  '(("Gregor Grigorjan" . "gregor@grigorjan.net"))
  :maintainers
  '(("Gregor Grigorjan" . "gregor@grigorjan.net"))
  :maintainer
  '("Gregor Grigorjan" . "gregor@grigorjan.net")
  :url "https://github.com/gekoke/magit-file-icons")
;; Local Variables:
;; no-byte-compile: t
;; End:
