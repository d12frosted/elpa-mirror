;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-eask" "20260224.1651"
  "Company backend for Eask-file."
  '((emacs   "26.1")
    (company "0.8.0")
    (eask    "0.1.0"))
  :url "https://github.com/emacs-eask/company-eask"
  :commit "748c53fe1530c7b75682d78128f85326e41432d6"
  :revdesc "748c53fe1530"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
