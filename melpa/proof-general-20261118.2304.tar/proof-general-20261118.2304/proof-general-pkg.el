;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261118.2304"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "f0460033ef60baa04a989f565a79d5f871196df4"
  :revdesc "f0460033ef60"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
