;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-smart-underscore" "20190309.101"
  "Ess Smart Underscore."
  '((ess "0"))
  :url "https://github.com/mlf176f2/ess-smart-underscore.el"
  :commit "aa871c5b0448515db439ea9bed6a8574e82ddb47"
  :revdesc "aa871c5b0448"
  :keywords '("ess" "underscore"))
