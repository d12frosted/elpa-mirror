(define-package "slime-docker" "20190430.157" "Integration of SLIME with Docker containers."
  '((emacs "24")
    (slime "2.16")
    (docker-tramp "0.1")
    (cl-lib "0.5"))
  :commit "151cec4a11965cdc00d231900a50f2c9f455fce2" :keywords
  '("docker" "lisp" "slime")
  :url "https://github.com/daewok/slime-docker")
;; Local Variables:
;; no-byte-compile: t
;; End:
