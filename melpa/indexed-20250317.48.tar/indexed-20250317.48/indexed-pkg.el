;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250317.48"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (el-job "2.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "09f6db7516a8c904adcfbb73d8c74261931f1a8e"
  :revdesc "09f6db7516a8"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
