(define-package "yaml-pro" "20240223.455" "Parser-aided YAML editing features"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "b891d55c4abbdbdafe775022f874da509156e975" :authors
  '(("Zachary Romero"))
  :maintainers
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("tools")
  :url "https://github.com/zkry/yaml-pro")
;; Local Variables:
;; no-byte-compile: t
;; End:
