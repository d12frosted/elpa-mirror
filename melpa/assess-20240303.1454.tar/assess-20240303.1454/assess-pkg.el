;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "assess" "20240303.1454"
  "Test support functions."
  '((emacs    "24.4")
    (m-buffer "0.15"))
  :url "https://github.com/phillord/assess"
  :commit "cadeb24a5d8261fad4bdfdc09e7d571cc395a6ca"
  :revdesc "cadeb24a5d82"
  :authors '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@russet.org.uk")))
