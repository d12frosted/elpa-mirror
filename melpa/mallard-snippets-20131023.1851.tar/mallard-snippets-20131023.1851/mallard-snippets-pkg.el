;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mallard-snippets" "20131023.1851"
  "Yasnippets for Mallard."
  '((yasnippet    "0.8.0")
    (mallard-mode "0.1.1"))
  :url "https://github.com/jhradilek/emacs-mallard-snippets"
  :commit "35b7d0558da14fcffd51863f623806216a0093ce"
  :revdesc "35b7d0558da1"
  :keywords '("snippets" "mallard")
  :authors '(("Jaromir Hradilek" . "jhradilek@gmail.com"))
  :maintainers '(("Jaromir Hradilek" . "jhradilek@gmail.com")))
