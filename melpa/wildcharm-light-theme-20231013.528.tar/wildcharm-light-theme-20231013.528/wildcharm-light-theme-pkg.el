(define-package "wildcharm-light-theme" "20231013.528" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "d15ef8d67126dee183262cc141355cbed944149f" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
