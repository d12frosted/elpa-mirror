;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codex-cli" "20250913.1900"
  "Codex CLI integration."
  '((emacs "28.1"))
  :url "https://github.com/bennfocus/codex-cli.el"
  :commit "172d62381851d82860186a56da6f936f40180b3f"
  :revdesc "172d62381851"
  :keywords '("tools" "convenience" "codex" "codex-cli")
  :authors '(("Benn" . "bennmsg@gmail.com"))
  :maintainers '(("Benn" . "bennmsg@gmail.com")))
