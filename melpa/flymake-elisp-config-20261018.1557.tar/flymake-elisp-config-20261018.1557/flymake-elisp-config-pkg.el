;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-elisp-config" "20261018.1557"
  "Setup load-path for flymake on Emacs Lisp mode."
  '((emacs "28.1"))
  :url "https://github.com/ROCKTAKEY/flymake-elisp-config"
  :commit "b5a22131c36d71d82da7fc6473a684dae56e4bff"
  :revdesc "b5a22131c36d"
  :keywords '("lisp")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
