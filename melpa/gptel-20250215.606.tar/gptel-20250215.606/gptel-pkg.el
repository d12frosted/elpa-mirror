;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250215.606"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "a502ca547c22e51c9c6a21227c5744b17c4fd1c3"
  :revdesc "a502ca547c22"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
