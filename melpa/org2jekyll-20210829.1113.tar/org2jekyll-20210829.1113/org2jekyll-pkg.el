;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2jekyll" "20210829.1113"
  "Minor mode to publish org-mode post to jekyll without specific yaml."
  '((dash "2.18.0")
    (s    "1.9.0"))
  :url "https://github.com/ardumont/org2jekyll"
  :commit "4393402448da722667f6f5a4d742fa817dec0c0f"
  :revdesc "4393402448da"
  :keywords '("org-mode" "jekyll" "blog" "publish")
  :authors '(("Antoine R. Dumont" . "antoine.romain.dumont@gmail.com"))
  :maintainers '(("Antoine R. Dumont" . "antoine.romain.dumont@gmail.com")))
