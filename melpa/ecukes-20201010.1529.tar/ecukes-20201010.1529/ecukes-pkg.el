(define-package "ecukes" "20201010.1529" "Cucumber for Emacs."
  '((commander "0.6.1")
    (espuds "0.2.2")
    (ansi "0.3.0")
    (dash "2.2.0")
    (s "1.8.0")
    (f "0.11.0"))
  :commit "f13723e0d7c2abbcb7a870091201ec80103bf202")
;; Local Variables:
;; no-byte-compile: t
;; End:
