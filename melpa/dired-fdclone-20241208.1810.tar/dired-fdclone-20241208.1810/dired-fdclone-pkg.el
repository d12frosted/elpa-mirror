;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-fdclone" "20241208.1810"
  "Dired functions and settings to mimic FD/FDclone."
  '((emacs "28.1"))
  :url "https://github.com/knu/dired-fdclone.el"
  :commit "e234c0bf91649bd13de984f6ef1b2354565fd4ce"
  :revdesc "e234c0bf9164"
  :keywords '("unix" "directories" "dired")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
