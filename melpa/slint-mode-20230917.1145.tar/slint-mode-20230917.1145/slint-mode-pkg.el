(define-package "slint-mode" "20230917.1145" "Major-mode for the Slint UI language"
  '((emacs "24.4")
    (lsp-mode "6.0"))
  :commit "2859f20bbc5ba2d193af1223b37669f87ac5853d" :authors
  '(("Niklas Cathor" . "niklas.cathor@gmx.de"))
  :maintainers
  '(("Niklas Cathor" . "niklas.cathor@gmx.de"))
  :maintainer
  '("Niklas Cathor" . "niklas.cathor@gmx.de")
  :keywords
  '("languages")
  :url "https://github.com/nilclass/slint-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
