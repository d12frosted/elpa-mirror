;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sketch-themes" "20230210.1507"
  "Sketch color themes."
  '((emacs "26.1"))
  :url "https://github.com/dawranliou/sketch-themes/"
  :commit "5534254232f1a556ec20952c75b5506625573049"
  :revdesc "5534254232f1"
  :keywords '("faces")
  :authors '(("Daw-Ran Liou" . "hi@dawranliou.com"))
  :maintainers '(("Daw-Ran Liou" . "hi@dawranliou.com")))
