;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261006.2204"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "3a572193bcf78f226126ca83efac8f8b82e9e612"
  :revdesc "3a572193bcf7"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
