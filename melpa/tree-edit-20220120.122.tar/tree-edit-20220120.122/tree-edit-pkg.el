(define-package "tree-edit" "20220120.122" "A library for structural refactoring and editing"
  '((emacs "27.1")
    (tree-sitter "0.15.0")
    (tsc "0.15.0")
    (tree-sitter-langs "0.10.0")
    (dash "2.19")
    (reazon "0.4.0")
    (s "0.0.0"))
  :commit "ad5d3c5060d8cf43d2053c2bc74b0beda1e664a1" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
