(define-package "lsp-mssql" "20230316.1612" "MSSQL LSP bindings"
  '((emacs "25.1")
    (lsp-mode "6.2")
    (dash "2.14.1")
    (f "0.20.0")
    (ht "2.0")
    (lsp-treemacs "0.1"))
  :commit "9d9a14a2b40c5fd13b8e33fccd397283a2437526" :authors
  '(("Ivan Yonchovski" . "yyoncho@gmail.com"))
  :maintainer
  '("Ivan Yonchovski" . "yyoncho@gmail.com")
  :keywords
  '("data" "languages")
  :url "https://github.com/emacs-lsp/lsp-mssql")
;; Local Variables:
;; no-byte-compile: t
;; End:
