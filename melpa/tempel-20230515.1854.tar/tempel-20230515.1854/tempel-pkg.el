(define-package "tempel" "20230515.1854" "Tempo templates/snippets with in-buffer field editing"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "7a6a95825d55df868a869cbbc80412fb44f6520b" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "languages" "tools" "wp")
  :url "https://github.com/minad/tempel")
;; Local Variables:
;; no-byte-compile: t
;; End:
