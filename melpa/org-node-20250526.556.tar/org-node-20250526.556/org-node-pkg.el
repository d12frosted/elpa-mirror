;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250526.556"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "434f0c888cbec7cf49698e72d932a2fc6d259fcd"
  :revdesc "434f0c888cbe"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
