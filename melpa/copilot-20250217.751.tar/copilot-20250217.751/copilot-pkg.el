;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20250217.751"
  "An unofficial Copilot plugin."
  '((emacs        "27.2")
    (s            "1.12.0")
    (dash         "2.19.1")
    (editorconfig "0.8.2")
    (jsonrpc      "1.0.14")
    (f            "0.20.0"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "6fc7307fa32d01e4a96f7c96b26dfec78ee2a866"
  :revdesc "6fc7307fa32d"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Rakotomandimby Mihamina" . "mihamina.rakotomandimby@rktmb.org")))
