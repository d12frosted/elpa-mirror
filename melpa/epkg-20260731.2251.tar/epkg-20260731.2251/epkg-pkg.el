;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260731.2251"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "a94d4b0ff889c20f059b9ac9848369741d115a96"
  :revdesc "a94d4b0ff889"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
