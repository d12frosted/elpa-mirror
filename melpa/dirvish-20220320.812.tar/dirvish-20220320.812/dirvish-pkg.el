(define-package "dirvish" "20220320.812" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "ef6451b43b92909f699bf3bd574749f5388b90cf" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
