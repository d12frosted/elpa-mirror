(define-package "dirvish" "20220320.812" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "4a49926f4e736c740048788561cdf348d4a5c79b" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
