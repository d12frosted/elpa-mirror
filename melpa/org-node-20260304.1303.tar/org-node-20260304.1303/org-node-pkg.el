;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260304.1303"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.34.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "81143f30e50df4bc85c6c738858da477020b5b98"
  :revdesc "81143f30e50d"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
