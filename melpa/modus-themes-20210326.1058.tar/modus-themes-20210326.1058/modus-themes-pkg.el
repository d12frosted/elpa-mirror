(define-package "modus-themes" "20210326.1058" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "556fc264571c53d9e87ad83a52eec596f58e3c2e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
