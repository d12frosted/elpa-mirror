;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250317.1027"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "268102c786bf41f6f20e62cc69545e9b5c250b44"
  :revdesc "268102c786bf"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
