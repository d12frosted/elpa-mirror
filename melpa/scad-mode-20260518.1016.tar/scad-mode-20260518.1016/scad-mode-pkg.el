;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "20260518.1016"
  "A major mode for editing OpenSCAD code."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "860621f05563c0694c0ef105d0a35cb74ee71570"
  :revdesc "860621f05563"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
