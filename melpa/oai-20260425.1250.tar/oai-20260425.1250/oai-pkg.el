;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260425.1250"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "182792d0a8fa3d9fd9e9d238f76c7c54519299ce"
  :revdesc "182792d0a8fa"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
