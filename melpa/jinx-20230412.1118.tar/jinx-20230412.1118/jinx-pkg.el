(define-package "jinx" "20230412.1118" "Enchanted Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "6d9c285c35ca1c6b3145983132ca484e10fa0fb1" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "wp")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
