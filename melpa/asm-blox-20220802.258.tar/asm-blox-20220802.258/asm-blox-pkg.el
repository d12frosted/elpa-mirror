(define-package "asm-blox" "20220802.258" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "dd43e800096066a8472db630a2af411de770e3ac" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
