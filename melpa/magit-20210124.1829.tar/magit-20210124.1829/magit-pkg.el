(define-package "magit" "20210124.1829" "A Git porcelain inside Emacs."
  '((emacs "25.1")
    (dash "20200524")
    (git-commit "20200516")
    (transient "20200601")
    (with-editor "20200522"))
  :commit "59a87436bd8443e55d28f43bc396ec740aab20b3" :authors
  '(("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
