;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sexy-theme" "20260708.327"
  "A strong colors variant of the Gruber Darker theme."
  '((emacs "24.1"))
  :url "https://github.com/bgcicca/sexy-theme.el"
  :commit "eb747facb5916d8cbcac3e5d086317ce5e1ff341"
  :revdesc "eb747facb591"
  :authors '(("Bruno Ciccarino" . "brunociccarinoo@gmail.com"))
  :maintainers '(("Bruno Ciccarino" . "brunociccarinoo@gmail.com")))
