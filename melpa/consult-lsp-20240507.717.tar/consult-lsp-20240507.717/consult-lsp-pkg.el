(define-package "consult-lsp" "20240507.717" "LSP-mode Consult integration"
  '((emacs "27.1")
    (lsp-mode "5.0")
    (consult "0.16")
    (f "0.20.0"))
  :commit "431fc60fc69c77745717507acd277571633324c4" :authors
  '(("Gerry Agbobada"))
  :maintainers
  '(("Gerry Agbobada"))
  :maintainer
  '("Gerry Agbobada")
  :keywords
  '("tools" "completion" "lsp")
  :url "https://github.com/gagbo/consult-lsp")
;; Local Variables:
;; no-byte-compile: t
;; End:
