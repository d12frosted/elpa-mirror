;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250522.2114"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.76.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "444550abd3a95bd4553a850f392cd259e3f773c0"
  :revdesc "444550abd3a9")
