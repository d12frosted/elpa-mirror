;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261025.812"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "d78c6013272bded1228be6678b4bfa18e2e1b822"
  :revdesc "d78c6013272b"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
