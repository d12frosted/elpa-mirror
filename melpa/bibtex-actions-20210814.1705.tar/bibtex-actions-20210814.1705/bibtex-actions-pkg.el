(define-package "bibtex-actions" "20210814.1705" "Biblographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0"))
  :commit "22136167a110c88c9cdbe89cd19abfc94f4788e8" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
