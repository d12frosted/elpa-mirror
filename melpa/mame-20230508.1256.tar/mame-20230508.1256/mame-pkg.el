(define-package "mame" "20230508.1256" "A MAME front-end"
  '((emacs "27.1"))
  :commit "a5f05f2b9218979c52f42718b29fc58d80a58daf" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
