;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20241205.1522"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "3abd2afda2e82f6a1e8328a093add8c6f885cee9"
  :revdesc "3abd2afda2e8"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
