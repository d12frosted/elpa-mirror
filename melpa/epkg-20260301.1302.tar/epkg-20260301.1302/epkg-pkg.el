;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260301.1302"
  "Browse the Emacsmirror package database."
  '((emacs   "28.1")
    (compat  "30.1")
    (closql  "2.4")
    (emacsql "4.3")
    (llama   "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "fc3cba38a416ec4e26a7d8eb7bc5ee910e67aa73"
  :revdesc "fc3cba38a416"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
