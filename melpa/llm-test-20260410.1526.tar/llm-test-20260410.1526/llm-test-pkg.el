;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260410.1526"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "a3ff5f0b8c7bff27ebbe49c700fc0a07390601da"
  :revdesc "a3ff5f0b8c7b"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
