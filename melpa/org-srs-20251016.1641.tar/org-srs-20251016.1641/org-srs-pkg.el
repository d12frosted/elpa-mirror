;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251016.1641"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "8a96c6ce6e453caf49d96732c7dfe59e86c33aca"
  :revdesc "8a96c6ce6e45"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
