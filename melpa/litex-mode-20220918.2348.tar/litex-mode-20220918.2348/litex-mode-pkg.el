(define-package "litex-mode" "20220918.2348" "Minor mode for converting lisp to LaTeX"
  '((emacs "24.4")
    (units-mode "0.1.1"))
  :commit "966aa25af6b4268d20d35f1338753bfa93df01d4" :authors
  '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainer
  '("Gaurav Atreya" . "allmanpride@gmail.com")
  :keywords
  '("calculator" "lisp" "latex")
  :url "https://github.com/Atreyagaurav/litex-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
