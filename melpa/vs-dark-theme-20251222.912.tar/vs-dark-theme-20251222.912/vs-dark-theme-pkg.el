;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-dark-theme" "20251222.912"
  "Visual Studio IDE dark theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-dark-theme"
  :commit "f2ce0e490b7fd939aea3700a67247fa934209396"
  :revdesc "f2ce0e490b7f"
  :keywords '("faces"))
