(define-package "osm" "20220511.1756" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "471f21f0f8bffc078d5ccfd86610a83e5269c2a0" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
