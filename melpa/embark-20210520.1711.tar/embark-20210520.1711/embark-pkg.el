(define-package "embark" "20210520.1711" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "973d3247d1ee812bd2e3569e015afd7d2ad786f9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
