(define-package "php-mode" "20220908.216" "Major mode for editing PHP code"
  '((emacs "25.2"))
  :commit "6d6b5a66a4546381c3cfe39221ae06ef787aa623" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
