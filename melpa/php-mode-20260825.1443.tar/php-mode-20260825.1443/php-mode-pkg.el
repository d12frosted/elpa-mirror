;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20260825.1443"
  "Major mode for editing PHP code."
  '((emacs "28.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "a348c078aff1210c1e73bd058e963e1a3b5a2dee"
  :revdesc "a348c078aff1"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
