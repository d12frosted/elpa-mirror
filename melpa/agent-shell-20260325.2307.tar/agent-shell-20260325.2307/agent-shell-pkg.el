;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260325.2307"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "68ce6b5cd51cb0f07c3849767cf6455edb8fb992"
  :revdesc "68ce6b5cd51c")
