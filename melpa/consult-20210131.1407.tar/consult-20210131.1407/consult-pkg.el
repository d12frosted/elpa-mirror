(define-package "consult" "20210131.1407" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "d729ef00b72d5a43e4c573b29a5ead12f1c04ca8" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
