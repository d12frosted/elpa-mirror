(define-package "chezmoi" "20230106.1716" "A package for interacting with chezmoi"
  '((emacs "26.1"))
  :commit "0578f81ab01f5280e6c68d7a8a70ae4b4ba29755" :authors
  '(("Harrison Pielke-Lombardo"))
  :maintainer
  '("Harrison Pielke-Lombardo")
  :keywords
  '("vc")
  :url "http://www.github.com/tuh8888/chezmoi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
