(define-package "embark" "20211009.1551" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d01dc194fa05b464f36a48f08ff3ec29041e6fd2" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
