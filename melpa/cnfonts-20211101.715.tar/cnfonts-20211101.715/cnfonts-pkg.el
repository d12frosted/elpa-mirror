(define-package "cnfonts" "20211101.715" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "847f0a7584ca947583d32eb9c2f27d647025862f" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
