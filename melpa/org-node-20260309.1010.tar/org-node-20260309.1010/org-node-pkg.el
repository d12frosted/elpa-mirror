;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260309.1010"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.34.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "dbf40e11a6ab270bf5da0bfe1b2552398a2cf585"
  :revdesc "dbf40e11a6ab"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
