(define-package "osm" "20230518.1534" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "6df17a6a84a242e3a9a45a0677fe6a0fc42657c2" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
