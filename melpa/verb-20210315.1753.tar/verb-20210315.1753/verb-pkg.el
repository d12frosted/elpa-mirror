(define-package "verb" "20210315.1753" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "9c5e9baf43388d5a69ea2fb216d9936628b36a84" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
