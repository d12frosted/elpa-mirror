;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "20260507.2233"
  "A set of eye pleasing themes."
  '((emacs      "25.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "a1b77c2630705e04762a9419f04184cf0e60191a"
  :revdesc "a1b77c263070"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
