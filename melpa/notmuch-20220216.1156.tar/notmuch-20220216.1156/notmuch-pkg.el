(define-package "notmuch" "20220216.1156" "run notmuch within emacs" 'nil :commit "6286b76a69f11a72927c96a928d4493cab2237ce" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
