(define-package "notmuch" "20220216.1156" "run notmuch within emacs" 'nil :commit "999706c4d506f77fcef2a3d5d1c6bfe65c8db791" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
