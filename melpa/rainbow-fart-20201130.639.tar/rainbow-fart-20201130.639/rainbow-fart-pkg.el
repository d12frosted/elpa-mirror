(define-package "rainbow-fart" "20201130.639" "Checks the keywords of code to play suitable sounds"
  '((emacs "25.1")
    (flycheck "32snapshot"))
  :commit "fe5b01ec36bc5db7f578ba94593ac92fd653ea5e" :keywords
  ("tools")
  :url "https://github.com/stardiviner/emacs-rainbow-fart")
;; Local Variables:
;; no-byte-compile: t
;; End:
