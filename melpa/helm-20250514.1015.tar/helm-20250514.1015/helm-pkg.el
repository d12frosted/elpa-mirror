;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250514.1015"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.3")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "063fe595ace5dd008cf2cbbfc27b90f7752c44dd"
  :revdesc "063fe595ace5"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
