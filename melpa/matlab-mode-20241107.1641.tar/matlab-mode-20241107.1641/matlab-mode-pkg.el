;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241107.1641"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "48e56cc22d227d468ecfbb03ca8e427e975e6915"
  :revdesc "48e56cc22d22"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")))
