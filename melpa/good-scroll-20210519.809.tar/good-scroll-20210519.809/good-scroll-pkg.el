(define-package "good-scroll" "20210519.809" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "c72aa45b69025c2ee2c62eeccdaf15117cffe10d" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
