;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260209.1821"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "20d397d33561d65ed2063c455e0e76ac2a081bc8"
  :revdesc "20d397d33561"
  :keywords '("convenience"))
