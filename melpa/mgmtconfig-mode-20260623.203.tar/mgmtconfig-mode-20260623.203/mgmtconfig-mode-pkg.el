;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mgmtconfig-mode" "20260623.203"
  "Mgmt configuration management language."
  '((emacs "24.3"))
  :url "https://github.com/purpleidea/mgmt/misc/emacs"
  :commit "0f7ad93cd17e5251c6ec112fa6ff4272499b430a"
  :revdesc "0f7ad93cd17e"
  :keywords '("languages")
  :authors '(("Peter Oliver" . "mgmtconfig@mavit.org.uk"))
  :maintainers '(("Mgmt contributors" . "https://github.com/purpleidea/mgmt")))
