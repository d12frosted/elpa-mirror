(define-package "cybercafe-theme" "20230915.1506" "Cybercafe color theme"
  '((emacs "24.1"))
  :commit "b23fa2baf039ad863c35d37b34c5376e18db68ef" :authors
  '((nil . "Gabriel de Brito gabrielgbrito@icloud.com"))
  :maintainers
  '((nil . "Gabriel de Brito gabrielgbrito@icloud.com"))
  :maintainer
  '(nil . "Gabriel de Brito gabrielgbrito@icloud.com")
  :keywords
  '("faces")
  :url "http://github.com/gboncoffee/cybercafe-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
