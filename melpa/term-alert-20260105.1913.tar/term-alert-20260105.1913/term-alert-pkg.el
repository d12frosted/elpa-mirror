;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-alert" "20260105.1913"
  "Notifications when commands complete in term.el and eat."
  '((emacs    "24.0")
    (term-cmd "1.1")
    (alert    "1.1")
    (f        "0.18.2"))
  :url "https://github.com/calliecameron/term-alert"
  :commit "d2eea58abe95de009e9c8ed3f814bd0dce2a5e2f"
  :revdesc "d2eea58abe95"
  :keywords '("notifications" "processes")
  :authors '(("Callie Cameron" . "cjcameron7@gmail.com"))
  :maintainers '(("Callie Cameron" . "cjcameron7@gmail.com")))
