;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-cmd" "20260117.1350"
  "Send commands from programs running in term.el."
  '((emacs "27.2")
    (dash  "2.12.0")
    (f     "0.18.2"))
  :url "https://github.com/calliecameron/term-cmd"
  :commit "0596a96b0e5a4e8a5f828951fb6e2c1af03914c8"
  :revdesc "0596a96b0e5a"
  :keywords '("processes")
  :authors '(("Callie Cameron" . "cjcameron7@gmail.com"))
  :maintainers '(("Callie Cameron" . "cjcameron7@gmail.com")))
