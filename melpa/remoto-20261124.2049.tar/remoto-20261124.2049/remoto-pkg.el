;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261124.2049"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "cd8ec5d083091ad164f8260a6bd05453e5dd73db"
  :revdesc "cd8ec5d08309"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
