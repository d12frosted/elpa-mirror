(define-package "affe" "20210809.1920" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.7"))
  :commit "2cddfff2018d8635f8ec9bd018322ccf6769ea37" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
