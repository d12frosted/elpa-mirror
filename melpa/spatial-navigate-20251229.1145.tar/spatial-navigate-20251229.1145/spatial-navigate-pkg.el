;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-navigate" "20251229.1145"
  "Directional navigation between blank-space blocks."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spatial-navigate"
  :commit "9f61d3894c2f77b5fafa3f3529a39cb29cd67bc7"
  :revdesc "9f61d3894c2f"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
