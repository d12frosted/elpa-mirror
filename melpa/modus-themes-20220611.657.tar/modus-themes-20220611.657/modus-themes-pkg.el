(define-package "modus-themes" "20220611.657" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "5d68eda0965caa159630901669a7b8ca42d712e7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
