;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "datetime-format" "20240105.1901"
  "Datetime functions."
  '((emacs "26.3"))
  :url "https://github.com/emacs-php/emacs-datetime"
  :commit "c4ee8ef11bc95c78c390497f1d1397ca57a96f97"
  :revdesc "c4ee8ef11bc9"
  :keywords '("lisp" "datetime" "calendar")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
