;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clean-kill-ring" "20250922.1649"
  "Keep the kill ring clean."
  '((emacs "24.4"))
  :url "http://github.com/NicholasBHubbard/clean-kill-ring.el"
  :commit "44c3fa45e74d1d7dd26cc92cc4c15880bd27b4d7"
  :revdesc "44c3fa45e74d"
  :keywords '("kill-ring" "convenience")
  :authors '(("Nicholas Hubbard" . "nicholashubbard@posteo.net"))
  :maintainers '(("Nicholas Hubbard" . "nicholashubbard@posteo.net")))
