(define-package "meow" "20230928.629" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "b47d1fa88fc3b06b9f70e4c8657a8f10f216a226" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
