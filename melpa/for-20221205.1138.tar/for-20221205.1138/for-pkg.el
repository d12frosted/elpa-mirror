(define-package "for" "20221205.1138" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "f2820b0a73c76d2ed1734f73991cc83baac7be52" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
