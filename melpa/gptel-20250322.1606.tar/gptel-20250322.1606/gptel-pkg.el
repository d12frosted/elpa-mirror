;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250322.1606"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "075376c002d0f0c50e68ffd23c647eeab27fea73"
  :revdesc "075376c002d0"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
