(define-package "consult" "20230128.820" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "7989642a2bdc830e1b3de8cfeb479f329bc7d4c9" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
