;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260605.1307"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "f16d727da6c5fd4d1ba195eb75322208333b9987"
  :revdesc "f16d727da6c5"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
