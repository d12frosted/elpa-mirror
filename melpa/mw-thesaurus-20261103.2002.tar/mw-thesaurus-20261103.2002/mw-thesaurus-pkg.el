;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mw-thesaurus" "20261103.2002"
  "Merriam-Webster Thesaurus and Dictionary."
  '((emacs "27.1"))
  :url "https://github.com/agzam/mw-thesaurus.el"
  :commit "3d70e0f4addece03afa9b5250659464936e0e467"
  :revdesc "3d70e0f4adde"
  :keywords '("wp" "matching")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
