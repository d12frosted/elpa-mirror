(define-package "consult" "20210221.1019" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "600ace35bd488206f97bb9e5d3ac4e850e16c29b" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
