;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-img" "20151224.2321"
  "Utilities for making image sources for helm."
  '((helm   "1.7.7")
    (cl-lib "0.5"))
  :url "https://github.com/l3msh0/helm-img"
  :commit "aa3f8a5dce8d0413bf07584f07153a39015c2bfc"
  :revdesc "aa3f8a5dce8d"
  :keywords '("convenience")
  :authors '(("Sho Matsumoto" . "l3msh0_at_gmail.com")))
