;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260604.736"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7531b41fa36c3ab6ab31f384443b36f7bd044f71"
  :revdesc "7531b41fa36c")
