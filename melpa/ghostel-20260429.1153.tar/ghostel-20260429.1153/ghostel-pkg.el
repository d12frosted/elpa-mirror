;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260429.1153"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "6437e5b5dd08dcbc9822413e8dd6a7966019bace"
  :revdesc "6437e5b5dd08"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
