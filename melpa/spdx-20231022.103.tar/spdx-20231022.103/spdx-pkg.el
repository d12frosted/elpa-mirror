(define-package "spdx" "20231022.103" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "e930e89a87f15cfba3f7cc61a287a9044e2cd652" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
