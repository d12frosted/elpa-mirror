(define-package "merlin" "20220502.811" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "49324b4fdc14987164ed7a3a8c3681df5b4866ee" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
