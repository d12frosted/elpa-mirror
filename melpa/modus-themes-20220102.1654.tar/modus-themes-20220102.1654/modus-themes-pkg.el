(define-package "modus-themes" "20220102.1654" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "c25c8dcc779476e8695d7f02055c9fb433d3fb08" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
