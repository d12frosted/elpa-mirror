(define-package "transient" "20240713.1929" "Transient commands"
  '((emacs "26.1")
    (compat "30.0.0.0")
    (seq "2.24"))
  :commit "ed732cb35f6a6753930df10a0f66a6e4efd29e6d" :authors
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
