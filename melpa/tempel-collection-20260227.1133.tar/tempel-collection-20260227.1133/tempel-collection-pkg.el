;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel-collection" "20260227.1133"
  "Collection of templates for Tempel."
  '((tempel "0.5")
    (emacs  "29.1"))
  :url "https://github.com/Crandel/tempel-collection"
  :commit "6292604c1d5ed0044ce0beb2d46c73697dc66ed3"
  :revdesc "6292604c1d5e"
  :keywords '("tools")
  :authors '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
             ("Max Penet" . "mpenetr@s-exp.com")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
                 ("Max Penet" . "mpenetr@s-exp.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
