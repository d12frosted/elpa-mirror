;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solo-rpg" "20260309.1904"
  "Solo roleplaying games support functions."
  '((emacs     "27.1")
    (transient "0.3.7"))
  :url "https://github.com/enfors/solo-rpg"
  :commit "cfad9f7cd76393932591d89d899e7749428c3b9c"
  :revdesc "cfad9f7cd763"
  :keywords '("games")
  :authors '(("Christer Enfors" . "christer.enfors@gmail.com"))
  :maintainers '(("Christer Enfors" . "christer.enfors@gmail.com")))
