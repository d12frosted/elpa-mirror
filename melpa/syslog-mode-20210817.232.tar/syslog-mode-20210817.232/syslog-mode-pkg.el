(define-package "syslog-mode" "20210817.232" "Major-mode for viewing log files"
  '((hide-lines "20130623")
    (ov "20150311"))
  :commit "136025d372c8fe8b410e4a4b8c56ac08a8e652c6" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
