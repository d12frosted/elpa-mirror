;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260507.2016"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "5d2ca0237635a2ee6f34dd41bc291ee973d1a608"
  :revdesc "5d2ca0237635"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
