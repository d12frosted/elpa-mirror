(define-package "darktooth-theme" "20220817.1429" "From the darkness... it watches"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "980071d47c8577613e8777d9290919d0a09700dc" :url "http://github.com/emacsfodder/emacs-theme-darktooth")
;; Local Variables:
;; no-byte-compile: t
;; End:
