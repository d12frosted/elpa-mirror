(define-package "ivy-erlang-complete" "20191112.1137" "Erlang context sensitive completion at point using ivy. It also support xref and eldoc."
  '((async "1.9")
    (counsel "0.11.0")
    (ivy "0.11.0")
    (erlang "19.2")
    (emacs "25.1"))
  :commit "7d60ed111dbfd34ab6ec1b07c06e2d16a5380b9a" :authors
  '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainer
  '("Sergey Kostyaev" . "feo.me@ya.ru")
  :keywords
  '("languages" "tools"))
;; Local Variables:
;; no-byte-compile: t
;; End:
