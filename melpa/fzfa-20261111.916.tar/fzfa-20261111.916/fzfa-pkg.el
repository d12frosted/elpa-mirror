;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20261111.916"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "3.4"))
  :url "https://github.com/jojojames/fzfa"
  :commit "49b97f1f9f0b5fb390511e6da4693fb0f59f254c"
  :revdesc "49b97f1f9f0b"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
