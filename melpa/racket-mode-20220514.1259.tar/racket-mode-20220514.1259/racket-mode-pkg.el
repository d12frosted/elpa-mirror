(define-package "racket-mode" "20220514.1259" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "47d3dd954dc997198af468b6bbee06c80aa86264" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
