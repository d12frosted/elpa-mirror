(define-package "geiser" "20220127.2354" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3"))
  :commit "d89fb1f66e125973c1596ad5cb00a46ea7ce9c52" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
