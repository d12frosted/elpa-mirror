;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260226.1527"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "2b2d153c758976cff824c04fc7431d0bddb8816a"
  :revdesc "2b2d153c7589"
  :keywords '("hypermedia"))
