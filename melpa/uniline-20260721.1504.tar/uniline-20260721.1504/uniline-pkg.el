;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260721.1504"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "dc31332675769a789da879608276ec7e5b964865"
  :revdesc "dc3133267576"
  :keywords '("convenience" "text"))
