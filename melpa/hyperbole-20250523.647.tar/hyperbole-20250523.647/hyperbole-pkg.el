;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250523.647"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "8eaf97e901ab88704d8266daaf0a67309ba23850"
  :revdesc "8eaf97e901ab"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
