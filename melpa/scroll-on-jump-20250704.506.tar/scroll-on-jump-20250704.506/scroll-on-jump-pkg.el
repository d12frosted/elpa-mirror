;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scroll-on-jump" "20250704.506"
  "Scroll when jumping to a new point."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-scroll-on-jump"
  :commit "89230f620b4f57ed0799fc3f576dc569566d375b"
  :revdesc "89230f620b4f"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
