;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-thumbnail" "20260712.2348"
  "Utility package to provide media icons."
  '((emacs "28.1"))
  :url "https://github.com/jojojames/media-thumbnail"
  :commit "4cb8075ec8bc46408a6b01fc8877571d8e66e439"
  :revdesc "4cb8075ec8bc"
  :keywords '("files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
