;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260330.1305"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "40b67aa2930a6daf70cb315fa2a8439993d0a3f5"
  :revdesc "40b67aa2930a"
  :keywords '("languages"))
