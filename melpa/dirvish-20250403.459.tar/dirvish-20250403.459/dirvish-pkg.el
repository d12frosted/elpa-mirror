;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250403.459"
  "A modern file manager based on dired mode."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "7011a0fbff90c09285cf86905a0ca009d43708f9"
  :revdesc "7011a0fbff90"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
