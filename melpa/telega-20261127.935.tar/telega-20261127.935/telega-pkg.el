;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20261127.935"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "d1682e179cf3ee35a5ede7fce693d4a51640b56c"
  :revdesc "d1682e179cf3"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
