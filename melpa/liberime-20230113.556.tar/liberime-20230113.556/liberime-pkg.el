(define-package "liberime" "20230113.556" "Rime elisp binding"
  '((emacs "25.1"))
  :commit "cc9eb9812fd6f68e78ed6a0c0a85da7a18765753" :authors
  '(("A.I."))
  :maintainer
  '("A.I.")
  :keywords
  '("convenience" "chinese" "input-method" "rime")
  :url "https://github.com/merrickluo/liberime")
;; Local Variables:
;; no-byte-compile: t
;; End:
