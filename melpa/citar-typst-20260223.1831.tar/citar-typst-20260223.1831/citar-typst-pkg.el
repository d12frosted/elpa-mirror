;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-typst" "20260223.1831"
  "Typst support for citar."
  '((emacs "29.1")
    (citar "1.4"))
  :url "https://codeberg.org/ashton314/citar-typst"
  :commit "c1be8d4faf626d348505484463fd1506173ccaa2"
  :revdesc "c1be8d4faf62"
  :authors '(("Ashton Wiersdorf" . "https://lambdaland.org/"))
  :maintainers '(("Ashton Wiersdorf" . "https://lambdaland.org/")))
