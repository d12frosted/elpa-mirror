;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark" "20260605.553"
  "Conveniently act on minibuffer completions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/oantolin/embark"
  :commit "557d933f3a53dbccc750cfbe70c38ad6a17ac866"
  :revdesc "557d933f3a53"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
