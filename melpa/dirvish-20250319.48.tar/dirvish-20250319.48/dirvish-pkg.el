;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250319.48"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "250768fa040293b04fc74149cc253d3c243a5f7e"
  :revdesc "250768fa0402"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
