;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "age" "20260919.1901"
  "The Age Encryption Library."
  '((emacs "28.1"))
  :url "https://github.com/anticomputer/age.el"
  :commit "afe3bf43fab7ff988419762f851129048c396ccc"
  :revdesc "afe3bf43fab7"
  :keywords '("data")
  :authors '(("Daiki Ueno" . "ueno@unixuser.org")
             ("Bas Alberts" . "bas@anti.computer"))
  :maintainers '(("Bas Alberts" . "bas@anti.computer")))
