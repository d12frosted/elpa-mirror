;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20250214.1034"
  "Copilot chat interface."
  '((request       "0.3.2")
    (markdown-mode "2.6")
    (emacs         "27.1")
    (magit         "4.0.0")
    (transient     "0.8.3")
    (org           "9.4.6")
    (polymode      "0.2.2"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "b62cf38cfee68e0dfe4c0bc73be6cdcbeb4f101a"
  :revdesc "b62cf38cfee6"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
