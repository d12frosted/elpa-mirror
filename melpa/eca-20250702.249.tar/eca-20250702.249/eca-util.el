;;; eca-util.el --- ECA (Editor Code Assistant) util -*- lexical-binding: t; -*-
;; Copyright (C) 2025 Eric Dallo
;;
;; SPDX-License-Identifier: Apache-2.0
;;
;; This file is not part of GNU Emacs.
;;
;;; Commentary:
;;
;;  The ECA (Editor Code Assistant) utils.
;;
;;; Code:

(require 'cl-lib)
(require 'vc-git)
(require 'dash)

(defun eca-assoc (map key val)
  "Return a new MAP with KEY associated to flat plist VAL, replacing any existing."
  (cons (cons key val)
        (cl-remove-if (lambda (pair) (equal (car pair) key)) map)))

(defun eca-get (map key)
  "Return the plist value associated with KEY in MAP, or nil."
  (let ((pair (cl-find key map :key #'car :test #'equal)))
    (when pair (cdr pair))))

(defun eca-vals (map)
  "Return the plist values from MAP."
  (-map #'cdr map))

(defun eca--project-root ()
  "Get the project root using git falling back to file directory."
  (-some-> (or (vc-git-root default-directory)
               (when buffer-file-name (file-name-directory buffer-file-name))
               default-directory)
    (file-truename)))

(defvar eca--session nil)

(cl-defstruct eca--session
  ;; The status of this session
  (status 'stopped)

  ;; The eca <process>
  (process nil)

  ;; the chat buffer
  (chat nil)

  ;; A list of workspace folders of this session
  (workspace-folders '())

  ;; A plist of request method names (strings) -> handlers used when
  ;; receiving requests from server.
  (request-handlers '())

  ;; A plist of client request ids -> handlers for pending requests used when
  ;; receiving responses from server.
  (response-handlers '())

  ;; The suported models by the server.
  (models '())

  ;; The mcp servers and their status.
  (mcp-servers '())

  ;; Default model to use in the chat returned by server.
  (chat-default-model nil)

  ;; The supported chat behaviors by the server.
  (chat-behaviors nil)

  ;; Default behavior to use in the chat returned by server.
  (chat-default-behavior nil)

  ;; The welcome message for new chats.
  (chat-welcome-message ""))

(defun eca-create-session ()
  "Create a new ECA session."
  (let ((session (make-eca--session)))
    (setf (eca--session-workspace-folders session) (list (eca--project-root)))
    session))

(defun eca-assert-session-running ()
  "Assert that a eca session is running."
  (unless eca--session
    (user-error "ECA must be running, start with `eca` command")))

(defun eca--path-to-uri (path)
  "Convert a PATH to a uri."
  (concat "file://"
          (--> path
               (expand-file-name it)
               (or (file-remote-p it 'localname t) it))))

(defun eca-info (format &rest args)
  "Display eca info message with FORMAT with ARGS."
  (message "%s :: %s" (propertize "ECA" 'face 'success) (apply #'format format args)))

(defun eca-warn (format &rest args)
  "Display eca warn message with FORMAT with ARGS."
  (message "%s :: %s" (propertize "ECA" 'face 'warning) (apply #'format format args)))

(defun eca-error (format &rest args)
  "Display eca error message with FORMAT with ARGS."
  (message "%s :: %s" (propertize "ECA" 'face 'error) (apply #'format format args)))

(provide 'eca-util)
;;; eca-util.el ends here
