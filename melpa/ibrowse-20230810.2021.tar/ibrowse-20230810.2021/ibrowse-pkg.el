(define-package "ibrowse" "20230810.2021" "Interact with your browser"
  '((emacs "27.1"))
  :commit "d04fde7321db23421935065274d6f3dee7447194" :authors
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainers
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainer
  '("Nicolas Graves" . "ngraves@ngraves.fr")
  :keywords
  '("comm" "data" "files" "tools")
  :url "https://git.sr.ht/~ngraves/ibrowse.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
