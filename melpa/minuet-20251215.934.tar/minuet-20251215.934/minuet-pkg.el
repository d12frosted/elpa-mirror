;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20251215.934"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "a38179d42dca9c4c49ac01cd64710880db335790"
  :revdesc "a38179d42dca"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
