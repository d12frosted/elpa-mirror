;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260826.244"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "2286cab28317283f1aa54a59cd4bbfcad106c50b"
  :revdesc "2286cab28317"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
