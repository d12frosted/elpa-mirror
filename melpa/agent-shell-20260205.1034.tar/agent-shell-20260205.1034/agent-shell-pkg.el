;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260205.1034"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4897b7fd458f93f9d6aad0bee834941970a7ff22"
  :revdesc "4897b7fd458f")
