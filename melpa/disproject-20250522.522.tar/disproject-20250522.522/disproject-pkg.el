;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20250522.522"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.8.0"))
  :url "https://github.com/aurtzy/disproject"
  :commit "217582ca034478659e6a46a833fe1f9dc4e6e9c2"
  :revdesc "217582ca0344"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
