;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250527.350"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "20250520.1040")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "cf961cedd6e678dfd7eb227b000e57001d026989"
  :revdesc "cf961cedd6e6"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
