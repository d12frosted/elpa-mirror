;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260330.1617"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "ac48b135793fc323af0c05bf83d7f0ccd7159852"
  :revdesc "ac48b135793f"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
