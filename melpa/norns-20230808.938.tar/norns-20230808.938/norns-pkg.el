(define-package "norns" "20230808.938" "Interactive development environment for monome norns"
  '((emacs "27.1")
    (dash "2.17.0")
    (s "1.12.0")
    (f "0.20.0")
    (request "0.3.2")
    (websocket "1.13")
    (lua-mode "20221218.605"))
  :commit "da737848883152782abc746a197ce6fd3d371ef2" :keywords
  '("processes" "terminals")
  :url "https://github.com/p3r7/norns.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
