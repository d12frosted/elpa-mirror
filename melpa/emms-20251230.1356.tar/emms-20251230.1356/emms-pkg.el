;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "20251230.1356"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://www.gnu.org/software/emms/"
  :commit "47c68835b213e79c3651b81a6579a114d2450a52"
  :revdesc "47c68835b213"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
