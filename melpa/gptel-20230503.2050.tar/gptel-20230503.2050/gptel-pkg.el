(define-package "gptel" "20230503.2050" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "422eba80488e795816b7539a05c6dc4ba102fc95" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
