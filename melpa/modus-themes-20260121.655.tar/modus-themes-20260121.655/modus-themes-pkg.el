;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260121.655"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "55be658ddf4c6a7f537d8161343ff17611852a64"
  :revdesc "55be658ddf4c"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
