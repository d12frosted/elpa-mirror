;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-deps-new" "20230413.1833"
  "Create clojure projects from templates."
  '((emacs     "25.1")
    (transient "0.3.7"))
  :url "https://github.com/jpe90/emacs-deps-new"
  :commit "72f25d86bbd9cd6cb4aa431e70bda38f35b19262"
  :revdesc "72f25d86bbd9"
  :authors '(("jpe90" . "eskinjp@gmail.com"))
  :maintainers '(("jpe90" . "eskinjp@gmail.com")))
