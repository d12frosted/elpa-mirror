;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250514.1015"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "063fe595ace5dd008cf2cbbfc27b90f7752c44dd"
  :revdesc "063fe595ace5"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
