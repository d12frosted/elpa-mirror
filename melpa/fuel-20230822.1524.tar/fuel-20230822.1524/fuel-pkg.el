(define-package "fuel" "20230822.1524" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9c54c00ebd2d7a81b6532d63c14939f2d5cb730e")
;; Local Variables:
;; no-byte-compile: t
;; End:
