;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260429.2217"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f25fd7566b7da4a5e94c98becc9de279b01323c5"
  :revdesc "f25fd7566b7d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
