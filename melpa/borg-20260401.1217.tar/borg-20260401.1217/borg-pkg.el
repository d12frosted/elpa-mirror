;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260401.1217"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "8d0e26e6c16c1e503785b3e6b62a9a6d55b4e472"
  :revdesc "8d0e26e6c16c"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
