;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260810.404"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "97c4f7fafa5599f781454b1d41861514efa0425e"
  :revdesc "97c4f7fafa55"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
