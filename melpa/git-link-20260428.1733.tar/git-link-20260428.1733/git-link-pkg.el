;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-link" "20260428.1733"
  "Get the GitHub/Bitbucket/GitLab URL for a buffer location."
  '((emacs "24.3"))
  :url "https://github.com/sshaw/git-link"
  :commit "a5764b1d402dc398ecf404635267cb0b7d230c10"
  :revdesc "a5764b1d402d"
  :keywords '("git" "vc" "github" "bitbucket" "gitlab" "sourcehut" "aws" "azure" "convenience")
  :authors '(("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainers '(("Skye Shaw" . "skye.shaw@gmail.com")))
