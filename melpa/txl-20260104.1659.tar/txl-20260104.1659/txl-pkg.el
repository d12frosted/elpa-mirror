;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "txl" "20260104.1659"
  "Provides machine translation via DeepL's REST API."
  '((request        "0.3.2")
    (guess-language "0.0.1")
    (emacs          "24.4"))
  :url "https://github.com/tmalsburg/txl.el"
  :commit "e368746afba6d8ec170f479d06a10c4e2a9e2eee"
  :revdesc "e368746afba6"
  :keywords '("wp")
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
