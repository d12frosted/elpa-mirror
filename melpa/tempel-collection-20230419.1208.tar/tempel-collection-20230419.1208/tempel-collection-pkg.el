(define-package "tempel-collection" "20230419.1208" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "4e2c054d25a514db771b6e146a4d8da0853327c8" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
