(define-package "modaled" "20230612.255" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "6185171ddf51a877604002047dcd662cf58c9242" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
