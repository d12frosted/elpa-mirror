(define-package "impatient-showdown" "20200914.221" "Preview markdown buffer live over HTTP using showdown"
  '((emacs "24.3")
    (impatient-mode "1.1"))
  :commit "b70eb25f854ccc1f6f05d79f438095de4ca1b93e" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/impatient-showdown")
;; Local Variables:
;; no-byte-compile: t
;; End:
