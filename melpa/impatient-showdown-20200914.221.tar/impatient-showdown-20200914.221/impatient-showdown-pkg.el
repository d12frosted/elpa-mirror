(define-package "impatient-showdown" "20200914.221" "Preview markdown buffer live over HTTP using showdown"
  '((emacs "24.3")
    (impatient-mode "1.1"))
  :commit "6825147ebacb1d738b1c96baf0534a5ed3e6b289" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/impatient-showdown")
;; Local Variables:
;; no-byte-compile: t
;; End:
