(define-package "modus-themes" "20220905.257" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "845a8bfd7b9f972e5cdf1eb397d3392b8180688a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
