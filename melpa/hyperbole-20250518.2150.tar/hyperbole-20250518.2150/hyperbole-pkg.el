;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250518.2150"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "2e4857aef4957eb4e1967c09b199385540c52d27"
  :revdesc "2e4857aef495"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
