(define-package "el-get" "20200912.1653" "Manage the external elisp bits and pieces you depend upon" 'nil :commit "4183ac0d68e0d02298a77583ab31bcba3aef4332" :authors
  (("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainer
  ("Dimitri Fontaine" . "dim@tapoueh.org")
  :keywords
  ("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :url "http://www.emacswiki.org/emacs/el-get")
;; Local Variables:
;; no-byte-compile: t
;; End:
