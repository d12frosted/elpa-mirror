(define-package "dwim-shell-command" "20220818.739" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "1ee5004ee33ff94f7141210745bfc99e9986f734" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
