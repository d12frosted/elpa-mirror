(define-package "basic-mode" "20230902.1556" "Major mode for editing BASIC code"
  '((seq "2.20")
    (emacs "25.1"))
  :commit "d9a161a5c151509d53ea88f869cc62dfe38efbb2" :authors
  '(("Johan Dykstrom"))
  :maintainers
  '(("Johan Dykstrom"))
  :maintainer
  '("Johan Dykstrom")
  :keywords
  '("basic" "languages")
  :url "https://github.com/dykstrom/basic-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
