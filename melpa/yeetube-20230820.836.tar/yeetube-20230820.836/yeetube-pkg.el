(define-package "yeetube" "20230820.836" "YouTube & Invidious Front End"
  '((emacs "27.2"))
  :commit "a81f261a9c4b9d5ec2ece2cf635aca3b3d030010" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
