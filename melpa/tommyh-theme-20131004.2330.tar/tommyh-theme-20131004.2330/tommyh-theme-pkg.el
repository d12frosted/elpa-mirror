;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tommyh-theme" "20131004.2330"
  "A bright, bold-colored theme for emacs."
  ()
  :url "https://github.com/wglass/tommyh-theme"
  :commit "46d1c69ee0a1ca7c67b569b891a2f28fed89e7d5"
  :revdesc "46d1c69ee0a1"
  :authors '(("William Glass" . "william.glass@gmail.com"))
  :maintainers '(("William Glass" . "william.glass@gmail.com")))
