;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-fringe-mark" "20190320.453"
  "Display evil-mode marks in the fringe."
  '((emacs         "24.3")
    (evil          "1.0.0")
    (fringe-helper "0.1.1")
    (goto-chg      "1.6"))
  :url "https://github.com/Andrew-William-Smith/evil-fringe-mark"
  :commit "a1689fddb7ee79aaa720a77aada1208b8afd5c20"
  :revdesc "a1689fddb7ee"
  :authors '(("Andrew Smith" . "andy.bill.smith@gmail.com"))
  :maintainers '(("Andrew Smith" . "andy.bill.smith@gmail.com")))
