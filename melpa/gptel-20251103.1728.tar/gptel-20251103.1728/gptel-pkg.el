;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251103.1728"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "8a39875973a97c1e4aa53edf27407e8c0daaae5e"
  :revdesc "8a39875973a9"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
