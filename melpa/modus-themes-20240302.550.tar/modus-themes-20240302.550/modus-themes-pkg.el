(define-package "modus-themes" "20240302.550" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "5bec85b46d035a4ab6e3c33798d66682138a9330" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
