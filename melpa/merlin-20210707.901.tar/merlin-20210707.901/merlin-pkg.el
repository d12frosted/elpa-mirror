(define-package "merlin" "20210707.901" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "5731826810ef8caa2201d8e1f4385ce83f99c909" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
