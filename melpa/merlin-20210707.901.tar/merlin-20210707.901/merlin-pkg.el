(define-package "merlin" "20210707.901" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "7c4c0a7018109b2b1bcbc3f6c1486961b223e658" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
