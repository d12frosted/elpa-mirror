(define-package "merlin" "20210707.901" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "6a584d994116490a06e44000b117c4454851f13f" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
