;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-toggle" "20251030.153"
  "Toggle Evil and God Mode."
  '((emacs    "28.1")
    (evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/jam1015/evil-god-toggle"
  :commit "79f8617e7b5f123f484eef1ff012766dbcd62589"
  :revdesc "79f8617e7b5f"
  :keywords '("convenience" "emulation" "evil" "god-mode")
  :authors '(("Jordan Mandel" . "jordan.mandel@live.com"))
  :maintainers '(("Jordan Mandel" . "jordan.mandel@live.com")))
