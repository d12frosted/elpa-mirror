;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-easy" "20261122.1234"
  "Helpers for easily building flymake checkers."
  ()
  :url "https://github.com/purcell/flymake-easy"
  :commit "2edddf15bf044be6f5be9595868464906387aa9c"
  :revdesc "2edddf15bf04"
  :keywords '("convenience" "internal")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
