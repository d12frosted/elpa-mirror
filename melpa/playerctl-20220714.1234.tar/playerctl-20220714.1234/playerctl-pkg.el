;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "playerctl" "20220714.1234"
  "Control your music player (e.g. Spotify) with playerctl."
  ()
  :url "https://github.com/thomasluquet/playerctl.el"
  :commit "0912ed5a5ab6d611b5f35db589f608f1fafdc81a"
  :revdesc "0912ed5a5ab6"
  :keywords '("multimedia" "playerctl" "music")
  :authors '(("Thomas Luquet" . "thomas@luquet.net"))
  :maintainers '(("Thomas Luquet" . "thomas@luquet.net")))
