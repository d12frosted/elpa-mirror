;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gh" "20260217.442"
  "GitHub CLI integration for Magit."
  '((emacs     "29.1")
    (magit     "4.0.0")
    (transient "0.5.0"))
  :url "https://github.com/jonathanchu/magit-gh"
  :commit "ef7714bf287f66c4c665f909465762bb232de765"
  :revdesc "ef7714bf287f"
  :keywords '("git" "tools" "vc" "github")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
