(define-package "lsp-grammarly" "20230814.1813" "LSP Clients for Grammarly"
  '((emacs "27.1")
    (lsp-mode "6.1")
    (grammarly "0.3.0")
    (request "0.3.0")
    (s "1.12.0")
    (ht "2.3"))
  :commit "798fdf2eb764b3738992c7a0f256de0bd72cd622" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "lsp" "grammarly" "checker")
  :url "https://github.com/emacs-grammarly/lsp-grammarly")
;; Local Variables:
;; no-byte-compile: t
;; End:
