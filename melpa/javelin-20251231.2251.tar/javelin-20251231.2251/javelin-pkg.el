;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "javelin" "20251231.2251"
  "Implementation of harpoon: bookmarks on steroids."
  '((emacs "28.1"))
  :url "https://github.com/DamianB-BitFlipper/javelin.el"
  :commit "175a2ebc56ecc8468f0ca8ffde9a8650446f1c74"
  :revdesc "175a2ebc56ec"
  :keywords '("tools" "languages"))
