;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241023.1925"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "b0551ade93d8a56fd950fea30cbdddf052c06d71"
  :revdesc "b0551ade93d8"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")))
