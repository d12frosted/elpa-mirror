;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mini-echo" "20250123.1840"
  "Echo buffer status in minibuffer window."
  '((emacs          "29.1")
    (dash           "2.19.1")
    (hide-mode-line "1.0.3"))
  :url "https://github.com/eki3z/mini-echo.el"
  :commit "e3faeed53a2230287d183b2cf254ef8e16d4e95e"
  :revdesc "e3faeed53a22"
  :keywords '("frames")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
