;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-sidebar" "20240102.9"
  "Helpful sidebar for Org buffers."
  '((emacs            "26.1")
    (compat           "29.1")
    (s                "1.10.0")
    (dash             "2.18")
    (org              "9.6")
    (org-ql           "0.2")
    (org-super-agenda "1.0"))
  :url "https://github.com/alphapapa/org-sidebar"
  :commit "1e06d1b4ab5f0d09301712cdecb757c9437a7179"
  :revdesc "1e06d1b4ab5f"
  :keywords '("hypermedia" "outlines" "org" "agenda")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
