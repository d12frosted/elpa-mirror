;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251030.2245"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "cf7710c7b6c171ba8bc41f6f19b64a4f942c8514"
  :revdesc "cf7710c7b6c1"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
