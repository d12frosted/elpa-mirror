;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uiua-ts-mode" "20261125.422"
  "Uiua treesiter mode."
  '((emacs     "29.1")
    (uiua-mode "0.0.5"))
  :url "https://github.com/crmsnbleyd/uiua-ts-mode"
  :commit "100b31f96346ed9d3260c956ae5fdc5d83f6f9d5"
  :revdesc "100b31f96346"
  :keywords '("languages" "uiua"))
