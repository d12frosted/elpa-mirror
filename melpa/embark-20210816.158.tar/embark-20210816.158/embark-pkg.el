(define-package "embark" "20210816.158" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "f7e79316f81a61feff5a2fb8e717d2c7c3bb9846" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
