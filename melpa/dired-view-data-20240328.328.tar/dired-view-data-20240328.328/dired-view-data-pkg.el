;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-view-data" "20240328.328"
  "View data from dired via ESS and R."
  '((emacs         "26.1")
    (ess           "18.10.1")
    (ess-view-data "1.0"))
  :url "https://github.com/ShuguangSun/dired-view-data"
  :commit "2dadb995c3f32c572f5483adab21bdff3ac64186"
  :revdesc "2dadb995c3f3"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
