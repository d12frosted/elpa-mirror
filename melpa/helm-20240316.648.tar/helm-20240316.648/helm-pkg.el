(define-package "helm" "20240316.648" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.7")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "2138fe3e59bf4054e84d9212a7b766b6e4c083c6" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
