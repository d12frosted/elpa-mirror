(define-package "bibtex-actions" "20210917.1233" "Bibliographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0")
    (parsebib "3.0"))
  :commit "7e350115c0565f2599a21c6990847576fe2f9c60" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
