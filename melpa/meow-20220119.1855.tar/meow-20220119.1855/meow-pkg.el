(define-package "meow" "20220119.1855" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "371f6554acfa4ecb9fc121f23539f77064f97115" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
