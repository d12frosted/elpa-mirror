(define-package "run-command-recipes" "20240707.623" "Start pack of recipes to `run-command' inside Emacs using only one command."
  '((emacs "25.1")
    (dash "2.18.0")
    (f "0.20.0")
    (run-command "1.0.0"))
  :commit "12118cff35cd106c2e6fea29cddf94f3be698a3d" :authors
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainers
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainer
  '("semenInRussia" . "hrams205@gmail.com")
  :keywords
  '("extensions" "run-command")
  :url "https://github.com/semenInRussia/emacs-run-command-recipes")
;; Local Variables:
;; no-byte-compile: t
;; End:
