(define-package "for" "20220919.1801" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "8e8cb94677faee0dd42d26ab3af614de481ce7b6" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
