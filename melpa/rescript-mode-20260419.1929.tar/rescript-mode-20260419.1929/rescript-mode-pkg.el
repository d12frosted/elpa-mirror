;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rescript-mode" "20260419.1929"
  "A major mode for editing ReScript."
  '((emacs "26.1"))
  :url "https://github.com/jjlee/rescript-mode"
  :commit "202cf1202f286b4440980e46c0a0c0a8003f7ec6"
  :revdesc "202cf1202f28"
  :keywords '("languages" "rescript")
  :authors '(("Karl Landstrom" . "karl.landstrom@brgeight.se")
             ("Daniel Colascione" . "dancol@dancol.org")
             ("John Lee" . "jjl@pobox.com"))
  :maintainers '(("John Lee" . "jjl@pobox.com")))
