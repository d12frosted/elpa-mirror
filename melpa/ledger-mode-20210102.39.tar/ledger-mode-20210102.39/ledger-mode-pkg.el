(define-package "ledger-mode" "20210102.39" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "49d25f9b97b53735e2558498df06a62a9613b199")
;; Local Variables:
;; no-byte-compile: t
;; End:
