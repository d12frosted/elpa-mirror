;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "license-snippets" "20201117.1619"
  "LICENSE templates for yasnippet."
  '((emacs     "26")
    (yasnippet "0.8.0"))
  :url "https://github.com/sei40kr/license-snippets"
  :commit "a89988b81604fd23c43746912215770a4b861989"
  :revdesc "a89988b81604"
  :keywords '("tools")
  :authors '(("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainers '(("Seong Yong-ju" . "sei40kr@gmail.com")))
