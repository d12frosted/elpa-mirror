;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern" "20250419.1429"
  "Modern looks for Org."
  '((emacs  "28.1")
    (org    "9.5")
    (compat "30"))
  :url "https://github.com/minad/org-modern"
  :commit "3b7304e9c842ba8890bd89f138173a002502cc53"
  :revdesc "3b7304e9c842"
  :keywords '("outlines" "hypermedia" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")
                 ("J.D. Smith" . "jdtsmith+elpa@gmail.com")))
