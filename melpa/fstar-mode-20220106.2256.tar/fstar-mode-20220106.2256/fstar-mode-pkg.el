(define-package "fstar-mode" "20220106.2256" "Support for F* programming"
  '((emacs "24.3")
    (dash "2.11")
    (company "0.8.12")
    (quick-peek "1.0")
    (yasnippet "0.11.0")
    (flycheck "30.0")
    (company-quickhelp "2.2.0"))
  :commit "c95c2a61a6c42a1fa8bab9a8eb812a41be3e6f69" :authors
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/FStarLang/fstar-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
