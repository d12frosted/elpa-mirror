(define-package "fanyi" "20210905.1203" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "352fc9ae3230e87470fcbb638d623169c2e582f9" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
