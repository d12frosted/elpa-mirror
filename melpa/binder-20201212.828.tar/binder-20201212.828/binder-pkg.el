(define-package "binder" "20201212.828" "Global minor mode to facilitate multi-file writing projects"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "24d55db236fea2b405d4bdc69b4c33d0f066059c" :keywords
  ("files" "outlines" "wp" "text")
  :authors
  (("Paul W. Rankin" . "pwr@skeletons.cc"))
  :maintainer
  ("Paul W. Rankin" . "pwr@skeletons.cc")
  :url "https://git.skeletons.cc/binder")
;; Local Variables:
;; no-byte-compile: t
;; End:
