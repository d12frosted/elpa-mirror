(define-package "bqn-mode" "20230308.136" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "10a495e1e527a8ab117c0f6b05b57cdd45f4dfc8" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
