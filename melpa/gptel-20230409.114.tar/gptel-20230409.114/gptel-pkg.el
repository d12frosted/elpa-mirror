(define-package "gptel" "20230409.114" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "dfb45863d332ad61d0af46380799b0d0d3d51aa2" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
