(define-package "helm-core" "20221228.813" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "796b84970d2bfcd1d341cada5398bb9368b82da4" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
