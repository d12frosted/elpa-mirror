;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260914.403"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6b983d11c737325f5c5f5ffcffbf930032d6abf4"
  :revdesc "6b983d11c737")
