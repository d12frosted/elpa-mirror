;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imake" "20261001.1551"
  "Simple, opinionated make target runner."
  '((emacs      "28.1")
    (compat     "31.1")
    (marginalia "2.13"))
  :url "https://github.com/tarsius/imake"
  :commit "73285db3186295633583ca39c9ce66a5fa9cc659"
  :revdesc "73285db31862"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev")))
