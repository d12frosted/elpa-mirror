(define-package "cape" "20230113.1550" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.1.0"))
  :commit "bbc399e4724c86d80ee04c5d3af1567683c2b87c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
