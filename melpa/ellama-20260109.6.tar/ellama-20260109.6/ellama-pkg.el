;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260109.6"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "543ea90d91614e3aaafeb1e6311df9ccc5c90074"
  :revdesc "543ea90d9161"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
