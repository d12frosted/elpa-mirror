(define-package "rust-mode" "20240312.348" "A major-mode for editing Rust source code"
  '((emacs "25.1"))
  :commit "825a37dbf7b3a5c2ee44e3707c4ad081fdf7dd15" :authors
  '(("Mozilla"))
  :maintainers
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages")
  :url "https://github.com/rust-lang/rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
