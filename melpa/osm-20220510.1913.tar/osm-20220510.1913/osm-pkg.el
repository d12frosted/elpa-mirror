(define-package "osm" "20220510.1913" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "05ac461360f32692f91305e9b42726334fcc81da" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
