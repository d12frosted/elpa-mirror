(define-package "ellama" "20231116.2010" "Tool for interacting with LLMs"
  '((emacs "28.1")
    (llm "0.5.2")
    (spinner "1.7.4"))
  :commit "8ba8897578b136688e5783329beb9b5accf191c3" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
