;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hiccup-cli" "20210211.2127"
  "Convert HTML to Hiccup syntax."
  '((emacs "26.1"))
  :url "https://github.com/kwrooijen/hiccup-cli"
  :commit "cfbb957a1f86bc1d28e778bfdffdeaaa2ae79286"
  :revdesc "cfbb957a1f86"
  :keywords '("tools"))
