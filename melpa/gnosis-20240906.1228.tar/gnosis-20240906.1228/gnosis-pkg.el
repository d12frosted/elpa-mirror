;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20240906.1228"
  "Spaced Repetition System."
  '((emacs     "27.2")
    (emacsql   "4.0.1")
    (compat    "29.1.4.2")
    (transient "0.7.2"))
  :url "https://git.thanosapollo.org/gnosis"
  :commit "40f63788afdb74fa71177abd882e852177829881"
  :revdesc "40f63788afdb"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
