(define-package "ob-chatgpt-shell" "20230531.732" "Org babel functions for ChatGPT evaluation"
  '((emacs "27.1")
    (chatgpt-shell "0.39.1"))
  :commit "4e117234f07991a1f1d100be84fbf2f4689ae39d" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
