;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251005.1523"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "dc30415f5e9facddb175bc015ce2d0d9c1185840"
  :revdesc "dc30415f5e9f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
