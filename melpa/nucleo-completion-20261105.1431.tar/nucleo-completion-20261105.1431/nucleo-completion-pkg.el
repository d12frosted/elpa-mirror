;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20261105.1431"
  "Nucleo-backed completion style."
  '((emacs "29.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "9f4f7395c9b80f7a29976ae4e4b739f6129c2aa0"
  :revdesc "9f4f7395c9b8"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
