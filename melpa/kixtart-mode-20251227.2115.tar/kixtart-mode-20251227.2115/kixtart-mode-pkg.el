;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "20251227.2115"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "e84979f0a0f579ec922d96e081632e4cd57db846"
  :revdesc "e84979f0a0f5"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
