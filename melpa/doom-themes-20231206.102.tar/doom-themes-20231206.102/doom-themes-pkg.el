(define-package "doom-themes" "20231206.102" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "0a895b00bd18ab72beb6c0a2e4ace5f39cbea14f" :authors
  '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainers
  '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainer
  '("Henrik Lissner" . "contact@henrik.io")
  :keywords
  '("themes" "faces")
  :url "https://github.com/doomemacs/themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
