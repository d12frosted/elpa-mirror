(define-package "notmuch" "20211223.1216" "run notmuch within emacs" 'nil :commit "02d8ff376d77e5d96389c30576221a7ac5b4bea1" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
