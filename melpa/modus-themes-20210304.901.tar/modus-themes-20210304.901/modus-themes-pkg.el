(define-package "modus-themes" "20210304.901" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "1f41820678885f621873ca1b4bc7e056aa5391a2" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
