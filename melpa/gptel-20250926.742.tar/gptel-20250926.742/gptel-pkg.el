;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250926.742"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "33363745eae0819c58a0a48f84a0474789f2c9e5"
  :revdesc "33363745eae0"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
