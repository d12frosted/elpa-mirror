;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-luau" "20260121.919"
  "Luau language server integration for eglot."
  '((emacs "29.1")
    (eglot "1.17"))
  :url "https://github.com/kennethloeffler/eglot-luau"
  :commit "6fd1ba044fd1f35785c8cb5fc831878993b0afbb"
  :revdesc "6fd1ba044fd1"
  :keywords '("roblox" "luau" "tools")
  :authors '(("Kenneth Loeffler" . "kenloef@gmail.com"))
  :maintainers '(("Kenneth Loeffler" . "kenloef@gmail.com")))
