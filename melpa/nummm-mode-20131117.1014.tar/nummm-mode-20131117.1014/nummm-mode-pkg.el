(define-package "nummm-mode" "20131117.1014" "Display the number of minor modes instead of their names" 'nil :commit "73b1aa8643d86197c82cd28acdaefcb48a1e0abe" :authors
  '(("Andreu Gil" . "agpchil@gmail.com"))
  :maintainers
  '(("Andreu Gil" . "agpchil@gmail.com"))
  :maintainer
  '("Andreu Gil" . "agpchil@gmail.com")
  :url "http://github.com/agpchil/nummm-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
