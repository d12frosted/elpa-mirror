;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250527.55"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "708c4cd08ae5b4e8e31636bb0963c29b6eb0123e"
  :revdesc "708c4cd08ae5"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
