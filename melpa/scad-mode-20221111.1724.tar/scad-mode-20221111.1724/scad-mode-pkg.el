(define-package "scad-mode" "20221111.1724" "A major mode for editing OpenSCAD code"
  '((emacs "27.1"))
  :commit "710cf2b7ce41a8c0b20b27d5e142a1db5f8371f9" :authors
  '(("Len Trigg, Łukasz Stelmach, zk_phi, Daniel Mendler"))
  :maintainer
  '("Len Trigg <lenbok@gmail.com>, Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("languages")
  :url "https://github.com/openscad/emacs-scad-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
