;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250322.1237"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (el-job "2.2.0")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "77882ca0f2e134511705ec5b1be2efc91051ba2f"
  :revdesc "77882ca0f2e1"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
