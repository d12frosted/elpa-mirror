;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260419.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "2813707d1f2c98562fa873624abc79ce49db969c"
  :revdesc "2813707d1f2c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
