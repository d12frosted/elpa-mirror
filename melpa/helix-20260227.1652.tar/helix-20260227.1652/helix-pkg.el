;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "20260227.1652"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "88914b870e096715c82a970a25f77ae435ebd9aa"
  :revdesc "88914b870e09"
  :keywords '("convenience"))
