;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-historian" "20210714.56"
  "Persistently store selected minibuffer candidates."
  '((emacs     "24.4")
    (historian "20170111")
    (ivy       "0.8.0")
    (flx       "0.6.1"))
  :url "https://github.com/PythonNut/historian.el"
  :commit "852cb4e72c0f78c8dbb2c972bdcb4e7b0108ff4c"
  :revdesc "852cb4e72c0f"
  :keywords '("convenience" "ivy")
  :authors '(("PythonNut" . "pythonnut@pythonnut.com"))
  :maintainers '(("PythonNut" . "pythonnut@pythonnut.com")))
