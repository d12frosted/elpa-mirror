;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260319.1221"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a2597ad40f5054a31ce59526a0b70722a4c5d744"
  :revdesc "a2597ad40f50")
