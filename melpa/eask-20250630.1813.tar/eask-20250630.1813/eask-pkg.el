;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20250630.1813"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "5cf79407e28dd76a26f362ba0d3518f2891b806a"
  :revdesc "5cf79407e28d"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
