;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qso" "20260805.2330"
  "Amateur radio QSO logging."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/Emacs-QSO-Logger"
  :commit "984c6c1266299021af3fd768426cdb413dfa7a7d"
  :revdesc "984c6c126629"
  :keywords '("lisp"))
