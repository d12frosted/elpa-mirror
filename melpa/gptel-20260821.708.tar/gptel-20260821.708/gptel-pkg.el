;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260821.708"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "33b7af7113580c32af7a8593766d33f16b926973"
  :revdesc "33b7af711358"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
