;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "20250528.1031"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "1b41007ccee6481edbf84b9f07f5995b6bb50c93"
  :revdesc "1b41007ccee6"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
