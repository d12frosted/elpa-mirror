;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern" "20250419.1635"
  "Modern looks for Org."
  '((emacs  "28.1")
    (org    "9.5")
    (compat "30"))
  :url "https://github.com/minad/org-modern"
  :commit "f0cf9aaad64f4ea9be6f23ee7a925745b84f52bc"
  :revdesc "f0cf9aaad64f"
  :keywords '("outlines" "hypermedia" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")
                 ("J.D. Smith" . "jdtsmith+elpa@gmail.com")))
