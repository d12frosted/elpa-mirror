(define-package "binky" "20231020.2113" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "0078a4b0bab190e27cf011b6d1f685ae953fcc82" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
