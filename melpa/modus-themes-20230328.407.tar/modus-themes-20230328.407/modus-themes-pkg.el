(define-package "modus-themes" "20230328.407" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "a380f86397f61802b2dd058a56b086a13cecb4ae" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
