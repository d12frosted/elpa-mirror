;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meshtastic" "20260524.1854"
  "Chat client for Meshtastic LoRa devices via serial."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/meshtastic.el"
  :commit "94a8642f7886614673c720671c4c58d5aa28d31f"
  :revdesc "94a8642f7886"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
