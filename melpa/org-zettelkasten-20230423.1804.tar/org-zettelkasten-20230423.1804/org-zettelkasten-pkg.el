(define-package "org-zettelkasten" "20230423.1804" "A Zettelkasten mode leveraging Org"
  '((emacs "25.1")
    (org "9.3"))
  :commit "23ad5db1cb9aeea700e91db95bf0ac4401c01068" :authors
  '(("Yann Herklotz" . "yann@ymhg.org"))
  :maintainers
  '(("Yann Herklotz" . "yann@ymhg.org"))
  :maintainer
  '("Yann Herklotz" . "yann@ymhg.org")
  :keywords
  '("files" "hypermedia" "org" "notes")
  :url "https://sr.ht/~ymherklotz/org-zettelkasten")
;; Local Variables:
;; no-byte-compile: t
;; End:
