;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "howm" "20250224.1324"
  "Wiki-like note-taking tool."
  '((cl-lib "0.5"))
  :url "https://kaorahi.github.io/howm/"
  :commit "0967a3f2c05b790e22f58812fc59313dc089d8b7"
  :revdesc "0967a3f2c05b"
  :authors '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com"))
  :maintainers '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com")))
