;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "20260914.1711"
  "Slack client."
  '((websocket "1.12")
    (request   "0.3.2")
    (circe     "2.11")
    (alert     "1.2")
    (emojify   "1.2.0")
    (emacs     "25.1")
    (dash      "2.19.1")
    (s         "1.13.0")
    (ts        "0.3"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "15a6728b6d34497c44b86320290e140855bc573e"
  :revdesc "15a6728b6d34"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
