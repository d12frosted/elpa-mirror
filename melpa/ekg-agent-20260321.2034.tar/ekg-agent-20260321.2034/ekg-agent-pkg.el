;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260321.2034"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "b3d1b7803bb27fd710ab92d79bfdfeb870a154cc"
  :revdesc "b3d1b7803bb2"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
