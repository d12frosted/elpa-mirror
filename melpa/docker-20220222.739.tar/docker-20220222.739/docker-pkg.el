(define-package "docker" "20220222.739" "Interface to Docker"
  '((aio "1.0")
    (dash "2.19.1")
    (docker-tramp "0.1")
    (emacs "26.1")
    (json-mode "1.8.0")
    (s "1.12.0")
    (tablist "1.0")
    (transient "0.3.7"))
  :commit "855bc82ec4628738660279c2f0280ea4303b2f61" :authors
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainer
  '("Philippe Vaucher" . "philippe.vaucher@gmail.com")
  :keywords
  '("filename" "convenience")
  :url "https://github.com/Silex/docker.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
