(define-package "apheleia" "20230329.2135" "Reformat buffer stably"
  '((emacs "26"))
  :commit "23c8b7d1ca3d855b38b8fe8bee760fa1234b6143" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/raxod502/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
