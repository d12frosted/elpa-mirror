(define-package "go-translate" "20211008.1434" "Translation"
  '((emacs "26.1"))
  :commit "4f2ee2fcc81f46a075beed8a334fdc5ca4a7b8e6" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
