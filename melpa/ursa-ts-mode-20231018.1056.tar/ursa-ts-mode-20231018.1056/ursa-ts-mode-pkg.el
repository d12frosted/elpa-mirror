(define-package "ursa-ts-mode" "20231018.1056" "Major mode for Ursa, using tree-sitter"
  '((emacs "29.1"))
  :commit "0fa5ea47f68cc71301491953cf9f550a8c191692" :authors
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("ursalang" "languages" "tree-sitter")
  :url "https://github.com/ursalang/ursa-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
