;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-dabbrev" "20261102.1439"
  "Like dabbrev-expand with preview and popup menu."
  '((emacs "25.1")
    (popup "0.5.3"))
  :url "https://github.com/jrosdahl/fancy-dabbrev"
  :commit "0b2b7c70429fbf930b86718bf2c9c964c1deaa6e"
  :revdesc "0b2b7c70429f"
  :authors '(("Joel Rosdahl" . "joel@rosdahl.net"))
  :maintainers '(("Joel Rosdahl" . "joel@rosdahl.net")))
