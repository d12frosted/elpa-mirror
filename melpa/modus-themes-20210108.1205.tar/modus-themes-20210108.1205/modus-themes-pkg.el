(define-package "modus-themes" "20210108.1205" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "9cf36ffc4287365a41be5279548b12f4f001d0fa" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
