(define-package "exwm-edit" "20240418.722" "Edit mode for EXWM"
  '((emacs "27.1"))
  :commit "302ea5240044f9cc718c214ff5abf7c45761c180" :authors
  '(("Ag Ibragimov"))
  :maintainers
  '(("Ag Ibragimov"))
  :maintainer
  '("Ag Ibragimov")
  :keywords
  '("convenience")
  :url "https://github.com/agzam/exwm-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
