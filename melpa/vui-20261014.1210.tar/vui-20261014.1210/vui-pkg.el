;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261014.1210"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "f42b4d87a3e9eac9114d8aa52bc721731277904f"
  :revdesc "f42b4d87a3e9"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
