;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hover" "20220129.1935"
  "Package to use hover with flutter."
  '((emacs "25.2")
    (dash  "2.14.1"))
  :url "https://github.com/ericdallo/hover.el"
  :commit "2b826735bb8d3bcfced489a1e0fa21b10fbc967e"
  :revdesc "2b826735bb8d"
  :keywords '("hover" "flutter" "mobile" "tools"))
