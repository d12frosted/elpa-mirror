(define-package "org-tidy" "20231011.37" "A minor mode to tidy org-mode buffers"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "789795a032b121825938e74e4bcbdede31de864f" :authors
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainers
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainer
  '("Xuqing Jia" . "jxq@jxq.me")
  :keywords
  '("convenience" "org")
  :url "https://github.com/jxq0/org-tidy")
;; Local Variables:
;; no-byte-compile: t
;; End:
