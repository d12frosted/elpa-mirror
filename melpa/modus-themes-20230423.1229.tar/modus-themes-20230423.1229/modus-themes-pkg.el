(define-package "modus-themes" "20230423.1229" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "24313757252e53bb7a5d0a021b8c7aabbbec9a94" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
