(define-package "w3m" "20230920.110" "an Emacs interface to w3m" 'nil :commit "fc14a7555380ade52ca8cc909a6ac6d6927a6abd" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
