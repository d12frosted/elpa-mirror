;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260428.1950"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "e0cc901060bc3707b5f4bc8089b14f768858d4f8"
  :revdesc "e0cc901060bc"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
