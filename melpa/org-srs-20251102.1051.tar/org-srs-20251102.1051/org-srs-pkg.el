;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251102.1051"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "e50ecae9733d5bce1ba7c0e4d680db53581331b3"
  :revdesc "e50ecae9733d"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
