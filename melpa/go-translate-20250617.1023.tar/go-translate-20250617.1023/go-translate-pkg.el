;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250617.1023"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "83db48b7e5eff808ec756a891ae72e4df1215265"
  :revdesc "83db48b7e5ef"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
