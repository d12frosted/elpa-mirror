(define-package "modus-themes" "20220823.1919" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "777089c0ffaabadc10cefead3737fabe24b9004c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
