;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "file-info" "20261031.930"
  "Show pretty information about current file."
  '((emacs            "28.1")
    (hydra            "0.15.0")
    (browse-at-remote "0.15.0"))
  :url "https://github.com/artawower/file-info.el"
  :commit "9c68e2eec20fd99ea056aafb4ccf669f4a9b3400"
  :revdesc "9c68e2eec20f"
  :authors '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers '(("Artur Yaroshenko" . "artawower@protonmail.com")))
