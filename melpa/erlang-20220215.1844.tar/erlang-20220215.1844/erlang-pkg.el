(define-package "erlang" "20220215.1844" "Erlang major mode"
  '((emacs "24.1"))
  :commit "5337c84817dfe1ac87a7d0317b4d301177e097f2" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
