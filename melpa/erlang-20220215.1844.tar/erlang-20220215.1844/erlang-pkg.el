(define-package "erlang" "20220215.1844" "Erlang major mode"
  '((emacs "24.1"))
  :commit "62ff88c44c5ac81ecaab7be7baca53ae7935e146" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
