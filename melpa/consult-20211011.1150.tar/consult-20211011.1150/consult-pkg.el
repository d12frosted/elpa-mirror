(define-package "consult" "20211011.1150" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b2cc3d376066e7c43c25195342ee530090f33fbf" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
