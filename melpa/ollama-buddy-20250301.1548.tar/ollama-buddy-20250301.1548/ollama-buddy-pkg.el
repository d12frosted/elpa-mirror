;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250301.1548"
  "Ollama Buddy: Your Friendly AI Assistant."
  '((emacs "26.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "18e7571426f4e36e0dc5a88ee1729f89039c4b01"
  :revdesc "18e7571426f4"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
