(define-package "modus-themes" "20210723.615" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "72ccffafab68312672f994c3b73887f1db79ee69" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
