;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent-harness" "20260910.1400"
  "Autonomous coding-agent harness for gptel-agent."
  '((emacs       "29.1")
    (compat      "30.1.0.0")
    (gptel       "0.9.9")
    (gptel-agent "0.0.1"))
  :url "https://github.com/beacoder/gptel-agent-harness"
  :commit "6abadc72125262cf65a455f30e5d3adf7ad63967"
  :revdesc "6abadc721252"
  :keywords '("programming" "convenience" "ai" "agent")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
