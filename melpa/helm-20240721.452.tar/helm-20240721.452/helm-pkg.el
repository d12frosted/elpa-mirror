(define-package "helm" "20240721.452" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.9")
    (wfnames "1.2"))
  :commit "ef4e7b96ce6ea12d3728ac6a0fcb349fc42e2ce9" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
