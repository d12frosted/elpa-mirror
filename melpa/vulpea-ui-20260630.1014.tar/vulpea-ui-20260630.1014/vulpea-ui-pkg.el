;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20260630.1014"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.4.0")
    (vui    "1.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "ad1f784b173a7422ba8e8e383ae7b0870fa0be78"
  :revdesc "ad1f784b173a"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
