(define-package "c0-mode" "20151110.1852" "Major mode for editing C0 files" 'nil :commit "c214093c36864d6208fcb9e6a72413ed17ed5d60" :keywords
  ("c0" "languages")
  :authors
  (("Jakob Max Uecker"))
  :maintainer
  ("Jakob Max Uecker")
  :url "http://c0.typesafety.net/")
;; Local Variables:
;; no-byte-compile: t
;; End:
