(define-package "consult" "20230128.936" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "271269c5a1a93d9ed343793ba526cf7569b16edd" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
