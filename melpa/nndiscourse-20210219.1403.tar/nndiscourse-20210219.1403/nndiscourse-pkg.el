(define-package "nndiscourse" "20210219.1403" "Gnus backend for Discourse"
  '((emacs "25.1")
    (dash "2.18")
    (anaphora "1.0.4")
    (rbenv "0.0.3")
    (json-rpc "20200417"))
  :commit "fa337f806f329931a1de217fec68b92de53ec66f" :keywords
  '("news")
  :url "https://github.com/dickmao/nndiscourse")
;; Local Variables:
;; no-byte-compile: t
;; End:
