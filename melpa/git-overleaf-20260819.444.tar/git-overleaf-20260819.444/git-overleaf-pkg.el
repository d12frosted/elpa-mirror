;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "20260819.444"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs         "29.4")
    (websocket     "1.15")
    (webdriver     "0.1")
    (magit-section "4.5")
    (transient     "0.7.2"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "04576f1d7fe30e61acfa1a6532b6011b41dd6e0a"
  :revdesc "04576f1d7fe3"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
