;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-dark" "20260215.2206"
  "Automatically set the dark-mode theme based on system status."
  '((emacs "24.4"))
  :url "https://github.com/LionyxML/auto-dark-emacs"
  :commit "9194f46775ab00998bb6393badaf0f82ace5e298"
  :revdesc "9194f46775ab"
  :keywords '("macos" "windows" "linux" "themes" "tools" "faces")
  :authors '(("Tim Harper" . "timcharperatgmaildotcom")
             ("Vincent Zhang" . "seagle0128@gmail.com")
             ("Jonathan Arnett" . "jonathan.arnett@protonmail.com")
             ("Greg Pfeil" . "greg@technomadic.org"))
  :maintainers '(("Tim Harper" . "timcharperatgmaildotcom")
                 ("Vincent Zhang" . "seagle0128@gmail.com")
                 ("Jonathan Arnett" . "jonathan.arnett@protonmail.com")
                 ("Greg Pfeil" . "greg@technomadic.org")))
