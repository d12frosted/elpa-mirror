(define-package "vs-dark-theme" "20230904.618" "Visual Studio IDE dark theme"
  '((emacs "24.1"))
  :commit "cec640fb94970c696f04573fe57e2788a4352622" :authors
  '(("Jen-Chieh Shen"))
  :maintainers
  '(("Jen-Chieh Shen"))
  :maintainer
  '("Jen-Chieh Shen")
  :url "https://github.com/emacs-vs/vs-dark-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
