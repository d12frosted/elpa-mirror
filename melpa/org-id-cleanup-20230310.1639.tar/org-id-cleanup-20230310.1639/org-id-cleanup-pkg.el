(define-package "org-id-cleanup" "20230310.1639" "Interactively find, present and maybe clean up unused IDs of org-id"
  '((org "9.3")
    (dash "2.12")
    (emacs "26.3"))
  :commit "73d3f750d236dd486b8bcc07c88bfda9ce5b384e" :authors
  '(("Marc Ihm" . "marc@ihm.name"))
  :maintainers
  '(("Marc Ihm" . "marc@ihm.name"))
  :maintainer
  '("Marc Ihm" . "marc@ihm.name")
  :url "https://github.com/marcIhm/org-id-cleanup")
;; Local Variables:
;; no-byte-compile: t
;; End:
