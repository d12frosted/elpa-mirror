;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "molecule" "20180527.743"
  "Simple wrapper for molecule."
  '((emacs "25.1"))
  :url "https://git.daemons.it/drymer/molecule.el"
  :commit "2ef72b81d9aa24ea782b71a061a3abdad6cae162"
  :revdesc "2ef72b81d9aa"
  :keywords '(":" "languages" "terminals")
  :authors '(("drymer" . "drymer[AT]autistici.org"))
  :maintainers '(("drymer" . "drymer[AT]autistici.org")))
