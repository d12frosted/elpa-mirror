(define-package "apheleia" "20240331.243" "Reformat buffer stably"
  '((emacs "27"))
  :commit "c7040a6f6e60abf22225df91415df76f3f739cf1" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
