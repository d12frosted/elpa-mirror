;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20260222.646"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "16d4dfc586245dd4b726b129591e08ed50d14bce"
  :revdesc "16d4dfc58624"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
