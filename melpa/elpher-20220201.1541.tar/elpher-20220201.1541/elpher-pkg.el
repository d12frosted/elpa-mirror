(define-package "elpher" "20220201.1541" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "dc2d321c502ae2598d0d3c05ad92b3d937f9ea44" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
