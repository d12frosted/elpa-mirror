(define-package "kkp" "20230801.1603" "Enable support for the Kitty Keyboard Protocol"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "18e3b1b73fddd234176a7e6633da67c30d13d107" :authors
  '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers
  '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainer
  '("Benjamin Orthen" . "contact@orthen.net")
  :keywords
  '("terminals")
  :url "https://github.com/benjaminor/kkp")
;; Local Variables:
;; no-byte-compile: t
;; End:
