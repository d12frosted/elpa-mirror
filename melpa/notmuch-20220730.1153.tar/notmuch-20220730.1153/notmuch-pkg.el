(define-package "notmuch" "20220730.1153" "run notmuch within emacs" 'nil :commit "f4ebb6037529569875029f411fd062d79641ce14" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
