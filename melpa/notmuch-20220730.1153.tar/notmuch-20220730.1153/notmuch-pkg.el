(define-package "notmuch" "20220730.1153" "run notmuch within emacs" 'nil :commit "54190d091cbceb345c489bd3f20fdca7e4b9a111" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
