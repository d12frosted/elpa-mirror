(define-package "notmuch" "20220730.1153" "run notmuch within emacs" 'nil :commit "3a175ddffba61e49197190127621684c8f5b18a8" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
