;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260215.1854"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "cf3263b7ad356af81ae32cdfae3ff375008ccfd1"
  :revdesc "cf3263b7ad35"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
