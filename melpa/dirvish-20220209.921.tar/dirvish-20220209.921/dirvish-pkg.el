(define-package "dirvish" "20220209.921" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "d8736e93b5bafdb581b731d853a5fc201672ec6e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
