(define-package "org-wild-notifier" "20230323.920" "Customizable org-agenda notifications"
  '((alert "1.2")
    (async "1.9.3")
    (dash "2.18.0")
    (emacs "24.4"))
  :commit "cdca8be45b80ab52077a915e77c625bc0ad07dd7" :authors
  '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainers
  '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainer
  '("Artem Khramov" . "akhramov+emacs@pm.me")
  :keywords
  '("notification" "alert" "org" "org-agenda" "agenda")
  :url "https://github.com/akhramov/org-wild-notifier.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
