(define-package "embark" "20210821.615" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "cbb93d9c6230e7baf60758b4e5dd7108eac28d41" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
