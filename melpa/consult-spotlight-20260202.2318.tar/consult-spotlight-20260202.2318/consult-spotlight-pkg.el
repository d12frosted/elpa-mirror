;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-spotlight" "20260202.2318"
  "Consult interface to macOS mdfind (Spotlight)."
  '((emacs   "27.1")
    (consult "1.5"))
  :url "https://github.com/guibor/consult-spotlight"
  :commit "b60fef973c19e22225cae395217ff01bd32a0ef5"
  :revdesc "b60fef973c19"
  :keywords '("matching" "files" "convenience")
  :authors '(("MDF" . "sguibor@gmail.com"))
  :maintainers '(("MDF" . "sguibor@gmail.com")))
