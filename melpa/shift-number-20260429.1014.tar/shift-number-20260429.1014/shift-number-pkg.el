;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shift-number" "20260429.1014"
  "Increase/decrease the number at point."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-shift-number"
  :commit "ab412a7af647c230fa1d316dc0e6a0c289986e16"
  :revdesc "ab412a7af647"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
