(define-package "elisp-autofmt" "20230119.854" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "d4bfb6180b880a3082b1aa6ec2467f4a7c0ea97d" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
