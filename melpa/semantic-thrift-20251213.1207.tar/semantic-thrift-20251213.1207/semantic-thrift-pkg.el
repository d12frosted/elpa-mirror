;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "semantic-thrift" "20251213.1207"
  "Thrift LALR parser."
  '((thrift "0.0.1")
    (emacs  "25.1"))
  :url "https://github.com/jerryxgh/semantic-thrift"
  :commit "484a2db27b26e814d93c4177271375ba2693e810"
  :revdesc "484a2db27b26"
  :keywords '("extensions" "thrift" "semantic")
  :authors '((nil . "GuanghuiXugh_xu@qq.com"))
  :maintainers '((nil . "GuanghuiXugh_xu@qq.com")))
