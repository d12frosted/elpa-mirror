(define-package "pet" "20230423.2326" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0"))
  :commit "2e5c777a835283ee4fe9eb20fd82114f348ba1f2" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
