;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "css-comb" "20160416.559"
  "Sort CSS properties in a particular order using CSS Comb."
  ()
  :url "https://github.com/channikhabra/css-comb.el"
  :commit "6fa45e5af8a8bd3af6c1154cde3540e32c4206ee"
  :revdesc "6fa45e5af8a8"
  :authors '(("Charanjit Singh" . "ckhabra@gmail.com"))
  :maintainers '(("Charanjit Singh" . "ckhabra@gmail.com")))
