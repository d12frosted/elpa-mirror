;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "20260901.1713"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "30.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "9aabf2b9cdb2155acaa026349e5fbbe842aaa431"
  :revdesc "9aabf2b9cdb2"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
