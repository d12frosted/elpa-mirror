(define-package "asm-blox" "20220124.411" "Programming game involving WAT and YAML"
  '((emacs "26.1")
    (yaml "0.3.4"))
  :commit "0c35b2a882f7816c2860abc62ecabdf89ef98789" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
