(define-package "orgit-forge" "20231006.2228" "Org links to Forge issue buffers"
  '((emacs "25.1")
    (compat "29.1.4.1")
    (forge "0.3")
    (magit "3.3")
    (org "9.6")
    (orgit "1.9"))
  :commit "ace5c7ca5df5de7c3f65fa7adb8ec118d8d10e4a" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("hypermedia" "vc")
  :url "https://github.com/magit/orgit-forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
