;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261127.918"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "b7ecd71acedcd45721adb52f4686613b4ccde316"
  :revdesc "b7ecd71acedc"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
