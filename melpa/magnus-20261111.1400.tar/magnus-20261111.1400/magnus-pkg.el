;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20261111.1400"
  "Manage multiple AI coding agents."
  '((emacs         "28.1")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (magit-section "3.3.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "be31e14ba0421cdcfb558ed43982a1d4c1be571b"
  :revdesc "be31e14ba042"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
