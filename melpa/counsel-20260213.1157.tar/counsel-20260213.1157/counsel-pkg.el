;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel" "20260213.1157"
  "Various completion functions using Ivy."
  '((emacs  "24.5")
    (ivy    "0.15.1")
    (swiper "0.15.1"))
  :url "https://github.com/abo-abo/swiper"
  :commit "11649c347107cba5f7ef8fd67ad8e77bc3b2472c"
  :revdesc "11649c347107"
  :keywords '("convenience" "matching" "tools")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
