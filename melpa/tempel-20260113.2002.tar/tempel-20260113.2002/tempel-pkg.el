;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260113.2002"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "14326646d734706926ed9d19cfe9875a06d0532a"
  :revdesc "14326646d734"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
