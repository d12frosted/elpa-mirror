;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250422.1746"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "7f9b063594bd00ace43cdc13ddd567129534b3b0"
  :revdesc "7f9b063594bd"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
