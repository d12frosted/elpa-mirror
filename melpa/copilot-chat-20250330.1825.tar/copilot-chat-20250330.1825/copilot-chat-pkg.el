;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20250330.1825"
  "Copilot chat interface."
  '((emacs         "27.1")
    (aio           "1.0")
    (request       "0.3.2")
    (transient     "0.8.3")
    (polymode      "0.2.2")
    (org           "9.4.6")
    (markdown-mode "2.6")
    (shell-maker   "0.76.2"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "2af9260b3ec46a1ec9d44ff55824c04d506dea1d"
  :revdesc "2af9260b3ec4"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
