;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261126.644"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "eb087ab62e718b2d79767bb007460d38dcfc17c3"
  :revdesc "eb087ab62e71"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
