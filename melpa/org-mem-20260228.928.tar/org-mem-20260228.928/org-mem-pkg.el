;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260228.928"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "4ec6f9fd61072a9c2b980a3b8c866ab913df17a6"
  :revdesc "4ec6f9fd6107"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
