;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260724.1012"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "825f86d1ebd8fe0779be199da2beb09bc3773fb9"
  :revdesc "825f86d1ebd8"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
