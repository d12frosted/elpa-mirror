;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260407.1917"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "be9f828997049c1a3bc5851e1e04f6b90a64555a"
  :revdesc "be9f82899704"
  :keywords '("convenience" "text"))
