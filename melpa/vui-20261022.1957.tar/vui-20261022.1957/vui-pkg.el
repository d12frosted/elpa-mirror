;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261022.1957"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "13325341c1b2457356ec5537ae4674b422ae537b"
  :revdesc "13325341c1b2"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
