;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251211.2307"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "369d060ab3a909f36a5b77f7478669fd69f3f016"
  :revdesc "369d060ab3a9"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
