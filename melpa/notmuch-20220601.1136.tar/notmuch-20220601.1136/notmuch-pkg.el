(define-package "notmuch" "20220601.1136" "run notmuch within emacs" 'nil :commit "66369ddf1cd1d7f84a048095ee5dcf5cb07e110c" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
