(define-package "affe" "20210812.1934" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.10"))
  :commit "cc63708913fc5d16073bcb96f483c2e207151032" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
