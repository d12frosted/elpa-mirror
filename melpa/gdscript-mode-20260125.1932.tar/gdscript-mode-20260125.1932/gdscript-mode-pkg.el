;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260125.1932"
  "Major mode for Godot's GDScript language."
  '((emacs "26.3"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "d3f8271bfdb6e3b44688b0998da59810bc604943"
  :revdesc "d3f8271bfdb6"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
