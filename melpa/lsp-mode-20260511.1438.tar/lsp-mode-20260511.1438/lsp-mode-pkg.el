;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260511.1438"
  "LSP mode."
  '((emacs         "29.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "fbc926fd3137d34796be254b92cb04c4f24dfae2"
  :revdesc "fbc926fd3137"
  :keywords '("languages"))
