(define-package "go-translate" "20211006.1336" "Google Translate"
  '((emacs "26.1"))
  :commit "3adc91935798708eb467f6ad649087009d09dba8" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
