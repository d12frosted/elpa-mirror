(define-package "hyperbole" "20240911.1430" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.2"))
  :commit "430ad66caf4eea14f3347ebce0dbdb936aa1c6f7" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainer
  '("Robert Weiner" . "rsw@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
