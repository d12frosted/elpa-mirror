(define-package "good-scroll" "20210122.1328" "Good pixel line scrolling"
  '((emacs "24.4"))
  :commit "3823e7706eb219105ce19b4eabce6aed1a2ce5c6" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
