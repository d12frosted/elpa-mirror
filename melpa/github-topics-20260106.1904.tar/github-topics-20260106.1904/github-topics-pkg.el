;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-topics" "20260106.1904"
  "Lookup PRs matching a query."
  '((emacs "29.4")
    (ts    "0.3"))
  :url "https://github.com/agzam/github-topics"
  :commit "dce3530b61fe4293190e40edf835291e8542a762"
  :revdesc "dce3530b61fe"
  :keywords '("vc" "matching" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
