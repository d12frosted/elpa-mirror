(define-package "elbank" "20180215.1356" "Personal finances reporting application"
  '((emacs "25")
    (seq "2.16"))
  :commit "f494716105b1a9f4f52f43bc3dd37c9cd0309bf5" :authors
  '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainer
  '("Nicolas Petton" . "nicolas@petton.fr")
  :keywords
  '("tools" "personal-finances"))
;; Local Variables:
;; no-byte-compile: t
;; End:
