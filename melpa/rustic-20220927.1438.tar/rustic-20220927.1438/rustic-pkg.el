(define-package "rustic" "20220927.1438" "Rust development environment"
  '((emacs "26.1")
    (rust-mode "1.0.3")
    (dash "2.13.0")
    (f "0.18.2")
    (let-alist "1.0.4")
    (markdown-mode "2.3")
    (project "0.3.0")
    (s "1.10.0")
    (seq "2.3")
    (spinner "1.7.3")
    (xterm-color "1.6"))
  :commit "4c89ea72f7934efd9dd4a7d1a2f6ec47903e59bd" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
