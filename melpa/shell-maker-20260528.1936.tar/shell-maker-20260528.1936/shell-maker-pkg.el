;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260528.1936"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "0100df0cbd7ae90b4d908d7d072a39e627e5c80c"
  :revdesc "0100df0cbd7a")
