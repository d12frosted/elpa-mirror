(define-package "consult" "20220522.952" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "380886441ed80f474d153de7c39dd5c5ab38b457" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
