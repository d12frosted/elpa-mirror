(define-package "el-patch" "20220103.142" "Future-proof your Elisp"
  '((emacs "25"))
  :commit "b9dbf15df1e6dff46c96ec5c0259e663997fd9c0" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/el-patch")
;; Local Variables:
;; no-byte-compile: t
;; End:
