(define-package "zotero" "20210328.2225" "Library for the Zotero API"
  '((emacs "27.1")
    (ht "2.2")
    (oauth "1.0.4")
    (s "1.12.0"))
  :commit "f204c763ebe74302a21ae5b25bb3a43f052a1342" :authors
  '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainer
  '("Folkert van der Beek" . "folkertvanderbeek@gmail.com")
  :keywords
  '("zotero" "hypermedia")
  :url "https://gitlab.com/fvdbeek/emacs-zotero")
;; Local Variables:
;; no-byte-compile: t
;; End:
