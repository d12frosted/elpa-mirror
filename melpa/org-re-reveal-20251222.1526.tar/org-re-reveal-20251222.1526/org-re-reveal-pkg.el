;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-re-reveal" "20251222.1526"
  "Org export to reveal.js presentations."
  '((emacs   "24.4")
    (org     "8.3")
    (htmlize "1.34"))
  :url "https://gitlab.com/oer/org-re-reveal"
  :commit "80bee1b270b142e3d9fd0b6ab94e42ba388a7b74"
  :revdesc "80bee1b270b1"
  :keywords '("tools" "outlines" "hypermedia" "slideshow" "presentation" "oer"))
