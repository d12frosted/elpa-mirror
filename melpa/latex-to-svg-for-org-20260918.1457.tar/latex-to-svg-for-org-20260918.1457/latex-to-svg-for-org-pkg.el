;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-org" "20260918.1457"
  "Preview Org LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.11.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "851860555c3942e4f9cb2d660e912a08ea81f808"
  :revdesc "851860555c39"
  :keywords '("tex" "org" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
