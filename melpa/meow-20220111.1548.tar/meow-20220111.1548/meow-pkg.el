(define-package "meow" "20220111.1548" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "b4dd3135cc60bfd144e5d007b4395a3bd65ee4d9" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
