;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vc-modified-files" "20250226.936"
  "Show git modified files in a vc project with consult."
  '((emacs   "28.1")
    (consult "0.9"))
  :url "https://github.com/chmouel/consult-vc-modified-files"
  :commit "f4cad4bde12d9855e0f2eefec26528e9351ac265"
  :revdesc "f4cad4bde12d"
  :keywords '("vc" "convenience")
  :authors '(("Chmouel Boudjnah" . "chmouel@chmouel.com"))
  :maintainers '(("Chmouel Boudjnah" . "chmouel@chmouel.com")))
