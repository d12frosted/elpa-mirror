;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-spy" "20131226.2008"
  "Mocking framework for Emacs lisp. It also support spy, proxy."
  ()
  :url "https://github.com/uk-ar/el-spy"
  :commit "b1dead9d1877660856ada22d906ac4e54695aec7"
  :revdesc "b1dead9d1877"
  :keywords '("test")
  :authors '(("Yuuki Arisawa" . "yuuki.ari@gmail.com"))
  :maintainers '(("Yuuki Arisawa" . "yuuki.ari@gmail.com")))
