;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-chat" "20260315.225"
  "Emacs client for Lisp Chat."
  '((emacs     "27.1")
    (websocket "1.12"))
  :url "https://github.com/ryukinix/lisp-chat"
  :commit "1479a989508f2963f7b773b9133fbe1d34d559c4"
  :revdesc "1479a989508f"
  :keywords '("comm" "chat" "lisp"))
