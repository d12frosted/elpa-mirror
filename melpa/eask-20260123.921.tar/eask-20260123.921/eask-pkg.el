;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20260123.921"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "f47f790261fd098e1892612f7ecae347f88ce20c"
  :revdesc "f47f790261fd"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
