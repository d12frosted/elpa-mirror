;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "openfoam" "20210516.1015"
  "OpenFOAM files and directories."
  '((emacs "25.1"))
  :url "https://github.com/ralph-schleicher/emacs-openfoam"
  :commit "e2c899009a9df412bf9f360492b1072eb6f1513f"
  :revdesc "e2c899009a9d"
  :keywords '("languages")
  :authors '(("Ralph Schleicher" . "rs@ralph-schleicher.de"))
  :maintainers '(("Ralph Schleicher" . "rs@ralph-schleicher.de")))
