;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nav" "20250211.1523"
  "Emacs mode for filesystem navigation."
  ()
  :url "https://github.com/emacsorphanage/nav"
  :commit "c9446387e337888778ea289ed7acc009691450da"
  :revdesc "c9446387e337"
  :authors '(("Issac Trotts" . "issactrotts@google.com"))
  :maintainers '(("Issac Trotts" . "issactrotts@google.com")))
