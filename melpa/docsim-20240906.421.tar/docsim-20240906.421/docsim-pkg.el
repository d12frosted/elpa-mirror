;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docsim" "20240906.421"
  "Search and compare notes with a local search engine."
  '((emacs "24.4")
    (org   "8.0"))
  :url "https://github.com/hrs/docsim.el"
  :commit "1441436621835eb9c6fe80bb07299043133f2942"
  :revdesc "144143662183"
  :authors '(("Robin Schwartz" . "hello@robinschwartz.me"))
  :maintainers '(("Robin Schwartz" . "hello@robinschwartz.me")))
