;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260817.2000"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b4b82f4ebe415aa62ef35509047c49b0a482bebb"
  :revdesc "b4b82f4ebe41"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
