;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261105.215"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "4dab1cb6e9ef360497c2fdc8b6b4933329ac5290"
  :revdesc "4dab1cb6e9ef"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
