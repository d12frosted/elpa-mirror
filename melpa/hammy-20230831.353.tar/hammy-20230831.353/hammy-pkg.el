(define-package "hammy" "20230831.353" "Programmable, interactive interval timers"
  '((emacs "28.1")
    (svg-lib "0.2.5")
    (ts "0.2.2"))
  :commit "666112f3825ef8b120611f3d5baf7c361842d997" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/hammy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
