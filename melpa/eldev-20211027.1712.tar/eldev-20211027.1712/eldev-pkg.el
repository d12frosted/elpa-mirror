(define-package "eldev" "20211027.1712" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "0aa5abc1d2f3c812f1bc53253ea511b810128c41" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
