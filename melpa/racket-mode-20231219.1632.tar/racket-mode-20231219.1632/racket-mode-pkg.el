(define-package "racket-mode" "20231219.1632" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "8bb83cf12ebf04d1ed3ecf2d5b46974b37976020" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
