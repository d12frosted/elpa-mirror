;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lcb-mode" "20160816.630"
  "LiveCode Builder major mode."
  '((emacs "24"))
  :url "https://github.com/peter-b/lcb-mode"
  :commit "be0768e9aa6f9b8e76f2230f4f7f4d152a766b9a"
  :revdesc "be0768e9aa6f"
  :keywords '("languages")
  :authors '(("Peter TB Brett" . "peter@peter-b.co.uk"))
  :maintainers '(("Peter TB Brett" . "peter@peter-b.co.uk")))
