;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-insert-plus" "20260119.644"
  "Use insert and append as evil operators."
  '((emacs "24.4")
    (evil  "1.14.0"))
  :url "https://github.com/yad-tahir/evil-insert-plus"
  :commit "be94f6842dbb57a5509fa5e283921d8381749dce"
  :revdesc "be94f6842dbb"
  :keywords '("emulations" "textvim" "editing")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
