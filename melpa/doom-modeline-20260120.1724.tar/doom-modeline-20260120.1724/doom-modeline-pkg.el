;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260120.1724"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "b6afaafd8c380756ccbaa10d655afbb315f78d2b"
  :revdesc "b6afaafd8c38"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
