;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20241130.1731"
  "Fuzzy completion style using `flx'."
  '((emacs "27.2")
    (flx   "0.5"))
  :url "https://github.com/jojojames/fussy"
  :commit "2a18b6c48dbb001473188ee81c4c51ff8602fdcb"
  :revdesc "2a18b6c48dbb"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
