;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20250525.338"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "507002b7b4baa1e182120ca417cd37de580e9b39"
  :revdesc "507002b7b4ba"
  :keywords '("hypermedia"))
