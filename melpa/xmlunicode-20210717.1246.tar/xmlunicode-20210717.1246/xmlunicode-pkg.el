(define-package "xmlunicode" "20210717.1246" "Unicode support for XML" 'nil :commit "7e4c71c30f0d5214c45d4d4d48b149029ddb6b77" :authors
  '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainer
  '("Norman Walsh" . "ndw@nwalsh.com")
  :keywords
  '("utf-8" "unicode" "xml" "characters"))
;; Local Variables:
;; no-byte-compile: t
;; End:
