;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260119.714"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "c5547a204dac1c8149127e9142a293f0d23761a6"
  :revdesc "c5547a204dac"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
