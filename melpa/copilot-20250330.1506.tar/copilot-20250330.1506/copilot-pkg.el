;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20250330.1506"
  "An unofficial Copilot plugin."
  '((emacs        "27.2")
    (s            "1.12.0")
    (dash         "2.19.1")
    (editorconfig "0.8.2")
    (jsonrpc      "1.0.14")
    (f            "0.20.0"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "445f2b5c9275717c0ad1c46289ccaf1d3f1c284a"
  :revdesc "445f2b5c9275"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Rakotomandimby Mihamina" . "mihamina.rakotomandimby@rktmb.org")))
