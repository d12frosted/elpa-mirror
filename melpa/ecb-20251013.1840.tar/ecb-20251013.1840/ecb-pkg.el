;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ecb" "20251013.1840"
  "A code browser for Emacs."
  ()
  :url "https://github.com/ecb-org/ecb"
  :commit "c87d9946016c80d37cc63cc45d943ce152e3ef0f"
  :revdesc "c87d9946016c"
  :keywords '("browser" "code" "programming" "tools")
  :authors '(("Jesper Nordenberg" . "mayhem@home.se")
             ("Klaus Berndl" . "klaus.berndl@sdm.de")
             ("Kevin A. Burton" . "burton@openprivacy.org"))
  :maintainers '(("Klaus Berndl" . "klaus.berndl@sdm.de")))
