;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260201.1716"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "abf66f3708e7fde1dd66aeabd446f014c739ea41"
  :revdesc "abf66f3708e7"
  :keywords '("languages" "lisp" "slime"))
