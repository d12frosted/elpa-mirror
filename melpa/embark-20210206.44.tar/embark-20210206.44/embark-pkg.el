(define-package "embark" "20210206.44" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "75cb2b0fae4c6bcb851224ef8630870d14bdc6f1" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
