;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251003.1339"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "ebc35005bab7763b758fbb28a4ab0db188e2baae"
  :revdesc "ebc35005bab7"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
