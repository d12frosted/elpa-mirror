(define-package "dirvish" "20220317.1004" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "2600201e181fedd16fbdfb36bf303a4c3119f536" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
