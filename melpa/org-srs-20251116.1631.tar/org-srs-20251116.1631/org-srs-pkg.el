;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251116.1631"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "0d422fc4ef95dcf5f23e8eab8fdec86e0f36dfc4"
  :revdesc "0d422fc4ef95"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
