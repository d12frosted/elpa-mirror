(define-package "citar" "20211129.1330" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (s "1.12")
    (parsebib "3.0")
    (org "9.5"))
  :commit "9c591366f88a9cfc65e9236bf9c23cdc4cf01499" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
