(define-package "shell-maker" "20230618.2028" "Interaction mode for making comint shells"
  '((emacs "27.1"))
  :commit "5a25d2ed2d5bd4f3e034a692a80a875313d7af53" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
