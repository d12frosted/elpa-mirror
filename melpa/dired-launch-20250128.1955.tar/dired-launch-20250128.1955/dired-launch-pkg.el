;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-launch" "20250128.1955"
  "Use dired as a launcher."
  '((emacs "24.3"))
  :url "https://codeberg.org/thomp/dired-launch"
  :commit "32ba5b600034a58511fc243fd06165cc07120cbb"
  :revdesc "32ba5b600034"
  :keywords '("dired" "launch"))
