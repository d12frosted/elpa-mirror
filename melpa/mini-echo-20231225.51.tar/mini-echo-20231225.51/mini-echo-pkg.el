(define-package "mini-echo" "20231225.51" "Echo buffer status in minibuffer window"
  '((emacs "29.1"))
  :commit "b9ce71dfbf7b7fde165cd33e067f2bb4ca46309d" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
