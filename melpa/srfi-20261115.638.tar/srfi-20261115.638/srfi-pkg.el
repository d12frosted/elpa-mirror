;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20261115.638"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "ddd5c4d6b493d9d2c13348517fa3345ff4daf9aa"
  :revdesc "ddd5c4d6b493"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
