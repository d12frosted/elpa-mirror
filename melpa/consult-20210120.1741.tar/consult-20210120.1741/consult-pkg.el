(define-package "consult" "20210120.1741" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "3c8609cf91eba3964004b9191b94ad122a73023d" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
