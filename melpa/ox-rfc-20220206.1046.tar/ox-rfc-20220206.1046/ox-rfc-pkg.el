(define-package "ox-rfc" "20220206.1046" "RFC Back-End for Org Export Engine"
  '((emacs "24.3")
    (org "8.3"))
  :commit "53d47df620157bd26f53a7f263b7a53224ef5712" :authors
  '(("Christian Hopps" . "chopps@devhopps.com"))
  :maintainer
  '("Christian Hopps" . "chopps@devhopps.com")
  :keywords
  '("org" "rfc" "wp" "xml")
  :url "https://github.com/choppsv1/org-rfc-export")
;; Local Variables:
;; no-byte-compile: t
;; End:
