;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocp-indent" "20260903.1746"
  "Automatic indentation with ocp-indent."
  ()
  :url "http://www.typerex.org/ocp-indent.html"
  :commit "0cc48eb5eb74f682020121225bc38344ea9052f2"
  :revdesc "0cc48eb5eb74"
  :keywords '("ocaml" "languages"))
