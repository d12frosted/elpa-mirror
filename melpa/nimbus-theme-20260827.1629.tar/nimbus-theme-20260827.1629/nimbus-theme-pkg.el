;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "20260827.1629"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "7f806ef0f1918c1b9ce6b62ef024d870d17f6da5"
  :revdesc "7f806ef0f191"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
