;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260923.530"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "163db9c7539cd6bd29c559192c65702bae2e81b8"
  :revdesc "163db9c7539c"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
