(define-package "proof-general" "20220310.2253" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "f34a4938399e6b863f14315ba5eeefb5ce047c50" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
