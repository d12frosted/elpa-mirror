(define-package "modus-themes" "20220322.1016" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "6b163eb44718a23b5288d1efcfbee706a9ba7be3" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
