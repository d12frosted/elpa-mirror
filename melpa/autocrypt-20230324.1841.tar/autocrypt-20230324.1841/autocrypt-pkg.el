(define-package "autocrypt" "20230324.1841" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "cf63019b3f58c8696b7251cde4087127557283a3" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
