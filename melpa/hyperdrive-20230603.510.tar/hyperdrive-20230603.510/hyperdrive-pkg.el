(define-package "hyperdrive" "20230603.510" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.3.2")
    (plz "0.6pre")
    (persist "0.5"))
  :commit "596a28fe34c95da757bb7525ee2d10e5239ca871" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
