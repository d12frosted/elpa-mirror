;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260704.702"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "f61118c5a35effbda7d96d234c9dc3f3794375ef"
  :revdesc "f61118c5a35e"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
