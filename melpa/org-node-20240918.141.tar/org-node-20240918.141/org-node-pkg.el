(define-package "org-node" "20240918.141" "Link org-id entries into a network"
  '((emacs "28.1")
    (compat "30")
    (dash "2.19.1")
    (transient "0.4.3")
    (persist "0.6.1"))
  :commit "8d1c1913790fc54d843ea4f7275dc021d17287e8" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node")
;; Local Variables:
;; no-byte-compile: t
;; End:
