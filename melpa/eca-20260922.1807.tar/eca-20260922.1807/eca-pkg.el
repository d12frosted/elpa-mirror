;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260922.1807"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "d7632c8bb8a093df1fde0c52fd1fd7662ead7e76"
  :revdesc "d7632c8bb8a0"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
