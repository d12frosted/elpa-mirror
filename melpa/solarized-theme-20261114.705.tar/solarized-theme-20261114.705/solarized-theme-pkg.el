;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "20261114.705"
  "The Solarized color theme."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "b33cce3ba8d5b316bfb83a9d508295cb22758676"
  :revdesc "b33cce3ba8d5"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
