;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260213.229"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "d4c24dba48ae6ea8b479261f979922aa5242c16f"
  :revdesc "d4c24dba48ae"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
