;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jump-tree" "20171014.1551"
  "Treat position history as a tree."
  ()
  :url "https://github.com/yangwen0228/jump-tree"
  :commit "282267dc6305889e31d46b405b7ad4dfe5923b66"
  :revdesc "282267dc6305"
  :keywords '("convenience" "position" "jump" "tree")
  :authors '(("Wen Yang" . "yangwen0228@foxmail.com"))
  :maintainers '(("Wen Yang" . "yangwen0228@foxmail.com")))
