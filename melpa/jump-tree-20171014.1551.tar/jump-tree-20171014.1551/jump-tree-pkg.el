(define-package "jump-tree" "20171014.1551" "Treat position history as a tree" 'nil :commit "282267dc6305889e31d46b405b7ad4dfe5923b66" :keywords
  ("convenience" "position" "jump" "tree")
  :authors
  (("Wen Yang" . "yangwen0228@foxmail.com"))
  :maintainer
  ("Wen Yang" . "yangwen0228@foxmail.com")
  :url "https://github.com/yangwen0228/jump-tree")
;; Local Variables:
;; no-byte-compile: t
;; End:
