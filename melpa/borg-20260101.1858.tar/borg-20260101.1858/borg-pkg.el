;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260101.1858"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "61f9e083b8d9f9ca196758729adce2c286841991"
  :revdesc "61f9e083b8d9"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
