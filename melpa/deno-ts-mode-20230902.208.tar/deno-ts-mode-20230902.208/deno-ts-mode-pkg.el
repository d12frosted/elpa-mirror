(define-package "deno-ts-mode" "20230902.208" "Major mode for Deno"
  '((emacs "29.1"))
  :commit "465f976d9930c21b2fb7e3e21f26c4e813bed02e" :authors
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainers
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainer
  '("Graham Marlow" . "info@mgmarlow.com")
  :keywords
  '("languages")
  :url "https://git.sr.ht/~mgmarlow/deno-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
