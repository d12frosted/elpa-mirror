;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260321.1826"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "512f444fe7b7cc4189b7f794274199dc0687fd7e"
  :revdesc "512f444fe7b7"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
