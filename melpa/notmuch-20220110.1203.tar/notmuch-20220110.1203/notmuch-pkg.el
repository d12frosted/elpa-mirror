(define-package "notmuch" "20220110.1203" "run notmuch within emacs" 'nil :commit "21e206e8b9bec15dbb4b1fa738a483eac4a135fa" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
