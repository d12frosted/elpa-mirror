(define-package "notmuch" "20220110.1203" "run notmuch within emacs" 'nil :commit "332b3b639ebd797eac6980fc7bd547f6cd064e84" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
