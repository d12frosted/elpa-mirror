(define-package "zk" "20230712.1103" "Functions for working with Zettelkasten-style linked notes"
  '((emacs "25.1"))
  :commit "5be59ca972f3f624d444b7b7d7ca75a06bcd2ce5" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/zk")
;; Local Variables:
;; no-byte-compile: t
;; End:
