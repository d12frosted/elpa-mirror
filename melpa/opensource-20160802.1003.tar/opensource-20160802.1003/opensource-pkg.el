(define-package "opensource" "20160802.1003" "Client for Opensource API"
  '((s "1.11.0")
    (dash "2.12.1")
    (pkg-info "0.6.0")
    (request "0.2.0"))
  :commit "27d06be45c852e84e47c33cbd0f4c344fd9a0370" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("opensource")
  :url "https://github.com/nlamirault/opensource.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
