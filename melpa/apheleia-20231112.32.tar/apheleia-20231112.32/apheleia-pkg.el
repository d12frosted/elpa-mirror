(define-package "apheleia" "20231112.32" "Reformat buffer stably"
  '((emacs "27"))
  :commit "ddea9bea708ce029cea6126b5be8e9f8979c58b3" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
