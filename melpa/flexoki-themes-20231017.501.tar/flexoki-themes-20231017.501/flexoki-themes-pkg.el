(define-package "flexoki-themes" "20231017.501" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "4285faa2f6fd95c46b42fa922e3309f6a0ad0711" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
