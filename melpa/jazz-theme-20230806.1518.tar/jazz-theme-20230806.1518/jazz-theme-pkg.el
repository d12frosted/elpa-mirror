(define-package "jazz-theme" "20230806.1518" "A warm color theme for Emacs 24+." 'nil :commit "54777a103746a0b6413ce0210326e3d2c10a0288" :authors
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainers
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainer
  '("Roman Parykin" . "donderom@ymail.com")
  :url "https://github.com/donderom/jazz-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
