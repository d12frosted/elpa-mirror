;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20250427.57"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "4bcacf9eeb5125ce188f9da8227a1f31cda9d578"
  :revdesc "4bcacf9eeb51"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
