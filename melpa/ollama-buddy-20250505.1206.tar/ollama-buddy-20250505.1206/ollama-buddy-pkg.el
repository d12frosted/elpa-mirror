;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250505.1206"
  "Ollama LLM AI Assistant with ChatGPT, Claude, Gemini and Grok Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "f7959e58c7a8545620c8a847867b61aa38fa53b6"
  :revdesc "f7959e58c7a8"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
