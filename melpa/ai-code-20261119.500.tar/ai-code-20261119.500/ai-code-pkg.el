;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261119.500"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "335fe26ee79a5947d54398c2853293031ea42c0f"
  :revdesc "335fe26ee79a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
