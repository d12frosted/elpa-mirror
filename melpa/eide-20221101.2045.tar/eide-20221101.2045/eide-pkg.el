(define-package "eide" "20221101.2045" "IDE interface" 'nil :commit "e0a5deb627da9cf70f02229601a1ebe6d78cabc8" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://software.hjuvi.fr.eu.org/eide/")
;; Local Variables:
;; no-byte-compile: t
;; End:
