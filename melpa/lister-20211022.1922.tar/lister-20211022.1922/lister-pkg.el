(define-package "lister" "20211022.1922" "Yet another list printer"
  '((emacs "26.1"))
  :commit "4da66a9eb682c59adfc03ed62bd628406613207e" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
