(define-package "simple-indentation" "20220215.1745" "Simplify writing indentation functions, alternative to SMIE"
  '((emacs "24.3")
    (dash "2.18.0")
    (s "1.12.0"))
  :commit "7008ac14f0789ff74e36636ae6bd13fdb2042193" :authors
  '(("Semen Khramtsov" . "hrams205@gmail.com"))
  :maintainer
  '("Semen Khramtsov" . "hrams205@gmail.com")
  :url "https://github.com/semenInRussia/simple-indentation.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
