(define-package "catppuccin-theme" "20221012.1849" "Catppuccin Theme"
  '((emacs "25.1"))
  :commit "6aa060373e5d108a3f28fe4d03f75dc82280beb3" :authors
  '(("pspiagicw"))
  :maintainer
  '("pspiagicw" . "pspiagicw@gmail.com")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
