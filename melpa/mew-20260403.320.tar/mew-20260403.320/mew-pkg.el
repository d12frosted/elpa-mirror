;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260403.320"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "ee3d2ac1a898f3fe8e54a6a431053b303faf96e7"
  :revdesc "ee3d2ac1a898")
