;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-twiddle" "20221203.1351"
  "Send & twiddle & resend HTTP requests."
  ()
  :url "https://github.com/hassy/http-twiddle/blob/master/http-twiddle.el"
  :commit "c07e8620183ec710623db35e26dd839b84c56007"
  :revdesc "c07e8620183e"
  :keywords '("http" "rest" "soap")
  :authors '(("Luke Gorrie" . "luke@synap.se"))
  :maintainers '(("Hasan Veldstra" . "h@vidiowiki.com")))
