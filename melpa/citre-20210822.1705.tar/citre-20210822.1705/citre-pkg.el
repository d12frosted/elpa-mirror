(define-package "citre" "20210822.1705" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "19a704d6fd22613c8c7b46b0ecfd9510168c9362" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
