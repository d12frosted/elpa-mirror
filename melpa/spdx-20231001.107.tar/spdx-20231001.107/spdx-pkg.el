(define-package "spdx" "20231001.107" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d277276d0c6e9dcc7da3531ea9a5de04fd80d4f0" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
