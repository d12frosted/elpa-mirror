(define-package "modus-themes" "20211212.1043" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "48a88b0d24374976372183c4ada4ab370a53acc5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
