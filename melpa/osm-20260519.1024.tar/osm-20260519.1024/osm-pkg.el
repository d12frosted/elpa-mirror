;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260519.1024"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/osm"
  :commit "a9e76ce08fb86e40a9f3efc42b38045c9b58fa95"
  :revdesc "a9e76ce08fb8"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
