;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sackspace" "20130719.956"
  "A better backspace."
  ()
  :url "https://github.com/cofi/sackspace.el"
  :commit "fd0480eaaf6d3d11fd30ac5feb2da2f4f7572708"
  :revdesc "fd0480eaaf6d"
  :keywords '("delete" "convenience")
  :authors '(("Michael Markert" . "markert.michael@googlemail.com"))
  :maintainers '(("Michael Markert" . "markert.michael@googlemail.com")))
