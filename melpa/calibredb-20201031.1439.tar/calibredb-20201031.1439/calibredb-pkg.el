(define-package "calibredb" "20201031.1439" "Yet another calibre client"
  '((emacs "25.1")
    (transient "0.1.0")
    (s "1.12.0")
    (dash "2.17.0"))
  :commit "74ec71dcd946598f7ed1ac372d85a633e3dacb6d" :keywords
  ("tools")
  :authors
  (("Damon Chan" . "elecming@gmail.com"))
  :maintainer
  ("Damon Chan" . "elecming@gmail.com")
  :url "https://github.com/chenyanming/calibredb.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
