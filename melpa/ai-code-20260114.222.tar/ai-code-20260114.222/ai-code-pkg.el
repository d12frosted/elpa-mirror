;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260114.222"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "16003c84f1306e8b106d63301137f1f73304848a"
  :revdesc "16003c84f130"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
