(define-package "jupyter" "20231020.1901" "Jupyter"
  '((emacs "26")
    (cl-lib "0.5")
    (org "9.1.6")
    (zmq "0.10.10")
    (simple-httpd "1.5.0")
    (websocket "1.9"))
  :commit "3a31920d48dc5e0d1028fb676cf20d13ea9f78ad" :authors
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainers
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainer
  '("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")
  :url "https://github.com/nnicandro/emacs-jupyter")
;; Local Variables:
;; no-byte-compile: t
;; End:
