;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250301.818"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "431c8d8c6388b8e77548d68da70a1eb44f562a98"
  :revdesc "431c8d8c6388"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
