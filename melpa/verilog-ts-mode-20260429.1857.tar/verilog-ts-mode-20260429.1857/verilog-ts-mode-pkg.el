;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ts-mode" "20260429.1857"
  "Verilog Tree-sitter major mode."
  '((emacs        "29.1")
    (verilog-mode "2024.3.1.121933719"))
  :url "https://github.com/gmlarumbe/verilog-ts-mode"
  :commit "b243ea4c78c37c8b01a06a269b1b3cd24996b00d"
  :revdesc "b243ea4c78c3"
  :keywords '("systemverilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
