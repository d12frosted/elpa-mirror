;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260121.2358"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "256e4cffa6737fa5245ef27f7754c844bf3fdbeb"
  :revdesc "256e4cffa673"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
