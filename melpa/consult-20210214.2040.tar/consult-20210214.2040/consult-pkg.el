(define-package "consult" "20210214.2040" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "af4c0314d6a156aeb020611b085f7a87fb051c1f" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
