(define-package "caml" "20231003.2221" "Caml mode for GNU Emacs"
  '((emacs "24.4"))
  :commit "6ed600cde9d6bc9c6eb19b462b3da1e34d42abbb" :authors
  '(("Jacques Garrigue" . "garrigue@kurims.kyoto-u.ac.jp")
    ("Ian T Zimmerman" . "itz@rahul.net")
    ("Damien Doligez" . "damien.doligez@inria.fr"))
  :maintainers
  '(("Christophe Troestler" . "Christophe.Troestler@umons.ac.be"))
  :maintainer
  '("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
  :keywords
  '("ocaml")
  :url "https://github.com/ocaml/caml-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
