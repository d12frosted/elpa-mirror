(define-package "dylan-mode" "20210309.1456" "Major mode for the Dylan programming language"
  '((emacs "25.1"))
  :commit "25dd620cf467a4a322461d9f9983db0fcca08e43" :authors
  '(("Robert Stockton" . "rgs@cs.cmu.edu"))
  :maintainer
  '("Chris Page" . "cpage@opendylan.org")
  :url "https://opendylan.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
