;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260208.143"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a282e902dbd2c55b7332b2dceebd9ceff6d6f2aa"
  :revdesc "a282e902dbd2"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
