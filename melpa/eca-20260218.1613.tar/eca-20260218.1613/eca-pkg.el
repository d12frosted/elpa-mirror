;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260218.1613"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "ce55a3d72cb9a1a9c6fa70a9acb0f13636cc7324"
  :revdesc "ce55a3d72cb9"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
