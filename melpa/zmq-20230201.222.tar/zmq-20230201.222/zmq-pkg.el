(define-package "zmq" "20230201.222" "ZMQ bindings in elisp"
  '((cl-lib "0.5")
    (emacs "26"))
  :commit "5477aa9f7a1c471f00c8f4cb915c13e7405e32a2" :authors
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainer
  '("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")
  :keywords
  '("comm")
  :url "https://github.com/nnicandro/emacs-zmq")
;; Local Variables:
;; no-byte-compile: t
;; End:
