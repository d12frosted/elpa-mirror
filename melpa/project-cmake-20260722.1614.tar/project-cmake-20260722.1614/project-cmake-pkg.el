;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-cmake" "20260722.1614"
  "A cmake backend for project.el."
  '((emacs "30.1"))
  :url "https://github.com/lucius-martius/project-cmake"
  :commit "530295d483bc67d9c27f41d22d9ad5167b643837"
  :revdesc "530295d483bc"
  :keywords '("tools" "convenience")
  :authors '(("Lucius Martius" . "lucius.martius@mailbox.org"))
  :maintainers '(("Lucius Martius" . "lucius.martius@mailbox.org")))
