(define-package "apdl-mode" "20210922.540" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "9e4251eb58faf0ddf7accee4d6fd875c15c04114" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
