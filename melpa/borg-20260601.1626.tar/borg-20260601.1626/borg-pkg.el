;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260601.1626"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "8269db64810cc2ff574d27311648ce3da35181f2"
  :revdesc "8269db64810c"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
