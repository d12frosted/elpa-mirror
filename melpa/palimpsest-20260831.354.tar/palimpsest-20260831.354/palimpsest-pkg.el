;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "palimpsest" "20260831.354"
  "Various deletion strategies when editing."
  ()
  :url "https://github.com/danielsz/Palimpsest"
  :commit "5c61147bf22e63fc3789dc84b51e5246404c2174"
  :revdesc "5c61147bf22e"
  :authors '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
