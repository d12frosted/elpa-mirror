(define-package "ob-crystal" "20180126.718" "org-babel functions for Crystal evaluation"
  '((emacs "24.3"))
  :commit "b3bb27a21a4cefef3f5aeef52718b694bd51245b" :authors
  '(("Brantou" . "brantou89@gmail.com"))
  :maintainer
  '("Brantou" . "brantou89@gmail.com")
  :keywords
  '("crystal" "literate programming" "reproducible research")
  :url "https://github.com/brantou/ob-crystal")
;; Local Variables:
;; no-byte-compile: t
;; End:
