;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "20260611.611"
  "Visually highlight the selected buffer."
  '((emacs "27.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "4793253653d8bd50dd491b6ffadbeb0e642ea2d2"
  :revdesc "4793253653d8"
  :keywords '("faces" "editing"))
