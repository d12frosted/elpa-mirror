(define-package "i-ching" "20211112.1528" "The Book of Changes"
  '((emacs "25.1")
    (request "0.3"))
  :commit "992f53ae2bd572b89bc642ca70b8bdaa5eb2553f" :authors
  '(("nik gaffney" . "nik@fo.am"))
  :maintainer
  '("nik gaffney" . "nik@fo.am")
  :keywords
  '("games" "divination" "stochastism" "cleromancy" "change")
  :url "https://github.com/zzkt/i-ching")
;; Local Variables:
;; no-byte-compile: t
;; End:
