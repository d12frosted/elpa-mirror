(define-package "clojure-ts-mode" "20230816.244" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "329a39ba3bd5d1832893416ef05bacb8c7678268" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
