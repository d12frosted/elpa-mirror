;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-present-remote" "20221107.1139"
  "A web-based remote control for org-present."
  '((org-present "9")
    (elnode      "0.9")
    (emacs       "25")
    (fakir       "20140729.1652")
    (s           "20210616.619")
    (web         "20141231.2001"))
  :url "https://gitlab.com/duncan-bayne/org-present-remote"
  :commit "95ea38b985b5aaa49b8039010bbe5fda5188a197"
  :revdesc "95ea38b985b5"
  :keywords '("comm" "docs")
  :authors '(("Duncan Bayne" . "duncan@bayne.id.au"))
  :maintainers '(("Duncan Bayne" . "duncan@bayne.id.au")))
