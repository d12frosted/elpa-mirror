;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-newline" "20131208.340"
  "Provide smart newline for one keybind."
  ()
  :url "https://github.com/ainame/smart-newline.el"
  :commit "c50ab035839b307c66d439083b6761cb7db5e972"
  :revdesc "c50ab035839b")
