(define-package "loopy" "20240818.230" "A looping macro"
  '((emacs "27.1")
    (map "3.3.1")
    (seq "2.22")
    (compat "29.1.3")
    (stream "2.3.0"))
  :commit "79b1fa59ddfbe2dcf252c9f40c59b3748ca1dd2f" :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
