;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ameba" "20191226.1011"
  "Add support for Ameba to Flycheck."
  '((emacs    "24.4")
    (flycheck "30"))
  :url "https://github.com/crystal-ameba/ameba.el"
  :commit "b129dbd8e4c43077521d1c77cc94bb3d52d5ee6d"
  :revdesc "b129dbd8e4c4"
  :keywords '("tools" "crystal" "ameba"))
