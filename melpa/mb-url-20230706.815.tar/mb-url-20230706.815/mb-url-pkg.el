(define-package "mb-url" "20230706.815" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "d0615da8c62890d7c2cd67c1976bdcfd712177f9" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
