;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20261027.2123"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "54a4dedc9d4e78d406df3125126dbd7a7b5949af"
  :revdesc "54a4dedc9d4e"
  :keywords '("convenience" "files" "tools"))
