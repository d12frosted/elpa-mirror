;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "20260801.1030"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "677939b0566295e1ff227de115edfcfeceb52bab"
  :revdesc "677939b05662"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
