;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260916.1042"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "9ba6fb3062145a9884aab8c9e11731c748689ce3"
  :revdesc "9ba6fb306214"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
