;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260314.47"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "a5cf2f4a15725517e1588d8a1a54bf3b8a56d3a1"
  :revdesc "a5cf2f4a1572"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
