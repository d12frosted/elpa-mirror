(define-package "epkg" "20220101.1312" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "44bcdb03bb11891f5966b39be942d76a4a57f5cf" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
