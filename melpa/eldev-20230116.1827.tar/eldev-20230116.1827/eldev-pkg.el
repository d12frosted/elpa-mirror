(define-package "eldev" "20230116.1827" "Elisp development tool"
  '((emacs "24.4"))
  :commit "370be888c7992551ee016ccc6eccdccbb2760183" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
