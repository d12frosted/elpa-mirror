;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260127.1457"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "e217289a5cacd18cfd9c3924f11636499211cd05"
  :revdesc "e217289a5cac"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
