(define-package "consult" "20210805.1453" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "239578d86b37da8bdc757dd788d7200b8f43be8d" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
