;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaesar-mode" "20230626.401"
  "AES encrypt/decrypt buffer."
  '((emacs  "24.3")
    (kaesar "0.1.4"))
  :url "https://github.com/mhayashi1120/Emacs-kaesar"
  :commit "fd833c69ad3ced4a890eb162f4399d79a8ec199c"
  :revdesc "fd833c69ad3c"
  :keywords '("data" "convenience")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
