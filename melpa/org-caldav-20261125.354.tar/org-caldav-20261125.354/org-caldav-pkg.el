;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-caldav" "20261125.354"
  "Sync org files with external calendar through CalDAV."
  '((emacs "26.3")
    (org   "9.1"))
  :url "https://github.com/dengste/org-caldav/"
  :commit "da7964cbf063933774adc12e8a6d4931e4f5cbe9"
  :revdesc "da7964cbf063"
  :keywords '("calendar" "caldav")
  :authors '(("David Engster" . "deng@randomsample.de"))
  :maintainers '(("David Engster" . "deng@randomsample.de")))
