(define-package "wanderlust" "20220720.1344" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "a3847bf379ac92e39ac7188071707551d1628ccb")
;; Local Variables:
;; no-byte-compile: t
;; End:
