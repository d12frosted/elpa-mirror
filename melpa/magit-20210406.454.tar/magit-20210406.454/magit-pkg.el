(define-package "magit" "20210406.454" "A Git porcelain inside Emacs."
  '((emacs "25.1")
    (dash "20200524")
    (git-commit "20200516")
    (transient "20200601")
    (with-editor "20200522"))
  :commit "4f41ba4945f4688579fa22394f04bf0baebe9484" :authors
  '(("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
