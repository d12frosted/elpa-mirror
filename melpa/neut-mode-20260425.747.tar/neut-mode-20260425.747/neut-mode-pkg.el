;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neut-mode" "20260425.747"
  "A major mode for Neut."
  '((emacs "29"))
  :url "https://github.com/vekatze/neut-mode"
  :commit "536ba9641011ea31c019beb6399ffca9945fc34e"
  :revdesc "536ba9641011"
  :authors '(("vekatze" . "vekatze@icloud.com"))
  :maintainers '(("vekatze" . "vekatze@icloud.com")))
