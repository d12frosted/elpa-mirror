;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plim-mode" "20140813.13"
  "Major mode for editing Plim files."
  ()
  :url "https://github.com/dongweiming/plim-mode"
  :commit "98cd6d11b7ff3ee7b6cb8845f143b5a692a3e6e8"
  :revdesc "98cd6d11b7ff"
  :keywords '("markup" "language"))
