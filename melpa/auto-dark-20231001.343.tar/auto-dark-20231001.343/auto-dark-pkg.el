(define-package "auto-dark" "20231001.343" "Automatically sets the dark-mode theme based on macOS/Linux/Windows status"
  '((emacs "24.4"))
  :commit "85f2c70c0b163612f668343547c1bd5620369496" :authors
  '(("Rahul M. Juliato")
    ("Tim Harper <timcharper at gmail dot com>")
    ("Vincent Zhang" . "seagle0128@gmail.com")
    ("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers
  '(("Rahul M. Juliato"))
  :maintainer
  '("Rahul M. Juliato")
  :keywords
  '("macos" "windows" "linux" "themes" "tools" "faces")
  :url "https://github.com/LionyxML/auto-dark-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
