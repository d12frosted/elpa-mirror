;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260401.715"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "4b96917fae1234915fd2ffda4d2b62d82437bb6e"
  :revdesc "4b96917fae12"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
