(define-package "srfi" "20220526.2233" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "3e5fbaef46126634c58d0f39be4bc522c05de1f9" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
