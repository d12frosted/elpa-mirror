(define-package "cframe" "20231101.1742" "Customize a frame and fast switch size and positions"
  '((emacs "26")
    (buffer-manage "0.11")
    (dash "2.17.0"))
  :commit "d0f8b36cce8a9f2e1caa373e8c336c16d092c2ad" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("frames")
  :url "https://github.com/plandes/cframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
