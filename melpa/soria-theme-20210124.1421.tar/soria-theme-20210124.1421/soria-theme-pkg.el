(define-package "soria-theme" "20210124.1421" "A xoria256 theme with some colors from openSUSE"
  '((emacs "25.1"))
  :commit "bca7a42db1245543d81373e67d71278a0e3135a2" :authors
  '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainer
  '("Miquel Sabaté Solà" . "mikisabate@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/mssola/soria")
;; Local Variables:
;; no-byte-compile: t
;; End:
