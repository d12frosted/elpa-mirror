;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260906.1502"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "be3021db13b4c96050f97fa147e65fa53f50fb36"
  :revdesc "be3021db13b4"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
