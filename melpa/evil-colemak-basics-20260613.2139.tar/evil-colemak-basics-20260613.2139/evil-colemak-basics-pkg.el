;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-colemak-basics" "20260613.2139"
  "Basic Colemak key bindings for evil-mode."
  '((emacs      "24.3")
    (evil       "1.2.12")
    (evil-snipe "2.0.3"))
  :url "https://github.com/wbolster/evil-colemak-basics"
  :commit "c613db5c33b69549eff0d3d9d9f687d266158fee"
  :revdesc "c613db5c33b6"
  :keywords '("convenience" "emulations" "colemak" "evil")
  :authors '(("Wouter Bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("Wouter Bolsterlee" . "wouter@bolsterl.ee")))
