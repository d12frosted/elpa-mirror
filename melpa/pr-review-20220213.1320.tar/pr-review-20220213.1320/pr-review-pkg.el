(define-package "pr-review" "20220213.1320" "Review github PR"
  '((emacs "27.1")
    (magit-section "3.2")
    (magit "3.2")
    (markdown-mode "2.5")
    (ghub "3.5"))
  :commit "0bf87e491b8130d815ef220ac5d5c4fa086e7372" :authors
  '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainer
  '("Yikai Zhao" . "yikai@z1k.dev")
  :keywords
  '("tools")
  :url "https://github.com/blahgeek/emacs-pr-review")
;; Local Variables:
;; no-byte-compile: t
;; End:
