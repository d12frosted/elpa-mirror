(define-package "kuronami-theme" "20240104.1541" "A deep blue theme with cool autumnal colors"
  '((emacs "24.1"))
  :commit "00b1a391e5e9b1f59bdceca9132c86b3c6488096" :authors
  '(("inj0h <>"))
  :maintainers
  '(("inj0h <>"))
  :maintainer
  '("inj0h <>")
  :url "https://github.com/inj0h/kuronami")
;; Local Variables:
;; no-byte-compile: t
;; End:
