;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oberon" "20120715.909"
  "Major mode for editing Oberon/Oberon-2 program texts."
  ()
  :url "https://github.com/emacsorphanage/oberon"
  :commit "fb57d18ce13835a8a69b6bafecdd9193ca9a59a3"
  :revdesc "fb57d18ce138"
  :keywords '("oberon" "oberon-2" "languages" "oop")
  :authors '(("Karl Landström" . "karl@karllandstrom.se"))
  :maintainers '(("Karl Landström" . "karl@karllandstrom.se")))
