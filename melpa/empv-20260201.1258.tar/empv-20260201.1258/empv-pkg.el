;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260201.1258"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "5287a71a6220acdb1716d47af183cee4c6094994"
  :revdesc "5287a71a6220"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
