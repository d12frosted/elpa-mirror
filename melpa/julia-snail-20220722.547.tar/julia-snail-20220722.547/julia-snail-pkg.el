(define-package "julia-snail" "20220722.547" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (vterm "0.0.1")
    (popup "0.5.9"))
  :commit "d275f8a070431d2ce669a2844a28e5a65ee0c430" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
