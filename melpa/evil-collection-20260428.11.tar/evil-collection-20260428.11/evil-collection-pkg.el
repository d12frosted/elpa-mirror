;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260428.11"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "8db8a959d2c1ca54496224e96ff712c9185e38ab"
  :revdesc "8db8a959d2c1"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
