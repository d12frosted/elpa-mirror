(define-package "racket-mode" "20231222.2114" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "a4035b5065765c6730b25a0c065c706891ed5e9a" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
