;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "replace-symbol" "20160518.12"
  "Rename symbols in expressions or buffers."
  ()
  :url "https://github.com/bmastenbrook/replace-symbol-el"
  :commit "baf949e528aee1881f455f9c84e67718bedcb3f6"
  :revdesc "baf949e528ae"
  :authors '(("Brian Mastenbrook" . "brian@mastenbrook.net"))
  :maintainers '(("Brian Mastenbrook" . "brian@mastenbrook.net")))
