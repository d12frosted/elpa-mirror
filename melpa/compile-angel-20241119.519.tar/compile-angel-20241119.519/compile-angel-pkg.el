;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20241119.519"
  "Compile Emacs Lisp libraries automatically."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "72248622519f841796e8f7be7550de31d43bb63a"
  :revdesc "72248622519f"
  :keywords '("convenience"))
