;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20251011.925"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "3446853f0f1bdba4eb84e2fd438c1129273c1448"
  :revdesc "3446853f0f1b"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
