;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sudo-utils" "20210119.1930"
  "Sudo utilities."
  '((emacs "25.1"))
  :url "https://github.com/alpha-catharsis/sudo-utils"
  :commit "089f7833fa256f293284a6286bf9cb2b78eff40d"
  :revdesc "089f7833fa25"
  :keywords '("processes" "unix")
  :authors '(("Alpha Catharsis" . "alpha.catharsis@gmail.com"))
  :maintainers '(("Alpha Catharsis" . "alpha.catharsis@gmail.com")))
