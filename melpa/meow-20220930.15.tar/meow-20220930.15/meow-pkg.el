(define-package "meow" "20220930.15" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "dae2baa8228ee0a5cb37c6707057160c57bfe5f2" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
