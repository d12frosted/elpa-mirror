;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "better-scroll" "20260101.557"
  "Improve user experience when scrolling window."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/better-scroll"
  :commit "f87c21c7b29ba1545f7e1f050325dd85d478de76"
  :revdesc "f87c21c7b29b"
  :keywords '("convenience" "scrolling" "scroll" "window" "better" "improvement")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
