(define-package "modus-themes" "20210325.2025" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "f163839c48b3418c367d88e975f9df48f40d9015" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
