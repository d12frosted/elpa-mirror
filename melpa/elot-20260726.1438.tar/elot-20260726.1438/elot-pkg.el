;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "20260726.1438"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "571ecfbf05e92424d24cd60ef90054be040d6a06"
  :revdesc "571ecfbf05e9"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
