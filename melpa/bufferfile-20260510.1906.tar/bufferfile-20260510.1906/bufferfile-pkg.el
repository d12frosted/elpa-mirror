;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20260510.1906"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "23a92c44f79d8b4661156a492904705b243a05e3"
  :revdesc "23a92c44f79d"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
