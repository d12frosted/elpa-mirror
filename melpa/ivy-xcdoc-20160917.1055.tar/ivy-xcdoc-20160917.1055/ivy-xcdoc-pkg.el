;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-xcdoc" "20160917.1055"
  "Search Xcode documents with ivy interface."
  '((ivy   "0.8.0")
    (emacs "24.4"))
  :url "https://github.com/hex2010/emacs-ivy-xcdoc"
  :commit "fbf264b0746182567b17fd7409fff8eed3658c71"
  :revdesc "fbf264b07461"
  :keywords '("ivy" "xcode" "xcdoc")
  :authors '(("C.T.Chen" . "chenct@7adybird.com"))
  :maintainers '(("C.T.Chen" . "chenct@7adybird.com")))
