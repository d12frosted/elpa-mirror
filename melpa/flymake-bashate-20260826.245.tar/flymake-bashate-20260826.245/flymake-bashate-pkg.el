;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "20260826.245"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "67706445e4c42e5297b058aff51e379ef5ff6531"
  :revdesc "67706445e4c4"
  :keywords '("tools" "languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
