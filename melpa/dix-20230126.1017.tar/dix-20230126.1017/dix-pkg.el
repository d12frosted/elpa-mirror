(define-package "dix" "20230126.1017" "Apertium XML editing minor mode"
  '((cl-lib "0.5")
    (emacs "26.2"))
  :commit "5eeed9362fbeaf5a032bccd69b861b8a36877516" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("languages")
  :url "http://wiki.apertium.org/wiki/Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
