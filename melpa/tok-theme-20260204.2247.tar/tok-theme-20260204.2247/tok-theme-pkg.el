;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tok-theme" "20260204.2247"
  "Minimal monochromatic theme with restrained color highlights."
  '((emacs "27.0"))
  :url "https://github.com/topikettunen/tok-theme"
  :commit "5849183dce55594386a72f79f8b92e4560a37e09"
  :revdesc "5849183dce55"
  :authors '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers '(("Topi Kettunen" . "topi@topikettunen.com")))
