;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitpatch" "20170722.410"
  "Git-format patch toolkit."
  '((emacs "24.3"))
  :url "https://github.com/tumashu/gitpatch"
  :commit "577d5adf65c8133caa325c10e89e1e2fc323c907"
  :revdesc "577d5adf65c8"
  :keywords '("convenience")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
