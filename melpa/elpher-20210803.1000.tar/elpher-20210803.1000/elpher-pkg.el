(define-package "elpher" "20210803.1000" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "9d28cdcbac0acb9ddcac68084fea7394e51c038a" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
