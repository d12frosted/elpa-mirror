(define-package "org-jira" "20220702.709" "Syncing between Jira and Org-mode."
  '((emacs "24.5")
    (cl-lib "0.5")
    (request "0.2.0")
    (dash "2.14.1"))
  :commit "7581ee26f7a57789d4e18c8a53865a2693673c48" :maintainer
  '("Matthew Carter" . "m@ahungry.com")
  :keywords
  '("ahungry" "jira" "org" "bug" "tracker")
  :url "https://github.com/ahungry/org-jira")
;; Local Variables:
;; no-byte-compile: t
;; End:
