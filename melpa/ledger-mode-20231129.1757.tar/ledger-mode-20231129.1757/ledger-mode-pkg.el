(define-package "ledger-mode" "20231129.1757" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "6a425f6c8703e03cec8bf1e18fa2fae86c895334")
;; Local Variables:
;; no-byte-compile: t
;; End:
