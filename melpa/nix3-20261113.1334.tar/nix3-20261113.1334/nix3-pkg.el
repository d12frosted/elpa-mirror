;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix3" "20261113.1334"
  "Frontend to experimental commands of Nix."
  '((emacs         "29.1")
    (promise       "1.1")
    (compat        "29.1")
    (magit-section "4.5")
    (s             "1.12")
    (transient     "0.13"))
  :url "https://github.com/emacs-twist/nix3.el"
  :commit "38c7116dff6df6761fba5dde64ca0f8deaff1265"
  :revdesc "38c7116dff6d"
  :keywords '("processes")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
