;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260717.1115"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "dc2fdb7149b07f0a4454a36a05b3a174efdfcb6e"
  :revdesc "dc2fdb7149b0"
  :keywords '("data" "extensions"))
