(define-package "helm-pt" "20150309.215" "Helm interface to the platinum searcher"
  '((helm "1.5.6"))
  :commit "03e35e2bb5b683d79897d07acb57ee67009cc6cd" :authors
  '(("Rich Alesi"))
  :maintainer
  '("Rich Alesi")
  :url "https://github.com/ralesi/helm-pt")
;; Local Variables:
;; no-byte-compile: t
;; End:
