(define-package "sparql-mode" "20180320.1457" "Edit and interactively evaluate SPARQL queries."
  '((cl-lib "0.5")
    (emacs "24.3"))
  :commit "2837b97244111515c61fb3823c1479bc126a458b" :authors
  '(("Craig Andera <candera at wangdera dot com>"))
  :maintainer
  '("Bjarte Johansen <Bjarte dot Johansen at gmail dot com>")
  :url "https://github.com/ljos/sparql-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
