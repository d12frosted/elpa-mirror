;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260129.2327"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "b5fc731a7d3fe3d661bcd9e47ab4c2dbfc4c7ee5"
  :revdesc "b5fc731a7d3f"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
