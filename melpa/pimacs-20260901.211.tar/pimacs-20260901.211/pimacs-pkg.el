;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260901.211"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "db58cdd918fd83e18f4b81c43c5f3e78a9a1da38"
  :revdesc "db58cdd918fd"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
