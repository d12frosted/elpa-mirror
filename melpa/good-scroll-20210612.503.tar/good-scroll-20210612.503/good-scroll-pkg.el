(define-package "good-scroll" "20210612.503" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "4ca86e18c8f64fd7a2d088a591ac11773d6b06a7" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
