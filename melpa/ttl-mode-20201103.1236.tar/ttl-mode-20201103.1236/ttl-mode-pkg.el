;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ttl-mode" "20201103.1236"
  "Mode for Turtle (and Notation 3)."
  ()
  :url "https://github.com/jeeger/ttl-mode"
  :commit "366aed213714a37201c584a77ae1208a1fcd5010"
  :revdesc "366aed213714")
