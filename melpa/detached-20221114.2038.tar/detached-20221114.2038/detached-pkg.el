(define-package "detached" "20221114.2038" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "4ed1a3a5b9a1f675fa2f71a89825e43fad6c6e97" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
