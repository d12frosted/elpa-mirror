;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251111.629"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "5d8d69fb00c2cc8e795892fb76e9fc34b8694021"
  :revdesc "5d8d69fb00c2"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
