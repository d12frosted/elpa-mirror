;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "find-dupes-dired" "20210426.835"
  "Find dupes and handle in dired."
  '((emacs "26.1"))
  :url "https://github.com/ShuguangSun/find-dupes-dired"
  :commit "af56f75afc240d8121c8944a614a272be811830c"
  :revdesc "af56f75afc24"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
