;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251105.1055"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "a1149ce5e7070dd303ec8d09af057d05f8c6e227"
  :revdesc "a1149ce5e707"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
