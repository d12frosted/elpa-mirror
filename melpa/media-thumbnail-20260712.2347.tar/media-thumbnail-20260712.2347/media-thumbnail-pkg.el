;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-thumbnail" "20260712.2347"
  "Utility package to provide media icons."
  '((emacs "28.1"))
  :url "https://github.com/jojojames/media-thumbnail"
  :commit "eb43298ad1600171300c20319eec63c7272324f3"
  :revdesc "eb43298ad160"
  :keywords '("files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
