;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xref-rst" "20260108.1306"
  "Lookup reStructuredText symbols."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-xref-rst"
  :commit "2d1ed3f31b64a9e10a757dedf06f1b514894d67f"
  :revdesc "2d1ed3f31b64"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
