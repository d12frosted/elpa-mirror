;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-tasks" "20260520.133"
  "Efficient task management for your project."
  '((emacs   "26.1")
    (project "0.6.0"))
  :url "https://github.com/TxGVNN/project-tasks"
  :commit "a8736133dc3ee77b6002098592853ac56e5a5b40"
  :revdesc "a8736133dc3e"
  :keywords '("project" "workflow" "tools")
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
