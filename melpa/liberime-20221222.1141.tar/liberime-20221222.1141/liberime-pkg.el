(define-package "liberime" "20221222.1141" "Rime elisp binding"
  '((emacs "25.1"))
  :commit "70ad2e6e1f0ff74fc8b9b5177b9aba645a18e546" :authors
  '(("A.I."))
  :maintainer
  '("A.I.")
  :keywords
  '("convenience" "chinese" "input-method" "rime")
  :url "https://github.com/merrickluo/liberime")
;; Local Variables:
;; no-byte-compile: t
;; End:
