(define-package "loopy" "20230314.136" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22")
    (compat "29.1.3"))
  :commit "0cb8714f0a77b257039b5269eb257e83718d1ef0" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
