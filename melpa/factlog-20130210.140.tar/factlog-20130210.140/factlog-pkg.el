;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "factlog" "20130210.140"
  "File activity logger."
  '((deferred "0.3.1"))
  :url "https://github.com/tkf/factlog"
  :commit "38f78132ae311faffba98ed5dd18d661af68678e"
  :revdesc "38f78132ae31"
  :authors '(("Takafumi Arakaki" . "aka.tkfatgmail.com"))
  :maintainers '(("Takafumi Arakaki" . "aka.tkfatgmail.com")))
