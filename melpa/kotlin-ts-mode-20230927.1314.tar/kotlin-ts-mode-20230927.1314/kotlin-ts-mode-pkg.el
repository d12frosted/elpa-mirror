(define-package "kotlin-ts-mode" "20230927.1314" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "a699d76adfdf263cef3ed13fa599219e611d26bc" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
