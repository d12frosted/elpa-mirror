;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20260213.2206"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "37b915d2374db36f701f4545baa19dd2bfe48f33"
  :revdesc "37b915d2374d"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
