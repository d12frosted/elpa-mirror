;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250430.1203"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "28.1")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "66ce00bef4c2e445626058ec05f3cbd912e3b379"
  :revdesc "66ce00bef4c2"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
