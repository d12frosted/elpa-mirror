(define-package "osm" "20221231.940" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "7a7be6ce999a9abd5d2e6a90f21d9626c73880c5" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
