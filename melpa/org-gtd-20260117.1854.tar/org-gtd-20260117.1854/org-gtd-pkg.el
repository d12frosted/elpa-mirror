;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gtd" "20260117.1854"
  "An implementation of GTD."
  '((emacs     "28.1")
    (compat    "30.0.0.0")
    (org-edna  "1.1.2")
    (f         "0.20.0")
    (org       "9.6")
    (transient "0.11.0")
    (dag-draw  "1.0.4"))
  :url "https://github.com/Trevoke/org-gtd.el"
  :commit "21ba4b1c03a0b9e6feec1b3f1f85ccb682adf867"
  :revdesc "21ba4b1c03a0"
  :authors '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainers '(("Aldric Giacomoni" . "trevoke@gmail.com")))
