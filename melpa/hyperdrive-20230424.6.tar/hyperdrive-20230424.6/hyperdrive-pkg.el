(define-package "hyperdrive" "20230424.6" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.3.2")
    (plz "0.5.4")
    (persist "0.5"))
  :commit "04dd828a3cf9febf5dfd1fbdc443ae79146cd9fe" :authors
  '(("Joseph Turner"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
