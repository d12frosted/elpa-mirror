;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251209.1719"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.2")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "70bcd24b9d2e11fb6ae3c7fde7fb25b7307886ed"
  :revdesc "70bcd24b9d2e")
