;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "folgezett" "20260510.1449"
  "Folgezettel IDs for org-roam."
  '((emacs    "27.2")
    (org-roam "2.0.0"))
  :url "https://github.com/landerwells/folgezett.el"
  :commit "9bc112c7d97700adcaa3a6017f78ce6d764d4ad5"
  :revdesc "9bc112c7d977"
  :keywords '("outlines" "tools" "org-roam" "zettelkasten")
  :authors '(("Lander Wells" . "landerwells@gmail.com"))
  :maintainers '(("Lander Wells" . "landerwells@gmail.com")))
