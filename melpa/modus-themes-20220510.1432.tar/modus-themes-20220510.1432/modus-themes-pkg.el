(define-package "modus-themes" "20220510.1432" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "d00946e80bb4923b941c6232302bc9536fa1d0a0" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
