;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260222.204"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "639f5ff740ec5ec2d7debad1349fe1d130528ff1"
  :revdesc "639f5ff740ec"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
