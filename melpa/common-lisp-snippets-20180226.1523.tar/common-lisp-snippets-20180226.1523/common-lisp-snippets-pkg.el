(define-package "common-lisp-snippets" "20180226.1523" "Yasnippets for Common Lisp"
  '((yasnippet "0.8.0"))
  :commit "1ddf808311ba4d9e8444a1cb50bd5ee75e4111f6" :authors
  '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainer
  '("Mark Karpov" . "markkarpov92@gmail.com")
  :keywords
  '("snippets")
  :url "https://github.com/mrkkrp/common-lisp-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
