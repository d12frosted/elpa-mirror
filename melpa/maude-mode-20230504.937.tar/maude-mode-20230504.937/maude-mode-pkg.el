;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maude-mode" "20230504.937"
  "Emacs mode for the programming language Maude."
  '((emacs "25"))
  :url "https://github.com/rudi/abs-mode"
  :commit "2e1f68a890493d964f933d6e40b0ede047f70ede"
  :revdesc "2e1f68a89049"
  :keywords '("languages" "maude")
  :authors '(("Ellef Gjelstad" . "ellefg+maude*ifi.uio.no"))
  :maintainers '(("Rudi Schlatte" . "rudi@constantly.at")))
