;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260320.1754"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "dc49fc2b3ae356713ee08102ff85ea5181e738d6"
  :revdesc "dc49fc2b3ae3"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
