(define-package "magit-section" "20230919.1453" "Sections for read-only buffers."
  '((emacs "25.1")
    (compat "29.1.3.4")
    (dash "20221013"))
  :commit "1ab107a72d9022383ce4e0e6fc1460201d58dcab" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
