;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260726.239"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "c9dd7fe377b49d4079c72fb698013f642e2bf989"
  :revdesc "c9dd7fe377b4"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
