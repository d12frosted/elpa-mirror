;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260927.2157"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://codeberg.org/okamsn/loopy"
  :commit "f02d09667489011e412321ee9331b5163c4c1b36"
  :revdesc "f02d09667489"
  :keywords '("extensions"))
