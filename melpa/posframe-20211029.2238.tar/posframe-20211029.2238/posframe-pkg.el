(define-package "posframe" "20211029.2238" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "13cfdc170d7e2064f7d469698300f5f417d51ed1" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
