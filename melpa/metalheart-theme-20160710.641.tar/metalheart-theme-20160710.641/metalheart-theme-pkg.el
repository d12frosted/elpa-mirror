;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metalheart-theme" "20160710.641"
  "Low-contrast theme with a dark blue-green background."
  '((emacs "24"))
  :url "https://github.com/mswift42/MetalHeart-Emacs"
  :commit "ec98ea2c11dc1213dae8cbe1fe0cee73ca138bb2"
  :revdesc "ec98ea2c11dc")
