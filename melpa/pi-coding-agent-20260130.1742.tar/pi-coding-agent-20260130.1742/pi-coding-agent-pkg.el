;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260130.1742"
  "Emacs frontend for pi coding agent."
  '((emacs         "28.1")
    (markdown-mode "2.6")
    (transient     "0.3.7"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "6253b0471e1f3c033b0263ece1492a4eaffafbe7"
  :revdesc "6253b0471e1f"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
