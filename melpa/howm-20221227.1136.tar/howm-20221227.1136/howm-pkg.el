(define-package "howm" "20221227.1136" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "a06238160809189d69e19be8e01089cb0cbcdb52" :authors
  '(("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
