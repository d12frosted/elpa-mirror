(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "eef21c284742fa5ae14d7d352acc3a4dc98821ce" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
