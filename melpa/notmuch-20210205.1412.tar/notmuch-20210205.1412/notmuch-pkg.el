(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "a34d7b41444ad2fb50cc7def25659c88d439780a" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
