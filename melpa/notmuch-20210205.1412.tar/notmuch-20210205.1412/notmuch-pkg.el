(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "7061e41cd0ed7a37dab83687697a692a53c5a66f" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
