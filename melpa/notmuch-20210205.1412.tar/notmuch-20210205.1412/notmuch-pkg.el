(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "ccd2ef38718efa3c9268eb68ad54454609e4451c" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
