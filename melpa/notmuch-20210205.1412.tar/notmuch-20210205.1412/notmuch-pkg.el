(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "62f03b6ab86bdc378198f9c1a86cb51ead289961" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
