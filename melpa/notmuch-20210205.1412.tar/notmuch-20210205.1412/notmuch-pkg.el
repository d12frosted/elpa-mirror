(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "121f9ddad3eecfb23babccbe84280381e5f5a283" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
