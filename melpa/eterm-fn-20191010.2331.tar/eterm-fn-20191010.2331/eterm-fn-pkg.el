(define-package "eterm-fn" "20191010.2331" "Function keys (F1--F12) for term."
  '((term "0"))
  :commit "66f3b2f6308fa2ac4d8a32be5a7e35a96e08a9ee" :url "https://github.com/oitofelix/eterm-fn" :maintainer
  ("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org")
  :authors
  (("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org")))
;; Local Variables:
;; no-byte-compile: t
;; End:
