;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260425.216"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "e36ee02dbea02936f3416b71337aeaf7d8b883bc"
  :revdesc "e36ee02dbea0"
  :keywords '("convenience" "input method" "dbus"))
