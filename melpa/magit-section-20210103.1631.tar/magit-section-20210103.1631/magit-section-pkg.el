(define-package "magit-section" "20210103.1631" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "86eec7ba39eb46fa1e4c2f37800d22c6dfd155c7" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
