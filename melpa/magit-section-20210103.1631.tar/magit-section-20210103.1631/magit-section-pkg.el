(define-package "magit-section" "20210103.1631" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "21454777281247d97814ce5fb64f4afe39fab5da" :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  ("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
