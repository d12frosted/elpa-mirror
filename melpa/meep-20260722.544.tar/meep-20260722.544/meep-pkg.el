;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260722.544"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "90025544266eaf47758ad58c7174f7e31bfebefd"
  :revdesc "90025544266e"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
