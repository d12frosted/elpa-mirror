(define-package "go-translate" "20240719.857" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "72e3452ff517b0bcd2ff624f6ce009b5791e3dd6" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
