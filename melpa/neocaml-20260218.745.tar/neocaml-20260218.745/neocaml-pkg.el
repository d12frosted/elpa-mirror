;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260218.745"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "8db3894f034ae02ced6b0f0262edd724a8c4a29b"
  :revdesc "8db3894f034a"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
