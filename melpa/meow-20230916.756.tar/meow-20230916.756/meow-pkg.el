(define-package "meow" "20230916.756" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "ba0cf4d1607971374351a68e48581d3ff4184c0e" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
