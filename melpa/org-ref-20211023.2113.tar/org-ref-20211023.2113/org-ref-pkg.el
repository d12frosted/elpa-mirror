(define-package "org-ref" "20211023.2113" "citations, cross-references and bibliographies in org-mode"
  '((dash "0")
    (s "0")
    (f "0")
    (htmlize "0")
    (hydra "0")
    (parsebib "0")
    (bibtex-completion "0")
    (citeproc "0"))
  :commit "65399cb68cc000d8226e68cca23cdf6ba9d2fc15" :authors
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainer
  '("John Kitchin" . "jkitchin@andrew.cmu.edu")
  :keywords
  '("org-mode" "cite" "ref" "label")
  :url "https://github.com/jkitchin/org-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
