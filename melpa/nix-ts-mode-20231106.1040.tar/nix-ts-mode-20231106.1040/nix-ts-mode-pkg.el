(define-package "nix-ts-mode" "20231106.1040" "Major mode for Nix expressions, powered by tree-sitter"
  '((emacs "29.1"))
  :commit "3e496e8cd779a10c881d264cf50c47ad4d775eb3" :maintainers
  '(("Remi Gelinas" . "mail@remigelin.as"))
  :maintainer
  '("Remi Gelinas" . "mail@remigelin.as")
  :keywords
  '("nix" "languages")
  :url "https://github.com/remi-gelinas/nix-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
