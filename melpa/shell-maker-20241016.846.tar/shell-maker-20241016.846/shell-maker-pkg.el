;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20241016.846"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "d988b7f83942dd24a8ac0b7a8d854608acfaedfe"
  :revdesc "d988b7f83942")
