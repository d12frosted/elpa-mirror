(define-package "docopt" "20201121.1523" "A Docopt implementation in Elisp"
  '((emacs "26.3")
    (dash "2.17.0")
    (emacs "26.1")
    (f "0.20.0")
    (parsec "0.1.3")
    (s "1.12.0")
    (transient "0.3.0"))
  :commit "8a0e1777777d6ef7d144f1150b06ede9d9950220" :keywords
  ("docopt" "tools" "processes")
  :authors
  (("r0man" . "roman@burningswell.com"))
  :maintainer
  ("r0man" . "roman@burningswell.com")
  :url "https://github.com/r0man/docopt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
