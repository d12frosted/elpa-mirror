(define-package "spdx" "20230224.116" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "66afaeda787edbb509b24fd3999763493822d3f5" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
