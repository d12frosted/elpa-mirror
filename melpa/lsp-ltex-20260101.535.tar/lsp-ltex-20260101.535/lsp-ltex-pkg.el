;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex" "20260101.535"
  "LSP Clients for LTEX."
  '((emacs    "28.1")
    (lsp-mode "6.1"))
  :url "https://github.com/emacs-languagetool/lsp-ltex"
  :commit "6adc2b4d32a907943a6ce06e2267090241e7af6a"
  :revdesc "6adc2b4d32a9"
  :keywords '("convenience" "lsp" "languagetool" "checker")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
