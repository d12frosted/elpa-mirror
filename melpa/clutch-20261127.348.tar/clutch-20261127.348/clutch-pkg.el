;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261127.348"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "462900dfa9b70127f96fe79edd85d56bb5919b2b"
  :revdesc "462900dfa9b7"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
