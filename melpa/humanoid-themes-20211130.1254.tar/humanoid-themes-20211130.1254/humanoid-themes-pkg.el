(define-package "humanoid-themes" "20211130.1254" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "18f481d54a01a2c08f456db5610a8017d87b9fbc" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
