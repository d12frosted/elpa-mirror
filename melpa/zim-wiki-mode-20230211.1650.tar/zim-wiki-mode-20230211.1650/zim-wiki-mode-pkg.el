(define-package "zim-wiki-mode" "20230211.1650" "Zim Desktop Wiki edit mode"
  '((emacs "25.1")
    (helm-ag "0.58")
    (helm-projectile "0.14.0")
    (dokuwiki-mode "0.1.1")
    (link-hint "0.1")
    (pretty-hydra "0.2.2"))
  :commit "cf3d5a0dfb53d6cba8d7d35420ec18bf81b5bf2f" :authors
  '(("Will Foran" . "willforan+zim-wiki-mode@gmail.com"))
  :maintainers
  '(("Will Foran" . "willforan+zim-wiki-mode@gmail.com"))
  :maintainer
  '("Will Foran" . "willforan+zim-wiki-mode@gmail.com")
  :keywords
  '("outlines")
  :url "https://github.com/WillForan/zim-wiki-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
