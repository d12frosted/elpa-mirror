(define-package "obsidian" "20231211.1857" "Obsidian Notes interface"
  '((emacs "27.2")
    (f "0.2.0")
    (s "1.12.0")
    (dash "2.13")
    (markdown-mode "2.5")
    (elgrep "1.0.0")
    (yaml "0.5.1"))
  :commit "56f686176b88696332ace3c4db4989161673d625" :authors
  '(("Mykhaylo Bilyanskyy"))
  :maintainers
  '(("Mykhaylo Bilyanskyy"))
  :maintainer
  '("Mykhaylo Bilyanskyy")
  :keywords
  '("obsidian" "pkm" "convenience")
  :url "https://github.com./licht1stein/obsidian.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
