;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260201.1509"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "7d8fd72222b77ffaaaf8a32eedebb1f546d2441f"
  :revdesc "7d8fd72222b7"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
