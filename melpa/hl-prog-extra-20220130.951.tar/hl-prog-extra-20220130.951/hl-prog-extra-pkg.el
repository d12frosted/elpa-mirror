(define-package "hl-prog-extra" "20220130.951" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "42ca96ec86f32e5fb0b6ef9bf259a0e653ace74c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
