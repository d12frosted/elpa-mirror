;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20251104.839"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1.4.2"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "af2d996cc525fc13af15adaa6706211b5d148a70"
  :revdesc "af2d996cc525"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
