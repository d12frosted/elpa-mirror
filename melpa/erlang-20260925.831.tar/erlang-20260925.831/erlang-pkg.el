;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20260925.831"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "91ffe3af52a0847db89d5a671b791f9890e4ec90"
  :revdesc "91ffe3af52a0"
  :keywords '("erlang" "languages" "processes"))
