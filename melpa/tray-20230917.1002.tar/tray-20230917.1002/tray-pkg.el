(define-package "tray" "20230917.1002" "Various transient menus"
  '((emacs "27.1")
    (compat "29.1.4.1")
    (transient "0.4.0"))
  :commit "b8d48c81de06261926420d75608cc69f99970563" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("convenience")
  :url "https://git.sr.ht/~tarsius/tray")
;; Local Variables:
;; no-byte-compile: t
;; End:
