(define-package "consult" "20220408.145" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "23023d91c4e1aabbd6dbecc5fcb507e209b56019" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
