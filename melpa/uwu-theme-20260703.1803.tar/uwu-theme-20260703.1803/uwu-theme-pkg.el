;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uwu-theme" "20260703.1803"
  "An awesome dark color scheme."
  '((emacs "24.1"))
  :url "https://github.com/kborling/uwu-theme"
  :commit "10b07fae92e2b28d7f3948e5feba0e3172123370"
  :revdesc "10b07fae92e2"
  :keywords '("custom themes" "dark" "faces"))
