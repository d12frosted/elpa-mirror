(define-package "hammy" "20231108.23" "Programmable, interactive interval timers"
  '((emacs "28.1")
    (svg-lib "0.2.5")
    (ts "0.2.2"))
  :commit "c28a4a704f57f0e889110063edaf0f186feace0f" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/hammy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
