;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250927.2313"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "755ee8a8282f37ef4677260d0d0a3cdc259433cb"
  :revdesc "755ee8a8282f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
