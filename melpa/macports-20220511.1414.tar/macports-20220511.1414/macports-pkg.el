(define-package "macports" "20220511.1414" "A porcelain for MacPorts"
  '((emacs "25.1")
    (transient "0.1.0"))
  :commit "c3c0616af55d4327da727da01780253b6678a7cc" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("convenience")
  :url "https://github.com/amake/macports.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
