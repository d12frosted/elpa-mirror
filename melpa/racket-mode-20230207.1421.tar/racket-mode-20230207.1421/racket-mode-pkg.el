(define-package "racket-mode" "20230207.1421" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "2ce4bc3ee0c1b1e4bb93d99122b0822832f29b9d" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
