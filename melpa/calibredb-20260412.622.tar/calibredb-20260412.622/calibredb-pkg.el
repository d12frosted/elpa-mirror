;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calibredb" "20260412.622"
  "Yet another calibre client."
  '((emacs     "29.1")
    (org       "9.3")
    (transient "0.1.0")
    (s         "1.12.0")
    (dash      "2.17.0")
    (request   "0.3.3")
    (esxml     "0.3.7"))
  :url "https://github.com/chenyanming/calibredb.el"
  :commit "af6fc49edf72f0ebc42d9d3983ad00c268541092"
  :revdesc "af6fc49edf72"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
