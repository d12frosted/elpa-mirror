;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20260404.1956"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "a73b462b7cfc60e916da993502997e436fedee7e"
  :revdesc "a73b462b7cfc"
  :keywords '("frames")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
