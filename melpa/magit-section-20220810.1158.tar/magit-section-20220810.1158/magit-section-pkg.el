(define-package "magit-section" "20220810.1158" "Sections for read-only buffers."
  '((emacs "25.1")
    (compat "28.1.1.2")
    (dash "20210826"))
  :commit "9ffaed3f6bc743abd88402c412b970fc2ae2ea91" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
