;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260325.59"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "7ca945420b2e7d0b68b975ca662e15228126fbf3"
  :revdesc "7ca945420b2e"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
