;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-relative-date" "20260923.1103"
  "Live relative-date overlays on org timestamps."
  '((emacs "27.1")
    (org   "9.1"))
  :url "https://github.com/RobertPlant/org-relative-date"
  :commit "dd36792afc93b1dd97f9755ae373210327b38f7f"
  :revdesc "dd36792afc93"
  :keywords '("calendar" "org" "convenience")
  :authors '(("Rob Plant" . "rob@robertplant.io"))
  :maintainers '(("Rob Plant" . "rob@robertplant.io")))
