(define-package "lacquer" "20230206.756" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "8a4e7dc1827862ad025f2af5354ca377cc660939" :authors
  '(("zakudriver" . "zy.hua1122@gmail.com"))
  :maintainer
  '("zakudriver" . "zy.hua1122@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/zakudriver/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
