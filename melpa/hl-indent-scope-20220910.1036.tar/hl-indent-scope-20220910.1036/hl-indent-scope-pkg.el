(define-package "hl-indent-scope" "20220910.1036" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "f2168588fe1d29ab14b4d73d660d51a48547827e" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
