;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260802.1020"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "c17d22968425d49fca9c11cd4f8354f7e5af2ac8"
  :revdesc "c17d22968425"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
