;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remind-bindings" "20200820.1723"
  "Reminders for your init bindings."
  '((emacs       "25.1")
    (omni-quotes "0.5")
    (popwin      "1.0")
    (map         "2.0"))
  :url "https://github.com/mtekman/remind-bindings.el"
  :commit "c9a327bfd3c68a0c41b5b64df491bdee4c73ca39"
  :revdesc "c9a327bfd3c6"
  :keywords '("outlines"))
