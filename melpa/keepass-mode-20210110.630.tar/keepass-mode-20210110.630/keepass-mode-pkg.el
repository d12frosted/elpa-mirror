(define-package "keepass-mode" "20210110.630" "Mode for KeePass DB."
  '((emacs "27"))
  :commit "cd07542fddf080927eae927afdcf62be1b087503" :authors
  '(("Ignasi Fosch" . "natx@y10k.ws"))
  :maintainer
  '("Ignasi Fosch" . "natx@y10k.ws")
  :keywords
  '("data" "files" "tools")
  :url "https://github.com/ifosch/keepass-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
