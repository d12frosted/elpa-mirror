;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-ts-mode" "20260418.410"
  "Tree-sitter support for OpenSCAD."
  '((emacs "29.3"))
  :url "https://github.com/yoshinari-nomura/scad-ts-mode"
  :commit "9a61e0ad7a9cf2c4274553a35fc8643506d40c68"
  :revdesc "9a61e0ad7a9c"
  :keywords '("openscad" "languages" "tree-sitter")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
