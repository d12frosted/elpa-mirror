;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-box" "20260309.526"
  "Display documentation in childframe."
  '((emacs "27.1"))
  :url "https://github.com/casouri/eldoc-box"
  :commit "820ea6ad1fe62883e065c43523140eaa441b4b81"
  :revdesc "820ea6ad1fe6"
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
