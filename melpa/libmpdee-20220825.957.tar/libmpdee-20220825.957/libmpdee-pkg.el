;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "libmpdee" "20220825.957"
  "Client end library for mpd, a music playing daemon."
  ()
  :url "https://github.com/andyetitmoves/libmpdee"
  :commit "9a84e074385cd085622f94e720a968a0e05ceae5"
  :revdesc "9a84e074385c"
  :keywords '("music" "mpd")
  :authors '(("Ramkumar R. Aiyengar" . "andyetitmoves@gmail.com"))
  :maintainers '(("Ramkumar R. Aiyengar" . "andyetitmoves@gmail.com")))
