;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260522.506"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "73bd082991baeabb996741f5de1c2f378b612d57"
  :revdesc "73bd082991ba"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
