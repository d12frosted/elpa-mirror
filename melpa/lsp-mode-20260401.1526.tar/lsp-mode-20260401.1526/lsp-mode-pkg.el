;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260401.1526"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "fb384fed198fa9012fd9788220e23e672f7d8619"
  :revdesc "fb384fed198f"
  :keywords '("languages"))
