(define-package "go-translate" "20240507.724" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "53bff41894121fa094937c41e8760b2b5d2b5464" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
