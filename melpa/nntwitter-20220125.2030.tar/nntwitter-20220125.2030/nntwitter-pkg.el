(define-package "nntwitter" "20220125.2030" "Gnus Backend For Twitter"
  '((emacs "25.1")
    (dash "20190401")
    (anaphora "20180618")
    (request "20190819"))
  :commit "221902b1acb3ed4f9527eaee6584c2d9ff0d309f" :keywords
  '("news")
  :url "https://github.com/dickmao/nntwitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
