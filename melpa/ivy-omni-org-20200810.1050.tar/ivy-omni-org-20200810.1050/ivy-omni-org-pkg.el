;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-omni-org" "20200810.1050"
  "Browse anything in Org mode."
  '((emacs "25.1")
    (ivy   "0.13")
    (dash  "2.12"))
  :url "https://github.com/akirak/ivy-omni-org"
  :commit "b6a27379bc40fd6530a84afc50b3f41cd488e0c9"
  :revdesc "b6a27379bc40"
  :keywords '("outlines")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
