;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250521.1517"
  "Mordern HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "78332c9109cbaeaf5d1d8adb84d4d4a02beff4a8"
  :revdesc "78332c9109cb"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
