;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sourcemap" "20200315.1037"
  "Sourcemap parser."
  '((emacs "24.3"))
  :url "https://github.com/syohex/emacs-sourcemap"
  :commit "bb2a56b2feb62b0c77d7f03ef2acd94f91be6b3f"
  :revdesc "bb2a56b2feb6"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
