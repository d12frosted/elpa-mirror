(define-package "lister" "20211003.1433" "Yet another list printer"
  '((emacs "26.1"))
  :commit "40e2966389b42bf0d6af51eaa88ddbd3e80ca72b" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
