;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "varuga" "20250618.138"
  "Send ical calendar invites by email."
  '((emacs "27.1"))
  :url "https://git.systemreboot.net/varuga"
  :commit "ee9242a9b5ee69821c1dd8de258ecfd6ad616802"
  :revdesc "ee9242a9b5ee"
  :authors '(("Arun Isaac" . "arunisaac@systemreboot.net"))
  :maintainers '(("Arun Isaac" . "arunisaac@systemreboot.net")))
