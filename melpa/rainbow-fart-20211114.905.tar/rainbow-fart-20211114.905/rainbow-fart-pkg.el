(define-package "rainbow-fart" "20211114.905" "Checks the keywords of code to play suitable sounds"
  '((emacs "25.1")
    (flycheck "32snapshot"))
  :commit "aaaec8e20b3bde3a567baa501623c451f796a46a" :keywords
  '("tools")
  :url "https://github.com/stardiviner/emacs-rainbow-fart")
;; Local Variables:
;; no-byte-compile: t
;; End:
