(define-package "timu-line" "20231001.2029" "Custom and simple mode line"
  '((emacs "28.1")
    (f "0.20.0"))
  :commit "f0682223785e2699213e0601ffadbc8a213231c6" :authors
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainer
  '("Aimé Bertrand" . "aime.bertrand@macowners.club")
  :keywords
  '("modeline" "frames" "ui")
  :url "https://gitlab.com/aimebertrand/timu-line")
;; Local Variables:
;; no-byte-compile: t
;; End:
