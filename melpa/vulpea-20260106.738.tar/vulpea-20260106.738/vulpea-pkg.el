;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260106.738"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "0304cb02df0047baf6ad043dfe4e792eb2d27e76"
  :revdesc "0304cb02df00"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
