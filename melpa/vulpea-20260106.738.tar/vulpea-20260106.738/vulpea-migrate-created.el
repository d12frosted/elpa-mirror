;;; vulpea-migrate-created.el --- Add CREATED property to notes  -*- lexical-binding: t; -*-
;;
;; Copyright (c) 2015-2026 Boris Buliga <boris@d12frosted.io>
;;
;; Author: Boris Buliga <boris@d12frosted.io>
;; Maintainer: Boris Buliga <boris@d12frosted.io>
;;
;;; Commentary:
;;
;; Migration script to add CREATED property to existing notes.
;;
;; Heuristics priority:
;; 1. Filename patterns (YYYY-MM-DD.org or YYYYMMDDHHmmss-slug.org)
;; 2. Git history (first commit date) - optional, slow
;; 3. File system modification time (fallback)
;;
;; Usage:
;;   ;; Dry run (default) - just reports what would be done
;;   (vulpea-migrate-created-run)
;;
;;   ;; Limit to first N notes (for testing)
;;   (vulpea-migrate-created-run :limit 100)
;;
;;   ;; Enable git lookup (slow but more accurate)
;;   (vulpea-migrate-created-run :use-git t)
;;
;;   ;; Actually apply changes
;;   (vulpea-migrate-created-run :dry-run nil)
;;
;;   ;; Process specific notes
;;   (vulpea-migrate-created-run :notes (list note1 note2))
;;
;;; Code:

(require 'vulpea)
(require 'vulpea-db)
(require 'vulpea-utils)

(defvar vulpea-migrate-created--date-format "%Y-%m-%d"
  "Format for CREATED property value.")

(defun vulpea-migrate-created--parse-filename (filename)
  "Try to extract date from FILENAME.

Supports patterns:
- YYYY-MM-DD.org (journal files)
- YYYYMMDDHHmmss-slug.org or YYYYMMDDHHmmss_slug.org

Returns date string in `vulpea-migrate-created--date-format' or nil."
  (let ((name (file-name-sans-extension (file-name-nondirectory filename))))
    (cond
     ;; Pattern: YYYY-MM-DD
     ((string-match "^\\([0-9]\\{4\\}\\)-\\([0-9]\\{2\\}\\)-\\([0-9]\\{2\\}\\)$" name)
      (format "%s-%s-%s"
              (match-string 1 name)
              (match-string 2 name)
              (match-string 3 name)))

     ;; Pattern: YYYYMMDDHHmmss-slug or YYYYMMDDHHmmss_slug
     ((string-match "^\\([0-9]\\{4\\}\\)\\([0-9]\\{2\\}\\)\\([0-9]\\{2\\}\\)[0-9]\\{6\\}[-_]" name)
      (format "%s-%s-%s"
              (match-string 1 name)
              (match-string 2 name)
              (match-string 3 name)))

     (t nil))))

(defun vulpea-migrate-created--git-date (filepath)
  "Get the first commit date for FILEPATH from git history.

Returns date string in `vulpea-migrate-created--date-format' or nil."
  (let* ((default-directory (file-name-directory filepath))
         (result (shell-command-to-string
                  (format "git log --diff-filter=A --follow --format=%%ai -- %s 2>/dev/null | tail -1"
                          (shell-quote-argument (file-name-nondirectory filepath))))))
    (when (and result
               (not (string-empty-p result))
               (string-match "^\\([0-9]\\{4\\}-[0-9]\\{2\\}-[0-9]\\{2\\}\\)" result))
      (match-string 1 result))))

(defun vulpea-migrate-created--file-mtime (filepath)
  "Get modification time of FILEPATH.

Returns date string in `vulpea-migrate-created--date-format'."
  (format-time-string
   vulpea-migrate-created--date-format
   (file-attribute-modification-time (file-attributes filepath))))

(defun vulpea-migrate-created--detect-date (note &optional use-git)
  "Detect creation date for NOTE using heuristics.

When USE-GIT is non-nil, also try git history (slow).

Returns a plist (:date DATE :source SOURCE) where SOURCE is one of:
- filename
- git
- mtime"
  (let* ((path (vulpea-note-path note))
         (filename-date (vulpea-migrate-created--parse-filename path))
         (git-date (when (and use-git (not filename-date))
                     (vulpea-migrate-created--git-date path)))
         (mtime-date (vulpea-migrate-created--file-mtime path)))
    (cond
     (filename-date
      (list :date filename-date :source 'filename))
     (git-date
      (list :date git-date :source 'git))
     (t
      (list :date mtime-date :source 'mtime)))))

(defun vulpea-migrate-created--has-created-p (note)
  "Check if NOTE already has CREATED property."
  (assoc "CREATED" (vulpea-note-properties note)))

(cl-defun vulpea-migrate-created-run (&key (dry-run t) notes limit use-git)
  "Add CREATED property to notes that don't have it.

When DRY-RUN is non-nil (default), only report what would be done.
When DRY-RUN is nil, actually modify the files.

NOTES is an optional list of notes to process. If nil, processes
all file-level notes from the database.

LIMIT limits processing to first N notes (useful for testing).

USE-GIT enables git history lookup (slow, ~1 sec per file).

Returns a list of plists with migration results."
  (interactive)
  (let* ((all-notes (or notes
                        (vulpea-db-query
                         (lambda (note)
                           (= 0 (vulpea-note-level note))))))
         (without-created (seq-remove #'vulpea-migrate-created--has-created-p all-notes))
         (already-have (- (length all-notes) (length without-created)))
         (to-process (if limit (seq-take without-created limit) without-created))
         (results nil)
         (by-source (list (cons 'filename 0)
                          (cons 'git 0)
                          (cons 'mtime 0))))
    (message "=== Vulpea CREATED Migration %s ==="
             (if dry-run "[DRY RUN]" "[APPLYING]"))
    (message "Total file-level notes: %d" (length all-notes))
    (message "Already have CREATED: %d" already-have)
    (message "Need CREATED: %d%s" (length to-process)
             (if limit (format " (limited from %d)" (length without-created)) ""))
    (message "Git lookup: %s" (if use-git "enabled (slow)" "disabled"))
    (message "")

    (if dry-run
        ;; Dry run - just analyze and report
        (let ((count 0)
              (total (length to-process)))
          (dolist (note to-process)
            (setq count (1+ count))
            (let* ((detection (vulpea-migrate-created--detect-date note use-git))
                   (date (plist-get detection :date))
                   (source (plist-get detection :source))
                   (path (vulpea-note-path note)))
              ;; Update counters
              (cl-incf (alist-get source by-source))
              ;; Log progress
              (message "[%d/%d] %s -> %s (via %s)"
                       count total
                       (file-name-nondirectory path)
                       date
                       source)
              (push (list :note note :date date :source source) results)
              ;; Yield to event loop periodically for responsiveness
              (when (zerop (% count 50))
                (sit-for 0)))))

      ;; Actually apply changes
      (vulpea-utils-process-notes to-process
        (let* ((detection (vulpea-migrate-created--detect-date it use-git))
               (date (plist-get detection :date))
               (source (plist-get detection :source)))
          ;; Update counters
          (cl-incf (alist-get source by-source))
          ;; Add the property
          (org-set-property "CREATED" date)
          (push (list :note it :date date :source source) results)))

      ;; Sync database for processed files (filenotify doesn't catch internal saves)
      (message "Syncing database...")
      (let ((paths (mapcar (lambda (r) (vulpea-note-path (plist-get r :note))) results))
            (count 0))
        (dolist (path paths)
          (vulpea-db-update-file path)
          (setq count (1+ count))
          ;; Yield to event loop periodically for responsiveness
          (when (zerop (% count 20))
            (sit-for 0)))))

    ;; Summary
    (message "")
    (message "=== Summary ===")
    (message "Processed: %d notes" (length to-process))
    (message "  - via filename: %d" (alist-get 'filename by-source))
    (message "  - via git:      %d" (alist-get 'git by-source))
    (message "  - via mtime:    %d" (alist-get 'mtime by-source))
    (when dry-run
      (message "")
      (message "Run with :dry-run nil to apply changes"))

    (nreverse results)))

(provide 'vulpea-migrate-created)
;;; vulpea-migrate-created.el ends here
