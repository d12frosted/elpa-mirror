(define-package "ligo-mode" "20230302.1616" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "d1073474efc9e0a020a4bcdf5e0c12a217265a3a" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
