(define-package "modus-themes" "20220325.456" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "aafd02640a6ea194badf44fa54f8a55880e80089" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
