(define-package "julia-mode" "20210824.747" "Major mode for editing Julia source code"
  '((emacs "24.3"))
  :commit "a1ba9a03a4b18a0d9536753efee623ab7afca596" :keywords
  '("languages")
  :url "https://github.com/JuliaEditorSupport/julia-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
