;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker-api" "20160525.720"
  "Emacs interface to the Docker API."
  '((dash    "2.12.1")
    (request "0.2.0")
    (s       "1.11.0"))
  :url "https://github.com/Silex/docker-api.el"
  :commit "206144346b7fa4165223349cfeb64a75d47ddd1b"
  :revdesc "206144346b7f"
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
