(define-package "speed-type" "20220810.1139" "Practice touch and speed typing"
  '((emacs "25.1"))
  :commit "93c05453a3f5265f9f8723ed449b18cca17b8fa9" :authors
  '(("Gunther Hagleitner"))
  :maintainer
  '("Daniel Kraus" . "daniel@kraus.my")
  :keywords
  '("games")
  :url "https://github.com/dakra/speed-type")
;; Local Variables:
;; no-byte-compile: t
;; End:
