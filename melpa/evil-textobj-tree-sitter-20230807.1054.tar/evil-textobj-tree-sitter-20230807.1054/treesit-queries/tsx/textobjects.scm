; inherits: typescript,jsx
