(define-package "evil-textobj-tree-sitter" "20230807.1054" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1"))
  :commit "c5f6368c6923f33057a62fc8808733c62609a761" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
