;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260117.2051"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "f624b2345e3cb0f410600eed65cf32c2f267b495"
  :revdesc "f624b2345e3c"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
