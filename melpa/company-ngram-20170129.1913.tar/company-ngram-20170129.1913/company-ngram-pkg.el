(define-package "company-ngram" "20170129.1913" "N-gram based completion"
  '((cl-lib "0.5")
    (company "0.8.0"))
  :commit "09a68b802e64799e95f205b438d469bbd78cd2e6" :authors
  '(("kshramt"))
  :maintainer
  '("kshramt")
  :url "https://github.com/kshramt/company-ngram")
;; Local Variables:
;; no-byte-compile: t
;; End:
