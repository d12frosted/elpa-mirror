;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ngram" "20170129.1913"
  "N-gram based completion."
  '((cl-lib  "0.5")
    (company "0.8.0"))
  :url "https://github.com/kshramt/company-ngram"
  :commit "d15182df3eac72b29772802759b77c9eafef5066"
  :revdesc "d15182df3eac")
