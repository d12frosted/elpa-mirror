;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260501.1707"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.8.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "fdd369d44604b2fc6ac33e9771a3cb757c638221"
  :revdesc "fdd369d44604"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
