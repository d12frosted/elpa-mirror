;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250317.1801"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (llama  "0.5.0")
    (el-job "2.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "bd81cd47917179c7d71b8c11c6f6eb8ff809bbeb"
  :revdesc "bd81cd479171"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
