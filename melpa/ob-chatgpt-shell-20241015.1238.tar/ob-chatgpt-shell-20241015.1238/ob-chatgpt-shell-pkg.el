;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-chatgpt-shell" "20241015.1238"
  "Org babel functions for ChatGPT evaluation."
  '((emacs         "27.1")
    (chatgpt-shell "1.0.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "5ab70e11537ab9c775bf80a1caf502c769e9b7fe"
  :revdesc "5ab70e11537a")
