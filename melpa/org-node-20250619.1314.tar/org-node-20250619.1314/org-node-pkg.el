;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250619.1314"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.16.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "ffca9a354d091202803513a61b89b9dde8c81ca8"
  :revdesc "ffca9a354d09"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
