(define-package "helm-proc" "20161006.305" "Helm interface for managing system processes"
  '((helm "1.6.0"))
  :commit "576d31c2d74ba3897d56e2acd2b0993f52c2547c")
;; Local Variables:
;; no-byte-compile: t
;; End:
