(define-package "memento-mori" "20240407.346" "Reminder of our mortality"
  '((emacs "24.4"))
  :commit "f5a5067946bf27f9d701dcd3f480ddf55561583e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainer
  '("Ivan Andrus" . "darthandrus@gmail.com")
  :keywords
  '("help")
  :url "https://github.com/gvol/emacs-memento-mori")
;; Local Variables:
;; no-byte-compile: t
;; End:
