;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260123.2043"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6e04a69aae1b78fc2f4c901d0538249b1820aa7a"
  :revdesc "6e04a69aae1b")
