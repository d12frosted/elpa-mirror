;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260301.1355"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "66d3ccafdf40b3fbfcf0bedce8b6ccfcfda1f010"
  :revdesc "66d3ccafdf40"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
