;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260526.2135"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "c1274c14bb1f20d0206aa292e5d751d817c04af5"
  :revdesc "c1274c14bb1f"
  :keywords '("data" "extensions"))
