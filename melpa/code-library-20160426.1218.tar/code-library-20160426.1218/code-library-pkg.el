;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-library" "20160426.1218"
  "Use org-mode to collect code snippets."
  '((gist "1.3.1"))
  :url "https://github.com/lujun9972/code-library"
  :commit "3c79338eae5c892bfb4e4882298422d9fd65d2d7"
  :revdesc "3c79338eae5c"
  :keywords '("lisp" "code")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
