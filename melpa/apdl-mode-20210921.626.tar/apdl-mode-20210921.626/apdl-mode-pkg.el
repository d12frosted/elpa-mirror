(define-package "apdl-mode" "20210921.626" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "db5a5b31a23d2a3391e41ab984db93153298f021" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
