;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20241202.1452"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "a8e37294ea05bb6100f0f3d24c8fe15cf498858a"
  :revdesc "a8e37294ea05"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
