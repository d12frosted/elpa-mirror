(define-package "vunit-mode" "20220316.1812" "VUnit Runner Interface"
  '((hydra "0.14.0")
    (emacs "24.3"))
  :commit "5643460a7011d6bc13c2d4762f329d19f6c7d46b" :authors
  '(("Lukas Lichtl" . "support@embed-me.com"))
  :maintainers
  '(("Lukas Lichtl" . "support@embed-me.com"))
  :maintainer
  '("Lukas Lichtl" . "support@embed-me.com")
  :keywords
  '("vunit" "python" "tools")
  :url "https://github.com/embed-me")
;; Local Variables:
;; no-byte-compile: t
;; End:
