;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260921.1658"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "df92d5c153b4321d2a4e287fed7adaef0f0242ca"
  :revdesc "df92d5c153b4"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
