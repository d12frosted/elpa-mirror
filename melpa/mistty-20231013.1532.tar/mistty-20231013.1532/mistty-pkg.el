(define-package "mistty" "20231013.1532" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "5d411da307c899ad0756cef7e9c203bb8efe8615" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
