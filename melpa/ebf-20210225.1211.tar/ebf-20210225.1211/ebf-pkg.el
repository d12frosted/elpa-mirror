;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebf" "20210225.1211"
  "Brainfuck language transpiler to Emacs Lisp."
  '((dash   "2.18.0")
    (cl-lib "0.5"))
  :url "https://github.com/rexim/ebf"
  :commit "6cbeb4d62416f4cfd5be8906667342af8ecc44a6"
  :revdesc "6cbeb4d62416"
  :authors '(("Alexey Kutepov" . "reximkut@gmail.com"))
  :maintainers '(("Alexey Kutepov" . "reximkut@gmail.com")))
