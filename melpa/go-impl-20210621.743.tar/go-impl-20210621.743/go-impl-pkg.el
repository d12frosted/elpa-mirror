;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-impl" "20210621.743"
  "Impl integration for go-mode."
  '((emacs   "24.3")
    (go-mode "1.3.0"))
  :url "https://github.com/syohex/emacs-go-impl"
  :commit "1eebba6ccd02d11a5a82ad4540a8d562797bc3b3"
  :revdesc "1eebba6ccd02"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
