(define-package "fanyi" "20230619.1600" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "72f6a7d038507203bbc1cd2d4e4b8cf00efeb3ed" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
