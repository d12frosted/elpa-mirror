;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260317.914"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "a17cb9c719520dc33e8a23032d822d6a043b906d"
  :revdesc "a17cb9c71952"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
