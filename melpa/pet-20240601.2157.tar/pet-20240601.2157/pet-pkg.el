(define-package "pet" "20240601.2157" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0")
    (map "3.3.1")
    (seq "2.24"))
  :commit "1cd18b74634dd8def83cc5d3d5630ca1db043152" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
