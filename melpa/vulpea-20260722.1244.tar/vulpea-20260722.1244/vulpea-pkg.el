;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260722.1244"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "771f5e77211dd486eaac179ffb2f731ba97914e2"
  :revdesc "771f5e77211d"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
