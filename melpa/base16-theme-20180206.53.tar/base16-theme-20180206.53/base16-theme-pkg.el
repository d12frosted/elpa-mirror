(define-package "base16-theme" "20180206.53" "Collection of themes built on combinations of 16 base colors" 'nil :commit "10180e88d6d9434cec367b6c91222dd2fc3bd8ae" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/belak/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
