;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260508.2207"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "d0f2be00b4f56a8fe466f335c2c09b70cf830cd6"
  :revdesc "d0f2be00b4f5"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
