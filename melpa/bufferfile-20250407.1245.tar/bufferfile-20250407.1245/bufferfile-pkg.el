;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20250407.1245"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "a0ef947b51b69cd7cabb9c7623af9d628e481587"
  :revdesc "a0ef947b51b6"
  :keywords '("convenience"))
