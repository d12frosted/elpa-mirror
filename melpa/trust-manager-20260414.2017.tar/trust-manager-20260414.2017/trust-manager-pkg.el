;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "20260414.2017"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "361cf9a357782f10be9da2a404495a86e6950eae"
  :revdesc "361cf9a35778"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
