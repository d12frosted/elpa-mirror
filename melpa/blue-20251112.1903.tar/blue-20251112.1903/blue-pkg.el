;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251112.1903"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "fe1cbbc2e5e9c1f42c3e94616fa868e8d9248255"
  :revdesc "fe1cbbc2e5e9"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
