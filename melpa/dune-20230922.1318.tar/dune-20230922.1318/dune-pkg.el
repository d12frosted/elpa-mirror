(define-package "dune" "20230922.1318" "Integration with the dune build system" 'nil :commit "e3bfd215dd35cf702b3af66be03f2912b69b0a0a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
