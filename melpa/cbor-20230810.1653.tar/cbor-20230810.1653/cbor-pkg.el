;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cbor" "20230810.1653"
  "CBOR utilities."
  '((emacs "25.1"))
  :url "https://github.com/Titan-C/cardano.el"
  :commit "ba624ad3f8b726bee1d8dcb0a2a9e2b658bb4c9b"
  :revdesc "ba624ad3f8b7"
  :authors '(("Oscar Najera" . "https://oscarnajera.com"))
  :maintainers '(("Oscar Najera" . "hi@oscarnajera.com")))
