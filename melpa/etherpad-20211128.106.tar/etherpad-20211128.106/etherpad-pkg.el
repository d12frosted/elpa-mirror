(define-package "etherpad" "20211128.106" "Interface to the Etherpad API"
  '((emacs "26.3")
    (request "0.3")
    (let-alist "0.0")
    (websocket "1.12")
    (parsec "0.1")
    (0xc "0.1"))
  :commit "1fae6a03084e0794e09ac036838b53aaae1dbd63" :authors
  '(("nik gaffney" . "nik@fo.am"))
  :maintainers
  '(("nik gaffney" . "nik@fo.am"))
  :maintainer
  '("nik gaffney" . "nik@fo.am")
  :keywords
  '("comm" "etherpad" "collaborative editing")
  :url "https://github.com/zzkt/ethermacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
