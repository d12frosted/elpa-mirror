;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash" "20260217.1302"
  "Flash-style navigation."
  '((emacs "27.1"))
  :url "https://github.com/Prgebish/flash"
  :commit "0c3029da4017fcbdc5e7bc9d68dac2e27e9f546d"
  :revdesc "0c3029da4017"
  :keywords '("convenience" "navigation")
  :authors '(("Vadim Pavlov" . "https://github.com/Prgebish"))
  :maintainers '(("Vadim Pavlov" . "https://github.com/Prgebish")))
