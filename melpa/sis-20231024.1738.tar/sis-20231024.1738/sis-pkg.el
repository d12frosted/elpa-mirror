(define-package "sis" "20231024.1738" "Less manual switch for native or OS input source (input method)."
  '((emacs "25.1")
    (terminal-focus-reporting "0.0"))
  :commit "80b2e7c3be365c7685cc4070294359341799cd47" :keywords
  '("convenience")
  :url "https://github.com/laishulu/emacs-smart-input-source")
;; Local Variables:
;; no-byte-compile: t
;; End:
