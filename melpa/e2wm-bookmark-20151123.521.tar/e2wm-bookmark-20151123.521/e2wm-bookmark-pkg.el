;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-bookmark" "20151123.521"
  "Bookmark plugin for e2wm.el."
  '((e2wm "1.2"))
  :url "https://github.com/myuhe/e2wm-bookmark.el"
  :commit "bad816b6d8049984d69bcd277b7d325fb84d55eb"
  :revdesc "bad816b6d804"
  :keywords '("convenience")
  :authors '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com"))
  :maintainers '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com")))
