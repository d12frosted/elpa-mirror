;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mmt" "20230606.1513"
  "Missing macro tools for Emacs Lisp."
  '((emacs "24.5"))
  :url "https://github.com/mrkkrp/mmt"
  :commit "2a24463eeb72ebef100e89977ebfb88f5f220217"
  :revdesc "2a24463eeb72"
  :keywords '("macro" "lisp" "extensions")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
