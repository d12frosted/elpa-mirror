(define-package "org-link-beautify" "20230414.1339" "Beautify Org Links"
  '((emacs "28.1")
    (all-the-icons "5.0.0"))
  :commit "1b9fc4c4e3bc4d505ad1797983d752bbacaef129" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
