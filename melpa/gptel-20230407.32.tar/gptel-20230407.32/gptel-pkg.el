(define-package "gptel" "20230407.32" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "6c47c0a48306e127557caf54c5a03e162e2d2ed3" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
