;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20261028.1115"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "c95ceeeffff6b39725842c5416789778e3d6b5f3"
  :revdesc "c95ceeeffff6"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
