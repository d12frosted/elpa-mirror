;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nael" "20260114.2208"
  "Major mode for Lean."
  '((emacs "29.1"))
  :url "https://codeberg.org/mekeor/nael"
  :commit "97114434492e3fa1b3c2795d3120ca78628d9765"
  :revdesc "97114434492e"
  :keywords '("languages")
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
