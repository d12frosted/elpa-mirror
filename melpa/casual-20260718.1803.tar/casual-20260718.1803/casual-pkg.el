;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260718.1803"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "cadbeab2ec45804e63a328202c9a82fbed2413c5"
  :revdesc "cadbeab2ec45"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
