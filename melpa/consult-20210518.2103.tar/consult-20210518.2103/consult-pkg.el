(define-package "consult" "20210518.2103" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "4852f57fcd3de57d7b18f7f5728d0b732324aaca" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
