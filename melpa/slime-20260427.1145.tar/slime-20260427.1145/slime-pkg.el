;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260427.1145"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "97efbc14ec6baebb7598e6dd314ee9f1d87b2836"
  :revdesc "97efbc14ec6b"
  :keywords '("languages" "lisp" "slime"))
