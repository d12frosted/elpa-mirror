(define-package "org-alert" "20230520.1449" "Notify org deadlines via notify-send"
  '((org "9.0")
    (alert "1.2"))
  :commit "87abaeac60e37fda530787988e00307a1f72fedb" :authors
  '(("Stephen Pegoraro" . "spegoraro@tutive.com"))
  :maintainers
  '(("Stephen Pegoraro" . "spegoraro@tutive.com"))
  :maintainer
  '("Stephen Pegoraro" . "spegoraro@tutive.com")
  :keywords
  '("org" "org-mode" "notify" "notifications" "calendar")
  :url "https://github.com/spegoraro/org-alert")
;; Local Variables:
;; no-byte-compile: t
;; End:
