(define-package "edit-as-format" "20220214.549" "Edit document as other format"
  '((emacs "26.1")
    (edit-indirect "0.1.5"))
  :commit "95418d52e3359491a822a1693f51187181a7a603" :authors
  '(("Xiaobing Jing" . "jingxiaobing@gmail.com"))
  :maintainer
  '("Xiaobing Jing" . "jingxiaobing@gmail.com")
  :keywords
  '("files" "outlines" "convenience")
  :url "https://github.com/etern/edit-as-format")
;; Local Variables:
;; no-byte-compile: t
;; End:
