(define-package "edit-as-format" "20220214.549" "Edit document as other format"
  '((emacs "26.1")
    (edit-indirect "0.1.5"))
  :commit "c1247f25046a90967b4fbd20e5b28b62892da78f" :authors
  '(("Xiaobing Jing" . "jingxiaobing@gmail.com"))
  :maintainer
  '("Xiaobing Jing" . "jingxiaobing@gmail.com")
  :keywords
  '("files" "outlines" "convenience")
  :url "https://github.com/etern/edit-as-format")
;; Local Variables:
;; no-byte-compile: t
;; End:
