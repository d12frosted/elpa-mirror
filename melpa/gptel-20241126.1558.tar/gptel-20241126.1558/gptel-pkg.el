;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241126.1558"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "e10c26e97e20c597d110c40f49c73fb63c057396"
  :revdesc "e10c26e97e20"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
