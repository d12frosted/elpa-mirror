(define-package "closql" "20240701.821" "Store EIEIO objects using EmacSQL"
  '((emacs "26.1")
    (compat "29.1.4.5")
    (emacsql "20240124"))
  :commit "7ab214c615480bb6f686fc12322c3b3fc53b3579" :authors
  '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev")
  :keywords
  '("extensions")
  :url "https://github.com/emacscollective/closql")
;; Local Variables:
;; no-byte-compile: t
;; End:
