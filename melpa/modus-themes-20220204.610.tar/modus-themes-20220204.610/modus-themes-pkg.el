(define-package "modus-themes" "20220204.610" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "91ef46502c277f325ddd757806667dfa741a64cc" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
