(define-package "consult" "20211004.2051" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "d96147aaff3029bf36011603f55ff651791a43f8" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
