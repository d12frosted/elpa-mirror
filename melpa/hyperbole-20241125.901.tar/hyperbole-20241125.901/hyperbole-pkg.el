;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241125.901"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "94a3d0c3d0a2cad3cefb2444972a2688217380ee"
  :revdesc "94a3d0c3d0a2"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
