;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20260609.1424"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "36b336d7675edfb976768465c5067bc8bc16ee9a"
  :revdesc "36b336d7675e"
  :keywords '("erlang" "languages" "processes"))
