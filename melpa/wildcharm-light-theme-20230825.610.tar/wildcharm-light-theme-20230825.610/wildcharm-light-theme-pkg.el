(define-package "wildcharm-light-theme" "20230825.610" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "5a8f420493b68c7bc460bc1fdc41b26c3ad1a738" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
