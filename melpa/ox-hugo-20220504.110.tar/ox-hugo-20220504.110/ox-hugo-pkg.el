(define-package "ox-hugo" "20220504.110" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0")
    (tomelr "0.2.2"))
  :commit "d33c8cbf9b9047746bb23cb8a4753f270339b449" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
