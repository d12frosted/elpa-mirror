;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251025.1501"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "f84e45cbaf19a433d83bf0df9bf28d7e9ec49956"
  :revdesc "f84e45cbaf19"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
