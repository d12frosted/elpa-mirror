;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20260318.1025"
  "Display documentation for mouse hover."
  '((emacs    "27.1")
    (posframe "1.4.0")
    (eglot    "1.8"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "0fdde5461ecf688f75b8b379713b335d25af81f8"
  :revdesc "0fdde5461ecf"
  :keywords '("tools" "languages" "convenience" "mouse" "hover")
  :authors '(("Huang Feiyu" . "sibadake1@163.com"))
  :maintainers '(("Huang Feiyu" . "sibadake1@163.com")))
