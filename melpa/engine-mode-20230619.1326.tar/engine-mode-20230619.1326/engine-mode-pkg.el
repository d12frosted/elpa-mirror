(define-package "engine-mode" "20230619.1326" "Define and query search engines"
  '((emacs "24.3"))
  :commit "81d4ae1054dab2dbf81c1efbed50f27112dddbb1" :authors
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainers
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainer
  '("Harry R. Schwartz" . "hello@harryrschwartz.com")
  :url "https://github.com/hrs/engine-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
