;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-marker-icons" "20250228.119"
  "Display icons for mu4e markers."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/mu4e-marker-icons.git"
  :commit "4d9bdea919583ce3e2895bfd44383624ed6bc3ca"
  :revdesc "4d9bdea91958"
  :keywords '("mail"))
