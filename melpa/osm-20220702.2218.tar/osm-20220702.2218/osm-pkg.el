(define-package "osm" "20220702.2218" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "d847f1aca747d2c8cfe97c547e9387e568b3706e" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
