(define-package "osm" "20220702.2218" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "b8dee7a7c3a6954df26c5aa0eb5f7de1f4f4159b" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
