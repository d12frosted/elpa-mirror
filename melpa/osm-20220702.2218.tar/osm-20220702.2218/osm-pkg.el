(define-package "osm" "20220702.2218" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "808baabecd9882736b240e6ea9344047aeb669e2" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
