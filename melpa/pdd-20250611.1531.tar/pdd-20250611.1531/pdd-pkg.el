;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250611.1531"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "969fc03fd2a5fe010ec517976ed91f83eb51537f"
  :revdesc "969fc03fd2a5"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
