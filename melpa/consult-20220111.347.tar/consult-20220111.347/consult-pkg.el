(define-package "consult" "20220111.347" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "eda8dbd1a78547fe86e611fe02558e63b57dcf45" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
