(define-package "iedit" "20211223.1134" "Edit multiple regions in the same way simultaneously." 'nil :commit "070775fb85b233351bd17b534d2dec9157f5311e" :authors
  '(("Victor Ren" . "victorhge@gmail.com"))
  :maintainer
  '("Victor Ren" . "victorhge@gmail.com")
  :keywords
  '("occurrence" "region" "simultaneous" "refactoring")
  :url "https://github.com/victorhge/iedit")
;; Local Variables:
;; no-byte-compile: t
;; End:
