;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251229.1454"
  "An Org-social client for Emacs."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "0394bd9c207ecd9c49fb5593a6350ac731630342"
  :revdesc "0394bd9c207e"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
