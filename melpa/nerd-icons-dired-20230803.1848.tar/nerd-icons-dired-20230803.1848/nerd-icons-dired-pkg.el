(define-package "nerd-icons-dired" "20230803.1848" "Shows icons for each file in dired mode"
  '((emacs "24.4")
    (nerd-icons "0.0.1"))
  :commit "00038929395a2a10ed5614b59161f29f9e0ffddc" :authors
  '(("Hongyu Ding" . "rainstormstudio@yahoo.com"))
  :maintainers
  '(("Hongyu Ding" . "rainstormstudio@yahoo.com"))
  :maintainer
  '("Hongyu Ding" . "rainstormstudio@yahoo.com")
  :keywords
  '("lisp")
  :url "https://github.com/rainstormstudio/nerd-icons-dired")
;; Local Variables:
;; no-byte-compile: t
;; End:
