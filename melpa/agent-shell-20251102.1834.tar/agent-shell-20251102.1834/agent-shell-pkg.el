;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251102.1834"
  "An agent shell powered by ACP."
  '((emacs       "29.1")
    (shell-maker "0.82.2")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "fa86fe55bae623ab91ac7147f4e1d8fea4f9e136"
  :revdesc "fa86fe55bae6")
