;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250601.813"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "51cbe0f15a46731b7b72e05eeacd433788134aa4"
  :revdesc "51cbe0f15a46"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
