(define-package "diff-ansi" "20230808.1343" "Display diff's using alternative diffing tools"
  '((emacs "27.1"))
  :commit "c14d1f6c58ddf579cba86b95d160f71589c8cd04" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi")
;; Local Variables:
;; no-byte-compile: t
;; End:
