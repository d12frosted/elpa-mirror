(define-package "erlang" "20211213.1046" "Erlang major mode"
  '((emacs "24.1"))
  :commit "73737c1e3e4842d493f1c9dfa95f0fa0e7878ce8" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
