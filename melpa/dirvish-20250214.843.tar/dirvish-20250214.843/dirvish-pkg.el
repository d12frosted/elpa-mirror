;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250214.843"
  "A modern file manager based on dired mode."
  '((emacs     "27.1")
    (transient "0.3.7"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "ed9a2f077c76a2461ec6dc119a5cf5789f35c9cf"
  :revdesc "ed9a2f077c76"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
