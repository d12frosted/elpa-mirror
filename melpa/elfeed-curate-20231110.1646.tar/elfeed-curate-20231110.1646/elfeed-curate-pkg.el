(define-package "elfeed-curate" "20231110.1646" "Elfeed entry curation"
  '((emacs "25.1")
    (elfeed "3.4.1"))
  :commit "8d3628c81fc7dd9fefb9c5beca9fe4eab3575238" :authors
  '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainers
  '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainer
  '("Robert Nadler" . "robert.nadler@gmail.com")
  :keywords
  '("news")
  :url "https://github.com/rnadler/elfeed-curate")
;; Local Variables:
;; no-byte-compile: t
;; End:
