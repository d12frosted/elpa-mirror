(define-package "status" "20151230.1408" "This package adds support for status icons to Emacs." 'nil :commit "b62c74bf272566f82a68622f29fb9edafea0f241")
;; Local Variables:
;; no-byte-compile: t
;; End:
