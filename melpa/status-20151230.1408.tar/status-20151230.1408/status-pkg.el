(define-package "status" "20151230.1408" "This package adds support for status icons to Emacs." 'nil :commit "b62c74bf272566f82a68622f29fb9edafea0f241" :authors
  (("Tom Tromey" . "tom@tromey.com"))
  :maintainer
  ("Tom Tromey" . "tom@tromey.com")
  :keywords
  ("frames" "multimedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
