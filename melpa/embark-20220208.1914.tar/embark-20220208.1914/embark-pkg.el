(define-package "embark" "20220208.1914" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "1e7cc508b46fb862351450d03a560651781aeedc" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
