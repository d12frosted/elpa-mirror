(define-package "templ-ts-mode" "20240108.142" "Major mode for editing Templ files"
  '((emacs "29.1"))
  :commit "9e41b828b014c615b1cd9fc577e2f76a214d3ff8" :authors
  '(("David Anderson" . "dave@natulte.net"))
  :maintainers
  '(("David Anderson" . "dave@natulte.net"))
  :maintainer
  '("David Anderson" . "dave@natulte.net")
  :keywords
  '("languages")
  :url "https://github.com/danderson/templ-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
