;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260412.811"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "348394cbd9d8a25b61bccd284196c97a065b7013"
  :revdesc "348394cbd9d8"
  :keywords '("data" "extensions"))
