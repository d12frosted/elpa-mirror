(define-package "dall-e-shell" "20231109.913" "Interaction mode for DALL-E"
  '((emacs "27.1")
    (shell-maker "0.42.1"))
  :commit "ad7caa8bde9d9e3e4f09458e6542ae1318949b2b" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
