(define-package "cern-ldap" "20230418.1249" "Library to interact with CERN's LDAP servers"
  '((emacs "27.1"))
  :commit "7a2dfa4c5ec9d05ec0c4e90caedae8508a96196c" :authors
  '(("Nacho Barrientos" . "nacho.barrientos@cern.ch"))
  :maintainers
  '(("Nacho Barrientos" . "nacho.barrientos@cern.ch"))
  :maintainer
  '("Nacho Barrientos" . "nacho.barrientos@cern.ch")
  :keywords
  '("tools" "convenience")
  :url "https://git.sr.ht/~nbarrientos/cern-ldap.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
