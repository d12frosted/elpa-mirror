;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250528.727"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "3a55a3a54995540c8f274153c3cbbe395460aba0"
  :revdesc "3a55a3a54995"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
