;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "20260331.446"
  "Project-wide grep search."
  '((emacs "27.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "270c094f6b64840e2f57db148e1df13702b0c83e"
  :revdesc "270c094f6b64"
  :keywords '("tools" "search" "grep" "convenience" "project"))
