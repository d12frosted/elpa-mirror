;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20260209.1941"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.82.3")
    (transient   "0.9.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "adb5c9230cf328e865bcff8fc48418e158d4bf49"
  :revdesc "adb5c9230cf3")
