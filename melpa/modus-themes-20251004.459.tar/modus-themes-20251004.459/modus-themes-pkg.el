;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251004.459"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "91cd9dfed3a2f0c42bc0c66e72168bc22aebf1c1"
  :revdesc "91cd9dfed3a2"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
