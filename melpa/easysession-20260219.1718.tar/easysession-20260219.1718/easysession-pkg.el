;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260219.1718"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "b53d4ba3143885f0b6fafd9d273d48166c7b618f"
  :revdesc "b53d4ba31438"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
