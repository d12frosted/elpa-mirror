;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260203.1010"
  "AI-LLM chat block for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "cdf6d150cb8f2c44b27b402654c46935397803bf"
  :revdesc "cdf6d150cb8f"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
