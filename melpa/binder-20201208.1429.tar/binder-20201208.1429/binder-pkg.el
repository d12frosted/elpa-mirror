(define-package "binder" "20201208.1429" "Global minor mode to facilitate multi-file writing projects"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "bc63f9fdfe10fcf799abab3f8d8deb38c51e9f80" :keywords
  ("files" "outlines" "wp" "text")
  :authors
  (("Paul W. Rankin" . "pwr@skeletons.cc"))
  :maintainer
  ("Paul W. Rankin" . "pwr@skeletons.cc")
  :url "https://git.skeletons.cc/binder")
;; Local Variables:
;; no-byte-compile: t
;; End:
