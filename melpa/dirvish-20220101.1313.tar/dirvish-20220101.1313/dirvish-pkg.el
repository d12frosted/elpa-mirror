(define-package "dirvish" "20220101.1313" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e3377c39f457f4bc376d412a8ff8084713ceb2a6" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
