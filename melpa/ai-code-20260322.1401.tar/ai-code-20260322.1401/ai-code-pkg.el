;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260322.1401"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a89174fdf2db4c75202b37a73599a2eb4d32ae01"
  :revdesc "a89174fdf2db"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
