;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-linuxmag-fr" "20250907.1103"
  "Org-mode exporter for the French GNU/Linux Magazine."
  '((emacs "28.1"))
  :url "https://github.com/DamienCassou/ox-linuxmag-fr"
  :commit "67381be882a384e0e0ed810b24556148c0eb6b9f"
  :revdesc "67381be882a3"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
