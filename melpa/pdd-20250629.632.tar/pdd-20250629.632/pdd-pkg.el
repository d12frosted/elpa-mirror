;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250629.632"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "cdd4c4e6e0c946b34013027c7b3158809402e4e8"
  :revdesc "cdd4c4e6e0c9"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
