;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "20260215.2013"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "a33c16dca1f8669db7132500cedab959a271a62b"
  :revdesc "a33c16dca1f8"
  :keywords '("languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
