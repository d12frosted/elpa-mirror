;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective-exwm" "20231225.2313"
  "Better integration for perspective.el and EXWM."
  '((emacs       "27.1")
    (burly       "0.2-pre")
    (exwm        "0.26")
    (perspective "2.17"))
  :url "https://github.com/SqrtMinusOne/perspective-exwm.el"
  :commit "68fb0ca2d482e0f4a92c4ceb19bf2262ea937e95"
  :revdesc "68fb0ca2d482"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
