;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251031.814"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "c2acde4a478d9adacdeed56d808ccc67fd6916f9"
  :revdesc "c2acde4a478d"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
