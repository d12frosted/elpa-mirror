;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260524.1856"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "117a5704b6ec18c0986dab97d3b57d7b594c9012"
  :revdesc "117a5704b6ec"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
