(define-package "ecukes" "20220802.1502" "Cucumber for Emacs."
  '((commander "0.6.1")
    (espuds "0.2.2")
    (ansi "0.3.0")
    (dash "2.2.0")
    (s "1.8.0")
    (f "0.11.0"))
  :commit "3fff6edbf4acfab5b9e042c307bc5bbfac1c550f")
;; Local Variables:
;; no-byte-compile: t
;; End:
