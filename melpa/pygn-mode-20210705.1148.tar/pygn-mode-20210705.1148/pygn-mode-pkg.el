(define-package "pygn-mode" "20210705.1148" "Major-mode for chess PGN files, powered by Python"
  '((emacs "25.1")
    (uci-mode "0.5.4")
    (nav-flash "1.0.0")
    (ivy "0.10.0"))
  :commit "503ebb29de55d90e60bc7682f821d915cdbd0ae4" :authors
  '(("Dodge Coates and Roland Walker"))
  :maintainer
  '("Dodge Coates and Roland Walker")
  :keywords
  '("data" "games" "chess")
  :url "https://github.com/dwcoates/pygn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
