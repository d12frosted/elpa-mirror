(define-package "dwim-shell-command" "20220801.1958" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "3606b6a8a9246ff2fe0b20bdb9bc3404f9e23de9" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
