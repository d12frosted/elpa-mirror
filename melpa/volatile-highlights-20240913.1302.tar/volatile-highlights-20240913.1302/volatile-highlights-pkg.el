(define-package "volatile-highlights" "20240913.1302" "Minor mode for visual feedback on some operations." 'nil :commit "07f674fd8b8707e4d35d1f2532ea8b1d889dc066" :authors
  '(("K-talo Miyazaki" . "KeitarodotMiyazakiatgmaildotcom"))
  :maintainers
  '(("K-talo Miyazaki" . "KeitarodotMiyazakiatgmaildotcom"))
  :maintainer
  '("K-talo Miyazaki" . "KeitarodotMiyazakiatgmaildotcom")
  :keywords
  '("emulations" "convenience" "wp")
  :url "http://www.emacswiki.org/emacs/download/volatile-highlights.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
