;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250709.1023"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "61bac0aada02cb3d1b98fbec458e490bc0063a3f"
  :revdesc "61bac0aada02"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
