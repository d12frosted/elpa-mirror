;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20260914.1038"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "0884ccdfb85ad27e66e72417b2a225b7bdb8b389"
  :revdesc "0884ccdfb85a"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
