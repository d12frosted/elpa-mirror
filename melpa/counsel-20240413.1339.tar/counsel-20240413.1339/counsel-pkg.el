(define-package "counsel" "20240413.1339" "Various completion functions using Ivy"
  '((emacs "24.5")
    (ivy "0.14.2")
    (swiper "0.14.2"))
  :commit "49c749515d44395c06715aba0f98fcde3fd87d92" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers
  '(("Basil L. Contovounesios" . "basil@contovou.net"))
  :maintainer
  '("Basil L. Contovounesios" . "basil@contovou.net")
  :keywords
  '("convenience" "matching" "tools")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
