(define-package "consult" "20210112.1820" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9c2d766453332f7b3061132fdfe996ba54a2ed7d" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
