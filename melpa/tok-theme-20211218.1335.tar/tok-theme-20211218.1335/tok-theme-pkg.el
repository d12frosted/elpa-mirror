(define-package "tok-theme" "20211218.1335" "My theme"
  '((emacs "24.3"))
  :commit "b0285c1d4263363a879a373c9846199e311aff51" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
