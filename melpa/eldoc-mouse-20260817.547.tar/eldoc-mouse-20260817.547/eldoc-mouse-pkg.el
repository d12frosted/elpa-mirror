;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20260817.547"
  "Display documentation for mouse hover."
  '((emacs    "27.1")
    (posframe "1.5.1")
    (eglot    "1.23"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "a7ba5ad987c94d456868fd6c1a4def78b7f835b7"
  :revdesc "a7ba5ad987c9"
  :keywords '("tools" "languages" "convenience" "mouse" "hover")
  :authors '(("Huang Feiyu" . "sibadake1@163.com"))
  :maintainers '(("Huang Feiyu" . "sibadake1@163.com")))
