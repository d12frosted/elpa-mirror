;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dslide" "20241123.627"
  "Domain Specific sLIDEs. A presentation framework."
  '((emacs "29.2"))
  :url "https://github.com/positron-solutions/dslide"
  :commit "dee290e1c41fdcaa3be508f8476b3ca3a5e56ed1"
  :revdesc "dee290e1c41f"
  :keywords '("convenience" "org-mode" "presentation" "narrowing")
  :authors '(("Positron" . "contact@positron.solutions"))
  :maintainers '(("Positron" . "contact@positron.solutions")))
