;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260605.521"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "4932cf776c430bc86344b79dcff5159f76ce12a6"
  :revdesc "4932cf776c43"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
