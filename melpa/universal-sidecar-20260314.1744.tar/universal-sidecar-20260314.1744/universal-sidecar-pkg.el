;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "universal-sidecar" "20260314.1744"
  "A universal sidecar buffer."
  '((emacs         "26.1")
    (magit-section "3.0.0"))
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar"
  :commit "3b6bd928f7adb840e62a63dd5bf1236ece912b13"
  :revdesc "3b6bd928f7ad"
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
