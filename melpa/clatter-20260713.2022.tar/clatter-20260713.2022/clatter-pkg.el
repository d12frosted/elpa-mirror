;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260713.2022"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "f0318260b65802c47f443daf051c4859aa81ec31"
  :revdesc "f0318260b658"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
