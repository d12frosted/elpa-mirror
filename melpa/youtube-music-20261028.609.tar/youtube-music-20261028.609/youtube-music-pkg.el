;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youtube-music" "20261028.609"
  "YouTube Music client."
  '((emacs "29.1"))
  :url "https://github.com/cyberkm/emacs-youtube-music"
  :commit "c83fe80b22c7391c47b4eb17f44d36d336c31059"
  :revdesc "c83fe80b22c7"
  :keywords '("multimedia" "youtube" "music")
  :authors '(("Pavel Bibergal" . "pavel@keewano.com"))
  :maintainers '(("Pavel Bibergal" . "pavel@keewano.com")))
