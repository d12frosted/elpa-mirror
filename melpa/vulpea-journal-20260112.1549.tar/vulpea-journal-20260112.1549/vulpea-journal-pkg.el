;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-journal" "20260112.1549"
  "Daily note interface for vulpea."
  '((emacs     "29.1")
    (vulpea    "2.0.0")
    (vulpea-ui "0.1.0")
    (dash      "2.20.0"))
  :url "https://github.com/d12frosted/vulpea-journal"
  :commit "1c674c4769d501269e3aae60dc31745fa8adfa2d"
  :revdesc "1c674c4769d5"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
