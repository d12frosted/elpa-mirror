;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260702.414"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "f64f8431fcbbdfac4242eb4055b9d0c783e20a62"
  :revdesc "f64f8431fcbb"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
