(define-package "rats" "20160311.1157" "Rapid testing suite for Go"
  '((s "1.10.0")
    (go-mode "1.3.1")
    (cl-lib "0.5"))
  :commit "8ad4023a4b9b00c1224b10b0060f6dc60b4814a4" :authors
  '(("Antoine Kalmbach" . "ane@iki.fi"))
  :maintainer
  '("Antoine Kalmbach" . "ane@iki.fi")
  :keywords
  '("convenience"))
;; Local Variables:
;; no-byte-compile: t
;; End:
