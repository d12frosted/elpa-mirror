(define-package "tmsu" "20230807.2218" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "8207b4140fd1b3eff2ec4b9818e67148139cb72f" :authors
  '(("Wojciech Siewierski"))
  :maintainers
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
