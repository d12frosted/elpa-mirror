;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "immaterial-theme" "20260219.749"
  "A family of themes loosely based on material colors."
  '((emacs        "29")
    (modus-themes "5.0.0"))
  :url "https://github.com/petergardfjall/emacs-immaterial-theme"
  :commit "4d2920d48f07a7681b9fb98cf27f60bd1611c265"
  :revdesc "4d2920d48f07"
  :keywords '("themes"))
