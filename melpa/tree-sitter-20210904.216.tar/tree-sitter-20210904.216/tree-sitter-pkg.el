(define-package "tree-sitter" "20210904.216" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.15.1"))
  :commit "8a1fa08171b67a1a5de3f5a3b7301e7206499520" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
