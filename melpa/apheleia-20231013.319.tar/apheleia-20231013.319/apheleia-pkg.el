(define-package "apheleia" "20231013.319" "Reformat buffer stably"
  '((emacs "26"))
  :commit "f57d21ef1f36f00930001fc3a22bd7e4a9fa16c9" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
