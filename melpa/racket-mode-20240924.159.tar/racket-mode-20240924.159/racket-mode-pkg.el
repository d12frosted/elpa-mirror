(define-package "racket-mode" "20240924.159" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "587672012b10ee8456199d78eb4085346f32c11d" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
