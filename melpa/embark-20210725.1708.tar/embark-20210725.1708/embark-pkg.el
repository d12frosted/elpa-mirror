(define-package "embark" "20210725.1708" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "736ffffb13573600d11c0c62f589f8032448356e" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
