;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260515.207"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "99f2cf4ca1e6ba758d17bf3c667b4abb502ad120"
  :revdesc "99f2cf4ca1e6"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
