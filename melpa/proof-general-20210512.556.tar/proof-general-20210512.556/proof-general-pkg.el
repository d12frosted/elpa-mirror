(define-package "proof-general" "20210512.556" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.5"))
  :commit "632297dd0ab35a42ed6eac163dcaca1e71fcd83b" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
