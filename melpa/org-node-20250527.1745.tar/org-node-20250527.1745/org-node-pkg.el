;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250527.1745"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "c4cefd8554c0b95e4e85428afde4981d37282b71"
  :revdesc "c4cefd8554c0"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
