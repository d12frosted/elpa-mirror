;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260708.1119"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "d7eddae717497f66bfb7256b2e38444e7e52336c"
  :revdesc "d7eddae71749"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
