(define-package "chronometrist" "20210507.923" "A time tracker with a nice interface"
  '((emacs "25.1")
    (literate-elisp "0.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "81b12053bc5c645ef27577cc9e6258c4cc8b3f33" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "https://github.com/contrapunctus-1/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
