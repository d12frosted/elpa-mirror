;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260925.1736"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "d401ff659609c5f7c3b8af641c4e91ff61912fad"
  :revdesc "d401ff659609"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
