;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260204.2031"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "d2bb56c2032bc1352336a76ef9e137e6514e0658"
  :revdesc "d2bb56c2032b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
