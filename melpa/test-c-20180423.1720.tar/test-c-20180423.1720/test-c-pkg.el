;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-c" "20180423.1720"
  "Quickly test c code."
  '((emacs "24.3"))
  :url "https://github.com/aaptel/test-c"
  :commit "761a576f62c7021ba941f178f153c51289df1553"
  :revdesc "761a576f62c7"
  :authors '(("Aurélien Aptel" . "aurelien.aptel@gmail.com"))
  :maintainers '(("Aurélien Aptel" . "aurelien.aptel@gmail.com")))
