(define-package "gpx" "20240609.1337" "Major mode for GPX files"
  '((emacs "27.1"))
  :commit "e5c6e6771d9c9a91757cf45306c3b2ab190d5a35" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("data" "tools")
  :url "https://github.com/mkcms/gpx-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
