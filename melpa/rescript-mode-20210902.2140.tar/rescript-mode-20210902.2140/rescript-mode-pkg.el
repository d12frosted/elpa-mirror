(define-package "rescript-mode" "20210902.2140" "A major mode for editing ReScript"
  '((emacs "26.1"))
  :commit "768eebff4fd88b20e892364583caff382ef26bed" :authors
  '(("Karl Landstrom" . "karl.landstrom@brgeight.se")
    ("Daniel Colascione" . "dancol@dancol.org")
    ("John Lee" . "jjl@pobox.com"))
  :maintainer
  '("John Lee" . "jjl@pobox.com")
  :keywords
  '("languages" "rescript")
  :url "https://github.com/jjlee/rescript-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
