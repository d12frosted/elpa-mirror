(define-package "gerrit" "20211001.2009" "Gerrit client"
  '((emacs "25.1")
    (hydra "0.15.0")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "75ec3df177765da38205f59e03e832b1ef9b7942" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
