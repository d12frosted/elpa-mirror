(define-package "grugru" "20201225.638" "Rotate text at point"
  '((emacs "24.4"))
  :commit "e4ccfd416de6a5f70e3f1c718f773b9fa2e8e17a" :authors
  (("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  ("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  ("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
