;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250920.446"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "dd1094734b3b750018764bb6993848b29d3f7bdf"
  :revdesc "dd1094734b3b"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
