(define-package "osm" "20231221.1841" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "73b14a49ecec3887732a636fef685c26970da70b" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
