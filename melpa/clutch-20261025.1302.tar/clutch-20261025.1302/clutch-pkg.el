;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261025.1302"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "2730745f3b721b1b4570844eaf1d339a23f5994d"
  :revdesc "2730745f3b72"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
