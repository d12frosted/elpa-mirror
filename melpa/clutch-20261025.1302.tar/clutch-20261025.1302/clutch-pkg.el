;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261025.1302"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "4ece93a1e7450ca45ff5f2e48b88a0447f71a2c8"
  :revdesc "4ece93a1e745"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
