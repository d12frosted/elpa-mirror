(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "65ca4d6cfac3db8bc6e24fc46394cf301ebc2933")
;; Local Variables:
;; no-byte-compile: t
;; End:
