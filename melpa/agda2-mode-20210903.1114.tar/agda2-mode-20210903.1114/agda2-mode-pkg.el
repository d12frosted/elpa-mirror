(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "bea11a04df5f82b2b8782bcad5bf2af2a6b88b65")
;; Local Variables:
;; no-byte-compile: t
;; End:
