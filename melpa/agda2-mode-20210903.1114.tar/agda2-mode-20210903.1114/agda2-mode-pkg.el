(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "a4e58890b592bfcc706f63948fe6e4c0936178b7")
;; Local Variables:
;; no-byte-compile: t
;; End:
