(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "cf59a4bf974944cccb9aa0c9f5f5c886334d7219")
;; Local Variables:
;; no-byte-compile: t
;; End:
