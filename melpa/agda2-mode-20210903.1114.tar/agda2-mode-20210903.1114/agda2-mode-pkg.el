(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "376860c0f62869b27a0f4d2b06b6b871e6c8e761")
;; Local Variables:
;; no-byte-compile: t
;; End:
