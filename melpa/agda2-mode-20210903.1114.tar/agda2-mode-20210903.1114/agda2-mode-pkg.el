(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "e913532676fb92272b650f3a053e116eaaffc963")
;; Local Variables:
;; no-byte-compile: t
;; End:
