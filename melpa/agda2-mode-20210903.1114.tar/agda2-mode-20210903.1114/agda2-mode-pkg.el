(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "070d0c841788d3a09e4557d92fd954bb1b6a7e9e")
;; Local Variables:
;; no-byte-compile: t
;; End:
