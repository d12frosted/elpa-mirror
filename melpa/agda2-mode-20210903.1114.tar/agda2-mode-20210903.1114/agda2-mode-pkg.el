(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "5018aa45c18e3bd2b7de323c789daefc920cbbe7")
;; Local Variables:
;; no-byte-compile: t
;; End:
