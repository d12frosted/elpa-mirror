(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "78ea6d259b10d4751f96924e418dbc1c8cd8b638")
;; Local Variables:
;; no-byte-compile: t
;; End:
