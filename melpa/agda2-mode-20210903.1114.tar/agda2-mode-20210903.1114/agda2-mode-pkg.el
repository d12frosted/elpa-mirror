(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "152efd679d3ab9d983e6f776d58b990904d52c99")
;; Local Variables:
;; no-byte-compile: t
;; End:
