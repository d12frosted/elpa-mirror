(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "046f0d367a87c5fba6097bb36b33b671ad84a2df")
;; Local Variables:
;; no-byte-compile: t
;; End:
