(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "d8145b921a95c659d0313c1b84500d73081572cc")
;; Local Variables:
;; no-byte-compile: t
;; End:
