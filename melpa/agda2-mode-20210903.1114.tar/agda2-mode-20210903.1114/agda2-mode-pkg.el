(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "475d9add939bf86936a1d5b41c3260f0000bd3c8")
;; Local Variables:
;; no-byte-compile: t
;; End:
