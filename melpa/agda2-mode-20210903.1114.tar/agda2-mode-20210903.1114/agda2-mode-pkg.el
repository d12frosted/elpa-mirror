(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "90bb34b54710bff4b5ce2db7a34d4438df7389f8")
;; Local Variables:
;; no-byte-compile: t
;; End:
