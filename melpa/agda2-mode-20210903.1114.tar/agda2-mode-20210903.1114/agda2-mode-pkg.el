(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "20974a85a21259b4b58e53999037c532f0c79a20")
;; Local Variables:
;; no-byte-compile: t
;; End:
