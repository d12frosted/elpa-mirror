(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "631660c3d13da25c0ad599c8a1759b6863de9999")
;; Local Variables:
;; no-byte-compile: t
;; End:
