(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "d281edeac893db140ab2a0ec9f42a4c1dd2efecb")
;; Local Variables:
;; no-byte-compile: t
;; End:
