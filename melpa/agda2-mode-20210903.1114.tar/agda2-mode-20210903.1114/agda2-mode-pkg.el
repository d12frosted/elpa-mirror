(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "5883777d450e0959bfcfa638ec536b327668cc38")
;; Local Variables:
;; no-byte-compile: t
;; End:
