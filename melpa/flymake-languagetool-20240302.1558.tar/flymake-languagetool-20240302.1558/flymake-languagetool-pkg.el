(define-package "flymake-languagetool" "20240302.1558" "Flymake support for LanguageTool"
  '((emacs "27.1"))
  :commit "b7f03bc0a6e06e1cc5614694e9d51949685fe3b0" :keywords
  '("convenience" "grammar" "check")
  :url "https://github.com/emacs-languagetool/flymake-languagetool")
;; Local Variables:
;; no-byte-compile: t
;; End:
