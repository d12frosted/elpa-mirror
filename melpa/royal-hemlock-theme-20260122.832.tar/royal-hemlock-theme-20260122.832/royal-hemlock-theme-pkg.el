;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "20260122.832"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "2522edae28d38f4a8b2df91982d1fd7252573a7a"
  :revdesc "2522edae28d3"
  :keywords '("color" "theme" "faces"))
