(define-package "embark" "20210717.1434" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "956ee04653c1db948afa986c883f6c84b768ca1a" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
