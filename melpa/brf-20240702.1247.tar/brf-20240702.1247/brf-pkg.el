(define-package "brf" "20240702.1247" "Brf-mode provides features from the legendary editor Brief"
  '((fringe-helper "0.1.1")
    (emacs "24.3"))
  :commit "e904a3278c1b211db6d53606977c90b654e234b0" :authors
  '(("Mike Woolley" . "mike@bulsara.com"))
  :maintainers
  '(("Mike Woolley" . "mike@bulsara.com"))
  :maintainer
  '("Mike Woolley" . "mike@bulsara.com")
  :keywords
  '("brief" "crisp" "emulations")
  :url "https://bitbucket.org/MikeWoolley/brf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
