(define-package "lsp-scheme" "20220914.2015" "Scheme support for lsp-mode"
  '((emacs "26.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "62a2d49014312b7f80c06994cbf634aa8d175a95" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
