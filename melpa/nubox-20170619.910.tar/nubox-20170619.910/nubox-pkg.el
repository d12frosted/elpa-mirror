;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nubox" "20170619.910"
  "Nubox color theme (dark, light and tty versions)."
  ()
  :url "https://github.com/martijnat/nubox"
  :commit "84aa965f0cb4bde293237e4cc586643d1f662f83"
  :revdesc "84aa965f0cb4"
  :keywords '("faces")
  :authors '(("Martijn Terpstra" . "bigmartijn@gmail.com"))
  :maintainers '(("Martijn Terpstra" . "bigmartijn@gmail.com")))
