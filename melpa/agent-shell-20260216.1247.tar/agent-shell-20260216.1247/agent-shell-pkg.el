;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260216.1247"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.10.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "995fac9ba4a112658e44061856c00422a523561c"
  :revdesc "995fac9ba4a1")
