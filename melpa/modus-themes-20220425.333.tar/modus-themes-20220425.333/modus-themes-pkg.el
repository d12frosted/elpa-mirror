(define-package "modus-themes" "20220425.333" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "29b8a115046f864e454ded9e2ff864d9cf9d6d6e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
