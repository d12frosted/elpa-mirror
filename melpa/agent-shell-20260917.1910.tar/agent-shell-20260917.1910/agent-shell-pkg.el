;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260917.1910"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d8176098fe1651811cf1767f297c320aa0102929"
  :revdesc "d8176098fe16")
