(define-package "gnosis" "20240716.647" "Spaced Repetition System"
  '((emacs "27.2")
    (emacsql "20240124")
    (compat "29.1.4.2"))
  :commit "9a68868346bc4e3a385480140f60e7736ed7c364" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions")
  :url "https://thanosapollo.org/projects/gnosis")
;; Local Variables:
;; no-byte-compile: t
;; End:
