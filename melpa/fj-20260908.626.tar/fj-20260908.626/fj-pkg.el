;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20260908.626"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "665af2b3d0019b9bcb2297cc1f3aff81a62cea6f"
  :revdesc "665af2b3d001"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
