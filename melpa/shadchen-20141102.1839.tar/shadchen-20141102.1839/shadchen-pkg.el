;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shadchen" "20141102.1839"
  "Pattern matching for elisp."
  ()
  :url "https://github.com/VincentToups/shadchen-el"
  :commit "35f2b9c304eec990c16efbd557198289dc7cbb1f"
  :revdesc "35f2b9c304ee")
