;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwin" "20251125.1016"
  "Navigate and arrange desktop windows."
  '((emacs "30.2"))
  :url "https://github.com/lsth/dwin"
  :commit "e508310767e2e12d486c2af331d590cbaf2fc16f"
  :revdesc "e508310767e2"
  :keywords '("frames" "processes" "convenience")
  :authors '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de"))
  :maintainers '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de")))
