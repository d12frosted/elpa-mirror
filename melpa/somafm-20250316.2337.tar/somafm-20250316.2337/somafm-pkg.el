;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "somafm" "20250316.2337"
  "A simple soma.fm interface."
  '((emacs   "26.1")
    (dash    "2.12.0")
    (request "0.3.2")
    (cl-lib  "0.6.1"))
  :url "https://github.com/artenator/somafm.el"
  :commit "549fea7df8f7bb3c70939275c04f88ff84e0b5a8"
  :revdesc "549fea7df8f7"
  :keywords '("multimedia")
  :authors '(("Arte Ebrahimi" . ""))
  :maintainers '(("Arte Ebrahimi" . "")))
