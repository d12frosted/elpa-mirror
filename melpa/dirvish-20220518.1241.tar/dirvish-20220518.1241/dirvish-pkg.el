(define-package "dirvish" "20220518.1241" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "73dcaa404da9ab84d25f2919e6e3af4b1f8e7f37" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
