(define-package "elm-mode" "20230315.930" "Major mode for Elm"
  '((f "0.17")
    (s "1.7.0")
    (emacs "25.1")
    (seq "2.23")
    (reformatter "0.3"))
  :commit "79aef834b017fd9054507c3f21797d2ee3444e93" :authors
  '(("Joseph Collard"))
  :maintainer
  '("Joseph Collard")
  :url "https://github.com/jcollard/elm-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
