;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260306.543"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "1476784172058cefa2a488c018080489e35f31c7"
  :revdesc "147678417205"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
