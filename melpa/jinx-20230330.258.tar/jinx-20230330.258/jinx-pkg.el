(define-package "jinx" "20230330.258" "Enchanted Just-in-time Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "397112434c3ca0f6c9a201b73eeaf19c8dc11d8e" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
