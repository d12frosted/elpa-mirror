;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apdl-mode" "20250508.908"
  "Major mode for the scripting language APDL."
  '((emacs "25.1"))
  :url "https://github.com/dieter-wilhelm/apdl-mode"
  :commit "4883ab085811b85cc75c44b5af478ab8f7e98386"
  :revdesc "4883ab085811"
  :keywords '("languages" "convenience" "tools" "ansys" "apdl")
  :authors '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de")))
