;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260504.1806"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "59d279075fa3ba1c41672bd0328864489e522f19"
  :revdesc "59d279075fa3"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
