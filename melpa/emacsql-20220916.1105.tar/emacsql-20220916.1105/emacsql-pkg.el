(define-package "emacsql" "20220916.1105" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "6728a8649ae0209094c8c4b9e9f5786c004ab2ae" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
