(define-package "spdx" "20221225.114" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "9515f5e4b0473d61b86bbc7fcebe74aae5b03554" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
