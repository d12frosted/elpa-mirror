(define-package "tempel-collection" "20230918.814" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "29.1"))
  :commit "3b2b209a7e3871d85e7219c6f1701db6c16dc824" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
