;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260801.1042"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "bbd6af53ff612a20b03a900ed14fd32ef0db3f4f"
  :revdesc "bbd6af53ff61"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
