;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ical-form" "20251103.1109"
  "A widget form for editing ical events."
  '((emacs "29.1"))
  :url "https://github.com/haji-ali/maccalfw"
  :commit "656cb789813339cbd86b00d8416cab9fa0f8383e"
  :revdesc "656cb7898133"
  :keywords '("calendar")
  :authors '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
