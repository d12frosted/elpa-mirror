;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260124.849"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "e4a0ed52f8e635c3a824498c70ab4736abc412bd"
  :revdesc "e4a0ed52f8e6"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
