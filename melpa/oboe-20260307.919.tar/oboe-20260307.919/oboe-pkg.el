;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260307.919"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "cc6442419e917ce6a2a4f318308262edf80b79d3"
  :revdesc "cc6442419e91"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
