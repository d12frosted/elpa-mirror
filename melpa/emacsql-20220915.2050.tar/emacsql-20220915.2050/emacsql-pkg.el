(define-package "emacsql" "20220915.2050" "high-level SQL database front-end"
  '((emacs "25.1"))
  :commit "f5da68e5f986c1b85ec7866ef091427db43107f2" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
