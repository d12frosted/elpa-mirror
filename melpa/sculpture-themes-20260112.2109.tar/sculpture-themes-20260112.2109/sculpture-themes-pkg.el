;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "20260112.2109"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "ce17fba2d12775e9596386b237158b8ca531a186"
  :revdesc "ce17fba2d127"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
