;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-leanpub" "20260419.2104"
  "Export Org documents to Leanpub book format."
  '((org    "9.1")
    (ox-gfm "1.0")
    (emacs  "26.1")
    (s      "1.12.0"))
  :url "https://gitlab.com/zzamboni/ox-leanpub"
  :commit "cfd521786c281ad7fa38212016226af80e163329"
  :revdesc "cfd521786c28"
  :keywords '("files" "org" "leanpub")
  :authors '(("Diego Zamboni" . "diego@zzamboni.org"))
  :maintainers '(("Diego Zamboni" . "diego@zzamboni.org")))
