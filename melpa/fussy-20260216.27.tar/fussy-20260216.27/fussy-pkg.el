;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260216.27"
  "Fuzzy completion style using `flx'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "17ca387c077f47553239816f41d6f0e351a21103"
  :revdesc "17ca387c077f"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
