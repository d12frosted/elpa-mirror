;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260210.1532"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "1757b72cf0e0f17c58ef5a484157b3758041ca86"
  :revdesc "1757b72cf0e0"
  :keywords '("convenience"))
