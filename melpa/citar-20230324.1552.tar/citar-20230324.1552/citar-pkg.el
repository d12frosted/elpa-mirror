(define-package "citar" "20230324.1552" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "4.2")
    (org "9.5")
    (citeproc "0.9"))
  :commit "cd86ac2869f4d1822dd8a6167e34673f6dfa3fa8" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/emacs-citar/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
