;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20260626.420"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "7b85d09784c2cf5f209cad98bdef2254c084c379"
  :revdesc "7b85d09784c2"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
