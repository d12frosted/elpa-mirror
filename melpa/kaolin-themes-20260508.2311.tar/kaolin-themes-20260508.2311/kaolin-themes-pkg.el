;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "20260508.2311"
  "A set of eye pleasing themes."
  '((emacs      "25.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "6273de3f015199856af10507a1f762082d2af056"
  :revdesc "6273de3f0151"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
