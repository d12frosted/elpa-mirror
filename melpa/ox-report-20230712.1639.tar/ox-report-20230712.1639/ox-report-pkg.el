(define-package "ox-report" "20230712.1639" "Export your org file to minutes report PDF file"
  '((emacs "24.4")
    (org-msg "3.9"))
  :commit "91e047968c4730dfe10d1e94836e0747de8c7361" :authors
  '(("Matthias David" . "db@gnu.re"))
  :maintainers
  '(("Matthias David" . "db@gnu.re"))
  :maintainer
  '("Matthias David" . "db@gnu.re")
  :keywords
  '("org" "outlines" "report" "exporter" "meeting" "minutes")
  :url "https://github.com/DarkBuffalo/ox-report")
;; Local Variables:
;; no-byte-compile: t
;; End:
