(define-package "consult" "20210318.1440" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "e7d409c684a34475349e4019c9c54ee08f644cdb" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
