;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-solo" "20260621.1352"
  "Switch the active Denote directory."
  '((emacs  "28.1")
    (denote "4.0"))
  :url "https://github.com/pavlo/denote-solo"
  :commit "f6f3621b48022fe43ec54429dcff4f92a06d7c15"
  :revdesc "f6f3621b4802"
  :keywords '("convenience" "notes")
  :authors '(("Pavlo V. Lysov" . "pavlikus@gmail.com"))
  :maintainers '(("Pavlo V. Lysov" . "pavlikus@gmail.com")))
