;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "google-contacts" "20201012.1056"
  "Support for Google Contacts in Emacs."
  '((oauth2 "0.10")
    (cl-lib "0.5"))
  :url "https://github.com/jd/google-contacts.el"
  :commit "8923c238fe0906184d2254b33ba72792ed12cd47"
  :revdesc "8923c238fe09"
  :keywords '("comm")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
