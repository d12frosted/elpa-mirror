;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-ibuffer" "20261011.1414"
  "Display nerd icons in ibuffer."
  '((emacs      "24.3")
    (nerd-icons "0.0.1"))
  :url "https://github.com/seagle0128/nerd-icons-ibuffer"
  :commit "19b28bcdba9d3c1f8cc6f37a57a574f1a5540dc4"
  :revdesc "19b28bcdba9d"
  :keywords '("convenience" "icons" "ibuffer")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
