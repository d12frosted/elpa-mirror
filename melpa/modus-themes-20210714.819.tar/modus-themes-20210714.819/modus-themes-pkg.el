(define-package "modus-themes" "20210714.819" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "6593dc2569722c3e85d9e00eff62e4afa35e0610" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
