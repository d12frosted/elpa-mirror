(define-package "modus-themes" "20211108.705" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "1495c8d0362a50cfc7462ab0a9fab546ae39a9df" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
