(define-package "pamparam" "20201226.914" "Simple and fast flashcards."
  '((emacs "26.1")
    (lispy "0.27.0")
    (worf "0.1.0")
    (ivy-posframe "0.5.5"))
  :commit "b78fbfd6cf3a8d05fca8f7c96e9f31f6e097f0ad" :authors
  (("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  ("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  ("outlines" "hypermedia" "flashcards" "memory")
  :url "https://github.com/abo-abo/pamparam")
;; Local Variables:
;; no-byte-compile: t
;; End:
