;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260124.1410"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e1eac8293a5264a3ad2c7962b841e5deaed17c82"
  :revdesc "e1eac8293a52")
