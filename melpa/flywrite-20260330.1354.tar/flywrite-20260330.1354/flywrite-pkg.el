;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flywrite" "20260330.1354"
  "Inline writing suggestions via LLM."
  '((emacs "29.1"))
  :url "https://github.com/awdeorio/flywrite"
  :commit "67af2b548449da231b55468c74b92589fae48270"
  :revdesc "67af2b548449"
  :keywords '("text" "wp")
  :authors '(("Andrew DeOrio" . "awdeorio@umich.edu"))
  :maintainers '(("Andrew DeOrio" . "awdeorio@umich.edu")))
