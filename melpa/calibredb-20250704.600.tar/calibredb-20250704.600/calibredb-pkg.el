;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calibredb" "20250704.600"
  "Yet another calibre client."
  '((emacs     "29.1")
    (org       "9.3")
    (transient "0.1.0")
    (s         "1.12.0")
    (dash      "2.17.0")
    (request   "0.3.3")
    (esxml     "0.3.7"))
  :url "https://github.com/chenyanming/calibredb.el"
  :commit "d6685b0809a851bf551972b8fb02b455b6607a26"
  :revdesc "d6685b0809a8"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
