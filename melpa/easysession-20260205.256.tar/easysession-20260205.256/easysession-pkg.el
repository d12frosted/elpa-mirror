;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260205.256"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "57c41d7b5ff5e56b7f7e50df05e29b3589cd4537"
  :revdesc "57c41d7b5ff5"
  :keywords '("convenience"))
