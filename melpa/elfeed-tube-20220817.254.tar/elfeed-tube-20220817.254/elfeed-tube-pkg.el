(define-package "elfeed-tube" "20220817.254" "YouTube integration for Elfeed"
  '((emacs "27.1")
    (elfeed "3.4.1")
    (aio "1.0"))
  :commit "54347f333c7333ba800efe96f762dd3527ce2e0a" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("news" "hypermedia" "convenience")
  :url "https://github.com/karthink/elfeed-tube")
;; Local Variables:
;; no-byte-compile: t
;; End:
