;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261105.1139"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "860b93d3b663312e9da482df7eb2b6b70c5b9b19"
  :revdesc "860b93d3b663"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
