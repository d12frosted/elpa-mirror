;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesky" "20260611.24"
  "A Bluesky client."
  '((emacs "30.1")
    (plz   "0.9.0")
    (futur "1.7")
    (vui   "1.0.0"))
  :url "https://github.com/ahyatt/emacs-bluesky"
  :commit "3c71c95ecd8e4ffc961f701cc937df0184aebf52"
  :revdesc "3c71c95ecd8e"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
