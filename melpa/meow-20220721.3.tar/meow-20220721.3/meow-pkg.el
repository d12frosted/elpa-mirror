(define-package "meow" "20220721.3" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "0c977962f45d22fe8079e94ec7947f3b37663826" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
