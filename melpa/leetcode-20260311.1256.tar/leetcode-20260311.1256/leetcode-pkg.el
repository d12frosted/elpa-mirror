;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leetcode" "20260311.1256"
  "An leetcode client."
  '((emacs "28.1")
    (s     "1.13.0")
    (aio   "1.0")
    (log4e "0.3.3"))
  :url "https://github.com/kaiwk/leetcode.el"
  :commit "4f3fb7d4740e156ad1c6f5973ad97ed436170aa2"
  :revdesc "4f3fb7d4740e"
  :keywords '("extensions" "tools")
  :authors '(("Wang Kai" . "kaiwkx@gmail.com"))
  :maintainers '(("Wang Kai" . "kaiwkx@gmail.com")))
