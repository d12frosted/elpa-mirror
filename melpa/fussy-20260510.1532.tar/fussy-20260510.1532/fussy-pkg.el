;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260510.1532"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "a775e01f24273300d219fea94f5ba73e4ef807d2"
  :revdesc "a775e01f2427"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
