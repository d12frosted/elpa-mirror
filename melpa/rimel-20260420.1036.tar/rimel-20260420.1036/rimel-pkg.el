;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260420.1036"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "1b7e6c7c626b36a7f80e8c388454bb4562da11e9"
  :revdesc "1b7e6c7c626b"
  :keywords '("convenience" "chinese" "input-method" "rime"))
