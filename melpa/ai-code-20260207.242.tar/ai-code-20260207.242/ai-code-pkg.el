;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260207.242"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "42750f639f5630b8560738e2a03c937aac5b82a5"
  :revdesc "42750f639f56"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
