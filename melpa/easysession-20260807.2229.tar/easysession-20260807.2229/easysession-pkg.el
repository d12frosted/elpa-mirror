;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260807.2229"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "83a15da810f88d095b9e21619b70b6d801b0aac0"
  :revdesc "83a15da810f8"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
