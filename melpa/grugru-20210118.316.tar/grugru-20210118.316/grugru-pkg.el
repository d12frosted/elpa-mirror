(define-package "grugru" "20210118.316" "Rotate text at point"
  '((emacs "24.4"))
  :commit "14da20195c4a221161ab8c4853e28332ad917bf5" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
