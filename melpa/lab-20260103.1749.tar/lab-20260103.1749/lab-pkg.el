;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "20260103.1749"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "a7a3985b7f39dd4bdb6ad9b3579b54edb49f34de"
  :revdesc "a7a3985b7f39"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
