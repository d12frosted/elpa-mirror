;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251228.631"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "89185784ea87772703515dd09458bbb6940f4c72"
  :revdesc "89185784ea87"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
