;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250418.155"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "e8523ec5b8c4a6eabdc5f1aefcff239968a98183"
  :revdesc "e8523ec5b8c4"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
