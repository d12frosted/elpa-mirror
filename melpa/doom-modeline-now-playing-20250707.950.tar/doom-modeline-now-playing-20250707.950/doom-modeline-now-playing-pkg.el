;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline-now-playing" "20250707.950"
  "Segment for Doom Modeline to show media player information."
  '((emacs "26.1"))
  :url "https://github.com/elken/doom-modeline-now-playing"
  :commit "ba1619e98e011dabb24450db3e2e125bcce02a19"
  :revdesc "ba1619e98e01"
  :authors '(("Ellis Kenyő" . "me@elken.dev"))
  :maintainers '(("Ellis Kenyő" . "me@elken.dev")))
