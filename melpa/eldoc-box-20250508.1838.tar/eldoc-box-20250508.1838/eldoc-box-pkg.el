;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-box" "20250508.1838"
  "Display documentation in childframe."
  '((emacs "27.1"))
  :url "https://github.com/casouri/eldoc-box"
  :commit "3cf770ac54af512a325b9044aede5255c7c46f62"
  :revdesc "3cf770ac54af"
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
