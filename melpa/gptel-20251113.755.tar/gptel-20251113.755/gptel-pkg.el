;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251113.755"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "566a1fb27704148abe77db2f62ad1e5f62ba7262"
  :revdesc "566a1fb27704"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
