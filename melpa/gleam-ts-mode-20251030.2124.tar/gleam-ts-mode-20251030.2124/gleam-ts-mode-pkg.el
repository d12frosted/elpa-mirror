;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gleam-ts-mode" "20251030.2124"
  "Major mode for Gleam."
  '((emacs "29.1"))
  :url "https://github.com/gleam-lang/gleam-mode"
  :commit "e32f167e4384cd14306a0836dea1e8d1497a0868"
  :revdesc "e32f167e4384"
  :keywords '("languages" "gleam"))
