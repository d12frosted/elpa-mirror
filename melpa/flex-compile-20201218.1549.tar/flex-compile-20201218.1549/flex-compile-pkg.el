(define-package "flex-compile" "20201218.1549" "Run, evaluate and compile across many languages"
  '((emacs "26.1")
    (dash "2.17.0")
    (buffer-manage "0.11"))
  :commit "bc1f0804f089686260b64d5e4dde80c0c9f6df21" :keywords
  ("compilation" "integration" "processes")
  :authors
  (("Paul Landes"))
  :maintainer
  ("Paul Landes")
  :url "https://github.com/plandes/flex-compile")
;; Local Variables:
;; no-byte-compile: t
;; End:
