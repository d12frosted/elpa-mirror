(define-package "undo-fu" "20240615.920" "Undo helper with redo"
  '((emacs "25.1"))
  :commit "acd4f6c92521716c1010ff3aba471218ba14a5e9" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-undo-fu")
;; Local Variables:
;; no-byte-compile: t
;; End:
