;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winnow" "20261010.1307"
  "Winnow ag/grep results by matching/excluding lines."
  '((emacs "24"))
  :url "https://github.com/dgtized/winnow.el"
  :commit "628c8d20ac4e9ba2ccad2b088a3fa2d5dc91708c"
  :revdesc "628c8d20ac4e"
  :keywords '("matching")
  :authors '(("Charles L.G. Comstock" . "dgtized@gmail.com"))
  :maintainers '(("Charles L.G. Comstock" . "dgtized@gmail.com")))
