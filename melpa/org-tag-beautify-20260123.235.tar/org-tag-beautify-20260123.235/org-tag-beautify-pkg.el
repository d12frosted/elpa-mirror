;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "20260123.235"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "3b0e03b5a7929b2c0b107d90355e0a0f03490aef"
  :revdesc "3b0e03b5a792"
  :keywords '("hypermedia"))
