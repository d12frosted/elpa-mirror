(define-package "robe" "20220731.104" "Code navigation, documentation lookup and completion for Ruby"
  '((inf-ruby "2.5.1")
    (emacs "25.1"))
  :commit "89e67681746eeecaab841e93e4a6c2f078ccbf43" :authors
  '(("Dmitry Gutov"))
  :maintainer
  '("Dmitry Gutov")
  :keywords
  '("ruby" "convenience" "rails")
  :url "https://github.com/dgutov/robe")
;; Local Variables:
;; no-byte-compile: t
;; End:
