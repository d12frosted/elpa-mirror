;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20250420.1613"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "ed628274e79f42a320779ba9fa6422bbb15db01b"
  :revdesc "ed628274e79f"
  :keywords '("convenience"))
