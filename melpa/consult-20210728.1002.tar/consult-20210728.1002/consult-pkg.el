(define-package "consult" "20210728.1002" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "4ae68628686b5a35b03aabd0063908763eb71da2" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
