(define-package "merlin" "20230510.1520" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "4bd7b7f42c460c0c85a267eada352b627fd54d20" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainers
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
