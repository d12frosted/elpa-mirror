;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261023.932"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "11f0af1a3e7c9df0b99272ba8f069fa3abe5a4c7"
  :revdesc "11f0af1a3e7c"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
