(define-package "loopy-dash" "20240225.1310" "Dash destructuring for `loopy'"
  '((emacs "25.1")
    (loopy "0.12.1")
    (dash "2.19"))
  :commit "14a8a8e9dc898e8c6ac5e92e14d2ae3b092e1817" :authors
  '(("Earl Hyatt"))
  :maintainers
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
