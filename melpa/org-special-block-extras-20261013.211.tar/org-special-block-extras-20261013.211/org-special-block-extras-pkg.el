;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20261013.211"
  "30 new custom blocks & 34 link types for Org-mode."
  '((s        "1.13.1")
    (dash     "2.18.1")
    (emacs    "27.1")
    (org      "9.1")
    (lf       "1.0")
    (dad-joke "1.4")
    (seq      "2.0")
    (lolcat   "0"))
  :url "https://alhassy.github.io/org-special-block-extras"
  :commit "2b9dd174a1504d4f77dc2e410f3ec64005b77d2b"
  :revdesc "2b9dd174a150"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
