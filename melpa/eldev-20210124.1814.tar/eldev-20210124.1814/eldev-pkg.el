(define-package "eldev" "20210124.1814" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "dc8e1ebf0af386eee46097ee20c20b193d1d6a2d" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
