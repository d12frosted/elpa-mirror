(define-package "rspec-mode" "20220401.306" "Enhance ruby-mode for RSpec"
  '((ruby-mode "1.0")
    (cl-lib "0.4"))
  :commit "a54ac64097b6ccc6acc52a8b077ceb63766fc4d1" :authors
  '(("Peter Williams, et al."))
  :maintainer
  '("Peter Williams, et al.")
  :keywords
  '("rspec" "ruby")
  :url "http://github.com/pezra/rspec-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
