;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "20260906.1735"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "624df07a45e3289d395ee54baeba88087d0b0cd6"
  :revdesc "624df07a45e3"
  :keywords '("outlines" "tools" "convenience" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
