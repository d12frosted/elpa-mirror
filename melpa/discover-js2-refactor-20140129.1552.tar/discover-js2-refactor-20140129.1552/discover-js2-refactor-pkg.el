;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "discover-js2-refactor" "20140129.1552"
  "Adds discover context menu for js2-refactor."
  '((js2-refactor "20131221.501")
    (discover     "20140103.1339"))
  :url "https://github.com/NicolasPetton/discover-js2-refactor"
  :commit "3812abf61f39f3e73a9f3daefa6fed4f21a429ba"
  :revdesc "3812abf61f39"
  :keywords '("js2-refactor" "discover")
  :authors '(("Nicolas Petton" . "petton.nicolas@gmail.com"))
  :maintainers '(("Nicolas Petton" . "petton.nicolas@gmail.com")))
