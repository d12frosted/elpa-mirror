(define-package "elisp-autofmt" "20221230.413" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "d89a97c1245208f8a2a6cb32e32d24bdc6dd4e48" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
