(define-package "git-commit" "20220222.1036" "Edit Git commit messages."
  '((emacs "25.1")
    (transient "20210920")
    (with-editor "20211001"))
  :commit "0b3b18452cf7b72e067451a453c55c44cf1d8c89" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
