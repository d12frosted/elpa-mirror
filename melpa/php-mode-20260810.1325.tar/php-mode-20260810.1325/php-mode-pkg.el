;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20260810.1325"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "f92c0acf51a36c30b8dd8b7a2b61c2785be45780"
  :revdesc "f92c0acf51a3"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
