(define-package "consult" "20220804.821" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "aaba2b0260a522cea3c733850dd13a9aae803917" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
