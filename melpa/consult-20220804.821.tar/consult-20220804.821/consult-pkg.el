(define-package "consult" "20220804.821" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "d0e85c588ec8738e5dd9d364cad3131a7d019f52" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
