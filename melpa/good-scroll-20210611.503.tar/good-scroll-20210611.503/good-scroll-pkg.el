(define-package "good-scroll" "20210611.503" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "ae1c2e12abfddcb368b7619d548065d20df61c9d" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
