;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260917.739"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "b7a89ad0a94d200996c746540b52f6d3740b0aa5"
  :revdesc "b7a89ad0a94d"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
