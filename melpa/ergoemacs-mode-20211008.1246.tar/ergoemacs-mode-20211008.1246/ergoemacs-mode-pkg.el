(define-package "ergoemacs-mode" "20211008.1246" "Emacs mode based on common modern interface and ergonomics."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "d2d29aa071735c207d38f931fecf54652ebd738e" :authors
  '(("Xah Lee" . "xah@xahlee.org")
    ("David Capello" . "davidcapello@gmail.com")
    ("Matthew L. Fidler" . "matthew.fidler@gmail.com"))
  :maintainer
  '("Matthew L. Fidler" . "matthew.fidler@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ergoemacs/ergoemacs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
