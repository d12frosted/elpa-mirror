(define-package "wildcharm-theme" "20230926.2256" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "42ef62acaf96dce160928e112af86cb4c9da3cd8" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
