(define-package "fuel" "20210506.1352" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "bfc423e43beeebcb14774054c9685fbded456faf")
;; Local Variables:
;; no-byte-compile: t
;; End:
