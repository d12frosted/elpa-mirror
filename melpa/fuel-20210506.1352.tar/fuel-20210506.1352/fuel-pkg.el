(define-package "fuel" "20210506.1352" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "25e5b51689a03cbd7e8b652c9e879a14f5e4326f")
;; Local Variables:
;; no-byte-compile: t
;; End:
