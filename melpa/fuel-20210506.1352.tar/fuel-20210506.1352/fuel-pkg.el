(define-package "fuel" "20210506.1352" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "20cefa0fb6514f30738a4b6774e0ce356b4af9bd")
;; Local Variables:
;; no-byte-compile: t
;; End:
