;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-consult" "20261113.705"
  "Consult UI for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.83.4")
    (acp         "0.18.1")
    (consult     "3.0"))
  :url "https://github.com/Gleek/agent-shell-consult"
  :commit "b95ea0e295389473728b203dc83321b405bb9114"
  :revdesc "b95ea0e29538"
  :keywords '("convenience" "processes" "tools")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
