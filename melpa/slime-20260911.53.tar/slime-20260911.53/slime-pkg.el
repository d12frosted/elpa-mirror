;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260911.53"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "b7c25d3cf9d29f9babd0431de00e44ad744a81fd"
  :revdesc "b7c25d3cf9d2"
  :keywords '("languages" "lisp" "slime"))
