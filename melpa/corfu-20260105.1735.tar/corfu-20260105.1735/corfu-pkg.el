;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20260105.1735"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "c524ed908bac3fb685343355804e89b87a528bce"
  :revdesc "c524ed908bac"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
