(define-package "mandoku" "20180403.1106" "A tool to access repositories of premodern Chinese texts"
  '((org "8.0")
    (magit "20151028")
    (github-clone "20150705")
    (git "20140128"))
  :commit "d65dbaa329ecf931f4142be72862972ea6a24e63")
;; Local Variables:
;; no-byte-compile: t
;; End:
