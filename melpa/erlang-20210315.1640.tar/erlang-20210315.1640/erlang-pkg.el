(define-package "erlang" "20210315.1640" "Erlang major mode"
  '((emacs "24.1"))
  :commit "645ea8110da97687de302791829b4a6119a9b396" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
