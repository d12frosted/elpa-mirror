(define-package "erlang" "20210315.1640" "Erlang major mode"
  '((emacs "24.1"))
  :commit "bcc9ef57b3445224fcd7f4c84e99886141c25436" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
