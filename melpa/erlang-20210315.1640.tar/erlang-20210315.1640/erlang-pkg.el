(define-package "erlang" "20210315.1640" "Erlang major mode"
  '((emacs "24.1"))
  :commit "5660e960e9a1fa73d98b3aecbd24cef15fcc66c4" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
