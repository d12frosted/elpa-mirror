(define-package "company" "20240911.158" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "35a5c405916502135b2badee513984bde7f85fc7" :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
