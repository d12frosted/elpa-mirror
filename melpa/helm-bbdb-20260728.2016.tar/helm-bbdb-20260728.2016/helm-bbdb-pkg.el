;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bbdb" "20260728.2016"
  "Helm interface for bbdb."
  '((emacs "26.1")
    (helm  "1.5")
    (bbdb  "3.1.2"))
  :url "https://github.com/emacs-helm/helm-bbdb"
  :commit "8d5e5e35af18d61870f00e06ce272d90d4006506"
  :revdesc "8d5e5e35af18"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Jonathan Gregory" . "jgrg@autistici.org")))
