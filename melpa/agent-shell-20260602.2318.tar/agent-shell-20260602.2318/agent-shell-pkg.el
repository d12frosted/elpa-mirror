;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260602.2318"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "877c98a622cdc9ddc33817096915ebcbf908accb"
  :revdesc "877c98a622cd")
