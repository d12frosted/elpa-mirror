;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-test" "20230714.517"
  "A test runner for Python code."
  '((dash  "2.9.0")
    (f     "0.17")
    (emacs "24.4"))
  :url "https://github.com/Bogdanp/py-test.el"
  :commit "72975bb547b6123dcc1213ff78fdcf80f7b29842"
  :revdesc "72975bb547b6"
  :keywords '("python" "testing" "py.test")
  :authors '(("Bogdan Paul Popa" . "popa.bogdanp@gmail.com"))
  :maintainers '(("Bogdan Paul Popa" . "popa.bogdanp@gmail.com")))
