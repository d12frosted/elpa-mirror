(define-package "evil-collection" "20231216.954" "A set of keybindings for Evil mode"
  '((emacs "26.3")
    (evil "1.2.13")
    (annalist "1.0"))
  :commit "ddf0deb2c45cbb0c44326d3c0b7094818f232d8b" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainers
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("evil" "tools")
  :url "https://github.com/emacs-evil/evil-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
