;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260304.202"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "26.1"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "8d52546833d84b60a0cd038c7d505e4506a4c699"
  :revdesc "8d52546833d8"
  :keywords '("programming"))
