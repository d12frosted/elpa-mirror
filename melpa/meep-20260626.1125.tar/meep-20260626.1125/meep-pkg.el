;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260626.1125"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "b6620f6f066f888a7ea8c14e88b6e3efb448f6fb"
  :revdesc "b6620f6f066f"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
