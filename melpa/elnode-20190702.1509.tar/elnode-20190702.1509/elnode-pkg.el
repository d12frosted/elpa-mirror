;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elnode" "20190702.1509"
  "A simple emacs async HTTP server."
  ()
  :url "https://github.com/jcaw/elnode"
  :commit "29ef0f51a65a24fca7fdcdb4140d2e4556e4bb29"
  :revdesc "29ef0f51a65a"
  :keywords '("lisp" "http" "hypermedia")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
