;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251213.1959"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "4c4a41b0b3a7a65729b701670052d2287f57b427"
  :revdesc "4c4a41b0b3a7"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
