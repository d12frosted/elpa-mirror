;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20261024.2210"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "f2711c333df4ef644ff59d0d7e58080e670a889a"
  :revdesc "f2711c333df4"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
