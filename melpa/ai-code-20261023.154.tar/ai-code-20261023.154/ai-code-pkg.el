;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261023.154"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "86b6a9c1067a6744a5b5b948e12b693b5a04f3fb"
  :revdesc "86b6a9c1067a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
