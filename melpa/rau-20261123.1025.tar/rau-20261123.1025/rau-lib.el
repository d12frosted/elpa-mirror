;;; rau-lib --- library of common functions for Rau frontend and backend -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Thomas Koch

;;; SPDX-License-Identifier: GPL-3.0-or-later

;;; Commentary:

;; Common code for frontend (rau.el) and backend (rau-be.el)

;;; Code:

(require 'lgr)

(defvar rau--lgr (lgr-get-logger "rau"))

(defconst rau--modifier-bits
  '((shift   . 1)
    (control . 4)
    (meta    . 8)
    (super   . 64)
    (hyper   . 128))
  "Modifier bits as per river_seat_v1.modifiers / XKB.")

(defun rau--modifiers-bitmap (modifier-symbols)
  "Make bitmap for binding MODIFIER-SYMBOLS.
See `rau--modifier-bits' for valid symbols."
  (let ((modifier-bits (seq-keep (lambda (mod)
                                   (alist-get mod rau--modifier-bits))
                                 modifier-symbols)))
    (apply #'logior modifier-bits)))

(defun rau--map-if (cond-p fn xs)
  "Apply FN only to those elements of XS where COND-P is true."
  (mapcar (lambda (x)
            (if (funcall cond-p x)
                 (funcall fn x)
               x))
          xs))

(defun rau--apply-cons (fn &rest args)
  "Map FN over cars and cdrs of ARGS separately.
This can be used for simple two dimensional vector calculations."
  `(,(apply fn (rau--map-if #'listp #'car args)) .
    ,(apply fn (rau--map-if #'listp #'cdr args))))

(defun rau--cons-as (cons symbol1 symbol2)
  "Transform CONS cell into a plist with names SYMBOL1 and SYMBOL2."
  `((,symbol1 . ,(car cons))
    (,symbol2 . ,(cdr cons))))

;;; Remote Procedure Calls between front-end and back-end

(defvar rau--rpc-proc nil
  "Network process.")

(defvar rau--rpc-recv-buffer nil)

(defconst rau--rpc-prin1-overrides
  '(t
    (escape-newlines . t)
    (escape-control-characters . t)
    (float-format . nil)
    (integers-as-characters . nil))
  "Settings for `prin1-to-string' in RPC data serialization.")

(defun rau--rpc-init-connection (connection)
  "Store CONNECTION and create its receive buffer."
  (setq rau--rpc-proc connection
        rau--rpc-recv-buffer (get-buffer-create " *rau--rpc-recv-buffer*")))

(defun rau--rpc-connect (socket-file)
  "Create RPC connection to unix SOCKET-FILE."
  (rau--rpc-init-connection
   (make-network-process :name "rau-rpc"
                         :service nil
                         :remote socket-file
                         :filter #'rau--rpc-filter
                         :noquery t)))

(defun rau--rpc-accept-connection (connection msg)
  "Accept RPC CONNECTION, log MSG, see :log in `make-network-process'."
  (rau--rpc-init-connection connection)
  (lgr-info rau--lgr "new connection: %S" msg))

(defun rau--rpc-send-sexp (process sexp)
  (let ((coding-system-for-write 'utf-8-emacs-unix)
        (msg (prin1-to-string sexp nil rau--rpc-prin1-overrides)))
    (process-send-string process (format "%s\n" msg))))

(defun rau--rpc-send (fn &rest args)
  "Call FN with ARGS on the remote site.  Return values are ignored."
  ;; (rau--rpc-send (cons fn args))
  (let ((sexp `(,fn . ,args)))
    (rau--rpc-send-sexp rau--rpc-proc sexp)))

(defalias 'rau--be #'rau--rpc-send)
(defalias 'rau--fe #'rau--rpc-send)

(defun rau--rpc-handle (fn args)
  "Execute the requested function FN with ARGS.
Return values are ignored and errors catched and logged."
  (condition-case-unless-debug err
      (apply fn args)
    (error (lgr-error rau--lgr "RPC error %S with %S: %S" fn args err))))

(defun rau--rpc-filter (_proc string)
  "Process filter for incoming RPC STRING."
  (let ((coding-system-for-read 'utf-8-emacs-unix))
    (with-current-buffer rau--rpc-recv-buffer
      (goto-char (point-max))
      (save-excursion (insert string))
      (let ((end-pos (point-min-marker)))
        (while (search-forward "\n" nil t)
          (let ((line (buffer-substring-no-properties end-pos (1- (point)))))
            (setq end-pos (point))
            (lgr-trace rau--lgr "be recv: %s" line)
            (let* ((r (read-from-string line))
                   (sexp (car r))
                   (fn (car sexp))
                   (args (cdr sexp)))
              (rau--rpc-handle fn args))))
        (when (> end-pos (point-min))
          (delete-region (point-min) end-pos))))))

(provide 'rau-lib)

;;; rau-lib.el ends here
;; Local Variables:
;; package-lint-main-file: "rau.el"
;; End:
