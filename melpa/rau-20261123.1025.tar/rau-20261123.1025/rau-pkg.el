;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rau" "20261123.1025"
  "Wayland Window Manager based on River."
  '((emacs "31.1")
    (ewc   "0")
    (lgr   "0.1.0"))
  :url "https://github.com/thkoch2001/rau"
  :commit "45806077c67e5170b32720980bd4bbdb1bd6c257"
  :revdesc "45806077c67e"
  :keywords '("frames")
  :authors '(("Thomas Koch" . "thomas@koch.ro"))
  :maintainers '(("Thomas Koch" . "thomas@koch.ro")))
