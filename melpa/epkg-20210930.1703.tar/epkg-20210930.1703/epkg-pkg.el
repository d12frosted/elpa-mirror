(define-package "epkg" "20210930.1703" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "e0f541516a8369128a51f6ad2b7f720b82389dd5" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
