(define-package "epkg" "20210930.1703" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "a8e2b7e7a8123c32f14b13af5cf2ab1d1d1ec764" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
