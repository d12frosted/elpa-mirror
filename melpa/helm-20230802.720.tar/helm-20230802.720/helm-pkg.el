(define-package "helm" "20230802.720" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.2")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "4e17e266fc987d86bdfe22e42b0929265779d89b" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
