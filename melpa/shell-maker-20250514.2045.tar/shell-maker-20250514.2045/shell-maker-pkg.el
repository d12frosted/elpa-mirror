;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20250514.2045"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "9965923ebc09abc75c7af9b5440752da1f093e75"
  :revdesc "9965923ebc09")
