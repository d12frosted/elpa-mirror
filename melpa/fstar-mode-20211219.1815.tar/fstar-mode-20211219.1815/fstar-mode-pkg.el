(define-package "fstar-mode" "20211219.1815" "Support for F* programming"
  '((emacs "24.3")
    (dash "2.11")
    (company "0.8.12")
    (quick-peek "1.0")
    (yasnippet "0.11.0")
    (flycheck "30.0")
    (company-quickhelp "2.2.0"))
  :commit "751726d708f90c543b80a8916f4397140422273c" :authors
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/FStarLang/fstar-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
