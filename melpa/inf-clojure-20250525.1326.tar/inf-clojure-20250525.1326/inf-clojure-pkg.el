;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-clojure" "20250525.1326"
  "Basic interaction with a Clojure REPL."
  '((emacs        "27.1")
    (clojure-mode "5.11"))
  :url "http://github.com/clojure-emacs/inf-clojure"
  :commit "b6268430a357b34a10fe9412df507bed77e28fa4"
  :revdesc "b6268430a357"
  :keywords '("processes" "comint" "clojure")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
