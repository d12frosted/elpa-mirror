(define-package "easy-kill-extras" "20210524.1500" "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :commit "04afcdae128424a156c960cfce9d02e3aa1bf9a6" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/easy-kill-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
