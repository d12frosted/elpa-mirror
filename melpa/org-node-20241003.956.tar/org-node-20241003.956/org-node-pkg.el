;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241003.956"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "665d0b5116eba1604f0bb57bbae3f442eb500011"
  :revdesc "665d0b5116eb"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
