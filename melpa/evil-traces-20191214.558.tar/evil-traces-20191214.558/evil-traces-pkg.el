(define-package "evil-traces" "20191214.558" "Visual hints for `evil-ex'"
  '((emacs "25.1")
    (evil "1.2.13"))
  :commit "05e201cd63b549e3c88b5c3fc9b264bd6fe5a42c" :authors
  '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainers
  '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainer
  '("Daniel Phan" . "daniel.phan36@gmail.com")
  :keywords
  '("emulations" "evil" "visual")
  :url "https://github.com/mamapanda/evil-traces")
;; Local Variables:
;; no-byte-compile: t
;; End:
