(define-package "helm-core" "20220217.812" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "fbe5eb03255c18466162253c60db7b6ca50f32b4" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
