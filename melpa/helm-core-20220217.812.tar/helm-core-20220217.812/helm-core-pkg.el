(define-package "helm-core" "20220217.812" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "46008f69fded4fe7e3cba942a8c7ce91a3cf1187" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
