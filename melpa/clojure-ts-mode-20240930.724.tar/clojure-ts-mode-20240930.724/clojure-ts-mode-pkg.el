;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20240930.724"
  "Major mode for Clojure code."
  '((emacs "29.1"))
  :url "https://github.com/clojure-emacs/clojure-ts-mode"
  :commit "fd7e5dab9efe08c0e2bdf7ca6ada2a063915f2ec"
  :revdesc "fd7e5dab9efe"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Danny Freeman" . "danny@dfreeman.email")))
