;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-pandoc" "20261117.1126"
  "An Org-mode exporter using pandoc."
  '((org   "8.2")
    (emacs "24.4")
    (dash  "2.8")
    (ht    "2.0"))
  :url "https://github.com/a-fent/ox-pandoc"
  :commit "b917e864108cb47c5c0124803d316730a98f1128"
  :revdesc "b917e864108c"
  :keywords '("tools")
  :authors '(("Taichi" . "kawabata.taichi@gmail.com")
             ("Alex" . "a-fent@github"))
  :maintainers '(("Alex" . "a-fent@github")))
