(define-package "skeletor" "20151221.454" "Provides project skeletons for Emacs"
  '((s "1.7.0")
    (f "0.14.0")
    (dash "2.2.0")
    (cl-lib "0.3")
    (let-alist "1.0.3")
    (emacs "24.1"))
  :commit "d986806559628623b591542143707de8d76347d0" :authors
  '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainer
  '("Chris Barrett" . "chris.d.barrett@me.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
