;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-project-extra" "20260428.547"
  "Consult integration for project.el."
  '((emacs   "28.1")
    (consult "0.17")
    (project "0.8.1"))
  :url "https://github.com/Qkessler/consult-project-extra"
  :commit "b8b2a1a244830f366e3a32b6a98a1d4a74fc276a"
  :revdesc "b8b2a1a24483"
  :keywords '("convenience" "project" "management"))
