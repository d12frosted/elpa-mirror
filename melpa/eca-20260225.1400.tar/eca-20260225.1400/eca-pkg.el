;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260225.1400"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "91d97fa5018eaa70b6fd5c71d588729bef5f2106"
  :revdesc "91d97fa5018e"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
