(define-package "modus-themes" "20220927.1257" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "375450fbdbda8e2045d786d0b38129632122962d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
