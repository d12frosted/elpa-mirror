(define-package "cape" "20220429.1945" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "5c96c5cdff72b93ca4adea5e36da51fa87d03eb6" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
