;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boa-mode" "20230730.2216"
  "Mode for boa language files."
  '((emacs "26.1"))
  :url "https://github.com/boalang/syntax-highlight"
  :commit "892f2a33ef95db9f19b45deb8309652534f91efd"
  :revdesc "892f2a33ef95"
  :keywords '("languages")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
