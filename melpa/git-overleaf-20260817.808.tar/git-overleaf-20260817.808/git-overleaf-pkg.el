;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "20260817.808"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs         "29.4")
    (websocket     "1.15")
    (webdriver     "0.1")
    (magit-section "4.5")
    (transient     "0.7.2"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "cdfaf78e6eb13f8026dab9017cbee9e799ecf6c7"
  :revdesc "cdfaf78e6eb1"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
