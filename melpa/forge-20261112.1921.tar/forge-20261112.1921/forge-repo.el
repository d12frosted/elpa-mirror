;;; forge-repo.el --- Repository support  -*- lexical-binding:t -*-

;; Copyright (C) 2018-2026 Jonas Bernoulli

;; Author: Jonas Bernoulli <emacs.forge@jonas.bernoulli.dev>
;; Maintainer: Jonas Bernoulli <emacs.forge@jonas.bernoulli.dev>

;; SPDX-License-Identifier: GPL-3.0-or-later

;; This file is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published
;; by the Free Software Foundation, either version 3 of the License,
;; or (at your option) any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this file.  If not, see <https://www.gnu.org/licenses/>.

;;; Code:

(require 'forge)
(require 'eieio)

;;; Classes

(defclass forge-repository (forge-object)
  ((closql-class-prefix        :initform "forge-")
   (closql-class-suffix        :initform "-repository")
   (closql-table               :initform 'repository)
   (closql-primary-key         :initform 'id)
   (discussions-url-format     :initform nil :allocation :class)
   (discussion-url-format      :initform nil :allocation :class)
   (discussion-post-url-format :initform nil :allocation :class)
   (issues-url-format          :initform nil :allocation :class)
   (issue-url-format           :initform nil :allocation :class)
   (issue-post-url-format      :initform nil :allocation :class)
   (pullreqs-url-format        :initform nil :allocation :class)
   (pullreq-url-format         :initform nil :allocation :class)
   (pullreq-post-url-format    :initform nil :allocation :class)
   (commit-url-format          :initform nil :allocation :class)
   (branch-url-format          :initform nil :allocation :class)
   (remote-url-format          :initform nil :allocation :class)
   (blob-url-format            :initform nil :allocation :class)
   (create-issue-url-format    :initform nil :allocation :class)
   (create-pullreq-url-format  :initform nil :allocation :class)
   (pullreq-refspec            :initform nil :allocation :class)
   (id                         :initform nil :initarg :id)
   (forge-id                   :initform nil :initarg :forge-id)
   (forge                      :initform nil :initarg :forge)
   (owner                      :initform nil :initarg :owner)
   (name                       :initform nil :initarg :name)
   (apihost                    :initform nil :initarg :apihost)
   (githost                    :initform nil :initarg :githost)
   (remote                     :initform nil :initarg :remote)
   (condition                  :initform :stub)
   (created                    :initform nil)
   (updated                    :initform nil)
   (pushed                     :initform nil)
   (parent                     :initform nil)
   (description                :initform nil)
   (homepage                   :initform nil)
   (default-branch             :initform nil)
   (archived-p                 :initform nil)
   (fork-p                     :initform nil)
   (locked-p                   :initform nil)
   (mirror-p                   :initform nil)
   (private-p                  :initform nil)
   (issues-p                   :initform t)
   (wiki-p                     :initform nil)
   (stars                      :initform nil)
   (watchers                   :initform nil)
   (assignees                  :closql-table assignee)
   (forks                      :closql-table fork)
   (issues                     :closql-class forge-issue)
   (labels                     :closql-table label)
   (pullreqs                   :closql-class forge-pullreq)
   (revnotes                   :closql-class forge-revnote)
   (selective-p                :initform nil)
   (worktree                   :initform nil)
   (milestones                 :closql-table milestone)
   (issues-until               :initform nil)
   (pullreqs-until             :initform nil)
   (teams                      :initform nil)
   (discussion-categories      :closql-table discussion-category)
   (discussions                :closql-class forge-discussion)
   (discussions-p              :initform nil)
   (discussions-until          :initform nil)
   (topic-templates            :closql-table topic-template))
  :abstract t)

(defclass forge-unusedapi-repository (forge-repository) () :abstract t)

(defclass forge-noapi-repository (forge-repository) () :abstract t)

(cl-defmethod slot-missing ((object forge-repository)
                            slot-name operation &optional _new-value)
  (if (and (eq operation 'oref)
           (eq slot-name 'slug))
      (concat (oref object owner) "/"
              (oref object name))
    (cl-call-next-method)))

;;; Query
;;;; Get

(defvar-local forge-buffer-repository nil)
(put 'forge-buffer-repository 'permanent-local t)

(defvar-local forge-buffer-unassociated-p nil)

(defconst forge--signal-no-entry '(:tracked :stub :insert!))

(defun forge--get-remote (&optional warn ignore-variable)
  (let* ((remotes (magit-list-remotes))
         (config (and (not ignore-variable)
                      (magit-get "forge.remote")))
         (remote (if (cdr remotes)
                     (or (car (member config remotes))
                         (car (member "upstream" remotes))
                         (car (member "origin" remotes)))
                   (car remotes))))
    (when (and warn config remote (not (equal config remote)))
      (message "Ignored forge.remote=%s; no such remote.\nSee %s." config
               "https://docs.magit.vc/forge/How-Forge-Detection-Works.html"))
    remote))

(defun forge--get-default-branch (repo)
  (let ((default-directory (forge-get-worktree repo)))
    (concat (forge--get-remote) "/"
            (or (oref repo default-branch) "master"))))

(cl-defmethod forge-get-repository ((_(eql :id)) id)
  (closql-get (forge-db) (substring-no-properties id) 'forge-repository))

(cl-defmethod forge-get-repository ((_(eql :dir)) dir)
  (let ((default-directory dir)
        (forge-buffer-repository nil)
        (forge-buffer-topic nil))
    (forge-get-repository :stub? nil 'notatpt)))

(cl-defmethod forge-get-repository ((demand symbol) &optional remote notatpt)
   "Return the current forge repository.

First check if `forge-buffer-repository', or if that is nil, then
the repository for `forge-buffer-topic', satisfies DEMAND.  If so,
then return that repository.

Otherwise return the repository for `default-directory', if that
exists and satisfies DEMAND.  If that fails too, then return nil
or signal an error, depending on DEMAND."
  (or (and-let ((_(not notatpt))
                (repo (forge-repository-at-point)))
        (forge-get-repository repo 'noerror demand))
      (and-let ((_(not remote))
                (repo (or (forge-buffer-repository)
                          (and forge-buffer-topic
                               (forge-get-repository forge-buffer-topic)))))
        (forge-get-repository repo 'noerror demand))
      (magit--with-refresh-cache
          (list default-directory 'forge-get-repository demand)
        (cond-let
          ((not (magit-gitdir))
           (when (memq demand forge--signal-no-entry)
             (error
              "Cannot determine Forge repository outside of Git repository")))
          [[remote (or remote (forge--get-remote 'warn))]]
          ([_ remote]
           [url (magit-git-string "remote" "get-url" remote)]
           (and$ (forge-get-repository url remote demand)
                 (prog1 $ (oset $ worktree (magit-toplevel)))))
          ((memq demand forge--signal-no-entry)
           (error
            "Cannot determine forge repository.  %s\nSee %s."
            (cond (remote (format "No url configured for %S." remote))
                  ((and$ (magit-get "forge.remote")
                         (format "Value of `forge.remote' is %S but %s"
                                 $ "that remote does not exist.")))
                  ((magit-list-remotes) "Cannot decide on remote to use.")
                  (t "No remote configured."))
            "https://docs.magit.vc/forge/How-Forge-Detection-Works.html"))))))

(cl-defmethod forge-get-repository ((url string) &optional remote demand)
  "Return the repository at URL."
  (cond-let
    ([parts (forge--split-forge-url url)]
     (forge-get-repository parts remote (or demand :known?)))
    ((memq demand forge--signal-no-entry)
     (error "Cannot determine forge repository.  %s isn't a forge URL.  %s"
            url "You might have to customize `forge-alist'."))))

(cl-defmethod forge-get-repository (((host owner name) list)
                                    &optional remote demand)
  "((HOST OWNER NAME) &optional REMOTE DEMAND)

Return the repository identified by HOST, OWNER and NAME.
See `forge-alist' for valid Git hosts."
  (setq host  (substring-no-properties host))
  (setq owner (substring-no-properties owner))
  (setq name  (substring-no-properties name))
  (unless (memq demand
                '(:tracked :tracked? :known? :insert! :valid? :stub :stub?))
    (error "Unknown value %s for `forge-get-repository's DEMAND" demand))
  (cond-let
    ([spec (forge--get-forge-host host t)]
     (pcase-let* ((db (forge-db))
                  ;; The WEBHOST is used to identify the corresponding forge.
                  ;; For that reason it is stored in the FORGE slot.  The ID
                  ;; stored in the ID slot also derives from that value.
                  (`(,githost ,apihost ,webhost ,class) spec)
                  (obj (and$ (car (forge-sql [:select * :from repository
                                              :where (and (= forge $s1)
                                                          (= owner $s2)
                                                          (= name  $s3))]
                                             webhost owner name))
                             (closql--remake-instance class (forge-db) $))))
       ;; The repository is known.  We might need it to be tracked as well.
       (pcase (list demand (and obj (eq (oref obj condition) :tracked)))
         (`(:tracked? nil) (setq obj nil))
         (`(:tracked  nil)
          (error "Forge doesn't track %s yet.\n%s" (magit-toplevel)
                 "Use `M-x forge-add-repository' to start tracking.")))
       ;; No repository found using OWNER/NAME.  Maybe it was renamed so
       ;; maybe look it up using its ID, which we have to retrieve from
       ;; the forge first.
       (when (and (not obj)
                  ;; If a known or even tracked repository was requested
                  ;; then there is nothing left to be done, regardless of
                  ;; whether there is a known/tracked repository or not.
                  (memq demand '(:insert! :valid? :stub :stub?)))
         (pcase-let ((`(,id ,current-owner ,current-name ,forge-id)
                      ;; Make no network request, if we only need a stub.
                      ;; For a stub we won't know whether it actually
                      ;; exists on the forge.  Use :valid? if we must be
                      ;; certain.
                      (cond ((memq demand '(:stub :stub?))
                             (forge--identify-repo :stub webhost owner name))
                            ((forge--identify-repo class webhost owner name)))))
           (cond
             ((not id)
              ;; Repository does not exist on the forge.
              (when (eq demand :insert!)
                (error "BUG: Use of :insert! without using :valid? first")))
             ((setq obj (forge-get-repository :id id))
              ;; Repository was renamed/moved on the forge.
              (oset obj owner current-owner)
              (oset obj name  current-name))
             ((setq obj (funcall class
                                 :id       id
                                 :forge-id forge-id
                                 :forge    webhost
                                 :owner    current-owner
                                 :name     current-name
                                 :apihost  apihost
                                 :githost  githost
                                 :remote   remote))
              (when (eq demand :insert!)
                (closql-insert db obj)
                (oset obj condition :known))))))
       (when obj
         (oset obj remote remote)
         ;; Synchronize the object with the entry from `forge-alist'.
         ;; This only has an effect if the entry was modified, which
         ;; should rarely, if ever, happen.
         (oset obj apihost apihost)
         (oset obj githost githost))
       obj))
    ((memq demand forge--signal-no-entry)
     (error "Cannot determine forge repository.  No entry for %S in %s"
            host 'forge-alist))))

(cl-defmethod forge-get-repository ((repo forge-repository)
                                    &optional noerror demand)
  (setq noerror (and noerror t))
  (with-slots (condition slug) repo
    (cl-symbol-macrolet
        ((err (error "Requested %s for %s, but is %s" demand slug condition))
         (key (list (oref repo forge)
                    (oref repo owner)
                    (oref repo name)))
         (ins (forge-get-repository key nil :insert!))
         (set (forge-get-repository key nil :valid?)))
      (pcase-exhaustive (list demand condition noerror)
        (`(nil       ,_                     ,_)  repo)
        (`(:tracked? :tracked               ,_)  repo)
        (`(:tracked? ,_                     ,_)   nil)
        (`(:tracked  :tracked               ,_)  repo)
        (`(:tracked  ,_                      t)   nil)
        (`(:tracked  ,_                    nil)   err)
        (`(:known?   ,(or :tracked :known)  ,_)  repo)
        (`(:known?   ,_                     ,_)   nil)
        (`(:insert!  ,(or :tracked :known)  ,_)  repo)
        (`(:insert!  ,_                     ,_)   ins)
        (`(:valid?   ,(or :tracked :known)  ,_)  repo)
        (`(:valid?   ,_                     ,_)   set)
        (`(:stub?    ,_                     ,_)  repo)
        (`(:stub     ,_                     ,_)  repo)))))

(cl-defmethod forge-get-repository ((_ null) &optional noerror demand)
  (if (and (memq demand '(:insert! :tracked :stub))
           (not noerror))
      (error "(Maybe repository) is nil; `%s' not satisfied" demand)
    nil))

(defun forge-repository-at-point (&optional demand)
  "Return the repository at point.
If there is no such repository and DEMAND is non-nil, then signal
an error."
  (or (magit-section-value-if 'forge-repo)
      (and-let ((topic (forge-topic-at-point)))
        (forge-get-repository topic))
      (and-let ((_(derived-mode-p 'forge-repository-list-mode))
                (id (tabulated-list-get-id)))
        (forge-get-repository :id id))
      (and-let ((_(derived-mode-p 'magit-repolist-mode))
                (dir (tabulated-list-get-id)))
        (forge-get-repository :dir dir))
      (and demand (user-error "No repository at point"))))

(defun forge--repo-for-thingatpt ()
  (or (magit-section-value-if 'forge-repo)
      (and-let ((topic (magit-section-value-if '(issue pullreq))))
        (forge-get-repository topic))
      (and (not forge-buffer-unassociated-p)
           (or (forge-buffer-repository)
               (forge-get-repository :known? nil 'notatpt)))))

(defun forge-buffer-repository ()
  (and-let* ((id forge-buffer-repository)
             (repo (forge-get-repository :id id))
             (_(member (forge--get-remote) (list nil (oref repo remote)))))
    repo))

(defun forge-set-buffer-repository ()
  "Initialize the value of variable `forge-buffer-repository'."
  (unless forge-buffer-repository
    (and$ (forge-get-repository :known?)
          (setq forge-buffer-repository (oref $ id)))))

(add-hook 'magit-mode-hook #'forge-set-buffer-repository)

(defun forge-get-worktree (repo)
  "Validate, remember and return a worktree for REPO.
If `default-directory' is within one of REPO's worktrees, record that
location in its `worktree' slot and return it.  Otherwise, if a worktree
has been recorded before, validate that.  If it still is a worktree of
REPO, return it, else set the slot to nil and return nil."
  (cond-let*
    ([_(forge-repository-equal
        repo (forge-get-repository :dir default-directory))]
     [current-tree (magit-toplevel)]
     (oset repo worktree current-tree))
    ([saved-tree (oref repo worktree)]
     [_(file-accessible-directory-p saved-tree)]
     (if (forge-repository-equal repo (forge-get-repository :dir saved-tree))
         saved-tree
       (oset repo worktree nil)))))

;;;; List

(defun forge--ls-repos ()
  (mapcar (partial #'closql--remake-instance 'forge-repository (forge-db))
          (forge-sql [:select * :from repository
                      :order-by [(asc owner) (asc name)]])))

(defun forge--ls-owned-repos ()
  (mapcar (partial #'closql--remake-instance 'forge-repository (forge-db))
          (forge-sql [:select * :from repository
                      :where (and (in owner $v1)
                                  (not (in name $v2)))
                      :order-by [(asc owner) (asc name)]]
                     (vconcat (mapcar #'car forge-owned-accounts))
                     (vconcat forge-owned-ignored))))

;;; Identity

(defun forge-repository-equal (repo1 repo2)
  "Return t if REPO1 and REPO2 are the same repository.
REPO1 and/or REPO2 may also be nil, in which case return nil."
  (and repo1 repo2
       (or (equal      (oref repo1 id)      (oref repo2 id))
           (and (equal (oref repo1 githost) (oref repo2 githost))
                (equal (oref repo1 owner)   (oref repo2 owner))
                (equal (oref repo1 name)    (oref repo2 name))))))

(cl-defmethod forge--identify-repo ((_ (eql :stub)) host owner name)
  (pcase-let ((`(,_ ,_ ,hostid ,_) (forge--get-forge-host host t))
              (path (format "%s/%s" owner name)))
    (list (base64-encode-string (format "%s:%s" hostid path) t)
          owner name path)))

(cl-defmethod forge--identify-repo ((_class (subclass forge-noapi-repository))
                                     host owner name)
  (forge--identify-repo :stub host owner name))

;;; Read

(defun forge-read-repository (prompt)
  (let ((choice (magit-completing-read
                 prompt
                 (mapcar (pcase-lambda (`(,host ,owner ,name))
                           (format "%s/%s @%s" owner name host))
                         (forge-sql [:select [githost owner name]
                                     :from repository]))
                 nil t nil nil
                 (and$ (forge-get-repository :known?)
                       (format "%s/%s @%s"
                               (oref $ owner)
                               (oref $ name)
                               (oref $ githost))))))
    (save-match-data
      (if (string-match "\\`\\(.+\\)/\\([^/]+\\) @\\(.+\\)\\'" choice)
          (forge-get-repository (list (match-string 3 choice)
                                      (match-string 1 choice)
                                      (match-string 2 choice))
                                nil :known?)
        (error "BUG")))))

(defun forge-select-repository (prompt &optional demand)
  (or (forge-get-repository (or demand :known?))
      (forge-read-repository prompt)))

(defun forge-read-host (prompt &optional class)
  (magit-completing-read
   prompt
   (if class
       (seq-keep (pcase-lambda (`(,githost ,_apihost ,_webhost ,c))
                   (and (child-of-class-p c class) githost))
                 forge-alist)
     (mapcar #'car forge-alist))
   nil t))

;;; Miscellaneous

(cl-defmethod forge--format ((repo forge-repository) format-or-slot &optional spec)
  (pcase-let* (((eieio (forge webhost) owner name) repo)
               (path (if owner (concat owner "/" name) name)))
    (format-spec
     (let ((format (if (symbolp format-or-slot)
                       (eieio-oref repo format-or-slot)
                     format-or-slot)))
       (if (member webhost ghub-insecure-hosts)
           (replace-regexp-in-string "\\`https://" "http://" format t t)
         format))
     `(,@spec
       (?h . ,webhost)
       (?o . ,owner)
       (?n . ,name)
       (?p . ,path)
       (?P . ,(string-replace "/" "%2F" path))))))

(defun forge--repo-selective-p (&optional repo)
  (and-let ((repo (or repo (forge-get-repository :tracked?))))
    (or (oref repo selective-p)
        ;; We do not record whether the initial pull only fetched topics
        ;; created after a certain date, so we have to use a heuristic.
        ;; Topics can be deleted, so any of the first three topics will
        ;; have to do.
        (not (or (forge-get-topic repo 1)
                 (forge-get-topic repo 2)
                 (forge-get-topic repo 3))))))

(defvar forge--mode-line-buffer nil)

(defun forge--msg (repo echo done format &rest args)
  (let ((msg (apply #'format format args)))
    (when repo
      (setq msg (string-replace
                 "REPO"
                 (concat (oref repo owner) "/" (oref repo name))
                 msg)))
    (when (and echo msg)
      (message "%s%s" msg (if done "...done" "...")))
    (when (buffer-live-p forge--mode-line-buffer)
      (with-current-buffer forge--mode-line-buffer
        (setq mode-line-process
              (if done
                  nil
                (concat " " (propertize msg 'font-lock-face
                                        'magit-mode-line-process)))))
      (force-mode-line-update t))))

(defun forge--as-githost (host)
  (or (car (car (cl-member host forge-alist :test #'equal :key #'car)))
      (car (car (cl-member host forge-alist :test #'equal :key #'cadr)))
      (car (car (cl-member host forge-alist :test #'equal :key #'caddr)))
      (error "Cannot determine githost for %S" host)))

(defun forge--as-apihost (host)
  (or (cadr (car (cl-member host forge-alist :test #'equal :key #'cadr)))
      (cadr (car (cl-member host forge-alist :test #'equal :key #'car)))
      (cadr (car (cl-member host forge-alist :test #'equal :key #'caddr)))
      (error "Cannot determine apihost for %S" host)))

(defun forge--as-webhost (host &optional noerror)
  (or (caddr (car (cl-member host forge-alist :test #'equal :key #'cadr)))
      (caddr (car (cl-member host forge-alist :test #'equal :key #'car)))
      (caddr (car (cl-member host forge-alist :test #'equal :key #'caddr)))
      (and (not noerror)
           (error "Cannot determine webhost for %S" host))))

(defun forge--host-id (host)
  (or (forge--as-webhost host t)
      (error "Cannot determine identifier for %S" host)))

(cl-defmethod ghub--host ((repo forge-repository))
  (cl-call-next-method (forge--ghub-type-symbol (eieio-object-class repo))))

(cl-defmethod ghub--username ((repo forge-repository))
  (let ((default-directory default-directory))
    (unless (forge-repository-equal (forge-get-repository :stub?) repo)
      (when-let ((worktree (forge-get-worktree repo)))
        (setq default-directory worktree)))
    (cl-call-next-method (forge--host-id (oref repo apihost))
                         (forge--ghub-type-symbol (eieio-object-class repo)))))

(defun forge--ghub-type-symbol (class)
  (pcase-exhaustive class
    ('forge-github-repository    'github)
    ('forge-gitlab-repository    'gitlab)
    ('forge-forgejo-repository   'forgejo)
    ('forge-gitea-repository     'gitea)
    ('forge-gogs-repository      'gogs)
    ('forge-bitbucket-repository 'bitbucket)))

;;; _
;; Local Variables:
;; read-symbol-shorthands: (
;;   ("and$"          . "cond-let--and$")
;;   ("thread$"       . "cond-let--thread$")
;;   ("when$"         . "cond-let--when$")
;;   ("and-let*"      . "cond-let--and-let*")
;;   ("and-let"       . "cond-let--and-let")
;;   ("if-let*"       . "cond-let--if-let*")
;;   ("if-let"        . "cond-let--if-let")
;;   ("when-let*"     . "cond-let--when-let*")
;;   ("when-let"      . "cond-let--when-let")
;;   ("while-let*"    . "cond-let--while-let*")
;;   ("while-let"     . "cond-let--while-let")
;;   ("partial"       . "llama--left-apply-partially"))
;; End:
(provide 'forge-repo)
;;; forge-repo.el ends here
