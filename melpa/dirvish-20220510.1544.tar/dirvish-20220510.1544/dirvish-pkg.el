(define-package "dirvish" "20220510.1544" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "7373affacc4ce4169adc986006125005922ca835" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
