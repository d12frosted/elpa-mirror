;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neil" "20260524.1246"
  "Companion for Babashka Neil."
  '((emacs "29.4"))
  :url "https://github.com/babashka/neil"
  :commit "2cdd7c66843ba3f1a2adb08208f2312b72b31900"
  :revdesc "2cdd7c66843b"
  :keywords '("convenience" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
