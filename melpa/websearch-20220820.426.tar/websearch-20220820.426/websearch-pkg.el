(define-package "websearch" "20220820.426" "Query search engines"
  '((emacs "24.4"))
  :commit "d3211664727c03d1aec36f4c10fbd5a6e92ffc63" :authors
  '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainer
  '("Maciej Barć" . "xgqt@riseup.net")
  :keywords
  '("convenience" "hypermedia")
  :url "https://gitlab.com/xgqt/emacs-websearch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
