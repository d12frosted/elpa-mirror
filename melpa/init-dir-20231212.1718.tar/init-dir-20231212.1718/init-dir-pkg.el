(define-package "init-dir" "20231212.1718" "Init directory instead of just a single file"
  '((emacs "27.1"))
  :commit "ea9f1314041c83ef60fd293bea01d5fb025c72e3" :authors
  '(("Jared Finder" . "jared@finder.org"))
  :maintainers
  '(("Jared Finder" . "jared@finder.org"))
  :maintainer
  '("Jared Finder" . "jared@finder.org")
  :keywords
  '("extensions" "internal")
  :url "http://github.com/chaosemer/init-dir")
;; Local Variables:
;; no-byte-compile: t
;; End:
