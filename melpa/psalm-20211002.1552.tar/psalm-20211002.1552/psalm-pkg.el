(define-package "psalm" "20211002.1552" "Interface to Psalm"
  '((emacs "24.3")
    (php-mode "1.22.3"))
  :commit "06434b938485e2540fc97ce6cb017a8a001c1f13" :authors
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("tools" "php")
  :url "https://github.com/emacs-php/psalm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
