;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260517.1140"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "675a19aa68df693fa26070bf19b5d6fd53f2990f"
  :revdesc "675a19aa68df"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
