;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nord-theme" "20250309.1122"
  "An arctic, north-bluish clean and elegant theme."
  '((emacs "24"))
  :url "https://github.com/nordtheme/emacs"
  :commit "336a76ab504171ef47816d7697af714f9cd69e1d"
  :revdesc "336a76ab5041"
  :authors '(("Sven Greb" . "development@svengreb.de"))
  :maintainers '(("Sven Greb" . "development@svengreb.de")))
