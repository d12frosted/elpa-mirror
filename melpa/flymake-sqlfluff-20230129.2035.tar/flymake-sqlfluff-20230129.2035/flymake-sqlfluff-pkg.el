(define-package "flymake-sqlfluff" "20230129.2035" "A flymake plugin for SQL files using sqlfluff"
  '((emacs "27.1"))
  :commit "f7921a5b762eb0675b8fca7cfb00273a76eaee5b" :authors
  '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers
  '(("Erick Navarro" . "erick@navarro.io"))
  :maintainer
  '("Erick Navarro" . "erick@navarro.io")
  :url "https://github.com/erickgnavar/flymake-sqlfluff")
;; Local Variables:
;; no-byte-compile: t
;; End:
