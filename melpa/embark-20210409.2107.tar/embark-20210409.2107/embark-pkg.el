(define-package "embark" "20210409.2107" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "5f3097824f8c3d17bcd70c4e4ce597bcfcf2196f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
