(define-package "live-py-mode" "20211023.2036" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "3191fbb9954815bdef0af5a3d469b4f820d5a233" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
