;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260227.530"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "4034025d8a7dd781b923ea8fc45d1a60df761759"
  :revdesc "4034025d8a7d"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
