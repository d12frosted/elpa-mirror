;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260427.303"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "2130baba8e5e15922650bc01de95a1d6c6a1c1f7"
  :revdesc "2130baba8e5e"
  :keywords '("convenience" "chinese" "input-method" "rime"))
