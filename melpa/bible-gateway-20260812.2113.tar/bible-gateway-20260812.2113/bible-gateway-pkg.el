;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260812.2113"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "28af97571e8ba9eb5d190b675110c9f1d0ebe7f3"
  :revdesc "28af97571e8b"
  :keywords '("convenience" "comm" "hypermedia"))
