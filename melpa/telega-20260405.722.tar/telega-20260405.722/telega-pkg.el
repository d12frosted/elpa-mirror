;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260405.722"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "849feedf504ae8f48987e0cf38a3b01d7cbd4ae9"
  :revdesc "849feedf504a"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
