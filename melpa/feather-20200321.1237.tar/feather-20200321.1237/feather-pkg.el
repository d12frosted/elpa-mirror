(define-package "feather" "20200321.1237" "Parallel thread modern package manager"
  '((emacs "26.3")
    (async "1.9")
    (async-await "1.0")
    (ppp "1.0")
    (page-break-lines "0.1"))
  :commit "3f19293dada8bf368e9f86f783610e7ca0a51ecb" :keywords
  ("convenience" "package")
  :authors
  (("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  ("Naoya Yamashita" . "conao3@gmail.com")
  :url "https://github.com/conao3/feather.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
