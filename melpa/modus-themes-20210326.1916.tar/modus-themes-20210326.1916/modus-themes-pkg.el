(define-package "modus-themes" "20210326.1916" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "e07461ca01b04a6536961eb538769f9889813852" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
