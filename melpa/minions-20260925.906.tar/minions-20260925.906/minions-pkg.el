;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minions" "20260925.906"
  "A minor-mode menu for the mode line."
  '((emacs  "29.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/minions"
  :commit "d683c91b8d20efb2ad799e55faae98c5b23c8077"
  :revdesc "d683c91b8d20"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev")))
