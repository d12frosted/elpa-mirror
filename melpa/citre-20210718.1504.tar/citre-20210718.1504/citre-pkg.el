(define-package "citre" "20210718.1504" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "81b6d19941a3e0905cfc0491e9bba44dff0a0712" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
