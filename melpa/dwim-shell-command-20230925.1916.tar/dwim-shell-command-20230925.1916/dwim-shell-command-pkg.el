(define-package "dwim-shell-command" "20230925.1916" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "3ad3db9155bdde0dc050690b2d50a57a3ac99aa4" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
