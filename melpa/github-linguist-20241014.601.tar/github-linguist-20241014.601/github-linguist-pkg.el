;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-linguist" "20241014.601"
  "Run GitHub Linguist on projects to collect information."
  '((emacs   "28.1")
    (project "0.8")
    (async   "1.9")
    (map     "3"))
  :url "https://github.com/akirak/github-linguist.el"
  :commit "442bc84dcdd3fe756f228b52fd027842f419e52b"
  :revdesc "442bc84dcdd3"
  :keywords '("processes")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
