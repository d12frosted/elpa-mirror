(define-package "embark" "20220404.2326" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "05cf792f8fdc061cfacf8686e1bb39d9c6e092ac" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
