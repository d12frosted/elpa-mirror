;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinboard" "20230101.850"
  "A pinboard.in client."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/davep/pinboard.el"
  :commit "112e903b489fed3f71b3165447ba6f21ee5675e6"
  :revdesc "112e903b489f"
  :keywords '("hypermedia" "bookmarking" "reading" "pinboard")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
