(define-package "math-symbols" "20201005.2313" "Math Symbol Input methods and conversion tools" 'nil :commit "091b81cb40ceaff97614999ffe85b572ace182f0" :keywords
  ("i18n" "languages" "tex")
  :authors
  (("KAWABATA, Taichi <kawabata.taichi_at_gmail.com>"))
  :maintainer
  ("KAWABATA, Taichi <kawabata.taichi_at_gmail.com>")
  :url "https://github.com/kawabata/math-symbols")
;; Local Variables:
;; no-byte-compile: t
;; End:
