(define-package "loopy" "20210828.1741" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "80885a104654a9958d652ab35170f50daaee6023" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
