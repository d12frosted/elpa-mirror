(define-package "verb" "20210104.2336" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "7ee2d15a14985f30ca2a750691817634b2382b38" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
