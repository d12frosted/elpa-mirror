;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260614.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "0ee89a4761665322f8bfdbd6823f193b955ad2b6"
  :revdesc "0ee89a476166"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
