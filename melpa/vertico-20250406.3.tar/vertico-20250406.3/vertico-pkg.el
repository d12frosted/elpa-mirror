;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20250406.3"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "d65a0db53edeb65aee0e3c2b5f8332ffc3381ba8"
  :revdesc "d65a0db53ede"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
