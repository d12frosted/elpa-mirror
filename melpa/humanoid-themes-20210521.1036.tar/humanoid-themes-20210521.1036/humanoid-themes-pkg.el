(define-package "humanoid-themes" "20210521.1036" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "1e408e8221c8c041dddb85cf33ec4919ebcf3586" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
