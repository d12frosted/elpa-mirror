;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261015.804"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "cd335eafc99a3855c120c4889b455a5d46740349"
  :revdesc "cd335eafc99a"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
