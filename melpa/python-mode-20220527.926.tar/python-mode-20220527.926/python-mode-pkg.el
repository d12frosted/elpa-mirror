(define-package "python-mode" "20220527.926" "Python major mode" 'nil :commit "31c6696c2b11d20a6832d009137575f75f49578c" :authors
  '(("2015-2021 https://gitlab.com/groups/python-mode-devs")
    ("2003-2014 https://launchpad.net/python-mode")
    ("1995-2002 Barry A. Warsaw")
    ("1992-1994 Tim Peters"))
  :maintainer
  '(nil . "python-mode@python.org")
  :keywords
  '("languages" "processes" "python" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
