(define-package "dwim-shell-command" "20231107.818" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "9b6b02dc95add7b3141efae711b863be42f7265d" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
