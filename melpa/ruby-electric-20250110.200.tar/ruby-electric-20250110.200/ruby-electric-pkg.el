;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-electric" "20250110.200"
  "Minor mode for electrically editing ruby code."
  ()
  :url "https://github.com/ruby/elisp-ruby-electric"
  :commit "93256c805251d8d98c45a8742713c610b7d4a6ac"
  :revdesc "93256c805251"
  :keywords '("languages" "ruby")
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
