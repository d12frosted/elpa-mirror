;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "20260602.1511"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "3ef070cfc9bf87d8e61d77b80e71ad0611074564"
  :revdesc "3ef070cfc9bf"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
