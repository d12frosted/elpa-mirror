(define-package "pomm" "20220815.824" "Pomodoro and Third Time timers"
  '((emacs "27.1")
    (alert "1.2")
    (seq "2.22")
    (transient "0.3.0"))
  :commit "42f03d6ff29109038b31a8647f1acdc80fb867be" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/pomm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
