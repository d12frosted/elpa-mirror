;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250220.446"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.1")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "90428a8fae6b329241f906fba0d6501a373594b8"
  :revdesc "90428a8fae6b"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
