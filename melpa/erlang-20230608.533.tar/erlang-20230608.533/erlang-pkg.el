(define-package "erlang" "20230608.533" "Erlang major mode"
  '((emacs "24.1"))
  :commit "b54b86ad4f1253f46fd4552a73923756660c1d53" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
