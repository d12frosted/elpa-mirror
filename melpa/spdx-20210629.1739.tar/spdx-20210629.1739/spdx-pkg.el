(define-package "spdx" "20210629.1739" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "b915b063f9de2eff4b9a37c04559a3f2fbfdba84" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
