;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hippo-themes" "20260918.38"
  "Hippo color theme."
  '((emacs "24.1"))
  :url "https://github.com/kimim/emacs-hippo-theme"
  :commit "1ba5d9641833930dd0487fa1b6a4440b63b0bc00"
  :revdesc "1ba5d9641833"
  :keywords '("faces" "local" "color" "theme"))
