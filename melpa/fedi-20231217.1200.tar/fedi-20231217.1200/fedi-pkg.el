(define-package "fedi" "20231217.1200" "Helper functions for fediverse clients"
  '((emacs "28.1")
    (markdown-mode "2.5"))
  :commit "772f1725e2ee46f4b12763fa2e95aeaca6b0d4d4" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
