;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20261028.1225"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "83190d8827a7eab43e1c52614d0dcc1e32bdb62a"
  :revdesc "83190d8827a7"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
