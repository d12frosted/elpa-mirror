;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260314.1619"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "9faee8bac41c6cf64c6c2e9f5ba17b1ff5eaa9d8"
  :revdesc "9faee8bac41c"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
