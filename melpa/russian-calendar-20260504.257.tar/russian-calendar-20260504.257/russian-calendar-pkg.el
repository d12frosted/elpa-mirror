;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20260504.257"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "9f1d983bbd63197108a9073720c113f1b66a0a70"
  :revdesc "9f1d983bbd63"
  :keywords '("calendar" "holidays"))
