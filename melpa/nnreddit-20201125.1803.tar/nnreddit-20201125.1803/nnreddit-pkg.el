(define-package "nnreddit" "20201125.1803" "Gnus Backend For Reddit"
  '((emacs "25.1")
    (virtualenvwrapper "20190223")
    (json-rpc "20200417")
    (dash "20190401")
    (anaphora "20180618")
    (request "20190819"))
  :commit "9085d7b0b85bf8857901f03488c0e6a66ecbc5aa" :url "https://github.com/dickmao/nnreddit")
;; Local Variables:
;; no-byte-compile: t
;; End:
