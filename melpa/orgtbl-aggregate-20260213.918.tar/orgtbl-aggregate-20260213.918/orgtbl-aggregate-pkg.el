;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260213.918"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "4d5694bbe2b2b0b788f83bc49d57320c2b3fa5d1"
  :revdesc "4d5694bbe2b2"
  :keywords '("data" "extensions"))
