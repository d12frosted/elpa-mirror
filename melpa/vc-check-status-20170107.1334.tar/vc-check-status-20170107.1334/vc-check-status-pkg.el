(define-package "vc-check-status" "20170107.1334" "Warn you when quitting emacs and leaving repo dirty." 'nil :commit "37734beb16bfd8633ea328059bf9a47eed826d5c" :authors
  (("Sylvain Rousseau <thisirs at gmail dot com>"))
  :maintainer
  ("Sylvain Rousseau <thisirs at gmail dot com>")
  :keywords
  ("vc" "convenience")
  :url "https://github.com/thisirs/vc-check-status")
;; Local Variables:
;; no-byte-compile: t
;; End:
