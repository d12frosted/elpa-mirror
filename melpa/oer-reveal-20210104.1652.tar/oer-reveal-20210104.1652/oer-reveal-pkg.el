(define-package "oer-reveal" "20210104.1652" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "44d61b14278b931593c9086eda6234b592b3a243" :authors
  (("Jens Lechtenbörger"))
  :maintainer
  ("Jens Lechtenbörger")
  :keywords
  ("hypermedia" "tools" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
