(define-package "sway" "20230731.1819" "Communication with the Sway window manager"
  '((emacs "27.1")
    (dash "2.18.1"))
  :commit "be38a30e41ea1d1ac670679c7e890cff6204f581" :authors
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainers
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainer
  '("Thibault Polge" . "thibault@thb.lt")
  :keywords
  '("frames")
  :url "https://github.com/thblt/sway.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
