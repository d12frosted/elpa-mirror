;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241024.1122"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f142e55a9fa10b740c7d0f3559b71aa80f74465b"
  :revdesc "f142e55a9fa1"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
