(define-package "weblorg" "20210902.328" "Static Site Generator for org-mode"
  '((templatel "0.1.6")
    (emacs "26.1"))
  :commit "7ccfc443d1d4ded4cde0b6b6e9ebd184601a94d6" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
