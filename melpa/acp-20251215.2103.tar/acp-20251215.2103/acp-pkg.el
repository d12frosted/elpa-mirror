;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20251215.2103"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "18f34bf56dbd3f8c2567d3fa34494f0cf95c5f5f"
  :revdesc "18f34bf56dbd")
