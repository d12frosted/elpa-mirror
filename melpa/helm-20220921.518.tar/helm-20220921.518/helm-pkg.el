(define-package "helm" "20220921.518" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.7")
    (popup "0.5.3"))
  :commit "80b3a39da395bee2db49c88fabcb4fccd1178588" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
