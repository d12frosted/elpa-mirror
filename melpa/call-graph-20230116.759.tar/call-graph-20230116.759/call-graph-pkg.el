(define-package "call-graph" "20230116.759" "Generate call graph for c/c++ functions"
  '((emacs "25.1")
    (hierarchy "0.7.0")
    (tree-mode "1.0.0")
    (ivy "0.10.0"))
  :commit "ea557a4be47e19706d09a9619748288b9e183f0e" :authors
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainer
  '("Huming Chen" . "chenhuming@gmail.com")
  :keywords
  '("programming" "convenience")
  :url "https://github.com/beacoder/call-graph")
;; Local Variables:
;; no-byte-compile: t
;; End:
