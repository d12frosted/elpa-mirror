(define-package "kmacro-x" "20230308.1246" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "1721963b4de5096fcedcb9cff4635a8834c6b6f8" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
