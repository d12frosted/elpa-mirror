;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260405.1811"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "845011c88c1dc0a58334997a0af929057198d84f"
  :revdesc "845011c88c1d"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
