(define-package "tree-sitter" "20210911.1001" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.15.1"))
  :commit "f33be722f30f1d9dfcb1159352dc36fb8b5e3239" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
