;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20250611.321"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "fcee9ce01851e9d127baa78390506c5d183840d6"
  :revdesc "fcee9ce01851"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
