;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moody" "20260101.1838"
  "Tabs and ribbons for the mode line."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/moody"
  :commit "82f65014dcdfc7178464c282b5c9ec5f7016c945"
  :revdesc "82f65014dcdf"
  :keywords '("faces")
  :authors '(("Jonas Bernoulli" . "emacs.moody@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.moody@jonas.bernoulli.dev")))
