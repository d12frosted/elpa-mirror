(define-package "dpkg-dev-el" "20190824.2314" "Emacs modes for debian packaging"
  '((debian-el "37"))
  :commit "aafb047e03c642e6ae4740a7fbc0a789e0ec1291")
;; Local Variables:
;; no-byte-compile: t
;; End:
