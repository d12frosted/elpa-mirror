(define-package "dpkg-dev-el" "20190824.2314" "Emacs modes for debian packaging"
  '((debian-el "37"))
  :commit "b0de196d11a6730c21bb4be308fd8924d4a0eb7c" :authors
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainer
  '("Peter S Galbraith" . "psg@debian.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
