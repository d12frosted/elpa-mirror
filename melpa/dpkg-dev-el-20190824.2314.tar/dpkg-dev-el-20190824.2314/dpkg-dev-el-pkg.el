(define-package "dpkg-dev-el" "20190824.2314" "Emacs modes for debian packaging"
  '((debian-el "37"))
  :commit "458f5230d02b15c94e94eca1af4eabaec30f45db" :authors
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainer
  '("Peter S Galbraith" . "psg@debian.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
