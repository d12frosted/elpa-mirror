;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elixir-yasnippets" "20150417.1239"
  "Yasnippets for Elixir."
  '((yasnippet "0.8.0"))
  :url "https://github.com/hisea/elixir-yasnippets"
  :commit "980ca7626c14ef0573bec0035ec7942796062783"
  :revdesc "980ca7626c14"
  :keywords '("snippets")
  :authors '(("Yinghai Zhao" . "zyinghai@gmail.com"))
  :maintainers '(("Yinghai Zhao" . "zyinghai@gmail.com")))
