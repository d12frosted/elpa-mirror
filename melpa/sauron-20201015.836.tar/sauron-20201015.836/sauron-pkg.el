;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sauron" "20201015.836"
  "Track (erc/org/dbus/...) events and react to them."
  ()
  :url "https://github.com/djcb/sauron"
  :commit "5daade4836da5b1b2ab26d84128d6c38328a5d52"
  :revdesc "5daade4836da"
  :keywords '("comm" "frames")
  :authors '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl"))
  :maintainers '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl")))
