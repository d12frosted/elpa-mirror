(define-package "lsp-ui" "20220619.1215" "UI modules for lsp-mode"
  '((emacs "26.1")
    (dash "2.18.0")
    (lsp-mode "6.0")
    (markdown-mode "2.3"))
  :commit "3632ddd9e4b76da2a547b6be7a5d27c622638b61" :authors
  '(("Sebastien Chapuis <sebastien@chapu.is>, Fangrui Song" . "i@maskray.me"))
  :maintainer
  '("Sebastien Chapuis <sebastien@chapu.is>, Fangrui Song" . "i@maskray.me")
  :keywords
  '("languages" "tools")
  :url "https://github.com/emacs-lsp/lsp-ui")
;; Local Variables:
;; no-byte-compile: t
;; End:
