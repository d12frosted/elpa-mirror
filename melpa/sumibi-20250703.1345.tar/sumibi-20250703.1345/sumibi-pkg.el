;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250703.1345"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (mozc           "0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "0108fca4feaee6fa7b578a55cfbf1961bd9ec8ca"
  :revdesc "0108fca4feae"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
