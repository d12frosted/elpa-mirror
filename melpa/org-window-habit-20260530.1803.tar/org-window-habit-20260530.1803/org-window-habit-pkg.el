;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20260530.1803"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "1b0d483f655851d0c9fd688832140048bcb1763b"
  :revdesc "1b0d483f6558"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
