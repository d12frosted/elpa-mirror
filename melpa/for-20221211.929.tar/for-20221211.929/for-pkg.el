(define-package "for" "20221211.929" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "dadbb79c10fafaf988a523b89ee34f92de36c839" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
