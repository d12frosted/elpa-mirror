;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-io" "20230322.1038"
  "Integration for git.io URL shortening in buffer."
  '((emacs "24.4"))
  :url "https://github.com/tejasbubane/emacs-git-io"
  :commit "fb25f9432e6454edd621a7512ee7abc6220151a5"
  :revdesc "fb25f9432e64"
  :keywords '("convenience" "files")
  :authors '(("Tejas Bubane" . "tejasbubane@gmail.com"))
  :maintainers '(("Tejas Bubane" . "tejasbubane@gmail.com")))
