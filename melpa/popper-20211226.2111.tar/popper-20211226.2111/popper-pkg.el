(define-package "popper" "20211226.2111" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "527a85c49174e6e79220f0ed0761c204a979eae6" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
