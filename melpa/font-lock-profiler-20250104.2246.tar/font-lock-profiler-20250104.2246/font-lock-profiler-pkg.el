;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "font-lock-profiler" "20250104.2246"
  "Coverage and timing tool for font-lock."
  '((emacs "24.3"))
  :url "https://github.com/Lindydancer/font-lock-profiler"
  :commit "6f19fda11de06f5f6c5b3732f056df762d685fcc"
  :revdesc "6f19fda11de0"
  :keywords '("faces" "tools"))
