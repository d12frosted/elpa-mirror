;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbake" "20260620.217"
  "Running bitbake from emacs."
  '((emacs    "24.1")
    (dash     "2.6.0")
    (mmm-mode "0.5.4")
    (s        "1.10.0"))
  :url "https://github.com/canatella/bitbake-el"
  :commit "683f6e9fa1d15447eeef0415b88bd116180463d3"
  :revdesc "683f6e9fa1d1"
  :keywords '("convenience"))
