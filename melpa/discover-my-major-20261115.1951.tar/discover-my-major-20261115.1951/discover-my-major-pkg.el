;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "discover-my-major" "20261115.1951"
  "Discover key bindings and their meaning for the current Emacs major mode."
  '((makey "0.2"))
  :url "https://framagit.org/steckerhalter/discover-my-major"
  :commit "13557c305fe2cde5115b448f33c6950645eaf6e6"
  :revdesc "13557c305fe2"
  :keywords '("discover" "help" "major-mode" "keys"))
