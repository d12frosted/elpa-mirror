;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citre" "20260220.1205"
  "Superior code reading & auto-completion tool with pluggable backends."
  '((emacs "26.1"))
  :url "https://github.com/universal-ctags/citre"
  :commit "8ca71997f45d80241e5a307bfe4a6569a2b72e30"
  :revdesc "8ca71997f45d"
  :keywords '("convenience" "tools")
  :authors '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainers '(("Hao Wang" . "amaikinono@gmail.com")))
