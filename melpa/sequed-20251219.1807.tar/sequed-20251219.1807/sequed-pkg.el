;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sequed" "20251219.1807"
  "Major mode for FASTA format DNA alignments."
  '((emacs "25.2"))
  :url "https://github.com/brannala/sequed"
  :commit "15d890f9cb8d161c3d37dfa79a87c84a27bce6d6"
  :revdesc "15d890f9cb8d"
  :authors '(("Bruce Rannala" . "brannala@ucdavis.edu"))
  :maintainers '(("Bruce Rannala" . "brannala@ucdavis.edu")))
