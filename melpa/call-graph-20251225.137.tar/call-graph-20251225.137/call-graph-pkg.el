;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "call-graph" "20251225.137"
  "Generate call graph for c/c++ functions."
  '((emacs     "28.1")
    (tree-mode "1.0.0")
    (ivy       "0.10.0")
    (beacon    "1.3.4"))
  :url "https://github.com/beacoder/call-graph"
  :commit "2d2f9b9c7a94e05bf3c510f9234e78ea749c1531"
  :revdesc "2d2f9b9c7a94"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
