(define-package "wildcharm-theme" "20230830.213" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "8978899bb3a2b186fa342026a1c83899fa403988" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
