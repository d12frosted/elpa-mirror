;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260301.143"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "86a3ed664a17b3ac271a17b05aa448a7456c144c"
  :revdesc "86a3ed664a17"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
