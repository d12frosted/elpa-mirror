;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mag-menu" "20150505.1850"
  "Intuitive keyboard-centric menu system."
  '((splitter "0.1.0"))
  :url "https://github.com/chumpage/mag-menu"
  :commit "9b9277021cd09fb1dba64b1d2a00705d20914bd6"
  :revdesc "9b9277021cd0"
  :keywords '("convenience"))
