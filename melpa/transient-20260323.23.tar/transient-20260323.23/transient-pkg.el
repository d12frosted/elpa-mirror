;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260323.23"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "30.1")
    (cond-let "0.2")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "733c408d94aac9ca1660d14ff3aedc367abcd8ca"
  :revdesc "733c408d94aa"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
