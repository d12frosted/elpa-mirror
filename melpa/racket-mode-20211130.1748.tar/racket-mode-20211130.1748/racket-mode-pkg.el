(define-package "racket-mode" "20211130.1748" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "ef54a42ddd32f8827eef430f0410e392f9cb1726" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
