;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251103.2157"
  "A single native shell experience to interact with agentic providers (Claude Code, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.82.2")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c27b47b3443c26a8a02d14440417a730ac9f4de6"
  :revdesc "c27b47b3443c")
