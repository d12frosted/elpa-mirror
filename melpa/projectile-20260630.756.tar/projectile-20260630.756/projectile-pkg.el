;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260630.756"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "b1d2a6cf59c2c14ee32bbe0e0a84104dc87a4138"
  :revdesc "b1d2a6cf59c2"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
