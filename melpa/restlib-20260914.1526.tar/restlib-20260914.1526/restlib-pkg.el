;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restlib" "20260914.1526"
  "Utility library for building REST clients."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/restlib"
  :commit "3bde75339f0e6f64698f0d829f13a675ac4042a8"
  :revdesc "3bde75339f0e"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
