(define-package "tree-sitter" "20210829.1421" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.15.1"))
  :commit "588170ffbdbf02175cdb97547f7efd7e933a5a5f" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
