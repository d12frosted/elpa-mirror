(define-package "socyl" "20170212.642" "Frontend for several search tools"
  '((s "1.11.0")
    (dash "2.12.0")
    (pkg-info "0.5.0")
    (cl-lib "0.5"))
  :commit "1ef2da42f66f3ab31a34131e51648f352416f0ba" :keywords
  ("ripgrep" "sift" "ack" "pt" "ag" "grep" "search")
  :authors
  (("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  ("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :url "https://github.com/nlamirault/socyl")
;; Local Variables:
;; no-byte-compile: t
;; End:
