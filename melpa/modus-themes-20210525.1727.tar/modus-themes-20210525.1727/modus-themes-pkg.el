(define-package "modus-themes" "20210525.1727" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "599c703043b93232b6146e4d43ce7e753e0b0efc" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
