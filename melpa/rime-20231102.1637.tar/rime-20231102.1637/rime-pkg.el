(define-package "rime" "20231102.1637" "Rime input method"
  '((emacs "26.3")
    (dash "2.17.0")
    (cl-lib "0.6.1")
    (popup "0.5.3")
    (posframe "0.1.0"))
  :commit "ca02a6b8035aa4dec186a2e9d818e28bc8c55a79" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "input-method")
  :url "https://www.github.com/DogLooksGood/emacs-rime")
;; Local Variables:
;; no-byte-compile: t
;; End:
