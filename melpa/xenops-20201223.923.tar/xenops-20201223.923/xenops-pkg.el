(define-package "xenops" "20201223.923" "A LaTeX editing environment for mathematical documents"
  '((emacs "26.1")
    (aio "1.0")
    (auctex "12.2.0")
    (avy "0.5.0")
    (dash "2.17.0")
    (dash-functional "1.2.0")
    (f "0.20.0")
    (s "1.12.0"))
  :commit "d34644d20a81b8de6a2ffe3d15c5396f8da7e4f0" :authors
  (("Dan Davison" . "dandavison7@gmail.com"))
  :maintainer
  ("Dan Davison" . "dandavison7@gmail.com")
  :url "https://github.com/dandavison/xenops")
;; Local Variables:
;; no-byte-compile: t
;; End:
