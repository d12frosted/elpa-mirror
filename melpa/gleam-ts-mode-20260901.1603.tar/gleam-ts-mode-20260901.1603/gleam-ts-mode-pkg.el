;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gleam-ts-mode" "20260901.1603"
  "Major mode for Gleam."
  '((emacs "29.1"))
  :url "https://github.com/gleam-lang/gleam-mode"
  :commit "b326f9df2f92328d4a3322d186ec389216783011"
  :revdesc "b326f9df2f92"
  :keywords '("languages" "gleam")
  :authors '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com")))
