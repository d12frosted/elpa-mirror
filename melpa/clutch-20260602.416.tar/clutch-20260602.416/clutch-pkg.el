;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260602.416"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "722fca6c8694a3bb048525e7694d30983d794ede"
  :revdesc "722fca6c8694"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
