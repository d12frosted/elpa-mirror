;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260315.2341"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "540d5a842035b924b3a08d309a08aa2b6dc613ab"
  :revdesc "540d5a842035")
