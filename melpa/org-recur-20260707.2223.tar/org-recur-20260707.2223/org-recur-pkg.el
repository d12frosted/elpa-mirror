;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-recur" "20260707.2223"
  "Recurring org-mode tasks."
  '((emacs "24.1")
    (org   "9.0")
    (dash  "2.7.0"))
  :url "https://github.com/mrcnski/org-recur"
  :commit "680731635038bf453dc75242bf007e886be8c765"
  :revdesc "680731635038"
  :authors '(("Marcin Swieczkowski" . "marcin.swieczkowski@gmail.com"))
  :maintainers '(("Marcin Swieczkowski" . "marcin.swieczkowski@gmail.com")))
