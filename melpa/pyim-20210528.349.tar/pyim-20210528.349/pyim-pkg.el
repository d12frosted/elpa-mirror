(define-package "pyim" "20210528.349" "A Chinese input method support quanpin, shuangpin, wubi and cangjie."
  '((emacs "24.4")
    (async "1.6")
    (xr "1.13"))
  :commit "8d08ed7174e1b46ee2413c515e96a955fc3f88d3" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
