(define-package "for" "20220925.1743" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "c0c35056d981b32c97488fe441cf27cfe5faaaeb" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
