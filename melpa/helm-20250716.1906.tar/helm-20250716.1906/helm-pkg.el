;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250716.1906"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "d33a88ca5e59886bb16c9b3e5a1be5b4d06419f3"
  :revdesc "d33a88ca5e59"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
