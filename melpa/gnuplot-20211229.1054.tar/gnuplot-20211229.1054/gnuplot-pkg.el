(define-package "gnuplot" "20211229.1054" "Major-mode and interactive frontend for gnuplot"
  '((emacs "24.3"))
  :commit "cc547ce0c86309c59d3aeaecbb202d9dd7144d91" :authors
  '(("Jon Oddie")
    ("Bruce Ravel")
    ("Phil Type"))
  :maintainer
  '("Bruce Ravel" . "bruceravel1@gmail.com")
  :keywords
  '("data" "gnuplot" "plotting")
  :url "https://github.com/emacsorphanage/gnuplot")
;; Local Variables:
;; no-byte-compile: t
;; End:
