;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260504.307"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "0392d1044a64792a3a72259c59ae82caa74fe0a5"
  :revdesc "0392d1044a64"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
