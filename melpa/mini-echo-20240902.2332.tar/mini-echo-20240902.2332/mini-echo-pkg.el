(define-package "mini-echo" "20240902.2332" "Echo buffer status in minibuffer window"
  '((emacs "29.1")
    (dash "2.19.1")
    (hide-mode-line "1.0.3"))
  :commit "db876b16c0c8b83e87ae86ef0fb89aabde636d14" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
