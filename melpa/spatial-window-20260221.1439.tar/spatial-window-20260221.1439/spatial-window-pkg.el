;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-window" "20260221.1439"
  "Jump to windows using keyboard spatial mapping."
  '((emacs    "28.1")
    (posframe "1.0.0"))
  :url "https://github.com/lewang/spatial-window"
  :commit "2a6a4cec766a3ebcd41ab637c3eb9946e80b22b2"
  :revdesc "2a6a4cec766a"
  :keywords '("convenience" "windows")
  :authors '(("Le Wang" . "lewang.dev.26@gmail.com"))
  :maintainers '(("Le Wang" . "lewang.dev.26@gmail.com")))
