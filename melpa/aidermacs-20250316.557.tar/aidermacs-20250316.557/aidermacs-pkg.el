;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250316.557"
  "AI pair programming with Aider."
  '((emacs "29.1"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "764a99dd5ee301621645a5969b6ca43c2823950d"
  :revdesc "764a99dd5ee3"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
