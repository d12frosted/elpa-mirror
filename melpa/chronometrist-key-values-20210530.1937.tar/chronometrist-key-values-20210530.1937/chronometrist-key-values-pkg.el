(define-package "chronometrist-key-values" "20210530.1937" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "bb2973405f757864f15fbcaa4c19ac2ff096caba" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
