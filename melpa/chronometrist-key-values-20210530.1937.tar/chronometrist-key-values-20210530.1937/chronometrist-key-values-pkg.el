(define-package "chronometrist-key-values" "20210530.1937" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "bdae4e024500ea4a3f3bbaf284dcb251c5ad340d" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
