(define-package "chronometrist-key-values" "20210530.1937" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "e9164ecca1e2f43676e5a071aca7644177866deb" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
