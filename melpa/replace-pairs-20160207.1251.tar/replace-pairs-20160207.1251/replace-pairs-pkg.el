;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "replace-pairs" "20160207.1251"
  "Query-replace pairs of things."
  '((emacs "24.4"))
  :url "https://github.com/davidshepherd7/replace-pairs"
  :commit "ef6f2719aab7714f6cb209fd3dd6d2e720681b3c"
  :revdesc "ef6f2719aab7"
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
