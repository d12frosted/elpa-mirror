;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260714.648"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b2e47ff06255235cbdc303e3abb95a887a418a0c"
  :revdesc "b2e47ff06255"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
