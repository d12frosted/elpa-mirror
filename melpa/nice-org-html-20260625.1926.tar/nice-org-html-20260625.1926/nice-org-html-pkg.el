;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nice-org-html" "20260625.1926"
  "Prettier org-to-html export."
  '((emacs   "25.1")
    (s       "1.13.0")
    (dash    "2.19.1")
    (htmlize "1.58")
    (uuidgen "1.0"))
  :url "https://github.com/ewantown/nice-org-html"
  :commit "16c9efdd92a12c78a55364f3d5e8e310585aa012"
  :revdesc "16c9efdd92a1"
  :keywords '("org" "org-export" "html" "css" "js" "tools")
  :authors '(("Ewan Townshend" . "ewan@etown.dev"))
  :maintainers '(("Ewan Townshend" . "ewan@etown.dev")))
