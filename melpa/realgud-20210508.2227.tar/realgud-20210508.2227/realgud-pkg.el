(define-package "realgud" "20210508.2227" "A modular front-end for interacting with external debuggers"
  '((load-relative "1.3.1")
    (loc-changes "1.2")
    (test-simple "1.3.0")
    (emacs "25"))
  :commit "34557f8d8fc6af8d3763380942cc07193335c73b" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :keywords
  '("debugger" "gdb" "python" "perl" "go" "bash" "zsh" "bashdb" "zshdb" "remake" "trepan" "perldb" "pdb")
  :url "https://github.com/realgud/realgud/")
;; Local Variables:
;; no-byte-compile: t
;; End:
