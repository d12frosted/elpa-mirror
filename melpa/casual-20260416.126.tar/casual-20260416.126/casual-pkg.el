;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260416.126"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "6a3fbb40d3369614f36d9a37035942fa57572c5b"
  :revdesc "6a3fbb40d336"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
