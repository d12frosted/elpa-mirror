;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260422.507"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "9958ec4c4396ae8435f7e1818ff383c05df47a14"
  :revdesc "9958ec4c4396"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
