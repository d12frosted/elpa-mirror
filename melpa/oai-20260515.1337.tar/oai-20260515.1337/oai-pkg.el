;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260515.1337"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "ac974f4788fbce245f05bdae65df7811c9e64365"
  :revdesc "ac974f4788fb"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
