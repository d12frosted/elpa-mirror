;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250305.1639"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e62f7d99d6af84f94a5ee8bb3859c3cc5122cdf8"
  :revdesc "e62f7d99d6af"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
