;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rocq-timing" "20260417.1401"
  "Display timing of rocq commands in buffer."
  '((emacs "24"))
  :url "https://github.com/Chobbes/rocq-timing-el"
  :commit "5423ac37dc6a6abff74e59ac299b57746462bd02"
  :revdesc "5423ac37dc6a"
  :keywords '("convenience" "tools" "rocq" "coq" "proofs" "profiling")
  :authors '(("Calvin Beck" . "hobbes@ualberta.ca"))
  :maintainers '(("Calvin Beck" . "hobbes@ualberta.ca")))
