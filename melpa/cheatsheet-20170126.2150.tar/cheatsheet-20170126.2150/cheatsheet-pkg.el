;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cheatsheet" "20170126.2150"
  "Create your own cheatsheet."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/darksmile/cheatsheet/"
  :commit "e4f8e0110167ea16a17a74517d1f10cb7ff805b8"
  :revdesc "e4f8e0110167"
  :keywords '("convenience" "usability")
  :authors '(("Shirin Nikita and contributors" . "shirin.nikita@gmail.com"))
  :maintainers '(("Shirin Nikita and contributors" . "shirin.nikita@gmail.com")))
