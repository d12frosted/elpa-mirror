;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "20260210.2300"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "9c1dac3c39fcdbecbb9e963898cb353ec8ba6cc3"
  :revdesc "9c1dac3c39fc"
  :keywords '("languages" "tools"))
