(define-package "helm-apt" "20230926.1818" "Helm interface for Debian/Ubuntu packages (apt-*)"
  '((helm "3.6")
    (emacs "25.1"))
  :commit "a3629302b6878c8919f89d6d5913d37d9012a992" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://github.com/emacs-helm/helm-apt")
;; Local Variables:
;; no-byte-compile: t
;; End:
