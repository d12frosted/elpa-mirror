(define-package "mistty" "20231105.2142" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "ce25f80f2779ca472b3d53e931e309f50d8b1c13" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
