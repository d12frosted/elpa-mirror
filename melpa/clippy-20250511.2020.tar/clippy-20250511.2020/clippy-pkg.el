;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clippy" "20250511.2020"
  "Show tooltip with function documentation at point."
  '((pos-tip "1.0"))
  :url "https://github.com/Fuco1/clippy.el"
  :commit "006e0bbe3f695c0e0ebdc0de5095255608eb9e6c"
  :revdesc "006e0bbe3f69"
  :keywords '("docs")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
