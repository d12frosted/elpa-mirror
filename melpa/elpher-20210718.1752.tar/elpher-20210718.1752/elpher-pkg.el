(define-package "elpher" "20210718.1752" "A friendly gopher and gemini client"
  '((emacs "26.2"))
  :commit "b0272de36cea3e1cd41cd15a012c8141b4b04575" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "http://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
