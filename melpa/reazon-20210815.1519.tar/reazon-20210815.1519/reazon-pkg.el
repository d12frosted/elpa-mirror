(define-package "reazon" "20210815.1519" "miniKanren for Emacs"
  '((emacs "26"))
  :commit "1bfce512612eb679d06356b5c070e6f8743fd0dc" :authors
  '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainer
  '("Nick Drozd" . "nicholasdrozd@gmail.com")
  :keywords
  '("languages" "extensions" "lisp")
  :url "https://github.com/nickdrozd/reazon")
;; Local Variables:
;; no-byte-compile: t
;; End:
