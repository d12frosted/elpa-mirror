(define-package "tree-sitter" "20201229.1403" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.13.0"))
  :commit "e7f2f625c1b9a2dce4f6b16a5affbb4f57337ae0" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
