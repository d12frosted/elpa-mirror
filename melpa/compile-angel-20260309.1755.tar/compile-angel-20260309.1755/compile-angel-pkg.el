;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260309.1755"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "3f2a305ba40443edd8fd36b71a05727cd7558655"
  :revdesc "3f2a305ba404"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
