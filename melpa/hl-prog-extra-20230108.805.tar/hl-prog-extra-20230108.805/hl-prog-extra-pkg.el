(define-package "hl-prog-extra" "20230108.805" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "86a9304f0d4ca3dccfd50731e5f2ae00aeb811ac" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
