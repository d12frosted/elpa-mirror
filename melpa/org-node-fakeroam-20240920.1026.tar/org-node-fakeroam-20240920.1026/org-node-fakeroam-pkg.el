(define-package "org-node-fakeroam" "20240920.1026" "Stand-ins for org-roam-autosync-mode"
  '((emacs "28.1")
    (compat "30")
    (org-node "0")
    (org-roam "2.2.2")
    (emacsql "4.0.3")
    (persist "0.6.1"))
  :commit "a825b6757a3e2112db041f9a06b4c3c4140a4b79" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node-fakeroam")
;; Local Variables:
;; no-byte-compile: t
;; End:
