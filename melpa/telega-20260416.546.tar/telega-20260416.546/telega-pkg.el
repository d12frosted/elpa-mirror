;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260416.546"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "5196e752b1dae4367d446a3fcc6169e6a7533093"
  :revdesc "5196e752b1da"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
