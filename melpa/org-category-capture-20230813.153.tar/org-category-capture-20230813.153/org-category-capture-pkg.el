(define-package "org-category-capture" "20230813.153" "Contextualy capture of org-mode TODOs."
  '((org "9.0.0")
    (emacs "24"))
  :commit "5b484e95004f799f8f605a77550f18b00791e000" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "todo" "tools" "outlines")
  :url "https://github.com/IvanMalison/org-projectile")
;; Local Variables:
;; no-byte-compile: t
;; End:
