(define-package "alarm-clock" "20221031.430" "Alarm Clock"
  '((emacs "24.4"))
  :commit "54a5557c05c63053fe31072905ba80d8231ce2f3" :authors
  '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainer
  '("Steve Lemuel" . "wlemuel@hotmail.com")
  :keywords
  '("calendar" "tools" "convenience")
  :url "https://github.com/wlemuel/alarm-clock")
;; Local Variables:
;; no-byte-compile: t
;; End:
