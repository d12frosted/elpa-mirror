;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260609.2159"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "0f06f00d5048928ba0f4bb4d86f5dd7d0fb32d85"
  :revdesc "0f06f00d5048"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
