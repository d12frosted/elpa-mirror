;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prisma-ts-mode" "20251024.1356"
  "Major mode for prisma using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/prisma-ts-mode"
  :commit "c63117764dc9e177aea7ddbef23c47feba1523d8"
  :revdesc "c63117764dc9"
  :keywords '("prisma" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
