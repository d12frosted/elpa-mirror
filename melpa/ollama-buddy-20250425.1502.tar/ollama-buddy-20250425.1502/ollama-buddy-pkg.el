;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250425.1502"
  "Ollama LLM AI Assistant with ChatGPT, Claude, Gemini and Grok Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "51d52d1ef04a57058e903b3e99e74901100369ef"
  :revdesc "51d52d1ef04a"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
