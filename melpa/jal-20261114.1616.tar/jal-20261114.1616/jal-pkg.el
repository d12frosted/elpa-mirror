;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jal" "20261114.1616"
  "Java Agent Loader (JAL) for JDTLS."
  '((emacs "28.1"))
  :url "https://github.com/saulotoledo/java-agent-loader"
  :commit "0b02842aa4013ff9ab0481781a94cc14d77247f8"
  :revdesc "0b02842aa401"
  :keywords '("java" "languages" "tools")
  :authors '(("Saulo Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo Toledo" . "saulotoledo@gmail.com")))
