;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghc-imported-from" "20141124.1932"
  "Haskell documentation lookup with ghc-imported-from."
  '((emacs "24.1"))
  :url "https://github.com/david-christiansen/ghc-imported-from-el"
  :commit "fcff08628a19f5d26151564659218cc677779b79"
  :revdesc "fcff08628a19"
  :keywords '("languages")
  :authors '(("David Raymond Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Raymond Christiansen" . "david@davidchristiansen.dk")))
