;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260727.953"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.42.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "cba5fa4c0d1913eef77bcea5bab2555536adf53f"
  :revdesc "cba5fa4c0d19"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
