(define-package "modus-themes" "20211012.800" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "eed2192d002b83aef260a0e8eabdb3607f1ac0cf" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
