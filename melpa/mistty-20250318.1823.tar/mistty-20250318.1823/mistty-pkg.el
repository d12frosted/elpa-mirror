;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250318.1823"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "a211330af7cff2759667518eaceceb9aec19bcdb"
  :revdesc "a211330af7cf"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
