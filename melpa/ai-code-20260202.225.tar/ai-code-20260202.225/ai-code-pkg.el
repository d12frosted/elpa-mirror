;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260202.225"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "c8bced5cc0bca5529e39f9ada95f7784bce0228e"
  :revdesc "c8bced5cc0bc"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
