(define-package "autocrypt" "20210707.1155" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "8cc4b86db387882955acbee247870e69ef79878d" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "philipk@posteo.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
