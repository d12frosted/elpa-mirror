(define-package "srfi" "20210212.2231" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "537b4c350e562660aa406b99660f80275254714e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
