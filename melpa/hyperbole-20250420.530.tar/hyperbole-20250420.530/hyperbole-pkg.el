;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250420.530"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "42dcd71f59ee199182a66c4429825120772e3b78"
  :revdesc "42dcd71f59ee"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
