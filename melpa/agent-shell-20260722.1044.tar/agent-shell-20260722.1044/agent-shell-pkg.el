;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260722.1044"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "125523d98aa26f07317cb5742caf29238cbf8f6d"
  :revdesc "125523d98aa2")
