;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260708.53"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "8fcd67a3ef22d9d0354027f9c58dc09274244005"
  :revdesc "8fcd67a3ef22"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
