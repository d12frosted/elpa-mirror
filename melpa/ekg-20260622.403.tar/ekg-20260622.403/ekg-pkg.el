;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260622.403"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "76ec310ae4684d785ba09caa4c8583089b44b435"
  :revdesc "76ec310ae468"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
