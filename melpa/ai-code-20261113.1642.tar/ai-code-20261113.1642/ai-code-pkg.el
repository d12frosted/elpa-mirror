;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261113.1642"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5ce5b87001e028058b3a3e46e9cd98543b8e2ac3"
  :revdesc "5ce5b87001e0"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
