;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260904.1327"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "1c99eece72a3f57a1be7187a07f70073b43e1589"
  :revdesc "1c99eece72a3"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
