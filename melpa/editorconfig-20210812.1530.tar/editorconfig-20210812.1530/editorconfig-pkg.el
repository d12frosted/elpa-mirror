(define-package "editorconfig" "20210812.1530" "EditorConfig Emacs Plugin"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (emacs "24"))
  :commit "98204d02e85157f66a5145bc12a938216db7d9bd" :authors
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainer
  '("EditorConfig Team" . "editorconfig@googlegroups.com")
  :url "https://github.com/editorconfig/editorconfig-emacs#readme")
;; Local Variables:
;; no-byte-compile: t
;; End:
