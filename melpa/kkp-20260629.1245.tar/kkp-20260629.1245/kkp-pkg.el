;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "20260629.1245"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "57e1b98e3b7dce428c128cb4f1654ca99bf787d1"
  :revdesc "57e1b98e3b7d"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
