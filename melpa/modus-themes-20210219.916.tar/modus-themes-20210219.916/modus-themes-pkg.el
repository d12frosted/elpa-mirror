(define-package "modus-themes" "20210219.916" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "1eb3f54d7195ee0a8d7633c529e9fca60693d99c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
