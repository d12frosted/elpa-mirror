(define-package "elisp-autofmt" "20230210.521" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "10e3a79a7a058e4956236b98852712b8b7b33e04" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
