;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260304.709"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "2a201016ff954304679ac1f1c81ea7bd78f507ae"
  :revdesc "2a201016ff95"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
