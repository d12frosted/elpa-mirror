(define-package "go-translate" "20240530.342" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "6b0f1f64d78dfda65e4d64e4dc4f9df3a220bb70" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
