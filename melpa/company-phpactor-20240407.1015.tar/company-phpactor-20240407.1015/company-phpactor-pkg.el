;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-phpactor" "20240407.1015"
  "A company-mode backend for Phpactor."
  '((emacs    "24.3")
    (company  "0.9.6")
    (phpactor "0.1.0"))
  :url "https://github.com/emacs-php/phpactor.el"
  :commit "e488ed4c46489861c15d83a43e70eb7c352adc09"
  :revdesc "e488ed4c4648"
  :keywords '("tools" "php")
  :authors '(("Martin Tang" . "martin.tang365@gmail.com")
             ("Mikael Kermorgant" . "mikael@kgtech.fi"))
  :maintainers '(("Martin Tang" . "martin.tang365@gmail.com")
                 ("Mikael Kermorgant" . "mikael@kgtech.fi")))
