;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-modeline" "20140115.1015"
  "Displays ert test results in the modeline."
  '((s          "1.3.1")
    (dash       "1.2.0")
    (emacs      "24.1")
    (projectile "0.9.1"))
  :url "https://github.com/chrisbarrett/ert-modeline"
  :commit "7c6340834387f749519616f9601821cb73fd657b"
  :revdesc "7c6340834387"
  :keywords '("tools" "tests" "convenience")
  :authors '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainers '(("Chris Barrett" . "chris.d.barrett@me.com")))
