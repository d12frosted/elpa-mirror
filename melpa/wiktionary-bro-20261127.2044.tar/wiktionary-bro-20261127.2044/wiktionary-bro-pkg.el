;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiktionary-bro" "20261127.2044"
  "Lookup Wiktionary entries."
  '((emacs   "29.4")
    (request "0.3.3"))
  :url "https://github.com/agzam/wiktionary-bro.el"
  :commit "b66483d71a85f45088ec91fdbd432ebe53e70b3a"
  :revdesc "b66483d71a85"
  :keywords '("convenience" "multimedia")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
