;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260228.535"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "5ed2c601f770cb2fee928f74982458faf706b72f"
  :revdesc "5ed2c601f770"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
