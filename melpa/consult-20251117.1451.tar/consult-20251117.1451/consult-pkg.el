;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20251117.1451"
  "Consulting completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "c2caf93d597ea57db86c0cbf7ff50114a57d74f6"
  :revdesc "c2caf93d597e"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
