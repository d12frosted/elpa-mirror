;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260212.1150"
  "Highlight by brightness of text and background."
  '((emacs "29.4"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "7936b00a5822d16e21736feeda332e64ebb35ae2"
  :revdesc "7936b00a5822"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
