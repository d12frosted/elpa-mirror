;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241110.1431"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "38af7f1d233d84c6513aa8946a5a86c99c4e0865"
  :revdesc "38af7f1d233d"
  :keywords '("convenience" "modal-editing"))
