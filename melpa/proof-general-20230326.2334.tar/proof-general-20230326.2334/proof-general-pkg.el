(define-package "proof-general" "20230326.2334" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "78a555a12dd40348fb098331a20aa6fd663c152d" :maintainer
  '(nil . "proof-general-maintainers@groupes.renater.fr")
  :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
