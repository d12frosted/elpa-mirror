(define-package "dirvish" "20220528.1135" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "7196bec83cd6c48dc76afbcd3ab269307be7ec2f" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
