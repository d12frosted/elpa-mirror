(define-package "geiser" "20211121.1801" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "122564229f068b13493db75b4521017e242f007c" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
