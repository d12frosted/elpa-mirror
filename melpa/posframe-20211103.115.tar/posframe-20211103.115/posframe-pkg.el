(define-package "posframe" "20211103.115" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "efef61d8cb0ce133dc133df6856db977abbba215" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
