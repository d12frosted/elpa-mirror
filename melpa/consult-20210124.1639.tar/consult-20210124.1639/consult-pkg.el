(define-package "consult" "20210124.1639" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "6061a858c9d4c55688afc3b1eba986b95ef2b711" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
