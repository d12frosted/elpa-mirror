(define-package "spdx" "20221209.116" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d7ea306ad91e2fb767b2c48d5ce96675bc76bc6f" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
