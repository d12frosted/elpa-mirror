;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keyword-search" "20180424.1102"
  "Browser keyword search from Emacs."
  ()
  :url "https://github.com/juhp/keyword-search"
  :commit "f8475ecaddb8804a9be6bee47678207c86ac8dee"
  :revdesc "f8475ecaddb8"
  :keywords '("web" "search" "keyword"))
