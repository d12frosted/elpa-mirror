(define-package "proof-general" "20220329.655" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "e1e29acb04f0707fb2b323727d08f0fe85fc0c02" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
