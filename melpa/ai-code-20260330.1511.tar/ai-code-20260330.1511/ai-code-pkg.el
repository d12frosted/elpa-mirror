;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260330.1511"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "1888ee36b58da112bcbace3915cb92a7092811bd"
  :revdesc "1888ee36b58d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
