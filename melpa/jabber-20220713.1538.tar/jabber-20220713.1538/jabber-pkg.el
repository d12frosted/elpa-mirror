(define-package "jabber" "20220713.1538" "A Jabber client for Emacs."
  '((fsm "0.2")
    (srv "0.2"))
  :commit "af0315e174fa6446d5c4dd3e6465d48912950e58" :authors
  '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainer
  '("wgreenhouse" . "wgreenhouse@tilde.club")
  :keywords
  '("comm")
  :url "https://codeberg.org/emacs-jabber/emacs-jabber")
;; Local Variables:
;; no-byte-compile: t
;; End:
