;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tmmofl" "20121025.1101"
  "Calls functions dependant on font lock highlighting at point."
  ()
  :url "https://github.com/phillord/tmmofl"
  :commit "532aa6978e994e2b069ffe37aaf9a0011a07dadc"
  :revdesc "532aa6978e99"
  :keywords '("minor mode" "font lock" "toggling.")
  :authors '(("Phillip Lord" . "p.lord@hgmp.mrc.ac.uk"))
  :maintainers '(("Phillip Lord" . "p.lord@hgmp.mrc.ac.uk")))
