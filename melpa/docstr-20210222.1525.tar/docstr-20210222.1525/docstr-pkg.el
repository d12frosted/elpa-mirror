(define-package "docstr" "20210222.1525" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "6103a63385f5dfa828a3e759f3668f6be630cd54" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
