(define-package "docstr" "20210222.1525" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "63b0460a4785b4b4aee5cc072b52fb2d3a7eef6e" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
