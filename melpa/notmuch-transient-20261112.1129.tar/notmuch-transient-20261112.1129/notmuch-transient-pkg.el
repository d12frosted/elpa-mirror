;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-transient" "20261112.1129"
  "Command dispatchers for Notmuch."
  '((emacs     "30.1")
    (compat    "31.1")
    (notmuch   "0.39")
    (transient "0.13"))
  :url "https://github.com/tarsius/notmuch-transient"
  :commit "45c764a4c9f70104d062746268253cc42100583b"
  :revdesc "45c764a4c9f7"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev")))
