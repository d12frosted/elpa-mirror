;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20261118.1339"
  "Nucleo-backed completion style."
  '((emacs "29.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "5ff75c04894da8b24aa7b7ff982290cd7b9c0dd0"
  :revdesc "5ff75c04894d"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
