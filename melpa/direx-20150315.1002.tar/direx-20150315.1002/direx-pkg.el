(define-package "direx" "20150315.1002" "Simple Directory Explorer" 'nil :commit "423caeed13249e37afc937dc8134cb3c53e0f111" :authors
  '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainer
  '("Tomohiro Matsuyama" . "m2ym.pub@gmail.com")
  :keywords
  '("convenience"))
;; Local Variables:
;; no-byte-compile: t
;; End:
