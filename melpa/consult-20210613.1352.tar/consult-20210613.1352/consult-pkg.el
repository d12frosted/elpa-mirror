(define-package "consult" "20210613.1352" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9e34c679a2bc39cd167a7226568dfac5b2193292" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
