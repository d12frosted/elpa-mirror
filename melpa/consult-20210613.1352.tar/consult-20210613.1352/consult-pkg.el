(define-package "consult" "20210613.1352" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "bf532c96b2798fba739b2d3b38749707b1c6bd1a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
