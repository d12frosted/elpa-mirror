;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime-repl-ansi-color" "20230214.1453"
  "Turn on ANSI colors in REPL output;."
  '((emacs "24")
    (slime "2.3.1"))
  :url "https://gitlab.com/augfab/slime-repl-ansi-color"
  :commit "9e8af90490332217e45d7568f1690df3f4e25d4b"
  :revdesc "9e8af9049033"
  :keywords '("lisp")
  :authors '(("Max Mikhanosha" . "max@openchat.com"))
  :maintainers '(("Augustin Fabre" . "augustin@augfab.fr")))
