;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260424.1809"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "a4aeba5b92a343a2e3709ee8b67b4120f587b7cb"
  :revdesc "a4aeba5b92a3"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
