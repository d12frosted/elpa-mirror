(define-package "moom" "20210308.1721" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "8e0fbcbe0c190cd98925d9cb5d5cad606c983a1c" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
