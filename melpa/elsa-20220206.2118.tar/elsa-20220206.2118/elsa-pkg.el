(define-package "elsa" "20220206.2118" "Emacs Lisp Static Analyser"
  '((trinary "1.0.0")
    (emacs "25.1")
    (seq "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3"))
  :commit "ce2fc8cdf67e74ee2df6f79fd6f7358e6e34a461" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
