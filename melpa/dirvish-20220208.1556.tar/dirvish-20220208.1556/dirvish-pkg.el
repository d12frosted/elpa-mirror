(define-package "dirvish" "20220208.1556" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "76843b7af0c09126862602fa430ad7d6363e2647" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
