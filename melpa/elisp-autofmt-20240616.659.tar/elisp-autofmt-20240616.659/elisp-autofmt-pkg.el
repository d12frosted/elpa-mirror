(define-package "elisp-autofmt" "20240616.659" "Emacs lisp auto-format"
  '((emacs "29.1"))
  :commit "1682d1a3887e3aa6757a489af3a64e45a1fd7e5d" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
