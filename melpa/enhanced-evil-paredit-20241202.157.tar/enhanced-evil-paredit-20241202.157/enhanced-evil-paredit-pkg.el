;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20241202.157"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "118c0511fa80f2e09a796e68561f45eddc1eab11"
  :revdesc "118c0511fa80"
  :keywords '("convenience"))
