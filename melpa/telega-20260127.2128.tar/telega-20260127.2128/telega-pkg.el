;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260127.2128"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "303e4759e4b6d504b0ba2fe1c43f2b7d63bc98bc"
  :revdesc "303e4759e4b6"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
