(define-package "memento-mori" "20231215.1528" "Reminder of mortality"
  '((emacs "24.3"))
  :commit "9e9c13e7a1b90418de13bbf22e22b5318a027dc9" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("help")
  :url "https://github.com/lassik/emacs-memento-mori")
;; Local Variables:
;; no-byte-compile: t
;; End:
