(define-package "consult" "20210109.2219" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "c607afa65ae203a8904e7d18ddfbbccc53c1c680" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
