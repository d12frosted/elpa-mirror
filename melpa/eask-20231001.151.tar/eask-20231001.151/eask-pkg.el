(define-package "eask" "20231001.151" "Core Eask APIs, for Eask CLI development"
  '((emacs "26.1")
    (dash "2.14.1"))
  :commit "749591e8e8120cd3081125ba0d4022d1db42f0dc" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("lisp" "eask" "api")
  :url "https://github.com/emacs-eask/eask")
;; Local Variables:
;; no-byte-compile: t
;; End:
