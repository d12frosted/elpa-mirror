;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pr-review" "20260323.1418"
  "Review github PR."
  '((emacs         "27.1")
    (magit-section "4.0")
    (magit         "4.0")
    (markdown-mode "2.5")
    (ghub          "5.0"))
  :url "https://github.com/blahgeek/emacs-pr-review"
  :commit "1bb67e6a10869ccef75812f421d35b0366d95cf5"
  :revdesc "1bb67e6a1086"
  :keywords '("tools")
  :authors '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainers '(("Yikai Zhao" . "yikai@z1k.dev")))
