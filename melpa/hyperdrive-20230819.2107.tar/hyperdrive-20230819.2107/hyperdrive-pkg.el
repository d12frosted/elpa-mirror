(define-package "hyperdrive" "20230819.2107" "P2P filesystem"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5"))
  :commit "bca3d260cb71ee7a770b2cbff2f1b6d8f816071d" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
