;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20261028.1752"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "bc44f68e52f30a856ba3cdc984eb82d2bbba2a6a"
  :revdesc "bc44f68e52f3"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
