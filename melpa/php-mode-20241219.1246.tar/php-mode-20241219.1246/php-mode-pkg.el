;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20241219.1246"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "c77eb101e2c6cf324789341cf05e744eca22068e"
  :revdesc "c77eb101e2c6"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
