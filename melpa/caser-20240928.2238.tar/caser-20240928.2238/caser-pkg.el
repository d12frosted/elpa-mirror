;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "caser" "20240928.2238"
  "Change text casing from camelCase to dash-case to snake_case."
  '((emacs "29.1"))
  :url "https://hg.sr.ht/~zck/caser.el"
  :commit "9b0cccef3afe3494d03011b0e0a56ff818f9150c"
  :revdesc "9b0cccef3afe3494d03011b0e0a56ff818f9150c")
