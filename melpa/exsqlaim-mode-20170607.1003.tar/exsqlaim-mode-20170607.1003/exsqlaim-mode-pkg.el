;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exsqlaim-mode" "20170607.1003"
  "Use variables inside sql queries."
  '((s "1.10.0"))
  :url "https://github.com/ahmadnazir/exsqlaim-mode"
  :commit "a2e0a62ec8b87193d8eaa695774bfd689324b06c"
  :revdesc "a2e0a62ec8b8"
  :authors '(("Ahmad Nazir Raja" . "ahmadnazir@gmail.com"))
  :maintainers '(("Ahmad Nazir Raja" . "ahmadnazir@gmail.com")))
