(define-package "dime" "20210329.604" "Dylan interaction mode"
  '((emacs "25.1")
    (dylan "3.0"))
  :commit "9d2891e3e06405b75072d296f385fa795aeb9835" :url "https://opendylan.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
