(define-package "dime" "20210329.604" "Dylan interaction mode"
  '((emacs "25.1")
    (dylan "3.0"))
  :commit "d85409dc3cba57a390ca85da95822f8078ecbfa2" :url "https://opendylan.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
