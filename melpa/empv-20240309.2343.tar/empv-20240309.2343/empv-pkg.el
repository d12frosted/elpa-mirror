(define-package "empv" "20240309.2343" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0")
    (compat "29.1.4.4"))
  :commit "688c94d90a35cbef54218304597bb212df83a4db" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
