(define-package "gnosis" "20240218.1437" "Spaced Repetition System For Note Taking & Self Testing"
  '((emacs "27.2")
    (compat "29.1.4.2")
    (emacsql "20240124"))
  :commit "51d5b4661e59b6ac291aa887391689372a7e4843" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions")
  :url "https://thanosapollo.org/projects/gnosis")
;; Local Variables:
;; no-byte-compile: t
;; End:
