;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250307.1053"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "77b15ee18ed2eb4d3454bb9c779b75a296c42911"
  :revdesc "77b15ee18ed2"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
