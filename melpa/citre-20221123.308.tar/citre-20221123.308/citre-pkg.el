(define-package "citre" "20221123.308" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "bf0ff61e143f6002cb223a0c8dfb1439e256b1a1" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
