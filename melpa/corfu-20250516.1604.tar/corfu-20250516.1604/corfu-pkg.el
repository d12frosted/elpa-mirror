;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250516.1604"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "52b6c0ec4903a87f905ec8ee547a77f28196502d"
  :revdesc "52b6c0ec4903"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
