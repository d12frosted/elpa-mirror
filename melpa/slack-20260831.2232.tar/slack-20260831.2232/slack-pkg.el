;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "20260831.2232"
  "Slack client."
  '((websocket "1.12")
    (request   "0.3.2")
    (circe     "2.11")
    (alert     "1.2")
    (emojify   "1.2.0")
    (emacs     "25.1")
    (dash      "2.19.1")
    (s         "1.13.0")
    (ts        "0.3"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "1543c19369466755c5057c0b5669ad27f7b07749"
  :revdesc "1543c1936946"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
