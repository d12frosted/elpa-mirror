;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "20250313.1620"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "6dfd2961471fde6892537fac43df8d2748b873b3"
  :revdesc "6dfd2961471f"
  :keywords '("languages" "tools"))
