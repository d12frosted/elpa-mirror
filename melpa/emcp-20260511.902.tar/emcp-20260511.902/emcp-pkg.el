;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260511.902"
  "Lets your agent talk to Emacs."
  '((emacs       "30.1")
    (http-server "0.1.0")
    (elisp-refs  "1.6"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "5df42accd738e983c31e166cf6dcc73482bf7154"
  :revdesc "5df42accd738"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
