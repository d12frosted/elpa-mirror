(define-package "modus-themes" "20210414.1025" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "eba0ca9ce2bc2014669a55231136a01e015098da" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
