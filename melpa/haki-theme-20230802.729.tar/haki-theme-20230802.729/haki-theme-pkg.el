(define-package "haki-theme" "20230802.729" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "522948af6b7d562d70e366dfce152464f058b8ea" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
