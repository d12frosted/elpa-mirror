(define-package "timesheet" "20180802.202" "Timesheet management add-on for org-mode"
  '((s "1")
    (org "7")
    (auctex "11"))
  :commit "67ca6a9f6733052066b438301fb2dd81b8b3f6eb" :authors
  '(("Tom Marble"))
  :maintainer
  '("Tom Marble")
  :keywords
  '("org" "timesheet")
  :url "https://github.com/tmarble/timesheet.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
