;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20250702.557"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "c80c69aaa78f2172f0619bc793877b2b8ace9e33"
  :revdesc "c80c69aaa78f"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
