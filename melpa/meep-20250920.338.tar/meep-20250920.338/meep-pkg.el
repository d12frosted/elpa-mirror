;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250920.338"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "c716b6d2f13a70e896df0749d206dc06c16007b1"
  :revdesc "c716b6d2f13a"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
