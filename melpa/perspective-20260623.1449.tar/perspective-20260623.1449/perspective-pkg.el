;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective" "20260623.1449"
  "Switch between named \"perspectives\" of the editor."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/nex3/perspective-el"
  :commit "451b0f0272c732f5e822b0c0c590d9dd0937915e"
  :revdesc "451b0f0272c7"
  :keywords '("workspace" "convenience" "frames")
  :authors '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers '(("Natalie Weizenbaum" . "nex342@gmail.com")))
