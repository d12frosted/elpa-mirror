;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250522.627"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "59ed891293f3d276551dbab9359f25dcb6561cd2"
  :revdesc "59ed891293f3"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
