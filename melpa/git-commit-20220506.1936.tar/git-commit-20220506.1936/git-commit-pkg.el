(define-package "git-commit" "20220506.1936" "Edit Git commit messages."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (transient "20210920")
    (with-editor "20211001"))
  :commit "71f7d1df1d715a866269f33ed5c3836ed0839571" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
