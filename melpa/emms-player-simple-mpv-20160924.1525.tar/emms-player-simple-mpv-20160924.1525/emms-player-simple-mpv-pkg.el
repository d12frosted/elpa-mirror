(define-package "emms-player-simple-mpv" "20160924.1525" "An extension of emms-player-simple.el for mpv JSON IPC"
  '((emacs "24")
    (cl-lib "0.5")
    (emms "4.0"))
  :commit "bcc056364df5f405716006a8b7bb90102a57f62f" :authors
  '(("momomo5717"))
  :maintainer
  '("momomo5717")
  :keywords
  '("emms" "mpv")
  :url "https://github.com/momomo5717/emms-player-simple-mpv")
;; Local Variables:
;; no-byte-compile: t
;; End:
