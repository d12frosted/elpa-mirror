;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260424.156"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "7a700608e9143f8e29a533bdeee9a6f175df6d06"
  :revdesc "7a700608e914"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
