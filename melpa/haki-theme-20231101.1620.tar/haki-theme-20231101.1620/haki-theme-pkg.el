(define-package "haki-theme" "20231101.1620" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "61fab22bfc5edb1bf23d210d982f080a89f16730" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
