;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260518.1450"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "e85ba49879ebc8a81cef812c243829bd4241d956"
  :revdesc "e85ba49879eb"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
