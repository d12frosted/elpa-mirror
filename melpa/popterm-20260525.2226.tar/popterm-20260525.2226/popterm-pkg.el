;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260525.2226"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "acd9f9347545a8c3eaa775e9573d01b82db6a9fd"
  :revdesc "acd9f9347545"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
