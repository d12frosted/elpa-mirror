;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260815.1706"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "02d11b03b633c556c825eda54e2d43ab60c3a9bd"
  :revdesc "02d11b03b633"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
