;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20241208.526"
  "Beautify Org Links."
  '((emacs      "29.1")
    (org        "9.7.14")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "cac2295294bbed0989f5b1c500a51967cc6f5d8c"
  :revdesc "cac2295294bb"
  :keywords '("hypermedia"))
