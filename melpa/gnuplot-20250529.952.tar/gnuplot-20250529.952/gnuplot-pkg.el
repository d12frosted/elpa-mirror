;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250529.952"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "a71779e7a46a78589e6d027d79da4f5e54f0e84e"
  :revdesc "a71779e7a46a"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
