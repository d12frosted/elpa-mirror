(define-package "consult" "20230416.221" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "c1c2d10355f2cc63f8a60a9bde9e796ed3ed9a77" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
