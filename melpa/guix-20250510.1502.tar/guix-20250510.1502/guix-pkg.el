;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20250510.1502"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4"))
  :url "https://emacs-guix.gitlab.io/website/"
  :commit "460ccf7f3f12268445e25e57698d2ce9c6b9081e"
  :revdesc "460ccf7f3f12"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
