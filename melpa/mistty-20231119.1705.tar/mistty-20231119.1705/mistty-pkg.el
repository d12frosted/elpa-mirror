(define-package "mistty" "20231119.1705" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "c755b86c46f0adebf1d7978644672668fb480f74" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
