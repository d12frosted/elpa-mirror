;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241031.1124"
  "ChatGPT shell + buffer insert commands."
  '((emacs       "28.1")
    (shell-maker "0.58.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "3020c28eb899e84ada8fc41e9b7e87389777530b"
  :revdesc "3020c28eb899")
