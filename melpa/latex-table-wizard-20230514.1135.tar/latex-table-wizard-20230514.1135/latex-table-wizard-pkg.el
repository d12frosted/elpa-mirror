(define-package "latex-table-wizard" "20230514.1135" "Magic editing of LaTeX tables"
  '((emacs "27.1")
    (auctex "12.1")
    (transient "0.3.7"))
  :commit "76d307f27eab65470592400819afaba493c78ef4" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :keywords
  '("convenience")
  :url "https://github.com/enricoflor/latex-table-wizard")
;; Local Variables:
;; no-byte-compile: t
;; End:
