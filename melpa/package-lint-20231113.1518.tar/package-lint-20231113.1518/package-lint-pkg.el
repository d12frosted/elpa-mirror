(define-package "package-lint" "20231113.1518" "A linting library for elisp package authors"
  '((cl-lib "0.5")
    (emacs "24.4")
    (let-alist "1.0.6")
    (compat "29.1"))
  :commit "dd81a5b9224cc6e6dc4bbb6b4a2928df89c01317" :authors
  '(("Steve Purcell" . "steve@sanityinc.com")
    ("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("lisp")
  :url "https://github.com/purcell/package-lint")
;; Local Variables:
;; no-byte-compile: t
;; End:
