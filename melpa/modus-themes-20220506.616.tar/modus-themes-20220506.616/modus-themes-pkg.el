(define-package "modus-themes" "20220506.616" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "5cd7f47e6e7d4c0d3c5df940d2d1e74b34961588" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
