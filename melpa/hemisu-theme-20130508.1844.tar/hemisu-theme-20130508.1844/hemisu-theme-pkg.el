;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hemisu-theme" "20130508.1844"
  "Hemisu for Emacs."
  ()
  :url "http://github/anrzejsliwa/django-theme"
  :commit "ae593ac58e6bffef97467259c1d1472840385e84"
  :revdesc "ae593ac58e6b")
