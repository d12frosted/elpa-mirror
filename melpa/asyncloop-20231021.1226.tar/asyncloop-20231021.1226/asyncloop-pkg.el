(define-package "asyncloop" "20231021.1226" "Non-blocking series of functions"
  '((emacs "28.1"))
  :commit "656a56bb5be36901388c7ba2692d93402b8ad971" :authors
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainers
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainer
  '(nil . "<meedstrom91@gmail.com>")
  :keywords
  '("tools")
  :url "https://github.com/meedstrom/asyncloop")
;; Local Variables:
;; no-byte-compile: t
;; End:
