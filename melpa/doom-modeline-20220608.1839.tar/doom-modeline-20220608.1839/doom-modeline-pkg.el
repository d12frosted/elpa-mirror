(define-package "doom-modeline" "20220608.1839" "A minimal and modern mode-line"
  '((emacs "25.1")
    (shrink-path "0.2.0")
    (dash "2.11.0"))
  :commit "685e26a9f44c5430b65bde4f94661bde87cd114d" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
