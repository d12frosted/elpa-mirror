(define-package "eldev" "20211106.2155" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "046df4a8b8a49085445aeca36e20d9570d8acd90" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
