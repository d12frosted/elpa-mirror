;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20260417.1854"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "62c31c609d7d96ec6c592eec40fba41735e40875"
  :revdesc "62c31c609d7d"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
