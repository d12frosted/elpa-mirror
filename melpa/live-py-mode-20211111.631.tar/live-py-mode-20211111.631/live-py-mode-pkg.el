(define-package "live-py-mode" "20211111.631" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "c6c581236b3eeb212d3f93de0463630773141e92" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
