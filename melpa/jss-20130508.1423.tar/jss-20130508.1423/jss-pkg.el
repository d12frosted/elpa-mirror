;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jss" "20130508.1423"
  "An emacs interface to webkit and mozilla debuggers."
  '((emacs     "24.1")
    (websocket "0")
    (js2-mode  "0"))
  :url "https://github.com/segv/jss"
  :commit "41749257aecf13c7bd6ed489b5ab3304d06e40bc"
  :revdesc "41749257aecf"
  :keywords '("languages")
  :authors '(("Marco Baringer" . "mb@bese.it"))
  :maintainers '(("Marco Baringer" . "mb@bese.it")))
