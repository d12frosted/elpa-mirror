;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251213.140"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "4fcfee2b5e6454dc5e728bd381ff3dc6464a0404"
  :revdesc "4fcfee2b5e64"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
