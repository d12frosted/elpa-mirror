;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20260718.1815"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "b6e51cb9a01c87e36d8920d947ed171bf21c8287"
  :revdesc "b6e51cb9a01c"
  :keywords '("convenience" "gptel" "llm"))
