;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-tools" "20251230.1321"
  "Support library for PDF documents."
  '((emacs     "26.3")
    (tablist   "1.0")
    (let-alist "1.0.4"))
  :url "http://github.com/vedang/pdf-tools/"
  :commit "cd9a2fe0c256fdeb5788e38f68ff124efdedf091"
  :revdesc "cd9a2fe0c256"
  :keywords '("files" "multimedia")
  :authors '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainers '(("Vedang Manerikar" . "vedang.manerikar@gmail.com")))
