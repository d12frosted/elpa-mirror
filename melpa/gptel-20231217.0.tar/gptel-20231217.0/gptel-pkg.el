(define-package "gptel" "20231217.0" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "0ea3c7fb15b0b60bcc930d7cadc5148abb1ca724" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
