(define-package "org-ref" "20211109.2359" "citations, cross-references and bibliographies in org-mode"
  '((dash "0")
    (s "0")
    (f "0")
    (htmlize "0")
    (hydra "0")
    (avy "0")
    (parsebib "0")
    (bibtex-completion "0")
    (citeproc "0"))
  :commit "ae1413d5078558ecdbaabf1a2a054e4d8e6808d4" :authors
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainer
  '("John Kitchin" . "jkitchin@andrew.cmu.edu")
  :keywords
  '("org-mode" "cite" "ref" "label")
  :url "https://github.com/jkitchin/org-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
