;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260218.116"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "1b93e7091e23855a2f674bddfed37ae81ff2e153"
  :revdesc "1b93e7091e23"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
