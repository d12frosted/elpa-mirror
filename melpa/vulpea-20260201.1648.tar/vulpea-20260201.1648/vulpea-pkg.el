;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260201.1648"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "317ae97a04bb6cbe7744d78a5347353c513e3740"
  :revdesc "317ae97a04bb"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
