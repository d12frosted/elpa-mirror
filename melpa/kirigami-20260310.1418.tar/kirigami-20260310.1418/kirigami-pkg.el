;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260310.1418"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "59d6aff6e3f160522072e36e9d3eb1b26668c4e6"
  :revdesc "59d6aff6e3f1"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
