(define-package "sumibi" "20230627.1034" "Japanese input method powered by ChatGPT API"
  '((emacs "28.1")
    (popup "0.5.9")
    (unicode-escape "1.1")
    (deferred "0.5.1"))
  :commit "a9544b57f1e7e1aa2c257d3f7378571c5587379e" :authors
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainer
  '("Kiyoka Nishiyama" . "kiyoka@sumibi.org")
  :keywords
  '("lisp" "ime" "japanese")
  :url "https://github.com/kiyoka/Sumibi")
;; Local Variables:
;; no-byte-compile: t
;; End:
