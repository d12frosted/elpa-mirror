;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emc" "20250919.831"
  "Invoking a C/C++ (et al.) build toolchain from ELisp."
  '((delight "1.7")
    (emacs   "29.1"))
  :url "https://github.com/marcoxa/emc"
  :commit "ba9012140f796789baa88b7cd8f46cbcc3553d1a"
  :revdesc "ba9012140f79"
  :keywords '("extensions" "c" "lisp" "building tools" "development" "deployment.")
  :authors '(("Marco Antoniotti" . "marcoxa[at]gmail.com"))
  :maintainers '(("Marco Antoniotti" . "marcoxa[at]gmail.com")))
