(define-package "helm-core" "20220409.756" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "155227133cac17c5db8a47e2cf937d9b77ed15ac" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
