(define-package "helm-core" "20220409.756" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "c41e59d045ee8a050cf1be5c728d3e6cc1d65ba9" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
