(define-package "wttrin" "20240421.1845" "Emacs Frontend for the Weather Web Service wttr.in"
  '((emacs "24.4")
    (xterm-color "1.0"))
  :commit "e31f4597c694e4783ece22ff7b446512e09b8b3a" :maintainers
  '(("Craig Jennings" . "c@cjennings.net"))
  :maintainer
  '("Craig Jennings" . "c@cjennings.net")
  :keywords
  '("weather" "wttrin" "games")
  :url "https://github.com/cjennings/emacs-wttrin")
;; Local Variables:
;; no-byte-compile: t
;; End:
