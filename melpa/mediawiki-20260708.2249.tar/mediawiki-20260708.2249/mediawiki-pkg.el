;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20260708.2249"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "6e081439a876b3cb9a27146fd75e887997712629"
  :revdesc "6e081439a876"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
