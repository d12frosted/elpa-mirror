(define-package "chronometrist-key-values" "20220212.1832" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "21c442069e16083153040837e671bc5e446f9643" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
