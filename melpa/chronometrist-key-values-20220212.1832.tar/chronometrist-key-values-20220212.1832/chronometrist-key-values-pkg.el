(define-package "chronometrist-key-values" "20220212.1832" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "7f4e5e9c7c3ff2223a10a237e4130dc0f17db4c1" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
