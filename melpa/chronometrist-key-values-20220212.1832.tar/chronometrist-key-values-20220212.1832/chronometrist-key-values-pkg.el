(define-package "chronometrist-key-values" "20220212.1832" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "2c1274147475b552716de7cecd7a9fd46e578e46" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
