;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xref-rst" "20261027.729"
  "Lookup reStructuredText symbols."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-xref-rst"
  :commit "cd291e8d7274b1dc207722004293b776ba2d61d2"
  :revdesc "cd291e8d7274"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
