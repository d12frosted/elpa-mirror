;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260426.657"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "80d858dbb91368772c2fee659ae27b3094e06eec"
  :revdesc "80d858dbb913"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
