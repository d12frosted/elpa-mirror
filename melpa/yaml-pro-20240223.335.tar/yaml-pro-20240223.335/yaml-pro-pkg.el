(define-package "yaml-pro" "20240223.335" "Parser-aided YAML editing features"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "62ba20899608fc6eaa27bb16755f90fbf6b222eb" :authors
  '(("Zachary Romero"))
  :maintainers
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("tools")
  :url "https://github.com/zkry/yaml-pro")
;; Local Variables:
;; no-byte-compile: t
;; End:
