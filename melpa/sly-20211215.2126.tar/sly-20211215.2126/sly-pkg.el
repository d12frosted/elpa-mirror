(define-package "sly" "20211215.2126" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "19f4046decb9715907b8064807b9e97c87a278fa" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
