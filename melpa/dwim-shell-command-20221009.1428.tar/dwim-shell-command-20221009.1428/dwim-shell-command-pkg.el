(define-package "dwim-shell-command" "20221009.1428" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "95dec835e2acc5de7e50ce156144bebd046e0ecc" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
