(define-package "boon" "20190818.1022" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (expand-region "0.10.0")
    (dash "2.12.0")
    (multiple-cursors "1.3.0"))
  :commit "270ae67b3136ac355d2aed5b4690ae28edaf7c29")
;; Local Variables:
;; no-byte-compile: t
;; End:
