;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shenshou" "20241015.1227"
  "Download&Extract subtitles from opensubtitles."
  '((emacs "27.1"))
  :url "https://github.com/redguardtoo/shenshou"
  :commit "65163b449131ed0946ca6e817a660b4bbb7d35e9"
  :revdesc "65163b449131"
  :keywords '("convenience" "tools")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
