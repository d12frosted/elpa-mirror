(define-package "syntactic-close" "20231217.1732" "Insert closing delimiter"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "f1db4a94f70cd067dc43311c5e9f4c446edabcaf" :authors
  '(("Andreas Röhler" . "andreas.roehler@online.de")
    ("Emacs User Group Berlin" . "emacs-berlin@emacs-berlin.org"))
  :maintainers
  '(("Andreas Röhler" . "andreas.roehler@online.de"))
  :maintainer
  '("Andreas Röhler" . "andreas.roehler@online.de")
  :keywords
  '("languages" "convenience")
  :url "https://github.com/emacs-berlin/syntactic-close")
;; Local Variables:
;; no-byte-compile: t
;; End:
