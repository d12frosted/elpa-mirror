;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260107.100"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "bd6df2cebe3c6ec49d0753852dc26d4ae4b920a5"
  :revdesc "bd6df2cebe3c"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
