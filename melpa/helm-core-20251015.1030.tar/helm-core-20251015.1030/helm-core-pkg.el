;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251015.1030"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "6dd04ac8172f6959e1e79656444bc59af37fdcc4"
  :revdesc "6dd04ac8172f"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
