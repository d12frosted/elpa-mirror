(define-package "gap-mode" "20240313.1615" "Major mode for editing files in the GAP programming language." 'nil :commit "8439c3622e1f9e2ec1a8ef21020eb55e917f4416" :authors
  '(("Michael Smith" . "smith@pell.anu.edu.au")
    ("Gary Zablackis")
    ("Goetz Pfeiffer")
    ("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainers
  '(("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainer
  '("Ivan Andrus" . "darthandrus@gmail.com")
  :keywords
  '("gap")
  :url "https://gitlab.com/gvol/gap-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
