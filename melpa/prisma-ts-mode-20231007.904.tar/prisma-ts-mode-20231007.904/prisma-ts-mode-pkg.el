(define-package "prisma-ts-mode" "20231007.904" "Major mode for prisma using tree-sitter"
  '((emacs "29.1"))
  :commit "b597a437a96c0f03cf2bc038794d6a98ba1bd48b" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("prisma" "languages" "tree-sitter")
  :url "https://github.com/nverno/prisma-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
