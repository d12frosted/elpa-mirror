;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260319.849"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "b14ce622b9c865e1641b5de2b2575222dd70c0b6"
  :revdesc "b14ce622b9c8"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
