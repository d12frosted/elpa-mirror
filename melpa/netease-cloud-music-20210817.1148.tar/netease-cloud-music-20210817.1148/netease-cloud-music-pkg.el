(define-package "netease-cloud-music" "20210817.1148" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "e228a3e8646d4d66f61eb91e306b8bc1cfa9861a" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
