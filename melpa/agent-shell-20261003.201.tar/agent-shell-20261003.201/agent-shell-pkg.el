;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261003.201"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1b276055f9fb87b58235515dabb087a213799883"
  :revdesc "1b276055f9fb")
