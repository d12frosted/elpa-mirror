;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-command-not-found" "20260201.715"
  "Integrate command-not-found in eshell."
  '((emacs "25.1"))
  :url "https://github.com/jaeyeom/eshell-command-not-found"
  :commit "0efda98051747183bd54cb021f4756bdf831bd8e"
  :revdesc "0efda9805174"
  :keywords '("convenience")
  :authors '(("Jaehyun Yeom" . "jae.yeom@gmail.com"))
  :maintainers '(("Jaehyun Yeom" . "jae.yeom@gmail.com")))
