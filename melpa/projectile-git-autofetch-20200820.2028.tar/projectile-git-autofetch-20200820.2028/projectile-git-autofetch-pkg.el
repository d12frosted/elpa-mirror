;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-git-autofetch" "20200820.2028"
  "Automatically fetch git repositories."
  '((emacs      "25.1")
    (projectile "0.14.0"))
  :url "https://github.com/andrmuel/projectile-git-autofetch"
  :commit "423ed5fa6508c4edc0a837bb585c7e77e99876be"
  :revdesc "423ed5fa6508"
  :keywords '("tools" "vc")
  :authors '(("Andreas Müller" . "code@0x7.ch"))
  :maintainers '(("Andreas Müller" . "code@0x7.ch")))
