;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-dogears" "20230608.356"
  "Helm source for Dogears."
  '((emacs   "26.3")
    (dogears "0.1-pre")
    (helm    "3.6"))
  :url "https://github.com/alphapapa/dogears.el"
  :commit "7ba83bd8924cec66fe3ede3334e98b1845e6852e"
  :revdesc "7ba83bd8924c"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
