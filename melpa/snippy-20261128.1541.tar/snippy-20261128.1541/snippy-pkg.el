;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snippy" "20261128.1541"
  "Vscode snippet support with Yasnippet."
  '((emacs     "30.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/MiniApollo/snippy"
  :commit "0c86c8ec90c905690657b16488e380950eca1719"
  :revdesc "0c86c8ec90c9"
  :keywords '("convenience" "emulations")
  :authors '(("Mark Surmann" . "surmannmark@gmail.com"))
  :maintainers '(("Mark Surmann" . "surmannmark@gmail.com")))
