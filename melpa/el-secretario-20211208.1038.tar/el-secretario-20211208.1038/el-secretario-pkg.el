(define-package "el-secretario" "20211208.1038" "Unify all your inboxes with the Emacs secretary"
  '((emacs "27.1")
    (org-ql "0.6pre")
    (hercules "0.3"))
  :commit "31a53f9b888ca4c2000e98c8b56ed187397fd9e7" :authors
  '(("Leo Okawa Ericson <http://github/Zetagon>"))
  :maintainer
  '("Leo" . "github@relevant-information.com")
  :keywords
  '("convenience")
  :url "https://git.sr.ht/~zetagon/el-secretario")
;; Local Variables:
;; no-byte-compile: t
;; End:
