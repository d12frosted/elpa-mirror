(define-package "prettier" "20220601.907" "Code formatting with Prettier"
  '((emacs "26.1")
    (iter2 "0.9")
    (nvm "0.2"))
  :commit "aeff9aaf8a358b8b34e33a58ae39bac89049e900" :authors
  '(("Julian Scheid" . "julians37@gmail.com"))
  :maintainer
  '("Julian Scheid" . "julians37@gmail.com")
  :keywords
  '("convenience" "languages" "files")
  :url "https://github.com/jscheid/prettier.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
