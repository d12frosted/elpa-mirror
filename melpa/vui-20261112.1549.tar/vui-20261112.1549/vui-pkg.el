;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261112.1549"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "ca897971b0f4501c6954942f9b0103ca36b6e9f4"
  :revdesc "ca897971b0f4"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
