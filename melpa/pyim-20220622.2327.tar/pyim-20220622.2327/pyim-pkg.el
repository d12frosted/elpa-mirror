(define-package "pyim" "20220622.2327" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "25.1")
    (async "1.6")
    (xr "1.13"))
  :commit "7a32f0e0a2a09a4379f900b1578beae59c2c6185" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
