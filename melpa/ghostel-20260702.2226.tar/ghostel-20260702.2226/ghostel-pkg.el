;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260702.2226"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "109ed0d1c88d36dcd415381148164bafd70ee97b"
  :revdesc "109ed0d1c88d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
