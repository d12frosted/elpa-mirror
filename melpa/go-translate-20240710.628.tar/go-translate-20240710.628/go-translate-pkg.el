(define-package "go-translate" "20240710.628" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "13975ae19a55401ee7bcd42d7b71584a554a0a1d" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
