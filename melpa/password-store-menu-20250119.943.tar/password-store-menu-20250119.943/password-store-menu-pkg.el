;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-store-menu" "20250119.943"
  "A better, more complete UI for password-store."
  '((emacs          "29.1")
    (password-store "2.3.2")
    (pass           "2.0.1"))
  :url "https://github.com/rjekker/password-store-menu"
  :commit "318ba3b1a80eb60f2be210e3a3970d152681dc2a"
  :revdesc "318ba3b1a80e"
  :keywords '("convenience" "data" "files")
  :authors '(("Reindert-Jan Ekker" . "info@rjekker.nl"))
  :maintainers '(("Reindert-Jan Ekker" . "info@rjekker.nl")))
