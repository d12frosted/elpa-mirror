(define-package "jabber" "20240521.629" "A Jabber client for Emacs."
  '((emacs "27.1")
    (fsm "0.2")
    (srv "0.2"))
  :commit "fcff3918158ed85576445cfbe800f28ab81c7031" :authors
  '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainer
  '("wgreenhouse" . "wgreenhouse@tilde.club")
  :keywords
  '("comm")
  :url "https://codeberg.org/emacs-jabber/emacs-jabber")
;; Local Variables:
;; no-byte-compile: t
;; End:
