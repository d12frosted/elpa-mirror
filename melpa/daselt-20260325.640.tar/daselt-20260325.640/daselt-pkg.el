;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260325.640"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "05b9a9bb37e2d74d0634683a9e86089be3a436b3"
  :revdesc "05b9a9bb37e2"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
