(define-package "python-docstring" "20220304.2113" "Smart Python docstring formatting" 'nil :commit "cff5b24936c6cdf0962cac2b6cb6e46164eaa5a1")
;; Local Variables:
;; no-byte-compile: t
;; End:
