;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250419.828"
  "Ollama LLM AI Assistant with ChatGPT and Claude Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "f514642d82a9ab8c67a5cc5358260e6e53f57d96"
  :revdesc "f514642d82a9"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
