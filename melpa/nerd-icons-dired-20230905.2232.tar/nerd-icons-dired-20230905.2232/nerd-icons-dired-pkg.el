(define-package "nerd-icons-dired" "20230905.2232" "Shows icons for each file in dired mode"
  '((emacs "24.4")
    (nerd-icons "0.0.1"))
  :commit "b7605208215194fb97da703dff8c1a71738a6533" :authors
  '(("Hongyu Ding" . "rainstormstudio@yahoo.com"))
  :maintainers
  '(("Hongyu Ding" . "rainstormstudio@yahoo.com"))
  :maintainer
  '("Hongyu Ding" . "rainstormstudio@yahoo.com")
  :keywords
  '("lisp")
  :url "https://github.com/rainstormstudio/nerd-icons-dired")
;; Local Variables:
;; no-byte-compile: t
;; End:
