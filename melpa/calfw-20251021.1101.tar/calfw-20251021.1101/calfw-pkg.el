;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251021.1101"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "7c976c34f45d2e1fbf7b262c31842b6f47e5ff73"
  :revdesc "7c976c34f45d"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
