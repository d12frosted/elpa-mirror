;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsrs" "20250608.703"
  "Free Spaced Repetition Scheduler."
  '((emacs "25.1"))
  :url "https://github.com/open-spaced-repetition/lisp-fsrs"
  :commit "be94cf2a4bcf542cc20f34bc0f1c68df1a051833"
  :revdesc "be94cf2a4bcf"
  :keywords '("tools"))
