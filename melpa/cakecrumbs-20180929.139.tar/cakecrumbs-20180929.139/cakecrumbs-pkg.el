;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cakecrumbs" "20180929.139"
  "Show parents on header for HTML/Jade/Sass/Stylus."
  '((emacs "24.4"))
  :url "https://github.com/kuanyui/cakecrumbs.el"
  :commit "cf8c1df885eee004602f73c4f841301e200e5850"
  :revdesc "cf8c1df885ee"
  :keywords '("languages" "html" "jade" "pug" "sass" "scss" "stylus")
  :authors '(("ono hiroko" . "kuanyui.github.io"))
  :maintainers '(("ono hiroko" . "kuanyui.github.io")))
