;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "20260505.404"
  "Obsidian-like note-taking for org files."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "b65690a61552ad2471c30d04ba0da2d5ce35cc23"
  :revdesc "b65690a61552"
  :keywords '("notes" "outlines" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
