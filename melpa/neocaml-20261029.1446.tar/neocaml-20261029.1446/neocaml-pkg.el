;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261029.1446"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "3234f421dc4e1cfbae4d8a1bda1bd791b440d9ab"
  :revdesc "3234f421dc4e"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
