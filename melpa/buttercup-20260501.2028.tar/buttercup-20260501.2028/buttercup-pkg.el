;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buttercup" "20260501.2028"
  "Behavior-Driven Emacs Lisp Testing."
  '((emacs "24.4"))
  :url "https://github.com/jorgenschaefer/emacs-buttercup"
  :commit "2b1537af18498532f7dd58cfee9ac34f7f8a9d4b"
  :revdesc "2b1537af1849"
  :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainers '(("Ola Nilsson" . "ola.nilsson@gmail.com")))
