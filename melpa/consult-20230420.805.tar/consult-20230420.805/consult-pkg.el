(define-package "consult" "20230420.805" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "89e068fd043c3f32f3b177bd77c0a9a08248c0b7" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
