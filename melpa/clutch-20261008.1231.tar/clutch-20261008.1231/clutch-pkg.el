;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261008.1231"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "185828f57fbb9256f0e77d3d2105f3743db1da2f"
  :revdesc "185828f57fbb"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
