;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260128.1225"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "0be43f7599f495acdd83a20b3207b267727632c2"
  :revdesc "0be43f7599f4"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
