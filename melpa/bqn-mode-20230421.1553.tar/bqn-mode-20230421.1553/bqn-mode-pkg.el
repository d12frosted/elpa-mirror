(define-package "bqn-mode" "20230421.1553" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "54fa67ac172f220d61773b2d2257fadf098454d7" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
