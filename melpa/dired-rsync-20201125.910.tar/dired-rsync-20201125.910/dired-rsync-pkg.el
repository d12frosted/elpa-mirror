(define-package "dired-rsync" "20201125.910" "Allow rsync from dired buffers"
  '((s "1.12.0")
    (dash "2.0.0")
    (emacs "24"))
  :commit "0dc7bf9ac4cb7056f278269e486ce43e364d52b8" :authors
  (("Alex Bennée" . "alex@bennee.com"))
  :maintainer
  ("Alex Bennée" . "alex@bennee.com")
  :url "https://github.com/stsquad/dired-rsync")
;; Local Variables:
;; no-byte-compile: t
;; End:
