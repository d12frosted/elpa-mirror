(define-package "run-command" "20230131.907" "Run an external command from a context-dependent list"
  '((emacs "27.1"))
  :commit "e44bc5fb9712303150906f05ce7dd41c8c184aea" :authors
  '(("Massimiliano Mirra" . "hyperstruct@gmail.com"))
  :maintainer
  '("Massimiliano Mirra" . "hyperstruct@gmail.com")
  :keywords
  '("processes")
  :url "https://github.com/bard/emacs-run-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
