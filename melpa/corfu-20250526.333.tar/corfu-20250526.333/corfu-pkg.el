;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250526.333"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "77e639bc6b982be09f355390beef6f200936109a"
  :revdesc "77e639bc6b98"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
