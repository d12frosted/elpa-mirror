;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "20260604.125"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "6b191a4fcf0e99a3a53902d6226f9963212140dc"
  :revdesc "6b191a4fcf0e"
  :keywords '("convenience"))
