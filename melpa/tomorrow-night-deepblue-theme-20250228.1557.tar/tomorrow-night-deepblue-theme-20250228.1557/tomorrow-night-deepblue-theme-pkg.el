;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tomorrow-night-deepblue-theme" "20250228.1557"
  "The Tomorrow Night Deepblue color theme."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/tomorrow-night-deepblue-theme.el"
  :commit "9abc4692986feb221c1cd7019bdf75a20bad870c"
  :revdesc "9abc4692986f"
  :keywords '("faces" "themes"))
