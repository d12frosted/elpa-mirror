(define-package "citre" "20210728.125" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "5c5958e467e4da7a8578039643d5036b3395e3d6" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
