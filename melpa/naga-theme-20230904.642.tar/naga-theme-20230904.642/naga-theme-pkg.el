(define-package "naga-theme" "20230904.642" "Dark color theme with green foreground color"
  '((emacs "24.1"))
  :commit "0f761c44d8d5321dcdc09f298f54c5598d8a00ed" :authors
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainers
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainer
  '("Johannes Maier" . "johannes.maier@mailbox.org")
  :keywords
  '("faces" "themes")
  :url "https://github.com/kenranunderscore/emacs-naga-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
