;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260510.1826"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "86a52b8fd4e8f3932a0f686e7ea966157b03a204"
  :revdesc "86a52b8fd4e8"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
