;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-latte" "20260201.2212"
  "Auto-highlight unlinked Org-roam references."
  '((emacs       "27.1")
    (org-roam    "2.0")
    (inflections "1.1"))
  :url "https://github.com/yad-tahir/org-roam-latte"
  :commit "619f4d95fdddce85cf96874c5961edf8dd5abc25"
  :revdesc "619f4d95fddd"
  :keywords '("hypermedia" "outlines" "org-roam" "convenience")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
