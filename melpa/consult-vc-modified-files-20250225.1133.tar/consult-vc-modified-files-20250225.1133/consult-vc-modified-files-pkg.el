;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vc-modified-files" "20250225.1133"
  "Show git modified files in a vc project with consult."
  '((emacs   "28.1")
    (consult "0.9"))
  :url "https://github.com/chmouel/consult-vc-modified-files"
  :commit "e85d26430cc10786d93db54600c0933012554b0a"
  :revdesc "e85d26430cc1"
  :keywords '("vc" "convenience")
  :authors '(("Chmouel Boudjnah" . "chmouel@chmouel.com"))
  :maintainers '(("Chmouel Boudjnah" . "chmouel@chmouel.com")))
