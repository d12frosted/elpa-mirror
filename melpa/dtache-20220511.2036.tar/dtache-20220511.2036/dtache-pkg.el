(define-package "dtache" "20220511.2036" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "b121de820cf28ed507194b9c4cde90ac9ca672d8" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
