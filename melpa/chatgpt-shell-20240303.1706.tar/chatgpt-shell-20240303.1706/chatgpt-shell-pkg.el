(define-package "chatgpt-shell" "20240303.1706" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.50.1"))
  :commit "2beb232d5ff5490b6f19fdabc401d4f9dc818273" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
