(define-package "org-gtd" "20220109.2016" "An implementation of GTD."
  '((emacs "27.1")
    (org-edna "1.1.2")
    (f "0.20.0")
    (org "9.3.1")
    (org-agenda-property "1.3.1")
    (transient "0.3.7"))
  :commit "10533bcd71b0735d2f94d95f14d25f08f343d4f8" :authors
  '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainer
  '("Aldric Giacomoni" . "trevoke@gmail.com")
  :url "https://github.com/Trevoke/org-gtd.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
