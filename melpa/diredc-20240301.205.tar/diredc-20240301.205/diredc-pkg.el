(define-package "diredc" "20240301.205" "Midnight Commander features (plus) for dired"
  '((emacs "26.1")
    (key-assist "1.0"))
  :commit "58c81884736af3758c723e3e0d062a7a46c00c38" :keywords
  '("files")
  :url "https://github.com/Boruch-Baum/emacs-diredc")
;; Local Variables:
;; no-byte-compile: t
;; End:
