(define-package "epkg" "20210105.1456" "browse the Emacsmirror package database"
  '((closql "1.0.1")
    (emacs "25.1"))
  :commit "b9040a91412824d04134286f31fe287f19496184" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
