;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zotelo" "20160602.949"
  "Manage Zotero collections from emacs."
  '((cl-lib "0.5"))
  :url "https://github.com/vitoshka/zotelo"
  :commit "d9dc089b9adfcc70a63f2a84269a12eb7cb4c748"
  :revdesc "d9dc089b9adf"
  :keywords '("zotero" "emacs" "reftex" "bibtex" "mozrepl" "bibliography manager"))
