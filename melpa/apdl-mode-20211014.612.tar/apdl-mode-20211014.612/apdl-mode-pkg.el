(define-package "apdl-mode" "20211014.612" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "30616b0924d85a99ca381f21d4717cb6eccc9f95" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
