(define-package "apdl-mode" "20211014.612" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "cf5a8957df997b99ac9c856f87e9d57a0cd91642" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
