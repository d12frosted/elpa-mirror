(define-package "chronometrist-key-values" "20210614.918" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "2f26ef0a605b83b2eeb829722817972ed1382466" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
