;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-delete" "20230802.1113"
  "IntelliJ-like backspace/delete."
  '((emacs "24.1"))
  :url "https://github.com/leodag/smart-delete"
  :commit "b1f90b9510caf21d87ba26e30d56dfbaec92d4e9"
  :revdesc "b1f90b9510ca"
  :keywords '("emulations" "wp"))
