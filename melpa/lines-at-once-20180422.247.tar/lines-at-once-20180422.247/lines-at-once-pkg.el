;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lines-at-once" "20180422.247"
  "Insert and edit multiple lines at once."
  '((emacs "25"))
  :url "https://github.com/jiahaowork/lines-at-once.el"
  :commit "a018ba90549384d52ec58c2685fd14a0f65252be"
  :revdesc "a018ba905493"
  :keywords '("abbrev" "tools")
  :authors '(("Jiahao Li" . "jiahaowork@gmail.com"))
  :maintainers '(("Jiahao Li" . "jiahaowork@gmail.com")))
