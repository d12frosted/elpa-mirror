;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-light-theme" "20260202.706"
  "Visual Studio IDE light theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-light-theme"
  :commit "b29295426ede547b385112b0b4edaeac0295f887"
  :revdesc "b29295426ede"
  :keywords '("faces"))
