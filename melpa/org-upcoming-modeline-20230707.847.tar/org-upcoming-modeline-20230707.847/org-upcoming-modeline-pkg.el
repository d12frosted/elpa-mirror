(define-package "org-upcoming-modeline" "20230707.847" "Show next org event in mode line"
  '((emacs "26.1")
    (ts "0.2")
    (org-ql "0.6"))
  :commit "c3e4705ff2ade869e229f33090c92ac671362623" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("convenience" "calendar")
  :url "https://github.com/unhammer/org-upcoming-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
