;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "20250319.1837"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "http://github.com/szermatt/visual-replace"
  :commit "1a5cb03073a11b3220323cada3461de2dec920e7"
  :revdesc "1a5cb03073a1"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
