(define-package "cnfonts" "20211130.948" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "7326ce9b0504c8c75357c7582df6272730dfc603" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
