(define-package "lsp-dart" "20220521.1556" "Dart support lsp-mode"
  '((emacs "26.3")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (dart-mode "1.0.5"))
  :commit "17801322a0dc8072d40f0e7372fea68f2bdc6cdb" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
