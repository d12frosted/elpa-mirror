;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nrepl-eval-sexp-fu" "20201007.2311"
  "Tiny functionality enhancements for evaluating sexps."
  '((highlight   "0.0.0")
    (smartparens "0.0.0")
    (thingatpt   "0.0.0"))
  :url "https://github.com/samaaron/nrepl-eval-sexp-fu"
  :commit "2d6ad728b1ba290974a2ae1f232a5a96810a135b"
  :revdesc "2d6ad728b1ba"
  :keywords '("lisp" "highlight" "convenience")
  :authors '(("Takeshi Banse" . "takebi@laafc.net"))
  :maintainers '(("Takeshi Banse" . "takebi@laafc.net")))
