;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20261017.1814"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "0c2e834dda0f5298747a077734cb9d5281dcef5e"
  :revdesc "0c2e834dda0f"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
