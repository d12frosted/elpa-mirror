(define-package "html-to-hiccup" "20230120.1416" "Convert HTML to Hiccup syntax"
  '((emacs "25.1")
    (dash "2.13.0")
    (s "1.10.0"))
  :commit "12f12fe3165eebbcf17e6209693c8e7251ffa04c" :authors
  '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainers
  '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainer
  '("Arne Brasseur" . "arne@arnebrasseur.net")
  :keywords
  '("html" "hiccup" "clojure" "convenience" "tools")
  :url "https://github.com/plexus/html-to-hiccup")
;; Local Variables:
;; no-byte-compile: t
;; End:
