;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260126.623"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "4aba4c2ae05f9e5d6446a69e254e06797f10e07d"
  :revdesc "4aba4c2ae05f"
  :keywords '("languages"))
