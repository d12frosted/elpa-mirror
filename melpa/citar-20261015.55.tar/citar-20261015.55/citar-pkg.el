;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar" "20261015.55"
  "Citation-related commands for org, latex, markdown."
  '((emacs    "29.1")
    (parsebib "4.2")
    (org      "9.5")
    (citeproc "0.9"))
  :url "https://github.com/emacs-citar/citar"
  :commit "347469e036d3ec15fb7a5a21b0cff6bebf04b661"
  :revdesc "347469e036d3"
  :authors '(("Bruce D'Arcus" . "https://github.com/bdarcus"))
  :maintainers '(("Bruce D'Arcus" . "https://github.com/bdarcus")))
