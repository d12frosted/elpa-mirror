(define-package "sculpture-themes" "20210828.1634" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "cce59d2bcc48d622f3978c583108cf853f21789c" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
