(define-package "osm" "20230411.439" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "0b51206b662797303207699fefcefb45724c02ad" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
