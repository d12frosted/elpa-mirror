(define-package "org-re-reveal" "20211021.733" "Org export to reveal.js presentations"
  '((emacs "24.4")
    (org "8.3")
    (htmlize "1.34"))
  :commit "6852b63a94319c34e8a8047fa259259a982484ce" :keywords
  '("tools" "outlines" "hypermedia" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/org-re-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
