;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251126.2035"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "129032fca88f29c20343e973c98fa17db3000405"
  :revdesc "129032fca88f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
