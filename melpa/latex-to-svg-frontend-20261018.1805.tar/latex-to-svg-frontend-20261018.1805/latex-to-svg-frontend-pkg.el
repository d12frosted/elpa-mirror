;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261018.1805"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.15.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "5368c0dad8dbc0f76af313c86644f3b810ce6b5f"
  :revdesc "5368c0dad8db"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
