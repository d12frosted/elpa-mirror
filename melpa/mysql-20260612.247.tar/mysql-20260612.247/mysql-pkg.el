;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20260612.247"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "5b9d6b6400fe2b7fbfe8d362c1dc6c0e6f0cee07"
  :revdesc "5b9d6b6400fe"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
