(define-package "csharp-mode" "20210115.1102" "C# mode derived mode" 'nil :commit "57055a7cf764ef8b92c81dd320edc5d3670bef69" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
