(define-package "modus-themes" "20211027.1941" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "31d51994ef54738de70ca799cd534672dc0b4443" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
