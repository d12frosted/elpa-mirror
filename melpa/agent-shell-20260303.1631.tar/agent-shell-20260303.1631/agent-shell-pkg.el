;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260303.1631"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.86.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "62737278bbc3b7ff756f9a3d493afa07690f6b9e"
  :revdesc "62737278bbc3")
