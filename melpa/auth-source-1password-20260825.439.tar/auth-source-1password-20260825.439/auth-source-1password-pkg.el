;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auth-source-1password" "20260825.439"
  "1password integration for auth-source."
  '((emacs "24.4"))
  :url "https://github.com/dlobraico"
  :commit "957bd9b3da51022a9d74610117621738fcec2de4"
  :revdesc "957bd9b3da51"
  :authors '(("Dominick LoBraico" . "auth-source-1password@lobrai.co"))
  :maintainers '(("Dominick LoBraico" . "auth-source-1password@lobrai.co")))
