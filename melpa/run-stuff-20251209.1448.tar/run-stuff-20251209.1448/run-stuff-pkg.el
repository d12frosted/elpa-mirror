;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "run-stuff" "20251209.1448"
  "Context based command execution."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-run-stuff"
  :commit "0873d04a8b18785bb8b1c9e49ac1ee6cea660d73"
  :revdesc "0873d04a8b18"
  :keywords '("files" "lisp" "convenience" "hypermedia")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
