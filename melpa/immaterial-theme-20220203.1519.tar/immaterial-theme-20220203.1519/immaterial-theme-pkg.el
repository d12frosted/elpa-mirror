(define-package "immaterial-theme" "20220203.1519" "A flexible theme based on material design principles"
  '((emacs "25"))
  :commit "90a0f4e6992a99d000d016b5a82fe1a10fcc5e1a" :authors
  '(("Peter Gardfjäll"))
  :maintainer
  '("Peter Gardfjäll")
  :keywords
  '("themes")
  :url "https://github.com/petergardfjall/emacs-immaterial-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
