;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260310.1255"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral DeepSeek OpenRouter Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "28047d7e112c6a54d114d829882c37003ee6b70f"
  :revdesc "28047d7e112c"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
