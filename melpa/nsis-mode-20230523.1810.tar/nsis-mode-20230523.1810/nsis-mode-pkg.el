(define-package "nsis-mode" "20230523.1810" "NSIS-mode" 'nil :commit "b80fa862e8aa2c74188c3028da96b449eb7f3441" :authors
  '(("Matthew L. Fidler"))
  :maintainers
  '(("Matthew L. Fidler"))
  :maintainer
  '("Matthew L. Fidler")
  :keywords
  '("nsis")
  :url "http://github.com/mlf176f2/nsis-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
