;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251124.621"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "61574c235803086b40b24ab2fbd1e072e689afe6"
  :revdesc "61574c235803"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
