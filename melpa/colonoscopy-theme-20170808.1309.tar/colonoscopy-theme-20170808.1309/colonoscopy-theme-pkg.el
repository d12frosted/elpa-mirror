;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colonoscopy-theme" "20170808.1309"
  "An Emacs 24 theme based on Colonoscopy (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "64bbb322b13dae91ce9f1e3581f836f94f800ead"
  :revdesc "64bbb322b13d")
