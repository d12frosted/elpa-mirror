;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260510.326"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "4e142f851fa4f6ed1ddb81e05170b1c8494b7e6c"
  :revdesc "4e142f851fa4"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
