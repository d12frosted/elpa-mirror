;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsharp-ts-mode" "20260329.654"
  "Major mode for F# code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/fsharp-ts-mode"
  :commit "22442687d3eb8e63f33ebcc49720166e465f54bb"
  :revdesc "22442687d3eb"
  :keywords '("languages" "fsharp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
