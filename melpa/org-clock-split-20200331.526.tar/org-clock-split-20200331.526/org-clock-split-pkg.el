;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-split" "20200331.526"
  "Split clock entries."
  '((emacs "24"))
  :url "https://github.com/justintaft/emacs-org-clock-split"
  :commit "39e1d2912a7a7223e2356a5fc4dff03507ae084d"
  :revdesc "39e1d2912a7a"
  :keywords '("calendar")
  :authors '(("Justin Taft" . "https://github.com/justintaft"))
  :maintainers '(("Justin Taft" . "https://github.com/justintaft")))
