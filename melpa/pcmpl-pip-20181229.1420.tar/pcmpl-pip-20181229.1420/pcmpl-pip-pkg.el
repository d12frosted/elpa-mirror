;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcmpl-pip" "20181229.1420"
  "Pcomplete for pip."
  '((s   "1.12.0")
    (f   "0.19.0")
    (seq "2.15"))
  :url "https://github.com/suzzvv/pcmpl-pip"
  :commit "ebb672d4494f876f611639e65df4e28e566c06b5"
  :revdesc "ebb672d4494f"
  :keywords '("pcomplete" "pip" "python" "tools")
  :authors '(("zwild" . "judezhao@outlook.com"))
  :maintainers '(("zwild" . "judezhao@outlook.com")))
