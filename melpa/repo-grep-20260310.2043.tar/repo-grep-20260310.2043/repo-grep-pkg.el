;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "20260310.2043"
  "Project-wide grep search."
  '((emacs "27.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "f66ca26e620fb092df4ab23f8794ee4153c23a3d"
  :revdesc "f66ca26e620f"
  :keywords '("tools" "search" "grep" "convenience" "project"))
