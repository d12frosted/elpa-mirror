;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calc-prog-utils" "20220820.1855"
  "Calc programmers utilities."
  '((emacs "24.1"))
  :url "https://github.com/Jesse-Millwood/calc-prog"
  :commit "190acfda56660a2d75df2d9eac5b14edaccccd80"
  :revdesc "190acfda5666"
  :keywords '("tools" "convenience"))
