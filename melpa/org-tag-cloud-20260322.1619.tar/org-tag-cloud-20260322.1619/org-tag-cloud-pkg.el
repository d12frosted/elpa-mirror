;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-cloud" "20260322.1619"
  "Easily maintain a tag-cloud of org-mode tags."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-tag-cloud"
  :commit "071ec9ef96706c56be4b47024b7ae02014fa1bc0"
  :revdesc "071ec9ef9670"
  :keywords '("outlines" "tagcloud" "tags")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
