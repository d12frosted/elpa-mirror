(define-package "magit-libgit" "20211004.1956" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "bb7b7a402025e26aabc0aee6e97c2ee852a806a9" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
