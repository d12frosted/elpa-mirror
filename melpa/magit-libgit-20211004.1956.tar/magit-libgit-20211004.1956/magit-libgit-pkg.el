(define-package "magit-libgit" "20211004.1956" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "cabcc9cea9d49854d327437c04909d2d5d57def6" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
