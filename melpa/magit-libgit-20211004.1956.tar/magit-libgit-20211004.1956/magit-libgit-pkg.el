(define-package "magit-libgit" "20211004.1956" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "65c4485e19bf570ebcb81fbaa6352c4e94bb05da" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
