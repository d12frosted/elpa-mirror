;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260620.531"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "ca73cb94f8391ebfb2a60537f8c51b244cbad9d9"
  :revdesc "ca73cb94f839"
  :keywords '("faces" "files" "q"))
