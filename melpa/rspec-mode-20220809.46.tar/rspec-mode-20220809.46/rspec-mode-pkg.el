(define-package "rspec-mode" "20220809.46" "Enhance ruby-mode for RSpec"
  '((ruby-mode "1.0")
    (cl-lib "0.4"))
  :commit "6fc421b3ab6477ccef16d26af073488493d50a3b" :authors
  '(("Peter Williams, et al."))
  :maintainer
  '("Peter Williams, et al.")
  :keywords
  '("rspec" "ruby")
  :url "http://github.com/pezra/rspec-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
