(define-package "igist" "20230816.1044" "List, create, update and delete GitHub gists"
  '((emacs "27.1")
    (ghub "3.6.0")
    (transient "0.4.1"))
  :commit "4d3681ffb38263c6072e61d604a3f2462395840a" :authors
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainer
  '("Karim Aziiev" . "karim.aziiev@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/KarimAziev/igist")
;; Local Variables:
;; no-byte-compile: t
;; End:
