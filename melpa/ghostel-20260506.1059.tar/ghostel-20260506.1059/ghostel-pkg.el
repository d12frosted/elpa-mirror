;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260506.1059"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f9b106c847a12411e026b8aa262c61454c3058b9"
  :revdesc "f9b106c847a1"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
