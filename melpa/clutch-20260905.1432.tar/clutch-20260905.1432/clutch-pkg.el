;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260905.1432"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "e75e33b4de83fb5431c1cc31472195755c2833ae"
  :revdesc "e75e33b4de83"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
