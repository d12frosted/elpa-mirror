(define-package "org-zettelkasten" "20230108.1326" "A Zettelkasten mode leveraging Org"
  '((emacs "25.1")
    (org "9.3"))
  :commit "8002c96d94cb89a0f5af03974f6d1eaea45e1e41" :authors
  '(("Yann Herklotz" . "yann@ymhg.org"))
  :maintainer
  '("Yann Herklotz" . "yann@ymhg.org")
  :keywords
  '("files" "hypermedia" "org" "notes")
  :url "https://sr.ht/~ymherklotz/org-zettelkasten")
;; Local Variables:
;; no-byte-compile: t
;; End:
