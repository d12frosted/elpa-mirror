;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20261125.1847"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "6b180cdf958e657d5641164a2eabc35baa5d52ee"
  :revdesc "6b180cdf958e"
  :keywords '("convenience" "text"))
