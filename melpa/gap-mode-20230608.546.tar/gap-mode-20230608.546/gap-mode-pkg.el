(define-package "gap-mode" "20230608.546" "Major mode for editing files in the GAP programming language." 'nil :commit "cf87eddea74e3e0308191847777807e6e017e1de" :authors
  '(("Michael Smith" . "smith@pell.anu.edu.au")
    ("Gary Zablackis")
    ("Goetz Pfeiffer")
    ("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainers
  '(("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainer
  '("Ivan Andrus" . "darthandrus@gmail.com")
  :keywords
  '("gap")
  :url "https://gitlab.com/gvol/gap-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
