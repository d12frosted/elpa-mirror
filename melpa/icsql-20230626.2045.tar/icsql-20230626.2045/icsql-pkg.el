(define-package "icsql" "20230626.2045" "Interactive iSQL iteraface to ciSQL"
  '((emacs "26")
    (choice-program "0.13")
    (buffer-manage "0.12"))
  :commit "fdf2a280f27def4b633a3a74ebdf3a6c95471e3d" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("isql" "sql" "rdbms" "data")
  :url "https://github.com/plandes/icsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
