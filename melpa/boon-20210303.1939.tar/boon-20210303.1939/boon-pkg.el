(define-package "boon" "20210303.1939" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "7a4805fbea06c372ff5e7d5e636235eebf2c5f63")
;; Local Variables:
;; no-byte-compile: t
;; End:
