;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-janet" "20260820.855"
  "Org-Babel support for the Janet language."
  '((emacs "26.1")
    (org   "9.1"))
  :url "https://codeberg.org/zzkt/ob-janet"
  :commit "3dbf225cd32bb60b4fe76fabd89fdac72c6aa84f"
  :revdesc "3dbf225cd32b"
  :keywords '("languages" "tools" "literate programming" "janet")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
