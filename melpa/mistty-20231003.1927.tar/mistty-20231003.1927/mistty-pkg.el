(define-package "mistty" "20231003.1927" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "505f664d850108a72720bf31119e77f788033395" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
