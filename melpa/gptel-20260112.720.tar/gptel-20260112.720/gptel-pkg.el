;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260112.720"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "5027bb7d5b9c39dce4729ac83012353e9d1d6bec"
  :revdesc "5027bb7d5b9c"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
