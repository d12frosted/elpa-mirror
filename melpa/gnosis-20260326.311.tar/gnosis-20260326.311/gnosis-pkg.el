;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260326.311"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "9ac7fc3e23100f22276b94ed6876acc2406c8d35"
  :revdesc "9ac7fc3e2310"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
