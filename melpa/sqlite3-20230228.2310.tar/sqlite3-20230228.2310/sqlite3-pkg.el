(define-package "sqlite3" "20230228.2310" "Direct access to the core SQLite3 API"
  '((emacs "25.1"))
  :commit "50b814063bef617028e4ace4e2315e5d29ed62b9" :authors
  '(("Y. N. Lo" . "gordonynlo@yahoo.com"))
  :maintainer
  '("Y. N. Lo" . "gordonynlo@yahoo.com")
  :keywords
  '("comm" "data" "sql")
  :url "https://github.com/pekingduck/emacs-sqlite3-api")
;; Local Variables:
;; no-byte-compile: t
;; End:
