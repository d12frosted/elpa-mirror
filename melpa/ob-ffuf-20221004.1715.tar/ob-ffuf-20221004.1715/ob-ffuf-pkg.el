(define-package "ob-ffuf" "20221004.1715" "Babel functions for ffuf"
  '((emacs "28.1"))
  :commit "5310a3e766a252ac34f8cb2307c4e48e982f5611" :authors
  '(("Daniel Tschertkow"))
  :maintainer
  '("Daniel Tschertkow" . "daniel.tschertkow@posteo.de")
  :keywords
  '("comm" "tools")
  :url "https://github.com/daniel-ts/ob-ffuf")
;; Local Variables:
;; no-byte-compile: t
;; End:
