(define-package "lab" "20231106.1250" "An interface for GitLab"
  '((emacs "27.1")
    (memoize "1.1")
    (request "0.3.2")
    (s "1.10.0")
    (f "0.20.0"))
  :commit "c79bf975ad799e11ead0e2f2ca909222044b35cd" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/lab.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
