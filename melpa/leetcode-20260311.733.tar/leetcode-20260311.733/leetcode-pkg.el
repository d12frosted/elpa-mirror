;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leetcode" "20260311.733"
  "An leetcode client."
  '((emacs "28.1")
    (s     "1.13.0")
    (aio   "1.0")
    (log4e "0.3.3"))
  :url "https://github.com/kaiwk/leetcode.el"
  :commit "9ce922cece6a31fe2036fb34583f538486765471"
  :revdesc "9ce922cece6a"
  :keywords '("extensions" "tools")
  :authors '(("Wang Kai" . "kaiwkx@gmail.com"))
  :maintainers '(("Wang Kai" . "kaiwkx@gmail.com")))
