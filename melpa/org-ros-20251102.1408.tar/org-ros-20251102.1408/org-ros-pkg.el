;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ros" "20251102.1408"
  "Rahul's Org-Mode Screenshot."
  '((emacs "24.1"))
  :url "https://github.com/LionyxML/ros"
  :commit "f212ede14350b339ce5e41b0a0b9ca13482ceb10"
  :revdesc "f212ede14350"
  :authors '(("Rahul Martim Juliato" . "rahul.juliato@gmail.com"))
  :maintainers '(("Rahul Martim Juliato" . "rahul.juliato@gmail.com")))
