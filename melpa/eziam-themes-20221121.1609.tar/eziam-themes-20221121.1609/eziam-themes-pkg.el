(define-package "eziam-themes" "20221121.1609" "The mostly monochrome Eziam theme family." 'nil :commit "7fba717293072d0afdbd1c45351ddf47b26b3064" :authors
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainer
  '("Thibault Polge" . "thibault@thb.lt")
  :keywords
  '("faces")
  :url "https://github.com/thblt/eziam-theme-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
