;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "20261012.825"
  "Reveal Markdown source at point."
  '((emacs               "31.1")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "0c44f3e842c1af026209beb2349a730df7a69cfa"
  :revdesc "0c44f3e842c1"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
