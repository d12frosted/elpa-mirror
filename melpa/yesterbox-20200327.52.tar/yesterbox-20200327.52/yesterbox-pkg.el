;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yesterbox" "20200327.52"
  "Count number of inbox messages by day."
  '((emacs "24.3"))
  :url "https://github.com/sje30/yesterbox"
  :commit "7d890ab3f012b1a48a0e8e437f5fcaeba9825fdc"
  :revdesc "7d890ab3f012"
  :keywords '("mail")
  :authors '(("Stephen J. Eglen" . "sje30@cam.ac.uk"))
  :maintainers '(("Stephen J. Eglen" . "sje30@cam.ac.uk")))
