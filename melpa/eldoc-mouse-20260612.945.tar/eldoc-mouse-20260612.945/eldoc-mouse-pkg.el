;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20260612.945"
  "Display documentation for mouse hover."
  '((emacs    "27.1")
    (posframe "1.5.1")
    (eglot    "1.23"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "6b7bddc4b16c0b3d6f4203e03e659b5211cab516"
  :revdesc "6b7bddc4b16c"
  :keywords '("tools" "languages" "convenience" "mouse" "hover")
  :authors '(("Huang Feiyu" . "sibadake1@163.com"))
  :maintainers '(("Huang Feiyu" . "sibadake1@163.com")))
