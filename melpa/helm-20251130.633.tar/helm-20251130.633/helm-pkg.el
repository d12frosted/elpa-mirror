;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251130.633"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "8ac2c3f3dc7431f51fc840e698f811d0fce41895"
  :revdesc "8ac2c3f3dc74"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
