;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260403.1210"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "73936fe0fc314519ab3a15b59ab1d8557df16a4e"
  :revdesc "73936fe0fc31"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
