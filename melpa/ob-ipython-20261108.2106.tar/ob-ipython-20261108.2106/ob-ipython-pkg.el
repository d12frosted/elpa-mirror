;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ipython" "20261108.2106"
  "Org-babel functions for IPython evaluation."
  '((s     "1.9.0")
    (dash  "2.18.0")
    (f     "0.17.2")
    (emacs "24"))
  :url "http://www.gregsexton.org"
  :commit "6369561e5ad0a58cebaf6609cea61a40743f0d57"
  :revdesc "6369561e5ad0"
  :keywords '("literate programming" "reproducible research")
  :authors '(("Greg Sexton" . "gregsexton@gmail.com"))
  :maintainers '(("Greg Sexton" . "gregsexton@gmail.com")))
