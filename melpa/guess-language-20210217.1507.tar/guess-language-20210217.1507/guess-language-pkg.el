(define-package "guess-language" "20210217.1507" "Robust automatic language detection"
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "e7decda098ee6819b37bacd958260c7c789962cb" :authors
  '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainer
  '("Titus von der Malsburg" . "malsburg@posteo.de")
  :keywords
  '("wp")
  :url "https://github.com/tmalsburg/guess-language.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
