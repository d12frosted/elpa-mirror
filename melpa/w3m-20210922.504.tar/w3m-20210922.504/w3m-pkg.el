(define-package "w3m" "20210922.504" "an Emacs interface to w3m" 'nil :commit "ea36959297d44259395fab042aa8093b5aee8be1" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
