(define-package "orgtbl-aggregate" "20210811.1427" "Create an aggregated Org table from another one" 'nil :commit "e81452e1dd3db5e7601b40ffa57243473ce892e7" :keywords
  '("org" "table" "aggregation" "filtering"))
;; Local Variables:
;; no-byte-compile: t
;; End:
