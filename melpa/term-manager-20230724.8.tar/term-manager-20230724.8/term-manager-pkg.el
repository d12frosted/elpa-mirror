(define-package "term-manager" "20230724.8" "Contextual terminal management"
  '((dash "2.12.0")
    (emacs "24.4"))
  :commit "c6da6a36d30525cf054f4d78912957c2f1952197" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("terminals" "tools")
  :url "https://www.github.com/IvanMalison/term-manager")
;; Local Variables:
;; no-byte-compile: t
;; End:
