;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260827.856"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "833b2a8031a22068c0528a1f7600926b7359154a"
  :revdesc "833b2a8031a2")
