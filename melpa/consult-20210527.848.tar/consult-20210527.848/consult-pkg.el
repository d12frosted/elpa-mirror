(define-package "consult" "20210527.848" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b43dfe24205283b5a13985bdb332898647281d16" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
