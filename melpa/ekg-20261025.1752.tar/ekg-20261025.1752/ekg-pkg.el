;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261025.1752"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "f2aa58cffdb3d435175a0a48dce1d89c38982d15"
  :revdesc "f2aa58cffdb3"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
