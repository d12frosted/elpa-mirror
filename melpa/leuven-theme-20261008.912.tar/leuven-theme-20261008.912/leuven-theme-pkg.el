;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "20261008.912"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "5cedf3c02dd33386c74ef3de3fb37ac0ddee85be"
  :revdesc "5cedf3c02dd3"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
