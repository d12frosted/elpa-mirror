;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260618.1130"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "dba2073cd6e899dd826e95d3ce6d26b6846e3f1b"
  :revdesc "dba2073cd6e8"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
