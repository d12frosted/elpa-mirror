(define-package "inkpot-theme" "20230610.1400" "A port of vim's inkpot theme"
  '((emacs "24.1"))
  :commit "23fe1dffc1b71f0593ca3b97807a6bcfcdf52417" :authors
  '(("Sarah Iovan" . "sarah@hwaetageek.com")
    ("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Sarah Iovan" . "sarah@hwaetageek.com"))
  :maintainer
  '("Sarah Iovan" . "sarah@hwaetageek.com")
  :url "https://codeberg.org/ideasman42/emacs-inkpot-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
