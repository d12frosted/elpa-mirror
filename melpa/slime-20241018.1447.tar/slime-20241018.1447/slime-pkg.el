;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20241018.1447"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "52c7920c27c820e6b1ebff30912eeaa05b6b4228"
  :revdesc "52c7920c27c8"
  :keywords '("languages" "lisp" "slime"))
