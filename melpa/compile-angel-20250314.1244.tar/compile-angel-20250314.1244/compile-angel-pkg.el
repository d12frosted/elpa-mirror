;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20250314.1244"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "48337ef5c6a931febd247abbac0173c7408010fc"
  :revdesc "48337ef5c6a9"
  :keywords '("convenience"))
