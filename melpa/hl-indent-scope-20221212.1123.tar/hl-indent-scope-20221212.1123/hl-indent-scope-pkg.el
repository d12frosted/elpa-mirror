(define-package "hl-indent-scope" "20221212.1123" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "8f84289ba2f9b2c90d24c1892b825bb12f047811" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
