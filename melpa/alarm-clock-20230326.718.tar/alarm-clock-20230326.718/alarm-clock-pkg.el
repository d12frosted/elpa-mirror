(define-package "alarm-clock" "20230326.718" "Alarm Clock"
  '((emacs "24.4"))
  :commit "bcd9158f18ead2aa25f10a48e4a38e2c3ed64217" :authors
  '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainers
  '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainer
  '("Steve Lemuel" . "wlemuel@hotmail.com")
  :keywords
  '("calendar" "tools" "convenience")
  :url "https://github.com/wlemuel/alarm-clock")
;; Local Variables:
;; no-byte-compile: t
;; End:
