;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern" "20251216.826"
  "Modern looks for Org."
  '((emacs  "29.1")
    (org    "9.6")
    (compat "30"))
  :url "https://github.com/minad/org-modern"
  :commit "b5f8475af31ea97af70bb93bb9895059b803bf10"
  :revdesc "b5f8475af31e"
  :keywords '("outlines" "hypermedia" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
