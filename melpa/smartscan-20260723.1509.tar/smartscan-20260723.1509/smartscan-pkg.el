;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smartscan" "20260723.1509"
  "Jumps between other symbols found at point."
  ()
  :url "https://github.com/mickeynp/smart-scan"
  :commit "b330b21c4f6f1785d1da0f74031a2ac3bbc6da55"
  :revdesc "b330b21c4f6f"
  :keywords '("extensions")
  :authors '(("Mickey Petersen" . "mickey@masteringemacs.org"))
  :maintainers '(("Mickey Petersen" . "mickey@masteringemacs.org")))
