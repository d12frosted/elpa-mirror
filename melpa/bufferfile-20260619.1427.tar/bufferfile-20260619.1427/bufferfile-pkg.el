;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20260619.1427"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "a18c09436284d58c73bdd4d15966d804d29fd526"
  :revdesc "a18c09436284"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
