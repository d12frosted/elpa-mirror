(define-package "modus-themes" "20220423.340" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "f2445a43d845adfb65485a02e653cb4844574983" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
