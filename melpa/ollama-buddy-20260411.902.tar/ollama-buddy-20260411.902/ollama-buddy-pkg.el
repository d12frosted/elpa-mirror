;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260411.902"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral DeepSeek OpenRouter Support."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "17e5c6f8b2b341b4afcb3d6158202469df95fe79"
  :revdesc "17e5c6f8b2b3"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
