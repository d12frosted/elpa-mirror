(define-package "modus-themes" "20210224.548" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "90370d0443edb7b6ca2bb9a13ab0afa134b989e5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
