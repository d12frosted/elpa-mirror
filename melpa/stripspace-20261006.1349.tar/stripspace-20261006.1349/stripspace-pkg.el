;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20261006.1349"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "3c720ff4b674bb4b489f993f8e0681d1ffbbab8c"
  :revdesc "3c720ff4b674"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
