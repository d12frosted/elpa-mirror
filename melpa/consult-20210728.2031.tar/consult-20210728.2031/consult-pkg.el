(define-package "consult" "20210728.2031" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "2730b2d9719b6f4c7e74a5bd09ed2a73547aa170" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
