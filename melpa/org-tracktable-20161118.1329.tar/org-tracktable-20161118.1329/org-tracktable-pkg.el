;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tracktable" "20161118.1329"
  "Track your writing progress in an org-table."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/tty-tourist/org-tracktable"
  :commit "8e0e60a582a034bd66d5efb72d513140b7d4d90a"
  :revdesc "8e0e60a582a0"
  :keywords '("org" "writing")
  :authors '(("tty-tourist" . "andreasrasholm@protonmail.com"))
  :maintainers '(("tty-tourist" . "andreasrasholm@protonmail.com")))
