;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edna-theme" "20260213.1757"
  "A dark, Edna-inspired theme."
  '((emacs "26.1"))
  :url "https://codeberg.org/golanv/edna-theme"
  :commit "84ba8e98f7ed623f8cbdf609913f7499ad04dfac"
  :revdesc "84ba8e98f7ed"
  :keywords '("faces" "theme")
  :authors '(("golanv" . "https://codeberg.org/golanv"))
  :maintainers '(("golanv" . "https://codeberg.org/golanv")))
