;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260917.1055"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "f80a74fdea1734962ee91678ae68b6bcd3d1c450"
  :revdesc "f80a74fdea17"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
