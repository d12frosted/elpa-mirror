(define-package "popper" "20230905.2050" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "ecc01a46b0aebf282fadabf70d14fe6f0b8e34ba" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
