(define-package "tempel-collection" "20230916.1319" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "29.1"))
  :commit "0e02b36a33555c6f14f4cff85260a97d9beb6fea" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
