;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260829.155"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5d63bef0700e29e8c85d0bad73ca2da8233dd47a"
  :revdesc "5d63bef0700e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
