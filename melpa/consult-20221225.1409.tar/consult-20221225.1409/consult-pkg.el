(define-package "consult" "20221225.1409" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "7c514c0a2414347c4cd0482a691371625a8a1c53" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
