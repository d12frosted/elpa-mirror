;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20250215.1712"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.22.0")
    (spinner   "1.7.4")
    (transient "0.7")
    (compat    "29.1")
    (posframe  "1.4.0"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "1e3b3210f0b553e7158065116a4d84adc7f3f1bd"
  :revdesc "1e3b3210f0b5"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
