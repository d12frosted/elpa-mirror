;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260117.1243"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a2385cccbaa956e2bad8889d4381111eb3e7d8bc"
  :revdesc "a2385cccbaa9")
