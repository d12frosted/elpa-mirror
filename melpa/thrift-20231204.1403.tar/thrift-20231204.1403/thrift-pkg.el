(define-package "thrift" "20231204.1403" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "f68ab56df1141ddaf2fa16074041afc62f4078a2" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
