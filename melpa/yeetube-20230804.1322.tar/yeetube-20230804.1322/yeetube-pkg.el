(define-package "yeetube" "20230804.1322" "YouTube/Invidious Front End"
  '((emacs "27.2"))
  :commit "2364a3e120b461fc6f5fbbf91cd0ab1ae805be15" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
