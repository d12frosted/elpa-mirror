(define-package "chronometrist-key-values" "20210603.1656" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "5c5b7fc5e72e2322af2cac14745c7adaab1d56cf" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
