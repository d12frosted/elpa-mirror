;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20251106.1200"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "ba02ef93f054c0df09f97b460e0cb87f264074ea"
  :revdesc "ba02ef93f054"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
