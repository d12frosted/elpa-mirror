(define-package "racket-mode" "20210831.1427" "Racket editing, REPL, and more"
  '((emacs "25.1")
    (faceup "0.0.2")
    (pos-tip "20191127.1028"))
  :commit "75af1ec5a8b5767f2b7a7da2dc6bd4a2b4612ef4" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
