(define-package "jazz-theme" "20230808.1440" "A warm color theme for Emacs 24+." 'nil :commit "10c4944e1d6e5e02bda1963f5882d4a216e2a119" :authors
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainers
  '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainer
  '("Roman Parykin" . "donderom@ymail.com")
  :url "https://github.com/donderom/jazz-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
