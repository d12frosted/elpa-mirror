;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swift-ts-mode" "20250115.1846"
  "Major mode for Swift based on tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/rechsteiner/swift-ts-mode"
  :commit "9bf81ced0faa594b5b9f773c2cc73cb3672f3059"
  :revdesc "9bf81ced0faa"
  :keywords '("swift" "languages" "tree-sitter"))
