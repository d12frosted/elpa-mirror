(define-package "mkdown" "20140517.1418" "Pretty Markdown previews based on mkdown.com"
  '((markdown-mode "2.0"))
  :commit "8e23de82719af6c5b53b52b3308a02b3a1fb872e" :authors
  (("Andrew Tulloch"))
  :maintainer
  ("Andrew Tulloch")
  :keywords
  ("markdown")
  :url "https://github.com/ajtulloch/mkdown.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
