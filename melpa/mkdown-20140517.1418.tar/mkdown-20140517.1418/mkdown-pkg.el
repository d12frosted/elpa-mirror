;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mkdown" "20140517.1418"
  "Pretty Markdown previews based on mkdown.com."
  '((markdown-mode "2.0"))
  :url "https://github.com/ajtulloch/mkdown.el"
  :commit "8e23de82719af6c5b53b52b3308a02b3a1fb872e"
  :revdesc "8e23de82719a"
  :keywords '("markdown"))
