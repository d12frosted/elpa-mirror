;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel-collection" "20260901.750"
  "Collection of templates for Tempel."
  '((tempel "0.5")
    (emacs  "31.1"))
  :url "https://github.com/Crandel/tempel-collection"
  :commit "a63ac2d0c50bcc879fb4bd8e72eb0234987f1af8"
  :revdesc "a63ac2d0c50b"
  :keywords '("tools")
  :authors '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
             ("Max Penet" . "mpenetr@s-exp.com")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
                 ("Max Penet" . "mpenetr@s-exp.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
