;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-toggle" "20260511.139"
  "Toggle Evil and God Mode."
  '((emacs    "28.1")
    (evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/jam1015/evil-god-toggle"
  :commit "ae27036ffe041cb8baeb4cfa9a33c110bceed29f"
  :revdesc "ae27036ffe04"
  :keywords '("convenience" "emulation" "evil" "god-mode")
  :authors '(("Jordan Mandel" . "jordan.mandel@live.com"))
  :maintainers '(("Jordan Mandel" . "jordan.mandel@live.com")))
