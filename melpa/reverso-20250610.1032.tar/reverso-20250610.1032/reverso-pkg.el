;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reverso" "20250610.1032"
  "Translation, grammar checking, context search."
  '((emacs     "27.1")
    (transient "0.3.7")
    (request   "0.3.2"))
  :url "https://github.com/SqrtMinusOne/reverso.el"
  :commit "40ed3d83c4f04c39e05d69d84595761ae2956a64"
  :revdesc "40ed3d83c4f0"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
