;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20261121.1727"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "dfdfeea5138fb5828c5365496dac610392b4dabd"
  :revdesc "dfdfeea5138f"
  :keywords '("tools" "convenience" "text")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
