(define-package "titlecase" "20220109.2137" "Title-case phrases"
  '((emacs "25.1"))
  :commit "5c60eeedd259bf137544b5711f767349c2734da1" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://github.com/duckwork/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
