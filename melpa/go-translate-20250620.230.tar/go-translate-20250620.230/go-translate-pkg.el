;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250620.230"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "5c74e8cebffe1631e98cbb2325b4b713e3c11113"
  :revdesc "5c74e8cebffe"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
