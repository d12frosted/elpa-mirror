(define-package "dirvish" "20220117.1641" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "d4745e67161733087bdf5fe8114532dddadb7520" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
