;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260708.1951"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "fd2c5485a10dcc992fd1f5c5794e77507c265f5d"
  :revdesc "fd2c5485a10d")
