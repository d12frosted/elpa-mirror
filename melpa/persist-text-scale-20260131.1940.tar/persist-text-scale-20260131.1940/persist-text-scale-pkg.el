;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20260131.1940"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "3cb4fddcfec089b3f76404fe35193e392954aff9"
  :revdesc "3cb4fddcfec0"
  :keywords '("convenience"))
