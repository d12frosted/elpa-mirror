;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "20260215.2013"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "765a697d17dbd969c1bb5551f14c6d0524439097"
  :revdesc "765a697d17db"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
