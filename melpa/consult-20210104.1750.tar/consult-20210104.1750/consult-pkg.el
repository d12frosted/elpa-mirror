(define-package "consult" "20210104.1750" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "999c8236cc11b9f53548f1bb997060d1a2e7a76a" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
