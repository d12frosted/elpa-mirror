(define-package "tree-sitter-langs" "20210805.303" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.15.0"))
  :commit "83c24815748be88288275371f6512116903a55ec" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/tree-sitter-langs")
;; Local Variables:
;; no-byte-compile: t
;; End:
