(define-package "consult" "20210321.1021" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "8b897256172ea8b84f4e2a60bcd898aacfdcde27" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
