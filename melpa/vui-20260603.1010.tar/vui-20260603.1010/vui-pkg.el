;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260603.1010"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "417729eeb09165123d28ea6b56091db7a07cd62e"
  :revdesc "417729eeb091"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
