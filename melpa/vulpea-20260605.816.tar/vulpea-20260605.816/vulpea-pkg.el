;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260605.816"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "36914ed93cb8c61fac989c88b86cf8ecdd39c359"
  :revdesc "36914ed93cb8"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
