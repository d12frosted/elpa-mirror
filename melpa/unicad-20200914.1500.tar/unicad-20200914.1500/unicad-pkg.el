(define-package "unicad" "20200914.1500" "An elisp port of Mozilla Universal Charset Auto Detector"
  '((emacs "24")
    (nadvice "0.3"))
  :commit "a5fd4e326a0607acc3776c11f41826e60b6486c6" :authors
  '(("Qichen Huang" . "unicad.el@gmail.com"))
  :maintainers
  '(("Qichen Huang" . "unicad.el@gmail.com"))
  :maintainer
  '("Qichen Huang" . "unicad.el@gmail.com")
  :keywords
  '("i18n")
  :url "https://github.com/ukari/unicad")
;; Local Variables:
;; no-byte-compile: t
;; End:
