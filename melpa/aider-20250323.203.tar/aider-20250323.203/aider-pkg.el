;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250323.203"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "cd644707bd4c4f1806f94c179352e078f3aa311b"
  :revdesc "cd644707bd4c"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
