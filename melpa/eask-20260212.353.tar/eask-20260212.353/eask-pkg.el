;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20260212.353"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "8fbe9e69f2654b3e297c1d263fa233c9e454ff34"
  :revdesc "8fbe9e69f265"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
