;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-server" "20261125.1012"
  "Speaks HTTP for you."
  '((emacs "30.1"))
  :url "https://codeberg.org/martenlienen/http-server.el"
  :commit "bc1f8836a6d5f6535caced1ce58f88a47f9e178b"
  :revdesc "bc1f8836a6d5"
  :keywords '("comm")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
