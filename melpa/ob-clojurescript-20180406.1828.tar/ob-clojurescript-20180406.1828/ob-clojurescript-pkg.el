;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-clojurescript" "20180406.1828"
  "Org-babel functions for ClojureScript evaluation."
  '((emacs "24.4")
    (org   "9.0"))
  :url "https://gitlab.com/statonjr/ob-clojurescript"
  :commit "17ee1558aa94c7b0246fd03f684884122806cfe7"
  :revdesc "17ee1558aa94"
  :keywords '("literate programming" "reproducible research"))
