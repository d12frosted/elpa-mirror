(define-package "consult" "20231023.1543" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "fa249d5dd7212e5ae1fa51c086d8f1197d738ef4" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
