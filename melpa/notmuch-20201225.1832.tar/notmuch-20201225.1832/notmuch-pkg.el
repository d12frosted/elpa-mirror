(define-package "notmuch" "20201225.1832" "run notmuch within emacs" 'nil :commit "0251cab3ab5021bd085fcbd8602c2f45ee4cdee3" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
