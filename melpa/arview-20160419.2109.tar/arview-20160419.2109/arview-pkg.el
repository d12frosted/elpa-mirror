;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arview" "20160419.2109"
  "Extract and view archives in the temporary directory."
  ()
  :url "https://github.com/afainer/arview"
  :commit "5437b4221b64b238c273a651d4792c577dba6d45"
  :revdesc "5437b4221b64"
  :keywords '("files")
  :authors '(("Andrey Fainer" . "fandrey@gmx.com"))
  :maintainers '(("Andrey Fainer" . "fandrey@gmx.com")))
