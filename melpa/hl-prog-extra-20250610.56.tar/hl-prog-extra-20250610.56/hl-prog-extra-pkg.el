;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-prog-extra" "20250610.56"
  "Customizable highlighting for source-code."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra"
  :commit "f9ca89939686493ee28c8cb0650848da2cb93774"
  :revdesc "f9ca89939686"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
