;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260701.826"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1a2e0d8af6931951df0f665052c6be3bc23ff556"
  :revdesc "1a2e0d8af693")
