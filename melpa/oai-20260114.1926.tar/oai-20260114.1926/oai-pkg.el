;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260114.1926"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "d0fb2b1bca84a397026301aeb8e8b4ff3f6f375d"
  :revdesc "d0fb2b1bca84"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
