;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-ack" "20140223.1732"
  "A front-end for ack."
  ()
  :url "http://nschum.de/src/emacs/full-ack/"
  :commit "8345753e9569dabf6426a837f29387557e32f2af"
  :revdesc "8345753e9569"
  :keywords '("tools" "matching")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
