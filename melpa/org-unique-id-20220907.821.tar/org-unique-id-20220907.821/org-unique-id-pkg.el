;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-unique-id" "20220907.821"
  "Create unique IDs for org headers."
  '((emacs "25.1")
    (org   "9.3"))
  :url "https://labs.phundrak.com/phundrak/org-unique-id"
  :commit "c3a0908ff2123c8786735f3c6f35e905efea2ef6"
  :revdesc "c3a0908ff212"
  :keywords '("convenience")
  :authors '(("Lucien Cartier-Tilet" . "lucien@phundrak.com"))
  :maintainers '(("Lucien Cartier-Tilet" . "lucien@phundrak.com")))
