(define-package "lsp-cfn" "20220707.824" "LSP integration for cfn-lsp-extra"
  '((emacs "27.0")
    (lsp-mode "8.0.0")
    (yaml-mode "0.0.15"))
  :commit "d3ab1c4187192bd9c658cfdf59d086ae47c51f25" :authors
  '(("Laurence Warne"))
  :maintainer
  '("Laurence Warne")
  :url "https://github.com/LaurenceWarne/lsp-cfn.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
