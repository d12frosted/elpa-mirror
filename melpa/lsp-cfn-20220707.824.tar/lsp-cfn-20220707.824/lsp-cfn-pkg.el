(define-package "lsp-cfn" "20220707.824" "LSP integration for cfn-lsp-extra"
  '((emacs "27.0")
    (lsp-mode "8.0.0")
    (yaml-mode "0.0.15"))
  :commit "8228864e0b16f7107300fb6b8ba595bb84f016fd" :authors
  '(("Laurence Warne"))
  :maintainer
  '("Laurence Warne")
  :url "https://github.com/LaurenceWarne/lsp-cfn.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
