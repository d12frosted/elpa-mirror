;;; hl-prog-extra-preset-lua-mode.el --- Lua preset -*- lexical-binding: t -*-
;; URL: https://gitlab.com/ideasman42/emacs-hl-prog-extra
;; Version: 0.1
;; Package-Requires: ((emacs "26.2"))

;;; Commentary:
;; Preset for Lua.

;;; Code:

;;;###autoload
(defun hl-prog-extra-preset-lua-mode (&rest args)
  "Presets for `lua-mode' with optional ARGS keyword arguments.
:no-string-escape
  Don't use escape strings."
  (let
    ( ;; Keywords.
      (no-string-escape nil)

      (result (list)))

    ;; Parse keywords.
    (while args
      (let ((arg-current (pop args)))
        (cond
          ((symbolp arg-current)
            (unless args
              (error "Keyword argument %S has no value!" arg-current))
            (let ((v (pop args)))
              (pcase arg-current
                (:no-string-escape
                  (unless (memq v (list nil t))
                    (error ":no-string-escape expected a boolean"))
                  (setq no-string-escape v))
                (_ (error "Unknown argument %S" arg-current)))))
          (t
            (error
              "Arguments must be property pairs, found %S = %S"
              (type-of arg-current)
              arg-current)))))

    (unless no-string-escape
      ;; See: http://www.lua.org/manual/5.3/manual.html
      (push
        (list
          (concat
            ;; Back-slash.
            "\\\\"
            ;; Group.
            "\\("
            ;; "\n" and similar single escape characters.
            "[abfnrtv\"\\\\]\\|"
            ;; "\x" number.
            "x[0-9a-fA-F]+\\|"
            ;; "\u" unicode.
            "[uU][0-9a-fA-F]+\\|"
            ;; "\x000".
            "[0-9]+"
            ;; End group.
            "\\)")
          0 'string 'escape-glyph)
        result))

    (printf "RUNNING\n")

    result))

(provide 'hl-prog-extra-preset-lua-mode)
;;; hl-prog-extra-preset-lua-mode.el ends here
