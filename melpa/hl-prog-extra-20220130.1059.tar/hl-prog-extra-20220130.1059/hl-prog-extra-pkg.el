(define-package "hl-prog-extra" "20220130.1059" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "457b5fe902184387f486bdc1dba1d44faf8692fa" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
