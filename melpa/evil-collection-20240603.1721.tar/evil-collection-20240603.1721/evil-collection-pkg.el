(define-package "evil-collection" "20240603.1721" "A set of keybindings for Evil mode"
  '((emacs "26.3")
    (evil "1.2.13")
    (annalist "1.0"))
  :commit "12fd87b631eea6b9b9be96456f39a03f0864dd3c" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainers
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("evil" "tools")
  :url "https://github.com/emacs-evil/evil-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
