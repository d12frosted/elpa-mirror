(define-package "proof-general" "20210317.510" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.5"))
  :commit "56ee4ebc97e77da7d61eaa7b00580bf4ef5b87d9" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
