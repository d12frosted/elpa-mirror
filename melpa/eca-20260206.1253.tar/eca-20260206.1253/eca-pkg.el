;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260206.1253"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "71e651e8a3b49f9660ab33749e43e8f146dcbfe0"
  :revdesc "71e651e8a3b4"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
