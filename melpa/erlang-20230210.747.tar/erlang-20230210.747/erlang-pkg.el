(define-package "erlang" "20230210.747" "Erlang major mode"
  '((emacs "24.1"))
  :commit "3e19219075e56801eead1f14a7438f3769d3ed37" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
