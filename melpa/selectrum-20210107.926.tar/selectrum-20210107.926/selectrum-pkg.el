(define-package "selectrum" "20210107.926" "Easily select item from list"
  '((emacs "25.1"))
  :commit "ec1f60c915965bf8205efbd6045caf4a9764b366" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
