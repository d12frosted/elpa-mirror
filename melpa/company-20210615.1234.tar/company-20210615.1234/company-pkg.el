(define-package "company" "20210615.1234" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "8b3fdf8815627b9bc3391c91e01dfdc7e344a1b8" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
