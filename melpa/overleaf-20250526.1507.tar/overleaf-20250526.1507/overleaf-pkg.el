;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250526.1507"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "62cb59e49c3914e0414a74b4ba77e02b15602522"
  :revdesc "62cb59e49c39"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
