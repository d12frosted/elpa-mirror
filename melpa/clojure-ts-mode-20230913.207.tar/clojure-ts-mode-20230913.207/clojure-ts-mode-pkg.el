(define-package "clojure-ts-mode" "20230913.207" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "5f16fb8dbcaf9476cc6d5baab958b730cb60e854" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
