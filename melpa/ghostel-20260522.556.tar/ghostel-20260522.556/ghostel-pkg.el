;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260522.556"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "563cdd014d4ce6da5cfad2ba7e9cc17908adb761"
  :revdesc "563cdd014d4c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
