;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260414.1742"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "63ecddd5fb0e93dcdc75d36723eea1a5d8f82fbc"
  :revdesc "63ecddd5fb0e"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
