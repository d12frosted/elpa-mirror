;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tubestatus" "20250112.1642"
  "Get the London Tube service status."
  '((emacs   "26.1")
    (request "0.3.2"))
  :url "https://github.com/smallwat3r/tubestatus.el"
  :commit "3d7bcfb12823c0084190b1a02bbeed3768db2bff"
  :revdesc "3d7bcfb12823"
  :authors '(("Matthieu Petiteau" . "matt@smallwat3r.com"))
  :maintainers '(("Matthieu Petiteau" . "matt@smallwat3r.com")))
