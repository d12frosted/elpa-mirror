(define-package "consult" "20240323.1534" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "e222aacb656161233931c4ff27d7625f31f3aaf9" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
