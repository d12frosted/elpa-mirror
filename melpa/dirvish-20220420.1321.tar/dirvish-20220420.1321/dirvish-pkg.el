(define-package "dirvish" "20220420.1321" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "7a0e47365482700bce2884790c2970b493776838" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
