;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251101.512"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "16c2c667c4e65a242ca69bcd536b9a902dabae6f"
  :revdesc "16c2c667c4e6"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
