;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250626.1512"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "5680dc038a0634ece05632633dfa8d720074e3df"
  :revdesc "5680dc038a06"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
