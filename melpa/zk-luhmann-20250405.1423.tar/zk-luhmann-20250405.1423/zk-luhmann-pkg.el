;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-luhmann" "20250405.1423"
  "Support for Luhmann-style IDs in zk."
  '((emacs    "25.1")
    (zk       "0.7")
    (zk-index "0.10"))
  :url "https://github.com/localauthor/zk-luhmann"
  :commit "54072378a49c5003d06e9f299f93c286b1e178af"
  :revdesc "54072378a49c"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
