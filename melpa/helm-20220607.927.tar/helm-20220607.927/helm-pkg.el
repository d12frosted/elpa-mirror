(define-package "helm" "20220607.927" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.4")
    (popup "0.5.3"))
  :commit "8387864d5a4e7393b0657d07ba2ce391de7bed21" :authors
  '(("Thierry Volpiatto "))
  :maintainer
  '("Thierry Volpiatto ")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
