(define-package "chronometrist" "20210104.526" "A time tracker with a nice interface"
  '((emacs "25.1")
    (dash "2.16.0")
    (seq "2.20")
    (s "1.12.0")
    (ts "0.2")
    (anaphora "1.0.4"))
  :commit "108cd3764476820735c00a059ae1218e13a3b897" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "https://github.com/contrapunctus-1/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
