;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-recent-headings" "20211011.1519"
  "Jump to recently used Org headings."
  '((emacs    "26.1")
    (org      "9.0.5")
    (dash     "2.18.0")
    (frecency "0.1")
    (s        "1.12.0"))
  :url "https://github.com/alphapapa/org-recent-headings"
  :commit "97418d581ea030f0718794e50b005e9bae44582e"
  :revdesc "97418d581ea0"
  :keywords '("hypermedia" "outlines" "org")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
