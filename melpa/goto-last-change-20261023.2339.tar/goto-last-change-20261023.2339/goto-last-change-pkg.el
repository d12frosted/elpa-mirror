;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-last-change" "20261023.2339"
  "Move point through buffer-undo-list positions."
  '((emacs "24.3"))
  :url "https://github.com/camdez/goto-last-change.el"
  :commit "f330d2793739ab7e7417b32c293eefa00bca4770"
  :revdesc "f330d2793739"
  :keywords '("convenience")
  :authors '(("Kevin Rodgers" . "ihs_4664@yahoo.com"))
  :maintainers '(("Kevin Rodgers" . "ihs_4664@yahoo.com")))
