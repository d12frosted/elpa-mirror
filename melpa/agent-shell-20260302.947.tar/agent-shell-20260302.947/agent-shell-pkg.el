;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260302.947"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.86.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "be00708ade589b8daefffcda71b8c6245c80ca56"
  :revdesc "be00708ade58")
