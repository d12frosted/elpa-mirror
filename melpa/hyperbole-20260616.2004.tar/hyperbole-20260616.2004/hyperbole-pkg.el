;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260616.2004"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "23650baba1f7ff0117a0ae8ed98b28f8cc7d5133"
  :revdesc "23650baba1f7"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
