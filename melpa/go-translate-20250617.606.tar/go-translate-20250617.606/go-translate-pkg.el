;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250617.606"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "dc3f61a03b04dc8d4ccfcdf0872727088c25dd2f"
  :revdesc "dc3f61a03b04"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
