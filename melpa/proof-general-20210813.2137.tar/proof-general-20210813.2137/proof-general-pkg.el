(define-package "proof-general" "20210813.2137" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.5"))
  :commit "d64f5a10bc4747f04b4ae908f88c21ae7f452495" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
