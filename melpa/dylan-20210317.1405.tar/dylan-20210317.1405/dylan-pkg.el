(define-package "dylan" "20210317.1405" "Dylan editing modes"
  '((emacs "25.1"))
  :commit "c51cdb2d947494d8161a429134f9e9d23070a173" :url "https://opendylan.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
