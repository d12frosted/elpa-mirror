;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260205.228"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "81030b5012de1b92cce87d2e109955e164a6b013"
  :revdesc "81030b5012de"
  :keywords '("hypermedia"))
