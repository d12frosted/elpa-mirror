;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "20250422.1612"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "cb7c77b7f85e8f395c2051bc279147bad823be44"
  :revdesc "cb7c77b7f85e"
  :keywords '("convenience"))
