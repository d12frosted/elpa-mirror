(define-package "ivy" "20210722.1003" "Incremental Vertical completYon"
  '((emacs "24.5"))
  :commit "1642e208466ed320379b5dcb9b65e4f2ceca7357" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("matching")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
