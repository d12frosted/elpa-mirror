;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20250328.1727"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "f69ea38e577f7ee94d7e763439cbdb4bdc7d8ea9"
  :revdesc "f69ea38e577f"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
