;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20250624.1357"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.1")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "e508e65866168c178136e260a86790cd12343024"
  :revdesc "e508e6586616"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
