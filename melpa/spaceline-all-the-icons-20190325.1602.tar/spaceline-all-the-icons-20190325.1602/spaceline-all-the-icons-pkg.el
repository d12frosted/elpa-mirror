;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spaceline-all-the-icons" "20190325.1602"
  "A Spaceline theme using All The Icons."
  '((emacs         "24.4")
    (all-the-icons "2.6.0")
    (spaceline     "2.0.0")
    (memoize       "1.0.1"))
  :url "https://github.com/domtronn/spaceline-all-the-icons.el"
  :commit "5afd48c10f1bd42d9b9648c5e64596b72f3e9042"
  :revdesc "5afd48c10f1b"
  :keywords '("convenience" "lisp" "tools")
  :authors '(("Dominic Charlesworth" . "dgc336@gmail.com"))
  :maintainers '(("Dominic Charlesworth" . "dgc336@gmail.com")))
