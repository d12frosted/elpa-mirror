;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250620.703"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.16.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "a4ba93295f9b2a2c7df8277dc4aed743d2794974"
  :revdesc "a4ba93295f9b"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
