;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tp" "20260219.1435"
  "Utilities for transient menus that POST to an API."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://codeberg.org/martianh/tp.el"
  :commit "cef3fc2daefbbfc29ad02b7e1f39542b57c72fe8"
  :revdesc "cef3fc2daefb"
  :keywords '("convenience" "api" "requests")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
