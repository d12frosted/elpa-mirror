;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jekyll-modes" "20141117.1314"
  "Major modes (markdown and HTML) for authoring Jekyll content."
  '((polymode "0.2"))
  :url "https://github.com/fred-o/jekyll-modes"
  :commit "7cb10b50fd2883e3f7b10fdfd98f19f2f0b2381c"
  :revdesc "7cb10b50fd28"
  :keywords '("docs")
  :authors '(("Fredrik Appelberg" . "fredrik@milgrim.local"))
  :maintainers '(("Fredrik Appelberg" . "fredrik@milgrim.local")))
