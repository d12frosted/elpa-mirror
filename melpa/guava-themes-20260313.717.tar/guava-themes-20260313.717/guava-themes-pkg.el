;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260313.717"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "1da48d54a1cf4797319d23aef564862922f252e3"
  :revdesc "1da48d54a1cf"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
