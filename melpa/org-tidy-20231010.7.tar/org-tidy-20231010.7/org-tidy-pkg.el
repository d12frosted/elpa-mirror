(define-package "org-tidy" "20231010.7" "A minor mode to tidy org-mode buffers"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "39bd3322edb47336dad34e62a8476e5dee416d85" :authors
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainers
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainer
  '("Xuqing Jia" . "jxq@jxq.me")
  :keywords
  '("convenience" "org")
  :url "https://github.com/jxq0/org-tidy")
;; Local Variables:
;; no-byte-compile: t
;; End:
