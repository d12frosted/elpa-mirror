(define-package "spdx" "20221116.128" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "15253511b12375766644ecdfba31ba9449da0c91" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
