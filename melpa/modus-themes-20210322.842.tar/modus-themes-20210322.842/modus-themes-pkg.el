(define-package "modus-themes" "20210322.842" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "7572c604fa65d8b460c59119868e36f16ff9908b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
