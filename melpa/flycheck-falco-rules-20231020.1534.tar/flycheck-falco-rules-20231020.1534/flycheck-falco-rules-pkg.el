;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-falco-rules" "20231020.1534"
  "On-the-fly syntax checking for falco rules files."
  '((emacs     "24.3")
    (flycheck  "0.25")
    (let-alist "1.0.1"))
  :url "https://github.com/falcosecurity/flycheck-falco-rules"
  :commit "4bdc576abb13569354281badeaafe4abeee7fb3d"
  :revdesc "4bdc576abb13"
  :keywords '("tools" "convenience"))
