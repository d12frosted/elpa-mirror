;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250712.1501"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "3da7b5dc980c2f7541fea129e3bc8d8749bac351"
  :revdesc "3da7b5dc980c"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
