(define-package "modus-themes" "20230421.1024" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "b3f39e8d10cd18beb33190629821c2980703aa82" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
