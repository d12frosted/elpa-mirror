;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "named-timer" "20181120.2224"
  "Simplified timer management for Emacs Lisp."
  '((emacs "24.4"))
  :url "https://github.com/DarwinAwardWinner/emacs-named-timer"
  :commit "670b81e3eddef2e7353a4eedc9553a85306445db"
  :revdesc "670b81e3edde"
  :keywords '("tools"))
