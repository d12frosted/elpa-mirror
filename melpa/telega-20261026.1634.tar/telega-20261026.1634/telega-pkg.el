;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20261026.1634"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "9c4f2f308a93963e8273858fc6bbbd9c1eb51a06"
  :revdesc "9c4f2f308a93"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
