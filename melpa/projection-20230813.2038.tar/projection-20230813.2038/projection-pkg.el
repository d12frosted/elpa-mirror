(define-package "projection" "20230813.2038" "Project type support for `project'"
  '((emacs "29")
    (project "0.9.8")
    (compat "29.1.4.1"))
  :commit "35dc6038e0e94c31fff0f0737579e697a1a4b383" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
