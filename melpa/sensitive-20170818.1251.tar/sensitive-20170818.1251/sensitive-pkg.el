;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sensitive" "20170818.1251"
  "A dead simple way to load sensitive information."
  '((emacs     "24")
    (sequences "0.1.0"))
  :url "https://github.com/timvisher/sensitive.el"
  :commit "69dd6125a41d8b55f4b6ba61daa4d1aa1f716fa8"
  :revdesc "69dd6125a41d"
  :keywords '("convenience")
  :authors '(("Tim Visher" . "tim.visher@gmail.com"))
  :maintainers '(("Tim Visher" . "tim.visher@gmail.com")))
