;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-at-point" "20251216.111"
  "Diff navigation."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-at-point"
  :commit "9c1617f0fba88c1f7daef78276c86d4447c99d48"
  :revdesc "9c1617f0fba8"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
