;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250312.433"
  "Interact with Aider: AI pair programming made simple."
  '((emacs     "26.1")
    (transient "0.3.0")
    (magit     "2.1.0")
    (helm      "3.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "3f6c1a3dd53b284d00c441c11592a7a46aed68f1"
  :revdesc "3f6c1a3dd53b"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
