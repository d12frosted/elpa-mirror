;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "20260202.1853"
  "IDE features made available out of the box."
  '((emacs "26.1"))
  :url "https://forge.tedomum.net/hjuvi/eide"
  :commit "ea10bf1b3727087e78921a146a1d7d0bcaf4f8a5"
  :revdesc "ea10bf1b3727"
  :authors '(("Cédric Marie" . "hjuvi@tedomum.fr"))
  :maintainers '(("Cédric Marie" . "hjuvi@tedomum.fr")))
