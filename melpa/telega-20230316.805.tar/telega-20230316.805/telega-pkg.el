(define-package "telega" "20230316.805" "Telegram client (unofficial)"
  '((emacs "27.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "0c23da925e1b5561d1e05ceab2aa401145c3a151" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
