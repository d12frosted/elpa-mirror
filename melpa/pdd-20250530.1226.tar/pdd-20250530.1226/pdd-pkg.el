;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250530.1226"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "22f6dc2bf45d646cef79c0ee6acc80553b100b0a"
  :revdesc "22f6dc2bf45d"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
