;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "20241103.1542"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "https://github.com/szermatt/visual-replace"
  :commit "fd37dd83ad15296119330969e3e85cb7fc22a4bb"
  :revdesc "fd37dd83ad15"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
