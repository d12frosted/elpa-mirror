;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fix-input" "20260802.956"
  "Make input methods play nicely with alternative layouts."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/fix-input"
  :commit "c68b830201e3910270f906cbe6784941aad6862b"
  :revdesc "c68b830201e3"
  :keywords '("convenience" "input")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
