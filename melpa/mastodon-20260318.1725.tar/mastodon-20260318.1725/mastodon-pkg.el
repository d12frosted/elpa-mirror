;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260318.1725"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "703f3645417f545df2d2cd07731d5f99ca347229"
  :revdesc "703f3645417f"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
