;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "20260711.1524"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "dbc5f27b57acc784219790bc79bf3abcb4bff4e1"
  :revdesc "dbc5f27b57ac"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
