;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "honcho" "20230224.420"
  "Run and manage long-running services."
  '((emacs "26.1"))
  :url "https://github.com/emacs-pe/honcho.el"
  :commit "95846309c6a4ce45f29f215d43847beb510b6aca"
  :revdesc "95846309c6a4"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
