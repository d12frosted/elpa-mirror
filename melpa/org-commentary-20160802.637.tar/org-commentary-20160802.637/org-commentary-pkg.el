;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-commentary" "20160802.637"
  "Generate or update conventional library headers using Org mode files."
  '((dash  "2.0")
    (emacs "24.4")
    (org   "8.0"))
  :url "https://github.com/smaximov/org-commentary"
  :commit "821ccb994811359c42f4e3d459e0e88849d42b75"
  :revdesc "821ccb994811"
  :keywords '("convenience" "docs" "tools")
  :authors '(("Sergei Maximov" . "s.b.maximov@gmail.com"))
  :maintainers '(("Sergei Maximov" . "s.b.maximov@gmail.com")))
