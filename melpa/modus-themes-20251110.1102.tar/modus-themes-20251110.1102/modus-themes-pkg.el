;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251110.1102"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "c94938ff794d043447ed4ffe9b55f1031039f667"
  :revdesc "c94938ff794d"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
