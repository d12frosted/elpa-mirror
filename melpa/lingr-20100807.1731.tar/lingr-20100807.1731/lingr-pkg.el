;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lingr" "20100807.1731"
  "Lingr Client for GNU Emacs."
  ()
  :url "https://github.com/lugecy/lingr-el"
  :commit "4215a8704492d3c860097cbe2649936c22c196df"
  :revdesc "4215a8704492"
  :keywords '("chat" "client" "internet")
  :authors '(("lugecy" . "lugecy@gmail.com"))
  :maintainers '(("lugecy" . "lugecy@gmail.com")))
