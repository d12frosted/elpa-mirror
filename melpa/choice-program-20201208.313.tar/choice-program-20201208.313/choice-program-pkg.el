(define-package "choice-program" "20201208.313" "parameter based program"
  '((emacs "26"))
  :commit "f95321f5e317225cd33824c32520fe7abb972e29" :keywords
  ("exec" "execution" "parameter" "option")
  :authors
  (("Paul Landes"))
  :maintainer
  ("Paul Landes")
  :url "https://github.com/plandes/choice-program")
;; Local Variables:
;; no-byte-compile: t
;; End:
