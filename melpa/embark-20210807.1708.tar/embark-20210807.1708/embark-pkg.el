(define-package "embark" "20210807.1708" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "24de8e6892e0715c0e0074544959c08b2405805c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
