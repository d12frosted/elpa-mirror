;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "20241228.2231"
  "Explore and visualise Denote files."
  '((emacs  "29.1")
    (denote "3.1")
    (dash   "2.19.1"))
  :url "https://github.com/pprevos/denote-explore"
  :commit "1e35592a55d6c8ba2eaf63862544a2b86f187a58"
  :revdesc "1e35592a55d6"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
