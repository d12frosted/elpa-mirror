(define-package "modus-themes" "20230101.333" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "5932c761b1b178c4d7d3254b37a2a27945cebe88" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
