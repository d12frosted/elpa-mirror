;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260523.217"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "cb745aec06b451304d28fc762227ab907608cc29"
  :revdesc "cb745aec06b4"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
