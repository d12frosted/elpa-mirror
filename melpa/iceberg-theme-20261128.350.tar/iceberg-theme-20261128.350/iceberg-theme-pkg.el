;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iceberg-theme" "20261128.350"
  "Well-designed, eye-friendly, dark blue color scheme."
  '((emacs           "28.1")
    (solarized-theme "2.1.0"))
  :url "https://github.com/conao3/iceberg-theme.el"
  :commit "56ff3120a2a8ba7ef346936785ae92f57d29c685"
  :revdesc "56ff3120a2a8"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
