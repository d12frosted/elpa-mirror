;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20261007.1124"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "6252531eb03c38410797c45ecd51e8f0a65c325a"
  :revdesc "6252531eb03c"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
