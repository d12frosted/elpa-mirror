;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "choice-program" "20260127.2022"
  "Parameter based program."
  '((emacs "27.1")
    (dash  "2.19.1"))
  :url "https://github.com/plandes/choice-program"
  :commit "9c027a54a97390ee4863d663be19b1a2aaa70c7b"
  :revdesc "9c027a54a973"
  :keywords '("execution" "processes" "unix" "lisp"))
