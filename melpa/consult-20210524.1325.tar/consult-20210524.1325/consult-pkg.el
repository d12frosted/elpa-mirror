(define-package "consult" "20210524.1325" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "2b45f6fb9df6ca4e105e9fcef90acaa90fe4a279" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
