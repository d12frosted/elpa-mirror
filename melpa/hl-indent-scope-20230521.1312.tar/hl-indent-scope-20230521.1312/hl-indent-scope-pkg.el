(define-package "hl-indent-scope" "20230521.1312" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "c71bc7ef421a25f27993d695d230b03e340d55f4" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
