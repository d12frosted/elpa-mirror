(define-package "elcord" "20210311.256" "Allows you to integrate Rich Presence from Discord"
  '((emacs "25.1"))
  :commit "9bea3248938b99498f5114f46441720e1d4b2f3a" :authors
  '(("heatingdevice")
    ("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com"))
  :maintainer
  '("heatingdevice")
  :keywords
  '("games")
  :url "https://github.com/Mstrodl/elcord")
;; Local Variables:
;; no-byte-compile: t
;; End:
