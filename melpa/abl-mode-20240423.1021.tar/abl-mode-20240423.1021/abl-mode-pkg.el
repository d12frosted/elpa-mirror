(define-package "abl-mode" "20240423.1021" "Python TDD minor mode" 'nil :commit "3c135ef703e46ffd1b42b2484acabaa3d4d03b23" :authors
  '(("Ulas Tuerkmen <ulas.tuerkmen at gmail dot com>"))
  :maintainers
  '(("Ulas Tuerkmen <ulas.tuerkmen at gmail dot com>"))
  :maintainer
  '("Ulas Tuerkmen <ulas.tuerkmen at gmail dot com>")
  :url "http://github.com/afroisalreadyinu/abl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
