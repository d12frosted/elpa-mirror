(define-package "meow" "20211216.1343" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "641575952748958502d52723493bc9ee93f8ad9c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
