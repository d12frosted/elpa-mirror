;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verb" "20260617.1912"
  "Organize and send HTTP requests."
  '((emacs "26.3"))
  :url "https://github.com/federicotdn/verb"
  :commit "25a25456bb9ef5090d80105aaa8ad931f336a06e"
  :revdesc "25a25456bb9e"
  :keywords '("tools")
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
