;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sourcepawn-mode" "20260318.957"
  "SourcePawn major mode."
  ()
  :url "https://rakeri.net/teamfortress2/sourcepawn-mode"
  :commit "1278cfe7e411385755b796ac7245ace7d0deb26d"
  :revdesc "1278cfe7e411"
  :authors '(("Aaron Griffith" . "aargri@gmail.com"))
  :maintainers '(("Aaron Griffith" . "aargri@gmail.com")))
