;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241022.1918"
  "Major mode for MATLAB(R) dot-m files."
  ()
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "b1dd400a90e3746028debd829f26c0ba033e90f8"
  :revdesc "b1dd400a90e3"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")))
