(define-package "jq-ts-mode" "20230928.622" "Tree-sitter support for jq buffers"
  '((emacs "29.1"))
  :commit "ce05512c2fb46dbc92a14766dcbebb8f9dac7cb4" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("jq" "languages" "tree-sitter")
  :url "https://github.com/nverno/jq-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
