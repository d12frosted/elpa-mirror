(define-package "elfeed-tube" "20220816.558" "YouTube integration for Elfeed"
  '((emacs "27.1")
    (elfeed "3.4.1")
    (aio "1.0"))
  :commit "b5abbdf0ab196eed9ef7552e5de1c516ef502358" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("news" "hypermedia" "convenience")
  :url "https://github.com/karthink/elfeed-tube")
;; Local Variables:
;; no-byte-compile: t
;; End:
