(define-package "elfeed-tube" "20220816.558" "YouTube integration for Elfeed"
  '((emacs "27.1")
    (elfeed "3.4.1")
    (aio "1.0"))
  :commit "7e1409e41628d61d8197ca248d910182ae4fc520" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("news" "hypermedia" "convenience")
  :url "https://github.com/karthink/elfeed-tube")
;; Local Variables:
;; no-byte-compile: t
;; End:
