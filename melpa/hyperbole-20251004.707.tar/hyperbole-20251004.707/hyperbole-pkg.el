;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251004.707"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "35c33bd53d41457b94c3b49e99345d2d179ad97c"
  :revdesc "35c33bd53d41"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
