(define-package "gnuplot" "20221111.821" "Major-mode and interactive frontend for gnuplot"
  '((emacs "25.1"))
  :commit "72e70e309978f48cf4724cd99e78d09331f7acee" :authors
  '(("Jon Oddie, Bruce Ravel, Phil Type"))
  :maintainer
  '("Maxime Tréca <maxime@gmail.com>, Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("data" "gnuplot" "plotting")
  :url "https://github.com/emacs-gnuplot/gnuplot")
;; Local Variables:
;; no-byte-compile: t
;; End:
