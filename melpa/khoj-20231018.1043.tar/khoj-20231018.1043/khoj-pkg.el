(define-package "khoj" "20231018.1043" "AI copilot for your Second Brain"
  '((emacs "27.1")
    (transient "0.3.0")
    (dash "2.19.1"))
  :commit "8346e1193cf31ce8d66de7793b958bdd06c9d2b9" :authors
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
    ("Saba Imran" . "saba@khoj.dev"))
  :maintainers
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev"))
  :maintainer
  '("Debanjum Singh Solanky" . "debanjum@khoj.dev")
  :keywords
  '("search" "chat" "org-mode" "outlines" "markdown" "pdf" "image")
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
