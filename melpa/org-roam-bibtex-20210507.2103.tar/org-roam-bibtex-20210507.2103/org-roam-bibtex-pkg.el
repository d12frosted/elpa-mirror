(define-package "org-roam-bibtex" "20210507.2103" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "2.0.0")
    (bibtex-completion "2.0.0")
    (org-ref "1.1.1"))
  :commit "03b3a843fdbba428b29faa932661bc74fd66e29b" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
