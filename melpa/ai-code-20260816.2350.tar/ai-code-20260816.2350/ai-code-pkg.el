;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260816.2350"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9cf99c953aeba7349ff633da92308ba426501324"
  :revdesc "9cf99c953aeb"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
