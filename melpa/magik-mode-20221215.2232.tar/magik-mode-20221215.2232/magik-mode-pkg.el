(define-package "magik-mode" "20221215.2232" "mode for editing Magik + some utils." 'nil :commit "05290e30f57379adc73cfd932b728d792039a42f" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
