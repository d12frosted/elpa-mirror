(define-package "notmuch" "20211212.1414" "run notmuch within emacs" 'nil :commit "ed03babd053d679a85ea3baa1632d8ae1dff31b6" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
