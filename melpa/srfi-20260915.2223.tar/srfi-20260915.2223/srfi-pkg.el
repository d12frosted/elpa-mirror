;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260915.2223"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "9a3987e73465dded7fd5370e017e42501cf433d9"
  :revdesc "9a3987e73465"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
