(define-package "citeproc" "20230116.1635" "A CSL 1.0.2 Citation Processor"
  '((emacs "26")
    (dash "2.13.0")
    (s "1.12.0")
    (f "0.18.0")
    (queue "0.2")
    (string-inflection "1.0")
    (org "9")
    (parsebib "2.4"))
  :commit "121efe540303ded2ebf486281e6fd472966e7cbe" :authors
  '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainer
  '("András Simonyi" . "andras.simonyi@gmail.com")
  :keywords
  '("bib")
  :url "https://github.com/andras-simonyi/citeproc-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
