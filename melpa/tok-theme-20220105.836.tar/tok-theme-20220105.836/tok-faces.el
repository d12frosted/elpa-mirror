;;; tok-faces.el --- Face definitions for my theme -*- lexical-binding: t; -*-

;; Copyright (C) 2021, Topi Kettunen <mail@topikettunen.com>

;; Author: Topi Kettunen <mail@topikettunen.com>
;; URL: https://github.com/topikettunen/tok-theme
;; Version: 0.1
;; Package-Requires: ((emacs "24.3"))

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <http://www.gnu.org/licenses/>.

;; This file is not part of Emacs.

;;; Commentary:

;; Face definition for my theme

;;; Code: 

(defvar tok-definition
  '((custom-theme-set-faces
     theme-name
     ;; 
     ;; Crucial faces
     ;; 
     `(default ((,class (:background ,bg1 :foreground ,fg1))))
     `(highlight ((,class (:foreground ,fg3 :background ,bg3))))
     `(hl-line ((,class (:background  ,hl))))
     `(fringe ((,class (:background ,bg1 :foreground ,fg1))))
     `(cursor ((,class (:background ,fg1))))
     `(isearch ((,class (:foreground ,bg1 :background ,fg1))))
     `(mode-line ((,class (:foreground ,fg-active :background ,bg-active :box (:line-width -1 :color ,fg3)))))
     `(mode-line-active ((,class :inherit mode-line)))
     `(mode-line-inactive ((,class (:foreground ,fg-inactive :background ,bg-inactive :box (:line-width -1 :color ,fg4)))))
     `(font-lock-comment-face ((,class (:foreground ,comment))))
     `(font-lock-doc-face ((,class (:foreground ,comment))))
     `(font-lock-preprocessor-face ((,class (:foreground ,comment))))
     `(org-link ((,class (:underline '(:color ,fg1)))))
     `(region ((,class (:background ,bg3))))
     ;; 
     ;; Following packages have good enough default faces on my experience
     ;; 
     ;;   - Company/corfu
     ;;   - Magit
     ;;   - Term
     ;;   - Org
     ;;   - Ido
     ;;   - Gnus
     ;; 
     ;; Disabled faces:
     ;;
     ;;   I don't use most of these packages so this list was a copy-paste
     ;;   from somewhere. If you happend to find some weird coloring in some
     ;;   packages, feel free to add it here.
     ;; 
     `(show-paren-match-face ((t nil)))
     `(mode-line-buffer-id ((t nil)))
     `(mode-line-highlight ((t nil)))
     `(mode-line-emphasis ((t nil)))
     `(vertical-border ((t nil)))
     `(minibuffer-prompt ((t nil)))
     `(default-italic ((t nil)))
     `(link ((t nil)))
     `(font-lock-builtin-face ((t nil)))
     `(font-lock-negation-char-face ((t nil)))
     `(font-lock-reference-face ((t nil)))
     `(font-lock-constant-face ((t nil)))
     `(font-lock-function-name-face ((t nil)))
     `(font-lock-keyword-face ((t nil)))
     `(font-lock-string-face ((t nil)))
     `(font-lock-type-face ((t nil)))
     `(font-lock-variable-name-face ((t nil)))
     `(font-lock-warning-face ((t nil)))
     `(sh-quoted-exec ((t nil)))
     `(eshell-prompt ((t nil)))
     `(font-latex-bold-face ((t nil)))
     `(font-latex-italic-face ((t nil)))
     `(font-latex-string-face ((t nil)))
     `(font-latex-match-reference-keywords ((t nil)))
     `(font-latex-match-variable-keywords ((t nil)))
     `(warning ((t nil)))
     `(trailing-whitespace ((t nil)))
     `(mu4e-view-url-number-face ((t nil)))
     `(mu4e-cited-1-face ((t nil)))
     `(mu4e-cited-7-face ((t nil)))
     `(mu4e-header-marks-face ((t nil)))
     `(ffap ((t nil)))
     `(js2-private-function-call ((t nil)))
     `(js2-jsdoc-html-tag-delimiter ((t nil)))
     `(js2-jsdoc-html-tag-name ((t nil)))
     `(js2-external-variable ((t nil)))
     `(js2-function-param ((t nil)))
     `(js2-jsdoc-value ((t nil)))
     `(js2-private-member ((t nil)))
     `(js3-warning-face ((t nil)))
     `(js3-error-face ((t nil)))
     `(js3-external-variable-face ((t nil)))
     `(js3-function-param-face ((t nil)))
     `(js3-jsdoc-tag-face ((t nil)))
     `(js3-instance-member-face ((t nil)))
     `(ac-completion-face ((t nil)))
     `(info-quoted-name ((t nil)))
     `(info-string ((t nil)))
     `(icompletep-determined ((t nil)))
     `(undo-tree-visualizer-current-face ((t nil)))
     `(undo-tree-visualizer-default-face ((t nil)))
     `(undo-tree-visualizer-unmodified-face ((t nil)))
     `(undo-tree-visualizer-register-face ((t nil)))
     `(slime-repl-inputed-output-face ((t nil)))
     `(rainbow-delimiters-depth-1-face ((t nil)))
     `(rainbow-delimiters-depth-2-face ((t nil)))
     `(rainbow-delimiters-depth-3-face ((t nil)))
     `(rainbow-delimiters-depth-4-face ((t nil)))
     `(rainbow-delimiters-depth-5-face ((t nil)))
     `(rainbow-delimiters-depth-6-face ((t nil)))
     `(rainbow-delimiters-depth-7-face ((t nil)))
     `(rainbow-delimiters-depth-8-face ((t nil)))
     `(rainbow-delimiters-unmatched-face ((t nil)))
     `(lazy-highlight ((t nil)))
     `(helm-header ((t nil)))
     `(helm-source-header ((t nil)))
     `(helm-selection ((t nil)))
     `(helm-selection-line ((t nil)))
     `(helm-visible-mark ((t nil)))
     `(helm-candidate-number ((t nil)))
     `(helm-separator ((t nil)))
     `(helm-time-zone-current ((t nil)))
     `(helm-time-zone-home ((t nil)))
     `(helm-buffer-not-saved ((t nil)))
     `(helm-buffer-process ((t nil)))
     `(helm-buffer-saved-out ((t nil)))
     `(helm-buffer-size ((t nil)))
     `(helm-ff-directory ((t nil)))
     `(helm-ff-file ((t nil)))
     `(helm-ff-executable ((t nil)))
     `(helm-ff-invalid-symlink ((t nil)))
     `(helm-ff-symlink ((t nil)))
     `(helm-ff-prefix ((t nil)))
     `(helm-grep-cmd-line ((t nil)))
     `(helm-grep-file ((t nil)))
     `(helm-grep-finish ((t nil)))
     `(helm-grep-lineno ((t nil)))
     `(helm-grep-match ((t nil)))
     `(helm-grep-running ((t nil)))
     `(helm-moccur-buffer ((t nil)))
     `(helm-source-go-package-godoc-description ((t nil)))
     `(helm-bookmark-w3m ((t nil)))
     `(web-mode-builtin-face ((t nil)))
     `(web-mode-comment-face ((t nil)))
     `(web-mode-constant-face ((t nil)))
     `(web-mode-keyword-face ((t nil)))
     `(web-mode-doctype-face ((t nil)))
     `(web-mode-function-name-face ((t nil)))
     `(web-mode-string-face ((t nil)))
     `(web-mode-type-face ((t nil)))
     `(web-mode-html-attr-name-face ((t nil)))
     `(web-mode-html-attr-value-face ((t nil)))
     `(web-mode-warning-face ((t nil)))
     `(web-mode-html-tag-face ((t nil)))
     `(jde-java-font-lock-package-face ((t nil)))
     `(jde-java-font-lock-public-face ((t nil)))
     `(jde-java-font-lock-private-face ((t nil)))
     `(jde-java-font-lock-constant-face ((t nil)))
     `(jde-java-font-lock-modifier-face ((t nil)))
     `(jde-jave-font-lock-protected-face ((t nil)))
     `(jde-java-font-lock-number-face ((t nil)))
     '(terraform--resource-name-face ((t nil)))
     '(terraform--resource-type-face ((t nil)))
     '(tuareg-font-lock-governing-face ((t nil)))
     '(tuareg-font-lock-multistage-face ((t nil)))
     '(tuareg-font-lock-operator-face ((t nil)))
     '(tuareg-font-lock-error-face ((t nil)))
     '(tuareg-font-lock-interactive-output-face ((t nil)))
     '(tuareg-font-lock-interactive-error-face ((t nil))))))

(provide 'tok-faces)

;;; tok-faces.el ends here
