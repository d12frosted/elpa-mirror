(define-package "tok-theme" "20220105.836" "My theme"
  '((emacs "24.3"))
  :commit "5a85936fe19f9c8692fb805527031ea9d1ca87bb" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
