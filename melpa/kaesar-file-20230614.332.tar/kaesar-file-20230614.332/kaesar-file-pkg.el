;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaesar-file" "20230614.332"
  "AES encrypt/decrypt file."
  '((emacs  "24.3")
    (kaesar "0.1.1"))
  :url "https://github.com/mhayashi1120/Emacs-kaesar"
  :commit "be615884cbbb9838c5e6655abf7f112a8df03a06"
  :revdesc "be615884cbbb"
  :keywords '("data" "files")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
