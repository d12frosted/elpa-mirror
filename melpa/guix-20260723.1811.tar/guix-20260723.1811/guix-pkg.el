;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20260723.1811"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "6833de3d97619191a06c589aa2aa7c79feb9ff79"
  :revdesc "6833de3d9761"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
