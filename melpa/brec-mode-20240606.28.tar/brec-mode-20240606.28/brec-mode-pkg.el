(define-package "brec-mode" "20240606.28" "A major mode for editing Breccian text"
  '((emacs "24.3"))
  :commit "bba9c2fe1e5b6beccbfb96adfa20948f7c6a19f8" :authors
  '(("Michael Allan" . "mike@reluk.ca"))
  :maintainers
  '(("Michael Allan" . "mike@reluk.ca"))
  :maintainer
  '("Michael Allan" . "mike@reluk.ca")
  :keywords
  '("outlines" "wp")
  :url "http://reluk.ca/project/Breccia/Emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
