;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "20260724.2118"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "734654129f9a3257f52f8f14847db7acf1d40bae"
  :revdesc "734654129f9a"
  :keywords '("wp" "convenience"))
