;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261018.2347"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "942859d4e5e01c541a8d3d8c99014e3b757fb82e"
  :revdesc "942859d4e5e0"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
