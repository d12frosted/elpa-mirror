(define-package "meow" "20230310.56" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "9860a7a218a2a6c2b773b041c2878d314d65a009" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
