;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenburn-theme" "20260531.2245"
  "A low contrast color theme for Emacs."
  ()
  :url "https://github.com/bbatsov/zenburn-emacs"
  :commit "792b703649592f039882b83412a19ccd6431dfd5"
  :revdesc "792b70364959"
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
