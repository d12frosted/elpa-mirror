(define-package "osm" "20220401.1318" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "d40ef3f4fea0724993db6a8f0a7a502a6333f598" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
