;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-athena" "20250706.846"
  "Run AWS Athena queries from Org Babel."
  '((emacs "26.1"))
  :url "https://github.com/will-abb/aws-athena-babel"
  :commit "2d2acc11fd97385d841d81acb34da48c65ee6137"
  :revdesc "2d2acc11fd97"
  :keywords '("aws" "athena" "org" "babel" "sql" "tools")
  :authors '(("Williams Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Williams Bosch-Bello" . "williamsbosch@gmail.com")))
