(define-package "docker" "20220628.546" "Interface to Docker"
  '((aio "1.0")
    (dash "2.19.1")
    (docker-tramp "0.1")
    (emacs "26.1")
    (s "1.12.0")
    (tablist "1.0")
    (transient "0.3.7"))
  :commit "a14957ff870817bd9fd9c25b53206d1097c454c2" :authors
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainer
  '("Philippe Vaucher" . "philippe.vaucher@gmail.com")
  :keywords
  '("filename" "convenience")
  :url "https://github.com/Silex/docker.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
