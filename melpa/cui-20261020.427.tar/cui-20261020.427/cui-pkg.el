;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261020.427"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "8cbd2c2fe21eb0e908feb31494310f9ad8957ba4"
  :revdesc "8cbd2c2fe21e"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
