(define-package "compiler-explorer" "20240411.2049" "Compiler explorer client (godbolt.org)"
  '((emacs "26.1")
    (request "0.3.0")
    (eldoc "1.15.0"))
  :commit "1ec7ed389d4a041f81eea58c1cf2c0a99541f539" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("c" "tools")
  :url "https://github.com/mkcms/compiler-explorer.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
