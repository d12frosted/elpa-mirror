;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260210.1534"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "b2abb0c61a08bf7ecdc194daa3e1efc53947f344"
  :revdesc "b2abb0c61a08"
  :keywords '("convenience"))
