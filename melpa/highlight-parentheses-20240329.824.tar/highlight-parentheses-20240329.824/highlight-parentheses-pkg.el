(define-package "highlight-parentheses" "20240329.824" "Highlight surrounding parentheses"
  '((emacs "24.3"))
  :commit "a2f2c5f564ab0cd24171563a133b3266fda41560" :authors
  '(("Nikolaj Schumacher <bugs * nschum de>"))
  :maintainers
  '(("Tassilo Horn" . "tsdh@gnu.org"))
  :maintainer
  '("Tassilo Horn" . "tsdh@gnu.org")
  :keywords
  '("faces" "matching")
  :url "https://sr.ht/~tsdh/highlight-parentheses.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
