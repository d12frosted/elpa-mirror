(define-package "init-dir" "20231214.2217" "Init directory instead of just a single file"
  '((emacs "27.1"))
  :commit "93e8ae3a83d4b90b84076a26ad7d34de4595b686" :authors
  '(("Jared Finder" . "jared@finder.org"))
  :maintainers
  '(("Jared Finder" . "jared@finder.org"))
  :maintainer
  '("Jared Finder" . "jared@finder.org")
  :keywords
  '("extensions" "internal")
  :url "http://github.com/chaosemer/init-dir")
;; Local Variables:
;; no-byte-compile: t
;; End:
