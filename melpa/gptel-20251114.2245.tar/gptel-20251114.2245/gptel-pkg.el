;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251114.2245"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "ffa679ef4c72a0ade9f6513a2360f826382832ea"
  :revdesc "ffa679ef4c72"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
