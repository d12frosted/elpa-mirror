;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20241210.459"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.8.0"))
  :url "https://github.com/aurtzy/disproject"
  :commit "9e2ad0466f1f06a56bf1b18d46a93c56ea80d984"
  :revdesc "9e2ad0466f1f"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
