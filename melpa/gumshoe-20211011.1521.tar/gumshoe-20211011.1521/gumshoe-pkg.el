(define-package "gumshoe" "20211011.1521" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "73bd956f7d87649e9fea31cf346d8af4538e2f39" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
