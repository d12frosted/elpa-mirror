(define-package "catppuccin-theme" "20240805.2320" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "d990be3db4f07f6506f5b27007691f1464d756c2" :maintainers
  '(("Carsten Kragelund" . "carsten@kragelund.me"))
  :maintainer
  '("Carsten Kragelund" . "carsten@kragelund.me")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
