(define-package "org-clock-agenda-daytime-mode" "20240403.1040" "Display the time clocked today in the modeline"
  '((org "9.6.18")
    (emacs "26.1"))
  :commit "0af1dea2363282fddd41e7a1826df98828aa5e31" :authors
  '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainers
  '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainer
  '("Arne Babenhauserheide" . "arne_bab@web.de")
  :keywords
  '("org" "lisp" "clock" "time" "agenda")
  :url "https://www.draketo.de/software/emacs-daytime")
;; Local Variables:
;; no-byte-compile: t
;; End:
