;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251104.1103"
  "A single native shell experience to interact with agentic providers (Claude Code, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.82.2")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "28373715fba94174c097a36f0484fddde4e3fb5b"
  :revdesc "28373715fba9")
