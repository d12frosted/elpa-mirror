(define-package "eldev" "20220307.2114" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "d90aae7001b93aec4e65eb94f86fea052f896d57" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
