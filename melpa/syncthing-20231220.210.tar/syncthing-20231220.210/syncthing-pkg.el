(define-package "syncthing" "20231220.210" "Client for Syncthing"
  '((emacs "27.1"))
  :commit "946b30eadde7c6207559009c043c9e405e527854" :authors
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainer
  '("Peter Badida" . "keyweeusr@gmail.com")
  :keywords
  '("convenience" "syncthing" "sync" "client" "view")
  :url "https://github.com/KeyWeeUsr/emacs-syncthing")
;; Local Variables:
;; no-byte-compile: t
;; End:
