;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-redis" "20220221.1249"
  "Execute Redis queries within org-mode blocks."
  '((org "8"))
  :url "https://repo.or.cz/ob-redis.git"
  :commit "44c83636ccbea0b3e9838b0180471905c30224c5"
  :revdesc "44c83636ccbe"
  :keywords '("org" "babel" "redis")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
