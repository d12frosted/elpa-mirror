;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260914.913"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "31.1"))
  :url "https://github.com/melpa/package-build"
  :commit "cb1fc153c79a0f1f7e3d5df1641bbfe39ddba45e"
  :revdesc "cb1fc153c79a"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
