;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260303.2212"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "b8f7b94f1a815d217b225fec3be3eadda04cb4cd"
  :revdesc "b8f7b94f1a81"
  :keywords '("outlines" "contacts" "people"))
