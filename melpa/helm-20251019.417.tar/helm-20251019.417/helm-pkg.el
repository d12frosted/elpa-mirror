;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251019.417"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "2f2e1036db859d738e378561f88bd0b57c0047b5"
  :revdesc "2f2e1036db85"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
