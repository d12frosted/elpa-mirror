;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260529.648"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "4056374e4c02f7f0a9bffa6b82d361d3b5953f34"
  :revdesc "4056374e4c02"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
