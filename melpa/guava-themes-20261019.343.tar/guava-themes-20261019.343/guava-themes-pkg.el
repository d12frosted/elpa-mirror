;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261019.343"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "d8f952b1d80d4281b25a64e2ff46ea2696d32ac7"
  :revdesc "d8f952b1d80d"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
