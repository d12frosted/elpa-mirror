(define-package "dirvish" "20220531.1522" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "c2be3c1bcfa34228256041e9f219e66c8846d36a" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
