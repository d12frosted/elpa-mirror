(define-package "mame" "20240828.1559" "A MAME front-end"
  '((emacs "27.1"))
  :commit "7c727999e03932fc65cabdbe2161efbe06ff1274" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
