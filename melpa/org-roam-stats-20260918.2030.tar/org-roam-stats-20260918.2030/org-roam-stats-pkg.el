;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-stats" "20260918.2030"
  "Personal Knowledge Management Dashboard."
  '((emacs        "27.1")
    (org-roam     "2.0")
    (simple-httpd "1.6"))
  :url "https://github.com/GerardoCendejas/org-roam-stats"
  :commit "5a09e6eb9d7f2006a436fc1403d7c86978dbd3eb"
  :revdesc "5a09e6eb9d7f"
  :keywords '("outlines" "tools")
  :authors '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu"))
  :maintainers '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu")))
