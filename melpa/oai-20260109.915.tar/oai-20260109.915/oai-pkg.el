;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260109.915"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "1cc12a88a14048f15a9e68a2aa62794985c72f3a"
  :revdesc "1cc12a88a140"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
