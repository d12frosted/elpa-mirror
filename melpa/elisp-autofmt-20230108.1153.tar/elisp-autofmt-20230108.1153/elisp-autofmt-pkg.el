(define-package "elisp-autofmt" "20230108.1153" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "bf1d626d52f7b2ae1f6095ce4d54d5ba5a42c23c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
