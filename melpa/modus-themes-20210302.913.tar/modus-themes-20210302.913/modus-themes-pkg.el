(define-package "modus-themes" "20210302.913" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "3b2ee734da3b47972ebc2a62c344224f34b5636b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
