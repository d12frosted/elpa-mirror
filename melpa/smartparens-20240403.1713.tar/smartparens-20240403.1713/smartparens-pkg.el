(define-package "smartparens" "20240403.1713" "Automatic insertion, wrapping and paredit-like navigation with user defined pairs."
  '((dash "2.13.0")
    (cl-lib "0.3"))
  :commit "1ffd35cd0f4bfd723c731d7f881735c527d10b23" :authors
  '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matus Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("abbrev" "convenience" "editing")
  :url "https://github.com/Fuco1/smartparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
