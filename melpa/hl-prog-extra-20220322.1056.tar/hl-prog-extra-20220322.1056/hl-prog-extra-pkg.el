(define-package "hl-prog-extra" "20220322.1056" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "a567da410d7e8ae7f20320ac33aef5e93554eb1b" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
