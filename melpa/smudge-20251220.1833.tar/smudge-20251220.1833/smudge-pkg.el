;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smudge" "20251220.1833"
  "Control the Spotify app."
  '((emacs        "27.1")
    (simple-httpd "1.5.1")
    (request      "0.3")
    (oauth2       "0.17"))
  :url "https://github.com/danielfm/smudge"
  :commit "0f57416312c358156fbf7b479634fa44f49c824b"
  :revdesc "0f57416312c3"
  :keywords '("multimedia" "music" "spotify" "smudge"))
