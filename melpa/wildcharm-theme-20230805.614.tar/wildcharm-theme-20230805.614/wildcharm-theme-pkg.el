(define-package "wildcharm-theme" "20230805.614" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "d8f92a54c51c29faa2dbf7485a83e5a67feee11d" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
