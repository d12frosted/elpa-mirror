;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar" "20251107.1154"
  "Citation-related commands for org, latex, markdown."
  '((emacs    "27.1")
    (parsebib "4.2")
    (org      "9.5")
    (citeproc "0.9")
    (compat   "30"))
  :url "https://github.com/emacs-citar/citar"
  :commit "0d981915a134ce1847974496417b07b5d9803b43"
  :revdesc "0d981915a134"
  :authors '(("Bruce D'Arcus" . "https://github.com/bdarcus"))
  :maintainers '(("Bruce D'Arcus" . "https://github.com/bdarcus")))
