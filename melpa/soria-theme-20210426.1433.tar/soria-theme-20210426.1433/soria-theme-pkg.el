(define-package "soria-theme" "20210426.1433" "A xoria256 theme with some colors from openSUSE"
  '((emacs "25.1"))
  :commit "12d3472e6823ff1bdc1591984367e2ed769afcb7" :authors
  '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainer
  '("Miquel Sabaté Solà" . "mikisabate@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/mssola/soria")
;; Local Variables:
;; no-byte-compile: t
;; End:
