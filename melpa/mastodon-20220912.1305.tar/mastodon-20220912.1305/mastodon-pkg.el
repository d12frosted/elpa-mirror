(define-package "mastodon" "20220912.1305" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0"))
  :commit "5073a82d39914e1b753005520219ab949cd13f97" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
