(define-package "dashboard" "20220307.1807" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "fcb43b1ab14ca95b8504518bb49d8fb3ccc70d39" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
