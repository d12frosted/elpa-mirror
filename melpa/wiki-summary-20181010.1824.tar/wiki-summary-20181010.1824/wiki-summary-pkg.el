;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiki-summary" "20181010.1824"
  "View Wikipedia summaries in Emacs easily."
  '((emacs "24"))
  :url "https://github.com/jozefg/wiki-summary.el"
  :commit "fa41ab6e50b3b80e54148af9d4bac18fd0405000"
  :revdesc "fa41ab6e50b3"
  :keywords '("wikipedia" "utility"))
