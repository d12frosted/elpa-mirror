(define-package "transient" "20211023.1742" "Transient commands"
  '((emacs "25.1"))
  :commit "f5e600d3f49d736ba201f3343a29907283e74da5" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("bindings")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
