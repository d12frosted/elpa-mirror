;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "20260709.1716"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "d7e9b47207a16841bb5a08077e1dfcb47608f37f"
  :revdesc "d7e9b47207a1"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
