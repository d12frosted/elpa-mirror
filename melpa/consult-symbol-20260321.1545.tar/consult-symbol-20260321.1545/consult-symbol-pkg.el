;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-symbol" "20260321.1545"
  "Consult-based symbol search with narrowing."
  '((emacs   "27.1")
    (consult "2.0"))
  :url "https://github.com/danielfleischer/consult-symbol"
  :commit "61a98d6fb80fbda6b2b90b892c80675f5852adcc"
  :revdesc "61a98d6fb80f"
  :keywords '("convenience" "matching")
  :authors '(("Daniel Fleischer" . "danflscr@gmail.com"))
  :maintainers '(("Daniel Fleischer" . "danflscr@gmail.com")))
