(define-package "git-cliff" "20231008.2005" "Generate and update changelog using git-cliff"
  '((emacs "27.1")
    (transient "0.4.3"))
  :commit "c9d563e34322667779ad6ba506f326d82d7d05f0" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/liuyinz/git-cliff.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
