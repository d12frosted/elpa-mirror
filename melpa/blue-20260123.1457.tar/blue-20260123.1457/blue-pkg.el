;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260123.1457"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "360bc05f630a016d3a09ca7adbfb4436e638e76f"
  :revdesc "360bc05f630a"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
