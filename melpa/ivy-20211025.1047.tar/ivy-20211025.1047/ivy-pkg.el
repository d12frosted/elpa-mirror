(define-package "ivy" "20211025.1047" "Incremental Vertical completYon"
  '((emacs "24.5"))
  :commit "eb89e10b395ea7b433e3184a355ff215c8f5cd65" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("matching")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
