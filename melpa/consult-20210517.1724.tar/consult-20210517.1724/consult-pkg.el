(define-package "consult" "20210517.1724" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9dcecad2d448e2da0ae9fa17222358176ef58dd3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
