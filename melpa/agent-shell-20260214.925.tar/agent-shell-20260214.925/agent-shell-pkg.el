;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260214.925"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "465c2dc7e26413bd8419628cbf886fa395c12c6c"
  :revdesc "465c2dc7e264")
