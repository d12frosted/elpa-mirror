;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250508.1639"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "2c7e4dc4a99e652e0ffe5c261ff06aedda80fc68"
  :revdesc "2c7e4dc4a99e"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
