(define-package "dirvish" "20220312.1121" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "08688a8f94eac5ebcff7108a241012c8be2325b6" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
