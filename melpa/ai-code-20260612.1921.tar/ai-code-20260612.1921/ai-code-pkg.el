;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260612.1921"
  "Unified interface for AI coding backends."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "1119cf3281c9a04cc34afb2cc6cd0f4275efc0ea"
  :revdesc "1119cf3281c9"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
