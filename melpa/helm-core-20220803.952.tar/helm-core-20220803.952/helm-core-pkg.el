(define-package "helm-core" "20220803.952" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "0c8a48e94af09692ea51c022c370c3ef311eb83d" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
