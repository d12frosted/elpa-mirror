(define-package "elsa" "20230314.1700" "Emacs Lisp Static Analyser"
  '((emacs "25.1")
    (trinary "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3")
    (lsp-mode "0"))
  :commit "bb556333db3a3400c3d125d932ab876db6e72190" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp")
  :url "https://github.com/emacs-elsa/Elsa")
;; Local Variables:
;; no-byte-compile: t
;; End:
