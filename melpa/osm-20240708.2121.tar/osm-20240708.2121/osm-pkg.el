(define-package "osm" "20240708.2121" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "30"))
  :commit "1d69916c1bdbc3dbd49dc5b510626b47cd55202b" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
