(define-package "ox-linuxmag-fr" "20230417.1134" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "4eeebd75349853e3131d5358cd653a145322ea02" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
