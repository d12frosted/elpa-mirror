(define-package "live-py-mode" "20220404.0" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "b6583c0c845e3ef607d57e35a009255d630df2c1" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
