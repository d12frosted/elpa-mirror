(define-package "live-py-mode" "20220404.0" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "4d7fe4b7899a8f7c1bd800cfe913fde3f188452d" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
