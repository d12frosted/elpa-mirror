(define-package "live-py-mode" "20220404.0" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "b466460b6783caacf1ea3fcfa28752cb73fd0805" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
