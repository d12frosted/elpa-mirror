;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250616.1511"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "1afcffb954f4897192bb21a89d35d3f65d08e14f"
  :revdesc "1afcffb954f4"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
