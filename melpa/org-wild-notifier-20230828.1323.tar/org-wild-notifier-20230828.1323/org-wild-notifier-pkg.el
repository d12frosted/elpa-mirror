(define-package "org-wild-notifier" "20230828.1323" "Customizable org-agenda notifications"
  '((alert "1.2")
    (async "1.9.3")
    (dash "2.18.0")
    (emacs "24.4"))
  :commit "04d687730ce79cc12dff0de1e6df39d3b4292350" :authors
  '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainers
  '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainer
  '("Artem Khramov" . "akhramov+emacs@pm.me")
  :keywords
  '("notification" "alert" "org" "org-agenda" "agenda")
  :url "https://github.com/akhramov/org-wild-notifier.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
