;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261007.2120"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "34f6b01f3ad80f7173688ea6f3d50e9e7221035e"
  :revdesc "34f6b01f3ad8"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
