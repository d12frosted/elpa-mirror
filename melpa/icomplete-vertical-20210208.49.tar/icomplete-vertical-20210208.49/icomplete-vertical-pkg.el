(define-package "icomplete-vertical" "20210208.49" "Display icomplete candidates vertically"
  '((emacs "25.1"))
  :commit "cb476262a35acaf36f34e920a4aacb407c76661c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
