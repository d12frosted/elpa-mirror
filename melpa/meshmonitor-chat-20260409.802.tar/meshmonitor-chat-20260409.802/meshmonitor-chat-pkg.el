;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meshmonitor-chat" "20260409.802"
  "Chat client for MeshMonitor (Meshtastic)."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/meshmonitor-chat.el"
  :commit "862d8fed090dde4db19105afcc29199b3aa38cf0"
  :revdesc "862d8fed090d"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
