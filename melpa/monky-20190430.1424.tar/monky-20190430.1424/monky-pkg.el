(define-package "monky" "20190430.1424" "Control Hg from Emacs." 'nil :commit "099f1af9d3f6f6143f5e98a9b844f965a011a120" :authors
  '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainer
  '("Anantha kumaran" . "ananthakumaran@gmail.com")
  :keywords
  '("tools")
  :url "http://github.com/ananthakumaran/monky")
;; Local Variables:
;; no-byte-compile: t
;; End:
