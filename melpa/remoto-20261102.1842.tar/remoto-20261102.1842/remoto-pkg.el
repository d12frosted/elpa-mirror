;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261102.1842"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "88567c9a3ebecd0f10f169d35a91aef289a73e4f"
  :revdesc "88567c9a3ebe"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
