;;; remoto.el --- Browse GitHub and Codeberg repos without cloning -*- lexical-binding: t; -*-
;;
;; Copyright (C) 2026 Ag Ibragimov
;;
;; Author: Ag Ibragimov <agzam.ibragimov@gmail.com>
;; Assisted-by: ECA:claude-opus-5
;; Maintainer: Ag Ibragimov <agzam.ibragimov@gmail.com>
;; Created: April 24, 2026
;; Package-Version: 20261102.1842
;; Package-Revision: 88567c9a3ebe
;; Keywords: tools vc
;; Homepage: https://github.com/agzam/remoto.el
;; Package-Requires: ((emacs "29.1") (ghub "5.3.0"))
;;
;; SPDX-License-Identifier: GPL-3.0-or-later
;;
;; This file is not part of GNU Emacs.

;;; Commentary:

;; remoto.el lets you browse any GitHub or Codeberg repository in Emacs as
;; if it were cloned locally - without cloning it.  It registers a virtual
;; filesystem via `file-name-handler-alist' that translates Emacs file
;; operations into requests to a forge.  A forge is a `remoto-forge' that
;; answers the generic functions of the forge contract with plain data;
;; GitHub's answers live in remoto-github.el and use the `ghub' library.
;;
;; Loading this file defines things and changes nothing.  `global-remoto-mode'
;; is the switch: it installs the file-name handler, the `find-file' and
;; `dired' URL rewriting, the completion metadata, and the auto-enabling of
;; `remoto-mode' in remoto buffers, and removes all of them when turned off.
;;
;; Usage:
;;   C-x C-f /github:torvalds/linux RET
;;   C-x C-f /cb:forgejo/forgejo RET
;;   M-x remoto-browse RET https://github.com/torvalds/linux RET
;;
;; Each turns the mode on when it is off: `remoto-browse' itself, and the
;; path through `remoto-autoload-file-name-handler', which the package
;; autoloads register for the prefixes of the forges that come with
;; remoto, the way TRAMP autoloads on a remote path.
;; `(global-remoto-mode 1)' in the init file turns it on ahead of time.
;; `remoto-browse' supports pasting any forge URL, git remote URL,
;; /PREFIX:OWNER/REPO name, or OWNER/REPO of `remoto-default-forge'.

;;; Code:

(require 'cl-lib)
(require 'files-x)
(require 'format-spec)
(require 'ghub)
(require 'iso8601)
(require 'project)

;;;; Forges

(cl-defstruct (remoto-forge (:constructor remoto-forge-create)
                            (:copier nil))
  "A source of repositories that remoto paths name; TITLE names it in messages.
PREFIXES are path prefixes, the first canonical; DELIMITERS the characters
after a repository; TOPIC-KEY a regexp of topic keys; LOCATOR the segments
a repository name takes: a number, a function of the segments, or `open'."
  name prefixes host delimiters repo-end title (topic-key "\\`[0-9]+\\'")
  (locator 2))

(cl-defstruct (remoto-github (:include remoto-forge (title "GitHub"))
                             (:constructor remoto-github-create)
                             (:copier nil))
  "The GitHub forge.")

(defvar remoto--forges nil
  "Alist of (PREFIX . FORGE) for every prefix of every registered forge.")

(defvar remoto--handler-regexp "\\`/\\(?:github\\|gh\\):"
  "Regexp matching remoto file paths: every prefix of every forge.
`remoto-register-forge' rebuilds it.  Each forge file carries an
autoload cookie that repeats its prefixes as a literal, in this
spelling, for `remoto-autoload-file-name-handler'.")

(defun remoto--prefix (forge)
  "Return the canonical path prefix of FORGE, such as /github:."
  (concat "/" (car (remoto-forge-prefixes forge)) ":"))

(defvar tramp-ignored-file-name-regexp)

(defvar remoto--tramp-ignored-saved nil
  "List of the value `tramp-ignored-file-name-regexp' had before remoto's.
Nil while the prefixes are not composed into it.")

(defun remoto--tramp-ignored-regexp (original)
  "Return the regexp ORIGINAL, or nil, extended by every registered prefix."
  (cond ((null remoto--forges) original)
        (original (concat "\\(?:" original "\\)\\|" remoto--handler-regexp))
        (t remoto--handler-regexp)))

(defun remoto--refresh-tramp-ignored ()
  "Compose the registered prefixes into `tramp-ignored-file-name-regexp'."
  ;; A one-name path such as /npm:react@18:/x has TRAMP's /METHOD:HOST: shape.
  ;; The variable is autoloaded, and tramp's `defcustom' keeps a value set
  ;; before it loads.
  (unless remoto--tramp-ignored-saved
    (setq remoto--tramp-ignored-saved
          (list (bound-and-true-p tramp-ignored-file-name-regexp))))
  (setq tramp-ignored-file-name-regexp
        (remoto--tramp-ignored-regexp (car remoto--tramp-ignored-saved))))

(defun remoto--restore-tramp-ignored ()
  "Put back the value `tramp-ignored-file-name-regexp' had before remoto's."
  (when remoto--tramp-ignored-saved
    (setq tramp-ignored-file-name-regexp (car remoto--tramp-ignored-saved)
          remoto--tramp-ignored-saved nil)))

(defun remoto--refresh-handler ()
  "Point the entry of `file-name-handler-alist' at the current prefixes."
  (when (bound-and-true-p global-remoto-mode)
    (setq file-name-handler-alist
          (rassq-delete-all #'remoto-file-name-handler file-name-handler-alist))
    (push (cons remoto--handler-regexp #'remoto-file-name-handler)
          file-name-handler-alist)
    (remoto--refresh-tramp-ignored)))

(defun remoto-register-forge (forge)
  "Register FORGE under each of its prefixes and refresh the handler regexp.
Register the delimiters of FORGE with `remoto-register-delimiter' first.
An `open' locator ends a repository name at a delimiter or colon only:
its slashes separate groups, which nest to any depth."
  (setf (remoto-forge-repo-end forge)
        (rx-to-string `(in ,(if (eq (remoto-forge-locator forge) 'open) ":" "/:")
                           ,@(mapcar #'char-to-string
                                     (remoto-forge-delimiters forge)))
                      t))
  (dolist (prefix (remoto-forge-prefixes forge))
    (if-let* ((entry (assoc prefix remoto--forges)))
        (setcdr entry forge)
      (setq remoto--forges (append remoto--forges (list (cons prefix forge))))))
  (setq remoto--handler-regexp
        (concat "\\`/\\(?:"
                (mapconcat #'regexp-quote (mapcar #'car remoto--forges) "\\|")
                "\\):"))
  (remoto--refresh-handler))

(defun remoto--forge-buffers (forge)
  "Return the buffers of FORGE: its files, its Dired directories, its topics."
  (let ((regexp (concat "\\`/" (regexp-opt (remoto-forge-prefixes forge)) ":")))
    (seq-filter (lambda (buffer)
                  (when-let* ((name (with-current-buffer buffer
                                      (or buffer-file-name
                                          (and (derived-mode-p 'dired-mode)
                                               default-directory)
                                          (bound-and-true-p remoto-topic--repo-path)))))
                    (string-match-p regexp name)))
                (buffer-list))))

(defun remoto-unregister-forge (forge)
  "Remove FORGE from the registry and refresh the handler regexp.
The buffers of FORGE are killed first: once no handler serves their
names, `uniquify' fails to kill any buffer that shares their name."
  (when-let* ((killed (seq-count #'kill-buffer (remoto--forge-buffers forge)))
              ((< 0 killed)))
    (message "Remoto: killed %d buffer%s of %s" killed (if (= killed 1) "" "s")
             (remoto--prefix forge)))
  (setq remoto--forges (seq-remove (lambda (entry) (eq (cdr entry) forge))
                                   remoto--forges))
  (setq remoto--handler-regexp
        (concat "\\`/\\(?:"
                (mapconcat #'regexp-quote (mapcar #'car remoto--forges) "\\|")
                "\\):"))
  (remoto--refresh-handler))

(defun remoto--prefix-of (string)
  "Return (PREFIX . FORGE) for the registered prefix at the head of STRING."
  (seq-find (lambda (entry)
              (string-prefix-p (concat "/" (car entry) ":") string))
            remoto--forges))

(defun remoto--canonical-forge (string)
  "Return the forge whose canonical prefix is the head of STRING, or nil."
  (when-let* (((stringp string))
              (entry (remoto--prefix-of string))
              ((equal (car entry) (car (remoto-forge-prefixes (cdr entry))))))
    (cdr entry)))

(defun remoto--after-prefix (name)
  "Return the text of the remoto NAME after its canonical prefix."
  (substring name (length (remoto--prefix (remoto--canonical-forge name)))))

;; Made anew at each load: a newer remoto loaded into a running session
;; redefines the struct, whose accessors fail on a record of the old shape.
(defconst remoto--github
  (remoto-github-create :name 'github :prefixes '("github" "gh")
                        :host "github.com" :delimiters '(?@ ?#))
  "The GitHub forge.  A `remoto-path' built without a forge is GitHub's.")

;;;; Forge contract

;; A forge answers these with plain data that the core turns into files,
;; Dired lines and candidates.  Data methods signal `remoto-unsupported'
;; by default; URL methods answer nil.  A repo is anything with a tree, a
;; ref anything that selects one, a topic an item with a key and a buffer.

(define-error 'remoto-unsupported "Remoto: the forge does not support this")

(defun remoto--unsupported (forge operation)
  "Signal `remoto-unsupported' for OPERATION on FORGE."
  (signal 'remoto-unsupported (list (remoto-forge-name forge) operation)))

(cl-defgeneric remoto-forge-default-ref (forge _owner _repo)
  "Return the name of the default branch of OWNER/REPO on FORGE.
A source without refs answers nil."
  (remoto--unsupported forge 'default-ref))

(cl-defgeneric remoto-forge-tree (forge _owner _repo _ref)
  "Return the tree of OWNER/REPO at REF on FORGE.
A hash table from path to entry, an alist with `type' (\"tree\" or
\"blob\"), `size', `sha' and `mode'; \"\" and \"/\" hold the root entry
and \"\\0truncated\" is t when the tree is partial."
  (remoto--unsupported forge 'tree))

(cl-defgeneric remoto-forge-directory-contents (forge _owner _repo _ref _dir)
  "Return the entries under DIR of OWNER/REPO at REF on FORGE.
A list of (PATH . ENTRY) with PATH from the repository root, asked for
when the tree is truncated."
  (remoto--unsupported forge 'directory-contents))

(cl-defgeneric remoto-forge-children (forge owner repo ref dir)
  "Return the direct children of DIR in OWNER/REPO at REF on FORGE.
A list of (NAME . ENTRY) cheap enough for completion; the tree answers
by default."
  (remoto--tree-children
   (remoto-path-create :forge forge :owner owner :repo repo :ref ref
                       :path (concat "/" dir))))

(cl-defgeneric remoto-forge-content (forge _owner _repo _ref _path)
  "Return the bytes of the file PATH of OWNER/REPO at REF on FORGE.
A unibyte string; the caller decodes it."
  (remoto--unsupported forge 'content))

(cl-defgeneric remoto-forge-resolve-ref (forge _owner _repo _ref)
  "Return the exact ref that REF names in OWNER/REPO on FORGE, for a permalink.
A commit SHA on a forge: the link keeps naming the same tree when REF
moves on."
  (remoto--unsupported forge 'resolve-ref))

(cl-defgeneric remoto-forge-refs (forge _owner _repo)
  "Return the refs of OWNER/REPO on FORGE as ((LABEL . NAMES) ...).
The groups and names come in listing order.  LABEL is the kind of each
of its NAMES, such as \"branch\" or \"tag\": the refs Dired and completion
show it beside each name."
  (remoto--unsupported forge 'refs))

(defun remoto--ref-label (groups ref)
  "Return the label of REF in GROUPS, as `remoto-forge-refs' gives them.
The first group with REF among its names gives its label."
  (car (seq-find (lambda (group) (member ref (cdr group))) groups)))

(cl-defgeneric remoto-forge-forget (_forge &optional _owner _repo)
  "Drop what FORGE caches of OWNER/REPO, or everything it caches without them.
`remoto-refresh' asks for one repository, `remoto-unload-function' for all."
  nil)

(cl-defgeneric remoto-forge-topics (forge _owner _repo _query)
  "Return the topics of OWNER/REPO on FORGE that match QUERY.
A nil or empty QUERY lists the open topics, newest first.  Each item is
the source's alist plus `key', the text after #, and `kind', \"issue\"
or \"pr\"."
  (remoto--unsupported forge 'topics))

(cl-defgeneric remoto-forge-topic (forge _owner _repo _key)
  "Return the topic KEY of OWNER/REPO on FORGE, or nil when KEY names none.
The item has `key' and `kind', as `remoto-forge-topics' gives them."
  (remoto--unsupported forge 'topic))

(cl-defgeneric remoto-forge-topic-comments (forge _owner _repo _key)
  "Return the comments of the topic KEY of OWNER/REPO on FORGE."
  (remoto--unsupported forge 'topic-comments))

(cl-defgeneric remoto-forge-topic-extra (_forge _owner _repo _key)
  "Return the extra data of topic KEY of OWNER/REPO on FORGE for its buffer.
Extra is what the buffer shows past title, body, state and comments.
A pull request on GitHub: ((pull-request . DATA) (reviews . REVIEWS))."
  nil)

(defun remoto--topic-key-p (forge key)
  "Return non-nil when KEY has the shape of a topic key of FORGE."
  (string-match-p (remoto-forge-topic-key forge) key))

(defun remoto--topic-key< (a b)
  "Return non-nil when topic key A comes before B, as numbers where both are."
  (if (and (string-match-p "\\`[0-9]+\\'" a) (string-match-p "\\`[0-9]+\\'" b))
      (< (string-to-number a) (string-to-number b))
    (string< a b)))

(cl-defgeneric remoto-forge-entry-notes (_forge _owner _repo _ref _dir _names)
  "Return (NAME . NOTE) for the NAMES under DIR of OWNER/REPO at REF on FORGE.
NOTE is the text shown after NAME in completion, such as the subject of
the last commit that touched it."
  nil)

(cl-defgeneric remoto-forge-entries (forge _path &optional _continuation _callback)
  "Return (ENTRIES . NEXT), a page of the listing at PATH on FORGE.
PATH is a `remoto-path' at level root or owner.  CONTINUATION names the
page, the first without it; NEXT names the next one, nil after the last.
With CALLBACK, return nil and later call it with the pair or `failed'."
  (remoto--unsupported forge 'entries))

(cl-defmethod remoto-forge-entries :around
  (_forge _path &optional _continuation callback)
  "Pass the page FORGE answers for PATH and CONTINUATION at once to CALLBACK.
So a method that ignores CALLBACK still serves the background pages."
  (when-let* ((page (cl-call-next-method)))
    (if callback
        (ignore (funcall callback page))
      page)))

(cl-defgeneric remoto-forge-complete (forge path query _wait)
  "Return the TAB candidates for QUERY at PATH, a root or owner path of FORGE.
An empty QUERY answers the accounts or the recent repositories, text a
search; a nil QUERY only warms the cache that an empty one reads.  With
WAIT, ask and answer; without it, answer from a cache and ask later."
  (if (and (equal query "") (eq (remoto-path-level path) 'root))
      (when (remoto--known-user forge)
        (mapcar #'remoto--account-login (car (remoto-forge-entries forge path))))
    (remoto--unsupported forge 'complete)))

(cl-defgeneric remoto-forge-parse-url (_forge _input)
  "Return the `remoto-path' that INPUT names on FORGE, or nil.
INPUT is a web URL, a git remote or a shorthand, at any level: the URL
of a topic gives the topics level with the topic key as its query."
  nil)

(cl-defgeneric remoto-forge-split (forge names &optional _wait)
  "Return (OWNER . REPO) for NAMES, the segments of a short form on FORGE.
OWNER is nil for a one-name repository.  Nil while FORGE cannot tell yet;
WAIT asks it to look the name up.  The default splits by the locator; an
`open' one needs a method, called from the rewrite and listing steps."
  (when-let* ((count (remoto--locator-count forge names))
              ((<= count (length names))))
    (cons (and (< 1 count) (string-join (seq-take names (1- count)) "/"))
          (nth (1- count) names))))

(defun remoto--locator-count (forge names)
  "Return how many of NAMES the locator of FORGE takes, nil for an open one."
  (let ((locator (remoto-forge-locator forge)))
    (cond ((integerp locator) locator)
          ((eq locator 'open) nil)
          (t (funcall locator names)))))

(defvar remoto--url-ref-lookup t
  "Non-nil when a forge may ask for its refs to split the ref of a URL.")

(defconst remoto--shorthand-regexp
  (rx bos (group (+ (not (in "/@")))) "/" (group (+ (not (in "/@"))))
      (? "@" (group (+ nonl))) eos)
  "Regexp of the bare OWNER/REPO[@REF], a GitHub name without a host.")

(defun remoto--parse-url (input &optional hosted)
  "Return the `remoto-path' that INPUT, a URL, remote or shorthand, names.
Each forge answers for a host in INPUT first; the bare OWNER/REPO[@REF],
GitHub's, comes last, so it never claims a URL of another forge.  Nil
when none answers.  HOSTED leaves the shorthand out: a relative file
name has its shape."
  (when (stringp input)
    (let ((shorthand (string-match-p remoto--shorthand-regexp input)))
      (or (seq-some (lambda (forge)
                      (and (not (and shorthand (eq forge remoto--github)))
                           (remoto-forge-parse-url forge input)))
                    (seq-uniq (mapcar #'cdr remoto--forges)))
          (and shorthand (not hosted)
               (remoto-forge-parse-url remoto--github input))))))

(defun remoto--url-shape (input)
  "Return the `remoto-path' of the URL or remote INPUT, refs not looked up.
The shape of INPUT is enough to tell its forge, level and topic."
  (let ((remoto--url-ref-lookup nil))
    (remoto--parse-url input t)))

(defun remoto--url-forge (input)
  "Return the forge for which INPUT is a URL or remote, or nil."
  (when-let* ((parsed (remoto--url-shape input)))
    (remoto-path-forge parsed)))

(defun remoto--path-at (forge level &optional owner repo query)
  "Return the `remoto-path' at LEVEL of FORGE that OWNER, REPO and QUERY name.
LEVEL is `root', `owner' or the level of a delimiter, such as `topics'."
  (remoto--parse (remoto--unparse
                  (remoto-path-create :forge forge :level level :owner owner
                                      :repo repo :query (or query "")))))

;;;; Path parsing

(cl-defstruct (remoto-delimiter (:constructor remoto-delimiter-create)
                                (:copier nil))
  "A character after OWNER/REPO that opens a level of its own."
  char level kind)

(defvar remoto--delimiters nil
  "Alist of (CHAR . `remoto-delimiter') that `remoto--parse' reads.")

(defun remoto-register-delimiter (char level kind)
  "Register CHAR as the delimiter after OWNER/REPO that opens LEVEL.
KIND is `ref' when the text after CHAR names a ref and a colon then
starts its tree, as `@' does, or `topic' when it names a topic that
opens in a buffer of its own, as `#' does.  A forge lists the
delimiters it supports; the others are plain characters in its paths."
  (setf (alist-get char remoto--delimiters)
        (remoto-delimiter-create :char char :level level :kind kind)))

(remoto-register-delimiter ?@ 'refs 'ref)
(remoto-register-delimiter ?# 'topics 'topic)
(remoto-register-forge remoto--github)

(defun remoto--delimiter-of (level)
  "Return the `remoto-delimiter' that opens LEVEL, or nil."
  (seq-find (lambda (d) (eq (remoto-delimiter-level d) level))
            (mapcar #'cdr remoto--delimiters)))

(defun remoto--level-kind (level)
  "Return the kind of the delimiter that opens LEVEL, or nil."
  (when-let* ((delimiter (remoto--delimiter-of level)))
    (remoto-delimiter-kind delimiter)))

(cl-defstruct (remoto-path (:constructor remoto-path-create)
                           (:copier nil))
  "Parsed components of a remoto path.
LEVEL names the directory the path is in, QUERY the text after it.
SHORT marks the /PREFIX:OWNER/REPO/PATH form, a tree on the default branch."
  (forge remoto--github) owner repo ref path level query string short)

(defun remoto--parse-tree (forge string owner repo ref raw short)
  "Build the `remoto-path' of STRING, a tree path of FORGE, from its parts.
OWNER, REPO and REF name the tree; RAW is the text after the colon, or
after the repository in the SHORT form.  A directory ends in a slash,
so the query is what follows the last one."
  (remoto-path-create
   :forge forge :owner owner :repo repo
   :ref (and ref (not (string-empty-p ref)) ref)
   :path (if (string-empty-p raw) "/" raw)
   :level 'tree
   :query (cond ((string-suffix-p "/" raw) "")
                ((string-match-p (rx "/" (* (not "/")) eos) raw)
                 (substring raw (1+ (string-match-p (rx "/" (* (not "/")) eos) raw))))
                (t raw))
   :string string :short short))

(defun remoto--parse (string)
  "Parse STRING, a partial or canonical remoto path, into a `remoto-path'.
Return nil unless STRING starts with the canonical prefix of a forge.
Every string with one parses: LEVEL is the deepest directory it names
and QUERY the text after that, so `remoto-path-directory' + QUERY is STRING."
  (when-let* ((forge (remoto--canonical-forge string)))
    (let ((rest (substring string (length (remoto--prefix forge))))
          (locator (remoto-forge-locator forge)))
      (if (eq locator 'open)
          (remoto--parse-open forge string rest)
        (let* ((count (if (integerp locator)
                          locator
                        (funcall locator (split-string rest "/"))))
               (slash (and (< 1 count) (remoto--nth-slash rest (1- count))))
               (owner (and slash (substring rest 0 slash)))
               (after-owner (if slash (substring rest (1+ slash)) (and (= count 1) rest)))
               (end (and after-owner
                         (string-match-p (remoto-forge-repo-end forge) after-owner)))
               (repo (and end (substring after-owner 0 end))))
          (cond
           ;; /PREFIX:QUERY, or /PREFIX:/... with no account name
           ((or (null after-owner) (and owner (string-empty-p owner))
                (and (null owner) (or (null end) (string-empty-p repo))))
            (remoto-path-create :forge forge :level 'root :query rest
                                :path "/" :string string))
           ;; /PREFIX:OWNER/QUERY: no delimiter yet, or one after no name
           ((or (null end) (string-empty-p repo))
            (remoto-path-create :forge forge :level 'owner :owner owner
                                :query after-owner :path "/" :string string))
           (t (remoto--parse-after-repo forge string owner repo
                                        (aref after-owner end)
                                        (substring after-owner (1+ end))))))))))

(defun remoto--nth-slash (string n &optional start)
  "Return the position of the Nth slash in STRING from START, or nil."
  (when-let* ((slash (string-search "/" string start)))
    (if (< 1 n) (remoto--nth-slash string (1- n) (1+ slash)) slash)))

(defun remoto--parse-open (forge string rest)
  "Parse REST, the text of STRING after the prefix of FORGE, an `open' locator.
A delimiter or colon ends the repository and the slash before it the
owner.  Without either the name stays unresolved at the owner level, its
last segment the query, until `remoto--split-open' asks FORGE."
  (let* ((end (string-match-p (remoto-forge-repo-end forge) rest))
         (slash (cl-position ?/ rest :end end :from-end t)))
    (if (or (null slash) (= slash 0))
        (remoto-path-create :forge forge :level 'root :query rest
                            :path "/" :string string)
      (let ((owner (substring rest 0 slash)))
        (if (or (null end) (= end (1+ slash)))
            (remoto-path-create :forge forge :level 'owner :owner owner
                                :query (substring rest (1+ slash))
                                :path "/" :string string)
          (remoto--parse-after-repo forge string owner
                                    (substring rest (1+ slash) end)
                                    (aref rest end) (substring rest (1+ end))))))))

(defun remoto--parse-after-repo (forge string owner repo char tail)
  "Parse STRING of FORGE, which names OWNER/REPO, CHAR and then TAIL.
CHAR is a colon, a slash that starts the short form, or a delimiter."
  (pcase char
    (?: (remoto--parse-tree forge string owner repo nil tail nil))
    (?/ (remoto--parse-tree forge string owner repo nil (concat "/" tail) t))
    (_
     (let* ((delimiter (alist-get char remoto--delimiters))
            (colon (and (eq (remoto-delimiter-kind delimiter) 'ref)
                        (string-search ":" tail))))
       (if colon
           (remoto--parse-tree forge string owner repo
                               (substring tail 0 colon)
                               (substring tail (1+ colon)) nil)
         (remoto-path-create :forge forge
                             :level (remoto-delimiter-level delimiter)
                             :owner owner :repo repo :query tail
                             :path "/" :string string))))))

(defun remoto-path-directory (parsed)
  "Return the directory part of PARSED: its string without its query."
  (let ((string (remoto-path-string parsed)))
    (substring string 0 (- (length string) (length (remoto-path-query parsed))))))

(defun remoto--directory-level (directory)
  "Return the level that DIRECTORY, a remoto directory name, is at, or nil.
A name with a query after its level is no directory, except in a tree,
where a canonical name without a trailing slash lists its parent."
  (when-let* ((parsed (remoto--parse directory)))
    (let ((level (remoto-path-level parsed)))
      (and (or (eq level 'tree) (string-empty-p (remoto-path-query parsed)))
           level))))

(defun remoto--parse-path (filename)
  "Parse canonical remoto FILENAME into a `remoto-path' struct.
Returns nil if FILENAME does not match the canonical format."
  (when-let* ((parsed (remoto--parse filename))
              ((eq (remoto-path-level parsed) 'tree))
              ((not (remoto-path-short parsed))))
    parsed))

(defun remoto--path-prefix (parsed)
  "Return the canonical prefix of the forge of PARSED, such as /github:."
  (remoto--prefix (remoto-path-forge parsed)))

(defun remoto--tree-prefix (parsed)
  "Return the /PREFIX:OWNER/REPO[@REF]: prefix of the canonical PARSED."
  (let ((owner (remoto-path-owner parsed))
        (ref (remoto-path-ref parsed)))
    (concat (remoto--path-prefix parsed)
            (remoto--repo-name owner (remoto-path-repo parsed)) (and ref "@") ref ":")))

(defun remoto--canonical-path (parsed)
  "Build a canonical remoto path string from PARSED `remoto-path'."
  (concat (remoto--tree-prefix parsed) (or (remoto-path-path parsed) "/")))

(defun remoto--unparse (parsed)
  "Build the remoto path string of PARSED, the inverse of `remoto--parse'.
A canonical tree path comes back with the slash after its colon.  A
one-name repository has no OWNER, so no slash comes before its name."
  (let ((prefix (remoto--path-prefix parsed))
        (owner (remoto-path-owner parsed))
        (repo (remoto-path-repo parsed))
        (query (remoto-path-query parsed)))
    (pcase (remoto-path-level parsed)
      ('root (concat prefix query))
      ('owner (concat prefix owner "/" query))
      ('tree (if (remoto-path-short parsed)
                 (concat prefix (remoto--repo-name owner repo) (remoto-path-path parsed))
               (remoto--canonical-path parsed)))
      (level (concat prefix (remoto--repo-name owner repo)
                     (char-to-string
                      (remoto-delimiter-char (remoto--delimiter-of level)))
                     query)))))

(defun remoto--repo-name (owner repo)
  "Return the name of REPO of OWNER as a forge writes it: OWNER/REPO.
A one-name source has a nil OWNER, and its name is REPO alone."
  (concat owner (and owner "/") repo))

(defun remoto--repo-id (forge owner repo)
  "Return the cache key of OWNER/REPO on FORGE: its canonical name.
Two forges may host an OWNER/REPO each, so the prefix is part of the key."
  (concat (remoto--prefix forge) (remoto--repo-name owner repo)))

(defun remoto--repo-key (parsed)
  "Return the cache key of the tree PARSED names: /PREFIX:OWNER/REPO@REF."
  (format "%s@%s"
          (remoto--repo-id (remoto-path-forge parsed)
                           (remoto-path-owner parsed)
                           (remoto-path-repo parsed))
          (or (remoto-path-ref parsed) "HEAD")))

;;;; Options, auth and the ghub transport

(declare-function dired-get-filename "dired" (&optional localp no-error-if-not-filep))
(declare-function dired-goto-file "dired" (file))

(defgroup remoto nil
  "Browse the repositories of GitHub, Codeberg and other forges without cloning."
  :group 'tools
  :prefix "remoto-")

(defcustom remoto-github-auth nil
  "How remoto authenticates to GitHub.
nil looks the token up in auth-source, where `remoto-login' stores it;
`none' never sends a token; a string is the token itself."
  :type '(choice (const :tag "Look the token up" nil)
                 (const :tag "Send no token" none)
                 (string :tag "Literal token"))
  :group 'remoto)

(defcustom remoto-auth-timeout 10
  "Unused: remoto looks its tokens up itself, without ghub's own lookup."
  :type 'number
  :group 'remoto)
(make-obsolete-variable 'remoto-auth-timeout nil "2.5.0")

(defcustom remoto-search-cache-ttl 300
  "Seconds before cached API results expire.
Set to 0 to disable caching.  Applies to the search, branch, and
directory-listing caches.  Defined early so functions above the
\"Repository search\" section can reference it at byte-compile time."
  :type 'integer
  :group 'remoto)

(cl-defstruct (remoto--login (:constructor remoto--login-create)
                             (:copier nil))
  "What remoto knows of its login at one API host.
FAILED: anonymous reads until `remoto-reset-auth' or `remoto-login'.
TOKEN is the token in use, ACCOUNT the name in its row, USER the account
the forge answered for it; HINTED, DECLINED and REFUSED last the session."
  failed token user account hinted declined refused)

(defvar remoto--logins (make-hash-table :test 'equal)
  "Login state by API host, each a `remoto--login'.
Forges on one host, such as GitHub and gists, share one entry.")

(defun remoto--login (host)
  "Return the `remoto--login' of the API host HOST, made on first use."
  (or (gethash host remoto--logins)
      (puthash host (remoto--login-create) remoto--logins)))

(defun remoto--forget-stale-logins ()
  "Forget the logins an older remoto made, which lack this one's slots.
Loading remoto again in a running Emacs, as an upgrade does, keeps them."
  (maphash (lambda (host login)
             (unless (ignore-errors (listp (remoto--login-refused login)))
               (remhash host remoto--logins)))
           remoto--logins))

(remoto--forget-stale-logins)

(cl-defgeneric remoto--api-host (forge)
  "Return the host `remoto--api' sends the requests of FORGE to.
In ghub's spelling, with the path of the API: \"api.github.com\",
\"codeberg.org/api/v1\".")

(cl-defmethod remoto--api-host ((_forge remoto-github))
  "GitHub's API host."
  "api.github.com")

(cl-defgeneric remoto--ghub-forge (forge)
  "Return the symbol ghub knows the kind of FORGE by, nil for GitHub.")

(cl-defmethod remoto--ghub-forge ((_forge remoto-github))
  "GitHub is ghub's default kind."
  nil)

(defun remoto--forge-login (forge)
  "Return the `remoto--login' at the API host of FORGE."
  (remoto--login (remoto--api-host forge)))

(defun remoto--ghub-username (forge auth)
  "Return the `:username' for a request to FORGE with AUTH, or nil.
ghub reads git config for a name it is not given, even with a token in
hand, and uses the name for nothing then, so any name serves."
  (and (stringp auth)
       (let ((login (remoto--forge-login forge)))
         (or (remoto--login-account login) (remoto--login-user login) "remoto"))))

(defun remoto--json-reader (_status)
  "Parse JSON response with list-type arrays for remoto compatibility.
Finds the JSON body by scanning for the first `{' or `[',
handling both header-present and header-stripped response buffers
across different ghub and url.el versions."
  (goto-char (point-min))
  (when (re-search-forward "[{[]" nil t)
    (backward-char 1)
    (let ((body (buffer-substring-no-properties (point) (point-max))))
      (unless (string-empty-p body)
        (condition-case nil
            (json-parse-string
             (decode-coding-string body 'utf-8)
             :object-type 'alist
             :array-type 'list
             :null-object nil
             :false-object nil)
          (json-error nil))))))

;;;; Fetch indicator

(defcustom remoto-show-fetch-indicator t
  "When non-nil, show a \"fetching\" indicator during forge requests.
While completing a remoto path (e.g. with \\[find-file]) or at the
`remoto-browse' prompt, it is drawn as minibuffer text, so it works with
any completion UI (vertico, icomplete, default, ...).  A fetch that
blocks with no such prompt up, as when the chosen path opens, shows it
in the echo area instead."
  :type 'boolean
  :group 'remoto)

(defvar remoto--inflight-count 0
  "Number of API requests the minibuffer overlay stands for.
Every async request of the completion counts, and so does a blocking
fetch that runs while a remoto prompt is up.")

(defvar remoto--status-overlay nil
  "Overlay holding the fetch indicator slot in the active minibuffer.")

(defconst remoto--fetch-indicator-text
  (propertize "⟳" 'face 'shadow)
  "Circle arrow shown by the fetch indicator in both contexts.
Reused by the minibuffer slot and the echo-area message so the two read
identically.  One character, because a word in the minibuffer scrolls
the line as it comes and goes; a text character rather than an emoji,
because a color glyph is taller than the line it sits in and ignores
the `shadow' face.")

(defconst remoto--fetch-indicator-blank
  (make-string (string-width remoto--fetch-indicator-text) ?\s)
  "What the indicator's slot holds between requests.")

(defun remoto--clear-status ()
  "Remove the fetch indicator slot, if any."
  (when (overlayp remoto--status-overlay)
    (delete-overlay remoto--status-overlay))
  (setq remoto--status-overlay nil))

(defun remoto--render-status (buffer busy)
  "Draw the fetch indicator slot in BUFFER, filled when BUSY.
The slot sits between the prompt and the input, never after it.  Emacs
draws the cursor after any string that follows point, and a completion
UI that opens its candidate list there claims the `cursor' property for
its own string - Vertico does - so an indicator after the input drags
the cursor sideways on every request.  The blank keeps the slot's width
between requests, so the input does not shift either."
  (with-current-buffer buffer
    (let ((pos (minibuffer-prompt-end)))
      (unless (and (overlayp remoto--status-overlay)
                   (eq (overlay-buffer remoto--status-overlay) buffer))
        (remoto--clear-status)
        (setq remoto--status-overlay (make-overlay pos pos)))
      (move-overlay remoto--status-overlay pos pos)
      (overlay-put remoto--status-overlay 'priority 1000)
      (overlay-put remoto--status-overlay 'before-string
                   (concat (if busy
                               remoto--fetch-indicator-text
                             remoto--fetch-indicator-blank)
                           " ")))))

(defun remoto--hide-status ()
  "Blank the fetch indicator, keeping its slot while the prompt is up.
A slot that came and went would shift the input left and right as
requests come and go, which is what drawing it at all has to avoid."
  (let ((buf (and (overlayp remoto--status-overlay)
                  (overlay-buffer remoto--status-overlay))))
    (if (and (buffer-live-p buf) (minibufferp buf))
        (remoto--render-status buf nil)
      (remoto--clear-status))))

(defun remoto--completion-minibuffer ()
  "Return the active minibuffer when it is completing for remoto, else nil.
That is a file name inside a remoto path, with either prefix and possibly
behind a shadowed directory (\"~/x//gh:o/\") the way `read-file-name'
reads it, or the `remoto-browse' prompt, whose collection is
`remoto--repo-completion-table'.  A prompt opened inside a remoto
directory counts even with nothing typed: `read-file-name' puts its DIR
argument in the minibuffer's `default-directory', and completion keeps
fetching from there after \\[move-beginning-of-line] \\[kill-line]."
  (when-let* ((win (active-minibuffer-window))
              (buf (window-buffer win)))
    (with-current-buffer buf
      (and (or (eq minibuffer-completion-table #'remoto--repo-completion-table)
               (string-match-p remoto--handler-regexp
                               (condition-case nil
                                   (substitute-in-file-name
                                    (minibuffer-contents-no-properties))
                                 (error "")))
               (string-match-p remoto--handler-regexp
                               (or default-directory "")))
           buf))))

(defun remoto--show-status ()
  "Show the in-flight fetch indicator in the active remoto minibuffer.
No-op unless `remoto-show-fetch-indicator' is non-nil and the active
minibuffer is one that `remoto--completion-minibuffer' recognizes.
Drawn as minibuffer text so it works with any completion UI."
  (when remoto-show-fetch-indicator
    (when-let* ((buf (remoto--completion-minibuffer)))
      (remoto--render-status buf t))))

(defun remoto--inflight-inc ()
  "Register a new in-flight async request and show the indicator."
  (setq remoto--inflight-count (1+ remoto--inflight-count))
  (remoto--show-status))

(defun remoto--inflight-dec ()
  "Mark one in-flight async request as finished.
Blank the indicator once no requests remain."
  (setq remoto--inflight-count (max 0 (1- remoto--inflight-count)))
  (when (zerop remoto--inflight-count)
    (remoto--hide-status)))

(defun remoto--minibuffer-exit-cleanup ()
  "Reset in-flight indicator state when a minibuffer exits."
  (remoto--clear-status)
  (setq remoto--inflight-count 0))

(defvar remoto--sync-fetch-depth 0
  "Nesting depth of `remoto--with-fetch-indicator' bodies.
Only the outermost body draws and clears the indicator, so a command
wrapped as a whole and the API calls inside it draw it once.")

(defvar remoto--sync-fetch-overlay nil
  "Non-nil while the outermost blocking fetch is drawn as the minibuffer overlay.
Decides which of the two indicators the end of that fetch clears.")

(defun remoto--sync-fetch-begin ()
  "Draw the indicator for the blocking fetch about to begin.
In a remoto completion minibuffer that is the overlay of the async
fetches, painted at once because nothing redisplays while the fetch
blocks; anywhere else it is an echo-area message, which the echo area
shows at once."
  (setq remoto--sync-fetch-depth (1+ remoto--sync-fetch-depth))
  (when (= remoto--sync-fetch-depth 1)
    (setq remoto--sync-fetch-overlay (and (remoto--completion-minibuffer) t))
    (if remoto--sync-fetch-overlay
        (progn (remoto--inflight-inc)
               (redisplay))
      (let ((message-log-max nil))
        (message "Remoto %s" remoto--fetch-indicator-text)))))

(defun remoto--sync-fetch-end ()
  "Clear the indicator once the outermost blocking fetch is over.
A message that something else put up meanwhile is left alone."
  (setq remoto--sync-fetch-depth (max 0 (1- remoto--sync-fetch-depth)))
  (when (zerop remoto--sync-fetch-depth)
    (if remoto--sync-fetch-overlay
        (remoto--inflight-dec)
      (when (equal (current-message)
                   (format "Remoto %s" remoto--fetch-indicator-text))
        (let ((message-log-max nil))
          (message nil))))
    (setq remoto--sync-fetch-overlay nil)))

(defmacro remoto--with-fetch-indicator (&rest body)
  "Run BODY, a blocking forge round-trip, with the fetch indicator up.
Every synchronous API call goes through this, so `remoto-browse' and a
path at `find-file' or `dired' show the same thing: the minibuffer
overlay while completing, the echo area once the prompt is gone.
Honors `remoto-show-fetch-indicator' and does nothing in batch, where
there is no display.  Returns BODY's value."
  (declare (indent 0) (debug t))
  `(if (or noninteractive (not remoto-show-fetch-indicator))
       (progn ,@body)
     (remoto--sync-fetch-begin)
     (unwind-protect
         (progn ,@body)
       (remoto--sync-fetch-end))))

(cl-defstruct (remoto--request (:constructor remoto--request-create))
  "A forge request started under `while-no-input'."
  (status 'pending)
  buffer
  value
  headers)

(defvar remoto--response-headers nil
  "The headers of the answer that `remoto--ghub-get' read last.
Bind it around a call to read the headers of that call's answer.")

(defvar remoto--pending-requests (make-hash-table :test 'equal)
  "Requests started under `while-no-input', keyed by (HOST RESOURCE AUTH).
Such a request outlives the completion call that started it: the reply
lands in its `remoto--request', and the next call for the same key
waits on that request or reads the landed reply instead of asking
the forge again.  A failed request leaves the table, so the next call
retries.")

(defun remoto--request-condition (err host resource)
  "Turn ERR, as ghub hands it to an errorback, into the condition ghub signals.
HOST and RESOURCE name the request in the condition data."
  (pcase err
    (`(error http ,code . ,rest)
     (list 'ghub-http-error code (nth 2 (assq code url-http-codes))
           (concat "https://" host resource) (car rest)))
    (`(error . ,data) (cons 'ghub-error data))
    (_ err)))

(defun remoto--request-start (key forge resource auth)
  "Start a callback request to FORGE for RESOURCE with AUTH, registered under KEY."
  (let ((req (remoto--request-create))
        (host (remoto--api-host forge)))
    (setf (remoto--request-buffer req)
          (ghub-get resource nil
                    :auth auth
                    :username (remoto--ghub-username forge auth)
                    :reader #'remoto--json-reader
                    :host host
                    :forge (remoto--ghub-forge forge)
                    :callback (lambda (value &optional headers &rest _)
                                (setf (remoto--request-value req) value
                                      (remoto--request-headers req) headers
                                      (remoto--request-status req) 'done))
                    :errorback (lambda (err &optional headers &rest _)
                                 (remhash key remoto--pending-requests)
                                 (setf (remoto--request-value req)
                                       (remoto--request-condition err host resource)
                                       (remoto--request-headers req) headers
                                       (remoto--request-status req) 'error))))
    (puthash key req remoto--pending-requests)
    req))

(defun remoto--auth-key (auth)
  "Return a stable identity for AUTH that is not the credential itself.
`remoto--pending-requests' only has to tell two callers apart, and its
keys are readable in a backtrace or a variable dump, so a token string
goes in hashed.  A symbol such as `none' is no secret and stays as is."
  (if (stringp auth) (secure-hash 'sha256 auth) auth))

(defun remoto--ghub-get-interruptible (forge resource auth)
  "GET RESOURCE of FORGE with AUTH through a callback, in a way input can end.
`url-retrieve-synchronously' leaves its buffer behind when `while-no-input'
throws past it, and the reply nobody reads keeps the buffer alive; ghub
kills the buffer of a callback request itself once the reply is handled.
Return the value or signal the condition the synchronous call would."
  (let* ((key (list (remoto--api-host forge) resource (remoto--auth-key auth)))
         (req (or (gethash key remoto--pending-requests)
                  (remoto--request-start key forge resource auth))))
    (while (and (eq (remoto--request-status req) 'pending)
                (buffer-live-p (remoto--request-buffer req)))
      (accept-process-output nil 0.1))
    (remhash key remoto--pending-requests)
    (pcase (remoto--request-status req)
      ('done (setq remoto--response-headers (remoto--request-headers req))
             (remoto--request-value req))
      ;; `remoto--ghub-get' binds these around this call and reads them
      ;; for the message, as after a synchronous request.
      ('error (let ((err (remoto--request-value req)))
                (setq ghub-response-headers (remoto--request-headers req))
                (signal (car err) (cdr err))))
      (_ (error "Remoto: no reply for %s" resource)))))

(defconst remoto--not-found "Remoto: not found: "
  "How the `user-error' for an answer of 404 starts, or of 422 to a search.
Forgejo's 400 for a ref it lacks is one too.
Callers that take a missing resource for an answer test for it: a child
error of `user-error' would print its message in quotes.")

(defconst remoto--auth-rejected "Remoto: authentication failed for "
  "How the `user-error' for an answer of 401 starts, the API host after it.
`remoto--api' tests for it to go on without the token that was refused.")

(defun remoto--error-payload-message (err)
  "Return the message in the body that came with ERR, a `ghub-http-error'."
  (let ((payload (nth 4 err)))
    (and (listp payload) (stringp (alist-get 'message payload))
         (alist-get 'message payload))))

(defun remoto--http-error-message (forge endpoint err headers)
  "Return the message for ERR, the `ghub-http-error' of ENDPOINT on FORGE.
HEADERS came with the answer; a Retry-After among them says how long to wait."
  (let ((code (nth 1 err))
        (wait (cdr (assoc-string "retry-after" headers t)))
        (detail (remoto--error-payload-message err)))
    (concat (format "Remoto: %s " (remoto--api-host forge))
            (if (eql code 429)
                (format "rate limited %s (429)" endpoint)
              (format "answered %s%s for %s" code
                      (if (nth 2 err) (concat " " (nth 2 err)) "") endpoint))
            (and detail (concat ": " detail))
            (cond ((null wait) (and (eql code 429) "; retry later"))
                  ((string-match-p "\\`[0-9]+\\'" wait)
                   (format "; retry in %s seconds" wait))
                  (t (format "; retry after %s" wait))))))

(defconst remoto--rate-limited " rate limited until "
  "What a rate-limit `user-error' says between the forge and the time.
`remoto--api' looks for it to offer a login.")

(defun remoto--rate-limit-reset (headers)
  "Return the time the rate limit HEADERS report ends, or nil.
GitHub sends x-ratelimit-remaining and x-ratelimit-reset; a server that
asks the client to wait sends Retry-After, in seconds."
  (let ((remaining (cdr (assoc-string "x-ratelimit-remaining" headers t)))
        (reset (cdr (assoc-string "x-ratelimit-reset" headers t)))
        (wait (cdr (assoc-string "retry-after" headers t))))
    (cond ((and wait (string-match-p "\\`[0-9]+\\'" wait))
           (time-add nil (string-to-number wait)))
          ((and (equal remaining "0") reset (string-match-p "\\`[0-9]+\\'" reset))
           (string-to-number reset)))))

(defun remoto--rate-limited-message (forge reset auth)
  "Return the message for FORGE rate limiting a request with AUTH until RESET.
Without a token it names `remoto-login', which lifts GitHub's limit."
  (concat "Remoto: " (remoto-forge-title forge) remoto--rate-limited
          (format-time-string "%H:%M" reset)
          (and (eq auth 'none) (remoto--login-tail))))

(defun remoto--ghub-get (forge resource auth endpoint)
  "Call `ghub-get' on RESOURCE of FORGE with AUTH, translating errors.
ENDPOINT is used in error messages for context.  The host is always
explicit: ghub's default for a forge is its web host, which answers HTML."
  ;; A synchronous ghub-get leaves the headers of its answer here, so
  ;; the binding holds this request's and no earlier one's.
  (let ((ghub-response-headers nil))
    (condition-case err
        (remoto--with-fetch-indicator
          (let ((inhibit-message (not ghub-debug)))
            ;; `while-no-input' binds `throw-on-input'; only then can input
            ;; abandon the call, and only then is the callback path needed.
            (if throw-on-input
                (remoto--ghub-get-interruptible forge resource auth)
              (prog1 (ghub-get resource nil
                               :auth auth
                               :username (remoto--ghub-username forge auth)
                               :reader #'remoto--json-reader
                               :host (remoto--api-host forge)
                               :forge (remoto--ghub-forge forge))
                (setq remoto--response-headers ghub-response-headers)))))
      ;; ghub signals every HTTP failure as (ghub-http-error CODE MESSAGE URL
      ;; PAYLOAD); there are no per-status error symbols to match on.
      (ghub-http-error
       (pcase (cadr err)
         ((and (or 403 429)
               (let reset (remoto--rate-limit-reset ghub-response-headers))
               (guard reset))
          (user-error "%s" (remoto--rate-limited-message forge reset auth)))
         ;; A search answers 422 when its user: qualifier names no account.
         ((or 404 422) (user-error "%s%s" remoto--not-found endpoint))
         ;; Forgejo answers 400 "sha not found [REF]" to a ref it lacks.
         ((and 400 (guard (string-match-p "not found"
                                          (or (remoto--error-payload-message err) ""))))
          (user-error "%s%s" remoto--not-found endpoint))
         (403 (user-error "Remoto: access denied (rate limit or permissions): %s"
                          endpoint))
         (401 (user-error "%s%s%s" remoto--auth-rejected (remoto--api-host forge)
                          (remoto--login-tail)))
         (_ (user-error "%s" (remoto--http-error-message
                              forge endpoint err ghub-response-headers)))))
      (json-error
       (user-error "Remoto: could not parse API response for %s" endpoint)))))

(defun remoto--login-keys ()
  "Return how to call `remoto-login', in the face Emacs gives keys.
Plain outside a command: Emacs prints a timer's error with %S, where the
face would show as text properties."
  (let ((keys (substitute-command-keys "\\[remoto-login]")))
    (if this-command keys (substring-no-properties keys))))

(defun remoto--login-tail ()
  "Return the end of a message that names `remoto-login'."
  (concat ". " (remoto--login-keys)))

(cl-defgeneric remoto--literal-token (_forge)
  "Return the auth of FORGE from a user option: a token, `none' or nil."
  nil)

(cl-defmethod remoto--literal-token ((_forge remoto-github))
  "A string `remoto-github-auth' is GitHub's token, and `none' none."
  (and (or (stringp remoto-github-auth) (eq remoto-github-auth 'none))
       remoto-github-auth))

(defun remoto--auth (forge)
  "Return the `:auth' for a request to FORGE: a token or `none'.
A token found once stays in the login of the host, so later calls skip
the auth-source search; without one, the login reads anonymously until
`remoto-reset-auth' or `remoto-login'."
  (let ((login (remoto--forge-login forge)))
    (cond ((remoto--login-failed login) 'none)
          ((remoto--login-token login))
          ((let ((token (remoto--literal-token forge)))
             (and token (not (member token (remoto--login-refused login))) token)))
          ((when-let* ((token (remoto--find-token forge)))
             (setf (remoto--login-token login) token)))
          (t (setf (remoto--login-failed login) t)
             'none))))

(defun remoto--account-endpoint-p (endpoint)
  "Return non-nil when ENDPOINT is of the token's account, user and below.
Asked without a token, those answer 401, which url.el takes for a cue to
prompt for a password."
  (string-match-p (rx bos "user" (or eos (in "/?"))) endpoint))

(defun remoto--anonymous-get (forge endpoint)
  "GET ENDPOINT of the API of FORGE without a token.
An endpoint of the token's account is not asked: see
`remoto--account-endpoint-p'."
  (if (remoto--account-endpoint-p endpoint)
      (user-error "Remoto: %s needs a token for %s" endpoint (remoto--api-host forge))
    (remoto--ghub-get forge (concat "/" endpoint) 'none endpoint)))

(defun remoto--refuse-token (forge token)
  "Drop TOKEN, which FORGE refused; return non-nil with another token in place.
The next token of auth-source comes first, then a login when remoto may
ask; else remoto says so and reads anonymously until `remoto-reset-auth'."
  (let ((login (remoto--forge-login forge))
        (title (remoto-forge-title forge)))
    (push token (remoto--login-refused login))
    (setf (remoto--login-token login) nil)
    (if-let* ((next (remoto--find-token forge))
              ((not (member next (remoto--login-refused login)))))
        (progn
          (setf (remoto--login-token login) next)
          (message (if (equal token (remoto--literal-token forge))
                       "Remoto: %s refused the token in remoto-github-auth, \
using the one auth-source holds"
                     "Remoto: %s refused a token, using the next one auth-source holds")
                   title)
          t)
      (setf (remoto--login-failed login) t
            (remoto--login-hinted login) t)
      (or (remoto--offer-login forge (format "%s refused the token. Log in again? " title))
          (progn (message "Remoto: %s refused the token. %s" title (remoto--login-keys))
                 nil)))))

(defun remoto--api (forge endpoint)
  "Call ENDPOINT of the REST API of FORGE via ghub, return parsed JSON.
ENDPOINT has no leading slash.  A refused token, or a rate limit without
one, offers a login when remoto may ask, and the request goes again after
it; a refused token not replaced is dropped, and the request goes without."
  (let ((auth (remoto--auth forge)))
    (if (eq auth 'none)
        (condition-case err
            (remoto--anonymous-get forge endpoint)
          (user-error
           (if (remoto--offer-login-for-limit forge (cadr err))
               (remoto--api forge endpoint)
             (signal (car err) (cdr err)))))
      (condition-case err
          (remoto--ghub-get forge (concat "/" endpoint) auth endpoint)
        (user-error
         (unless (string-prefix-p remoto--auth-rejected (cadr err))
           (signal (car err) (cdr err)))
         (if (remoto--refuse-token forge auth)
             (remoto--api forge endpoint)
           (remoto--anonymous-get forge endpoint)))))))

(cl-defgeneric remoto--page-params (_forge count &optional page)
  "Return the query that asks FORGE for COUNT items, those of PAGE.
In GitHub's spelling by default."
  (concat (format "per_page=%d" count)
          (and page (format "&page=%d" page))))

(cl-defgeneric remoto--page-size (_forge)
  "Return the most items FORGE lists per page."
  100)

(cl-defgeneric remoto--paginated-api (forge endpoint &optional max-pages)
  "Fetch all pages of the paginated ENDPOINT of FORGE via `remoto--api'.
Request `remoto--page-size' items per page, following pages until a
short page is returned or MAX-PAGES (default 10) is reached.  The cap
bounds latency and request count on very large repositories."
  (let ((query-endpoint (concat endpoint (if (cl-search "?" endpoint) "&" "?")))
        (per-page (remoto--page-size forge)))
    (cl-loop for page from 1 to (or max-pages 10)
             for page-data = (remoto--api
                              forge
                              (concat query-endpoint
                                      (remoto--page-params forge per-page page)))
             append page-data
             until (< (length page-data) per-page))))

(defun remoto-reset-auth (&optional host)
  "Forget the login state of every API host, retrying the token lookup next.
With HOST, one of them, interactively with a prefix argument; an empty
HOST is every host.  Use after adding a token to auth-source."
  (interactive
   (list (and current-prefix-arg
              (completing-read "Remoto: reset the login of host (empty for all): "
                               (hash-table-keys remoto--logins) nil t))))
  (when (equal host "")
    (setq host nil))
  (if host
      (remhash host remoto--logins)
    (clrhash remoto--logins))
  ;; auth-source remembers a failed search for `auth-source-cache-expiry'.
  (auth-source-forget-all-cached)
  (message "Remoto: login state cleared for %s; retrying the token lookup \
on the next request" (or host "every host")))

;;;; Login

(defvar epa-file-encrypt-to)

(cl-defgeneric remoto--token-url (_forge)
  "Return the address of the page for a new token of FORGE, filled in.
GitHub's classic page, with its scopes ticked: a fine-grained token lists
no organizations."
  "https://github.com/settings/tokens/new?scopes=repo,read:org&description=remoto")

(cl-defgeneric remoto--token-prompt (forge)
  "Return the prompt for a token of FORGE."
  (format "%s token: " (remoto-forge-title forge)))

(defun remoto--buffer-forge ()
  "Return the forge of the remoto path of the current buffer, or nil."
  (when-let* ((name (or buffer-file-name
                        (and (derived-mode-p 'dired-mode) default-directory)
                        (bound-and-true-p remoto-topic--repo-path)))
              (parsed (remoto--parse name)))
    (remoto-path-forge parsed)))

(defun remoto--read-forge (prompt)
  "Read a registered forge with PROMPT, the forge of the current buffer first."
  (let* ((forges (seq-uniq (mapcar #'cdr remoto--forges)))
         (default (remoto-forge-title (or (remoto--buffer-forge) remoto--github)))
         (title (completing-read (format-prompt prompt default)
                                 (mapcar #'remoto-forge-title forges)
                                 nil t nil nil default)))
    (seq-find (lambda (forge) (equal (remoto-forge-title forge) title)) forges)))

(defun remoto--token-account (forge token)
  "Return the account of TOKEN on FORGE, or signal that the forge refused it."
  (condition-case err
      (alist-get 'login (remoto--ghub-get forge "/user" token "user"))
    (user-error
     (if (string-prefix-p remoto--auth-rejected (cadr err))
         (user-error "Remoto: %s refused the token" (remoto-forge-title forge))
       (signal (car err) (cdr err))))
    (error
     (user-error "Remoto: %s did not answer the check of the token: %s"
                 (remoto-forge-title forge) (error-message-string err)))))

(defun remoto--token-file ()
  "Return the first .gpg file of `auth-sources', or nil."
  (seq-some (lambda (source)
              (let ((file (if (consp source) (plist-get source :source) source)))
                (and (stringp file) (string-suffix-p ".gpg" file)
                     (expand-file-name file))))
            auth-sources))

(defun remoto--store-token (forge account token)
  "Store TOKEN of ACCOUNT on FORGE in the first .gpg file of `auth-sources'.
Return the file, or nil without one.  remoto's earlier line for the host
goes; the file is edited as `auth-source-netrc-saver' edits it, since
auth-source's own create keeps an existing row."
  (when-let* ((file (remoto--token-file)))
    (let ((host (remoto-forge-host forge)))
      (with-temp-buffer
        (when (file-exists-p file)
          (insert-file-contents file))
        ;; A local value, nil too, spares Emacs's list of keys to pick; nil
        ;; encrypts with a passphrase.  An existing file sets its own keys here.
        (when auth-source-gpg-encrypt-to
          (unless (local-variable-p 'epa-file-encrypt-to)
            (make-local-variable 'epa-file-encrypt-to))
          (when (listp auth-source-gpg-encrypt-to)
            (setq epa-file-encrypt-to auth-source-gpg-encrypt-to)))
        (goto-char (point-min))
        (flush-lines (concat "^machine " (regexp-quote host) " login [^ \t\n]+\\^remoto "))
        (goto-char (point-min))
        (insert (format "machine %s login %s^remoto password %s\n" host account token))
        (write-region nil nil file nil 'silent))
      (set-file-modes file #o600)
      (auth-source-forget-all-cached)
      file)))

(defvar xterm-store-paste-on-kill-ring)

(defun remoto--forget-kill (token)
  "Take TOKEN, pasted at the prompt for it, out of the kill ring."
  (setq kill-ring (seq-remove (lambda (text)
                                (equal (string-trim (substring-no-properties text)) token))
                              kill-ring)
        kill-ring-yank-pointer kill-ring))

(defun remoto--read-token (forge)
  "Open FORGE's page for a new token and read the token.
The page's address goes to *Messages*, and into the prompt when no browser
opens.  A pasted token stays out of the kill ring."
  (let* ((url (remoto--token-url forge))
         (prompt (remoto--token-prompt forge))
         (opened (progn (message "Remoto: make a %s token at %s"
                                 (remoto-forge-title forge) url)
                        (condition-case nil (progn (browse-url url) t) (error nil))))
         (token (string-trim
                 (let ((xterm-store-paste-on-kill-ring nil))
                   (read-passwd (if opened prompt
                                  (concat (string-remove-suffix ": " prompt)
                                          ", from " url ": ")))))))
    (remoto--forget-kill token)
    token))

;;;###autoload
(defun remoto-login (forge)
  "Log in to FORGE with a token that is checked and then kept.
Interactively, read the forge, the current buffer's first; open the page
that makes a token, read the token, ask the forge whose it is, and store
it in the first .gpg file of `auth-sources', else for the session."
  (interactive (list (remoto--read-forge "Remoto: log in to")))
  (let ((token (remoto--read-token forge)))
    (when (string-empty-p token)
      (user-error "Remoto: no token given"))
    (let* ((account (remoto--token-account forge token))
           (why nil)
           ;; A failed store leaves the checked token for the session.
           (file (condition-case err
                     (remoto--store-token forge account token)
                   (error (setq why (error-message-string err))
                          nil)))
           (login (remoto--forge-login forge)))
      (setf (remoto--login-token login) token
            (remoto--login-account login) account
            (remoto--login-user login) account
            (remoto--login-failed login) nil
            (remoto--login-declined login) nil
            (remoto--login-hinted login) t)
      (message "Remoto: logged in to %s as %s%s" (remoto-forge-title forge) account
               (cond (file "")
                     (why (format " for this session; %s: %s"
                                  (abbreviate-file-name (remoto--token-file)) why))
                     (t " for this session")))
      account)))

(defvar remoto--may-ask nil
  "Non-nil while a remoto entry point runs for a command of the user's.
Only then does remoto offer a login: never during completion, from a
timer, or from a process filter.")

(defun remoto--ask-login-p (forge)
  "Return non-nil when remoto may ask now to log in to FORGE."
  (and remoto--may-ask this-command (not noninteractive) (not throw-on-input)
       (not (remoto--login-declined (remoto--forge-login forge)))))

(defun remoto--offer-login (forge question)
  "Ask QUESTION, then log in to FORGE on yes; return non-nil after a login.
A no stands for the session: remoto asks FORGE no more, it only says."
  (when (remoto--ask-login-p forge)
    (if (y-or-n-p question)
        (and (remoto-login forge) t)
      (setf (remoto--login-declined (remoto--forge-login forge)) t)
      nil)))

(defun remoto--offer-login-for-limit (forge message)
  "Offer a login to FORGE when MESSAGE is a rate limit without a token.
Return non-nil after a login.  Reading without a token by choice, with
`remoto-github-auth' set to `none', asks nothing."
  (and (remoto--login-failed (remoto--forge-login forge))
       (string-match (concat "\\`Remoto: \\(.+" (regexp-quote remoto--rate-limited)
                             "[0-9:]+\\)")
                     message)
       (remoto--offer-login forge (concat (match-string 1 message) ". Log in now? "))))

(cl-defgeneric remoto--anonymous-limit (_forge)
  "Return the request limit of FORGE for a reader without a token, or nil.
A forge whose limit seldom runs out answers nil, and its hint is not shown."
  "60 requests/hour")

(defun remoto--hint-login (forge)
  "Say once a session that FORGE is read without a token, when that limits.
A refused or declined token said so already, and marked the hint shown."
  (when-let* ((limit (remoto--anonymous-limit forge))
              (login (remoto--forge-login forge))
              ((remoto--login-failed login))
              ((not (remoto--login-hinted login))))
    (setf (remoto--login-hinted login) t)
    (message "Remoto: no %s token, %s. %s"
             (remoto-forge-title forge) limit (remoto--login-keys))))

(defconst remoto--dir-entry
  '((type . "tree") (size . 0) (sha . "") (mode . "040000"))
  "Alist for synthesized directory entries (root, intermediates, `.', `..').")

;;;; Tree cache

(defvar remoto--tree-cache (make-hash-table :test 'equal)
  "Cache: `remoto--repo-key' -> hash table of path -> entry plist.")

(defvar remoto--default-branch-cache (make-hash-table :test 'equal)
  "Cache: `remoto--repo-id' -> default branch name.")

(cl-defstruct (remoto--listing (:constructor remoto--listing-create)
                               (:copier nil))
  "The entries of a Dired listing above the repository level.
ENTRIES is a list of (NAME . ATTRIBUTES) in the order the API sent them.
STATE is nil once complete, `fetching' while later pages load, `capped'
when `remoto-listing-cap' cut it short, and `failed' when a page failed."
  (time (float-time))
  entries
  state)

(defvar remoto--listing-cache (make-hash-table :test 'equal)
  "Cache: listing directory -> `remoto--listing'.
The directories are /github:, which lists the accounts of the token, and
/github:OWNER/, which lists OWNER's repositories.")

(defvar remoto--entry-cache (make-hash-table :test 'equal)
  "Cache: remoto name, downcased -> the attributes of its Dired line.
The names are /github:ACCOUNT, /github:OWNER/REPO and /github:OWNER/REPO@REF;
listing pages and searches fill it, so a name that a search found gets a
line and opens though no cached listing holds it.")


(defun remoto--resolve-ref (parsed)
  "Ensure PARSED `remoto-path' has a concrete ref, resolving if needed.
Returns a new `remoto-path' with ref filled in."
  (if (remoto-path-ref parsed)
      parsed
    (let* ((forge (remoto-path-forge parsed))
           (owner (remoto-path-owner parsed))
           (repo (remoto-path-repo parsed))
           (repo-id (remoto--repo-id forge owner repo))
           (branch (or (gethash repo-id remoto--default-branch-cache)
                       (let ((b (remoto-forge-default-ref forge owner repo)))
                         (puthash repo-id b remoto--default-branch-cache)
                         b))))
      (remoto-path-create
       :forge forge :owner owner :repo repo :ref branch
       :path (remoto-path-path parsed)))))

(defun remoto--repo-empty-p (forge owner repo ref failure)
  "Non-nil if OWNER/REPO on FORGE has no commit; FAILURE is how REF's tree failed.
GitHub says so in its 409.  Forgejo answers 404 and marks the repository,
which is asked only when REF is the default branch, the one ref an empty
repository names."
  (or (string-match-p "Git Repository is empty" failure)
      (and (string-prefix-p remoto--not-found failure)
           (equal ref (gethash (remoto--repo-id forge owner repo)
                               remoto--default-branch-cache))
           (eq t (alist-get 'empty (ignore-errors
                                     (remoto--api forge (format "repos/%s/%s" owner repo))))))))

(defun remoto--forge-tree (forge owner repo ref)
  "Return the tree of OWNER/REPO at REF on FORGE, an empty one without a commit."
  (condition-case err
      (remoto-forge-tree forge owner repo ref)
    (user-error
     (if (not (remoto--repo-empty-p forge owner repo ref (error-message-string err)))
         (signal (car err) (cdr err))
       (message "Remoto: %s is empty" (remoto--repo-name owner repo))
       (let ((table (make-hash-table :test 'equal)))
         (puthash "" remoto--dir-entry table)
         (puthash "/" remoto--dir-entry table)
         table)))))

(defun remoto--ensure-tree (parsed)
  "Ensure tree is cached for PARSED path, return the tree hash table."
  (let* ((resolved (remoto--resolve-ref parsed))
         (key (remoto--repo-key resolved)))
    (or (gethash key remoto--tree-cache)
        (let* ((tree (remoto--forge-tree
                      (remoto-path-forge resolved)
                      (remoto-path-owner resolved)
                      (remoto-path-repo resolved)
                      (remoto-path-ref resolved))))
          (puthash key tree remoto--tree-cache)
          tree))))

(defun remoto--fetch-directory-contents (parsed dir-key tree)
  "Fetch the entries under DIR-KEY of PARSED's repository, merge them into TREE.
On-demand fallback for repos whose recursive tree was truncated."
  (let* ((resolved (remoto--resolve-ref parsed))
         (entries (condition-case nil
                      (remoto-forge-directory-contents
                       (remoto-path-forge resolved)
                       (remoto-path-owner resolved)
                       (remoto-path-repo resolved)
                       (remoto-path-ref resolved)
                       dir-key)
                    (user-error nil))))
    (puthash (concat "\0fetched:" dir-key) t tree)
    (dolist (entry entries)
      ;; Keep existing entries from the tree (they have richer mode info)
      (unless (gethash (car entry) tree)
        (puthash (car entry) (cdr entry) tree)))))

(defun remoto--tree-lookup-key (path)
  "Normalize PATH for tree hash-table lookup.
Strips leading/trailing slashes and collapses runs of slashes."
  (let ((p (replace-regexp-in-string "/+" "/" path)))
    (when (string-prefix-p "/" p)
      (setq p (substring p 1)))
    (when (and (not (string-empty-p p))
               (string-suffix-p "/" p))
      (setq p (substring p 0 (1- (length p)))))
    p))

(defun remoto--tree-entry (parsed)
  "Look up the tree entry for PARSED path.  Return plist or nil.
For truncated trees, fetches the parent directory on demand."
  (let* ((tree (remoto--ensure-tree parsed))
         (key (remoto--tree-lookup-key (remoto-path-path parsed))))
    (or (gethash key tree)
        (when (and (gethash "\0truncated" tree)
                   (not (string-empty-p key)))
          (let ((parent (if (string-search "/" key)
                            (remoto--tree-lookup-key
                             (file-name-directory (directory-file-name key)))
                          "")))
            (unless (gethash (concat "\0fetched:" parent) tree)
              (remoto--fetch-directory-contents parsed parent tree))
            (gethash key tree))))))

(defun remoto--tree-children (parsed)
  "List direct children of directory at PARSED path.
Returns list of (NAME . PLIST) for each child.
For truncated trees, fetches the directory on demand."
  (let* ((tree (remoto--ensure-tree parsed))
         (dir-path (remoto--tree-lookup-key (remoto-path-path parsed)))
         (_ (when (and (gethash "\0truncated" tree)
                       (not (gethash (concat "\0fetched:" dir-path) tree)))
              (remoto--fetch-directory-contents parsed dir-path tree)))
         (prefix (if (string-empty-p dir-path) "" (concat dir-path "/")))
         (prefix-len (length prefix)))
    (thread-last (hash-table-keys tree)
      (seq-filter (lambda (path)
                    (and (not (string-prefix-p "\0" path))
                         (string-prefix-p prefix path)
                         (not (equal path dir-path))
                         ;; Direct child: no more slashes after prefix
                         (not (string-search "/" (substring path prefix-len))))))
      (mapcar (lambda (path)
                (cons (substring path prefix-len)
                      (gethash path tree))))
      (seq-remove (lambda (child) (string-empty-p (car child))))
      (seq-sort (lambda (a b) (string< (car a) (car b)))))))

;;;; Path normalization helpers

(defun remoto--normalize-path (path)
  "Clean up PATH component: collapse double slashes, resolve . and .."
  (let* ((parts (split-string path "/" t))
         (result nil))
    (dolist (p parts)
      (cond
       ((equal p "."))
       ((equal p "..")
        (when result (pop result)))
       (t (push p result))))
    (let ((normalized (concat "/" (mapconcat #'identity (nreverse result) "/"))))
      ;; Preserve trailing slash for directories
      (if (and (string-suffix-p "/" path)
               (not (string-suffix-p "/" normalized)))
          (concat normalized "/")
        normalized))))

(defun remoto--dot-component-p (name)
  "Return non-nil when the remoto NAME has a . or .. component."
  (string-match-p (rx (or bos "/") (** 1 2 ".") (or "/" eos))
                  (remoto--after-prefix name)))

(defun remoto--normalize-name (name)
  "Resolve the . and .. components of the remoto NAME, collapse its slashes.
The levels above a repository are directories too: .. at a repository
root names its owner, and .. at an owner names the prefix.  A canonical
root keeps the slash after its colon; any other trailing slash stays."
  (let ((prefix (remoto--prefix (remoto--canonical-forge name)))
        (parts nil)
        (dir (string-suffix-p "/" name)))
    (dolist (part (remoto--name-components name))
      (pcase part
        ("." nil)
        (".." (pop parts))
        (_ (push part parts))))
    (pcase-let ((`(,owner ,repo . ,path) (nreverse parts)))
      (cond
       ((null owner) prefix)
       ((null repo) (concat prefix owner "/"))
       ((string-suffix-p ":" repo)
        (concat prefix owner "/" repo "/" (string-join path "/")
                (and path dir "/")))
       (t (concat prefix owner "/" repo
                  (and path (concat "/" (string-join path "/")))
                  (and dir "/")))))))

(defun remoto--name-components (name)
  "Split the remoto NAME after its prefix into its slash-separated parts.
A canonical repository with its ref and colon is one part, since a ref
may hold slashes of its own."
  (if-let* ((parsed (remoto--parse-path name)))
      (cons (remoto-path-owner parsed)
            (cons (substring (remoto--tree-prefix parsed)
                             (+ (length (remoto--path-prefix parsed))
                                (length (remoto-path-owner parsed))
                                1))
                  (split-string (remoto-path-path parsed) "/" t)))
    (split-string (remoto--after-prefix name) "/" t)))

(defun remoto--file-name-prefix (filename)
  "Extract the /PREFIX:owner/repo@ref: prefix from FILENAME."
  (when-let* ((parsed (remoto--parse-path filename)))
    (remoto--tree-prefix parsed)))

;;;; File-name handler

(defun remoto--normalize-shorthand (arg)
  "Rewrite a leading shorthand prefix in ARG, such as /gh:, to its forge's.
A non-string ARG, or a string lacking a shorthand prefix, is returned
unchanged so downstream handlers only ever see canonical paths."
  (if-let* (((stringp arg))
            (entry (remoto--prefix-of arg))
            (forge (cdr entry))
            ((not (equal (car entry) (car (remoto-forge-prefixes forge))))))
      (concat (remoto--prefix forge)
              (substring arg (+ 2 (length (car entry)))))
    arg))

(defun remoto-file-name-handler (operation &rest args)
  "Handle file OPERATION for remoto paths.
Dispatches to `remoto--handle-OPERATION' or falls through to defaults.
The /gh: shorthand in ARGS is normalized to /github: first, so every
resolved handler receives only canonical paths."
  ;; File primitives leave the match data alone for local names, and the
  ;; handlers below call `string-match', so the caller's match data is kept.
  (save-match-data
    (let ((args (mapcar #'remoto--normalize-shorthand args)))
      (if-let* ((handler (intern-soft (format "remoto--handle-%s" operation)))
                ((fboundp handler)))
          (apply handler args)
        (remoto--pass-on operation args)))))

(defun remoto--pass-on (operation args)
  "Run OPERATION on ARGS with remoto's handler out of the way."
  (let ((inhibit-file-name-handlers
         (cons #'remoto-file-name-handler
               (and (eq inhibit-file-name-operation operation)
                    inhibit-file-name-handlers)))
        (inhibit-file-name-operation operation))
    (apply operation args)))

;;;; Read operations

(defun remoto--handle-file-exists-p (filename)
  "Return t if FILENAME exists or is openable.
Returns nil for mid-completion paths (no selection made yet),
triggering variable `confirm-nonexistent-file-or-buffer' on RET.
A bare account or repository name exists once a cached listing holds it."
  (when-let* ((parsed (remoto--parse filename))
              (query (remoto-path-query parsed)))
    (pcase (remoto-path-level parsed)
      ;; /github: and /github:OWNER/ exist for navigation.  A bare name is a
      ;; line of their listing; a delimiter after no repository names nothing.
      ((or 'root 'owner)
       (cond ((member query '("" "/")) t)
             ((not (remoto--bare-name parsed)) nil)
             (t (and (remoto--listed-p filename) t))))
      ;; /github:OWNER/REPO@REF is a line of a Dired of matching refs; the
      ;; delimiter alone is still being typed.
      ('refs (and (not (string-empty-p query))
                  (remoto--entry-for filename) t))
      ;; /github:OWNER/REPO#NUM opens on its shape alone.
      ('topics (and (remoto--topic-key-p (remoto-path-forge parsed) query) t))
      ;; A short form is openable as Dired on the default branch.  So is the
      ;; repository root at a ref: answering it from the tree would cost one
      ;; recursive tree per ref, because completion asks this of every
      ;; candidate it offers at the @ level.
      ('tree
       (cond ((remoto-path-short parsed) t)
             ((string-empty-p (remoto--tree-lookup-key (remoto-path-path parsed))) t)
             (t (and (remoto--tree-entry parsed) t)))))))

(defun remoto--handle-access-file (filename string)
  "Return nil when FILENAME can be read, else signal `file-missing'.
STRING names the caller's purpose, as `access-file' documents.  Without
this the operation falls through to the local primitive, which sees no
such file and always signals, and `recentf' then drops every remoto
path."
  (unless (remoto--handle-file-exists-p filename)
    (signal 'file-missing
            (list string "No such file or directory" filename))))

(defun remoto--handle-file-directory-p (filename)
  "Return t if FILENAME is a directory in the remote repo.
Also returns t for partial paths like /github: and /github:OWNER/."
  (when-let* ((parsed (remoto--parse filename))
              (query (remoto-path-query parsed)))
    (pcase (remoto-path-level parsed)
      ;; The levels above a repository and every name in them are directories
      ;; by shape; a delimiter after no repository is a line of nothing.
      ((or 'root 'owner)
       (cond ((member query '("" "/")) t)
             ((remoto--bare-name parsed) t)
             (t (and (remoto--entry-for filename) t))))
      ;; /github:OWNER/REPO@ is the Dired of refs; a ref in it is a line of
      ;; a Dired of matching refs.
      ('refs (or (string-empty-p query)
                 (and (remoto--entry-for filename) t)))
      ('topics nil)
      ('tree
       (if (remoto-path-short parsed)
           t
         (when-let* ((entry (remoto--tree-entry parsed)))
           (equal "tree" (alist-get 'type entry))))))))

(defun remoto--handle-file-accessible-directory-p (filename)
  "Return t if FILENAME is an accessible directory.
Delegates to `file-directory-p' - remote dirs are always readable."
  (remoto--handle-file-directory-p filename))

(defun remoto--handle-file-regular-p (filename)
  "Return t if FILENAME is a regular file in the remote repo."
  (when-let* ((parsed (remoto--parse-path filename))
              (entry (remoto--tree-entry parsed)))
    (equal "blob" (alist-get 'type entry))))

(defun remoto--handle-file-readable-p (filename)
  "Return non-nil if remote FILENAME is readable.
A directory reads though `file-exists-p' denies /github:OWNER and
/github:OWNER/REPO@ for the [Confirm] of a half-typed name: Dired asks
this of them before it lists the names that match there."
  (or (remoto--handle-file-exists-p filename)
      (remoto--handle-file-directory-p filename)))

(defun remoto--handle-file-writable-p (_filename)
  "Remote repos are never writable."
  nil)

(defvar remoto--inodes (make-hash-table :test 'equal)
  "Inode numbers of remoto files, by canonical name.")

(defun remoto--inode (parsed)
  "Return the inode number of the file PARSED names.
Emacs takes two files with equal inodes and attributes for one file and
visits both in one buffer, so each canonical name gets its own number."
  (let ((name (concat (remoto--tree-prefix parsed) "/"
                      (remoto--tree-lookup-key (remoto-path-path parsed)))))
    (or (gethash name remoto--inodes)
        (puthash name (1+ (hash-table-count remoto--inodes)) remoto--inodes))))

(defun remoto--handle-file-attributes (filename &optional _id-format)
  "Return file attributes for FILENAME.
Synthesized from tree cache - timestamps are epoch 0."
  (when-let* ((parsed (remoto--parse-path filename))
              (entry (remoto--tree-entry parsed)))
    (let* ((dir? (equal "tree" (alist-get 'type entry)))
           (size (or (alist-get 'size entry) 0))
           (mode-str (or (alist-get 'mode entry) "100644"))
           (mode (string-to-number mode-str 8))
           ;; Use epoch 0 for all timestamps
           (time '(0 0 0 0)))
      ;; Return vector matching `file-attributes' format:
      ;; (type links uid gid atime mtime ctime size mode
      ;;  gid-change inode device)
      (list (if dir? t nil)      ; type: t=dir, nil=file
            1                    ; links
            0                    ; uid
            0                    ; gid
            time                 ; atime
            time                 ; mtime
            time                 ; ctime
            size                 ; size
            (format "%05o" mode) ; mode string
            nil                  ; gid-change
            (remoto--inode parsed) ; inode
            0))))               ; device

(defun remoto--handle-directory-files (directory &optional full match nosort count)
  "List files in remote DIRECTORY.
FULL, MATCH, NOSORT, COUNT as per `directory-files'."
  (when-let* ((parsed (remoto--parse-path directory)))
    (let ((names (append '("." "..")
                         (mapcar #'car (remoto--tree-children parsed)))))
      (when match
        (setq names (seq-filter (lambda (name)
                                  (string-match-p match name))
                                names)))
      (unless nosort
        (setq names (sort names #'string<)))
      (when count
        (setq names (seq-take names count)))
      (if full
          (let ((prefix (remoto--file-name-prefix directory))
                (dir-path (remoto-path-path parsed)))
            (mapcar (lambda (name)
                      (concat prefix
                              (remoto--normalize-path
                               (concat dir-path "/" name))))
                    names))
        names))))

(defun remoto--handle-directory-files-and-attributes
    (directory &optional full match nosort id-format)
  "Like `directory-files-and-attributes' for remote DIRECTORY.
Pass FULL, MATCH, NOSORT, and ID-FORMAT through unchanged."
  (let* ((parsed (remoto--parse-path directory))
         (prefix (remoto--file-name-prefix directory))
         (base-path (lambda (f)
                      (concat prefix
                              (remoto--normalize-path
                               (concat (remoto-path-path parsed) "/" f))))))
    (thread-last
      (remoto--handle-directory-files directory full match nosort)
      (mapcar (lambda (f)
                (cons f (remoto--handle-file-attributes
                         (if full f (funcall base-path f))
                         id-format)))))))

(defvar remoto-min-search-chars) ; forward-decl for byte-compiler

(defun remoto--owner-candidate (owner prefix)
  "Return a root completion candidate for account OWNER under PREFIX.
Preserves OWNER's text properties (used for affixation) and attaches a
`remoto-target' of the canonical owner path so Embark can act on it."
  (propertize (concat owner "/")
              'remoto-target (concat prefix (substring-no-properties owner))))

(defun remoto--account-login (entry)
  "Return the login of ENTRY, a root listing entry, with account properties.
The `account-type' and `description' fields of ENTRY give them."
  (let ((fields (cdr entry)))
    (propertize (car entry)
                'remoto-acct-type (or (alist-get 'account-type fields) "")
                'remoto-acct-desc (or (alist-get 'description fields) ""))))

(defun remoto--minibuffer-input ()
  "Contents of the current buffer when it is an active completion minibuffer."
  (when (and (minibufferp) minibuffer-completion-table)
    (minibuffer-contents-no-properties)))

(defun remoto--input-query (input directory)
  "Return the text of INPUT after DIRECTORY, or nil when INPUT is elsewhere.
Normalize INPUT with `substitute-in-file-name' first, the way
`read-file-name' does, so a shadowed prefix such as \"~/x//github:o/\"
and the /gh: shorthand both resolve to DIRECTORY.  Return nil as well when
the text after DIRECTORY carries a level delimiter: `partial-completion'
probes parent levels with an empty FILE while the input sits deeper,
and that probe must not turn the deeper path into a search query."
  (when-let* ((effective (condition-case nil
                             (substitute-in-file-name input)
                           (error input)))
              ((string-prefix-p directory effective))
              (rest (substring effective (length directory)))
              ((not (string-match-p (rx (in "/@#:")) rest))))
    rest))

(defun remoto--minibuffer-query (directory)
  "What the user typed after DIRECTORY in the active minibuffer, or nil.
Completion styles that express the typed text as `completion-regexp-list'
\(orderless) hand the table only the text up to the completion boundary,
so FILE in `file-name-all-completions' arrives empty; the search levels
need the typed text as their API query."
  (when-let* ((input (remoto--minibuffer-input)))
    (remoto--input-query input directory)))

(defun remoto--completion-query (file directory)
  "Search query for FILE in DIRECTORY: FILE, or the minibuffer text if empty."
  (if (string-empty-p file)
      (or (remoto--minibuffer-query directory) file)
    file))

(defun remoto--candidate-match-text (candidate)
  "Text that `completion-regexp-list' is matched against for CANDIDATE.
The bare number of an issue and the bare name of a repo or account are
rarely what the user types, so the title or description joins the
name.  The trailing / or : delimiter stays out, as the built-in file
name primitives match names without it."
  (let ((name (string-trim-right candidate "[/:]"))
        (extra (or (remoto--get-prop candidate 'remoto-topic-title)
                   (remoto--get-prop candidate 'remoto-repo-desc)
                   (remoto--get-prop candidate 'remoto-acct-desc))))
    (if (and (stringp extra) (not (string-empty-p extra)))
        (concat name " " extra)
      name)))

(defun remoto--filter-by-completion-regexps (candidates)
  "Drop the CANDIDATES that `completion-regexp-list' rejects.
Completion styles rely on the table applying `completion-regexp-list'
itself: the built-in `file-name-all-completions' and TRAMP both do, and
orderless never filters on its own.  Case folding follows
`completion-ignore-case', as in the built-in primitives."
  (if (null completion-regexp-list)
      candidates
    (let ((case-fold-search completion-ignore-case))
      (seq-filter (lambda (c)
                    (let ((text (remoto--candidate-match-text c)))
                      (seq-every-p (lambda (re) (string-match-p re text))
                                   completion-regexp-list)))
                  candidates))))

(defun remoto--handle-file-name-all-completions (file directory)
  "Return completions for FILE in remote DIRECTORY.
Applies `completion-regexp-list' like the built-in primitive does."
  (remoto--filter-by-completion-regexps
   (remoto--file-name-completions file directory)))

(defun remoto--file-name-completions (file directory)
  "Return unfiltered completions for FILE in remote DIRECTORY.
Handles multiple levels: user search at /github:, repo listing at
/github:OWNER/, branch/tag at /github:OWNER/REPO@, files at
/github:OWNER/REPO/, issues at /github:OWNER/REPO#, and file
listing within a repo.  Search-level calls (user, repo) are
non-blocking: cached results are returned immediately while async
fetches populate the cache in the background.
An empty FILE does not mean an empty query: see `remoto--minibuffer-query'."
  (let* ((parsed (remoto--parse directory))
         (level (and parsed (remoto-path-level parsed)))
         (forge (and parsed (remoto-path-forge parsed)))
         (prefix (and parsed (remoto--path-prefix parsed)))
         (owner (and parsed (remoto-path-owner parsed)))
         (repo (and parsed (remoto-path-repo parsed))))
    (when (and parsed
               (or (eq level 'tree)
                   (string-empty-p (remoto-path-query parsed))))
      (pcase level
        ('root
         ;; Empty query + authenticated: show user + orgs
         ;; Non-empty: search users/orgs matching the query (non-blocking)
         (let* ((query (remoto--completion-query file directory))
                (root (remoto--path-at forge 'root))
                (candidate (lambda (acct) (remoto--owner-candidate acct prefix))))
           (if (string-empty-p query)
               (mapcar candidate (remoto-forge-complete forge root "" nil))
             (when-let* ((result (remoto-forge-complete forge root query nil)))
               (let ((filtered (seq-filter (lambda (u) (string-prefix-p file u))
                                           result)))
                 ;; Pre-fetch repos for the top match so the cache is
                 ;; warm by the time the user types "/"
                 (when-let* ((top (car filtered)))
                   (remoto-forge-complete forge (remoto--path-at forge 'owner top)
                                          nil nil))
                 (mapcar candidate filtered))))))
        ('owner
         ;; Repo completion at /github:OWNER/
         ;; Try cached/async results first; on cold-cache nil, fall
         ;; back to a synchronous fetch that yields to user input.
         (let* ((query (remoto--completion-query file directory))
                (path (remoto--path-at forge 'owner owner))
                (repos (or (remoto-forge-complete forge path query nil)
                           (let ((sync (while-no-input
                                         (condition-case nil
                                             (when (or (string-empty-p query)
                                                       (<= remoto-min-search-chars
                                                           (length query)))
                                               (remoto-forge-complete forge path query t))
                                           (error nil)))))
                             (and (consp sync) sync)))))
           (mapcar (lambda (r)
                     (let* ((name (if (string-suffix-p "/" r) (substring r 0 -1) r))
                            (cand (concat name "/")))
                       ;; Carry the full canonical path so Embark actions can
                       ;; resolve a bare candidate (see `remoto--embark-transform').
                       (put-text-property 0 (length cand) 'remoto-target
                                          (format "%s%s/%s:/" prefix owner name)
                                          cand)
                       cand))
                   repos)))
        ('refs
         ;; Ref completion at /github:OWNER/REPO@, each ref typed by its label
         (if (string-suffix-p ":" file)
             ;; Ref already selected (e.g. "main:") - exact match
             (list file)
           (let ((groups (while-no-input (remoto-forge-refs forge owner repo))))
             (when (listp groups)
               (thread-last
                 groups
                 (seq-mapcat (lambda (group)
                               (mapcar (lambda (ref)
                                         (propertize (concat ref ":")
                                                     'remoto-ref-type (car group)
                                                     'remoto-target
                                                     (concat prefix
                                                             (remoto--repo-name owner repo)
                                                             "@" ref ":/")))
                                       (cdr group))))
                 (seq-filter (lambda (r)
                               (or (string-empty-p file)
                                   (string-prefix-p file r)))))))))
        ((and 'tree (guard (remoto-path-short parsed)))
         ;; File completion on default branch: /github:OWNER/REPO/[subdir/]
         ;; Uses lightweight Contents API (single call) instead of
         ;; recursive tree fetch for fast initial display.
         (let* ((branch (condition-case nil
                            (while-no-input
                              (remoto-forge-default-ref forge owner repo))
                          (user-error 'failed))))
           ;; A string names the default ref; nil, a source without refs.
           (when (or (null branch) (stringp branch))
             (let* ((subpath (substring (remoto-path-path parsed) 1))
                    (root (concat prefix (remoto--repo-name owner repo)
                                  (and branch (concat "@" branch)) ":/"))
                    (children (while-no-input
                                (remoto-forge-children
                                 forge owner repo branch subpath)))
                    (names (when (listp children)
                             (mapcar (lambda (child)
                                       (if (equal "tree" (alist-get 'type (cdr child)))
                                           (concat (car child) "/")
                                         (car child)))
                                     children)))
                    (filtered (when names
                                (if (string-empty-p file)
                                    names
                                  (seq-filter (lambda (name)
                                                (string-search file name))
                                              names)))))
               (when filtered
                 (mapcar (lambda (name)
                           (propertize name 'remoto-target (concat root subpath name)))
                         filtered))))))
        ('topics
         ;; Issue/PR completion at /github:OWNER/REPO#
         (let* ((query (remoto--completion-query file directory))
                (issues
                 (cond
                  ;; Empty query: show top open issues
                  ((string-empty-p query)
                   (while-no-input
                     (remoto-forge-topics forge owner repo nil)))
                  ;; A topic key: direct fetch + filter cached
                  ((remoto--topic-key-p forge query)
                   (let* ((cached (while-no-input
                                    (remoto-forge-topics forge owner repo nil)))
                          (direct (while-no-input
                                    (remoto-forge-topic forge owner repo query)))
                          (results (if (listp cached) cached nil)))
                     (if (consp direct)
                         (cl-remove-duplicates
                          (cons direct results)
                          :key (lambda (i) (alist-get 'key i)) :test #'equal)
                       results)))
                  ;; Text query: search
                  (t
                   (while-no-input
                     (remoto-forge-topics forge owner repo query))))))
           (when (listp issues)
             (let* ((candidates
                     (mapcar (lambda (i)
                               (let* ((key (alist-get 'key i))
                                      (is-pr (equal (alist-get 'kind i) "pr"))
                                      (title (or (alist-get 'title i) ""))
                                      (state (or (alist-get 'state i) "")))
                                 (propertize key
                                             'remoto-topic-pr is-pr
                                             'remoto-topic-title title
                                             'remoto-topic-state state
                                             'remoto-target
                                             (concat prefix (remoto--repo-name owner repo)
                                                     "#" key))))
                             issues))
                    (filtered
                     (if (or (string-empty-p file)
                             (remoto--topic-key-p forge file))
                         (seq-filter (lambda (n) (string-prefix-p file n)) candidates)
                       candidates)))
               ;; Sort: PRs first, then issues; within each group newest key first
               (sort filtered
                     (lambda (a b)
                       (let ((a-pr (get-text-property 0 'remoto-topic-pr a))
                             (b-pr (get-text-property 0 'remoto-topic-pr b)))
                         (cond
                          ((and a-pr (not b-pr)) t)
                          ((and (not a-pr) b-pr) nil)
                          (t (remoto--topic-key< b a))))))))))
        ('tree
         ;; Canonical path: entries of the tree at the ref
         (let* ((ref (remoto-path-ref parsed))
                (path (remoto-path-path parsed))
                ;; A directory's files join it with one slash: test/x, not test//x.
                (dir-path (string-trim path "/+" "/+"))
                (children (remoto--tree-children parsed))
                (names (thread-last children
                                    (mapcar (lambda (child)
                                              (if (equal "tree" (alist-get 'type (cdr child)))
                                                  (concat (car child) "/")
                                                (car child))))
                                    (seq-filter (lambda (name)
                                                  (string-prefix-p file name)))))
                (commits (when ref
                           (remoto-forge-entry-notes
                            forge owner repo ref dir-path names))))
           (mapcar (lambda (name)
                     (let ((cand (copy-sequence name))
                           (msg (alist-get name commits nil nil #'equal)))
                       (when msg
                         (put-text-property 0 (length cand) 'remoto-file-commit msg cand))
                       (put-text-property 0 (length cand) 'remoto-target
                                          (concat directory name) cand)
                       cand))
                   names)))))))

(defun remoto--handle-file-name-completion (file directory &optional predicate)
  "Complete FILE in remote DIRECTORY using optional PREDICATE.
Handles partial /github: paths for pre-repo completion.
PREDICATE may be a function, nil, or a string directory-prefix
passed through by `completion-file-name-table' - strings are
ignored since remoto paths always qualify."
  (let ((completions (remoto--handle-file-name-all-completions file directory))
        ;; completion-file-name-table passes the read-file-name
        ;; directory as a string predicate - not a callable filter
        (pred (if (stringp predicate) nil predicate)))
    (cond
     ((null completions) nil)
     ((null (cdr completions))
      (if (equal file (car completions)) t (car completions)))
     (t (try-completion file completions pred)))))

(defun remoto--handle-expand-file-name (name &optional dir)
  "Expand NAME relative to DIR for remoto paths."
  (let ((inhibit-file-name-handlers
         (cons #'remoto-file-name-handler
               (and (eq inhibit-file-name-operation 'expand-file-name)
                    inhibit-file-name-handlers)))
        (inhibit-file-name-operation 'expand-file-name))
    (cond
     ;; Absolute remoto path.  Primitives such as `file-exists-p' expand
     ;; their argument first, so this is where . and .. must resolve.
     ((remoto--canonical-forge name)
      (if (remoto--dot-component-p name)
          (remoto--normalize-name name)
        name))
     ;; Local absolute or home-relative path - never resolve under remoto
     ((or (string-prefix-p "/" name)
          (string-prefix-p "~" name))
      (expand-file-name name))
     ;; Relative path under a remoto directory
     ((and dir (remoto--canonical-forge dir))
      (if-let* ((parsed (remoto--parse-path dir))
                (prefix (remoto--file-name-prefix dir)))
          (remoto--normalize-name
           (concat prefix (remoto-path-path parsed) "/" name))
        ;; Partial path (e.g. /github:owner/ or /github:owner/repo@)
        (let ((joined (concat dir name)))
          (if (remoto--dot-component-p joined)
              (remoto--normalize-name joined)
            joined))))
     ;; Not our path, delegate
     (t (expand-file-name name dir)))))

(defun remoto--handle-file-truename (filename &optional _counter _prev-dirs)
  "Return FILENAME as-is - no symlink resolution for remote repos."
  filename)

(defun remoto--reached-p (filename)
  "Return non-nil when FILENAME's repository was already reached this session.
A cached default branch or tree is as close as remoto comes to an open
connection: it means the forge answered for that repository without a
new request."
  (when-let* ((parsed (remoto--parse-path filename)))
    (or (gethash (remoto--repo-id (remoto-path-forge parsed)
                                  (remoto-path-owner parsed)
                                  (remoto-path-repo parsed))
                 remoto--default-branch-cache)
        (gethash (remoto--repo-key parsed) remoto--tree-cache))))

(defun remoto--evil-ex-argument-p (filename)
  "Return non-nil when FILENAME is the argument of the running Evil ex command."
  (when-let* (((if (boundp 'evil-called-from-ex-p)
                   evil-called-from-ex-p
                 ;; An Evil without that flag binds this around each command.
                 (bound-and-true-p evil-ex-point)))
              (argument (bound-and-true-p evil-ex-argument))
              ((stringp argument)))
    (equal filename (remoto--normalize-shorthand argument))))

(defun remoto--localname (filename prefix)
  "Return the `localname' of FILENAME, whose remote prefix is PREFIX.
That is PREFIX, since callers pass it to local programs and remoto runs
none, except for an Evil ex argument: Evil rebuilds that from both
answers and replaces a bare `#' or `%' in it, so both come back escaped."
  (if (remoto--evil-ex-argument-p filename)
      (replace-regexp-in-string
       (rx (? "\\") (in "#%"))
       (lambda (s) (if (string-prefix-p "\\" s) s (concat "\\" s)))
       (substring filename (length prefix)) t t)
    prefix))

(defun remoto--handle-file-remote-p (filename &optional identification connected)
  "Return remote identification for FILENAME.
Use IDENTIFICATION to select which remote field to report.
CONNECTED asks for an answer only while the repository is reachable
without a request, which is what keeps `recentf' and `auto-revert' from
making remoto fetch a tree just to classify a path.  The symbol `never'
means the opposite - answer, but never open a connection - so it reads
like a nil CONNECTED here, where no answer costs one.
Handles partial paths for pre-repo completion."
  (when-let* ((forge (remoto--canonical-forge filename))
              ((or (not connected)
                   (eq connected 'never)
                   (remoto--reached-p filename))))
    (if-let* ((parsed (remoto--parse-path filename))
              (prefix (remoto--file-name-prefix filename)))
        (pcase identification
          ('method (symbol-name (remoto-forge-name forge)))
          ('host (remoto--repo-name (remoto-path-owner parsed)
                                    (remoto-path-repo parsed)))
          ('localname (remoto--localname filename prefix))
          (_ prefix))
      ;; Partial path - still remote
      (pcase identification
        ('method (symbol-name (remoto-forge-name forge)))
        ('host (remoto-forge-host forge))
        ('localname (remoto--localname filename (remoto--prefix forge)))
        (_ (remoto--prefix forge))))))

(defun remoto--handle-file-name-directory (filename)
  "Return directory part of remote FILENAME: the level it is in.
The result must be a prefix of FILENAME: `completion-file-name-table'
derives the completion boundary from its length, so a synthesized slash
after the colon would push the boundary past the text being completed
and make the UI append the candidate to it."
  (when-let* ((parsed (remoto--parse filename)))
    (remoto-path-directory parsed)))

(defun remoto--handle-file-name-nondirectory (filename)
  "Return non-directory part of remote FILENAME: the text after its level.
A directory name keeps nothing after its slash, or Dired lists it as a
wildcard and completion matches its own name."
  (if-let* ((parsed (remoto--parse filename)))
      (remoto-path-query parsed)
    (file-name-nondirectory filename)))

;;;; File contents

(defun remoto--relative-path (path)
  "Strip leading slash from PATH for API requests."
  (if (string-prefix-p "/" path) (substring path 1) path))

(defun remoto--topic-path (filename)
  "Return (REPO-PATH . KEY) when FILENAME names an issue or pull request.
The /github:OWNER/REPO#KEY shape belongs to `remoto-topic-display', not
to any file operation, so both the `find-file' advice and the handler
recognize it here."
  (when-let* ((parsed (remoto--parse filename))
              ((eq (remoto-path-level parsed) 'topics))
              (query (remoto-path-query parsed))
              ((remoto--topic-key-p (remoto-path-forge parsed) query)))
    (cons (remoto--repo-id (remoto-path-forge parsed)
                           (remoto-path-owner parsed) (remoto-path-repo parsed))
          query)))

(defun remoto--handle-insert-file-contents
    (filename &optional visit beg end replace)
  "Insert contents of remote FILENAME into current buffer.
VISIT, BEG, END, REPLACE as per `insert-file-contents'."
  ;; Reached when the `find-file-noselect' advice did not run, which is
  ;; the case for the very first remoto call of a session.  Say what the
  ;; path is and take the buffer `find-file-noselect' made with it: that
  ;; function has no unwind of its own, so the error would leave an empty
  ;; buffer named after the number.  The emptiness test is what tells that
  ;; buffer apart from a caller's own.
  (when (remoto--topic-path filename)
    ;; An empty buffer with no file name, under VISIT, is the state
    ;; `find-file-noselect' leaves: that call reached the handler because it
    ;; started before `remoto--install' added the advice that turns a #NUM
    ;; path into a topic buffer, and the advice is in place by now, so
    ;; repeating the call works.  Any other caller asked for file contents
    ;; directly and needs the command that goes through the advice.
    (let ((from-find-file (and visit (zerop (buffer-size)) (not buffer-file-name))))
      (when from-find-file
        (set-buffer-modified-p nil)
        (kill-buffer (current-buffer)))
      (user-error
       "Remoto: %s is an issue or pull request, not a file - %s"
       filename
       (if from-find-file
           "remoto is loaded now, run the command again"
         "open it with `find-file'"))))
  (let ((parsed (remoto--parse-path filename)))
    (unless parsed
      (error "Remoto: cannot parse path: %s" filename))
    ;; `find-file-noselect' treats a `file-error' as a nonexistent file and
    ;; otherwise keeps the buffer it created; the tree is cached, so the
    ;; check costs no request.  Like the primitive and TRAMP, a visiting
    ;; call still records the file name so the new-file path can go on.
    (unless (remoto--tree-entry parsed)
      (when visit
        (setq buffer-file-name filename)
        (set-buffer-modified-p nil))
      (signal 'file-missing
              (list "Opening input file" "No such file or directory" filename)))
    (let* ((resolved (remoto--resolve-ref parsed))
           (path (remoto--relative-path (remoto-path-path resolved)))
           (bytes (remoto-forge-content
                   (remoto-path-forge resolved)
                   (remoto-path-owner resolved)
                   (remoto-path-repo resolved)
                   (remoto-path-ref resolved)
                   path)))
      (when replace (erase-buffer))
      (let ((pt (point))
            len)
        ;; Insert the bytes and decode them in place, so the file gets the
        ;; coding the primitive would pick from disk: cookies and
        ;; `auto-coding-alist' by name, then detection.  A binary such as
        ;; an image stays raw bytes under `no-conversion', which is how
        ;; `image-mode' recovers the data from a remote buffer.  The
        ;; primitive sets `buffer-file-coding-system' from the result once
        ;; this handler returns the decoded length.
        (save-restriction
          (narrow-to-region pt pt)
          (insert (if (or beg end) (substring bytes (or beg 0) end) bytes))
          (decode-coding-inserted-region (point-min) (point-max) filename
                                         visit beg end replace)
          (setq len (- (point-max) (point-min))))
        (goto-char pt)
        (when visit
          (setq buffer-file-name filename)
          (setq buffer-read-only t)
          (set-buffer-modified-p nil)
          (set-visited-file-modtime 0))
        (list filename len)))))

;;;; Dired integration

(defun remoto--mode-to-string (mode-str dir?)
  "Convert git MODE-STR to an ls-style permission string for DIR?."
  (cond
   (dir?                "drwxr-xr-x")
   ((equal mode-str "100755") "-rwxr-xr-x")
   ((equal mode-str "120000") "lrwxrwxrwx")
   (t                   "-rw-r--r--")))

(defun remoto--ls-switch-p (switches short &optional long)
  "Return non-nil when ls options ask for SHORT, or for LONG spelled out.
SWITCHES holds the options as a string, the way Dired passes them.
Like Dired, look for SHORT in a group of short options; a nil SHORT
names an option that has only its LONG form."
  (and (stringp switches)
       (let ((case-fold-search nil))
         (string-match-p
          (rx-to-string `(seq (or bos " ")
                              (or ,@(and short `((seq "-" (* alnum) ,short)))
                                  ,@(and long `((seq "--" ,long eow))))))
          switches))))

(defun remoto--classify-p (switches)
  "Return non-nil when ls options ask for -F file type indicators.
SWITCHES holds the options as a string, the way Dired passes them."
  (remoto--ls-switch-p switches "F" "classify"))

(defconst remoto--ls-short-options
  '((?U (:sort . none)) (?f (:sort . none) (:show . all)) (?S (:sort . size))
    (?t (:sort . time)) (?v (:sort . version)) (?X (:sort . extension))
    (?r (:reverse . t)) (?h (:human . 1024)) (?a (:show . all))
    (?A (:show . almost)) (?B (:backups . t)))
  "The settings each short ls option makes, in the order it makes them.")

(defconst remoto--ls-long-options
  '(("reverse" (:reverse . t)) ("group-directories-first" (:group . t))
    ("human-readable" (:human . 1024)) ("si" (:human . 1000))
    ("all" (:show . all)) ("almost-all" (:show . almost))
    ("ignore-backups" (:backups . t)))
  "The settings each long ls option without an argument makes.")

(defun remoto--ls-sort-key (word)
  "Return the sort key that GNU ls's --sort=WORD asks for."
  (pcase word
    ("none" 'none) ("size" 'size) ("time" 'time) ("version" 'version)
    ("extension" 'extension) ("width" 'width) (_ 'name)))

(defun remoto--ls-argument (name value)
  "Return the settings of the ls option NAME with the argument VALUE."
  (pcase name
    ("sort" `((:sort . ,(remoto--ls-sort-key value))))
    ("ignore" `((:ignore . ,value)))
    ("hide" `((:hide . ,value)))))

(defun remoto--ls-word (word)
  "Return (SETTINGS . WAITING) for WORD of the ls options, SETTINGS in order.
WAITING names the option that takes the next word as its argument.  In
a group of short options, -I, -T and -w take the rest of the group."
  (let ((case-fold-search nil))
    (cond
     ((string-match "\\`--\\([^=]+\\)\\(?:=\\(.*\\)\\)?\\'" word)
      (let ((name (match-string 1 word))
            (value (match-string 2 word)))
        (cond (value (list (remoto--ls-argument name value)))
              ((member name '("sort" "ignore" "hide")) (cons nil name))
              (t (list (cdr (assoc name remoto--ls-long-options)))))))
     ((string-match "\\`-\\([^ITw]*\\)\\([ITw]\\)?\\(.*\\)\\'" word)
      (let ((settings (seq-mapcat (lambda (char) (alist-get char remoto--ls-short-options))
                                  (match-string 1 word)))
            (name (pcase (match-string 2 word) ('nil nil) ("I" "ignore") (_ "skip")))
            (value (match-string 3 word)))
        (cond ((null name) (list settings))
              ((string-empty-p value) (cons settings name))
              (t (list (append settings (remoto--ls-argument name value))))))))))

(defun remoto--ls-settings (words)
  "Return the settings the ls option WORDS make, as (KEY . VALUE), last first.
An option whose argument is not in its own word takes the next one."
  (pcase-let ((`(,settings . ,waiting) (and words (remoto--ls-word (car words)))))
    (cond ((null words) nil)
          (waiting (append (remoto--ls-settings (cddr words))
                           (and (cdr words) (remoto--ls-argument waiting (cadr words)))
                           (reverse settings)))
          (t (append (remoto--ls-settings (cdr words)) (reverse settings))))))

(defun remoto--ls-options (switches)
  "Return a plist of what the ls options ask of a listing.
SWITCHES holds them as Dired passes them.  :sort, :reverse, :group and
:human come as GNU ls reads them, the last given winning; :show is all,
almost or nil, :backups is -B, :ignore and :hide those of -I and --hide."
  (let ((settings (remoto--ls-settings
                   (split-string (if (listp switches) (string-join switches " ") switches)))))
    (list :sort (alist-get :sort settings 'name)
          :reverse (alist-get :reverse settings)
          :group (alist-get :group settings)
          :human (alist-get :human settings)
          :show (alist-get :show settings)
          :backups (alist-get :backups settings)
          :ignore (seq-keep (lambda (setting) (and (eq (car setting) :ignore) (cdr setting)))
                            settings)
          :hide (seq-keep (lambda (setting) (and (eq (car setting) :hide) (cdr setting)))
                          settings))))

(defun remoto--human-p (switches)
  "Return 1024 when ls options ask for -h sizes, 1000 for --si, else nil.
SWITCHES holds the options as a string, the way Dired passes them."
  (plist-get (remoto--ls-options switches) :human))

(defun remoto--human-size (size &optional base)
  "Return SIZE in bytes as ls -h prints it: 549, 1.4K, 26K, 2.6M.
BASE 1000 prints it as --si does: 1.5k, 26k.  The digits come as GNU's
human_readable makes them: rounded up, with one decimal below 10."
  (let ((base (if (eql base 1000) 1000 1024)))
    (named-let scale ((amount size) (tenths 0) (rounding 0) (unit nil)
                      (units (list (if (= base 1000) "k" "K") "M" "G" "T" "P" "E")))
      (if (and (<= base amount) units)
          (let* ((r10 (+ (* (% amount base) 10) tenths))
                 (r2 (+ (* (% r10 base) 2) (ash rounding -1))))
            (scale (/ amount base) (/ r10 base)
                   (cond ((and (< r2 base) (zerop (+ r2 rounding))) 0)
                         ((< r2 base) 1)
                         ((< base (+ r2 rounding)) 3)
                         (t 2))
                   (car units) (cdr units)))
        ;; One decimal shows below 10, and its tenth rounds up.
        (let* ((up (and unit (< amount 10) (< 0 rounding)))
               (tenths (if up (1+ tenths) tenths))
               (carry (= tenths 10))
               (amount (if carry (1+ amount) amount))
               (tenths (if carry 0 tenths))
               (rounding (if up 0 rounding)))
          (cond ((null unit) (number-to-string amount))
                ((< amount 10) (format "%d.%d%s" amount tenths unit))
                ((zerop (+ tenths rounding)) (format "%d%s" amount unit))
                ((and (= (1+ amount) base) units) (format "1.0%s" (car units)))
                (t (format "%d%s" (1+ amount) unit))))))))

(defun remoto--ls-indicator (plist classify)
  "Return the ls -F type indicator for an entry with PLIST, if CLASSIFY."
  (let ((mode (alist-get 'mode plist)))
    (cond ((not classify) "")
          ((equal "tree" (alist-get 'type plist)) "/")
          ((equal mode "120000") "@")
          ((equal mode "100755") "*")
          (t ""))))

(defun remoto--ls-time (time)
  "Format TIME as ls -l does, or the fixed date of tree entries when nil.
Within the last six months it shows the hour, before that the year.
English month names, as in the fixed date, keep the columns aligned."
  (let ((system-time-locale "C"))
    (cond ((null time) "Jan  1  2000")
          ((< (float-time (time-subtract nil time)) (* 182 24 60 60))
           (format-time-string "%b %e %H:%M" time))
          (t (format-time-string "%b %e  %Y" time)))))

(defun remoto--one-line (text)
  "Return TEXT with each line break, and the blanks around it, as one space.
A forge's description may span lines; a Dired line or an annotation cannot."
  (if (string-match-p "[\n\r\f\v]" text)
      (mapconcat #'identity (split-string text "[\n\r\f\v]+" t "[ \t]+") " ")
    text))

(defun remoto--format-dired-entry (name plist &optional classify widths human)
  "Format a single Dired line for NAME with PLIST attributes.
CLASSIFY appends the ls -F indicator; HUMAN, 1024 or 1000, sizes as -h or
--si do.  WIDTHS line up a listing's sizes and names; a note in PLIST
starts 4 columns past the names, where Dired hides link targets."
  (let* ((dir? (equal "tree" (alist-get 'type plist)))
         (indicator (remoto--ls-indicator plist classify))
         (note (and (alist-get 'note plist) (remoto--one-line (alist-get 'note plist))))
         (size (or (alist-get 'size plist) 0)))
    (concat (or (alist-get 'perms plist)
                (remoto--mode-to-string (alist-get 'mode plist) dir?))
            "  1 github github "
            (string-pad (if human (remoto--human-size size human) (number-to-string size))
                        (or (car widths) 8) nil t)
            " " (remoto--ls-time (alist-get 'time plist)) " "
            ;; Dired reads exactly the name by this property, whatever
            ;; the switches; a name with a note after it needs it as well.
            (propertize name 'dired-filename t)
            indicator
            (and note (not (string-empty-p note))
                 (concat (make-string (max 4 (- (+ 4 (or (cdr widths) 0))
                                                (string-width name)
                                                (length indicator)))
                                      ?\s)
                         note))
            "\n")))

(defun remoto--listing-widths (entries classify &optional human)
  "Return the size and name column widths that line up ENTRIES.
CLASSIFY counts the ls -F indicator into the name, HUMAN takes -h or --si
sizes.  The name column stops at 40, so one long name moves only its note."
  (cons (apply #'max 8 (mapcar (lambda (entry)
                                 (let ((size (or (alist-get 'size (cdr entry)) 0)))
                                   (length (if human
                                               (remoto--human-size size human)
                                             (number-to-string size)))))
                               entries))
        (min 40 (apply #'max 0 (mapcar (lambda (entry)
                                         (+ (string-width (car entry))
                                            (length (remoto--ls-indicator
                                                     (cdr entry) classify))))
                                       entries)))))

(defun remoto--listing-note (listing)
  "Return the note on the . line of LISTING, or nil once it is complete.
Not the total line: Dired deletes that under the default `dired-free-space'."
  (let ((count (length (remoto--listing-entries listing))))
    (pcase (remoto--listing-state listing)
      ('fetching (format "%d so far, fetching the rest" count))
      ('capped (format "the %d most recently pushed, as `remoto-listing-cap' allows"
                       count))
      ('failed (format "%d, the rest failed to load; `remoto-refresh' retries"
                       count)))))

(defun remoto--ls-locale ()
  "Return the locale ls takes its order of names from, or nil for none.
That is LC_ALL, else LC_COLLATE, else LANG, from `process-environment',
which ls inherits."
  (seq-some (lambda (var)
              (let ((value (getenv var)))
                (and value (not (string-empty-p value)) value)))
            '("LC_ALL" "LC_COLLATE" "LANG")))

(defconst remoto--macos-ascii-keys
  (let ((order " _-,;:!?.'\"()[]{}@*/\\&#%`^+<=>|~$0123456789abcdefghijklmnopqrstuvwxyz"))
    (vconcat (mapcar (lambda (char)
                       (when-let* ((index (string-search (string (downcase char)) order)))
                         (list (1+ index) 1 (if (<= ?A char ?Z) 2 1))))
                     (number-sequence 0 127))))
  "The (WEIGHT ACCENT CASE) of each ASCII character in the order of macOS.
Symbols weigh least, then digits, then letters, both cases of a letter
alike, capitals after lowercase; a character with none counts for nothing.")

(defconst remoto--macos-accents
  "\u0301\u0300\u0306\u0302\u030c\u030a\u0308\u030b\u0303\u0307\u0327\u0328\u0304"
  "Combining accents in the order macOS sorts the letters that bear them.")

(defun remoto--macos-key (name)
  "Return a string whose `string<' order is that of NAME on macOS.
The weights count first, then accents, then case, lowercase first.  An
accented letter weighs as its base; any other character outside ASCII
counts for nothing, as a Cyrillic or CJK one does on macOS."
  (let ((keys (delq nil (mapcar #'remoto--macos-char-key name))))
    (concat (mapcar #'car keys) "\0" (mapcar #'cadr keys) "\0" (mapcar #'caddr keys))))

(defun remoto--macos-char-key (char)
  "Return (WEIGHT ACCENT CASE) of CHAR in the order of names on macOS.
Return nil for a character that counts for nothing there."
  (if (< char 128)
      (aref remoto--macos-ascii-keys char)
    (let* ((parts (get-char-code-property char 'decomposition))
           (base (car parts))
           (accent (cadr parts))
           (key (and (characterp base) (< base 128)
                     (aref remoto--macos-ascii-keys base)))
           (rank (and key (characterp accent)
                      (string-search (string accent) remoto--macos-accents))))
      (and key
           (list (car key)
                 (cond ((not (characterp accent)) 1)
                       (rank (+ 2 rank))
                       (t (+ 16 (logand accent #xff))))
                 (nth 2 key))))))

(defun remoto--name-lessp-function ()
  "Return a predicate that orders names as ls does in its locale.
`string-collate-lessp' has no locales on macOS, so the order ls has there
is copied; the C locale orders by bytes.  Names alike in order go by bytes."
  (let ((locale (remoto--ls-locale)))
    (cond ((or (null locale) (member locale '("C" "POSIX"))
               (and (eq system-type 'darwin) (string-prefix-p "C." locale)))
           #'string<)
          ((eq system-type 'darwin)
           (let ((keys (make-hash-table :test #'equal)))
             (lambda (a b)
               (let ((key-a (with-memoization (gethash a keys) (remoto--macos-key a)))
                     (key-b (with-memoization (gethash b keys) (remoto--macos-key b))))
                 (or (string< key-a key-b)
                     (and (string= key-a key-b) (string< a b)))))))
          ((condition-case nil
               (or (string-collate-lessp "a" "b" locale) t)
             (error nil))
           (lambda (a b)
             (or (string-collate-lessp a b locale)
                 (and (not (string-collate-lessp b a locale)) (string< a b)))))
          (t #'string<))))

(defun remoto--version-lessp (a b)
  "Return non-nil when the name A comes before B under ls -v.
`string-version-lessp' compares as gnulib's filevercmp, which GNU ls -v
uses; names it finds alike go by bytes, as GNU ls has them."
  (or (string-version-lessp a b)
      (and (not (string-version-lessp b a)) (string< a b))))

(defun remoto--extension (name)
  "Return the extension of NAME for ls -X: NAME from its last dot, or nothing."
  (if (string-match "\\.[^.]*\\'" name)
      (substring name (match-beginning 0))
    ""))

(defun remoto--dot-entry-p (entry)
  "Return non-nil when ENTRY is the . or .. of a listing."
  (member (car entry) '("." "..")))

(defvar ls-lisp-use-insert-directory-program)
(defvar ls-lisp-dirs-first)
(declare-function ls-lisp-handle-switches "ls-lisp" (file-alist switches))
(declare-function ls-lisp--sanitize-switches "ls-lisp" (switches))

(defun remoto--ls-lisp-p ()
  "Return non-nil when ls-lisp lists local directories, not ls."
  (and (featurep 'ls-lisp) (not ls-lisp-use-insert-directory-program)))

(defun remoto--ls-lisp-switches (switches)
  "Return the characters that stand for the ls options in ls-lisp.
SWITCHES holds the options as Dired passes them."
  (seq-remove (lambda (char) (memq char '(?\s ?-)))
              (ls-lisp--sanitize-switches (or switches ""))))

(defun remoto--ls-lisp-sort (entries switches)
  "Return ENTRIES in the order ls-lisp gives the files of a local directory.
SWITCHES are the ls options.  ls-lisp sorts ENTRIES itself, from file
attributes made of theirs, and reads the options as its
`insert-directory' does."
  ;; ls-lisp compares the variable with t, and binds t itself for a local
  ;; directory listed with --group-directories-first.
  (let ((ls-lisp-dirs-first (if (string-search "--group-directories-first"
                                               (or switches ""))
                                t
                              ls-lisp-dirs-first)))
    ;; Each file carries its entry after its twelve file attributes.
    (mapcar (lambda (file) (car (last file)))
            (ls-lisp-handle-switches
             (mapcar (lambda (entry)
                       (let* ((dot (remoto--dot-entry-p entry))
                              (time (if dot most-positive-fixnum
                                      (or (alist-get 'time (cdr entry)) 0))))
                         (list (car entry) (equal "tree" (alist-get 'type (cdr entry)))
                               1 0 0 time time time
                               (if dot most-positive-fixnum
                                 (or (alist-get 'size (cdr entry)) 0))
                               "-rw-r--r--" nil 0 0 entry)))
                     entries)
             (remq ?F (remoto--ls-lisp-switches switches))))))

(defun remoto--sort-entries (entries switches)
  "Return ENTRIES, each (NAME . ATTRIBUTES), in the order ls gives them.
SWITCHES are the ls options, read as GNU ls reads them, or as ls-lisp
does when it lists local directories.  remoto knows no size or time of
the entries . and .., so they lead under -S and -t."
  (let* ((options (remoto--ls-options switches))
         (sort (plist-get options :sort)))
    (cond
     ((remoto--ls-lisp-p) (remoto--ls-lisp-sort entries switches))
     ((eq sort 'none) (copy-sequence entries))
     (t
      (let* ((name< (if (eq sort 'version)
                        #'remoto--version-lessp
                      (remoto--name-lessp-function)))
             (lessp
              (pcase sort
                ((or 'size 'time)
                 (let ((key (if (eq sort 'size)
                                (lambda (entry) (or (alist-get 'size (cdr entry)) 0))
                              (lambda (entry)
                                (float-time (or (alist-get 'time (cdr entry)) 0))))))
                   (lambda (a b)
                     (let ((key-a (if (remoto--dot-entry-p a) 1.0e+INF (funcall key a)))
                           (key-b (if (remoto--dot-entry-p b) 1.0e+INF (funcall key b))))
                       (if (= key-a key-b)
                           (funcall name< (car a) (car b))
                         (< key-b key-a))))))
                ('width
                 (lambda (a b)
                   (let ((width-a (string-width (car a)))
                         (width-b (string-width (car b))))
                     (if (= width-a width-b)
                         (funcall name< (car a) (car b))
                       (< width-a width-b)))))
                ('extension
                 (lambda (a b)
                   (let ((ext-a (remoto--extension (car a)))
                         (ext-b (remoto--extension (car b))))
                     (cond ((funcall name< ext-a ext-b) t)
                           ((funcall name< ext-b ext-a) nil)
                           (t (funcall name< (car a) (car b)))))))
                (_ (lambda (a b) (funcall name< (car a) (car b))))))
             (sorted (sort (copy-sequence entries) lessp))
             (ordered (if (plist-get options :reverse) (reverse sorted) sorted)))
        (if (plist-get options :group)
            (let ((dir-p (lambda (entry)
                           (equal "tree" (alist-get 'type (cdr entry))))))
              (append (seq-filter dir-p ordered) (seq-remove dir-p ordered)))
          ordered))))))

(defun remoto--ls-pattern-p (pattern name)
  "Return non-nil when the shell PATTERN of -I or --hide matches NAME.
A dot that starts NAME matches only a dot that starts PATTERN, as ls has it."
  (and (condition-case nil
           (let ((case-fold-search nil))
             (string-match-p (wildcard-to-regexp pattern) name))
         (invalid-regexp nil))
       (or (not (string-prefix-p "." name)) (string-prefix-p "." pattern))))

(defun remoto--shown-entries (entries switches)
  "Return the ENTRIES of a listing that ls would list.
SWITCHES are the ls options: dot names need -a, or -A, which leaves
out only . and ..; -B leaves out backups, -I and --hide what their
patterns match.  ls-lisp reads only -a, -A and -B."
  (if (remoto--ls-lisp-p)
      (let ((chars (remoto--ls-lisp-switches switches)))
        (seq-remove (lambda (entry)
                      (or (if (memq ?A chars)
                              (remoto--dot-entry-p entry)
                            (and (not (memq ?a chars))
                                 (string-prefix-p "." (car entry))))
                          (and (memq ?B chars) (string-suffix-p "~" (car entry)))))
                    entries))
    (let* ((options (remoto--ls-options switches))
           (show (plist-get options :show))
           (patterns (append (plist-get options :ignore)
                             (and (plist-get options :backups) '("*~" ".*~"))
                             (and (not show) (plist-get options :hide)))))
      (seq-remove (lambda (entry)
                    (or (pcase show
                          ('all nil)
                          ('almost (remoto--dot-entry-p entry))
                          (_ (string-prefix-p "." (car entry))))
                        (seq-some (lambda (pattern)
                                    (remoto--ls-pattern-p pattern (car entry)))
                                  patterns)))
                  entries))))

(defun remoto--insert-listing (dir switches)
  "Insert the Dired listing of DIR, accounts or repositories.
SWITCHES are the ls options, which decide what shows and in what order."
  (let* ((listing (remoto--listing dir))
         (classify (remoto--classify-p switches))
         (human (remoto--human-p switches))
         (lines (remoto--sort-entries
                 (remoto--shown-entries
                  (append (list (cons "." `((note . ,(remoto--listing-note listing))
                                            ,@remoto--dir-entry))
                                (cons ".." remoto--dir-entry))
                          (remoto--listing-entries listing))
                  switches)
                 switches))
         (widths (remoto--listing-widths lines classify human)))
    (insert "total 0\n")
    (dolist (line lines)
      (insert (remoto--format-dired-entry (car line) (cdr line)
                                          classify widths human)))))

(defvar-local remoto--entry-widths nil
  "(NAMES . WIDTHS) for the Dired of a list of names in this buffer.
Dired asks for each line on its own, and the widths need all the names;
the first name of each reading computes them again.")

(defun remoto--insert-entry-line (filename switches)
  "Insert the Dired line of FILENAME, an account, repository or ref.
SWITCHES are the ls options.  A Dired of a list of names asks for each
line on its own; the names in `dired-directory' line the notes up."
  (let* ((classify (remoto--classify-p switches))
         (human (remoto--human-p switches))
         (dir (remoto--handle-file-name-directory filename))
         (name (remoto--handle-file-name-nondirectory filename))
         (listed (bound-and-true-p dired-directory))
         (names (if (and (consp listed)
                         (equal dir (car listed))
                         (member name (cdr listed)))
                    (cdr listed)
                  (list name))))
    (unless (and (eq names (car remoto--entry-widths))
                 (not (equal name (car names))))
      (setq remoto--entry-widths
            (cons names
                  (remoto--listing-widths
                   (mapcar (lambda (each)
                             (cons each (or (remoto--entry-for (concat dir each))
                                            remoto--dir-entry)))
                           names)
                   classify human))))
    ;; Two columns of our own: Dired gives a list of names whose lines
    ;; bring none one column per line and then two more.
    (insert "  " (remoto--format-dired-entry
                  name (or (remoto--entry-for filename) remoto--dir-entry)
                  classify (cdr remoto--entry-widths) human))))

(defun remoto--handle-insert-directory
    (filename switches &optional _wildcard full-directory-p)
  "Insert a Dired-format listing for remote FILENAME.
SWITCHES, the ls options, decide the order, -F indicators and -h sizes.
FULL-DIRECTORY-P asks for a listing; without it FILENAME gets its one
line, as with ls-lisp.  /github: and /github:OWNER/ list accounts and repos."
  ;; A Dired of a list of names passes each one relative to its directory,
  ;; and the first Dired of a session passes a short form as typed.
  (let* ((filename (expand-file-name filename))
         (entry (and (not full-directory-p) (remoto--entry-name-p filename)))
         (filename (if entry filename (remoto--maybe-rewrite filename)))
         (dir (and (not entry) (remoto--listing-dir filename)))
         (classify (remoto--classify-p switches))
         (human (remoto--human-p switches)))
    (cond
     (entry (remoto--insert-entry-line filename switches))
     (dir (when (or full-directory-p
                    (equal filename dir)
                    (string-suffix-p "/" filename))
            (remoto--insert-listing dir switches)))
     (t
      (when-let* ((parsed (remoto--parse-path filename))
                  (entry (remoto--tree-entry parsed)))
        (if full-directory-p
            (progn
              (insert "total 0\n")
              (dolist (child (remoto--sort-entries
                              (remoto--shown-entries
                               (append (list (cons "." remoto--dir-entry)
                                             (cons ".." remoto--dir-entry))
                                       (remoto--tree-children parsed))
                               switches)
                              switches))
                (insert (remoto--format-dired-entry
                         (car child) (cdr child) classify nil human))))
          (insert "  " (remoto--format-dired-entry
                        (file-name-nondirectory
                         (directory-file-name (remoto-path-path parsed)))
                        entry classify nil human))))))))

(defun remoto--handle-file-local-copy (filename)
  "Download remote FILENAME to a temp file, return temp path.
A short FILENAME, /github:OWNER/REPO/PATH, names PATH on the default branch."
  (when-let* ((parsed (remoto--parse-path (remoto--maybe-rewrite filename)))
              (resolved (remoto--resolve-ref parsed))
              (path (remoto--relative-path (remoto-path-path resolved)))
              (content (remoto-forge-content
                        (remoto-path-forge resolved)
                        (remoto-path-owner resolved)
                        (remoto-path-repo resolved)
                        (remoto-path-ref resolved)
                        path)))
    (let* ((ext (file-name-extension path t))
           (temp (make-temp-file "remoto-" nil ext))
           (coding-system-for-write 'no-conversion))
      (write-region content nil temp nil 0)
      temp)))

(defun remoto--handle-make-nearby-temp-file (prefix &optional dir-flag suffix)
  "Create a temp file using PREFIX in the system temp dir.
Pass DIR-FLAG and SUFFIX through to `make-temp-file'."
  (make-temp-file prefix dir-flag suffix))

;;;; Additional operations needed by dired and other Emacs internals

(defun remoto--handle-file-name-as-directory (filename)
  "Append / to FILENAME if not already present.
/github: and /github:OWNER/REPO@ are directory names as they are: with a
slash after them, every name their Dired holds would read /github:/OWNER
or /github:OWNER/REPO@/REF."
  (let ((parsed (remoto--parse filename)))
    (if (or (string-suffix-p "/" filename)
            (and parsed
                 (string-empty-p (remoto-path-query parsed))
                 (let ((level (remoto-path-level parsed)))
                   (or (eq level 'root)
                       (eq (remoto--level-kind level) 'ref)))))
        filename
      (concat filename "/"))))

(defun remoto--handle-directory-file-name (directory)
  "Strip trailing / from DIRECTORY."
  (if (and (string-suffix-p "/" directory)
           ;; Don't strip the / after the colon in /github:o/r@ref:/
           (not (string-suffix-p ":/" directory)))
      (substring directory 0 (1- (length directory)))
    directory))

(defun remoto--handle-file-name-case-insensitive-p (_filename)
  "Forge repositories are case-sensitive."
  nil)

(defun remoto--handle-vc-registered (_filename)
  "Remote files are not under local vc."
  nil)

(defun remoto--handle-make-directory (dir &optional _parents)
  "Ignore existing DIR and signal an error otherwise.
Any name below an owner is a directory by its shape, so it must exist
too, or Dired adds a line for the repository that `+' did not create."
  (unless (and (remoto--handle-file-directory-p dir)
               (remoto--handle-file-exists-p dir))
    (user-error "Remoto: repository is read-only")))

(defun remoto--handle-abbreviate-file-name (filename)
  "Return FILENAME as-is - no abbreviation for remote paths."
  filename)

(defun remoto--handle-unhandled-file-name-directory (_filename)
  "Return nil - no local equivalent for remote paths."
  nil)

;;;; Programs

;; A program started in a remoto directory runs in `~', which is what a nil
;; `unhandled-file-name-directory' gives it.  The searches among them would
;; report the files there as the repository's, so they stop with a message.

(defconst remoto--search-programs
  '("grep" "egrep" "fgrep" "rg" "ugrep" "ag" "ack" "find" "fd" "fdfind")
  "Programs that search the files of the directory they run in.")

(defun remoto--search-program (program args)
  "Return the search that PROGRAM with ARGS would start, or nil.
That is PROGRAM itself, git with its grep subcommand, or for a shell a
word of the command line after its -c."
  (when (stringp program)
    ;; Words of a command line can look like remote names; they are only split.
    (let* ((file-name-handler-alist nil)
           (name (file-name-nondirectory program))
           (line (cadr (or (member shell-command-switch args) (member "-c" args)))))
      (cond ((member name remoto--search-programs) name)
            ((and (equal name "git") (member "grep" args)) "git grep")
            ((stringp line)
             (seq-find (lambda (word) (member word remoto--search-programs))
                       (mapcar #'file-name-nondirectory
                               (split-string line "[][ \t\n|;&()<>`'\"$]+" t))))))))

(defun remoto--refuse-search (program args)
  "Signal a `user-error' when PROGRAM with ARGS is a search."
  (when-let* ((search (remoto--search-program program args)))
    (user-error "Remoto: %s needs a clone; a repository has no local files" search)))

(defun remoto--handle-process-file (program &optional infile buffer display &rest args)
  "Run PROGRAM with ARGS unless it is a search; INFILE, BUFFER, DISPLAY as usual."
  (remoto--refuse-search program args)
  (remoto--pass-on #'process-file (append (list program infile buffer display) args)))

(defun remoto--handle-start-file-process (name buffer program &rest args)
  "Start PROGRAM with ARGS as process NAME in BUFFER unless it is a search."
  (remoto--refuse-search program args)
  (remoto--pass-on #'start-file-process (append (list name buffer program) args)))

(defun remoto--handle-make-process (&rest args)
  "Make the process that ARGS describe unless its command is a search."
  (let ((command (plist-get args :command)))
    (remoto--refuse-search (car command) (cdr command)))
  (remoto--pass-on #'make-process args))

(defun remoto--handle-shell-command (command &rest args)
  "Run the shell COMMAND with ARGS unless it is a search."
  (remoto--refuse-search shell-file-name (list shell-command-switch command))
  (remoto--pass-on #'shell-command (cons command args)))

;;;; Write operations (all read-only)

(defun remoto--read-only (&rest _args)
  "Signal that remote repos are read-only."
  (user-error "Remoto: repository is read-only"))

(defalias 'remoto--handle-write-region #'remoto--read-only)
(defalias 'remoto--handle-delete-file #'remoto--read-only)
(defalias 'remoto--handle-delete-directory #'remoto--read-only)
(defalias 'remoto--handle-rename-file #'remoto--read-only)
(defun remoto--handle-copy-file (file newname
                                      &optional ok-if-already-exists keep-time
                                      preserve-uid-gid preserve-permissions)
  "Copy FILE to NEWNAME outside remoto, as `copy-file' copies a local file.
OK-IF-ALREADY-EXISTS, KEEP-TIME and PRESERVE-UID-GID go to `copy-file'.
A new copy, and any under PRESERVE-PERMISSIONS, gets the git mode of FILE
rather than the mode of the temporary file it comes from."
  (if (remoto--parse-path newname)
      (remoto--read-only 'copy-file file newname)
    (let* ((file (remoto--maybe-rewrite file))
           (local-copy (remoto--handle-file-local-copy file))
           (new (not (file-exists-p newname))))
      (unless local-copy
        (error "Remoto: failed to download %s" file))
      (unwind-protect
          (let ((inhibit-file-name-handlers
                 (cons #'remoto-file-name-handler
                       (and (eq inhibit-file-name-operation 'copy-file)
                            inhibit-file-name-handlers)))
                (inhibit-file-name-operation 'copy-file))
            (copy-file local-copy newname ok-if-already-exists keep-time
                       preserve-uid-gid preserve-permissions))
        (when (file-exists-p local-copy)
          (delete-file local-copy)))
      (when (or new preserve-permissions)
        (let ((modes (if (equal "100755" (alist-get 'mode (remoto--tree-entry
                                                           (remoto--parse-path file))))
                         #o755
                       #o644)))
          (set-file-modes newname (if preserve-permissions
                                      modes
                                    (logand modes (default-file-modes)))))))))
(defalias 'remoto--handle-set-file-modes #'remoto--read-only)
(defalias 'remoto--handle-set-file-times #'remoto--read-only)

;;;; Refresh

;;;###autoload
(defun remoto-refresh ()
  "Invalidate cached tree for the current repo, re-fetch on next access.
In a listing of /github: or /github:OWNER/, fetch that listing again.  In
a Dired of branches and tags, forget the repository's branches and tags."
  (interactive)
  (let* ((dir (or dired-directory default-directory))
         (dir (if (consp dir) (car dir) dir))
         (listing-dir (remoto--listing-dir dir))
         (parsed (remoto--parse-path dir)))
    (cond
     (listing-dir
      (remhash listing-dir remoto--listing-cache)
      (message "Remoto: cache cleared for %s" listing-dir)
      (when (derived-mode-p 'dired-mode)
        (revert-buffer)))
     (parsed
      (let* ((resolved (remoto--resolve-ref parsed))
             (key (remoto--repo-key resolved)))
        (remhash key remoto--tree-cache)
        (remoto-forge-forget (remoto-path-forge resolved)
                             (remoto-path-owner resolved)
                             (remoto-path-repo resolved))
        (message "Remoto: cache cleared for %s" key)
        (when (derived-mode-p 'dired-mode)
          (revert-buffer))))
     ((remoto--refs-dir-p dir)
      (let* ((refs (remoto--parse dir))
             (repo-id (remoto--repo-name (remoto-path-owner refs)
                                         (remoto-path-repo refs))))
        (remoto-forge-forget (remoto-path-forge refs)
                             (remoto-path-owner refs) (remoto-path-repo refs))
        (message "Remoto: cache cleared for %s" repo-id)
        (when (derived-mode-p 'dired-mode)
          (revert-buffer))))
     (t (user-error "Remoto: not in a remoto buffer")))))

;;;; Forge web URLs

(defvar remoto-forge-url-templates
  '((github
     (blob    . "https://github.com/%o/%r/blob/%R/%p%L")
     (tree    . "https://github.com/%o/%r/tree/%R/%p%L")
     (blame   . "https://github.com/%o/%r/blame/%R/%p%L")
     (history . "https://github.com/%o/%r/commits/%R/%p")
     (raw     . "https://raw.githubusercontent.com/%o/%r/%R/%p")
     (repo    . "https://github.com/%o/%r")
     (ssh     . "git@github.com:%o/%r.git")
     (https   . "https://github.com/%o/%r.git")
     (compare . "https://github.com/%o/%r/compare/%R")
     (new-pr  . "https://github.com/%o/%r/pull/new/%R")
     (issue   . "https://github.com/%o/%r/issues/%N")
     (pr      . "https://github.com/%o/%r/pull/%N")
     (pr-diff . "https://github.com/%o/%r/pull/%N/files")
     (owner       . "https://github.com/%o")
     (owner-repos . "https://github.com/%o?tab=repositories")
     (line    . "#L%s")
     (region  . "#L%s-L%e")))
  "Per-forge web-URL templates, keyed by forge symbol.

Each value is an alist of (KIND . TEMPLATE).  Path-level kinds: `blob',
`tree', `blame', `history', `raw'.  Repository-level kinds: `repo' (web
root), `ssh' and `https' (clone URLs).  Account-level kinds: `owner' for
the profile page and `owner-repos' for the repositories tab.  Plus the
line-fragment builders `line' and `region'.  Templates are expanded with
`format-spec' using:

  %o  repository owner
  %r  repository name
  %R  git ref (branch, tag, or commit SHA)
  %k  the kind of %R where the forge spells it out: branch, tag or commit
  %p  path relative to the repository root
  %N  topic key, of an issue or pull request
  %L  line fragment built from the `line'/`region' templates
  %s  start line (in the `line' and `region' templates)
  %e  end line (in the `region' template)

The default `remoto-forge-url' answers from the entry under the name of
the forge; a forge without one has no URLs unless its own method answers.")

(cl-defgeneric remoto--ref-kind (_forge _owner _repo _ref)
  "Return \"branch\", \"tag\" or \"commit\" for REF of OWNER/REPO on FORGE.
Only a forge whose URL templates use %k answers; nil by default."
  nil)

(defun remoto--forge-type (path)
  "Return the forge symbol for remoto PATH, or nil when undetermined.
Derived from the path prefix, e.g. \"/github:...\" -> `github'."
  (when-let* (((stringp path))
              (entry (remoto--prefix-of path)))
    (remoto-forge-name (cdr entry))))

(defun remoto--url-encode-path (path)
  "Percent-encode each segment of PATH for a web URL, keeping the slashes."
  (mapconcat #'url-hexify-string (split-string (or path "") "/") "/"))

(cl-defgeneric remoto-forge-url (forge kind context)
  "Return the web or clone URL of KIND for CONTEXT on FORGE, or nil.
KIND is a key of the templates of `remoto-forge-url-templates', such as
`blob' or `ssh'.  CONTEXT is a plist of :owner :repo :ref :path :key
:line-start :line-end.  By default the templates of FORGE's name answer."
  (when-let* ((templates (alist-get (remoto-forge-name forge)
                                    remoto-forge-url-templates))
              ((not (memq kind '(line region))))
              (template (alist-get kind templates)))
    (remoto--fill-url-template forge template templates context)))

(defun remoto--fill-url-template (forge template templates context)
  "Return TEMPLATE of FORGE filled from the plist CONTEXT.
TEMPLATES give the line fragments.  A nil ref is \"HEAD\", which the
forge resolves to the default branch."
  (let* ((owner (plist-get context :owner))
         (repo (plist-get context :repo))
         (ref (plist-get context :ref))
         (start (plist-get context :line-start))
         (end (plist-get context :line-end))
         (line (cond ((and start end)
                      (format-spec (alist-get 'region templates)
                                   `((?s . ,start) (?e . ,end))))
                     (start (format-spec (alist-get 'line templates)
                                         `((?s . ,start))))
                     (t "")))
         (ref-kind (and (string-search "%k" template)
                        (remoto--ref-kind forge owner repo ref))))
    (format-spec template `((?o . ,owner)
                            (?r . ,repo)
                            (?R . ,(or ref "HEAD"))
                            (?k . ,(or ref-kind "branch"))
                            (?p . ,(remoto--url-encode-path
                                    (plist-get context :path)))
                            (?N . ,(plist-get context :key))
                            (?L . ,line)))))

(defun remoto--refuse-url (forge kind)
  "Signal a `user-error' that FORGE has no URL of KIND."
  (user-error "Remoto: %s has no %s URL"
              (or (remoto-forge-title forge) (remoto-forge-name forge)) kind))

(defun remoto--url (forge kind context)
  "Return the URL of KIND for CONTEXT on FORGE, or refuse when FORGE has none.
See `remoto-forge-url'."
  (or (remoto-forge-url forge kind context)
      (remoto--refuse-url forge kind)))

(defun remoto--forge-named (name)
  "Return the registered forge called NAME, a symbol, or nil."
  (seq-find (lambda (forge) (eq (remoto-forge-name forge) name))
            (mapcar #'cdr remoto--forges)))

(defun remoto--context-permalink (ctx)
  "Return the URL of the context plist CTX pinned to a commit, or nil.
A source whose default ref is nil has no refs to pin."
  (let* ((forge (remoto--forge-named (plist-get ctx :forge)))
         (owner (plist-get ctx :owner))
         (repo (plist-get ctx :repo))
         (ref (remoto-path-ref
               (remoto--resolve-ref
                (remoto-path-create :forge forge :owner owner :repo repo
                                    :ref (plist-get ctx :ref) :path "/")))))
    (when ref
      (remoto-forge-url
       forge (plist-get ctx :kind)
       (plist-put (copy-sequence ctx) :ref
                  (or (remoto-forge-resolve-ref forge owner repo ref)
                      (user-error "Remoto: could not resolve commit SHA for %s@%s"
                                  (remoto--repo-name owner repo) ref)))))))

(defun remoto--url-path (input)
  "Return the `remoto-path' that the URL, remote or shorthand INPUT names.
Signal a `user-error' when no forge answers, see `remoto--parse-url'."
  (or (when-let* ((url (remoto--parse-url input))
                  ((remoto-path-repo url)))
        url)
      (user-error "Remoto: cannot parse input: %s" input)))

(defun remoto--path-context (path &optional line-start line-end)
  "Build a forge-agnostic context plist for the remoto PATH string.
Return nil when PATH is not a remoto path.

Plist keys: :forge :owner :repo :ref :path :kind :type :line-start
:line-end.  :kind is `tree' or `blob'.  :type is the Embark target type,
one of `remoto-repo', `remoto-dir', `remoto-file'.  A repository root is
classified as `remoto-repo' without resolving the ref or fetching the
tree (so it works offline and on bare `owner/repo' targets).  LINE-START
and LINE-END are retained only for `remoto-file' targets."
  (when-let* ((parsed (remoto--parse-path path)))
    (if (member (remoto-path-path parsed) '("" "/"))
        (list :forge (remoto--forge-type path)
              :owner (remoto-path-owner parsed)
              :repo (remoto-path-repo parsed)
              :ref (remoto-path-ref parsed)
              :path "" :kind 'tree :type 'remoto-repo
              :line-start nil :line-end nil)
      (let* ((resolved (remoto--resolve-ref parsed))
             (entry (remoto--tree-entry resolved))
             (filep (not (and entry (equal "tree" (alist-get 'type entry))))))
        (list :forge (remoto--forge-type path)
              :owner (remoto-path-owner resolved)
              :repo (remoto-path-repo resolved)
              :ref (remoto-path-ref resolved)
              :path (remoto--relative-path (remoto-path-path resolved))
              :kind (if filep 'blob 'tree)
              :type (if filep 'remoto-file 'remoto-dir)
              :line-start (and filep line-start)
              :line-end (and filep line-end))))))

(defun remoto--buffer-file-context ()
  "Return a context plist describing the current buffer's remoto target.

Works in file buffers (line/region at point) and in Dired (entry at
point, falling back to the directory).  Resolves the ref so the context
carries a concrete branch, then delegates classification to
`remoto--path-context'.  Signals a `user-error' when the current buffer
is not a remoto buffer."
  (let* ((dired (derived-mode-p 'dired-mode))
         (file (or buffer-file-name
                   (and dired (dired-get-filename nil t))
                   (and dired (if (listp dired-directory)
                                  (car dired-directory)
                                dired-directory))
                   default-directory))
         (parsed (and file (remoto--parse-path file))))
    (unless parsed
      (user-error "Remoto: not in a remoto buffer"))
    (let* ((canonical (remoto--canonical-path (remoto--resolve-ref parsed)))
           (region (and (not dired) (use-region-p)))
           (line-start (and (not dired)
                            (line-number-at-pos
                             (if region (region-beginning) (point)))))
           (line-end (and region (line-number-at-pos (region-end)))))
      (remoto--path-context canonical line-start line-end))))

(defun remoto--context-url (ctx kind)
  "Return the URL of KIND for the context plist CTX, or refuse without one."
  (remoto--url (remoto--forge-named (plist-get ctx :forge)) kind ctx))

(defun remoto--context-permalink-or-refuse (ctx)
  "Return the permalink of the context plist CTX, or refuse without one."
  (or (remoto--context-permalink ctx)
      (remoto--refuse-url (remoto--forge-named (plist-get ctx :forge))
                          'permalink)))

(defun remoto--context-web-url (ctx)
  "Return the human-facing web URL for context CTX, chosen by its :type.
A repo target yields the repository page, a directory the tree view, and
a file the blob view (with any line fragment)."
  (remoto--context-url ctx (pcase (plist-get ctx :type)
                             ('remoto-repo 'repo)
                             ('remoto-dir 'tree)
                             (_ 'blob))))

(defun remoto--require-blob (ctx what)
  "Signal a `user-error' unless CTX refers to a file.
WHAT names the operation, for the error message."
  (unless (eq (plist-get ctx :kind) 'blob)
    (user-error "Remoto: %s is only available for files, not directories"
                what)))

(defun remoto--kill-url (url)
  "Put URL on the kill ring and report it in the echo area."
  (kill-new url)
  (message "Copied: %s" url))

;;;; URL commands

;;;###autoload
(defun remoto-copy-url ()
  "Copy the forge web URL for the current file or directory.
In a file buffer the link targets the current line, or the active
region as a line range.  In Dired it targets the entry at point, or
the directory itself."
  (interactive)
  (let ((ctx (remoto--buffer-file-context)))
    (remoto--kill-url (remoto--context-url ctx (plist-get ctx :kind)))))

;;;###autoload
(defun remoto-copy-blame-url ()
  "Copy the forge blame URL for the current file and line/region."
  (interactive)
  (let ((ctx (remoto--buffer-file-context)))
    (remoto--require-blob ctx "Blame")
    (remoto--kill-url (remoto--context-url ctx 'blame))))

;;;###autoload
(defun remoto-copy-permalink ()
  "Copy a permalink: the web URL pinned to the current commit SHA.
Resolves the ref to a commit via the forge API so the link keeps
pointing at the same content even after the branch advances."
  (interactive)
  (remoto--kill-url
   (remoto--context-permalink-or-refuse (remoto--buffer-file-context))))

;;;###autoload
(defun remoto-copy-raw-url ()
  "Copy the raw-content URL for the current file."
  (interactive)
  (let ((ctx (remoto--buffer-file-context)))
    (remoto--require-blob ctx "Raw URL")
    (remoto--kill-url (remoto--context-url ctx 'raw))))

;;;###autoload
(defun remoto-copy-history-url ()
  "Copy the commit-history URL for the current file or directory."
  (interactive)
  (let ((ctx (remoto--buffer-file-context)))
    (remoto--kill-url (remoto--context-url ctx 'history))))

;;;###autoload
(defun remoto-browse-url ()
  "Open the forge web page for the current file or directory in a browser."
  (interactive)
  (let* ((ctx (remoto--buffer-file-context))
         (url (remoto--context-url ctx (plist-get ctx :kind))))
    (browse-url url)
    (message "Browsing: %s" url)))

;;;###autoload
(define-obsolete-function-alias 'remoto-copy-github-url #'remoto-copy-url "1.8.0")

;;;; Search cache and background requests

(defvar remoto--search-cache (make-hash-table :test 'equal)
  "Cache: query string -> (TIMESTAMP . RESULTS).
Entries expire after `remoto-search-cache-ttl' seconds.")

(defcustom remoto-debounce-delay 0.3
  "Seconds of idle time before firing an async search request.
Lower values feel more responsive but generate more API calls."
  :type 'number
  :group 'remoto)

(defcustom remoto-min-search-chars 3
  "Minimum characters before searching users or repos.
Prevents premature API requests while typing short prefixes."
  :type 'integer
  :group 'remoto)

(defcustom remoto-repo-cache-ttl 1800
  "Seconds before repo list cache entries expire.
Repo lists change infrequently, so a longer TTL (default 30 min)
avoids repeated fetches during a session."
  :type 'integer
  :group 'remoto)

(defvar remoto--debounce-timer nil
  "Active idle timer for debounced async searches.")

(defvar remoto--debounce-key nil
  "Key identifying the currently pending debounce.
When a new debounce request arrives with the same key, the
existing timer is kept rather than cancelled and rescheduled.
This prevents completion frameworks (vertico, icomplete) from
starving the async fetch by re-calling the completion function
on every `post-command-hook' cycle.")

(defvar remoto--async-generation 0
  "Monotonic counter for invalidating stale async callbacks.
Incremented on each new debounce schedule; callbacks whose
captured generation doesn't match the current value are stale
and skip UI refresh (but still cache their results).")

(defun remoto--search-cache-get (key &optional ttl)
  "Return cached results for KEY if not expired.
TTL overrides `remoto-search-cache-ttl' when provided.
Returns two values via list: (HIT-P RESULTS).  HIT-P is non-nil
when KEY was found and not expired.  RESULTS may be nil for
queries that returned zero results."
  (let ((cache-ttl (or ttl remoto-search-cache-ttl)))
    (if-let* ((entry (gethash key remoto--search-cache))
              (timestamp (car entry))
              (fresh-p (or (zerop cache-ttl)
                           (< (- (float-time) timestamp) cache-ttl))))
        (list t (cdr entry))
      (when entry (remhash key remoto--search-cache))
      '(nil nil))))

(defun remoto--search-cache-put (key results)
  "Store RESULTS for KEY with current timestamp."
  (puthash key (cons (float-time) results) remoto--search-cache)
  results)

(defun remoto--api-async (forge endpoint callback &optional errback)
  "Call ENDPOINT of the REST API of FORGE asynchronously via ghub.
CALLBACK receives the parsed JSON response; on a failure ERRBACK, when
non-nil, is called with no arguments.  The `:host' is explicit, or ghub
may resolve the HTML site.  The call counts toward the fetch indicator."
  (let* ((resource (concat "/" endpoint))
         (auth (remoto--auth forge)))
    (if (and (eq auth 'none) (remoto--account-endpoint-p endpoint))
        (when errback (funcall errback))
      (remoto--api-async-send forge resource auth callback errback))))

(defun remoto--api-async-send (forge resource auth callback errback)
  "Send the request of `remoto--api-async' for RESOURCE of FORGE with AUTH.
CALLBACK and ERRBACK are those of `remoto--api-async'."
  (condition-case nil
      (let ((inhibit-message t))
        (remoto--inflight-inc)
        ;; ghub calls :callback as (value headers status req) and retries
        ;; with (value) on `wrong-number-of-arguments'.  Accept the full
        ;; arglist so the retry never fires and the in-flight counter is
        ;; decremented exactly once.  All callers pass a 1-arg callback.
        (ghub-get resource nil
                  :auth auth
                  :username (remoto--ghub-username forge auth)
                  :reader #'remoto--json-reader
                  :host (remoto--api-host forge)
                  :forge (remoto--ghub-forge forge)
                  :callback (lambda (value &rest _)
                              (remoto--inflight-dec)
                              (funcall callback value))
                  :errorback (lambda (&rest _)
                               (remoto--inflight-dec)
                               (when errback (funcall errback)))))
    (error (remoto--inflight-dec)
           (when errback (funcall errback)))))

(defun remoto--debounce (key fn)
  "Schedule FN after `remoto-debounce-delay' seconds of idle time.
KEY identifies this request; if a timer is already pending for
the same KEY, it is kept as-is (no cancel/reschedule).  A
different KEY cancels the old timer and schedules a new one."
  (unless (and remoto--debounce-timer
               (equal key remoto--debounce-key))
    (when remoto--debounce-timer
      (cancel-timer remoto--debounce-timer))
    (setq remoto--debounce-key key)
    (cl-incf remoto--async-generation)
    (let ((gen remoto--async-generation))
      (setq remoto--debounce-timer
            (run-with-idle-timer
             remoto-debounce-delay nil
             (lambda ()
               (setq remoto--debounce-timer nil
                     remoto--debounce-key nil)
               (when (= gen remoto--async-generation)
                 (funcall fn))))))))

(defun remoto--invalidate-completion-ui ()
  "Void live front-ends' recompute caches in the selected minibuffer.
Emacs has no single API for refreshing an in-progress completion UI,
so poke the popular front-ends explicitly and fall back to
`post-command-hook' for anything else.  Assumes the active minibuffer
window is selected."
  ;; Default cycling cache.
  (when (boundp 'completion-all-sorted-completions)
    (setq completion-all-sorted-completions nil))
  ;; Vertico skips recompute while the input is `equal', so a
  ;; late-arriving fetch is ignored unless its cache is voided.
  ;; `set' avoids a free-variable warning when vertico is absent.
  (when (boundp 'vertico--input)
    (set 'vertico--input t))
  ;; Icomplete/fido and any UI that recomputes on this hook.
  (run-hooks 'post-command-hook)
  ;; The default *Completions* buffer is not live; rebuild it only
  ;; when it is already on screen.
  (when (get-buffer-window "*Completions*" 0)
    (minibuffer-completion-help)))

(defun remoto--refresh-minibuffer-completions ()
  "Refresh the active minibuffer's completion display.
Called from async callbacks after updating the cache, so freshly
cached candidates appear without the user editing the input."
  (run-at-time
   0 nil
   (lambda ()
     (when-let* ((win (active-minibuffer-window)))
       (with-selected-window win
         (remoto--invalidate-completion-ui))))))

(defvar remoto--user-timer nil
  "Idle timer of the lookup of the token's account that completion waits for.")

(defun remoto--known-user (forge)
  "Return the login of the account of the token on FORGE, or nil until known.
An unknown one is looked up after `remoto-debounce-delay' of idle time,
as a search waits, and the completions refresh when it answers.  The
lookup asks nothing without a token, and settles the login either way."
  (let ((login (remoto--forge-login forge)))
    (or (remoto--login-user login)
        (unless (remoto--login-failed login)
          (when (timerp remoto--user-timer)
            (cancel-timer remoto--user-timer))
          (setq remoto--user-timer
                (run-with-idle-timer
                 remoto-debounce-delay nil
                 (lambda ()
                   (setq remoto--user-timer nil)
                   (when (stringp (while-no-input
                                    (remoto--get-authenticated-user forge)))
                     (remoto--refresh-minibuffer-completions)))))
          nil))))

;;;; Listings above the repository level

(defcustom remoto-listing-cap 1000
  "Most repositories a Dired listing of /github:OWNER/ holds.
The listing keeps the most recently pushed ones.  Its first page arrives
before Dired shows it; the later ones load in the background."
  :type 'integer
  :group 'remoto)

(defun remoto--listing-dir (filename)
  "Return the listing directory that FILENAME names, or nil.
That is /github:, the accounts of the token, or /github:OWNER/, OWNER's
repositories: the two levels above a repository."
  (when-let* ((parsed (remoto--parse
                       (remoto--handle-file-name-as-directory filename)))
              (query (remoto-path-query parsed)))
    (pcase (remoto-path-level parsed)
      ('root (and (member query '("" "/")) (remoto--path-prefix parsed)))
      ('owner (and (string-empty-p query)
                   (format "%s%s/" (remoto--path-prefix parsed)
                           (remoto-path-owner parsed)))))))

(defun remoto--refs-dir-p (filename)
  "Return non-nil when FILENAME is a /github:OWNER/REPO@ directory."
  (when-let* ((parsed (remoto--parse filename)))
    (and (eq (remoto-path-level parsed) 'refs)
         (string-empty-p (remoto-path-query parsed)))))

(defun remoto--bare-name (parsed)
  "Return the query of PARSED when it is a bare name at its level, else nil.
A bare name holds no slash, colon or delimiter: it is one line of a
listing, not a path into it."
  (let ((query (remoto-path-query parsed)))
    (and (not (string-empty-p query))
         (not (string-search "/" query))
         (not (string-match-p (remoto-forge-repo-end (remoto-path-forge parsed))
                              query))
         query)))

(defun remoto--bare-repo-parts (filename)
  "Return (OWNER . NAME) when FILENAME is a bare /github:OWNER/NAME."
  (when-let* ((parsed (remoto--parse filename))
              ((eq (remoto-path-level parsed) 'owner))
              (name (remoto--bare-name parsed)))
    (cons (remoto-path-owner parsed) name)))

(defun remoto--entry-name-p (filename)
  "Return non-nil when FILENAME names an account, a repository or a ref.
Those are the lines of a listing or of a Dired of matches."
  (when-let* ((parsed (remoto--parse filename))
              (query (remoto-path-query parsed)))
    (pcase (remoto-path-level parsed)
      ((or 'root 'owner) (and (remoto--bare-name parsed) t))
      ('refs (and (not (string-empty-p query))
                  (not (string-search ":" query))
                  (not (string-suffix-p "/" query)))))))

(defun remoto--entry-for (name)
  "Return the remembered Dired line attributes of the remoto NAME."
  (gethash (downcase name) remoto--entry-cache))

(defun remoto--remember (name entry)
  "Remember ENTRY as the Dired line attributes of the remoto NAME.
Return ENTRY."
  (puthash (downcase name) entry remoto--entry-cache))

(defun remoto--listed-p (filename)
  "Return non-nil when FILENAME is an entry of a cached listing.
The age of the listing does not matter: a Dired buffer that still shows
the name has to open it.  A name that a search found counts too."
  (or (when-let* ((listing (gethash (remoto--handle-file-name-directory filename)
                                    remoto--listing-cache)))
        (assoc (remoto--handle-file-name-nondirectory filename)
               (remoto--listing-entries listing)))
      (remoto--entry-for filename)))

(defun remoto--listing-fresh-p (listing)
  "Return non-nil when LISTING may be shown without fetching it again.
Its time renews when the background pages end, failed or not: the revert
that shows the end would otherwise fetch it all again, and again."
  (or (zerop remoto-repo-cache-ttl)
      (< (- (float-time) (remoto--listing-time listing))
         remoto-repo-cache-ttl)))

(defun remoto--listing (dir)
  "Return the listing of DIR, fetching it unless a fresh one is cached.
DIR is what `remoto--listing-dir' returns."
  (let ((cached (gethash dir remoto--listing-cache)))
    (if (and cached (remoto--listing-fresh-p cached))
        cached
      (remoto--fetch-listing (remoto--canonical-forge dir) dir))))

(defun remoto--listing-owner (dir)
  "Return the name of DIR's listing in the messages: its owner, or DIR."
  (or (remoto-path-owner (remoto--parse dir)) dir))

(defun remoto--add-listing-page (listing entries next)
  "Add ENTRIES, one page, to LISTING, up to `remoto-listing-cap'.
NEXT is the continuation of the page after, nil after the last."
  (let ((all (append (remoto--listing-entries listing) entries)))
    (setf (remoto--listing-entries listing) (seq-take all remoto-listing-cap)
          (remoto--listing-state listing)
          (cond ((< remoto-listing-cap (length all)) 'capped)
                ((null next) nil)
                ((< (length all) remoto-listing-cap) 'fetching)
                (t 'capped)))))

(defun remoto--fetch-listing (forge dir)
  "Fetch the first page of the listing DIR of FORGE and cache the listing.
When more pages follow, they load in the background."
  (pcase-let* ((`(,entries . ,next) (remoto-forge-entries forge (remoto--parse dir)))
               (listing (puthash dir (remoto--listing-create) remoto--listing-cache)))
    (remoto--add-listing-page listing entries next)
    (when (eq (remoto--listing-state listing) 'fetching)
      (message "Remoto: listing the first %d repositories of %s, fetching the rest"
               (length entries) (remoto--listing-owner dir))
      (remoto--fetch-listing-page forge dir listing next))
    listing))

(defun remoto--fetch-listing-page (forge dir listing continuation)
  "Fetch the page CONTINUATION names into LISTING, the one of DIR on FORGE.
In the background and one page at a time, as GitHub asks of clients,
until the last page, the cap or a failure.  A LISTING no longer cached,
as after `remoto-refresh', ends it."
  (remoto-forge-entries
   forge (remoto--parse dir) continuation
   (lambda (page)
     (when (eq listing (gethash dir remoto--listing-cache))
       (if (eq page 'failed)
           (setf (remoto--listing-state listing) 'failed)
         (remoto--add-listing-page listing (car page) (cdr page)))
       (if (eq (remoto--listing-state listing) 'fetching)
           (remoto--fetch-listing-page forge dir listing (cdr page))
         (remoto--listing-done dir listing (remoto--listing-owner dir)))))))

(defun remoto--listing-done (dir listing owner)
  "Say how the background fetch of LISTING ended, and revert DIR's buffers.
OWNER names the account in the message."
  (let ((count (length (remoto--listing-entries listing))))
    (pcase (remoto--listing-state listing)
      ('capped (message "Remoto: listed the %d most recently pushed \
repositories of %s, as `remoto-listing-cap' allows" count owner))
      ('failed (message "Remoto: listing the repositories of %s stopped \
after %d; M-x remoto-refresh retries" owner count))
      (_ (message "Remoto: listed all %d repositories of %s" count owner))))
  (setf (remoto--listing-time listing) (float-time))
  (dolist (buffer (buffer-list))
    (with-current-buffer buffer
      (when (and (derived-mode-p 'dired-mode)
                 (equal dir (if (consp dired-directory)
                                (car dired-directory)
                              dired-directory)))
        (revert-buffer)))))

;;;; Matches of a name that names nothing

(defun remoto--if-found (fn &rest args)
  "Call FN with ARGS, or return nil when the forge answers 404 to it.
Any other failure signals."
  (condition-case err
      (apply fn args)
    (user-error
     (unless (string-prefix-p remoto--not-found (cadr err))
       (signal (car err) (cdr err))))))

(defun remoto--repository-p (forge owner name)
  "Return non-nil when OWNER has a repository NAME on FORGE, asking if need be.
A NAME with a character that no repository name has is not asked about."
  (and (string-match-p (rx bos (+ (in "A-Za-z0-9._-")) eos) name)
       (remoto--if-found #'remoto--resolve-ref
                         (remoto-path-create :forge forge :owner owner
                                             :repo name :path "/"))))

(defun remoto--ref-p (forge owner repo ref)
  "Return non-nil when OWNER/REPO on FORGE has a tree at REF.
REF is a branch, tag or commit; one with a character that no ref has is
not asked about."
  (and (not (string-empty-p ref))
       (not (string-match-p (rx (or (in " \t~^:?*[\\") "..")) ref))
       (remoto--if-found #'remoto--ensure-tree
                         (remoto-path-create :forge forge :owner owner :repo repo
                                             :ref ref :path "/"))))

(defun remoto--words-match-p (query name)
  "Return non-nil when each word of QUERY is in NAME, ignoring case."
  (let ((name (downcase name)))
    (seq-every-p (lambda (word) (string-search word name))
                 (split-string (downcase query)))))

(defun remoto--dired-line-p (name)
  "Return non-nil when the remoto NAME is a line of the current Dired buffer.
Dired opens its lines by name, and the name of an account line is the
same as the account typed as a query."
  (and (derived-mode-p 'dired-mode)
       (save-excursion (dired-goto-file name))))

(defvar remoto--dired-switches nil
  "The ls options of the Dired being made, nil for `dired-listing-switches'.
A Dired of the names that match what was typed takes its order from them.")

(defun remoto--sorted-names (dir names query)
  "Return NAMES, lines of a Dired of DIR, in the order of its ls options.
A name that is QUERY, ignoring case, comes first, wherever the switches
would put it: it is what was typed.  Their text properties go."
  (let* ((sorted (mapcar #'car
                         (remoto--sort-entries
                          (mapcar (lambda (name)
                                    (let ((name (substring-no-properties name)))
                                      (cons name (remoto--entry-for (concat dir name)))))
                                  names)
                          (or remoto--dired-switches dired-listing-switches))))
         (exact (seq-find (lambda (name) (string-equal-ignore-case name query))
                          sorted)))
    (if exact (cons exact (delete exact sorted)) sorted)))

(defun remoto--not-found-or-private (forge owner repo)
  "Signal that FORGE has no OWNER/REPO, which may be private without a token."
  (if (eq (remoto--auth forge) 'none)
      (user-error "Remoto: %s not found or private%s"
                  (remoto--repo-name owner repo) (remoto--login-tail))
    (user-error "%srepos/%s/%s" remoto--not-found owner repo)))

(defun remoto--or-private (forge owner repo thunk)
  "Call THUNK, and say so when FORGE has no OWNER/REPO for it.
A forge answers 404 for a private repository read without a token, so
the message names `remoto-login' then."
  (condition-case err
      (funcall thunk)
    (user-error
     ;; Only the repository's own endpoint: a missing ref is no private repository.
     (if (equal (cadr err) (format "%srepos/%s/%s" remoto--not-found owner repo))
         (remoto--not-found-or-private forge owner repo)
       (signal (car err) (cdr err))))))

(defun remoto--account-matches (name)
  "Return (/github: . LOGINS) when NAME is a bare /github:QUERY.
LOGINS are the accounts of the search that hold each word of QUERY.  A
line of the current Dired buffer is the account to open, no query.
Signal a `user-error' when no account matches."
  (when-let* ((parsed (remoto--parse name))
              ((eq (remoto-path-level parsed) 'root))
              (query (remoto--bare-name parsed))
              ((not (remoto--dired-line-p name))))
    (let* ((prefix (remoto--path-prefix parsed))
           (forge (remoto-path-forge parsed))
           (logins (seq-filter (lambda (login) (remoto--words-match-p query login))
                               (remoto-forge-complete
                                forge (remoto--path-at forge 'root) query t))))
      (dolist (login logins)
        (remoto--remember (concat prefix login)
                          `((type . "tree")
                            (note . ,(get-text-property 0 'remoto-acct-type login)))))
      (cons prefix
            (or (remoto--sorted-names prefix logins query)
                (user-error "Remoto: no account matches %s" query))))))

(defun remoto--repo-matches (name)
  "Return (DIR . NAMES) when NAME, a bare /github:OWNER/QUERY, is no repository.
NAMES are the owner's repositories that the search of completion finds
for QUERY; DIR is the owner's listing.  Signal a `user-error' when no
repository matches, or when OWNER is no account."
  (when-let* ((parts (remoto--bare-repo-parts name))
              (forge (remoto--canonical-forge name))
              ((not (remoto--repository-p forge (car parts) (cdr parts)))))
    (pcase-let* ((`(,owner . ,query) parts)
                 (dir (format "%s%s/" (remoto--prefix forge) owner))
                 (names (condition-case err
                            (remoto-forge-complete
                             forge (remoto--path-at forge 'owner owner) query t)
                          (user-error
                           (if (string-prefix-p remoto--not-found (cadr err))
                               (user-error "Remoto: no account %s" owner)
                             (signal (car err) (cdr err)))))))
      (cons dir
            (or (remoto--sorted-names dir names query)
                (if (eq (remoto--auth forge) 'none)
                    (remoto--not-found-or-private forge owner query)
                  (user-error "Remoto: no repository of %s matches %s"
                              owner query)))))))

(defun remoto--ref-matches (name)
  "Return (DIR . REFS) when NAME, a /github:OWNER/REPO@QUERY, is no ref.
REFS are the branches and tags that hold each word of QUERY, all of
them for an empty QUERY; DIR is /github:OWNER/REPO@.  Signal a
`user-error' when no ref matches."
  (when-let* ((parsed (remoto--parse name))
              ((eq (remoto-path-level parsed) 'refs))
              (owner (remoto-path-owner parsed))
              (repo (remoto-path-repo parsed))
              (query (string-remove-suffix "/" (remoto-path-query parsed)))
              (forge (remoto-path-forge parsed))
              ((not (remoto--ref-p forge owner repo query))))
    (let* ((dir (concat (remoto--repo-id forge owner repo) "@"))
           (groups (remoto-forge-refs forge owner repo))
           (refs (seq-filter (lambda (ref) (remoto--words-match-p query ref))
                             (seq-uniq (seq-mapcat #'cdr groups)))))
      (dolist (ref refs)
        (remoto--remember (concat dir ref)
                          `((type . "tree")
                            (note . ,(remoto--ref-label groups ref)))))
      (cons dir
            (or (remoto--sorted-names dir refs query)
                (user-error "Remoto: no branch or tag of %s%s"
                            (remoto--repo-name owner repo)
                            (if (string-empty-p query)
                                ""
                              (concat " matches " query))))))))

(defun remoto--file-matches (filename)
  "Return (DIR . NAMES) when the canonical FILENAME is missing from its tree.
NAMES are the entries of its directory DIR that hold each word of its
name, in the order of the Dired's ls options.  A name with a trailing
slash or a wildcard is no query; one that nothing matches is a new file."
  (when-let* ((parsed (remoto--parse-path filename))
              (path (remoto-path-path parsed))
              (name (file-name-nondirectory path))
              ((not (string-empty-p name)))
              ((not (string-match-p "[[*?]" name)))
              ((not (remoto--tree-entry parsed)))
              (dir (concat (remoto--file-name-prefix filename)
                           (or (file-name-directory path) "/")))
              (dir-parsed (remoto--parse-path dir))
              ((equal "tree" (alist-get 'type (remoto--tree-entry dir-parsed))))
              (names (mapcar #'car
                             (remoto--sort-entries
                              (seq-filter (lambda (child)
                                            (remoto--words-match-p name (car child)))
                                          (remoto--tree-children dir-parsed))
                              (or remoto--dired-switches dired-listing-switches)))))
    (cons dir names)))

(defun remoto--query-matches (filename)
  "Return (DIR . NAMES) when FILENAME is a short remoto name that names nothing.
The names are /github:QUERY, /github:OWNER/QUERY and
/github:OWNER/REPO@QUERY; NAMES are the accounts, repositories or refs
that match QUERY, for a Dired of DIR."
  (when-let* ((name (remoto--normalize-shorthand filename))
              ((remoto--canonical-forge name))
              ;; /github:OWNER/.. names no repository called "..".
              (name (if (remoto--dot-component-p name)
                        (remoto--normalize-name name)
                      name)))
    (or (remoto--account-matches name)
        (remoto--repo-matches name)
        (remoto--ref-matches name))))

(defun remoto--name-or-matches (filename)
  "Return what visiting FILENAME opens: the (DIR . NAMES) of matches or a name.
The matches are those of a name that names nothing.  Any other FILENAME
comes back as `remoto--maybe-rewrite' makes it.  A name that an `open'
forge splits into a repository is no query."
  (or (and (not (when-let* ((parsed (remoto--parse
                                     (remoto--normalize-shorthand filename))))
                  (remoto--split-open parsed)))
           (remoto--query-matches filename))
      (let ((name (remoto--maybe-rewrite filename)))
        (or (remoto--file-matches name) name))))

(defun remoto--get-authenticated-user (forge)
  "Return the login of the account of the token on FORGE, or nil.
Caches the result for the session.  Returns nil when auth has
failed or the API call errors."
  (let ((login (remoto--forge-login forge)))
    (or (remoto--login-user login)
        (unless (remoto--login-failed login)
          (condition-case nil
              (when-let* ((data (remoto--api forge "user"))
                          (user (alist-get 'login data)))
                (setf (remoto--login-user login) user))
            (user-error nil))))))

;;;; Rewriting what find-file and dired receive

(defun remoto--split-open (parsed)
  "Return the short tree PARSED names when its `open' forge splits it, else nil.
PARSED stays at the owner level until this asks `remoto-forge-split', from
its cache first and then with a wait; the forge keeps the answer, so
remoto keeps no cache of its own."
  (when-let* ((forge (remoto-path-forge parsed))
              ((eq (remoto-forge-locator forge) 'open))
              ((eq (remoto-path-level parsed) 'owner))
              (string (remoto-path-string parsed))
              (rest (substring string (length (remoto--prefix forge))))
              (names (split-string rest "/" t))
              (split (or (remoto-forge-split forge names)
                         (remoto-forge-split forge names t)))
              (name (concat (car split) (and (car split) "/") (cdr split)))
              ((string-prefix-p name rest))
              (tail (substring rest (length name)))
              ((or (string-empty-p tail) (string-prefix-p "/" tail))))
    (remoto--parse-tree forge string (car split) (cdr split) nil
                        (if (string-empty-p tail) "/" tail) t)))

(defun remoto--repo-root (parsed)
  "Return the `remoto-path' of the repository root that PARSED names, or nil.
That is a bare /PREFIX:OWNER/REPO, or REPO alone where the locator takes
one name, or either with @REF; its ref is nil for the default branch.  A
bare name of an `open' forge is one only as `remoto--split-open' finds it."
  (pcase (remoto-path-level parsed)
    ('root
     (when-let* ((name (remoto-path-query parsed))
                 ((string-match-p "\\`[^/]+\\'" name))
                 ((eql 1 (remoto--locator-count (remoto-path-forge parsed) (list name)))))
       (remoto-path-create :forge (remoto-path-forge parsed) :repo name
                           :ref nil :path "/")))
    ('owner
     (when-let* (((not (eq (remoto-forge-locator (remoto-path-forge parsed)) 'open)))
                 (repo (remoto--bare-name parsed)))
       (remoto-path-create :forge (remoto-path-forge parsed)
                           :owner (remoto-path-owner parsed) :repo repo
                           :ref nil :path "/")))
    ('refs
     (let ((ref (string-remove-suffix "/" (remoto-path-query parsed))))
       (unless (string-empty-p ref)
         (remoto-path-create :forge (remoto-path-forge parsed)
                             :owner (remoto-path-owner parsed)
                             :repo (remoto-path-repo parsed)
                             :ref ref :path "/"))))))

(defun remoto--maybe-rewrite (input)
  "If INPUT is a GitHub URL/shorthand, return canonical remoto path.
Also handles partial canonical paths like /github:OWNER/REPO and the
/gh: shorthand prefix.  Otherwise return INPUT unchanged.  The . and ..
components resolve first: a short form reads /github:OWNER/.. as a repo."
  (setq input (remoto--normalize-shorthand input))
  (when (and (remoto--canonical-forge input)
             (remoto--dot-component-p input))
    (setq input (remoto--normalize-name input)))
  (let* ((parsed (remoto--parse input))
         (parsed (and parsed (or (remoto--split-open parsed) parsed)))
         (root (and parsed (remoto--repo-root parsed))))
    (cond
     ;; Already a full canonical path
     ((remoto--parse-path input) input)
     ;; Files-default short form: /github:owner/repo/ or /github:owner/repo/path
     ((and parsed (eq (remoto-path-level parsed) 'tree))
      (let* ((owner (remoto-path-owner parsed))
             (repo (remoto-path-repo parsed))
             (subpath (substring (remoto-path-path parsed) 1))
             (repo-id (remoto--repo-id (remoto-path-forge parsed) owner repo))
             (branch (or (gethash repo-id remoto--default-branch-cache)
                         (let ((b (remoto-forge-default-ref
                                   (remoto-path-forge parsed) owner repo)))
                           (when b (puthash repo-id b remoto--default-branch-cache))
                           b))))
        ;; A source without refs answers nil: its tree takes no selector.
        (concat (remoto--repo-id (remoto-path-forge parsed) owner repo)
                (and branch "@") branch ":/" subpath)))
     ;; Partial canonical path: /github:owner/repo or /github:owner/repo@ref
     (root
      (remoto--canonical-path (remoto--resolve-ref root)))
     ;; A URL or remote of a repository; a topic URL names its root
     (t (if-let* ((url (remoto--parse-url input t))
                  ((remoto-path-repo url)))
            (remoto--canonical-path (remoto--resolve-ref url))
          input)))))

(defun remoto--dired-around-a (orig-fn dir-or-list &rest args)
  "Rewrite GitHub URLs and short remoto paths for Dired, then call ORIG-FN.
DIR-OR-LIST and ARGS go to ORIG-FN; a name that names nothing becomes the
list of the matching ones.  The advice sits on `dired-noselect', which
every Dired command calls, so each buffer gets a canonical directory."
  (if-let* ((raw (if (consp dir-or-list) (car dir-or-list) dir-or-list))
            ((stringp raw))
            (dir (remoto--normalize-shorthand raw))
            ((or (remoto--url-forge dir)
                 (remoto--canonical-forge dir))))
      (let ((remoto--may-ask t))
        (apply orig-fn
               (if (consp dir-or-list)
                   (cons (remoto--maybe-rewrite dir) (cdr dir-or-list))
                 (let ((remoto--dired-switches (car args)))
                   (remoto--name-or-matches dir)))
               args))
    (apply orig-fn dir-or-list args)))

(defun remoto--find-file-around-a (orig-fn filename &rest args)
  "Rewrite GitHub URLs to canonical remoto paths for `find-file'.
Intercepts #NUM patterns to display issues instead of file operations.
Call ORIG-FN with FILENAME and ARGS after any rewrite.  A name that names
nothing opens a Dired of the names that match it."
  (setq filename (remoto--normalize-shorthand filename))
  ;; A pull request or issue web URL is the topic, not the repository root
  ;; its canonical name would be.
  (when-let* ((url (remoto--url-shape filename))
              ((eq (remoto-path-level url) 'topics)))
    (setq filename (remoto--unparse url)))
  ;; Check for #NUM BEFORE rewrite (rewrite would mangle the # delimiter)
  (let ((remoto--may-ask t))
    (if-let* ((topic (remoto--topic-path filename)))
        (progn
          (remoto--require-topic)
          (remoto-topic-display (cdr topic) (car topic)))
      (let ((target (remoto--name-or-matches filename)))
        (if (consp target)
            (dired-noselect target)
          (apply orig-fn target args))))))

;;;; Eager auth warm-up

(defconst remoto--token-tags '("remoto" "forge" "ghub")
  "The package tags of the auth-source logins remoto reads, best first.
ghub keeps a token per package under the login ACCOUNT^PACKAGE; an
untagged login ranks after these, a login of another package not at all.")

(defun remoto--split-login (login)
  "Split the auth-source LOGIN, ACCOUNT^PACKAGE or ACCOUNT, into a list."
  (if-let* ((caret (and login (string-search "^" login))))
      (list (substring login 0 caret) (substring login (1+ caret)))
    (list login nil)))

(defun remoto--token-rank (row preferred)
  "Return the rank of the auth-source ROW as a token, lower first, or nil.
PREFERRED is the account git config names, or nil: its rows come first
among those of one tag."
  (pcase-let ((`(,account ,tag) (remoto--split-login (plist-get row :user))))
    (when-let* ((index (if tag
                           (seq-position remoto--token-tags tag)
                         (length remoto--token-tags))))
      (+ (* 2 index) (if (and preferred (equal account preferred)) 0 1)))))

(defun remoto--keychain-source-p (source)
  "Return non-nil when SOURCE, an entry of `auth-sources', is a macOS keychain.
macOS asks the user before a program reads an item another one saved,
such as the github.com item of git's credential helper."
  (let ((source (if (consp source) (plist-get source :source) source)))
    (cond ((symbolp source) (memq source '(macos-keychain-internet macos-keychain-generic)))
          ((stringp source) (string-prefix-p "macos-keychain-" source))
          ((consp source) (or (plist-member source :macos-keychain-internet)
                              (plist-member source :macos-keychain-generic))))))

(defun remoto--row-secret (row)
  "Return the secret of the auth-source ROW."
  (let ((secret (plist-get row :secret)))
    (if (functionp secret) (funcall secret) secret)))

(defun remoto--best-row (forge preferred)
  "Return the best row of `auth-sources' for FORGE whose token it did not refuse.
PREFERRED is the account git config names, as for `remoto--token-rank'."
  (let ((refused (remoto--login-refused (remoto--forge-login forge)))
        best best-rank)
    (dolist (host (delete-dups (list (remoto--api-host forge) (remoto-forge-host forge))))
      (dolist (row (auth-source-search :host host :max 100 :require '(:secret)))
        (when-let* ((rank (remoto--token-rank row preferred))
                    ((or (null best-rank) (< rank best-rank)))
                    ((not (member (remoto--row-secret row) refused))))
          (setq best row best-rank rank))))
    best))

(defun remoto--find-token (forge)
  "Search auth-source for a token of FORGE; return it or nil.
Every row under its API host or web host counts, ranked by
`remoto--token-rank'; git config only breaks ties.  A macOS keychain is
read last, when no other source holds a token."
  (let ((login (remoto--forge-login forge))
        (preferred (condition-case nil
                       (ghub--username (remoto-forge-host forge)
                                       (remoto--ghub-forge forge))
                     (error nil)))
        (keychains (seq-filter #'remoto--keychain-source-p auth-sources)))
    (condition-case err
        (when-let* ((best (or (let ((auth-sources (seq-difference auth-sources keychains)))
                                (remoto--best-row forge preferred))
                              ;; auth-source caches by search, not by source.
                              (and keychains
                                   (let ((auth-sources keychains)
                                         (auth-source-do-cache nil))
                                     (remoto--best-row forge preferred)))))
                    (token (remoto--row-secret best))
                    ((not (string-empty-p token))))
          (setf (remoto--login-account login)
                (car (remoto--split-login (plist-get best :user))))
          token)
      ;; A broken backend, say a .authinfo.gpg that does not decrypt, fails
      ;; on every later call too: say so once and leave the retry to
      ;; `remoto-reset-auth'.
      (error
       (setf (remoto--login-failed login) t)
       (message "Remoto: auth-source lookup failed (%s); \
using unauthenticated access until M-x remoto-reset-auth"
                (error-message-string err))
       nil))))

(defun remoto--warm-auth ()
  "Learn GitHub's token and its account once Emacs is idle.
An idle timer runs it, so a GPG passphrase prompt comes before the user
types.  It says who the token belongs to, or that GitHub refused it."
  (let ((login (remoto--forge-login remoto--github)))
    (unless (or (remoto--login-user login) (remoto--login-failed login))
      (when-let* ((token (remoto--auth remoto--github))
                  ((stringp token)))
        (condition-case err
            (when-let* ((data (let ((inhibit-message t))
                                (ghub-get "/user" nil
                                          :auth token
                                          :username (remoto--ghub-username
                                                     remoto--github token)
                                          :host (remoto--api-host remoto--github)
                                          :reader #'remoto--json-reader)))
                        (user (alist-get 'login data)))
              (setf (remoto--login-user login) user)
              (message "Remoto: authenticated as %s" user))
          (ghub-http-error
           (when (eql (cadr err) 401)
             (remoto--refuse-token remoto--github token)))
          ;; Anything else passes: the first request says what it is.
          (error nil))))))

(defvar remoto--warm-auth-timer nil
  "Pending idle timer for `remoto--warm-auth', or nil.
Held so turning `global-remoto-mode' off before the timer fires can
cancel it.")

;;;; Minor mode

(defvar remoto-command-map
  (let ((map (make-sparse-keymap)))
    (define-key map "u" #'remoto-copy-url)
    (define-key map "b" #'remoto-copy-blame-url)
    (define-key map "p" #'remoto-copy-permalink)
    (define-key map "r" #'remoto-copy-raw-url)
    (define-key map "h" #'remoto-copy-history-url)
    (define-key map "w" #'remoto-browse-url)
    map)
  "Keymap of remoto URL commands, meant to be bound to a prefix key.

Short mnemonic keys: `u' copy-url, `b' blame, `p' permalink, `r' raw,
`h' history, `w' browse.  It is intentionally bound to no key by
default, so it claims none of the user-reserved \\=`C-c LETTER\\=' space.
Bind it as a unit under a prefix of your choice, e.g.:

  (with-eval-after-load \\='remoto
    (keymap-set remoto-mode-map \"C-c g\" remoto-command-map))")
(defalias 'remoto-command-map remoto-command-map)

(defvar remoto-mode-map (make-sparse-keymap)
  "Keymap for `remoto-mode'.
Empty by default.  Populate it in your configuration, commonly by
binding the variable `remoto-command-map' to a prefix key.")

;;;###autoload
(define-minor-mode remoto-mode
  "Minor mode for buffers backed by a remoto virtual filesystem.

Offers forge-agnostic commands to copy or open the web URL of the file
or directory shown in the current buffer.  The commands work the same in
file buffers and in Dired, and adapt to the forge behind the path:
GitHub, Codeberg, or a server of `remoto-forgejo-instances'.

While `global-remoto-mode' is on, `remoto-mode' is enabled automatically
when visiting a remoto path.  Its keymap is empty by default; the
commands are grouped in the variable `remoto-command-map', which you can
bind to a prefix of your choosing."
  :lighter " Remoto"
  :keymap remoto-mode-map)

(defun remoto--maybe-enable-mode ()
  "Enable `remoto-mode' when the current buffer is a remoto buffer.
`global-remoto-mode' runs it from `find-file-hook' and `dired-mode-hook'."
  (let ((file (or buffer-file-name
                  (and (derived-mode-p 'dired-mode)
                       (if (listp dired-directory)
                           (car dired-directory)
                         dired-directory)))))
    (when (and (stringp file)
               (string-match-p remoto--handler-regexp file))
      (remoto-mode 1)
      (when-let* ((forge (remoto--buffer-forge)))
        (remoto--hint-login forge)))))

(defun remoto--get-prop (candidate prop)
  "Get text property PROP from CANDIDATE.
Searches from the end backwards, skipping trailing delimiters.
Handles candidates with prefix prepended by completion framework."
  (let ((len (length candidate)))
    (when (< 0 len)
      ;; Try near end (skip trailing / : characters which lack props)
      (or (and (< 1 len) (get-text-property (- len 2) prop candidate))
          (get-text-property (1- len) prop candidate)
          (get-text-property 0 prop candidate)))))

(defface remoto-annotation
  '((t :inherit completions-annotations))
  "Face for remoto completion annotations.")

(defvar remoto-annotation-width-step 10
  "Round annotation alignment width up to this step size.")

(defun remoto--affixate (items)
  "Format ITEMS as affixation triples with aligned suffixes.
ITEMS is a list of (candidate prefix suffix).
Uses display property for alignment (works in any completion UI)."
  (let* ((max-len (apply #'max 0 (mapcar (lambda (x) (length (car x))) items)))
         (align-to (* (ceiling (/ (float (+ max-len 4))
                                  remoto-annotation-width-step))
                      remoto-annotation-width-step)))
    (mapcar (lambda (x)
              (let* ((c (nth 0 x))
                     (prefix (nth 1 x))
                     (suffix (remoto--one-line (nth 2 x))))
                (list c prefix
                      (if (string-empty-p suffix) ""
                        (concat (propertize " " 'display
                                            `(space :align-to ,align-to))
                                (propertize suffix 'face 'remoto-annotation))))))
            items)))

(defun remoto--completion-metadata (directory)
  "Return completion metadata alist for DIRECTORY, or nil.
Provides group-function and affixation-function for @ and # modes."
  (pcase (remoto--directory-level directory)
    ;; Issues mode: /github:OWNER/REPO#
    ('topics
     (let ((group-fn (lambda (candidate transform)
                       (if transform candidate
                         (if (remoto--get-prop candidate 'remoto-topic-pr)
                             "Pull Request"
                           "Issue"))))
           (affix-fn (lambda (candidates)
                       (remoto--affixate
                        (mapcar (lambda (c)
                                  (let ((title (or (remoto--get-prop c 'remoto-topic-title) ""))
                                        (state (or (remoto--get-prop c 'remoto-topic-state) ""))
                                        (is-pr (remoto--get-prop c 'remoto-topic-pr)))
                                    (list c
                                          (if is-pr "PR " "   ")
                                          (format "%s [%s]" title state))))
                                candidates)))))
       ;; The candidates come pre-sorted (pull requests first, newest first);
       ;; without these two entries the UI re-sorts them by length or name.
       `((category . remoto-issue)
         (display-sort-function . identity)
         (cycle-sort-function . identity)
         (group-function . ,group-fn)
         (affixation-function . ,affix-fn))))
    ;; Branches/tags mode: /github:OWNER/REPO@
    ('refs
     (let ((group-fn (lambda (candidate transform)
                       (if transform candidate
                         (if (equal "tag" (remoto--get-prop candidate 'remoto-ref-type))
                             "Tag"
                           "Branch")))))
       `((category . remoto-branch)
         (group-function . ,group-fn))))
    ;; File mode: canonical path or files-default (owner/repo/ with optional subpath)
    ('tree
     (let ((affix-fn (lambda (candidates)
                       (remoto--affixate
                        (mapcar (lambda (c)
                                  (let ((msg (or (remoto--get-prop c 'remoto-file-commit) "")))
                                    (list c "" msg)))
                                candidates)))))
       `((category . remoto-file)
         (affixation-function . ,affix-fn))))
    ;; Owner mode: /github:OWNER/ - repo descriptions
    ('owner
     (let ((affix-fn (lambda (candidates)
                       (remoto--affixate
                        (mapcar (lambda (c)
                                  (let ((desc (or (remoto--get-prop c 'remoto-repo-desc) "")))
                                    (list c "" desc)))
                                candidates)))))
       `((category . remoto-repo)
         (affixation-function . ,affix-fn))))
    ;; Root mode: /github: - user/org type
    ('root
     (let ((affix-fn (lambda (candidates)
                       (remoto--affixate
                        (mapcar (lambda (c)
                                  (let* ((acct-type (or (remoto--get-prop c 'remoto-acct-type) ""))
                                         (desc (or (remoto--get-prop c 'remoto-acct-desc) ""))
                                         (suffix (cond
                                                  ((not (string-empty-p desc))
                                                   (format "%s  %s" acct-type desc))
                                                  (t acct-type))))
                                    (list c "" suffix)))
                                candidates)))))
       `((category . remoto-owner)
         (affixation-function . ,affix-fn))))))

(defun remoto--read-file-name-internal-a (orig string pred action)
  "Inject remoto completion metadata inside `read-file-name'.
Completion itself is delegated to ORIG so candidates stay relative to the
completion boundary.  Re-basing them to full paths makes frameworks like
Vertico prepend the directory twice (e.g. /github: + /github:owner ->
/github:/github:owner).  Only category/affixation metadata is added, for the
@ (branches/tags), # (issues), and owner/repo levels.  The /gh: shorthand is
already canonicalized by `substitute-in-file-name', so EFFECTIVE is /github:.
Args: ORIG, STRING, PRED, ACTION."
  (let ((effective (substitute-in-file-name string)))
    (if (not (and (eq action 'metadata) (remoto--canonical-forge effective)))
        (funcall orig string pred action)
      (let* ((dir (or (file-name-directory effective) ""))
             (extra (remoto--completion-metadata dir))
             (base (funcall orig string pred action))
             (base-alist (and (consp base) (eq (car base) 'metadata) (cdr base))))
        (if extra
            ;; Replace category so Marginalia doesn't override our annotations.
            ;; Use the per-level category from `remoto--completion-metadata' when
            ;; it provides one, else the generic `remoto'.
            (let ((cat (or (alist-get 'category extra) 'remoto)))
              (cons 'metadata (append (assq-delete-all 'category (copy-alist extra))
                                      `((category . ,cat))
                                      (assq-delete-all 'category (copy-alist base-alist)))))
          (or base (cons 'metadata nil)))))))

;;;; Inhibited functions

(defvar remoto--inhibited nil
  "Functions advised with `remoto--inhibit-a'.")

(defun remoto--buffer-p ()
  "Return non-nil in a remoto buffer."
  (string-match-p remoto--handler-regexp
                  (or buffer-file-name default-directory "")))

(defun remoto--inhibit-a (fn &rest args)
  "Call FN with ARGS outside remoto buffers."
  (unless (remoto--buffer-p)
    (apply fn args)))

(defun remoto--sync-inhibited (functions)
  "Advise exactly FUNCTIONS with `remoto--inhibit-a'."
  (dolist (f remoto--inhibited)
    (advice-remove f #'remoto--inhibit-a))
  (dolist (f functions)
    (advice-add f :around #'remoto--inhibit-a))
  (setq remoto--inhibited (copy-sequence functions)))

(defcustom remoto-inhibited-functions '(lsp eglot-ensure)
  "Functions that do nothing in remoto buffers, like LSP clients."
  :type '(repeat (symbol :tag "Function"))
  :set (lambda (symbol value)
         (set-default-toplevel-value symbol value)
         (when (bound-and-true-p global-remoto-mode)
           (remoto--sync-inhibited value)))
  :group 'remoto)

;;;; project.el

(defun remoto--project (dir)
  "Return the project of DIR, a directory in a repository tree, or nil.
The project is (remoto . ROOT), ROOT the /PREFIX:OWNER/REPO@REF:/ of the
tree.  A project found before the mode is on turns it on."
  ;; DIR can carry a completion candidate's text properties, and project.el
  ;; writes the root to `project-list-file'.
  (when-let* ((parsed (remoto--parse-path
                       (remoto--normalize-shorthand (substring-no-properties dir)))))
    (remoto--ensure-global-mode)
    (cons 'remoto (concat (remoto--tree-prefix parsed) "/"))))

(cl-defmethod project-root ((project (head remoto)))
  "Return the root of the remoto PROJECT."
  (cdr project))

(cl-defmethod project-name ((project (head remoto)))
  "Return OWNER/REPO@REF, the name of the remoto PROJECT."
  (string-remove-suffix ":/" (remoto--after-prefix (cdr project))))

(defvar remoto--every-file nil
  "Non-nil while a command runs that visits every file of its project.")

(defun remoto--refuse-every-file (project)
  "Signal a `user-error' when PROJECT is a remoto project."
  (when (eq (car-safe project) 'remoto)
    (user-error "Remoto: this visits every file of %s, a request each; search a clone"
                (project-name project))))

(defun remoto--every-file-a (function &rest args)
  "Run FUNCTION on ARGS unless its project is remoto's: it visits every file.
The current project is refused before the prompt, a project picked at the
prompt once FUNCTION asks for its files."
  (interactive (lambda (spec)
                 (remoto--refuse-every-file (project-current))
                 (advice-eval-interactive-spec spec)))
  (let ((remoto--every-file t))
    (apply function args)))

(cl-defmethod project-files ((project (head remoto)) &optional dirs)
  "Return the files of the remoto PROJECT under DIRS, its root by default.
The names are relative to the one directory asked for when
`project-files-relative-names' allows it, as project.el's own are."
  (when remoto--every-file
    (remoto--refuse-every-file project))
  (let ((dirs (or dirs (list (project-root project)))))
    (if (and (bound-and-true-p project-files-relative-names) (null (cdr dirs)))
        (remoto--tree-files (car dirs) t)
      (mapcan #'remoto--tree-files dirs))))

(defun remoto--tree-files (dir &optional relative)
  "Return the names of the files under DIR, a directory in a repository tree.
RELATIVE names them from DIR.  They come from the tree: the default
`project-files' runs find, and a repository has no local directory to
run it in."
  (when-let* ((parsed (remoto--parse-path
                       (remoto--normalize-shorthand (substring-no-properties dir)))))
    (let* ((tree (remoto--ensure-tree parsed))
           (key (remoto--tree-lookup-key (remoto-path-path parsed)))
           (under (if (string-empty-p key) "" (concat key "/")))
           (root (concat (remoto--tree-prefix parsed) "/"))
           (head (if relative "" (concat root under)))
           (files nil))
      (when (gethash "\0truncated" tree)
        (message "Remoto: the tree of %s is partial, and so is its file list" root))
      (maphash (lambda (path entry)
                 (when (and (not (string-prefix-p "\0" path))
                            (string-prefix-p under path)
                            (equal (alist-get 'type entry) "blob"))
                   (push (concat head (substring path (length under))) files)))
               tree)
      (sort files #'string<))))

(defun remoto--git (&rest args)
  "Return what git prints for ARGS in `default-directory', or nil if it fails."
  (with-temp-buffer
    (when (eq 0 (ignore-errors (apply #'process-file "git" nil '(t nil) nil args)))
      (string-remove-suffix "\n" (buffer-string)))))

(defun remoto--remote-parts (url)
  "Return (SCHEME HOST OWNER REPO) of the git remote URL, or nil.
SCHEME is nil for the scp form, USER@HOST:OWNER/REPO."
  (when (and (stringp url)
             (string-match
              (rx bos (or (seq (group-n 1 (+ (in "a-z+"))) "://"
                               (? (* (not (in "@/"))) "@")
                               (group-n 2 (+ (not (in "/:"))))
                               (? ":" (* digit)) (+ "/"))
                          (seq (? (* (not (in "@/"))) "@")
                               (group-n 2 (+ (not (in "/:")))) ":" (? "/")))
                  (group-n 3 (+ (not "/"))) "/"
                  (group-n 4 (+? (not (in "/?#")))) (? ".git") (* "/") eos)
              url))
    (mapcar (lambda (group) (match-string group url)) '(1 2 3 4))))

(defun remoto--remote-path (forge url)
  "Return the root `remoto-path' of the git remote URL on FORGE, or nil.
URL names FORGE when its host is the host of FORGE."
  (pcase (remoto--remote-parts url)
    (`(,_ ,host ,owner ,repo)
     (when (string-equal-ignore-case host (remoto-forge-host forge))
       (remoto-path-create :forge forge :owner owner :repo repo
                           :level 'tree :path "/")))))

(defun remoto--ssh-hostname (host)
  "Return the name that ssh connects to for HOST, which may be an alias."
  (with-temp-buffer
    (when (eq 0 (ignore-errors (process-file "ssh" nil '(t nil) nil "-G" host)))
      (goto-char (point-min))
      (and (re-search-forward "^hostname \\(.+\\)$" nil t)
           (match-string 1)))))

(defun remoto--remote-repo (url)
  "Return the root of the repository that the git remote URL names, or nil.
The root is a `remoto-path'.  An ssh host that is no forge's can be an
alias of the ssh configuration, which ssh -G resolves."
  (or (when-let* ((root (remoto--parse-url url t))
                  ((remoto-path-repo root)))
        root)
      (pcase (remoto--remote-parts url)
        (`(,scheme ,host ,owner ,repo)
         (when-let* (((not (member scheme '("http" "https"))))
                     (name (remoto--ssh-hostname host)))
           (remoto--parse-url (format "git@%s:%s/%s" name owner repo) t))))))

(defun remoto--git-remotes ()
  "Return (NAME . URL) for each remote of the repository, as git lists them."
  (seq-uniq
   (seq-keep (lambda (line)
               (and (string-match "\\`\\([^\t]+\\)\t\\(.+\\) (fetch)\\'" line)
                    (cons (match-string 1 line) (match-string 2 line))))
             (split-string (or (remoto--git "remote" "-v") "") "\n" t))))

(defun remoto--git-upstream (branch)
  "Return (REMOTE REMOTE-BRANCH) that BRANCH tracks, or nil.
REMOTE-BRANCH is nil once its remote-tracking branch is gone."
  (when-let* ((line (remoto--git "for-each-ref"
                                 "--format=%(upstream:remotename)%09%(upstream:remoteref)%09%(upstream:track)"
                                 (concat "refs/heads/" branch)))
              (fields (split-string line "\t"))
              ((not (string-empty-p (car fields)))))
    (list (car fields)
          (and (not (equal (nth 2 fields) "[gone]"))
               (string-prefix-p "refs/heads/" (nth 1 fields))
               (string-remove-prefix "refs/heads/" (nth 1 fields))))))

(defun remoto--read-remote (remotes default)
  "Ask for one of REMOTES, (NAME . ROOT) pairs; DEFAULT names the one offered."
  (let* ((width (apply #'max (mapcar (lambda (remote) (length (car remote))) remotes)))
         (completion-extra-properties
          (list :annotation-function
                (lambda (name)
                  (concat (make-string (- (1+ width) (length name)) ?\s)
                          (remoto--canonical-path (cdr (assoc name remotes))))))))
    (assoc (completing-read (format-prompt "Remote" default) remotes nil t nil nil default)
           remotes)))

(defun remoto--forge-directory (pick)
  "Return the remoto directory of `default-directory', a directory of a clone.
The remote is the one the branch tracks; PICK, or several remotes and
none tracked, asks for it.  The ref is the tracked branch, else the
branch's own name when the remote has it, else the default branch."
  (let* ((prefix (or (remoto--git "rev-parse" "--show-prefix")
                     (user-error "Remoto: %s is not in a git repository"
                                 (abbreviate-file-name default-directory))))
         (remotes (or (remoto--git-remotes)
                      (user-error "Remoto: this repository has no remote")))
         (served (or (seq-keep (lambda (remote)
                                 (when-let* ((root (remoto--remote-repo (cdr remote))))
                                   (cons (car remote) root)))
                               remotes)
                     (user-error "Remoto: no remote is on a forge remoto serves: %s"
                                 (mapconcat (lambda (remote) (concat (car remote) " " (cdr remote)))
                                            remotes ", "))))
         (branch (remoto--git "symbolic-ref" "--quiet" "--short" "HEAD"))
         (upstream (and branch (remoto--git-upstream branch)))
         (tracked (assoc (car upstream) served))
         (remote (if (or pick (and (not tracked) (cdr served)))
                     (remoto--read-remote served (car (or tracked (assoc "origin" served)
                                                          (car served))))
                   (or tracked (car served))))
         (root (cdr remote)))
    (setf (remoto-path-ref root)
          (cond ((eq remote tracked) (nth 1 upstream))
                ((and branch (remoto--git "show-ref" "--verify" "--quiet"
                                          (format "refs/remotes/%s/%s" (car remote) branch)))
                 branch)))
    (concat (remoto--tree-prefix root) "/" prefix)))

;;;###autoload
(defun remoto-project-find-file (&optional pick)
  "Find a file in the forge copy of this clone, starting from this directory.
The prompt is on the remote the branch tracks, at that branch when the
remote has it, else at its default branch.  PICK, a prefix argument, or
several remotes and none tracked, asks for the remote."
  (interactive "P")
  (let ((default-directory (if (string-match-p remoto--handler-regexp default-directory)
                               default-directory
                             (remoto--forge-directory pick)))
        (command (key-binding (kbd "C-x C-f"))))
    (remoto--ensure-global-mode)
    (call-interactively (if (commandp command) command #'find-file))))

;;;; Global mode

(defun remoto--drop-autoload-handler ()
  "Remove the bootstrap entry of the autoloads from `file-name-handler-alist'."
  (setq file-name-handler-alist
        (rassq-delete-all #'remoto-autoload-file-name-handler
                          file-name-handler-alist)))

(defun remoto--install ()
  "Install the handler, the advice, the hooks and the auth warm-up timer.
Each step is idempotent, so a second call while on is a no-op."
  ;; The real handler takes over from the bootstrap entry; left behind, that
  ;; entry would catch the operations the real handler passes down.
  (remoto--drop-autoload-handler)
  (unless (equal (cdr (assoc remoto--handler-regexp file-name-handler-alist))
                 #'remoto-file-name-handler)
    (push (cons remoto--handler-regexp #'remoto-file-name-handler)
          file-name-handler-alist))
  (remoto--refresh-tramp-ignored)
  (advice-add 'dired-noselect :around #'remoto--dired-around-a)
  (advice-add 'find-file-noselect :around #'remoto--find-file-around-a)
  (advice-add 'read-file-name-internal :around
              #'remoto--read-file-name-internal-a)
  (advice-add 'project-search :around #'remoto--every-file-a)
  (advice-add 'project-query-replace-regexp :around #'remoto--every-file-a)
  (remoto--sync-inhibited remoto-inhibited-functions)
  (add-hook 'find-file-hook #'remoto--maybe-enable-mode)
  (add-hook 'dired-mode-hook #'remoto--maybe-enable-mode)
  ;; Clear the fetch indicator and reset in-flight state whenever a
  ;; minibuffer exits.
  (add-hook 'minibuffer-exit-hook #'remoto--minibuffer-exit-cleanup)
  (unless (timerp remoto--warm-auth-timer)
    (setq remoto--warm-auth-timer
          (run-with-idle-timer 2 nil #'remoto--warm-auth))))

(defun remoto--uninstall ()
  "Remove the handler, the advice, the hooks and the auth warm-up timer."
  (setq file-name-handler-alist
        (assoc-delete-all remoto--handler-regexp file-name-handler-alist))
  (remoto--restore-tramp-ignored)
  (advice-remove 'dired-noselect #'remoto--dired-around-a)
  (advice-remove 'find-file-noselect #'remoto--find-file-around-a)
  (advice-remove 'read-file-name-internal #'remoto--read-file-name-internal-a)
  (advice-remove 'project-search #'remoto--every-file-a)
  (advice-remove 'project-query-replace-regexp #'remoto--every-file-a)
  (remoto--sync-inhibited nil)
  (remove-hook 'find-file-hook #'remoto--maybe-enable-mode)
  (remove-hook 'dired-mode-hook #'remoto--maybe-enable-mode)
  (remove-hook 'minibuffer-exit-hook #'remoto--minibuffer-exit-cleanup)
  (when (timerp remoto--warm-auth-timer)
    (cancel-timer remoto--warm-auth-timer))
  (setq remoto--warm-auth-timer nil))

;;;###autoload
(define-minor-mode global-remoto-mode
  "Toggle remoto's virtual filesystem for the repositories of forges.

When on, the paths of every forge, such as `/github:OWNER/REPO...',
`/gh:...' and `/cb:...', work in `find-file', `dired', and every other
file operation, forge URLs typed at those prompts are rewritten to
remoto paths, `find-file' completion inside a remoto path shows remoto's
annotations, `remoto-mode' turns on in remoto buffers, and a GitHub
token is looked up once Emacs is idle.  When off, all of that is
removed again.

Loading remoto does not turn this mode on.  Enable it in your init file,
or let the first use do it: `remoto-browse', the Embark open actions,
and a path of a forge that comes with remoto at any file prompt all turn
it on."
  :global t
  :group 'remoto
  (if global-remoto-mode
      (remoto--install)
    (remoto--uninstall)))

(defun remoto--ensure-global-mode ()
  "Turn on `global-remoto-mode' when it is off, and say so.
For remoto's own entry points: the buffers they open need the
file-name handler for as long as they live, so the mode has to stay on."
  (unless global-remoto-mode
    (global-remoto-mode 1)
    (message "Remoto: `global-remoto-mode' enabled")))

(defun remoto--take-over (operation args)
  "Turn on `global-remoto-mode' for the first remoto path, then run OPERATION.
ARGS are its arguments.  The advice of `remoto--install' arrives while this
call runs, so the rewrite it would give `expand-file-name', which
`find-file-noselect' asks first, happens here."
  (remoto--drop-autoload-handler)
  (remoto--ensure-global-mode)
  (when (and (eq operation 'expand-file-name) (stringp (car args)))
    (setcar args (remoto--maybe-rewrite (car args))))
  (apply operation args))

;; The definition itself goes into the autoloads: answering `file-remote-p'
;; must not load remoto, since project.el and recentf ask it of every name
;; they keep.  Before remoto loads no repository is reached, so a connected
;; answer is nil, as `remoto--handle-file-remote-p' gives.
;;;###autoload
(progn
  (defun remoto-autoload-file-name-handler (operation &rest args)
    "Load remoto for a path of a forge that comes with it, then run OPERATION.
ARGS are the arguments of OPERATION.  The package autoloads register this
handler, so such a path works before remoto loads, as a remote path loads
TRAMP; `file-remote-p' of a canonical name is answered without loading."
    (if-let* (((eq operation 'file-remote-p))
              ((not (featurep 'remoto)))
              (name (car args))
              ((stringp name))
              ((null (nth 1 args)))
              ((string-match-p "\\`/\\(?:github\\|codeberg\\):" name)))
        (and (memq (nth 2 args) '(nil never))
             (save-match-data
               (if (string-match
                    "\\`\\(/[^/:]+:[^/]+/[^/:@#]+\\)\\(?:@\\([^:]+\\)\\|@\\)?:" name)
                   (concat (match-string 1 name)
                           (and (match-beginning 2) (concat "@" (match-string 2 name)))
                           ":")
                 (substring name 0 (1+ (string-search ":" name))))))
      (require 'remoto)
      (remoto--take-over operation args))))

;;;; Issue display (see remoto-topic.el for full implementation)

(declare-function remoto-topic-display "remoto-topic" (number repo-path))

(defun remoto--require-topic ()
  "Load remoto-topic if not already loaded.
Adds the package directory to `load-path' if needed."
  (unless (featurep 'remoto-topic)
    (when-let* ((dir (file-name-directory
                      (or load-file-name
                          (locate-library "remoto")
                          buffer-file-name))))
      (add-to-list 'load-path dir))
    (require 'remoto-topic)))

;;;; remoto-browse

(defcustom remoto-default-forge 'github
  "Name of the registered forge that a bare OWNER/REPO in `remoto-browse' names.
An input with a prefix, such as /cb:OWNER/REPO, or a URL names its own forge."
  :type 'symbol
  :group 'remoto)

(defvar remoto--browse-history nil
  "Minibuffer history for `remoto-browse'.")

(defun remoto--default-forge ()
  "Return the forge that `remoto-default-forge' names."
  (or (remoto--forge-named remoto-default-forge)
      (user-error "Remoto: remoto-default-forge names no registered forge: %s"
                  remoto-default-forge)))

(defun remoto--browse-split (input)
  "Return (FORGE HEAD . REST) for INPUT, the text read by `remoto-browse'.
HEAD is the prefix INPUT starts with, such as /cb:, or \"\"; REST is the
text after HEAD.  A URL or remote names its own forge, with a nil REST."
  (if-let* ((entry (remoto--prefix-of input)))
      (let ((head (concat "/" (car entry) ":")))
        (cons (cdr entry) (cons head (substring input (length head)))))
    (if-let* ((forge (remoto--url-forge input)))
        (list forge "")
      (cons (remoto--default-forge) (cons "" input)))))

(defun remoto--browse-parse-input (string)
  "Parse STRING, a name after its prefix, into (MODE OWNER REPO QUERY).
MODE is one of `search', `branches', `issues' or `files'.  OWNER and REPO
are non-nil for the @, # and / modes.  QUERY is the text after the delimiter."
  (if (string-match (rx bos (group (+ (not (in "/@#"))))
                        "/" (group (+ (not (in "/@#"))))
                        (group (in "#@/")) (group (* anything)) eos)
                    string)
      (list (alist-get (aref (match-string 3 string) 0)
                       '((?# . issues) (?@ . branches) (?/ . files)))
            (match-string 1 string) (match-string 2 string) (match-string 4 string))
    (list 'search nil nil string)))

(defun remoto--qualify-repos (owner names)
  "Return each bare repository name of NAMES as OWNER/NAME, with its properties.
The `remoto-repo-desc' property of a name annotates its candidate."
  (mapcar (lambda (name)
            (apply #'propertize (concat owner "/" name)
                   (text-properties-at 0 name)))
          names))

(cl-defgeneric remoto--browse-repos (forge query)
  "Return the OWNER/REPO candidates of FORGE for QUERY, never blocking.
An OWNER/TEXT QUERY lists the repositories of OWNER and a plain one the
accounts, as `remoto-forge-complete' answers them; an account ends in /."
  (let ((slash (string-search "/" query)))
    (cond
     ((null slash)
      (unless (string-empty-p query)
        (mapcar (lambda (login) (concat login "/"))
                (remoto-forge-complete forge (remoto--path-at forge 'root) query nil))))
     ((< 0 slash)
      (let ((owner (substring query 0 slash)))
        (remoto--qualify-repos
         owner (remoto-forge-complete forge (remoto--path-at forge 'owner owner)
                                      (substring query (1+ slash)) nil)))))))

(defun remoto--browse-topics (forge owner repo query)
  "Return the topics of OWNER/REPO on FORGE to complete QUERY with.
A topic key QUERY gives that topic and the open ones, any other text a
search.  The symbol t means input arrived and interrupted the fetch."
  (cond
   ((string-empty-p query)
    (while-no-input (remoto-forge-topics forge owner repo nil)))
   ((remoto--topic-key-p forge query)
    (let* ((cached (while-no-input (remoto-forge-topics forge owner repo nil)))
           (direct (while-no-input (remoto-forge-topic forge owner repo query)))
           (results (and (listp cached) cached)))
      (if (consp direct)
          (cl-remove-duplicates (cons direct results)
                                :key (lambda (topic) (alist-get 'key topic))
                                :test #'equal)
        results)))
   (t (while-no-input (remoto-forge-topics forge owner repo query)))))

(defun remoto--browse-topic-candidates (forge head owner repo query)
  "Return the # candidates of OWNER/REPO on FORGE for QUERY, after HEAD.
Pull requests come first, then the keys from the newest."
  (let* ((prefix (concat head (remoto--repo-name owner repo) "#"))
         (topics (remoto--browse-topics forge owner repo query))
         (key-of (lambda (candidate) (substring candidate (length prefix)))))
    (when (listp topics)
      (sort (mapcar (lambda (topic)
                      (let ((key (alist-get 'key topic)))
                        (propertize (concat prefix key)
                                    'remoto-topic-pr (equal "pr" (alist-get 'kind topic))
                                    'remoto-topic-title (or (alist-get 'title topic) "")
                                    'remoto-topic-state (or (alist-get 'state topic) "")
                                    'remoto-target (concat (remoto--repo-id forge owner repo)
                                                           "#" key))))
                    topics)
            (lambda (a b)
              (let ((a-pr (get-text-property 0 'remoto-topic-pr a))
                    (b-pr (get-text-property 0 'remoto-topic-pr b)))
                (if (eq (not a-pr) (not b-pr))
                    (remoto--topic-key< (funcall key-of b) (funcall key-of a))
                  a-pr)))))))

(defun remoto--browse-ref-candidates (forge head owner repo query)
  "Return the @ candidates of OWNER/REPO on FORGE that start with QUERY.
Each candidate follows HEAD and carries the label of its ref."
  (let ((prefix (concat head (remoto--repo-name owner repo) "@"))
        (groups (while-no-input (remoto-forge-refs forge owner repo))))
    (when (listp groups)
      (seq-mapcat (lambda (group)
                    (mapcar (lambda (ref)
                              (propertize (concat prefix ref)
                                          'remoto-ref-type (car group)
                                          'remoto-target
                                          (concat (remoto--repo-id forge owner repo)
                                                  "@" ref ":/")))
                            (seq-filter (lambda (ref) (string-prefix-p query ref))
                                        (cdr group))))
                  groups))))

(defun remoto--browse-file-candidates (forge head owner repo query)
  "Return the / candidates of OWNER/REPO on FORGE for QUERY, after HEAD.
QUERY is a path from the root of the default ref; its last segment
filters the entries of its directory."
  (let ((ref (while-no-input (remoto-forge-default-ref forge owner repo))))
    (when (stringp ref)
      (let* ((subpath (or (file-name-directory query) ""))
             (file-part (file-name-nondirectory query))
             (children (while-no-input
                         (remoto-forge-children forge owner repo ref subpath)))
             (names (when (listp children)
                      (mapcar (lambda (child)
                                (let ((name (if (equal "tree" (alist-get 'type (cdr child)))
                                                (concat (car child) "/")
                                              (car child))))
                                  (propertize (concat head (remoto--repo-name owner repo)
                                                      "/" subpath name)
                                              'remoto-target
                                              (concat (remoto--repo-id forge owner repo)
                                                      "@" ref ":/" subpath name))))
                              children))))
        (if (string-empty-p file-part)
            names
          (seq-filter (lambda (name) (string-search file-part name)) names))))))

(defun remoto--browse-completions (string)
  "Return completion candidates for STRING in `remoto-browse'.
The forge that STRING names answers them through the forge contract;
a URL completes to nothing, and so does a forge without the data."
  (pcase-let ((`(,forge ,head . ,rest) (remoto--browse-split string)))
    (when rest
      (pcase-let ((`(,mode ,owner ,repo ,query) (remoto--browse-parse-input rest)))
        (condition-case nil
            (pcase mode
              ('issues (remoto--browse-topic-candidates forge head owner repo query))
              ('branches (remoto--browse-ref-candidates forge head owner repo query))
              ('files (remoto--browse-file-candidates forge head owner repo query))
              ('search
               (mapcar (lambda (cand)
                         (let* ((name (substring-no-properties cand))
                                (c (apply #'propertize (concat head name)
                                          (text-properties-at 0 cand))))
                           (put-text-property 0 (length c) 'remoto-target
                                              (concat (remoto--prefix forge) name
                                                      (unless (string-suffix-p "/" name)
                                                        ":/"))
                                              c)
                           c))
                       (remoto--browse-repos forge query))))
          (remoto-unsupported nil))))))

(defun remoto--browse-metadata (string)
  "Return completion metadata alist for STRING in `remoto-browse'."
  (pcase (when-let* ((rest (cddr (remoto--browse-split string))))
           (car (remoto--browse-parse-input rest)))
    ('issues
     (let ((group-fn (lambda (candidate transform)
                       (if transform candidate
                         (if (get-text-property 0 'remoto-topic-pr candidate)
                             "Pull Request"
                           "Issue"))))
           (affix-fn (lambda (candidates)
                       (remoto--affixate
                        (mapcar (lambda (c)
                                  (let ((title (or (get-text-property 0 'remoto-topic-title c) ""))
                                        (state (or (get-text-property 0 'remoto-topic-state c) ""))
                                        (is-pr (get-text-property 0 'remoto-topic-pr c)))
                                    (list c
                                          (if is-pr "PR " "   ")
                                          (format "%s [%s]" title state))))
                                candidates)))))
       `(metadata (category . remoto-browse)
                  (group-function . ,group-fn)
                  (affixation-function . ,affix-fn))))
    ('branches
     (let ((group-fn (lambda (candidate transform)
                       (if transform candidate
                         (capitalize (or (get-text-property 0 'remoto-ref-type candidate)
                                         "branch"))))))
       `(metadata (category . remoto-browse)
                  (group-function . ,group-fn))))
    ('search
     (let ((affix-fn (lambda (candidates)
                       (remoto--affixate
                        (mapcar (lambda (c)
                                  (let ((desc (or (get-text-property 0 'remoto-repo-desc c) "")))
                                    (list c "" desc)))
                                candidates)))))
       `(metadata (category . remoto-browse)
                  (affixation-function . ,affix-fn))))
    (_ '(metadata (category . remoto-browse)))))

(defun remoto--repo-completion-table (string pred action)
  "Programmed completion table for the repositories, refs and topics of forges.
STRING is the minibuffer input, PRED a filter predicate and ACTION the
action of `completing-read'.  Styles that filter by `completion-regexp-list'
pass an empty STRING, so the minibuffer supplies the input then."
  (cond
   ((eq action 'metadata) (remoto--browse-metadata string))
   ((eq (car-safe action) 'boundaries) nil)
   (t (let ((input (if (string-empty-p string)
                       (or (remoto--minibuffer-input) string)
                     string)))
        (complete-with-action action (remoto--browse-completions input)
                              string pred)))))

(defun remoto--read-repo ()
  "Read a repository from the minibuffer with search completion.
Type 3+ characters to search, @ to complete refs, # to browse topics.
A prefix such as /cb: picks the forge; URLs can be typed directly."
  (completing-read (format "%s repo: " (remoto-forge-title (remoto--default-forge)))
                   #'remoto--repo-completion-table
                   nil nil nil
                   'remoto--browse-history))

;;;###autoload
(defun remoto-browse (input)
  "Browse a repository of a forge without cloning.
INPUT is a URL, a git remote, /PREFIX:OWNER/REPO or OWNER/REPO of
`remoto-default-forge', with #KEY for a topic or @REF for a ref.
Turn on `global-remoto-mode' when it is off: the buffers need it."
  (interactive (progn (remoto--ensure-global-mode)
                      (list (remoto--read-repo))))
  (remoto--ensure-global-mode)
  (let ((remoto--may-ask t))
    (remoto--browse-input input)))

(defun remoto--browse-tree (parsed)
  "Open the tree PARSED names, in Dired or as a file.
A PARSED without a ref opens on the default ref."
  (let* ((resolved (remoto--or-private
                    (remoto-path-forge parsed) (remoto-path-owner parsed)
                    (remoto-path-repo parsed)
                    (lambda () (remoto--resolve-ref parsed))))
         (canonical (remoto--canonical-path resolved)))
    (if (equal "tree" (alist-get 'type (remoto--tree-entry resolved)))
        (dired canonical)
      (find-file canonical))))

(defun remoto--browse-topic (forge owner repo key)
  "Open the topic KEY of OWNER/REPO on FORGE."
  (remoto--require-topic)
  (remoto-topic-display key (remoto--repo-id forge owner repo)))

(defun remoto--browse-url-path (parsed)
  "Open PARSED, the `remoto-path' of a URL: a topic, a tree or a listing."
  (pcase (remoto-path-level parsed)
    ('topics (remoto--browse-topic (remoto-path-forge parsed) (remoto-path-owner parsed)
                                   (remoto-path-repo parsed) (remoto-path-query parsed)))
    ('tree (remoto--browse-tree parsed))
    (_ (dired (remoto--unparse parsed)))))

(defun remoto--browse-name (forge input rest)
  "Open REST, the name of INPUT on FORGE after its prefix, if it has one.
A canonical path opens as it is; OWNER/REPO opens on its default ref."
  (pcase-let ((canonical (remoto--parse-path (remoto--normalize-shorthand input)))
              (`(,mode ,owner ,repo ,query) (remoto--browse-parse-input rest))
              (name (string-trim rest)))
    (cond
     (canonical (remoto--browse-tree canonical))
     ((and (eq mode 'issues) (remoto--topic-key-p forge query))
      (remoto--browse-topic forge owner repo query))
     ((eq mode 'files)
      (let* ((short (concat (remoto--repo-id forge owner repo) "/" query))
             (path (remoto--or-private
                    forge owner repo (lambda () (remoto--maybe-rewrite short))))
             (parsed (remoto--parse-path path)))
        (if (and parsed (equal "tree" (alist-get 'type (remoto--tree-entry parsed))))
            (dired path)
          (find-file path))))
     ((string-match remoto--shorthand-regexp name)
      (remoto--browse-tree
       (remoto-path-create :forge forge :owner (match-string 1 name)
                           :repo (match-string 2 name) :ref (match-string 3 name)
                           :level 'tree :path "/")))
     (t (user-error "Remoto: cannot parse input: %s" (string-trim input))))))

(defun remoto--browse-input (input)
  "Open INPUT, a name `remoto-browse' read, as a topic, file or tree."
  (pcase-let ((`(,forge ,_head . ,rest) (remoto--browse-split input)))
    (remoto--with-fetch-indicator
      (if rest
          (remoto--browse-name forge input rest)
        (remoto--browse-url-path (remoto--parse-url input))))))

;;;; Unload

(defun remoto-unload-function ()
  "Turn `global-remoto-mode' off and drop the caches.
The bootstrap entry of the autoloads goes too: it is still there when
remoto was loaded some other way and the mode never turned on."
  (when global-remoto-mode
    (global-remoto-mode -1))
  (remoto--drop-autoload-handler)
  (clrhash remoto--tree-cache)
  (clrhash remoto--default-branch-cache)
  (clrhash remoto--search-cache)
  (clrhash remoto--listing-cache)
  (clrhash remoto--entry-cache)
  (clrhash remoto--pending-requests)
  (clrhash remoto--logins)
  (dolist (forge (seq-uniq (mapcar #'cdr remoto--forges)))
    (remoto-forge-forget forge))
  nil)

(provide 'remoto)

;; The forges that come with remoto load after the core they extend, as
;; magit's own libraries do; each registers itself when loaded.  They load
;; from this file's directory: an upgrade by package.el reloads this file
;; before that directory is on `load-path'.
(require 'remoto-github
         (expand-file-name "remoto-github" (file-name-directory (macroexp-file-name))))
(require 'remoto-forgejo
         (expand-file-name "remoto-forgejo" (file-name-directory (macroexp-file-name))))

;;; remoto.el ends here
