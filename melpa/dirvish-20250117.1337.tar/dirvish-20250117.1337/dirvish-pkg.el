;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250117.1337"
  "A modern file manager based on dired mode."
  '((emacs     "27.1")
    (transient "0.3.7"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "3b9ef89119db491963411e539259dbe4ff3cc429"
  :revdesc "3b9ef89119db"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
