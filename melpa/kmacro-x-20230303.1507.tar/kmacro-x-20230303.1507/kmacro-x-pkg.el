(define-package "kmacro-x" "20230303.1507" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "dd8083f5280eb7d2490626a027424ae8b077b01a" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
