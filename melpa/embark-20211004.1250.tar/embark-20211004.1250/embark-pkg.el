(define-package "embark" "20211004.1250" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "98121bacef39abaf6f6849f87a439ba2184c03e2" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
