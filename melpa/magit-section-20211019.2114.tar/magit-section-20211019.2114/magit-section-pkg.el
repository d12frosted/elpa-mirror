(define-package "magit-section" "20211019.2114" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "28f0c1918723dd0bf3a7eb211993875077a739d5" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
