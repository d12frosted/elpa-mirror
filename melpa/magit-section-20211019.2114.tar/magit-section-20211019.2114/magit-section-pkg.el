(define-package "magit-section" "20211019.2114" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "a121f3408940237253341ec755be2204f5fa1582" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
