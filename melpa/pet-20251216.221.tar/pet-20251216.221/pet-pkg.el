;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pet" "20251216.221"
  "Executable and virtualenv tracker for python-mode."
  '((emacs "27.1")
    (f     "0.6.0")
    (map   "3.3.1")
    (seq   "2.24"))
  :url "https://github.com/wyuenho/emacs-pet/"
  :commit "99dfde30b7febc8b691f5562ca2f908369d0b836"
  :revdesc "99dfde30b7fe"
  :keywords '("tools")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
