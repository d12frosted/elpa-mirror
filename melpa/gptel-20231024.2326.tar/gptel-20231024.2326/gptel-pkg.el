(define-package "gptel" "20231024.2326" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "644fc1de2f1934f2db1e448de1edae065e848b77" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
