(define-package "geiser-chez" "20221015.233" "Chez and Geiser talk to each other"
  '((emacs "26.1")
    (geiser "0.19"))
  :commit "e0e651c29daa86fefe5125c6d5256cc0bdbcc03d" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chez" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chez")
;; Local Variables:
;; no-byte-compile: t
;; End:
