;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20261025.1905"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "6a400a34a095a9dd359b9b10e7598313e7c92e86"
  :revdesc "6a400a34a095"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
