;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chroma" "20240716.1131"
  "Color manipulation library."
  '((emacs "24.1"))
  :url "https://github.com/galdor/chroma"
  :commit "89324b476498bdfc657079040cfbbe33d1da48a3"
  :revdesc "89324b476498"
  :authors '(("Nicolas Martyanoff" . "nicolas@n16f.net"))
  :maintainers '(("Nicolas Martyanoff" . "nicolas@n16f.net")))
