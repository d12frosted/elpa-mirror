;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260315.1748"
  "Highlight by brightness of text and background."
  '((emacs "25.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "4b0e0c42ca343051fd2924b32a47b8c9179432a8"
  :revdesc "4b0e0c42ca34"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
