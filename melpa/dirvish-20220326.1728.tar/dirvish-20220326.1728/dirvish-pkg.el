(define-package "dirvish" "20220326.1728" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "8207cd48ab1910f4edcf1571045e6375209004aa" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
