(define-package "org-zettelkasten" "20240716.1428" "A Zettelkasten mode leveraging Org"
  '((emacs "25.1")
    (org "9.3"))
  :commit "5b476c4df803b78691dc4a7166d78d5b2d93afef" :authors
  '(("Yann Herklotz" . "git@yannherklotz.com"))
  :maintainers
  '(("Yann Herklotz" . "git@yannherklotz.com"))
  :maintainer
  '("Yann Herklotz" . "git@yannherklotz.com")
  :keywords
  '("files" "hypermedia" "org" "notes")
  :url "https://sr.ht/~ymherklotz/org-zettelkasten")
;; Local Variables:
;; no-byte-compile: t
;; End:
