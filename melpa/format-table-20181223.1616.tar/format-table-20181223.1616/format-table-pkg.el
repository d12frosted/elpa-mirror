;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "format-table" "20181223.1616"
  "Parse and reformat tabular data."
  '((emacs "25")
    (dash  "2.14.1"))
  :url "https://github.com/functionreturnfunction/format-table"
  :commit "dfcae3a867e574577fc09a43b045889ff155b58f"
  :revdesc "dfcae3a867e5"
  :keywords '("data")
  :authors '(("Jason Duncan" . "jasond496@msn.com"))
  :maintainers '(("Jason Duncan" . "jasond496@msn.com")))
