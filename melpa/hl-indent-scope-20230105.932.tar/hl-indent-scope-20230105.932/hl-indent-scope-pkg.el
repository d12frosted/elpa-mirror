(define-package "hl-indent-scope" "20230105.932" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "e91ad5a78f4be099e202d3240cb6d8b688669a9b" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
