;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imakado" "20141024.923"
  "Imakado's usefull macros and functions."
  ()
  :url "https://github.com/imakado/emacs-imakado"
  :commit "00a1e7eea2cb9e9066343a23927d6c747707902f"
  :revdesc "00a1e7eea2cb"
  :keywords '("convenience")
  :authors '(("imakado" . "ken.imakado_at_gmail.com")))
