;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-multi-wiki" "20210324.1820"
  "Multiple wikis based on Org mode."
  '((emacs  "26.1")
    (dash   "2.12")
    (s      "1.12")
    (org-ql "0.5")
    (org    "9.3"))
  :url "https://github.com/akirak/org-multi-wiki"
  :commit "bf8039aadddaf02569fab473f766071ef7e63563"
  :revdesc "bf8039aaddda"
  :keywords '("org" "outlines" "files")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
