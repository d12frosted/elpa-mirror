;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260111.1625"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "bfe19d61e63aa67b376ab702f538f73020bc7843"
  :revdesc "bfe19d61e63a"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
