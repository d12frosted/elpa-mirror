;;; skk-jisx0213.el --- SKK $BMQ(B JISX0213 $BJ8;z%3!<%I4XO"%W%m%0%i%`(B -*- lexical-binding: t; coding: iso-2022-jp -*-

;; Copyright (C) 2000 NAKAJIMA Mikio <minakaji@osaka.email.ne.jp>

;; Author: NAKAJIMA Mikio <minakaji@osaka.email.ne.jp>
;; Maintainer: SKK Development Team
;; URL: https://github.com/skk-dev/ddskk
;; Keywords: japanese, mule, input method
;; Created: Sep. 30, 2000.

;; This file is part of Daredevil SKK.

;; This program is free software: you can redistribute it and/or
;; modify it under the terms of the GNU General Public License as
;; published by the Free Software Foundation, either version 3 of
;; the License, or (at your option) any later version.

;; This program is distributed in the hope that it will be
;; useful, but WITHOUT ANY WARRANTY; without even the implied
;; warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
;; PURPOSE.  See the GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;;; Code:

(require 'skk)
(require 'cl-lib)

(defconst skk-jisx0213-target-charsets
  ;; $B<B9T;~$KB8:_$9$kJ8;z=89g$N%j%9%H(B
  (cl-remove-if-not #'charsetp
                    '(japanese-jisx0213-a      ;2000$BG/HG(B $BBh(B1$BLLDI2CJ,(B
                      japanese-jisx0213-2      ;2000$BG/HG(B $BBh(B2$BLL!JLLA4It$,DI2CJ,!K(B
                      japanese-jisx0213.2004-1 ;2004$BG/HG(B $B2~Dj!&DI2CJ,(B
                      japanese-jisx0213-b      ;$BJd=u4A;z$H$N=EJ#9MN8J,(B
                      )))

(defconst skk-jisx0213--filter-regexp
  (rx-to-string `(any ,@skk-jisx0213-target-charsets)))

(defsubst skk-jisx0213--match-p (candidate)
  "CANDIDATE $B$,(B JIS X 0213 $BJ8;z$r4^$s$G$$$l$PHs(B nil $B$rJV$9!#(B"
  (string-match-p skk-jisx0213--filter-regexp
                  (if (consp candidate)
                      (cdr candidate)
                    candidate)))

;;;###autoload
(defun skk-jisx0213-henkan-list-filter ()
  "JIS X 0213 $BJ8;z$r4^$`8uJd$r(B `skk-henkan-list' $B$+$i:o=|$9$k!#(B
$B8=:_A*BrCf$N%$%s%G%C%/%9!J(B`skk-henkan-count'$B!K0J9_$N8uJd$,BP>]!#(B"
  (let ((unprocessed (nthcdr skk-henkan-count skk-henkan-list)))
    (when unprocessed
      (let ((filtered (cl-delete-if #'skk-jisx0213--match-p unprocessed)))
        (if (zerop skk-henkan-count)
            (setq skk-henkan-list filtered)
          (setcdr (nthcdr (1- skk-henkan-count) skk-henkan-list) filtered))))))

(provide 'skk-jisx0213)

;; Local Variables:
;; indent-tabs-mode: nil
;; End:

;;; skk-jisx0213.el ends here
