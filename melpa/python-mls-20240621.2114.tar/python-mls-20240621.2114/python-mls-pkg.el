;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mls" "20240621.2114"
  "Multi-line shell for (i)Python."
  '((emacs  "27.1")
    (compat "29.1"))
  :url "https://github.com/jdtsmith/python-mls"
  :commit "3ebacc6c46e9f7de25279783001ca3fc8964d7a8"
  :revdesc "3ebacc6c46e9"
  :keywords '("languages" "processes"))
