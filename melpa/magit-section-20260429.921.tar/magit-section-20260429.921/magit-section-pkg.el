;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "20260429.921"
  "Sections for read-only buffers."
  '((emacs    "28.1")
    (compat   "30.1")
    (cond-let "0.2")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/magit"
  :commit "6b10f7f6f90f3f2af69073d33568422dd38944df"
  :revdesc "6b10f7f6f90f"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
