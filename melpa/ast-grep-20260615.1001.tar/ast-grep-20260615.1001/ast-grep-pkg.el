;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ast-grep" "20260615.1001"
  "Search code using ast-grep with completing-read interface."
  '((emacs "28.1"))
  :url "https://github.com/sunskyxh/ast-grep.el"
  :commit "8fabb5064131a1c822580e47bf35871466d469ff"
  :revdesc "8fabb5064131"
  :keywords '("tools" "matching")
  :authors '(("SunskyxXH" . "sunskyxh@gmail.com"))
  :maintainers '(("SunskyxXH" . "sunskyxh@gmail.com")))
