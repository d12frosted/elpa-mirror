;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bshell" "20260107.1903"
  "Manage and track multiple inferior shells."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.1"))
  :url "https://github.com/plandes/bshell"
  :commit "0e90efb7e955e75f27d02f5560f556bfa3372b92"
  :revdesc "0e90efb7e955"
  :keywords '("unix" "interactive" "shell" "management"))
