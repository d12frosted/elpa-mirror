;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260716.50"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "613234c46907728f907006642d615d6256fef2e3"
  :revdesc "613234c46907"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
