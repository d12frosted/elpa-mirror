(define-package "dtache" "20220513.2050" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "08310ca70b935d82fab146c7135d19a2c784f160" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
