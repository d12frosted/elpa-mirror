;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wc-goal-mode" "20140829.1359"
  "Running word count with goals (minor mode)."
  ()
  :url "https://github.com/bnbeckwith/wc-goal-mode"
  :commit "bf21ab9c5a449bcc20dd207a4915dcec218d2699"
  :revdesc "bf21ab9c5a44")
