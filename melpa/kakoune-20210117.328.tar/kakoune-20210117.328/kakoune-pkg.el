(define-package "kakoune" "20210117.328" "A simulation, but not emulation, of kakoune"
  '((ryo-modal "0.4")
    (multiple-cursors "1.4")
    (expand-region "0.11.0")
    (emacs "25.1"))
  :commit "962b140a0b02cd0c9189c96b4f97b81576f4eba1" :authors
  '(("Joseph Morag" . "jm4157@columbia.edu"))
  :maintainer
  '("Joseph Morag" . "jm4157@columbia.edu")
  :url "https://github.com/jmorag/kakoune.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
