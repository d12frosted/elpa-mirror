;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-manage" "20260711.1557"
  "Manage buffers."
  '((emacs          "26.1")
    (choice-program "0.16.0")
    (dash           "2.17.0"))
  :url "https://github.com/plandes/buffer-manage"
  :commit "229673aca42f2cd7fc60b3d24516aa075a1fb48c"
  :revdesc "229673aca42f"
  :keywords '("internal" "maint"))
