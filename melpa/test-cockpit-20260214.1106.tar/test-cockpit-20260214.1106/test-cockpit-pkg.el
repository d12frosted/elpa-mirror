;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260214.1106"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "ff5f1bd1d7ad9b040e93e4426ee065a925899d05"
  :revdesc "ff5f1bd1d7ad"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
