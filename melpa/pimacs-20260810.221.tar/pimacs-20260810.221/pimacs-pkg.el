;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260810.221"
  "Emacs Client for Pi."
  '((emacs         "29.1")
    (compat        "31.0")
    (markdown-mode "2.8")
    (timeout       "2.1.7")
    (pcre2el       "1.12")
    (spinner       "1.7")
    (transient     "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "c6b30279a5d25e4742ffd93c12f09ec8da783999"
  :revdesc "c6b30279a5d2"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
