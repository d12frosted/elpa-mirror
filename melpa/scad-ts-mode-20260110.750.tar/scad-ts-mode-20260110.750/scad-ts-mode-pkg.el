;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-ts-mode" "20260110.750"
  "Tree-sitter support for OpenSCAD."
  '((emacs "29.3"))
  :url "https://github.com/yoshinari-nomura/scad-ts-mode"
  :commit "bb6859b20303187b7d40174e22d6697465a6306a"
  :revdesc "bb6859b20303"
  :keywords '("openscad" "languages" "tree-sitter")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
