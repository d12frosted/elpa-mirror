(define-package "notmuch" "20210515.1210" "run notmuch within emacs" 'nil :commit "572af2795007464ffbf9cd4656e0e5736d78d362" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
