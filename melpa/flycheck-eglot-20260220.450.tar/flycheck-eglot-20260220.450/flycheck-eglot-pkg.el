;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-eglot" "20260220.450"
  "Flycheck support for eglot."
  '((emacs    "28.1")
    (eglot    "1.9")
    (flycheck "32"))
  :url "https://github.com/flycheck/flycheck-eglot"
  :commit "d073b246949cd3a645c330efdc5dd9bd396bc584"
  :revdesc "d073b246949c"
  :keywords '("convenience" "language" "tools")
  :authors '(("Sergey Firsov" . "intramurz@gmail.com"))
  :maintainers '(("Sergey Firsov" . "intramurz@gmail.com")))
