;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251128.1431"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "17aa148caa685b0a23c978098ffdeb59fe2c2682"
  :revdesc "17aa148caa68")
