;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronometrist-spark" "20230629.1039"
  "Show sparklines in Chronometrist buffers."
  '((emacs         "25.1")
    (chronometrist "0.7.0")
    (spark         "0.1"))
  :url "https://tildegit.org/contrapunctus/chronometrist"
  :commit "d8290a82ea65730413627325a705067269cfa2f1"
  :revdesc "d8290a82ea65"
  :keywords '("calendar")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de")))
