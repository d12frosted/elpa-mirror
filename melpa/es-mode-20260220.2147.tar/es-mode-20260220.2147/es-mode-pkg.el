;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "es-mode" "20260220.2147"
  "A major mode for editing and executing Elasticsearch queries."
  '((dash    "2.11.0")
    (cl-lib  "0.5")
    (spark   "1.0")
    (s       "1.11.0")
    (request "0.3.0"))
  :url "http://www.github.com/dakrone/es-mode"
  :commit "cf93c9900057a9f3c89f982f778f41f48285d076"
  :revdesc "cf93c9900057"
  :keywords '("elasticsearch")
  :authors '(("Lee Hinman" . "lee@writequit.org"))
  :maintainers '(("Lee Hinman" . "lee@writequit.org")))
