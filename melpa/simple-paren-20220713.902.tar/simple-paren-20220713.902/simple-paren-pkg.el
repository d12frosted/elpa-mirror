(define-package "simple-paren" "20220713.902" "Non-electrical insert paired delimiter, wrap"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "feac5e500f49e3825e2e3017d94459e663ebd5ff" :authors
  '(("Andreas Röhler, Steve Purcell"))
  :maintainers
  '(("Andreas Röhler, Steve Purcell"))
  :maintainer
  '("Andreas Röhler, Steve Purcell")
  :keywords
  '("convenience")
  :url "https://github.com/andreas-roehler/simple-paren")
;; Local Variables:
;; no-byte-compile: t
;; End:
