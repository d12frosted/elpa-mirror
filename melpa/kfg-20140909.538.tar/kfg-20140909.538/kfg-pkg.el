;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kfg" "20140909.538"
  "An emacs configuration system."
  '((f "0.17.1"))
  :url "https://github.com/abingham/kfg"
  :commit "ffc35b77f227d4c64a1271ec30d31333ffeb0013"
  :revdesc "ffc35b77f227"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
