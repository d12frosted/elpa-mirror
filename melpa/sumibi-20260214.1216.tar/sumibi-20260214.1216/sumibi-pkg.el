;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20260214.1216"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (markdown-mode  "2.0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "dbbb06f6c0d5f921e3d5f8c34a2bcb4ec8caff4d"
  :revdesc "dbbb06f6c0d5"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
