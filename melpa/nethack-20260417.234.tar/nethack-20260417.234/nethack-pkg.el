;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20260417.234"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "4c6e483966eee5a210b99ea8de34d20146e21237"
  :revdesc "4c6e483966ee"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
