(define-package "org-roam-ql" "20230927.100" "Interface to query and view results from org-roam"
  '((emacs "28")
    (org-roam "2.2.0")
    (s "1.12.0")
    (magit-section "3.3.0")
    (transient "0.4")
    (org-super-agenda "1.2"))
  :commit "3a40541a8cb836c35759ee063595c0a33159cd25" :authors
  '(("Shariff AM Faleel"))
  :maintainers
  '(("Shariff AM Faleel"))
  :maintainer
  '("Shariff AM Faleel")
  :url "https://github.com/ahmed-shariff/org-roam-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
