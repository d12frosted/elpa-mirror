;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reveal-in-osx-finder" "20150802.1657"
  "Reveal file associated with buffer in OS X Finder."
  ()
  :url "https://github.com/kaz-yos/reveal-in-osx-finder"
  :commit "5710e5936e47139a610ec9a06899f72e77ddc7bc"
  :revdesc "5710e5936e47"
  :keywords '("os x" "finder"))
