;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuel" "20241006.231"
  "Factor's Ultimate Emacs Library."
  '((cl-lib "0.2")
    (emacs  "24.2"))
  :url "https://github.com/factor/fuel"
  :commit "6d0e98494f89d8b7dcfcae4cf83775562bf44ea9"
  :revdesc "6d0e98494f89"
  :keywords '("languages" "fuel" "factor")
  :authors '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org")))
