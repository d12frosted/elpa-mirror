;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20260209.1625"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "444be6919070c8769f43ae181a502d1de9bcfab3"
  :revdesc "444be6919070"
  :keywords '("frames"))
