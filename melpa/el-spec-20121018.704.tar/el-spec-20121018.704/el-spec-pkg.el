;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-spec" "20121018.704"
  "Ruby's rspec like syntax test frame work."
  ()
  :url "https://github.com/uk-ar/el-spec"
  :commit "1dbc465401d4aea5560318c4f13ff30920a0718d"
  :revdesc "1dbc465401d4"
  :keywords '("test")
  :authors '(("Yuuki Arisawa" . "yuuki.ari@gmail.com"))
  :maintainers '(("Yuuki Arisawa" . "yuuki.ari@gmail.com")))
