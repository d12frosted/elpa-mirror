;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-call-tree" "20260813.19"
  "Analyze source code based on font-lock text-properties."
  '((emacs    "24.3")
    (anaphora "1.0.0"))
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el"
  :commit "2365b14457340548529ad86728b52ba4bb2460e2"
  :revdesc "2365b1445734"
  :keywords '("programming")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
