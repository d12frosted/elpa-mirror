;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-navigate" "20260614.1125"
  "Directional navigation between blank-space blocks."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spatial-navigate"
  :commit "8b3e31be5a16657dc875d3ea248f907c75f8244f"
  :revdesc "8b3e31be5a16"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
