(define-package "python-mls" "20230522.2131" "Multi-line shell for (i)Python"
  '((emacs "27.1")
    (compat "29.1"))
  :commit "449122636573217fc8e45753f829a96d8b170f66" :authors
  '(("J.D. Smith"))
  :maintainers
  '(("J.D. Smith"))
  :maintainer
  '("J.D. Smith")
  :keywords
  '("languages" "processes")
  :url "https://github.com/jdtsmith/python-mls")
;; Local Variables:
;; no-byte-compile: t
;; End:
