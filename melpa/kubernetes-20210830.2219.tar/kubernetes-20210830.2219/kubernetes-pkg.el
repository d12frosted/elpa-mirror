(define-package "kubernetes" "20210830.2219" "Magit-like porcelain for Kubernetes."
  '((emacs "25.1")
    (dash "2.12.0")
    (magit-section "3.1.1")
    (magit-popup "2.13.0")
    (with-editor "3.0.4")
    (transient "0.3.0"))
  :commit "6cd0e63d302197bed03f1ac74afcd92b6115c9f5" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool"))
;; Local Variables:
;; no-byte-compile: t
;; End:
