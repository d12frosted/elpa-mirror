;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ext" "20250707.1824"
  "SystemVerilog Extensions."
  '((emacs           "29.1")
    (verilog-mode    "2024.3.1.121933719")
    (verilog-ts-mode "0.3.0")
    (lsp-mode        "8.0.0")
    (ag              "0.48")
    (ripgrep         "0.4.0")
    (hydra           "0.15.0")
    (apheleia        "3.1")
    (yasnippet       "0.14.0")
    (flycheck        "32")
    (async           "1.9.7"))
  :url "https://github.com/gmlarumbe/verilog-ext"
  :commit "15e2815034e469580c0401699654c8a155acae59"
  :revdesc "15e2815034e4"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
