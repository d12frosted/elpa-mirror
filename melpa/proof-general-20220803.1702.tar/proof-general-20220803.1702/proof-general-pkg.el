(define-package "proof-general" "20220803.1702" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "c304d73e09daec54dd8f8cef90df10c0b3d2c2ef" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
