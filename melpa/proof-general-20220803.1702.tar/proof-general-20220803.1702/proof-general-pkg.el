(define-package "proof-general" "20220803.1702" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "b5e3589ac84698eb94eb005bd17cd35633788127" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
