;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20250918.2024"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "95e2b66a6ab65bec524bde2d833d2ff597a40941"
  :revdesc "95e2b66a6ab6"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
