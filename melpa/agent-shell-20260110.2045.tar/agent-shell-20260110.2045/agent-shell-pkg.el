;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260110.2045"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "91c518a5e78ced0e5810035519160059f2c1eebc"
  :revdesc "91c518a5e78c")
