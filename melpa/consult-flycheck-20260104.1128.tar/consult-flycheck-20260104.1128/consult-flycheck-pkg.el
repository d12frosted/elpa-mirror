;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-flycheck" "20260104.1128"
  "Provides the command `consult-flycheck'."
  '((emacs    "29.1")
    (consult  "2.8")
    (flycheck "35"))
  :url "https://github.com/minad/consult-flycheck"
  :commit "e3fca5fadfa86cde5b1f2a5fc7c7669fb3423d15"
  :revdesc "e3fca5fadfa8"
  :keywords '("languages" "tools" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
