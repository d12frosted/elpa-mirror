(define-package "rspec-mode" "20220613.923" "Enhance ruby-mode for RSpec"
  '((ruby-mode "1.0")
    (cl-lib "0.4"))
  :commit "a72751dff9728c54316daf83ef301d4d3f1a970b" :authors
  '(("Peter Williams, et al."))
  :maintainer
  '("Peter Williams, et al.")
  :keywords
  '("rspec" "ruby")
  :url "http://github.com/pezra/rspec-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
