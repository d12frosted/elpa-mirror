;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "20260725.1947"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "80b764970b121b35dee22c9824c45be0e628fd63"
  :revdesc "80b764970b12"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
