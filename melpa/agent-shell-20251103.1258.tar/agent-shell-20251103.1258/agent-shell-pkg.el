;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251103.1258"
  "A single native shell experience to interact with agentic providers (Claude Code, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.82.2")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d60dd7f82b049beca0594933874049d2a094e394"
  :revdesc "d60dd7f82b04")
