(define-package "modus-themes" "20211004.759" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "70570a7161812ee7fd6efbc772b0c6391670ff37" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
