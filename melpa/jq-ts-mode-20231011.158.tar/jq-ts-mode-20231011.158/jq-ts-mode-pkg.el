(define-package "jq-ts-mode" "20231011.158" "Tree-sitter support for jq buffers"
  '((emacs "29.1"))
  :commit "aca935107da50a36232d2bc28d1797fd9896d218" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("jq" "languages" "tree-sitter")
  :url "https://github.com/nverno/jq-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
