;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260212.1357"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "a41fd6be6d3c5c15dbfd51e9ce48126be31ac944"
  :revdesc "a41fd6be6d3c"
  :keywords '("hypermedia"))
