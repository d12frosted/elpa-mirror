;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261018.1556"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "250ad52f77435d0e542e57f56634f979a065897e"
  :revdesc "250ad52f7743"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
