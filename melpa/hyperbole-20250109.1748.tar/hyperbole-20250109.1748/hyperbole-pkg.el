;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250109.1748"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "7e3bb0f41fafd587b03e34738ceee98a42f7f392"
  :revdesc "7e3bb0f41faf"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
