;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260321.1139"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "a455c950ee9dd2816e6eb5ca56bf9cf20632afa0"
  :revdesc "a455c950ee9d"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
