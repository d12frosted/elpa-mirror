;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260922.738"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "ef4b94cb2ff06d54fc28c3966241819761889097"
  :revdesc "ef4b94cb2ff0"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
