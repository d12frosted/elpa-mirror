;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esh-autosuggest" "20260520.316"
  "History autosuggestions for eshell."
  '((emacs   "24.4")
    (company "0.9.4"))
  :url "https://github.com/dieggsy/esh-autosuggest"
  :commit "80a42e490f55beb803f3c729d76895af991a0a69"
  :revdesc "80a42e490f55"
  :keywords '("completion" "company" "matching" "convenience" "abbrev")
  :authors '(("Diego A. Mundo" . "dieggsy@pm.me"))
  :maintainers '(("Diego A. Mundo" . "dieggsy@pm.me")))
