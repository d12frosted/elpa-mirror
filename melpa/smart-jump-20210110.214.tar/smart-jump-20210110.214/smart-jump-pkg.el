(define-package "smart-jump" "20210110.214" "Smart go to definition."
  '((emacs "25.1"))
  :commit "947499023b7c31b99fc172e2a4c1a105ad9c8555" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("tools")
  :url "https://github.com/jojojames/smart-jump")
;; Local Variables:
;; no-byte-compile: t
;; End:
