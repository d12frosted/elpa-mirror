(define-package "soria-theme" "20210813.912" "A xoria256 theme with some colors from openSUSE"
  '((emacs "25.1"))
  :commit "cc225f51ea724d8767f97249d8c6b3fc5182d331" :authors
  '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainer
  '("Miquel Sabaté Solà" . "mikisabate@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/mssola/soria")
;; Local Variables:
;; no-byte-compile: t
;; End:
