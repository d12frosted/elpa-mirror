;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260503.1145"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "999c42a5a134a5ef2acf0e687b49e9d5201de417"
  :revdesc "999c42a5a134"
  :keywords '("languages"))
