(define-package "org-ai" "20230330.1352" "Emacs org-mode integration for the OpenAI API"
  '((emacs "28.2"))
  :commit "8ea0a834bd9da160986d0c7a5803120a0b21c004" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
