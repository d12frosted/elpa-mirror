(define-package "embark" "20210324.1623" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d92ccbc054d0f56a5b745a61d1179a7593656864" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
