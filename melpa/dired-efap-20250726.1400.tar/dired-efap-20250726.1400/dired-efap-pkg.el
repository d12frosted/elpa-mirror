;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-efap" "20250726.1400"
  "Edit Filename At Point in a dired buffer."
  ()
  :url "https://github.com/juan-leon/dired-efap"
  :commit "34afe56327e26b90634e054e3b38e69c82f833bd"
  :revdesc "34afe56327e2"
  :keywords '("dired" "environment" "files" "renaming")
  :authors '(("Juan-Leon Lahoz" . "juanleon1@gmail.com"))
  :maintainers '(("Juan-Leon Lahoz" . "juanleon1@gmail.com")))
