(define-package "meow" "20220321.1832" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "264edfefb1e125d56edb77b1b1fc51a7a98f836b" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
