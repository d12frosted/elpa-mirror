;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250524.1443"
  "Modern HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "c47a49f484e769a352b56501dc0bcf9258a23a2f"
  :revdesc "c47a49f484e7"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
