(define-package "mini-echo" "20231114.2343" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "5c6c6554dd567e2b7b2b9f55d5f7c1d4fc048733" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
