;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260129.832"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0214d4578c675d5012346ce75c638ed4720bf702"
  :revdesc "0214d4578c67")
