;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250517.1557"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "2d2b23c3d5ce1bbc3953325cd953d535637e12fa"
  :revdesc "2d2b23c3d5ce"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
