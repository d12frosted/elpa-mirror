;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260404.1245"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "d7092fb7a2ff4b0440d078aa976a2828449f71a5"
  :revdesc "d7092fb7a2ff"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
