;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261128.1915"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.19.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "e3fbe9783cd9f058c66a688da0a9c3f59e237e3a"
  :revdesc "e3fbe9783cd9"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
