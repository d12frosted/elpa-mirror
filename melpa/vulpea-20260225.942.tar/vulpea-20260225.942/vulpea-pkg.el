;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260225.942"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "433e7db4a7e50de6a82ddad03e62dab571ca0c8f"
  :revdesc "433e7db4a7e5"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
