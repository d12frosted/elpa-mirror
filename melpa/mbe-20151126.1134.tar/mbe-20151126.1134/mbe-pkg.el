;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mbe" "20151126.1134"
  "Macros by Example."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/ijp/mbe.el"
  :commit "bb10aa8f26bb7e9b1d5746934c94edb00402940c"
  :revdesc "bb10aa8f26bb"
  :keywords '("tools" "macros")
  :authors '(("Ian Price" . "ianprice90@googlemail.com"))
  :maintainers '(("Ian Price" . "ianprice90@googlemail.com")))
