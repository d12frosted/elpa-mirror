(define-package "asyncloop" "20231028.1257" "Non-blocking series of functions"
  '((emacs "28.1"))
  :commit "cf595cc3e437421972a6f1a088a28a9a5060e07a" :authors
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainers
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainer
  '(nil . "<meedstrom91@gmail.com>")
  :keywords
  '("tools")
  :url "https://github.com/meedstrom/asyncloop")
;; Local Variables:
;; no-byte-compile: t
;; End:
