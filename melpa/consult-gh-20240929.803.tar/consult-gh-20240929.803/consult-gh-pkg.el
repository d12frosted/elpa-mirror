;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh" "20240929.803"
  "Consulting GitHub Client."
  '((emacs         "29.1")
    (consult       "1.0")
    (markdown-mode "2.6"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "4e4a1ef9a4823b37cf7057208f712aa69e1e0e2c"
  :revdesc "4e4a1ef9a482"
  :keywords '("convenience" "matching" "tools" "vc"))
