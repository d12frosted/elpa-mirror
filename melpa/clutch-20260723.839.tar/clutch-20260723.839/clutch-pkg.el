;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260723.839"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "ef1daae15fe30cd082cac5237d67636ce436402a"
  :revdesc "ef1daae15fe3"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
