;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesound" "20260921.1148"
  "Play, pause, resume music on a Bluesound player."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~rwv/bluesound-el/"
  :commit "b4dc3538a14b306caae1dcd23a0b7f622618a2b2"
  :revdesc "b4dc3538a14b"
  :keywords '("convenience" "multimedia"))
