;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250326.304"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "6a000d64b97ce0933ed42136e52cb21f179fd1cb"
  :revdesc "6a000d64b97c"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
