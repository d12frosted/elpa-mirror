;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jvm-mode" "20150422.708"
  "Monitor and manage your JVMs."
  '((dash  "2.6.0")
    (emacs "24"))
  :url "https://github.com/martintrojer/jvm-mode.el"
  :commit "3355dbaf5b0185aadfbad24160399abb32c5bea0"
  :revdesc "3355dbaf5b01"
  :keywords '("convenience")
  :authors '(("Martin Trojer" . "martin.trojer@gmail.com"))
  :maintainers '(("Martin Trojer" . "martin.trojer@gmail.com")))
