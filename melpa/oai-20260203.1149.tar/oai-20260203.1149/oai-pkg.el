;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260203.1149"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "7c6e9a3bcafc2cf80456a5c6620aa86f4d2301ca"
  :revdesc "7c6e9a3bcafc"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
