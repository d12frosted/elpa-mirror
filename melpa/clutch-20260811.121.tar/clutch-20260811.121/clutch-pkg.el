;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260811.121"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "9b3f7889ce7de99326b2f5ee23af9db40c47b4db"
  :revdesc "9b3f7889ce7d"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
