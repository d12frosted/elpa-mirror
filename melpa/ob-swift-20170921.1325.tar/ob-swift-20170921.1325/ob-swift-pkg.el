;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-swift" "20170921.1325"
  "Org-babel functions for swift evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-swift"
  :commit "ed478ddbbe41ce5373efde06b4dd0c3663c9055f"
  :revdesc "ed478ddbbe41"
  :keywords '("org" "babel" "swift")
  :authors '(("Feng Zhou" . "zf.pascal@gmail.com"))
  :maintainers '(("Feng Zhou" . "zf.pascal@gmail.com")))
