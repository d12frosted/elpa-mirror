(define-package "sis" "20231211.1406" "Less manual switch for native or OS input source (input method)."
  '((emacs "25.1")
    (terminal-focus-reporting "0.0"))
  :commit "9d145b6d9854c348f6e7ecceea0b2e97573e9409" :keywords
  '("convenience")
  :url "https://github.com/laishulu/emacs-smart-input-source")
;; Local Variables:
;; no-byte-compile: t
;; End:
