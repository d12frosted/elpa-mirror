(define-package "rescript-mode" "20230321.1917" "A major mode for editing ReScript"
  '((emacs "26.1"))
  :commit "a0a21d1c037c78ba4c05108a5e7afd5f75fe7bd7" :authors
  '(("Karl Landstrom" . "karl.landstrom@brgeight.se")
    ("Daniel Colascione" . "dancol@dancol.org")
    ("John Lee" . "jjl@pobox.com"))
  :maintainer
  '("John Lee" . "jjl@pobox.com")
  :keywords
  '("languages" "rescript")
  :url "https://github.com/jjlee/rescript-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
