;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontsloth" "20261110.1016"
  "Elisp otf/ttf font loader/renderer."
  '((async  "1.9.7")
    (f      "0.20.0")
    (logito "0.1")
    (pcache "0.5")
    (emacs  "28.1"))
  :url "https://github.com/jollm/fontsloth"
  :commit "76aba776f498219312d6e901eb5916395076faca"
  :revdesc "76aba776f498"
  :keywords '("data" "font" "rasterization" "ttf" "otf")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")))
