(define-package "workgroups2" "20211221.2249" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "ad17c2d6b0008a47e1ba85fd538d71f1e779e9ba" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
