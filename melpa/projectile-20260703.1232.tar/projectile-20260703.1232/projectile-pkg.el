;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260703.1232"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "568be01169da1779edff914f9d4090a8c008ea43"
  :revdesc "568be01169da"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
