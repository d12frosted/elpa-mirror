;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20260306.2317"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "011e7b999552f3c0730035183a4a6dfb60c10182"
  :revdesc "011e7b999552"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
