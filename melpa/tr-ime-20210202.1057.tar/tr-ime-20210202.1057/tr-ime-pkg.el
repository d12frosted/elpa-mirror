(define-package "tr-ime" "20210202.1057" "Emulator of IME patch for Windows"
  '((emacs "27.1")
    (w32-ime "0.0.1"))
  :commit "077dfb87054a20a1bbec8d6d0f282f64c6722999" :authors
  '(("Masamichi Hosoda" . "trueroad@trueroad.jp"))
  :maintainer
  '("Masamichi Hosoda" . "trueroad@trueroad.jp")
  :url "https://github.com/trueroad/tr-emacs-ime-module")
;; Local Variables:
;; no-byte-compile: t
;; End:
