(define-package "remark-mode" "20191103.1825" "Major mode for the remark slideshow tool"
  '((emacs "25.1")
    (markdown-mode "2.0"))
  :commit "e80a1b78304045dec3eceffb6c8cbaf2b6c7b57a" :authors
  (("@torgeir"))
  :maintainer
  ("@torgeir")
  :keywords
  ("remark" "slideshow" "markdown" "hot reload"))
;; Local Variables:
;; no-byte-compile: t
;; End:
