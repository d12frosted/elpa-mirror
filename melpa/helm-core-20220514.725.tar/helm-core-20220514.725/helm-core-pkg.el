(define-package "helm-core" "20220514.725" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "49bf6a160a96057f56e51c69e9402569b12643f1" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
