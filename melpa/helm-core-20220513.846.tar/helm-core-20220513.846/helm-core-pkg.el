(define-package "helm-core" "20220513.846" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "70c9e00470d0b53a47dde93d050076582d596bd1" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
