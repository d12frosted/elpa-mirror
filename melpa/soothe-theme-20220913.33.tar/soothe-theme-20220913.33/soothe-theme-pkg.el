(define-package "soothe-theme" "20220913.33" "A dark colorful theme"
  '((emacs "24.3")
    (autothemer "0.2"))
  :commit "b3452a86befe2754f282f75efb60adb4bc5d364e" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/emacs-soothe-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
