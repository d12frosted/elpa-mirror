;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llama" "20241029.103"
  "Compact syntax for short lambda."
  '((emacs "26.1"))
  :url "https://github.com/tarsius/llama"
  :commit "1faaa9696e8d715e5774937ce7d252f9313e23fe"
  :revdesc "1faaa9696e8d"
  :keywords '("extensions"))
