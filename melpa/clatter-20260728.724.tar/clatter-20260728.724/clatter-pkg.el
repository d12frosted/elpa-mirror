;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260728.724"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "48ce55f2e70a225d8e4b8094f818d8871048d013"
  :revdesc "48ce55f2e70a"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
