(define-package "gerrit" "20201216.2245" "Gerrit client"
  '((emacs "25.1")
    (hydra "0.15.0")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "00b0201cef4fd2ade108289a8444e1b354a882f6" :authors
  (("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  ("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  ("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
