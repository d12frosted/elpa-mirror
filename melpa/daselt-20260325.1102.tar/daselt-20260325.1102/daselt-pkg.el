;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260325.1102"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "88b756c00c6385a9db2ee26c043890ef9b7e1e7b"
  :revdesc "88b756c00c63"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
