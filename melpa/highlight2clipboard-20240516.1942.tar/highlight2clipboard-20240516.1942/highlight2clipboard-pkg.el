;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight2clipboard" "20240516.1942"
  "Copy text to clipboard with highlighting."
  '((htmlize "1.47"))
  :url "https://github.com/Lindydancer/highlight2clipboard"
  :commit "6564fafd09a9c676b4d393f2260a0c73daac7257"
  :revdesc "6564fafd09a9"
  :keywords '("tools"))
