(define-package "dirvish" "20220527.1146" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "ed84a7ffb83037416af2811e83152855b117c3bf" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
