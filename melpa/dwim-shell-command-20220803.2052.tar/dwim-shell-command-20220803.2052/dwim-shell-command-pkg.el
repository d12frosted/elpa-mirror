(define-package "dwim-shell-command" "20220803.2052" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "0ca360b69f0caf48f7df519a8c061607efe0147c" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
