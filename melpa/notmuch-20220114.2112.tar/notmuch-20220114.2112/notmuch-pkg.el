(define-package "notmuch" "20220114.2112" "run notmuch within emacs" 'nil :commit "6472dbf4b7fdec3bd59d7622ef477a035e34c67a" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
