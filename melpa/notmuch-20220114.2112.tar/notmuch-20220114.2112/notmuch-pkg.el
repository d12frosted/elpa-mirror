(define-package "notmuch" "20220114.2112" "run notmuch within emacs" 'nil :commit "fad2e7540bf9309bfb335650ded753e9ed085eff" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
