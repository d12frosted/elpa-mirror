(define-package "notmuch" "20220114.2112" "run notmuch within emacs" 'nil :commit "78e6cf12c05222c324110aa1eb9df9d99baa91a1" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
