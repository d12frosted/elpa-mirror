(define-package "notmuch" "20220114.2112" "run notmuch within emacs" 'nil :commit "c5cf92aa3534b27c0dda4794d14571b1b5439da8" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
