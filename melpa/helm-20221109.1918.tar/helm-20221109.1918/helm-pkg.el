(define-package "helm" "20221109.1918" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.8")
    (popup "0.5.3"))
  :commit "720df76514104202f803c37d8935ea49fa2529e5" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
