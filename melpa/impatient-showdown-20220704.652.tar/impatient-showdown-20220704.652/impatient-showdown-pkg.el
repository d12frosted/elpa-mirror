(define-package "impatient-showdown" "20220704.652" "Preview markdown buffer live over HTTP using showdown"
  '((emacs "24.3")
    (impatient-mode "1.1"))
  :commit "8f3e7ef41ea8fc43a747716a2c84c2708d5d4a2a" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "live" "preview" "markdown" "http" "server" "impatient")
  :url "https://github.com/jcs-elpa/impatient-showdown")
;; Local Variables:
;; no-byte-compile: t
;; End:
