(define-package "modus-themes" "20210516.2021" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "65348321fdb707574824d0cda42cbd1526b795d0" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
