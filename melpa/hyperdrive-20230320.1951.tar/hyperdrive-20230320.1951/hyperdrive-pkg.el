(define-package "hyperdrive" "20230320.1951" "Emacs gateway to the Hypercore network"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.3.2")
    (plz "0.4")
    (persist "0.5"))
  :commit "450e15a49d070e867f44e22229ae1881c73d47f9" :authors
  '(("Joseph Turner"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
