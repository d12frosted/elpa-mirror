;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260408.524"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "22348ba4cb89bb71d03e3cac0953d54c88d8f0ac"
  :revdesc "22348ba4cb89"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
