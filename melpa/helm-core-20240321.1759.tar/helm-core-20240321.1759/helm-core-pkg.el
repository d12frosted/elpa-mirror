(define-package "helm-core" "20240321.1759" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "9a9878c56902e29f2296442e94cd7e99d7a6fb2e" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
