(define-package "corfu" "20231123.1811" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "aa6d3b0d692cc994500c4151f48256a6c7fe8ea8" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
