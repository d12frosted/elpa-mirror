;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nnreddit" "20250831.1249"
  "Gnus backend for reddit."
  ()
  :url "https://github.com/dickmao/nnreddit"
  :commit "4b194b5953e9d4e6d94ce929fc264cd2b9e200a4"
  :revdesc "4b194b5953e9"
  :keywords '("news")
  :authors '(("dickmao" . "githubid:dickmao"))
  :maintainers '(("dickmao" . "githubid:dickmao")))
