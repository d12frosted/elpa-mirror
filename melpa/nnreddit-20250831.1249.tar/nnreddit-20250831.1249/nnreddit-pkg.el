;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nnreddit" "20250831.1249"
  "Gnus Backend For Reddit."
  '((emacs             "25.1")
    (request           "0.3.3")
    (anaphora          "1.0.4")
    (dash              "2.18.1")
    (json-rpc          "0.0.1")
    (virtualenvwrapper "20151123")
    (s                 "1.6.1"))
  :url "https://github.com/dickmao/nnreddit"
  :commit "4b194b5953e9d4e6d94ce929fc264cd2b9e200a4"
  :revdesc "4b194b5953e9"
  :keywords '("news")
  :authors '(("dickmao" . "githubid:dickmao"))
  :maintainers '(("dickmao" . "githubid:dickmao")))
