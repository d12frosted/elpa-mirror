;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251104.1949"
  "A single native shell experience to interact with agentic providers (Claude Code, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "96d8b8a0a8f21f819d2bafdaa5e8382f83de99b6"
  :revdesc "96d8b8a0a8f2")
