(define-package "meow" "20211213.35" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "8d1bf45e6e00b50bf05879ca7972b417b4ac4c7c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
