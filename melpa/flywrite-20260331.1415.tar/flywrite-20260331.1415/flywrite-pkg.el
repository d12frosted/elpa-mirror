;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flywrite" "20260331.1415"
  "Inline writing suggestions via LLM."
  '((emacs "29.1"))
  :url "https://github.com/awdeorio/flywrite"
  :commit "fd9387cdee7a104ef94d53b2c14915272ea31c2b"
  :revdesc "fd9387cdee7a"
  :keywords '("text" "wp")
  :authors '(("Andrew DeOrio" . "awdeorio@umich.edu"))
  :maintainers '(("Andrew DeOrio" . "awdeorio@umich.edu")))
