;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smog" "20230530.843"
  "Analyse the writing style, word use and readability of prose."
  '((emacs "24.1")
    (org   "8.1"))
  :url "https://github.com/zzkt/smog"
  :commit "2fc5fef0f5000027b3550495259a65966c68ec52"
  :revdesc "2fc5fef0f500"
  :keywords '("tools" "style" "readability" "prose")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
