;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-org" "20251027.1046"
  "Calendar view for org-agenda."
  '((emacs "28.1")
    (calfw "2.0")
    (org   "9.7"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "98c57682d5201d2ab59220c43cb77e0f1b7766b9"
  :revdesc "98c57682d520"
  :keywords '("calendar" "org")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
