;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cryptol-mode" "20190531.2051"
  "Cryptol major mode for Emacs."
  ()
  :url "https://github.com/thoughtpolice/cryptol-mode"
  :commit "81ebbde83f7cb75b2dfaefc09de6a1703068c769"
  :revdesc "81ebbde83f7c"
  :keywords '("cryptol" "cryptography")
  :authors '(("Austin Seipp" . "aseipp[@at]pobox[dot]com"))
  :maintainers '(("Austin Seipp" . "aseipp[@at]pobox[dot]com")))
