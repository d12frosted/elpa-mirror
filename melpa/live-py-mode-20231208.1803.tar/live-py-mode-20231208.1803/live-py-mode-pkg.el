(define-package "live-py-mode" "20231208.1803" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "578c47e4084fbca4992a9be327d45a9e4ff0f33e" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainers
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
