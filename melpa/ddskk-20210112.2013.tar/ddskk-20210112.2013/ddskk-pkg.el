(define-package "ddskk" "20210112.2013" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "cec99365fb3ad725c44514b918696ab153596b8d")
;; Local Variables:
;; no-byte-compile: t
;; End:
