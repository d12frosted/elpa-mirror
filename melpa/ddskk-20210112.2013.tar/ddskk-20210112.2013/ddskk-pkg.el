(define-package "ddskk" "20210112.2013" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "56ff3c6658d4c0790830c1ed40521ceb052a13fc")
;; Local Variables:
;; no-byte-compile: t
;; End:
