(define-package "ddskk" "20210112.2013" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "6ed518435be2d8c6fe3cfb421f046c0f084dde9e")
;; Local Variables:
;; no-byte-compile: t
;; End:
