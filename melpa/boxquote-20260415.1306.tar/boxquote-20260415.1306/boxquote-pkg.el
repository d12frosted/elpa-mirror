;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boxquote" "20260415.1306"
  "Quote text with a semi-box."
  '((emacs "28.1"))
  :url "https://github.com/davep/boxquote.el"
  :commit "8a1ed0814beffe597aa3c3f5867fc53e2e14bcc4"
  :revdesc "8a1ed0814bef"
  :keywords '("convenience" "editing" "quoting")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
