;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "volatile-highlights" "20250916.756"
  "Transient visual feedback for edits."
  '((emacs "24.4"))
  :url "https://github.com/k-talo/volatile-highlights.el"
  :commit "da88fd13579adf63f052ccaa78e04fe2ed8d7516"
  :revdesc "da88fd13579a"
  :keywords '("editing" "emulations" "convenience" "wp")
  :authors '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com"))
  :maintainers '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com")))
