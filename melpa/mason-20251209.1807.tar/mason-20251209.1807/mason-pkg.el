;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20251209.1807"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/deirn/mason.el"
  :commit "b572b91c663c20e4ab8eb6571db9393bd024fe36"
  :revdesc "b572b91c663c"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
