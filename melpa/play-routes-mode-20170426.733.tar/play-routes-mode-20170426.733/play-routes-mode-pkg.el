;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "play-routes-mode" "20170426.733"
  "Play Framework Routes File Support."
  ()
  :url "https://github.com/brocode/play-routes-mode/"
  :commit "ef8230932f7bb96643febbd6872c522932f9571a"
  :revdesc "ef8230932f7b"
  :keywords '("play" "scala")
  :authors '(("M.Riehl" . "max@flatmap.ninja")
             ("P.Haun" . "bomgar85@googlemail.com"))
  :maintainers '(("M.Riehl" . "max@flatmap.ninja")
                 ("P.Haun" . "bomgar85@googlemail.com")))
