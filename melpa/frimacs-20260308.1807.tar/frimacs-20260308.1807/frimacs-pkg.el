;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frimacs" "20260308.1807"
  "An environment for the FriCAS computer algebra system."
  '((emacs "26.1"))
  :url "https://github.com/pdo/frimacs"
  :commit "e1f1599c6144e697b41059369f4d6010eca9019f"
  :revdesc "e1f1599c6144"
  :keywords '("fricas" "computer algebra" "extensions" "tools")
  :authors '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainers '(("Paul Onions" . "paul.onions@acm.org")))
