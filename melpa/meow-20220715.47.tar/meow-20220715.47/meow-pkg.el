(define-package "meow" "20220715.47" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "6083e746f7c009b16d2178b7a4eddb309f50d738" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
