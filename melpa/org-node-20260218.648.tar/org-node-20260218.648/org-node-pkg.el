;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260218.648"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "942e864604c85fa6b23d45ac0ce45b8ed74133c5"
  :revdesc "942e864604c8"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
