;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slurpbarf" "20251018.1532"
  "Commands for slurping and barfing."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "3fed105466fa7bf89b3fa3e616e7d3d9b175895e"
  :revdesc "3fed105466fa"
  :keywords '("convenience" "lisp" "nxml"))
