(define-package "svg-tag-mode" "20230110.1824" "Replace keywords with SVG tags"
  '((emacs "27.1")
    (svg-lib "0.2"))
  :commit "9f5c2cb862fcba96f247b85fdd1b7dffff7af93a" :authors
  '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr"))
  :maintainers
  '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr"))
  :maintainer
  '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr")
  :keywords
  '("convenience")
  :url "https://github.com/rougier/svg-tag-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
