(define-package "chronometrist-key-values" "20220223.922" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "3d2bc8149e06f5e713de903f5e51967bc8c2f31f" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
