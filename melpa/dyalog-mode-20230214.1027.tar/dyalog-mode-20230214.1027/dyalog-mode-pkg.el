;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dyalog-mode" "20230214.1027"
  "Major mode for editing Dyalog APL source code."
  '((cl-lib "0.2")
    (emacs  "24.3"))
  :url "https://github.com/harsman/dyalog-mode.git"
  :commit "13c0d391aa878a1609259a89fe3e6db8d21935e8"
  :revdesc "13c0d391aa87"
  :keywords '("languages")
  :authors '(("Joakim Hårsman" . "joakim.harsman@gmail.com"))
  :maintainers '(("Joakim Hårsman" . "joakim.harsman@gmail.com")))
