(define-package "pyinspect" "20211102.1415" "Python object inspector"
  '((emacs "27.1"))
  :commit "36cf624236c8b4cce852dd52b64d058d4d4a32fd" :authors
  '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainer
  '("Maor Kadosh" . "git@avocadosh.xyz")
  :keywords
  '("tools")
  :url "https://github.com/it-is-wednesday/pyinspect.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
