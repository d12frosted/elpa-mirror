;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260426.1046"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "4813a15788182ff8902202680d4dc202ca7f90ed"
  :revdesc "4813a1578818"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
