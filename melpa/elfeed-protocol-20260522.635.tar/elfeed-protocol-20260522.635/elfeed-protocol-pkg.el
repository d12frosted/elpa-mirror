;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol" "20260522.635"
  "Provide fever/newsblur/owncloud/ttrss protocols for elfeed."
  '((emacs  "24.4")
    (elfeed "2.1.1")
    (cl-lib "0.5"))
  :url "https://github.com/fasheng/elfeed-protocol"
  :commit "2ae880b0d01bf30f5c22255fe073ec12ded71547"
  :revdesc "2ae880b0d01b"
  :keywords '("news")
  :authors '(("Xu Fasheng" . "fasheng[AT]fasheng.info"))
  :maintainers '(("Xu Fasheng" . "fasheng[AT]fasheng.info")))
