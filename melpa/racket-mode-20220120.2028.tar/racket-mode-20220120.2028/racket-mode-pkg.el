(define-package "racket-mode" "20220120.2028" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "59b227b1aab315cdaa798648e47c4c4a8f71ddba" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
