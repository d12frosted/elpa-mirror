;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20261122.1615"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1")
    (timeout     "2.1.6"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "36b5fc01292b48963bce38cf04d363bdce04d3cd"
  :revdesc "36b5fc01292b"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
