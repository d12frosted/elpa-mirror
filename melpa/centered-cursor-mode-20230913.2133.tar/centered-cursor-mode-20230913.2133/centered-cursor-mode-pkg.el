(define-package "centered-cursor-mode" "20230913.2133" "cursor stays vertically centered" 'nil :commit "25f307fe0a5b736e2a7c5e964ab7d6b020bf602f" :authors
  '(("André Riemann" . "andre.riemann@web.de"))
  :maintainers
  '(("André Riemann" . "andre.riemann@web.de"))
  :maintainer
  '("André Riemann" . "andre.riemann@web.de")
  :keywords
  '("convenience")
  :url "https://github.com/andre-r/centered-cursor-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
