;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250217.441"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.1")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "b4d7331b906f0421b29fe95bac24b502131f147c"
  :revdesc "b4d7331b906f"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
