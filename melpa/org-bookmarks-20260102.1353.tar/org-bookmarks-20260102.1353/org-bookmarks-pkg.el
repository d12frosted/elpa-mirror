;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bookmarks" "20260102.1353"
  "Manage bookmarks in Org mode."
  '((emacs      "29.1")
    (nerd-icons "0.1.0")
    (seq        "2.24"))
  :url "https://repo.or.cz/org-bookmarks.git"
  :commit "b54d1e296bb0fcaf33452838de83f69c1ab58f0d"
  :revdesc "b54d1e296bb0"
  :keywords '("outline" "matching" "hypermedia" "org")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
