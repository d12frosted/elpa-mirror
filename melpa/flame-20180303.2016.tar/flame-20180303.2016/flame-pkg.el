;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flame" "20180303.2016"
  "Automatic generation of flamage, as if we needed more."
  '((emacs "24"))
  :url "https://github.com/mschuldt/flame"
  :commit "2cfb860a483197e92a4c20d7b9b055d586e76fe0"
  :revdesc "2cfb860a4831"
  :keywords '("games")
  :authors '(("Ian G. Batten" . "batten@uk.ac.bham.multics")
             ("Noah Friedman" . "friedman@splode.com"))
  :maintainers '(("Noah Friedman" . "friedman@splode.com")))
