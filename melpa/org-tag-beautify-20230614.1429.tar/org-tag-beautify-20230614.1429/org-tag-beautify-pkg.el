(define-package "org-tag-beautify" "20230614.1429" "Beautify Org mode tags"
  '((emacs "26.1")
    (org-pretty-tags "0.2.2")
    (nerd-icons "0.0.1"))
  :commit "a0e38c868a920c3d6a019241f414c98907852f2d" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-tag-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
