(define-package "cnfonts" "20230214.904" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "bc2c94a712b904f26d090d18dbaccc412f30ef3a" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
