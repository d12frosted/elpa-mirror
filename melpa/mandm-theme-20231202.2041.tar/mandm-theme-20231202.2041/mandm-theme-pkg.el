(define-package "mandm-theme" "20231202.2041" "An M&M color theme." 'nil :commit "cada8be0bd89086564ce1d5545c083595d4d4b71" :authors
  '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainers
  '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainer
  '("Christian Hopps" . "chopps@gmail.com")
  :url "https://github.com/choppsv1/emacs-mandm-theme.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
