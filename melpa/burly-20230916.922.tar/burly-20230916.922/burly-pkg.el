(define-package "burly" "20230916.922" "Save and restore frame/window configurations with buffers"
  '((emacs "27.1")
    (map "2.1"))
  :commit "fa65f28bb60a72f47a0af703567525c0e5d3edaf" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
