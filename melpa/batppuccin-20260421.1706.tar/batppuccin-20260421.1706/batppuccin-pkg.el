;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "20260421.1706"
  "Shared infrastructure for Batppuccin themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "4e9c240c332e745d58cf47ad900fdeefb01f707a"
  :revdesc "4e9c240c332e"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
