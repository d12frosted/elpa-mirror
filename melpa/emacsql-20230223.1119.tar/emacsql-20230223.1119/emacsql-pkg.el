(define-package "emacsql" "20230223.1119" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "c4399789fb2226386b3bce6674b6fcba2cc002c5" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
