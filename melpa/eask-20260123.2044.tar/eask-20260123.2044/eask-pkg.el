;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20260123.2044"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "9c0b084b523a44087efabfc63fcc0f41c5ec1e96"
  :revdesc "9c0b084b523a"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
