(define-package "orderless" "20211125.1250" "Completion style for matching regexps in any order"
  '((emacs "26.1"))
  :commit "8cea82b6d395078d0105f4957d4a95206dc9c7ba" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("extensions")
  :url "https://github.com/oantolin/orderless")
;; Local Variables:
;; no-byte-compile: t
;; End:
