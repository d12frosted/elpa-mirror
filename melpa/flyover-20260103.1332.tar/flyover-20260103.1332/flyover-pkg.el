;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20260103.1332"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "27a68d2207ca7ceac69f904389738cf0e0ef1cc5"
  :revdesc "27a68d2207ca"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
