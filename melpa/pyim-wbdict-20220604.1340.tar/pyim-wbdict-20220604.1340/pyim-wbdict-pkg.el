;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim-wbdict" "20220604.1340"
  "Some wubi dicts for pyim."
  '((pyim "3.7"))
  :url "https://github.com/tumashu/pyim-wbdict"
  :commit "e3b128cfcf218e4a0ca04189b0bd46909761227e"
  :revdesc "e3b128cfcf21"
  :keywords '("convenience" "chinese" "pinyin" "input-method" "complete")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
