;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20250221.1923"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.8.0"))
  :url "https://github.com/aurtzy/disproject"
  :commit "d245a5c916b028d7e6d39cdbcfeaf11237b40ea2"
  :revdesc "d245a5c916b0"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
