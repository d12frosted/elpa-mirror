;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20261107.804"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "66dd9455c1dece79f043f2995d7fc674703a46b5"
  :revdesc "66dd9455c1de"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
