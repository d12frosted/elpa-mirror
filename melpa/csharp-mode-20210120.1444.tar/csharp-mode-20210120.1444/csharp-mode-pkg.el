(define-package "csharp-mode" "20210120.1444" "C# mode derived mode"
  '((emacs "26.1")
    (tree-sitter "0.12.1")
    (tree-sitter-indent "0.1")
    (tree-sitter-langs "0.9.1"))
  :commit "3f963c2ccee0ef4b7a1acdeb2cb0c11647c91a80" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
