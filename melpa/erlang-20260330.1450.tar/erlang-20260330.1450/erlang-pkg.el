;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20260330.1450"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "11d07debf154d1236ad4293ef96e2ea55746a8ff"
  :revdesc "11d07debf154"
  :keywords '("erlang" "languages" "processes"))
