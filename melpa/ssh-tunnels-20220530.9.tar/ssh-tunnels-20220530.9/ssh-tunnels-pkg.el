(define-package "ssh-tunnels" "20220530.9" "Manage SSH tunnels"
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "21770eac179b03cd3c6c58048c021817b2f7cb55" :authors
  '(("death <github.com/death>"))
  :maintainer
  '("death <github.com/death>")
  :keywords
  '("tools" "convenience")
  :url "http://github.com/death/ssh-tunnels")
;; Local Variables:
;; no-byte-compile: t
;; End:
