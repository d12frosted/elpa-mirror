(define-package "moom" "20210317.2350" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "cd83ceb37088918c68f53fd77142d13e9424af81" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
