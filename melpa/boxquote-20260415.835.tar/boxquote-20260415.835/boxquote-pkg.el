;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boxquote" "20260415.835"
  "Quote text with a semi-box."
  '((cl-lib "0.5"))
  :url "https://github.com/davep/boxquote.el"
  :commit "a64c1b67f61fe149391f2134af9491b3a371b5e6"
  :revdesc "a64c1b67f61f"
  :keywords '("convenience" "editing" "quoting")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
