(define-package "dirvish" "20220522.1236" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "36db5dccaead034d2a55ac804e789d3dedf398c8" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
