;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-emoji" "20180515.1837"
  "Show :emoji-name: instead of emoji characters."
  '((emacs "24"))
  :url "https://github.com/ecraven/no-emoji"
  :commit "ebceeab50dbfe4d60235180a57633745dbc18c77"
  :revdesc "ebceeab50dbf"
  :keywords '("extensions")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Peter" . "craven@gmx.net")))
