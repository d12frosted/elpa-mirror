;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "v2ex-mode" "20160720.345"
  "Major mode for visit http://v2ex.com/ site."
  '((cl-lib    "0.5")
    (request   "0.2")
    (let-alist "1.0.3"))
  :url "https://github.com/aborn/v2ex-mode"
  :commit "b7d19bb594b43ea3824a6f215dd1e5d1d4c0e8ad"
  :revdesc "b7d19bb594b4"
  :keywords '("v2ex" "v2ex.com")
  :authors '(("Aborn Jiang" . "aborn.jiang@gmail.com"))
  :maintainers '(("Aborn Jiang" . "aborn.jiang@gmail.com")))
