(define-package "spdx" "20230910.101" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "f09c5d90a4344e24334942ce25ebf95af10337d6" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
