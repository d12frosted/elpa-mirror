(define-package "esxml" "20210323.1102" "Library for working with xml via esxml and sxml"
  '((kv "0.0.5")
    (cl-lib "0.5"))
  :commit "cc5b9a8fef4c31acb4bbc4bae71c5feeb919da97" :authors
  '(("Evan Izaksonas-Smith <izak0002 at umn dot edu>"))
  :maintainer
  '("Evan Izaksonas-Smith")
  :keywords
  '("tools" "lisp" "comm"))
;; Local Variables:
;; no-byte-compile: t
;; End:
