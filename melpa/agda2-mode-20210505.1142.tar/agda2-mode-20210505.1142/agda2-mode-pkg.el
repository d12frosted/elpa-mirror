(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "e96aa7ce0545077b14be605af46f8e442cee9b28")
;; Local Variables:
;; no-byte-compile: t
;; End:
