(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "ed6730a1717a0e3ddc25a75de0c2e109371391c7")
;; Local Variables:
;; no-byte-compile: t
;; End:
