(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "54dfa724cf496f0cd5a067d6bc8cb8a834445841")
;; Local Variables:
;; no-byte-compile: t
;; End:
