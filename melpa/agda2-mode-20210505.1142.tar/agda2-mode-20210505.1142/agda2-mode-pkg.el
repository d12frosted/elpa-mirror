(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "d92578e78d91a23eccf973f76b09fea78b74a5da")
;; Local Variables:
;; no-byte-compile: t
;; End:
