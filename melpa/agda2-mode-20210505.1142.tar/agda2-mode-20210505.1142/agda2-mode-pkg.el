(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c6401a63e84caa495d74f4a5696b4628c306d5dc")
;; Local Variables:
;; no-byte-compile: t
;; End:
