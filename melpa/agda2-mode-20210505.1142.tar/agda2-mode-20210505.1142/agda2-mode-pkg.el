(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "4d972a3c6f7d75d42dc7e7eae9626d925c2c3f69")
;; Local Variables:
;; no-byte-compile: t
;; End:
