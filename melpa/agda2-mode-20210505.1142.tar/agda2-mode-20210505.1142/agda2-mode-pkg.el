(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "464444fced565a7f5bd84de431c7e5f71b668755")
;; Local Variables:
;; no-byte-compile: t
;; End:
