(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "e64e79bc26b06bcc1fa965f3fda661732475ebb8")
;; Local Variables:
;; no-byte-compile: t
;; End:
