(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "35d44f18eb8f43ff511c6f29ea562e89d83ba626")
;; Local Variables:
;; no-byte-compile: t
;; End:
