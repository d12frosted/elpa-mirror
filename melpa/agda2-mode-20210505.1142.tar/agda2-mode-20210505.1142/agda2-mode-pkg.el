(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "8cfd31fc3b2a9a3d888051485505a585a3ed5c3e")
;; Local Variables:
;; no-byte-compile: t
;; End:
