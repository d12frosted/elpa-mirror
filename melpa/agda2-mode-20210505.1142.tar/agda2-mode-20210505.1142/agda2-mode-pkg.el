(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "2c433222ad624682cd82a63b047507aeacfcff3c")
;; Local Variables:
;; no-byte-compile: t
;; End:
