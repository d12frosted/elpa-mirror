(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "4773470ceb0e8671e128109f4728d6416ff93fae")
;; Local Variables:
;; no-byte-compile: t
;; End:
