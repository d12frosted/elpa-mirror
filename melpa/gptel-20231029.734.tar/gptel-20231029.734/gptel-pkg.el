(define-package "gptel" "20231029.734" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "aa50cbab704ce8e6cab57868c3358a2eda6bdd68" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
