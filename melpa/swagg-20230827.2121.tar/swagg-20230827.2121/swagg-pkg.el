(define-package "swagg" "20230827.2121" "Swagger UI"
  '((emacs "27.1")
    (compat "29.1.4.0")
    (request "0.3.3")
    (dash "2.19.1")
    (yaml "0.5.1")
    (s "1.13.1"))
  :commit "28bfee4157e6b7d58661ae2f1e610fb5e42ecb9e" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :keywords
  '("tools" "convenience")
  :url "https://github.com/isamert/swagg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
