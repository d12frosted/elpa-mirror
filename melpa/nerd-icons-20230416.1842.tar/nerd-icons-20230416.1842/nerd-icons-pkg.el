(define-package "nerd-icons" "20230416.1842" "Emacs Nerd Font Icons Library"
  '((emacs "24.3"))
  :commit "2ff304882c1c809713fc2b904b0309bfdb507b7b" :authors
  '(("Hongyu Ding <rainstormstudio@yahoo.com>, Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Hongyu Ding <rainstormstudio@yahoo.com>, Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/rainstormstudio/nerd-icons.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
