(define-package "cc-isearch-menu" "20240301.1909" "A Transient menu for isearch"
  '((emacs "29.1"))
  :commit "ad4f3c870412bf6f3b26cdb894097dddd4c73911" :authors
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainer
  '("Charles Choi" . "kickingvegas@gmail.com")
  :keywords
  '("wp")
  :url "https://github.com/kickingvegas/cc-isearch-menu")
;; Local Variables:
;; no-byte-compile: t
;; End:
