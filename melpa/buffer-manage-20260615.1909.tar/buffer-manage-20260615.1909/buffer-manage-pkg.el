;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-manage" "20260615.1909"
  "Manage buffers."
  '((emacs          "26.1")
    (choice-program "0.13")
    (dash           "2.17.0"))
  :url "https://github.com/plandes/buffer-manage"
  :commit "3063b6efb9eb9e5efa27098ddb25bc12205c362f"
  :revdesc "3063b6efb9eb"
  :keywords '("internal" "maint"))
