(define-package "srfi" "20221004.1653" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "ad2b110a30df7273352d7c12e28e130731de9662" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
