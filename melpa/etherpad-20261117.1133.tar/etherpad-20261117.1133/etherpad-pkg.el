;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etherpad" "20261117.1133"
  "Collaborative editing via Etherpad."
  '((emacs     "29.1")
    (websocket "1.12"))
  :url "https://codeberg.org/zzkt/ethermacs"
  :commit "9cee52c17259fb78dc3d0cd03b3664267af4480e"
  :revdesc "9cee52c17259"
  :keywords '("comm" "etherpad" "collaborative editing")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
