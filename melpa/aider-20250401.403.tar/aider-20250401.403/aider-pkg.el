;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250401.403"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "857fcbc1ecd8a6f06954d5d8dddd498093b7177d"
  :revdesc "857fcbc1ecd8"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
