(define-package "skype" "20160711.824" "skype UI for emacs users.." 'nil :commit "8e3b33e620ed355522aa36434ff41e3ced080629" :keywords
  ("skype" "chat")
  :authors
  (("SAKURAI Masashi" . "m.sakurai@kiwanami.net"))
  :maintainer
  ("SAKURAI Masashi" . "m.sakurai@kiwanami.net"))
;; Local Variables:
;; no-byte-compile: t
;; End:
