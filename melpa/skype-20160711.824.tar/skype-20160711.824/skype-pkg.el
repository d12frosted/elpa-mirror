;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skype" "20160711.824"
  "Skype UI for emacs users.."
  ()
  :url "https://github.com/kiwanami/emacs-skype"
  :commit "8e3b33e620ed355522aa36434ff41e3ced080629"
  :revdesc "8e3b33e620ed"
  :keywords '("skype" "chat")
  :authors '(("SAKURAI Masashi" . "m.sakurai@kiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakurai@kiwanami.net")))
