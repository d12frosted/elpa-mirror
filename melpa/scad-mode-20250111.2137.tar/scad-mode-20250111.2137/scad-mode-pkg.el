;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "20250111.2137"
  "A major mode for editing OpenSCAD code."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "be616229a22d9a1058c553b806039ddef46a6ec2"
  :revdesc "be616229a22d"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
