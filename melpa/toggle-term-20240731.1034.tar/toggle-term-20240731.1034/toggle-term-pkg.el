(define-package "toggle-term" "20240731.1034" "Quickly toggle persistent term and shell buffers"
  '((emacs "24.3"))
  :commit "8f0014db7f9a928128f4f4f13951f796da4be55c" :keywords
  '("frames" "convenience" "terminals")
  :url "https://github.com/justinlime/toggle-term.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
