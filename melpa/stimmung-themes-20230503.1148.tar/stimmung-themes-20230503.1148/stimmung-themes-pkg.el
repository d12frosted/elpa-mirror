(define-package "stimmung-themes" "20230503.1148" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "06da5ed93ae3180674e980c0ac2e036841d15ac4" :authors
  '(("Love Lagerkvist"))
  :maintainers
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
