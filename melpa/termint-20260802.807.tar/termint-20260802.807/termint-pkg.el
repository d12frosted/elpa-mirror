;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "20260802.807"
  "Run REPLs in a terminal backend."
  '((emacs "29.1"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "b640da2a32b0a25cd7cee1ee96a2e35d363ad3fc"
  :revdesc "b640da2a32b0"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
