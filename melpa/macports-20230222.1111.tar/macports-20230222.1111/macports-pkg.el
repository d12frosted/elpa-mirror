(define-package "macports" "20230222.1111" "A porcelain for MacPorts"
  '((emacs "25.1")
    (transient "0.1.0"))
  :commit "8a16f149ce28e1e56e2736e1c1608dead445b8e8" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("convenience")
  :url "https://github.com/amake/macports.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
