;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keymap-utils" "20260504.1726"
  "Keymap utilities."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/keymap-utils"
  :commit "687c81b50a16e774ccbc1bcfa7e99ede3a3c826e"
  :revdesc "687c81b50a16"
  :keywords '("convenience" "extensions")
  :authors '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev")))
