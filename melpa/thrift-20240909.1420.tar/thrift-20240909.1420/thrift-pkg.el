(define-package "thrift" "20240909.1420" "Major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "b31299af9a1630280888132be342bca6f6622158" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
