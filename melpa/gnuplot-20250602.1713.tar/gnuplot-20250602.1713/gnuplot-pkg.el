;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250602.1713"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "5d8f06ad300ea1dd46b950cbf42f4c24ce30c0ae"
  :revdesc "5d8f06ad300e"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
