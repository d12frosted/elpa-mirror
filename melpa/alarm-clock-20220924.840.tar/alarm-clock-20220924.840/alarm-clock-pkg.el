(define-package "alarm-clock" "20220924.840" "Alarm Clock"
  '((emacs "24.4"))
  :commit "1d8cb396f4e63e9e16d82ab64b1ce599f98f09ce" :authors
  '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainer
  '("Steve Lemuel" . "wlemuel@hotmail.com")
  :keywords
  '("calendar" "tools" "convenience")
  :url "https://github.com/wlemuel/alarm-clock")
;; Local Variables:
;; no-byte-compile: t
;; End:
