;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260521.427"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "1cf59a4b4cb2b90106cf606d8e3c6a879d1e03f9"
  :revdesc "1cf59a4b4cb2"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
