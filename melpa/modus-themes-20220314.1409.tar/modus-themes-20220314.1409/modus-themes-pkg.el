(define-package "modus-themes" "20220314.1409" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "5ce44378f36570b2a0771790d3da6aa99fcf9151" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
