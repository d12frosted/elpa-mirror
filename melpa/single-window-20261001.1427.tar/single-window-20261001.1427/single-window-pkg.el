;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "single-window" "20261001.1427"
  "Always open buffers in the current window."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/single-window.el"
  :commit "8a9cdfa22030b11f261a27823740e1b818e7c55b"
  :revdesc "8a9cdfa22030"
  :keywords '("convenience" "windows")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
