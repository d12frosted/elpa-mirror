;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251006.1701"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "e20e5a3b432c8e704279cbec61700344b94015d1"
  :revdesc "e20e5a3b432c"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
