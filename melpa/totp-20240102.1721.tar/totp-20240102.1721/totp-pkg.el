;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "totp" "20240102.1721"
  "Time-based One-time Password (TOTP)."
  '((emacs "27.1"))
  :url "https://github.com/juergenhoetzel/emacs-totp"
  :commit "fe05ce6130ff1e9a76fc2aca289083475f70fd52"
  :revdesc "fe05ce6130ff"
  :keywords '("tools" "pass" "password")
  :authors '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainers '(("Jürgen Hötzel" . "juergen@hoetzel.info")))
