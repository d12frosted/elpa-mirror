;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20250915.215"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "2432c207fcf3b5782f00735873106ffc8d6e0536"
  :revdesc "2432c207fcf3"
  :keywords '("outlines"))
