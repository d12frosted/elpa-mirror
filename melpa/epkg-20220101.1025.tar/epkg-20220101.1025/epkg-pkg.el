(define-package "epkg" "20220101.1025" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "1d26d907d60043be5b9117046c870621a8211da7" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
