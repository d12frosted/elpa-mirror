(define-package "flymake-flycheck" "20230825.1700" "Use flycheck checkers as flymake backends"
  '((flycheck "31")
    (emacs "26.1"))
  :commit "a02d84a4860233af75fbabb0ef86b0622b688f13" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://github.com/purcell/flymake-flycheck")
;; Local Variables:
;; no-byte-compile: t
;; End:
