;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elkee" "20250928.2333"
  "Keepass client."
  '((emacs    "25.1")
    (kaesar   "0.9.5")
    (elchacha "1.0.4"))
  :url "https://github.com/KeyWeeUsr/elkee"
  :commit "9caf0b086e6b4f8132163620a709de7b260b5ace"
  :revdesc "9caf0b086e6b"
  :keywords '("convenience" "keepass" "client")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
