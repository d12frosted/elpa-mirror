(define-package "paren-face" "20230511.2101" "A face for parentheses in lisp modes"
  '((emacs "25.1")
    (compat "29.1.4.1"))
  :commit "8b575bc215e715525644ed66152a9bcefde3bd08" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("faces" "lisp")
  :url "https://github.com/tarsius/paren-face")
;; Local Variables:
;; no-byte-compile: t
;; End:
