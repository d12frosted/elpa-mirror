;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20251107.1442"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "699c91d84dd5aac28b478abc73aa7d6beab28852"
  :revdesc "699c91d84dd5"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
