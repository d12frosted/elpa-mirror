;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adafruit-wisdom" "20200217.306"
  "Get/display adafruit.com quotes."
  '((emacs   "25.1")
    (request "0.3.1"))
  :url "https://github.com/gonewest818/adafruit-wisdom.el"
  :commit "c4ae0db35d0be94f0e9c50977758224d7e00234a"
  :revdesc "c4ae0db35d0b"
  :keywords '("games")
  :authors '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com"))
  :maintainers '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com")))
