;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20251229.1604"
  "A collection of note-taking functions."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "79422880b3e392fe2e9fd60cab469590a12af321"
  :revdesc "79422880b3e3"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
