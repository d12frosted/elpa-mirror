(define-package "embark" "20210807.2227" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "57faa9e05fe766456c4ef60e964cabe34010b5f0" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
