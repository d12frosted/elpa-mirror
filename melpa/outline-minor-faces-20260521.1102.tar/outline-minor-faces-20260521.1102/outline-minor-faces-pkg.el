;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-minor-faces" "20260521.1102"
  "Highlight only section headings."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/outline-minor-faces"
  :commit "e1ad94189167f3f15fa00e7765aa663ec47d1c7b"
  :revdesc "e1ad94189167"
  :keywords '("faces" "outlines")
  :authors '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev")))
