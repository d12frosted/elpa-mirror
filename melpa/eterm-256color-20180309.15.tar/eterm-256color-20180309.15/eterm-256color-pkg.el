(define-package "eterm-256color" "20180309.15" "Customizable 256 colors for term."
  '((emacs "24.4")
    (xterm-color "1.7")
    (f "0.19.0"))
  :commit "dab96af559deb443c4c9c00e23389926e1607192" :authors
  '(("Diego A. Mundo" . "diegoamundo@gmail.com"))
  :maintainer
  '("Diego A. Mundo" . "diegoamundo@gmail.com")
  :keywords
  '("faces")
  :url "http://github.com/dieggsy/eterm-256color")
;; Local Variables:
;; no-byte-compile: t
;; End:
