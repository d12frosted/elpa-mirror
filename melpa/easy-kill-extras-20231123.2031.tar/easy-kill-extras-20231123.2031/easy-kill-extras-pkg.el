(define-package "easy-kill-extras" "20231123.2031" "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :commit "9dcdd662f8bdf9afd7366b5009e5f04e9dcf57d1" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/easy-kill-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
