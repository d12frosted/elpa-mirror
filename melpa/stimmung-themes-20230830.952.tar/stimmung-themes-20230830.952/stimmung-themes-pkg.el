(define-package "stimmung-themes" "20230830.952" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "6185778f9c89d11c27bea1a10c56e067d684f68f" :authors
  '(("Love Lagerkvist"))
  :maintainers
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
