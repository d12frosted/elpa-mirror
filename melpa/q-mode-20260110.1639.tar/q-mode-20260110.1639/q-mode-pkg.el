;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260110.1639"
  "A q editing mode."
  '((emacs "24"))
  :url "https://github.com/psaris/q-mode"
  :commit "ce1c5e827c29f7799b699aa0a476f4f06a1cf7ff"
  :revdesc "ce1c5e827c29"
  :keywords '("faces" "files" "q"))
