(define-package "dap-mode" "20200807.157" "Debug Adapter Protocol mode"
  '((emacs "26.1")
    (dash "2.14.1")
    (lsp-mode "6.0")
    (dash-functional "1.2.0")
    (bui "1.1.0")
    (f "0.20.0")
    (s "1.12.0")
    (lsp-treemacs "0.1")
    (posframe "0.7.0"))
  :commit "35db94e81c592246675f300aaca4a70966b8a5fc" :authors
  '(("Ivan Yonchovski" . "yyoncho@gmail.com"))
  :maintainer
  '("Ivan Yonchovski" . "yyoncho@gmail.com")
  :keywords
  '("languages" "debug")
  :url "https://github.com/yyoncho/dap-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
