(define-package "lsp-dart" "20210110.15" "Dart support lsp-mode"
  '((emacs "26.1")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (pkg-info "0.4")
    (dart-mode "1.0.5"))
  :commit "69e36b6c824c165527a25b9e6e754eea659a878e" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
