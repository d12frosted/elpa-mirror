;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dslide" "20241125.333"
  "Domain Specific sLIDEs. A presentation framework."
  '((emacs "29.2"))
  :url "https://github.com/positron-solutions/dslide"
  :commit "0d9a1f6c27e0543e912213d0a5047999f9e5deb5"
  :revdesc "0d9a1f6c27e0"
  :keywords '("convenience" "org-mode" "presentation" "narrowing")
  :authors '(("Positron" . "contact@positron.solutions"))
  :maintainers '(("Positron" . "contact@positron.solutions")))
