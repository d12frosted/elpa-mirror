;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "20260629.1347"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.0"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "08760f3c2169bed4d7866753bac6ce3a1e5d3529"
  :revdesc "08760f3c2169"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
