(define-package "modus-themes" "20211229.1023" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "c5c8fb9923ff19b1615f5f2f650ee536193d6b4c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
