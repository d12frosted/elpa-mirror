;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-chrome-bm" "20211022.1427"
  "Browse Chrom(e/ium) bookmarks with Ivy."
  '((emacs   "25.1")
    (counsel "0.13.0"))
  :url "https://github.com/BlueBoxWare/counsel-chrome-bm"
  :commit "3321bf78231e443cb98520dbb30a6c49e004c6a7"
  :revdesc "3321bf78231e"
  :keywords '("hypermedia")
  :authors '(("BlueBoxWare" . "(BlueBoxWare@users.noreply.github.com)"))
  :maintainers '(("BlueBoxWare" . "(BlueBoxWare@users.noreply.github.com)")))
