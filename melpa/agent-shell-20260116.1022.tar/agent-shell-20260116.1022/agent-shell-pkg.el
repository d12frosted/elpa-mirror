;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260116.1022"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7a8e2454730f9cf60b48ed86d3921f625ffac6c1"
  :revdesc "7a8e2454730f")
