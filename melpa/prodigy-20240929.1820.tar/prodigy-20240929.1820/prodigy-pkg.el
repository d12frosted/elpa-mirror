;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "prodigy" "20240929.1820"
  "Manage external services."
  '((s     "1.8.0")
    (dash  "2.4.0")
    (f     "0.14.0")
    (emacs "27.1"))
  :url "https://github.com/rejeep/prodigy.el"
  :commit "18c0a3b6de3613440679375fcb2b2163d6cf5bef"
  :revdesc "18c0a3b6de36"
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
