;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-web" "20260623.1111"
  "Web interface to Elfeed."
  '((emacs        "29.1")
    (compat       "31")
    (elfeed       "4.0.0")
    (simple-httpd "1.6"))
  :url "https://github.com/emacs-elfeed/elfeed-web"
  :commit "9074428d7a5159e647ebdd07f53c9720b908aaf6"
  :revdesc "9074428d7a51"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
