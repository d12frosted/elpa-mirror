(define-package "modus-themes" "20230205.723" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "28fa9ad0b7391ffa6b8e837dfbdca8f902c72e09" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
