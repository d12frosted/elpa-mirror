;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20260420.1713"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "a90c86c53e65f95fd19c67587ba7d904b939db3d"
  :revdesc "a90c86c53e65"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
