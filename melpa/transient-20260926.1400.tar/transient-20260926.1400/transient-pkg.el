;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260926.1400"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "a789ecb5485085adcbb404c736b95f71dee04329"
  :revdesc "a789ecb54850"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
