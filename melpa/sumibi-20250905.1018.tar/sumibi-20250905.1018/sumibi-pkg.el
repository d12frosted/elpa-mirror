;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250905.1018"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (mozc           "0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "1051a201dee73ec6374df459e32671085cd6b026"
  :revdesc "1051a201dee7"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
