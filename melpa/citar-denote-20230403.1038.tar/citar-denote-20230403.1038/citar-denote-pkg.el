(define-package "citar-denote" "20230403.1038" "Minor mode to integrate Citar and Denote"
  '((emacs "28.1")
    (citar "1.1")
    (denote "1.2.0")
    (dash "2.19.1"))
  :commit "327c7f386e8660c63b48568d23315cbebf95d151" :authors
  '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers
  '(("Peter Prevos" . "peter@prevos.net"))
  :maintainer
  '("Peter Prevos" . "peter@prevos.net")
  :url "https://github.com/pprevos/citar-denote")
;; Local Variables:
;; no-byte-compile: t
;; End:
