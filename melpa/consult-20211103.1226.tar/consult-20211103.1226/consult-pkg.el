(define-package "consult" "20211103.1226" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "39f41edda6f35f63b0cf099905b890bdc925db45" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
