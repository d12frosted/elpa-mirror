;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260530.1356"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e63f1ca96bc89feb9aa2fb66056e1d9214bdb584"
  :revdesc "e63f1ca96bc8")
