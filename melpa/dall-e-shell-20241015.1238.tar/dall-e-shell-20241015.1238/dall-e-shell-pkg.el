;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dall-e-shell" "20241015.1238"
  "Interaction mode for DALL-E."
  '((emacs       "27.1")
    (shell-maker "0.49.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "5ab70e11537ab9c775bf80a1caf502c769e9b7fe"
  :revdesc "5ab70e11537a")
