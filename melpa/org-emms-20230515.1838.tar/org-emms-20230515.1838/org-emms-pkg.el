(define-package "org-emms" "20230515.1838" "Play multimedia files in org-mode"
  '((emacs "24.1")
    (org "9.3")
    (emms "0.0"))
  :commit "3a4073565e88d6b17348a533a9ebd88941fb3da8" :authors
  '(("Jonathan Gregory <jgrg at autistici dot org>"))
  :maintainers
  '(("Jonathan Gregory <jgrg at autistici dot org>"))
  :maintainer
  '("Jonathan Gregory <jgrg at autistici dot org>")
  :keywords
  '("multimedia")
  :url "https://git.sr.ht/~jagrg/org-emms")
;; Local Variables:
;; no-byte-compile: t
;; End:
