;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-dark-vscode-theme" "20260706.2133"
  "The GitHub Dark Theme from Visual Studio Code."
  '((emacs "25.1"))
  :url "https://github.com/justintime50/github-dark-vscode-emacs-theme"
  :commit "b3590004a25a279a913168801142d18d2decfde0"
  :revdesc "b3590004a25a"
  :keywords '("faces"))
