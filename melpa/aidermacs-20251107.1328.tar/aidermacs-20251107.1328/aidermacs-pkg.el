;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20251107.1328"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "f3b64b5b3ded2296206d391533deabec75db5d20"
  :revdesc "f3b64b5b3ded"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
