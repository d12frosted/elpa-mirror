;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "20261025.1615"
  "Visually highlight the selected buffer."
  '((emacs "27.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "5525d29bac335a67040bcfc6a5c7083ebe5ac2f8"
  :revdesc "5525d29bac33"
  :keywords '("faces" "editing"))
