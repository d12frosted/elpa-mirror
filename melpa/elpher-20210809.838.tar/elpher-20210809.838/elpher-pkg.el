(define-package "elpher" "20210809.838" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "8eb8d6707f84064d3a3cd2947ca04fe17fc3f22e" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
