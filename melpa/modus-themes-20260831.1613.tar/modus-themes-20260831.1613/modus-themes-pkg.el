;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260831.1613"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "24e4b4b9e47a382cba6dfb3dc41d68a8ba7912d2"
  :revdesc "24e4b4b9e47a"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
