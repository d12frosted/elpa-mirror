(define-package "electric-spacing" "20211025.1016" "Insert operators with surrounding spaces smartly" 'nil :commit "859f4ab05eff9b00b3fd460b69010a03e010130e" :authors
  '(("William Xu" . "william.xwl@gmail.com"))
  :maintainer
  '("William Xu" . "william.xwl@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
