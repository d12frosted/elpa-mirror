;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcsh" "20230402.1229"
  "Vcsh integration."
  '((emacs "25.1"))
  :url "http://git.smrk.net/vcsh.el"
  :commit "b9c0109a8c77446980de668785e6af1e46bdcdcd"
  :revdesc "b9c0109a8c77"
  :keywords '("vc" "files")
  :authors '(("těpán Němec" . "stepnem@smrk.net"))
  :maintainers '(("těpán Němec" . "stepnem@smrk.net")))
