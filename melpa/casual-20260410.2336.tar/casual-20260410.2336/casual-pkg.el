;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260410.2336"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "d646190d565cb678db762fcc3663703616327bb7"
  :revdesc "d646190d565c"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
