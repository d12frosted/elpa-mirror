;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260509.1927"
  "Lets your agent talk to Emacs."
  '((emacs       "30.1")
    (http-server "0.1.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "26e28f22ab729886a2bd1318636dbeb4b177f6fa"
  :revdesc "26e28f22ab72"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
