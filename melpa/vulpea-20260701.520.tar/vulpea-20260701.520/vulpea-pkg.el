;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260701.520"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "e0a91c2dde663463b4724b52e5fcd2c9adf3a2c3"
  :revdesc "e0a91c2dde66"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
