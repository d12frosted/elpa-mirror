;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250316.358"
  "AI pair programming with Aider."
  '((emacs "29.1"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "3f366d166e8f131a237d83d62a60f67f466cd046"
  :revdesc "3f366d166e8f"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
