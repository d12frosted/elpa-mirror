;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "info-rename-buffer" "20200328.1450"
  "Rename Info buffers to match manuals."
  '((emacs "24.3"))
  :url "https://github.com/oitofelix/info-rename-buffer"
  :commit "87fb263b18717538fd04878e3358e1e720415db8"
  :revdesc "87fb263b1871"
  :keywords '("help")
  :authors '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org"))
  :maintainers '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org")))
