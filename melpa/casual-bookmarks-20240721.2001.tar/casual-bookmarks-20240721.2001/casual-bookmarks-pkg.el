(define-package "casual-bookmarks" "20240721.2001" "Transient UI for Bookmarks"
  '((emacs "29.1")
    (casual-lib "1.1.0"))
  :commit "57cd69570d6737259e7fa08ada309f891dc91474" :authors
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainer
  '("Charles Choi" . "kickingvegas@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kickingvegas/casual-bookmarks")
;; Local Variables:
;; no-byte-compile: t
;; End:
