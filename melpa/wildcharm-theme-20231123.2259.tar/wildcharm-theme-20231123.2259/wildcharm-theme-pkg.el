(define-package "wildcharm-theme" "20231123.2259" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "2ca0ef9493e883d5834107f1535bb4d1fab485d3" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
