(define-package "pass" "20231203.1555" "Major mode for password-store.el"
  '((emacs "25")
    (password-store "2.1.0")
    (password-store-otp "0.1.5")
    (f "0.17"))
  :commit "9fe45015db8839803e2ef54f51a0b0c5d64873b4" :authors
  '(("Nicolas Petton" . "petton.nicolas@gmail.com")
    ("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Nicolas Petton" . "petton.nicolas@gmail.com"))
  :maintainer
  '("Nicolas Petton" . "petton.nicolas@gmail.com")
  :keywords
  '("password-store" "password" "keychain"))
;; Local Variables:
;; no-byte-compile: t
;; End:
