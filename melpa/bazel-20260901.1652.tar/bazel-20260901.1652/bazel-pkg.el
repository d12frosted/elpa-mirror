;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260901.1652"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "a26a0c5c66910743a9e78b258c7a31b487c32fb6"
  :revdesc "a26a0c5c6691"
  :keywords '("build tools" "languages"))
