(define-package "hyperdrive" "20230423.25" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.3.2")
    (plz "0.5.4")
    (persist "0.5"))
  :commit "bdb4b3fe886c8e9a20907d3b2d056d58d7b18cab" :authors
  '(("Joseph Turner"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
