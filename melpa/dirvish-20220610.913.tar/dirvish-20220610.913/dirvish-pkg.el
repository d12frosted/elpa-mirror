(define-package "dirvish" "20220610.913" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "0276b0c73272d2f346c4bc7b8cc267ddecdc7b00" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
