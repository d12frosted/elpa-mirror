(define-package "dirvish" "20220610.913" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a15be7ac591cb3a43c8d7370aa54d8d9b3776767" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
