;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20251104.1816"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "e2396273464a58427edd3901cbef9d9a4d2420f3"
  :revdesc "e2396273464a"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
