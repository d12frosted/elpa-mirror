;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20261104.1848"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "d240a7fce2463c0b3c72fae281c426bb47e6dc95"
  :revdesc "d240a7fce246"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
