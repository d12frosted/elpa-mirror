(define-package "dashboard" "20221203.1936" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "753db383e57458203fbda813a6bfe9bf99ca1c6c" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
