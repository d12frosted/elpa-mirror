(define-package "meow" "20211214.1812" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "65c9fba7603a7365c0639abaee30534d40b42376" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
