;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sotlisp" "20220909.803"
  "Write lisp at the speed of thought."
  '((emacs "24.1"))
  :url "https://github.com/Malabarba/speed-of-thought-lisp"
  :commit "04186129f2dccf48e288639b78adeb9c0e94be54"
  :revdesc "04186129f2dc"
  :keywords '("convenience" "lisp")
  :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "emacs@endlessparentheses.com")))
