;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gh" "20260202.326"
  "GitHub CLI integration for Magit."
  '((emacs     "29.1")
    (magit     "4.0.0")
    (transient "0.5.0"))
  :url "https://github.com/jonathanchu/magit-gh"
  :commit "170360db2e2171a8d7f26393a3e3d8aceedbf5f4"
  :revdesc "170360db2e21"
  :keywords '("git" "tools" "vc" "github")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
