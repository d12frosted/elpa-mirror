;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260426.238"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "a5539cfa079dbcfd8db7e8b3a9fae626b906ccf9"
  :revdesc "a5539cfa079d"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
