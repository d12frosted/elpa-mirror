;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "20260114.1535"
  "Deactivate mouse input (alternative to disable-mouse)."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "448a86b679dc4d45ec74f94d1471b51850bfd6b8"
  :revdesc "448a86b679dc"
  :keywords '("convenience"))
