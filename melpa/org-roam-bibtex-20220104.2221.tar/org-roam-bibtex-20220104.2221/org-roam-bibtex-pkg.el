(define-package "org-roam-bibtex" "20220104.2221" "Org Roam meets BibTeX"
  '((emacs "27.2")
    (org-roam "2.0.0")
    (bibtex-completion "2.0.0"))
  :commit "948ff0922237f78070ab4c9062a4376f00dfa0a5" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
