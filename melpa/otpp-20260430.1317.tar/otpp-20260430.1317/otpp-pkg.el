;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260430.1317"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "126f6125ddb0148f6c7d1313cc0f412ac4845d92"
  :revdesc "126f6125ddb0"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
