(define-package "julia-formatter" "20231125.2109" "Use JuliaFormatter.jl for julia code"
  '((emacs "27.1")
    (session-async "0.0.5"))
  :commit "5ae0e4d67459b65a82dae3622ee7283a0751d98f" :authors
  '(("Felipe Lema" . "felipe.lema@mortemale.org"))
  :maintainers
  '(("Felipe Lema" . "felipe.lema@mortemale.org"))
  :maintainer
  '("Felipe Lema" . "felipe.lema@mortemale.org")
  :keywords
  '("convenience" "tools")
  :url "https://codeberg.org/FelipeLema/julia-formatter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
