;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pianobar" "20201002.1756"
  "Thin wrapper for Pianobar, a Pandora Radio client."
  ()
  :url "https://github.com/agrif/pianobar.el"
  :commit "d708417608df4f09ee565fddaad03dfe181829a8"
  :revdesc "d708417608df"
  :authors '(("Aaron Griffith" . "aargri@gmail.com"))
  :maintainers '(("Aaron Griffith" . "aargri@gmail.com")))
