;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260215.1323"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "21c916cc674dda61469c365b682fbb4c471f9c9c"
  :revdesc "21c916cc674d"
  :keywords '("convenience"))
