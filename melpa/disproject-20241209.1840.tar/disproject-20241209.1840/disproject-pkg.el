;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20241209.1840"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.8.0"))
  :url "https://github.com/aurtzy/disproject"
  :commit "160e4a71b87c6543b76ccc9642dc4a1a8ed6682c"
  :revdesc "160e4a71b87c"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
