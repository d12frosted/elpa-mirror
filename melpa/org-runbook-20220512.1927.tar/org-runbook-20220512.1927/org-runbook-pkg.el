(define-package "org-runbook" "20220512.1927" "Org mode for runbooks" 'nil :commit "d60aac9519e15fde8b2dc1de08e90856d5e02b42" :authors
  '(("Tyler Dodge"))
  :maintainer
  '("Tyler Dodge")
  :keywords
  '("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
