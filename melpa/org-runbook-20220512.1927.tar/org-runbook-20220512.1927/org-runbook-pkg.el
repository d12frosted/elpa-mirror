(define-package "org-runbook" "20220512.1927" "Org mode for runbooks" 'nil :commit "ec8b933c1269804546c356fe379169d1f0fce9ea" :authors
  '(("Tyler Dodge"))
  :maintainer
  '("Tyler Dodge")
  :keywords
  '("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
