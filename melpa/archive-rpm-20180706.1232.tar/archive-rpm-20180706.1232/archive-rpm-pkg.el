(define-package "archive-rpm" "20180706.1232" "RPM and CPIO support for archive-mode"
  '((emacs "24.4"))
  :commit "59f83caebbd2f92fd634f6968e6d17b50ffa3dc7" :authors
  '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainer
  '("Magnus Henoch" . "magnus.henoch@gmail.com")
  :keywords
  '("files"))
;; Local Variables:
;; no-byte-compile: t
;; End:
