(define-package "helm-core" "20240118.527" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "2dc2efc5dc07fb7bb7e37bf649d2672632e87977" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
