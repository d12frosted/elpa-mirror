;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260125.742"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "593d7697e9c9c83aed2bce103499b42898582689"
  :revdesc "593d7697e9c9"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
