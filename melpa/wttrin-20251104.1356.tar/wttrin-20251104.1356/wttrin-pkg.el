;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20251104.1356"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "6cf0aac96ae0abb455ee8525e0ede9a63f5974f3"
  :revdesc "6cf0aac96ae0"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
