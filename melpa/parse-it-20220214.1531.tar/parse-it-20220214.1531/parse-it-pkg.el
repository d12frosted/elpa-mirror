(define-package "parse-it" "20220214.1531" "Basic Parser in Emacs Lisp"
  '((emacs "25.1")
    (s "1.12.0"))
  :commit "265c4c1af0ad0f39b62944cf029729f865d63741" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/parse-it")
;; Local Variables:
;; no-byte-compile: t
;; End:
