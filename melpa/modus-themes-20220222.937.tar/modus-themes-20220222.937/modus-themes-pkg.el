(define-package "modus-themes" "20220222.937" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "f3ff0bc0089051cea85e39700ec148c1a40aeba4" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
