(define-package "live-py-mode" "20210413.205" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "c191b149f93ed473f3900e506cfc762d53145237" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
