(define-package "live-py-mode" "20210413.205" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "d799d074300aa7f1d78024167513a2316cffc204" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
