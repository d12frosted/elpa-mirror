(define-package "loopy" "20210614.102" "A looping macro"
  '((emacs "27.1"))
  :commit "f04778b55c302175edf157afe486f876ebf8b6f2" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
