(define-package "helm-core" "20240328.742" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "23a33265e1582bedd362c5e46b2f1663869a9b79" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
