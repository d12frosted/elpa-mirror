(define-package "commify" "20220531.1301" "Toggle grouping commas in numbers"
  '((s "1.9.0"))
  :commit "c4aeccae5b4a073fc3f4e8bd780a2ebbb7d5e533" :authors
  '(("Daniel E. Doherty" . "ded-commify@ddoherty.net"))
  :maintainers
  '(("Daniel E. Doherty" . "ded-commify@ddoherty.net"))
  :maintainer
  '("Daniel E. Doherty" . "ded-commify@ddoherty.net")
  :keywords
  '("convenience" "editing" "numbers" "grouping" "commas")
  :url "https://github.com/ddoherty03/commify")
;; Local Variables:
;; no-byte-compile: t
;; End:
