(define-package "elsa" "20211129.38" "Emacs Lisp Static Analyser"
  '((trinary "1.0.0")
    (emacs "25.1")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3"))
  :commit "5b8848fd7d87ee4927adda12a6cf5ed2a7e0c186" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
