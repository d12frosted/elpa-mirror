(define-package "citre" "20210731.1720" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "f8629119108ed2d9f0b02408d1210c382a3f6b01" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
