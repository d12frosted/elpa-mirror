;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-org" "20260926.1452"
  "Preview Org LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.11.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "cfa874f45f1555ccc7fd6f038f845071f5ab4319"
  :revdesc "cfa874f45f15"
  :keywords '("tex" "org" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
