;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-typescript-preset" "20260329.335"
  "Eglot preset for TypeScript."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-typescript-preset"
  :commit "39723885d5de1afa9b4ef763e25223fb5e49113e"
  :revdesc "39723885d5de"
  :keywords '("typescript" "javascript" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
