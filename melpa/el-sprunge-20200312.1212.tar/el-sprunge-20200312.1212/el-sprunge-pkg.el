;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-sprunge" "20200312.1212"
  "Command line paste server with Emacs highlighting."
  '((web-server "20140105.2246")
    (htmlize    "20130207.1202")
    (emacs      "24.3"))
  :url "https://github.com/eschulte/el-sprunge"
  :commit "e4365ea0bdf60969817619376bdcc98003fec33d"
  :revdesc "e4365ea0bdf6"
  :keywords '("http" "html" "server" "sprunge" "paste")
  :authors '(("Eric Schulte" . "schulte.eric@gmail.com"))
  :maintainers '(("Eric Schulte" . "schulte.eric@gmail.com")))
