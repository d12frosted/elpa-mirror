;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vterm-toggle" "20260105.1117"
  "Toggles between the vterm buffer and other buffers."
  '((emacs "25.1")
    (vterm "0.0.1"))
  :url "https://github.com/jixiuf/vterm-toggle"
  :commit "0c293594565993c84fdf0264418b49c0834ae2e4"
  :revdesc "0c2935945659"
  :keywords '("vterm" "terminals")
  :authors '((nil . "jixiufjixiuf@qq.com"))
  :maintainers '((nil . "jixiufjixiuf@qq.com")))
