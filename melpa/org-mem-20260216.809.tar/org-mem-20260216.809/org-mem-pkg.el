;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260216.809"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "79207bb91310f568a4c07c580544a908d36541e5"
  :revdesc "79207bb91310"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
