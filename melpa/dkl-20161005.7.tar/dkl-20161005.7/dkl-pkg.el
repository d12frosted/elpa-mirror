;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dkl" "20161005.7"
  "Display keyboard layout."
  ()
  :url "https://github.com/flexibeast/dkl"
  :commit "6b4584f86037bda3383960c678d51f340229fb91"
  :revdesc "6b4584f86037"
  :keywords '("input" "keyboard" "layout")
  :authors '(("Alexis" . "flexibeast@gmail.com"))
  :maintainers '(("Alexis" . "flexibeast@gmail.com")))
