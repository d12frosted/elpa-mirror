(define-package "dkl" "20161005.7" "Display keyboard layout." 'nil :commit "6b4584f86037bda3383960c678d51f340229fb91" :authors
  (("Alexis" . "flexibeast@gmail.com"))
  :maintainer
  ("Alexis" . "flexibeast@gmail.com")
  :keywords
  ("input" "keyboard" "layout")
  :url "https://github.com/flexibeast/dkl")
;; Local Variables:
;; no-byte-compile: t
;; End:
