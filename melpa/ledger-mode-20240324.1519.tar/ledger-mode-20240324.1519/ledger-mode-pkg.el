(define-package "ledger-mode" "20240324.1519" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "fb09516dfd73809297e77bafc8a5595d4129e6ac")
;; Local Variables:
;; no-byte-compile: t
;; End:
