(define-package "mentor" "20220105.1348" "Frontend for the rTorrent bittorrent client"
  '((emacs "25.1")
    (xml-rpc "1.6.15")
    (seq "1.11")
    (cl-lib "0.5")
    (async "1.9.3"))
  :commit "567daebce2b422b02b3b83296e2dde63d4936938" :authors
  '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainer
  '("Stefan Kangas" . "stefankangas@gmail.com")
  :keywords
  '("comm" "processes" "bittorrent"))
;; Local Variables:
;; no-byte-compile: t
;; End:
