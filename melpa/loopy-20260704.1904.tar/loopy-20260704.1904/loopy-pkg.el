;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260704.1904"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://codeberg.org/okamsn/loopy"
  :commit "838e1f5d38281dde54efbf61142267224e78e494"
  :revdesc "838e1f5d3828"
  :keywords '("extensions"))
