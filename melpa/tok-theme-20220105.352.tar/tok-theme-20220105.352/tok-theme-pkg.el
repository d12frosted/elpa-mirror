(define-package "tok-theme" "20220105.352" "My theme"
  '((emacs "24.3"))
  :commit "0963d71f56310cb43533645d860ad7751e339346" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
