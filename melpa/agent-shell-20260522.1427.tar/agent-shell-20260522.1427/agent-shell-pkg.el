;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260522.1427"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "58458b1442d9487039ea27762af983697d898aa7"
  :revdesc "58458b1442d9")
