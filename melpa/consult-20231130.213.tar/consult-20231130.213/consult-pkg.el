(define-package "consult" "20231130.213" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "49144b6a1f4ce639093c181402a5b29e6eeebd3b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
