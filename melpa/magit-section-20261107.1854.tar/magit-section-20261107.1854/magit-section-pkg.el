;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "20261107.1854"
  "Sections for read-only buffers."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/magit"
  :commit "d60aea3445e23ee0f9a17e889d2f22fef6da8c65"
  :revdesc "d60aea3445e2"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
