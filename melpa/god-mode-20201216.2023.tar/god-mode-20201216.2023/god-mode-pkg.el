(define-package "god-mode" "20201216.2023" "Minor mode for God-like command entering"
  '((emacs "25.1"))
  :commit "f6eb3428e6a17a97e6e9f0783ce17ced004b98c3" :authors
  (("Chris Done" . "chrisdone@gmail.com"))
  :maintainer
  ("Chris Done" . "chrisdone@gmail.com")
  :url "https://github.com/emacsorphanage/god-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
