;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-chat" "20260314.1216"
  "Emacs client for Lisp Chat."
  '((emacs     "27.1")
    (websocket "1.12"))
  :url "https://github.com/ryukinix/lisp-chat"
  :commit "3ea62513f804a6ef318e9103c2fa1375de0d0b30"
  :revdesc "3ea62513f804"
  :keywords '("comm" "chat" "lisp"))
