(define-package "consult" "20210113.128" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b96156086386d6f392f84e7a6232987e7af9aefc" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
