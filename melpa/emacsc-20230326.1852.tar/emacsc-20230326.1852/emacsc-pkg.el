(define-package "emacsc" "20230326.1852" "helper for emacsc(1)" 'nil :commit "b4afd616c4ef160c58fc9a9682d3431b30a9d434" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("tools")
  :url "https://github.com/knu/emacsc")
;; Local Variables:
;; no-byte-compile: t
;; End:
