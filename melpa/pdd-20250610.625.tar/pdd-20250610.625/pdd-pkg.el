;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250610.625"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "e8ac6baf7f502028675a2b5c945dd9fe7728f36c"
  :revdesc "e8ac6baf7f50"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
