;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar" "20260922.132"
  "Citation-related commands for org, latex, markdown."
  '((emacs    "29.1")
    (parsebib "4.2")
    (org      "9.5")
    (citeproc "0.9"))
  :url "https://github.com/emacs-citar/citar"
  :commit "5efc5ac78f235cdaafe361758d03c7a51a015dd1"
  :revdesc "5efc5ac78f23"
  :authors '(("Bruce D'Arcus" . "https://github.com/bdarcus"))
  :maintainers '(("Bruce D'Arcus" . "https://github.com/bdarcus")))
