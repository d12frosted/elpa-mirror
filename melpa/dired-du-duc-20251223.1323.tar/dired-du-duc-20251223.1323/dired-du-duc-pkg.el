;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-du-duc" "20251223.1323"
  "Speed up dired-du with duc."
  '((emacs    "29.1")
    (dired-du "0.5.2"))
  :url "https://github.com/meedstrom/dired-du-duc"
  :commit "a568d5168349ac360690a2f8c5fd05d7a8c7decc"
  :revdesc "a568d5168349"
  :keywords '("files")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
