;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clingo-mode" "20240724.1135"
  "A major mode for editing Answer Set Programs."
  '((emacs "24.3"))
  :url "https://github.com/llaisdy/clingo-mode"
  :commit "feff7d3308a824e918740461e9df636ab67a8874"
  :revdesc "feff7d3308a8"
  :keywords '("asp" "clingo" "answer set programs" "potassco" "major mode" "languages")
  :authors '(("Ivan Uemlianin" . "ivan@llaisdy.com")
             ("Henrik Jürges" . "juerges.henrik@gmail.com"))
  :maintainers '(("Ivan Uemlianin" . "ivan@llaisdy.com")))
