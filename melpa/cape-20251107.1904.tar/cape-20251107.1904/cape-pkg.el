;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20251107.1904"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "58d2a14016bf98639fa8036541cb55236ec53fb0"
  :revdesc "58d2a14016bf"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
