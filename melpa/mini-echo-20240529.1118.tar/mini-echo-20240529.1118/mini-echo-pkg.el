(define-package "mini-echo" "20240529.1118" "Echo buffer status in minibuffer window"
  '((emacs "29.1")
    (dash "2.19.1")
    (hide-mode-line "1.0.3"))
  :commit "f7e9cea2af294422f48577c40da11b2478104eb1" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
