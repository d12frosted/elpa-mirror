(define-package "mew" "20240429.602" "Messaging in the Emacs World" 'nil :commit "06abadce56c8bab3799e6de78aa824a078da9c5d" :authors
  '(("Mew developing team"))
  :maintainers
  '(("Mew developing team"))
  :maintainer
  '("Mew developing team"))
;; Local Variables:
;; no-byte-compile: t
;; End:
