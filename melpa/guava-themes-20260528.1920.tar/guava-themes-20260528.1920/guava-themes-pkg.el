;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260528.1920"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "53032e85478257bbe0cb8c82cd9955bffdd96493"
  :revdesc "53032e854782"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
