;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ninja-mode" "20241031.1344"
  "Major mode for editing .ninja files."
  '((emacs "24"))
  :url "https://github.com/ninja-build/ninja"
  :commit "089af0065cf00d3b3137b7e666a949379051ddf4"
  :revdesc "089af0065cf0"
  :keywords '("languages"))
