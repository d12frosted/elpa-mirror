;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-project-notes" "20261029.1347"
  "Link Denote notes to a project."
  '((emacs  "28.1")
    (denote "3.0.0"))
  :url "https://git.sr.ht/~swflint/denote-project-notes"
  :commit "f48cc3cc08233e574ab40b8c2671a5b6c0fc1ebd"
  :revdesc "f48cc3cc0823"
  :keywords '("convenience")
  :authors '(("Samuel W. Flint" . "swflint@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "swflint@samuelwflint.com")))
