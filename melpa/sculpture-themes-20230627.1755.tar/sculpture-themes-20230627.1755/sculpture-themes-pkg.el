(define-package "sculpture-themes" "20230627.1755" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "bd2cb01bf219c64c422a89769074eab674ad6996" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainers
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
