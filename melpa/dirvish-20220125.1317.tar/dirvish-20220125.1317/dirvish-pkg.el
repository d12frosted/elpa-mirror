(define-package "dirvish" "20220125.1317" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "16aa978151e4859d00bd22e2c228b14430a63653" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
