;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbdb-" "20140221.2354"
  "Provide interface for more easily search/choice than BBDB."
  '((bbdb       "20140123.1541")
    (log4e      "0.2.0")
    (yaxception "0.1"))
  :url "https://github.com/aki2o/bbdb-"
  :commit "2839e84c894de2513af41053e80a277a1b483d22"
  :revdesc "2839e84c894d"
  :keywords '("bbdb" "news" "mail")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
