(define-package "geiser" "20211218.2103" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "476897e4f8a101d808ee0a0a97cc98a46d079af6" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
