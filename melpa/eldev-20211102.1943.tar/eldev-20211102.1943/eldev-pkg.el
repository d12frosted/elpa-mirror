(define-package "eldev" "20211102.1943" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "4a44c72a8cca50677315b1af7dbcae471421ef3f" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
