(define-package "consult" "20230406.1519" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "f93949999d3681dbede5cd88c849199d7adf3d8d" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
