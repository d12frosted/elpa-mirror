(define-package "envrc" "20230803.1124" "Support for `direnv' that operates buffer-locally"
  '((seq "2")
    (emacs "25.1")
    (inheritenv "0.1"))
  :commit "a763eadd28df8078d4331fa1dc71eb8a09ae4582" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("processes" "tools")
  :url "https://github.com/purcell/envrc")
;; Local Variables:
;; no-byte-compile: t
;; End:
