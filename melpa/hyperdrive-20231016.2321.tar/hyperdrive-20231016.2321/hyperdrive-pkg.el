(define-package "hyperdrive" "20231016.2321" "P2P filesystem"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5")
    (transient "0.4.3"))
  :commit "7f2ab3a8b9fc912637aafcd6c361a97c01e317ab" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
