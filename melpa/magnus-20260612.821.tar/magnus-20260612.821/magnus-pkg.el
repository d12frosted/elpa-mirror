;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260612.821"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "b60dd922a5a4975659fa7b32d5da30e261a7439d"
  :revdesc "b60dd922a5a4"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
