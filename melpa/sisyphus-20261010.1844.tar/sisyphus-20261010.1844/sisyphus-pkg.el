;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "20261010.1844"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.7"))
  :url "https://github.com/magit/sisyphus"
  :commit "8249691acf372ddab6d976b47e97316d910c7940"
  :revdesc "8249691acf37"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
