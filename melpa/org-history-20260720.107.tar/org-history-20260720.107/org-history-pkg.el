;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-history" "20260720.107"
  "Show Dates for Org headers from vcs + auto-commit."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-org-history"
  :commit "1ed3069a837ba32947de72d22bf0d3dc3180c0e2"
  :revdesc "1ed3069a837b"
  :keywords '("org" "outline" "vc")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
