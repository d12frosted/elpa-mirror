(define-package "modus-themes" "20220623.605" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "469ff07139ac30e68102563f57010e866680d9f9" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
