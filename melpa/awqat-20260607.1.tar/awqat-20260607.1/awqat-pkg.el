;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awqat" "20260607.1"
  "Islamic prayer times."
  '((emacs "28.1")
    (alert "1.2"))
  :url "https://github.com/zkry/awqat"
  :commit "db533a7bbc5bf2778bd6a62055125afe9447f5c4"
  :revdesc "db533a7bbc5b"
  :authors '(("Zachary Romero" . "zacromero@posteo.net"))
  :maintainers '(("Zachary Romero" . "zacromero@posteo.net")))
