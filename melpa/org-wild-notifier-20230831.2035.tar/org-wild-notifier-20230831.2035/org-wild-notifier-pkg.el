(define-package "org-wild-notifier" "20230831.2035" "Customizable org-agenda notifications"
  '((alert "1.2")
    (async "1.9.3")
    (dash "2.18.0")
    (emacs "24.4"))
  :commit "aa0f2d8ea282dea714ae67f3f5a0471488e6e396" :authors
  '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainers
  '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainer
  '("Artem Khramov" . "akhramov+emacs@pm.me")
  :keywords
  '("notification" "alert" "org" "org-agenda" "agenda")
  :url "https://github.com/akhramov/org-wild-notifier.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
