;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geolocation" "20200317.1559"
  "Get your location on Earth."
  '((request-deferred "0.3.2")
    (deferred         "0.5.1")
    (emacs            "25.1"))
  :url "https://github.com/gonewest818/geolocation.el"
  :commit "08e3569024659f6f04cb269ad213d144fd8e2a95"
  :revdesc "08e356902465"
  :keywords '("hardware")
  :authors '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com"))
  :maintainers '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com")))
