(define-package "lyrics-fetcher" "20220717.1716" "Fetch song lyrics and album covers"
  '((emacs "27")
    (emms "7.5")
    (f "0.20.0")
    (request "0.3.2"))
  :commit "a3be34b0153c2c056dc4b55bbc5fbdc2d9f87549" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/lyrics-fetcher.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
