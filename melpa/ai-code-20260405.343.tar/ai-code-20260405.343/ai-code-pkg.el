;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260405.343"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "cd7cb113c3cf0c2b2ce5d5fa8b03e9d299024640"
  :revdesc "cd7cb113c3cf"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
