(define-package "apheleia" "20231018.1901" "Reformat buffer stably"
  '((emacs "27"))
  :commit "8cccf12df25b08b9b7568ca21c7e9f123b81622e" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
