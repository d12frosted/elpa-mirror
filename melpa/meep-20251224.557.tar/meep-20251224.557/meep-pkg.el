;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251224.557"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "4bc650418af3f2a1c696ecbd6eb4ba77099f58af"
  :revdesc "4bc650418af3"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
