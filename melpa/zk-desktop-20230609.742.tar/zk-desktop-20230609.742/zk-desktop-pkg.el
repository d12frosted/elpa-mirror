(define-package "zk-desktop" "20230609.742" "Desktop environment for zk"
  '((emacs "27.1")
    (zk "0.6")
    (zk-index "0.9"))
  :commit "6ba90de2b33a8717fb1e263fe6df7b3831d3bd8e" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/zk")
;; Local Variables:
;; no-byte-compile: t
;; End:
