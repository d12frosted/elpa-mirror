;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minimal-dashboard" "20251028.819"
  "A very minimal dashboard plugin."
  '((emacs "27.1"))
  :url "https://github.com/dheerajshenoy/minimal-dashboard.el"
  :commit "4424cf776c06320dd4d06aa58aa4ffc392c24def"
  :revdesc "4424cf776c06"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com"))
  :maintainers '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com")))
