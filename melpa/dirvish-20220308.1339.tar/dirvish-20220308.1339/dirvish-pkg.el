(define-package "dirvish" "20220308.1339" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e1e80d3e85912041a34be915bd1af0cae050f2ba" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
