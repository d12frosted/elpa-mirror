(define-package "diff-ansi" "20230501.2304" "Display diff's using alternative diffing tools"
  '((emacs "27.1"))
  :commit "9992b0be2eac8c1bd8051f2ca8de4dc593dc6ff8" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi")
;; Local Variables:
;; no-byte-compile: t
;; End:
