(define-package "phi-search-mc" "20231116.1344" "multiple-cursors extension for phi-search"
  '((phi-search "2.0.0")
    (multiple-cursors "1.2.1")
    (emacs "25.1"))
  :commit "f07b0d442fdd40ddcdcf90be2b38012dcd8d338b" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("search" "cursors")
  :url "https://github.com/knu/phi-search-mc.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
