(define-package "emacsql" "20230220.1858" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "8dd25b030701c1f9c8fe6c38b89399a82dfa558b" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
