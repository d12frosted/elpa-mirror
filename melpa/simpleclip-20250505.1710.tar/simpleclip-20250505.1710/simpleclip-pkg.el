;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simpleclip" "20250505.1710"
  "Simplified access to the system clipboard."
  ()
  :url "https://github.com/rolandwalker/simpleclip"
  :commit "105b7adce212fdc9bbcbe7801531669a658c735b"
  :revdesc "105b7adce212"
  :keywords '("convenience")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
