(define-package "helm" "20240506.444" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.8")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "7be4524864ea1cf974a1adf451695db14b3d916b" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
