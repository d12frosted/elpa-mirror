(define-package "meow" "20220125.1131" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "5bdd9ec796e644b35ab575f876d7da31ee4e6320" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
