;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260221.2307"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "573e98522e4f0ab61d86d725b7a971339ea2e17f"
  :revdesc "573e98522e4f"
  :keywords '("comm")
  :authors '(("Patrick Thomson" . "patrickt@github.com"))
  :maintainers '(("Patrick Thomson" . "patrickt@github.com")))
