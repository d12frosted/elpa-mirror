(define-package "datetime" "20230917.1852" "Parsing, formatting and matching timestamps"
  '((emacs "24.4")
    (extmap "1.1.1"))
  :commit "32e6d3f1f32977a66169a11b38578bc29ceb6f6f" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
