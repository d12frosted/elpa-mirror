;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261118.2346"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "077d05a2d9d64c47af80bc9888b039c8a34e9cf4"
  :revdesc "077d05a2d9d6"
  :keywords '("build tools" "languages"))
