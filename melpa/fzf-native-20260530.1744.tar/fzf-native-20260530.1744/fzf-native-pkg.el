;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260530.1744"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "d50c00ef2bf9781d61d68fa068f18eb87867b1d1"
  :revdesc "d50c00ef2bf9"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
