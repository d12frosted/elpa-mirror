;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dag-draw" "20251117.1418"
  "Draw directed graphs using the GKNV algorithm."
  '((emacs "26.1")
    (dash  "2.19.1")
    (ht    "2.3"))
  :url "https://codeberg.org/trevoke/dag-draw.el"
  :commit "d7e004b32e06073d09b67cab7086695cce7f690d"
  :revdesc "d7e004b32e06"
  :keywords '("tools" "extensions"))
