(define-package "dracula-theme" "20230921.825" "Dracula Theme"
  '((emacs "24.3"))
  :commit "427e0677a755107c232aef2ab201013491ec04cd" :authors
  '(("film42"))
  :maintainers
  '(("Étienne Deparis" . "etienne@depar.is"))
  :maintainer
  '("Étienne Deparis" . "etienne@depar.is")
  :url "https://github.com/dracula/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
