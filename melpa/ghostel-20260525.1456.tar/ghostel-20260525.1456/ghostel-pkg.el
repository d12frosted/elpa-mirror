;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260525.1456"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "45d02cd0abb2dd182b69a43407fa41bed48c305a"
  :revdesc "45d02cd0abb2"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
