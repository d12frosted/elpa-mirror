(define-package "modus-themes" "20210910.1603" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "357ba191a3eff2e3b7aa6870ac2539dc7dba2e44" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
