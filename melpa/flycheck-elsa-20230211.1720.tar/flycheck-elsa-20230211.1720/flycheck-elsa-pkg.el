(define-package "flycheck-elsa" "20230211.1720" "Flycheck for Elsa."
  '((emacs "25")
    (seq "2.0"))
  :commit "b3c81d9b64e805bdc9e72798212a07cc07ccc1ef" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/emacs-elsa/flycheck-elsa")
;; Local Variables:
;; no-byte-compile: t
;; End:
