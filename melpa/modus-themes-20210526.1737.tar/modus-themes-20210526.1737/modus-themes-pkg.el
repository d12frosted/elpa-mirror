(define-package "modus-themes" "20210526.1737" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "6589f7f52a63e4248f07f2f97ef606a9e1ff89f2" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
