;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotate-depth" "20160520.2040"
  "Annotate buffer if indentation depth is beyond threshold."
  ()
  :url "https://github.com/netromdk/annotate-depth"
  :commit "fcb24fa36287250e40d195590c4ca4a8a696277b"
  :revdesc "fcb24fa36287"
  :keywords '("convenience")
  :authors '(("Morten Slot Kristensen" . "mskATnullpointerDOTdk"))
  :maintainers '(("Morten Slot Kristensen" . "mskATnullpointerDOTdk")))
