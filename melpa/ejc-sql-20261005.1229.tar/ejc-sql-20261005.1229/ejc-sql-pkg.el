;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20261005.1229"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "26.3")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "84759a0e7c5ca6360e04144e18c78044c39ab5bc"
  :revdesc "84759a0e7c5c"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
