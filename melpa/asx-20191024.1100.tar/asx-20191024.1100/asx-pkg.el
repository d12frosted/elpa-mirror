;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asx" "20191024.1100"
  "Ask StackExchange/StackOverflow."
  '((emacs "26.1"))
  :url "https://github.com/ragone/asx"
  :commit "5ca12cc51bb02b5926adf9a7976ba9ca08a1ea21"
  :revdesc "5ca12cc51bb0"
  :keywords '("convenience")
  :authors '(("Alex Ragone" . "ragonedk@gmail.com"))
  :maintainers '(("Alex Ragone" . "ragonedk@gmail.com")))
