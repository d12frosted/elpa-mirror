(define-package "promise" "20200114.633" "Promises/A+"
  '((emacs "25.1"))
  :commit "53e1dfe9a8bd613fdfa31944e5259dcdd3a29e12" :authors
  '(("chuntaro" . "chuntaro@sakura-games.jp"))
  :maintainer
  '("chuntaro" . "chuntaro@sakura-games.jp")
  :keywords
  '("async" "promise" "convenience")
  :url "https://github.com/chuntaro/emacs-promise")
;; Local Variables:
;; no-byte-compile: t
;; End:
