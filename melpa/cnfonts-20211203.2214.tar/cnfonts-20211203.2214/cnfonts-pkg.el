(define-package "cnfonts" "20211203.2214" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "a86a08a3b22e794d6527acc8ef1a432556e25dde" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
