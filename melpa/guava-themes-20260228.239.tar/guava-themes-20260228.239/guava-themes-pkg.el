;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260228.239"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "33ae78b9dfcd4c4dab44e5bd839baa1ab855d466"
  :revdesc "33ae78b9dfcd"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
