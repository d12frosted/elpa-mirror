;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260412.1616"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "d6ed3eec0209d0bdb7fc9354195e40933b855384"
  :revdesc "d6ed3eec0209"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
