(define-package "spdx" "20220518.117" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "e23ac498e9c96f5e93569271d192e6c247134412" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
