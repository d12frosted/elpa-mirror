;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251104.1631"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "b2cc4ad0391376f310faa6bb6137477d5b0266e0"
  :revdesc "b2cc4ad03913"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
