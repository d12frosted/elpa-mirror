;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251124.1008"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "0730b280457501f0cc52e413ca48a7f3dbbd2108"
  :revdesc "0730b2804575"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
