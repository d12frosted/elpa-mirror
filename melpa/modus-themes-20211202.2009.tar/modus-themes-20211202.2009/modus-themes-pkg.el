(define-package "modus-themes" "20211202.2009" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "b83cd68508143e10a3ea7fb5aa97736969c6ef35" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
