;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-howm" "20251030.1600"
  "Calendar view for howm."
  '((emacs "28.1")
    (calfw "2.0")
    (howm  "1.5.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "c34b6afaee33392e0bcd18441588e9a502f368eb"
  :revdesc "c34b6afaee33"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
