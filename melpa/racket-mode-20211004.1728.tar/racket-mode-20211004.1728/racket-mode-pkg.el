(define-package "racket-mode" "20211004.1728" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "794f737c5a1702a99e8f81c2bc14a25b57ffc312" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
