;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacemacs-theme" "20260812.1549"
  "Color theme with a dark and light versions."
  '((emacs "24"))
  :url "https://github.com/nashamri/spacemacs-theme"
  :commit "c1617a86bc18ae611b0c0cf1d51e5906a2676c6b"
  :revdesc "c1617a86bc18"
  :keywords '("color" "theme"))
