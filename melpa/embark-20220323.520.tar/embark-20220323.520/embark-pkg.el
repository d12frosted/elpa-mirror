(define-package "embark" "20220323.520" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "123ad4752c4877dc38abce2a9392f1d7bfe35bf9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
