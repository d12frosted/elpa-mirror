(define-package "skeletor" "20191129.841" "Provides project skeletons for Emacs"
  '((s "1.7.0")
    (f "0.14.0")
    (dash "2.2.0")
    (cl-lib "0.3")
    (let-alist "1.0.3")
    (emacs "24.1"))
  :commit "dd7283e2141019e2880bb6c1d1604feb29b0f26d" :authors
  '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainer
  '("Chris Barrett" . "chris.d.barrett@me.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
