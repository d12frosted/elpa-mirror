;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dag-draw" "20260627.2238"
  "Draw directed graphs using the GKNV algorithm."
  '((emacs "26.1")
    (dash  "2.19.1")
    (ht    "2.3"))
  :url "https://codeberg.org/trevoke/dag-draw.el"
  :commit "c20b3c28781f1d768116a2cc601a4e8d0058e2ba"
  :revdesc "c20b3c28781f"
  :keywords '("tools" "extensions"))
