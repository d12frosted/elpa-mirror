(define-package "kotlin-ts-mode" "20231114.1243" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "9688741a59a5ffd71850660dd320b0309a2ba119" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
