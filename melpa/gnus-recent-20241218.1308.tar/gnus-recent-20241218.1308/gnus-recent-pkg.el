;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-recent" "20241218.1308"
  "Article breadcrumbs for Gnus."
  '((emacs "25.3.2"))
  :url "https://github.com/unhammer/gnus-recent"
  :commit "9cd9797c2aa54be4ca03b5ca0c50b64c4dc1d34e"
  :revdesc "9cd9797c2aa5"
  :keywords '("convenience" "mail")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
