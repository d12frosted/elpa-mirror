(define-package "elisp-autofmt" "20230204.1214" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "a33340ccee2bed8aa15db6024721a29b1bffcd01" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
