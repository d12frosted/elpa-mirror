;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260628.1217"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "01fc13461f03a69596a30abefe8396a7063ee606"
  :revdesc "01fc13461f03"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
