(define-package "autocrypt" "20210720.1810" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "b2c8d431f89788d1e01d42c55e65612e6fc11b44" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "philipk@posteo.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
