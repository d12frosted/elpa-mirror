(define-package "mb-url" "20220921.1844" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "a578d302ae1d22cbecfc505107fc78906643b804" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
