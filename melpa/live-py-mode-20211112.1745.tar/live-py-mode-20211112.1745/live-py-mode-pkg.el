(define-package "live-py-mode" "20211112.1745" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "806465e20fd4c0faf8475a70e03fc287fcb0b079" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
