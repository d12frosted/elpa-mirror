;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edts" "20250214.2310"
  "Erlang Development Tool Suite."
  '((auto-complete         "20201213.1255")
    (auto-highlight-symbol "20211106.638")
    (dash                  "20210609.1330")
    (emacs                 "24.3")
    (erlang                "20210315.1640")
    (f                     "20191110.1357")
    (popup                 "20210317.138")
    (s                     "20210603.736"))
  :url "https://github.com/sebastiw/edts"
  :commit "5481bcbe61f2843fbb939daac5a32e59b9acfd69"
  :revdesc "5481bcbe61f2"
  :keywords '("erlang" "tools" "programming" "development")
  :authors '(("Thomas Järvstrand" . "tjarvstrand@gmail.com")
             ("Sebastian Weddmark Olsson" . "visnae@gmail.com"))
  :maintainers '(("Thomas Järvstrand" . "tjarvstrand@gmail.com")
                 ("Sebastian Weddmark Olsson" . "visnae@gmail.com")))
