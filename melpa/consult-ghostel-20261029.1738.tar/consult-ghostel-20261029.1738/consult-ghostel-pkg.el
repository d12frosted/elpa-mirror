;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "20261029.1738"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "2c13feaa31da8a55a0471210cd26414d7265ee1e"
  :revdesc "2c13feaa31da"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
