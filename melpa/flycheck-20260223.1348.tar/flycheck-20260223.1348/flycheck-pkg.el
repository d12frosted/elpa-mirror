;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260223.1348"
  "On-the-fly syntax checking."
  '((emacs "27.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "c1cf9df01162a5d91634b4528be6a4d0a468ca48"
  :revdesc "c1cf9df01162"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
