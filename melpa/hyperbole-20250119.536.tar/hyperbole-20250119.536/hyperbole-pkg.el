;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250119.536"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "cbbf963a9f55f5cdfd7cc3f0909ec34678de3972"
  :revdesc "cbbf963a9f55"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
