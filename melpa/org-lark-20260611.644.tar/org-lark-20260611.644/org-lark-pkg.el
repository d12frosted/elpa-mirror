;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "20260611.644"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "dbb12fae2ba71e3dfecb5b13c1494ce5aff9b9e1"
  :revdesc "dbb12fae2ba7"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
