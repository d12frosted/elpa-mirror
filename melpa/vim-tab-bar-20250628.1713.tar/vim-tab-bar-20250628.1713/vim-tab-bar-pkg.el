;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20250628.1713"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "043c7e628334ff283b72b62af6bde97f725465ce"
  :revdesc "043c7e628334"
  :keywords '("frames"))
