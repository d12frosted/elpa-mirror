;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol" "20260520.1852"
  "Provide fever/newsblur/owncloud/ttrss protocols for elfeed."
  '((emacs  "24.4")
    (elfeed "2.1.1")
    (cl-lib "0.5"))
  :url "https://github.com/fasheng/elfeed-protocol"
  :commit "0dbce7ddf47f66ce005aff057b2305971759a084"
  :revdesc "0dbce7ddf47f"
  :keywords '("news")
  :authors '(("Xu Fasheng" . "fasheng[AT]fasheng.info"))
  :maintainers '(("Xu Fasheng" . "fasheng[AT]fasheng.info")))
