;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260511.1313"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "0db38afafbe15e4b046b2c2d354f7292304c5897"
  :revdesc "0db38afafbe1"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
