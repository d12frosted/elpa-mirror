;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260113.536"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "02c80a6249daf9ceee4049441d48e460ec178ee8"
  :revdesc "02c80a6249da"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
