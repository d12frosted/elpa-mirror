;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260707.604"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "9b1114241427f4d80436a1a901c3375333a626a9"
  :revdesc "9b1114241427"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
