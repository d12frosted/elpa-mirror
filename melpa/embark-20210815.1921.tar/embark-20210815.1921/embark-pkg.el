(define-package "embark" "20210815.1921" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "b20de98c55833e0af38d82f8e698ec9f49157278" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
