(define-package "meow" "20220907.600" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "41c6e12329046d9e6ab4dbddae6bc234c589d28c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
