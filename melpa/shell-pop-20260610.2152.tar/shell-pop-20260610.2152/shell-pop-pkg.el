;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260610.2152"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "03ad7edfa7422b8ebbc1c22baf0cf71aead15331"
  :revdesc "03ad7edfa742"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
