(define-package "fennel-mode" "20220327.1825" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "e3382dcbe1c822d06a57ed1e5637198e74fd2aab" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
