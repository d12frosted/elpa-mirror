(define-package "lesim-mode" "20230608.1344" "Major mode for Learning Simulator scripts"
  '((emacs "28.1"))
  :commit "9fd94af69ee08b4969d721f9aa227e7d85153ee1" :authors
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainer
  '("Stefano Ghirlanda" . "drghirlanda@gmail.com")
  :keywords
  '("languages" "faces")
  :url "https://github.com/drghirlanda/lesim-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
