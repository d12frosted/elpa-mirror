;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20250423.1122"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "http://github.com/clojure-emacs/clojure-ts-mode"
  :commit "605adba8babdc82013cd9a9a9f15a8f3ae587e64"
  :revdesc "605adba8babd"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
