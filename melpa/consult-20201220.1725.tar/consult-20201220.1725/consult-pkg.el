(define-package "consult" "20201220.1725" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "27d7e3e1d715ca4217ce118f1ed4983c8c5dccca" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
