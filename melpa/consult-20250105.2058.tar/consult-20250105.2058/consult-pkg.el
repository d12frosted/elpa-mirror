;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250105.2058"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "c8e0606076999f28ef25a2a1cdec7bfed572dc81"
  :revdesc "c8e060607699"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
