(define-package "phpactor" "20221020.1638" "Interface to Phpactor"
  '((emacs "25.1")
    (f "0.17")
    (php-runtime "0.2")
    (composer "0.2.0")
    (async "1.9.3"))
  :commit "209337f6327c18b17c326bd57a4529511c6fd55d" :authors
  '(("USAMI Kenta" . "tadsan@zonu.me")
    ("Mikael Kermorgant" . "mikael@kgtech.fi"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("tools" "php")
  :url "https://github.com/emacs-php/phpactor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
