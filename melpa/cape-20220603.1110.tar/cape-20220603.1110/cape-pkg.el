(define-package "cape" "20220603.1110" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "de4532bbce98ac4e10fd6db0e9c14f9c4f2cd91c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
