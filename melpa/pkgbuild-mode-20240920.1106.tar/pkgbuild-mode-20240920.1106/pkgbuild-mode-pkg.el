(define-package "pkgbuild-mode" "20240920.1106" "Interface to the Arch Linux package manager"
  '((emacs "26.1"))
  :commit "5325a334a5dde34e38a8dbab81029837ef84391a" :authors
  '(("Juergen Hoetzel" . "juergen@hoetzel.info"))
  :maintainers
  '(("Juergen Hoetzel" . "juergen@hoetzel.info"))
  :maintainer
  '("Juergen Hoetzel" . "juergen@hoetzel.info")
  :keywords
  '("languages")
  :url "https://github.com/juergenhoetzel/pkgbuild-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
