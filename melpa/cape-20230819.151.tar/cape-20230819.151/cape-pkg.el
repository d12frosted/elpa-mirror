(define-package "cape" "20230819.151" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "df831c35aa0eb73d238ef8297b9273b0e7b69b80" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
