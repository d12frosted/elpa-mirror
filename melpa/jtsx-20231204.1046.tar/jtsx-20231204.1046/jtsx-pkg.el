(define-package "jtsx" "20231204.1046" "Extends default support for JSX/TSX"
  '((emacs "29.1"))
  :commit "b088a4c7d75be498fbda92828da91d5cef75a79e" :authors
  '(("Loïc Lemaître" . "loic.lemaitre@gmail.com"))
  :maintainers
  '(("Loïc Lemaître" . "loic.lemaitre@gmail.com"))
  :maintainer
  '("Loïc Lemaître" . "loic.lemaitre@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/llemaitre19/jtsx")
;; Local Variables:
;; no-byte-compile: t
;; End:
