(define-package "consult-lsp" "20210928.1113" "LSP-mode Consult integration"
  '((emacs "27.1")
    (lsp-mode "5.0")
    (consult "0.9")
    (f "0.20.0"))
  :commit "8ed43c6eaaf3ff8963861fa3234e81683be91e45" :authors
  '(("Gerry Agbobada"))
  :maintainer
  '("Gerry Agbobada")
  :keywords
  '("tools" "completion" "lsp")
  :url "https://github.com/gagbo/consult-lsp")
;; Local Variables:
;; no-byte-compile: t
;; End:
