;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mpv-notes" "20241222.107"
  "Take notes in org mode while watching videos in mpv."
  '((emacs "28.1"))
  :url "https://github.com/bpanthi977/org-mpv-notes"
  :commit "3222a917efceb903d6052e57f7967d9e38926a81"
  :revdesc "3222a917efce"
  :authors '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainers '(("Bibek Panthi" . "bpanthi977@gmail.com")))
