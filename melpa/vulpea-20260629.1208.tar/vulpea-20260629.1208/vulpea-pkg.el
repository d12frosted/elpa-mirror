;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260629.1208"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "2623e12a96328478d2d90ca3ef3c38ba03869d76"
  :revdesc "2623e12a9632"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
