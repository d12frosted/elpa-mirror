;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260501.1441"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "cf0044518fb4d35f93464a18f98c4e863981b045"
  :revdesc "cf0044518fb4"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
