(define-package "chronometrist" "20220123.512" "Friendly and powerful time tracker and analyzer"
  '((emacs "27.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "4ddc06c084c921cda5995b1bba9999db3ff01c4b" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
