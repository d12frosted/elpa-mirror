;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20261113.915"
  "Pure Elisp HTTP server."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "2777955684eb8724757014de03e7834640d37423"
  :revdesc "2777955684eb"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
