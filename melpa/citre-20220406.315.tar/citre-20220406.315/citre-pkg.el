(define-package "citre" "20220406.315" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "0ae60846b0b58f09ea463f603bcc3f414a8fb35d" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
