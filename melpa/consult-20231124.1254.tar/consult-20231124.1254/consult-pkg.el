(define-package "consult" "20231124.1254" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "36a5aeb12a32319c1efc8a397ea09219d62cc763" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
