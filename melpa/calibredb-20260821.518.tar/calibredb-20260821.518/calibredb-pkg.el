;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calibredb" "20260821.518"
  "Yet another calibre client."
  '((emacs     "29.1")
    (org       "9.3")
    (transient "0.1.0")
    (s         "1.12.0")
    (dash      "2.17.0")
    (request   "0.3.3")
    (esxml     "0.3.7"))
  :url "https://github.com/chenyanming/calibredb.el"
  :commit "4fefffd7018365677e6fc4cdbcd8b6041a4c0b18"
  :revdesc "4fefffd70183"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
