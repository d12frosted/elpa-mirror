;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20260315.1455"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "5f6de169a937545a9c5551c6944fe822ec23ce27"
  :revdesc "5f6de169a937"
  :keywords '("maint"))
