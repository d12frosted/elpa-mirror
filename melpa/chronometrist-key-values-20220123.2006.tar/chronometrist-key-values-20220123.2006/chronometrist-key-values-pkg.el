(define-package "chronometrist-key-values" "20220123.2006" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "a83173d0a9efc0d785a18a88f62f60a46c02c5f2" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
