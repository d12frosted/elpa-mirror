(define-package "chronometrist-key-values" "20220123.2006" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "406c23275ca3aef4a19958b882484ed7e5a4f12e" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
