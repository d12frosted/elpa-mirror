(define-package "emms" "20210417.2055" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (seq "0"))
  :commit "f992e4c98b1d472acb802ea2a149f087c2656034" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
