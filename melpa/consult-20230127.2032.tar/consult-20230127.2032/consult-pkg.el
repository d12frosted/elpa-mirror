(define-package "consult" "20230127.2032" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "1710aec5a2714f4b4f18b013b7edaed2bbaf5653" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
