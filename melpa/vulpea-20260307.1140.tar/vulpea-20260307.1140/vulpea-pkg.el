;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260307.1140"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "a81e4995424f747975633f0361303b85f157dc8f"
  :revdesc "a81e4995424f"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
