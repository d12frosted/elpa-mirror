(define-package "helm" "20220603.851" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.4")
    (popup "0.5.3"))
  :commit "8ec4ce04b54c5f681161ac9f566dc4e9a7429802" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
