(define-package "yeetube" "20230928.517" "YouTube Front End"
  '((emacs "27.2"))
  :commit "10cf200dcd7aa69c533c603d94e156c00fbe0727" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.com/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
