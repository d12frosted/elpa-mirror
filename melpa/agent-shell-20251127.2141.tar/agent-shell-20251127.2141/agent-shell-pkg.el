;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251127.2141"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b045cccd9ee940dd092af527af6060a10207e23c"
  :revdesc "b045cccd9ee9")
