;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20251115.913"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/dicom"
  :commit "7f36f2ae2c91b0d9c8de317e35830e44e7c93372"
  :revdesc "7f36f2ae2c91"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
