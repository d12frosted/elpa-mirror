;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260622.1322"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "ef657f82c4fea69a798372ec6147820bac766bec"
  :revdesc "ef657f82c4fe"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
