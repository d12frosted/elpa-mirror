;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250427.704"
  "A modern file manager based on dired mode."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "e8ec5765da1284be88b0cbf190362205a31fb19a"
  :revdesc "e8ec5765da12"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
