;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250702.1113"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "4a5fa703463baa7797e2a86ed3c4832720ea6a85"
  :revdesc "4a5fa703463b"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
