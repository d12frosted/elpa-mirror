(define-package "mastodon" "20230128.1300" "Client for Mastodon, a federated social network"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4")
    (ts "0.3"))
  :commit "83f250f4daed1c0b72f8d9f2f4101786d1bfadf8" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
