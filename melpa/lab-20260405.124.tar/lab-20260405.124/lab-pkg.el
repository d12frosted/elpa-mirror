;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "20260405.124"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "953e899dee5a720e7edd94eaeb2a928fef881e0e"
  :revdesc "953e899dee5a"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
