(define-package "tempel" "20230810.1031" "Tempo templates/snippets with in-buffer field editing"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "9656b27ff7f0144728831110514c016050fffb21" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "languages" "tools" "wp")
  :url "https://github.com/minad/tempel")
;; Local Variables:
;; no-byte-compile: t
;; End:
