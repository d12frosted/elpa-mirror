;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260114.2349"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a9ddd7bb069115353d41ec352427509b07fa634f"
  :revdesc "a9ddd7bb0691"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
