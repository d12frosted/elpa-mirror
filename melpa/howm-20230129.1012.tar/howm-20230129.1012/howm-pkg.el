(define-package "howm" "20230129.1012" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "f4b2c9ec980062d6c1eb57d8633fa0a1b7204b7c" :authors
  '(("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
