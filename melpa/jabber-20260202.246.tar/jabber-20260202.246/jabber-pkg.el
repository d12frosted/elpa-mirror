;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260202.246"
  "A minimal Jabber client."
  '((emacs "27.1")
    (fsm   "0.2.0")
    (srv   "0.2"))
  :url "https://codeberg.org/emacs-jabber/emacs-jabber"
  :commit "308e003048ce5c01abe248bc5fd6e3df697f54f2"
  :revdesc "308e003048ce"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("wgreenhouse" . "wgreenhouse@tilde.club")))
