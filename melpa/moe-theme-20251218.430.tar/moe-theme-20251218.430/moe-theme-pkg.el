;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moe-theme" "20251218.430"
  "A colorful eye-candy theme. Moe, moe, kyun!."
  ()
  :url "https://github.com/kuanyui/moe-theme.el"
  :commit "19eb91a49d15d75816609b44dc13f00548e0b274"
  :revdesc "19eb91a49d15"
  :keywords '("themes")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
