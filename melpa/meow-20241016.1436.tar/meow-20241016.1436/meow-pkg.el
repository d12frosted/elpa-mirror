;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241016.1436"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "a7364a99b866fd1d3fb793a7d8c3e5ae2cf1fe97"
  :revdesc "a7364a99b866"
  :keywords '("convenience" "modal-editing"))
