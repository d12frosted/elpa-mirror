(define-package "humanoid-themes" "20210523.1021" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "703756e1eaf9fa6ca9d51556cdac017396f3d085" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
