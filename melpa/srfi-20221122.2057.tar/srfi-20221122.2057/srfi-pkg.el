(define-package "srfi" "20221122.2057" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "7123b49b83aa76a8e3f14afbd04184f92e2ebaba" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
