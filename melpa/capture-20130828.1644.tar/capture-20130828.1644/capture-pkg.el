(define-package "capture" "20130828.1644" "screencasting with \"avconv\" or \"ffmpeg\"" 'nil :commit "9140c207b48b3520a2f06674b3e1bee2fc92b80c" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>"))
;; Local Variables:
;; no-byte-compile: t
;; End:
