(define-package "boon" "20201118.1521" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (expand-region "0.10.0")
    (dash "2.12.0")
    (multiple-cursors "1.3.0"))
  :commit "3dd9669d01e48860bb7ea12be8c764a4bc6808ea")
;; Local Variables:
;; no-byte-compile: t
;; End:
