(define-package "julia-snail" "20211204.1553" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (vterm "0.0.1"))
  :commit "18a88cb33acfc2f349bf63d1e3d6b189ac8fe162" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
