;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "20261117.1608"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "5e7bde282c9c7e1073463f9f76c94d185e24383a"
  :revdesc "5e7bde282c9c"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
