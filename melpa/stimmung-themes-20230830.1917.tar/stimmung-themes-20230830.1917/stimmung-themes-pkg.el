(define-package "stimmung-themes" "20230830.1917" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "9a763725249dfa1a2644b5f26a8cfedfba312eee" :authors
  '(("Love Lagerkvist"))
  :maintainers
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
