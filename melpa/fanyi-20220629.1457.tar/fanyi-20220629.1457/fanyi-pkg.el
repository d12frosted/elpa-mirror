(define-package "fanyi" "20220629.1457" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "45eb63f62c24a9d3ceaa6f7d30e63920fdeefca3" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
