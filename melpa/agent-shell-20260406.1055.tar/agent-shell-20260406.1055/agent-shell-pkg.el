;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260406.1055"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ef9cfa6340bf4f13490b40e04e2d4a202d40bfed"
  :revdesc "ef9cfa6340bf")
