;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "musicbrainz-interactive" "20260721.357"
  "Interactive commands for MusicBrainz related things."
  '((emacs       "28.1")
    (musicbrainz "0.1"))
  :url "https://github.com/zzkt/metabrainz"
  :commit "67dba8b5c29e76305c62a0e877f4135aa60343bd"
  :revdesc "67dba8b5c29e"
  :keywords '("data" "convenience" "music")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
