;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20250516.740"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.1.0.0")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "70791e2c97f6422568ca6a3398be844a905dfabc"
  :revdesc "70791e2c97f6"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
