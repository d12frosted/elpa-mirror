;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260711.827"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "fc6a4d1ec6edba6b3c65b3f069cce0398c2fb7a5"
  :revdesc "fc6a4d1ec6ed"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
