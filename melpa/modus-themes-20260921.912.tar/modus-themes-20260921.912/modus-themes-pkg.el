;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260921.912"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "4fcc8d00540a81936a213d608a69c4c85df8f970"
  :revdesc "4fcc8d00540a"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
