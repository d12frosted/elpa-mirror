;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260518.21"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "616479afdf0e2f6b8f6f0c719402c33b1fdd9238"
  :revdesc "616479afdf0e"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
