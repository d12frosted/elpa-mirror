;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260513.243"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "ee01c5b6d9a173e53bb5e8a49d0ab7a3e8f9705c"
  :revdesc "ee01c5b6d9a1"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
