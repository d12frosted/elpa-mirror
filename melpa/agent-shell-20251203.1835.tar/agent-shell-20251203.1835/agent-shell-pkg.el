;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251203.1835"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "262436dff883b02c38f783b79dfe162193d3641c"
  :revdesc "262436dff883")
