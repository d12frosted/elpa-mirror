(define-package "spdx" "20220311.108" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "8ca8d0df3b9ab149a94d94f6c5e74fd526262057" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
