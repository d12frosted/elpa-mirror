;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251206.1903"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "44cdf2f387dfc91651a580727cc2c7ebab3440e7"
  :revdesc "44cdf2f387df")
