(define-package "citar-denote" "20230708.403" "Minor mode to integrate Citar and Denote"
  '((emacs "28.1")
    (citar "1.1")
    (denote "1.2.0")
    (dash "2.19.1"))
  :commit "2107142e3c621aa64f95c7820d4b12b69f1763f4" :authors
  '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers
  '(("Peter Prevos" . "peter@prevos.net"))
  :maintainer
  '("Peter Prevos" . "peter@prevos.net")
  :url "https://github.com/pprevos/citar-denote")
;; Local Variables:
;; no-byte-compile: t
;; End:
