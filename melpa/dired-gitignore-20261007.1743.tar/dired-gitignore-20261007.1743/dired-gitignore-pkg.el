;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-gitignore" "20261007.1743"
  "A minor mode to hide gitignored files in a dired buffer."
  '((emacs "26.1"))
  :url "https://github.com/johannes-mueller/dired-gitignore.el"
  :commit "0c26270f74232645512674a48cf51fa3660c1f8f"
  :revdesc "0c26270f7423"
  :keywords '("dired" "convenience" "git")
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
