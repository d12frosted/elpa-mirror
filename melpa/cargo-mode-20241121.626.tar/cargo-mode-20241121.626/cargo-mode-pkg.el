;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cargo-mode" "20241121.626"
  "Cargo Major Mode. Cargo is the Rust package manager."
  '((emacs "25.1"))
  :url "https://github.com/ayrat555/cargo-mode"
  :commit "9325ee0d12a0ae870785d2e296ad3a0d0cfcb0a2"
  :revdesc "9325ee0d12a0"
  :keywords '("tools")
  :authors '(("Ayrat Badykov" . "ayratin555@gmail.com"))
  :maintainers '(("Ayrat Badykov" . "ayratin555@gmail.com")))
