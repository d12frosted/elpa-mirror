;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "s12cpuv2-mode" "20171013.2051"
  "Major-mode for S12CPUV2 assembly."
  '((emacs "24.3"))
  :url "https://github.com/AdamNiederer/s12cpuv2-mode"
  :commit "b17d4cf848dec1e20e66458e5c7ff77a2c051a8c"
  :revdesc "b17d4cf848de"
  :keywords '("s12cpuv2" "assembly" "languages")
  :authors '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainers '(("Adam Niederer" . "adam.niederer@gmail.com")))
