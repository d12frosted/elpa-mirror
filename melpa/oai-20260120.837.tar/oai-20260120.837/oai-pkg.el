;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260120.837"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "7e43fb235b3b48cf27bb3efdf1b70bc100b916d7"
  :revdesc "7e43fb235b3b"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
