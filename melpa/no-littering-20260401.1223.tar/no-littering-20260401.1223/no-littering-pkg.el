;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260401.1223"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "db60be0939f31eae0cfc537918503a13b028fa56"
  :revdesc "db60be0939f3"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
