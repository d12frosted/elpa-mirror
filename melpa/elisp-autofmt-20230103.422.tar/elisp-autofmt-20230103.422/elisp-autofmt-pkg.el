(define-package "elisp-autofmt" "20230103.422" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "9e5227ace5b1a86c0387bf3c4dd6a669c9e10442" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
