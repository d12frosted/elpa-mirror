;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "20261121.759"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "31f8199eae0d5fc75a6183469a0d6559ea6f2307"
  :revdesc "31f8199eae0d"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
