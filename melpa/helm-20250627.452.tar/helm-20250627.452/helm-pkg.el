;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250627.452"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "aa560fa3c1808ae9e6f65d18751ec8a96c98ebf3"
  :revdesc "aa560fa3c180"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
