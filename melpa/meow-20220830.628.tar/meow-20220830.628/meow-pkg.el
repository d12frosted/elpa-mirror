(define-package "meow" "20220830.628" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "6263d32a38d0447f43a718a584a464029e7b68ab" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
