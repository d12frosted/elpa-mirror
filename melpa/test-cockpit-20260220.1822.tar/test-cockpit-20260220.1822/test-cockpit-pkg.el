;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260220.1822"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "728af885767f13892135e85f6dd6db8af404e5d3"
  :revdesc "728af885767f"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
