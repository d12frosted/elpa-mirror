(define-package "zk-index" "20230505.2118" "Index for zk"
  '((emacs "27.1")
    (zk "0.3"))
  :commit "b9f5433486e79a23e82035be3e10d8f5678b2880" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/zk")
;; Local Variables:
;; no-byte-compile: t
;; End:
