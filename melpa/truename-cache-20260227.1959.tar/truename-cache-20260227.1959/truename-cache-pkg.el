;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260227.1959"
  "Efficiently de-dup file-names."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "435c1d0256c9fbb18314e2a2b4eec87fb4f20703"
  :revdesc "435c1d0256c9"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
