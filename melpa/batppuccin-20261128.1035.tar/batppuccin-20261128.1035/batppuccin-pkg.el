;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "20261128.1035"
  "Batppuccin (Catppuccin) color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "2a12b26f765a6a35855e051ece0945812b9e60c4"
  :revdesc "2a12b26f765a"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
