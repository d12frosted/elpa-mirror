(define-package "pyim-basedict" "20170726.1515" "The default pinyin dict of pyim" 'nil :commit "f71d0ffd9d2421f2b51cd0ccb89fd9eb43c09585" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/tumashu/pyim-basedict")
;; Local Variables:
;; no-byte-compile: t
;; End:
