(define-package "embark" "20220223.2258" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "f741dab05b09beb18e0a7e87f5b80ea462ca44a2" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
