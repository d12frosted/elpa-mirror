;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-c-headers" "20200816.1007"
  "Auto-complete source for C headers."
  '((auto-complete "1.3.1"))
  :url "http://zk-phi.gitub.io/"
  :commit "67e1e86a48c9bed57bc7ce5ce2553ad203f5752e"
  :revdesc "67e1e86a48c9")
