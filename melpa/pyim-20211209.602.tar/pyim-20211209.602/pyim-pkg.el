(define-package "pyim" "20211209.602" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "24.4")
    (async "1.6")
    (xr "1.13"))
  :commit "9c52fd9eecd2729cfc85f5500cb61ea7ac4574ec" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
