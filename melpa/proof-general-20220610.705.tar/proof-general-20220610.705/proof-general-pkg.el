(define-package "proof-general" "20220610.705" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "3bbe326bf2789bea90eed563dfb2895c54a6e7df" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
