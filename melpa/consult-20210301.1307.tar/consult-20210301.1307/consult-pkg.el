(define-package "consult" "20210301.1307" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "892d594f9487445f3fddeefc5c4f233813d8c141" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
