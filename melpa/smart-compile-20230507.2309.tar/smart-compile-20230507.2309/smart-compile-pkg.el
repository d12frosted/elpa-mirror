(define-package "smart-compile" "20230507.2309" "an interface to `compile'" 'nil :commit "dfa6a49ced30720336be3d1fabbab4d6e0c787f0" :authors
  '(("Seiji Zenitani" . "zenitani@gmail.com"))
  :maintainers
  '(("Seiji Zenitani" . "zenitani@gmail.com"))
  :maintainer
  '("Seiji Zenitani" . "zenitani@gmail.com")
  :keywords
  '("tools" "unix"))
;; Local Variables:
;; no-byte-compile: t
;; End:
