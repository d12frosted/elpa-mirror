(define-package "orgmdb" "20230522.1817" "An OMDb API client with some convenience functions"
  '((emacs "27.1")
    (dash "2.11.0")
    (s "1.12.0")
    (org "8.0.0"))
  :commit "292a58b3bd19b61d24d897efefeee1a309a666fd" :authors
  '(("Isa Mert Gurbuz" . "isamert@protonmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamert@protonmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamert@protonmail.com")
  :url "https://github.com/isamert/orgmdb")
;; Local Variables:
;; no-byte-compile: t
;; End:
