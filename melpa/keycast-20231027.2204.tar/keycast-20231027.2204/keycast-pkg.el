(define-package "keycast" "20231027.2204" "Show current command and its binding"
  '((emacs "25.3")
    (compat "29.1.4.1"))
  :commit "0a1cd94dfe047e60912791439e03caed0fdcaa0b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("multimedia")
  :url "https://github.com/tarsius/keycast")
;; Local Variables:
;; no-byte-compile: t
;; End:
