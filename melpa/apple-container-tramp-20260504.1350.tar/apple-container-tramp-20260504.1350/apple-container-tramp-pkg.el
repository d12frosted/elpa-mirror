;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apple-container-tramp" "20260504.1350"
  "TRAMP integration for apple container."
  '((emacs "24.3"))
  :url "https://github.com/major1201/apple-container-tramp.el"
  :commit "f47d58d029c594f4c9e9b1cfff79630de68a9cb5"
  :revdesc "f47d58d029c5")
