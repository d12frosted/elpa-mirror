(define-package "bqn-mode" "20230415.1105" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "b1f7f062b87dc5de84e0f00b7b5d895bf862af90" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
