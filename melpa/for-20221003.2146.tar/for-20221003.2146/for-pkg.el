(define-package "for" "20221003.2146" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "e82e63f5235d22901c4774eef3ff3d17df6472b7" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
