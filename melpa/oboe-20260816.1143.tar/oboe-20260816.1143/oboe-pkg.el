;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260816.1143"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "b81cc19f474ed33a10958853f503428d271d1c2c"
  :revdesc "b81cc19f474e"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
