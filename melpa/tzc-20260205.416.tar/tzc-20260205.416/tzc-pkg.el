;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260205.416"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "99d0420aeed0565c0e5b12a1ecc4836764a4950f"
  :revdesc "99d0420aeed0"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
