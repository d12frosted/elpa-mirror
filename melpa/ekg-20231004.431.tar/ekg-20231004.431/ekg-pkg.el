(define-package "ekg" "20231004.431" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.1.1"))
  :commit "cec144245bf7adbd4761bd5be39471c31f33410a" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
