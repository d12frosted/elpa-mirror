;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20241125.1532"
  "Miasma: color theme inspired by the woods."
  ()
  :url "https://github.com/daut/miasma-theme.el"
  :commit "b36d6a770eab9be25ddb284f73db76726423a57b"
  :revdesc "b36d6a770eab")
