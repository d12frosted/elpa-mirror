;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260214.1520"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "http://github.com/bbatsov/neocaml"
  :commit "6880bf30c54e82afb9b8f83655be8b025494a847"
  :revdesc "6880bf30c54e"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
