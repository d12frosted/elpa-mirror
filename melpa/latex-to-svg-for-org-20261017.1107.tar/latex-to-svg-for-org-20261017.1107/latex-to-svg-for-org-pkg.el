;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-org" "20261017.1107"
  "Preview Org LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.22.2"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "4bd14405ab5c12bf4f7507402371d70b5c5ed063"
  :revdesc "4bd14405ab5c"
  :keywords '("tex" "org" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
