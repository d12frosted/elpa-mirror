;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dtk" "20241013.331"
  "Access SWORD content via diatheke."
  '((emacs  "24.4")
    (cl-lib "0.6.1")
    (dash   "2.12.0")
    (seq    "1.9")
    (s      "1.9"))
  :url "https://codeberg.org/thomp/dtk"
  :commit "a80891a3f59381de1ae902417a19bc4f75255d00"
  :revdesc "a80891a3f593"
  :keywords '("hypermedia"))
