(define-package "embark" "20210203.407" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "c8f164b1a48bbcb6884dedd0a6de1d2a7ede0e3e" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
