(define-package "zoxide" "20220711.33" "Find file by zoxide"
  '((emacs "25.1"))
  :commit "b09c06962316d28b14ecbb2340af7c0636ab6d16" :authors
  '(("Ruoyu Feng" . "emacs@vonfry.name"))
  :maintainers
  '(("Ruoyu Feng" . "emacs@vonfry.name"))
  :maintainer
  '("Ruoyu Feng" . "emacs@vonfry.name")
  :keywords
  '("converience" "matching")
  :url "https://gitlab.com/Vonfry/zoxide.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
