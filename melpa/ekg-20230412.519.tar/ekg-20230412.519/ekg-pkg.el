(define-package "ekg" "20230412.519" "A system for recording and linking information"
  '((triples "0.2.5")
    (emacs "28.1"))
  :commit "96003526c7997ac295ef0afaf4cfe224a054380c" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
