(define-package "nsis-mode" "20120820.1809" "NSIS-mode" 'nil :commit "f1bf701c37680553c8f51462e0829d0dd6c53187" :authors
  '(("Matthew L. Fidler"))
  :maintainer
  '("Matthew L. Fidler")
  :keywords
  '("nsis")
  :url "http://github.com/mlf176f2/nsis-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
