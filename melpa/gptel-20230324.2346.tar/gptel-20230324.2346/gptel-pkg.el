(define-package "gptel" "20230324.2346" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "5ebaf361f1d96801f913943ce6d57f703abfb594" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
