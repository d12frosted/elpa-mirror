;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251104.514"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "5799c6d9fe5c47ad6be02dff8b2c765636e91230"
  :revdesc "5799c6d9fe5c"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
