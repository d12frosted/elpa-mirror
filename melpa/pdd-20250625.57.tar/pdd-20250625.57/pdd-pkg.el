;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250625.57"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "5632a73d26639def430c074d69cc38810685ea9c"
  :revdesc "5632a73d2663"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
