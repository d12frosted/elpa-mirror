(define-package "meow" "20220207.439" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "4fd728e48aadfc7446414830f75b3347808c8c5e" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
