;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20251219.2039"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "9ce1ee692cf3bae68fcfd16ff59abbb3b7377631"
  :revdesc "9ce1ee692cf3"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
