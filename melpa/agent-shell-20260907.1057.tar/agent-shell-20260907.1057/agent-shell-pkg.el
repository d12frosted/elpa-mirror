;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260907.1057"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.14.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7eda18b6a67e303729fe19128f94882cec4889f1"
  :revdesc "7eda18b6a67e")
