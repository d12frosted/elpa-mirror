(define-package "live-py-mode" "20220107.329" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "51e8fc36bb8cea5089af2a10a3a24373d335d782" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
