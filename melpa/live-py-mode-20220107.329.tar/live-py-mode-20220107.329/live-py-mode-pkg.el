(define-package "live-py-mode" "20220107.329" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "fe6911d664a25be046631cc8f013f1a142775f49" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
