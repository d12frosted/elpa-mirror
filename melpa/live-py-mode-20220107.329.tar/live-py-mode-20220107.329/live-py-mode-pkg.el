(define-package "live-py-mode" "20220107.329" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "d03d7f3eaec0449a291d590884854179e091964d" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
