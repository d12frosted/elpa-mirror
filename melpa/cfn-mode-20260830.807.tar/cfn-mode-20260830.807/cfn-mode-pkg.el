;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260830.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "bbdd731d1a78eecc07ec612743130de6401a4bc6"
  :revdesc "bbdd731d1a78"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
