;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260702.910"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "64c7685bc491cbe21abde40594ce47489be0019e"
  :revdesc "64c7685bc491"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
