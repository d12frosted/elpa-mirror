;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async" "20260316.2025"
  "Asynchronous processing in Emacs."
  '((emacs "24.4"))
  :url "https://github.com/jwiegley/emacs-async"
  :commit "c9ad8bcdf172cde80c987c0c3aa1add163197665"
  :revdesc "c9ad8bcdf172"
  :keywords '("async")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
