;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20260114.1445"
  "Major modes for editing and running Erlang."
  '((emacs "24.3"))
  :url "https://github.com/erlang/otp"
  :commit "28fef74d7a13556a2bbd12a90b19a30e939f72ce"
  :revdesc "28fef74d7a13"
  :keywords '("erlang" "languages" "processes"))
