;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260915.417"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "b1ddfb3e4c68c8f6a4aee2e48e0016c3fb4c3803"
  :revdesc "b1ddfb3e4c68"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
