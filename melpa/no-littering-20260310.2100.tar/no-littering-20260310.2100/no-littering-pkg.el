;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260310.2100"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "24002d52785b5feb2313dfabc49d0006b8ba5ba0"
  :revdesc "24002d52785b"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
