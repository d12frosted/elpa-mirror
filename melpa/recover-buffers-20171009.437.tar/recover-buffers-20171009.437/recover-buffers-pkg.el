(define-package "recover-buffers" "20171009.437" "revisit all buffers from an auto-save file" 'nil :commit "81a5cb53099955ebc2a411a44cba5a394ee3f2d1" :authors
  (("era eriksson <http://www.iki.fi/era>"))
  :maintainer
  ("era eriksson <http://www.iki.fi/era>"))
;; Local Variables:
;; no-byte-compile: t
;; End:
