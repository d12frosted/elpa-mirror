;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recover-buffers" "20171009.437"
  "Revisit all buffers from an auto-save file."
  ()
  :url "https://github.com/tripleee/recover-buffers"
  :commit "81a5cb53099955ebc2a411a44cba5a394ee3f2d1"
  :revdesc "81a5cb530999"
  :authors '(("era eriksson" . "http://www.iki.fi/era"))
  :maintainers '(("era eriksson" . "http://www.iki.fi/era")))
