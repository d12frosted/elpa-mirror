;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "environ" "20260130.1135"
  "API for environment variables and env files."
  '((emacs "24.1")
    (dash  "2.17.0")
    (f     "0.20.0")
    (s     "1.12.0"))
  :url "https://github.com/cfclrk/environ"
  :commit "fae49380dd859c63c333b80c3bda7bd497e92d91"
  :revdesc "fae49380dd85"
  :keywords '("tools")
  :authors '(("Chris Clark" . "cfclrk@gmail.com"))
  :maintainers '(("Chris Clark" . "cfclrk@gmail.com")))
