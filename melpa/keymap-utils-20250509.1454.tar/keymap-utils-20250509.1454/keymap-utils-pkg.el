;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keymap-utils" "20250509.1454"
  "Keymap utilities."
  '((emacs  "26.1")
    (compat "30.0.0.0"))
  :url "https://github.com/tarsius/keymap-utils"
  :commit "c141b16ca400ad2494d499f97f37722046b1c811"
  :revdesc "c141b16ca400"
  :keywords '("convenience" "extensions")
  :authors '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev")))
