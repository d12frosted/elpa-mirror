;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251118.131"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "b814a276c95fc75b814bed21d851739d37adabc4"
  :revdesc "b814a276c95f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
