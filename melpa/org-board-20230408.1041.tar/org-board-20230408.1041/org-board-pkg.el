;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-board" "20230408.1041"
  "Bookmarking and web archival system for Org mode."
  ()
  :url "https://github.com/scallywag/org-board"
  :commit "500fe02bc114e5b535a2eb2ab73954d79428168f"
  :revdesc "500fe02bc114"
  :keywords '("org" "bookmarks" "archives")
  :authors '(("Charles A. Roelli" . "charles@aurox.ch"))
  :maintainers '(("Charles A. Roelli" . "charles@aurox.ch")))
