(define-package "selectrum" "20201205.912" "Easily select item from list"
  '((emacs "25.1"))
  :commit "2451929b403fd5b212b1f558b0ddd75de4013218" :keywords
  ("extensions")
  :authors
  (("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  ("Radon Rosborough" . "radon.neon@gmail.com")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
