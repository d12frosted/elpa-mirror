(define-package "gptel" "20230806.41" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "c0ffce0849c8596d763d0ad603b9d67f75e93161" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
