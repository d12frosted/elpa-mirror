;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260408.524"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "22348ba4cb89bb71d03e3cac0953d54c88d8f0ac"
  :revdesc "22348ba4cb89"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
