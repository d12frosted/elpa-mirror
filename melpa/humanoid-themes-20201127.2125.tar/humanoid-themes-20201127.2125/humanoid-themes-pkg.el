(define-package "humanoid-themes" "20201127.2125" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "0d997c8fc570292ceaf2511777a1ab96373abddf" :keywords
  ("faces" "color" "theme")
  :authors
  (("Thomas Friese"))
  :maintainer
  ("Thomas Friese")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
