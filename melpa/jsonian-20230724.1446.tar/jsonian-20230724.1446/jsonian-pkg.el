(define-package "jsonian" "20230724.1446" "A major mode for editing JSON files"
  '((emacs "27.1"))
  :commit "43ab410a017f01bff89f83de3b450da46691e6a2" :authors
  '(("Ian Wahbe"))
  :maintainers
  '(("Ian Wahbe"))
  :maintainer
  '("Ian Wahbe")
  :url "https://github.com/iwahbe/jsonian")
;; Local Variables:
;; no-byte-compile: t
;; End:
