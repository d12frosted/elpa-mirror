;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260203.912"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "61623d5acfbd52aa13b50523c7be7a0f74e355e3"
  :revdesc "61623d5acfbd")
