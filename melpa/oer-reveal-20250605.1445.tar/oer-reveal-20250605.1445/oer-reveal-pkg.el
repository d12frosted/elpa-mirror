;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "20250605.1445"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.35.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "b30c67c8df96511c28e7544420df29fb1b4bcd2d"
  :revdesc "b30c67c8df96"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
