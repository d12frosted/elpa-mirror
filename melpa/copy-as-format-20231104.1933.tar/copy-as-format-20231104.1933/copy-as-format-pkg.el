(define-package "copy-as-format" "20231104.1933" "Copy buffer locations as GitHub/Slack/JIRA etc... formatted code"
  '((cl-lib "0.5"))
  :commit "d4a88544d3e89385cc401f2026e8d46ca02e7ca4" :authors
  '(("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainers
  '(("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainer
  '("Skye Shaw" . "skye.shaw@gmail.com")
  :keywords
  '("github" "slack" "jira" "hipchat" "gitlab" "bitbucket" "org-mode" "pod" "rst" "asciidoc" "tools" "convenience")
  :url "https://github.com/sshaw/copy-as-format")
;; Local Variables:
;; no-byte-compile: t
;; End:
