(define-package "reazon" "20210828.1425" "miniKanren for Emacs"
  '((emacs "26"))
  :commit "f3b4d4c12d2c4a973251d3791fa414e33df3969c" :authors
  '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainer
  '("Nick Drozd" . "nicholasdrozd@gmail.com")
  :keywords
  '("languages" "extensions" "lisp")
  :url "https://github.com/nickdrozd/reazon")
;; Local Variables:
;; no-byte-compile: t
;; End:
