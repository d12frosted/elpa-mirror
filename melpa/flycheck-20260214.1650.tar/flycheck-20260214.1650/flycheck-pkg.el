;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260214.1650"
  "On-the-fly syntax checking."
  '((emacs "27.1")
    (seq   "2.24"))
  :url "https://www.flycheck.org"
  :commit "4615773d7e1b4b7aae409867671885356ab74b49"
  :revdesc "4615773d7e1b"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
