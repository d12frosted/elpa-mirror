(define-package "modus-themes" "20210726.1150" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "66fbe78c5a96c7b349fca5c9b49fe8079fa263a8" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
