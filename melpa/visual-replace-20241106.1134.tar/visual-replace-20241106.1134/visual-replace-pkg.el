;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "20241106.1134"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "https://github.com/szermatt/visual-replace"
  :commit "530904e31fc5af4688cedbb784ed0aec778f8e43"
  :revdesc "530904e31fc5"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
