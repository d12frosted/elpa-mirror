(define-package "outshine" "20190116.1748" "outline with outshine outshines outline"
  '((outorg "2.0")
    (cl-lib "0.5"))
  :commit "3edf0c61e94d36d174120c8080a98023e30a58a2" :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :url "http://github.com/alphapapa/outshine")
;; Local Variables:
;; no-byte-compile: t
;; End:
