;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "i-ching" "20241113.1642"
  "The Book of Changes."
  '((emacs   "25.1")
    (request "0.3"))
  :url "https://github.com/zzkt/i-ching"
  :commit "e4339cb64a97e0d04a4cb8e7183aeec4e4ae6a29"
  :revdesc "e4339cb64a97"
  :keywords '("games" "divination" "stochastism" "cleromancy" "change")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
