(define-package "oer-reveal" "20230925.1039" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.22.0"))
  :commit "008a4433d64389d00ae86e00a391041e12a9cba7" :authors
  '(("Jens Lechtenbörger"))
  :maintainers
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
