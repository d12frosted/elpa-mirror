(define-package "racket-mode" "20221205.1518" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "68d14352f9973b7b8b3f505da82d082f96270935" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
