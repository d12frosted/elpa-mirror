(define-package "thrift" "20231119.16" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "0d87d2068b9df8ae5b7ab21048ffeb58ba91a9ca" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
