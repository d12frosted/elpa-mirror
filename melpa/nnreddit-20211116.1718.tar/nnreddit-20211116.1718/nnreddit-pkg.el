(define-package "nnreddit" "20211116.1718" "Gnus Backend For Reddit"
  '((emacs "25.1")
    (request "0.3.3")
    (anaphora "1.0.4")
    (dash "2.18.1")
    (json-rpc "0.0.1")
    (virtualenvwrapper "20151123")
    (s "1.6.1"))
  :commit "7347ad1f3db7351c2e7f9a06d2ca8873130dbbfb" :keywords
  '("news")
  :url "https://github.com/dickmao/nnreddit")
;; Local Variables:
;; no-byte-compile: t
;; End:
