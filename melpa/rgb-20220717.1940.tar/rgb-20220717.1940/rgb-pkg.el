;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rgb" "20220717.1940"
  "RGB control via OpenRGB."
  '((emacs "24.3"))
  :url "https://gitlab.com/cwpitts/rgb.el"
  :commit "4aab5a5be16b69b47ef5e67d02782df5e41dbd7b"
  :revdesc "4aab5a5be16b")
