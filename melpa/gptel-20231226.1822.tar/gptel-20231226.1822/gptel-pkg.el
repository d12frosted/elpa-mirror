(define-package "gptel" "20231226.1822" "Interact with ChatGPT and other LLMs"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "5470e0690a2fc6110e5080baa785233d6cb1470e" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
