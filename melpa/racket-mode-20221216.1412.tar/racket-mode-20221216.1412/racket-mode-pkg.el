(define-package "racket-mode" "20221216.1412" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "6fde181e86882427336ff8c46d1aca7b59f824bb" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
