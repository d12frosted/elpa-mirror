(define-package "consult" "20230216.2154" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "1794377b1d61f88e0af2e3dff033bd9832d274b8" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
