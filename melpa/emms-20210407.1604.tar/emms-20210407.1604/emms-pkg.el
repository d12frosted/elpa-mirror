(define-package "emms" "20210407.1604" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (seq "0"))
  :commit "f79343bf03f6ece09638ec27eeb831c0abe59667" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
