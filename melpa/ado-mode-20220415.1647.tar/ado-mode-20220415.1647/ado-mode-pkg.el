(define-package "ado-mode" "20220415.1647" "Major mode for editing Stata-related files"
  '((emacs "25.1"))
  :commit "695ea71cf4d6ae5f0afbc37b6fd08458e5c584c4" :authors
  '(("Bill Rising" . "brising@alum.mit.edu"))
  :maintainer
  '("Bill Rising" . "brising@alum.mit.edu")
  :keywords
  '("tools" "languages" "files" "convenience" "stata" "mata" "ado")
  :url "https://github.com/louabill/ado-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
