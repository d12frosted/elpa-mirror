;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260722.144"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://codeberg.org/okamsn/loopy"
  :commit "d33417ff4ff436a221eb10c73c283c9c2af3cde1"
  :revdesc "d33417ff4ff4"
  :keywords '("extensions"))
