(define-package "modus-themes" "20221021.206" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "8ce12ca6877e6ea4a2fab043995a54a5d4362484" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
