;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250421.1739"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "42fb1bfa72faa79afc608b17a7a32518ed2915e7"
  :revdesc "42fb1bfa72fa"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
