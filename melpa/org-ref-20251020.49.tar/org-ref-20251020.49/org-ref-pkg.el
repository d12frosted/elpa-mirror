;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ref" "20251020.49"
  "Citations, cross-references and bibliographies in org-mode."
  '((org               "9.4")
    (htmlize           "0")
    (transient         "0")
    (avy               "0")
    (parsebib          "0")
    (bibtex-completion "0")
    (citeproc          "0")
    (ox-pandoc         "0")
    (request           "0"))
  :url "https://github.com/jkitchin/org-ref"
  :commit "d82f8c7cc720a8cbb90fbf56e39c35771ef9e4a8"
  :revdesc "d82f8c7cc720"
  :keywords '("org-mode" "cite" "ref" "label")
  :authors '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainers '(("John Kitchin" . "jkitchin@andrew.cmu.edu")))
