;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indian-ext" "20231009.740"
  "Extension to Indian language utilities."
  '((emacs "24"))
  :url "https://github.com/paddymcall/indian-ext"
  :commit "80ea22eea203c8eb4c28f59fceb8d276395ecb0f"
  :revdesc "80ea22eea203"
  :keywords '("i18n" "tools" "wp" "indian" "devanagari" "encoding")
  :authors '(("Patrick McAllister" . "pma@rdorte.org"))
  :maintainers '(("Patrick McAllister" . "pma@rdorte.org")))
