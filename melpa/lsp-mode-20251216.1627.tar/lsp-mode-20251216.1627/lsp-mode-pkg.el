;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20251216.1627"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "febc89ecb34a5dff0233107b6a157f0292f00ddb"
  :revdesc "febc89ecb34a"
  :keywords '("languages"))
