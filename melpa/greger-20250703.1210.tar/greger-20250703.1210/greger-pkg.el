;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greger" "20250703.1210"
  "Agentic coding environment with tool use, using Claude."
  '((emacs "29.1"))
  :url "https://github.com/andreasjansson/greger.el"
  :commit "093bf3424d6033626fe9638e998c1fc52e9a9334"
  :revdesc "093bf3424d60"
  :keywords '("agent" "agentic" "ai" "chat" "language-models" "tools")
  :authors '(("Andreas Jansson" . "andreas@jansson.me.uk"))
  :maintainers '(("Andreas Jansson" . "andreas@jansson.me.uk")))
