;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "20241002.1651"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "898ca57a4047df99c5f852661e1bbb4e4a1830cb"
  :revdesc "898ca57a4047")
