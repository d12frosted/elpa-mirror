(define-package "forth-mode" "20220628.1335" "Programming language mode for Forth" 'nil :commit "3ad7b9e9d6b9b69140ceed8ffabaa58aa89b78cb" :authors
  '(("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainer
  '("Lars Brinkhoff" . "lars@nocrew.org")
  :keywords
  '("languages" "forth")
  :url "http://github.com/larsbrinkhoff/forth-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
