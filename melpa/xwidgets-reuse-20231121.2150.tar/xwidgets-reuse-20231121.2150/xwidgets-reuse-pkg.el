(define-package "xwidgets-reuse" "20231121.2150" "Reuse xwidgets sessions to reduce resource consumption"
  '((emacs "26.1"))
  :commit "d9ef301c69f4d81c7a2d89492c13bde6ddbcf18b" :authors
  '(("Boris Glavic" . "lordpretzel@gmail.com"))
  :maintainers
  '(("Boris Glavic" . "lordpretzel@gmail.com"))
  :maintainer
  '("Boris Glavic" . "lordpretzel@gmail.com")
  :keywords
  '("hypermedia")
  :url "https://github.com/lordpretzel/xwidgets-reuse")
;; Local Variables:
;; no-byte-compile: t
;; End:
