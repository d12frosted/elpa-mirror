;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restclient" "20250719.2136"
  "An interactive HTTP client for Emacs."
  '((emacs  "26.1")
    (compat "30.1.0.0"))
  :url "https://github.com/emacsorphanage/restclient"
  :commit "4b4e4f40d53b238fe256a5c17dfb17650ad78297"
  :revdesc "4b4e4f40d53b"
  :keywords '("http" "comm" "tools")
  :authors '(("Pavel Kurnosov" . "pashky@gmail.com"))
  :maintainers '(("Peder O. Klingenberg" . "peder@klingenberg.no")))
