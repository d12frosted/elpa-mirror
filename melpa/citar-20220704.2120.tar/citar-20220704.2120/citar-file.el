;;; citar-file.el --- File functions for citar -*- lexical-binding: t; -*-
;;
;; Copyright (C) 2021 Bruce D'Arcus
;;
;; This file is not part of GNU Emacs.
;;
;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.
;;
;;; Commentary:
;;
;;  Functions for opening and creating bibliographic files related to a source.
;;
;;; Code:

(eval-when-compile
  (require 'cl-lib)
  (require 'subr-x))
(require 'seq)
(require 'map)

;;; pre-1.0 API cleanup

;; make all these private

(make-obsolete 'citar-file-parser-default 'citar-file--parser-default "1.0")
(make-obsolete 'citar-file-parser-triplet 'citar-file--parser-triplet "1.0")
(make-obsolete-variable 'citar-file-extensions
                        'citar-library-file-extensions "1.0")

(declare-function citar-get-value "citar")
(declare-function citar--bibliography-files "citar")
(declare-function citar--check-configuration "citar")
(declare-function citar--get-notes-config "citar")

;;;; File related variables

(defcustom  citar-file-variable "file"
  "The field key to look for in an entry for PDF, etc."
  :group 'citar
  :type '(string))

(defcustom citar-file-open-prompt t
  "Prompt for selection of related files to open."
  :group 'citar
  :type '(boolean))

(defcustom citar-file-parser-functions
  '(citar-file--parser-default
    citar-file--parser-triplet)
  "List of functions to parse file field."
  :group 'citar
  :type '(repeat function))

(defcustom citar-file-open-function 'find-file
  "Function to use to open files."
  :group 'citar
  :type '(function))

;; TODO move this to citar.el for consistency with `citar-library-file-extensions'?
(defcustom citar-file-note-extensions '("org" "md")
  "List of file extensions to filter for notes.

These are the extensions the `citar-open-note-function'
will open, via `citar-open-notes'."
  :group 'citar
  :type '(repeat string))

(defcustom citar-file-additional-files-separator nil
  "Find additional library files starting with reference key.

If nil, the functions `citar-open-library-files' and
`citar-open-notes' only locate files with the naming scheme
\"<key>.<extension>\".  Otherwise, the value of this variable
should be a regular expression that separates the key from
optional additional text following the key in the file name.
Then files named as \"<key><separator><extra>.<extension>\" are
also located.

Note: when non-nil, the value of this variable should be a
separator that does not otherwise occur in citation keys."
  :group 'citar
  :type '(choice (const :tag "Ignore additional files" nil)
                 (const :tag "Find files with space after key" "[[:space:]]")
                 (regexp :tag "Filename separator")))

(defvar citar-notes-paths)
(defvar citar-create-note-function)
(defvar citar-library-paths)
(defvar citar-library-file-extensions)

;;;; Convenience functions for files and paths

(defun citar-file--normalize-paths (file-paths)
  "Return a list of FILE-PATHS normalized with truename."
  (if (stringp file-paths)
      ;; If path is a string, return as a list.
      (list (file-truename file-paths))
    (delete-dups (mapcar #'file-truename file-paths))))

;;;; Parsing file fields

(defun citar-file--parser-default (file-field)
  "Split FILE-FIELD by `;'."
  (seq-remove
   #'string-empty-p
   (mapcar
    #'string-trim
    (citar-file--split-escaped-string file-field ?\;))))

(defun citar-file--parser-triplet (file-field)
  "Return a list of files from DIRS and a FILE-FIELD formatted as a triplet.

This is file-field format seen in, for example, Calibre and Mendeley.

Example: ':/path/to/test.pdf:PDF'."
  (let (filenames)
    (dolist (sepchar '(?\; ?,))         ; Mendeley and Zotero use ;, Calibre uses ,
      (dolist (substring (citar-file--split-escaped-string file-field sepchar))
        (let* ((triplet (citar-file--split-escaped-string substring ?:))
               (len (length triplet)))
          (when (>= len 3)
            ;; If there are more than three components, we probably split on unescaped : in the filename.
            ;; Take all but the first and last components of TRIPLET and join them with :
            (let* ((escaped (string-join (butlast (cdr triplet)) ":"))
                   (filename (replace-regexp-in-string "\\\\\\(.\\)" "\\1" escaped)))
              ;; Calibre doesn't escape file names in BIB files, so try both
              ;; See https://github.com/kovidgoyal/calibre/blob/master/src/calibre/library/catalogs/bibtex.py
              (push filename filenames)
              (push escaped filenames))))))
    (nreverse filenames)))

(defun citar-file--parse-file-field (entry dirs &optional citekey)
  "Return files found in file field of ENTRY.
Relative file names are expanded from the first directory in DIRS
in which they are found. Omit non-existing absolute file names
and relative file names not found in DIRS. On failure, print a
message explaining the cause; CITEKEY is included in this failure
message."
  (when-let* ((fieldname citar-file-variable)
              (fieldvalue (citar-get-value fieldname entry)))
    (if-let ((files (delete-dups (mapcan (lambda (parser)
                                           (funcall parser fieldvalue))
                                         citar-file-parser-functions))))
        (if-let ((foundfiles (citar-file--find-files-in-dirs files dirs)))
            (if (null citar-library-file-extensions)
                foundfiles
              (or (seq-filter (lambda (file)
                                (member (file-name-extension file) citar-library-file-extensions))
                              foundfiles)
                  (ignore
                   (message "No files for `%s' with `citar-library-file-extensions': %S"
                            citekey foundfiles))))
          (ignore
           (message (concat "None of the files for `%s' exist; check `citar-library-paths' and "
                            "`citar-file-parser-functions': %S")
                    citekey files)))
      (ignore
       (if (string-empty-p (string-trim fieldvalue))
           (message "Empty `%s' field: %s" fieldname citekey)
         (message "Could not parse `%s' field of `%s'; check `citar-file-parser-functions': %s"
                  fieldname citekey fieldvalue))))))

(defun citar-file--has-file-field (entries)
  "Return predicate to test if bibliography entry in ENTRIES has a file field.
Note: this function is intended to be used in
`citar-has-files-functions'. Use `citar-has-files' to test
whether entries have associated files."
  (when-let ((filefield citar-file-variable))
    (lambda (key)
      (when-let ((entry (gethash key entries)))
        (citar-get-value filefield entry)))))

(defun citar-file--get-from-file-field (keys entries)
  "Return list of FILES for KEYS given in ENTRIES.

Parse and return files given in the bibliography field named by
`citar-file-variable'.

Note: this function is intended to be used in
`citar-get-files-functions'. Use `citar-get-files' to get all
files associated with KEYS."
  (when citar-file-variable
    (citar--check-configuration 'citar-library-paths 'citar-library-file-extensions
                                'citar-file-parser-functions)
    (let ((dirs (append citar-library-paths
                        (mapcar #'file-name-directory (citar--bibliography-files)))))
      (mapcan
       (lambda (citekey)
         (when-let ((entry (gethash citekey entries)))
           (citar-file--parse-file-field entry dirs citekey)))
       keys))))

;;;; Scanning library directories

(defun citar-file--has-library-files (&optional _entries)
  "Return predicate testing whether cite key has library files."
  (citar--check-configuration 'citar-library-paths 'citar-library-file-extensions)
  (let ((files (citar-file--directory-files
                citar-library-paths nil citar-library-file-extensions
                citar-file-additional-files-separator)))
    (lambda (key)
      (gethash key files))))

(defun citar-file--get-library-files (keys &optional _entries)
  "Return list of files for KEYS in ENTRIES."
  (citar--check-configuration 'citar-library-paths)
  (let ((files (citar-file--directory-files citar-library-paths keys
                                            citar-library-file-extensions
                                            citar-file-additional-files-separator)))
    (mapcan (lambda (key) (gethash key files)) keys)))

(defun citar-file--make-filename-regexp (keys extensions &optional additional-sep)
  "Regexp matching file names starting with KEYS and ending with EXTENSIONS.
When ADDITIONAL-SEP is non-nil, it should be a regular expression
that separates the key from optional additional text that follows
it in matched file names.  The returned regexp captures the key
as group 1, the extension as group 2, and any additional text
following the key as group 3."
  (when (and (null keys) (string-empty-p additional-sep))
    (setq additional-sep nil))
  (concat
   "\\`"
   (if keys (regexp-opt keys "\\(?1:") "\\(?1:[^z-a]*?\\)")
   (when additional-sep (concat "\\(?3:" additional-sep "[^z-a]*\\)?"))
   "\\."
   (if extensions (regexp-opt extensions "\\(?2:") "\\(?2:[^.]*\\)")
   "\\'"))

(defun citar-file--directory-files (dirs &optional keys extensions additional-sep)
  "Return files in DIRS starting with KEYS and ending with EXTENSIONS.

Return a hash table mapping keys to lists of file names present
in DIRS.  Each file name is divided into three parts: the key,
optional additional text, and the extension:

- When KEYS is non-nil, each file name must start with an element
of KEYS.  Otherwise file names can start with any key.

- When EXTENSIONS is non-nil, the file extension must match one
of its elements.  Otherwise the files can have any extension.

- When ADDITIONAL-SEP is non-nil, the file name can have
additional text following the key.  ADDITIONAL-SEP is a regexp
separating the key from the additional text.

When KEYS is nil and ADDITIONAL-SEP is non-nil, each file name is
stored in the hash table under two keys: the base name of the
file; and the portion of the file name preceding the first match
of ADDITIONAL-SEP.

When KEYS is nil, if ADDITIONAL-SEP is empty then it is treated
as being nil. In other words, this function can only scan a
directory for file names matching unknown keys if either

1. The key is not followed by any additional text except for the
   file extension.

2. There is a non-empty ADDITIONAL-SEP between the key and any
   following text.

Note: when KEYS and EXTENSIONS are non-nil and ADDITIONAL-SEP is
nil, this function has an optimized implementation; it checks for
existing files named \"KEY.EXT\" in DIRS, with KEY and EXT being
the elements of KEYS and EXTENSIONS, respectively.  It does not
need to scan the contents of DIRS in this case."
  (let ((files (make-hash-table :test 'equal))
        (filematch (unless (and keys extensions (not additional-sep))
                     (citar-file--make-filename-regexp keys extensions additional-sep))))
    (prog1 files
      (dolist (dir dirs)
        (when (file-directory-p dir)
          (if filematch
              ;; Use regexp to scan directory
              (dolist (file (directory-files dir nil filematch))
                (let ((key (and (string-match filematch file) (match-string 1 file)))
                      (filename (expand-file-name file dir))
                      (basename (file-name-base file)))
                  (push filename (gethash key files))
                  (unless (or keys (string= key basename))
                    (push filename (gethash basename files)))))
            ;; Otherwise, check for files named KEY.EXT
            (dolist (key keys)
              (dolist (ext extensions)
                (let ((filename (expand-file-name (concat key "." ext) dir)))
                  (when (file-exists-p filename)
                    (push filename (gethash key files)))))))))
      ;; Reverse file lists because push adds elements to the front
      (maphash (lambda (key filelist)
                 (puthash key (nreverse filelist) files))
               files))))

;;;; Opening and creating files functions

(defun citar-file-open (file)
  "Open FILE."
  (if (equal (file-name-extension file) "html")
      (citar-file-open-external (expand-file-name file))
    (funcall citar-file-open-function (expand-file-name file))))

(defun citar-file-open-external (file)
  "Open FILE with external application."
  ;; Adapted from consult-file-externally.
  (if (and (eq system-type 'windows-nt)
           (fboundp 'w32-shell-execute))
      (w32-shell-execute "open" file)
    (call-process (pcase system-type
                    ('darwin "open")
                    ('cygwin "cygstart")
                    (_ "xdg-open"))
                  nil 0 nil
                  file)))

;;;; Note files

(defun citar-file--get-notes-hash (&optional keys)
  "Return hash-table with KEYS with file notes."
  (citar-file--directory-files
   citar-notes-paths keys citar-file-note-extensions
   citar-file-additional-files-separator))

(defun citar-file-has-notes (&optional _entries)
  "Return predicate testing whether cite key has associated notes."
  ;; REVIEW why this optional arg when not needed?
  (let ((files (citar-file--get-notes-hash)))
    (lambda (key)
      (gethash key files))))

(defun citar-file--open-note (key entry)
  "Open a note file from KEY and ENTRY."
  (if-let* ((file (citar-file--get-note-filename key
                                                 citar-notes-paths
                                                 citar-file-note-extensions))
            (file-exists (file-exists-p file)))
      (find-file file)
    (if (and (null citar-notes-paths)
             (equal (citar--get-notes-config :action)
                    'citar-org-format-note-default))
        (error "You must set 'citar-notes-paths'")
      (funcall
       (citar--get-notes-config :create) key entry))))

(defun citar-file--get-note-files (keys)
  "Return list of notes associated with KEYS."
  (let ((notehash (citar-file--get-notes-hash keys)))
    (flatten-list (map-values notehash))))

(defun citar-file--get-note-filename (key dirs extensions)
  "Return existing or new filename for KEY in DIRS with extension in EXTENSIONS.

This is for use in a note function where notes are one-per-file,
with citekey as filename.

Returns the filename whether or not the file exists, to support a
function that will open a new file if the note is not present."
  (let ((files (citar-file--directory-files dirs (list key) extensions
                                            citar-file-additional-files-separator)))
    (or (car (gethash key files))
        (when-let ((dir (car dirs))
                   (ext (car extensions)))
          (expand-file-name (concat key "." ext) dir)))))

;;;; Utility functions

(defun citar-file--split-escaped-string (string sepchar)
  "Split STRING into substrings at unescaped occurrences of SEPCHAR.
A character is escaped in STRING if it is preceded by `\\'. The
`\\' character can also escape itself. Return a list of
substrings of STRING delimited by unescaped occurrences of
SEPCHAR."
  (let ((skip (format "^\\\\%c" sepchar))
        strings)
    (with-temp-buffer
      (insert string)
      (goto-char (point-min))
      (while (progn (skip-chars-forward skip) (< (point) (point-max)))
        (if (= ?\\ (following-char))
            (ignore-error 'end-of-buffer (forward-char 2))
          (push (delete-and-extract-region (point-min) (point)) strings)
          (delete-char 1)))
      (push (buffer-string) strings))
    (nreverse strings)))

(defun citar-file--find-files-in-dirs (files dirs)
  "Expand file names in FILES in DIRS and keep the ones that exist."
  (let (foundfiles)
    (dolist (file files)
      (if (file-name-absolute-p file)
          (when (file-exists-p file) (push (expand-file-name file) foundfiles))
        (when-let ((filepath (seq-some (lambda (dir)
                                         (let ((filepath (expand-file-name file dir)))
                                           (when (file-exists-p filepath) filepath)))
                                       dirs)))
          (push filepath foundfiles))))
    (nreverse foundfiles)))

(provide 'citar-file)
;;; citar-file.el ends here
