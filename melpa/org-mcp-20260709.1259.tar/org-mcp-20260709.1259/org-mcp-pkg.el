;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260709.1259"
  "MCP server for Org-mode."
  '((emacs          "28.2")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "7a529cfb4f8cdc11c71080e6121ef90b66256cb3"
  :revdesc "7a529cfb4f8c"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
