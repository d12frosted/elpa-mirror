;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260522.1543"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "617cdfb4c5cfad1526fd69cea32a316554e091ae"
  :revdesc "617cdfb4c5cf"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
