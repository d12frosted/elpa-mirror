;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260319.710"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "bf357646d9c1333d719a1dd99566db315daeec2a"
  :revdesc "bf357646d9c1"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
