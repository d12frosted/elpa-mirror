;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sozluk" "20230730.1749"
  "An online Turkish dictionary."
  '((emacs "27.1")
    (dash  "2.11.0"))
  :url "https://github.com/isamert/sozluk.el"
  :commit "420ace999fa0d27fbc6aa6011313488c8664a925"
  :revdesc "420ace999fa0"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
