(define-package "brutal-theme" "20211128.1457" "Brutalist theme"
  '((emacs "24.1"))
  :commit "097c613f715f49dc84234203fdbae562c3bb2d71" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
