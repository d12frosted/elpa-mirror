(define-package "emacsql-sqlite" "20220917.1551" "EmacSQL back-end for SQLite"
  '((emacs "25.1")
    (emacsql "3.0.0"))
  :commit "6d999ba39dfa1df002169b5ef2c886b1bd7afd8e" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
