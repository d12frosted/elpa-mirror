;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260807.941"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.96.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "5b8e2e3abf591ecad557f3bcf780bb05150fc0ec"
  :revdesc "5b8e2e3abf59")
