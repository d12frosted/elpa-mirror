;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-chef" "20250607.2152"
  "Cookbook and recipe management with org-mode."
  '((org   "0")
    (emacs "24.3"))
  :url "https://github.com/Chobbes/org-chef"
  :commit "5bb361c4b2ade95b45e698bd30ce8024c40fa6f2"
  :revdesc "5bb361c4b2ad"
  :keywords '("convenience" "abbrev" "outlines" "org" "food" "recipes" "cooking")
  :authors '(("Calvin Beck" . "hobbes@ualberta.ca"))
  :maintainers '(("Calvin Beck" . "hobbes@ualberta.ca")))
