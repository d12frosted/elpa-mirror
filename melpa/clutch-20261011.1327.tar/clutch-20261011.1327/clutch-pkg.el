;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261011.1327"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "ec4f1881446351fd965b91e7d71692179c41e524"
  :revdesc "ec4f18814463"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
