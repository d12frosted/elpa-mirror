;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circe-notifications" "20180102.2318"
  "Add desktop notifications to Circe."
  '((emacs "24.4")
    (circe "2.3")
    (alert "1.2"))
  :url "https://github.com/eqyiel/circe-notifications"
  :commit "291149ac12877bbd062da993479d3533a26862b0"
  :revdesc "291149ac1287"
  :authors '(("Ruben Maher" . "r@rkm.id.au"))
  :maintainers '(("Ruben Maher" . "r@rkm.id.au")))
