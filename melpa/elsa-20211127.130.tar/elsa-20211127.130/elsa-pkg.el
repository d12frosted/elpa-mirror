(define-package "elsa" "20211127.130" "Emacs Lisp Static Analyser"
  '((trinary "1.0.0")
    (emacs "25.1")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3"))
  :commit "b056f041fb8f012b63fffa82e41057029bdcfaac" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
