;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250518.133"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "f2ea38117ecdc47a84152be1a1d5698cf65b4083"
  :revdesc "f2ea38117ecd"
  :keywords '("agent" "ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
