;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "run-command-recipes" "20240708.1555"
  "Start pack of recipes to `run-command'."
  '((emacs       "25.1")
    (dash        "2.18.0")
    (f           "0.20.0")
    (run-command "1.0.0"))
  :url "https://github.com/semenInRussia/emacs-run-command-recipes"
  :commit "5a249052933dfa5e8f768da6c73d926e167d6175"
  :revdesc "5a249052933d"
  :keywords '("extensions" "run-command")
  :authors '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainers '(("semenInRussia" . "hrams205@gmail.com")))
