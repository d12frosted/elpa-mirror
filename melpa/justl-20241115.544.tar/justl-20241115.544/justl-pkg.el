;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "justl" "20241115.544"
  "Major mode for driving just files."
  '((transient  "0.1.0")
    (emacs      "27.1")
    (s          "1.2.0")
    (f          "0.20.0")
    (inheritenv "0.2"))
  :url "https://github.com/psibi/justl.el"
  :commit "649490d67470fa494ab9e2988b3c7d786f4755ea"
  :revdesc "649490d67470"
  :keywords '("just" "justfile" "tools" "processes"))
