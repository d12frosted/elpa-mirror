;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bicycle" "20260516.2101"
  "Cycle outline and code visibility."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/bicycle"
  :commit "28aa18f5b9d03ed6e7cbe6435dc8fb7fe1ce6f4f"
  :revdesc "28aa18f5b9d0"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev")))
