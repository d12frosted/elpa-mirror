(define-package "git-commit" "20220429.934" "Edit Git commit messages."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (transient "20210920")
    (with-editor "20211001"))
  :commit "eef732e30b9409e1b3c96edf2a62c764be86097c" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
