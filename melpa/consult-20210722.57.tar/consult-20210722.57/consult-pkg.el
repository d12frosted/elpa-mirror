(define-package "consult" "20210722.57" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "497106916cd23113bd71b35c60e14110caf756d5" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
