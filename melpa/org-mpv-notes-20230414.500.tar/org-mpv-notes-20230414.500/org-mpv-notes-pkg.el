(define-package "org-mpv-notes" "20230414.500" "Take notes in org mode while watching videos in mpv"
  '((emacs "27.1")
    (mpv "0.2.0"))
  :commit "215bd0fdbb8593e555231309dd11a96af7e98a33" :authors
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainers
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainer
  '("Bibek Panthi" . "bpanthi977@gmail.com")
  :url "https://github.com/bpanthi977/org-mpv-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
