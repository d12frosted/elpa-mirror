;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weblogger" "20110926.1618"
  "Weblog maintenance via XML-RPC APIs."
  '((xml-rpc "1.6.8"))
  :url "http://launchpad.net/weblogger-el"
  :commit "40cfbfc69be6a619173804441db2f407e3fa1731"
  :revdesc "40cfbfc69be6"
  :keywords '("weblog" "blogger" "cms" "movable" "type" "openweblog" "blog"))
