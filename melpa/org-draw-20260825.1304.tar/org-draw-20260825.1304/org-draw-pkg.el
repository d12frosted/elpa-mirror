;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-draw" "20260825.1304"
  "Draw into Org from a browser."
  '((emacs "28.1"))
  :url "https://github.com/larrasket/org-draw"
  :commit "dd87797e3345f888bbaf525189df1f89f8e123d2"
  :revdesc "dd87797e3345"
  :keywords '("org" "multimedia" "hypermedia")
  :authors '(("Saleh" . "root@lr0.org"))
  :maintainers '(("Saleh" . "root@lr0.org")))
