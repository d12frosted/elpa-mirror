(define-package "chatgpt-shell" "20240702.858" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.50.5"))
  :commit "6c410fc2458d83e9d582f7fbec9a415a99776d8c" :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
