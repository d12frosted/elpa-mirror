;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260709.611"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "55828fdc298e9ea0731aef898508f497ff73594d"
  :revdesc "55828fdc298e")
