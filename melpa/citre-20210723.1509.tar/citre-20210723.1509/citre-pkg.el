(define-package "citre" "20210723.1509" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "036b207cc1684903a22fc1aa698ffdc04902f62a" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
