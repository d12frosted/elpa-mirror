(define-package "simple-modeline" "20201130.844" "A simple mode-line configuration for Emacs"
  '((emacs "26.1"))
  :commit "6bb96a00c5fcce48e681d8e75b000b4047815181" :keywords
  ("mode-line" "faces")
  :authors
  (("Eder Elorriaga" . "gexplorer8@gmail.com"))
  :maintainer
  ("Eder Elorriaga" . "gexplorer8@gmail.com")
  :url "https://github.com/gexplorer/simple-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
