(define-package "elisp-autofmt" "20230305.1227" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "411dca7d4435eee20073a3447e9b1a4d626a861c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
