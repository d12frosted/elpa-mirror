(define-package "consult" "20201219.2128" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "ca96fbaac2aa506da9231a463c208a2f68b20cbb" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
