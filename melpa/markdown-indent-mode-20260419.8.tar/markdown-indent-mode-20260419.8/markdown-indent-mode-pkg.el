;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-indent-mode" "20260419.8"
  "Dynamic indentation for Markdown."
  '((emacs "28.1"))
  :url "https://github.com/whhone/markdown-indent-mode"
  :commit "e8d36904be83de7ceb7fdd1c1ddaa59093129b36"
  :revdesc "e8d36904be83"
  :authors '(("Wai Hon Law" . "whhone@gmail.com"))
  :maintainers '(("Wai Hon Law" . "whhone@gmail.com")))
