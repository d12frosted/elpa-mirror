(define-package "modus-themes" "20230108.1255" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "9225ac0d0a40fa3a6192ca69d2c3569e3fe00c0c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
