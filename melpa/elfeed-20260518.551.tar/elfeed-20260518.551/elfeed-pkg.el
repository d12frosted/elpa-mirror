;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260518.551"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "8d44e3e8bf0a652cc4483f6d454fc9c4db264129"
  :revdesc "8d44e3e8bf0a"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
