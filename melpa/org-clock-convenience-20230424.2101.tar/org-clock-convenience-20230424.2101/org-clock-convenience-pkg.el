;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-convenience" "20230424.2101"
  "Convenience functions for org time tracking."
  '((org   "8")
    (emacs "24.3"))
  :url "https://github.com/dfeich/org-clock-convenience"
  :commit "08417dfd51deb400b890cf71c87b57393fc5ac8c"
  :revdesc "08417dfd51de"
  :keywords '("convenience")
  :authors '(("Derek Feichtinger" . "dfeich.gmail.com"))
  :maintainers '(("Derek Feichtinger" . "dfeich.gmail.com")))
