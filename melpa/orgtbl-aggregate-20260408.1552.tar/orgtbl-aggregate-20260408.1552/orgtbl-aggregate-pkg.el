;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260408.1552"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "ee0112c8b2061183199551af92ec8706edcb1efa"
  :revdesc "ee0112c8b206"
  :keywords '("data" "extensions"))
