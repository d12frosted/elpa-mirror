;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperstitional-themes" "20250219.1037"
  "Weird themes with incremental palettes."
  '((emacs "24.1"))
  :url "https://github.com/precompute/hyperstitional-themes"
  :commit "054fec25fb073a3b24a399ed35c20cb4051ce62e"
  :revdesc "054fec25fb07"
  :authors '(("precompute" . "git@precompute.net"))
  :maintainers '(("precompute" . "git@precompute.net")))
