(define-package "sl" "20161217.1404" "An Emacs clone of sl(1)"
  '((cl-lib "0.5"))
  :commit "0882117728be91276b815e18c2a66106bf9d69d3" :authors
  '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainer
  '("Chunyang Xu" . "mail@xuchunyang.me")
  :url "https://github.com/xuchunyang/sl.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
