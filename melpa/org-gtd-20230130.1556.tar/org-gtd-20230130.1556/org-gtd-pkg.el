(define-package "org-gtd" "20230130.1556" "An implementation of GTD."
  '((emacs "27.1")
    (org-edna "1.1.2")
    (f "0.20.0")
    (org "9.3.1")
    (org-agenda-property "1.3.1")
    (transient "0.3.7"))
  :commit "5f8a5ff121a498d21b659d029099bb35de8e22ab" :authors
  '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainer
  '("Aldric Giacomoni" . "trevoke@gmail.com")
  :url "https://github.com/Trevoke/org-gtd.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
