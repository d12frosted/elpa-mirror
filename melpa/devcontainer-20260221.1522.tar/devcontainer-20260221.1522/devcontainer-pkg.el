;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20260221.1522"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "6c28f50da80f8242bee90e43abacd9bced552114"
  :revdesc "6c28f50da80f"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
