;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evangelion-theme" "20241116.1036"
  "A dark colour scheme inspired by Neon Genesis Evangelion."
  '((emacs "27.1"))
  :url "https://github.com/crmsnbleyd/evangelion-theme"
  :commit "89577330e93f1c11b3e75d1c8bbae6accc18fc48"
  :revdesc "89577330e93f"
  :keywords '("faces" "theme")
  :authors '(("Andrew Jose" . "mail@drewsh.com"))
  :maintainers '(("Andrew Jose" . "mail@drewsh.com")))
