;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "departure-times-norway" "20250419.2145"
  "Description."
  '((emacs   "27.1")
    (persist "0.6.1"))
  :url "https://github.com/hsolg/emacs-departure-times-norway"
  :commit "aea0214e291ba4f3d21ee43265a4981756c3e9e2"
  :revdesc "aea0214e291b"
  :authors '(("Henrik Solgaard" . "henrik.solgaard@gmail.com"))
  :maintainers '(("Henrik Solgaard" . "henrik.solgaard@gmail.com")))
