(define-package "indent-control" "20230817.2115" "Management for indentation level"
  '((emacs "26.1"))
  :commit "f8f5511c4bffb1371bcb3b712b32ae6c832c15bb" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "control" "indent" "tab" "generic" "level")
  :url "https://github.com/jcs-elpa/indent-control")
;; Local Variables:
;; no-byte-compile: t
;; End:
