(define-package "geiser" "20210416.1443" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "c5a9aae4d30ea6dbf2d8af4dd1cc35a839686a00" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
