;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260607.1338"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "739c8bb26a0434fd8a70f439b0ba6dd1fcb0be93"
  :revdesc "739c8bb26a04"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
