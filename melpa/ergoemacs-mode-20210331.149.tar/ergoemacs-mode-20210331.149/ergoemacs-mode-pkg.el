(define-package "ergoemacs-mode" "20210331.149" "Emacs mode based on common modern interface and ergonomics."
  '((emacs "24.1")
    (undo-tree "0.6.5")
    (cl-lib "0.5"))
  :commit "347070d72d7487181c0bcaff5c3c345ad4dc5e12" :authors
  '(("Xah Lee" . "xah@xahlee.org")
    ("David Capello" . "davidcapello@gmail.com")
    ("Matthew L. Fidler" . "matthew.fidler@gmail.com"))
  :maintainer
  '("Matthew L. Fidler" . "matthew.fidler@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ergoemacs/ergoemacs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
