(define-package "modus-themes" "20210930.838" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "32e86cd1da982cac0c82349519e37dcc67bfa19d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
