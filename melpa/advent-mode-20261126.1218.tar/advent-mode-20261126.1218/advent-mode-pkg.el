;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20261126.1218"
  "Advent of Code mode."
  '((emacs "30.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "4ff3bccb5713c9f4bd869155936b909e43735f2a"
  :revdesc "4ff3bccb5713"
  :keywords '("tools")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
