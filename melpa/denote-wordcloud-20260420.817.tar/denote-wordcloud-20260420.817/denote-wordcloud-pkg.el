;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-wordcloud" "20260420.817"
  "Generate a word cloud."
  '((emacs  "28.1")
    (denote "4.1.3"))
  :url "https://codeberg.org/treflip/denote-wordcloud"
  :commit "60d6ae8bc63bd7d223803def9694f78b015ee23a"
  :revdesc "60d6ae8bc63b"
  :keywords '("files")
  :authors '(("Alexander Kuzmin" . "treflcrew@gmail.org"))
  :maintainers '(("Alexander Kuzmin" . "treflcrew@gmail.org")))
