;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260521.2016"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "41e42986a2bcd2d4488cfd60e12dc62dc6dc0952"
  :revdesc "41e42986a2bc"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
