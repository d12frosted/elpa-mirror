;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260328.1915"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b982163b4c7223b7eccfbb77a31dab41046244e4"
  :revdesc "b982163b4c72"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
