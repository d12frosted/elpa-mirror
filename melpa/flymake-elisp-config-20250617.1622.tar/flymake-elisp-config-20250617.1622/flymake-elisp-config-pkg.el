;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-elisp-config" "20250617.1622"
  "Setup load-path for flymake on Emacs Lisp mode."
  '((emacs "28.1"))
  :url "https://github.com/ROCKTAKEY/flymake-elisp-config"
  :commit "c247dddf3aa8349c8f3ebf965cbaff8907c18ca1"
  :revdesc "c247dddf3aa8"
  :keywords '("lisp")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
