;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occult" "20260405.2236"
  "Collapse and reveal buffer regions."
  '((emacs "29.1"))
  :url "https://github.com/agzam/occult.el"
  :commit "3d626126ede4fd017824d44a24a577fce171bcd0"
  :revdesc "3d626126ede4"
  :keywords '("convenience")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
