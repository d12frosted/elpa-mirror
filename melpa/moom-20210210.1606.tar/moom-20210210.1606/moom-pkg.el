(define-package "moom" "20210210.1606" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "42d809ed57ad6ed63dde61f75e4b535b2700aaca" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
