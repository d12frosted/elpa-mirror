(define-package "composable" "20160413.1922" "composable editing"
  '((emacs "24.4"))
  :commit "4739b6a730498e7526d06222810c3ccf3723d509" :authors
  '(("Simon Friis Vindum" . "simon@vindum.io"))
  :maintainer
  '("Simon Friis Vindum" . "simon@vindum.io")
  :keywords
  '("lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
