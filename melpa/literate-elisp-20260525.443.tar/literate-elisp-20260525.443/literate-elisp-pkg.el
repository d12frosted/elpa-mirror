;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literate-elisp" "20260525.443"
  "Load Emacs Lisp code blocks from Org files."
  '((emacs "26.1"))
  :url "https://github.com/jingtaozf/literate-elisp"
  :commit "62a28dc8cd685c141e0b4d71ae8c9f7390a25f3b"
  :revdesc "62a28dc8cd68"
  :keywords '("lisp" "docs" "extensions" "tools")
  :authors '(("Jingtao Xu" . "jingtaozf@gmail.com"))
  :maintainers '(("Jingtao Xu" . "jingtaozf@gmail.com")))
