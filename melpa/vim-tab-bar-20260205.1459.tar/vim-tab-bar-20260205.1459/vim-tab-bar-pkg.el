;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20260205.1459"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "d88fef014e42ad087c5b8d41ad59671aae9fae51"
  :revdesc "d88fef014e42"
  :keywords '("frames"))
