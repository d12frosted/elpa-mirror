(define-package "apheleia" "20231001.440" "Reformat buffer stably"
  '((emacs "26"))
  :commit "1fae320aaef2c1c9ce40125aaff5cd75f6cf7480" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
