;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20260304.928"
  "Display documentation for mouse hover."
  '((emacs    "27.1")
    (posframe "1.4.0")
    (eglot    "1.8"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "50bc7e0ddf3787851ee9695b671395ee8ccc943d"
  :revdesc "50bc7e0ddf37"
  :keywords '("tools" "languages" "convenience" "mouse" "hover")
  :authors '(("Huang Feiyu" . "sibadake1@163.com"))
  :maintainers '(("Huang Feiyu" . "sibadake1@163.com")))
