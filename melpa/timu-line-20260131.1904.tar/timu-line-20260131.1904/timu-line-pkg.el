;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-line" "20260131.1904"
  "Custom and simple mode line."
  '((emacs "29.1"))
  :url "https://gitlab.com/aimebertrand/timu-line"
  :commit "745f38f27e9bf73323d25d9624d462ba977131c3"
  :revdesc "745f38f27e9b"
  :keywords '("modeline" "frames" "ui")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
