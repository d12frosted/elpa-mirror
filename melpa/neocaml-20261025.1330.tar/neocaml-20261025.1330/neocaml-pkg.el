;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261025.1330"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "d67410ec9b21e69bbe46b749720f02dcf333bbbe"
  :revdesc "d67410ec9b21"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
