(define-package "ledger-mode" "20240318.627" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "5f95628f2eea724ce63f7e06d4cf17e9a636f4a4")
;; Local Variables:
;; no-byte-compile: t
;; End:
