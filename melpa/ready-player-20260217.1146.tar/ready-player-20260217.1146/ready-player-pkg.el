;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "20260217.1146"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "867d8e5e3e1f94f92fcbbd9ec97eca196421bee8"
  :revdesc "867d8e5e3e1f")
