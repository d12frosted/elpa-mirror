;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261102.847"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "587a3de1ea98f8f38266b4b1151c2d598dd948dc"
  :revdesc "587a3de1ea98"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
