(define-package "eldev" "20220524.1830" "Elisp development tool"
  '((emacs "24.4"))
  :commit "f9b13a976abd5152accf33331b9285ec1b095156" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
