;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20250414.26"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "60bf78108c83817c79ce164bf2511ab77db50d03"
  :revdesc "60bf78108c83"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
