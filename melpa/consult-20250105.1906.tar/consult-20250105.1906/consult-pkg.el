;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250105.1906"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "189bed606a304ac835605023c67890456483e89b"
  :revdesc "189bed606a30"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
