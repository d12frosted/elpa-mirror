(define-package "sauron" "20130818.1834" "Track (erc/org/dbus/...) events and react to them." 'nil :commit "a9877f0efa9418c41d25002b58d1c2f8c69ec975" :authors
  '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl"))
  :maintainer
  '("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl")
  :keywords
  '("comm" "frames"))
;; Local Variables:
;; no-byte-compile: t
;; End:
