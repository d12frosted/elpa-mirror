(define-package "ligo-mode" "20230918.1358" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "9e515109956dd19184884eef422c127e6b198c1a" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
