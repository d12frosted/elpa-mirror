;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241012.733"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "37ca1069326aefc54bdb1722fcac1e81f90b2ff3"
  :revdesc "37ca1069326a"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
