;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260410.716"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ba3fbc79dbc8134d026592daed2ddc531d4ae92a"
  :revdesc "ba3fbc79dbc8"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
