;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260123.1809"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.4")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "da9234f7d9074e1ea72df8d3c694378230107daa"
  :revdesc "da9234f7d907"
  :keywords '("programming"))
