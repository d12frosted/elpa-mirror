;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260522.827"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "c470fbd49057f5206ae67e8d2d55fb8451a5a203"
  :revdesc "c470fbd49057"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
