;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251004.2146"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "7f203de4b21c3f1a888fdaf4fab2ee80fb2b193b"
  :revdesc "7f203de4b21c"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
