;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-credo" "20240105.1655"
  "Flycheck checker for elixir credo."
  '((flycheck "29"))
  :url "https://github.com/aaronjensen/flycheck-credo"
  :commit "e285bd042a535d0f13e0b4c5226df404cdda4033"
  :revdesc "e285bd042a53"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
