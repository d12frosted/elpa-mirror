;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20241126.1628"
  "Miasma: color theme inspired by the woods."
  ()
  :url "https://github.com/daut/miasma-theme.el"
  :commit "468e05dbce47c5980976d5596d4646c2db45a2bc"
  :revdesc "468e05dbce47")
