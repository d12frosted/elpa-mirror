;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260413.1730"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "a8a3034f7d18f5e5627114b4abc7fb182554eda7"
  :revdesc "a8a3034f7d18"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
