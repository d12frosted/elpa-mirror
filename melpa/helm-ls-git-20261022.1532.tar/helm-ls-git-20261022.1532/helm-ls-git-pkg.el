;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ls-git" "20261022.1532"
  "The git project manager for helm."
  '((helm  "3.9.5")
    (emacs "25.3"))
  :url "https://github.com/emacs-helm/helm-ls-git"
  :commit "89c67f7a91648ad4fc7adc6539234270c99bf466"
  :revdesc "89c67f7a9164"
  :keywords '("helm" "convenience" "vc" "files" "buffers" "completion" "diff" "log" "git"))
