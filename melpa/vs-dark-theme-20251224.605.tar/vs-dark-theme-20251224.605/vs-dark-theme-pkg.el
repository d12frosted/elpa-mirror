;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-dark-theme" "20251224.605"
  "Visual Studio IDE dark theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-dark-theme"
  :commit "249f63aec7778334d43bec79c64ee2d8ec60b0fe"
  :revdesc "249f63aec777"
  :keywords '("faces"))
