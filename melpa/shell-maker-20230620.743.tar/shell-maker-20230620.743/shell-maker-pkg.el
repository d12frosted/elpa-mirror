(define-package "shell-maker" "20230620.743" "Interaction mode for making comint shells"
  '((emacs "27.1"))
  :commit "141d37c742fec1b2d090cf1891be687f683f8fad" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
