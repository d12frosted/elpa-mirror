;;; hide-mode-line.el --- minor mode that hides/masks your modeline -*- lexical-binding: t; -*-
;;
;; Copyright (C) 2018-2021 Henrik Lissner
;;
;; Author: Henrik Lissner <http://github/hlissner>
;; Maintainer: Henrik Lissner <contact@henrik.io>
;; Created: March 01, 2018
;; Modified: November 12, 2021
;; Package-Version: 20261126.2053
;; Package-Revision: 2325a2caf51b
;; Keywords: frames mode-line
;; URL: https://github.com/hlissner/emacs-hide-mode-line
;; Package-Requires: ((emacs "24.4"))
;;
;; This file is not part of GNU Emacs.

;;; Commentary:
;;
;; Provides `hide-mode-line-mode`.  A minor mode that hides (or masks) the
;; mode-line in your current buffer.  It can be used to toggle an alternative
;; mode-line, toggle its visibility, or simply disable the mode-line in buffers
;; where it isn't very useful otherwise.
;;
;;; Code:

(defvar hide-mode-line-format nil
  "The modeline format to use when `hide-mode-line-mode' is active.")

(defvar hide-mode-line-excluded-modes '(fundamental-mode)
  "List of major modes where `global-hide-mode-line-mode' won't affect.")

(defvar-local hide-mode-line--old-format nil
  "The buffer's `mode-line-format' before `hide-mode-line-mode' was enabled.
Is nil if nothing is saved, the symbol `default' if the buffer had no
buffer-local value, or a list whose car is the old buffer-local value.")

(defvar hide-mode-line--old-default-format nil
  "The default `mode-line-format' before `global-hide-mode-line-mode'.
Is nil if nothing is saved, otherwise a list whose car is the old value.")

;;;###autoload
(define-minor-mode hide-mode-line-mode
  "Minor mode to hide the mode-line in the current buffer."
  :init-value nil
  :global nil
  (if hide-mode-line-mode
      (progn
        (add-hook 'after-change-major-mode-hook #'hide-mode-line-mode nil t)
        (unless hide-mode-line--old-format
          (setq hide-mode-line--old-format
                (if (local-variable-p 'mode-line-format)
                    (list mode-line-format)
                  'default)))
        (setq mode-line-format hide-mode-line-format))
    (remove-hook 'after-change-major-mode-hook #'hide-mode-line-mode t)
    (if (consp hide-mode-line--old-format)
        (setq mode-line-format (car hide-mode-line--old-format))
      (kill-local-variable 'mode-line-format))
    (kill-local-variable 'hide-mode-line--old-format))
  (when (called-interactively-p 'any)
    (redraw-display)))

;; Changing major modes kills the local `mode-line-format' (and with it, the
;; state saved above), so this hook must survive to hide the new one.
(put 'hide-mode-line-mode 'permanent-local-hook t)

;;;###autoload
(define-globalized-minor-mode global-hide-mode-line-mode
  hide-mode-line-mode turn-on-hide-mode-line-mode
  (if global-hide-mode-line-mode
      (progn
        (unless hide-mode-line--old-default-format
          (setq hide-mode-line--old-default-format
                (list (default-value 'mode-line-format))))
        (setq-default mode-line-format nil))
    (when hide-mode-line--old-default-format
      (setq-default mode-line-format (car hide-mode-line--old-default-format))
      (setq hide-mode-line--old-default-format nil)))
  (redraw-display))

;;;###autoload
(defun turn-on-hide-mode-line-mode ()
  "Turn on `hide-mode-line-mode'.
Unless in `fundamental-mode' or `hide-mode-line-excluded-modes'."
  (unless (memq major-mode hide-mode-line-excluded-modes)
    (hide-mode-line-mode +1)))

;;;###autoload
(defun turn-off-hide-mode-line-mode ()
  "Turn off `hide-mode-line-mode'."
  (hide-mode-line-mode -1))

(provide 'hide-mode-line)
;;; hide-mode-line.el ends here
