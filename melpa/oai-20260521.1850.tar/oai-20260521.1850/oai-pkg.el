;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260521.1850"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "5c3768da0b791f940252c3050b44f30119968368"
  :revdesc "5c3768da0b79"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
