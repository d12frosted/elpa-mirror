(define-package "catppuccin-theme" "20230525.1218" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "da2b14a171c0f81a6294ec433dc174e913f3a747" :authors
  '(("nyxkrage"))
  :maintainers
  '(("Carsten Kragelund" . "carsten@kragelund.me"))
  :maintainer
  '("Carsten Kragelund" . "carsten@kragelund.me")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
