(define-package "consult" "20220126.1847" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "37c0b0b39f5093bd3bcd90862af39167a2479ec4" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
