(define-package "orgtbl-aggregate" "20210817.1958" "Create an aggregated Org table from another one" 'nil :commit "f008a654fd5d99e674b14bbfbb194c7506c2dc41" :keywords
  '("org" "table" "aggregation" "filtering"))
;; Local Variables:
;; no-byte-compile: t
;; End:
