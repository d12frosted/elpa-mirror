;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260701.522"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "134700bc05be6369bf3dff44e10be894be80a654"
  :revdesc "134700bc05be"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
