(define-package "racket-mode" "20231115.1544" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "296de3c15580805f2d84dd30e01eb9b12f18bc3f" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
