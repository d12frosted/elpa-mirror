;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250515.642"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "e1050ef6e5ecbbe31bc35abfa293a5dee75e9647"
  :revdesc "e1050ef6e5ec"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
