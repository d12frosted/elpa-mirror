;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "20260306.1633"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "73957230ffdd3dedf16f4436f61471bd1365abf6"
  :revdesc "73957230ffdd"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
