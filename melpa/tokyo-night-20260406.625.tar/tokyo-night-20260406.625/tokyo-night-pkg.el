;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20260406.625"
  "Shared infrastructure for Tokyo Night themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "1b6ad5621d0e044be1f6777b0474bdfd180ef58c"
  :revdesc "1b6ad5621d0e"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
