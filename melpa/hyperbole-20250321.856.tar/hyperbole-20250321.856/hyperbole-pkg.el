;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250321.856"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e6735c0a2294ae74e2a4bbd4c713f4180bb06690"
  :revdesc "e6735c0a2294"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
