;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "20261025.1447"
  "The Solarized color theme."
  '((emacs "24.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "d8bc6f72dc3e3800a2119bae9733c333d215b04d"
  :revdesc "d8bc6f72dc3e"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
