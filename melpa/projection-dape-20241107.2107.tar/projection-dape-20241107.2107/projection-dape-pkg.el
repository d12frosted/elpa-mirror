;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projection-dape" "20241107.2107"
  "Projection integration for `dape'."
  '((emacs      "29.1")
    (projection "0.1")
    (dape       "0.8"))
  :url "https://github.com/mohkale/projection"
  :commit "50d4f0ec4edfddd24f7c1c540f299a919aa4c151"
  :revdesc "50d4f0ec4edf"
  :keywords '("project" "convenience")
  :authors '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@kisara.moe")))
