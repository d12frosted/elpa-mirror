(define-package "pyramid" "20181212.1204" "Minor mode for working with pyramid projects"
  '((emacs "25.2")
    (pythonic "0.1.1")
    (tablist "0.70"))
  :commit "f0687b8aee3e685b55e2c66b16211e02ac5f9d94" :authors
  (("Daniel Kraus" . "daniel@kraus.my"))
  :maintainer
  ("Daniel Kraus" . "daniel@kraus.my")
  :keywords
  ("python" "pyramid" "pylons" "convenience" "tools" "processes")
  :url "https://github.com/dakra/pyramid.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
