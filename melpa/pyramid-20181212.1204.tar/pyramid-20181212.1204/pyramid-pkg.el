(define-package "pyramid" "20181212.1204" "Minor mode for working with pyramid projects"
  '((emacs "25.2")
    (pythonic "0.1.1")
    (tablist "0.70"))
  :commit "59d7ec03dcb1968160ac1dfe3c979cc83fe0fe4b" :authors
  '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainer
  '("Daniel Kraus" . "daniel@kraus.my")
  :keywords
  '("python" "pyramid" "pylons" "convenience" "tools" "processes")
  :url "https://github.com/dakra/pyramid.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
