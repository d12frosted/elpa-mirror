(define-package "hl-prog-extra" "20230116.1031" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "1caf8e571352438d6cc71e0b695662946efed9b7" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
