;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cframe" "20250126.1800"
  "Customize a frame and fast switch size and positions."
  '((emacs         "26")
    (buffer-manage "1.1")
    (dash          "2.17.0"))
  :url "https://github.com/plandes/cframe"
  :commit "c968e4d9fd6079e60ae90531dac4647a66d7d2b7"
  :revdesc "c968e4d9fd60"
  :keywords '("frames"))
