(define-package "wildcharm-theme" "20230802.530" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "7d4a504a177fd52b860fe1bd84cb00d1fe7904b3" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
