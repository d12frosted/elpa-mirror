;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250427.1624"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "1b449389ab9099bc2cde75f2071e851c1c97bd0b"
  :revdesc "1b449389ab90"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
