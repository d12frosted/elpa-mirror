(define-package "dash" "20210602.1540" "A modern list library for Emacs"
  '((emacs "24"))
  :commit "28103aec4f35856e9b40a50bafeed21d1b56dc68" :authors
  '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainer
  '("Magnar Sveen" . "magnars@gmail.com")
  :keywords
  '("extensions" "lisp")
  :url "https://github.com/magnars/dash.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
