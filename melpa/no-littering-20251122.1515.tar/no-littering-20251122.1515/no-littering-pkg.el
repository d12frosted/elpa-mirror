;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20251122.1515"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "8c54ee35f2633dae183d476e9536bdd1145b8960"
  :revdesc "8c54ee35f263"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
