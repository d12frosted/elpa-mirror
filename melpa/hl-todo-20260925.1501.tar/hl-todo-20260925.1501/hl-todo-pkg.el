;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-todo" "20260925.1501"
  "Highlight TODO and similar keywords."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/hl-todo"
  :commit "7ccf66cdf10b89822802b01ecfa0c3f8693f00d0"
  :revdesc "7ccf66cdf10b"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev")))
