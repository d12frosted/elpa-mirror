;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20251006.1629"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "496063123f332b39b2ef6613dcb62809da89cc1b"
  :revdesc "496063123f33"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
