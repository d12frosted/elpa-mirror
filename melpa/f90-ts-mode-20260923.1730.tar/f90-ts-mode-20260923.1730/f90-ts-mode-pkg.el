;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "20260923.1730"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "29.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "ca6474d1bc68a7e329828f5ddd5c6c535a82c433"
  :revdesc "ca6474d1bc68"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
