(define-package "nordic-night-theme" "20230818.1958" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "9c342c42305d6f57e4b7fa3dec92099da3757b43" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
