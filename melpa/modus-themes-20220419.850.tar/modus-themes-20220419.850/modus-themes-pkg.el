(define-package "modus-themes" "20220419.850" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "0751e312302eedfcc6668bd290cb8e0f25db7a72" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
