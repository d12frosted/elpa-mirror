(define-package "roguel-ike" "20160120.302" "A coffee-break roguelike"
  '((popup "0.5.0"))
  :commit "706dcb0687e8016d7d776f9d9e5ace9fdbbca43c")
;; Local Variables:
;; no-byte-compile: t
;; End:
