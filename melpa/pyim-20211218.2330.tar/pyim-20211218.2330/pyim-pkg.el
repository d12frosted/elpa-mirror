(define-package "pyim" "20211218.2330" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "24.4")
    (async "1.6")
    (xr "1.13"))
  :commit "45c3c761aa9e6cbca49f97981d5ed0996778f884" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
