(define-package "hl-indent-scope" "20221016.508" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "fa2f0f28ad869e83ae3c77d8d936dde5a1e45f24" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
