;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260416.536"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "7564e6011e76be7803a11f707501b6b92a2af8db"
  :revdesc "7564e6011e76"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
