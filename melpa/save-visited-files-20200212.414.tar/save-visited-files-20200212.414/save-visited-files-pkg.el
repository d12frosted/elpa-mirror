;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "save-visited-files" "20200212.414"
  "Save opened files across sessions."
  ()
  :url "https://github.com/nflath/save-visited-files"
  :commit "8203a05a322324ec17b14437c8dfb38efdb53241"
  :revdesc "8203a05a3223"
  :authors '(("Nathaniel Flath" . "nflath@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "nflath@gmail.com")))
