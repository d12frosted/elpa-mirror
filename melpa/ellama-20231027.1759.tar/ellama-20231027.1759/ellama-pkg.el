(define-package "ellama" "20231027.1759" "Tool for interacting with LLMs"
  '((emacs "28.1")
    (llm "0.5.0")
    (spinner "1.7.4"))
  :commit "2e5219afbef9ae0c9adc288d3d13b21e49c847d1" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
