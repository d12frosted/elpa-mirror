;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261024.728"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "a9a82848cd125ef8aa1404b05f2ce15cfc8dddf1"
  :revdesc "a9a82848cd12")
