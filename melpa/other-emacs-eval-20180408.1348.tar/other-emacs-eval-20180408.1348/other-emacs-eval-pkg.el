;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "other-emacs-eval" "20180408.1348"
  "Evaluate the Emacs Lisp expression in other Emacs."
  '((emacs "25.1")
    (async "1.9.2"))
  :url "https://github.com/xuchunyang/other-emacs-eval"
  :commit "8ace5acafef65daabf0c6619eff60733d7f5d792"
  :revdesc "8ace5acafef6"
  :keywords '("tools")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
