(define-package "meow" "20230207.234" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "1994d6b614e31dc226a24ec872e9c8d982cb7418" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
