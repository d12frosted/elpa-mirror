;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-jekyll" "20250830.1006"
  "Major mode managing jekyll blogs."
  '((emacs   "25.1")
    (request "0.3.0"))
  :url "https://github.com/masasam/emacs-easy-jekyll"
  :commit "4e85bb4568f87e08a93d7c5c82898a8e98109669"
  :revdesc "4e85bb4568f8")
