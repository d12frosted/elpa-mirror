(define-package "magik-mode" "20220408.1250" "mode for editing Magik + some utils." 'nil :commit "9c0faba222afc875cf604dd7fe4265f1ff891535" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
