(define-package "perfect-margin" "20231213.1227" "Auto center windows, works with line numbers"
  '((emacs "24.3"))
  :commit "7c812c08125362f608bb059b0547d3e5a8cb264e" :authors
  '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainers
  '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainer
  '("Randall Wang" . "randall.wjz@gmail.com")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/mpwang/perfect-margin")
;; Local Variables:
;; no-byte-compile: t
;; End:
