;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-spacegrey-theme" "20250410.2248"
  "Color theme inspired by the Spacegray theme in Sublime Text."
  '((emacs "26.1"))
  :url "https://gitlab.com/aimebertrand/timu-spacegrey-theme"
  :commit "a90616ae0b110920c8be134cb7ffacee75552ac7"
  :revdesc "a90616ae0b11"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
