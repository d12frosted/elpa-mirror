(define-package "window-purpose" "20210211.1713" "Purpose-based window management for Emacs"
  '((emacs "24.4")
    (let-alist "1.0.3")
    (imenu-list "0.1"))
  :commit "76b2298c27e69941ed5200363fbcac7487875f83" :authors
  '(("Bar Magal"))
  :maintainer
  '("Bar Magal")
  :keywords
  '("frames")
  :url "https://github.com/bmag/emacs-purpose")
;; Local Variables:
;; no-byte-compile: t
;; End:
