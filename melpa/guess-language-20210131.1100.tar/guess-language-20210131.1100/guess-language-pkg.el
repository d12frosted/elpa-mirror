(define-package "guess-language" "20210131.1100" "Robust automatic language detection"
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "e423be90a4c517f8fb032ba4ea6d776a72db03f9" :authors
  '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainer
  '("Titus von der Malsburg" . "malsburg@posteo.de")
  :keywords
  '("wp")
  :url "https://github.com/tmalsburg/guess-language.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
