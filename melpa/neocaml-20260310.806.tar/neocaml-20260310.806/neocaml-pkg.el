;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260310.806"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "04316c7385317781b62adbeca9936f91553998a7"
  :revdesc "04316c738531"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
