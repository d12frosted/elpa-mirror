;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ember-mode" "20240507.915"
  "Ember navigation mode for emacs."
  '((cl-lib "0.5"))
  :url "https://github.com/madnificent/ember-mode"
  :commit "38145ad189000c58860594c05523e42bacb3d246"
  :revdesc "38145ad18900"
  :keywords '("ember" "ember.js" "emberjs")
  :authors '(("Aad Versteden" . "madnificent@gmail.com"))
  :maintainers '(("Aad Versteden" . "madnificent@gmail.com")))
