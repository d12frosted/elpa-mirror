;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperkitty" "20220226.1951"
  "Emacs interface for Hyperkitty archives."
  '((request "0.3.2")
    (emacs   "25.1"))
  :url "https://github.com/maxking/hyperkitty.el"
  :commit "2c1d22ff017d096c359aa151e6a29f7214a58118"
  :revdesc "2c1d22ff017d"
  :keywords '("mail" "hyperkitty" "mailman")
  :authors '(("Abhilash Raj" . "maxking@asynchronous.in"))
  :maintainers '(("Abhilash Raj" . "maxking@asynchronous.in")))
