;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dakrone-theme" "20170801.1933"
  "Dakrone's custom dark theme."
  ()
  :url "https://github.com/dakrone/dakrone-theme"
  :commit "232ad1be5f3572dcbdf528f1655109aa355a6937"
  :revdesc "232ad1be5f35"
  :keywords '("color" "themes")
  :authors '(("Lee Hinman" . "lee_AT_writequit.org"))
  :maintainers '(("Lee Hinman" . "lee_AT_writequit.org")))
