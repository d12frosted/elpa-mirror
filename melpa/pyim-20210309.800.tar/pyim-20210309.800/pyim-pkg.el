(define-package "pyim" "20210309.800" "A Chinese input method support quanpin, shuangpin, wubi and cangjie."
  '((emacs "24.4")
    (async "1.6")
    (xr "1.13"))
  :commit "c510a7d7202ff0d5cc9a49e344cd27de65df1f2a" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
