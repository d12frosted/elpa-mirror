;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark-consult" "20260502.1731"
  "Consult integration for Embark."
  '((emacs   "29.1")
    (compat  "30")
    (embark  "1.1")
    (consult "3.2"))
  :url "https://github.com/oantolin/embark"
  :commit "80254c91da90635978fb12db8b9ab9bf54f3bfb0"
  :revdesc "80254c91da90"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
