;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260926.855"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "84420697005c0e0b2545b9940b612a331682a48d"
  :revdesc "84420697005c"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
