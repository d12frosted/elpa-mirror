;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglink" "20260504.1738"
  "Use Org Mode links in other modes."
  '((emacs  "26.1")
    (compat "31.0")
    (org    "9.7")
    (seq    "2.24"))
  :url "https://github.com/tarsius/orglink"
  :commit "9b54c5e6dfea54b861e5f0975141a02d79ede374"
  :revdesc "9b54c5e6dfea"
  :keywords '("hypermedia")
  :authors '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev")))
