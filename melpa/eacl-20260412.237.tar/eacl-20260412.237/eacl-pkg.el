;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eacl" "20260412.237"
  "Auto-complete lines by grepping project."
  '((emacs "27.1"))
  :url "https://github.com/redguardtoo/eacl"
  :commit "5a304e4655a28cc817b9a633304bd64a5d5ddf53"
  :revdesc "5a304e4655a2"
  :keywords '("abbrev" "convenience" "matching"))
