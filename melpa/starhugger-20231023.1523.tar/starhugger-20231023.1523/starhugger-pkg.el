(define-package "starhugger" "20231023.1523" "Hugging Face/AI-powered text & code completion client"
  '((emacs "28.2")
    (compat "29.1.4.0")
    (dash "2.18.0")
    (s "1.13.1")
    (spinner "1.7.4"))
  :commit "8e1bc1167a64cc421ce3d1368a9c0e5da89bf687" :keywords
  '("completion" "convenience" "languages")
  :url "https://gitlab.com/daanturo/starhugger.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
