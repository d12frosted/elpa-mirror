;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260201.1458"
  "Support for Org links to Magit buffers."
  '((emacs    "28.1")
    (compat   "30.1")
    (cond-let "0.2")
    (magit    "4.5")
    (org      "9.7"))
  :url "https://github.com/magit/orgit"
  :commit "39cb93b283c1b4ac05025eb17a43ccc623e44686"
  :revdesc "39cb93b283c1"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
