(define-package "dirvish" "20220308.1908" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "6be5740c3ef610e3b4d254ea66e3acc46827b8f3" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
