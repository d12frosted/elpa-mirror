(define-package "dirvish" "20220308.1908" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "aa1ae34633e2d15574ae85d894725561c9eb78a0" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
