;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kanban" "20250501.957"
  "Parse org-todo headlines to use org-tables as Kanban tables."
  ()
  :commit "6bfdc94e4cee0f946fc032a2471898b945e25aea"
  :revdesc "6bfdc94e4cee"
  :keywords '("outlines" "convenience")
  :authors '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainers '(("Arne Babenhauserheide" . "arne_bab@web.de")))
