;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20261010.2023"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.14.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "159c64df0fda5a2cda5b741778c2e08eadbef68f"
  :revdesc "159c64df0fda"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
