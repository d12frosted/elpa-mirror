;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260119.1334"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "6ffc61939d461df590f6913176c22bfecdda82e1"
  :revdesc "6ffc61939d46"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
