;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20261114.641"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "bd6b67b0c55a9a0652346b04e4ee1b295bcfe6e0"
  :revdesc "bd6b67b0c55a"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
