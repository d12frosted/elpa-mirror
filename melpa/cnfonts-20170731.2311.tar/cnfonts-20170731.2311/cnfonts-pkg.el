(define-package "cnfonts" "20170731.2311" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "cbe1ddd49e33b790a568c55351146aa5b909f173" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
