;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trailing-newline-indicator" "20260111.2138"
  "Show an indicator for the trailing newline."
  '((emacs "26.1"))
  :url "https://github.com/saulotoledo/trailing-newline-indicator"
  :commit "7a53505df0b76784680b8fc2a97b11e259788a74"
  :revdesc "7a53505df0b7"
  :keywords '("convenience" "display" "editing")
  :authors '(("Saulo S. de Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo S. de Toledo" . "saulotoledo@gmail.com")))
