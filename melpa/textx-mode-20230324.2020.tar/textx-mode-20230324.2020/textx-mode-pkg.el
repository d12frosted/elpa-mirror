;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "textx-mode" "20230324.2020"
  "Major mode for editing TextX files."
  '((emacs "24.3"))
  :url "https://github.com/novakboskov/textx-mode"
  :commit "ecf90abec508cfd82d5da68474e976be907d9a77"
  :revdesc "ecf90abec508"
  :keywords '("textx")
  :authors '(("Novak Boškov" . "gnovak.boskov@gmail.com"))
  :maintainers '(("Novak Boškov" . "gnovak.boskov@gmail.com")))
