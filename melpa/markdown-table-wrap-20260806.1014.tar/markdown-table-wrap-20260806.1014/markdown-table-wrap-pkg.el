;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-table-wrap" "20260806.1014"
  "Word-wrap GFM pipe tables to fit window width."
  '((emacs "28.1"))
  :url "https://github.com/dnouri/markdown-table-wrap"
  :commit "f846b77d13f34fba57c80214c1a61e00c94048a3"
  :revdesc "f846b77d13f3"
  :keywords '("text" "markdown" "tables")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
