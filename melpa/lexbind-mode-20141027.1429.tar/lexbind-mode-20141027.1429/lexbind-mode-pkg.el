;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lexbind-mode" "20141027.1429"
  "Puts the value of lexical-binding in the mode line."
  ()
  :url "https://github.com/spacebat/lexbind-mode"
  :commit "fa0a6848c1cfd3fbf45db43dc2deef16377d887d"
  :revdesc "fa0a6848c1cf"
  :keywords '("convenience" "lisp")
  :authors '(("Andrew Kirkpatrick" . "ubermonk@gmail.com"))
  :maintainers '(("Andrew Kirkpatrick" . "ubermonk@gmail.com")))
