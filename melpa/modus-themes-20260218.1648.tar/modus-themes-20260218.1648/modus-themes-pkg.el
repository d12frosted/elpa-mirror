;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260218.1648"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "122d53333f8faafffc44e4ccf5f28021f61da743"
  :revdesc "122d53333f8f"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
