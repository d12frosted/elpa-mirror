(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "d8818317f5dad0eadb51160389591a5081fa062c")
;; Local Variables:
;; no-byte-compile: t
;; End:
