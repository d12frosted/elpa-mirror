(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "f7c80281c7005ba5965a8fc410708c08119cfee6")
;; Local Variables:
;; no-byte-compile: t
;; End:
