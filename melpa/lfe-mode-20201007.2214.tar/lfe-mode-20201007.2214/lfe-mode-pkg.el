(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "48f7bafb559ca7d14be55a85466f33d3c4fc38e4")
;; Local Variables:
;; no-byte-compile: t
;; End:
