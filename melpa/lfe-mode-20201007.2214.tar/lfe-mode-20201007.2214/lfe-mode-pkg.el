(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "5bb4b76b1d1d2453de69920b3a1a6b2a302aea07")
;; Local Variables:
;; no-byte-compile: t
;; End:
