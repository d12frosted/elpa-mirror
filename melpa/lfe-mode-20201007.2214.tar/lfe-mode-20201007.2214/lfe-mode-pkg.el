(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "dbfd16af065b12d2dbce26ff1fbad151765243fd")
;; Local Variables:
;; no-byte-compile: t
;; End:
