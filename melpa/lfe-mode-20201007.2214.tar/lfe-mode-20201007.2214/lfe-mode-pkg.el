(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "7be14cb23a72b2c445519281e4e2fb9b607f9a8b")
;; Local Variables:
;; no-byte-compile: t
;; End:
