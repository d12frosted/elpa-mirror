(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "f762e9310390edb7a5a49d8d9dc22693fbcde973")
;; Local Variables:
;; no-byte-compile: t
;; End:
