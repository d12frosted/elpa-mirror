;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lirve" "20260708.1737"
  "Learn irregular verbs in English."
  '((emacs "26.1"))
  :url "https://git.andros.dev/andros/lirve.el"
  :commit "b8dfa92eb51bde15c269dede50342f0b94240a49"
  :revdesc "b8dfa92eb51b"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
