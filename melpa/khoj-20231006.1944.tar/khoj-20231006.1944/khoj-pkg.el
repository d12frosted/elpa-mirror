(define-package "khoj" "20231006.1944" "AI personal assistant for your digital brain"
  '((emacs "27.1")
    (transient "0.3.0")
    (dash "2.19.1"))
  :commit "f6f7a62d8076580e8794b18cee20ba86dd95a0e6" :authors
  '(("Debanjum Singh Solanky" . "debanjum@gmail.com"))
  :maintainers
  '(("Debanjum Singh Solanky" . "debanjum@gmail.com"))
  :maintainer
  '("Debanjum Singh Solanky" . "debanjum@gmail.com")
  :keywords
  '("search" "chat" "org-mode" "outlines" "markdown" "pdf" "image")
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
