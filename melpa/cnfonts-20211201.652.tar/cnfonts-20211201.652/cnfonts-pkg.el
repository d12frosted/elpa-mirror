(define-package "cnfonts" "20211201.652" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "58a64357b42aced78b8cb47876eecde4c24e5def" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
