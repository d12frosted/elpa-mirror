;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20261105.136"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://codeberg.org/okamsn/loopy"
  :commit "b75089cdf0a7b004b44ea703d80c47ac821b2635"
  :revdesc "b75089cdf0a7"
  :keywords '("extensions"))
