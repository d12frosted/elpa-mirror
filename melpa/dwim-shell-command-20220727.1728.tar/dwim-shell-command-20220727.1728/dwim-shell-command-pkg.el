(define-package "dwim-shell-command" "20220727.1728" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "bd87d12bc7e8c28534172ae076809a368b3ae654" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
