(define-package "spdx" "20220909.204" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "e1331e2b6531e70cbb85def22757ad8078e64891" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
