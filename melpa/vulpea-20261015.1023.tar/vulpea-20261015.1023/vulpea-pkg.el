;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261015.1023"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "74d77d11c11f93745fdf88e3a8d00599aee80960"
  :revdesc "74d77d11c11f"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
