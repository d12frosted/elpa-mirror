;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "20241120.1329"
  "Slack client for Emacs."
  '((websocket "1.8")
    (request   "0.2.0")
    (oauth2    "0.10")
    (circe     "2.2")
    (alert     "1.2")
    (emojify   "0.2")
    (emacs     "25.1")
    (dash      "2.19.1")
    (s         "1.13.1"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "549cbb8dc800288f00be3c97e3f34b3f42bf9a71"
  :revdesc "549cbb8dc800"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
