(define-package "emms" "20231027.2131" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (seq "0"))
  :commit "cdea73e122e07c39678606bf876be925589a51f9" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers
  '(("Yoni Rabkin" . "yrk@gnu.org"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
