(define-package "keg" "20211019.719" "Modern Elisp package development system"
  '((emacs "24.1")
    (cl-lib "0.6"))
  :commit "de9011babac9dadd7aeff9700fa6e21ca093aa30" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
