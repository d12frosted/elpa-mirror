(define-package "detached" "20221108.1827" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "669113092ce7a927c5988e302215f9f1183f52f4" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
