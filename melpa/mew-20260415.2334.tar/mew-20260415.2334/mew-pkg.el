;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260415.2334"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "ced187bbc3dcd2594edc21137e232d398d75da2d"
  :revdesc "ced187bbc3dc")
