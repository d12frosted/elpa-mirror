(define-package "slime" "20240210.2136" "Superior Lisp Interaction Mode for Emacs"
  '((emacs "24.3")
    (macrostep "0.9"))
  :commit "2c2e90cb6f4eb4d3a839a10d57384f983079cf15" :keywords
  '("languages" "lisp" "slime")
  :url "https://github.com/slime/slime")
;; Local Variables:
;; no-byte-compile: t
;; End:
