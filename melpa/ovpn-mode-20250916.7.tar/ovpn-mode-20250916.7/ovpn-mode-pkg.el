;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ovpn-mode" "20250916.7"
  "An openvpn management mode."
  '((emacs  "25")
    (cl-lib "0.5"))
  :url "https://github.com/anticomputer/ovpn-mode"
  :commit "0474294b76f3a7b468c94090352fe71f7aedeebf"
  :revdesc "0474294b76f3"
  :keywords '("comm")
  :authors '(("Bas Alberts" . "bas@anti.computer"))
  :maintainers '(("Bas Alberts" . "bas@anti.computer")))
