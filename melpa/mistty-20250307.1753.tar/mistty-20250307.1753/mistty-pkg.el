;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250307.1753"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "8c2c659b97f69ad077a2084eefac382a0e9e6c82"
  :revdesc "8c2c659b97f6"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
