(define-package "orgtbl-aggregate" "20210819.1739" "Create an aggregated Org table from another one" 'nil :commit "141577373600e7be16a5b67284165f54e8743505" :keywords
  '("org" "table" "aggregation" "filtering"))
;; Local Variables:
;; no-byte-compile: t
;; End:
