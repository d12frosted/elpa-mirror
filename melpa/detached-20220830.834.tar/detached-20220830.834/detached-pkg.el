(define-package "detached" "20220830.834" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "d58230fadbf9fc161a4c6fb3662ca128bea2449f" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
