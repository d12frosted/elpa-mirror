;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261127.1633"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "f15e4bf82c596268949f0da16530f031edcefa0e"
  :revdesc "f15e4bf82c59"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
