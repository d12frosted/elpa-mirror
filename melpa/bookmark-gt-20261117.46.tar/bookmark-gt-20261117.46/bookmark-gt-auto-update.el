;;; bookmark-gt-auto-update.el --- Track and refresh bookmarks under editing  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Daniel M. German <dmg@turingmachine.org>

;; Author: Daniel M. German <dmg@turingmachine.org>
;; Maintainer: Daniel M. German <dmg@turingmachine.org>
;; Assisted-by: Claude:claude-opus-4-7
;; Keywords: convenience, matching, hypermedia
;; URL: https://github.com/dmgerman/bookmark-gt

;; SPDX-License-Identifier: GPL-3.0-or-later
;;
;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; A bookmark carrying the `auto-update' alist property is refreshed
;; to the current point of the buffer visiting its file, on three
;; triggers:
;;
;;   - An idle timer firing every `bookmark-gt-auto-update-interval'
;;     seconds.
;;   - `kill-buffer-hook'         (catches "closing the file").
;;   - `window-state-change-hook' (catches "switching away").
;;   - `bookmark-gt-list-before-read-hook' (opening or reverting the
;;     list buffer).
;;
;; The refresh only runs while `bookmark-gt-auto-update-mode' is on.
;; The mode is off by default — enable it globally with
;; `(bookmark-gt-auto-update-mode 1)' or interactively.
;;
;; Per-bookmark toggle: `bookmark-gt-auto-update-toggle NAME', and
;; `^' in the list buffer, which runs
;; `bookmark-gt-list-toggle-auto-update' (defined here, bound in the
;; list buffer's keymap).  The list buffer shows a `^' glyph in its
;; dedicated column for any record with the property set, whether or
;; not the tracking timer is currently running.

;;; Code:

(require 'bookmark)
(require 'seq)
(require 'bookmark-gt-core)
(require 'bookmark-gt-list)

;;;; Customization

(defcustom bookmark-gt-auto-update-interval 60
  "Seconds of idle time between ticks of `bookmark-gt-auto-update-mode'."
  :type 'integer
  :group 'bookmark-gt)

(defcustom bookmark-gt-auto-update-preserve-fields
  '(handler tags annotation auto-update visits last-visited defaults)
  "Alist keys never overwritten during an auto-update refresh.
Every other field returned by the buffer's
`bookmark-make-record-function' replaces the bookmark's value."
  :type '(repeat symbol)
  :group 'bookmark-gt)

;;;; Predicate

(defun bookmark-gt-auto-update-p (record)
  "Return non-nil when RECORD carries the `auto-update' property."
  (bookmark-prop-get record 'auto-update))

;;;; Toggle

;;;###autoload
(defun bookmark-gt-auto-update-toggle (&optional bookmark)
  "Toggle the `auto-update' property on BOOKMARK.
BOOKMARK is a record, a name, or an id; nil prompts.  A name
shared by several bookmarks asks which one rather than taking
the first.

Runs `bookmark-gt-record-changed-hook' with the updated record so
the list buffer and any other observers refresh."
  (interactive)
  (let* ((record (bookmark-gt--resolve bookmark "Toggle auto-update"))
         (current (bookmark-gt-auto-update-p record)))
    (bookmark-gt-auto-update-set record (not current))
    (message "%s auto-update on %S"
             (if current "Disabled" "Enabled")
             (bookmark-name-from-full-record record))))

;;;###autoload
(defun bookmark-gt-auto-update-set (record flag &optional no-notify)
  "Set the `auto-update' property on RECORD according to FLAG.
RECORD is a `(NAME . DATA)' pair or a bookmark name.  FLAG
non-nil sets the property; nil removes it.  When NO-NOTIFY is
non-nil, skip UI refresh and the external
`bookmark-gt-record-changed-hook' — the caller is expected to notify
once at end of a batch.  Returns the mutated record."
  (let ((entry (bookmark-get-bookmark record)))
    (unless entry
      (user-error "No bookmark called %S" record))
    (if flag
        (unless (bookmark-gt-auto-update-p entry)
          (setcdr entry (cons (cons 'auto-update t) (cdr entry))))
      (setcdr entry (assq-delete-all 'auto-update (cdr entry))))
    (if no-notify
        (bookmark-gt--stamp-modified entry)
      (bookmark-gt--after-mutation entry 'auto-update))
    entry))

;;;; Refresh

(defun bookmark-gt-auto-update--refresh (record buffer)
  "Refresh RECORD's position from BUFFER.
Calls BUFFER's `bookmark-make-record-function' so the update
uses the mode-appropriate recorder.  Every field in the fresh
record replaces the bookmark's value, except those listed in
`bookmark-gt-auto-update-preserve-fields'."
  (with-current-buffer buffer
    (let* ((raw (funcall bookmark-make-record-function))
           (fresh (if (stringp (car-safe raw)) (cdr raw) raw)))
      (dolist (cell fresh)
        (let ((field (car cell)))
          (unless (memq field bookmark-gt-auto-update-preserve-fields)
            (bookmark-prop-set (car record) field (cdr cell))))))))

(defun bookmark-gt-auto-update--buffer-for-record (record)
  "Return the live buffer visiting RECORD's file, or nil."
  (let ((file (bookmark-prop-get record 'filename)))
    (and file (find-buffer-visiting file))))

(defun bookmark-gt-auto-update-tick (&optional only-buffer)
  "Refresh every auto-update bookmark whose file is currently visited.
When ONLY-BUFFER is non-nil, restrict to records whose file
matches that buffer."
  (let ((target-file (and only-buffer (buffer-file-name only-buffer)))
        ;; Runs from an idle timer.  Resolution refuses to prompt
        ;; while this is set, rather than opening a minibuffer
        ;; nobody is waiting at.
        (bookmark-gt--in-timer t))
    (dolist (record bookmark-alist)
      (when (bookmark-gt-auto-update-p record)
        (let ((buffer (if target-file
                          (and (equal (bookmark-prop-get record 'filename)
                                      target-file)
                               only-buffer)
                        (bookmark-gt-auto-update--buffer-for-record record))))
          (when (buffer-live-p buffer)
            (bookmark-gt-auto-update--refresh record buffer)))))))

;;;###autoload
(defun bookmark-gt-auto-update-now ()
  "Force an immediate refresh of every auto-update bookmark."
  (interactive)
  ;; "Every" has to mean every record in the file, so this asks for
  ;; the load that `bookmark-gt-auto-update-tick' does not: the
  ;; tick also runs from an idle timer, where reading the file is a
  ;; side effect nobody asked for.  A tick with nothing loaded has
  ;; nothing to refresh, which the next operation puts right.
  (bookmark-maybe-load-default-file)
  (bookmark-gt-auto-update-tick)
  (when (called-interactively-p 'interactive)
    (message "Auto-update bookmarks refreshed")))

;;;; List buffer command

;;;###autoload
(defun bookmark-gt-list-toggle-auto-update ()
  "Toggle `auto-update' on the marked bookmarks, or the one at point.
With several rows marked, all of them are set to the same
value: on unless every one of them already has the property, in
which case all are turned off."
  (interactive nil bookmark-gt-list-mode)
  (let* ((records (bookmark-gt-list--records-to-act-on))
         (flag (bookmark-gt-list--toggle-target
                records #'bookmark-gt-auto-update-p)))
    (dolist (record records)
      (bookmark-gt-auto-update-set record flag t))
    (bookmark-gt-list--finish records)
    (message "%s auto-update on %s"
             (if flag "Enabled" "Disabled")
             (if (cdr records)
                 (format "%d bookmarks" (length records))
               (format "%S" (car (car records)))))))

;;;; Timer + hooks
;;
;; The timer is the one piece of process-scoped state this module
;; owns: a resource handle kept so the timer can be cancelled when
;; the mode is turned off.

(defvar bookmark-gt-auto-update--timer nil
  "Idle timer object for `bookmark-gt-auto-update-mode'.
Held so it can be cancelled on mode-off.  Nil when the mode is
inactive.")

(defun bookmark-gt-auto-update--on-kill-buffer ()
  "Refresh any auto-update bookmark whose file is the buffer being killed."
  (when (buffer-file-name)
    (bookmark-gt-auto-update-tick (current-buffer))))

(defun bookmark-gt-auto-update--on-window-state-change ()
  "Refresh auto-update bookmarks for any buffer newly visible in a window."
  (bookmark-gt-auto-update-tick))

(defun bookmark-gt-auto-update--arm ()
  "Start the idle timer and register the trigger hooks."
  (unless bookmark-gt-auto-update--timer
    (setq bookmark-gt-auto-update--timer
          (run-with-idle-timer bookmark-gt-auto-update-interval
                               t #'bookmark-gt-auto-update-tick)))
  (add-hook 'kill-buffer-hook #'bookmark-gt-auto-update--on-kill-buffer)
  (add-hook 'window-state-change-hook
            #'bookmark-gt-auto-update--on-window-state-change)
  (add-hook 'bookmark-gt-list-before-read-hook #'bookmark-gt-auto-update-tick))

(defun bookmark-gt-auto-update--disarm ()
  "Cancel the idle timer and remove the trigger hooks."
  (when bookmark-gt-auto-update--timer
    (cancel-timer bookmark-gt-auto-update--timer)
    (setq bookmark-gt-auto-update--timer nil))
  (remove-hook 'kill-buffer-hook #'bookmark-gt-auto-update--on-kill-buffer)
  (remove-hook 'window-state-change-hook
               #'bookmark-gt-auto-update--on-window-state-change)
  (remove-hook 'bookmark-gt-list-before-read-hook
               #'bookmark-gt-auto-update-tick))

;;;; Global mode

;;;###autoload
(define-minor-mode bookmark-gt-auto-update-mode
  "Global minor mode that keeps auto-update bookmarks current.

When enabled, an idle timer (interval
`bookmark-gt-auto-update-interval') refreshes every bookmark
carrying the `auto-update' alist property to the current point
of the buffer visiting its file.  `kill-buffer-hook' and
`window-state-change-hook' also trigger a refresh, so a
buffer close or window switch is captured without waiting for
the next idle tick, and opening or reverting the list buffer
refreshes before it draws (`bookmark-gt-list-before-read-hook').

Turning the mode off cancels the timer and removes the three
hooks.  Bookmark records keep their `auto-update' property;
tracking just stops running.  Re-enable to resume."
  :global t
  :group 'bookmark-gt
  (if bookmark-gt-auto-update-mode
      (bookmark-gt-auto-update--arm)
    (bookmark-gt-auto-update--disarm)))

(provide 'bookmark-gt-auto-update)


;; Local Variables:
;; package-lint-main-file: "bookmark-gt.el"
;; End:

;;; bookmark-gt-auto-update.el ends here
