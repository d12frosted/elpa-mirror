;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bookmark-gt" "20261117.46"
  "Records-only bookmark manager."
  '((emacs "30.1"))
  :url "https://github.com/dmgerman/bookmark-gt"
  :commit "7f4be1847aba8ef543393b085b0b8792d29bee99"
  :revdesc "7f4be1847aba"
  :keywords '("convenience" "matching" "hypermedia")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
