(define-package "gap-mode" "20230609.506" "Major mode for editing files in the GAP programming language." 'nil :commit "4da309e209370d5bcbeadab79f509de50a5db240" :authors
  '(("Michael Smith" . "smith@pell.anu.edu.au")
    ("Gary Zablackis")
    ("Goetz Pfeiffer")
    ("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainers
  '(("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainer
  '("Ivan Andrus" . "darthandrus@gmail.com")
  :keywords
  '("gap")
  :url "https://gitlab.com/gvol/gap-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
