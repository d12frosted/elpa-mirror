;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260701.538"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "b26c0cfd9ed9580cfca04bf47a17df4ac3e0fef7"
  :revdesc "b26c0cfd9ed9"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
