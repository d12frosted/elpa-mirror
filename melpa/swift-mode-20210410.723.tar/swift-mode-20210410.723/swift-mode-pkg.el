(define-package "swift-mode" "20210410.723" "Major-mode for Apple's Swift programming language"
  '((emacs "24.4")
    (seq "2.3"))
  :commit "9676f906f222fcb23d3196c43bb7ccc75fc98984" :keywords
  '("languages" "swift")
  :url "https://github.com/swift-emacs/swift-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
