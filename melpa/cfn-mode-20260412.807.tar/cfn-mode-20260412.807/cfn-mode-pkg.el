;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260412.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "7ed737240b25b03fd5b7eb05d5f3b2e8a21a2de3"
  :revdesc "7ed737240b25"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
