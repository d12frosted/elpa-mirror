;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "humanoid-themes" "20251106.1956"
  "Color themes with a dark and light variant."
  '((emacs "27.1"))
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes"
  :commit "4adf696a5d9968f6328f488a1f606558cfc8f940"
  :revdesc "4adf696a5d99"
  :keywords '("faces" "color" "theme"))
