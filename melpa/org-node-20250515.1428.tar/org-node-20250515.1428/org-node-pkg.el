;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250515.1428"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.8.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f3f273b1febb6841ec805fc83a99f7b9e5bb5468"
  :revdesc "f3f273b1febb"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
