(define-package "sml-basis" "20210516.1815" "Standard ML Basis Library lookup"
  '((emacs "24.5"))
  :commit "ed267b95e762625cca509ed6fb56c7359d857158" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/lassik/emacs-sml-basis")
;; Local Variables:
;; no-byte-compile: t
;; End:
