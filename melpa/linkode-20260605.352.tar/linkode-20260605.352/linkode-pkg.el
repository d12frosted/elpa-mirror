;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linkode" "20260605.352"
  "Generate a linkode snippet with region/buffer content."
  ()
  :url "https://github.com/erickgnavar/linkode.el"
  :commit "8bfb80ca046bc0c942a14effef354722ad8a8a6c"
  :revdesc "8bfb80ca046b"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
