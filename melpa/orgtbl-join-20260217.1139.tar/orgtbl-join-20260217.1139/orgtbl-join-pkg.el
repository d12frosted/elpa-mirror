;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260217.1139"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "bd9edf54bdd55d1d33b8c6fb51a7f23a78c09355"
  :revdesc "bd9edf54bdd5"
  :keywords '("data" "extensions"))
