;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-org-clock-menubar" "20150205.2111"
  "Simple menubar integration for org-clock."
  ()
  :url "https://github.com/jordonbiondo/osx-org-clock-menubar"
  :commit "9964d2a97cc2fb6570dc4116da44f73bd8eb7cb3"
  :revdesc "9964d2a97cc2"
  :keywords '("org" "osx")
  :authors '(("Jordon Biondo" . "jordonbiondo@gmail.com"))
  :maintainers '(("Jordon Biondo" . "jordonbiondo@gmail.com")))
