(define-package "vhdl-ext" "20230916.2152" "VHDL Extensions"
  '((emacs "29.1")
    (vhdl-ts-mode "0.1.0")
    (eglot "1.9")
    (lsp-mode "8.0.0")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "32")
    (outshine "3.0.1")
    (async "1.9.7"))
  :commit "daa17bcdab576304a70a70986195f32129db0e48" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
