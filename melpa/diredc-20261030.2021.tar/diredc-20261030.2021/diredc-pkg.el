;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20261030.2021"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "ddde288914a58c64bd2d93e23acb9612a6efbe5b"
  :revdesc "ddde288914a5"
  :keywords '("files"))
