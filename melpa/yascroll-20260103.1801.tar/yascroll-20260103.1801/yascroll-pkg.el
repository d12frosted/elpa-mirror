;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yascroll" "20260103.1801"
  "Yet Another Scroll Bar Mode."
  '((emacs "26.1"))
  :url "https://github.com/emacsorphanage/yascroll"
  :commit "c0a302e6a44169c290564174c48298572f418f62"
  :revdesc "c0a302e6a441"
  :keywords '("convenience")
  :authors '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
