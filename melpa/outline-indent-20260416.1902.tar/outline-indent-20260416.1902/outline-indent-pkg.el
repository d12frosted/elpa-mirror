;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260416.1902"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "b25886d0b6a6de1b6c3e881230e41b76ad8652e0"
  :revdesc "b25886d0b6a6"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
