;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260429.1730"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "6e55379317a3f402b95ab65f3da0dc59f0f154bf"
  :revdesc "6e55379317a3"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
