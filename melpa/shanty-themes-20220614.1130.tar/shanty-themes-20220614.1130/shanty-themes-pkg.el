(define-package "shanty-themes" "20220614.1130" "The themes for digital workers"
  '((emacs "27.2"))
  :commit "7beb53d68b75b0a2a8bbb7254303889dbbdbd1ae" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
