;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iss-mode" "20141001.1913"
  "Mode for InnoSetup install scripts."
  ()
  :url "https://github.com/rasmus-toftdahl-olesen/iss-mode"
  :commit "3b517aff31529bab33f8d7b562bd17aff0107fd1"
  :revdesc "3b517aff3152"
  :authors '((nil . "stefan@xsteve.at"))
  :maintainers '((nil . "stefan@xsteve.at")))
