(define-package "dwim-shell-command" "20231108.1028" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "a9d8d500d13d0a55cfd04ea8eb5510fc93f2021f" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
