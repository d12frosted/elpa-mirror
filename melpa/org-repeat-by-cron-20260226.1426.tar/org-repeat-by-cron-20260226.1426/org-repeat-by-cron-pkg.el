;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-repeat-by-cron" "20260226.1426"
  "An Org mode task repeater based on Cron expressions."
  '((emacs "24.4"))
  :url "https://github.com/TomoeMami/org-repeat-by-cron.el"
  :commit "6586282bd13dc43626b11028c8917f23e0494b66"
  :revdesc "6586282bd13d"
  :keywords '("calendar")
  :authors '(("TomoeMami" . "trembleafterme@outlook.com"))
  :maintainers '(("TomoeMami" . "trembleafterme@outlook.com")))
