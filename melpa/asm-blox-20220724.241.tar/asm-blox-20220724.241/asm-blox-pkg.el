(define-package "asm-blox" "20220724.241" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.3.4"))
  :commit "274beab092dcc169b9887f7734a5f82b892e7702" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
