(define-package "yatex" "20220921.208" "Yet Another tex-mode for emacs //野鳥//" 'nil :commit "91a6b97d01fadad960aece159b86fd8861fcd1cd")
;; Local Variables:
;; no-byte-compile: t
;; End:
