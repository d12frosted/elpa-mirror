;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plur" "20160504.924"
  "Easily search and replace multiple variants of a word."
  '((emacs "24.4"))
  :url "https://github.com/xuchunyang/plur"
  :commit "5bdd3b9a2f0624414bd596e798644713cd1545f0"
  :revdesc "5bdd3b9a2f06"
  :authors '(("Chunyang Xu" . "xuchunyang.me@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang.me@gmail.com")))
