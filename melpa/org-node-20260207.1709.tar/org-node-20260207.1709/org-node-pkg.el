;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260207.1709"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "1978b2b83f22ba817cd6d0f45d1bd6e3420afd2b"
  :revdesc "1978b2b83f22"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
