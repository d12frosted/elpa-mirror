(define-package "jinx" "20240310.1041" "Enchanted Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "b2ef3af2857896e20cff0488c46a4bfcfee39ecc" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "text")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
