(define-package "popper" "20220126.844" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "a50edecacf2939fc50ad2bc48f1015486a09f885" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
