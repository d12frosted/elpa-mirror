(define-package "flim" "20220720.1311" "A library to provide basic features about message representation or encoding."
  '((emacs "24.5")
    (apel "10.8")
    (oauth2 "0.11"))
  :commit "b27f4ae0bff18791bf41efa346cdc2eb35ad53e7")
;; Local Variables:
;; no-byte-compile: t
;; End:
