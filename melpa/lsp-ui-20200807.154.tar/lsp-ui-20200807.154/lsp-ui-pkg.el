(define-package "lsp-ui" "20200807.154" "UI modules for lsp-mode"
  '((emacs "26.1")
    (dash "2.14")
    (dash-functional "1.2.0")
    (lsp-mode "6.0")
    (markdown-mode "2.3"))
  :commit "449f3a6b80a60d88c4ed300e69d64eb8e875f1c7" :authors
  '(("Sebastien Chapuis <sebastien@chapu.is>, Fangrui Song" . "i@maskray.me"))
  :maintainer
  '("Sebastien Chapuis <sebastien@chapu.is>, Fangrui Song" . "i@maskray.me")
  :keywords
  '("languages" "tools")
  :url "https://github.com/emacs-lsp/lsp-ui")
;; Local Variables:
;; no-byte-compile: t
;; End:
