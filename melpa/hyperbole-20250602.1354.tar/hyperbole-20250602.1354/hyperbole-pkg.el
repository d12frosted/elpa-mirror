;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250602.1354"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "8e4d0ffb70c59fcdf4d447676113be8673282185"
  :revdesc "8e4d0ffb70c5"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
