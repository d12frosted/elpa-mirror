(define-package "tawny-mode" "20210528.1710" "Ontology Editing with Tawny-OWL"
  '((cider "0.12")
    (emacs "25"))
  :commit "5da72b601cb9f052f35e88c41f1a18b326c03791" :authors
  '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
  :maintainers
  '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
  :maintainer
  '("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
;; Local Variables:
;; no-byte-compile: t
;; End:
