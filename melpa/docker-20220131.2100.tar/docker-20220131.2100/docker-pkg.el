(define-package "docker" "20220131.2100" "Emacs interface to Docker"
  '((dash "2.14.1")
    (docker-tramp "0.1")
    (emacs "24.5")
    (json-mode "1.7.0")
    (s "1.12.0")
    (tablist "0.70")
    (transient "0.2.0"))
  :commit "ff8a564622df8cf086e4ace9eb4251a74b20f77b" :authors
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainer
  '("Philippe Vaucher" . "philippe.vaucher@gmail.com")
  :keywords
  '("filename" "convenience")
  :url "https://github.com/Silex/docker.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
