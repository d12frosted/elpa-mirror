;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260122.1028"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7a02091f48387fb3d5ba7eadd35d9fd80e3dd9e0"
  :revdesc "7a02091f4838")
