(define-package "doom-themes" "20210525.827" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "6db51c033f0eba6110e9af97d43817fca539f25d" :authors
  '(("Henrik Lissner <http://github/hlissner>"))
  :maintainer
  '("Henrik Lissner" . "henrik@lissner.net")
  :keywords
  '("dark" "light" "blue" "atom" "one" "theme" "neotree" "icons" "faces" "nova")
  :url "https://github.com/hlissner/emacs-doom-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
