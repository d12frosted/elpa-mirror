(define-package "citre" "20210902.751" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "09b618f73c47abebcd26c8fc8484a5816c36ab6f" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
