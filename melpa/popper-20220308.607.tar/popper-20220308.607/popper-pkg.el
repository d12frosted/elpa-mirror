(define-package "popper" "20220308.607" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "3212241316f7da42d2848700dbb23f09f768df4e" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
