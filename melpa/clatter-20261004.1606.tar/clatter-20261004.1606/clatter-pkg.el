;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20261004.1606"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "cd53806fad981ac91af15408ee42eea099fc3321"
  :revdesc "cd53806fad98"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
