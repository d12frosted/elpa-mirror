(define-package "shen-elisp" "20210530.349" "Shen implementation in Elisp"
  '((emacs "24.4"))
  :commit "dabb829d0d86f454ceb3b0846cdfc11af1f91cc7" :authors
  '(("Aditya Siram" . "aditya.siram@gmail.com"))
  :maintainer
  '("Aditya Siram" . "aditya.siram@gmail.com")
  :url "https://github.com/deech/shen-elisp")
;; Local Variables:
;; no-byte-compile: t
;; End:
