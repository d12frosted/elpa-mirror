(define-package "clojure-mode" "20230823.1453" "Major mode for Clojure code"
  '((emacs "25.1"))
  :commit "dae21f8807c80297b9d69aefac4c3864c56d50af" :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.dev")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
