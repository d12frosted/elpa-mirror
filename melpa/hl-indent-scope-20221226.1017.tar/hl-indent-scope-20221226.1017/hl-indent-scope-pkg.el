(define-package "hl-indent-scope" "20221226.1017" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "fbccec196d6f3ccffc965ca68ddec49bb08150f2" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
