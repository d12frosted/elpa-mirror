(define-package "sketch-themes" "20210222.1337" "Sketch color themes"
  '((emacs "26.1"))
  :commit "33b63867db76225e46eda0a8a613813151dc5b62" :authors
  '(("Daw-Ran Liou" . "hi@dawranliou.com"))
  :maintainer
  '("Daw-Ran Liou" . "hi@dawranliou.com")
  :keywords
  '("faces")
  :url "https://github.com/dawranliou/sketch-themes/")
;; Local Variables:
;; no-byte-compile: t
;; End:
