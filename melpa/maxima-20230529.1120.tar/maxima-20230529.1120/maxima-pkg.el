(define-package "maxima" "20230529.1120" "Major mode for Maxima"
  '((emacs "26.1")
    (s "1.11.0")
    (test-simple "1.3.0"))
  :commit "83574afcd308e28210668680a7feead2b07aaad0" :authors
  '(("William F. Schelter")
    ("Jay Belanger")
    ("Fermin Munoz"))
  :maintainers
  '(("Fermin Munoz" . "fmfs@posteo.net"))
  :maintainer
  '("Fermin Munoz" . "fmfs@posteo.net")
  :keywords
  '("maxima" "tools" "math")
  :url "https://gitlab.com/sasanidas/maxima")
;; Local Variables:
;; no-byte-compile: t
;; End:
