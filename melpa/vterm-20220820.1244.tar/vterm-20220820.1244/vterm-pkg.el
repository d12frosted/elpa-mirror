(define-package "vterm" "20220820.1244" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "886c8b826316100cc632fad3c4cc0bf86f56aeb0" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
