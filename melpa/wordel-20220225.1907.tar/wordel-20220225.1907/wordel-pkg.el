(define-package "wordel" "20220225.1907" "An Elisp implementation of \"Wordle\" (aka \"Lingo\")"
  '((emacs "27.1"))
  :commit "19be797818be2d9ac5a0a8acf30b43ad38e2f4ed" :authors
  '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com"))
  :maintainer
  '("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/progfolio/wordel")
;; Local Variables:
;; no-byte-compile: t
;; End:
