;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-transient" "20261001.1637"
  "Command dispatchers for Notmuch."
  '((emacs     "29.1")
    (compat    "31.1")
    (notmuch   "0.39")
    (transient "0.13"))
  :url "https://github.com/tarsius/notmuch-transient"
  :commit "1d22f34c11441f8ae760ddf5203ef38d3570b567"
  :revdesc "1d22f34c1144"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev")))
