(define-package "devil" "20230810.2152" "Minor mode for translating key sequences"
  '((emacs "24.4"))
  :commit "e0a12cd7737f17050f17174c8d9581fb0ad9e965" :authors
  '(("Susam Pal" . "susam@susam.net"))
  :maintainers
  '(("Susam Pal" . "susam@susam.net"))
  :maintainer
  '("Susam Pal" . "susam@susam.net")
  :keywords
  '("convenience" "abbrev")
  :url "https://github.com/susam/devil")
;; Local Variables:
;; no-byte-compile: t
;; End:
