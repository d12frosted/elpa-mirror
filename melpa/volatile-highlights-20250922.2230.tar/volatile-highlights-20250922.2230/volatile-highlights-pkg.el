;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "volatile-highlights" "20250922.2230"
  "Transient visual feedback for edits."
  '((emacs "24.4"))
  :url "https://github.com/k-talo/volatile-highlights.el"
  :commit "569a671fdd9458d9e18021a5c69c162fcbc7462e"
  :revdesc "569a671fdd94"
  :keywords '("editing" "emulations" "convenience" "wp")
  :authors '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com"))
  :maintainers '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com")))
