(define-package "kagi" "20240811.1525" "Kagi API integration"
  '((emacs "29.1")
    (markdown-mode "2.6")
    (shell-maker "0.46.1"))
  :commit "6109a0d3b115551ca5999eb938a42a37062a88b1" :authors
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainer
  '("Bram Schoenmakers" . "me@bramschoenmakers.nl")
  :keywords
  '("terminals" "wp")
  :url "https://codeberg.org/bram85/kagi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
