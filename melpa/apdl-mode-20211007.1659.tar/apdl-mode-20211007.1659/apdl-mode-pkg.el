(define-package "apdl-mode" "20211007.1659" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "97efe576f24dab0dfbda8f89db6e3cf38fec9738" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
