(define-package "apdl-mode" "20211007.1659" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "73c258795e99dfba68f55ba44335bcb23dc8ac00" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
