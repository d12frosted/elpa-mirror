(define-package "thrift" "20230726.1838" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "c51cb5780198089ea5997e825f7bf72d249ec8ef" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
