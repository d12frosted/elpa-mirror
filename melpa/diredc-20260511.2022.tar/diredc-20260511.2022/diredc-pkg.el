;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260511.2022"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "e2c66e17612ced58b9a26224838b204ba02ae299"
  :revdesc "e2c66e17612c"
  :keywords '("files"))
