(define-package "elsa" "20230314.13" "Emacs Lisp Static Analyser"
  '((emacs "25.1")
    (trinary "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3")
    (lsp-mode "0"))
  :commit "b0d15956214d21aa63dab00f44c16f155cb70915" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp")
  :url "https://github.com/emacs-elsa/Elsa")
;; Local Variables:
;; no-byte-compile: t
;; End:
