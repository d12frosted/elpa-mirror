;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260908.1415"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "5fcb166226f34890dda5aff100cc9086faf51692"
  :revdesc "5fcb166226f3"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
