(define-package "org-side-tree" "20231003.640" "Navigate Org outlines in side window tree"
  '((emacs "28.1"))
  :commit "dc4b6c0f5336aba163096be44eb66f821a5f5232" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/org-side-tree")
;; Local Variables:
;; no-byte-compile: t
;; End:
