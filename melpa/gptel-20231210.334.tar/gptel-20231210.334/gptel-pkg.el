(define-package "gptel" "20231210.334" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "5c3b26aeece94c65ac605613c502767cc97478a5" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
