(define-package "helm-ls-git" "20240820.1207" "list git files."
  '((helm "3.9.5")
    (emacs "25.3"))
  :commit "2685aad6fc6407edae1e1a3bc40c9674b0df9e5c" :keywords
  '("helm" "convenience" "vc" "files" "buffers" "completion" "diff" "log" "git")
  :url "https://github.com/emacs-helm/helm-ls-git")
;; Local Variables:
;; no-byte-compile: t
;; End:
