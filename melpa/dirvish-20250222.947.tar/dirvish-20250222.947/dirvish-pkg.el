;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250222.947"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "79d73c07772088e777f1d99deffee2992c3a261b"
  :revdesc "79d73c077720"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
