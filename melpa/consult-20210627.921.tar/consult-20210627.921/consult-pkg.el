(define-package "consult" "20210627.921" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "e8ce2b6aa0022ab9095f061b3085a498f64e0094" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
