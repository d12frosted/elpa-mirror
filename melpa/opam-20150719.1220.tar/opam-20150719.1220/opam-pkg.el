;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "opam" "20150719.1220"
  "OPAM tools."
  '((emacs "24.1"))
  :url "https://github.com/lunaryorn/opam.el"
  :commit "4d589de5765728f56af7078fae328b6792de8600"
  :revdesc "4d589de57657"
  :keywords '("convenience")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
