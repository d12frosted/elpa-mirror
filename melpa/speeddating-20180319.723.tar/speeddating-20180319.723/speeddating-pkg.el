;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speeddating" "20180319.723"
  "Increase date and time at point."
  '((emacs "25"))
  :url "https://github.com/xuchunyang/emacs-speeddating"
  :commit "eeaf90cd10e376bff5a295590a3d5f7fd1402523"
  :revdesc "eeaf90cd10e3"
  :keywords '("date" "time")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
