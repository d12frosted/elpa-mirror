;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260308.1247"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "fb3e6f786ec1933b667d363c8cac5fbc4e859d09"
  :revdesc "fb3e6f786ec1"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
