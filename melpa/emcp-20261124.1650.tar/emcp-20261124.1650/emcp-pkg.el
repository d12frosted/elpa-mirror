;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20261124.1650"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "0c2872e93aa84f6c9cf09c550733b27586b22838"
  :revdesc "0c2872e93aa8"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
