(define-package "for" "20230504.1607" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "08f65ee62cc4d5fcf5c6eeed5971c43709ff9e00" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainers
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
