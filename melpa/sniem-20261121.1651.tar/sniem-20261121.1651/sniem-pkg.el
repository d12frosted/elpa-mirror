;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sniem" "20261121.1651"
  "Hands-eased united editing method."
  '((emacs "27.1")
    (s     "2.12.0")
    (dash  "1.12.0"))
  :url "https://github.com/SpringHan/sniem.git"
  :commit "5c2364587f3eda8f996375bba5bf8ff4fd0977f6"
  :revdesc "5c2364587f3e"
  :keywords '("convenience" "united-editing-method"))
