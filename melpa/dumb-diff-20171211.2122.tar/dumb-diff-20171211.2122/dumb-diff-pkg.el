;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-diff" "20171211.2122"
  "Fast arbitrary diffs."
  '((emacs "24.3"))
  :url "https://github.com/jacktasia/dumb-diff"
  :commit "1a2331d283049b71a07c1b06b1e0627a950d55f4"
  :revdesc "1a2331d28304"
  :keywords '("programming" "diff"))
