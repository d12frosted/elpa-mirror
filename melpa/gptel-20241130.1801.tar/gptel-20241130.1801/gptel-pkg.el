;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241130.1801"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "5c7369fd531398250f83ca57c2877ba968e41198"
  :revdesc "5c7369fd5313"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
