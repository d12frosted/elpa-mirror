;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260907.528"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "d3cd37ba22bfd696da9f83926ba9536833f4d433"
  :revdesc "d3cd37ba22bf"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
