;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250505.1856"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "8f1a4fb9709b9e8bc6e4557171a51b749a9eb2fa"
  :revdesc "8f1a4fb9709b"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
