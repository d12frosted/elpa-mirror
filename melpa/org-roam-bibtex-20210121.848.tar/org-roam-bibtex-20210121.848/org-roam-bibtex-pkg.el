(define-package "org-roam-bibtex" "20210121.848" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "1.2.2")
    (bibtex-completion "2.0.0"))
  :commit "5236917e1d8a4f88daadacc690248854f53facb4" :authors
  '(("Leo Vivier" . "leo.vivier+dev@gmail.com")
    ("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  '("Leo Vivier" . "leo.vivier+dev@gmail.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
