;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250214.1810"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "d4c8296ddd3cbc32c1f60da95db4369397065669"
  :revdesc "d4c8296ddd3c"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
