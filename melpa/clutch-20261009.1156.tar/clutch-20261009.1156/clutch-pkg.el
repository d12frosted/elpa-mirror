;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261009.1156"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "4e21242833efb5e4360595be3e2b32fbec0c4192"
  :revdesc "4e21242833ef"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
