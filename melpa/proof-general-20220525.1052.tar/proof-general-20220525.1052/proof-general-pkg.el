(define-package "proof-general" "20220525.1052" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "ac9ba11fda58800a1cec699fbda8811644847bbe" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
