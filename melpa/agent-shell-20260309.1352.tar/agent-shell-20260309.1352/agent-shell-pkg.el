;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260309.1352"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.88.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c72ff6e10855b63a418a73dff315a1c107aec86c"
  :revdesc "c72ff6e10855")
