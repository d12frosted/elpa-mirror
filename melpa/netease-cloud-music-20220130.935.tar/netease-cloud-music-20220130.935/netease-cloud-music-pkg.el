(define-package "netease-cloud-music" "20220130.935" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "221d8705eab4b66b1a4fa42655ac38271dc7a6e4" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
