(define-package "grugru" "20210112.935" "Rotate text at point"
  '((emacs "24.4"))
  :commit "1911cecb0a48e653ed3c99d58a25266f01189722" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
