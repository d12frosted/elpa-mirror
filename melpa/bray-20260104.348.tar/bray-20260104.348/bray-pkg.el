;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bray" "20260104.348"
  "Lightweight modal editing."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-bray"
  :commit "cdd0b8a75cae45763979762ff8970762dd0277bc"
  :revdesc "cdd0b8a75cae"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
