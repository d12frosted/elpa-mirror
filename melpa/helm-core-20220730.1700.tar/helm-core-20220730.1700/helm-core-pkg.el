(define-package "helm-core" "20220730.1700" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "2f634db1f318b25ccafde49b2848be056ad09eef" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
