;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-embark" "20240929.803"
  "Embark Actions for consult-gh."
  '((emacs          "29.1")
    (consult-gh     "2.0")
    (embark-consult "1.1"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "4e4a1ef9a4823b37cf7057208f712aa69e1e0e2c"
  :revdesc "4e4a1ef9a482"
  :keywords '("matching" "git" "repositories" "forges" "completion"))
