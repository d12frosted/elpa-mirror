;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "harvest" "20170822.1746"
  "Harvest integration."
  '((swiper "0.7.0")
    (hydra  "0.13.0")
    (s      "1.11.0"))
  :url "https://github.com/kostajh/harvest.el"
  :commit "7acbc0564b250521b67131ee2a0a92720239454f"
  :revdesc "7acbc0564b25"
  :keywords '("harvest")
  :authors '(("Kosta Harlan" . "kosta@kostaharlan.net"))
  :maintainers '(("Kosta Harlan" . "kosta@kostaharlan.net")))
