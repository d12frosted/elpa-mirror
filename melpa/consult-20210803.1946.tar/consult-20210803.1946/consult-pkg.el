(define-package "consult" "20210803.1946" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "964528d7fa4e6c9de8fe37da15672167761bf620" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
