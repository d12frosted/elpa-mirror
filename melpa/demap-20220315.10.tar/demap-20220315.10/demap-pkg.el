(define-package "demap" "20220315.10" "Detachable minimap package"
  '((emacs "24.4")
    (dash "2.18.0"))
  :commit "5e1034abda4ffaf4bfe96bcc96144fa7396477eb" :authors
  '(("Sawyer Gardner <https://gitlab.com/sawyerjgardner>"))
  :maintainer
  '("Sawyer Gardner <https://gitlab.com/sawyerjgardner>")
  :keywords
  '("lisp" "tools" "convenience")
  :url "https://gitlab.com/sawyerjgardner/demap.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
