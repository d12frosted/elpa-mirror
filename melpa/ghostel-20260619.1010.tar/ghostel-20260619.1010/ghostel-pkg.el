;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260619.1010"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "adb010b7fec943405006fcd1fac280e74ffa9e30"
  :revdesc "adb010b7fec9"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
