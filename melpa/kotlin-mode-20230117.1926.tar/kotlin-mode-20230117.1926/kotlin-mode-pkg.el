(define-package "kotlin-mode" "20230117.1926" "Major mode for kotlin"
  '((emacs "24.3"))
  :commit "3a84689d0bce5eecd15008bc2f71c0e058ad7671" :authors
  '(("Shodai Yokoyama" . "quantumcars@gmail.com"))
  :maintainer
  '("Shodai Yokoyama" . "quantumcars@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/Emacs-Kotlin-Mode-Maintainers/kotlin-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
