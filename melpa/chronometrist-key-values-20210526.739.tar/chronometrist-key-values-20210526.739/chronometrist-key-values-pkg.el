(define-package "chronometrist-key-values" "20210526.739" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "b9c800232bbe35c94b96419ceecf089679b99720" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "gemini://tilde.team/~contrapunctus/software.gmi")
;; Local Variables:
;; no-byte-compile: t
;; End:
