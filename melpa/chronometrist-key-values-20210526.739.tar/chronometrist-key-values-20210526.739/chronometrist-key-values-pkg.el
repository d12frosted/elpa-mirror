(define-package "chronometrist-key-values" "20210526.739" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "7206299e51f60fef96091ac6263dcab1c21fbabf" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "gemini://tilde.team/~contrapunctus/software.gmi")
;; Local Variables:
;; no-byte-compile: t
;; End:
