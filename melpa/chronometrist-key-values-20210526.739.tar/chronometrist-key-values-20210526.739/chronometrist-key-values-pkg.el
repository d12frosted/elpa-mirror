(define-package "chronometrist-key-values" "20210526.739" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "f4a8006ac836854b680540fcb36e918641532907" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "gemini://tilde.team/~contrapunctus/software.gmi")
;; Local Variables:
;; no-byte-compile: t
;; End:
