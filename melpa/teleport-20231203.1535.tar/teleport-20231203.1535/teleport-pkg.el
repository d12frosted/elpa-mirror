(define-package "teleport" "20231203.1535" "Integration for tsh (goteleport.com)"
  '((emacs "27.1")
    (dash "2.18.0"))
  :commit "5767bc31fee6d2a24503cc7cd24df1cfbd169bc2" :authors
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainers
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainer
  '("Caramel Hooves" . "caramel.hooves@protonmail.com")
  :keywords
  '("tools")
  :url "https://github.com/caramelhooves/teleport.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
