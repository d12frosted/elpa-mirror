;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blockdiag-mode" "20160427.524"
  "Major mode for editing blockdiag files."
  '((emacs "24.3"))
  :url "https://github.com/xcezx/xdiag-mode"
  :commit "f3b21ba433d60327cebd103ae4492200750e24a9"
  :revdesc "f3b21ba433d6"
  :authors '(("xcezx" . "main.xcezx@gmail.com"))
  :maintainers '(("xcezx" . "main.xcezx@gmail.com")))
