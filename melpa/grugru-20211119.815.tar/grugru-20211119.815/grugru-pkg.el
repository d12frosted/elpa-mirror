(define-package "grugru" "20211119.815" "Rotate text at point"
  '((emacs "24.4"))
  :commit "1b3b807e84cb250f0cc70876a438fed3b27eb756" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
