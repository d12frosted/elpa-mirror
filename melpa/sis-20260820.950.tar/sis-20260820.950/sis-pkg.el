;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "20260820.950"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "13bc51610390271e8e9f2e177de12117f7ce9bcb"
  :revdesc "13bc51610390"
  :keywords '("convenience"))
