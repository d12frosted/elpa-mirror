(define-package "company-box" "20220909.2043" "Company front-end with icons"
  '((emacs "26.0.91")
    (dash "2.19.0")
    (company "0.9.6")
    (frame-local "0.0.1"))
  :commit "7164422b39f4698d86eb1aca30f0c6d11e83008f" :authors
  '(("Sebastien Chapuis" . "sebastien@chapu.is"))
  :maintainer
  '("Sebastien Chapuis" . "sebastien@chapu.is")
  :keywords
  '("company" "completion" "front-end" "convenience")
  :url "https://github.com/sebastiencs/company-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
