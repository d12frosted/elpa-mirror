(define-package "embark" "20211210.1440" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "fed14590737b6e2d82a89321d2bf5642c2479a22" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
