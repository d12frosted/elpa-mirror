;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20250111.2232"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "cfc2e906124c31515f14ba122665063484b5e777"
  :revdesc "cfc2e906124c"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
