(define-package "logview" "20230816.1915" "Major mode for viewing log files"
  '((emacs "25.1")
    (datetime "0.8")
    (extmap "1.0"))
  :commit "01502a59e1f6409edd5c232d4dd07e7bdd2d889f" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("files" "tools")
  :url "https://github.com/doublep/logview")
;; Local Variables:
;; no-byte-compile: t
;; End:
