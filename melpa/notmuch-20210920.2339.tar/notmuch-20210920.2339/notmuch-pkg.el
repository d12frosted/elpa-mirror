(define-package "notmuch" "20210920.2339" "run notmuch within emacs" 'nil :commit "3e2e724d53a1dce3ba00a20c71b2e6f735678136" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
