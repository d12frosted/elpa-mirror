(define-package "notmuch" "20210920.2339" "run notmuch within emacs" 'nil :commit "bc91954ee04051a695b756fd867ec4528b30b3d4" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
