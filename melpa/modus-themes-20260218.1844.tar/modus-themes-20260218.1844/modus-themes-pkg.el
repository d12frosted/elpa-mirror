;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260218.1844"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "1343ea994781bd1d51bc5109186d497be63efdba"
  :revdesc "1343ea994781"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
