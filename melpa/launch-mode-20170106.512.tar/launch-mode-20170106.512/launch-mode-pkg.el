;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "launch-mode" "20170106.512"
  "Major mode for launch-formatted text."
  '((emacs "24.4"))
  :url "https://github.com/iory/launch-mode"
  :commit "25ebd4ba77afcbe729901eb74923dbe9ae81c313"
  :revdesc "25ebd4ba77af"
  :authors '(("iory" . "ab.ioryz@gmail.com"))
  :maintainers '(("iory" . "ab.ioryz@gmail.com")))
