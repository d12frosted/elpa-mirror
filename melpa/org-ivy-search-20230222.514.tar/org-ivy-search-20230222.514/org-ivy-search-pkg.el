(define-package "org-ivy-search" "20230222.514" "Full text search for org files powered by ivy"
  '((emacs "25.1")
    (ivy "0.10.0")
    (org "0.10.0")
    (beacon "1.3.4"))
  :commit "7f2afd8c196e3723ae6ac4dd229367ece9acd3bf" :authors
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainer
  '("Huming Chen" . "chenhuming@gmail.com")
  :keywords
  '("convenience" "tool" "org")
  :url "https://github.com/beacoder/org-ivy-search")
;; Local Variables:
;; no-byte-compile: t
;; End:
