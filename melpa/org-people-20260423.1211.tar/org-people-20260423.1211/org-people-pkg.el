;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260423.1211"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "cc97f09b395f0a805020464f7bc361cb810af7a8"
  :revdesc "cc97f09b395f"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
