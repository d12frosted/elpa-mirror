(define-package "esxml" "20220505.1058" "Library for working with xml via esxml and sxml"
  '((emacs "24.1")
    (kv "0.0.5")
    (cl-lib "0.5"))
  :commit "aafc2eced58906678d1e789855893e0f8cd6fc1c" :authors
  '(("Evan Izaksonas-Smith <izak0002 at umn dot edu>"))
  :maintainer
  '("Evan Izaksonas-Smith")
  :keywords
  '("tools" "lisp" "comm")
  :url "https://github.com/tali713/esxml")
;; Local Variables:
;; no-byte-compile: t
;; End:
