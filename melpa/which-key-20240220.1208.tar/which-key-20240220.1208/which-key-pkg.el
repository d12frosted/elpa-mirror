(define-package "which-key" "20240220.1208" "Display available keybindings in popup"
  '((emacs "24.4"))
  :commit "5bffdf94d8a760a15e7c9bb8e12136fce127bdac" :authors
  '(("Justin Burkett" . "justin@burkett.cc"))
  :maintainers
  '(("Justin Burkett" . "justin@burkett.cc"))
  :maintainer
  '("Justin Burkett" . "justin@burkett.cc")
  :url "https://github.com/justbur/emacs-which-key")
;; Local Variables:
;; no-byte-compile: t
;; End:
