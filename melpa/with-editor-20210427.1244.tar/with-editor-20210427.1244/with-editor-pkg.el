(define-package "with-editor" "20210427.1244" "Use the Emacsclient as $EDITOR"
  '((emacs "24.4"))
  :commit "7b80d8e5c644ab95717c32d296e1c9e32ab1951e" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/with-editor")
;; Local Variables:
;; no-byte-compile: t
;; End:
