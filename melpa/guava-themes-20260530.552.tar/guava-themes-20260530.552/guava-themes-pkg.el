;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260530.552"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "7535a39184502e387dbccf3ef131a91cf3707b6a"
  :revdesc "7535a3918450"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
