(define-package "fedi" "20230817.2004" "Helper functions for fediverse clients"
  '((emacs "28.1"))
  :commit "924180a4ef4c15621e3f3fc855cd10de7b615c35" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
