(define-package "sly" "20211121.1002" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "0470c0281498b9de072fcbf3718fc66720eeb3d0" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
