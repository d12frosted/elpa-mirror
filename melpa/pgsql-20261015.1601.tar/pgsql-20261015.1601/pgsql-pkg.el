;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "20261015.1601"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "a3d719766dd71155f11cc2405e0b179f994bc384"
  :revdesc "a3d719766dd7"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
