(define-package "kagi" "20240410.527" "Kagi API integration"
  '((emacs "29.1")
    (shell-maker "0.46.1"))
  :commit "3d05ca00da8385e40689b30f35b5c7d9dd31d3a4" :authors
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainer
  '("Bram Schoenmakers" . "me@bramschoenmakers.nl")
  :keywords
  '("terminals" "wp")
  :url "https://codeberg.org/bram85/kagi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
