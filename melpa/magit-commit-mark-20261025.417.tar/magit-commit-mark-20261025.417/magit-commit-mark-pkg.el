;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-commit-mark" "20261025.417"
  "Support marking commits as read."
  '((emacs "29.1")
    (magit "3.3.0"))
  :url "https://codeberg.org/ideasman42/emacs-magit-commit-mark"
  :commit "c45a5772fdec028dba914ed92e7b4c4ba7ecc6c5"
  :revdesc "c45a5772fdec"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
