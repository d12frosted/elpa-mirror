(define-package "flexoki-themes" "20231122.256" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "99a22e20796d31beb0de9394e9ce00b5fc1b1e13" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
