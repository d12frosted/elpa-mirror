;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsbot-data-browser" "20220830.230"
  "Browse the fsbot database using tabulated-list-mode."
  ()
  :url "https://github.com/benaiah/fsbot-data-browser"
  :commit "27455860fec01ca47bf98b85f093cc24b9852bef"
  :revdesc "27455860fec0"
  :keywords '("fsbot" "irc" "tabulated-list-mode"))
