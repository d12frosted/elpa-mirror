(define-package "brutal-theme" "20211130.1048" "Brutal theme"
  '((emacs "24.1"))
  :commit "01140537dcddec7869529fb65784b6b83052a253" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
