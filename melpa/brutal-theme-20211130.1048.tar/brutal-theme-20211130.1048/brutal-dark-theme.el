;;; brutal-dark-theme.el --- Brutal dark theme -*- lexical-binding: t; -*-

;; Copyright (C) 2021, Topi Kettunen <mail@topikettunen.com>

;; Author: Topi Kettunen <mail@topikettunen.com>
;; URL: https://github.com/topikettunen/brutal-emacs
;; Version: 0.1
;; Package-Requires: ((emacs "24.1"))

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <http://www.gnu.org/licenses/>.

;; This file is not part of Emacs.

;;; Commentary:

;; Dark variant of Brutal theme.

;;; Code:

(require 'brutal)
(eval-when-compile
  (require 'brutal-palettes))

(deftheme brutal-dark
  "The dark variant of the brutal theme.")

(brutal-with-color-variables 'dark 'brutal-dark
                             brutal-dark-color-palette-alist)

(provide-theme 'brutal-dark)
(provide 'brutal-dark)

;;; brutal-dark-theme.el ends here
