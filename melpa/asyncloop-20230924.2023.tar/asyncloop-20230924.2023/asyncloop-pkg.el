(define-package "asyncloop" "20230924.2023" "Non-blocking series of functions"
  '((emacs "28.1"))
  :commit "b9a394498fdad424a23ac1195b25b8e941018018" :authors
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainers
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainer
  '(nil . "<meedstrom91@gmail.com>")
  :keywords
  '("tools")
  :url "https://github.com/meedstrom/asyncloop")
;; Local Variables:
;; no-byte-compile: t
;; End:
