;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260312.1341"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "71daceef4e9e891c9580b1644c1971c6d977d96b"
  :revdesc "71daceef4e9e")
