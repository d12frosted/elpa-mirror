(define-package "company" "20240302.1508" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "5404b3ab7d3c287343f0d91f3db60af688ae7704" :authors
  '(("Nikolaj Schumacher"))
  :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
