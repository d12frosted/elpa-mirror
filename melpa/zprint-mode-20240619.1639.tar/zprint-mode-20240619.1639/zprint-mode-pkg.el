;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zprint-mode" "20240619.1639"
  "Reformat Clojure(Script) code using zprint."
  '((emacs "24.3"))
  :url "https://github.com/pesterhazy/zprint-mode.el"
  :commit "ac3b25e250c83aedc49d1eab508142e3060e3833"
  :revdesc "ac3b25e250c8"
  :keywords '("tools")
  :authors '(("Paulus Esterhazy" . "(pesterhazy@gmail.com)"))
  :maintainers '(("Paulus Esterhazy" . "(pesterhazy@gmail.com)")))
