;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "20260727.503"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "fac3672ff7e3c350c940d958f2623d111ddf42a1"
  :revdesc "fac3672ff7e3")
