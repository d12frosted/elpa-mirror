(define-package "meow" "20230505.2113" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "07ccf112fc1a56ddd96cfc39967957be7dc8dd5f" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
