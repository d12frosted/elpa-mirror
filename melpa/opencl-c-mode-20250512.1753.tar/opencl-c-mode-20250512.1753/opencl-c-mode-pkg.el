;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "opencl-c-mode" "20250512.1753"
  "Syntax coloring for opencl kernels."
  ()
  :url "https://github.com/salmanebah/opencl-mode"
  :commit "0d305f9618ff56eb7e5e35c5bae980bcf957e972"
  :revdesc "0d305f9618ff"
  :keywords '("c" "opencl")
  :authors '(("Salmane Bah" . "salmane.bah~at~u-bordeaux.fr")
             ("Gustaf Waldemarson" . "gustaf.waldemarson~at~gmail.com"))
  :maintainers '(("Salmane Bah" . "salmane.bah~at~u-bordeaux.fr")
                 ("Gustaf Waldemarson" . "gustaf.waldemarson~at~gmail.com")))
