;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260325.1558"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e79101f55862708de2d56f218bb05afb10ba6220"
  :revdesc "e79101f55862"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
