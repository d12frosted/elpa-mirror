;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "20241213.2028"
  "IDE interface."
  '((emacs "26.1"))
  :url "https://forge.tedomum.net/hjuvi/eide.git"
  :commit "ec04e7f707f9e526af9efd13c3ab4af3d8c485ba"
  :revdesc "ec04e7f707f9"
  :authors '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainers '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org")))
