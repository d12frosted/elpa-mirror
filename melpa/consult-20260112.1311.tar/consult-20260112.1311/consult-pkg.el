;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260112.1311"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "74e6cc77609cb36cd61aa2a23848659fbb66f05a"
  :revdesc "74e6cc77609c"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
