(define-package "hyperdrive" "20230325.3" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.3.2")
    (plz "0.4")
    (persist "0.5"))
  :commit "ea38cdb017647e5c9acf96f06b9979829dc4f292" :authors
  '(("Joseph Turner"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
