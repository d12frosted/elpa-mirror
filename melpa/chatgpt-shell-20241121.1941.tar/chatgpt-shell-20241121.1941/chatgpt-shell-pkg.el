;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241121.1941"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.70.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "da8d9e7eb686e86430196c87f1899c042d61a153"
  :revdesc "da8d9e7eb686")
