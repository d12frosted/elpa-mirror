;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "20260826.1737"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "71fa77b07b037a21bb154023d7d72fc88dd4b8e8"
  :revdesc "71fa77b07b03"
  :keywords '("convenience"))
