;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20250916.657"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "190e12205915de8334ed85c9ea1a8c0f6a3b19c1"
  :revdesc "190e12205915"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
