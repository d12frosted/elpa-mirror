(define-package "elpher" "20220502.1540" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "aa75538a7139278c120ccc4361fff634d1b2a715" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
