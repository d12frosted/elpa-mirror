(define-package "spdx" "20220327.113" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "279caa7aa99e7b5d6f2f9307b20e9fcb730ffb29" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
