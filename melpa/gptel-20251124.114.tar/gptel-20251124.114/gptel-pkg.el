;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251124.114"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "2270c99a9b361c90c8b2d6a49160aaa228eb2b7e"
  :revdesc "2270c99a9b36"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
