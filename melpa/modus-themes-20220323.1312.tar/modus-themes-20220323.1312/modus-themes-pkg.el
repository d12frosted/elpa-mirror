(define-package "modus-themes" "20220323.1312" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "30f282069e385b604f337942efcd65f344c04096" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
