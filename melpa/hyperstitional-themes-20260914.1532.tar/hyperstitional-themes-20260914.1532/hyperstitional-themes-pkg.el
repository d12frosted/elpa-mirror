;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperstitional-themes" "20260914.1532"
  "Weird themes with incremental palettes."
  '((emacs "24.1"))
  :url "https://github.com/precompute/hyperstitional-themes"
  :commit "c9271e63f2869ea6787d4ef9ba834958fd565474"
  :revdesc "c9271e63f286"
  :authors '(("precompute" . "git@precompute.net"))
  :maintainers '(("precompute" . "git@precompute.net")))
