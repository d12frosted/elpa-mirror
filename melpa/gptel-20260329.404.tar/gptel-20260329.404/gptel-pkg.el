;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260329.404"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "bd49e433648034a24512b012b7fb1170aecfaf49"
  :revdesc "bd49e4336480"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
