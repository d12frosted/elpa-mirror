(define-package "embark" "20230226.2122" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "6806fbb9313d9f43f29acc47a56ce48ec94254dc" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
