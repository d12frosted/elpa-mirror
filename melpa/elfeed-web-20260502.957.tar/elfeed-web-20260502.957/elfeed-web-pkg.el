;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-web" "20260502.957"
  "Web interface to Elfeed."
  '((emacs        "28.1")
    (compat       "31")
    (elfeed       "3.4.2")
    (simple-httpd "1.5.1"))
  :url "https://github.com/emacs-elfeed/elfeed-web"
  :commit "718531d00a9cd4c667645c7d458ec71f5f1f6a6c"
  :revdesc "718531d00a9c"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
