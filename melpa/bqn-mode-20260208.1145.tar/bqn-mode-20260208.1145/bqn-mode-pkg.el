;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bqn-mode" "20260208.1145"
  "Emacs mode for BQN."
  '((emacs  "26.1")
    (compat "30.0.0.0")
    (eros   "0.1.0"))
  :url "https://github.com/museoa/bqn-mode"
  :commit "7968023225c23ec63644a18ea613cb8cd2cd536e"
  :revdesc "7968023225c2"
  :authors '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainers '(("Marshall Lochbaum" . "mwlochbaum@gmail.com")))
