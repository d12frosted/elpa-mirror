(define-package "live-py-mode" "20231216.1538" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "ae29b9dfca83a83037d780424a85d617cddd2e47" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainers
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
