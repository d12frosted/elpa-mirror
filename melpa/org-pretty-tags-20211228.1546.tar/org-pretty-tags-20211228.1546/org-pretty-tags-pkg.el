;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-pretty-tags" "20211228.1546"
  "Surrogates for tags."
  '((emacs "25"))
  :url "https://gitlab.com/marcowahl/org-pretty-tags"
  :commit "e127a1e08df8273b909a99594ffaad84960ff212"
  :revdesc "e127a1e08df8"
  :keywords '("reading" "outlines")
  :authors '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainers '(("Marco Wahl" . "marcowahlsoft@gmail.com")))
