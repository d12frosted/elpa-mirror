;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260105.2359"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "0d8d8e9f16bb434ac6186a97327e9af3d67c2823"
  :revdesc "0d8d8e9f16bb"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
