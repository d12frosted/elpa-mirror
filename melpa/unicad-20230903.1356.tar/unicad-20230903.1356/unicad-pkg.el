;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicad" "20230903.1356"
  "An elisp port of Mozilla Universal Charset Auto Detector."
  '((emacs   "24")
    (nadvice "0.3"))
  :url "https://github.com/ukari/unicad"
  :commit "fcc220703798d140c86711e2feeb299fd765b5b5"
  :revdesc "fcc220703798"
  :keywords '("i18n")
  :authors '(("Qichen Huang" . "unicad.el@gmail.com"))
  :maintainers '(("Qichen Huang" . "unicad.el@gmail.com")))
