;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260616.1507"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "0b826202e12d6c66ae902d71ab770693cf89c33e"
  :revdesc "0b826202e12d"
  :keywords '("files"))
