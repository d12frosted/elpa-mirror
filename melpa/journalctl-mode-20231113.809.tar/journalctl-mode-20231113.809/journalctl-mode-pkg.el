(define-package "journalctl-mode" "20231113.809" "Sample major mode for  viewing output journalctl"
  '((emacs "27.1"))
  :commit "d9ecbd2f1ca15c90a05f11441886ab2e66b9a51f" :authors
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainers
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainer
  '("Sebastian Meisel" . "sebastian.meisel@gmail.com")
  :keywords
  '("unix")
  :url "https://github.com/SebastianMeisel/journalctl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
