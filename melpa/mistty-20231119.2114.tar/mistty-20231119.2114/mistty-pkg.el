(define-package "mistty" "20231119.2114" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "98061e6016059ee8ce6fa785fb4f5ea476d0a00c" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
