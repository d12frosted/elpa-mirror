;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250708.1559"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "2ac3e9a2954009e6ccfeda3d7cad6e4debd40299"
  :revdesc "2ac3e9a29540"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
