;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261108.901"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "20de568be368eef29e97635a31f383eeadcc4c31"
  :revdesc "20de568be368"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
