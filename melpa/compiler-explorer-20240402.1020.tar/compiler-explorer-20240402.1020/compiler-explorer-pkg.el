(define-package "compiler-explorer" "20240402.1020" "Compiler explorer client (godbolt.org)"
  '((emacs "26.1")
    (request "0.3.0"))
  :commit "4f325536d1a451b1143686b5e4796f1bffb03066" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("c" "tools")
  :url "https://github.com/mkcms/compiler-explorer.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
