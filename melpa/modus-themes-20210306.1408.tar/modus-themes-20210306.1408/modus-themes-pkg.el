(define-package "modus-themes" "20210306.1408" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "04bb1d7380bc6822a960bb6821677bc33e12e0b6" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
