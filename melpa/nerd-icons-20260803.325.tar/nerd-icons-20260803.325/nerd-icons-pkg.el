;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20260803.325"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "f12d1e4619aa5ed7d1c1ddf837d4335015bdfd4d"
  :revdesc "f12d1e4619aa"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
