(define-package "magit-libgit" "20220331.2308" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "3cfc8458e14c705afdfbeb7dcd3d3f43d7479344" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
