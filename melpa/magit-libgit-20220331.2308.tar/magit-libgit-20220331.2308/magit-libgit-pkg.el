(define-package "magit-libgit" "20220331.2308" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "0bbf31a2efd769ac2a4734358b4da08a596e9514" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
