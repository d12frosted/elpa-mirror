(define-package "opensub" "20230417.1635" "Search and download from open-subtitles"
  '((emacs "25.1"))
  :commit "0faef3dad6fc9c0eda1db1b237e6f66a8f411b01" :authors
  '(("Daniel Fleischer" . "danflscr@gmail.com"))
  :maintainers
  '(("Daniel Fleischer" . "danflscr@gmail.com"))
  :maintainer
  '("Daniel Fleischer" . "danflscr@gmail.com")
  :keywords
  '("multimedia")
  :url "https://github.com/danielfleischer/opensub")
;; Local Variables:
;; no-byte-compile: t
;; End:
