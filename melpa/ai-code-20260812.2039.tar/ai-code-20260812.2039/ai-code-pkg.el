;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260812.2039"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "c9e88eb9fe113049981b4f88676e26e9127ecf6b"
  :revdesc "c9e88eb9fe11"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
