;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debian-el" "20260703.520"
  "Startup file for the debian-el package."
  ()
  :commit "ce58c690e27522669eb1905e21a194ff9eb79a9b"
  :revdesc "ce58c690e275"
  :keywords '("debian" "apt" "elisp")
  :authors '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org"))
  :maintainers '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org")))
