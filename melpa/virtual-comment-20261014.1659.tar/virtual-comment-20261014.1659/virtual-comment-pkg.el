;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtual-comment" "20261014.1659"
  "Virtual Comments."
  '((emacs "26.1"))
  :url "https://github.com/thanhvg/emacs-virtual-comment"
  :commit "5d595844cf0d6c5a48c5039e9f02c6aca2c5acc2"
  :revdesc "5d595844cf0d"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
