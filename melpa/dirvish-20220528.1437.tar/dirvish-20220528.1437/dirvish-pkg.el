(define-package "dirvish" "20220528.1437" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "cfd3220bc4727638084260c77ccc08bfd6e5f802" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
