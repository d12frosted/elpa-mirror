(define-package "dwim-shell-command" "20220815.725" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "7afb2f7ba7adc0c58766268e3b2e6b6e25b0a77c" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
