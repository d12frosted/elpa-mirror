;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "20261030.1821"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "970d1a3a70f3955da3de8b437ff14f22e900320f"
  :revdesc "970d1a3a70f3"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
