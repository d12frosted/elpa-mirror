;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docstr" "20260101.548"
  "A document string minor mode."
  '((emacs "27.1")
    (s     "1.9.0"))
  :url "https://github.com/emacs-vs/docstr"
  :commit "c83e3d24b610168477466aab7ca691cbe7c36484"
  :revdesc "c83e3d24b610"
  :keywords '("convenience" "document" "string")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
