;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260504.837"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "476bf92185c8a44a7729fac6b85252fff9e4f9ba"
  :revdesc "476bf92185c8"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
