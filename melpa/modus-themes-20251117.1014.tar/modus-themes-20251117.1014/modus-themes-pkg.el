;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251117.1014"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "f79684961e9fbd06f3b013c8e44458dff391dfea"
  :revdesc "f79684961e9f"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
