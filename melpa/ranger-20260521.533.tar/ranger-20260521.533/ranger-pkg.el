;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ranger" "20260521.533"
  "Make dired more like ranger."
  '((emacs "27.1"))
  :url "https://github.com/ralesi/ranger"
  :commit "9ddc8b5b29f413e20c7e94c985a52089e83169e9"
  :revdesc "9ddc8b5b29f4"
  :keywords '("files" "convenience" "dired")
  :authors '(("Rich Alesi" . "https://github.com/ralesi"))
  :maintainers '(("Rich Alesi" . "https://github.com/ralesi")))
