(define-package "consult" "20210222.1204" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "6c509a1f9b8a173c73064760152eef397d920762" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
