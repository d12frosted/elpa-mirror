;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stan-ts-mode" "20260320.1433"
  "Major mode for editing Stan files."
  '((emacs "30.1"))
  :url "https://github.com/WardBrian/stan-ts-mode"
  :commit "fd3cf464e56febf3a73a174792161f3656d8d0a2"
  :revdesc "fd3cf464e56f"
  :keywords '("stan" "languages" "tree-sitter")
  :authors '(("Brian Ward" . "bward@flatironinstitute.org"))
  :maintainers '(("Brian Ward" . "bward@flatironinstitute.org")))
