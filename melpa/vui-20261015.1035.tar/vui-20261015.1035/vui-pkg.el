;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261015.1035"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "e33a0115903823c51faceb36c8dcf3c002f6c99e"
  :revdesc "e33a01159038"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
