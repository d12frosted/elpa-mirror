;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess" "20241125.1731"
  "Emacs Speaks Statistics."
  '((emacs "25.1"))
  :url "https://github.com/emacs-ess/ESS"
  :commit "eac35866d8d6ae3bed5109fa8843523e30ff8c9e"
  :revdesc "eac35866d8d6"
  :authors '(("David Smith" . "dsmith@stats.adelaide.edu.au")
             ("A.J. Rossini" . "blindglobe@gmail.com")
             ("Richard M. Heiberger" . "rmh@temple.edu")
             ("Kurt Hornik" . "Kurt.Hornik@R-project.org")
             ("Martin Maechler" . "maechler@stat.math.ethz.ch")
             ("Rodney A. Sparapani" . "rsparapa@mcw.edu")
             ("Stephen Eglen" . "stephen@gnu.org")
             ("Sebastian P. Luque" . "spluque@gmail.com")
             ("Henning Redestig" . "henning.red@googlemail.com")
             ("Vitalie Spinu" . "spinuvit@gmail.com")
             ("Lionel Henry" . "lionel.hry@gmail.com")
             ("J. Alexander Branham" . "alex.branham@gmail.com"))
  :maintainers '(("ESS Core Team" . "ESS-core@r-project.org")))
