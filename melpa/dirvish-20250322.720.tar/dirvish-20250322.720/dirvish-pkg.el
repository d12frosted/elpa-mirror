;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250322.720"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "2f06964137872c32ac716b6fe2df700f971854f8"
  :revdesc "2f0696413787"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
