(define-package "magik-mode" "20210728.1354" "mode for editing Magik + some utils." 'nil :commit "d221002128b7954fb5705c37b974223514a9c4f0" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
