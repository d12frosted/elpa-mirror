(define-package "hyperdrive" "20240818.2122" "P2P filesystem"
  '((emacs "28.1")
    (map "3.0")
    (compat "30.0.0.0")
    (org "9.7.6")
    (plz "0.9.1")
    (persist "0.6.1")
    (taxy-magit-section "0.14")
    (transient "0.7.4"))
  :commit "bcfc7adaf7ed9a58ea33881413c602eaa193fedb" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
