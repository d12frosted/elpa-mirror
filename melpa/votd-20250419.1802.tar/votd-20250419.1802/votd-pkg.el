;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "votd" "20250419.1802"
  "Bible Verse Of The Day."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/votd"
  :commit "c1ef8d654bd06b286789e0b3959c635e8c8c3545"
  :revdesc "c1ef8d654bd0"
  :keywords '("convenience" "comm" "hypermedia"))
