(define-package "julia-snail" "20230829.546" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (popup "0.5.9"))
  :commit "49c13ad005b66724bde385e45ef8aa448e40f233" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
