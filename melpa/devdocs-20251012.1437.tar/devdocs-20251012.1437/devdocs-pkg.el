;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devdocs" "20251012.1437"
  "Emacs viewer for DevDocs."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/astoff/devdocs.el"
  :commit "a0a40cc7b0a4ed37bd146cd03737fb426863787c"
  :revdesc "a0a40cc7b0a4"
  :keywords '("help")
  :authors '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers '(("Augusto Stoffel" . "arstoffel@gmail.com")))
