;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arduino-cli-mode" "20250410.1508"
  "Arduino-CLI command wrapper."
  '((emacs "25.1"))
  :url "https://github.com/motform/arduino-cli-mode"
  :commit "7beef86e943f887e1eb417c366b4f0fd51056728"
  :revdesc "7beef86e943f"
  :keywords '("processes" "tools"))
