;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debian-el" "20241025.551"
  "Startup file for the debian-el package."
  ()
  :url "https://salsa.debian.org/emacsen-team/debian-el.git"
  :commit "778e3ae7de8d374ca1d9e874c897f612ded2d5be"
  :revdesc "778e3ae7de8d"
  :keywords '("debian" "apt" "elisp")
  :authors '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org"))
  :maintainers '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org")))
