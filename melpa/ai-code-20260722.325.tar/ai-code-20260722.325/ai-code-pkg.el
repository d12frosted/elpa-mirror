;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260722.325"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "868563037cd083f5c5b3377cbc9e38e4275a809a"
  :revdesc "868563037cd0"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
