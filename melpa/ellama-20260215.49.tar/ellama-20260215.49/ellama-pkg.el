;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260215.49"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "d3ede72b263379dcd80cdc99b1de6c4ebf1d2a69"
  :revdesc "d3ede72b2633"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
