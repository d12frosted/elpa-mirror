;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260109.917"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "66d02c1d197a9506f8df7a7e35f760bdbbcddb3b"
  :revdesc "66d02c1d197a"
  :keywords '("data" "extensions"))
