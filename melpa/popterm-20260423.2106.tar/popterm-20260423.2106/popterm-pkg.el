;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260423.2106"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "7efcca742ec9a23c2e6e627b2c1d42aa752dea5d"
  :revdesc "7efcca742ec9"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
