;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-ess-r" "20241120.757"
  "R with tree-sitter."
  '((emacs             "26.1")
    (ess               "18.10.1")
    (tree-sitter       "0.12.1")
    (tree-sitter-langs "0.12.0"))
  :url "https://github.com/ShuguangSun/tree-sitter-ess-r"
  :commit "895846900530017e91f95374a125c66b01d8925c"
  :revdesc "895846900530"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
