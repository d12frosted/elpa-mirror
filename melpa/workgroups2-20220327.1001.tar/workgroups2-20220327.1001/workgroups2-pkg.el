(define-package "workgroups2" "20220327.1001" "save&load multiple named workspaces (or \"workgroups\")"
  '((emacs "25.1"))
  :commit "59952e80acecfd6f8b79f075d473501ee468085e" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
