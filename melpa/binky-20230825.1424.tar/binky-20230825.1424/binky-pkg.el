(define-package "binky" "20230825.1424" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "630507927b4ddf255ee62ec05df406a06125649f" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
