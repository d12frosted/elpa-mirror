;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20241208.1840"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "a0d5610f0c37c611645719d2acea43cd2ddd2851"
  :revdesc "a0d5610f0c37"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
