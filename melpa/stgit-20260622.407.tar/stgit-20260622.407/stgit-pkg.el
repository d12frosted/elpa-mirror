;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stgit" "20260622.407"
  "Major mode for StGit interaction."
  ()
  :url "http://stacked-git.github.io"
  :commit "faa026a62a423762b9821d332aa0f13d59b339e0"
  :revdesc "faa026a62a42"
  :authors '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainers '(("David Kågedal" . "davidk@lysator.liu.se")))
