(define-package "keg" "20200726.228" "Modern Elisp package development system"
  '((emacs "24.1")
    (cl-lib "0.6"))
  :commit "fea2f831d84d7642c35820bb63250487e46683e5" :keywords
  ("convenience")
  :authors
  (("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  ("Naoya Yamashita" . "conao3@gmail.com")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
