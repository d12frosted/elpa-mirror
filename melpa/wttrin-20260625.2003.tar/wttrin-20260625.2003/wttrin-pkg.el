;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260625.2003"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "7027cccea9eb7170ea0f08e1def3f979f2e59932"
  :revdesc "7027cccea9eb"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
