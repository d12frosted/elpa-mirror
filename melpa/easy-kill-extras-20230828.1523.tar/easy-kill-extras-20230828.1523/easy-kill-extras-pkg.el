(define-package "easy-kill-extras" "20230828.1523" "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :commit "f4334dbeefc99a7656f6283543628a8378366485" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/easy-kill-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
