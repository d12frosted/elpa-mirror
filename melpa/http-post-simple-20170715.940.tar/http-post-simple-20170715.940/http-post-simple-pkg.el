;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-post-simple" "20170715.940"
  "HTTP POST requests using the url library."
  ()
  :url "https://github.com/emacsorphanage/http-post-simple"
  :commit "f53697fca278c741051aeb668b00466b5e0fd3fe"
  :revdesc "f53697fca278"
  :keywords '("comm" "data" "processes" "hypermedia"))
