(define-package "weblorg" "20210919.1547" "Static Site Generator for org-mode"
  '((templatel "0.1.6")
    (emacs "26.1"))
  :commit "0f8ec7e9065b2962c93209ee30b46f91843e2815" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
