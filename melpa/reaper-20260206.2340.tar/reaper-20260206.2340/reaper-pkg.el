;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reaper" "20260206.2340"
  "Interact with Harvest time tracking app."
  '((emacs "26.2"))
  :url "https://github.com/xendk/reaper"
  :commit "71c0fcb54a13a446851d4fb351fd9576fefe4172"
  :revdesc "71c0fcb54a13"
  :keywords '("tools")
  :authors '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers '(("Thomas Fini Hansen" . "xen@xen.dk")))
