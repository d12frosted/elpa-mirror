(define-package "mame" "20230526.1453" "A MAME front-end"
  '((emacs "27.1"))
  :commit "f91cab8d32ceffdff9817f7c2371d7c43cbdd1ec" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
