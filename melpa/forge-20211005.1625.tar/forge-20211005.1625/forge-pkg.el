(define-package "forge" "20211005.1625" "Access Git forges from Magit."
  '((emacs "25.1")
    (closql "20210927")
    (dash "2.18.1")
    (emacsql-sqlite "3.0.0")
    (ghub "3.5.2")
    (let-alist "1.0.6")
    (magit "3.0.0")
    (markdown-mode "2.4")
    (transient "0.3.3")
    (yaml "0.3.3"))
  :commit "c11c3c7efb8921f8e3d3b8b74f1faa7f2911fb42" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
