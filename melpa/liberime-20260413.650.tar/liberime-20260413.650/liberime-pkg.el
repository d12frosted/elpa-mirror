;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260413.650"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "6ad07ab91fd4a546c9ea1cf811e22c60312ef062"
  :revdesc "6ad07ab91fd4"
  :keywords '("convenience" "chinese" "input-method" "rime"))
