;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-phpstan" "20250521.1459"
  "Flymake backend for PHP using PHPStan."
  '((emacs   "26.1")
    (phpstan "0.8.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "af600b9aff5f89aab5a0f5744c5734392414e013"
  :revdesc "af600b9aff5f"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
