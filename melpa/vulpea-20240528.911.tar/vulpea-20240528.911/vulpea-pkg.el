(define-package "vulpea" "20240528.911" "A collection of org-roam note-taking functions"
  '((emacs "27.2")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12")
    (dash "2.19"))
  :commit "d461b338bc3d3b686a8513ca62751cd928e6aecd" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
