(define-package "yeetube" "20231005.205" "YouTube Front End"
  '((emacs "27.2"))
  :commit "293eb1599c3ac485d920b79a1c9bc56638488fff" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.com/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
