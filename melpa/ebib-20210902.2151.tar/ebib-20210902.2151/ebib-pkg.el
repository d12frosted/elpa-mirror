(define-package "ebib" "20210902.2151" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "3a56590c15d86c5d97b1e8505834bb3f481431f9" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
