;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "20260928.612"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "51596b82b59d56317d4c6af93efd4bafb850b529"
  :revdesc "51596b82b59d"
  :keywords '("convenience"))
