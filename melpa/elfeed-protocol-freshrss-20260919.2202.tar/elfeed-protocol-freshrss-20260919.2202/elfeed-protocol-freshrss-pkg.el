;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol-freshrss" "20260919.2202"
  "FreshRSS compatible gReader protocol implementation for elfeed."
  '((emacs            "29.1")
    (elfeed           "4.0.0")
    (elfeed-protocol  "1.0.0")
    (deferred         "0.5.1")
    (request          "0.3.2")
    (request-deferred "0.3.2"))
  :url "https://codeberg.org/lou/elfeed-protocol-freshrss"
  :commit "90384b4d46cba5fd5d73481d7bf88f74d6c9bff3"
  :revdesc "90384b4d46cb"
  :authors '(("Lou Woell" . "lou@repetitions.de"))
  :maintainers '(("Lou Woell" . "lou@repetitions.de")))
