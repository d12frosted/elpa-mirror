(define-package "easy-kill-extras" "20210522.1435" "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :commit "84782119a3b7ff6d6b7d9718d7bc27296847637b" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/easy-kill-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
