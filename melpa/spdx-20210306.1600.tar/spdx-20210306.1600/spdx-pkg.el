(define-package "spdx" "20210306.1600" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "55e569923a34361878a73fc1f89aa07d671f29bf" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
