(define-package "csharp-mode" "20210725.1141" "C# mode derived mode"
  '((emacs "26.1")
    (tree-sitter "0.15.1")
    (tree-sitter-indent "0.1")
    (tree-sitter-langs "0.10.0"))
  :commit "2595b901387e3f7eb5e8359ced65e6275f95e082" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
