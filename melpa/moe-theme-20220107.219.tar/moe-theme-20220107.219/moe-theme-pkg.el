(define-package "moe-theme" "20220107.219" "A colorful eye-candy theme. Moe, moe, kyun!" 'nil :commit "db057d5711f92e6b67814e4983f32982d69729b8" :authors
  '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainer
  '("kuanyui" . "azazabc123@gmail.com")
  :keywords
  '("themes")
  :url "https://github.com/kuanyui/moe-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
