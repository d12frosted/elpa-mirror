;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20251022.4"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "a328affd84bc82016cd5af64e1c8c7f0798fe237"
  :revdesc "a328affd84bc"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
