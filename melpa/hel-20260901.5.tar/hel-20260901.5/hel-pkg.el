;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "20260901.5"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "08b4a750ba3c255f8c2a1bcfaa423335bd70c537"
  :revdesc "08b4a750ba3c"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
