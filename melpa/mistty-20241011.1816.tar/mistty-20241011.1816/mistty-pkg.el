;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241011.1816"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "54aacb7956a5c397dc0836ad8dfe17b1943ee63c"
  :revdesc "54aacb7956a5"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
