(define-package "lsp-mode" "20201209.1808" "LSP mode"
  '((emacs "26.1")
    (dash "2.14.1")
    (dash-functional "2.14.1")
    (f "0.20.0")
    (ht "2.0")
    (spinner "1.7.3")
    (markdown-mode "2.3")
    (lv "0"))
  :commit "742d7d7ab1cdc5957102e0b1dff9872b6bc7370a" :keywords
  ("languages")
  :authors
  (("Vibhav Pant, Fangrui Song, Ivan Yonchovski"))
  :maintainer
  ("Vibhav Pant, Fangrui Song, Ivan Yonchovski")
  :url "https://github.com/emacs-lsp/lsp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
