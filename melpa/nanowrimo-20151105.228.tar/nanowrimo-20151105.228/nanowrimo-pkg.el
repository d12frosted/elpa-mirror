;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nanowrimo" "20151105.228"
  "Track progress for nanowrimo."
  ()
  :url "https://bitbucket.org/gvol/nanowrimo-mode"
  :commit "b1d41458926ccb39cefbb1bb74aefe4f02fd349f"
  :revdesc "b1d41458926c"
  :authors '(("Ivan Andrus" . "darthandrusatgmail.com"))
  :maintainers '(("Ivan Andrus" . "darthandrusatgmail.com")))
