;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260112.2056"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "3a8ac46916c0699f0905ac4fe65d72768add3efb"
  :revdesc "3a8ac46916c0"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
