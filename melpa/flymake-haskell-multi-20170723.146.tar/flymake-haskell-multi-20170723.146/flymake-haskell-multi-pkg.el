;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-haskell-multi" "20170723.146"
  "Syntax-check haskell-mode using both ghc and hlint."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-haskell-multi"
  :commit "b564a94312259885b1380272eb867bf52a164020"
  :revdesc "b564a9431225"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
