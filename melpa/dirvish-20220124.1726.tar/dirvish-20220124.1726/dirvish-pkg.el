(define-package "dirvish" "20220124.1726" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "bf0005d09a58089573bbdbfcdb8b8a5b5271fcf1" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
