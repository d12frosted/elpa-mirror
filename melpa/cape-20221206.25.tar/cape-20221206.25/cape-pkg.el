(define-package "cape" "20221206.25" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "185970a11c4871a1ceb38c8e10cb5fd6ccf1628b" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
