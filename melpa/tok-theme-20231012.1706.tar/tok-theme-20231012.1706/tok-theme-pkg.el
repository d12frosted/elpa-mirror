(define-package "tok-theme" "20231012.1706" "Minimal monochromatic theme for Emacs in the spirit of Zmacs and Smalltalk-80."
  '((emacs "27.0"))
  :commit "c1b2ca2965a177e454901c141b16fb49d59fc8cf" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
