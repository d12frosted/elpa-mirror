(define-package "jinx" "20231123.1811" "Enchanted Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "0e2dc2d283db6d5d092f112b6dee13fa207e95d4" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "wp")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
