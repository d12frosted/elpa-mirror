;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-books" "20260528.819"
  "Reading list management with Org mode and helm."
  '((enlive   "0.0.1")
    (s        "1.11.0")
    (helm     "2.9.2")
    (helm-org "1.0")
    (dash     "2.14.1")
    (org      "9.3")
    (emacs    "25"))
  :url "https://github.com/lepisma/org-books"
  :commit "74b82acd56c7ddaec5b03135a4cbbd5330a9b020"
  :revdesc "74b82acd56c7"
  :keywords '("outlines")
  :authors '(("Abhinav Tushar" . "abhinav@lepisma.xyz"))
  :maintainers '(("Abhinav Tushar" . "abhinav@lepisma.xyz")))
