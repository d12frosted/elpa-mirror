(define-package "haki-theme" "20231028.643" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "6badf26c40463155d15d196ebb1ee8d69e6b384b" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
