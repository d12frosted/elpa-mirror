(define-package "run-command-recipes" "20230102.2031" "This is collection of recipes to `run-command'"
  '((emacs "25.1")
    (dash "2.18.0")
    (f "0.20.0")
    (run-command "0.1.0"))
  :commit "6395c773ac798eaac0cb2941d5c4057a5070b1d7" :authors
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainer
  '("semenInRussia" . "hrams205@gmail.com")
  :keywords
  '("extensions" "run-command")
  :url "https://github.com/semenInRussia/emacs-run-command-recipes")
;; Local Variables:
;; no-byte-compile: t
;; End:
