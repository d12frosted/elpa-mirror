;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kotlin-ts-mode" "20260326.930"
  "A mode for editing Kotlin files based on tree-sitter."
  '((emacs "30.1"))
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode"
  :commit "136d8d1fd3158fc5558aff866041c1935b574588"
  :revdesc "136d8d1fd315"
  :authors '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers '(("Alex Figl-Brick" . "alex@alexbrick.me")))
