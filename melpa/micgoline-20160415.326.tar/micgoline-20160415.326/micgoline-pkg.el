;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "micgoline" "20160415.326"
  "Powerline mode, color schemes from microsoft and google's logo."
  '((emacs     "24.3")
    (powerline "2.3"))
  :url "https://github.com/yzprofile/micgoline"
  :commit "e3e2effe4846175a3b52b4092c0c134ced5978d8"
  :revdesc "e3e2effe4846"
  :keywords '("mode-line" "powerline" "theme")
  :authors '(("yzprofile" . "yzprofiles@gmail.com"))
  :maintainers '(("yzprofile" . "yzprofiles@gmail.com")))
