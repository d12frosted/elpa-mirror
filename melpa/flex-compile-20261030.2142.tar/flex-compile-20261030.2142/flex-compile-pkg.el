;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-compile" "20261030.2142"
  "Run, evaluate and compile across many languages."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.2.1"))
  :url "https://github.com/plandes/flex-compile"
  :commit "47f0bbcd24fe63a9c5c8c5c12e188ad3df8d1a41"
  :revdesc "47f0bbcd24fe"
  :keywords '("compilation" "integration" "processes"))
