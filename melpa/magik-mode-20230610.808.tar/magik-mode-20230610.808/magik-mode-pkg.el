(define-package "magik-mode" "20230610.808" "mode for editing Magik + some utils." 'nil :commit "d1a117bef989e039fbb72ac542133c73cdc70758" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
