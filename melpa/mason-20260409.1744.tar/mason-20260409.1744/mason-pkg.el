;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20260409.1744"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/mason-org/mason.el"
  :commit "3ac674a7880dd6432f83e249bfd6fea8cf6fc974"
  :revdesc "3ac674a7880d"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
