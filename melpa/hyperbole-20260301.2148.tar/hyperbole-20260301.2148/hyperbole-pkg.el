;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260301.2148"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "6aa7c5ad0f5700b795495a0cd40edc95132137ee"
  :revdesc "6aa7c5ad0f57"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
