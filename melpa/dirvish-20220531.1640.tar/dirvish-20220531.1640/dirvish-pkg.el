(define-package "dirvish" "20220531.1640" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "593f3a9a0515a80cc84d6745449f37c860e1c5b4" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
