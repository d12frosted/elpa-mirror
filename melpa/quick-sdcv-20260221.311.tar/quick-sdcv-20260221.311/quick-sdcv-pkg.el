;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20260221.311"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "d12901f87dd191fd6061abcb32cac31503da62be"
  :revdesc "d12901f87dd1"
  :keywords '("docs" "startdict" "sdcv"))
