(define-package "grugru" "20210124.552" "Rotate text at point"
  '((emacs "24.4"))
  :commit "981d19444af3e926cefe34419f16e770923e4958" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
