;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250522.2002"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "140351a9c43d406df612f8986b450bbdf108a451"
  :revdesc "140351a9c43d"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
