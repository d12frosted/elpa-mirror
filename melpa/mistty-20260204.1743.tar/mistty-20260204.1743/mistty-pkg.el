;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20260204.1743"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "1446a304f154bb3616b20cec881ccda586bed4f7"
  :revdesc "1446a304f154"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
