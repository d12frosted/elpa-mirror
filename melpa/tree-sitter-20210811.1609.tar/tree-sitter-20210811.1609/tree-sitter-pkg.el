(define-package "tree-sitter" "20210811.1609" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.15.1"))
  :commit "442675addcd621a138e3554d66cc7e5ae0869977" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
