;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20250519.430"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "978c8c6f2f01bdd6878e5569fa0941f889f28a2e"
  :revdesc "978c8c6f2f01"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
