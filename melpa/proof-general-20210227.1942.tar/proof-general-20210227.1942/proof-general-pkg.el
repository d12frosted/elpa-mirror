(define-package "proof-general" "20210227.1942" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.5"))
  :commit "7844e312b2a192c4245d0d05c12908efc5730e3b" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
