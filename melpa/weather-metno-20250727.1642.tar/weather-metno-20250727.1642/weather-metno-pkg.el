;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weather-metno" "20250727.1642"
  "Weather data from met.no in Emacs."
  '((emacs  "24")
    (cl-lib "0.3"))
  :url "https://github.com/ruediger/weather-metno-el"
  :commit "00eab9a9486e192917238145a4f2505d17fad77a"
  :revdesc "00eab9a9486e"
  :keywords '("comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.de"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.de")))
