;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260809.915"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.96.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "00cbf571c62a1e215489f9f1daf4d7062ee2815d"
  :revdesc "00cbf571c62a")
