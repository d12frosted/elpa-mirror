(define-package "go-translate" "20240716.206" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "74c4e0b0723311f6f592716bccc7328a24828f57" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
