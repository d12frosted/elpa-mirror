(define-package "whizzml-mode" "20191216.1743" "Programming mode for editing WhizzML files"
  '((emacs "24.4"))
  :commit "65fa17f8c1dc50dcb90277b64019c2846a317293" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@bigml.com"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@bigml.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
