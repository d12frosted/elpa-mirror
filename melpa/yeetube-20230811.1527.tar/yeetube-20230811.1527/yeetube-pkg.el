(define-package "yeetube" "20230811.1527" "YouTube/Invidious Front End"
  '((emacs "27.2"))
  :commit "4bf64ad52c800a54a15df49cfc7f5089b4342a9d" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
