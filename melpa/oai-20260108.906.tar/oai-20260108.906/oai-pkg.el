;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260108.906"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "268eda829b16b9000eebbcc30f021c47338a9757"
  :revdesc "268eda829b16"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
