;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ts-mode" "20251007.1735"
  "Verilog Tree-sitter major mode."
  '((emacs        "29.1")
    (verilog-mode "2024.3.1.121933719"))
  :url "https://github.com/gmlarumbe/verilog-ts-mode"
  :commit "32306d69b049d4aa4e2c8fe370ba94a6ffb054bb"
  :revdesc "32306d69b049"
  :keywords '("systemverilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
