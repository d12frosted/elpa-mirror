;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gh" "20260215.349"
  "GitHub CLI integration for Magit."
  '((emacs     "29.1")
    (magit     "4.0.0")
    (transient "0.5.0"))
  :url "https://github.com/jonathanchu/magit-gh"
  :commit "4d8ebed5fcb783c045ac7876c7541d3d6defc668"
  :revdesc "4d8ebed5fcb7"
  :keywords '("git" "tools" "vc" "github")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
