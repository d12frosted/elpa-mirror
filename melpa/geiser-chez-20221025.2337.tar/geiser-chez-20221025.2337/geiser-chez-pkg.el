(define-package "geiser-chez" "20221025.2337" "Chez and Geiser talk to each other"
  '((emacs "26.1")
    (geiser "0.19"))
  :commit "3ad1c3807c25283bb344512b3be3da197200ba3a" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chez" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chez")
;; Local Variables:
;; no-byte-compile: t
;; End:
