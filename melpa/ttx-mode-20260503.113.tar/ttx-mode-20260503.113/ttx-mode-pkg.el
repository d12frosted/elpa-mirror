;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ttx-mode" "20260503.113"
  "TrueType/OpenType font viewer using ttx."
  '((emacs "30.0"))
  :url "https://github.com/wmedrano/ttx-mode"
  :commit "00d5b9ccd3093778c5fab34096c239ae637cca2b"
  :revdesc "00d5b9ccd309"
  :keywords '("tools" "fonts")
  :authors '(("Will Medrano" . "will@wmedrano.dev"))
  :maintainers '(("Will Medrano" . "will@wmedrano.dev")))
