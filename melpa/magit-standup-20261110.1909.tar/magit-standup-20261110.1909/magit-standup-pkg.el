;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-standup" "20261110.1909"
  "Collect recent git commits for standup notes."
  '((emacs     "28.1")
    (magit     "4.5.0")
    (transient "0.8.0"))
  :url "https://github.com/function-artisans/magit-standup"
  :commit "871d75e9e3256226f9a9009da5b03cd34d6c32a1"
  :revdesc "871d75e9e325"
  :keywords '("tools" "vc")
  :authors '(("István Karaszi" . "ikaraszi@gmail.com"))
  :maintainers '(("István Karaszi" . "ikaraszi@gmail.com")))
