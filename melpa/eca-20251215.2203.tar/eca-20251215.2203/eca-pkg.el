;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251215.2203"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "dc2dbdd7ff94d58b691051a372cdeee59950293c"
  :revdesc "dc2dbdd7ff94"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
