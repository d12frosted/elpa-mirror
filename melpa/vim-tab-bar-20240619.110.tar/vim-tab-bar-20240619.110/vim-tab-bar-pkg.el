(define-package "vim-tab-bar" "20240619.110" "Vim-like tab bar"
  '((emacs "28.1"))
  :commit "30cf07595eaa471fd280ee6637c2e6699ef9c42b" :authors
  '(("James Cherti"))
  :maintainers
  '(("James Cherti"))
  :maintainer
  '("James Cherti")
  :keywords
  '("frames")
  :url "https://github.com/jamescherti/vim-tab-bar.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
