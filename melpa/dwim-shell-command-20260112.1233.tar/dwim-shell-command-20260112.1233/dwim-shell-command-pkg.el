;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-shell-command" "20260112.1233"
  "Shell commands with DWIM behaviour."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/dwim-shell-command"
  :commit "1227c014d08c116d8fd446cf5eeb27c566289644"
  :revdesc "1227c014d08c")
