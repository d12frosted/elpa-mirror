;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fanyi" "20261103.847"
  "Not only English-Chinese translator."
  '((emacs "27.1")
    (s     "1.12.0"))
  :url "https://github.com/condy0919/fanyi.el"
  :commit "450704b2c9ceae62c1e7de7cbd5ec1129bb93d81"
  :revdesc "450704b2c9ce"
  :keywords '("convenience" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
