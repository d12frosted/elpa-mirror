;;; fanyi-haici.el --- Haici dictionary service -*- lexical-binding: t -*-

;; Copyright (C) 2021 Zhiwei Chen
;; SPDX-License-Identifier: GPL-3.0-or-later
;; Author: Zhiwei Chen <condy0919@gmail.com>
;; Keywords: convenience, tools
;; URL: https://github.com/condy0919/fanyi.el
;; Package-Requires: ((emacs "27.1") (s "1.12.0"))

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Haici dictionary service.

;;; Code:

(require 'fanyi-base)

(require 's)
(require 'subr-x)
(require 'dom)
(require 'seq)
(require 'json)
(require 'chart)
(require 'cl-lib)
(require 'button)

(defface fanyi-haici-star-face
  '((t :foreground "gold"))
  "Face used for star of word."
  :group 'fanyi)

(defcustom fanyi-haici-chart-inhibit-same-window nil
  "Non-nil means the distribution chart will be popped in another window."
  :type 'boolean
  :group 'fanyi)

(defclass fanyi-haici-service (fanyi-base-service)
  ((syllable :initarg :syllable
             :initform "-"
             :type string
             :documentation "Syllable of the word.")
   (star :initarg :star
         :initform 0
         :type number
         :documentation "Frequency of the word.")
   (star-desc :initarg :star-desc
              :initform ""
              :type string
              :documentation "Frequency description of the word.")
   (phonetics :initarg :phonetics
              :type list
              :documentation "List of (label pronunciation female-audio male-audio).
The label identifies the pronunciation without relying on its position.")
   (paraphrases :initarg :paraphrases
                :type list
                :documentation "List of (pos . paraphrase).")
   (distribution :initarg :distribution
                 :initform nil
                 :type list
                 :documentation "List of (percent . sense).")
   (related :initarg :related
            :type list
            :documentation "List of other parts of speech.")
   (etymons :initarg :etymons
            :type list
            :documentation "The etymons of the word."))
  "The Haici dictionary service.")

;; Silence unknown slots warning.
(eieio-declare-slots :syllable :star :star-desc :phonetics :paraphrases :distribution :related :etymons)

(defconst fanyi-haici-distribution-chart-title
  "fanyi-haici-distribution-chart"
  "The default name of Haici distribution chart buffer.")

(defconst fanyi-haici-speaker-xpm
  "\
/* XPM */
static char* speaker_xpm[] = {
\"13 14 3 1\",
\" 	c None\",
\".	c #000000\",
\"+	s color\",
\"        +++  \",
\"       ++++  \",
\"      +++++ +\",
\"     +++++++ \",
\"     ++++++  \",
\"++++ ++++++  \",
\"++++ ++++++++\",
\"++++ ++++++  \",
\"++++ ++++++  \",
\"     ++++++  \",
\"     +++++++ \",
\"      +++++ +\",
\"       ++++  \",
\"        +++  \"};"
  "The speaker xpm image.")

;; Silence compile warning.
(declare-function fanyi-dwim "fanyi")

(defun fanyi-haici--present-p (value)
  "Return non-nil if VALUE is a nonblank string."
  (and (stringp value) (not (string-empty-p (string-trim value)))))

(defun fanyi-haici--distribution (data)
  "Read optional chart DATA, ignoring malformed rows and chart data."
  (when (fanyi-haici--present-p data)
    (condition-case nil
        (let ((json-object-type 'alist)
              (json-array-type 'list)
              (json-key-type 'symbol))
          (cl-loop for row in (json-read-from-string (url-unhex-string data))
                   for fields = (and (listp (cdr-safe row)) (cdr-safe row))
                   for percent = (cdr (assq 'percent fields))
                   for sense = (cdr (assq 'sense fields))
                   when (and (numberp percent) (<= 0 percent 100)
                             (fanyi-haici--present-p sense))
                   collect (list percent sense)))
      (error nil))))

(cl-defmethod fanyi-parse-from ((this fanyi-haici-service) dom)
  "Complete THIS from DOM, preserving definitions when optional data is absent.
Signal `fanyi-parse-error' when no usable definitions can be extracted."
  ;; Locate elements rather than depending on whitespace or a final dummy li.
  (oset this paraphrases
        (cl-loop for item in (dom-by-tag (dom-by-class dom "dict-basic-ul") 'li)
                 for pos = (string-trim (dom-texts (dom-child-by-tag item 'span) ""))
                 for para = (string-trim (dom-texts (dom-child-by-tag item 'strong) ""))
                 when (fanyi-haici--present-p para)
                 collect (list pos para)))
  (unless (oref this paraphrases)
    (signal 'fanyi-parse-error '("Haici response contains no usable definitions")))
  ;; Syllable, could be nil.
  (when-let* ((str (dom-attr (dom-by-class dom "keyword") 'tip))
              (matches (s-match "\\([a-zA-Z·]+\\)" str)))
    (oset this syllable (nth 1 matches)))
  ;; Star and description, could be nil.
  (when-let* ((str (dom-attr (dom-by-class dom "level-title") 'level))
              (matches (s-match "\\([12345]\\)" str)))
    (oset this star (string-to-number (nth 1 matches)))
    (oset this star-desc str))
  (oset this phonetics
        (cl-loop for item in (dom-non-text-children (dom-by-class dom "phonetic"))
                 for phonetic = (dom-search item (lambda (node) (dom-attr node 'lang)))
                 for pronunciation = (string-trim (dom-texts phonetic ""))
                 for label-text = (string-trim (dom-text item))
                 for lang = (downcase (or (dom-attr phonetic 'lang) ""))
                 for label = (cond ((string-match-p "\\`\\(?:英\\|UK\\|British\\)" label-text) "英")
                                   ((string-match-p "\\`\\(?:美\\|US\\|American\\)" label-text) "美")
                                   ((equal lang "en-gb") "英")
                                   ((equal lang "en-us") "美")
                                   (t "音标"))
                 for female = (dom-attr (dom-by-class item "\\bfsound\\b") 'naudio)
                 for male = (dom-attr
                             (dom-search item
                                         (lambda (node)
                                           (let ((classes (split-string (or (dom-attr node 'class) ""))))
                                             (and (member "sound" classes)
                                                  (not (member "fsound" classes))))))
                             'naudio)
                 when (or (fanyi-haici--present-p pronunciation)
                          (fanyi-haici--present-p female)
                          (fanyi-haici--present-p male))
                 collect (list label pronunciation female male)))
  (oset this distribution
        (fanyi-haici--distribution (dom-attr (dom-by-id dom "dict-chart-basic") 'data)))
  ;; Ignore incomplete related-word pairs.
  (oset this related
        (cl-loop for (label word)
                 in (seq-partition
                     (mapcar (lambda (node) (string-trim (dom-texts node "")))
                             (dom-non-text-children (dom-by-class dom "shape")))
                     2)
                 when (and (fanyi-haici--present-p label)
                           (fanyi-haici--present-p word))
                 collect (list label word)))
  (let* ((section (dom-by-class dom "\\betm\\b"))
         (items (or (dom-by-tag section 'li) (dom-by-tag section 'p))))
    (oset this etymons
          (cl-loop for item in items
                   for text = (string-trim (dom-texts item ""))
                   when (fanyi-haici--present-p text)
                   collect text))))

(defun fanyi-haici--insert-sound (this audio face description)
  "Insert an AUDIO button for THIS with FACE and DESCRIPTION when available."
  (when (fanyi-haici--present-p audio)
    (insert " ")
    (insert-button "🔊"
                   'display (when (fanyi-display-glyphs-p)
                              (find-image `((:type xpm
                                                   :data ,fanyi-haici-speaker-xpm
                                                   :ascent center
                                                   :color-symbols
                                                   (("color" . ,(face-attribute face :foreground)))))))
                   'action #'fanyi-play-sound
                   'button-data (format (oref this sound-url) audio)
                   'face face
                   'follow-link t
                   'help-echo description)))

(cl-defmethod fanyi-render ((this fanyi-haici-service))
  "Render THIS page into a buffer named `fanyi-buffer-name'.
It's NOT thread-safe, caller should hold `fanyi-buffer-mtx'
before calling this method."
  (fanyi-with-fanyi-buffer
    ;; The headline about Haici service.
    (insert "# 海词\n\n")
    ;; Syllables and star/level description.
    (insert (oref this syllable)
            " "
            (s-repeat (oref this star) "★")
            " "
            (oref this star-desc)
            "\n\n")
    ;; Each available pronunciation carries its own label and optional audio.
    (when (oref this phonetics)
      (cl-loop for (label pronunciation female male) in (oref this phonetics)
               for first = t then nil
               do (unless first (insert "  "))
               do (insert label " " pronunciation)
               do (fanyi-haici--insert-sound this female 'fanyi-female-speaker-face "女声版发音")
               do (fanyi-haici--insert-sound this male 'fanyi-male-speaker-face "男声版发音"))
      (insert "\n\n"))
    ;; Paraphrases.
    ;; - n. 荣誉；荣幸；尊敬；信用；正直；贞洁
    ;; - vt. 尊敬；使荣幸；对...表示敬意；兑现
    ;; ...
    (cl-loop for pa in (oref this paraphrases)
             for (pos p) = pa
             do (insert "- " pos " " p "\n"))
    (insert "\n")
    ;; Make a button for distribution chart.
    (when-let ((dist (oref this distribution)))
      (insert-button "Click to view the distribution chart"
                     'action (lambda (dist)
                               ;; `switch-to-buffer' is used in `chart-bar-quickie' which means a new chart buffer will
                               ;; always be popped in the same window.
                               ;;
                               ;; Typing `q' (`quit-window') in chart buffer will
                               ;;
                               ;; 1. bury the *fanyi-haici-distribution-chart* buffer.
                               ;; 2. reset the `restore-quit' window parameter of current window to nil.
                               ;;
                               ;; When the second `q' is typed in *fanyi* buffer, `quit-window' will
                               ;;
                               ;; 1. bury the *fanyi* buffer.
                               ;; 2. `switch-to-prev-buffer'
                               ;;
                               ;; It can't restore the window configuration since `restore-quit' was reset to nil.
                               ;;
                               ;; Once `fanyi-haici-chart-inhibit-same-window' is non-nil, the chart buffer won't be popped
                               ;; in the same window which prevent `quit-window' window parameter from being reset.
                               ;;
                               ;; See (C-x C-e) the below manual
                               ;;
                               ;; (info "(elisp)Quitting Windows")
                               ;;
                               ;; for more information.
                               (let ((switch-to-buffer-obey-display-actions fanyi-haici-chart-inhibit-same-window)
                                     (display-buffer-alist `((,(concat "\\*" fanyi-haici-distribution-chart-title "\\*")
                                                              (display-buffer-pop-up-window)
                                                              (inhibit-same-window . t)))))
                                 (chart-bar-quickie
                                  'vertical
                                  fanyi-haici-distribution-chart-title
                                  (seq-map #'cadr dist) "Senses"
                                  (seq-map #'car dist) "Percent")))
                     'button-data dist
                     'follow-link t)
      (insert "\n\n"))
    ;; Make buttons for related words.
    (when-let ((rs (oref this related)))
      (cl-loop for r in rs
               for (k v) = r
               do (insert k " ")
               do (insert-button v
                                 'action #'fanyi-dwim
                                 'button-data v
                                 'follow-link t)
               do (insert " "))
      (insert "\n\n"))
    ;; The etymons.
    (when-let ((etymons (oref this etymons)))
      (insert "## 起源\n\n")
      (cl-loop for i in etymons
               do (insert "- " i "\n"))
      (insert "\n"))
    ;; Visit the url for more information.
    (insert-button "Browse the full page via eww"
                   'action #'eww
                   'button-data (format (oref this url) (oref this word))
                   'follow-link t)
    (insert "\n\n")))

;; The Haici dict specific font-lock keywords
(add-to-list 'fanyi-mode-font-lock-keywords-extra '("★" . 'fanyi-haici-star-face))

(defconst fanyi-haici-provider
  (fanyi-haici-service :word "dummy"
                       :url "https://dict.cn/%s"
                       :sound-url "https://audio.dict.cn/%s"
                       :api-type 'xml)
  "Haici dictionary service instance.")

(provide 'fanyi-haici)
;;; fanyi-haici.el ends here
