;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keymap-utils" "20260401.1221"
  "Keymap utilities."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/keymap-utils"
  :commit "46e4aeb2801740a69f4ab5411579cc9cb2f0e786"
  :revdesc "46e4aeb28017"
  :keywords '("convenience" "extensions")
  :authors '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev")))
