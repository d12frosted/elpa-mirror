(define-package "notmuch" "20220124.47" "run notmuch within emacs" 'nil :commit "88633bc7a79d47ba96879f698ec2267f2d3f6766" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
