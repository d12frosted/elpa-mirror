(define-package "notmuch" "20220124.47" "run notmuch within emacs" 'nil :commit "15207652a1e52f995d08eb5645f28531b5e19d46" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
