;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20251125.1311"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "0e131b513486836173aff012299caaf7ef2e8ec6"
  :revdesc "0e131b513486"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")
                 ("John Ciolfi" . "john.ciolfi.32@gmail.com")))
