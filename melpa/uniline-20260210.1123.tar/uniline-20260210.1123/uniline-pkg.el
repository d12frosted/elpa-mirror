;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260210.1123"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "89acee815070909139a201373bc87815405efeee"
  :revdesc "89acee815070"
  :keywords '("convenience" "text"))
