;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20250929.1752"
  "Russian holidays and conferences. Updated 2025-09-24."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "8ce40d701969a98a92f01f966709ece9da35a9dd"
  :revdesc "8ce40d701969"
  :keywords '("calendar" "holidays"))
