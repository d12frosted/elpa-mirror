(define-package "live-py-mode" "20211216.329" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "a7da0facf462c092f6ccf1ba84bae6697df01462" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
