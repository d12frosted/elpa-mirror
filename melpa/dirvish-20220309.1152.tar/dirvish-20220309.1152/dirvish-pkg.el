(define-package "dirvish" "20220309.1152" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "259043e17696070335fb9b82fc2e3228c85d9c18" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
