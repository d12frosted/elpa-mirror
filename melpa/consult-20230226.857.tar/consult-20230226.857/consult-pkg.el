(define-package "consult" "20230226.857" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "5116e26cd68d43766d71cb5e941e709000da8fdd" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
