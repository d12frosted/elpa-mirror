(define-package "jupyter" "20231203.650" "Jupyter"
  '((emacs "26")
    (cl-lib "0.5")
    (org "9.1.6")
    (zmq "0.10.10")
    (simple-httpd "1.5.0")
    (websocket "1.9"))
  :commit "e237ff0a312f41c51d2457d311bd7b6b63532922" :authors
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainers
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainer
  '("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")
  :url "https://github.com/emacs-jupyter/jupyter")
;; Local Variables:
;; no-byte-compile: t
;; End:
