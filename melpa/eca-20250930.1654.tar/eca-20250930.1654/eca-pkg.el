;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20250930.1654"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "71c1e45c9bf1cb4b8181fdd41428faa04b09460e"
  :revdesc "71c1e45c9bf1"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
