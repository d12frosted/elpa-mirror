(define-package "affe" "20230121.900" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.20"))
  :commit "6d4314176cce2e915e3aa0b22326a9a10a85d1f6" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
