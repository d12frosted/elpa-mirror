(define-package "notmuch" "20211229.1824" "run notmuch within emacs" 'nil :commit "9cc026f3daaa7731527787f8c7e729c0a08c456c" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
