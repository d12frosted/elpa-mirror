(define-package "notmuch" "20211229.1824" "run notmuch within emacs" 'nil :commit "d99b0d4dc8b9262373e2d0ae158dd8336fc28e41" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
