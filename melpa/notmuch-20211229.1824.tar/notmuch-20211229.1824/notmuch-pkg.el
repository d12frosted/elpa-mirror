(define-package "notmuch" "20211229.1824" "run notmuch within emacs" 'nil :commit "e9c55864cde6e9b9653b9963a36f633f34a57779" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
