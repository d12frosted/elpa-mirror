;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261110.1351"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "6dfe79844972e43dd0fffea73aa79675d53362e3"
  :revdesc "6dfe79844972"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
