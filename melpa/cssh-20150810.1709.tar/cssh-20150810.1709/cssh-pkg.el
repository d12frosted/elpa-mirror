;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cssh" "20150810.1709"
  "Clusterssh implementation for emacs."
  ()
  :url "http://tapoueh.org/emacs/cssh.html"
  :commit "2fe2754235225a59b63f08b130cfd4352e2e1c3f"
  :revdesc "2fe275423522"
  :keywords '("clusterssh" "ssh" "cssh")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
