;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "third-time" "20240207.1621"
  "Third Time: A Better Way to Work."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~swflint/third-time"
  :commit "093b74be860fac389fb173caef5fabf61e417eef"
  :revdesc "093b74be860f"
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
