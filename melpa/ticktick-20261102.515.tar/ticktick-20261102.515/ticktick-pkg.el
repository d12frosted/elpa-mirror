;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ticktick" "20261102.515"
  "Sync Org Mode tasks with TickTick."
  '((emacs        "27.1")
    (request      "0.3.0")
    (simple-httpd "1.5.0"))
  :url "https://github.com/polhuang/ticktick.el"
  :commit "ec02da078ae2bd129e4eb97439b887c70f420864"
  :revdesc "ec02da078ae2"
  :keywords '("tools" "ticktick" "org" "tasks" "todo"))
