(define-package "pumpkin-spice-theme" "20231002.1323" "Spice up your day with a delightful pumpkin colored theme"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "e87ad63bcf39cdde7b26bf5f1e30c899b0c6005c" :authors
  '(("Grant Shangreaux" . "shoshin@cicadas.surf"))
  :maintainers
  '(("Grant Shangreaux" . "shoshin@cicadas.surf"))
  :maintainer
  '("Grant Shangreaux" . "shoshin@cicadas.surf")
  :keywords
  '("faces" "theme" "halloween" "pumpkin")
  :url "https://cicadas.surf/cgit/pumpkin-spice-theme.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
