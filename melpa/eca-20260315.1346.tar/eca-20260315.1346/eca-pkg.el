;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260315.1346"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "2fdaa70b23d5f5845daed648c2303bb10291af4d"
  :revdesc "2fdaa70b23d5"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
