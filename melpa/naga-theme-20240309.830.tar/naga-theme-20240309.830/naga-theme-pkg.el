(define-package "naga-theme" "20240309.830" "Dark color theme with green foreground color" 'nil :commit "fda2b66ce6111d776830d75d18149ebba7ee34b0" :authors
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainers
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainer
  '("Johannes Maier" . "johannes.maier@mailbox.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
