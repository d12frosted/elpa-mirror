;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loco" "20250717.1830"
  "Enter complex key sequences with ease!."
  '((emacs "29.1"))
  :url "https://github.com/csmclaren/loco"
  :commit "364a54157cf432f76adffc342a2f890e38fbef85"
  :revdesc "364a54157cf4"
  :keywords '("abbrev" "convenience")
  :authors '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainers '(("Chris McLaren" . "csmclaren@me.com")))
