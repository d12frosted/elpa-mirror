;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260221.2207"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "50b601dd92f99dd9534ff44de5f411480ca32b09"
  :revdesc "50b601dd92f9"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
