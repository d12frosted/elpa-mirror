(define-package "cape" "20221120.341" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "fe068552e5f85a8e2476ff32555a13fa643d7b71" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
