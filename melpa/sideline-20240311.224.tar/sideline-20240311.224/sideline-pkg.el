(define-package "sideline" "20240311.224" "Show information on the side"
  '((emacs "27.1")
    (ht "2.4"))
  :commit "ca48f3bd234eef8e3648612d62a3f02c98dc99f3" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/emacs-sideline/sideline")
;; Local Variables:
;; no-byte-compile: t
;; End:
