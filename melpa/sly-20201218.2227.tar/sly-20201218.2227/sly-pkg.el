(define-package "sly" "20201218.2227" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "613f597ecf72eb5719d4e13a4bfdbeb91373bf09" :keywords
  ("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
