(define-package "modus-themes" "20210630.1252" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "9b1d1594efa5d7389300b93c78f1b1dd389f9c27" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
