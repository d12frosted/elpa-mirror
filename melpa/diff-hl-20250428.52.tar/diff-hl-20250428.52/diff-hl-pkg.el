;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20250428.52"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "a45d2650f7e8faf899edd7d0ef0a0f8abb13250c"
  :revdesc "a45d2650f7e8"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
