(define-package "modus-themes" "20211002.618" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "9b4900ee2f8bc419b026d89628e90a1dcbed0eab" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
