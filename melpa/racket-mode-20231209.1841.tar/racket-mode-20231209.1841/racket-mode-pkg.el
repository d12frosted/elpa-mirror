(define-package "racket-mode" "20231209.1841" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "e8cbeff9553159f3fbe6760a119d83239eb5ff72" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
