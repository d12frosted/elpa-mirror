;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskjuggler-mode" "20260413.142"
  "Major mode for TaskJuggler project files."
  '((emacs "27.1"))
  :url "https://github.com/devrintalen/taskjuggler-mode.el"
  :commit "a2d6995abcab6ef39697b4f27d6c8856b5398746"
  :revdesc "a2d6995abcab"
  :keywords '("languages" "project-management")
  :authors '(("Devrin Talen" . "devrin@fastmail.com"))
  :maintainers '(("Devrin Talen" . "devrin@fastmail.com")))
