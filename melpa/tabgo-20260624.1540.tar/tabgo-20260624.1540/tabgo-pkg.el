;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabgo" "20260624.1540"
  "Jump to tabs, avy style."
  '((emacs "27.1"))
  :url "https://github.com/isamert/tabgo.el"
  :commit "7cf1142c3e194ded79632846830775b42830ce51"
  :revdesc "7cf1142c3e19"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
