;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hamburg-theme" "20160123.740"
  "Color Theme with a dark blue background."
  '((emacs "24"))
  :url "https://github.com/mswift42/hamburg-theme"
  :commit "a05bf090e0c57c34cc59e301f95d9961280db244"
  :revdesc "a05bf090e0c5")
