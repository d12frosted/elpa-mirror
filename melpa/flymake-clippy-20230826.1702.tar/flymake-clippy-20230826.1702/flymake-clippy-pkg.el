(define-package "flymake-clippy" "20230826.1702" "Flymake backend for Clippy"
  '((emacs "26.1"))
  :commit "d0774403fe96d88bd629d0825ffca46a1786d697" :authors
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainers
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainer
  '("Graham Marlow" . "info@mgmarlow.com")
  :keywords
  '("tools")
  :url "https://sr.ht/~mgmarlow/flymake-clippy/")
;; Local Variables:
;; no-byte-compile: t
;; End:
