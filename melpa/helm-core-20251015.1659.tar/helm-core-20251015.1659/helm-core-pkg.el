;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251015.1659"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "d46b1af1a5bd84f2a2f81dee15a7d0a2967428fe"
  :revdesc "d46b1af1a5bd"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
