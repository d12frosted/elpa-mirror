;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apparmor-mode" "20260506.621"
  "Major mode for editing AppArmor policy files."
  '((emacs "26.1"))
  :url "https://gitlab.com/apparmor/apparmor-mode"
  :commit "b74d3f962c9ac82f3ac2c06ced5f8041296dbe1d"
  :revdesc "b74d3f962c9a"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
