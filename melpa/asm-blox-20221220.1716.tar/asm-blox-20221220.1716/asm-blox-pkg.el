(define-package "asm-blox" "20221220.1716" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "5517efb1e186139197a2d348b7339a72dd379af8" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
