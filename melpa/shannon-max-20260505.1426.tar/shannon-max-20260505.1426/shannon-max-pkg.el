;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shannon-max" "20260505.1426"
  "Analyze your keybindings with information theory."
  '((emacs "29.1"))
  :url "https://github.com/sstraust/shannonmax"
  :commit "539bd5f771b798973734696b3b0ae10f56d3966d"
  :revdesc "539bd5f771b7"
  :authors '(("Sam Straus" . "sam_straus@alumni.brown.edu"))
  :maintainers '(("Sam Straus" . "sam_straus@alumni.brown.edu")))
