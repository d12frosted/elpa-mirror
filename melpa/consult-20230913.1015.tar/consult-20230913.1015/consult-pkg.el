(define-package "consult" "20230913.1015" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "a294f162632767e8950ec9758b123c29b46c03af" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
