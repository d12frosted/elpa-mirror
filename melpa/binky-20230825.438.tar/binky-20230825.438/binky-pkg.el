(define-package "binky" "20230825.438" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "3ce323c000ba509b8dd99b23b44a0464ffd4dd7f" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
