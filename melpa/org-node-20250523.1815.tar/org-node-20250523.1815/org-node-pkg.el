;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250523.1815"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "dcb7a4d7322561f60dfe90e9910dde24aec11851"
  :revdesc "dcb7a4d73225"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
