(define-package "modus-themes" "20201219.1819" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "0bd451207a093e8b231d7a6d7c1408c913de1e63" :keywords
  ("faces" "theme" "accessibility")
  :authors
  (("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  ("Protesilaos Stavrou" . "info@protesilaos.com")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
