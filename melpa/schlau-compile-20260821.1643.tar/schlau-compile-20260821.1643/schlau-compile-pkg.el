;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "schlau-compile" "20260821.1643"
  "Git-root-aware interface to `compile'."
  '((emacs "24.3"))
  :url "https://github.com/flajann2/schlau-compile"
  :commit "720f1c4e4ceddf5f36b236f92ac3270e49246234"
  :revdesc "720f1c4e4ced"
  :keywords '("tools" "unix" "processes" "compile" "compilation" "workflow" "development")
  :authors '(("Fred Mitchell" . "fred.mitchell@atomlogik.de"))
  :maintainers '(("Fred Mitchell" . "fred.mitchell@atomlogik.de")))
