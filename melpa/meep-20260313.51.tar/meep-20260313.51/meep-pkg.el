;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260313.51"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "d187dd3cd59edd5dad46f4c588504607b4191eaf"
  :revdesc "d187dd3cd59e"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
