;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250630.1453"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "cbe975f1d1fe856c15113b7be5f9df98aa971a84"
  :revdesc "cbe975f1d1fe"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
