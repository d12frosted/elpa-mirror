;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "20241106.934"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "https://github.com/szermatt/visual-replace"
  :commit "57a25ee9471e0d718730c95cc8028d0e0eb215cd"
  :revdesc "57a25ee9471e"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
