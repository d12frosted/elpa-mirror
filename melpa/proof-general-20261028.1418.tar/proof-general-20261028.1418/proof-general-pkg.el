;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261028.1418"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "7117e4b9bad3e3801f464091df9cd77d7f560be2"
  :revdesc "7117e4b9bad3"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
