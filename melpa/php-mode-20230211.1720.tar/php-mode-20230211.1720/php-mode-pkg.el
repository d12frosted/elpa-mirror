(define-package "php-mode" "20230211.1720" "Major mode for editing PHP code"
  '((emacs "25.2"))
  :commit "be716f0479737baf2518b777c6015ffb124e949a" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
