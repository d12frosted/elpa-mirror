(define-package "immersive-translate" "20230909.1801" "Translate the current buffer immersively"
  '((emacs "28.2"))
  :commit "431a303b7c319dc5e2c98a4bf06b7e8fb305273d" :authors
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainers
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainer
  '("Eli Qian" . "eli.q.qian@gmail.com")
  :keywords
  '("convenience" "help" "translate")
  :url "https://github.com/Elilif/emacs-immersive-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
