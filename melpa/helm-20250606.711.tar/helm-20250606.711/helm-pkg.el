;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250606.711"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.3")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "f1ab92a1afa927b4252e85838b7148e2f4813735"
  :revdesc "f1ab92a1afa9"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
