(define-package "m-buffer" "20220719.1850" "List-Oriented, Functional Buffer Manipulation"
  '((seq "2.14"))
  :commit "ecdc61282155739acd6b03233d5733e1ad57da1b" :authors
  '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainer
  '("Phillip Lord" . "phillip.lord@russet.rg.uk"))
;; Local Variables:
;; no-byte-compile: t
;; End:
