;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-char-preview" "20260128.834"
  "Preview character when executing `goto-char` command."
  '((emacs "24.3"))
  :url "https://github.com/emacs-vs/goto-char-preview"
  :commit "e2a4534e2632e40d0f8042c9804047875bc59e91"
  :revdesc "e2a4534e2632"
  :keywords '("convenience" "character" "navigation")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
