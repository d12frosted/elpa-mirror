(define-package "srfi" "20210701.23" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "a92d2a4f748f124910d406a9386979688f7f28a5" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
