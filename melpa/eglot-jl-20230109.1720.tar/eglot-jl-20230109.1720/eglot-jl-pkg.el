(define-package "eglot-jl" "20230109.1720" "Julia support for eglot"
  '((emacs "25.1")
    (eglot "1.4")
    (project "0.8.1")
    (cl-generic "1.0"))
  :commit "3e66d604b66a35290c686194de7cb39b113ab20a" :authors
  '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz"))
  :maintainer
  '("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/non-Jedi/eglot-jl")
;; Local Variables:
;; no-byte-compile: t
;; End:
