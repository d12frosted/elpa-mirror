;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20260330.819"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "4f8b4cdb75867b08b488a29630e81e27fc15b81d"
  :revdesc "4f8b4cdb7586"
  :keywords '("erlang" "languages" "processes"))
