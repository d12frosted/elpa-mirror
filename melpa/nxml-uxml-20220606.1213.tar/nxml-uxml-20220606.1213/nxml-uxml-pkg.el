;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nxml-uxml" "20220606.1213"
  "MicroXML support for nXML."
  '((emacs "25"))
  :url "https://gitlab.com/dpk/nxml-uxml"
  :commit "95bbd0018ab218b9f39f5bf1f1e809f60fbc3edc"
  :revdesc "95bbd0018ab2"
  :keywords '("languages" "xml" "microxml"))
