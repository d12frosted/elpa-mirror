;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "20251006.1002"
  "A major mode for editing OpenSCAD code."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "fcb94c54019e3be5cbc4730f45c6bd2a5cac5386"
  :revdesc "fcb94c54019e"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
