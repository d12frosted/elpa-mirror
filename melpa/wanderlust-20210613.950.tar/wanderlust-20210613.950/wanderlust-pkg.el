(define-package "wanderlust" "20210613.950" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "a3aa8db135c08632f1d87966d0543e4661d89514")
;; Local Variables:
;; no-byte-compile: t
;; End:
