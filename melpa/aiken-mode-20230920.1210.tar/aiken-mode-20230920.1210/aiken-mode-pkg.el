;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aiken-mode" "20230920.1210"
  "Major mode for Aiken."
  '((emacs "26.1"))
  :url "https://github.com/aiken-lang/aiken-mode"
  :commit "1af54e4df02eb52cf62034acbe1c6dd54776d843"
  :revdesc "1af54e4df02e"
  :keywords '("languages" "aiken")
  :authors '(("Sebastian Nagel" . "sebastian.nagel@ncoding.at"))
  :maintainers '(("Sebastian Nagel" . "sebastian.nagel@ncoding.at")))
