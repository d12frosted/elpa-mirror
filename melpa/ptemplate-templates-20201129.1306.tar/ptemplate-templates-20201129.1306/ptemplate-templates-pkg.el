(define-package "ptemplate-templates" "20201129.1306" "Official templates"
  '((emacs "25.1")
    (ptemplate "2.0.0"))
  :commit "40cf3031f0fb5bbb75e1f35db3186fd1aabe7262" :authors
  (("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainer
  ("Nikita Bloshchanevich" . "nikblos@outlook.com")
  :url "https://github.com/nbfalcon/ptemplate-templates")
;; Local Variables:
;; no-byte-compile: t
;; End:
