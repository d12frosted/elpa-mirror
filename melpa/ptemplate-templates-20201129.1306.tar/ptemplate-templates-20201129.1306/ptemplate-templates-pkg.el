(define-package "ptemplate-templates" "20201129.1306" "Official templates"
  '((emacs "25.1")
    (ptemplate "2.0.0"))
  :commit "17c3f270a97ea3f018536a7b8fb81101e46b1090" :authors
  (("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainer
  ("Nikita Bloshchanevich" . "nikblos@outlook.com")
  :url "https://github.com/nbfalcon/ptemplate-templates")
;; Local Variables:
;; no-byte-compile: t
;; End:
