;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20241209.1035"
  "Beautify Org Links."
  '((emacs      "29.1")
    (org        "9.7.14")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "d9f5dcfde011d3c085d6b9ede666b044fc10816d"
  :revdesc "d9f5dcfde011"
  :keywords '("hypermedia"))
