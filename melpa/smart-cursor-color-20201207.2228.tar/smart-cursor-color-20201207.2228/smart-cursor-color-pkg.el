;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-cursor-color" "20201207.2228"
  "Change cursor color dynamically."
  ()
  :url "https://github.com/7696122/smart-cursor-color/"
  :commit "d532f0b27e37cbd3bfc0be09d0b54aa38f1648f1"
  :revdesc "d532f0b27e37"
  :keywords '("cursor" "color" "face"))
