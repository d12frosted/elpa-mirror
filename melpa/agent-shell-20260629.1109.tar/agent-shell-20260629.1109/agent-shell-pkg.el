;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260629.1109"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7dfc627390d52188047701a54b191842681d1ba9"
  :revdesc "7dfc627390d5")
