(define-package "gptel" "20231108.637" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "66d2bafad6a6f51d4e4e015db7e66c5eae319a17" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
