(define-package "forge" "20230521.2023" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "29.1.4.1")
    (closql "20230407")
    (dash "2.19.1")
    (emacsql "20230409")
    (ghub "20220621")
    (let-alist "1.0.6")
    (magit "20230319")
    (markdown-mode "2.4")
    (transient "0.4.0")
    (yaml "0.5.2"))
  :commit "e165c2e4fbe4f04ce4801b0d3883d7a2c16661fb" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
