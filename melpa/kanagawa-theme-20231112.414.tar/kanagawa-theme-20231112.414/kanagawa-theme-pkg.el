(define-package "kanagawa-theme" "20231112.414" "Retro elegant theme"
  '((autothemer "0.2.18")
    (emacs "28.1"))
  :commit "692cc627ccdd0595de3bbc67e313a0363002e444" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/Meritamen/kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
