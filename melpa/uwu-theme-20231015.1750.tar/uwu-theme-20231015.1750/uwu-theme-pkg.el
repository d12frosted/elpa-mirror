(define-package "uwu-theme" "20231015.1750" "An awesome dark color scheme"
  '((emacs "24.1"))
  :commit "465d9823be14a9f45b0fb2bfb3bbd7038d6169a2" :authors
  '(("Kevin Borling"))
  :maintainers
  '(("Kevin Borling"))
  :maintainer
  '("Kevin Borling")
  :keywords
  '("custom themes" "dark" "faces")
  :url "https://github.com/kborling/uwu-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
