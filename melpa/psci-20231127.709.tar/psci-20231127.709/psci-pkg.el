(define-package "psci" "20231127.709" "Major mode for purescript repl psci"
  '((emacs "24.4")
    (purescript-mode "13.10")
    (dash "2.9.0"))
  :commit "8a7481b81551c3ab095917292c704679f474869a" :authors
  '(("Antoine R. Dumont <eniotna.t AT gmail.com>"))
  :maintainers
  '(("Antoine R. Dumont <eniotna.t AT gmail.com>"))
  :maintainer
  '("Antoine R. Dumont <eniotna.t AT gmail.com>")
  :keywords
  '("languages" "purescript" "psci" "repl")
  :url "https://github.com/purescript-emacs/emacs-psci")
;; Local Variables:
;; no-byte-compile: t
;; End:
