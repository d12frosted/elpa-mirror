(define-package "burly" "20220630.1113" "Save and restore frame/window configurations with buffers"
  '((emacs "28.1")
    (map "2.1"))
  :commit "a3b43a0afd3ceebc196585115ee94dfa423f3c4a" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
