;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260320.1344"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "31f1ff5b20a9e0f3ffb27df0d27f935cd2750a76"
  :revdesc "31f1ff5b20a9"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
