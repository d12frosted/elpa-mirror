;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260328.1759"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "a646f643f8f9cffc2c8decd43df2ca8e44dc90c2"
  :revdesc "a646f643f8f9"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
