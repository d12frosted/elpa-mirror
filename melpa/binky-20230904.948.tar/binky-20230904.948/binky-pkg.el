(define-package "binky" "20230904.948" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "268988d0f96c27e52c056d0e043a23d35c584445" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
