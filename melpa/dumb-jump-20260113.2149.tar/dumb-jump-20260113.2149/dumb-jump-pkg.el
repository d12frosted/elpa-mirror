;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260113.2149"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.3")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "95254b29f2a27cff63e3faebdfd12772c0f90168"
  :revdesc "95254b29f2a2"
  :keywords '("programming"))
