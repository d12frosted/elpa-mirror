(define-package "elixir-ts-mode" "20231007.1031" "Major mode for Elixir with tree-sitter support"
  '((emacs "29.1")
    (heex-ts-mode "1.3"))
  :commit "411ab0a8594040573a2b6bc30f35fa4eea02ba02" :authors
  '(("Wilhelm H Kirschbaum"))
  :maintainers
  '(("Wilhelm H Kirschbaum"))
  :maintainer
  '("Wilhelm H Kirschbaum")
  :keywords
  '("elixir" "languages" "tree-sitter")
  :url "https://github.com/wkirschbaum/elixir-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
