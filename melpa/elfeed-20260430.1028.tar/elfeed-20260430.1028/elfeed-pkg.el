;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260430.1028"
  "An Emacs Atom/RSS feed reader."
  '((emacs "24.3"))
  :url "https://github.com/skeeto/elfeed"
  :commit "07b0b761fac0282fcaa424948df85c4f7118b53e"
  :revdesc "07b0b761fac0"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
