;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "20260813.1041"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "30.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "a312dc80048ad66275596c0fe0a0366ba3ced895"
  :revdesc "a312dc80048a"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
