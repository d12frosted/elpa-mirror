(define-package "meow" "20220727.2104" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "7471762ec043fa85a91398b2b5b05859da544200" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
