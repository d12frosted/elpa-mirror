;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "universal-sidecar-citeproc" "20260314.1744"
  "Centralise Citeproc Support for Universal Sidecar."
  '((emacs    "28.1")
    (citeproc "0.9.4"))
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar"
  :commit "3b6bd928f7adb840e62a63dd5bf1236ece912b13"
  :revdesc "3b6bd928f7ad"
  :keywords '("bib" "convenience")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
