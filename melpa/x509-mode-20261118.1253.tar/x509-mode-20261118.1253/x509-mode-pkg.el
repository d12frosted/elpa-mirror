;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261118.1253"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "6183dc010f4e482eec10445c0b59441bb340d698"
  :revdesc "6183dc010f4e"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
