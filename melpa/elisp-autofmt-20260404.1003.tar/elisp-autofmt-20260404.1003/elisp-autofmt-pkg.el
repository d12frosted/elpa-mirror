;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-autofmt" "20260404.1003"
  "Emacs lisp auto-format."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt"
  :commit "ed36c5ed4eec91a2c2373a4a03d0d0a9f14aea83"
  :revdesc "ed36c5ed4eec"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
