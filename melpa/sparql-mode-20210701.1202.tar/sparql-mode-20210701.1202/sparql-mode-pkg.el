(define-package "sparql-mode" "20210701.1202" "Edit and interactively evaluate SPARQL queries."
  '((cl-lib "0.5")
    (emacs "24.3"))
  :commit "ceb370b3879841f8809cc3f9b1b87e898f10562f" :authors
  '(("Craig Andera <candera at wangdera dot com>"))
  :maintainer
  '("Bjarte Johansen <Bjarte dot Johansen at gmail dot com>")
  :url "https://github.com/ljos/sparql-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
