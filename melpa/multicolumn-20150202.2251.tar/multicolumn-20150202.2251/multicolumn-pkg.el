;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multicolumn" "20150202.2251"
  "Creating and managing multiple side-by-side windows."
  ()
  :url "https://github.com/Lindydancer/multicolumn"
  :commit "c7a3afecd470859b2e60aa7c554d6e4d436df7fa"
  :revdesc "c7a3afecd470")
