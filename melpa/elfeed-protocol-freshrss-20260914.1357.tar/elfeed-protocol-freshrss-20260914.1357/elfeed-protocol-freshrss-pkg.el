;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol-freshrss" "20260914.1357"
  "FreshRSS compatible gReader protocol implementation for elfeed."
  '((emacs            "29.1")
    (elfeed           "4.0.0")
    (elfeed-protocol  "1.0.0")
    (deferred         "0.5.1")
    (request          "0.3.2")
    (request-deferred "0.3.2"))
  :url "https://codeberg.org/lou/elfeed-protocol-freshrss"
  :commit "04b373d1b4deae95e4ea3ede001e74fabbc3ba66"
  :revdesc "04b373d1b4de"
  :authors '(("Lou Woell" . "lou@repetitions.de"))
  :maintainers '(("Lou Woell" . "lou@repetitions.de")))
