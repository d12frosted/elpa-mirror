;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250224.1054"
  "Emacs major mode for Smallworld Magik files."
  '((emacs  "24.4")
    (compat "28.1"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "6d1fd36b3211d5413d1c557b8341fd268f7a07e5"
  :revdesc "6d1fd36b3211"
  :keywords '("languages"))
