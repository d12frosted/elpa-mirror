;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260731.2202"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "d83e647b0a4e35b79dec4d879e280dc17bb809c8"
  :revdesc "d83e647b0a4e"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
