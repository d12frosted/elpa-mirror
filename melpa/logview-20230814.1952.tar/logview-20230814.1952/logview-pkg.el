(define-package "logview" "20230814.1952" "Major mode for viewing log files"
  '((emacs "25.1")
    (datetime "0.8")
    (extmap "1.0"))
  :commit "673c90b48a94755c0f7d8d91ad9e2a7c529e7a1a" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("files" "tools")
  :url "https://github.com/doublep/logview")
;; Local Variables:
;; no-byte-compile: t
;; End:
