(define-package "popper" "20211008.2344" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "8d2b664465bcdbd04375fdbea2054f808ffe8976" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
