;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260701.1350"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "cb87bda462cdfdd39817148a3896b304865f668f"
  :revdesc "cb87bda462cd"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
