(define-package "loopy" "20210615.235" "A looping macro"
  '((emacs "27.1"))
  :commit "8203d98d4c66fe2907a114e1f5d867974005a4cc" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
