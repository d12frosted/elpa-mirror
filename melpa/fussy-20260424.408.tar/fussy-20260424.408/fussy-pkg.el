;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260424.408"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "6366161a0e03c6c12aeba872fed3dfdc135bff9c"
  :revdesc "6366161a0e03"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
