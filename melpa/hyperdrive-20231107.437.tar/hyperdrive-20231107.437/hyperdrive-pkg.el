(define-package "hyperdrive" "20231107.437" "P2P filesystem"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5")
    (taxy-magit-section "0.12.1")
    (transient "0.4.3"))
  :commit "be533a1d1988f28ac73d496e863983d0c80a295c" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
