;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20260518.954"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "e60458cdb597e0089e2bdd280cd29a67c0f4652f"
  :revdesc "e60458cdb597"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
