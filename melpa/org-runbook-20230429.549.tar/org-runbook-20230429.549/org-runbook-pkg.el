(define-package "org-runbook" "20230429.549" "Org mode for runbooks"
  '((emacs "27.1")
    (seq "2.3")
    (f "0.20.0")
    (s "1.12.0")
    (dash "2.17.0")
    (mustache "0.24")
    (ht "0.9")
    (ivy "0.8.0"))
  :commit "4c72d552e988ed554fd1566908276fcf48013352" :authors
  '(("Tyler Dodge"))
  :maintainers
  '(("Tyler Dodge"))
  :maintainer
  '("Tyler Dodge")
  :keywords
  '("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
