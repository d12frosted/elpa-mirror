(define-package "spdx" "20230928.59" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "c4f5947bb920b331c581ff0a6cde2fc4777b77ae" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
