;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keg" "20261112.956"
  "Modern Elisp package development system."
  '((emacs "24.1"))
  :url "https://github.com/conao3/keg.el"
  :commit "d5962451b6b8e35fbc05631006776b962d64017f"
  :revdesc "d5962451b6b8"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
