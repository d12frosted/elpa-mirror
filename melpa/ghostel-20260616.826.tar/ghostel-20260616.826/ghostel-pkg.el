;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260616.826"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "a6c05008057c799033b9542e462dff0b10b4877b"
  :revdesc "a6c05008057c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
