(define-package "awk-yasnippets" "20230513.2206" "Yasnippets for AWK"
  '((emacs "26.3")
    (yasnippet "0.8.0"))
  :commit "0c721d7c472823806b1033227f17a9f4ca4933ca" :authors
  '(("Adriano Martinez"))
  :maintainers
  '(("Adriano Martinez" . "uberkael@gmail.com"))
  :maintainer
  '("Adriano Martinez" . "uberkael@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/uberkael/awk-yasnippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
