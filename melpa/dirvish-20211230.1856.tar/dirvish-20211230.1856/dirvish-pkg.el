(define-package "dirvish" "20211230.1856" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "5eec5aa87039659366386b25a07f4e5ce3760b92" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
