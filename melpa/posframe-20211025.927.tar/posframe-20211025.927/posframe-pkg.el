(define-package "posframe" "20211025.927" "Pop a posframe (just a frame) at point"
  '((emacs "26"))
  :commit "d16dfbdab1b62ca140bf4a39fedff812ae9a71ec" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
