(define-package "ebib" "20221107.1819" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "26.1"))
  :commit "6ca581972590ecbccd64275b89d2ad5282145b2d" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
