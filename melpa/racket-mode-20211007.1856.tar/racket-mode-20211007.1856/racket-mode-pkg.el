(define-package "racket-mode" "20211007.1856" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "e34970b6e82f3fee6ca7e5aa971c2d8e2cd54a0b" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
