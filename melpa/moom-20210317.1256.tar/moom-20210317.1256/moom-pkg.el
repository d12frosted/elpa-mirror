(define-package "moom" "20210317.1256" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "19da207749ed2a52d775041c2010f7524b4e60a9" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
