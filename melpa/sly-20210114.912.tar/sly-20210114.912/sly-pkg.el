(define-package "sly" "20210114.912" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "eb67be9698794ba66a09f46b7cfffab742863a91" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
