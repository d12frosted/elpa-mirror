;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "20250515.1640"
  "Wrapper for difftastic."
  '((emacs     "28.1")
    (compat    "29.1.4.2")
    (magit     "4.0.0")
    (transient "0.4.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "7170403fd202b20d5b129afb97d00cbba4a57efc"
  :revdesc "7170403fd202"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
