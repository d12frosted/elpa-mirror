;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260723.738"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "8f334b1f905f304163033cf5b4c9d1a7c536b3df"
  :revdesc "8f334b1f905f"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
