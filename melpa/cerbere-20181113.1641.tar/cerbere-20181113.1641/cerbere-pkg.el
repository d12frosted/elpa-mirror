(define-package "cerbere" "20181113.1641" "Unit testing in Emacs for several programming languages"
  '((pkg-info "0.5"))
  :commit "bb18d932b16541105d41a668dbf6fc4e833a6dc2" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("python" "go" "php" "phpunit" "elisp" "ert" "tests" "tdd")
  :url "https://github.com/nlamirault/cerbere")
;; Local Variables:
;; no-byte-compile: t
;; End:
