;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260709.1016"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a38d17227f20256140ece91d7ee42f7188369d7e"
  :revdesc "a38d17227f20"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
