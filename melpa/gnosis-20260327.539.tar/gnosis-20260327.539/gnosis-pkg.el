;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260327.539"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "d3c301e6f5fb6f8b2e0224fdc763dc3a31b1a1cd"
  :revdesc "d3c301e6f5fb"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
