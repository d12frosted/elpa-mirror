(define-package "wildcharm-theme" "20231024.2311" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "cd887cf61f73a4cf044bd01cec60be7324660f9b" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
