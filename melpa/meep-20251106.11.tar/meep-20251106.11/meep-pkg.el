;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251106.11"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a315ef40a355f09bb2f3b78e03f34dd0ec7237e7"
  :revdesc "a315ef40a355"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
