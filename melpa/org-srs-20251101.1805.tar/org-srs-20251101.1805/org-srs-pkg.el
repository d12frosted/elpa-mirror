;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251101.1805"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "6e6f4dc6eff228d51889665fad42f1840cfcc0cd"
  :revdesc "6e6f4dc6eff2"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
