(define-package "format-all" "20230530.859" "Auto-format C, C++, JS, Python, Ruby and 50 other languages"
  '((emacs "24.4")
    (inheritenv "0.1")
    (language-id "0.19"))
  :commit "4a5c64e44083de91c5b49cfea71872d503cae8fc" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/lassik/emacs-format-all-the-code")
;; Local Variables:
;; no-byte-compile: t
;; End:
