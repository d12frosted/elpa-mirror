;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260625.1307"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "66cebba3d63edfa229d5d5d0f502ff60c102a02f"
  :revdesc "66cebba3d63e"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
