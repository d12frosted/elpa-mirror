;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-space-mode" "20260204.255"
  "Auto add space between CJK and ASCII."
  '((emacs "29.1"))
  :url "https://github.com/wowhxj/auto-space-mode"
  :commit "38cd6bc259522250c1df88f24d0a3cc3727fb982"
  :revdesc "38cd6bc25952"
  :keywords '("convenience" "wp")
  :authors '(("Randolph" . "xiaojianghuang@yahoo.com"))
  :maintainers '(("Randolph" . "xiaojianghuang@yahoo.com")))
