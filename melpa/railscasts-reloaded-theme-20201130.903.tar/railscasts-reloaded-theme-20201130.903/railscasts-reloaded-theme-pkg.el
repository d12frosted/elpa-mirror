;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "railscasts-reloaded-theme" "20201130.903"
  "Railscasts Reloaded color theme."
  ()
  :url "https://github.com/thegeorgeous/railscasts-reloaded-theme"
  :commit "1c3850568e60a555d59cbb57bf2b6aa06e99d454"
  :revdesc "1c3850568e60"
  :authors '(("George Thomas" . "iamgeorgethomas@gmail.com"))
  :maintainers '(("George Thomas" . "iamgeorgethomas@gmail.com")))
