(define-package "dylan-mode" "20201212.2106" "Major mode for the Dylan programming language. http://opendylan.org" 'nil :commit "6277d31e6ec896ceaa9533ed156cece26359ba17" :authors
  '(("Robert Stockton" . "rgs@cs.cmu.edu"))
  :maintainer
  '("Chris Page" . "cpage@opendylan.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
