(define-package "modus-themes" "20211028.1111" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "0617ab1a0c8fb93c720b1381cd0a6796e4c2c624" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
