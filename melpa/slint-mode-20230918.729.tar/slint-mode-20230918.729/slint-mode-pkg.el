(define-package "slint-mode" "20230918.729" "Major-mode for the Slint UI language"
  '((emacs "24.4")
    (lsp-mode "6.0"))
  :commit "9fc038d57330c94d131a1770cbc25c297376ee6e" :authors
  '(("Niklas Cathor" . "niklas.cathor@gmx.de"))
  :maintainers
  '(("Niklas Cathor" . "niklas.cathor@gmx.de"))
  :maintainer
  '("Niklas Cathor" . "niklas.cathor@gmx.de")
  :keywords
  '("languages")
  :url "https://github.com/nilclass/slint-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
