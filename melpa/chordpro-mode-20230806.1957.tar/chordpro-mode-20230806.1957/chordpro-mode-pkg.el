(define-package "chordpro-mode" "20230806.1957" "Major mode for ChordPro lead sheet file format"
  '((emacs "28.1")
    (compat "29.1.4.1"))
  :commit "d37dbe72a227091ee433159e6bb018364fd48af7" :authors
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainer
  '("Howard Ding" . "hading2@gmail.com")
  :keywords
  '("convenience")
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
