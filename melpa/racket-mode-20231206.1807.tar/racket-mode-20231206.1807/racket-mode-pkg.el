(define-package "racket-mode" "20231206.1807" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "310f1952213b0e4a8cee7e8cd1f057442e9feb0f" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
