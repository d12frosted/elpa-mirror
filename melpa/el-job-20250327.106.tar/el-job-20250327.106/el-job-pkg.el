;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250327.106"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "73eea0da430f6f424b5a958760e00a6c05cba0ed"
  :revdesc "73eea0da430f"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
