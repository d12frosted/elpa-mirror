(define-package "file-info" "20230427.714" "Show pretty information about current file"
  '((emacs "28.1")
    (hydra "0.15.0")
    (browse-at-remote "0.15.0"))
  :commit "cb06d793b7e1ba769189f2002236305eba002660" :authors
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainer
  '("Artur Yaroshenko" . "artawower@protonmail.com")
  :url "https://github.com/artawower/file-info.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
