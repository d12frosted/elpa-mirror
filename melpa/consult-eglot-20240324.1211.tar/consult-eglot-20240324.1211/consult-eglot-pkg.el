(define-package "consult-eglot" "20240324.1211" "A consulting-read interface for eglot"
  '((emacs "27.1")
    (eglot "1.7")
    (consult "0.31")
    (project "0.3.0"))
  :commit "64262e72452f8fe6dd49d31bcdd4bd577b7d682d" :authors
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :keywords
  '("tools" "completion" "lsp")
  :url "https://github.com/mohkale/consult-eglot")
;; Local Variables:
;; no-byte-compile: t
;; End:
