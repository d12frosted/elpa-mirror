;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "20260924.1754"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "7b93522b6f9d0f3343fd34e5fd1be2ce2f66b279"
  :revdesc "7b93522b6f9d"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
