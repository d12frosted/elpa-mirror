(define-package "dix" "20220323.1046" "Apertium XML editing minor mode"
  '((cl-lib "0.5")
    (emacs "26.2"))
  :commit "5230c18456ab034f2fb69acdbef62c1abae6a8cf" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("languages")
  :url "http://wiki.apertium.org/wiki/Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
