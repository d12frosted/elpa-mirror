(define-package "package-lint" "20220603.848" "A linting library for elisp package authors"
  '((cl-lib "0.5")
    (emacs "24.1")
    (let-alist "1.0.6"))
  :commit "622a5a6e853e5a4c7f2b4c53e2ac0edde354b07c" :authors
  '(("Steve Purcell" . "steve@sanityinc.com")
    ("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("lisp")
  :url "https://github.com/purcell/package-lint")
;; Local Variables:
;; no-byte-compile: t
;; End:
