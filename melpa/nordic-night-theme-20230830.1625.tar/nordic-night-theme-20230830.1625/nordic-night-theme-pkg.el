(define-package "nordic-night-theme" "20230830.1625" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "d13a78fb5494d931609fc8e714af7076afb6a503" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
