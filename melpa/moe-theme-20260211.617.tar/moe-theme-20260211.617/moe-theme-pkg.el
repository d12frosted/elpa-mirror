;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moe-theme" "20260211.617"
  "A colorful eye-candy theme. Moe, moe, kyun!."
  ()
  :url "https://github.com/kuanyui/moe-theme.el"
  :commit "4d779e8af108cd0b2867a9145453ce1dd46678df"
  :revdesc "4d779e8af108"
  :keywords '("themes")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
