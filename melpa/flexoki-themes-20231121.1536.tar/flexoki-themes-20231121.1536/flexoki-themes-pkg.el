(define-package "flexoki-themes" "20231121.1536" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "83b3c3888a7900141f5e2f4049a26755bd9ff14d" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
