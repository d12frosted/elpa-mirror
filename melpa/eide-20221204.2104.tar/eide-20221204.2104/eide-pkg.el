(define-package "eide" "20221204.2104" "IDE interface" 'nil :commit "ccddbb7b893c9b2439c19832aeb2c4d7dd8f5d90" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://software.hjuvi.fr.eu.org/eide/")
;; Local Variables:
;; no-byte-compile: t
;; End:
