(define-package "elisp-autofmt" "20221228.1255" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "685386cb3b2b2a988f325435c252f9ebbbbdc8c2" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
