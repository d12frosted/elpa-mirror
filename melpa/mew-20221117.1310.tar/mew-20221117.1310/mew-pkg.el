(define-package "mew" "20221117.1310" "Messaging in the Emacs World" 'nil :commit "7e4dd83a1896f44e1b6c820263c850e3b33eec50" :authors
  '(("Kazu Yamamoto" . "Kazu@Mew.org"))
  :maintainer
  '("Kazu Yamamoto" . "Kazu@Mew.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
