;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260906.955"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "832d885eaee344b6f939e149cbb1c644058370ab"
  :revdesc "832d885eaee3"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
