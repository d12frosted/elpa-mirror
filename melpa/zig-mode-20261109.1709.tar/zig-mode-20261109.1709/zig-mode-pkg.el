;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-mode" "20261109.1709"
  "A major mode for the Zig programming language."
  '((emacs       "26.1")
    (reformatter "0.6"))
  :url "https://codeberg.org/ziglang/zig-mode"
  :commit "16592be806dc87911efec57be9c840c96298a1a0"
  :revdesc "16592be806dc"
  :keywords '("zig" "languages")
  :authors '(("Andrea Orru" . "andreaorru1991@gmail.com")
             ("Andrew Kelley" . "superjoe30@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
