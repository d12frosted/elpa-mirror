(define-package "stimmung-themes" "20220326.1241" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "659d5814c5f9b21b159778ffab30aa9d8fb2cb96" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
