(define-package "dirvish" "20220114.1440" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "d663f40766f243382be7a584e368878fcfbff35b" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
