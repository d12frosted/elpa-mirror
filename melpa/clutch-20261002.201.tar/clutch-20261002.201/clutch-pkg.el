;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261002.201"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "b4a80a2be46f4f03d1e7de2fbe3f9a1c8330e745"
  :revdesc "b4a80a2be46f"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
