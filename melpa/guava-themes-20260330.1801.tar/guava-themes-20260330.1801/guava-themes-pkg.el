;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260330.1801"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "00002429293601c169d11352bfdf56c93860cce2"
  :revdesc "000024292936"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
