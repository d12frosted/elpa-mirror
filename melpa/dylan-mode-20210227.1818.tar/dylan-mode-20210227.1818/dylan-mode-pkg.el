(define-package "dylan-mode" "20210227.1818" "Major mode for the Dylan programming language. http://opendylan.org" 'nil :commit "fe965628177b0ee0bced7aa4fa42b6f5519c2d0e" :authors
  '(("Robert Stockton" . "rgs@cs.cmu.edu"))
  :maintainer
  '("Chris Page" . "cpage@opendylan.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
