;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20260828.607"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "a2a89494fd2e53111a81227d2e35290e0825c3fb"
  :revdesc "a2a89494fd2e"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
