(define-package "spdx" "20210227.1343" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "697e07e31adb82b9f14e8da67682bd1c0a14c7f6" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
