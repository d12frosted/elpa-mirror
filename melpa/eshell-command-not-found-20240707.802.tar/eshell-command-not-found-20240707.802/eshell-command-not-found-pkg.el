(define-package "eshell-command-not-found" "20240707.802" "Integrate command-not-found in eshell"
  '((emacs "25.1"))
  :commit "9626730aadb5dad7174ab0759355f379c7e41d37" :authors
  '(("Jaehyun Yeom" . "jae.yeom@gmail.com"))
  :maintainers
  '(("Jaehyun Yeom" . "jae.yeom@gmail.com"))
  :maintainer
  '("Jaehyun Yeom" . "jae.yeom@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/jaeyeom/eshell-command-not-found")
;; Local Variables:
;; no-byte-compile: t
;; End:
