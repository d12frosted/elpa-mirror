(define-package "cape" "20220714.1350" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "c36d7405db24e15d1ad019b549b0fc5a2944f66c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
