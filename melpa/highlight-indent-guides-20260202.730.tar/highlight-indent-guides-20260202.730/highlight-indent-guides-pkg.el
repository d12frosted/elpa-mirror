;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-indent-guides" "20260202.730"
  "Minor mode to highlight indentation."
  '((emacs "26.1"))
  :url "https://github.com/DarthFennec/highlight-indent-guides"
  :commit "b27669babba38985f3d4851fc697625bda6bbac1"
  :revdesc "b27669babba3"
  :keywords '("convenience")
  :authors '(("DarthFennec" . "darthfennec@derpymail.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
