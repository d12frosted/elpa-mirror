;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250313.359"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "99c31acdb31af30b946936fb690d95dda48bd5f5"
  :revdesc "99c31acdb31a"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
