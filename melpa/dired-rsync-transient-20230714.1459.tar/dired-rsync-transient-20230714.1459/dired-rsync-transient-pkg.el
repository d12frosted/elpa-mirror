;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rsync-transient" "20230714.1459"
  "Transient command for dired-rsync."
  '((dired-rsync "0.6")
    (transient   "0.3.0")
    (emacs       "24.4"))
  :url "https://github.com/stsquad/dired-rsync"
  :commit "95607fc7eb84e792122b52d2b1d62f49199a2a37"
  :revdesc "95607fc7eb84"
  :authors '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers '(("Alex Bennée" . "alex@bennee.com")))
