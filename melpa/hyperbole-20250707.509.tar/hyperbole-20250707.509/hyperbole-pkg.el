;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250707.509"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "0adae2bbea101423fe555377dd33214f0b5adc74"
  :revdesc "0adae2bbea10"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
