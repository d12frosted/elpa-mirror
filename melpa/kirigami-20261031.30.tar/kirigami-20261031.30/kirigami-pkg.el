;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20261031.30"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "961befbfa592eca7a41880e7961d0d1d4db5cb67"
  :revdesc "961befbfa592"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
