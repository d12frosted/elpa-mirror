(define-package "gruvbox-theme" "20230506.432" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "3d5e0a0b1e007f7faf1bc8414575262057d52dd8" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
