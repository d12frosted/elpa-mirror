;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-kondor" "20211026.501"
  "Linter with clj-kondo."
  '((emacs "26.1"))
  :url "https://github.com/turbo-cafe/flymake-kondor"
  :commit "784e57f36812a37e323409b90b935ef3c6920a22"
  :revdesc "784e57f36812")
