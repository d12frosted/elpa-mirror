;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-codemod" "20190921.941"
  "Run js-codemod on current sentence or selected region."
  '((emacs "24.4"))
  :url "https://github.com/torgeir/js-codemod.el"
  :commit "056bdf3e5e0c807b8cf17edb5834179a90fb722b"
  :revdesc "056bdf3e5e0c"
  :keywords '("js" "codemod" "region")
  :authors '(("Torgeir Thoresen" . "@torgeir"))
  :maintainers '(("Torgeir Thoresen" . "@torgeir")))
