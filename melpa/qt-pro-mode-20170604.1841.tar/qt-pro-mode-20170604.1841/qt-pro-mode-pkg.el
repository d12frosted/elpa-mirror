;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qt-pro-mode" "20170604.1841"
  "Qt Pro/Pri major mode."
  '((emacs "24"))
  :url "https://github.com/emacsorphanage/qt-pro-mode"
  :commit "1e0052fcfb89c15cb47714c1546d4e8ec6e01ae6"
  :revdesc "1e0052fcfb89"
  :keywords '("extensions")
  :authors '(("Todd Neal" . "tolchz@gmail.com"))
  :maintainers '(("Todd Neal" . "tolchz@gmail.com")))
