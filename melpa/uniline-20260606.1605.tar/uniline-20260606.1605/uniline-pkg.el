;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260606.1605"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "c749b07f1e5804eefe20e20cf23fb71cce5f8931"
  :revdesc "c749b07f1e58"
  :keywords '("convenience" "text"))
