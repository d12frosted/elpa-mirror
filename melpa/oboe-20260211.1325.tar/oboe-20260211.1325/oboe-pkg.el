;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260211.1325"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "00666c5d0a0a9c8f4a5db90d20042672f3a3ef09"
  :revdesc "00666c5d0a0a"
  :keywords '("convenience"))
