(define-package "lister" "20230204.1357" "Yet another list printer"
  '((emacs "26.1"))
  :commit "b256c254f670ebaf50134655fbe430025fff41ab" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainers
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
