;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bibtexkey" "20140214.1504"
  "Bibtexkey source for helm."
  '((helm "1.5.8"))
  :url "https://github.com/kenbeese/helm-bibtexkey"
  :commit "aa1637ea5c8c5f1817e480fc2a3750cafab3d99f"
  :revdesc "aa1637ea5c8c"
  :keywords '("bib" "tex")
  :authors '(("TAKAGI Kentaro" . "kentaro0910_at_gmail.com"))
  :maintainers '(("TAKAGI Kentaro" . "kentaro0910_at_gmail.com")))
