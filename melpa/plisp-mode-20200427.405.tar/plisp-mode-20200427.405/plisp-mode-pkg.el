(define-package "plisp-mode" "20200427.405" "Major mode for PicoLisp programming." 'nil :commit "59e682d77569b04e9fc80af9c4b05e4a997dbcec" :authors
  '(("Alexis" . "flexibeast@gmail.com"))
  :maintainer
  '("Alexis" . "flexibeast@gmail.com")
  :keywords
  '("picolisp" "lisp" "programming")
  :url "https://github.com/flexibeast/plisp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
