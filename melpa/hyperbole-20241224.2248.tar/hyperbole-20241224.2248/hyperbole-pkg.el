;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241224.2248"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "4f8fa6f04d4e2e4787103979f3569b22a89cb9a2"
  :revdesc "4f8fa6f04d4e"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
