;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260402.752"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "c3d5d7f758b8fbb071abbd18d599d1eacb0f2fbd"
  :revdesc "c3d5d7f758b8"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
