;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20261031.1757"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "1c63993071f399b93540991c6c3ac0867efa87df"
  :revdesc "1c63993071f3"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
