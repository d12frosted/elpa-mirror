;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250522.2335"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "5a3e86d8d2688f984595b27e7809a4ac272ab1a5"
  :revdesc "5a3e86d8d268"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
