;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260829.1143"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "7fb35a92bb92a05b46fc363136437ffaedf3c7cb"
  :revdesc "7fb35a92bb92"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
