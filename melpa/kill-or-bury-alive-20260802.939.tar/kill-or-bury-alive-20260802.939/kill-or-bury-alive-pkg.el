;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-or-bury-alive" "20260802.939"
  "Precise control over buffer killing."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/kill-or-bury-alive"
  :commit "0d69edb0148246b239d2c720ed8077cb4e797033"
  :revdesc "0d69edb01482"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
