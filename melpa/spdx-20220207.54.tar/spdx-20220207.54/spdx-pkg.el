(define-package "spdx" "20220207.54" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "cc331a92f5e81613796110a529b3f9fb511dda87" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
