;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "su" "20240320.1707"
  "Automatically read and write files using su or sudo."
  '((emacs "26.1"))
  :url "https://github.com/PythonNut/su.el"
  :commit "e097f31b3bbb8581d045d0e684d3f129f90e8085"
  :revdesc "e097f31b3bbb"
  :keywords '("convenience" "helm" "fuzzy" "flx")
  :authors '(("PythonNut" . "pythonnut@pythonnut.com"))
  :maintainers '(("PythonNut" . "pythonnut@pythonnut.com")))
