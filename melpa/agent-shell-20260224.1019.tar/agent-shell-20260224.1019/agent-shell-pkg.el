;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260224.1019"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6a33d6a2eae163a5dbd5ec47245f129fe2cd4139"
  :revdesc "6a33d6a2eae1")
