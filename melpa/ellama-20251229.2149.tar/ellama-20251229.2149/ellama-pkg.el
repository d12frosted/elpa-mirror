;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20251229.2149"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "7bd7aa46544e316f90f545a098caafbc80f65520"
  :revdesc "7bd7aa46544e"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
