(define-package "citre" "20210805.1541" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "a7e176fe6883748c6d989f33967bee14a63ea7d5" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
