(define-package "citre" "20210805.1541" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "544d72d388f92763ce55f8c29882df11959c80f6" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
