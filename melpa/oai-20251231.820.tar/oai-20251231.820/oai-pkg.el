;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20251231.820"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "ef5f87da595508d4ea6f7a78b0858c183f6b7f45"
  :revdesc "ef5f87da5955"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
