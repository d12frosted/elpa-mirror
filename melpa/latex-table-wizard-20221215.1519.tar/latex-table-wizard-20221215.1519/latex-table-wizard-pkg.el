(define-package "latex-table-wizard" "20221215.1519" "Magic editing of LaTeX tables"
  '((emacs "27.1")
    (auctex "12.1")
    (transient "0.3.7"))
  :commit "7568cbbe112db8e61e38d69308f9e51610734bf6" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :keywords
  '("convenience")
  :url "https://github.com/enricoflor/latex-table-wizard")
;; Local Variables:
;; no-byte-compile: t
;; End:
