;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-quick-sort" "20260308.2151"
  "Persistent quick sorting of Dired buffers in various ways."
  '((emacs "28"))
  :url "https://gitlab.com/xuhdev/dired-quick-sort"
  :commit "7f01a60997b5fa8c5d572dece9c5db16b1438b9b"
  :revdesc "7f01a60997b5"
  :keywords '("convenience" "files")
  :authors '(("Hong Xu" . "hong@topbug.net"))
  :maintainers '(("Hong Xu" . "hong@topbug.net")))
