;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "green-is-the-new-black-theme" "20230828.2225"
  "A cool and minimalist green blackened theme engine."
  ()
  :url "https://github.com/fredcamps/green-is-the-new-black-emacs"
  :commit "ad6f349e7e3a626f790af994424d3f015ac0d3ee"
  :revdesc "ad6f349e7e3a"
  :keywords '("faces" "themes")
  :authors '(("Fred Campos" . "fred.tecnologia@gmail.com"))
  :maintainers '(("Fred Campos" . "fred.tecnologia@gmail.com")))
