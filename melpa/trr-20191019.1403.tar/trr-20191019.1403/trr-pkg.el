;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trr" "20191019.1403"
  "A type-writing training program on GNU Emacs."
  ()
  :url "https://github.com/kawabata/emacs-trr"
  :commit "f841173e11213ac6916b2d3394b28fb202543871"
  :revdesc "f841173e1121"
  :keywords '("games" "faces")
  :authors '(("YAMAMOTO Hirotaka" . "ymmt@is.s.u-tokyo.ac.jp")
             ("KATO Kenji" . "kato@suri.co.jp")
             ("INAMURA You" . "inamura@icot.or.jp"))
  :maintainers '(("YAMAMOTO Hirotaka" . "ymmt@is.s.u-tokyo.ac.jp")
                 ("KATO Kenji" . "kato@suri.co.jp")
                 ("INAMURA You" . "inamura@icot.or.jp")))
