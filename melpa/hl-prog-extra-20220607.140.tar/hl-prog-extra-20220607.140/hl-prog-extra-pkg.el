(define-package "hl-prog-extra" "20220607.140" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "e7e24735cd020746e4070c908a6ebd2515c4c19b" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
