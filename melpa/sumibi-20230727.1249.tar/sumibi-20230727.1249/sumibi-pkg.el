(define-package "sumibi" "20230727.1249" "Japanese input method powered by ChatGPT API"
  '((emacs "28.1")
    (popup "0.5.9")
    (unicode-escape "1.1")
    (deferred "0.5.1"))
  :commit "d934aee4d6a2493e40db3d848d459d97c8e2e229" :authors
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainer
  '("Kiyoka Nishiyama" . "kiyoka@sumibi.org")
  :keywords
  '("lisp" "ime" "japanese")
  :url "https://github.com/kiyoka/Sumibi")
;; Local Variables:
;; no-byte-compile: t
;; End:
