(define-package "racket-mode" "20220404.257" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "819ac6778712022d1e75c8f21422c862e4f85e3e" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
