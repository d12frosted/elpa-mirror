;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260403.2340"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "e830171c4bcbcbc0b1d466ffdbec179e32e9688e"
  :revdesc "e830171c4bcb"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
