;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-syntax" "20231119.1633"
  "Provides syntax text objects."
  '((emacs "24")
    (evil  "0"))
  :url "https://github.com/laishulu/evil-textobj-syntax"
  :commit "64252ded690a2e65b71a1c84aa3acd24e704d02f"
  :revdesc "64252ded690a"
  :keywords '("evil" "syntax" "highlight" "text-object"))
