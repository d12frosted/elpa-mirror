(define-package "latex-change-env" "20230220.637" "Change in and out of LaTeX environments"
  '((emacs "27.1")
    (auctex "13.1"))
  :commit "748cdbb4bbf29a2e5053cf3d965e95cc7db67fac" :authors
  '(("Tony Zorman" . "soliditsallgood@mailbox.org"))
  :maintainers
  '(("Tony Zorman" . "soliditsallgood@mailbox.org"))
  :maintainer
  '("Tony Zorman" . "soliditsallgood@mailbox.org")
  :keywords
  '("convenience" "tex")
  :url "https://gitlab.com/slotThe/change-env")
;; Local Variables:
;; no-byte-compile: t
;; End:
