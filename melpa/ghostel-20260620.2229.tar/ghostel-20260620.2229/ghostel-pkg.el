;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260620.2229"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "d8fde4241e15c094ee3c6453a76d4dbbc87abd1a"
  :revdesc "d8fde4241e15"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
