;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-scratch" "20210706.459"
  "A scratch buffer to interactively evaluate php code."
  '((emacs    "24.3")
    (s        "1.11.0")
    (php-mode "1.17.0"))
  :url "https://github.com/mallt/php-scratch"
  :commit "b6bfd279da8a8ac7fc30459485956f3fd5d02573"
  :revdesc "b6bfd279da8a"
  :authors '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com"))
  :maintainers '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com")))
