;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261128.1512"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "d324c9c8b3585450e6c0b0a4e5fa5f2075765bc8"
  :revdesc "d324c9c8b358"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
