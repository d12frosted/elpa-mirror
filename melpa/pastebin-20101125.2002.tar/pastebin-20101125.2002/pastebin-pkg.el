;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pastebin" "20101125.2002"
  "A simple interface to the www.pastebin.com webservice."
  ()
  :url "https://github.com/nicferrier/elpastebin"
  :commit "8e9a829298ce0f747ab80758aa26caeb2af6cb30"
  :revdesc "8e9a829298ce")
