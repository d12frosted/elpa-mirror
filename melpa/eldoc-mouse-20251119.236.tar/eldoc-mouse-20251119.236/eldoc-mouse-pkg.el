;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20251119.236"
  "Display documentation for mouse hover."
  '((emacs    "30.1")
    (posframe "1.4.0")
    (eglot    "1.8"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "2c2efc5c886d3c74e418dd01f0c945045559583c"
  :revdesc "2c2efc5c886d"
  :keywords '("tools" "languages" "convenience" "emacs" "mouse" "hover")
  :authors '((nil . "HuangFeiyusibadake1@163.com"))
  :maintainers '((nil . "HuangFeiyusibadake1@163.com")))
