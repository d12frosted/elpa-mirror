;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260214.1416"
  "Manage and navigate projects in Emacs easily."
  '((emacs "26.1"))
  :url "https://github.com/bbatsov/projectile"
  :commit "81fd74f17e7e2a6082c905947a603f76f04ff730"
  :revdesc "81fd74f17e7e"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
