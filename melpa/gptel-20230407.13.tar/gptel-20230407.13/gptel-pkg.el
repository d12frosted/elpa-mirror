(define-package "gptel" "20230407.13" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "936c27e28b4734293fd1bd259b040698ba68ab93" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
