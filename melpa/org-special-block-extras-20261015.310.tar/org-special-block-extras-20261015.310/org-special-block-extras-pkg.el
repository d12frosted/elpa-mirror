;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20261015.310"
  "30 new custom blocks & 34 link types for Org-mode."
  '((s     "1.13.1")
    (dash  "2.18.1")
    (emacs "27.1")
    (org   "9.6")
    (lf    "26.10.1")
    (seq   "2.0"))
  :url "https://alhassy.github.io/org-special-block-extras"
  :commit "4ffb3bcad92ca6d1ae3873f0524f2fa8f91a0055"
  :revdesc "4ffb3bcad92c"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
