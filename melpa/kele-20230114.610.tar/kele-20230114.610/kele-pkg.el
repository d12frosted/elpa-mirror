(define-package "kele" "20230114.610" "Interface with Kubernetes"
  '((emacs "27.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (plz "0.3")
    (request "0.3.2")
    (yaml "0.5.1"))
  :commit "41466e9374e3b50d63eb9f47ab0e20d2aeae4ad9" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
