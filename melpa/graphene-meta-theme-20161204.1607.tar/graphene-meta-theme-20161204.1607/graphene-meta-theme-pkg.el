(define-package "graphene-meta-theme" "20161204.1607" "Integrated theming for common packages" 'nil :commit "62cc73fee31f1bd9474027b83a249feee050271e" :authors
  '(("Robert Dallas Gray" . "mail@robertdallasgray.com"))
  :maintainers
  '(("Robert Dallas Gray" . "mail@robertdallasgray.com"))
  :maintainer
  '("Robert Dallas Gray" . "mail@robertdallasgray.com")
  :keywords
  '("defaults")
  :url "https://github.com/rdallasgray/graphene")
;; Local Variables:
;; no-byte-compile: t
;; End:
