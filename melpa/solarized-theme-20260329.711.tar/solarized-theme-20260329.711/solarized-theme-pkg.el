;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "20260329.711"
  "The Solarized color theme."
  '((emacs "24.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "326cda27d8e43f093990670899e2772e6ade5a23"
  :revdesc "326cda27d8e4"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
