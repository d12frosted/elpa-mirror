(define-package "frimacs" "20220528.1935" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "c33b4d37751d31cf901e933f58779ab606ccb6fb" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
