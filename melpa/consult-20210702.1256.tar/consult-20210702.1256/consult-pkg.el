(define-package "consult" "20210702.1256" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9e5db5571738113728887c565af5f0cab2dbf6e1" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
