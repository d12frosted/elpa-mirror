;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "20260609.428"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "c960db25a2a9813b1c40c9f21cfa62f30da9fd2d"
  :revdesc "c960db25a2a9")
