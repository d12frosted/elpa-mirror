(define-package "tao-theme" "20230311.44" "This package provides two parametrized uncoloured color themes for Emacs: tao-yin and tao-yang." 'nil :commit "14efde1bc97e32dca04e59ca13d8d4ca745e58ce" :authors
  '(("Peter Kosov" . "11111000000@email.com"))
  :maintainer
  '("Peter Kosov" . "11111000000@email.com")
  :url "http://github.com/11111000000/tao-theme-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
