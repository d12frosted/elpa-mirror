(define-package "eldoc-box" "20230610.700" "Display documentation in childframe"
  '((emacs "27.1"))
  :commit "049eacfd9808c446d93891b4d3332f5d62c0c053" :authors
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainer
  '("Yuan Fu" . "casouri@gmail.com")
  :url "https://github.com/casouri/eldoc-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
