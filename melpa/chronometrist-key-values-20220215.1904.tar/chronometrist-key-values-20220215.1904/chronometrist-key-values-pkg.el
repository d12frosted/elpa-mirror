(define-package "chronometrist-key-values" "20220215.1904" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "c51f4a45609b99d694de6cfad0d99d854b8e4af4" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
