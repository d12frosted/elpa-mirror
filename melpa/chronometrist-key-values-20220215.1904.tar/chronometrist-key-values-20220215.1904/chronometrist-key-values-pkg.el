(define-package "chronometrist-key-values" "20220215.1904" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "e6df8138eef45cf149cdb8b4d77e8ef289f7aaa7" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
