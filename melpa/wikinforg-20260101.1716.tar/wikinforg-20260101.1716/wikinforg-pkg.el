;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wikinforg" "20260101.1716"
  "Org-mode wikinfo integration."
  '((emacs   "27.1")
    (wikinfo "0.0.0")
    (org     "9.3"))
  :url "https://github.com/progfolio/wikinforg"
  :commit "9f1b72c2f2e5648f9b736470e350750b8726884c"
  :revdesc "9f1b72c2f2e5"
  :keywords '("org" "convenience")
  :authors '(("Nicholas Vollmer" . "progfolio@protonmail.com"))
  :maintainers '(("Nicholas Vollmer" . "progfolio@protonmail.com")))
