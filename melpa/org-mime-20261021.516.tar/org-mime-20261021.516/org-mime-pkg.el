;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mime" "20261021.516"
  "Org html export for text/html MIME emails."
  '((emacs "29.1"))
  :url "https://github.com/org-mime/org-mime"
  :commit "1073e4fbed1afa99e4c1aad6940b90dcf198df64"
  :revdesc "1073e4fbed1a"
  :keywords '("mime" "mail" "email" "html")
  :maintainers '(("Chen Bin" . "chb_shAThotmailDOTcom")))
