;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "20260112.1052"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "08ecc2363f99bb312c6002b24810baa484b8cae8"
  :revdesc "08ecc2363f99"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
