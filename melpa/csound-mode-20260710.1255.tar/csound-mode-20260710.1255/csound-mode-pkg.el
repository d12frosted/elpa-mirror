;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csound-mode" "20260710.1255"
  "A major mode for interacting and coding Csound."
  '((emacs "27.1"))
  :url "https://github.com/hlolli/csound-mode"
  :commit "411e31bb6ca8a4033322c11d2d838c6e8d9f02af"
  :revdesc "411e31bb6ca8"
  :authors '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers '(("Hlöðver Sigurðsson" . "hlolli@gmail.com")))
