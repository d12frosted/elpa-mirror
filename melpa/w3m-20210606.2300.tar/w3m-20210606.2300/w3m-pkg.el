(define-package "w3m" "20210606.2300" "an Emacs interface to w3m" 'nil :commit "6b39d60f1f5fc1276f47b10e90f146096a6cab41" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
