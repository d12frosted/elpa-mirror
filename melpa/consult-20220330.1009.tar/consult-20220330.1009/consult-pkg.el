(define-package "consult" "20220330.1009" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "473e6585c516d0e7fd4c256c333713fb40e9947a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
