;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250614.756"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "84f5d0eaf0986d6e61f724c9ac5a0b88758f24ba"
  :revdesc "84f5d0eaf098"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
