;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tt-mode" "20260403.913"
  "Emacs major mode for editing Template Toolkit files."
  ()
  :url "https://github.com/davorg/tt-mode"
  :commit "7322b52de06d9e786fbb66414775d2103efef562"
  :revdesc "7322b52de06d"
  :authors '(("Dave Cross" . "dave@dave.org.uk"))
  :maintainers '(("Dave Cross" . "dave@dave.org.uk")))
