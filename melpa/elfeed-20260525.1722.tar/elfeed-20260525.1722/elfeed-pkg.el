;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260525.1722"
  "An Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "e5c6eb583c97a772357a5e7a4cad3c391f4c6574"
  :revdesc "e5c6eb583c97"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
