(define-package "bluesound" "20230328.1430" "Play, pause, resume music on a Bluesound player"
  '((emacs "26.1"))
  :commit "f6a43dbe8b5a3d4541170717571c793ae3313c98" :authors
  '(("R.W. van 't Veer"))
  :maintainers
  '(("R.W. van 't Veer"))
  :maintainer
  '("R.W. van 't Veer")
  :keywords
  '("convenience" "multimedia")
  :url "https://git.sr.ht/~rwv/bluesound-el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
