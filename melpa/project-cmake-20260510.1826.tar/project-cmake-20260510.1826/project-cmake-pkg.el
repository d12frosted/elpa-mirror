;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-cmake" "20260510.1826"
  "A cmake backend for project.el."
  '((emacs "30.1"))
  :url "https://github.com/lucius-martius/project-cmake"
  :commit "e418c5bc2b10fd67eb2d374585fef0af07e8c5c1"
  :revdesc "e418c5bc2b10"
  :keywords '("tools" "convenience")
  :authors '(("Lucius Martius" . "lucius.martius@mailbox.org"))
  :maintainers '(("Lucius Martius" . "lucius.martius@mailbox.org")))
