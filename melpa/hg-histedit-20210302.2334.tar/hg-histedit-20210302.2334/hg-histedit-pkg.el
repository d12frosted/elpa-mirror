;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hg-histedit" "20210302.2334"
  "Edit HG histedit files."
  '((emacs       "25.1")
    (with-editor "2.8.3"))
  :url "https://github.com/jojojames/hg-histedit"
  :commit "a05149483b9c5f7848ece0ba6028c900595a6a25"
  :revdesc "a05149483b9c"
  :keywords '("mercurial" "hg" "emacs" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
