;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261002.1625"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "f3af60a6dcfdababa74232b3b58fd44c511cfc4a"
  :revdesc "f3af60a6dcfd"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
