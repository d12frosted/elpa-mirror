;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250530.2231"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "0623dee9a1de4ad56fb3372fbc49d48b9ea92c0a"
  :revdesc "0623dee9a1de"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
