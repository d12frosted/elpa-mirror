;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260414.223"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "0385a84a75d9ce239e8db47fbc32cb0f5a56b4a2"
  :revdesc "0385a84a75d9"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
