;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ext" "20200722.107"
  "A few extensions to Helm."
  '((emacs "24.4")
    (helm  "2.5.3"))
  :url "https://github.com/cute-jumper/helm-ext"
  :commit "c30f7772ec577a5ce1de3215f0507826e0725a69"
  :revdesc "c30f7772ec57"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
