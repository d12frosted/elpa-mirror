(define-package "epkg" "20210907.1806" "browse the Emacsmirror package database"
  '((closql "1.0.6")
    (emacs "25.1"))
  :commit "cb12a3fed77d574e5c30eafd4f950dae02022b67" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
