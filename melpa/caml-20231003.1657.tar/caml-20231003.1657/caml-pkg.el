(define-package "caml" "20231003.1657" "Caml mode for GNU Emacs"
  '((emacs "24.4"))
  :commit "9fda737890e91e2eddca6b43b6582d35d27a4d0b" :authors
  '(("Jacques Garrigue" . "garrigue@kurims.kyoto-u.ac.jp")
    ("Ian T Zimmerman" . "itz@rahul.net")
    ("Damien Doligez" . "damien.doligez@inria.fr"))
  :maintainers
  '(("Christophe Troestler" . "Christophe.Troestler@umons.ac.be"))
  :maintainer
  '("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
  :keywords
  '("ocaml")
  :url "https://github.com/ocaml/caml-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
