(define-package "pdf-tools" "20210529.714" "Support library for PDF documents"
  '((emacs "24.3")
    (tablist "1.0")
    (let-alist "1.0.4"))
  :commit "f771c93781b3135200cae6dbc8e45dbb887f77b1" :authors
  '(("Andreas Politz" . "politza@fh-trier.de"))
  :maintainer
  '("Andreas Politz" . "politza@fh-trier.de")
  :keywords
  '("files" "multimedia")
  :url "http://github.com/vedang/pdf-tools/")
;; Local Variables:
;; no-byte-compile: t
;; End:
