(define-package "ebib" "20201223.2217" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "f4a36bd7629dd67ec5fdfdf4ea4d087d8e8c986d" :authors
  (("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  ("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  ("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
