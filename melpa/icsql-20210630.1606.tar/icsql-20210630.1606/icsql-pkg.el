(define-package "icsql" "20210630.1606" "Interactive iSQL iteraface to ciSQL"
  '((emacs "26")
    (choice-program "0.13")
    (buffer-manage "0.12"))
  :commit "4521e9d2debef7687bfd26a664479f0c46688a36" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("isql" "sql" "rdbms" "data")
  :url "https://github.com/plandes/icsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
