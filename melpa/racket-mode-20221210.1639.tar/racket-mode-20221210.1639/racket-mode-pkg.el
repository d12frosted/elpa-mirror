(define-package "racket-mode" "20221210.1639" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "9905d8d0e87747749566d98068ce9b2996305fc1" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
