;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250624.506"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "bbbdec8e3066d33556454ce4c19856b13764b7e0"
  :revdesc "bbbdec8e3066"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
