;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260312.1252"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "1df11e2502487a430d8ccdd151150d37703b3ed9"
  :revdesc "1df11e250248"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
