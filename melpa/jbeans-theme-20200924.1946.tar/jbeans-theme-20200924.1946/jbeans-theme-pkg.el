;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jbeans-theme" "20200924.1946"
  "Jbeans theme for GNU Emacs 24 (deftheme)."
  '((emacs "24"))
  :url "https://github.com/synic/jbeans-emacs"
  :commit "a63916a928324c42bfbe3016972c2ecff598b1ae"
  :revdesc "a63916a92832"
  :authors '(("Adam Olsen" . "arolsen@gmail.com"))
  :maintainers '(("Adam Olsen" . "arolsen@gmail.com")))
