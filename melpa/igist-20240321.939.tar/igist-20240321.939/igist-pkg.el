(define-package "igist" "20240321.939" "List, create, update and delete GitHub gists"
  '((emacs "27.1")
    (ghub "3.6.0")
    (transient "0.4.1"))
  :commit "70746d322204b12ae9319d7c2d2ad0f4ccda7ffa" :authors
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainer
  '("Karim Aziiev" . "karim.aziiev@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/KarimAziev/igist")
;; Local Variables:
;; no-byte-compile: t
;; End:
