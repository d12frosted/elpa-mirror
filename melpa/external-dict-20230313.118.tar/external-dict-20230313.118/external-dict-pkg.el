(define-package "external-dict" "20230313.118" "Query external dictionary like goldendict, Bob.app etc"
  '((emacs "25.1"))
  :commit "7ef87709c09792dfa6332fb41a6ec1edd917120a" :keywords
  '("wp" "processes")
  :url "https://repo.or.cz/external-dict.el.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
