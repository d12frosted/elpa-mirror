;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyde" "20160508.308"
  "Major mode to help create and manage Jekyll blogs."
  ()
  :url "https://github.com/nibrahim/Hyde"
  :commit "a8cd6ed00ecd8d7de0ded2f4867015b412b15b76"
  :revdesc "a8cd6ed00ecd")
