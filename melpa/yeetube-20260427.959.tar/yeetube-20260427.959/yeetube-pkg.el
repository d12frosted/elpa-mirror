;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260427.959"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.1.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "97699a748a9272d3f82c1fd5998ffc02999183fa"
  :revdesc "97699a748a92"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
