(define-package "zk-luhmann" "20231008.2014" "Support for Luhmann-style IDs in zk"
  '((emacs "25.1")
    (zk "0.4")
    (zk-index "0.9"))
  :commit "c52411f079bbd8597bb7b9aa92906c17dffbdb82" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/zk-luhmann")
;; Local Variables:
;; no-byte-compile: t
;; End:
