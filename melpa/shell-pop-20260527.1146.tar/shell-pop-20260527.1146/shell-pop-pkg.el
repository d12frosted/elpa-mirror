;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260527.1146"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "866f18caaf3e6df12e3af3a8ac8f64116017bfc4"
  :revdesc "866f18caaf3e"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
