(define-package "dashboard" "20210714.305" "A startup screen extracted from Spacemacs"
  '((emacs "25.3"))
  :commit "09932ef488b47c6b645a081fee4a82be437f98d8" :authors
  '(("Rakan Al-Hneiti"))
  :maintainer
  '("Rakan Al-Hneiti")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
