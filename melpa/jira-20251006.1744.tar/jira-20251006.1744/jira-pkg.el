;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20251006.1744"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "865e97d9085be8fbb86e2c4ae749c72d8b79178e"
  :revdesc "865e97d9085b"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
