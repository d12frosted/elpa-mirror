(define-package "ledger-import" "20210419.818" "Fetch OFX files from bank and push them to Ledger"
  '((emacs "25.1")
    (ledger-mode "3.1.1"))
  :commit "f77adf79ce67524c3e08546448ac88ea1a665b64" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://gitlab.petton.fr/mpdel/libmpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
