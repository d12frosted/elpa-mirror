;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "20261118.934"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.64.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "4af9560818534dd97902f045acd0f9e44fb14525"
  :revdesc "4af956081853"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
