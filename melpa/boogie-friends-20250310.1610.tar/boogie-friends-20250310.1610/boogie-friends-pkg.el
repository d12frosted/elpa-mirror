;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boogie-friends" "20250310.1610"
  "A collection of programming modes for Boogie, Dafny, and Z3 (SMTLIB v2)."
  '((cl-lib    "0.5")
    (dash      "2.10.0")
    (flycheck  "0.23")
    (yasnippet "0.9.0.1")
    (company   "0.8.12"))
  :url "https://github.com/boogie-org/boogie-friends/"
  :commit "54905dab2944e7e808aa9445727646d7a3855174"
  :revdesc "54905dab2944"
  :keywords '("convenience" "languages")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
