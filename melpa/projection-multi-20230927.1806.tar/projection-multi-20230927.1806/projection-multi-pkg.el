(define-package "projection-multi" "20230927.1806" "Projection integration for `compile-multi'"
  '((emacs "29.1")
    (projection "0.1")
    (compile-multi "0.5"))
  :commit "44760f2999c3ec3ac5693ff2968b3a65a3bcaa75" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
