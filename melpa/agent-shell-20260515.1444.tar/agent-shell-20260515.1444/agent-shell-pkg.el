;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260515.1444"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "46623144c75b97163c26be5549b9e0c4bc3052d4"
  :revdesc "46623144c75b")
