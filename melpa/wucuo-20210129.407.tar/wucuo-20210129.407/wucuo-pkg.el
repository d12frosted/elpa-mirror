(define-package "wucuo" "20210129.407" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "4f1a63bf990c06942c5c290d5d146f8545f43b95" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
