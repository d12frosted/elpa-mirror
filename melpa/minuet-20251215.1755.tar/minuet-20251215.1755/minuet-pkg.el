;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20251215.1755"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "7b34bf0f0334478dab15ce185eacc794a6c7415f"
  :revdesc "7b34bf0f0334"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
