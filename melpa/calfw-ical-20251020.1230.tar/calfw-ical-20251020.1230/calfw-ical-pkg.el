;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-ical" "20251020.1230"
  "Calendar view for ical format."
  '((emacs "28.1")
    (calfw "2.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "e555b84dab3880a04436bcebd98f8601a6214e6e"
  :revdesc "e555b84dab38"
  :keywords '("calendar" "ical")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
