;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-notes" "20251113.1447"
  "Manage notes with consult."
  '((emacs   "27.1")
    (consult "0.17")
    (s       "1.12.0")
    (dash    "2.19"))
  :url "https://github.com/mclear-tools/consult-notes"
  :commit "406bee72d23044e8d900f8a863777ff82e16cc64"
  :revdesc "406bee72d230"
  :keywords '("convenience")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
