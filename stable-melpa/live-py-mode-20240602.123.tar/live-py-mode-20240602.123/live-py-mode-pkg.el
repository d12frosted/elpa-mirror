(define-package "live-py-mode" "20240602.123" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "ba9cfe705dade4aff3f0d1f5dda28f9ac8d32289" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainers
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
