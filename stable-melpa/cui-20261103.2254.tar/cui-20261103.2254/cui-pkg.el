;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261103.2254"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "20b5351f7b6d370430dec0644384835dff97e224"
  :revdesc "20b5351f7b6d"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
