(define-package "live-py-mode" "20220129.655" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "4b5b7c4f4ff73b72c7daf684cc534cca3e205881" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
