(define-package "stimmung-themes" "20210323.1434" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "c18908f12040e7dc27c968060b05fea128f495fd" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung")
;; Local Variables:
;; no-byte-compile: t
;; End:
