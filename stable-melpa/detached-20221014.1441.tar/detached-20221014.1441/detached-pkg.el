(define-package "detached" "20221014.1441" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "a0797535807f8d89f1c2c7d5269816e802257975" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
