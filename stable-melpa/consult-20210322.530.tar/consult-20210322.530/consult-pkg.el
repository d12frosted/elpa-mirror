(define-package "consult" "20210322.530" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "fa25d8feca2bdb12ccb500218a038f70c7f57fbe" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
