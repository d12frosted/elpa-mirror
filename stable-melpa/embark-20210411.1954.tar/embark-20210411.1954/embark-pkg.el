(define-package "embark" "20210411.1954" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "a005eef82a63950927a68a5ef79b33d25245687b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
