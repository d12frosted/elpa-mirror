;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "20260612.2325"
  "Minimal and elegant modeline."
  '((emacs "29.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "c132e1aa48ffb0bafd8731d7fe706a15cb57acbf"
  :revdesc "c132e1aa48ff"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
