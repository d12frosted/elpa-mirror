(define-package "modus-themes" "20201222.2234" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "fbf1e88178a63c4439ba2c2818999e067abcb52b" :keywords
  ("faces" "theme" "accessibility")
  :authors
  (("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  ("Protesilaos Stavrou" . "info@protesilaos.com")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
