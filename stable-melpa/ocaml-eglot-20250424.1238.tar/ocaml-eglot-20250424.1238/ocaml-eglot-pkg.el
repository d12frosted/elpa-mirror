;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocaml-eglot" "20250424.1238"
  "An OCaml companion for Eglot."
  '((emacs "29.1"))
  :url "https://github.com/tarides/ocaml-eglot"
  :commit "6ed253578b0e590a4eea7bf48ca3419330ed89a5"
  :revdesc "6ed253578b0e"
  :keywords '("ocaml" "languages")
  :authors '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com"))
  :maintainers '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com")))
