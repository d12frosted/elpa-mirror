;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260908.1917"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "d0654d137f68577449206ea99c53220f7c161c48"
  :revdesc "d0654d137f68"
  :keywords '("chinese" "isearch" "matching" "convenience")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
