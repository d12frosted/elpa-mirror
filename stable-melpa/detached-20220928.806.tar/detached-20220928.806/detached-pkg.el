(define-package "detached" "20220928.806" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "772ac746a9e8350f24ff548301ef13986e5b21d9" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
