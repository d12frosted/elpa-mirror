;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ansible-vault" "20251028.147"
  "Minor mode for editing ansible vault files."
  '((emacs "26.1"))
  :url "http://github.com/freehck/ansible-vault-mode"
  :commit "f1c93463a9a25b3341bd3c2301668c2a47d11456"
  :revdesc "f1c93463a9a2"
  :keywords '("ansible" "ansible-vault" "tools")
  :maintainers '(("Dmitrii Kashin" . "freehck@yandex.ru")))
