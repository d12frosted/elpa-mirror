(define-package "modus-themes" "20210523.2022" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "81de5153347f9c5262079313bf2b29601e06e8ab" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
