(define-package "embark" "20211013.119" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "010b7356af782a3723fcfbbfc943bc8082c54c27" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
