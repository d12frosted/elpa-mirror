(define-package "evil-test-helpers" "20220425.2132" "unit test helpers for Evil"
  '((evil "1.15.0"))
  :commit "008a6cdb12f15e748979a7d1c2f26c34c84dedbf" :authors
  '(("Vegard Øye <vegard_oye at hotmail.com>"))
  :maintainers
  '(("Vegard Øye <vegard_oye at hotmail.com>"))
  :maintainer
  '("Vegard Øye <vegard_oye at hotmail.com>"))
;; Local Variables:
;; no-byte-compile: t
;; End:
