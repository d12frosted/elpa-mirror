;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiktionary-bro" "20260927.222"
  "Lookup Wiktionary entries."
  '((emacs   "29.4")
    (request "0.3.3"))
  :url "https://github.com/agzam/wiktionary-bro.el"
  :commit "fca1963f43f4cde895513f0c03eca2cbc8196b20"
  :revdesc "fca1963f43f4"
  :keywords '("convenience" "multimedia")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
