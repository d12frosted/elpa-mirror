;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260105.38"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "9f7742b191ef240f733c058b440b56c2ffba738a"
  :revdesc "9f7742b191ef"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
