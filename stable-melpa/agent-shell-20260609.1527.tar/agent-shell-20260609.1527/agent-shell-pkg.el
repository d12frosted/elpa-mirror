;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260609.1527"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8850efdec24bfbc3b99fa758e55390bce73a8679"
  :revdesc "8850efdec24b")
