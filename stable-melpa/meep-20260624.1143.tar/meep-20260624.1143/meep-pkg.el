;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260624.1143"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "3f1ebf8ec5bdd0e3f11283472d252a195fa5485e"
  :revdesc "3f1ebf8ec5bd"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
