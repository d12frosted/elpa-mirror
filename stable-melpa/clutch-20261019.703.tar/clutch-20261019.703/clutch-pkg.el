;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261019.703"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "f5a4921bfa267d6f7c5215997d2fc2179481272d"
  :revdesc "f5a4921bfa26"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
