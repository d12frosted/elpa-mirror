;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keystore-mode" "20190409.1946"
  "A major mode for viewing and managing (java) keystores."
  '((emacs   "24.3")
    (origami "1.0")
    (s       "1.12.0")
    (seq     "2.20"))
  :url "https://github.com/peterpaul/keystore-mode"
  :commit "43bd5926348298d077c7221f37902c990df3f951"
  :revdesc "43bd59263482"
  :keywords '("tools")
  :authors '(("Peterpaul Taekele Klein Haneveld" . "pp.kleinhaneveld@gmail.com"))
  :maintainers '(("Peterpaul Taekele Klein Haneveld" . "pp.kleinhaneveld@gmail.com")))
