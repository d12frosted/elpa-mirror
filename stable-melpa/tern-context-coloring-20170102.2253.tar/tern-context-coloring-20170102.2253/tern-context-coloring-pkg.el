;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tern-context-coloring" "20170102.2253"
  "Use Tern for context coloring."
  '((emacs            "24.3")
    (context-coloring "8.1.0")
    (tern             "0.0.1"))
  :url "https://github.com/jacksonrayhamilton/tern-context-coloring"
  :commit "3a8e979d6cc83aabcb3dda3f5f31a6422532efba"
  :revdesc "3a8e979d6cc8"
  :keywords '("convenience" "faces" "tools")
  :authors '(("Jackson Ray Hamilton" . "jackson@jacksonrayhamilton.com"))
  :maintainers '(("Jackson Ray Hamilton" . "jackson@jacksonrayhamilton.com")))
