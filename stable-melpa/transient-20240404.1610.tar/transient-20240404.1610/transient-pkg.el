(define-package "transient" "20240404.1610" "Transient commands"
  '((emacs "26.1")
    (compat "29.1.4.4")
    (seq "2.24"))
  :commit "0c2928655ce75af86fede9adcb964d770c077090" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
