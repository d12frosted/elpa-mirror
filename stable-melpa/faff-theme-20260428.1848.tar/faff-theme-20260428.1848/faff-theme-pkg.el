;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20260428.1848"
  "Light cornsilk theme with warm, earthy colors."
  '((emacs        "28.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "f3aac0549f6e22021b5f65e12ad08bd6099147a3"
  :revdesc "f3aac0549f6e"
  :keywords '("faces" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
