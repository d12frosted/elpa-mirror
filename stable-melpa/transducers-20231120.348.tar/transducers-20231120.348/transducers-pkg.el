(define-package "transducers" "20231120.348" "Ergonomic, efficient data processing"
  '((emacs "28.1"))
  :commit "657c8074b0d98bb191434c9bf074cf039105ac3a" :authors
  '(("Colin Woodbury" . "colin@fosskers.ca"))
  :maintainers
  '(("Colin Woodbury" . "colin@fosskers.ca"))
  :maintainer
  '("Colin Woodbury" . "colin@fosskers.ca")
  :keywords
  '("lisp")
  :url "https://git.sr.ht/~fosskers/transducers.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
