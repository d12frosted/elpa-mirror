;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20250604.1813"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/casual"
  :commit "be93172baa02c9a93f2726875c2b1fa85554a7cd"
  :revdesc "be93172baa02"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
