(define-package "simple-indentation" "20221125.1839" "Simplify writing indentation functions, alternative to SMIE"
  '((emacs "24.3")
    (dash "2.18.0")
    (s "1.12.0"))
  :commit "3cd86024f1b46b1078c911c3c708bcfac9ce2d8a" :authors
  '(("Semen Khramtsov" . "hrams205@gmail.com"))
  :maintainer
  '("Semen Khramtsov" . "hrams205@gmail.com")
  :url "https://github.com/semenInRussia/simple-indentation.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
