;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-sets" "20250226.2053"
  "Sets of Buffers for Buffer Management."
  '((cl-lib "0.5"))
  :url "https://git.sr.ht/~swflint/buffer-sets"
  :commit "8d67ed8c9ea182abdcf457e0c247ab44675def9e"
  :revdesc "8d67ed8c9ea1"
  :keywords '("buffer-management")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
