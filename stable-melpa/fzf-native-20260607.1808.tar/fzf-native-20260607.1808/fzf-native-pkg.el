;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260607.1808"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "0c29a421217dfa61e74b2e1ce2dd99e8d4d9df17"
  :revdesc "0c29a421217d"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
