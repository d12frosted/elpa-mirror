;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260506.1433"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "54e7d3254af5ad42e14bda395bcf5248db784a48"
  :revdesc "54e7d3254af5"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
