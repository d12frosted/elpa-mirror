(define-package "dwim-shell-command" "20221008.2253" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "9a20b27062aaead63940f444d7a3b3fc0e2a840f" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
