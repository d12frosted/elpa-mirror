;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcute" "20260929.2020"
  "Commands for marking and killing lines electrically."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "a3cadb03249878ce4777504018d4948e8f9148f6"
  :revdesc "a3cadb032498"
  :keywords '("convenience" "lisp" "xml"))
