(define-package "forge" "20230410.752" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "29.1.3.4")
    (closql "20230220")
    (dash "2.19.1")
    (emacsql "20230220")
    (ghub "20220621")
    (let-alist "1.0.6")
    (magit "20230319")
    (markdown-mode "2.4")
    (transient "0.3.6")
    (yaml "0.3.5"))
  :commit "8989f64bc1cfd18b338ede20eb78a5cc3ed4d339" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
