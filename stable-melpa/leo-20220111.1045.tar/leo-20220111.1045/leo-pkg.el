(define-package "leo" "20220111.1045" "Interface for dict.leo.org"
  '((emacs "27.1"))
  :commit "12c7133c826925e088e0ddb2ae46f51bf3111af1" :authors
  '(("M.T. Enders <michael AT michael-enders.com>")
    ("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainer
  '("M.T. Enders <michael AT michael-enders.com>")
  :keywords
  '("convenience" "translate")
  :url "https://github.com/mtenders/emacs-leo")
;; Local Variables:
;; no-byte-compile: t
;; End:
