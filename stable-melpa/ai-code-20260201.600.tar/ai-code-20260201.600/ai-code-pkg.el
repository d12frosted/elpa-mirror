;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260201.600"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e87e37527d1da12afc1b6b231e5db5cd2e94c2f0"
  :revdesc "e87e37527d1d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
