;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-timeline" "20220321.2115"
  "HTML Timeline Back-End for Org Export Engine."
  '((emacs "24.4"))
  :url "https://github.com/jjuliano/org-simple-timeline"
  :commit "b28bd4ccd5fa114c0f51b9766f0b9be7fe05fdd8"
  :revdesc "b28bd4ccd5fa"
  :keywords '("simple timeline" "timeline" "hypermedia" "html timeline")
  :authors '(("Joel Bryan Juliano" . "joelbryandotjulianoatgmaildotcom"))
  :maintainers '(("Joel Bryan Juliano" . "joelbryandotjulianoatgmaildotcom")))
