;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261022.1330"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "309f23d7abc56977121330bba620fc3d6974d59b"
  :revdesc "309f23d7abc5"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
