;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20261101.1728"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "5b1736c9d3e02a880ec664814434bc9cdec43344"
  :revdesc "5b1736c9d3e0"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
