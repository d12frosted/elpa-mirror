;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sops" "20251102.57"
  "SOPS encrypt and decrypt without leaving the editor."
  '((emacs "28.1"))
  :url "https://github.com/djgoku/sops"
  :commit "7cce0d6800eff1e9c21ab43fffe1918bcc006e7d"
  :revdesc "7cce0d6800ef"
  :keywords '("convenience" "programming")
  :authors '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainers '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com")))
