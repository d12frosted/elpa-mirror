;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "locs-and-refs" "20250303.1629"
  "Define locations and references for files and buffers."
  '((emacs   "27.1")
    (pcre2el "1.11"))
  :url "https://github.com/phf-1/locs-and-refs"
  :commit "983ac5ed8c722d55a2ab04ac68cf93f1e68c3e1a"
  :revdesc "983ac5ed8c72"
  :authors '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com"))
  :maintainers '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com")))
