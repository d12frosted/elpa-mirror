;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241026.222"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "2f53b74703765cd1840f58f739720122f5c8517e"
  :revdesc "2f53b7470376"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
