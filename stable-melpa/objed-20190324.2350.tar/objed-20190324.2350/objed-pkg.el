(define-package "objed" "20190324.2350" "Navigate and edit text objects."
  '((emacs "25")
    (cl-lib "0.5"))
  :commit "4798b5b9fd531562ac17d6148e86cd8cdc1bc985" :authors
  '(("Clemens Radermacher" . "clemera@posteo.net"))
  :maintainer
  '("Clemens Radermacher" . "clemera@posteo.net")
  :keywords
  '("convenience")
  :url "https://github.com/clemera/objed")
;; Local Variables:
;; no-byte-compile: t
;; End:
