;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260112.1054"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "97a828688f06036303e9ce2aa57262a991e6bb29"
  :revdesc "97a828688f06"
  :keywords '("languages"))
