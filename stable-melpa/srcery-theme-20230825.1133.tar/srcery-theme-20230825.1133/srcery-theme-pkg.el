(define-package "srcery-theme" "20230825.1133" "Dark color theme"
  '((emacs "24"))
  :commit "31f5ef9b85d39f720fcd874041ddbe3d8616caf4" :authors
  '(("Daniel Berg"))
  :maintainers
  '(("Daniel Berg"))
  :maintainer
  '("Daniel Berg")
  :keywords
  '("faces")
  :url "https://github.com/srcery-colors/srcery-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
