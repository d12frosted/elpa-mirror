(define-package "syslog-mode" "20210817.1527" "Major-mode for viewing log files"
  '((hide-lines "20130623")
    (ov "20150311"))
  :commit "15fc03155b3786e5e6a2cbbd83a5254c1a5c9b40" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
