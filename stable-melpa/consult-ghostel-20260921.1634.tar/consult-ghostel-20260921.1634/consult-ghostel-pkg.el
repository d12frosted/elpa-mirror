;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "20260921.1634"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "c2c411f2b0051465a5f5e7826ebab4ed216d4c0e"
  :revdesc "c2c411f2b005"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
