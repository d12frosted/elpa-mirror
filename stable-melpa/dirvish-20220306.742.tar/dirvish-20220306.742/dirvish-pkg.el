(define-package "dirvish" "20220306.742" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "44b555c89455d4105c65caf342b943dac5943e77" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
