;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-alias" "20260224.27"
  "An alternative to gnus-posting-styles."
  ()
  :url "https://github.com/hexmode/gnus-alias"
  :commit "cd7e3f92a12fe7948e2658d26bd0c53ca4a483bd"
  :revdesc "cd7e3f92a12f"
  :keywords '("personality" "identity" "news" "mail" "gnus")
  :authors '(("Joe Casadonte" . "emacs@northbound-train.com"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
