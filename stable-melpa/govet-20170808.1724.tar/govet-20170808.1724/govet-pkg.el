;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "govet" "20170808.1724"
  "Linter/problem finder for the Go source code."
  ()
  :url "https://godoc.org/golang.org/x/tools/cmd/vet"
  :commit "1b8c044aa856f4b62a682bc57494af19d22a6053"
  :revdesc "1b8c044aa856")
