(define-package "dirvish" "20220609.548" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "14c6e1c927461e6162735e461c45548d6409ea8e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
