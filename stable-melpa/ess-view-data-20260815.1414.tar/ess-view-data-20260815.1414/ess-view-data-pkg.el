;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-view-data" "20260815.1414"
  "View Data."
  '((emacs     "26.1")
    (ess       "18.10.1")
    (csv-mode  "1.12")
    (transient "0.3.7"))
  :url "https://github.com/ShuguangSun/ess-view-data"
  :commit "2f368460aff9ccc4a841839ffa4372ca9df14f76"
  :revdesc "2f368460aff9"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
