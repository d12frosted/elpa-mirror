(define-package "evil-collection" "20230613.1637" "A set of keybindings for Evil mode"
  '((emacs "26.3")
    (evil "1.2.13")
    (annalist "1.0"))
  :commit "460957cb60aabc86e77553f8af36cc08473253d7" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainers
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("evil" "tools")
  :url "https://github.com/emacs-evil/evil-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
