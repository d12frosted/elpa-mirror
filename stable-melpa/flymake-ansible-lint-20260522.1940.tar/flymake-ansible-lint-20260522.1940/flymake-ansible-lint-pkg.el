;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ansible-lint" "20260522.1940"
  "A Flymake backend for ansible-lint."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/flymake-ansible-lint.el"
  :commit "3894288568c791111e55972a626276689e16fc2d"
  :revdesc "3894288568c7"
  :keywords '("tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
