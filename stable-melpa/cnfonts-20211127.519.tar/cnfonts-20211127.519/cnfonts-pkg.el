(define-package "cnfonts" "20211127.519" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "772c25ac6ca255dc1e8dfcbf941251af68dbdd7e" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
