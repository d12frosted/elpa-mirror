(define-package "websearch" "20220808.1128" "Query search engines"
  '((emacs "24.4"))
  :commit "25d28eb3ada57c038879d6058d708119285d4c5d" :authors
  '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainer
  '("Maciej Barć" . "xgqt@riseup.net")
  :keywords
  '("convenience" "hypermedia")
  :url "https://gitlab.com/xgqt/emacs-websearch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
