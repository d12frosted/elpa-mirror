;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-aibo" "20250226.333"
  "An AI Writing Assistant."
  '((emacs "27.1")
    (gptel "0.9.7"))
  :url "https://github.com/dolmens/gptel-aibo"
  :commit "1d20271ca1f1c4ef463af0ce0dc82859b0b03455"
  :revdesc "1d20271ca1f1"
  :keywords '("emacs" "tools" "editing" "gptel" "ai" "assistant" "code-completion" "productivity")
  :authors '(("Sun Yi Ming" . "dolmens@gmail.com"))
  :maintainers '(("Sun Yi Ming" . "dolmens@gmail.com")))
