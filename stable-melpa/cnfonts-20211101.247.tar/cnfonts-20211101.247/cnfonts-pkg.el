(define-package "cnfonts" "20211101.247" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "1724d5bbf01d1538164c01f9f439ccd0ffcb5dae" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
