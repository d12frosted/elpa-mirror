;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tangotango-theme" "20261106.1331"
  "Tango Palette color theme for Emacs 24."
  ()
  :url "https://github.com/juba/color-theme-tangotango"
  :commit "1f650e7312242bfe7d70e002397d0bd3abbfc8ad"
  :revdesc "1f650e731224"
  :keywords '("tango" "palette" "color" "theme" "emacs")
  :authors '(("Julien Barnier" . "julien@nozav.org"))
  :maintainers '(("Julien Barnier" . "julien@nozav.org")))
