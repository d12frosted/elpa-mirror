;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260815.1424"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "07dc2ca5ac766d30c8e3148b9d55b1861a33f977"
  :revdesc "07dc2ca5ac76"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
