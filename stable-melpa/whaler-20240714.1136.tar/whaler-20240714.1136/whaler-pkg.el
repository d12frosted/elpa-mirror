(define-package "whaler" "20240714.1136" "Minimalistic and customizable project manager"
  '((emacs "25.1")
    (f "0.20.0"))
  :commit "20ce0a6f0803828272679b698e93d7f56d329746" :authors
  '(("Hector Salorak Alarcon" . "salorack@protonmail.com"))
  :maintainers
  '(("Hector Salorak Alarcon" . "salorack@protonmail.com"))
  :maintainer
  '("Hector Salorak Alarcon" . "salorack@protonmail.com")
  :keywords
  '("tools")
  :url "https://github.com/salorak/whaler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
