(define-package "racket-mode" "20231110.1508" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "24d59b1546d963c2b92f67a8efde951db90182da" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
