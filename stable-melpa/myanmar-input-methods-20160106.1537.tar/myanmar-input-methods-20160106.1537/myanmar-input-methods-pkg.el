;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "myanmar-input-methods" "20160106.1537"
  "Emacs Input Method for Myanmar."
  ()
  :url "https://github.com/yelinkyaw/emacs-myanmar-input-methods"
  :commit "9d4e0d6358c61bde7a2274e430ef71683faea32e"
  :revdesc "9d4e0d6358c6"
  :keywords '("myanmar" "unicode" "keyboard")
  :authors '(("Ye Lin Kyaw" . "yelinkyaw@gmail.com"))
  :maintainers '(("Ye Lin Kyaw" . "yelinkyaw@gmail.com")))
