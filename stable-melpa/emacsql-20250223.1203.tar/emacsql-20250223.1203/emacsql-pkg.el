;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsql" "20250223.1203"
  "High-level SQL database front-end."
  '((emacs "26.1"))
  :url "https://github.com/magit/emacsql"
  :commit "ad9d1b97156975bf808ecdd8eb65b374b24db1a6"
  :revdesc "ad9d1b971569"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev")))
