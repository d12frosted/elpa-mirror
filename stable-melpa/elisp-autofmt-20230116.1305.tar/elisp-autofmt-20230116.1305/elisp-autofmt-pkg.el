(define-package "elisp-autofmt" "20230116.1305" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "a1af758338e934b38a58e9fb55961ce63fc1783b" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
