(define-package "kmacro-x" "20230303.200" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "cb34d079488d0bc21df482fb77cda846cf3b8326" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
