(define-package "consult" "20230502.1654" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "625edc0274674da64af7c1a4fd5988fece7933b5" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
