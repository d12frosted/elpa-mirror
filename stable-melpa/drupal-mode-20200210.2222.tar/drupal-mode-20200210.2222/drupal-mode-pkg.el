(define-package "drupal-mode" "20200210.2222" "Advanced minor mode for Drupal development"
  '((php-mode "1.5.0"))
  :commit "4f3cffa76d8359449bf0e960f884320130f24b85" :keywords
  ("programming" "php" "drupal")
  :authors
  (("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainer
  ("Arne Jørgensen" . "arne@arnested.dk")
  :url "https://github.com/arnested/drupal-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
