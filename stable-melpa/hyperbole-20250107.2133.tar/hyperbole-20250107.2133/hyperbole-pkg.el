;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250107.2133"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ec44804a87ad4210ef3b62e990eac80d60f1e764"
  :revdesc "ec44804a87ad"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
