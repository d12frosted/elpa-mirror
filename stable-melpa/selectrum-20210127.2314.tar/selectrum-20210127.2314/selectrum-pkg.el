(define-package "selectrum" "20210127.2314" "Easily select item from list"
  '((emacs "25.1"))
  :commit "ba54e839a03d734f2fd4e4d04398cf25e2727683" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
