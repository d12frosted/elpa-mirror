;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plantuml-mode" "20250704.1238"
  "Major mode for PlantUML."
  '((dash    "2.0.0")
    (emacs   "25.1")
    (deflate "0.0.3"))
  :url "https://github.com/skuro/plantuml-mode"
  :commit "0eaf340303cf65ddd20cfb65fee1137b52ea229f"
  :revdesc "0eaf340303cf"
  :keywords '("files" "text" "processes" "tools"))
