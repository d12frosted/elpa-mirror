(define-package "ebib" "20211214.31" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "39cd331f0ac1cdd0657d22625482aecdae27708d" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
