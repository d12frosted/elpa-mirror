(define-package "erlang" "20201215.830" "Erlang major mode"
  '((emacs "24.1"))
  :commit "2b906db0e520b2232a2ec5978b13ac7fa32d5303" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
