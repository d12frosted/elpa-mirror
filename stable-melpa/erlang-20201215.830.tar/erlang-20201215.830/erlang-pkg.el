(define-package "erlang" "20201215.830" "Erlang major mode"
  '((emacs "24.1"))
  :commit "ed4bc369fe6724083bd0decac961fb7b3462d202" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
