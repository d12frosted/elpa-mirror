(define-package "erlang" "20201215.830" "Erlang major mode"
  '((emacs "24.1"))
  :commit "05d8c1660b7930e25da32d54ac56db65e984fa83" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
