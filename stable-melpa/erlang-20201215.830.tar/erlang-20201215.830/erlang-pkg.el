(define-package "erlang" "20201215.830" "Erlang major mode"
  '((emacs "24.1"))
  :commit "13f50a098423837d1cc5dc680a402d4ec75481c9")
;; Local Variables:
;; no-byte-compile: t
;; End:
