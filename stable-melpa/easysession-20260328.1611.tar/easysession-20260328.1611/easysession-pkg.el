;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260328.1611"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "ca19be94d20be05a5176ae6fd2c63e4e147db4bf"
  :revdesc "ca19be94d20b"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
