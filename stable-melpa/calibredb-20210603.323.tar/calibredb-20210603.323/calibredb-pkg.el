(define-package "calibredb" "20210603.323" "Yet another calibre client"
  '((emacs "25.1")
    (transient "0.1.0")
    (s "1.12.0")
    (dash "2.17.0"))
  :commit "4230dd5ed949aa306f34fe3cbb1b72b98e98058f" :authors
  '(("Damon Chan" . "elecming@gmail.com"))
  :maintainer
  '("Damon Chan" . "elecming@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/chenyanming/calibredb.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
