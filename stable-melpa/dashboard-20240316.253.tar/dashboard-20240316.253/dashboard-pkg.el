(define-package "dashboard" "20240316.253" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "a63d772f042727a911152f3cd628750c4fd6bf07" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers
  '(("Jesús Martínez" . "jesusmartinez93@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
