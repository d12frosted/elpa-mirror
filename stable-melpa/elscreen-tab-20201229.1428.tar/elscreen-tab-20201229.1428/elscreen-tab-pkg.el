(define-package "elscreen-tab" "20201229.1428" "minor mode to display tabs of elscreen in a dedicated buffer"
  '((emacs "26")
    (elscreen "20180321")
    (dash "2.14.1"))
  :commit "6ad77f972bde05e4e3d44f0d33b68ac41655e5f1" :authors
  (("Aki Syunsuke" . "sunny.day.dev@gmail.com"))
  :maintainer
  ("Aki Syunsuke" . "sunny.day.dev@gmail.com")
  :keywords
  ("tools" "extensions")
  :url "https://github.com/aki-s/elscreen-tab")
;; Local Variables:
;; no-byte-compile: t
;; End:
