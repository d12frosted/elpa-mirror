;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20250215.2129"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.8.0"))
  :url "https://github.com/aurtzy/disproject"
  :commit "386dea3a3b43475c1df28a3ebba7ab7e34140732"
  :revdesc "386dea3a3b43"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
