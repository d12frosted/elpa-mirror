(define-package "ekg" "20230613.1319" "A system for recording and linking information"
  '((triples "0.3.1")
    (emacs "28.1"))
  :commit "edd6fa2ba7a0b83a0cc26662cc9b96e0ae9351a5" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
