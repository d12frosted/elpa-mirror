;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "holiday-pascha-etc" "20160822.58"
  "Eastern Christian analog to holiday-easter-etc."
  ()
  :url "https://github.com/hexmode/holiday-pascha-etc"
  :commit "eb198656f63cb8679fb0e3a8248782df071a0f3c"
  :revdesc "eb198656f63c"
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
