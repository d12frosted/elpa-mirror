;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260101.1916"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "662dbe7e13811cef4821056ba40b6a38223e4ca9"
  :revdesc "662dbe7e1381")
