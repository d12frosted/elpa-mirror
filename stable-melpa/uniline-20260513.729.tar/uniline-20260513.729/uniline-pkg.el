;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260513.729"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "3c442688ea6be37c912f00ff985ddb9638663dd7"
  :revdesc "3c442688ea6b"
  :keywords '("convenience" "text"))
