(define-package "kagi" "20240424.839" "Kagi API integration"
  '((emacs "29.1")
    (shell-maker "0.46.1"))
  :commit "5433a9a91d5471c47a73d38e87384fb6e3243b6b" :authors
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainer
  '("Bram Schoenmakers" . "me@bramschoenmakers.nl")
  :keywords
  '("terminals" "wp")
  :url "https://codeberg.org/bram85/kagi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
