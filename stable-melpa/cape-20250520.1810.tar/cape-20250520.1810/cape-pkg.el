;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20250520.1810"
  "Completion At Point Extensions."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "cec3ab4b1447f3e27bd6193c1a7ec287744bf592"
  :revdesc "cec3ab4b1447"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
