;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20260101.2027"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "705afce399a6c03599e9304c5366cc62cc565c68"
  :revdesc "705afce399a6"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
