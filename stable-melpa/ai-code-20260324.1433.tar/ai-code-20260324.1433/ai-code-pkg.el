;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260324.1433"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "578637a864f8bfbefee2c7020b2f75453d6d593e"
  :revdesc "578637a864f8"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
