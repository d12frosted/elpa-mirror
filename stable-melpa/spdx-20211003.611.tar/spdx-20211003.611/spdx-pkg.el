(define-package "spdx" "20211003.611" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "67e276ad37a0cf3754798b436e54792816a6d3f2" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
