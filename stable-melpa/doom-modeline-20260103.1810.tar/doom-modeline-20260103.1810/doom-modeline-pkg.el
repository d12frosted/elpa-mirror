;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260103.1810"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "b2a80636106afa88e872e1eb954315682106a35c"
  :revdesc "b2a80636106a"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
