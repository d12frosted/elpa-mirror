(define-package "elbank" "20180316.1343" "Personal finances reporting application"
  '((emacs "25")
    (seq "2.16"))
  :commit "fa9bc7dec0a8fd489e90b9f178719344cc8d315a" :keywords
  ("tools" "personal-finances")
  :authors
  (("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainer
  ("Nicolas Petton" . "nicolas@petton.fr"))
;; Local Variables:
;; no-byte-compile: t
;; End:
