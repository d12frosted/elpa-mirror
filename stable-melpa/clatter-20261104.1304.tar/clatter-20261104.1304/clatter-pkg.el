;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20261104.1304"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "bfd4313da32349f13741abd3ee801263be53c840"
  :revdesc "bfd4313da323"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
