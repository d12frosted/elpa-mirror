(define-package "embark" "20220221.550" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d7e5b347b1ceabb49a8a90a4c8ddadc39e953e4f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
