;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mandm-theme" "20260328.1745"
  "An M&M color theme."
  ()
  :url "https://github.com/choppsv1/emacs-mandm-theme.git"
  :commit "bccf228e07e785f6534faaf50edc2e1b212c9d54"
  :revdesc "bccf228e07e7"
  :authors '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainers '(("Christian Hopps" . "chopps@gmail.com")))
