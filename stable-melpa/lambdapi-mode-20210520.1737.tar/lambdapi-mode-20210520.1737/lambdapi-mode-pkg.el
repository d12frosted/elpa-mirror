(define-package "lambdapi-mode" "20210520.1737" "A major mode for editing Lambdapi source code"
  '((emacs "26.1")
    (eglot "1.5")
    (math-symbol-lists "1.2.1")
    (highlight "20190710.1527"))
  :commit "b4043c0acbfd5e900aa8c055b65ec3ee55849a4d" :maintainer
  '("Deducteam" . "dedukti-dev@inria.fr")
  :keywords
  '("languages")
  :url "https://github.com/Deducteam/lambdapi")
;; Local Variables:
;; no-byte-compile: t
;; End:
