;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260329.1731"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "2de5fe6f9616556b0aa0d584930673763430ade9"
  :revdesc "2de5fe6f9616"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
