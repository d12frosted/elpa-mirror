(define-package "dirvish" "20220512.1734" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e40cc2dd1594d4285ec78100e98a0b0516d23782" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
