;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20260114.1606"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "4d7d58b75f6d998a69da1dd7d444642dfec38cf3"
  :revdesc "4d7d58b75f6d"
  :keywords '("convenience"))
