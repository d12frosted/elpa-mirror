(define-package "dtache" "20220206.2103" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "a0179de712ca47c4e8136cd408f5a13c159cac59" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
