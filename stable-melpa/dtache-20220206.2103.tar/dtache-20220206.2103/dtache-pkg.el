(define-package "dtache" "20220206.2103" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "fb29761b4c33c8bc940e240a0728c15813bd05b3" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
