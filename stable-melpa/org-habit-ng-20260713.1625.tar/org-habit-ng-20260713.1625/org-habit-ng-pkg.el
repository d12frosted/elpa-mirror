;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-habit-ng" "20260713.1625"
  "Full RRULE recurrence for org-habit."
  '((emacs     "28.1")
    (org       "9.6")
    (transient "0.13.5"))
  :url "https://codeberg.org/Trevoke/org-habit-ng"
  :commit "8710d55411af41d5505236d33bd5b7ad05807441"
  :revdesc "8710d55411af"
  :keywords '("calendar" "org" "habits")
  :authors '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainers '(("Aldric Giacomoni" . "trevoke@gmail.com")))
