;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash" "20260218.341"
  "Flash-style navigation."
  '((emacs "27.1"))
  :url "https://github.com/Prgebish/flash"
  :commit "5b1aa7802170438bafeaebe943ed95409b8f364b"
  :revdesc "5b1aa7802170"
  :keywords '("convenience" "navigation")
  :authors '(("Vadim Pavlov" . "https://github.com/Prgebish"))
  :maintainers '(("Vadim Pavlov" . "https://github.com/Prgebish")))
