;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261119.1644"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "deba547a1bbeef75b143b115b822baee41d66980"
  :revdesc "deba547a1bbe"
  :keywords '("build tools" "languages"))
