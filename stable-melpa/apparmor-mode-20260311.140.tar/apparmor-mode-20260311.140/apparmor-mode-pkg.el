;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apparmor-mode" "20260311.140"
  "Major mode for editing AppArmor policy files."
  '((emacs "26.1"))
  :url "https://github.com/alexmurray/apparmor-mode"
  :commit "fd9c6f142602bf5ed730305419b2b7cad2269e57"
  :revdesc "fd9c6f142602"
  :authors '(("Alex Murray" . "alex.murray@canonical.com"))
  :maintainers '(("Alex Murray" . "alex.murray@canonical.com")))
