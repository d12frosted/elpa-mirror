;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261005.345"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "c06ddf9b39b42d8d514103191dc075571d6fb2fb"
  :revdesc "c06ddf9b39b4"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
