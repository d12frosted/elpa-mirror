;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbucket-devops" "20261017.1727"
  "Bitbucket Cloud DevOps workflows."
  '((emacs         "29.1")
    (magit         "4.0.0")
    (markdown-mode "2.6")
    (transient     "0.3.0")
    (yaml          "1.2.3"))
  :url "https://github.com/will-abb/bitbucket-devops.el"
  :commit "763e6c8095e41a259f7f907c3db3886b6719c5d6"
  :revdesc "763e6c8095e4"
  :keywords '("tools" "vc")
  :authors '(("Will Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Will Bosch-Bello" . "williamsbosch@gmail.com")))
