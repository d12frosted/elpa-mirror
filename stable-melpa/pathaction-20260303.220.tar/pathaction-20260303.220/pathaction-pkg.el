;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260303.220"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "5a0d68403e84189d77161e712004efa7aaa81b8e"
  :revdesc "5a0d68403e84"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
