;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-line-preview" "20260128.834"
  "Preview line when executing `goto-line` command."
  '((emacs "25"))
  :url "https://github.com/emacs-vs/goto-line-preview"
  :commit "e11a1e7bfff5240e44d71d2ff8fae2d5bcbda784"
  :revdesc "e11a1e7bfff5"
  :keywords '("convenience" "line" "navigation")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
