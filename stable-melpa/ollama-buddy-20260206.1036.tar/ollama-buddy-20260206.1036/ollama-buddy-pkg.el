;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260206.1036"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "9e4d95141caac83abb866fac4d85a87b4f37b2a5"
  :revdesc "9e4d95141caa"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
