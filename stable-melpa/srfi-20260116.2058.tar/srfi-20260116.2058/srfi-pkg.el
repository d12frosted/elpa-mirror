;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260116.2058"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "f0406b2f66b9ce859fbab8fe6617521ff588d03b"
  :revdesc "f0406b2f66b9"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
