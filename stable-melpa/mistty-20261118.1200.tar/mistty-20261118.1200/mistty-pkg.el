;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20261118.1200"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "3ac8573b056392e18cc1fe4b27bd7a4e81fee2cf"
  :revdesc "3ac8573b0563"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
