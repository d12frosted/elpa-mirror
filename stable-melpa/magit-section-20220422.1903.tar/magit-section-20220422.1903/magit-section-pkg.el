(define-package "magit-section" "20220422.1903" "Sections for read-only buffers"
  '((emacs "25.1")
    (compat "28.1.0.4")
    (dash "20210826"))
  :commit "b4d54d3f8ee047479980b6d8079f3ce1a93bb6a4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
