;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260903.747"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "9b3533ff48d627442abd9260492d47d7015d6413"
  :revdesc "9b3533ff48d6"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
