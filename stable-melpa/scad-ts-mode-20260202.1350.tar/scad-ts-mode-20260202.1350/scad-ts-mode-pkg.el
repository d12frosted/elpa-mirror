;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-ts-mode" "20260202.1350"
  "Tree-sitter support for OpenSCAD."
  '((emacs "29.3"))
  :url "https://github.com/yoshinari-nomura/scad-ts-mode"
  :commit "afaf52a34050aa1f7da12b85b25f20beffb08e2f"
  :revdesc "afaf52a34050"
  :keywords '("openscad" "languages" "tree-sitter")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
