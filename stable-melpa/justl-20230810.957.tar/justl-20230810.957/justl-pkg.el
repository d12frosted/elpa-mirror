(define-package "justl" "20230810.957" "Major mode for driving just files"
  '((transient "0.1.0")
    (emacs "27.1")
    (s "1.2.0")
    (f "0.20.0"))
  :commit "d8fae037a873b51e0b14b137f1c2b813dc89b853" :authors
  '(("Sibi Prabakaran"))
  :maintainers
  '(("Sibi Prabakaran"))
  :maintainer
  '("Sibi Prabakaran")
  :keywords
  '("just" "justfile" "tools" "processes")
  :url "https://github.com/psibi/justl.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
