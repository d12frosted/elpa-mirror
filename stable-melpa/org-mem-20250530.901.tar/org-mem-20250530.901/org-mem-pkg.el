;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250530.901"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "22a120c059a6737e310000ace91a92a8a6b0f09f"
  :revdesc "22a120c059a6"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
