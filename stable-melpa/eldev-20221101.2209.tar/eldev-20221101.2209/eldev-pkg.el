(define-package "eldev" "20221101.2209" "Elisp development tool"
  '((emacs "24.4"))
  :commit "dc3f73c38a31567fce8db529da238151aa44c307" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
