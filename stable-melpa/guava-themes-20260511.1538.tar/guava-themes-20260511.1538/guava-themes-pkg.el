;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260511.1538"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "77f4f99880a78ed2f0abd2e526da23dd72c322d7"
  :revdesc "77f4f99880a7"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
