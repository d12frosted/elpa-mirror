(define-package "dired-icon" "20170223.526" "A minor mode to display a list of associated icons in dired buffers."
  '((emacs "24.3"))
  :commit "f60e10757a5011235b519231ad35974ff25963ed" :keywords
  ("dired" "files")
  :authors
  (("Hong Xu" . "hong@topbug.net"))
  :maintainer
  ("Hong Xu" . "hong@topbug.net")
  :url "https://gitlab.com/xuhdev/dired-icon")
;; Local Variables:
;; no-byte-compile: t
;; End:
