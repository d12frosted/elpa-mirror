(define-package "spdx" "20220715.157" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "052b0c908ccb387f50ab8a80befa6a1443ba5b70" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
