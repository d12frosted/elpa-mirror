;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pynt" "20180710.726"
  "Generate and scroll EIN buffers from python code."
  '((emacs    "24.4")
    (ein      "0.13.1")
    (epc      "0.1.1")
    (deferred "0.5.1"))
  :url "https://github.com/ebanner/pynt"
  :commit "963c43cfdb5deea7daedc269aafa79192d853154"
  :revdesc "963c43cfdb5d"
  :keywords '("convenience")
  :authors '(("Edward Banner" . "edward.banner@gmail.com"))
  :maintainers '(("Edward Banner" . "edward.banner@gmail.com")))
