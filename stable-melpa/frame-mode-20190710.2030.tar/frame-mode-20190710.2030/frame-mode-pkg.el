(define-package "frame-mode" "20190710.2030" "Use frames instead of windows"
  '((s "1.9.0")
    (emacs "24.4"))
  :commit "ae2366969927c9f89ea07c999bef382b0b47cac1" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/IvanMalison/frame-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
