;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260622.2253"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "2cf1abf583d383665d07812366a6b51c89ef4e2d"
  :revdesc "2cf1abf583d3"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
