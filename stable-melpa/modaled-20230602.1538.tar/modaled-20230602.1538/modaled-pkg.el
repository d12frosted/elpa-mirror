(define-package "modaled" "20230602.1538" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "2ebe985f8b170b101f4f8de5f833ba5718761638" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
