(define-package "eldev" "20231104.2138" "Elisp development tool"
  '((emacs "24.4"))
  :commit "d7bf23c0668031a288bf41f0121833677163b551" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/emacs-eldev/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
