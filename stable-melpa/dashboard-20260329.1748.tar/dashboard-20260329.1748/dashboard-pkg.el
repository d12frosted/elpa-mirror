;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard" "20260329.1748"
  "A startup screen extracted from Spacemacs."
  '((emacs "27.1"))
  :url "https://github.com/emacs-dashboard/dashboard"
  :commit "56470b630d8057ac1609755a9aa881cab4d5da9c"
  :revdesc "56470b630d80"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Ricardo Arredondo" . "ricardo.richo@gmail.com")))
