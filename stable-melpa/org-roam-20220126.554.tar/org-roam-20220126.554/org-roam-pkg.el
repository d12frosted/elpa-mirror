(define-package "org-roam" "20220126.554" "A database abstraction layer for Org-mode"
  '((emacs "26.1")
    (dash "2.13")
    (org "9.4")
    (emacsql "3.0.0")
    (emacsql-sqlite "1.0.0")
    (magit-section "3.0.0"))
  :commit "aafe4114c2288706c5a7499c29cd5442e3c9e708" :authors
  '(("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  '("Jethro Kuan" . "jethrokuan95@gmail.com")
  :keywords
  '("org-mode" "roam" "convenience")
  :url "https://github.com/org-roam/org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
