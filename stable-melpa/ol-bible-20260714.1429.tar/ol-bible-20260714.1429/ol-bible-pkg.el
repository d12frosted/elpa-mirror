;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-bible" "20260714.1429"
  "Org Link support for Bible Passages."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~swflint/ol-bible"
  :commit "711f9a984c23b0cc91a3a12a339e3d0ebb714a8f"
  :revdesc "711f9a984c23"
  :keywords '("convenience" "outlines")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
