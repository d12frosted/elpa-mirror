;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250619.2231"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.16.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "ca0cf312f09242288d3887ee9bce74dd7afb6ee4"
  :revdesc "ca0cf312f092"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
