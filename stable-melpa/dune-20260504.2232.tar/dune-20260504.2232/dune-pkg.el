;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "20260504.2232"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "5c75ff0ce9c4b1189de8254c4da446db91c5afa1"
  :revdesc "5c75ff0ce9c4")
