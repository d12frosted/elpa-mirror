;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251017.23"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "0d6bddea97fe341cf43017d6db5c112788b99e37"
  :revdesc "0d6bddea97fe"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
