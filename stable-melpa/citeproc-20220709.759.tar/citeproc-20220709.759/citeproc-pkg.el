(define-package "citeproc" "20220709.759" "A CSL 1.0.2 Citation Processor"
  '((emacs "26")
    (dash "2.13.0")
    (s "1.12.0")
    (f "0.18.0")
    (queue "0.2")
    (string-inflection "1.0")
    (org "9")
    (parsebib "2.4"))
  :commit "993aeb24ba53d638cf9e5b4f2f7926d6d235c123" :authors
  '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainer
  '("András Simonyi" . "andras.simonyi@gmail.com")
  :keywords
  '("bib")
  :url "https://github.com/andras-simonyi/citeproc-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
