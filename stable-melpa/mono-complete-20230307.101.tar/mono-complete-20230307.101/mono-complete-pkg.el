(define-package "mono-complete" "20230307.101" "Completion suggestions with multiple back-ends"
  '((emacs "28.1"))
  :commit "8ea1a54e361abd782fa438d4fb4d3c5cdaa694a3" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mono-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
