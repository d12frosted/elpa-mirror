;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20251121.1323"
  "Display documentation for mouse hover."
  '((emacs    "30.1")
    (posframe "1.4.0")
    (eglot    "1.8"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "0b84d1bb46992680181cf67b8f8aeaff3be5620b"
  :revdesc "0b84d1bb4699"
  :keywords '("tools" "languages" "convenience" "emacs" "mouse" "hover")
  :authors '((nil . "HuangFeiyusibadake1@163.com"))
  :maintainers '((nil . "HuangFeiyusibadake1@163.com")))
