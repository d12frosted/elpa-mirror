;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "20260930.524"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "41dfa01dd8584d740e037cc891877995406e6ce2"
  :revdesc "41dfa01dd858"
  :keywords '("outlines" "tools" "convenience" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
