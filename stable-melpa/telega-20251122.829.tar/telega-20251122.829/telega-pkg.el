;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251122.829"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "d359504b77e139542f4fafd0cbe3a480ccdb09ed"
  :revdesc "d359504b77e1"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
