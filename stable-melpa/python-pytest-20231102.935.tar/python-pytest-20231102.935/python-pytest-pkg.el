(define-package "python-pytest" "20231102.935" "helpers to run pytest"
  '((emacs "24.4")
    (dash "2.18.0")
    (transient "0.3.7")
    (projectile "0.14.0")
    (s "1.12.0"))
  :commit "51ded7d572afa9eced25811380a75464b5eb1874" :authors
  '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers
  '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainer
  '("wouter bolsterlee" . "wouter@bolsterl.ee")
  :keywords
  '("pytest" "test" "python" "languages" "processes" "tools")
  :url "https://github.com/wbolster/emacs-python-pytest")
;; Local Variables:
;; no-byte-compile: t
;; End:
