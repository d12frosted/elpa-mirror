;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260211.1657"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "5842d1f5fbac3b4ec07e447e7a404cd3f6b4285b"
  :revdesc "5842d1f5fbac"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
