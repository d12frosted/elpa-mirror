(define-package "ejc-sql" "20200928.1925" "Emacs SQL client uses Clojure JDBC."
  '((emacs "26.3")
    (clomacs "0.0.5")
    (dash "2.16.0")
    (spinner "1.7.3")
    (direx "1.0.0"))
  :commit "4d4be613a59f9227d80566c6bc8064462996a254" :keywords
  ("sql" "jdbc")
  :authors
  (("Kostafey" . "kostafey@gmail.com"))
  :maintainer
  ("Kostafey" . "kostafey@gmail.com")
  :url "https://github.com/kostafey/ejc-sql")
;; Local Variables:
;; no-byte-compile: t
;; End:
