;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260703.358"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "278fe0c68dedd8494b3ecdd776a9fedc27b05b4f"
  :revdesc "278fe0c68ded"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
