;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250608.1328"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "9c9966a9763687f7352506f31e3b4d782667590a"
  :revdesc "9c9966a97636"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
