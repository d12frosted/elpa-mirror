(define-package "for" "20220909.1705" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "97ba4612474b034b784dc2e0e613a4622b58a730" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
