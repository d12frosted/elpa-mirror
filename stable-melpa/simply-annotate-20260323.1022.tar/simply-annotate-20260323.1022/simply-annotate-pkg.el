;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260323.1022"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "c2bf81ae5251dbc2a4b72dc4532bca012b3112de"
  :revdesc "c2bf81ae5251"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
