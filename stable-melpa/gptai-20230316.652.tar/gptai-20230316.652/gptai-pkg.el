(define-package "gptai" "20230316.652" "Integrate with the OpenAI API"
  '((emacs "24.1"))
  :commit "95533ffac2cbaa75aee14ad34df1d0643031b1fc" :authors
  '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainer
  '("Anton Hibl" . "antonhibl11@gmail.com")
  :keywords
  '("comm" "convenience")
  :url "https://github.com/antonhibl/gptai")
;; Local Variables:
;; no-byte-compile: t
;; End:
