(define-package "apdl-mode" "20210918.906" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "50768ea67977ef39bcd4e6e5ae1f4f874244e87b" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
