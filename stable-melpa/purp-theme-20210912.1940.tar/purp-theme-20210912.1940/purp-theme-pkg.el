(define-package "purp-theme" "20210912.1940" "A dark color theme with few colors" 'nil :commit "8d3510e1ed995b8323cd5205626ddde6386a76ca" :authors
  '(("Vincent Foley" . "vfoley@gmail.com"))
  :maintainer
  '("Vincent Foley" . "vfoley@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/gnuvince/purp")
;; Local Variables:
;; no-byte-compile: t
;; End:
