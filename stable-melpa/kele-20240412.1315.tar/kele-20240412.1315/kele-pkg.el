(define-package "kele" "20240412.1315" "Spritzy Kubernetes cluster management"
  '((emacs "28.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (plz "0.7.3")
    (s "1.13.0")
    (yaml "0.5.1"))
  :commit "3d7741728a3d9b95120eed7313266ef69ebb52fb" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
