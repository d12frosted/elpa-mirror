(define-package "oer-reveal" "20210819.850" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "aa1db964a25f99df945c308fba983de6f044aa8e" :authors
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
