(define-package "third-time" "20231023.212" "Third Time: A Better Way to Work"
  '((emacs "27.1"))
  :commit "d1e0e146c298de0114035b19c9c4f990db7f1ae5" :authors
  '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers
  '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainer
  '("Samuel W. Flint" . "swflint@flintfam.org")
  :url "https://git.sr.ht/~swflint/busylight")
;; Local Variables:
;; no-byte-compile: t
;; End:
