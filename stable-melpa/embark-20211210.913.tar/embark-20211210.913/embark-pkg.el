(define-package "embark" "20211210.913" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "f9e6749aade62b21bf077df0be17a5c79624dda2" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
