;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260926.910"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "3c64214db5cd61a8f8186e4dce89c0e04be1652c"
  :revdesc "3c64214db5cd"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
