;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260322.909"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "79686c56a1a07a8897301ae043d06c6e87084f7e"
  :revdesc "79686c56a1a0"
  :keywords '("comm"))
