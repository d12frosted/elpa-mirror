;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260217.541"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "dec1077f42497e8340ea171c32a70b05a8969fe7"
  :revdesc "dec1077f4249"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
