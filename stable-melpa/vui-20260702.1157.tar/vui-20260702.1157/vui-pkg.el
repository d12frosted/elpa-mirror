;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260702.1157"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "2762ef4a32c64068bd2195f2b4b2c43e5465f027"
  :revdesc "2762ef4a32c6"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
