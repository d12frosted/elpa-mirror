(define-package "omni-tags" "20150513.1150" "Highlight and Actions for 'Tags'"
  '((pcre2el "1.7")
    (cl-lib "0.5"))
  :commit "a7078bfbc9a6256efd0e57530df9fd7808bc2185" :authors
  '(("Adrien Becchis" . "adriean.khisbe@live.fr"))
  :maintainer
  '("Adrien Becchis" . "adriean.khisbe@live.fr")
  :keywords
  '("convenience")
  :url "http://github.com/AdrieanKhisbe/omni-tags.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
