(define-package "pyinspect" "20211101.804" "Python object inspector"
  '((emacs "27.1"))
  :commit "4e407d401978ac1a129daf292d53c04a913bbc81" :authors
  '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainer
  '("Maor Kadosh" . "git@avocadosh.xyz")
  :keywords
  '("tools")
  :url "https://github.com/it-is-wednesday/pyinspect.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
