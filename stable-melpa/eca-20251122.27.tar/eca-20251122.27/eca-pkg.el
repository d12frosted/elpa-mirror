;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251122.27"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "c4fb9be3e38bc0b2995d26cd9dc5db77a262ad80"
  :revdesc "c4fb9be3e38b"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
