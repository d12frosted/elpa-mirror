(define-package "ewal" "20200301.823" "A pywal-based theme generator"
  '((emacs "25.1"))
  :commit "732a2f4abb480f9f5a3249af822d8eb1e90324e3" :authors
  '(("Uros Perisic"))
  :maintainer
  '("Uros Perisic")
  :keywords
  '("faces")
  :url "https://gitlab.com/jjzmajic/ewal")
;; Local Variables:
;; no-byte-compile: t
;; End:
