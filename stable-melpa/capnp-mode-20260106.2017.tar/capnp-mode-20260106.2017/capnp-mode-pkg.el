;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "capnp-mode" "20260106.2017"
  "Major mode for editing Capn' Proto Files."
  ()
  :url "https://github.com/capnproto/capnproto"
  :commit "92327754f61963a2b4f0edbd299246ed1d42e665"
  :revdesc "92327754f619"
  :authors '(("Brian Taylor" . "el.wubo@gmail.com"))
  :maintainers '(("Brian Taylor" . "el.wubo@gmail.com")))
