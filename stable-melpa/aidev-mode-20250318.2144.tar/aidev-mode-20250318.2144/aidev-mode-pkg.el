;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidev-mode" "20250318.2144"
  "Minor mode for AI-assisted development."
  '((emacs   "27.1")
    (request "0.3.2"))
  :url "https://github.com/inaimathi/aidev-mode"
  :commit "5a71b7ddc43be3629e2c2928e349fee78099989f"
  :revdesc "5a71b7ddc43b"
  :keywords '("tools" "convenience" "ai")
  :authors '(("inaimathi" . "leo.zovic@example.com"))
  :maintainers '(("inaimathi" . "leo.zovic@example.com")))
