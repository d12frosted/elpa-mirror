;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf" "20261128.507"
  "Simplify your init.el configuration, extended use-package."
  '((emacs "24.1"))
  :url "https://github.com/conao3/leaf.el"
  :commit "aab780a2689788fb7198292982eb64111f1d7d6b"
  :revdesc "aab780a26897"
  :keywords '("lisp" "settings")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
