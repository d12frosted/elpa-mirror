;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251020.840"
  "An Org-social client."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "972d72fa9dcfce2517b79acc59e80e41d3e246a0"
  :revdesc "972d72fa9dcf"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
