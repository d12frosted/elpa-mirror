;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "life-calendar" "20260111.2324"
  "Display your life in weeks."
  '((emacs "27.1"))
  :url "https://github.com/vshender/emacs-life-calendar"
  :commit "9f618f7958282f04245a4a59214c7bfd255f73d4"
  :revdesc "9f618f795828"
  :keywords '("calendar" "visualization")
  :authors '(("Vadzim Shender" . "https://github.com/vshender"))
  :maintainers '(("Vadzim Shender" . "https://github.com/vshender")))
