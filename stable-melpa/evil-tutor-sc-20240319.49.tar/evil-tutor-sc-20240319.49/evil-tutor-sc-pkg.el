(define-package "evil-tutor-sc" "20240319.49" "Simplified Chinese tutor for Evil"
  '((evil "1.0.9")
    (evil-tutor "0.1"))
  :commit "11478f59a3d90b41313eab9c5fecffd4816ca182" :authors
  '(("clsty" . "celestial.y@outlook.com"))
  :maintainers
  '(("clsty" . "celestial.y@outlook.com"))
  :maintainer
  '("clsty" . "celestial.y@outlook.com")
  :keywords
  '("convenience" "editing" "evil" "chinese")
  :url "https://github.com/clsty/evil-tutor-sc")
;; Local Variables:
;; no-byte-compile: t
;; End:
