(define-package "fanyi" "20211024.1921" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "7760e553cf848511600b91f2fbfddcdf60b593d3" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
