(define-package "embark" "20211208.1655" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "9f2de96de350b61abf563f1d742b2469ab6ceb66" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
