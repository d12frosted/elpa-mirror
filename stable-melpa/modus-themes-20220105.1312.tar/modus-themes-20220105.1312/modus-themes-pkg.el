(define-package "modus-themes" "20220105.1312" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "d40952c8f4a72e66cf9de1f0ee5c0ea17d7b52fe" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
