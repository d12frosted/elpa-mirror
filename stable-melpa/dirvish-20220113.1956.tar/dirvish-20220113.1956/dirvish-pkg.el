(define-package "dirvish" "20220113.1956" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "8a4eab1c5e50a350d96f17594f57406974b282bb" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
