;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ronny-theme" "20260805.802"
  "A dark colorscheme inspired by Monokai."
  '((emacs "27"))
  :url "https://github.com/judaew/ronny.el"
  :commit "42fd8eeebe26b70d98bdc621183c4a2b6acef7a5"
  :revdesc "42fd8eeebe26"
  :authors '(("Vadym-Valdis Yudaiev" . "judaew@outlook.com"))
  :maintainers '(("Vadym-Valdis Yudaiev" . "judaew@outlook.com")))
