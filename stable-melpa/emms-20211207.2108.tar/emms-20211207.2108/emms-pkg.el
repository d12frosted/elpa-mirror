(define-package "emms" "20211207.2108" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (seq "0"))
  :commit "5a59c0f435fb3a9a96e29de2bc7dcb914316f9dd" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
