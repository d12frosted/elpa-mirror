;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260523.130"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "29677fe3020c2934f73f0d278c1dc4a6eb353f6c"
  :revdesc "29677fe3020c"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
