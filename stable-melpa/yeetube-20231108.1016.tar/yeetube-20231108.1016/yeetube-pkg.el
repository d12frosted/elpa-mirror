(define-package "yeetube" "20231108.1016" "YouTube Front End"
  '((emacs "27.2"))
  :commit "cca40d2020ba45b0113d4a5d6a5c26995e07d83d" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.org/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
