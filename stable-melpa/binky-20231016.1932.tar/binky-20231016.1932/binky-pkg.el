(define-package "binky" "20231016.1932" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "ded43d2286d1f36e1aedc2b6778b706a5a84a9a4" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
