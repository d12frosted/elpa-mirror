(define-package "naga-theme" "20230904.801" "Dark color theme with green foreground color"
  '((emacs "24.1"))
  :commit "a1b12bd7b00b286c3f37f50136dcf5602fc178ec" :authors
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainers
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainer
  '("Johannes Maier" . "johannes.maier@mailbox.org")
  :keywords
  '("faces" "themes")
  :url "https://github.com/kenranunderscore/emacs-naga-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
