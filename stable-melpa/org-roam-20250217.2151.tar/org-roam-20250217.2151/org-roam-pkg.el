;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam" "20250217.2151"
  "A database abstraction layer for Org-mode."
  '((emacs         "26.1")
    (dash          "2.13")
    (org           "9.4")
    (emacsql       "4.0.0")
    (magit-section "3.0.0"))
  :url "https://github.com/org-roam/org-roam"
  :commit "7dc76b708b436d9531b477001e8ac922e719ffd4"
  :revdesc "7dc76b708b43"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainers '(("Jethro Kuan" . "jethrokuan95@gmail.com")))
