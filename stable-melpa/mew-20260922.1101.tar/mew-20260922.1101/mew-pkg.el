;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260922.1101"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "66261fb2eead0abfbf3d8c435b2f615c8bc7fe4b"
  :revdesc "66261fb2eead")
