;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261028.1240"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "91c70e2637f678944de9f719c71d4fe24aa09c41"
  :revdesc "91c70e2637f6"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
