;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-inactive-region" "20260612.949"
  "Highlight the inactive region."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-show-inactive-region"
  :commit "c870fe641c56328458e16d92fd7aedf688844a3b"
  :revdesc "c870fe641c56"
  :keywords '("convenience" "faces")
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
