(define-package "related-files" "20230225.1900" "Easily find files related to the current one"
  '((emacs "28.2"))
  :commit "5f0888e6427c49b9ca62e5e21f135db0966a2194" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("tools")
  :url "https://www.gnu.org/software/emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
