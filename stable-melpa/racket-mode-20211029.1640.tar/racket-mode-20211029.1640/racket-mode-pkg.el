(define-package "racket-mode" "20211029.1640" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "e8ae8f8a12cb9ad26c049f7e2834ea239c9109f1" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
