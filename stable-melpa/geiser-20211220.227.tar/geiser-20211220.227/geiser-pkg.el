(define-package "geiser" "20211220.227" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3"))
  :commit "c5f6a8ac9ebdce93d4b551342accd2c85c4f7030" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
