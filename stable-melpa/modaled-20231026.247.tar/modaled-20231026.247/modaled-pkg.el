(define-package "modaled" "20231026.247" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "0a8471752f89d07b439680212dceda2e69b63457" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
