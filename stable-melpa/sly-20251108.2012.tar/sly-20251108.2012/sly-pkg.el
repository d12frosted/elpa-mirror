;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20251108.2012"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.3"))
  :url "https://github.com/joaotavora/sly"
  :commit "6e6520b88a7e54c91b2b23e4be208c989abdd0db"
  :revdesc "6e6520b88a7e"
  :keywords '("languages" "lisp" "sly"))
