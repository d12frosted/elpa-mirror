;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-table-sticky-header" "20190924.506"
  "Sticky header for org-mode tables."
  '((org   "8.2.10")
    (emacs "24.4"))
  :url "https://github.com/cute-jumper/org-table-sticky-header"
  :commit "b65442857128ab04724aaa301e60aa874a31a798"
  :revdesc "b65442857128"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
