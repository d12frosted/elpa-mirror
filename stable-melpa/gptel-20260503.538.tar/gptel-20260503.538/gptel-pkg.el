;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260503.538"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "d7c103ce8a66ecaee7c8fc9ecadb681dc4291408"
  :revdesc "d7c103ce8a66"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
