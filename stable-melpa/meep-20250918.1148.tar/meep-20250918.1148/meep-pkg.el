;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250918.1148"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "6d34f4c05a3b2ba65dea77a3a84f70b046f15841"
  :revdesc "6d34f4c05a3b"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
