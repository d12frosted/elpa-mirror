;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260528.1507"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "482b7854b04169b348f3c943891f0895bd38bc4f"
  :revdesc "482b7854b041"
  :keywords '("convenience" "chinese" "input-method" "rime"))
