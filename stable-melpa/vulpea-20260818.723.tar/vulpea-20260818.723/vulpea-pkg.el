;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260818.723"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "52c02bfda2bd51e7f46f25b71c6999bb63b6c133"
  :revdesc "52c02bfda2bd"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
