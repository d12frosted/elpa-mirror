;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "desktop+" "20170107.2132"
  "Handle special buffers when saving & restoring sessions."
  '((emacs "24.4")
    (dash  "2.11.0")
    (f     "0.17.2"))
  :url "https://github.com/ffevotte/desktop-plus"
  :commit "d26f369bda96860eef18365cdb5c79f39a2c765c"
  :revdesc "d26f369bda96"
  :authors '(("François Févotte" . "fevotte@gmail.com"))
  :maintainers '(("François Févotte" . "fevotte@gmail.com")))
