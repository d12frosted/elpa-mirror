;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglink" "20260925.941"
  "Use Org Mode links in other modes."
  '((emacs  "29.1")
    (compat "31.0")
    (llama  "1.0")
    (org    "9.8"))
  :url "https://github.com/tarsius/orglink"
  :commit "7aacbcd8190311db0ebfad941d967c7db0c558a0"
  :revdesc "7aacbcd81903"
  :keywords '("hypermedia")
  :authors '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev")))
