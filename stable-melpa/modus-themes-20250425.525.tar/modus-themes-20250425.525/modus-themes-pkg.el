;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250425.525"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "1fe0a3c9c46e66e6634e0ed23f2b5450497f618d"
  :revdesc "1fe0a3c9c46e"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
