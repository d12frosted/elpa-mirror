(define-package "zotra" "20230819.1747" "Library to use Zotero translators"
  '((emacs "27.1"))
  :commit "9cd9eb36bbc65efcc38ca38fc96730dbbe882fd8" :authors
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainers
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainer
  '("Mohammad Pedramfar <https://github.com/mpedramfar>")
  :url "https://github.com/mpedramfar/zotra")
;; Local Variables:
;; no-byte-compile: t
;; End:
