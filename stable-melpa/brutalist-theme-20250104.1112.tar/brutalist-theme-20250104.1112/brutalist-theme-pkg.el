;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brutalist-theme" "20250104.1112"
  "Brutalist theme."
  '((emacs "24.1"))
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el"
  :commit "29f1c70451075e87a9f1747478cc78ed6d37de26"
  :revdesc "29f1c7045107")
