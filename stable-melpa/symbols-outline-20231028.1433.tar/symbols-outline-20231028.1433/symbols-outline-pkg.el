(define-package "symbols-outline" "20231028.1433" "Display symbols (functions, variables, etc) in outline view"
  '((emacs "27.1"))
  :commit "56b7e341e61f06cb379e59e917758bcd1d508592" :authors
  '(("Shihao Liu"))
  :maintainers
  '(("Shihao Liu"))
  :maintainer
  '("Shihao Liu")
  :keywords
  '("outlines")
  :url "https://github.com/liushihao456/symbols-outline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
