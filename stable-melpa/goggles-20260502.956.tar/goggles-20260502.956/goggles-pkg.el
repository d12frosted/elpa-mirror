;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goggles" "20260502.956"
  "Pulse modified regions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/goggles"
  :commit "68d9909dab6b1a0f64f7888b2b2e74cda78faf1e"
  :revdesc "68d9909dab6b"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
