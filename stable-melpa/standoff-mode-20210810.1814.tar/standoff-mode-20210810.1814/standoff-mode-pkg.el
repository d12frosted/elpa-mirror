(define-package "standoff-mode" "20210810.1814" "Create stand-off markup, also called external markup." 'nil :commit "aa5bac257ebefd91f4b5dd787a835407bddd6fb2" :authors
  '(("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de"))
  :maintainer
  '("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de")
  :keywords
  '("text" "annotations" "ner" "humanities")
  :url "https://github.com/lueck/standoff-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
