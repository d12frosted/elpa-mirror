(define-package "standoff-mode" "20210810.1814" "Create stand-off markup, also called external markup." 'nil :commit "5e603092410d9c393d19050bcbed3014a379f0e6" :authors
  '(("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de"))
  :maintainer
  '("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de")
  :keywords
  '("text" "annotations" "ner" "humanities")
  :url "https://github.com/lueck/standoff-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
