(define-package "standoff-mode" "20210810.1814" "Create stand-off markup, also called external markup." 'nil :commit "e265bb36893af5d7327c3622cacae80772f59562" :authors
  '(("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de"))
  :maintainer
  '("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de")
  :keywords
  '("text" "annotations" "ner" "humanities")
  :url "https://github.com/lueck/standoff-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
