;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-projectile" "20260917.19"
  "Ivy integration for Projectile."
  '((counsel    "0.13.4")
    (projectile "3.3.0"))
  :url "https://github.com/ericdanan/counsel-projectile"
  :commit "037747b8d3cfee791eb6a5aa7822fbf6cf52b6d6"
  :revdesc "037747b8d3cf"
  :keywords '("project" "convenience"))
