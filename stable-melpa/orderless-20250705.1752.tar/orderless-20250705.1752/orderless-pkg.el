;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orderless" "20250705.1752"
  "Completion style for matching regexps in any order."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/oantolin/orderless"
  :commit "2adfaea003790614ce52e7aee3169f90c1a8769b"
  :revdesc "2adfaea00379"
  :keywords '("matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
