;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "20260409.2330"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "4b0deb0b0ef4a73ea8fe9e2b62b45321dd76a609"
  :revdesc "4b0deb0b0ef4"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
