(define-package "embark" "20210109.2045" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "8f5629d91dd1b63e979f8e2818b26fa541fdbc5b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
