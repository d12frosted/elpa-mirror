;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-R" "20120820.14"
  "Helm-sources and some utilities for GNU R."
  '((helm "20120517")
    (ess  "20120509"))
  :url "https://github.com/myuhe/helm-R.el"
  :commit "b0eb9d5f6a483a9dbe6eb6cf1f2024d4f5938bc2"
  :revdesc "b0eb9d5f6a48"
  :keywords '("convenience")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
