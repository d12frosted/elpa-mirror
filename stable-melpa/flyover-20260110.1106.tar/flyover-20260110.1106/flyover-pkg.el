;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20260110.1106"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "742e23551809c9bc7ffd6d2c59c7bbed3aacfef1"
  :revdesc "742e23551809"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
