(define-package "binder" "20201222.1603" "Global minor mode to facilitate multi-file writing projects"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "8a10a66116797e132b19f57026a1976753d332e9" :authors
  '(("Paul W. Rankin" . "pwr@skeletons.cc"))
  :maintainer
  '("Paul W. Rankin" . "pwr@skeletons.cc")
  :keywords
  '("files" "outlines" "wp" "text")
  :url "https://git.skeletons.cc/binder")
;; Local Variables:
;; no-byte-compile: t
;; End:
