(define-package "ebib" "20231103.2" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "26.1"))
  :commit "6381458947bc6fb6c0605469bceb92784a9fbd67" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
