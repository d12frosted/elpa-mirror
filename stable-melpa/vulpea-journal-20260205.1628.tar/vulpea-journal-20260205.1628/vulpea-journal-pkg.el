;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-journal" "20260205.1628"
  "Daily note interface for vulpea."
  '((emacs     "29.1")
    (vulpea    "2.0.0")
    (vulpea-ui "1.0.0")
    (dash      "2.20.0"))
  :url "https://github.com/d12frosted/vulpea-journal"
  :commit "002344eedfce1690586c3a7d9de85f06e89d5bf2"
  :revdesc "002344eedfce"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
