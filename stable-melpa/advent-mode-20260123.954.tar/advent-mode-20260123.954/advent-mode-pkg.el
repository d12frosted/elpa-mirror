;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20260123.954"
  "Advent of Code mode."
  '((emacs "29.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "b7f134bdeb02ecbe0f1a88ef7d455ffd9c173818"
  :revdesc "b7f134bdeb02"
  :keywords '("lisp"))
