(define-package "eldev" "20220516.2025" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "529427909fb3573867c0488b1785b7be0eaf9586" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
