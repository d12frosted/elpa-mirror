;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260324.946"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "d6a95682684940ca0d9aa31fd7d9a2b7c8c12e02"
  :revdesc "d6a956826849"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
