;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "espotify" "20220121.2057"
  "Spotify access library."
  '((emacs "26.1"))
  :url "https://codeberg.org/jao/espotify"
  :commit "ea6d6021e5acc550560325db2f09198839ee702f"
  :revdesc "ea6d6021e5ac"
  :keywords '("multimedia")
  :authors '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
