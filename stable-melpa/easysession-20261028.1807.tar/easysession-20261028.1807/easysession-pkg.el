;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20261028.1807"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "7953bf66397d0da3c6378b6885cad5ed73993fcc"
  :revdesc "7953bf66397d"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
