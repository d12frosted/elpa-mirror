;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fixed-page-mode" "20230531.929"
  "A fixed page length mode."
  '((emacs "24.3"))
  :url "https://gitlab.com/igorwojnicki/fixed-page-mode"
  :commit "608dd1120d35b02a02570f024c585f7569508586"
  :revdesc "608dd1120d35"
  :keywords '("wp")
  :authors '(("Igor Wojnicki" . "wojnicki@gmail.com"))
  :maintainers '(("Igor Wojnicki" . "wojnicki@gmail.com")))
