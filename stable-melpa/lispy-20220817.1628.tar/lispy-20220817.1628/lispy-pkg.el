(define-package "lispy" "20220817.1628" "vi-like Paredit"
  '((emacs "24.3")
    (ace-window "0.9.0")
    (iedit "0.9.9")
    (swiper "0.13.4")
    (hydra "0.14.0")
    (zoutline "0.2.0"))
  :commit "53b93630d6bd4003038e17ce7b6ad75a41e057cb" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/abo-abo/lispy")
;; Local Variables:
;; no-byte-compile: t
;; End:
