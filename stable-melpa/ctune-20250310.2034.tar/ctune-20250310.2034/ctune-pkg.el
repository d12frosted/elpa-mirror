;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ctune" "20250310.2034"
  "Tune out CC Mode Noise Macros."
  '((emacs "26.1"))
  :url "https://github.com/maurooaranda/ctune"
  :commit "7c26d7af3cd0d6cf4f94deb7f2bf3cf8ed8a1f11"
  :revdesc "7c26d7af3cd0"
  :keywords '("c" "convenience")
  :authors '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers '(("Mauro Aranda" . "maurooaranda@gmail.com")))
