(define-package "meow" "20220212.2112" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "6842c1c3eb4a4b01bd83f47fa97a87a809f81236" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
