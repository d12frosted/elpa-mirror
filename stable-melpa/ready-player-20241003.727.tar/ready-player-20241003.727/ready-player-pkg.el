;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "20241003.727"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "62a44bde9744fee43c050de3e4c0cab2686cf1f9"
  :revdesc "62a44bde9744")
