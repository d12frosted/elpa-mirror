;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260404.2317"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "84f44f784639324a8ef083db3205fad990bdd86e"
  :revdesc "84f44f784639"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
