;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "powerline-evil" "20190603.340"
  "Utilities for better Evil support for Powerline."
  '((evil      "1.0.8")
    (powerline "2.3"))
  :url "https://github.com/johnson-christopher/powerline-evil/"
  :commit "b77e2cf571e9990734f2b30d826f3a362b559fd1"
  :revdesc "b77e2cf571e9"
  :keywords '("evil" "mode-line" "powerline")
  :authors '(("Chris Johnson" . "chris@christophermjohnson.net"))
  :maintainers '(("Chris Johnson" . "chris@christophermjohnson.net")))
