;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "20260805.231"
  "Spaced repetition in plain text."
  '((emacs "26.1"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "6523b4a29b61cd0399110c0d401ed576a58b0d5d"
  :revdesc "6523b4a29b61"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
