;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260917.650"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "755c61a4bffa3d461d4c36d69c9f95cc9e31ea95"
  :revdesc "755c61a4bffa"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
