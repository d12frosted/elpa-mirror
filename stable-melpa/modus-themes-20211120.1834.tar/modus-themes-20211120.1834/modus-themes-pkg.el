(define-package "modus-themes" "20211120.1834" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "007fec26263accb850ef5a08bf65b9eb13a290e4" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
