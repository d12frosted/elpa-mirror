;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250522.344"
  "Mordern HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "c8b695dc99fd096d1c0fb0658957f938bb8ca20e"
  :revdesc "c8b695dc99fd"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
