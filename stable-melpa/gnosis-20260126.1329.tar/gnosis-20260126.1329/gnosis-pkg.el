;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260126.1329"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "54f6d37120a84d94451099f21d17aec1c9ab8ace"
  :revdesc "54f6d37120a8"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
