;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow-tree-sitter" "20251023.1533"
  "Tree-sitter powered motions for Meow."
  '((emacs "29.1")
    (meow  "1.2.0"))
  :url "https://github.com/skissue/meow-tree-sitter"
  :commit "777f744123399b4cd430e1dd08f995d5c43a28ab"
  :revdesc "777f74412339"
  :keywords '("convenience" "files" "languages" "tools")
  :authors '(("Ad" . "me@skissue.xyz"))
  :maintainers '(("Ad" . "me@skissue.xyz")))
