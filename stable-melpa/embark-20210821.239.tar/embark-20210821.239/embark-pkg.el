(define-package "embark" "20210821.239" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "0010c8185253a092a15943913bd5fd6f5764bb4d" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
