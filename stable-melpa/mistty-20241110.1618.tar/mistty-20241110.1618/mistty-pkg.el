;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241110.1618"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "6c5f9baff1ec9235a064616c0c2296ccad03ee21"
  :revdesc "6c5f9baff1ec"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
