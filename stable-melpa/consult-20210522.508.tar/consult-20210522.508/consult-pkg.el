(define-package "consult" "20210522.508" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "6e3626361a4f672b9255fd914f3018267dac3028" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
