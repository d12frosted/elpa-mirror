(define-package "x509-mode" "20220615.743" "View certificates, CRLs and keys using OpenSSL."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "638fe3b78ab46919e2325b3a01c62f45afa4ca91" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
