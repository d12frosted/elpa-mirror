;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darkmine-theme" "20160406.624"
  "Yet another emacs dark color theme."
  ()
  :url "https://github.com/pierre-lecocq/darkmine-theme"
  :commit "7f7e82ca03bcad52911fa41fb3e204e32d6ee63e"
  :revdesc "7f7e82ca03bc"
  :authors '(("Pierre Lecocq" . "pierre.lecocq@gmail.com"))
  :maintainers '(("Pierre Lecocq" . "pierre.lecocq@gmail.com")))
