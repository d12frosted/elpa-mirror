(define-package "dyalog-mode" "20200822.1536" "Major mode for editing Dyalog APL source code"
  '((cl-lib "0.2")
    (emacs "24.3"))
  :commit "f42e49b9dd7ab41f08361185cc25509f19b949a8" :authors
  '(("Joakim Hårsman" . "joakim.harsman@gmail.com"))
  :maintainer
  '("Joakim Hårsman" . "joakim.harsman@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/harsman/dyalog-mode.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
