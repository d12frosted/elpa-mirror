;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-review" "20221206.113"
  "Perform code review from Github, Gitlab, and Bitbucket Cloud."
  '((emacs         "25.1")
    (closql        "1.2.0")
    (magit         "3.0.0")
    (transient     "0.3.7")
    (a             "1.0.0")
    (ghub          "3.5.1")
    (uuidgen       "1.2")
    (deferred      "0.5.1")
    (markdown-mode "2.4")
    (forge         "0.3.0")
    (emojify       "1.2"))
  :url "https://github.com/wandersoncferreira/code-review"
  :commit "a8bb63b53f2a1fd31302c110e668ad7b5c871b34"
  :revdesc "a8bb63b53f2a"
  :keywords '("git" "tools" "vc")
  :authors '(("Wanderson Ferreira" . "https://github.com/wandersoncferreira"))
  :maintainers '(("Wanderson Ferreira" . "wand@hey.com")))
