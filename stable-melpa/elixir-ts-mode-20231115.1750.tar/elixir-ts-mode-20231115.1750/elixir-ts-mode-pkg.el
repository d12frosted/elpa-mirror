(define-package "elixir-ts-mode" "20231115.1750" "Major mode for Elixir with tree-sitter support"
  '((emacs "29.1")
    (heex-ts-mode "1.3"))
  :commit "212dd31f80cdc6343106efef3decc91091a470b6" :authors
  '(("Wilhelm H Kirschbaum"))
  :maintainers
  '(("Wilhelm H Kirschbaum"))
  :maintainer
  '("Wilhelm H Kirschbaum")
  :keywords
  '("elixir" "languages" "tree-sitter")
  :url "https://github.com/wkirschbaum/elixir-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
