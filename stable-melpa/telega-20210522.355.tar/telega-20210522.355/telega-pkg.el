(define-package "telega" "20210522.355" "Telegram client (unofficial)"
  '((emacs "26.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "cc4abaafcafc3078f196397fdde5cbc059958559" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
