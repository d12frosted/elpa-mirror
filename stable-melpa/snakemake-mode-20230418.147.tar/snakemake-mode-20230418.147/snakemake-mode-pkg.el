(define-package "snakemake-mode" "20230418.147" "Major mode for editing Snakemake files"
  '((emacs "26.1")
    (transient "0.3.0"))
  :commit "0c4c5b6a25735ac025ce124ace9f0259eb5198e9" :authors
  '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers
  '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainer
  '("Kyle Meyer" . "kyle@kyleam.com")
  :keywords
  '("tools")
  :url "https://git.kyleam.com/snakemake-mode/about")
;; Local Variables:
;; no-byte-compile: t
;; End:
