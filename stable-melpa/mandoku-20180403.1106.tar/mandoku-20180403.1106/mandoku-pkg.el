(define-package "mandoku" "20180403.1106" "A tool to access repositories of premodern Chinese texts"
  '((org "8")
    (github-clone "20150705.1705"))
  :commit "e3b7678762e9824861b1ce775a94b05b096164f5" :authors
  '(("Christian Wittern" . "cwittern@gmail.com"))
  :maintainer
  '("Christian Wittern" . "cwittern@gmail.com")
  :keywords
  '("convenience")
  :url "http://www.mandoku.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
