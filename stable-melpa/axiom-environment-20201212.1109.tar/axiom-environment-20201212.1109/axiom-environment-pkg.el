(define-package "axiom-environment" "20201212.1109" "An environment for using Axiom/OpenAxiom/FriCAS"
  '((emacs "24.2"))
  :commit "47d6dffc29286badb2b1d7143b219e5c1be15bdb" :keywords
  ("axiom" "openaxiom" "fricas")
  :authors
  (("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  ("Paul Onions" . "paul.onions@acm.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
