(define-package "workroom" "20221122.1938" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0")
    (compat "28.1.2.2"))
  :commit "3b7b17e2ccfa935843c5cd60f9c71a956f9f5c49" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
