(define-package "racket-mode" "20211021.1215" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "9531989a63f9a78dfa23c21f3a16279745805f5d" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
