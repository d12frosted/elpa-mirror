(define-package "racket-mode" "20211021.1215" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "6da1b8e42c17461260e1f2b6227c30542a85089c" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
