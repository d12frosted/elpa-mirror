;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-labeler" "20240827.2337"
  "Simplify equation labeling in LaTeX."
  '((emacs "28.1"))
  :url "https://github.com/X9hRRDys/latex-labeler"
  :commit "6ca15d7dea4f8b2fc0878f6be19438e84061e894"
  :revdesc "6ca15d7dea4f"
  :keywords '("tools"))
