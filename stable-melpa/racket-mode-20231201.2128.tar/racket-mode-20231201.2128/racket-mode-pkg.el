(define-package "racket-mode" "20231201.2128" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "1c11fce1c560d8e89c984b8cb6dfb6703bfda228" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
