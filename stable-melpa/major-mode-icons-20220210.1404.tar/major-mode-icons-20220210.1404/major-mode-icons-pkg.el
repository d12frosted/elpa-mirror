(define-package "major-mode-icons" "20220210.1404" "display icon for major-mode on mode-line."
  '((emacs "24.3")
    (powerline "2.4")
    (all-the-icons "2.3.0"))
  :commit "b0214e0af13cd3691c4d28f03e3108bd98ec7a85" :keywords
  '("frames" "multimedia")
  :url "https://repo.or.cz/major-mode-icons.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
