;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "20260509.344"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "3d124aa6a11267516846665ca7bc7ccab340f0b7"
  :revdesc "3d124aa6a112"
  :keywords '("hypermedia"))
