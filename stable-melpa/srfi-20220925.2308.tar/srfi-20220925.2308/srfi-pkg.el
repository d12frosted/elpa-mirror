(define-package "srfi" "20220925.2308" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "20a1c9b36e99cbfbf70598e2cfaccd960e74c1ce" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
