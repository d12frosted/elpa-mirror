;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20260418.1402"
  "An Org-social client for Emacs."
  '((emacs            "30.1")
    (org              "9.0")
    (request          "0.3.0")
    (seq              "2.20")
    (emojify          "1.2")
    (async-http-queue "0.1"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "613dcf8b65216a32afee1c42bb3273f6c4e1cd91"
  :revdesc "613dcf8b6521"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
