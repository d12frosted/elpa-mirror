;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260324.1627"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "dcdc3566b76459a2f00ab6c34b6157e556e05bec"
  :revdesc "dcdc3566b764"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
