;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "20260721.359"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "f8bf3e3520fea57770411a8aa882985a7f30fe0d"
  :revdesc "f8bf3e3520fe"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
