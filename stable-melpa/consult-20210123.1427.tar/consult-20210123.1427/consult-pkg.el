(define-package "consult" "20210123.1427" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f00fb6dd90d01d96a2f82b0f558a314c3486824f" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
