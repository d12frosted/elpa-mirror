;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250630.552"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "0737ed964800e32e5ca467f7d144590027287bbe"
  :revdesc "0737ed964800"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
