;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-aider" "20250321.450"
  "Org Babel functions for Aider.el integration."
  '((emacs "27.1")
    (org   "9.4"))
  :url "https://github.com/localredhead/ob-aider.el"
  :commit "e97172a031ed7f5e122a2236b5f19b9f63dbb68d"
  :revdesc "e97172a031ed"
  :keywords '("tools" "convenience" "languages" "org" "processes")
  :authors '(("Levi Strope" . "levi.strope@gmail.com"))
  :maintainers '(("Levi Strope" . "levi.strope@gmail.com")))
