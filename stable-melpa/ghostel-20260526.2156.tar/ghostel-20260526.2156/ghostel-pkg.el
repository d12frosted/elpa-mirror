;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260526.2156"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "22e535a6774e8aefede730db74cf133ee8840d97"
  :revdesc "22e535a6774e"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
