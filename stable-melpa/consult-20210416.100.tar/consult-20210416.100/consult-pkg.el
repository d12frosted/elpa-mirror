(define-package "consult" "20210416.100" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "923a34330207ed868b6388acf0f432ae989f1427" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
