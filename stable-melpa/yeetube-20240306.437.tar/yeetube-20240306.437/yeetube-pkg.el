(define-package "yeetube" "20240306.437" "Scrape YouTube - Play with mpv & Download with yt-dlp |"
  '((emacs "27.2")
    (compat "29.1.4.2"))
  :commit "f9feada5c09fa8245f0230696557f7e7ffa266f1" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://thanosapollo.org/projects/yeetube/")
;; Local Variables:
;; no-byte-compile: t
;; End:
