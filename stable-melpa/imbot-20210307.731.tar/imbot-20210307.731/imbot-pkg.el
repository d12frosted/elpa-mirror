(define-package "imbot" "20210307.731" "Automatic system input method switcher"
  '((emacs "25.1"))
  :commit "0588a5dbb4926e09cd19415eaafb6f79168183d8" :keywords
  '("convenience")
  :url "https://github.com/QiangF/imbot")
;; Local Variables:
;; no-byte-compile: t
;; End:
