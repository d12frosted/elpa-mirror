;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soar-mode" "20190503.1843"
  "A major mode for the Soar language."
  ()
  :url "https://github.com/adeschamps/soar-mode"
  :commit "ebb79789cd35530aea2c6d0eb4f4b280e97107d4"
  :revdesc "ebb79789cd35"
  :keywords '("languages" "soar"))
