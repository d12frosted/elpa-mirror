;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "deno-ts-mode" "20230912.202"
  "Major mode for Deno."
  '((emacs "29.1"))
  :url "https://git.sr.ht/~mgmarlow/deno-ts-mode"
  :commit "526b6c00483cd86a028805e31ebd8a4a7000c3da"
  :revdesc "526b6c00483c"
  :keywords '("languages")
  :authors '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainers '(("Graham Marlow" . "info@mgmarlow.com")))
