;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circe" "20260315.1435"
  "Client for IRC in Emacs."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/emacs-circe/circe"
  :commit "f717332348e4b59499dbf60c56155d9f03cd9303"
  :revdesc "f717332348e4"
  :keywords '("irc" "chat" "comm")
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainers '(("Jorgen Schaefer" . "forcer@forcix.cx")))
