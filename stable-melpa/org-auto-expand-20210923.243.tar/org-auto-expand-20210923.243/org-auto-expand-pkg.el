(define-package "org-auto-expand" "20210923.243" "Automatically expand certain headings"
  '((emacs "26.1"))
  :commit "dfb909d9fd0a658df8a05613a5b95b645b855344" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience" "outlines" "org")
  :url "https://github.com/alphapapa/org-auto-expand")
;; Local Variables:
;; no-byte-compile: t
;; End:
