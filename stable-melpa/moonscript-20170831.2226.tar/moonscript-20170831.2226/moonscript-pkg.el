(define-package "moonscript" "20170831.2226" "Major mode for editing MoonScript code"
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "56f90471e2ced2b0a177aed4d8c2f854797e9cc7" :authors
  '(("@GriffinSchneider, @k2052, @EmacsFodder"))
  :maintainer
  '("@GriffinSchneider, @k2052, @EmacsFodder"))
;; Local Variables:
;; no-byte-compile: t
;; End:
