(define-package "modus-themes" "20210104.1412" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "44313b8db352f080d3cce3b9d4fbcdcaccde6487" :authors
  (("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  ("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  ("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
