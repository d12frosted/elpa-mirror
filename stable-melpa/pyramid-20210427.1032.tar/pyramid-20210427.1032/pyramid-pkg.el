(define-package "pyramid" "20210427.1032" "Minor mode for working with pyramid projects"
  '((emacs "25.2")
    (pythonic "0.1.1")
    (tablist "0.70"))
  :commit "66f54f4a9cc9fa81edf768ab433d5b3c5517363c" :authors
  '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainer
  '("Daniel Kraus" . "daniel@kraus.my")
  :keywords
  '("python" "pyramid" "pylons" "convenience" "tools" "processes")
  :url "https://github.com/dakra/pyramid.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
