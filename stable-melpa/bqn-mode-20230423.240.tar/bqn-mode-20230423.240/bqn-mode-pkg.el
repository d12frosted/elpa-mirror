(define-package "bqn-mode" "20230423.240" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "77abd017902f248873cddfbca997954ca500c70f" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
