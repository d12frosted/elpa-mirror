;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260104.1326"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "30.1")
    (cond-let "0.2")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "c2a274cd2b201727e7d1a6af09497f324d492ac7"
  :revdesc "c2a274cd2b20"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
