;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260903.2323"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "f3e522855f586f9a704af0bb4e32c9350170ecbd"
  :revdesc "f3e522855f58"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
