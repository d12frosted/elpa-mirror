;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260122.1719"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "ca9950bb3ae736958ba835bfb35edf8030bc77bd"
  :revdesc "ca9950bb3ae7"
  :keywords '("outlines"))
