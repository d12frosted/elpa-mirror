(define-package "go-translate" "20240529.135" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "2e2212edb5ba982779596b38d283c6b07ee31e2e" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
