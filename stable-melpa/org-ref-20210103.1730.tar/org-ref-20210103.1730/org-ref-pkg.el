(define-package "org-ref" "20210103.1730" "citations, cross-references and bibliographies in org-mode"
  '((dash "2.11.0")
    (htmlize "1.51")
    (helm "1.5.5")
    (helm-bibtex "2.0.0")
    (ivy "0.8.0")
    (hydra "0.13.2")
    (key-chord "0")
    (s "1.10.0")
    (f "0.18.0")
    (pdf-tools "0.7"))
  :commit "68f60ef425b330a72a90b0c8d6a370d096e86e99" :authors
  (("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainer
  ("John Kitchin" . "jkitchin@andrew.cmu.edu")
  :keywords
  ("org-mode" "cite" "ref" "label")
  :url "https://github.com/jkitchin/org-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
