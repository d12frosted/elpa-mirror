;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wollok-mode" "20241012.1950"
  "Major mode for the Wollok programming language."
  '((emacs "24.4"))
  :url "https://github.com/tralph3/wollok-mode"
  :commit "bd52ad66d7c43d7e46f7edd6693619e47aeceef9"
  :revdesc "bd52ad66d7c4"
  :keywords '("wollok" "languages")
  :authors '(("Tomás Ralph" . "tomasralph2000@gmail.com"))
  :maintainers '(("Tomás Ralph" . "tomasralph2000@gmail.com")))
