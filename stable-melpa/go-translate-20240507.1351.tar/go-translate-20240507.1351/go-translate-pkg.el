(define-package "go-translate" "20240507.1351" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "590be2c41581fe72238f037f52c8f3bb899d62ac" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
