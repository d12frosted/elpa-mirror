(define-package "proof-general" "20230407.909" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "911cf014b899212815c2ec8d3e8c8b88be0df57b" :maintainer
  '(nil . "proof-general-maintainers@groupes.renater.fr")
  :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
