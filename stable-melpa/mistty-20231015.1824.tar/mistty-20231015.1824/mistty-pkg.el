(define-package "mistty" "20231015.1824" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "93a7c29f0b26a803f122bc1cffe0bd52c70a529d" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
