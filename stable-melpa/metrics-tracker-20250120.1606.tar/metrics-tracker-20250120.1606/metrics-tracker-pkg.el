;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metrics-tracker" "20250120.1606"
  "Generate reports of personal metrics from diary entries."
  '((emacs "24.4")
    (seq   "2.3"))
  :url "https://github.com/ianxm/emacs-tracker"
  :commit "a58591bad91854f63f539eb4657004f029c1ca24"
  :revdesc "a58591bad918"
  :keywords '("calendar")
  :authors '(("Ian Martins" . "ianxm@jhu.edu"))
  :maintainers '(("Ian Martins" . "ianxm@jhu.edu")))
