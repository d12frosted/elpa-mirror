;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250526.1453"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "92b110510d0c0d5acaa374939bf1ce729a83d8bb"
  :revdesc "92b110510d0c"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
