(define-package "meow" "20211225.621" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "bc1b365bb8a2908983cdcccc49513ab5b2b36325" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
