(define-package "org-index" "20230803.1629" "Ranked and incremental search among selected org-headlines"
  '((org "9.3")
    (dash "2.12")
    (s "1.12")
    (emacs "26.3"))
  :commit "1bf6e8d540774da3880d7c8e78eee15805409470" :authors
  '(("Marc Ihm" . "marc@ihm.name"))
  :maintainers
  '(("Marc Ihm" . "marc@ihm.name"))
  :maintainer
  '("Marc Ihm" . "marc@ihm.name")
  :url "https://github.com/marcIhm/org-index")
;; Local Variables:
;; no-byte-compile: t
;; End:
