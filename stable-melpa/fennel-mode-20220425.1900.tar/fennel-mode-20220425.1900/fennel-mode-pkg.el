(define-package "fennel-mode" "20220425.1900" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "da74dc0c9aca3b25820e19c122e632bab6bf32c6" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
