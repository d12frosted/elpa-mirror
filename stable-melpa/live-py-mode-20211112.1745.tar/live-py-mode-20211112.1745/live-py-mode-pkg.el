(define-package "live-py-mode" "20211112.1745" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "bc3504e4a390f3cbd4bdf35796a02e8616041fdd" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
