(define-package "live-py-mode" "20211112.1745" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "08171929d67827eaf2fdc138b088b0587ec4a70a" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
