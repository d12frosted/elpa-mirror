(define-package "live-py-mode" "20211112.1745" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "beecb04f021d3fc5c995029d3d00e0cdf669e833" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
