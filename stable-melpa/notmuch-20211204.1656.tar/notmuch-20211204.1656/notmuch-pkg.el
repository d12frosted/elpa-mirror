(define-package "notmuch" "20211204.1656" "run notmuch within emacs" 'nil :commit "57f29f4cb1e5ddfca453384954226b47f53e2ea6" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
