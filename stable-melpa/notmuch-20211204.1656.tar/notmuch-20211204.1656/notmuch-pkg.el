(define-package "notmuch" "20211204.1656" "run notmuch within emacs" 'nil :commit "a06b76b9b3c1212b17d2bb170bdd511711f578f8" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
