(define-package "recursion-indicator" "20230909.1633" "Recursion indicator"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "a48146f9146df72a9c4413f3faab9924aa91023f" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience")
  :url "https://github.com/minad/recursion-indicator")
;; Local Variables:
;; no-byte-compile: t
;; End:
