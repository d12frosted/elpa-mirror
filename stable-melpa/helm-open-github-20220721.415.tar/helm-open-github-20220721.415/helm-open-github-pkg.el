;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-open-github" "20220721.415"
  "Utilities of Opening Github Page."
  '((emacs     "24.4")
    (helm-core "3.6.0")
    (gh        "0.8.2"))
  :url "https://github.com/syohex/emacs-helm-open-github"
  :commit "5e6d700d1b484bd6cd44bc30674e96d157870c3f"
  :revdesc "5e6d700d1b48"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
