;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20241213.520"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.8.0"))
  :url "https://github.com/aurtzy/disproject"
  :commit "30ed3967fe8cc0a594b1eb6629eeca234f477680"
  :revdesc "30ed3967fe8c"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
