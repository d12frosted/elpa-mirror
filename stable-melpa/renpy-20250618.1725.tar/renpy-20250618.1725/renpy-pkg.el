;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "renpy" "20250618.1725"
  "Major mode for editing Ren'Py files."
  '((emacs "27.1"))
  :url "https://github.com/Reagankm/renpy-mode"
  :commit "d61a1a0253154604c0f458006b6c1265f04c9b28"
  :revdesc "d61a1a025315"
  :keywords '("languages")
  :authors '(("Dave Love" . "fx@gnu.org")
             ("PyTom" . "pytom@bishoujo.us"))
  :maintainers '(("Reagan Middlebrook" . "reagankm@gmail.com")))
