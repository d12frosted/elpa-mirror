;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clause" "20241020.1144"
  "Functions to move, mark, kill by clause."
  '((emacs         "27.1")
    (mark-thing-at "0.3"))
  :url "https://codeberg.org/martianh/clause.el"
  :commit "e51261495d88e80709443817af3159633c9a2d7b"
  :revdesc "e51261495d88"
  :keywords '("wp" "convenience" "sentences" "text")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
