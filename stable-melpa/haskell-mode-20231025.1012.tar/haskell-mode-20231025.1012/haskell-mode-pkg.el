(define-package "haskell-mode" "20231025.1012" "A Haskell editing mode"
  '((emacs "25.1"))
  :commit "d16c68ccdfdeaee72e033b6f899d9f00649b8830" :keywords
  '("haskell" "cabal" "ghc" "repl" "languages")
  :url "https://github.com/haskell/haskell-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
