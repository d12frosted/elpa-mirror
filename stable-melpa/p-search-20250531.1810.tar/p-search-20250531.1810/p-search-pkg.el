;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "p-search" "20250531.1810"
  "Emacs Search Tool Aggregator."
  '((emacs  "29.1")
    (compat "29.1"))
  :url "https://github.com/zkry/p-search"
  :commit "021da673d130d5d862d778f810679e84e2e00a08"
  :revdesc "021da673d130"
  :keywords '("tools"))
