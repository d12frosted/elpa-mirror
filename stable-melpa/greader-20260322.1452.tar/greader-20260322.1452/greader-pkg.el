;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "20260322.1452"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "20b5343211408dbbf12ff2194472cea50384a5fa"
  :revdesc "20b534321140"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
