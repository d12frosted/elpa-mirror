(define-package "stimmung-themes" "20210430.839" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "eac0f54da5ff116622a6448b68057b45c337f2de" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
