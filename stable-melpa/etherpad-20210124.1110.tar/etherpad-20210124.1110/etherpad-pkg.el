(define-package "etherpad" "20210124.1110" "Interface to the Etherpad API"
  '((emacs "26.1")
    (request "0.3")
    (let-alist "0.0"))
  :commit "6d9c86dac6ab569d1842fcfa8bbe63ee9de8cd71" :authors
  '(("nik gaffney" . "nik@fo.am"))
  :maintainer
  '("nik gaffney" . "nik@fo.am")
  :keywords
  '("comm" "etherpad" "collaborative editing")
  :url "https://github.com/zzkt/ethermacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
