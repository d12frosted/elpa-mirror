(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "c1e82f94aa2883feda752df450130ee204855c09" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
