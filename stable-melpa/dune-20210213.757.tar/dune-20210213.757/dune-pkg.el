(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "f7b56d6e79e96dbfb06120809d17c2ee68289b50" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
