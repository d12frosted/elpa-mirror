(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "0490fd413b81cca473ef5e4fb0a6c876e000e953" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
