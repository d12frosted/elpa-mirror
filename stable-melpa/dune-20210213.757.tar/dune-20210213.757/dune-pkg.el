(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "7f117144f31c44e066323e8cc25609260bca9395" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
