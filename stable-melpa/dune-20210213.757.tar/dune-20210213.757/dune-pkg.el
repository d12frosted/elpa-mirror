(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "000d62028ae03c4fe3493a02add7efbdadd6167e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
