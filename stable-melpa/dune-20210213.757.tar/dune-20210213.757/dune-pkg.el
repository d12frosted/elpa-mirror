(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "c5ec756220e93c1e5817e0666c803177a5f74b3a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
