(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "0a454e3c0628d963f1b60e872b9a149713ea884f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
