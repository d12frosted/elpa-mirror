(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "75ecfe34216dd07b339d2b9027f7b6a507151418" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
