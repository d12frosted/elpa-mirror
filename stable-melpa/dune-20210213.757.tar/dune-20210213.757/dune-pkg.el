(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "5ddd53273a97efbefe4ebe92a522a026096f1ee5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
