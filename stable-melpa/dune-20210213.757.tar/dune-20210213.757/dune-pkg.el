(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "c04fef6bd6f6d2083a27b3d62f0cb3697fbd83f9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
