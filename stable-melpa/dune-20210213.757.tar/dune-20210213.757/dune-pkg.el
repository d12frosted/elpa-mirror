(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "52eca926d717f641d228b8d93b233031e6bcba8c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
