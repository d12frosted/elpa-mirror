(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "e5b9b862479649c73111568548570576bb3cd4b3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
