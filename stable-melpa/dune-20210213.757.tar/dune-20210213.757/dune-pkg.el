(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "8b4f5e4476ca8d3b61d505ed113a697cc3f03cfc" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
