(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "98678a729df32ce154c0896b66120c44fa184de2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
