(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "8fb4a512d03482de0c6977b1975c06f71c94e093" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
