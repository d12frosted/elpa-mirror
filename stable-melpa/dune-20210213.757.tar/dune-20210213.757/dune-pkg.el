(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "b4cbb644c48a00e82003f7adfb1c32c32198a341" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
