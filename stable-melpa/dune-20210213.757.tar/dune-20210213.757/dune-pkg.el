(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "85b3f609e3292a1ba2ba2cf25df6076f49b2c092" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
