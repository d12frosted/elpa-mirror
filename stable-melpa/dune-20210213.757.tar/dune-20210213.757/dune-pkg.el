(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "0960ce79ea789cb9da971ff1df6e65bb4897ec44" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
