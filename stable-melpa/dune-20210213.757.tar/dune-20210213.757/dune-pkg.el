(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "7310d10a9c3c5a4cffa8fbcc6e0292255304c450" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
