(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "6481d0fac8ebf670957de0916b271562f50c954c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
