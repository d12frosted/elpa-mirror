(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "e1564823e86b797d41b2bb833c1f877f165df8d8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
