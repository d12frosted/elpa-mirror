(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "afd9c3e197980dffe81efa534f2c69fa49b43365" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
