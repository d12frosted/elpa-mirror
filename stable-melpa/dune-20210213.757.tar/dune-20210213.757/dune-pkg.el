(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "6997cbe893c3f36128c4061e53559edbb54634ce" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
