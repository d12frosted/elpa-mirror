(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "ef05a2ea3053aea8ae78a368d4a2c3d556d61234" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
