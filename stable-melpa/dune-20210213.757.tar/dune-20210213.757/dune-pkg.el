(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "7ca4a8c9e86ecbaf00cfc492c40a5bdeeb868dc9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
