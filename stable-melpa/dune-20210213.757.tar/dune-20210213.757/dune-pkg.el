(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "5d8c68b3982577c3f7954ec1b608549cf84689b8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
