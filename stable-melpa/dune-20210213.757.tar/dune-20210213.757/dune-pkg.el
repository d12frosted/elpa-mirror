(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "8a3b9787da51379f31a02b5598819727737b8f82" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
