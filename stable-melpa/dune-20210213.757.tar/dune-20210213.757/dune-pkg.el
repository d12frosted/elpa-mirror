(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "c70836069f2772c89f4b1848788183653a25d64b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
