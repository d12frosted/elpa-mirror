(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "03435a3608a703bac5b65bfa84c97d91dcc28a4f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
