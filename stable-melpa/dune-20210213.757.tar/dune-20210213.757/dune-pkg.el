(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "2d20e430437a09fb438d7294672e4c7f30a68504" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
