(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "ec8cf2c097c8f1306a8e8545ba272eb8207ebdb8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
