(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "7d5f6cde3c29b9421681d00de237c36a403e209e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
