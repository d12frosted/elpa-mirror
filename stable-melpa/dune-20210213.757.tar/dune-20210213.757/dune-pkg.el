(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "42ece423c63ae81ef003472af8987b7de2111191" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
