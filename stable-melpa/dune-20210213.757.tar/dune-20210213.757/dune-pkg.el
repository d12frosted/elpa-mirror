(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "f55a1dad33f41e136937e8e0b241cb5aca94a0c1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
