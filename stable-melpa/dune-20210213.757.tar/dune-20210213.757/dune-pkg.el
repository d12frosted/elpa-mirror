(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "0693738306e5cbcbc4d64ea68ead9fbe650d32ea" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
