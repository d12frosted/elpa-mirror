(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "81e4e403c1e45570a187948d579727ee8e362d76" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
