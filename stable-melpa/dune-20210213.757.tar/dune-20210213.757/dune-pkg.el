(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "45677db08e9c5065a776615e1a3f7e0880897dd9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
