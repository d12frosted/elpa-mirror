(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "ddf1982cc9d79c099bd6de2c1c4279eeb58ad795" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
