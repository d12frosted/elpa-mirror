(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "706accf8668aa59a1989ffa51c2c376e5d5ecdd3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
