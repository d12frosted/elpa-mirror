(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "9a3777f5c423a55da02a39e5ba485f2a9fae10f6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
