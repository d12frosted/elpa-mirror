(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "0501664a7d40755d0d0aaed39fb88b50e44bcfa2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
