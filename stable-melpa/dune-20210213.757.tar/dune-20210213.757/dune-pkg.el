(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "65e04ba5646e8ba4a033b099c92fbda9b9aca341" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
