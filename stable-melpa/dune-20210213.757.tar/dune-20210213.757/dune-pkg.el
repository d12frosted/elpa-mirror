(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "279ec06008454d8496c62935c976d92a0f9032cd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
