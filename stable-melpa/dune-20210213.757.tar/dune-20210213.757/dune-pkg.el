(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "2301025b9ef8567b421c69b3cbb9b97e5e1011a8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
