(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "756f2a69e33cea60dcffe57767e4df248ad7bafa" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
