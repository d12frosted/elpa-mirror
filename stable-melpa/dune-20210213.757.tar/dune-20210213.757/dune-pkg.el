(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "a6b5d41bb56836c42cef7e66339e678a511acb9c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
