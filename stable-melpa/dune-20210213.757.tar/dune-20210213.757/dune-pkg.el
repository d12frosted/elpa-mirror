(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "f8d9dae338b60c61bcabe035293c7fb6d154c4a1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
