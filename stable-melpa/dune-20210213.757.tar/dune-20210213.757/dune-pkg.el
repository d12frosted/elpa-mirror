(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "c7a3145dd02e234df787e9d5d663f97c2b10d017" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
