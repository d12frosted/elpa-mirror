(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "9a5e3c8b566a7e7e2f7a8be4ed5fc1ac87614212" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
