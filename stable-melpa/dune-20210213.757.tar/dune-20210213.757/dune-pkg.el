(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "dedd7039d65e0d801706a1d9c12e895f4b5fcdc3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
