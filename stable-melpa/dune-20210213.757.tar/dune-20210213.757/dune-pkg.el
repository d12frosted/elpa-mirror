(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "a8c6ed8bb27af690955e51eabbef0382b7e2d41e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
