(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "9f31bd9ad02238e2db10073140d204e2430cff0b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
