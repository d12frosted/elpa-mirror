(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "0d8c8834ec44492df27a0b80398cddb64707bd2d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
