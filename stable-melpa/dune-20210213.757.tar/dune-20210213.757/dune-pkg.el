(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "65404cf973aa7ffc0e9dd7d05c9dd3709c7db2d4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
