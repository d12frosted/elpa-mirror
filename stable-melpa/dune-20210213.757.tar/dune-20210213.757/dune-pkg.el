(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "974c863e1518e90cf6e334e242d98685c4a88e17" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
