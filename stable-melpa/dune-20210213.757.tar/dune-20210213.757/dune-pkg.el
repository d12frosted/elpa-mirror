(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "77fc494f14ad07eecb4f230aa5f9aefcff2ba3ac" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
