(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "904cbe5ce8d5c1d9d68e6c2697709a5abd036f3f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
