(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "4a8fa5757277be6e9bbd3698fd4d4336dadae520" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
