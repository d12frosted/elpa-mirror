(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "4226f7a1061fff57297111d2039235068892203c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
