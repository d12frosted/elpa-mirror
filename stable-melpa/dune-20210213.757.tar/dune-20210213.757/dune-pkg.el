(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "55acb0c661c50196cac11ea92dc6b73057668247" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
