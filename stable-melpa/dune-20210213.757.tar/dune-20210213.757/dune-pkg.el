(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "4f973397f1dfaa2417f8d62624b78631a3fde7bb" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
