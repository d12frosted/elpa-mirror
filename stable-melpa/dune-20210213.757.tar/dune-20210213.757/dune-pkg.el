(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "76a2ae6525348f8a70e2c36725703d66a27133c3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
