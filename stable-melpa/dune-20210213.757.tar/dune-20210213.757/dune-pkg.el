(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "8f84cd1d15976629abaccd8d3bfa2052edff8456" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
