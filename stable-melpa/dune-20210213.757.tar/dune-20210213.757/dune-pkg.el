(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "62ca6a6a71bf694d6262a36f2c97d4a2edeb42ff" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
