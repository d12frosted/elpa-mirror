(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "d2d0336319379d68bd1ca79572bd5d7573f10aca" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
