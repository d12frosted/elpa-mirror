(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "093cb1e8cacee1fc1aa9c8af89c20eeb98189139" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
