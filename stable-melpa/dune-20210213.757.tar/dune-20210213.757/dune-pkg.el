(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "927d1dce42373cb2cad8feef9d14a8242fafc097" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
