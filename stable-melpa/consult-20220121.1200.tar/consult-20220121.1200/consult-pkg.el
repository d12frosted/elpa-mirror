(define-package "consult" "20220121.1200" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "d44696b58b65eff6b1af5d674456bfa2b20a39fa" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
