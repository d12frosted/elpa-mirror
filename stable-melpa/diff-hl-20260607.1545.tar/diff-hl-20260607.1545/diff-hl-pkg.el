;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260607.1545"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "8348feb89b133d9064bab8b0c4d57aab63ea5f1a"
  :revdesc "8348feb89b13"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
