(define-package "mew" "20180607.546" "Messaging in the Emacs World" 'nil :commit "6a5d6bb11e5e1a239ee7db114a0e76b40e5a247e" :authors
  '(("Kazu Yamamoto" . "Kazu@Mew.org"))
  :maintainer
  '("Kazu Yamamoto" . "Kazu@Mew.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
