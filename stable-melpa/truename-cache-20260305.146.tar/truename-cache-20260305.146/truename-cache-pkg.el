;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260305.146"
  "Efficiently de-dup file-names."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "810a78e532c9743d1484a4e0a2a84b2f7d68e054"
  :revdesc "810a78e532c9"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
