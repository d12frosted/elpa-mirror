(define-package "detached" "20221128.927" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "12421301d2788bbff8ae9411d7296dc0b68f4300" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
