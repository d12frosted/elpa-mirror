;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260719.835"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7e5162d610a4e951aeedbac356f8ae6aa26d0133"
  :revdesc "7e5162d610a4")
