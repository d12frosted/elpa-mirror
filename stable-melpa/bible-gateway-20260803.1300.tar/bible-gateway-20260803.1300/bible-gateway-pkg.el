;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260803.1300"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "7c17a93324351024ad36ebb522b8b566d6b7a920"
  :revdesc "7c17a9332435"
  :keywords '("convenience" "comm" "hypermedia"))
