;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20260104.1157"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (markdown-mode  "2.0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "581a6d61ecc6d627676f946f9703b0fc74685551"
  :revdesc "581a6d61ecc6"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
