;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dag-draw" "20251218.1333"
  "Draw directed graphs using the GKNV algorithm."
  '((emacs "26.1")
    (dash  "2.19.1")
    (ht    "2.3"))
  :url "https://codeberg.org/trevoke/dag-draw.el"
  :commit "0c10afdff9f1ebfeea242e921fa22bb385cdf899"
  :revdesc "0c10afdff9f1"
  :keywords '("tools" "extensions"))
