;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20251101.1054"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "4d6270a06d335b63907dbcedcf4c4661cc830c31"
  :revdesc "4d6270a06d33"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
