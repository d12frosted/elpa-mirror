;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260511.1313"
  "Lets your agent talk to Emacs."
  '((emacs       "30.1")
    (http-server "0.1.0")
    (elisp-refs  "1.6"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "fe4b47f919ab6dc237abb5baa206278853765a3d"
  :revdesc "fe4b47f919ab"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
