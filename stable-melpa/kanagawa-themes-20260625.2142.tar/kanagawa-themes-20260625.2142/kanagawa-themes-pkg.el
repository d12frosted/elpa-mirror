;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kanagawa-themes" "20260625.2142"
  "Elegant theme inspired by The Great Wave off Kanagawa."
  '((emacs "24.3"))
  :url "https://github.com/Fabiokleis/kanagawa-emacs"
  :commit "fe06241196bf9c77df751cfd74a984b5d8a45ba4"
  :revdesc "fe06241196bf"
  :keywords '("themes" "faces")
  :authors '(("Mrjtjmn" . "meritamen@sdf.org"))
  :maintainers '(("Fabio Kleis" . "fabiohkrc@gmail.com")
                 ("Mrjtjmn" . "meritamen@sdf.org")))
