(define-package "dir-treeview" "20221027.150" "A directory tree browser and simple file manager"
  '((emacs "24.4")
    (treeview "1.1.1"))
  :commit "45979225edd996ee0c26dd029ecde30ad7e7e781" :authors
  '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainer
  '("Tilman Rassy" . "tilman.rassy@googlemail.com")
  :keywords
  '("tools" "convenience" "files")
  :url "https://github.com/tilmanrassy/emacs-dir-treeview")
;; Local Variables:
;; no-byte-compile: t
;; End:
