;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260331.1929"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "3f547f29ecfe80ecda6bbab9d89fd032d74bc5d3"
  :revdesc "3f547f29ecfe"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
