(define-package "keg" "20220913.1034" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "56a9c191da6adb293bb8a1abcc04414ae5f0748a" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
