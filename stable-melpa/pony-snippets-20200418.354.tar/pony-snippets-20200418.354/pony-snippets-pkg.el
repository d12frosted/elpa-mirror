(define-package "pony-snippets" "20200418.354" "Yasnippets for Pony"
  '((yasnippet "0.8.0"))
  :commit "44fe78228519b3adec0c50c7326187b54bb41846" :keywords
  '("snippets" "pony")
  :url "https://github.com/seantallen/pony-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
