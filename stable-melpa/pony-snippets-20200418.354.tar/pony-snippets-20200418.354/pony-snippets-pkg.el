(define-package "pony-snippets" "20200418.354" "Yasnippets for Pony"
  '((yasnippet "0.8.0"))
  :commit "81a1348f81b0d8a3097d1ca3f2fb2f57964d56d6" :keywords
  '("snippets" "pony")
  :url "https://github.com/seantallen/pony-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
