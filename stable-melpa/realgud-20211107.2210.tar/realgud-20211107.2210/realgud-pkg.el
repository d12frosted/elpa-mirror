(define-package "realgud" "20211107.2210" "A modular front-end for interacting with external debuggers"
  '((load-relative "1.3.1")
    (loc-changes "1.2")
    (test-simple "1.3.0")
    (emacs "25"))
  :commit "45f7e4409470abf964c7cb1d526248e4fa7078e0" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :keywords
  '("debugger" "gdb" "python" "perl" "go" "bash" "zsh" "bashdb" "zshdb" "remake" "trepan" "perldb" "pdb")
  :url "https://github.com/realgud/realgud/")
;; Local Variables:
;; no-byte-compile: t
;; End:
