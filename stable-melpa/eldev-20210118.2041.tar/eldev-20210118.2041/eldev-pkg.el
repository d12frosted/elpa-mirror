(define-package "eldev" "20210118.2041" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "dec5f456becab68c6069ac8cd7c4e7339cfc450d" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
