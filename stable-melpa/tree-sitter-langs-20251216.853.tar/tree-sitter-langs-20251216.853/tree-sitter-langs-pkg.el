;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-langs" "20251216.853"
  "Grammar bundle for tree-sitter."
  '((emacs       "25.1")
    (tree-sitter "0.15.0"))
  :url "https://github.com/emacs-tree-sitter/tree-sitter-langs"
  :commit "32a631db5df3b47ee046b294704e76356fed3613"
  :revdesc "32a631db5df3"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
