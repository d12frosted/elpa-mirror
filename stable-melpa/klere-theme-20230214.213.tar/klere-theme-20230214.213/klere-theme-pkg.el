(define-package "klere-theme" "20230214.213" "A dark theme with lambent color highlights and incremental grays"
  '((emacs "24"))
  :commit "61d2cd649a1cf57ce61063f76b395f21f358372e" :authors
  '(("Wamm K. D." . "jaft.r@outlook.com"))
  :maintainers
  '(("Wamm K. D." . "jaft.r@outlook.com"))
  :maintainer
  '("Wamm K. D." . "jaft.r@outlook.com")
  :url "https://codeberg.org/WammKD/emacs-klere-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
