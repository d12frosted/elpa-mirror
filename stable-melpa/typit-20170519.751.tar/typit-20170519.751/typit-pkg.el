(define-package "typit" "20170519.751" "Typing game similar to tests on 10 fast fingers"
  '((emacs "24.4")
    (f "0.18")
    (mmt "0.1.1"))
  :commit "a4e3147dedac5535bdc8b06aca00f34f14f26e35" :authors
  '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainer
  '("Mark Karpov" . "markkarpov92@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/mrkkrp/typit")
;; Local Variables:
;; no-byte-compile: t
;; End:
