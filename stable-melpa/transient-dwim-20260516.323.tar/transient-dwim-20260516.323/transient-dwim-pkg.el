;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-dwim" "20260516.323"
  "Useful preset transient commands."
  '((emacs     "28.1")
    (transient "0.1"))
  :url "https://github.com/conao3/transient-dwim.el"
  :commit "f8751dba53ad052f2292a4de2491053dea51b6cc"
  :revdesc "f8751dba53ad"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
