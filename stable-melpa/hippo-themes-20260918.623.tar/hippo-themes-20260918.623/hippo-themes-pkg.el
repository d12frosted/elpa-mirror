;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hippo-themes" "20260918.623"
  "Hippo color theme."
  '((emacs "24.1"))
  :url "https://github.com/kimim/emacs-hippo-theme"
  :commit "d03228c028148cac69c05f1d1aa46b68041940e2"
  :revdesc "d03228c02814"
  :keywords '("faces" "local" "color" "theme"))
