;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260125.1532"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "723ec36903a3470ac4c43dced7df4f4b2bd841e0"
  :revdesc "723ec36903a3"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
