(define-package "fuel" "20180224.2211" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "7999e72aecc3c5bc4019d43dc4697f49678cc3b4")
;; Local Variables:
;; no-byte-compile: t
;; End:
