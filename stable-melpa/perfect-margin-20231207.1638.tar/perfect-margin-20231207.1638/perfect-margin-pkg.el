(define-package "perfect-margin" "20231207.1638" "Auto center windows, works with line numbers"
  '((emacs "24.3"))
  :commit "593a492978b73ce7d2f86c43bbd692b918941e49" :authors
  '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainers
  '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainer
  '("Randall Wang" . "randall.wjz@gmail.com")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/mpwang/perfect-margin")
;; Local Variables:
;; no-byte-compile: t
;; End:
