(define-package "ellama" "20240629.921" "Tool for interacting with LLMs"
  '((emacs "28.1")
    (llm "0.6.0")
    (spinner "1.7.4"))
  :commit "eef3840384dd5b369a07036c776f93df6d8c6641" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
