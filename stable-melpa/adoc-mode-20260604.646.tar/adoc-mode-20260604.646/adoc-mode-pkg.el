;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260604.646"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "d1a03364d9dfd388a9789a417b623ddec15dc43a"
  :revdesc "d1a03364d9df"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
