(define-package "jinx" "20230327.1943" "Enchanted Just-in-time Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "68b579d715c4be5a255852130b9009151fb0c41e" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
