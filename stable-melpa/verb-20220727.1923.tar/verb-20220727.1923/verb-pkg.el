(define-package "verb" "20220727.1923" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "e3b3c146d7bf8fb12295338aded6a96ff4fb1752" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
