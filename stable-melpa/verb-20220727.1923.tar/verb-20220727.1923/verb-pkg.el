(define-package "verb" "20220727.1923" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "aa12067ba3c34749c41bf5247f4bda1c68625110" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
