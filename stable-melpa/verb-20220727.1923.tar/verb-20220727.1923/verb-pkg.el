(define-package "verb" "20220727.1923" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "89006a65946faa5fa7136f7ceba09cd9059899c4" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
