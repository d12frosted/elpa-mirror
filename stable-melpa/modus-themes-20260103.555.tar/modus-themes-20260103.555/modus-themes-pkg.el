;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260103.555"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "53fa9fd23d78a7ea97a60e562fc363b9b48653a6"
  :revdesc "53fa9fd23d78"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
