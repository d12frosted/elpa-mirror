(define-package "run-command-recipes" "20220825.1846" "This is collection of recipes to `run-command'"
  '((emacs "25.1")
    (dash "2.18.0")
    (f "0.20.0")
    (run-command "0.1.0")
    (s "1.12.0")
    (ht "2.4"))
  :commit "79668110a6b4a7ec4c5d2eb08b1c42dfe35f189e" :authors
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainer
  '("semenInRussia" . "hrams205@gmail.com")
  :keywords
  '("extensions" "run-command")
  :url "https://github.com/semenInRussia/emacs-run-command-recipes")
;; Local Variables:
;; no-byte-compile: t
;; End:
