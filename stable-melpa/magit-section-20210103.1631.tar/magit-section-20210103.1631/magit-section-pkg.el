(define-package "magit-section" "20210103.1631" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "9a96de26ec3772a3e374351738e911ac18e3e6de" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
