(define-package "magit-section" "20210103.1631" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "1773f34b8fad26e0dfbb1a83134adad30535e38a" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
