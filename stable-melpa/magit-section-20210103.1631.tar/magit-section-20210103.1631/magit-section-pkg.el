(define-package "magit-section" "20210103.1631" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "0390cebda94e0b2937f7c56a9b0c676dabd12d44" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
