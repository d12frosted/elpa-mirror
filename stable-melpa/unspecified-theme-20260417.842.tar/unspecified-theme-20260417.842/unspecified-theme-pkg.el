;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unspecified-theme" "20260417.842"
  "Theme that unspecifies all attributes of all faces."
  '((emacs      "25")
    (most-faces "0.0.3"))
  :url "https://codeberg.org/mekeor/unspecified-theme"
  :commit "50f87d04741e3fd6404c629a647299ae9e4f2f1d"
  :revdesc "50f87d04741e"
  :keywords '("faces" "theme")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
