;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lazy" "20260128.1547"
  "Lazy evaluation library."
  '((emacs "25"))
  :url "https://github.com/conao3/lazy.el"
  :commit "c9c70fb7f157148e9d08462e93240ada73e365ae"
  :revdesc "c9c70fb7f157"
  :keywords '("lisp" "lazy")
  :authors '(("chuntaro" . "chuntaro@sakura-games.jp"))
  :maintainers '(("conao3" . "conao3@gmail.com")))
