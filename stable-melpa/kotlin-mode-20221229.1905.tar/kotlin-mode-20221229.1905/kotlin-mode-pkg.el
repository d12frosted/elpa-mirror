(define-package "kotlin-mode" "20221229.1905" "Major mode for kotlin"
  '((emacs "24.3"))
  :commit "ff4637c4eaaa6874cebb7de3e2cf5d674fa9c33c" :authors
  '(("Shodai Yokoyama" . "quantumcars@gmail.com"))
  :maintainer
  '("Shodai Yokoyama" . "quantumcars@gmail.com")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
