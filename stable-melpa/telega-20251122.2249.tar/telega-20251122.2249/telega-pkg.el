;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251122.2249"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "e88f8b98f7ca8c1ffed9a17ee726bd1628dda057"
  :revdesc "e88f8b98f7ca"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
