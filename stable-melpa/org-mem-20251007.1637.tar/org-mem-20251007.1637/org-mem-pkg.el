;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20251007.1637"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.8")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "24011b0a8e6396f50d0914474541736582b9013c"
  :revdesc "24011b0a8e63"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
