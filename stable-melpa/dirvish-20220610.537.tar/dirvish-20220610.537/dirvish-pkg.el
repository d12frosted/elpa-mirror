(define-package "dirvish" "20220610.537" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "28aba79c96a4274c0d5f820a346153510c74fe9a" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
