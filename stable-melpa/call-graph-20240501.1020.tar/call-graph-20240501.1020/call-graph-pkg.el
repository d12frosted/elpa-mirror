(define-package "call-graph" "20240501.1020" "Generate call graph for c/c++ functions"
  '((emacs "26.1")
    (hierarchy "0.7.0")
    (tree-mode "1.0.0")
    (ivy "0.10.0")
    (beacon "1.3.4"))
  :commit "2201fade75f537e9d085068d9b868a85160c9287" :authors
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainer
  '("Huming Chen" . "chenhuming@gmail.com")
  :keywords
  '("programming" "convenience")
  :url "https://github.com/beacoder/call-graph")
;; Local Variables:
;; no-byte-compile: t
;; End:
