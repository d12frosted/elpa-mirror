(define-package "phpactor" "20240407.1015" "Interface to Phpactor"
  '((emacs "25.1")
    (f "0.17")
    (php-runtime "0.2")
    (composer "0.2.0")
    (async "1.9.3"))
  :commit "e488ed4c46489861c15d83a43e70eb7c352adc09" :authors
  '(("USAMI Kenta" . "tadsan@zonu.me")
    ("Mikael Kermorgant" . "mikael@kgtech.fi"))
  :maintainers
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("tools" "php")
  :url "https://github.com/emacs-php/phpactor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
