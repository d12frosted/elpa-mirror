;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20260904.1509"
  "Light green color theme."
  ()
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "ab5774f5e615cbf8e4258c7a58da77ad17905a73"
  :revdesc "ab5774f5e615")
