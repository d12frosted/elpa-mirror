;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260706.1314"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "67377e9e716c97fe79252e65ffa0ebdec10c56ba"
  :revdesc "67377e9e716c"
  :keywords '("languages"))
