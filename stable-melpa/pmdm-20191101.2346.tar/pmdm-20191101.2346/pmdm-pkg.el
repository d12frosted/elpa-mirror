;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pmdm" "20191101.2346"
  "Poor man's desktop-mode alternative."
  ()
  :url "https://hg.serna.eu/emacs/pmdm"
  :commit "6d2af9f9e88e6c91eb74dafaddb5f009e1de4907"
  :revdesc "6d2af9f9e88e"
  :authors '(("Iñigo Serna" . "inigoserna@gmx.com"))
  :maintainers '(("Iñigo Serna" . "inigoserna@gmx.com")))
