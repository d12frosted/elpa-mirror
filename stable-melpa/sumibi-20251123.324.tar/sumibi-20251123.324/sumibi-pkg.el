;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20251123.324"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (mozc           "0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "b360b7ad9b6cc9b935cdc5a73ddb40e5b3aae7dc"
  :revdesc "b360b7ad9b6c"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
