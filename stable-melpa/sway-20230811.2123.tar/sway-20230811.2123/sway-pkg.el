(define-package "sway" "20230811.2123" "Communication with the Sway window manager"
  '((emacs "27.1"))
  :commit "efac743cb0cf0863d220a2ff8bafa53d853eb6cb" :authors
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainers
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainer
  '("Thibault Polge" . "thibault@thb.lt")
  :keywords
  '("frames")
  :url "https://github.com/thblt/sway.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
