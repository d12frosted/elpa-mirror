(define-package "literate-starter-kit" "20150730.1854" "A literate starter kit to configure Emacs using Org-mode files."
  '((emacs "24.3"))
  :commit "6dce1d01781966c14558aa553cfc85008c06e115")
;; Local Variables:
;; no-byte-compile: t
;; End:
