(define-package "posframe" "20211025.617" "Pop a posframe (just a frame) at point"
  '((emacs "26"))
  :commit "2c2db2944040464800ed9cdcd16d2e9905135234" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
