(define-package "octicons" "20151101.340" "octicons utility"
  '((cl-lib "0.5"))
  :commit "229286a6166dba8ddabc8c4d338798c6cd3cf67d" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-octicons")
;; Local Variables:
;; no-byte-compile: t
;; End:
