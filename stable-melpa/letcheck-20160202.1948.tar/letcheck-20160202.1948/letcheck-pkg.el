;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "letcheck" "20160202.1948"
  "Check the erroneous assignments in let forms."
  ()
  :url "https://github.com/Fuco1/letcheck"
  :commit "edf188ca2f85349e971b83f164c6484264e79426"
  :revdesc "edf188ca2f85"
  :keywords '("convenience")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
