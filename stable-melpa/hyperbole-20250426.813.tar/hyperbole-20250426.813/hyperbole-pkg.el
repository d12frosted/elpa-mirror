;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250426.813"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e6401cb89d90981b19c88b3bc1c634aac15a7794"
  :revdesc "e6401cb89d90"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
