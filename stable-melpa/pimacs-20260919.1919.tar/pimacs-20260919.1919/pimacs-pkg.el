;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260919.1919"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "28f9eeaf25766119814bf9a8cd3bc804928c17d3"
  :revdesc "28f9eeaf2576"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
