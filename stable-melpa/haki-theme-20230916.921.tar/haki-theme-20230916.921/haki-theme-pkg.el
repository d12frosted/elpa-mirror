(define-package "haki-theme" "20230916.921" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "af6a3464f05227f2b9bdfcc3290063a7a5a11808" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
