;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250527.713"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "7185f01296c2599b1ebc6eb326ccc14f95c7a131"
  :revdesc "7185f01296c2"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
