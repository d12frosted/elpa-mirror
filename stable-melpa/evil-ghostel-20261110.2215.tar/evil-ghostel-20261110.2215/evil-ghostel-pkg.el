;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20261110.2215"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "c70c72c9aec57fc019847ec7b9ef4dfc256d1580"
  :revdesc "c70c72c9aec5"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
