;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "20260918.554"
  "Grammar and spell checking for LaTeX, Markdown, Org and more."
  '((emacs "29.1"))
  :url "https://github.com/ltex-plus/emacs-ltex-plus"
  :commit "ab94bdf86568c75dee22dd4b2af7b19361ad8549"
  :revdesc "ab94bdf86568"
  :keywords '("lsp" "grammar" "spelling" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
