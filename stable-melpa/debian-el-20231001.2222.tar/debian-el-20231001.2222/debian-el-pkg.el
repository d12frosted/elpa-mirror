(define-package "debian-el" "20231001.2222" "Emacs helpers specific to Debian users" 'nil :commit "b02428b9be806a62282d7a46aaf7e6be0b617eae")
;; Local Variables:
;; no-byte-compile: t
;; End:
