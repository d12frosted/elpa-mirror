(define-package "debian-el" "20231003.737" "Emacs helpers specific to Debian users" 'nil :commit "eb842697b4a7d04207e7e447d640873c6658a6f1")
;; Local Variables:
;; no-byte-compile: t
;; End:
