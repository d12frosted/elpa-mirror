(define-package "detached" "20220907.929" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "93db4748760a00a750f832ed03a9f9406d10d373" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
