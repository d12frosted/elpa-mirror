(define-package "org-node" "20240924.724" "Link org-id entries into a network"
  '((emacs "28.1")
    (compat "30")
    (llama "0"))
  :commit "3d7d68e9035ab3acb4cfd59327b82a3dda275ace" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node")
;; Local Variables:
;; no-byte-compile: t
;; End:
