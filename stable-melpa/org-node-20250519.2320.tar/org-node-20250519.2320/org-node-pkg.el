;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250519.2320"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.11.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "1eab4ff704a66e0d3c962fa1ecefca46264e8e7d"
  :revdesc "1eab4ff704a6"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
