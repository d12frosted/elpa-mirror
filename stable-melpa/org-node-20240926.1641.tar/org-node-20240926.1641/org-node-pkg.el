(define-package "org-node" "20240926.1641" "Link org-id entries into a network"
  '((emacs "28.1")
    (compat "30")
    (llama "0"))
  :commit "9c9a030c000842464e2292b30e3347c0cb8ec15c" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node")
;; Local Variables:
;; no-byte-compile: t
;; End:
