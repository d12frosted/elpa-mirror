(define-package "consult" "20210518.948" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "5435c1dd203706c3e9693e46757ba23f5e0b66b4" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
