;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20241219.829"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.0.0.0")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "03ef2e75665fe53d377bba5b72bde3a317d62ebd"
  :revdesc "03ef2e75665f"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
