(define-package "racket-mode" "20220421.1826" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "b4c65d1ae24db5156a2db1dd1762de774a03c49a" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
