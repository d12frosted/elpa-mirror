;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260813.1716"
  "Emacs Client for Pi."
  '((emacs         "29.1")
    (compat        "31.0")
    (markdown-mode "2.8")
    (timeout       "2.1.7")
    (pcre2el       "1.12")
    (spinner       "1.7")
    (transient     "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "243dab9c679bbe8f21e03e1556ea7bb6acdd85f5"
  :revdesc "243dab9c679b"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
