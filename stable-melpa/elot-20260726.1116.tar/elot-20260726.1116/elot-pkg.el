;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "20260726.1116"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "0d436ba4e8be08163f9661e0b8568559bea68ab3"
  :revdesc "0d436ba4e8be"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
