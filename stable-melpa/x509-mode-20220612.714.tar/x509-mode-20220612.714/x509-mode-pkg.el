(define-package "x509-mode" "20220612.714" "View certificates, CRLs and keys using OpenSSL."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "a064f1bfb94e0bca19ef67da2ac9c4be8537a00d" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
