(define-package "selectrum" "20210214.2202" "Easily select item from list"
  '((emacs "25.1"))
  :commit "50718266868a8a8fddf52ccaa8bf5ab661f490fd" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
