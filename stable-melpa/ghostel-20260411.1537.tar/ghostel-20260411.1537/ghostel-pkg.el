;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260411.1537"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "c851d4878ff8ad22772ecb8055b04477f0bfe6be"
  :revdesc "c851d4878ff8"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
