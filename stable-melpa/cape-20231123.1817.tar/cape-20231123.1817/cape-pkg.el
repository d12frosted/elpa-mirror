(define-package "cape" "20231123.1817" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "f9f8e4a1e36b0ee7972c35bc0a635cbed9959aa0" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
