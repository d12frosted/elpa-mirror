(define-package "consult" "20210520.1824" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "556ff4eb31eb1d00a2afdda6664d03b698264e3c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
