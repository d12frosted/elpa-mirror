;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20260810.1614"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "53299f3484304a95eccb63f57269b730b09dea5b"
  :revdesc "53299f348430"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
