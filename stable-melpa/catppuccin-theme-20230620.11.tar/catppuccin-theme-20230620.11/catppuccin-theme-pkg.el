(define-package "catppuccin-theme" "20230620.11" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "438622d74f1b0034c354fdd67ed39c36f059e1b4" :authors
  '(("nyxkrage"))
  :maintainers
  '(("Carsten Kragelund" . "carsten@kragelund.me"))
  :maintainer
  '("Carsten Kragelund" . "carsten@kragelund.me")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
