(define-package "consult" "20211024.1830" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "ae2761ead41a2e8bae011cee0f57830d6bf423b5" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
