;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "posframe" "20251117.305"
  "Pop a posframe (just a frame) at point."
  '((emacs "26.1"))
  :url "https://github.com/tumashu/posframe"
  :commit "f8c3e56189a1b5d88f9729d560fb6b5a8a383abc"
  :revdesc "f8c3e56189a1"
  :keywords '("convenience" "tooltip")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
