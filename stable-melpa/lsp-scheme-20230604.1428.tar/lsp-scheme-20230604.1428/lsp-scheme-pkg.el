(define-package "lsp-scheme" "20230604.1428" "Scheme support for lsp-mode"
  '((emacs "26.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "cb986d7c1a2d4baf891ea5bfe802b8159a6f217f" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainers
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
