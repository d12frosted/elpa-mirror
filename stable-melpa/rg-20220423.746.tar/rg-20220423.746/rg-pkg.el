(define-package "rg" "20220423.746" "A search tool based on ripgrep"
  '((emacs "25.1")
    (transient "0.3.0")
    (wgrep "2.1.10"))
  :commit "d795ba4c29bde39bc34fb16afc824e2ffa0ab346" :authors
  '(("David Landell" . "david.landell@sunnyhill.email")
    ("Roland McGrath" . "roland@gnu.org"))
  :maintainer
  '("David Landell" . "david.landell@sunnyhill.email")
  :keywords
  '("matching" "tools")
  :url "https://github.com/dajva/rg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
