(define-package "citar" "20230314.2057" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "4.2")
    (org "9.5")
    (citeproc "0.9"))
  :commit "cb7d51115c38bfff676a091ac1287ae59a1ab733" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/emacs-citar/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
