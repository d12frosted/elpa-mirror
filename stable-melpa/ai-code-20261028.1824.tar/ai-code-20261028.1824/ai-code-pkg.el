;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261028.1824"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e042951efea168ce1605cf314c7f89b1660e98b8"
  :revdesc "e042951efea1"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
