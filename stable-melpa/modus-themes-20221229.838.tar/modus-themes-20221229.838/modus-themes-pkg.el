(define-package "modus-themes" "20221229.838" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "72eb32f4fbbb7f3d403854909446e897b340db49" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
