;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20241222.1005"
  "30 new custom blocks & 34 link types for Org-mode."
  '((s        "1.13.1")
    (dash     "2.18.1")
    (emacs    "27.1")
    (org      "9.1")
    (lf       "1.0")
    (dad-joke "1.4")
    (seq      "2.0")
    (lolcat   "0"))
  :url "https://github.com/alhassy/org-special-block-extras"
  :commit "9f674dd756f951fcbc2a32fea4db08f4067deb95"
  :revdesc "9f674dd756f9"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
