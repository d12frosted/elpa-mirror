(define-package "sly" "20211114.1021" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "8b1b968651c6d1a8699d16c3a03d0d1e83ecca3d" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
