;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "material-icons" "20260907.853"
  "Material Icon Theme integration."
  '((emacs "27.1"))
  :url "https://github.com/zHaOdANiuu/material-icons.el"
  :commit "bce68b2a83698d59ebc5292024cbbd58623d3891"
  :revdesc "bce68b2a8369"
  :keywords '("convenience" "icons" "svg" "theme")
  :authors '(("Daniu Zhao" . "zhaodaniu1@gmail.com"))
  :maintainers '(("Daniu Zhao" . "zhaodaniu1@gmail.com")))
