(define-package "dired-launch" "20220916.1836" "Use dired as a launcher"
  '((emacs "24.3"))
  :commit "519a6a49b56978b53e88a005490175cb913ec7fa" :authors
  '(("David Thompson"))
  :maintainers
  '(("David Thompson"))
  :maintainer
  '("David Thompson")
  :keywords
  '("dired" "launch")
  :url "https://github.com/thomp/dired-launch")
;; Local Variables:
;; no-byte-compile: t
;; End:
