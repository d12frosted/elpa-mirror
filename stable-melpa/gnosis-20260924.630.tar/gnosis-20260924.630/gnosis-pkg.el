;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260924.630"
  "Linked notes and spaced repetition."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.4.4"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "5f030c9ff27187a5c1aa7131b9cc0719bbd73852"
  :revdesc "5f030c9ff271"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
