;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "20260723.1547"
  "Batppuccin (Catppuccin) color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "1d942272ba14cc3ba3a9a996ec51f1aabcd09323"
  :revdesc "1d942272ba14"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
