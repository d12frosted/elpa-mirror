;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260425.1702"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "195c15407bf668d5f7e78edf571ce9dd70b45ee4"
  :revdesc "195c15407bf6"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
