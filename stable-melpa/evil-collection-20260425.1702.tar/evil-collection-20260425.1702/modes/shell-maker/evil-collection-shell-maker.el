;;; evil-collection-shell-maker.el --- Bindings for `shell-maker' -*- lexical-binding: t -*-

;; Copyright (C) 2026 James Nguyen

;; Author: James Nguyen <james@jojojames.com>
;; Maintainer: James Nguyen <james@jojojames.com>
;; URL: https://github.com/emacs-evil/evil-collection
;; Version: 0.0.1
;; Package-Requires: ((emacs "27.1"))
;; Keywords: evil, shell-maker, tools

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;; Bindings for `shell-maker'.
;;;
;;; These bindings apply to `shell-maker-mode' and any derived mode that
;;; doesn't override RET / S-RET in its own evil state map (for example,
;;; `agent-shell-mode' inherits from `shell-maker-mode-map').

;;; Code:
(require 'evil-collection)
(require 'shell-maker nil t)

(defgroup evil-collection-shell-maker nil
  "Evil bindings for `shell-maker'."
  :group 'evil-collection)

(defcustom evil-collection-shell-maker-submit-state 'normal
  "Evil state in which RET submits the prompt in `shell-maker' buffers.

The other state gets RET bound to `newline'.  S-RET always inserts a
newline regardless of state."
  :type '(choice (const :tag "Submit in normal state" normal)
                 (const :tag "Submit in insert state" insert))
  :group 'evil-collection-shell-maker)

(defconst evil-collection-shell-maker-maps '(shell-maker-mode-map))

(defvar shell-maker-mode-map)

;;;###autoload
(defun evil-collection-shell-maker-setup ()
  "Set up `evil' bindings for `shell-maker'."
  (let* ((submit evil-collection-shell-maker-submit-state)
         (newline-state (if (eq submit 'normal) 'insert 'normal)))
    (evil-collection-define-key submit 'shell-maker-mode-map
      (kbd "RET") 'shell-maker-submit)
    (evil-collection-define-key newline-state 'shell-maker-mode-map
      (kbd "RET") 'newline)
    (evil-collection-define-key 'insert 'shell-maker-mode-map
      (kbd "S-<return>") 'newline)
    (evil-collection-define-key 'normal 'shell-maker-mode-map
      (kbd "S-<return>") 'newline)))

(provide 'evil-collection-shell-maker)
;;; evil-collection-shell-maker.el ends here
