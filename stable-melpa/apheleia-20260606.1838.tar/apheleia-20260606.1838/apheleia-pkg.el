;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20260606.1838"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "172e82c14f539d65295dd36159f16493ed127faf"
  :revdesc "172e82c14f53"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
