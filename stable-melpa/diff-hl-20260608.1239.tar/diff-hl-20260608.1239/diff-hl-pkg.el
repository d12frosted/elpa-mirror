;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260608.1239"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "f202e46b3b026e3e777d1fc24513b940abe88302"
  :revdesc "f202e46b3b02"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
