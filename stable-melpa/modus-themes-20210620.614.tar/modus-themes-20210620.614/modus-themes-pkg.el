(define-package "modus-themes" "20210620.614" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "facdd21d45c22a904307bd03296831eb1d6fa837" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
