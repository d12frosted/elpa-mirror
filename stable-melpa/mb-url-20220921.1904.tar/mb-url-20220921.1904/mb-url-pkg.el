(define-package "mb-url" "20220921.1904" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "74fd873981b0fdc35518e4cfdd52527b6f95cdf5" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
