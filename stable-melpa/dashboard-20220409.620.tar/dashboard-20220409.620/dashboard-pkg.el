(define-package "dashboard" "20220409.620" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "7060bd1cb9eb9a7d9c08d3233827345e235a563f" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
