;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241125.2314"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "48d9515c269962ff2095a398a1dcfbb51720cef9"
  :revdesc "48d9515c2699"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
