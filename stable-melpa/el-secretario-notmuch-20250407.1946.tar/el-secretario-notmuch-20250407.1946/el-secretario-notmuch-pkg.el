;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-secretario-notmuch" "20250407.1946"
  "Add notmuch inboxes to el-secretario."
  '((emacs         "27.1")
    (el-secretario "0.0.1")
    (notmuch       "0.3.1"))
  :url "https://git.sr.ht/~zetagon/el-secretario"
  :commit "0c728c3bdd1d19356c192ba333a945d732bd16b8"
  :revdesc "0c728c3bdd1d"
  :keywords '("convenience" "mail")
  :authors '(("Leo Okawa Ericson" . "https://sr.ht/~zetagon"))
  :maintainers '(("Leo Okawa Ericson" . "git@relevant-information.com")))
