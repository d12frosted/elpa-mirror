(define-package "cape" "20220804.2211" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "ab2f4ec9ec778d256c7e4b3490ecd50269c422f0" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
