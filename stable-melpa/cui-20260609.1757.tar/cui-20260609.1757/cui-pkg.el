;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260609.1757"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "7a000119d9b361c92e39456b366f5c31b9268411"
  :revdesc "7a000119d9b3"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
