;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261108.55"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "4c600e5c1254a5bc8f510667e2f4afa49c06a264"
  :revdesc "4c600e5c1254"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
