(define-package "ligo-mode" "20230925.1550" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "44579a86328e43a331ac26712295f99109f240e7" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
