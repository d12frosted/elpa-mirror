(define-package "modus-themes" "20220217.1635" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "4bd32dac89cc0e0ae9ad2074133ff1d2c60bdbcc" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
