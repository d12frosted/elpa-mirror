;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260212.443"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "7d65974c19ead334642fcd15b8e9b18e1390d84b"
  :revdesc "7d65974c19ea"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
