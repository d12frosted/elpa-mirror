;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "peacock-theme" "20170808.1320"
  "An Emacs 24 theme based on Peacock (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "9e46fbfb562b6e26c6e3d6d618b044b3694da4c8"
  :revdesc "9e46fbfb562b")
