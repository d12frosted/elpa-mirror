;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260601.431"
  "Unified interface for AI coding backends."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "1a2220c58982470164791aa172cd57c5528af94b"
  :revdesc "1a2220c58982"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
