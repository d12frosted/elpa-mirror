;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260422.1521"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "d228085198669c559f670d48251bfc5399e72a63"
  :revdesc "d22808519866"
  :keywords '("convenience" "input method" "dbus"))
