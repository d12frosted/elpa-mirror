(define-package "dirvish" "20220211.826" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e98a4788bc247ecaa0e43dc36bfe02c34b620536" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
