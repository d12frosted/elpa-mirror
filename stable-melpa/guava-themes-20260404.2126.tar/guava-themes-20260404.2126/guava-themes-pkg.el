;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260404.2126"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "00ba5433287dcf095504cec81f4eb6835f20d6b7"
  :revdesc "00ba5433287d"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
