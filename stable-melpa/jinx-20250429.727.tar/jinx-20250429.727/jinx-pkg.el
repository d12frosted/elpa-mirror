;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20250429.727"
  "Enchanted Spell Checker."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "22b8f2273dac63b6231fab53fba8afb1a789ceb7"
  :revdesc "22b8f2273dac"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
