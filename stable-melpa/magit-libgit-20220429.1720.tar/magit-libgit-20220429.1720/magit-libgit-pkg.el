(define-package "magit-libgit" "20220429.1720" "(POC) Teach Magit to use Libgit2."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (libgit "0")
    (magit "20211004"))
  :commit "9a09823e56ccb1d9a63f0edeac260fbc9bd5025b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
