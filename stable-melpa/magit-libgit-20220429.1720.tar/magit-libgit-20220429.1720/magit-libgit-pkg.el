(define-package "magit-libgit" "20220429.1720" "(POC) Teach Magit to use Libgit2."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (libgit "0")
    (magit "20211004"))
  :commit "475bc370ff9e567c69944e1611107584810a79aa" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
