(define-package "magit-libgit" "20220429.1720" "(POC) Teach Magit to use Libgit2."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (libgit "0")
    (magit "20211004"))
  :commit "125a8d5e417dda4438ce41d71a821d8a936fa5ea" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
