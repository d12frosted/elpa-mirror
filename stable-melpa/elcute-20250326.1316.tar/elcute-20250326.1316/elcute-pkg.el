;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcute" "20250326.1316"
  "Commands for marking and killing lines electrically."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "60cd522ff328c8e13ce6de759540a2b27bc96315"
  :revdesc "60cd522ff328"
  :keywords '("convenience"))
