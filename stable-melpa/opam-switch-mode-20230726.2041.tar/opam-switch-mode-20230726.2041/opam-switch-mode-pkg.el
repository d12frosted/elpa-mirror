(define-package "opam-switch-mode" "20230726.2041" "Select OCaml opam switches via a menu"
  '((emacs "25.1"))
  :commit "ab460078f9cd71f4989f2b11eb4e4dd05545f20a" :maintainers
  '((nil . "proof-general-maintainers@groupes.renater.fr"))
  :maintainer
  '(nil . "proof-general-maintainers@groupes.renater.fr")
  :url "https://github.com/ProofGeneral/opam-switch-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
