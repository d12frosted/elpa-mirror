;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260321.2038"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "ac8c04f0a90030a8862712af0172025ecec59130"
  :revdesc "ac8c04f0a900"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
