(define-package "live-py-mode" "20220107.329" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "d383396ae8fe555f0af9d3618e75445454e5825b" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
