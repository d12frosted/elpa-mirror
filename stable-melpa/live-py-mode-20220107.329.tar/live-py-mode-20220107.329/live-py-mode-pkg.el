(define-package "live-py-mode" "20220107.329" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "9bbf82d5fb936cd1ce2c8d6e11fcfbf1c68a5865" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
