;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261030.1245"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "95947b6f26eddc9922d249860d53a410de5ab12b"
  :revdesc "95947b6f26ed"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
