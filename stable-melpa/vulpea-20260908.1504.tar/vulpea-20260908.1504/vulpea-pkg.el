;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260908.1504"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "6e8b664f091134cf01b92dee214de642ae9a46a1"
  :revdesc "6e8b664f0911"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
