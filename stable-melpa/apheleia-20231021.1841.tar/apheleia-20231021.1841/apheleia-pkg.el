(define-package "apheleia" "20231021.1841" "Reformat buffer stably"
  '((emacs "27"))
  :commit "f4157e8c397896c0b984472ef7f82f444e0fc3e2" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
