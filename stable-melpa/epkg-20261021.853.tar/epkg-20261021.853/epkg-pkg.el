;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20261021.853"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.1")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "ba4a88c3c2bbb87b3af61140f281321066166613"
  :revdesc "ba4a88c3c2bb"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
