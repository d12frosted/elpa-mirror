;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250319.803"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.76.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "93f271c4537bdaa77f1570c0a4c0daf2ff653e10"
  :revdesc "93f271c4537b")
