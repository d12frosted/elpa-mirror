(define-package "fabric" "20171116.656" "Launch Fabric using Emacs" 'nil :commit "df79be341d0b34ed23850f9894136092fa5fea8c" :keywords
  ("python" "fabric")
  :authors
  (("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com"))
  :maintainer
  ("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com")
  :url "https://github.com/nlamirault/fabric.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
