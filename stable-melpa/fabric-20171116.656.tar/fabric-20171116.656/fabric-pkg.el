;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fabric" "20171116.656"
  "Launch Fabric using Emacs."
  ()
  :url "https://github.com/nlamirault/fabric.el"
  :commit "df79be341d0b34ed23850f9894136092fa5fea8c"
  :revdesc "df79be341d0b"
  :keywords '("python" "fabric")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com")))
