;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251013.846"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a6980020e50541e32d02eeb19010d052c6e6a68e"
  :revdesc "a6980020e505"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
