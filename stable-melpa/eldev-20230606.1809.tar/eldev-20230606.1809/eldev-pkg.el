(define-package "eldev" "20230606.1809" "Elisp development tool"
  '((emacs "24.4"))
  :commit "e6a2f6e523a8ddfa75fb99c27e4f416faa808eb3" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
