;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261024.1417"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "1c7a3a04d2be174685878e4ba5be964e00bdb81c"
  :revdesc "1c7a3a04d2be"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
