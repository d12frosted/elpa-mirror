;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idris-mode" "20260506.1030"
  "Major mode for editing Idris code."
  '((emacs     "24")
    (prop-menu "0.1")
    (cl-lib    "0.5"))
  :url "https://github.com/idris-hackers/idris-mode"
  :commit "7211af2fc8a6739a81de1f8e37082f914718ecbf"
  :revdesc "7211af2fc8a6"
  :keywords '("languages"))
