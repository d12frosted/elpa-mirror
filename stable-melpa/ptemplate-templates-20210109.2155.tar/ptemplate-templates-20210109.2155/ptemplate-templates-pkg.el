(define-package "ptemplate-templates" "20210109.2155" "Official templates"
  '((emacs "25.1")
    (ptemplate "2.0.0"))
  :commit "26f1e4d40ac0e89e82c3210591064770f86490bf" :authors
  '(("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainer
  '("Nikita Bloshchanevich" . "nikblos@outlook.com")
  :url "https://github.com/nbfalcon/ptemplate-templates")
;; Local Variables:
;; no-byte-compile: t
;; End:
