;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260225.2232"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "f2f7d5f45f4ff3362de753103c3586160795451c"
  :revdesc "f2f7d5f45f4f")
