;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "logview" "20241027.1032"
  "Major mode for viewing log files."
  '((emacs    "25.1")
    (datetime "0.8")
    (extmap   "1.0"))
  :url "https://github.com/doublep/logview"
  :commit "d0f861f717a0129c617f6c411d156a417fd417e4"
  :revdesc "d0f861f717a0"
  :keywords '("files" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
