(define-package "slime" "20240502.2149" "Superior Lisp Interaction Mode for Emacs"
  '((emacs "24.3")
    (macrostep "0.9"))
  :commit "04f26df1c3f403c8383df41507929e7bb9b1910c" :keywords
  '("languages" "lisp" "slime")
  :url "https://github.com/slime/slime")
;; Local Variables:
;; no-byte-compile: t
;; End:
