(define-package "meow" "20220124.1237" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "e50f4ffe1112ad041866ed2ba003c34b8627c229" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
