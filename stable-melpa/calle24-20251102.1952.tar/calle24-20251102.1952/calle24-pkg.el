;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calle24" "20251102.1952"
  "Emacs Toolbar Support for SF Symbols."
  '((emacs "29.1"))
  :url "https://github.com/kickingvegas/calle24"
  :commit "14672b622bbcd2168db7099185003bd2d2eb9a5c"
  :revdesc "14672b622bbc"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
