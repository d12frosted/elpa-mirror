;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-gradle" "20190315.233"
  "Flymake extension for Gradle."
  '((emacs "26.1"))
  :url "https://github.com/jojojames/flymake-gradle"
  :commit "dbedd29b78d4828ef57d4de20867be5df3eaab99"
  :revdesc "dbedd29b78d4"
  :keywords '("languages" "gradle")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
