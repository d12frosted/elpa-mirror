(define-package "fanyi" "20220805.216" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "031c7ab7a16113bdca2b351781dc95aff9658c9a" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
