;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260622.1737"
  "Friendly AI assistant for Ollama and cloud LLMs."
  '((emacs     "29.1")
    (transient "0.4.0"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "c87a8fd73f1fb49859da37d6ef440ae456f2c6e1"
  :revdesc "c87a8fd73f1f"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
