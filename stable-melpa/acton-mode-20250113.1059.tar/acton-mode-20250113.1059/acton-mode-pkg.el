;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acton-mode" "20250113.1059"
  "Major mode for editing Acton source code."
  '((emacs "25.1"))
  :url "https://github.com/actonlang/acton-mode"
  :commit "5a1a8509fb84dad4f8a02da47519ed7399c26d7f"
  :revdesc "5a1a8509fb84"
  :keywords '("languages" "programming"))
