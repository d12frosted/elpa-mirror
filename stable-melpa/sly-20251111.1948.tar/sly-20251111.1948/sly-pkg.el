;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20251111.1948"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.3"))
  :url "https://github.com/joaotavora/sly"
  :commit "87722894da6d8d64ac83c7d4a29382b450f669ea"
  :revdesc "87722894da6d"
  :keywords '("languages" "lisp" "sly"))
