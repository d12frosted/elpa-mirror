;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forge" "20260501.1411"
  "Access Git forges from Magit."
  '((emacs         "29.1")
    (compat        "30.1")
    (closql        "2.4")
    (cond-let      "1.0")
    (emacsql       "4.3")
    (ghub          "5.2")
    (llama         "1.0")
    (magit         "4.5")
    (markdown-mode "2.8")
    (seq           "2.24")
    (transient     "0.13")
    (yaml          "1.2"))
  :url "https://github.com/magit/forge"
  :commit "d4eb8d1be55398e350c8a68b0c355f5166418843"
  :revdesc "d4eb8d1be553"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev")))
