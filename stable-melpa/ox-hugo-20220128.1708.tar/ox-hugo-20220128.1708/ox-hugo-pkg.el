(define-package "ox-hugo" "20220128.1708" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "11b9aa3b2fafa6f56989fb3835f9f8bb3198d5d9" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
