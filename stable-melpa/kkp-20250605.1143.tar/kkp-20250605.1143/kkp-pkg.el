;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "20250605.1143"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "8667a06d40cd5d40f26a01ed70b64f11bc416ad3"
  :revdesc "8667a06d40cd"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
