;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "20260107.446"
  "Display diffs using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "0ed5fa5a39dfcdeb308e94cc251c0d82853d9c50"
  :revdesc "0ed5fa5a39df"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
