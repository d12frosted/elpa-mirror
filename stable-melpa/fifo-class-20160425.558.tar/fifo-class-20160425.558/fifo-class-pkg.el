;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fifo-class" "20160425.558"
  "First in first out abstract class."
  ()
  :url "https://github.com/mola-T/fifo-class"
  :commit "8fe4cf690727f4ac7b67f29c55f845df023c3f21"
  :revdesc "8fe4cf690727"
  :keywords '("lisp")
  :authors '(("Mola-T" . "Mola@molamola.xyz"))
  :maintainers '(("Mola-T" . "Mola@molamola.xyz")))
