(define-package "lister" "20220118.1322" "Yet another list printer"
  '((emacs "26.1"))
  :commit "51581b53ecf8e68d67a2d85dde539533aa7199ee" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
