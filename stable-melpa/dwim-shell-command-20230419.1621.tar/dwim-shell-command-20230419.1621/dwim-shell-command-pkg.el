(define-package "dwim-shell-command" "20230419.1621" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "681d259ac4b731d6d4992e47fef4f7cea8e3fb78" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
