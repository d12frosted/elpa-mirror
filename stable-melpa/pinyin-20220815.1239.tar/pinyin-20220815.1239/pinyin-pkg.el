;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin" "20220815.1239"
  "Convert Hanzi to Pinyin (汉字转拼音)."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/xuchunyang/pinyin.el"
  :commit "b7a0aad8ff35e50d1c536df4c0e73fc7e9d06700"
  :revdesc "b7a0aad8ff35"
  :keywords '("extensions")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
