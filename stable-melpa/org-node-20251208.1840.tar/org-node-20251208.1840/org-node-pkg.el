;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20251208.1840"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "76d6fee03faad5f91ada95b67182705aa2b3fb76"
  :revdesc "76d6fee03faa"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
