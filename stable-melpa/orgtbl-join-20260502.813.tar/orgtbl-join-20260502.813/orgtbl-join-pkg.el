;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260502.813"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "9963a6443e78f6574ff28058893bc8e1ac179f82"
  :revdesc "9963a6443e78"
  :keywords '("data" "extensions"))
