(define-package "elpa-clone" "20230804.449" "Clone ELPA archive"
  '((emacs "24.4"))
  :commit "e7645c5d588591d0e566d56df53ec6f0b2df53f1" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "elpa" "clone" "mirror")
  :url "https://github.com/dochang/elpa-clone")
;; Local Variables:
;; no-byte-compile: t
;; End:
