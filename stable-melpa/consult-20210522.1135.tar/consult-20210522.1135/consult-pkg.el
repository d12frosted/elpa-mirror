(define-package "consult" "20210522.1135" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "8c8a7f83c6ec381c800036c45903daebf27a654a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
