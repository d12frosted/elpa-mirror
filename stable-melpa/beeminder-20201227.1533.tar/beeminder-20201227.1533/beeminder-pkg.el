(define-package "beeminder" "20201227.1533" "Emacs interface for Beeminder"
  '((emacs "24.3")
    (seq "2.16")
    (org "7"))
  :commit "1f085b6bdf9138db8deb7cd3afd269e34a87e8cc" :authors
  '(("Phil Newton" . "phil@sodaware.net"))
  :maintainer
  '("Phil Newton" . "phil@sodaware.net")
  :keywords
  '("tools" "beeminder")
  :url "http://www.philnewton.net/code/beeminder-el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
