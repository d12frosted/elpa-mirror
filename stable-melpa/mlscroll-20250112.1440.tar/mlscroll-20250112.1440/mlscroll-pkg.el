;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mlscroll" "20250112.1440"
  "A scroll bar for the modeline."
  '((emacs "27.1"))
  :url "https://github.com/jdtsmith/mlscroll"
  :commit "d22f5d8e6ca5054d01f06ac57419267098b709a5"
  :revdesc "d22f5d8e6ca5"
  :keywords '("convenience"))
