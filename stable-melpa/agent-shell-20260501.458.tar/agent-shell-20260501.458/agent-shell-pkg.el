;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260501.458"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "152277f18e161ba4a13059853c1619984cbf98bb"
  :revdesc "152277f18e16")
