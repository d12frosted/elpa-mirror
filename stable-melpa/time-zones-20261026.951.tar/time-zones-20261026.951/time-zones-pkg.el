;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-zones" "20261026.951"
  "Time zone lookups."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/time-zones"
  :commit "85502669cc991805061afa1c479ec1c526be3ba4"
  :revdesc "85502669cc99")
