(define-package "blackjack" "20230820.121" "The game of Blackjack"
  '((emacs "26.2"))
  :commit "0398f9d59b323d7b9f6fd57f0c5c2e1b134e44aa" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
