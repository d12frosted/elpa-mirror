;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260503.1151"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "e7b7e816c5601d98b36ca13acae78bb404677889"
  :revdesc "e7b7e816c560"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
