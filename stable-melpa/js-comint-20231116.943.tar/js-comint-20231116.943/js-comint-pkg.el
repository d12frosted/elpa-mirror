(define-package "js-comint" "20231116.943" "JavaScript interpreter in window."
  '((emacs "24.3"))
  :commit "3790e017c0348d3bc6afe22397b155d7bef9f30a" :authors
  '(("Paul Huff" . "paul.huff@gmail.com"))
  :maintainers
  '(("Chen Bin <chenbin.sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin.sh AT gmail DOT com>")
  :keywords
  '("javascript" "node" "inferior-mode" "convenience")
  :url "https://github.com/redguardtoo/js-comint")
;; Local Variables:
;; no-byte-compile: t
;; End:
