;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "justl" "20260207.411"
  "Major mode for driving just files."
  '((transient  "0.1.0")
    (emacs      "27.1")
    (s          "1.2.0")
    (f          "0.20.0")
    (inheritenv "0.2"))
  :url "https://github.com/psibi/justl.el"
  :commit "36e5d5194bfc1ae4bd10663a4533546f0cec6d90"
  :revdesc "36e5d5194bfc"
  :keywords '("just" "justfile" "tools" "processes"))
