(define-package "wakatime-mode" "20221110.1632" "Automatic time tracking extension for WakaTime" 'nil :commit "ef923829912c3854d230834f81083814b7c9d992" :authors
  '(("Gabor Torok" . "gabor@20y.hu"))
  :maintainers
  '(("Alan Hamlett" . "alan@wakatime.com"))
  :maintainer
  '("Alan Hamlett" . "alan@wakatime.com")
  :keywords
  '("calendar" "comm"))
;; Local Variables:
;; no-byte-compile: t
;; End:
