;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ham-mode" "20150811.1306"
  "Html As Markdown. Transparently edit an html file using markdown."
  '((html-to-markdown "1.2")
    (markdown-mode    "2.0"))
  :url "https://github.com/Bruce-Connor/ham-mode"
  :commit "3a141986a21c2aa6eefb428983352abb8b7907d2"
  :revdesc "3a141986a21c"
  :keywords '("convenience" "emulation" "wp")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
