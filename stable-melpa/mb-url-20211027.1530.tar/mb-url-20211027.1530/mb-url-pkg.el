(define-package "mb-url" "20211027.1530" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "29408eeaf66df01f06dcc78c37dba3c0cf4e5df8" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
