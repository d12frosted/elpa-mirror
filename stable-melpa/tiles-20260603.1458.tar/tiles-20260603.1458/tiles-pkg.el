;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiles" "20260603.1458"
  "Tagged Instant Lightweight Emacs Snippets."
  '((emacs "27.1"))
  :url "https://github.com/ctanas/tiles"
  :commit "754b11764f8204ff1fce6d3aa80eca2150a8a164"
  :revdesc "754b11764f82"
  :keywords '("files" "text" "convenience")
  :authors '(("Claudiu Tănăselia" . "https://www.tanaselia.ro"))
  :maintainers '(("Claudiu Tănăselia" . "https://www.tanaselia.ro")))
