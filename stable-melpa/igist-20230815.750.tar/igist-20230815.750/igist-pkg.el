(define-package "igist" "20230815.750" "List, create, update and delete GitHub gists"
  '((emacs "27.1")
    (ghub "3.6.0")
    (transient "0.4.1"))
  :commit "d788f6bfb8fb4e2e1dfc0a9cda851affd80aae46" :authors
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainer
  '("Karim Aziiev" . "karim.aziiev@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/KarimAziev/igist")
;; Local Variables:
;; no-byte-compile: t
;; End:
