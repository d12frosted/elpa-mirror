;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250709.424"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "2192a0d526b821170dfe4662e2853c67c76de84e"
  :revdesc "2192a0d526b8"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
