;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "20260429.543"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "081fa1797e09fad1621b21294bfe0dc4a3701919"
  :revdesc "081fa1797e09")
