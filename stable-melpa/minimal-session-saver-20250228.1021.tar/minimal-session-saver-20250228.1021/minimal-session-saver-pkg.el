;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minimal-session-saver" "20250228.1021"
  "Very lean session saver."
  ()
  :url "https://github.com/rolandwalker/minimal-session-saver"
  :commit "1146d071c370bc3de33538e2d20172a9cca29ba2"
  :revdesc "1146d071c370"
  :keywords '("tools" "frames" "project")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
