;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260703.1209"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b835a03a517da5c1e3c689e88f51718c2b1ed441"
  :revdesc "b835a03a517d")
