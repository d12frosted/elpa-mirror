(define-package "jsdoc" "20230808.2224" "Insert JSDoc comments"
  '((emacs "29.1")
    (dash "2.11.0")
    (s "1.12.0"))
  :commit "98129da2d6f4b938f9833be3f760d30ebd2986aa" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/jsdoc.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
