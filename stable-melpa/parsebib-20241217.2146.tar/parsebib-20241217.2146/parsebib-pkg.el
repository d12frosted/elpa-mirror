;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parsebib" "20241217.2146"
  "A library for parsing bib files."
  '((emacs "25.1"))
  :url "https://github.com/joostkremers/parsebib"
  :commit "0cde83b8a0c51acea510d1b373de2f484e215699"
  :revdesc "0cde83b8a0c5"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
