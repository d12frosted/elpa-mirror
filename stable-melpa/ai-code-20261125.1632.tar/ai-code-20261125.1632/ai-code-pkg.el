;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261125.1632"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e5ed304ec242ff663795589987fca23a4ba30270"
  :revdesc "e5ed304ec242"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
