;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy" "20251122.2238"
  "Incremental Vertical completYon."
  '((emacs "24.5"))
  :url "https://github.com/abo-abo/swiper"
  :commit "4b1df7c492fd9be39df7f97dd6e22b8a0e99fb8a"
  :revdesc "4b1df7c492fd"
  :keywords '("matching")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
