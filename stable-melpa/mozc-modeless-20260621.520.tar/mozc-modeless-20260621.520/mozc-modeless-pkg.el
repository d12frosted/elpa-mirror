;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc-modeless" "20260621.520"
  "Modeless Japanese input with Mozc."
  '((emacs "29.0")
    (mozc  "1.0"))
  :url "https://github.com/kiyoka/mozc-modeless-emacs"
  :commit "95adeb91fbafb569d7ac06a3ab7df9679349a7be"
  :revdesc "95adeb91fbaf"
  :keywords '("i18n" "input-method")
  :authors '(("Kiyoka Nishiyama" . "kiyokap@gmail.com"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyokap@gmail.com")))
