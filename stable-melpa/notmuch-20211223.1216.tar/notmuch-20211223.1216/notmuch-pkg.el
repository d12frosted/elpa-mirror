(define-package "notmuch" "20211223.1216" "run notmuch within emacs" 'nil :commit "063f5e98620e2f2adeaa8b3313cdac85eb4ef4db" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
