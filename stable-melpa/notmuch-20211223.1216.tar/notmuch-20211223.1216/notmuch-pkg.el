(define-package "notmuch" "20211223.1216" "run notmuch within emacs" 'nil :commit "cea1604a087645d07998c6986a8678b2af239322" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
