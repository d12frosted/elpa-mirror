(define-package "catppuccin-theme" "20230417.2252" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "cbf3cc984729e07389a6c25f006073cc0eaef8bb" :authors
  '(("nyxkrage"))
  :maintainer
  '("Carsten Kragelund" . "carsten@kragelund.me")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
