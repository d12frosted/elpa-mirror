;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tinypng" "20200306.911"
  "Compress PNG and JPEG with TinyPNG.com API."
  '((emacs "25.1"))
  :url "https://github.com/xuchunyang/tinypng.el"
  :commit "f7632e073ce13ef5ce30ae5584cb482a8bb9ffff"
  :revdesc "f7632e073ce1"
  :keywords '("multimedia")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
