;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "departure-times-norway" "20250421.722"
  "Description."
  '((emacs   "27.1")
    (persist "0.6.1"))
  :url "https://github.com/hsolg/emacs-departure-times-norway"
  :commit "05cded8dadc3915690054340ea253687760eb06d"
  :revdesc "05cded8dadc3"
  :authors '(("Henrik Solgaard" . "henrik.solgaard@gmail.com"))
  :maintainers '(("Henrik Solgaard" . "henrik.solgaard@gmail.com")))
