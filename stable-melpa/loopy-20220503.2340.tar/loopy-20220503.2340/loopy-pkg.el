(define-package "loopy" "20220503.2340" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22"))
  :commit "9db4f2f2a2c4f4ef5fd4e80cb6dfe00306aa9d8c" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
