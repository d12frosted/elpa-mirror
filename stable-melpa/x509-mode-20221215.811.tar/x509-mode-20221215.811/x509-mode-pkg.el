(define-package "x509-mode" "20221215.811" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "578e46d720a09a023e5af91bdcb8762ebe7343f4" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
