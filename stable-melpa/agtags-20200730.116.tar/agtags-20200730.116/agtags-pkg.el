(define-package "agtags" "20200730.116" "A frontend to GNU Global"
  '((emacs "25"))
  :commit "d80c6f61dee74040c07b7010d48cab1df13a3abf" :keywords
  ("tools" "convenience")
  :authors
  (("Vietor Liu" . "vietor.liu@gmail.com"))
  :maintainer
  ("Vietor Liu" . "vietor.liu@gmail.com")
  :url "https://github.com/vietor/agtags")
;; Local Variables:
;; no-byte-compile: t
;; End:
