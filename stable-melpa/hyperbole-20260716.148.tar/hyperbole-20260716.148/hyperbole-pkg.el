;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260716.148"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "d36f2c3a316f775f3bf38cfa0dbb59a79fecea62"
  :revdesc "d36f2c3a316f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
