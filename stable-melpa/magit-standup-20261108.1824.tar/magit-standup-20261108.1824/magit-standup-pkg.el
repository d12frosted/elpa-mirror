;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-standup" "20261108.1824"
  "Collect recent git commits for standup notes."
  '((emacs     "28.1")
    (magit     "4.5.0")
    (transient "0.8.0"))
  :url "https://github.com/function-artisans/magit-standup"
  :commit "ea8a3bd7a18e9913709b099d23c72e92d5235e87"
  :revdesc "ea8a3bd7a18e"
  :keywords '("tools" "vc")
  :authors '(("István Karaszi" . "ikaraszi@gmail.com"))
  :maintainers '(("István Karaszi" . "ikaraszi@gmail.com")))
