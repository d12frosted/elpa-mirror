;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lfe-mode" "20250702.1243"
  "Lisp Flavoured Erlang mode."
  ()
  :url "https://github.com/rvirding/lfe"
  :commit "ebd7d221c52b6bf8c47c9e4f7daf15b3dee4d3fa"
  :revdesc "ebd7d221c52b")
