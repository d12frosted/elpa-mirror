;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260216.900"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "http://github.com/bbatsov/neocaml"
  :commit "90f7007dfe802aa600bf599836efa44a376c4d1b"
  :revdesc "90f7007dfe80"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
