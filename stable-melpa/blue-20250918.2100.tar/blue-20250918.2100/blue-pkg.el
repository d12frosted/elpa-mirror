;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20250918.2100"
  "BLUE build system interface."
  '((emacs "30.1"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "1625266e588b082d929503373c26e3b8af7a8e11"
  :revdesc "1625266e588b"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
