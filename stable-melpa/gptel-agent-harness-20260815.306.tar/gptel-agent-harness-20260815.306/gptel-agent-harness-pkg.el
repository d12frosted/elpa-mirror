;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent-harness" "20260815.306"
  "Agent execution harness for gptel-agent."
  '((emacs       "29.1")
    (compat      "30.1.0.0")
    (gptel-agent "0.0.1"))
  :url "https://github.com/beacoder/gptel-agent-harness"
  :commit "879ad848371d760ec41d0c8f6077633fd1d942f2"
  :revdesc "879ad848371d"
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
