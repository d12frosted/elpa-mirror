(define-package "cliphist" "20210803.57" "paste from clipboard managers"
  '((emacs "25.1"))
  :commit "caa2f10eeb1665081ad163f31d9a4c7f72d504b2" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("clipboard" "manager" "history")
  :url "http://github.com/redguardtoo/cliphist")
;; Local Variables:
;; no-byte-compile: t
;; End:
