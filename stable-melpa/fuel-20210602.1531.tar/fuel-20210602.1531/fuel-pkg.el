(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "471289907c4443ca239835e68c61118fbbf12498")
;; Local Variables:
;; no-byte-compile: t
;; End:
