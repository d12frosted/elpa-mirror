(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5b1c814d84714b0c94c5a7b4aeb3f44d2a4d5998")
;; Local Variables:
;; no-byte-compile: t
;; End:
