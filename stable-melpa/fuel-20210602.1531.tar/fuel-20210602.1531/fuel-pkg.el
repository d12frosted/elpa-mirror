(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b3fe2b626ac66922da47d11767c822996581a997")
;; Local Variables:
;; no-byte-compile: t
;; End:
