(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b989a860d1d6191bb9c5911ac77ed0931424eaeb")
;; Local Variables:
;; no-byte-compile: t
;; End:
