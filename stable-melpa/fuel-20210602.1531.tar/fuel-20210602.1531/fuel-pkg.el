(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "8515fe960b5b0bfce158ad91e9141f07a2c5fcc4")
;; Local Variables:
;; no-byte-compile: t
;; End:
