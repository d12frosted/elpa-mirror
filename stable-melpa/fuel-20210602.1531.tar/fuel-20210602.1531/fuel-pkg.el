(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "470bb02bc8d50d27250405eb0b2ad6df7662083e")
;; Local Variables:
;; no-byte-compile: t
;; End:
