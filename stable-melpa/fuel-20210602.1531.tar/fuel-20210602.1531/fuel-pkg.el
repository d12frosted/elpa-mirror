(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9dc82158a698d5346dceadecaf16a8cdc80ef11a")
;; Local Variables:
;; no-byte-compile: t
;; End:
