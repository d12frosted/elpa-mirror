(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "fb2e258c6f1a9b832567d5dd514eed9ee0161d1b")
;; Local Variables:
;; no-byte-compile: t
;; End:
