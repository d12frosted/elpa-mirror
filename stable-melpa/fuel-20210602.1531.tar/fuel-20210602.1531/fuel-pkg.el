(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "70cd43a8dc3afd3870d768274f4b5f2559c526a3")
;; Local Variables:
;; no-byte-compile: t
;; End:
