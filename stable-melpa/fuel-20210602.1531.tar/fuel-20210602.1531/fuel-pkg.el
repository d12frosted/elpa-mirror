(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "7b451bb813d242dbc0cd6c29d071e0b320f2200e")
;; Local Variables:
;; no-byte-compile: t
;; End:
