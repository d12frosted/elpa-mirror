(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "eb239127d73291adf3c9c1e9ffb2b5721884964f")
;; Local Variables:
;; no-byte-compile: t
;; End:
