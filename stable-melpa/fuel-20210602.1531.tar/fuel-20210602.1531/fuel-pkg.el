(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "48b6d17e13356c772e9a7dea6072d5c37b152ea9")
;; Local Variables:
;; no-byte-compile: t
;; End:
