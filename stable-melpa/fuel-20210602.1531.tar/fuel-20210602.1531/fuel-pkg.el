(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "eb499370eaef815b9a429eda5cd0a009ebdac131")
;; Local Variables:
;; no-byte-compile: t
;; End:
