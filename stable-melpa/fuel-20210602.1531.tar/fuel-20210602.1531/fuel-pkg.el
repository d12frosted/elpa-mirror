(define-package "fuel" "20210602.1531" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "94fc1f5faf4df0ba11d10ccecc71d996472102cc")
;; Local Variables:
;; no-byte-compile: t
;; End:
