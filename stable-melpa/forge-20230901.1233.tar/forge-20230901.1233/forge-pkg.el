(define-package "forge" "20230901.1233" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "29.1.4.1")
    (closql "20230407")
    (dash "2.19.1")
    (emacsql "20230409")
    (ghub "20220621")
    (let-alist "1.0.6")
    (magit "20230319")
    (markdown-mode "2.4")
    (transient "0.4.0")
    (yaml "0.5.2"))
  :commit "adb802eb08046a8b89d83524a17c966ee4541e2b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
