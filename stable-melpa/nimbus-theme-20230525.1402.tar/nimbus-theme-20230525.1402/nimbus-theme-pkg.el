(define-package "nimbus-theme" "20230525.1402" "Nimbus dark theme"
  '((emacs "24.1"))
  :commit "a5c66339676cb9008aeaf33f827161710e201d81" :authors
  '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers
  '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainer
  '("Marcin Swieczkowski" . "marcin@realemail.net")
  :keywords
  '("faces")
  :url "https://github.com/mrcnski/nimbus-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
