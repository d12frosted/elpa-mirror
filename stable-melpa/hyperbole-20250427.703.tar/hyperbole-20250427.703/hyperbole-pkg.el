;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250427.703"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "430afa38fd7d14c19700b4bc788a227984bea80c"
  :revdesc "430afa38fd7d"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
