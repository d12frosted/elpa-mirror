;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20241105.928"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "0e360c6cd7b0c30eff60a21ba701922dca4d7648"
  :revdesc "0e360c6cd7b0"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
