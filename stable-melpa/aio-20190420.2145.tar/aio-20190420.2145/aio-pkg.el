(define-package "aio" "20190420.2145" "async/await for Emacs Lisp"
  '((emacs "26.1"))
  :commit "077722896e649e7a33dcafbc4585686a29423979" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/emacs-aio")
;; Local Variables:
;; no-byte-compile: t
;; End:
