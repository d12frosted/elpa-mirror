;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nezburn-theme" "20230726.600"
  "A low contrast color theme for Emacs (inspired by zenburn)."
  ()
  :url "https://github.com/lanjoni/nezburn"
  :commit "83ea665941de938350956d62f430de1255a2d36d"
  :revdesc "83ea665941de"
  :authors '(("João Lanjoni" . "joaoaugustolanjoni@gmail.com"))
  :maintainers '(("João Lanjoni" . "joaoaugustolanjoni@gmail.com")))
