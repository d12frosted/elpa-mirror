;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260131.807"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "54d5740f899e949bb492468769e1afc28d45c201"
  :revdesc "54d5740f899e"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
