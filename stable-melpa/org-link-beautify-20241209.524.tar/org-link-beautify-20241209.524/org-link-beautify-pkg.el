;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20241209.524"
  "Beautify Org Links."
  '((emacs      "29.1")
    (org        "9.7.14")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "3d10984160c5ef974dc990f89922230b8f9a493e"
  :revdesc "3d10984160c5"
  :keywords '("hypermedia"))
