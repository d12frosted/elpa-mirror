;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-cite-overlay" "20260630.558"
  "Overlays for org-cite citations."
  '((emacs    "29.1")
    (citeproc "0.9.4"))
  :url "https://git.sr.ht/~swflint/org-cite-overlay"
  :commit "40dde06e57f4b7f5335e9d5e076e7c2a2dcc7861"
  :revdesc "40dde06e57f4"
  :keywords '("bib" "tex")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
