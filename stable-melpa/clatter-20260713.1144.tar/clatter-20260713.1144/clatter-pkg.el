;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260713.1144"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "cdd6e27c6eecd66484af5694abb9c36d6b260765"
  :revdesc "cdd6e27c6eec"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
