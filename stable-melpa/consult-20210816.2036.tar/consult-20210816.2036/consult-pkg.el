(define-package "consult" "20210816.2036" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "56e1a69d39608a476e6533c2c3a0bf83d5c0e760" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
