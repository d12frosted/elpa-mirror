;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "titlecase" "20260622.446"
  "Title-case phrases."
  '((emacs "25.1"))
  :url "https://codeberg.org/acdw/titlecase.el"
  :commit "eb75d7539243832761e8e75782252fd7a489fb37"
  :revdesc "eb75d7539243"
  :authors '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainers '(("Case Duckworth" . "acdw@acdw.net")))
