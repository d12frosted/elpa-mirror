(define-package "dirvish" "20220507.1433" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "3075374d34a96d320e54ec053a30482170d08c2e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
