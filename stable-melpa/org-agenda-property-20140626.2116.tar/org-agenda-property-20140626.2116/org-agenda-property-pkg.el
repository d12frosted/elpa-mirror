;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-agenda-property" "20140626.2116"
  "Display org properties in the agenda buffer."
  '((emacs "24.2"))
  :url "https://github.com/Bruce-Connor/org-agenda-property"
  :commit "01afb36072eb27846eb09310dfca7991dbae831e"
  :revdesc "01afb36072eb"
  :keywords '("calendar")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
