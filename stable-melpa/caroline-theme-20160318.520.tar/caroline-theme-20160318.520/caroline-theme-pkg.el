;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "caroline-theme" "20160318.520"
  "A trip down to New Orleans..."
  '((emacs "24"))
  :url "https://github.com/xjackk/carolines-theme"
  :commit "222fd483db304509f9e422dc82883d808e023ceb"
  :revdesc "222fd483db30"
  :authors '(("Jack Killilea" . "jaaacckz1@gmail.com"))
  :maintainers '(("Jack Killilea" . "jaaacckz1@gmail.com")))
