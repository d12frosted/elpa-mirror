;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "creds" "20140510.1706"
  "A parser credentials file library (not limited to credentials entries)."
  '((s    "1.9.0")
    (dash "2.5.0"))
  :url "https://github.com/ardumont/emacs-creds"
  :commit "00ebefd10005c170b790a01380cb6a98f798ce5c"
  :revdesc "00ebefd10005"
  :keywords '("credentials")
  :authors '(("Antoine R. Dumont" . "eniotna.tATgmail.com"))
  :maintainers '(("Antoine R. Dumont" . "eniotna.tATgmail.com")))
