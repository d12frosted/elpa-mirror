;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251215.1559"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "1fba7dbf32e4f6da30e2fb4d61a77cc35887d209"
  :revdesc "1fba7dbf32e4"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
