;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261124.309"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "c87ba593043d9e6a5dbc46fb6bcff5e951bb1ffc"
  :revdesc "c87ba593043d"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
