;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20261125.1326"
  "Advent of Code mode."
  '((emacs "29.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "7af3aa3fe810dedd77edcd013176d27a6fb441cc"
  :revdesc "7af3aa3fe810"
  :keywords '("tools")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
