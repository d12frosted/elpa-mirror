;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-chatgpt-shell" "20250704.705"
  "Org babel functions for ChatGPT evaluation."
  '((emacs         "27.1")
    (chatgpt-shell "2.24.1"))
  :url "https://github.com/xenodium/ob-chatgpt-shell"
  :commit "0e592d19528f8f3283a93e0e2844299e9ea21fcc"
  :revdesc "0e592d19528f")
