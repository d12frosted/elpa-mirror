;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "closql" "20260517.1250"
  "Store EIEIO objects using EmacSQL."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "0.2")
    (emacsql  "4.3")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/closql"
  :commit "bec93e9373acd1bfaeb392f18c56274518e0576b"
  :revdesc "bec93e9373ac"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev")))
