(define-package "embark" "20211219.312" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "2772ca0b35e8eb59724c31b5cb88ff802f21067a" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
