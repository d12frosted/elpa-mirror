(define-package "consult" "20210115.618" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "6e7fd01c217b2ee6cc5e02dd74d7e687c2ccf267" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
