(define-package "eldev" "20230611.1624" "Elisp development tool"
  '((emacs "24.4"))
  :commit "c63ca4bdb1cdfd1a60d55250ecd9ca62a4464b24" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
