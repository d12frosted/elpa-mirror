;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250104.2227"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "14e002c3f1f405d26f69facb3fe9736a3d79e187"
  :revdesc "14e002c3f1f4"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
