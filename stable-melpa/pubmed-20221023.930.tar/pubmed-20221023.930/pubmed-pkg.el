(define-package "pubmed" "20221023.930" "Interface to PubMed"
  '((emacs "26.1")
    (esxml "0.3.4")
    (s "1.12.0")
    (unidecode "0.2"))
  :commit "b2fbc124cabf0d373845763adf882e9d89ff5daa" :authors
  '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainer
  '("Folkert van der Beek" . "folkertvanderbeek@gmail.com")
  :keywords
  '("pubmed" "hypermedia")
  :url "https://gitlab.com/fvdbeek/emacs-pubmed")
;; Local Variables:
;; no-byte-compile: t
;; End:
