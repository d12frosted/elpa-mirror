;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphql-mode" "20251209.2139"
  "Major mode for editing GraphQL schemas."
  '((emacs "25.1"))
  :url "https://github.com/davazp/graphql-mode"
  :commit "6b68045702d72f72c63c0a4dc7c87221d41452f2"
  :revdesc "6b68045702d7"
  :keywords '("languages")
  :authors '(("David Vazquez Pua" . "davazp@gmail.com"))
  :maintainers '(("David Vazquez Pua" . "davazp@gmail.com")))
