(define-package "tok-theme" "20220125.2042" "My theme"
  '((emacs "24.3"))
  :commit "25f881cb1f75ea0f92fe57898fe1b3c0d0d9be81" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
