;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260520.849"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "4858ec3ea2b56f0a5ec09c916552f6dd51a248fd"
  :revdesc "4858ec3ea2b5"
  :keywords '("convenience" "input method" "dbus"))
