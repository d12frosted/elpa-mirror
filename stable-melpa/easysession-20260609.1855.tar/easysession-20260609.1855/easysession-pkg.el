;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260609.1855"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "eee84b2674a4e58542c24045cf02193a98d9ac50"
  :revdesc "eee84b2674a4"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
