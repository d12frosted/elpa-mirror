;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260427.454"
  "Pure Elisp HTTP server."
  '((emacs  "26.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "624fd08473de5b3ece5e2b5104340d9c8b9dc1c1"
  :revdesc "624fd08473de"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
