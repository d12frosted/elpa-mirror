(define-package "base16-theme" "20220621.905" "Collection of themes built on combinations of 16 base colors" 'nil :commit "21f089896a7d2a9cc202a59d971b075b6703e9b3" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/base16-project/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
