;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260505.615"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "43ea4cb4898e7b3dd72571f0d89953a4fe3db0ec"
  :revdesc "43ea4cb4898e"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
