(define-package "loopy" "20210627.216" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "107dcc3490ddd38ca85fd77c80de2761dc2be734" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
