(define-package "elsa" "20220208.17" "Emacs Lisp Static Analyser"
  '((trinary "1.0.0")
    (emacs "25.1")
    (seq "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3"))
  :commit "82ffb6eecefde7e99383e4a657f17fe414287846" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
