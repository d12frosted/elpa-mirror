;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250523.230"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "93c98514d0daf3d10a116e03a96042a8e263f5d3"
  :revdesc "93c98514d0da"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
