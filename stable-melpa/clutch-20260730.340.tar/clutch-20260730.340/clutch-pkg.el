;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260730.340"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "6798a93cd4f171b8eb142934c79ac84351ccb5d5"
  :revdesc "6798a93cd4f1"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
