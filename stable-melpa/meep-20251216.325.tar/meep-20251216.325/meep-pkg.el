;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251216.325"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "7bc27a9e809f6c5c6c45cd2d35e27af4d39696fb"
  :revdesc "7bc27a9e809f"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
