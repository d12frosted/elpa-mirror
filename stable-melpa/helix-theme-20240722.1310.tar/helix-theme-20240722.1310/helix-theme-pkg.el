(define-package "helix-theme" "20240722.1310" "Color theme inspired by Helix editor's default colors" 'nil :commit "38a146111f928640b12fa61cf286f6e25f759e60" :keywords
  '("faces")
  :url "https://github.com/ibakepunk/helix-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
