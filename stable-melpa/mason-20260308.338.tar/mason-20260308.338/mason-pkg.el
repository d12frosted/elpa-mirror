;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20260308.338"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/deirn/mason.el"
  :commit "13762996bb91a6abc667d56878da47b2e7ba409e"
  :revdesc "13762996bb91"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
