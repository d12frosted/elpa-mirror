(define-package "magit-section" "20210220.1153" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "cd6ddba4831602cf7646c013f181b5e5f38c796f" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
