(define-package "prettier" "20220525.750" "Code formatting with Prettier"
  '((emacs "26.1")
    (iter2 "0.9")
    (nvm "0.2"))
  :commit "8001def9fff84b42953f096ea06a916b21c2f310" :authors
  '(("Julian Scheid" . "julians37@gmail.com"))
  :maintainer
  '("Julian Scheid" . "julians37@gmail.com")
  :keywords
  '("convenience" "languages" "files")
  :url "https://github.com/jscheid/prettier.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
