;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260606.1946"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "080522bfb11e59d4a9dd9ed31bfb0b2e9c96fd33"
  :revdesc "080522bfb11e")
