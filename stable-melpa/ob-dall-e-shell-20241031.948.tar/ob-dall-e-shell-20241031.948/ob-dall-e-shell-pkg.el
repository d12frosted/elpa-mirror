;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-dall-e-shell" "20241031.948"
  "Org babel functions for DALL-E evaluation."
  '((emacs        "27.1")
    (dall-e-shell "0.42.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "feb2c85d75a5cf3877aa351744390f16909a67ee"
  :revdesc "feb2c85d75a5")
