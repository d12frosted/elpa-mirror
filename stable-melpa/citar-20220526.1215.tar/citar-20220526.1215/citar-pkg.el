(define-package "citar" "20220526.1215" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "3.0")
    (org "9.5")
    (citeproc "0.9"))
  :commit "6a1031f50b3e53dc1b3fc4bc51b10cf725ac86f0" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
