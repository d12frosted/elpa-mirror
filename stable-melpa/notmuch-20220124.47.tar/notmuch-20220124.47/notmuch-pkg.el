(define-package "notmuch" "20220124.47" "run notmuch within emacs" 'nil :commit "3bf6487359b693af572867083da06de2663fb1f8" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
