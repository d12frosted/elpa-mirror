;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260311.2138"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "a4cc9a1907a9c64b339325e31658f8769947c6c8"
  :revdesc "a4cc9a1907a9"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
