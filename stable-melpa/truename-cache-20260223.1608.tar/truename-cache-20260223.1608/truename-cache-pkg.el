;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260223.1608"
  "Efficiently de-dup file-names."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "22d8e5967505834f0e3fcc7d57c2f71630611a61"
  :revdesc "22d8e5967505"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
