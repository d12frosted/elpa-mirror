;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250102.145"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "13fd0064fce42fd4ea11ea3a5bcbee33ac30a197"
  :revdesc "13fd0064fce4"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
