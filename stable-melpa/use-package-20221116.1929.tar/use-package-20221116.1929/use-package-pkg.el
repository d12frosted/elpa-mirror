(define-package "use-package" "20221116.1929" "A configuration macro for simplifying your .emacs"
  '((emacs "24.3")
    (bind-key "2.4"))
  :commit "f23d1d9a5a11626e2a90c221abf099b57df4b05b" :authors
  '(("John Wiegley" . "johnw@newartisans.com"))
  :maintainer
  '("John Wiegley" . "johnw@newartisans.com")
  :keywords
  '("dotemacs" "startup" "speed" "config" "package")
  :url "https://github.com/jwiegley/use-package")
;; Local Variables:
;; no-byte-compile: t
;; End:
