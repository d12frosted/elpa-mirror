;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260731.1006"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "e937698299226493cf3d6f563c9f5e574505172a"
  :revdesc "e93769829922"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
