;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260103.1849"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "7a44cc0c083cec474bcbd2f48a25a53f234b34f0"
  :revdesc "7a44cc0c083c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
