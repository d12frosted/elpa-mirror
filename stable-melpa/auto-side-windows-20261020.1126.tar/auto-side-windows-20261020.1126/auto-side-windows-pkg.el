;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-side-windows" "20261020.1126"
  "Simplified buffer management for side windows."
  '((emacs "30.1"))
  :url "https://github.com/MArpogaus/auto-side-windows"
  :commit "95dedb1441765a817054372a2fccbe9fd7b9a22d"
  :revdesc "95dedb144176"
  :keywords '("convenience" "windows" "buffers")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
