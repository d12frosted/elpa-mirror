;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241228.1751"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "5db95714ac27907b7b3b1ca1f3f6e3922d1271a6"
  :revdesc "5db95714ac27"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
