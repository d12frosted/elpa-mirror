;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260212.1510"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "cfb875ca3dc6de03a31a7780b109a7fc0e77f53c"
  :revdesc "cfb875ca3dc6"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
