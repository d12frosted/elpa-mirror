(define-package "elsa" "20211126.25" "Emacs Lisp Static Analyser"
  '((trinary "1.0.0")
    (emacs "25.1")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3"))
  :commit "38a57df3931e7073046cc0bced9ff3d9e909adfb" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
