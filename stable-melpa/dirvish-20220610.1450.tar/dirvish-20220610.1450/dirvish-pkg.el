(define-package "dirvish" "20220610.1450" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "3d3230842632356ee9d4e6a67d419b0a5335e239" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
