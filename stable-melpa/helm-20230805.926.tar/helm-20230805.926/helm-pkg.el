(define-package "helm" "20230805.926" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.2")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "8de9b5ab4b1bd7c5ea4906b1b62f9fb788b60148" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
