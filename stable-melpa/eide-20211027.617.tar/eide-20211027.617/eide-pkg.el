(define-package "eide" "20211027.617" "IDE interface" 'nil :commit "5bb04501a7f5bb3f5be33b8b96742f1ac9839a8d" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://eide.hjuvi.fr.eu.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
