;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode-extra-font-locking" "20260212.1414"
  "Extra font-locking for Clojure mode."
  '((clojure-mode "3.0"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "b88e25b0d7abb4aa89ccda9900f1329ca2908951"
  :revdesc "b88e25b0d7ab"
  :keywords '("languages" "lisp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
