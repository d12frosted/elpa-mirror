;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ast-grep" "20260614.214"
  "Search code using ast-grep with completing-read interface."
  '((emacs "28.1"))
  :url "https://github.com/sunskyxh/ast-grep.el"
  :commit "c9fd7eb160c6b16cdd5d77ca639326d02ad7bb55"
  :revdesc "c9fd7eb160c6"
  :keywords '("tools" "matching")
  :authors '(("SunskyxXH" . "sunskyxh@gmail.com"))
  :maintainers '(("SunskyxXH" . "sunskyxh@gmail.com")))
