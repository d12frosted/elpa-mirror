;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260430.2250"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "c118f15abd2fa92d2b328f77d4322ab2b38dedfb"
  :revdesc "c118f15abd2f"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
