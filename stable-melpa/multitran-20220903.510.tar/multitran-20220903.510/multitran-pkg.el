(define-package "multitran" "20220903.510" "Interface to multitran"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "6244e227bcf57eed391eecb34bae445f9c17e809" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("dictionary" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
