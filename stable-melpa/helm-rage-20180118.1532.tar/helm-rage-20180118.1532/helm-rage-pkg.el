(define-package "helm-rage" "20180118.1532" "Helm command for rage characters."
  '((helm "1.9.8")
    (emacs "24.4")
    (dash "2.13.0")
    (s "1.11.0"))
  :commit "5d0aefb53d859186181d4bdcfeff7d315339c7b8" :keywords
  '("helm" "rage" "meme")
  :url "https://github.com/bomgar/helm-rage")
;; Local Variables:
;; no-byte-compile: t
;; End:
