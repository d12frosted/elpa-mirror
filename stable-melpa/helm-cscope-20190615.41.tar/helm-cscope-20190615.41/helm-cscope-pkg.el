;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-cscope" "20190615.41"
  "Helm interface for xcscope.el."
  '((xcscope "1.0")
    (helm    "1.6.7")
    (cl-lib  "0.5")
    (emacs   "24.1"))
  :url "https://github.com/alpha22jp/helm-cscope.el"
  :commit "af1d9e7f4460a88d7400b5a74d5da68084089ac1"
  :revdesc "af1d9e7f4460"
  :keywords '("cscope" "helm")
  :authors '(("alpha22jp" . "alpha22jp@gmail.com"))
  :maintainers '(("alpha22jp" . "alpha22jp@gmail.com")))
