(define-package "osm" "20230114.1331" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.1.1"))
  :commit "a786ea940b3d7befc3e8cc26c3550660b0e86811" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
