(define-package "modus-themes" "20220520.350" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "9c80eba37de776e298432f84b9aa437e01c32e1a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
