(define-package "modus-themes" "20210729.950" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "7447abafd82a1a7f9696ed5c193ae683609b5b82" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
