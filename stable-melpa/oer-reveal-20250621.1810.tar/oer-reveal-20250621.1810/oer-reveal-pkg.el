;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "20250621.1810"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.35.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "ba7930ea3c8fce8aa41374ae8eb46829e1ce361e"
  :revdesc "ba7930ea3c8f"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
