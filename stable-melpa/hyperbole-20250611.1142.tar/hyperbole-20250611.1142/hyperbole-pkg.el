;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250611.1142"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "14707845dbb789a93e8e1523945b9dea108cf03b"
  :revdesc "14707845dbb7"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
