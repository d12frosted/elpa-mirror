(define-package "rg" "20220319.1216" "A search tool based on ripgrep"
  '((emacs "25.1")
    (transient "0.3.0")
    (wgrep "2.1.10"))
  :commit "77a709626609e7069f457e1b1885b76ebb98a354" :authors
  '(("David Landell" . "david.landell@sunnyhill.email")
    ("Roland McGrath" . "roland@gnu.org"))
  :maintainer
  '("David Landell" . "david.landell@sunnyhill.email")
  :keywords
  '("matching" "tools")
  :url "https://github.com/dajva/rg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
