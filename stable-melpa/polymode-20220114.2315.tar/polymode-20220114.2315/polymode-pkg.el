(define-package "polymode" "20220114.2315" "Extensible framework for multiple major modes"
  '((emacs "25"))
  :commit "355daf3db8e02f1d5a75600d2d3a5325b54d1739" :authors
  '(("Vitalie Spinu"))
  :maintainer
  '("Vitalie Spinu")
  :keywords
  '("languages" "multi-modes" "processes")
  :url "https://github.com/polymode/polymode")
;; Local Variables:
;; no-byte-compile: t
;; End:
