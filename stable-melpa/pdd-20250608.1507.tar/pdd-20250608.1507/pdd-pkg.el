;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250608.1507"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "49ab45180762562cb26f5c8b15563dff2c53e67e"
  :revdesc "49ab45180762"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
