(define-package "typescript-mode" "20211022.653" "Major mode for editing typescript"
  '((emacs "24.3"))
  :commit "dd832751abf27f4dd098f09e2dbf69511faa38a5" :keywords
  '("typescript" "languages")
  :url "http://github.com/ananthakumaran/typescript.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
