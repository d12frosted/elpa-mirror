(define-package "editorconfig" "20210809.1523" "EditorConfig Emacs Plugin"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (emacs "24"))
  :commit "f14ea2ede4a7cc3e96c2d4e2265093b62c51442c" :authors
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainer
  '("EditorConfig Team" . "editorconfig@googlegroups.com")
  :url "https://github.com/editorconfig/editorconfig-emacs#readme")
;; Local Variables:
;; no-byte-compile: t
;; End:
