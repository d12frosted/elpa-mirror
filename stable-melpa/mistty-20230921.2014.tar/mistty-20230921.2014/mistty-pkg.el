(define-package "mistty" "20230921.2014" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "5fa2b91c1dec9eaa4f363d13e9ef2ff301f85b66" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
