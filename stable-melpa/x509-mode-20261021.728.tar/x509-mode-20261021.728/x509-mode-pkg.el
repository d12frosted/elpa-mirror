;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261021.728"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "c34975bbe74b6489266d7568b3faec98d5a4d238"
  :revdesc "c34975bbe74b"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
