(define-package "verb" "20231119.2118" "Organize and send HTTP requests"
  '((emacs "26.3"))
  :commit "f688f58b5a3bce5c92cd36c922d98a9e50809fcd" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
