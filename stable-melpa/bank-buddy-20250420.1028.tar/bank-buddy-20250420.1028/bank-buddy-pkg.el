;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bank-buddy" "20250420.1028"
  "Financial analysis and reporting."
  '((emacs "26.1")
    (async "1.9.4"))
  :url "https://github.com/captainflasmr/bank-buddy"
  :commit "d8ed128fa27e05e1502318b9ea69e428d53a0d51"
  :revdesc "d8ed128fa27e"
  :keywords '("matching")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
