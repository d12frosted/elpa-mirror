(define-package "ghub" "20220423.2114" "Client libraries for Git forge APIs."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (let-alist "1.0.6")
    (treepy "0.1.1"))
  :commit "5eed205902b02c01cf16057ef50887b117718cf6" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
