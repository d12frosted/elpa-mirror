;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260601.1421"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "e5c2ebee68985a30c5eec2a0b623f2cc687920c6"
  :revdesc "e5c2ebee6898"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
