(define-package "spdx" "20210414.1332" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "4f1e7c565b0f5e0bbf08e53418911a87e31e0f4a" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
