(define-package "nickel-mode" "20230502.841" "A major mode for editing Nickel source code"
  '((emacs "24.3"))
  :commit "4b92668564025b18a3d4da47db51d6360cf9da44" :authors
  '(("The Nickel Team" . "nickel-lang@tweag.io"))
  :maintainers
  '(("The Nickel Team" . "nickel-lang@tweag.io"))
  :maintainer
  '("The Nickel Team" . "nickel-lang@tweag.io")
  :keywords
  '("languages" "configuration-language" "configuration" "nickel" "infrastructure")
  :url "https://github.com/nickel-lang/nickel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
