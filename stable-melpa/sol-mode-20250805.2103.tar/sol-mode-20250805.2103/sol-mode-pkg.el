;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sol-mode" "20250805.2103"
  "Major mode for editing Solidity code."
  '((emacs "30.1"))
  :url "https://codeberg.org/nlordell/sol-mode"
  :commit "1379290f360fb3fea98ae397996b08d32372d77d"
  :revdesc "1379290f360f"
  :keywords '("solidity" "languages")
  :authors '(("Nicholas Rodrigues Lordello" . "n@lordello.net"))
  :maintainers '(("Nicholas Rodrigues Lordello" . "n@lordello.net")))
