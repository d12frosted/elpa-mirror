;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260726.1707"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "b083deabff2b937e6b0eaae0f7daa6d09c3c4c64"
  :revdesc "b083deabff2b"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
