;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "espy" "20250417.1352"
  "Emacs Simple Password Yielder."
  '((emacs "24"))
  :url "https://github.com/walseb/espy"
  :commit "f58049ed86798b6cb7f462e0a71bf3ecb1f0f9e5"
  :revdesc "f58049ed8679"
  :keywords '("convenience")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
