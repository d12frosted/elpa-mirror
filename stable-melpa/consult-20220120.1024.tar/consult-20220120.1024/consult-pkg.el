(define-package "consult" "20220120.1024" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "be08570d530f74c1e35a58db986d675140cadc3c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
