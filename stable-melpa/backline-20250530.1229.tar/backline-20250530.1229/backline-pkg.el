;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backline" "20250530.1229"
  "Preserve appearance of outline headings."
  '((emacs               "26.1")
    (compat              "30.0.0.0")
    (outline-minor-faces "1.0.2"))
  :url "https://github.com/tarsius/backline"
  :commit "d8ae18678beaeae6afc22e9b20c74975765721c3"
  :revdesc "d8ae18678bea"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev")))
