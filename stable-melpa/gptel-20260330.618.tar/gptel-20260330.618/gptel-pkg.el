;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260330.618"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "e1adf9c184dc18ad22c3676910e092411d78d414"
  :revdesc "e1adf9c184dc"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
