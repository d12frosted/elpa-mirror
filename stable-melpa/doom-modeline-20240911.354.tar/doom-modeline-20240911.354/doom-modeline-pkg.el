(define-package "doom-modeline" "20240911.354" "A minimal and modern mode-line"
  '((emacs "25.1")
    (compat "29.1.4.5")
    (nerd-icons "0.1.0")
    (shrink-path "0.3.1"))
  :commit "297fb8c4e0d9c0485d7a35943a9f725102294815" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
