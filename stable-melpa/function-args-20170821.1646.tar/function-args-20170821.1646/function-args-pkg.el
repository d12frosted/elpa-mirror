(define-package "function-args" "20170821.1646" "C++ completion for GNU Emacs"
  '((ivy "0.9.1"))
  :commit "0b07db81c0c1fa88d1ec763219ee57640858f79d" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :url "https://github.com/abo-abo/function-args")
;; Local Variables:
;; no-byte-compile: t
;; End:
