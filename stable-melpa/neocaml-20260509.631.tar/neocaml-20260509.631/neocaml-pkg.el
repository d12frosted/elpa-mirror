;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260509.631"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "5ce7ee40883e3e47b3f91ed5603105c4029d85ce"
  :revdesc "5ce7ee40883e"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
