;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rare-words" "20260401.618"
  "Highlight your rare words!."
  '((emacs "29.1"))
  :url "https://github.com/amolv06/rare-words"
  :commit "7e6b3e2083dd37e1a150422c648c28d3b703f185"
  :revdesc "7e6b3e2083dd"
  :authors '(("Amol Vaidya" . "amolvaidya.signup@gmail.com"))
  :maintainers '(("Amol Vaidya" . "amolvaidya.signup@gmail.com")))
