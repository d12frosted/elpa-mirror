;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magic-latex-buffer" "20261028.1939"
  "Magically enhance LaTeX-mode font-locking for semi-WYSIWYG editing."
  '((cl-lib "0.5")
    (emacs  "25.1"))
  :url "http://zk-phi.github.io/"
  :commit "0b07e77490c6167aab26e9be36cf0f4a6b23c80c"
  :revdesc "0b07e77490c6")
