(define-package "gptel" "20230623.2022" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "3d98ce8eeecd193a61efc1674ba33d1c94ef56f2" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
