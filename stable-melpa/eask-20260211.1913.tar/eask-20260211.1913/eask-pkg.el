;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20260211.1913"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "1d46b7d5e6799b9520f08920560f7d5d0ca02499"
  :revdesc "1d46b7d5e679"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
