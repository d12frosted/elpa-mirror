(define-package "gcode-mode" "20201011.1745" "Simple G-Code major mode"
  '((emacs "24.4"))
  :commit "2192ec743b49d9adfb9116ab410b195725dc886a" :keywords
  ("gcode" "languages" "highlight" "syntax")
  :authors
  (("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainer
  ("Yuri D'Elia" . "wavexx@thregr.org")
  :url "https://gitlab.com/wavexx/gcode-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
