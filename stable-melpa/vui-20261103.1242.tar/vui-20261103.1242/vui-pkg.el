;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261103.1242"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "43ebe180819b5d1ace15274cd2a96d500850df7e"
  :revdesc "43ebe180819b"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
