;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "20260812.607"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "30.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "6752741314e3adfba5e36832c35164d7238f7ed2"
  :revdesc "6752741314e3"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
