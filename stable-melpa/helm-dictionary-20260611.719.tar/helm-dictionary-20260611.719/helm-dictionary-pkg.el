;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-dictionary" "20260611.719"
  "Helm source for looking up dictionaries."
  '((helm "1.5.5"))
  :url "https://github.com/emacs-helm/helm-dictionary"
  :commit "79eb9b8b33cb3fd8228efde146e23866b4a02652"
  :revdesc "79eb9b8b33cb"
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de")
             ("Michael Heerdegen" . "michael_heerdegen@web.de"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
