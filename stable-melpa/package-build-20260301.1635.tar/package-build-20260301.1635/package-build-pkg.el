;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260301.1635"
  "Tools for assembling a package archive."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/melpa/package-build"
  :commit "de5b4dada04d85c4df7a424e23a9e637669e4e1e"
  :revdesc "de5b4dada04d"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")))
