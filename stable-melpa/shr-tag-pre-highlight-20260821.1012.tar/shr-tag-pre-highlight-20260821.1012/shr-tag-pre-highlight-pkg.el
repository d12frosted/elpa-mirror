;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shr-tag-pre-highlight" "20260821.1012"
  "Syntax highlighting code block in HTML."
  '((emacs              "25.1")
    (language-detection "0.1.0"))
  :url "https://github.com/xuchunyang/shr-tag-pre-highlight.el"
  :commit "f2b390a6297a9bf6a4527f79527f582a1ecced66"
  :revdesc "f2b390a6297a"
  :keywords '("html")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
