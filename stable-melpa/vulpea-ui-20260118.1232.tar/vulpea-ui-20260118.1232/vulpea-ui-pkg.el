;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20260118.1232"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.0.0")
    (vui    "0.1"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "2b07223f4e40cf309ad7215295afabc6ac9ecad7"
  :revdesc "2b07223f4e40"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
