(define-package "dirvish" "20220516.718" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "7fd3c317e7def7e2421ec0a65612e8f869c5e3f4" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
