(define-package "borg" "20230117.1759" "Assimilate Emacs packages as Git submodules"
  '((emacs "27.1")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "765dca9f3568c78e335369fd5eb65e7be1a661ea" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
