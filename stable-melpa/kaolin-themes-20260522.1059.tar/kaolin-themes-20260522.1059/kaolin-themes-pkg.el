;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "20260522.1059"
  "A set of eye pleasing themes."
  '((emacs      "26.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "74242fa1b30cd9e3ddb920c6ab53b2a91414b849"
  :revdesc "74242fa1b30c"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
