;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260705.419"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "83e577939bef55cb181a69a503301b7396a4fd39"
  :revdesc "83e577939bef"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
