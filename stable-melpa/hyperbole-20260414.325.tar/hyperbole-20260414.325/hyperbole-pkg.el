;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260414.325"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "78b70e550a9764fc89a1bcc1d29eae39bdc550da"
  :revdesc "78b70e550a97"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
