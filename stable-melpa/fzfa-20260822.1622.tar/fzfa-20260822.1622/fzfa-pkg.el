;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260822.1622"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.2"))
  :url "https://github.com/jojojames/fzfa"
  :commit "260b3d3a37fdad5b36e8c7c949c2262353df36aa"
  :revdesc "260b3d3a37fd"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
