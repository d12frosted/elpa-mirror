;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mindstream" "20241023.840"
  "Start writing, stay focused, don't worry."
  '((emacs "25.1")
    (magit "3.3.0"))
  :url "https://github.com/countvajhula/mindstream"
  :commit "df063ef856c9e00f904eab9108bff5ac73c56b9d"
  :revdesc "df063ef856c9"
  :keywords '("convenience" "files" "languages" "outlines" "tools" "vc" "wp")
  :authors '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Siddhartha Kasivajhula" . "sid@countvajhula.com")))
