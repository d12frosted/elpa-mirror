(define-package "erlang" "20220213.554" "Erlang major mode"
  '((emacs "24.1"))
  :commit "2413ca0be7f2a076be9e152cbec7f8bf33ba7d9a" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
