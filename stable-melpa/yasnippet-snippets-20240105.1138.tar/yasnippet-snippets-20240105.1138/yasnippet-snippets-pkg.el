(define-package "yasnippet-snippets" "20240105.1138" "Collection of yasnippet snippets"
  '((yasnippet "0.8.0"))
  :commit "9799ec9ffa45e1ebef895e4573abc0d188ecee0e" :authors
  '(("Andrea Crotti" . "andrea.crotti.0@gmail.com"))
  :maintainers
  '(("Andrea Crotti" . "andrea.crotti.0@gmail.com"))
  :maintainer
  '("Andrea Crotti" . "andrea.crotti.0@gmail.com")
  :keywords
  '("snippets")
  :url "https://github.com/AndreaCrotti/yasnippet-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
