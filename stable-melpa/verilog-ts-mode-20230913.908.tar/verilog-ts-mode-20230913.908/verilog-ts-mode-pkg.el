(define-package "verilog-ts-mode" "20230913.908" "Verilog Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "dff279d27073fc1ebde7865bba9211ee6e27f96e" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
