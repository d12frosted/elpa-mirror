;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-edit-indirect" "20220909.457"
  "Edit anything, not just source blocks."
  '((emacs         "27")
    (edit-indirect "0.1.10")
    (org           "9.0"))
  :url "https://github.com/agzam/org-edit-indirect.el"
  :commit "62894ac7b8b85eb03766f66072b0be10ffb6898e"
  :revdesc "62894ac7b8b8"
  :keywords '("convenience" "extensions" "outlines")
  :authors '(("Ag Ibragimomv" . "https://github.com/agzam"))
  :maintainers '(("Ag Ibragimomv" . "agzam.ibragimov@gmail.com")))
