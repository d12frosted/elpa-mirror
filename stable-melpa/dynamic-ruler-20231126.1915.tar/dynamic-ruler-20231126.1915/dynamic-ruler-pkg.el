;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynamic-ruler" "20231126.1915"
  "Displays a dynamic ruler at point."
  ()
  :url "http://rocher.github.io/dynamic-ruler"
  :commit "984877f3ad8dd4e4bdec2fcacb82a11b4f3b5d75"
  :revdesc "984877f3ad8d"
  :keywords '("ruler" "tools" "convenience")
  :authors '(("Francesc Rocher" . "francesc.rocher@gmail.com"))
  :maintainers '(("Francesc Rocher" . "francesc.rocher@gmail.com")))
