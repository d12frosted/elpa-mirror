;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "euslisp-mode" "20250823.1454"
  "Major mode for Euslisp-formatted text."
  '((emacs                "28.1")
    (s                    "1.9")
    (exec-path-from-shell "1.0")
    (helm                 "3.0"))
  :url "https://github.com/iory/euslisp-mode"
  :commit "bf74f683f3b0e127bf2c0e8082fe097e897cd572"
  :revdesc "bf74f683f3b0"
  :keywords '("languages" "lisp")
  :authors '(("iory" . "ab.ioryz@gmail.com"))
  :maintainers '(("iory" . "ab.ioryz@gmail.com")))
