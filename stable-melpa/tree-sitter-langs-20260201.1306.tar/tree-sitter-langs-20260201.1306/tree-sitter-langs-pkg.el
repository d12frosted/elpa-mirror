;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-langs" "20260201.1306"
  "Grammar bundle for tree-sitter."
  '((emacs       "26.1")
    (tree-sitter "0.15.0"))
  :url "https://github.com/emacs-tree-sitter/tree-sitter-langs"
  :commit "99af89c015c1272e4567048a5dd064144a917348"
  :revdesc "99af89c015c1"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
