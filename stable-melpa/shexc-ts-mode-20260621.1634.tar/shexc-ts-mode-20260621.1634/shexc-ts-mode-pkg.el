;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "20260621.1634"
  "Tree-sitter major mode for ShExC."
  '((emacs     "29.1")
    (transient "0.5.0")
    (compat    "29.1.4.4"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "9e944de428d380c8382ace1d8007bbdb714e09d8"
  :revdesc "9e944de428d3"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
