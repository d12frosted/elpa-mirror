;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260426.1813"
  "Pure Elisp HTTP server."
  '((emacs  "26.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "e560196595778a356bfa0aad8895a75f9a0fdaaf"
  :revdesc "e56019659577"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
