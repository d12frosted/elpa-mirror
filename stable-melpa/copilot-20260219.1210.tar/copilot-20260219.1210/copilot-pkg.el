;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260219.1210"
  "An unofficial Copilot plugin."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "b16137fa8bf5d875fd6f9c91eea663ee1651d921"
  :revdesc "b16137fa8bf5"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Rakotomandimby Mihamina" . "mihamina.rakotomandimby@rktmb.org")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
