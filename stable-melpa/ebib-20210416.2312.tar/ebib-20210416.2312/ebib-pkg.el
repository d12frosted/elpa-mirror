(define-package "ebib" "20210416.2312" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "dbb22e04f0b147771809b5dd8cfe4f3e508920a7" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
