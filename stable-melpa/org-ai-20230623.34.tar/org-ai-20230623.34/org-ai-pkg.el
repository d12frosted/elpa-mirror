(define-package "org-ai" "20230623.34" "Your AI assistant with ChatGPT, DALL-E, Whisper, Stable Diffusion"
  '((emacs "28.2"))
  :commit "b10f20b8e9fd00e7cfad3a5ebe0e5756de666354" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
