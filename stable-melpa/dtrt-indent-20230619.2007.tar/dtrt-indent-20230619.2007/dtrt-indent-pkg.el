(define-package "dtrt-indent" "20230619.2007" "Adapt to foreign indentation offsets" 'nil :commit "8b13cad77dbce79db24a08a9ab6fa230b6b74bc9" :authors
  '(("Julian Scheid" . "julians37@googlemail.com"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("convenience" "files" "languages" "c"))
;; Local Variables:
;; no-byte-compile: t
;; End:
