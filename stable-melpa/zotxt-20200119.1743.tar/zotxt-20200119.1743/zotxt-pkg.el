(define-package "zotxt" "20200119.1743" "Tools to integrate emacs with Zotero via the zotxt plugin."
  '((request "0.3.2")
    (deferred "0.5.1"))
  :commit "98323098c37a444de49cfef44f1506e9386e8c5f" :authors
  '(("Erik Hetzner" . "egh@e6h.org"))
  :maintainer
  '("Erik Hetzner" . "egh@e6h.org")
  :keywords
  '("bib"))
;; Local Variables:
;; no-byte-compile: t
;; End:
