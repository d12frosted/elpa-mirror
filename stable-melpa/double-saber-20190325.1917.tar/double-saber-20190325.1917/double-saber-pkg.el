;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "double-saber" "20190325.1917"
  "Narrow and delete in search buffers."
  '((emacs "24.4"))
  :url "https://github.com/dp12/double-saber.git"
  :commit "5555dc28cbaa228fa8f9390738a4200e071380b8"
  :revdesc "5555dc28cbaa"
  :keywords '("double-saber" "narrow" "delete" "sort" "tools" "convenience" "matching")
  :authors '(("Daniel Ting" . "deep.paren.12@gmail.com"))
  :maintainers '(("Daniel Ting" . "deep.paren.12@gmail.com")))
