;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250408.1405"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "1c582c44ffa438c8f3ff584666a6aca2a52478b3"
  :revdesc "1c582c44ffa4"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
