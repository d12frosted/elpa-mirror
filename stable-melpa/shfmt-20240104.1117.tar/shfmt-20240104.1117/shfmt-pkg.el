(define-package "shfmt" "20240104.1117" "Reformat shell scripts using shfmt"
  '((emacs "24")
    (reformatter "0.3"))
  :commit "37964b5901f8acab0c87acaa0fbb6256443193e7" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("languages")
  :url "https://github.com/purcell/emacs-shfmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
