;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-hy" "20180702.540"
  "Org-babel functions for Hy-lang evaluation."
  '((emacs "24.4"))
  :url "https://github.com/brantou/ob-hy"
  :commit "a42ecaf440adc03e279afe43ee5ef6093ddd542a"
  :revdesc "a42ecaf440ad"
  :keywords '("hy" "literate programming" "reproducible research")
  :authors '(("Brantou" . "brantou89@gmail.com"))
  :maintainers '(("Brantou" . "brantou89@gmail.com")))
