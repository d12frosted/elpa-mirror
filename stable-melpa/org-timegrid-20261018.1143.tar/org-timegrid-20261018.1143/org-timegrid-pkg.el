;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261018.1143"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "43c9fd027df9a66375e45cfc86915f201c03470d"
  :revdesc "43c9fd027df9"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
