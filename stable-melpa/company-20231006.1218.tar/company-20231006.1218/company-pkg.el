(define-package "company" "20231006.1218" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "3ab242fcc756a6c55e3a1609f840210cacdc86c7" :authors
  '(("Nikolaj Schumacher"))
  :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
