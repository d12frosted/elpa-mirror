;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251220.1739"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "2514504aa108f2bdf96152d8ddd7197034a20f5b"
  :revdesc "2514504aa108"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
