;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260916.2109"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "deacd6770efec5d9f98fc74df781fc0836124d79"
  :revdesc "deacd6770efe"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
