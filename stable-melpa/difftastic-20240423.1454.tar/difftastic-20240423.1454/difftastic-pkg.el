(define-package "difftastic" "20240423.1454" "Wrapper for difftastic"
  '((emacs "28.1")
    (compat "29.1.4.2")
    (magit "20220326"))
  :commit "9b6414cb7131dcdf1f760a82b79928ff46afe1e4" :authors
  '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers
  '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainer
  '("Przemyslaw Kryger" . "pkryger@gmail.com")
  :keywords
  '("tools" "diff")
  :url "https://github.com/pkryger/difftastic.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
