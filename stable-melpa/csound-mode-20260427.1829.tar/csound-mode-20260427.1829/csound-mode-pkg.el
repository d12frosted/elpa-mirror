;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csound-mode" "20260427.1829"
  "A major mode for interacting and coding Csound."
  '((emacs     "25")
    (shut-up   "0.3.2")
    (multi     "2.0.1")
    (dash      "2.16.0")
    (highlight "0"))
  :url "https://github.com/hlolli/csound-mode"
  :commit "21c171177a8e62fef6d7e3a7acfcd585a12e92ed"
  :revdesc "21c171177a8e"
  :authors '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers '(("Hlöðver Sigurðsson" . "hlolli@gmail.com")))
