(define-package "gptai" "20230318.32" "Integrate with the OpenAI API"
  '((emacs "24.1"))
  :commit "e2fb58785e1e8ae2956d0786d77821a5c2d2b326" :authors
  '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainer
  '("Anton Hibl" . "antonhibl11@gmail.com")
  :keywords
  '("comm" "convenience")
  :url "https://github.com/antonhibl/gptai")
;; Local Variables:
;; no-byte-compile: t
;; End:
