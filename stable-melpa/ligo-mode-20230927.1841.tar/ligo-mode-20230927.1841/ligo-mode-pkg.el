(define-package "ligo-mode" "20230927.1841" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "a392154388b1abe974f424b71a66d618010f9e95" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
