;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260221.2120"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "3f15fa6fd975e6d009d3c13e946d737c3fa46bf6"
  :revdesc "3f15fa6fd975"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
