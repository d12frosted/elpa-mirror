;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260404.1402"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "49ce5af0cb35b3321e73cb8b5105de4539ca6dac"
  :revdesc "49ce5af0cb35"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
