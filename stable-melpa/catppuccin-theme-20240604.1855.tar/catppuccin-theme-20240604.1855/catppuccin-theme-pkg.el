(define-package "catppuccin-theme" "20240604.1855" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "729e6be465d64d8511a88d1c37ac184a42e22feb" :authors
  '(("nyxkrage"))
  :maintainers
  '(("Carsten Kragelund" . "carsten@kragelund.me"))
  :maintainer
  '("Carsten Kragelund" . "carsten@kragelund.me")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
