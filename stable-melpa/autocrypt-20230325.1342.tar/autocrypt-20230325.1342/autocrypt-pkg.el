(define-package "autocrypt" "20230325.1342" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "a90aa6b644fe8cf72af9e1615a7c50b36b739e7c" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
