;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20260306.329"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "80c5ecd36483170f18612d9977e1765dfbf57b9c"
  :revdesc "80c5ecd36483"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
