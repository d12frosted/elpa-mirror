(define-package "cape" "20220430.1439" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "640e53f909f6702ff8a9069f4d250f8d936cfe7f" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
