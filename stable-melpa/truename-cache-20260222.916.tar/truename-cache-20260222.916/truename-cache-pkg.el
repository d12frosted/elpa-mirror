;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260222.916"
  "Efficiently de-dup file-names."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "65230aa058e771a65310fab956d1b836a5555e99"
  :revdesc "65230aa058e7"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
