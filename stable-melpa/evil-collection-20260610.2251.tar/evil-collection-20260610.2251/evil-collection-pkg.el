;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260610.2251"
  "A set of keybindings for Evil mode."
  '((emacs "26.3")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "e2888aa77ed2cfc0a5467479909e9ae2f0ab6e3d"
  :revdesc "e2888aa77ed2"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
