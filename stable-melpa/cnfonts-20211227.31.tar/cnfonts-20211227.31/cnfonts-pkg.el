(define-package "cnfonts" "20211227.31" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "75d3c0c85b31cc893521631dbb6bd4ae5e81b7ec" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
