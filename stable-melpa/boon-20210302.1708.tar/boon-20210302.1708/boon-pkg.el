(define-package "boon" "20210302.1708" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "032ce857ad42270cc85abc1fb0c29e74d292b106")
;; Local Variables:
;; no-byte-compile: t
;; End:
