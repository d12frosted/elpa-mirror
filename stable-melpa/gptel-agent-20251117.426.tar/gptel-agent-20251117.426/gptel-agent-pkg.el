;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20251117.426"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "4974961b7000e0b2c6c0168ae2405f12abc5a122"
  :revdesc "4974961b7000"
  :keywords '("comm"))
