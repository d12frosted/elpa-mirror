(define-package "spdx" "20230310.121" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "41faed1b7f82bff05883c9cea2b541a47651ae0f" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
