(define-package "pet" "20230820.137" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0"))
  :commit "95e758d5277e420ef5ad7671c27f670b967fbf5d" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
