;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20260213.1849"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "e5dec95452de8b4cbacf41156d4dfa261668ae31"
  :revdesc "e5dec95452de")
