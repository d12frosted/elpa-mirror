;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260528.1506"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "c5ec011852d3e8a1b7d90deba8b761af46789728"
  :revdesc "c5ec011852d3"
  :keywords '("convenience" "chinese" "input-method" "rime"))
