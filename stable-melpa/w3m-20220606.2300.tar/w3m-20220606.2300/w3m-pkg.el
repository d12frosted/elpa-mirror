(define-package "w3m" "20220606.2300" "an Emacs interface to w3m" 'nil :commit "e3ca74f62602e69af5ff3271bd98977bd490e9de" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
