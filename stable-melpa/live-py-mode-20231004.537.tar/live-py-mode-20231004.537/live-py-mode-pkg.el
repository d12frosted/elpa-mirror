(define-package "live-py-mode" "20231004.537" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "5a94b98a15fb8c4c539b37d8583db1e427308b44" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainers
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
