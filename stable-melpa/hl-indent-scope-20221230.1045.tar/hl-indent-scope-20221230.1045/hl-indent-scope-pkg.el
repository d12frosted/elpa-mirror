(define-package "hl-indent-scope" "20221230.1045" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "74052e8652a6695b8cdbb674dc35262781de1af1" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
