;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inverse-acme-theme" "20210204.1640"
  "A theme that looks like an inverse of Acme's color scheme."
  '((autothemer "0.2")
    (cl-lib     "0.5"))
  :url "https://github.com/dcjohnson/inverse-acme-theme"
  :commit "79008920ce7923312ada6f95a3ec1f96ce513c0b"
  :revdesc "79008920ce79")
