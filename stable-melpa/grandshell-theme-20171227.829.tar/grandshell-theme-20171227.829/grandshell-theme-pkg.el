(define-package "grandshell-theme" "20171227.829" "Dark color theme for Emacs > 24 with intensive colors." 'nil :commit "22c8df52c0fb8899fa748fa2980947ab38b53380" :authors
  '(("steckerhalter"))
  :maintainer
  '("steckerhalter")
  :keywords
  '("color" "theme" "grand" "shell" "faces")
  :url "https://github.com/steckerhalter/grandshell-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
