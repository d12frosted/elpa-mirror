;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-explorer" "20190909.1921"
  "Dynamic file browsing grid using ivy."
  '((emacs "25")
    (ivy   "0.10.0"))
  :url "https://github.com/clemera/ivy-explorer"
  :commit "a413966cfbcecacc082d99297fa1abde0c10d3f3"
  :revdesc "a413966cfbce"
  :keywords '("convenience" "files" "matching")
  :authors '(("Clemens Radermacher" . "clemera@posteo.net"))
  :maintainers '(("Clemens Radermacher" . "clemera@posteo.net")))
