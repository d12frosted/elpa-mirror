;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gumshoe" "20260215.918"
  "Scoped spatial and temporal POINT movement tracking."
  '((emacs "27.1"))
  :url "https://github.com/Overdr0ne/gumshoe"
  :commit "beb2442e44a820b2c2d4b6efb985892d14d82e80"
  :revdesc "beb2442e44a8"
  :keywords '("tools"))
