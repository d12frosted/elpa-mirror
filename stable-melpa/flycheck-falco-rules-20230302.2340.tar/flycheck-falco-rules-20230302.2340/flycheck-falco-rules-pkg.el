(define-package "flycheck-falco-rules" "20230302.2340" "On-the-fly syntax checking for falco rules files"
  '((emacs "24.3")
    (flycheck "0.25")
    (let-alist "1.0.1"))
  :commit "1ad301d497ade9556327053ca571ee51bf0c0633" :authors
  '(("The Falco Developers (https://falco.org)"))
  :maintainers
  '(("The Falco Developers (https://falco.org)"))
  :maintainer
  '("The Falco Developers (https://falco.org)")
  :keywords
  '("tools" "convenience")
  :url "https://github.com/falcosecurity/flycheck-falco-rules")
;; Local Variables:
;; no-byte-compile: t
;; End:
