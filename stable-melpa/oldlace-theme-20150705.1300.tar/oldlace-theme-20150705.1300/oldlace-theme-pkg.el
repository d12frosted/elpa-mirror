;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oldlace-theme" "20150705.1300"
  "Emacs 24 theme with an 'oldlace' background."
  '((emacs "24"))
  :url "https://github.com/mswift42/oldlace-theme"
  :commit "9ecbef999b63021c967846a3c80b3fbfc81f1290"
  :revdesc "9ecbef999b63")
