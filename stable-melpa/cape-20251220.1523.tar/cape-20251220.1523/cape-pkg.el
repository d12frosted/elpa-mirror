;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20251220.1523"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "a37254aa7e7634168c247d15a6c9df5a9baf357c"
  :revdesc "a37254aa7e76"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
