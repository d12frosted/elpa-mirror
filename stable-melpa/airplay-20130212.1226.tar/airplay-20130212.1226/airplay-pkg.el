(define-package "airplay" "20130212.1226" "Airplay bindings to Emacs"
  '((request "20130110.2144")
    (simple-httpd "1.4.1")
    (deferred "0.3.1"))
  :commit "46fad71d293a3e18551cf464fe6c6208a7a32d9d" :authors
  '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainer
  '("Wataru MIYAGUNI" . "gonngo@gmail.com")
  :keywords
  '("appletv" "airplay")
  :url "https://github.com/gongo/airplay-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
