(define-package "cask" "20220316.1557" "Cask: Project management for package development"
  '((emacs "24.5")
    (s "1.8.0")
    (f "0.16.0")
    (epl "0.5")
    (shut-up "0.1.0")
    (cl-lib "0.3")
    (package-build "0")
    (ansi "0.4.1"))
  :commit "ead8c3d8bfd25f41a5485b8dedfaa0c42ea08d91" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("speed" "convenience")
  :url "http://github.com/cask/cask")
;; Local Variables:
;; no-byte-compile: t
;; End:
