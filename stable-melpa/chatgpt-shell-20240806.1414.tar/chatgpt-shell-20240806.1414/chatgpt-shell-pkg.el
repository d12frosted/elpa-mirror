(define-package "chatgpt-shell" "20240806.1414" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.50.5"))
  :commit "e42e4d42b8978cdf8d7e7e8a5b7936cba80a035a" :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
