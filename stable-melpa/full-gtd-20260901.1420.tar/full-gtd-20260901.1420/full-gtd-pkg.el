;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "20260901.1420"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "27.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "5dadf34f3d0001c15900675bdb8e9bdb9148843a"
  :revdesc "5dadf34f3d00"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
