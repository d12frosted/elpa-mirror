;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verdict" "20260504.1454"
  "Generic test runner with treemacs results UI."
  '((emacs    "29.1")
    (treemacs "3.0")
    (dash     "2.0"))
  :url "https://github.com/tjarvstrand/verdict.el"
  :commit "256d402b45a33092dacf88186434dea9417bcf97"
  :revdesc "256d402b45a3"
  :keywords '("tools" "processes")
  :authors '(("Thomas Järvstrand" . "https://github.com/tjarvstrand"))
  :maintainers '(("Thomas Järvstrand" . "https://github.com/tjarvstrand")))
