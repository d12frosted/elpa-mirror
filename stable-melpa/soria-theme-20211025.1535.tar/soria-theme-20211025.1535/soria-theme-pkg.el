(define-package "soria-theme" "20211025.1535" "A xoria256 theme with some colors from openSUSE"
  '((emacs "25.1"))
  :commit "a111e7169405778d95f7a1e61a7d197ca1217edf" :authors
  '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainer
  '("Miquel Sabaté Solà" . "mikisabate@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/mssola/soria")
;; Local Variables:
;; no-byte-compile: t
;; End:
