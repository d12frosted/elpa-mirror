(define-package "epkg" "20211216.1834" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "9476086123834d0398968ce32c0a14e484a628cc" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
