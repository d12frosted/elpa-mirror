;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "puni" "20260504.457"
  "Parentheses Universalistic."
  '((emacs "26.1"))
  :url "https://github.com/AmaiKinono/puni"
  :commit "7adf54282c94267bf1d69aece94b816dd4af09bc"
  :revdesc "7adf54282c94"
  :keywords '("convenience" "lisp" "tools")
  :authors '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainers '(("Hao Wang" . "amaikinono@gmail.com")))
