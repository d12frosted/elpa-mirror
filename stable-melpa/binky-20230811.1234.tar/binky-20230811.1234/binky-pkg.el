(define-package "binky" "20230811.1234" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "83ad537a185dacff6e1aacc8ccb3ca519bb71668" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
