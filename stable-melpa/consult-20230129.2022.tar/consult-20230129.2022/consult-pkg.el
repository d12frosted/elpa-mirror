(define-package "consult" "20230129.2022" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "5a6e2c077892f48ba6a94b241cd1c595adc4c369" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
