(define-package "dwim-shell-command" "20220726.652" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "d20d778cc8f9157e2ea7781cef7337b3d838b01d" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
