;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250420.1720"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "306a07e92220ed49b5e835baa8a40300ee880add"
  :revdesc "306a07e92220"
  :keywords '("agent" "ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
