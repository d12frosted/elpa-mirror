;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loophole" "20221126.1556"
  "Manage temporary key bindings."
  '((emacs "27.1"))
  :url "https://github.com/0x60df/loophole"
  :commit "dadc3fadc68b13501c4dbe89109f30deb0d3441a"
  :revdesc "dadc3fadc68b"
  :keywords '("convenience")
  :authors '(("0x60DF" . "0x60df@gmail.com"))
  :maintainers '(("0x60DF" . "0x60df@gmail.com")))
