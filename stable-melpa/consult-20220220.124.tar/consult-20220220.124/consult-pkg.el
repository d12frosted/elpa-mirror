(define-package "consult" "20220220.124" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "1ce90d2e21c7bcbca2ce1a83a827ab98099ee892" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
