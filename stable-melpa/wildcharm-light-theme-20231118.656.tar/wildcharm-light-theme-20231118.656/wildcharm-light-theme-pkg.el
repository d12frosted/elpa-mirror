(define-package "wildcharm-light-theme" "20231118.656" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "ff2963fbd47f088bc1b3fda608e0086fbe91d86b" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
