;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251120.2040"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "637444fd7710de2db6ec147bea4e178e16211d56"
  :revdesc "637444fd7710"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
