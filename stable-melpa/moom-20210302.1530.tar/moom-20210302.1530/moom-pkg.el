(define-package "moom" "20210302.1530" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "174fd31f718f08e1e8cf7cf5c88a33fb820ee3d4" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
