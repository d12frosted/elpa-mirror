(define-package "osm" "20221011.1136" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "f2a2db15dde9874df38b85b7c6cbbf899fb3f9f7" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
