(define-package "mallard-snippets" "20131023.1851" "Yasnippets for Mallard"
  '((yasnippet "0.8.0")
    (mallard-mode "0.1.1"))
  :commit "35b7d0558da14fcffd51863f623806216a0093ce" :authors
  '(("Jaromir Hradilek" . "jhradilek@gmail.com"))
  :maintainer
  '("Jaromir Hradilek" . "jhradilek@gmail.com")
  :keywords
  '("snippets" "mallard")
  :url "https://github.com/jhradilek/emacs-mallard-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
