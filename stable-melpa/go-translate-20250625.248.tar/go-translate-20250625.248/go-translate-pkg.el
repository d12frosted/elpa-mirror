;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250625.248"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "1f817809ccab24bc44f325bb66af73e2b7dae7c7"
  :revdesc "1f817809ccab"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
