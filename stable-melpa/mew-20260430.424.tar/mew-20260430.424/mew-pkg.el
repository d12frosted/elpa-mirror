;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260430.424"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "6324170ed97ced68e920248e79e87cbfcb3e04b2"
  :revdesc "6324170ed97c")
