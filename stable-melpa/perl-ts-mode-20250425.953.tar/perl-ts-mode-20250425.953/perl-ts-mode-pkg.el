;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perl-ts-mode" "20250425.953"
  "Another Major mode for Perl."
  '((emacs "30.1"))
  :url "https://hg.sr.ht/~pranshu/perl-ts-mode"
  :commit "aa34c2a15aec61febb05afb74926b38f6a77f60e"
  :revdesc "aa34c2a15aec"
  :keywords '("languages" "perl")
  :authors '(("Pranshu Sharma" . "pranshu@bauherren.ovh"))
  :maintainers '(("Pranshu Sharma" . "pranshu@bauherren.ovh")))
