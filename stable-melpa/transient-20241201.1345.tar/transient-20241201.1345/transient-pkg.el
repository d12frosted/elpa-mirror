;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20241201.1345"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.0.0.0")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "23cb5b109dcb42550d573d7502bf9e8a5b7db325"
  :revdesc "23cb5b109dcb"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
