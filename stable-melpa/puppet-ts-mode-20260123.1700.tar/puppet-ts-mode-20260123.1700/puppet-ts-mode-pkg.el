;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "puppet-ts-mode" "20260123.1700"
  "Major mode for Puppet using Tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/smoeding/puppet-ts-mode"
  :commit "6c3082e49033572c598cbe45801ad4970c6d7254"
  :revdesc "6c3082e49033"
  :keywords '("languages")
  :authors '(("Stefan Möding" . "stm@kill-9.net"))
  :maintainers '(("Stefan Möding" . "stm@kill-9.net")))
