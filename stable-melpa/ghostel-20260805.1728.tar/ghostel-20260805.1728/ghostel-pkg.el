;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260805.1728"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "26f1ff9b2456633d006d02f1dd22b2a416fde3e9"
  :revdesc "26f1ff9b2456"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
