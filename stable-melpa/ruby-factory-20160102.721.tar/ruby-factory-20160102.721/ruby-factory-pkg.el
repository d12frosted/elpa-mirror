(define-package "ruby-factory" "20160102.721" "Minor mode for Ruby test object generation libraries"
  '((inflections "1.1"))
  :commit "2bb7ccc2fccb5257376a989aa395bc7b9eb1d55d" :keywords
  ("ruby" "rails" "convenience")
  :authors
  (("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainer
  ("Skye Shaw" . "skye.shaw@gmail.com")
  :url "http://github.com/sshaw/ruby-factory-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
