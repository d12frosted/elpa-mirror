(define-package "elpa-clone" "20221201.1227" "Clone ELPA archive"
  '((emacs "24.4"))
  :commit "1d130c251690f24c23b77a4e4570157fca881d8f" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "elpa" "clone" "mirror")
  :url "https://github.com/dochang/elpa-clone")
;; Local Variables:
;; no-byte-compile: t
;; End:
