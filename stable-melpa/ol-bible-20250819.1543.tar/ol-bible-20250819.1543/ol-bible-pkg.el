;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-bible" "20250819.1543"
  "Org Link support for Bible Passages."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~swflint/ol-bible"
  :commit "b67ff8c45d51af9fa71aa44bacb4a872f6b750c6"
  :revdesc "b67ff8c45d51"
  :keywords '("convenience" "outlines")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
