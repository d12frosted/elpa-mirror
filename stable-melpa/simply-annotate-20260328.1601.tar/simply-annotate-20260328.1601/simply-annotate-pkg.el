;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260328.1601"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "5181498523ec82fa39df5fa4b596e6fde1b8004c"
  :revdesc "5181498523ec"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
