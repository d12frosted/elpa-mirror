(define-package "modus-themes" "20220215.1631" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "10141c8b0ee622055ece5071944ea8df63b83698" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
