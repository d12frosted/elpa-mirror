;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260320.128"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "26203db30d36b54980b095d6b6ddfbfb874cae98"
  :revdesc "26203db30d36"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
