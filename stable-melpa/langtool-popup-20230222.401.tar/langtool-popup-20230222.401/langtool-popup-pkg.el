;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "langtool-popup" "20230222.401"
  "Popup message extension for langtool.el."
  '((emacs "25.1")
    (popup "0.5.9"))
  :url "https://github.com/mhayashi1120/Emacs-langtool"
  :commit "d86101eafe9a994eb0425e08e7c1795e9cb0cd42"
  :revdesc "d86101eafe9a"
  :keywords '("docs")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
