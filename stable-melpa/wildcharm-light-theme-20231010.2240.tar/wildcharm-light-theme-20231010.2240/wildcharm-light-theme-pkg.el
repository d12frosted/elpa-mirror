(define-package "wildcharm-light-theme" "20231010.2240" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "6fe1cdcd62f65dc427b25ac027222c8ebf475e21" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
