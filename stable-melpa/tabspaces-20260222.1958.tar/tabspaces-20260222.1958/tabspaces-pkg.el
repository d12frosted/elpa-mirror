;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260222.1958"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://github.com/mclear-tools/tabspaces"
  :commit "06fe5ad149bc5852698cd0adda6dd6e320b4cf8f"
  :revdesc "06fe5ad149bc"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
