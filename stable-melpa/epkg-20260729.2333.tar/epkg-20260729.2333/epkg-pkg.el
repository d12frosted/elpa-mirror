;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260729.2333"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "abb96029632bf9e8faafa3bf12c0bfa27aea0d40"
  :revdesc "abb96029632b"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
