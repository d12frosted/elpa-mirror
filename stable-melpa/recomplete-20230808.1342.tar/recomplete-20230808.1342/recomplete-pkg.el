(define-package "recomplete" "20230808.1342" "Immediately (re)complete actions"
  '((emacs "26.1"))
  :commit "0369b805d36462103eed6f87d9db870bdf0dbcd7" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-recomplete")
;; Local Variables:
;; no-byte-compile: t
;; End:
