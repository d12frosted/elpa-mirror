;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbake-ts-mode" "20240908.1435"
  "A major mode to use bitbake tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/seokbeomKim/bitbake-ts-mode"
  :commit "224d7fb93f0c06968421dd8536c64840a2f13273"
  :revdesc "224d7fb93f0c"
  :keywords '("bitbake" "tree-sitter" "languages")
  :authors '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers '(("Jason Kim" . "sukbeom.kim@gmail.com")))
