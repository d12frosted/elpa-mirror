(define-package "leo" "20211119.1636" "Interface for dict.leo.org"
  '((emacs "27.1"))
  :commit "41db8f64a0b4d335196f8d1c319518a68ccb2e50" :authors
  '(("M.T. Enders <michael AT michael-enders.com>")
    ("Marty Hiatt <mousebot AT riseup.net>"))
  :maintainer
  '("M.T. Enders <michael AT michael-enders.com>")
  :keywords
  '("convenience" "translate")
  :url "https://github.com/mtenders/emacs-leo")
;; Local Variables:
;; no-byte-compile: t
;; End:
