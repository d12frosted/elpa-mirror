(define-package "cnfonts" "20230215.1212" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "f8e3b090e355d3fa3c229d3958b07705bfdba330" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
