;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parinfer-rust-mode" "20260101.1949"
  "An interface for the parinfer-rust library."
  '((emacs         "29.2")
    (track-changes "1.1"))
  :url "https://github.com/justinbarclay/parinfer-rust-mode"
  :commit "6ee9f905c41f6368689ad12aa99516b9ee4fb06d"
  :revdesc "6ee9f905c41f"
  :keywords '("lisp" "tools")
  :authors '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers '(("Justin Barclay" . "justinbarclay@gmail.com")))
