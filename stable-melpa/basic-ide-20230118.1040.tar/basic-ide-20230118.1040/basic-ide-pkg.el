;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "basic-ide" "20230118.1040"
  "BASIC IDE c64."
  '((emacs      "25")
    (basic-mode "0.4.2")
    (company    "0.9.12")
    (flycheck   "0.22")
    (dash       "2.12.0")
    (f          "0.17.0"))
  :url "https://gitlab.com/sasanidas/emacs-c64-basic-ide"
  :commit "e33036f838e61b647927165e81be5d5b855e0518"
  :revdesc "e33036f838e6"
  :keywords '("languages" "basic")
  :authors '(("Fermin MF" . "fmfs@posteo.net"))
  :maintainers '(("Fermin MF" . "fmfs@posteo.net")))
