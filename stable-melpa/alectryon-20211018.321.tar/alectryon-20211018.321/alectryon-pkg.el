(define-package "alectryon" "20211018.321" "Toggle between Coq and reStructuredText"
  '((flycheck "31")
    (emacs "25.1"))
  :commit "1bcc7c68abcd6471604c9b7fe7f85b0878bbd435" :authors
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://github.com/cpitclaudel/alectryon")
;; Local Variables:
;; no-byte-compile: t
;; End:
