(define-package "dired-duplicates" "20231110.1214" "Find duplicate files locally and remotely"
  '((emacs "27.1"))
  :commit "62fc41cacd21b0338d556543aef278220a2d8c5f" :authors
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainers
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainer
  '("Harald Judt" . "h.judt@gmx.at")
  :keywords
  '("files")
  :url "https://codeberg.org/hjudt/dired-duplicates")
;; Local Variables:
;; no-byte-compile: t
;; End:
