(define-package "alarm-clock" "20190212.507" "Alarm Clock"
  '((emacs "24.4")
    (f "0.17.0"))
  :commit "2621d3a492d7f4e10a34d9d1d4af015df55a2b1b" :authors
  '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainer
  '("Steve Lemuel" . "wlemuel@hotmail.com")
  :keywords
  '("calendar" "tools" "convenience")
  :url "https://github.com/wlemuel/alarm-clock")
;; Local Variables:
;; no-byte-compile: t
;; End:
