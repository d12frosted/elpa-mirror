;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250306.1550"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (el-job        "1.0.5")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "bafd65652ecd15f7994ce7d71995162cb5e66d75"
  :revdesc "bafd65652ecd"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
