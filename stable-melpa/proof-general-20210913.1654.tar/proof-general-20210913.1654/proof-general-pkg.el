(define-package "proof-general" "20210913.1654" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "25.1"))
  :commit "e2b4227e1f63a78198d1b7521b63619fb702d3f5" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
