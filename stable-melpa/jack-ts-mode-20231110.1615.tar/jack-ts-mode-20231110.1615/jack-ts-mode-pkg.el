;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jack-ts-mode" "20231110.1615"
  "Major mode for jack buffers using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/jack-ts-mode"
  :commit "f57f211d96608a90142619a925caeb8808e7c632"
  :revdesc "f57f211d9660"
  :keywords '("tree-sitter" "languages" "jack" "nand2tetris")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
