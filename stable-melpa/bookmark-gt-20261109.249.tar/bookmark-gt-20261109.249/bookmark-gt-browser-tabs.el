;;; bookmark-gt-browser-tabs.el --- Browser tabs as ephemeral bookmarks  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Daniel M. German <dmg@turingmachine.org>

;; Author: Daniel M. German <dmg@turingmachine.org>
;; Maintainer: Daniel M. German <dmg@turingmachine.org>
;; Assisted-by: Claude:claude-opus-4-7
;; Keywords: convenience, matching, hypermedia
;; URL: https://github.com/dmgerman/bookmark-gt

;; SPDX-License-Identifier: GPL-3.0-or-later
;;
;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Fetches the browser's open tabs (via the browser-gt WebSocket
;; bridge) and exposes them as temp bookmarks with a dedicated
;; browser-tab handler.  Temp records carry the `bmkp-temp' alist
;; key and are excluded from `bookmark-save' output — restarting
;; Emacs starts with no tab entries; a refresh re-populates them.
;;
;; Entry points:
;;
;;   `bookmark-gt-browser-tabs-refresh' — one-shot rebuild.
;;   `bookmark-gt-browser-tabs-mode'    — global minor mode; when
;;                                        enabled, registers
;;                                        `bookmark-gt-browser-tabs-refresh'
;;                                        on `bookmark-gt-jump-before-read-hook'
;;                                        and `bookmark-gt-list-before-read-hook'
;;                                        so the jump reader and the list
;;                                        buffer see current tabs at each read.
;;
;; Loads lazily: if browser-gt is not installed the file is a no-op
;; and every command signals a friendly `user-error'.
;;
;; Tab names and the same-name policy
;; ----------------------------------
;;
;; A tab record is named after the tab's title, and titles repeat:
;; two windows on one site, a page open twice, several "New Tab"
;; pages.  Name conflicts are therefore normal here, not a mistake
;; to be reported.
;;
;; `bookmark-gt-allow-same-name-bookmarks' still decides what may
;; be stored, but a refresh cannot signal the way
;; `bookmark-gt-create' does: it runs from a timer, on behalf of
;; no one, and an error partway would abandon the rest of the
;; tabs.  So a refusal skips that tab and the refresh reports how
;; many were skipped.  What each setting means for tabs:
;;
;;   `always'                every tab is stored.
;;   `different-destination' tabs sharing a title are stored when
;;                           their URLs differ.  A second tab on
;;                           the same URL is skipped — as a
;;                           bookmark it is indistinguishable from
;;                           the first, and jumping to either
;;                           opens the same address.
;;   `never'                 the first tab with a given title is
;;                           stored and the rest are skipped.
;;
;; Skipping loses nothing that could be acted on differently:
;; these records are rebuilt from the browser on every refresh,
;; and they are never written to the bookmark file.

;;; Code:

(require 'bookmark)
(require 'seq)
(require 'bookmark-gt-core)
(require 'bookmark-gt-handlers)
(require 'bookmark-gt-list)

(require 'browser-gt nil t)

;; browser-gt is a soft-dep loaded at the top with (require 'browser-gt nil t).
;; The `ext:' prefix on the FILE argument tells `check-declare' this
;; symbol lives in an external package that need not be present at
;; compile time, so it skips validation.
(declare-function browser-gt-browser-tabs "ext:browser-gt")
(declare-function browser-gt-connected-clients "ext:browser-gt")

;;;; Customization

(defcustom bookmark-gt-browser-tabs-browsers nil
  "List of browser-gt browser clients to query for tabs, or nil for all."
  :type '(choice (const :tag "All connected browsers" nil)
                 (repeat string))
  :group 'bookmark-gt)

(defcustom bookmark-gt-browser-tabs-filter nil
  "Filter applied to each candidate tab before storing.
Value shape:

  nil        — accept every tab.
  regexp     — accept tabs whose URL matches the regexp.
  function   — called with the tab plist; accept when non-nil."
  :type '(choice (const :tag "Accept all" nil)
                 (regexp   :tag "URL regexp")
                 (function :tag "Predicate function"))
  :group 'bookmark-gt)

(defconst bookmark-gt-browser-tabs--marker-key 'bookmark-gt-browser-tab
  "Alist key that marks a record as stored by this module.")

(defun bookmark-gt-browser-tabs--own-record-p (record)
  "Return non-nil when RECORD was stored by this module."
  (bookmark-prop-get record bookmark-gt-browser-tabs--marker-key))

;; Clearing a tab record's temp flag removes these three, which
;; converts it into a plain URL bookmark.  Removing the marker is
;; also what preserves the record: `--clear' deletes only records
;; that still carry it.
(dolist (key (list 'browser-gt-id
                   'browser-gt-browser
                   bookmark-gt-browser-tabs--marker-key))
  (unless (memq key bookmark-gt-session-only-props)
    (push key bookmark-gt-session-only-props)))

;;;; Fetch + filter

(defun bookmark-gt-browser-tabs--fetch ()
  "Return the browser tab list from browser-gt, or nil after warning."
  (unless (featurep 'browser-gt)
    (user-error "Package `browser-gt' is not loaded"))
  (condition-case err
      (browser-gt-browser-tabs bookmark-gt-browser-tabs-browsers)
    (error
     (display-warning 'bookmark-gt-browser-tabs
                      (format "Cannot fetch tabs: %s"
                              (error-message-string err))
                      :warning)
     nil)))

(defun bookmark-gt-browser-tabs--accept-p (tab)
  "Return non-nil when TAB passes `bookmark-gt-browser-tabs-filter'."
  (let ((filt bookmark-gt-browser-tabs-filter)
        (url (or (plist-get tab :url) "")))
    (cond
     ((null filt)      t)
     ((stringp filt)   (string-match-p filt url))
     ((functionp filt) (funcall filt tab))
     (t                t))))

;;;; Visit carryover
;;
;; `visits' and `last-visited' record what the user did through
;; bookmark-gt: the visit tracker writes them from
;; `bookmark-after-jump-hook' after a jump.  A refresh deletes
;; every tab record and stores fresh ones, so both props would
;; reset on each refresh — and under
;; `bookmark-gt-browser-tabs-mode' a refresh runs before every
;; jump read, so a recorded visit would never survive to be
;; sorted on.  The snapshot below carries them across one
;; clear/rebuild cycle.
;;
;; What the carryover does not span: a browser restart (tab ids
;; are reassigned), turning the mode off and on (the intervening
;; `--clear' takes no snapshot), and exiting Emacs (tab records
;; are temporary and never reach the bookmark file).  Losing the
;; stats in those cases is intended.

(defun bookmark-gt-browser-tabs--visit-key (browser id)
  "Return the visit-carryover key for tab ID owned by BROWSER.
Tab ids are numbered per browser, so the browser name is part of
the key: tab 7 in one browser is a different tab from tab 7 in
another."
  (format "%s\0%s" (or browser "") id))

(defun bookmark-gt-browser-tabs--visit-snapshot ()
  "Return a hash table of visit stats for the tab records in `bookmark-alist'.
Keys come from `bookmark-gt-browser-tabs--visit-key'; each value
is a cons of the record's `visits' count and its `last-visited'
time.  Records carrying neither prop are omitted."
  (let ((table (make-hash-table :test #'equal)))
    (dolist (rec bookmark-alist table)
      (when (bookmark-gt-browser-tabs--own-record-p rec)
        (let ((visits (bookmark-prop-get rec 'visits))
              (visited (bookmark-prop-get rec 'last-visited)))
          (when (or visits visited)
            (puthash (bookmark-gt-browser-tabs--visit-key
                      (bookmark-prop-get rec 'browser-gt-browser)
                      (bookmark-prop-get rec 'browser-gt-id))
                     (cons visits visited)
                     table)))))))

;;;; Store

(defun bookmark-gt-browser-tabs--store (tab &optional snapshot)
  "Store TAB (a browser-gt plist) as a temp browser-tab bookmark.
The name is the tab title, falling back to the URL.  The
owning browser's client name becomes a tag so it shows up in the
list buffer's Tags column and in the `;tag' particle filter.

Stores with NO-NOTIFY and NO-CURRENT set: a refresh writes many
records from a timer, so the list buffer is refreshed once by
the caller, and `bookmark-current-bookmark' — buffer-local, and
the default for several name prompts — is left alone in
whatever buffer the timer happened to run in.

SNAPSHOT is the table from
`bookmark-gt-browser-tabs--visit-snapshot'.  When it holds an
entry for this tab, the record is stored with the `visits' and
`last-visited' values the previous record for the same tab had.
Both props then mean on a tab record what they mean on every
other record: the last jump bookmark-gt made to it, not the last
time the browser focused the tab."
  (let* ((url (or (plist-get tab :url) ""))
         (title (or (plist-get tab :title) ""))
         (id (plist-get tab :id))
         (browser (plist-get tab :browser-gt-browser))
         (base (if (string-empty-p title) url title))
         (stats (and snapshot
                     (gethash (bookmark-gt-browser-tabs--visit-key browser id)
                              snapshot)))
         (props (append
                 (list (cons 'url url)
                       (cons 'browser-gt-id id)
                       (cons 'browser-gt-browser browser)
                       (cons bookmark-gt-temp-key t)
                       (cons bookmark-gt-browser-tabs--marker-key t))
                 (when (car stats) (list (cons 'visits (car stats))))
                 (when (cdr stats) (list (cons 'last-visited (cdr stats))))
                 (when (and (stringp browser) (not (string-empty-p browser)))
                   (list (cons 'tags (list browser)))))))
    ;; A refresh is not a user acting on one bookmark, so a name
    ;; the policy refuses is skipped rather than signalled: an
    ;; error here would abandon a refresh nobody asked for,
    ;; partway through.  See the Commentary on tab names.
    (when (bookmark-gt-name-available-p base props)
      (bookmark-gt-create-non-file base
                                   'bookmark-gt-handler-url-jump
                                   props
                                   t t))))

(defun bookmark-gt-browser-tabs--clear ()
  "Remove every browser-gt-owned record from `bookmark-alist'.
Matches only records carrying the
`bookmark-gt-browser-tabs--marker-key' marker, so records
owned by other browser-gt-related packages are left alone.

Every record removed here is temporary, so
`bookmark-alist-modification-count' is left alone: none of them
would have been written to the bookmark file."
  (setq bookmark-alist
        (seq-remove #'bookmark-gt-browser-tabs--own-record-p
                    bookmark-alist))
  (bookmark-gt-list-refresh))

;;;; Refresh

(defvar bookmark-gt-browser-tabs--refreshing nil
  "Non-nil while `bookmark-gt-browser-tabs-refresh' is running.
Prevents re-entrancy: the idle timer might fire while a manual
refresh (or the mode-on immediate refresh) is still in progress,
which would produce duplicate records.  A second refresh that
finds this flag set silently returns.")

;;;###autoload
(defun bookmark-gt-browser-tabs-refresh ()
  "Rebuild browser-tab bookmarks from live browser state.
Clears existing tab records, fetches the current tabs via
browser-gt, applies `bookmark-gt-browser-tabs-filter', and stores
one temp bookmark per surviving tab.  A tab that already had a
record keeps its `visits' and `last-visited' props; see
`bookmark-gt-browser-tabs--visit-snapshot'.  Guarded against
re-entrancy."
  (interactive)
  (if bookmark-gt-browser-tabs--refreshing
      (when (called-interactively-p 'interactive)
        (message "Browser-tab refresh already in progress; skipping"))
    (let ((bookmark-gt-browser-tabs--refreshing t)
          (snapshot (bookmark-gt-browser-tabs--visit-snapshot))
          (count 0)
          (skipped 0))
      ;; Silence auto-save (would trigger mid-batch once modification-count
      ;; crosses `bookmark-save-flag') during the loop.  Temp records
      ;; are excluded from `bookmark-save' anyway, so a mid-batch
      ;; save is pure waste — and it produced spurious \"Cannot
      ;; syntax-propertize because of narrowing\" warnings from the
      ;; bookmark-file write path.
      (let ((bookmark-save-flag nil))
        (bookmark-gt-browser-tabs--clear)
        (dolist (tab (bookmark-gt-browser-tabs--fetch))
          (let ((url (plist-get tab :url)))
            (when (and (stringp url) (not (string-empty-p url))
                       (bookmark-gt-browser-tabs--accept-p tab))
              (if (bookmark-gt-browser-tabs--store tab snapshot)
                  (setq count (1+ count))
                (setq skipped (1+ skipped)))))))
      (bookmark-gt-list-refresh)
      (if (> skipped 0)
          (message
           "Refreshed %d browser-tab bookmark(s); %d skipped, their names are in use"
           count skipped)
        (message "Refreshed %d browser-tab bookmark(s)" count)))))

;;;; Mode
;;
;; No timer, and no subscription to browser-gt's connect and
;; disconnect hooks.  Tab records are rebuilt at the two moments
;; they are about to be read — the jump reader, and opening or
;; reverting the list buffer — plus on demand.
;;
;; Refreshing on client events as well was work done on behalf of
;; nobody: it fetched and rebuilt records that nothing was going
;; to display, needed a debounce timer to coalesce bursts, and
;; still could not guarantee freshness, since tabs change without
;; any client connecting or disconnecting.  Refreshing where the
;; records are read is both simpler and more accurate.

(defvar bookmark-gt-browser-tabs-mode)

;;;###autoload
(define-minor-mode bookmark-gt-browser-tabs-mode
  "Global minor mode that exposes browser tabs as temporary bookmarks.

When enabled, registers `bookmark-gt-browser-tabs-refresh' on
`bookmark-gt-jump-before-read-hook' and
`bookmark-gt-list-before-read-hook', so the jump reader and the
`*Bookmarks-gt List*' buffer see the current tabs at each read,
and refreshes once immediately if a browser is already connected.
`M-x bookmark-gt-browser-tabs-refresh' refreshes on demand.

Tab state changes faster than any event bookmark-gt could
subscribe to, so the records are rebuilt where they are about to
be read rather than kept continuously in sync.  Each read pays
one fetch and store.

Turning the mode off removes both hook entries and clears the
tab records this mode added — only records carrying its own
marker; records from other browser-gt-related packages are
untouched.

Requires browser-gt to be installed.  Enable is a `user-error'
no-op when browser-gt is not loaded."
  :global t
  :group 'bookmark-gt
  (cond
   ((and bookmark-gt-browser-tabs-mode (not (featurep 'browser-gt)))
    (setq bookmark-gt-browser-tabs-mode nil)
    (user-error "Package `browser-gt' is not loaded"))
   (bookmark-gt-browser-tabs-mode
    (add-hook 'bookmark-gt-jump-before-read-hook
              #'bookmark-gt-browser-tabs-refresh)
    (add-hook 'bookmark-gt-list-before-read-hook
              #'bookmark-gt-browser-tabs-refresh)
    (when (browser-gt-connected-clients)
      (bookmark-gt-browser-tabs-refresh)))
   (t
    (remove-hook 'bookmark-gt-jump-before-read-hook
                 #'bookmark-gt-browser-tabs-refresh)
    (remove-hook 'bookmark-gt-list-before-read-hook
                 #'bookmark-gt-browser-tabs-refresh)
    (bookmark-gt-browser-tabs--clear))))

(provide 'bookmark-gt-browser-tabs)


;; Local Variables:
;; package-lint-main-file: "bookmark-gt.el"
;; End:

;;; bookmark-gt-browser-tabs.el ends here
