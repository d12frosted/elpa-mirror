;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "20251011.1837"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "30.1")
    (cond-let "0.1")
    (elx      "2.3")
    (llama    "1.0")
    (magit    "4.4"))
  :url "https://github.com/magit/sisyphus"
  :commit "c9c48d82da272818fd7532d42b90dc181fdf1b0f"
  :revdesc "c9c48d82da27"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
