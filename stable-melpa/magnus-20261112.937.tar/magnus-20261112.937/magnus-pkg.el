;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20261112.937"
  "Manage multiple AI coding agents."
  '((emacs         "28.1")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (magit-section "3.3.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "38c70884b9a4ff6e5ab45f2dfd84335508e077ff"
  :revdesc "38c70884b9a4"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
