(define-package "bind" "20230513.1709" "Bind commands to keys"
  '((emacs "25.1"))
  :commit "2a9b8c4eb0b58c0058da1387811edc8436da49c4" :authors
  '(("repelliuss <https://github.com/repelliuss>"))
  :maintainers
  '(("repelliuss" . "repelliuss@gmail.com"))
  :maintainer
  '("repelliuss" . "repelliuss@gmail.com")
  :url "https://github.com/repelliuss/bind")
;; Local Variables:
;; no-byte-compile: t
;; End:
