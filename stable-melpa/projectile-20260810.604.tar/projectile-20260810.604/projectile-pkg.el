;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260810.604"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "8ac2b42ba5a725e757e693f1591d33ac4abf421d"
  :revdesc "8ac2b42ba5a7"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
