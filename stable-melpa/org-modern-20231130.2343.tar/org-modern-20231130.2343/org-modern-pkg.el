(define-package "org-modern" "20231130.2343" "Modern looks for Org"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "f04ae8d487efb952c083f944a2a0a34006a1414b" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "wp")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
