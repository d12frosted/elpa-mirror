;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iregister" "20150515.2107"
  "Interactive register commands for Emacs."
  ()
  :url "https://github.com/atykhonov/iregister.el"
  :commit "6a48c66187289de5f300492be11c83e98410c018"
  :revdesc "6a48c6618728"
  :keywords '("convenience")
  :authors '(("Andrey Tykhonov" . "atykhonov@gmail.com"))
  :maintainers '(("Andrey Tykhonov" . "atykhonov@gmail.com")))
