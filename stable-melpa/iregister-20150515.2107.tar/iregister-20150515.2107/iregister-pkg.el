(define-package "iregister" "20150515.2107" "Interactive register commands for Emacs." 'nil :commit "6a48c66187289de5f300492be11c83e98410c018" :authors
  (("Andrey Tykhonov" . "atykhonov@gmail.com"))
  :maintainer
  ("Andrey Tykhonov" . "atykhonov@gmail.com")
  :keywords
  ("convenience")
  :url "https://github.com/atykhonov/iregister.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
