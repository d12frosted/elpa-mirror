;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-skk" "20151111.950"
  "Ido interface for skk henkan."
  '((emacs "24.4")
    (ddskk "20150912.1820"))
  :url "https://github.com/tsukimizake/ido-skk"
  :commit "89a2e62799bff2841ff634517c86084c4ce69246"
  :revdesc "89a2e62799bf"
  :keywords '("languages")
  :authors '(("tsukimizake" . "shomasd_at_gmail.com"))
  :maintainers '(("tsukimizake" . "shomasd_at_gmail.com")))
