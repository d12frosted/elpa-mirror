(define-package "binky" "20231014.1153" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "cf13825dc2f8510c18910f54495eaefaf318d6d0" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
