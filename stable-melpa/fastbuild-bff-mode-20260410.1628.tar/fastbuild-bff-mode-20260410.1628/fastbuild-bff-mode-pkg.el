;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fastbuild-bff-mode" "20260410.1628"
  "Major mode for FASTBuild BFF files."
  '((emacs "26.1"))
  :url "https://github.com/cyberkm/fastbuild-bff-mode"
  :commit "eb0c2d3d58d9184680fdd1afb6df2ca9f8869cda"
  :revdesc "eb0c2d3d58d9"
  :keywords '("languages" "tools" "build")
  :authors '(("Pavel Bibergal" . "cyberkm@gmail.com"))
  :maintainers '(("Pavel Bibergal" . "cyberkm@gmail.com")))
