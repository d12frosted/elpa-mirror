(define-package "fennel-mode" "20220825.1549" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "a3d7564f209c32b804852b7fe8056c1952414f08" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
