;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "20241203.1934"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "1a6554bb2afc684701a289f284ee425960944425"
  :revdesc "1a6554bb2afc"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
