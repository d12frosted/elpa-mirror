;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-translate" "20170720.1919"
  "Translation of text blocks in org-mode."
  '((google-translate "0.11")
    (org              "8"))
  :url "https://github.com/krisajenkins/ob-translate"
  :commit "9d9054a51bafd5a29a8135964069b4fa3a80b169"
  :revdesc "9d9054a51baf"
  :keywords '("org" "babel" "translate" "translation")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
