;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inform-mode" "20250602.2351"
  "Major mode for Inform 6 interactive fiction code."
  '((emacs "29.1"))
  :url "https://rrthomas.github.io/inform-mode"
  :commit "e03289d0d056a6e35737612650c7a6060537f726"
  :revdesc "e03289d0d056"
  :keywords '("languages")
  :authors '(("Rupert Lane" . "rupert@rupert-lane.org")
             ("Gareth Rees" . "Gareth.Rees@cl.cam.ac.uk"))
  :maintainers '(("Reuben Thomas" . "rrt@sc3d.org")))
