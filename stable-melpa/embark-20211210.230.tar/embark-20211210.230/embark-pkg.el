(define-package "embark" "20211210.230" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "91e6db4dc029cc87ff3315f88552468de7344e30" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
