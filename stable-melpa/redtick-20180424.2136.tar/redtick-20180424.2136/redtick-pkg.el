(define-package "redtick" "20180424.2136" "Smallest pomodoro timer (1 char)"
  '((emacs "24.4"))
  :commit "94b4cd43ac20c64dcac96edac2c1a3b9fcc59bb9" :authors
  (("F. Febles"))
  :maintainer
  ("F. Febles")
  :keywords
  ("calendar")
  :url "http://github.com/ferfebles/redtick")
;; Local Variables:
;; no-byte-compile: t
;; End:
