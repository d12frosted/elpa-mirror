(define-package "dime" "20210329.604" "Dylan interaction mode"
  '((emacs "25.1")
    (dylan "3.0"))
  :commit "040c8ebc884305fd4ff980d21c68946fa74b095a" :url "https://opendylan.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
