;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260406.1448"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "241f289bd835548e7433ebb13aed2c32fd227533"
  :revdesc "241f289bd835"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
