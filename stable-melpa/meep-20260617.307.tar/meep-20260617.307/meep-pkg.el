;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260617.307"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "839ae422bb61f8f47350dd439ceb24962b3619f9"
  :revdesc "839ae422bb61"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
