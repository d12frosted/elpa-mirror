(define-package "hyperdrive" "20240927.223" "P2P filesystem"
  '((emacs "28.1")
    (map "3.0")
    (compat "30.0.0.0")
    (org "9.7.6")
    (plz "0.9.1")
    (persist "0.6.1")
    (taxy-magit-section "0.14")
    (transient "0.7.4"))
  :commit "36173a32723cd977e3a597b3c18ebe8a5ff99de4" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
