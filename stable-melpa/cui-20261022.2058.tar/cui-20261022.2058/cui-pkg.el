;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261022.2058"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "680b8d7c9a15d9ff85725b2e9f8ba5a349256795"
  :revdesc "680b8d7c9a15"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
