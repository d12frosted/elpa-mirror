(define-package "org-journal" "20240218.1501" "a simple org-mode based journaling mode"
  '((emacs "26.1")
    (org "9.1"))
  :commit "b1548879e9147cc270c600f86361a9616316b385" :authors
  '(("Bastian Bechtold")
    ("Christian Schwarzgruber"))
  :maintainers
  '(("Bastian Bechtold"))
  :maintainer
  '("Bastian Bechtold")
  :url "http://github.com/bastibe/org-journal")
;; Local Variables:
;; no-byte-compile: t
;; End:
