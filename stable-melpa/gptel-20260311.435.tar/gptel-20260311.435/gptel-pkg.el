;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260311.435"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "f45e7bc41e7e325370eeeafe569cb2a1c174713d"
  :revdesc "f45e7bc41e7e"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
