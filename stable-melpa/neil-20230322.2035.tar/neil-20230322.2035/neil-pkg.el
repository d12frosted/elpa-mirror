(define-package "neil" "20230322.2035" "companion for Babashka Neil"
  '((emacs "27.1"))
  :commit "19bc12d1c868eb5c1f200963c240a2a107982556" :authors
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainer
  '("Ag Ibragimov" . "agzam.ibragimov@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/babashka/neil")
;; Local Variables:
;; no-byte-compile: t
;; End:
