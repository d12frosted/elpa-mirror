(define-package "helm-core" "20220513.846" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "96fc4587aa73757f56550b9def7499fcb5b1a51f" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
