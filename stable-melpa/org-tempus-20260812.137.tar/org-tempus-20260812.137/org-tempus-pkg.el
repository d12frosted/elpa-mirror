;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tempus" "20260812.137"
  "Enhance Org time tracking."
  '((emacs "27.1"))
  :url "https://github.com/rul/org-tempus"
  :commit "3ac7ef4e08e2815420b74119a76248e3c698d439"
  :revdesc "3ac7ef4e08e2"
  :keywords '("calendar")
  :authors '(("Raul Benencia" . "id@rbenencia.name"))
  :maintainers '(("Raul Benencia" . "id@rbenencia.name")))
