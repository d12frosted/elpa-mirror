;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260508.1720"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "614a0c250e4310dbf3a6012369ef4703f03a2623"
  :revdesc "614a0c250e43"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
