(define-package "tree-sitter" "20201217.1738" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.12.1"))
  :commit "d6e98defcaf1d928bb9a1849f45e85d669925c26" :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
