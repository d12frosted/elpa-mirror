(define-package "minitest" "20200224.1823" "An Emacs mode for ruby minitest files"
  '((dash "1.0.0"))
  :commit "97d7d1760b24e117ffd163531b0f57fd4321677b" :authors
  '(("Arthur Neves"))
  :maintainer
  '("Arthur Neves")
  :url "https://github.com/arthurnn/minitest-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
