;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20250226.1833"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "25.1")
    (f     "0.18.2"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "76cd092f7ad7468434c39da6fda383d0ecf731d7"
  :revdesc "76cd092f7ad7"
  :keywords '("convenience"))
