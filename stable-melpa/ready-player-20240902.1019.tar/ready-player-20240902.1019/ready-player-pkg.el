(define-package "ready-player" "20240902.1019" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "05f52b520549b5954560b956c64eb6abe6673ae8" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
