(define-package "geiser" "20221023.2345" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (project "0.8.1"))
  :commit "67fae675d40833fe10471a6b237a16efef03b845" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
