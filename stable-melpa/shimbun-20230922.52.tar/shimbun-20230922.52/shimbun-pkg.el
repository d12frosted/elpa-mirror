(define-package "shimbun" "20230922.52" "interfacing with web newspapers" 'nil :commit "1f039c1c1521df2d9a1f5c3e5b341bc43bbd34cd" :authors
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
    ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
    ("Yuuichi Teranishi " . "teranisi@gohome.org")
    ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainers
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org"))
  :maintainer
  '("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  '("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
