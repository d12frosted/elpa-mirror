(define-package "osm" "20220321.408" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "372a4bedaaebad92b586033c6163a3d3e971dff6" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
