(define-package "syntree" "20221009.2339" "Draw plain text constituency trees"
  '((emacs "27.1")
    (org "9.2"))
  :commit "f3bc306e66e16dba9e535c37db09b2adadc156e1" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/syntree")
;; Local Variables:
;; no-byte-compile: t
;; End:
