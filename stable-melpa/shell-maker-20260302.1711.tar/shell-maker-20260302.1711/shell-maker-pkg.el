;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260302.1711"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "238b1e4f00781fd40ecd6e3baceed30abccd06ae"
  :revdesc "238b1e4f0078")
