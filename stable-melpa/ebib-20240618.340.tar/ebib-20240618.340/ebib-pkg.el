(define-package "ebib" "20240618.340" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "27.1")
    (compat "29.1.4.3"))
  :commit "99536e910638e28167150e84c2301c1825c8f4c3" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
