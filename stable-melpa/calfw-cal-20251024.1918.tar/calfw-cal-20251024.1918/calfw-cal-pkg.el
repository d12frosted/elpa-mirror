;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-cal" "20251024.1918"
  "Calendar view for diary."
  '((emacs "28.1")
    (calfw "2.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "bcb01c7afa1b8c38a0b6d4226d2148adfb62e29f"
  :revdesc "bcb01c7afa1b"
  :keywords '("calendar" "org")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
