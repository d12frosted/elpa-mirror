;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250502.2333"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "11fbb4dcd9e634af2e42784d0cf2af840c5e9468"
  :revdesc "11fbb4dcd9e6"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
