(define-package "detached" "20220915.1320" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "77921c6cf4020a8062f9fd6cccda19bef51b2350" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
