;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260916.1224"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "2369e80459ba98f7827032fb3068648b27d591f7"
  :revdesc "2369e80459ba"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
