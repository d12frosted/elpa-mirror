;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-walk" "20251210.1747"
  "Send email addresses for a walk."
  '((emacs "29.1"))
  :url "https://codeberg.org/timmli/mu4e-walk"
  :commit "1251140ba6bad70622ae8a5dc8e3d99bbd11f582"
  :revdesc "1251140ba6ba"
  :keywords '("convenience" "mail")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
