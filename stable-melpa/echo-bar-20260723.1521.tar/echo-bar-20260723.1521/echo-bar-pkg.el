;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "echo-bar" "20260723.1521"
  "Turn the echo area into a custom status bar."
  ()
  :url "https://github.com/qaiviq/echo-bar.el"
  :commit "25348c0220b58eea196ae79cab22e934817fdc89"
  :revdesc "25348c0220b5"
  :keywords '("convenience" "tools")
  :authors '(("Adam Tillou" . "qaiviq@gmail.com"))
  :maintainers '(("Adam Tillou" . "qaiviq@gmail.com")))
