;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tfsmacs" "20180911.2114"
  "MS TFS source control interaction."
  '((emacs   "25")
    (tablist "0.70"))
  :url "https://github.com/sebasmonia/tfsmacs/"
  :commit "13ee3f528ff616880611f563a68d921250692ef8"
  :revdesc "13ee3f528ff6"
  :keywords '("tfs" "vc")
  :authors '(("Dino Chiesa" . "dpchiesa@outlook.com")
             ("Sebastian Monia" . "smonia@outlook.com"))
  :maintainers '(("Dino Chiesa" . "dpchiesa@outlook.com")
                 ("Sebastian Monia" . "smonia@outlook.com")))
