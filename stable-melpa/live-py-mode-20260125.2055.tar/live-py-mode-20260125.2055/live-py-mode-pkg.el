;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-py-mode" "20260125.2055"
  "Live Coding in Python."
  '((emacs "24.3"))
  :url "http://donkirkby.github.io/live-py-plugin/"
  :commit "081eb5da23e531e493d480dd3b89c70e458d242d"
  :revdesc "081eb5da23e5"
  :keywords '("live" "coding"))
