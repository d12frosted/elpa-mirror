(define-package "modus-themes" "20211202.1444" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "78057f369c1bd07366472912bea1f70749b7c931" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
