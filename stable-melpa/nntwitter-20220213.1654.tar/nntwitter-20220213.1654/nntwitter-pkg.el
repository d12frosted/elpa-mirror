(define-package "nntwitter" "20220213.1654" "Gnus Backend For Twitter"
  '((emacs "25.1")
    (dash "20190401")
    (anaphora "20180618")
    (request "20190819"))
  :commit "f0eb3f6e8040f9064a18d3761b41f41dfd21a6ee" :keywords
  '("news")
  :url "https://github.com/dickmao/nntwitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
