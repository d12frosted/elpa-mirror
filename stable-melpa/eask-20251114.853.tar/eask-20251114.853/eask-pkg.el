;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20251114.853"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "9bb61ff757769ad46eb77526c97cdcdacc32c3a6"
  :revdesc "9bb61ff75776"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
