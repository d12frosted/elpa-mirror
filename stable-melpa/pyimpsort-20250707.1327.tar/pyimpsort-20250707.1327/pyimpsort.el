;;; pyimpsort.el --- Sort python imports. -*- lexical-binding: t -*-

;; Copyright © 2014 Mario Rodas <marsam@users.noreply.github.com>

;; Author: Mario Rodas <marsam@users.noreply.github.com>
;; URL: https://github.com/emacs-pe/pyimpsort.el
;; Keywords: convenience
;; Package-Version: 20250707.1327
;; Package-Revision: e26c8932fc66
;; Package-Requires: ((emacs "24.3"))

;; This file is NOT part of GNU Emacs.

;;; License:

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; `pyimpsort.el' sort the python imports of a file.
;; Currently uses [pyimpsort.py](pyimpsort.py) to process the way to sort python
;; imports.
;;
;;; Setup
;;
;; Add the following snippet to your `init.el':
;;
;;     (require 'pyimpsort)
;;     (eval-after-load 'python
;;       '(define-key python-mode-map "\C-c\C-u" #'pyimpsort-buffer))
;;
;;; Configuration:
;;
;; By default, `pyimpsort.el' looks for the `pyimpsort.py` script in the same
;; directory as this file, and constructs a shell command to run it using the
;; Python interpreter configured in Emacs (`python-shell-interpreter').
;;
;; These variables can be customized:
;;
;; - `pyimpsort-script'
;;   Absolute path to the `pyimpsort.py` script.  By default, it is resolved
;;   relative to the location of this file.  You can override it like so:
;;
;;       (setq pyimpsort-script "/my/custom/path/to/pyimpsort.py")
;;
;; - `pyimpsort-command'
;;   Full shell command used to call the script.  By default, it launches the
;;   `pyimpsort-script' using the Python interpreter configured in Emacs
;;   (`python-shell-interpreter').  Useful when calling the script inside a
;;   container or custom environment.  Example:
;;
;;       (setq pyimpsort-command
;;             "docker exec -i my-container python3 -m pyimpsort")
;;
;; You can also configure this per project using `.dir-locals.el`:
;;
;;     ((python-mode . ((pyimpsort-command . "docker exec -i my-container python3 -m pyimpsort"))))
;;
;;
;;; Troubleshooting:
;;
;; + **Doesn't sort correctly third party libraries**
;;
;;   `pyimpsort.el' tries to identify the third party libraries if are installed
;;   in in the PYTHONPATH, if a package is not installed it is assumed that
;;   belongs to the application.
;;   `pyimpsort.el' also tries to identify if a python virtualenv
;;   is activated.
;;
;;; Related projects:
;;
;; + [isort][] ([emacs integration](https://github.com/paetzke/py-isort.el))
;;
;; [isort]: https://github.com/timothycrosley/isort

;;; Code:

(require 'python)

(defgroup pyimpsort nil
  "Sort python imports."
  :prefix "pyimpsort-"
  :group 'applications)

(defcustom pyimpsort-display-error-buffer nil
  "Display error buffer on error."
  :type 'boolean
  :group 'pyimpsort)

(defcustom pyimpsort-error-buffer-name "*pyimpsort-error*"
  "Buffer name of pyimpsort error."
  :type 'string
  :group 'pyimpsort)

(defcustom pyimpsort-script
  (expand-file-name "pyimpsort.py"
                    (file-name-directory (if load-in-progress
                                             load-file-name
                                           (buffer-file-name))))
  "Absolute path to the Python script `pyimpsort.py`.

This script is used by default when `pyimpsort-command' is not customized."
  :type 'string
  :group 'pyimpsort)

(defcustom pyimpsort-command
  (let* ((exec-path (python-shell-calculate-exec-path)))
    (mapconcat #'shell-quote-argument
               (list (executable-find python-shell-interpreter) pyimpsort-script)
               " "))
  "Shell command used to launch `pyimpsort`.

If you override this value, `pyimpsort-script' will be ignored.
Use this if you run Python in a non-standard environment, such as a container:

    docker exec -i my-dev-container sudo -u my-dev-user python3 -m pyimpsort"
  :type 'string
  :group 'pyimpsort)

(make-variable-buffer-local 'pyimpsort-command)

(defconst pyimpsort-imports-start-regexp
  (rx (group (and bol (or "import" "from")))))

(defconst pyimpsort-imports-end-regexp
  (rx (or (and bol (or "import" "from")) (and bol (* space) eol))))

(defun pyimpsort--search-beg-point (&optional end)
  "Search the first import line until reach the END point."
  (save-excursion
    (goto-char (point-min))
    (and (re-search-forward pyimpsort-imports-start-regexp end t)
         (match-beginning 1))))

(defun pyimpsort--search-end-point (begin)
  "Search the last import line starting from BEGIN point."
  (let (end)
    (save-excursion
      (goto-char begin)
      (goto-char (point-at-bol))
      (catch 'eof
        (while (re-search-forward pyimpsort-imports-end-regexp (point-at-eol) t)
          (when (eobp)
            (throw 'eof "End of file."))
          (setq end (point-at-eol))
          (forward-line 1))))
    end))

;;;###autoload
(defun pyimpsort-region (begin end)
  "Sort python imports from region BEGIN to END points."
  (interactive "r")
  (atomic-change-group
    (or (zerop (shell-command-on-region begin end pyimpsort-command nil 'replace
                                        pyimpsort-error-buffer-name pyimpsort-display-error-buffer))
        (error "Command exited abnormally.  See %s for details" pyimpsort-error-buffer-name))))

;;;###autoload
(defun pyimpsort-buffer ()
  "Sort python imports from current buffer."
  (interactive)
  (let* ((begin (pyimpsort--search-beg-point))
         (end (and begin (pyimpsort--search-end-point begin))))
    (when (and begin end)
      (pyimpsort-region begin end))))

(provide 'pyimpsort)

;;; pyimpsort.el ends here
