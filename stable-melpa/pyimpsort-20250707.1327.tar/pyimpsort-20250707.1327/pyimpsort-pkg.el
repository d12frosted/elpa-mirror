;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyimpsort" "20250707.1327"
  "Sort python imports."
  '((emacs "24.3"))
  :url "https://github.com/emacs-pe/pyimpsort.el"
  :commit "e26c8932fc666c33a9dcbec6207c966c5b3b81ad"
  :revdesc "e26c8932fc66"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
