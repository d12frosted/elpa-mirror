(define-package "dir-treeview-themes" "20230112.134" "Themes for dir-treeview"
  '((emacs "24.4")
    (dir-treeview "1.3.3"))
  :commit "8e28c2501a978e6ff733fc9cf43a826fd8e7b87e" :authors
  '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainer
  '("Tilman Rassy" . "tilman.rassy@googlemail.com")
  :keywords
  '("tools" "convenience" "files")
  :url "https://github.com/tilmanrassy/emacs-dir-treeview-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
