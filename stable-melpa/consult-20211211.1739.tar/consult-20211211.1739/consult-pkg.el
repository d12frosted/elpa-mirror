(define-package "consult" "20211211.1739" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "1984605a4aa6707bd8b096440a1eda70212f616b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
