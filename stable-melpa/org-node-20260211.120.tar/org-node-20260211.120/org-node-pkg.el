;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260211.120"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "6d3f568659e831721160f483efe5e665c19e4705"
  :revdesc "6d3f568659e8"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
