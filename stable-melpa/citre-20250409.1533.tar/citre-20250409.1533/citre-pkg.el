;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citre" "20250409.1533"
  "Superior code reading & auto-completion tool with pluggable backends."
  '((emacs "26.1"))
  :url "https://github.com/universal-ctags/citre"
  :commit "693687d590a917a50d4bae8f539f0069c1fed947"
  :revdesc "693687d590a9"
  :keywords '("convenience" "tools")
  :authors '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainers '(("Hao Wang" . "amaikinono@gmail.com")))
