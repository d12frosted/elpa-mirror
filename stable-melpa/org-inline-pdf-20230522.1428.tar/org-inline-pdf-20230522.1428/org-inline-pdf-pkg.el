(define-package "org-inline-pdf" "20230522.1428" "Inline PDF previewing for Org"
  '((emacs "25.1")
    (org "9.4"))
  :commit "cd61240b598c6c175b84a670f9362f37b4d5589c" :authors
  '(("Shigeaki Nishina"))
  :maintainers
  '(("Shigeaki Nishina"))
  :maintainer
  '("Shigeaki Nishina")
  :keywords
  '("org" "outlines" "hypermedia")
  :url "https://github.com/shg/org-inline-pdf.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
