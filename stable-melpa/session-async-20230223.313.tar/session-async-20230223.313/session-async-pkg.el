(define-package "session-async" "20230223.313" "Asynchronous processing in a forked process session"
  '((emacs "27.1")
    (jsonrpc "1.0.9"))
  :commit "e06835ea181b3a15099280527c9a4590d2fa61d1" :authors
  '(("Felipe Lema" . "felipelema@mortemale.org"))
  :maintainers
  '(("Felipe Lema" . "felipelema@mortemale.org"))
  :maintainer
  '("Felipe Lema" . "felipelema@mortemale.org")
  :keywords
  '("async" "comm" "data" "files" "internal" "maint" "processes" "tools")
  :url "https://codeberg.org/FelipeLema/session-async.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
