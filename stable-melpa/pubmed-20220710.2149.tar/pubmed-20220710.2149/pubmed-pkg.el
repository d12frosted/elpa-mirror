(define-package "pubmed" "20220710.2149" "Interface to PubMed"
  '((emacs "26.1")
    (esxml "0.3.4")
    (s "1.12.0")
    (unidecode "0.2"))
  :commit "7e38b3f8ec72618b89afdeaa113f1787dcb690ca" :authors
  '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainer
  '("Folkert van der Beek" . "folkertvanderbeek@gmail.com")
  :keywords
  '("pubmed" "hypermedia")
  :url "https://gitlab.com/fvdbeek/emacs-pubmed")
;; Local Variables:
;; no-byte-compile: t
;; End:
