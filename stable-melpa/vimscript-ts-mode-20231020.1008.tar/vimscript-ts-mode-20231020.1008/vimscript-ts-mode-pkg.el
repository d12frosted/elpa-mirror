(define-package "vimscript-ts-mode" "20231020.1008" "Vim-script major mode using tree-sitter"
  '((emacs "29.1"))
  :commit "84c061f4f80f0768fbe2a8e4b7fb337da83bd150" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("languages" "vim" "tree-sitter")
  :url "https://github.com/nverno/vimscript-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
