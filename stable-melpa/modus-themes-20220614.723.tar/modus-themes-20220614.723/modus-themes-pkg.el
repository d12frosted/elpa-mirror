(define-package "modus-themes" "20220614.723" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "e342e3568c8a3a1cc20714c774bbe9df68489b32" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
