;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260309.839"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "5eb2f99f4da0cbc33bc1d7998266154540ebd2da"
  :revdesc "5eb2f99f4da0"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
