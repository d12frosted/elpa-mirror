(define-package "eldev" "20211026.1619" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "dec96c51321c45fe110e8be5ada8efc82884626b" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
