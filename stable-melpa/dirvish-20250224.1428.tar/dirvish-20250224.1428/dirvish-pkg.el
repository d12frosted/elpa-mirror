;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250224.1428"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "9f57250723151f0e35c5d901de4ab51f2e673b99"
  :revdesc "9f5725072315"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
