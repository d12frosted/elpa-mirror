(define-package "datetime" "20230915.1845" "Parsing, formatting and matching timestamps"
  '((emacs "24.4")
    (extmap "1.1.1"))
  :commit "4c422b6f9dbee8e090edc288d5e6a6d10a2be313" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
