(define-package "org-upcoming-modeline" "20230809.957" "Show next org event in mode line"
  '((emacs "26.1")
    (ts "0.2")
    (org-ql "0.6"))
  :commit "1f39a71fa04d6ee2808bced6dcacfed0f98b2e7e" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("convenience" "calendar")
  :url "https://github.com/unhammer/org-upcoming-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
