;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250610.1045"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "d1ce48de4d2e8fde6b3450fe90e3bb5ba10251c7"
  :revdesc "d1ce48de4d2e"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
