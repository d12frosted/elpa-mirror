;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261104.2307"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "d2e8c9d2623c87c8a3c44ba7aa29639da89920d3"
  :revdesc "d2e8c9d2623c"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
