(define-package "ellama" "20231016.932" "Ollama client for calling local LLMs"
  '((emacs "28.1"))
  :commit "92d4349bacb3db9d84ccbbf1b5c55dc95b10bc51" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
