(define-package "eldev" "20201223.2049" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "9ca9abb3edca233ab52ada40531bec4ce3a8e642" :authors
  (("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  ("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  ("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
