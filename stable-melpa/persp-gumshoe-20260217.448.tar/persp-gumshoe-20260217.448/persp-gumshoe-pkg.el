;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persp-gumshoe" "20260217.448"
  "Perspective support for gumshoe."
  '((emacs       "27.1")
    (perspective "2.0")
    (gumshoe     "4.0"))
  :url "https://github.com/Overdr0ne/gumshoe"
  :commit "4c228d89b35861f6461afcbd5cc596bd30582412"
  :revdesc "4c228d89b358"
  :keywords '("tools")
  :authors '(("overdr0ne" . "scmorris.dev@gmail.com"))
  :maintainers '(("overdr0ne" . "scmorris.dev@gmail.com")))
