;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20250703.1542"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "37ab67238c6991938ee4055cb52e892e60af0364"
  :revdesc "37ab67238c69"
  :keywords '("data" "extensions"))
