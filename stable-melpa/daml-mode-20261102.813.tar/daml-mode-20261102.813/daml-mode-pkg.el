;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daml-mode" "20261102.813"
  "Major mode for daml."
  '((emacs        "27.1")
    (haskell-mode "16.1"))
  :url "https://github.com/bartfaitamas/daml-mode"
  :commit "38c27dc971c9a0b1039b0b59b821c6192057479c"
  :revdesc "38c27dc971c9"
  :authors '(("Bártfai Tamás" . "tamas@bartfai.dev"))
  :maintainers '(("Bártfai Tamás" . "tamas@bartfai.dev")))
