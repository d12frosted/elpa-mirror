(define-package "helm" "20221027.541" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.8")
    (popup "0.5.3"))
  :commit "fed57a457cc46f38595f0057dbc842abced0c47f" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
