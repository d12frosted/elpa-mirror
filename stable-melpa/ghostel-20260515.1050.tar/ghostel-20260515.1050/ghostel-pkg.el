;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260515.1050"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "be0f53ff2ef0e4e97bc67b40799033eefbd645a8"
  :revdesc "be0f53ff2ef0"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
