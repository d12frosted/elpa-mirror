;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "20241205.1319"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://git.savannah.gnu.org/git/emms.git"
  :commit "e8f28b86929bb32d1074d988e3397b1e8009c22d"
  :revdesc "e8f28b86929b"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
