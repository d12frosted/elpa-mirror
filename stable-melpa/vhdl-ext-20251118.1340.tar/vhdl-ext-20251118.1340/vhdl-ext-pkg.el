;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ext" "20251118.1340"
  "VHDL Extensions."
  '((emacs        "29.1")
    (vhdl-ts-mode "0.3.2")
    (lsp-mode     "8.0.0")
    (ag           "0.48")
    (ripgrep      "0.4.0")
    (hydra        "0.15.0")
    (flycheck     "32")
    (async        "1.9.7"))
  :url "https://github.com/gmlarumbe/vhdl-ext"
  :commit "19b5be6e3b794e848b2554ffc6f03dfb35c75c8e"
  :revdesc "19b5be6e3b79"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
