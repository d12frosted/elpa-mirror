;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-line" "20261116.1735"
  "Custom and simple mode line."
  '((emacs "29.1"))
  :url "https://gitlab.com/aimebertrand/timu-line"
  :commit "0252da34e5ae5706d315a7370b886c05bcc6c2a4"
  :revdesc "0252da34e5ae"
  :keywords '("modeline" "frames" "ui")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
