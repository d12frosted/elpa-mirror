;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20250618.18"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "4fec18f9e4006e65c57edf97ac2ff3545a62fc9b"
  :revdesc "4fec18f9e400"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
