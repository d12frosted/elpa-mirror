;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260503.1351"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "c214d48dd80d5ba9b7d05b7751d67b9281cd25f4"
  :revdesc "c214d48dd80d"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
