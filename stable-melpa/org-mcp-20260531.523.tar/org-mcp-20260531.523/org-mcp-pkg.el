;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260531.523"
  "MCP server for Org-mode."
  '((emacs          "27.1")
    (mcp-server-lib "0.3.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "44b09c1872d9e8204bebd06a8c5e433c514103e7"
  :revdesc "44b09c1872d9"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
