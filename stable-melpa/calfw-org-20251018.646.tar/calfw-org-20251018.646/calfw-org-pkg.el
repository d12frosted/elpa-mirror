;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-org" "20251018.646"
  "Calendar view for org-agenda."
  '((emacs "28.1")
    (calfw "2.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "52ae145313f5ecbf91e7494386553e64d058c92c"
  :revdesc "52ae145313f5"
  :keywords '("calendar" "org")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
