(define-package "consult" "20220420.759" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "6f359b3ad8834718c64d0b32fa92e987109d56f6" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
