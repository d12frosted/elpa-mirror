;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "20260910.1641"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "79013d1b9cfe5cfe1a19bdb33ca4b9dfde4a2fa9"
  :revdesc "79013d1b9cfe"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
