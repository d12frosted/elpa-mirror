;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-view-data" "20260816.1321"
  "View Data."
  '((emacs     "26.1")
    (ess       "18.10.1")
    (csv-mode  "1.12")
    (transient "0.3.7"))
  :url "https://github.com/ShuguangSun/ess-view-data"
  :commit "831be384d0045ae9ff1f4b8ae2b5090377938475"
  :revdesc "831be384d004"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
