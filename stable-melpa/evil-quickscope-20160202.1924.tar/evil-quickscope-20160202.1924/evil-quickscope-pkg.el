;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-quickscope" "20160202.1924"
  "Highlight unique characters in words for f,F,t,T navigation."
  '((evil "0"))
  :url "https://github.com/blorbx/evil-quickscope"
  :commit "37a20e4c56c6058abf186ad4013c155e695e876f"
  :revdesc "37a20e4c56c6"
  :keywords '("faces" "emulation" "vim" "evil")
  :authors '(("Michael Chen" . "blorbx@gmail.com"))
  :maintainers '(("Michael Chen" . "blorbx@gmail.com")))
