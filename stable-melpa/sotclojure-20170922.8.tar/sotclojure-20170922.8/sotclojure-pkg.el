;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sotclojure" "20170922.8"
  "Write clojure at the speed of thought."
  '((emacs        "24.1")
    (clojure-mode "4.0.0")
    (cider        "0.8")
    (sotlisp      "1.3"))
  :url "https://github.com/Malabarba/speed-of-thought-clojure"
  :commit "ceac82aa691e8d98946471be6aaff9c9a4603c32"
  :revdesc "ceac82aa691e"
  :keywords '("convenience" "clojure")
  :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "emacs@endlessparentheses.com")))
