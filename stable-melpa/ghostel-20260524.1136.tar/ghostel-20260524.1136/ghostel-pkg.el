;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260524.1136"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "8b40864c490f5978373ca4936e33eb8a097c47a7"
  :revdesc "8b40864c490f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
