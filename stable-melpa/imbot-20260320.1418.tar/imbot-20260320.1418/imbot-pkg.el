;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260320.1418"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "3da793875b61c9e6c340e06ab40bb4912e202656"
  :revdesc "3da793875b61"
  :keywords '("convenience" "input method" "dbus"))
