;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual-symbol-overlay" "20260831.2152"
  "Transient UI for Symbol Overlay."
  '((emacs          "30.1")
    (casual         "3.0.0")
    (symbol-overlay "4.2"))
  :url "https://github.com/kickingvegas/casual-symbol-overlay"
  :commit "5da1b886607a1ad2ec73ff3dd9e2a67b683132ed"
  :revdesc "5da1b886607a"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
