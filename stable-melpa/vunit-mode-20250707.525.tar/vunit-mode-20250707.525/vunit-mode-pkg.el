;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vunit-mode" "20250707.525"
  "VUnit Runner Interface."
  '((hydra "0.14.0")
    (emacs "24.3"))
  :url "https://github.com/embed-me"
  :commit "e44cda6ef5a34b55e2c4e993ebe2d738841a7bb7"
  :revdesc "e44cda6ef5a3"
  :keywords '("vunit" "python" "tools")
  :authors '(("Lukas Lichtl" . "support@embed-me.com"))
  :maintainers '(("Lukas Lichtl" . "support@embed-me.com")))
