;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "declutter" "20220310.2101"
  "Read html content and (some) paywall sites without clutter."
  '((emacs "25.1"))
  :url "http://www.github.com/sanel/declutter"
  :commit "0b2ca86fa716dfc2fb3bc3425019f049dd65eda2"
  :revdesc "0b2ca86fa716"
  :keywords '("html" "hypermedia" "terminals")
  :authors '(("Sanel Zukan" . "sanelz@gmail.com"))
  :maintainers '(("Sanel Zukan" . "sanelz@gmail.com")))
