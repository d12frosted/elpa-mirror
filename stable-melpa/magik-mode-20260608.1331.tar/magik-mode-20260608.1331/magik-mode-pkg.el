;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260608.1331"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "ba05cca022a2cc27ee655acd1f25779b245ff380"
  :revdesc "ba05cca022a2"
  :keywords '("languages"))
