;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260701.1437"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "c4a6e1d63dea29e51edbaf788e3bee77d3e5c91d"
  :revdesc "c4a6e1d63dea"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
