;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-insert-plus" "20260127.1015"
  "Use insert and append as evil operators."
  '((emacs "24.4")
    (evil  "1.14.0"))
  :url "https://github.com/yad-tahir/evil-insert-plus"
  :commit "d584ed3ea2a49ed7f93fe176800e7a2f95dff6aa"
  :revdesc "d584ed3ea2a4"
  :keywords '("emulations" "textvim" "editing")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
