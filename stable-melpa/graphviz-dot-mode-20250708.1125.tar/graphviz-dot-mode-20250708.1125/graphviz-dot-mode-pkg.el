;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphviz-dot-mode" "20250708.1125"
  "Mode for the dot-language used by graphviz (att)."
  '((emacs "25.0"))
  :url "https://ppareit.github.io/graphviz-dot-mode/"
  :commit "1840165b60df7409cfccacbe5365843309d51aaa"
  :revdesc "1840165b60df"
  :keywords '("mode" "dot" "dot-language" "dotlanguage" "graphviz" "graphs" "att")
  :maintainers '(("Pieter Pareit" . "pieter.pareit@gmail.com")))
