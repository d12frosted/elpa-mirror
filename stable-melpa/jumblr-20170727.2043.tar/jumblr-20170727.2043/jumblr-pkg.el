;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jumblr" "20170727.2043"
  "An anagram game for emacs."
  '((s    "1.8.0")
    (dash "2.2.0"))
  :url "https://github.com/mkmcc/jumblr"
  :commit "34533dfb9db8538c005f4eaffafeff7ed193729f"
  :revdesc "34533dfb9db8"
  :keywords '("anagram" "word game" "games")
  :authors '(("Mike McCourt" . "mkmcc@astro.berkeley.edu"))
  :maintainers '(("Mike McCourt" . "mkmcc@astro.berkeley.edu")))
