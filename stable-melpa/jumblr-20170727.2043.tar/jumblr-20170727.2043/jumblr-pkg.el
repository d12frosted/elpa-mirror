(define-package "jumblr" "20170727.2043" "an anagram game for emacs"
  '((s "1.8.0")
    (dash "2.2.0"))
  :commit "34533dfb9db8538c005f4eaffafeff7ed193729f" :keywords
  ("anagram" "word game" "games")
  :url "https://github.com/mkmcc/jumblr")
;; Local Variables:
;; no-byte-compile: t
;; End:
