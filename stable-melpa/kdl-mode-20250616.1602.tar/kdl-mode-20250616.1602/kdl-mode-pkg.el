;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kdl-mode" "20250616.1602"
  "Major mode for editing KDL files."
  '((emacs "29.1"))
  :url "https://github.com/taquangtrung/emacs-kdl-mode"
  :commit "78a2fb34268eb1ec8b47b6c131fea392deb30d5c"
  :revdesc "78a2fb34268e"
  :keywords '("languages"))
