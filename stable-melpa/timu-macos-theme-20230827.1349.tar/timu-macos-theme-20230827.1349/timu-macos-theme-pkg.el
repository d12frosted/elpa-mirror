(define-package "timu-macos-theme" "20230827.1349" "Color theme inspired by the macOS UI"
  '((emacs "27.1"))
  :commit "7246a60147b082807df22b78d7cbb306e1d3fcb1" :authors
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainer
  '("Aimé Bertrand" . "aime.bertrand@macowners.club")
  :keywords
  '("faces" "themes")
  :url "https://gitlab.com/aimebertrand/timu-macos-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
