(define-package "websearch" "20220809.1338" "Query search engines"
  '((emacs "24.4"))
  :commit "362bf974532e01c31d4abb340ed3f749da385175" :authors
  '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainer
  '("Maciej Barć" . "xgqt@riseup.net")
  :keywords
  '("convenience" "hypermedia")
  :url "https://gitlab.com/xgqt/emacs-websearch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
