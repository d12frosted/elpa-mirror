;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20260910.859"
  "Display documentation for mouse hover."
  '((emacs    "27.1")
    (posframe "1.5.1")
    (eglot    "1.23"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "0c2285ba8f974ee3a295a6626f989e2b7c8a184e"
  :revdesc "0c2285ba8f97"
  :keywords '("tools" "languages" "convenience" "mouse" "hover")
  :authors '(("Huang Feiyu" . "sibadake1@163.com"))
  :maintainers '(("Huang Feiyu" . "sibadake1@163.com")))
