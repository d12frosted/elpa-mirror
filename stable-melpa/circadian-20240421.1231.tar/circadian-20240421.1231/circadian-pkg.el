(define-package "circadian" "20240421.1231" "Theme-switching based on daytime"
  '((emacs "24.4"))
  :commit "5203f15730f31a1c7263d83a8d2816a0f35e4e2e" :authors
  '(("Guido Schmidt"))
  :maintainers
  '(("Guido Schmidt" . "git@guidoschmidt.cc"))
  :maintainer
  '("Guido Schmidt" . "git@guidoschmidt.cc")
  :keywords
  '("themes")
  :url "https://github.com/GuidoSchmidt/circadian")
;; Local Variables:
;; no-byte-compile: t
;; End:
