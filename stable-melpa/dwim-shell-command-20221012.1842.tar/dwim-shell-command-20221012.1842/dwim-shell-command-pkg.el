(define-package "dwim-shell-command" "20221012.1842" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "8dd23b6b19d69307f0b43303285c1bae140157cf" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
