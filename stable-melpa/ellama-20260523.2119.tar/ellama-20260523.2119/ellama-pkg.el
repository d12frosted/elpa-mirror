;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260523.2119"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.30.2")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "dd96e6fceb78e2a2f9b0e407bc619f095eb6d82e"
  :revdesc "dd96e6fceb78"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
