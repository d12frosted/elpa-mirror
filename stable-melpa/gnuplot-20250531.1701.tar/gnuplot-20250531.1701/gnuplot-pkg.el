;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250531.1701"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "85c5a6ae32359f6505f03a9da080915825ec191e"
  :revdesc "85c5a6ae3235"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
