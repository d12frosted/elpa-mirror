;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260430.1555"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "95e6b2c14e8eb3ab6f7bacc1a3f112246b6a54c9"
  :revdesc "95e6b2c14e8e"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
