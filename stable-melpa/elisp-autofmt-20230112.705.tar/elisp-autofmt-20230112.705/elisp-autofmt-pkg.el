(define-package "elisp-autofmt" "20230112.705" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "f7e3732711907bb4f6b6409950756aff525cf9fe" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
