;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu" "20260105.449"
  "Undo helper with redo."
  '((emacs "25.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu"
  :commit "17fc25be69c06225b5b74f65e7ff6c212919bd3f"
  :revdesc "17fc25be69c0"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
