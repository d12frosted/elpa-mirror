(define-package "modus-themes" "20220321.2139" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "c3fc319bcfc3541a5cb575672a769e9a97e7eacd" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
