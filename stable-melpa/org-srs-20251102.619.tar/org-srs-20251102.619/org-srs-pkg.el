;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251102.619"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "5b470c3cbcddc41221de45f9470df5599b73ea99"
  :revdesc "5b470c3cbcdd"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
