;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260212.544"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e217c6083eb32c9e9b94ca500c761cfe496f13bc"
  :revdesc "e217c6083eb3"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
