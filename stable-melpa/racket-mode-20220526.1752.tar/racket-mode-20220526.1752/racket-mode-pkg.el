(define-package "racket-mode" "20220526.1752" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "ab8f953728a653bc6c53681c845a3a69133fdd4d" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
