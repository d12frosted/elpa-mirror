;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-shell-interpreter" "20260727.1248"
  "Helper for shell command APIs."
  '((emacs  "25.1")
    (cl-lib "0.6.1"))
  :url "https://github.com/p3r7/with-shell-interpreter"
  :commit "d960763b99e78fefc266fdd0d7de70bb6496aa78"
  :revdesc "d960763b99e7"
  :keywords '("processes" "terminals"))
