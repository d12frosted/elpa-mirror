(define-package "ekg" "20230410.338" "A system for recording and linking information"
  '((triples "0.2.5")
    (emacs "28.1"))
  :commit "722fc1e5c2c9afd30e39ddbbf8559486fdb76f5c" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
