(define-package "vulpea" "20231031.802" "A collection of org-roam note-taking functions"
  '((emacs "27.2")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12")
    (dash "2.19"))
  :commit "f4f220896aaaeee41b2341b74c1b9a554cf9c015" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
