(define-package "org2blog" "20220903.1653" "Blog from Org mode to WordPress"
  '((htmlize "1.56")
    (hydra "0.15.0")
    (xml-rpc "1.6.15")
    (metaweblog "1.1.13"))
  :commit "bc3bfe299e98a4bbe01bb0bc751fd74571aeca27" :authors
  '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainer
  '("Grant Rettke" . "grant@wisdomandwonder.com")
  :keywords
  '("comm" "convenience" "outlines" "wp")
  :url "https://github.com/org2blog/org2blog")
;; Local Variables:
;; no-byte-compile: t
;; End:
