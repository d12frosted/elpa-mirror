;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20241210.631"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "4f4d29d3e6665c73dbfbe743e0c2ae7e6f8cb8af"
  :revdesc "4f4d29d3e666"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
