(define-package "darkman" "20230318.1035" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "9f1f713b210ab7317191ab5c73e8e4216d0ef8ab" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://grtcdr.tn/darkman.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
