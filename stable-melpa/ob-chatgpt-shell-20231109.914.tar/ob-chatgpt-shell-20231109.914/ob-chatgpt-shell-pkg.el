(define-package "ob-chatgpt-shell" "20231109.914" "Org babel functions for ChatGPT evaluation"
  '((emacs "27.1")
    (chatgpt-shell "0.87.1"))
  :commit "58bb4d8eb9218be4925201a39596387d160f4593" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
