;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-chat" "20260323.206"
  "Emacs client for Lisp Chat."
  '((emacs     "27.1")
    (websocket "1.12"))
  :url "https://github.com/ryukinix/lisp-chat"
  :commit "cff980c915db1e47d3090c212050b7598d15daca"
  :revdesc "cff980c915db"
  :keywords '("comm" "chat" "lisp"))
