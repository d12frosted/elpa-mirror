(define-package "finito" "20220307.1527" "View and collect books"
  '((emacs "27.1")
    (dash "2.17.0")
    (request "0.3.2")
    (f "0.2.0")
    (s "1.12.0")
    (transient "0.3.0")
    (graphql "0.1.1")
    (async "1.9.3"))
  :commit "6e707da7ffc87d4e90c90694004d91dfa8b1d4ca" :authors
  '(("Laurence Warne"))
  :maintainer
  '("Laurence Warne")
  :keywords
  '("outlines")
  :url "https://github.com/LaurenceWarne/finito.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
