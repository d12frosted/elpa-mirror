(define-package "org-ql" "20231101.1937" "Org Query Language, search command, and agenda-like view"
  '((emacs "26.1")
    (dash "2.18.1")
    (f "0.17.2")
    (map "2.1")
    (org "9.0")
    (org-super-agenda "1.2")
    (ov "1.0.6")
    (peg "1.0.1")
    (s "1.12.0")
    (transient "0.1")
    (ts "0.2pre"))
  :commit "e885001a2ad14b8367ce66e011ecd6088782f677" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("hypermedia" "outlines" "org" "agenda")
  :url "https://github.com/alphapapa/org-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
