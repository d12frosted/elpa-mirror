(define-package "spdx" "20230322.110" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "7692d30983bd3299d42265266edb181d8bbc8d12" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
