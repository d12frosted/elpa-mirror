;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pastehub" "20140627.1319"
  "A client for the PasteHub cloud service."
  ()
  :url "https://github.com/kiyoka/pastehub"
  :commit "37b045c67659c078f1517d0fbd5282dab58dca23"
  :revdesc "37b045c67659")
