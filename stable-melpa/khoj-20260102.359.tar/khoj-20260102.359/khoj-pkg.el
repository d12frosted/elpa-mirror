;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "khoj" "20260102.359"
  "Your Second Brain."
  '((emacs     "27.1")
    (transient "0.3.0")
    (dash      "2.19.1"))
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs"
  :commit "d55a00288bd6257d1b84f2a491ca24fb00530d43"
  :revdesc "d55a00288bd6"
  :keywords '("search" "chat" "ai" "org-mode" "outlines" "markdown" "pdf" "image")
  :authors '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
             ("Saba Imran" . "saba@khoj.dev"))
  :maintainers '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
                 ("Saba Imran" . "saba@khoj.dev")))
