;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-view" "20250409.2120"
  "View R dataframes in a spreadsheet software."
  '((ess "15")
    (s   "1.8.0")
    (f   "0.16.0"))
  :url "https://github.com/GioBo/ess-view"
  :commit "82df032e6e367e7f587e6131925c0a349c685f93"
  :revdesc "82df032e6e36"
  :keywords '("extensions" "ess")
  :authors '(("Bocci Gionata" . "boccigionata@gmail.com"))
  :maintainers '(("Bocci Gionata" . "boccigionata@gmail.com")))
