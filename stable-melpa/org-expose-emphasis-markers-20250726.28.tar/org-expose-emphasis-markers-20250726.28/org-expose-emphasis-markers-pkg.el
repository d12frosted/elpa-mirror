;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-expose-emphasis-markers" "20250726.28"
  "Automatically show hidden org emphasis markers."
  '((emacs "29.1"))
  :url "https://github.com/lorniu/org-expose-emphasis-markers"
  :commit "5ca3994f2e13b342e0b9d353b66b892e34c7b784"
  :revdesc "5ca3994f2e13"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
