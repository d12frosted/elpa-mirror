(define-package "demap" "20220317.829" "Detachable minimap package"
  '((emacs "24.4")
    (dash "2.18.0"))
  :commit "cb119fa912699a7697b958a467e21f655b95a741" :authors
  '(("Sawyer Gardner <https://gitlab.com/sawyerjgardner>"))
  :maintainer
  '("Sawyer Gardner <https://gitlab.com/sawyerjgardner>")
  :keywords
  '("lisp" "tools" "convenience")
  :url "https://gitlab.com/sawyerjgardner/demap.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
