;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "secretaria" "20191128.250"
  "A personal assistant based on org-mode."
  '((emacs "24.4")
    (alert "1.2")
    (s     "1.12")
    (f     "0.20.0")
    (org   "9"))
  :url "https://gitlab.com/shackra/secretaria"
  :commit "03986130a2ada1fa952d45e83536729f20230fcf"
  :revdesc "03986130a2ad"
  :keywords '("org" "convenience")
  :authors '(("Jorge Araya Navarro" . "jorge@esavara.cr"))
  :maintainers '(("Jorge Araya Navarro" . "jorge@esavara.cr")))
