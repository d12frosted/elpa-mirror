;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tomorrow-night-deepblue-theme" "20260114.1535"
  "The Tomorrow Night Deepblue color theme."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/tomorrow-night-deepblue-theme.el"
  :commit "28170a5c5d9cec2af1531f12b284037fe7fd043c"
  :revdesc "28170a5c5d9c"
  :keywords '("faces" "themes"))
