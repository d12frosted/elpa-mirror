;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260618.347"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "a628daadccad4827fc93cf16cb698ee36a45c1b7"
  :revdesc "a628daadccad"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
