(define-package "norns" "20240928.818" "Interactive development environment for monome norns"
  '((emacs "27.1")
    (dash "2.17.0")
    (s "1.12.0")
    (f "0.20.0")
    (request "0.3.2")
    (websocket "1.13")
    (lua-mode "20221218.605"))
  :commit "9c5d3e5220958454256835675290449013b39edb" :keywords
  '("processes" "terminals")
  :url "https://github.com/p3r7/norns.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
