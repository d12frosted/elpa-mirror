(define-package "wordreference" "20230710.1203" "Interface for wordreference.com"
  '((emacs "28.1"))
  :commit "00e563c3b5f1634c8f43516d0e5a9674db7b6099" :authors
  '(("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainers
  '(("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainer
  '("Marty Hiatt <martianhiatus AT riseup.net>")
  :keywords
  '("convenience" "translate" "wp" "dictionary")
  :url "https://codeberg.org/martianh/wordreference.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
