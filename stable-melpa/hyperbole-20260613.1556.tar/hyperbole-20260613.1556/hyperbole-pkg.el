;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260613.1556"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e9be3e3d403735b13cd3eb99f5536f4b3b214e4f"
  :revdesc "e9be3e3d4037"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
