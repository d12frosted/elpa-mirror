(define-package "smudge" "20231207.2023" "Control the Spotify app"
  '((emacs "27.1")
    (simple-httpd "20230821.1458")
    (request "0.3")
    (oauth2 "0.16"))
  :commit "fe76ef5b6093fdc85a1bf91166451f148bafe970" :keywords
  '("multimedia" "music" "spotify" "smudge")
  :url "https://github.com/danielfm/smudge")
;; Local Variables:
;; no-byte-compile: t
;; End:
