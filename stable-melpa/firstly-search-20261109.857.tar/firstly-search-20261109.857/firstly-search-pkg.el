;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "20261109.857"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "dbcea6190390d74c56da2962a7f07aa76fffa298"
  :revdesc "dbcea6190390"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
