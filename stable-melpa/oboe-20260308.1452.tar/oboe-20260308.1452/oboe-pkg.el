;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260308.1452"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "4914e582087e14f8c3c09db51f1d32159bc06a00"
  :revdesc "4914e582087e"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
