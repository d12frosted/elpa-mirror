;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "20261111.914"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "0173e7e12375439c49dcc81bce1d0637d13e7260"
  :revdesc "0173e7e12375"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
