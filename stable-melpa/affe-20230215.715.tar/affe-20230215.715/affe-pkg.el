(define-package "affe" "20230215.715" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.32"))
  :commit "69d9d05200dbf9058b3ae14e37f52944718374d7" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
