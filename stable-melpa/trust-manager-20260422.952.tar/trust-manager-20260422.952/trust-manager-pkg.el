;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "20260422.952"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "3a702921eaa65ce8de552e88f6280786a645252d"
  :revdesc "3a702921eaa6"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
