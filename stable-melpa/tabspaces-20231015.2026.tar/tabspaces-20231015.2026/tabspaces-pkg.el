(define-package "tabspaces" "20231015.2026" "Leverage tab-bar and project for buffer-isolated workspaces"
  '((emacs "27.1")
    (project "0.8.1"))
  :commit "eb8925c50eacf0f5ba9df094cbda50f35912e78e" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainers
  '(("Colin McLear"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/mclear-tools/tabspaces")
;; Local Variables:
;; no-byte-compile: t
;; End:
