;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251023.1126"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "0d6cbd8fd88123b0c3ed3b47be6ca9e693e9221f"
  :revdesc "0d6cbd8fd881"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
