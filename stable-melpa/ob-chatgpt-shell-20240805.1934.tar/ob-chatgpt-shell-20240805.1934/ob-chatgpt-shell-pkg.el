(define-package "ob-chatgpt-shell" "20240805.1934" "Org babel functions for ChatGPT evaluation"
  '((emacs "27.1")
    (chatgpt-shell "1.0.3"))
  :commit "fe75c5d516b149c635cda97627e8f920f277d36e" :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
