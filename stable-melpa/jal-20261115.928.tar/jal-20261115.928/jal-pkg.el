;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jal" "20261115.928"
  "Java Agent Loader (JAL) for JDTLS."
  '((emacs "28.1"))
  :url "https://github.com/saulotoledo/java-agent-loader"
  :commit "f90e7c09e554c4609f8714021c45966bbe6b2743"
  :revdesc "f90e7c09e554"
  :keywords '("java" "languages" "tools")
  :authors '(("Saulo Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo Toledo" . "saulotoledo@gmail.com")))
