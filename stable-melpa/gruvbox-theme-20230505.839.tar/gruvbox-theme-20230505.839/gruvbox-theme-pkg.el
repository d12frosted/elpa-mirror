(define-package "gruvbox-theme" "20230505.839" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "87e493130a53c460782bae6d86d6c917b798e930" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
