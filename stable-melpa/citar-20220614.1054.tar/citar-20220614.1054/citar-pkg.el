(define-package "citar" "20220614.1054" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "3.0")
    (org "9.5")
    (citeproc "0.9"))
  :commit "dd028c6a4d2fb1c7b89082dffa15be01637765c5" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
