(define-package "modus-themes" "20230220.1859" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "f4282839d880a88062acaafbd8acea2708d3932b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
