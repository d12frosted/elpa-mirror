;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gomacro-mode" "20200326.1103"
  "Gomacro mode and Go REPL integration."
  '((emacs   "24.4")
    (go-mode "1.5.0"))
  :url "https://github.com/storvik/gomacro-mode"
  :commit "66b77efebb9654aa60383a1014f716f8cd74e3fc"
  :revdesc "66b77efebb96"
  :keywords '("gomacro" "repl" "languages" "tools" "processes"))
