;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20250115.1843"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://github.com/mclear-tools/tabspaces"
  :commit "47794d6ef56d9ce984dd446f138715e7cac2dfe9"
  :revdesc "47794d6ef56d"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
