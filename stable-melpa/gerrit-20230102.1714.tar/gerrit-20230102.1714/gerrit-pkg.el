(define-package "gerrit" "20230102.1714" "Gerrit client"
  '((emacs "25.1")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "76cc426d62f1b4964159706eafa8f5b50b8427ea" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainers
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
