(define-package "vhdl-ts-mode" "20240917.1210" "VHDL Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "f0843b4b801d4be07a06648065ae502804221027" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
