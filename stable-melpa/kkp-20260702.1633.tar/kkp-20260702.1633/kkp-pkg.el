;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "20260702.1633"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "fed406cf540a900d26e31f9c29b684d1a7b0ff8b"
  :revdesc "fed406cf540a"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
