;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250506.356"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "2f0234635cf50d7b8e38e16a012d273b7ee9257a"
  :revdesc "2f0234635cf5"
  :keywords '("agent" "ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
