(define-package "chatgpt-shell" "20231103.1141" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.42.1"))
  :commit "5ff7056917d83eccbcad8d093c5cfcf457f9bb6f" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
