;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20260921.1039"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "ef5654e63a48098dfc42a4a4bbe17c503070f8c5"
  :revdesc "ef5654e63a48"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
