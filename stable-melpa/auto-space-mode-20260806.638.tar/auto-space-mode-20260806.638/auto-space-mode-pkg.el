;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-space-mode" "20260806.638"
  "Auto add space between CJK and ASCII."
  '((emacs "29.1"))
  :url "https://github.com/wowhxj/auto-space-mode"
  :commit "9c474bc294d77ca6af7fcb248919765d96d3bb5f"
  :revdesc "9c474bc294d7"
  :keywords '("convenience" "wp")
  :authors '(("Randolph" . "xiaojianghuang@yahoo.com"))
  :maintainers '(("Randolph" . "xiaojianghuang@yahoo.com")))
