;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "20260412.348"
  "Run REPLs in a terminal backend."
  '((emacs "29.1"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "689549245bb6dc0429d8af06c4830c92b09f4667"
  :revdesc "689549245bb6"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
