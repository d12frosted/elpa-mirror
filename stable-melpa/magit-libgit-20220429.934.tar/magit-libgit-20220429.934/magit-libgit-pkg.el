(define-package "magit-libgit" "20220429.934" "."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (libgit "0")
    (magit "20211004"))
  :commit "eef732e30b9409e1b3c96edf2a62c764be86097c" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
