(define-package "magit-section" "20220216.1853" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "222cbb30f9fcbbb619b5c826301566c8efbae463" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
