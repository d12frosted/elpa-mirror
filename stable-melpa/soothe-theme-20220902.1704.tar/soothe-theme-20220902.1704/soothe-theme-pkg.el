(define-package "soothe-theme" "20220902.1704" "A dark colorful theme"
  '((emacs "24.3")
    (autothemer "0.2"))
  :commit "a9e6e47cb90182f75a748fffab87c974f76489fc" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/emacs-soothe-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
