;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prompt-text" "20190408.310"
  "Configure your minibuffer prompt."
  ()
  :url "https://github.com/10sr/prompt-text-el"
  :commit "b842bf13c53d0a2bd2bc7a00d37cc713d69fa9e9"
  :revdesc "b842bf13c53d"
  :keywords '("utility" "minibuffer")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
