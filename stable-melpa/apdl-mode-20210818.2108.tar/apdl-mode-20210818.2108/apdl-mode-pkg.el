(define-package "apdl-mode" "20210818.2108" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "91fcc64687a3df7d3fa83c2b1f34d12385ae3b5a" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
