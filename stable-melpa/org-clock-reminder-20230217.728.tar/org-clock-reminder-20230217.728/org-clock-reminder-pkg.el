(define-package "org-clock-reminder" "20230217.728" "Notifications that remind you about clocked-in tasks"
  '((emacs "26.1"))
  :commit "fd3d2ca9d5ca1a804c0e70193f89f650c69a8dc1" :authors
  '(("Nikolay Brovko" . "i@nickey.ru"))
  :maintainer
  '("Nikolay Brovko" . "i@nickey.ru")
  :keywords
  '("calendar" "convenience")
  :url "https://github.com/inickey/org-clock-reminder")
;; Local Variables:
;; no-byte-compile: t
;; End:
