(define-package "go-translate" "20211007.906" "Google Translate"
  '((emacs "26.1"))
  :commit "9fa4bc5669f77503af2f56bbc97ccb78a5c4bf17" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
