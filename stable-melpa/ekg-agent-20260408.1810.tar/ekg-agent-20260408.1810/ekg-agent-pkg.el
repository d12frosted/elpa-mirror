;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260408.1810"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "cda27dc2be9c08b994b9a4dc8b68f16f4e74c19e"
  :revdesc "cda27dc2be9c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
