;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260618.347"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "a628daadccad4827fc93cf16cb698ee36a45c1b7"
  :revdesc "a628daadccad"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
