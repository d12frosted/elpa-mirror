;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260213.802"
  "Manage and navigate projects in Emacs easily."
  '((emacs "26.1"))
  :url "https://github.com/bbatsov/projectile"
  :commit "5ac57c2553fd0d62cedd176c86c9e10fa0bebc97"
  :revdesc "5ac57c2553fd"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
