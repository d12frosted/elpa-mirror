;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260109.511"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "073e1d248877ba86336820ede620ce19204477ad"
  :revdesc "073e1d248877"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
