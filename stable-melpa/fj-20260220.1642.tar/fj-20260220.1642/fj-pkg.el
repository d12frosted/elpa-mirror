;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20260220.1642"
  "Client for Forgejo instances."
  ()
  :url "https://codeberg.org/martianh/fj.el"
  :commit "48a299cb54b9001b40f88789f8c693b5c408dabb"
  :revdesc "48a299cb54b9"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
