(define-package "fanyi" "20220306.2010" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "efde72ba9ba5e38fd02812db523a40bb186b567e" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
