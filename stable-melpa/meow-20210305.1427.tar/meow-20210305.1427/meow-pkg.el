(define-package "meow" "20210305.1427" "Modal Editing On Wheel"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1")
    (s "1.12.0"))
  :commit "790fe0f6e8b4af7cfe265c4f999846d94ba8d21f" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
