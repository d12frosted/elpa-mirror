;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-server" "20261124.1524"
  "Speaks HTTP for you."
  '((emacs "30.1"))
  :url "https://codeberg.org/martenlienen/http-server.el"
  :commit "1c0f70f10b5a9b1a64b4c07d2f55cb0c446a3add"
  :revdesc "1c0f70f10b5a"
  :keywords '("comm")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
