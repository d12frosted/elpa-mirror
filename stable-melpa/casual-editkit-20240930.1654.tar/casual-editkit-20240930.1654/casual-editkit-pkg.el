;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual-editkit" "20240930.1654"
  "Transient user interface library for editing commands."
  '((emacs                 "29.1")
    (casual-lib            "1.1.0")
    (casual-symbol-overlay "1.0.1")
    (magit                 "4.0.0")
    (transpose-frame       "0.2.1"))
  :url "https://github.com/kickingvegas/casual-editkit"
  :commit "1da33bfc7e4e698504e3496aa3374f191dcc54a1"
  :revdesc "1da33bfc7e4e"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
