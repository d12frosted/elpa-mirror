(define-package "fennel-mode" "20220928.842" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "9173638b9a1f15e94a05440fdaec7a2f9ea45438" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
