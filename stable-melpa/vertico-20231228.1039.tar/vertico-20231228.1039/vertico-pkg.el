(define-package "vertico" "20231228.1039" "VERTical Interactive COmpletion"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "b8a408c5ae150bc117cd940f6a7f814dab6b15aa" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "files" "matching" "completion")
  :url "https://github.com/minad/vertico")
;; Local Variables:
;; no-byte-compile: t
;; End:
