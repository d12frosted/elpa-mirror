(define-package "tuareg" "20210825.1050" "OCaml mode for Emacs."
  '((caml "3.12.0.1")
    (emacs "24.4"))
  :commit "f929e34c327e25c783995e3c1d72c5153c779468" :authors
  '(("Albert Cohen" . "Albert.Cohen@inria.fr")
    ("Sam Steingold" . "sds@gnu.org")
    ("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
    ("Till Varoquaux" . "till@pps.jussieu.fr")
    ("Sean McLaughlin" . "seanmcl@gmail.com")
    ("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainer
  '("Albert Cohen" . "Albert.Cohen@inria.fr")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/tuareg")
;; Local Variables:
;; no-byte-compile: t
;; End:
