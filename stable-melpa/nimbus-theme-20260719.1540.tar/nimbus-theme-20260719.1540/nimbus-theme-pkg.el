;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "20260719.1540"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "d755926ec6984207f63733a0fa9612954b350c34"
  :revdesc "d755926ec698"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
