(define-package "racket-mode" "20211013.1707" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "5ada3fff992bb5f3f2c35908aba25619621d0818" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
