;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260918.844"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "9427ba44964a292f03273e5be4d7a0f3c00b5029"
  :revdesc "9427ba44964a"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
