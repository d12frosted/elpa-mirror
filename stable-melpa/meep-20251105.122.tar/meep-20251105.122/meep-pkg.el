;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251105.122"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "f5836749f96aa9f74320d7cdf097f21a86813a89"
  :revdesc "f5836749f96a"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
