(define-package "org-page" "20230826.1157" "a static site generator based on org mode"
  '((ht "1.5")
    (simple-httpd "1.4.6")
    (mustache "0.22")
    (htmlize "1.47")
    (org "8.0")
    (dash "2.0.0")
    (cl-lib "0.5")
    (git "0.1.1"))
  :commit "0b229083b09f9c8f923b98fc2f03c665939bb87a" :authors
  '(("Kelvin Hu <ini DOT kelvin AT gmail DOT com>"))
  :maintainer
  '("Kelvin Hu <ini DOT kelvin AT gmail DOT com>")
  :keywords
  '("org-mode" "convenience" "beautify")
  :url "https://github.com/kelvinh/org-page")
;; Local Variables:
;; no-byte-compile: t
;; End:
