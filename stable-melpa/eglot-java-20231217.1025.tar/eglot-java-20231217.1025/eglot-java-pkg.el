(define-package "eglot-java" "20231217.1025" "Java extension for the eglot LSP client"
  '((emacs "26.1")
    (eglot "1.0")
    (jsonrpc "1.0.0"))
  :commit "ca47effe999c50e43c6246429642ba0ce2d2791c" :authors
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainers
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainer
  '("Yves Zoundi" . "yves_zoundi@hotmail.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/yveszoundi/eglot-java")
;; Local Variables:
;; no-byte-compile: t
;; End:
