;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nodemcu-mode" "20180501.2225"
  "Minor mode for NodeMCU."
  '((emacs "25"))
  :url "https://github.com/andrmuel/nodemcu-mode"
  :commit "8effd9f3df40b6b92a2f05e4d54750b624afc4a7"
  :revdesc "8effd9f3df40"
  :keywords '("tools")
  :authors '(("Andreas Müller" . "code@0x7.ch"))
  :maintainers '(("Andreas Müller" . "code@0x7.ch")))
