(define-package "inf-ruby" "20230923.12" "Run a Ruby process in a buffer"
  '((emacs "24.3"))
  :commit "4714f02bd86d354f99b77868fe39a71fa29b774f" :authors
  '(("Yukihiro Matsumoto")
    ("Nobuyoshi Nakada")
    ("Cornelius Mika" . "cornelius.mika@gmail.com")
    ("Dmitry Gutov" . "dgutov@yandex.ru")
    ("Kyle Hargraves" . "pd@krh.me"))
  :maintainers
  '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("languages" "ruby")
  :url "http://github.com/nonsequitur/inf-ruby")
;; Local Variables:
;; no-byte-compile: t
;; End:
