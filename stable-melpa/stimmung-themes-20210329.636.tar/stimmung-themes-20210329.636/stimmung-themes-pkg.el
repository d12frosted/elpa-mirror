(define-package "stimmung-themes" "20210329.636" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "234b0e16bc535b4e3b55f959fa103e2d0ab6e4da" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
