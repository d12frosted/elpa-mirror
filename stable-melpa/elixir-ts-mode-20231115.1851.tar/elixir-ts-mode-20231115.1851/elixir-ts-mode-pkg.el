(define-package "elixir-ts-mode" "20231115.1851" "Major mode for Elixir with tree-sitter support"
  '((emacs "29.1")
    (heex-ts-mode "1.3"))
  :commit "d56d5915d4540a4f55f495e27407637d0359c774" :authors
  '(("Wilhelm H Kirschbaum"))
  :maintainers
  '(("Wilhelm H Kirschbaum"))
  :maintainer
  '("Wilhelm H Kirschbaum")
  :keywords
  '("elixir" "languages" "tree-sitter")
  :url "https://github.com/wkirschbaum/elixir-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
