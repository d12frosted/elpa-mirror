(define-package "consult" "20230513.1232" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "838d0af87b626c6bef0ddf0c19db5d11edb3be2b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
