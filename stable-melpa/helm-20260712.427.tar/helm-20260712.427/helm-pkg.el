;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20260712.427"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "3cc1cef0f852a277cabeb51f3d1158d78073d6b5"
  :revdesc "3cc1cef0f852"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
