(define-package "gptel" "20240402.1850" "Interact with ChatGPT or other LLMs"
  '((emacs "27.1")
    (transient "0.4.0")
    (compat "29.1.4.1"))
  :commit "53ee34653e8a40719731bb0ce5149f296780ffb1" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
