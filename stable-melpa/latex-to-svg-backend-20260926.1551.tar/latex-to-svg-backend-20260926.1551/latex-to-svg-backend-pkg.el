;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-backend" "20260926.1551"
  "LaTeX-to-SVG rendering backend with caching."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/latex-to-svg-backend"
  :commit "82ebce7b31b0e41ac9ced3db23cdb3fa5b2b0940"
  :revdesc "82ebce7b31b0"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
