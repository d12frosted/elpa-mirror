(define-package "org-roam-ui" "20220803.1024" "User Interface for Org-roam"
  '((emacs "27.1")
    (org-roam "2.0.0")
    (simple-httpd "20191103.1446")
    (websocket "1.13"))
  :commit "16a8da9e5107833032893bc4c0680b368ac423ac" :authors
  '(("Kirill Rogovoy, Thomas Jorna"))
  :maintainer
  '("Kirill Rogovoy, Thomas Jorna")
  :keywords
  '("files" "outlines")
  :url "https://github.com/org-roam/org-roam-ui")
;; Local Variables:
;; no-byte-compile: t
;; End:
