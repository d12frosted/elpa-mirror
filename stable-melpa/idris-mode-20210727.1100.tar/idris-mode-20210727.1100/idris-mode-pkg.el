(define-package "idris-mode" "20210727.1100" "Major mode for editing Idris code"
  '((emacs "24")
    (prop-menu "0.1")
    (cl-lib "0.5"))
  :commit "48f09ba53cb031ee90efe4637b041dbe84ddf513" :keywords
  '("languages")
  :url "https://github.com/idris-hackers/idris-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
