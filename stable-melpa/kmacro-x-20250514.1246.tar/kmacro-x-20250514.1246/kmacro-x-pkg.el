;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kmacro-x" "20250514.1246"
  "Keyboard macro helpers and extensions."
  '((emacs "29.1"))
  :url "https://github.com/vifon/kmacro-x.el"
  :commit "6250d4d6e49b8708ac640e3d9b5ab4c072993067"
  :revdesc "6250d4d6e49b"
  :keywords '("convenience"))
