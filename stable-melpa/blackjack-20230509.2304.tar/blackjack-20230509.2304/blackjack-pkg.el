(define-package "blackjack" "20230509.2304" "The game of Blackjack"
  '((emacs "26.2"))
  :commit "12ec927458d2d3f278e04d3ad40c1df75618e21f" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
