;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20261011.758"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "1f0957c3fec78506c9b4b49fbad1d82f7a4cc4e7"
  :revdesc "1f0957c3fec7"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
