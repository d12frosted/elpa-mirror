(define-package "geiser-guile" "20221101.1625" "Guile and Geiser talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (geiser "0.26.1"))
  :commit "56fcdb0b73c1388b7695f4e2d3d3736ca4453e73" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
