(define-package "srfi" "20221103.2201" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "f4423cfdd7b9d1af40addd3af9aca520eb286430" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
