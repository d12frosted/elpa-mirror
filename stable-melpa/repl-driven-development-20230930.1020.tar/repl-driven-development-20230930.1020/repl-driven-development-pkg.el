(define-package "repl-driven-development" "20230930.1020" "Send arbitrary code to a REPL in the background"
  '((s "1.12.0")
    (dash "2.16.0")
    (eros "0.1.0")
    (bind-key "2.4.1")
    (emacs "27.1")
    (f "0.20.0")
    (devdocs "0.5")
    (pulsar "1.0.1"))
  :commit "d25f7ff5e258be6146f2fe09e6007960afabcafa" :authors
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainer
  '("Musa Al-hassy" . "alhassy@gmail.com")
  :keywords
  '("repl-driven-development" "rdd" "repl" "lisp" "java" "python" "ruby" "programming" "convenience")
  :url "http://alhassy.com/repl-driven-development")
;; Local Variables:
;; no-byte-compile: t
;; End:
