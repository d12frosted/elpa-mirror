(define-package "org-mpv-notes" "20230709.628" "Take notes in org mode while watching videos in mpv"
  '((emacs "27.1")
    (mpv "0.2.0"))
  :commit "e068fad0411a9213233059e3fbb39be2bfb941f4" :authors
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainers
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainer
  '("Bibek Panthi" . "bpanthi977@gmail.com")
  :url "https://github.com/bpanthi977/org-mpv-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
