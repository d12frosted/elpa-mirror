(define-package "dired-hist" "20240320.518" "Traverse Dired buffer's history: back, forward"
  '((emacs "27.1"))
  :commit "b49320be3c67e4517e44e8e6e88f3e2015f6b4ea" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
    ("Anoncheg1"))
  :maintainers
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience" "dired" "history")
  :url "https://github.com/Anoncheg1/dired-hist")
;; Local Variables:
;; no-byte-compile: t
;; End:
