(define-package "justl" "20230611.704" "Major mode for driving just files"
  '((transient "0.1.0")
    (emacs "25.3")
    (s "1.2.0")
    (f "0.20.0"))
  :commit "a85d81d44f1f92df13dbe6fa2a259e87453731f0" :authors
  '(("Sibi Prabakaran"))
  :maintainers
  '(("Sibi Prabakaran"))
  :maintainer
  '("Sibi Prabakaran")
  :keywords
  '("just" "justfile" "tools" "processes")
  :url "https://github.com/psibi/justl.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
