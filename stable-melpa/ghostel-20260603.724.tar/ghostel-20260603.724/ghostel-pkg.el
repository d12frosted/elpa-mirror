;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260603.724"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "864ee4e327ba9a3e8206f6bde59c28b7248d9104"
  :revdesc "864ee4e327ba"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
