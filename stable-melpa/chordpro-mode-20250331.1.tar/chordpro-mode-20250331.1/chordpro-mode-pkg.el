;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chordpro-mode" "20250331.1"
  "Major mode for ChordPro lead sheet file format."
  '((emacs  "29.1")
    (compat "29.1.4.1"))
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/"
  :commit "daa972d0847811ffec0cd7c00c5df7859f8cc148"
  :revdesc "daa972d08478"
  :keywords '("convenience")
  :authors '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers '(("Howard Ding" . "hading2@gmail.com")))
