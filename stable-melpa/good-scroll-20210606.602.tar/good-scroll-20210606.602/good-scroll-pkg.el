(define-package "good-scroll" "20210606.602" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "5ad9510857535317ec3c1ceab521ba5b07bf326e" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
