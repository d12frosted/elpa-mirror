(define-package "asyncloop" "20231113.1119" "Non-blocking series of functions"
  '((emacs "28")
    (named-timer "0.1"))
  :commit "de4d40a58bfaa4b9eb6ce6feb878d97a7ff5d696" :authors
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainers
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainer
  '(nil . "<meedstrom91@gmail.com>")
  :keywords
  '("tools")
  :url "https://github.com/meedstrom/asyncloop")
;; Local Variables:
;; no-byte-compile: t
;; End:
