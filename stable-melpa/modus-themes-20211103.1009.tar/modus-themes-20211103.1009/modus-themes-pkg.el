(define-package "modus-themes" "20211103.1009" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "58fa83706ba7d1eaa00d05b6dbbd11eea177365b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
