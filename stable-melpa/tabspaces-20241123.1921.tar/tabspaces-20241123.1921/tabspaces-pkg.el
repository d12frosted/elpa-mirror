;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20241123.1921"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://github.com/mclear-tools/tabspaces"
  :commit "43cbefa73b00c15ef0a0ba34a87d3ab97d8dd5f3"
  :revdesc "43cbefa73b00"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
