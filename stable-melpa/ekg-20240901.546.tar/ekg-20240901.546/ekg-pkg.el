(define-package "ekg" "20240901.546" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.17.0"))
  :commit "92432c150144b597c9d865e0a64a72f628f4e05f" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
