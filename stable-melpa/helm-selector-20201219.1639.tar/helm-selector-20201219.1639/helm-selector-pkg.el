(define-package "helm-selector" "20201219.1639" "Helm buffer selector"
  '((emacs "26.1")
    (helm "3"))
  :commit "6a943b9952c749c2a83c284cfcf5b56f5f6622ad" :authors
  (("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainer
  ("Pierre Neidhardt" . "mail@ambrevar.xyz")
  :url "https://github.com/emacs-helm/helm-selector")
;; Local Variables:
;; no-byte-compile: t
;; End:
