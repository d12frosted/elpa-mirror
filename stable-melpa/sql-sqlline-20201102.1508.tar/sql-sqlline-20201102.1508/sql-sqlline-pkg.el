(define-package "sql-sqlline" "20201102.1508" "Adds SQLLine support to SQLi mode"
  '((emacs "24.4"))
  :commit "189c55261ecf0d7990edf7d1bb89776225e9092b" :authors
  '(("Matteo Redaelli" . "matteo.redaelli@gmail.com"))
  :maintainers
  '(("Matteo Redaelli" . "matteo.redaelli@gmail.com"))
  :maintainer
  '("Matteo Redaelli" . "matteo.redaelli@gmail.com")
  :keywords
  '("languages")
  :url "https://gitlab.com/matteoredaelli/sql-sqlline")
;; Local Variables:
;; no-byte-compile: t
;; End:
