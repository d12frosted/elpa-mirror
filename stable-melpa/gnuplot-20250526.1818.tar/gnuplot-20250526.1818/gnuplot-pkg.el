;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250526.1818"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "821964c068079ecae39c065ec5454d0f77e74487"
  :revdesc "821964c06807"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
