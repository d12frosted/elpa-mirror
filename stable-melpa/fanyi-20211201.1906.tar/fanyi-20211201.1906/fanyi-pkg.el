(define-package "fanyi" "20211201.1906" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "8dec7b64a7a7b7a9a2e59bc3f4cb370532cc8d92" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
