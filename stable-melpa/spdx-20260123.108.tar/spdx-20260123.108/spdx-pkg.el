;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260123.108"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "b2b9192614a86b77ca0126c4d8557b2e29c172cf"
  :revdesc "b2b9192614a8"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
