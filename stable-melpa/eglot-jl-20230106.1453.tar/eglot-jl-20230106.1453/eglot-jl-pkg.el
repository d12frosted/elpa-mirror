(define-package "eglot-jl" "20230106.1453" "Julia support for eglot"
  '((emacs "25.1")
    (eglot "1.4")
    (julia-mode "0.3"))
  :commit "950d9eb2b57bac3eac06676422f328ee1d432897" :authors
  '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz"))
  :maintainer
  '("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/non-Jedi/eglot-jl")
;; Local Variables:
;; no-byte-compile: t
;; End:
