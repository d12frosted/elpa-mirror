(define-package "danneskjold-theme" "20210929.1514" "Beautiful high-contrast Emacs theme." 'nil :commit "a9e47c5c6ee241e2061846777333730b26ffa0f0" :authors
  '(("Dmitry Akatov" . "akatovda@yandex.com"))
  :maintainer
  '("Dmitry Akatov" . "akatovda@yandex.com")
  :url "https://github.com/rails-to-cosmos/")
;; Local Variables:
;; no-byte-compile: t
;; End:
