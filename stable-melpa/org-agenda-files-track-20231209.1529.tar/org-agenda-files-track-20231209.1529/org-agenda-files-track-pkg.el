;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-agenda-files-track" "20231209.1529"
  "Fine-track `org-agenda-files' to speed-up `org-agenda'."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~ngraves/org-agenda-files-track"
  :commit "c0f5f7746ec023a32ba106ec24812eca5cbe15df"
  :revdesc "c0f5f7746ec0"
  :keywords '("data" "files" "tools")
  :authors '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainers '(("Nicolas Graves" . "ngraves@ngraves.fr")))
