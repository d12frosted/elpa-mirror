(define-package "verb" "20201116.2114" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "b260b39cc86690c21bec4b540a8e727d7baa6daa" :keywords
  ("tools")
  :authors
  (("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  ("Federico Tedin" . "federicotedin@gmail.com")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
