;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260205.323"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "2f9863265d69285f97e6cebca3cefd076e697827"
  :revdesc "2f9863265d69"
  :keywords '("convenience"))
