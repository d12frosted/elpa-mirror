;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ariadne" "20131117.1711"
  "Ariadne plugin for Emacs."
  '((bert "0.1"))
  :url "https://github.com/manzyuk/ariadne-el"
  :commit "6fe401c7f996bcbc2f685e7971324c6f5e5eaf15"
  :revdesc "6fe401c7f996"
  :keywords '("comm" "convenience" "processes")
  :authors '(("Oleksandr Manzyuk" . "manzyuk@gmail.com"))
  :maintainers '(("Oleksandr Manzyuk" . "manzyuk@gmail.com")))
