;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250307.1038"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "2b52e884ccc6aeb71250741b844991471c552536"
  :revdesc "2b52e884ccc6"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
