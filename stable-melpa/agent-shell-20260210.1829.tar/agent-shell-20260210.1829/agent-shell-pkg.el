;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260210.1829"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2e586f7039610425a709706a4c857a88cb328b96"
  :revdesc "2e586f703961")
