(define-package "boon" "20230720.1235" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "75b30ef8703efb9ffba12e92685ad82e3ab55962")
;; Local Variables:
;; no-byte-compile: t
;; End:
