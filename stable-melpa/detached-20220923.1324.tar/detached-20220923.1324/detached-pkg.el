(define-package "detached" "20220923.1324" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "69fca1eaa74391838130b1d87286612c3291b42c" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
