;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260501.1852"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "010ed945271bbf98e2bd46cd419ab41878cc279f"
  :revdesc "010ed945271b"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
