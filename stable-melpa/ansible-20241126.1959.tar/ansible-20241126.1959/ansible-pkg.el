;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ansible" "20241126.1959"
  "Ansible minor mode."
  '((s     "1.9.0")
    (f     "0.16.2")
    (emacs "25.1"))
  :url "https://gitlab.com/emacs-ansible/emacs-ansible"
  :commit "b78ab4261b34d16eca36e8851ef1c399206d25c7"
  :revdesc "b78ab4261b34"
  :authors '((nil . "k1lowxb[at]gmail[dot]com")
             (nil . "k1low[at]101000lab[dot]org"))
  :maintainers '((nil . "k1lowxb[at]gmail[dot]com")
                 (nil . "k1low[at]101000lab[dot]org")))
