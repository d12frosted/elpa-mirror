;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-pseudo-daemon" "20240922.2024"
  "Daemon mode that plays nice with OSX."
  '((mac-pseudo-daemon "2.2"))
  :url "https://github.com/DarwinAwardWinner/mac-pseudo-daemon"
  :commit "c2326fe5baf53790d51386a75f09a114e0678c5e"
  :revdesc "c2326fe5baf5"
  :keywords '("convenience" "osx"))
