(define-package "consult" "20230127.1544" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "324450e795931d874fc8be1f47e3885ed662b1db" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
