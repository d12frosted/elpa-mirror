;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dag-draw" "20251217.1230"
  "Draw directed graphs using the GKNV algorithm."
  '((emacs "26.1")
    (dash  "2.19.1")
    (ht    "2.3"))
  :url "https://codeberg.org/trevoke/dag-draw.el"
  :commit "9d0aa4e5471206fb2b6d46cd6254f5c42c44d849"
  :revdesc "9d0aa4e54712"
  :keywords '("tools" "extensions"))
