(define-package "reazon" "20210814.1423" "miniKanren for Emacs"
  '((emacs "26"))
  :commit "03b7f0c2dabbb2e654c396123a7c68d83b62625b" :authors
  '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainer
  '("Nick Drozd" . "nicholasdrozd@gmail.com")
  :keywords
  '("languages" "extensions" "lisp")
  :url "https://github.com/nickdrozd/reazon")
;; Local Variables:
;; no-byte-compile: t
;; End:
