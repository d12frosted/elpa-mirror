(define-package "meow" "20220303.656" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "aa4aa68f4f7c188e13f072f239920d48c7e0dd86" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
