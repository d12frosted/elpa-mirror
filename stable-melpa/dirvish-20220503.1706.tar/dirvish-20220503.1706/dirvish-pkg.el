(define-package "dirvish" "20220503.1706" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a03f651791f50f1e49afb1bc4282af25bfec747e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
