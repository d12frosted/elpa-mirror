(define-package "hass" "20220813.1717" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3"))
  :commit "c6d9bd2e29fc2c4f37c0c72f3d136e43f34addbc" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
