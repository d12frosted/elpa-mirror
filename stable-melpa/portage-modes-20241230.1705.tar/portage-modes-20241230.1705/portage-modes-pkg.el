;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "portage-modes" "20241230.1705"
  "Major modes for editing Portage config files."
  ()
  :url "https://github.com/OpenSauce04/portage-modes"
  :commit "0f792c1a9ceabc6a2b8f80cfc0da951687948095"
  :revdesc "0f792c1a9cea"
  :authors '(("OpenSauce" . "opensauce04@gmail.com"))
  :maintainers '(("OpenSauce" . "opensauce04@gmail.com")))
