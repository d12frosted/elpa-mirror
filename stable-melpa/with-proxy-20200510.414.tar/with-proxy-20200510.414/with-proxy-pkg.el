;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-proxy" "20200510.414"
  "Evaluate expressions with proxy."
  '((emacs "24.4"))
  :url "https://github.com/twlz0ne/with-proxy.el"
  :commit "93b1ed2f3060f305009fa71f4fb5bb10173a10e3"
  :revdesc "93b1ed2f3060"
  :keywords '("comm")
  :authors '(("Gong Qijian" . "gongqijian@gmail.com"))
  :maintainers '(("Gong Qijian" . "gongqijian@gmail.com")))
