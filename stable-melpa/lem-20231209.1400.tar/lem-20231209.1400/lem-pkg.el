(define-package "lem" "20231209.1400" "A basic lemmy client"
  '((emacs "29.1")
    (fedi "0.1")
    (markdown-mode "2.5"))
  :commit "24221b3d66082d2ad1f259d17065141175472044" :authors
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainers
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainer
  '("martian hiatus <martianhiatus [a t] riseup [d o t] net>")
  :keywords
  '("multimedia" "comm" "web" "fediverse")
  :url "https://codeberg.org/martianh/lem.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
