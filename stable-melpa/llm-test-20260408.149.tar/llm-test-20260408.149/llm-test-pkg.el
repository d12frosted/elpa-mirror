;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260408.149"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "93a15380870c1edd241e48b3e7ee70de0c1c0417"
  :revdesc "93a15380870c"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
