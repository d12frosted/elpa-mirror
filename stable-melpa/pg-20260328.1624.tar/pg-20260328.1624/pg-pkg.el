;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20260328.1624"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "67f50311947a54913d91852ebd6880dbe68930bc"
  :revdesc "67f50311947a"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
