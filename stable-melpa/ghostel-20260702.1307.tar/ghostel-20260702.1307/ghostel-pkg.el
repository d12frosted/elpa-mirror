;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260702.1307"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "12f9ea153a005ebfe9f08fc04c266fb4c37c1099"
  :revdesc "12f9ea153a00"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
