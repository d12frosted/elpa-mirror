;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20241201.2012"
  "Fuzzy completion style using `flx'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "2cb03872dbac37abf1b7a4253393fbf453cd4916"
  :revdesc "2cb03872dbac"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
