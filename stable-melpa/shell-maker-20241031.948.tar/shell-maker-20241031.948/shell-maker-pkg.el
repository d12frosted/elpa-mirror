;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20241031.948"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "feb2c85d75a5cf3877aa351744390f16909a67ee"
  :revdesc "feb2c85d75a5")
