(define-package "csharp-mode" "20220815.935" "C# mode derived mode"
  '((emacs "26.1"))
  :commit "18fea21c59597a1b51728fc5670400a32b2adc1f" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
