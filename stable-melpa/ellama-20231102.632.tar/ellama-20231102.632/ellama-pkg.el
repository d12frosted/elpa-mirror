(define-package "ellama" "20231102.632" "Tool for interacting with LLMs"
  '((emacs "28.1")
    (llm "0.5.1")
    (spinner "1.7.4"))
  :commit "2700be1cf92539ab293bf19dca3eaac757f6b7b5" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
