(define-package "racket-mode" "20210211.1758" "Racket editing, REPL, and more"
  '((emacs "25.1")
    (faceup "0.0.2")
    (pos-tip "20191127.1028"))
  :commit "61181447c56f28ebbb6138b7a716d50aac70412d" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
