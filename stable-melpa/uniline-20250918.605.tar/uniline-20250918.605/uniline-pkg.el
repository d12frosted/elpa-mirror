;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250918.605"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "5fc27d0196630a21e5159d8c3d4d7783f067c214"
  :revdesc "5fc27d019663"
  :keywords '("convenience" "text"))
