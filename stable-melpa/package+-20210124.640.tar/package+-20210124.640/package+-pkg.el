(define-package "package+" "20210124.640" "Extensions for the package library."
  '((emacs "24.3"))
  :commit "079da78f3be8364e964f5861a5f433ad61b6f654" :authors
  '(("Ryan Davis" . "ryand-ruby@zenspider.com"))
  :maintainer
  '("Ryan Davis" . "ryand-ruby@zenspider.com")
  :keywords
  '("extensions" "tools")
  :url "https://github.com/zenspider/package")
;; Local Variables:
;; no-byte-compile: t
;; End:
