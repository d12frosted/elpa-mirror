;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260210.142"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "7a60e52ed8e76858176023cf8b65fde084f206fb"
  :revdesc "7a60e52ed8e7"
  :keywords '("convenience"))
