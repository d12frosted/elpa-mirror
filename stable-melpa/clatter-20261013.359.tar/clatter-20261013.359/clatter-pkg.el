;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20261013.359"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "e596c27778d57d76ca74a328501e1038ed56b7bd"
  :revdesc "e596c27778d5"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
