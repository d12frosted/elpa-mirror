;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-sly" "20170728.1027"
  "An auto-complete source using sly completions."
  '((sly           "1.0.0-alpha")
    (auto-complete "1.4")
    (cl-lib        "0.5"))
  :url "https://github.com/qoocku/ac-sly"
  :commit "bf69c687c4ecf1994349d20c182e9b567399912e"
  :revdesc "bf69c687c4ec"
  :authors '(("Damian T. Dobroczy\\'nski" . "qoocku@gmail.com"))
  :maintainers '(("Damian T. Dobroczy\\'nski" . "qoocku@gmail.com")))
