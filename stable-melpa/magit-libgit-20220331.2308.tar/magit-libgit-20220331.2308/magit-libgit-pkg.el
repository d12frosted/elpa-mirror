(define-package "magit-libgit" "20220331.2308" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "6a5c79fd1b19c5f64b2fdfc04112359954d06c1d" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
