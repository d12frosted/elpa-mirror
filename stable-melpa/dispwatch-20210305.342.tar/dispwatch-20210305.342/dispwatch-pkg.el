;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dispwatch" "20210305.342"
  "Watch displays for configuration changes."
  '((emacs "24.4"))
  :url "https://github.com/mnp/dispwatch"
  :commit "03abbac89a9f625aaa1a808dd49ae4906f466421"
  :revdesc "03abbac89a9f"
  :keywords '("frames")
  :authors '(("Mitchell Perilstein" . "mitchell.perilstein@gmail.com"))
  :maintainers '(("Mitchell Perilstein" . "mitchell.perilstein@gmail.com")))
