(define-package "dirvish" "20220319.1448" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "6f7de657dc1e7e1c533fb93c03dd38a34b34fad3" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
