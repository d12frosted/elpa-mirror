;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260429.48"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "8685e7104c4d1cb6013160205487a56c10ac3197"
  :revdesc "8685e7104c4d"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
