;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20250402.1212"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "bb0bdc2f8ffb82e18d22f4a4bcab954af3a5e91f"
  :revdesc "bb0bdc2f8ffb"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
