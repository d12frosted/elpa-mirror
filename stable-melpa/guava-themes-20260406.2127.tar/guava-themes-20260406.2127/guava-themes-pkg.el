;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260406.2127"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "d7e6aa8dac61dedace02bf9a3b3e23cc4ae49461"
  :revdesc "d7e6aa8dac61"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
