;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occidental-theme" "20130312.1958"
  "Custom theme for faces based on Adwaita."
  ()
  :url "https://github.com/olcai/occidental-theme"
  :commit "fd2db7256d4f78c43d99c3cddb1c39106d479816"
  :revdesc "fd2db7256d4f"
  :authors '(("William Stevenson" . "yhvh2000@gmail.com")
             ("Erik Timan" . "dev@timan.info"))
  :maintainers '(("William Stevenson" . "yhvh2000@gmail.com")
                 ("Erik Timan" . "dev@timan.info")))
