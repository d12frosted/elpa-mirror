(define-package "pygn-mode" "20210828.1848" "Major-mode for chess PGN files, powered by Python"
  '((emacs "26.1")
    (tree-sitter "0.15.1")
    (tree-sitter-langs "0.10.1")
    (uci-mode "0.5.4")
    (nav-flash "1.0.0")
    (ivy "0.10.0"))
  :commit "bbc532a85b7a5555cbf1f0b4cd91214cf9fa6751" :authors
  '(("Dodge Coates and Roland Walker"))
  :maintainer
  '("Dodge Coates and Roland Walker")
  :keywords
  '("data" "games" "chess")
  :url "https://github.com/dwcoates/pygn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
