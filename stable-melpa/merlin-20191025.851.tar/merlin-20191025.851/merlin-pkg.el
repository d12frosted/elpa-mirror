(define-package "merlin" "20191025.851" "Mode for Merlin, an assistant for OCaml." 'nil :commit "47ebe5e6186e70584ef5f92c9191bd7bbcb6c1da" :authors
  (("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  ("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  ("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
