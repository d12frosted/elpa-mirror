(define-package "merlin" "20191025.851" "Mode for Merlin, an assistant for OCaml." 'nil :commit "28193d5ff238be44556e0344c1c0207b77c2bb55" :keywords
  ("ocaml" "languages")
  :authors
  (("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  ("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
