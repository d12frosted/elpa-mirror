(define-package "merlin" "20191025.851" "Mode for Merlin, an assistant for OCaml." 'nil :commit "a1a6e02756426f58a885846cbe56c4704b2a79e1" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
