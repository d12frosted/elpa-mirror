(define-package "merlin" "20191025.851" "Mode for Merlin, an assistant for OCaml." 'nil :commit "3dd8eec9cb1f66811e8b3db3e492a2f4b5ea51bc" :keywords
  ("ocaml" "languages")
  :authors
  (("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  ("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
