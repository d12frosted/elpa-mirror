;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asciidoc-mode" "20260605.1209"
  "Major mode for AsciiDoc markup."
  '((emacs "30.1"))
  :url "https://github.com/bbatsov/asciidoc-mode"
  :commit "342b1833ad0f3d1654638d3d6cfd6c4bf3aee468"
  :revdesc "342b1833ad0f"
  :keywords '("text" "asciidoc" "languages" "tree-sitter")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
