;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "20260403.607"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "266b1ac196c47cfc67ba71a05f125f5890a43391"
  :revdesc "266b1ac196c4"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
