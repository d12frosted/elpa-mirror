;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "intellij-theme" "20260914.935"
  "Inspired by IntelliJ's default theme."
  ()
  :url "https://github.com/fommil/intellij-theme.el"
  :commit "c1db433761b7a63ca1efed956b05c2c1366932ae"
  :revdesc "c1db433761b7"
  :keywords '("faces")
  :authors '(("Vladimir Polushin" . "vovapolu@gmail.com"))
  :maintainers '(("Vladimir Polushin" . "vovapolu@gmail.com")))
