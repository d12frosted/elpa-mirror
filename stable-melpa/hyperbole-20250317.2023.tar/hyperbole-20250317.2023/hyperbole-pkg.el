;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250317.2023"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ec9104624fe774b50aa25efeb576152cfc38133c"
  :revdesc "ec9104624fe7"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
