(define-package "chronometrist-key-values" "20220326.1439" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "3f52469f31f0bc23dd63d0b3c29bc2040dfcd98a" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
