(define-package "hl-prog-extra" "20220131.358" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "8275de778fa273f63a6254a17f80c83c6780cac2" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
