;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260325.2224"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "0129d0a100ebaefcf89b25b67be1b2311a309c28"
  :revdesc "0129d0a100eb"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
