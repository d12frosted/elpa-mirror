;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250313.158"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "10e77396bc78e05c922b04a344818bc8ab72d665"
  :revdesc "10e77396bc78"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
