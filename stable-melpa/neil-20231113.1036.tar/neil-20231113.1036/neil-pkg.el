(define-package "neil" "20231113.1036" "companion for Babashka Neil"
  '((emacs "27.1"))
  :commit "076fb8339e4ea935c1a530a740b6eb6257c55962" :authors
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainer
  '("Ag Ibragimov" . "agzam.ibragimov@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/babashka/neil")
;; Local Variables:
;; no-byte-compile: t
;; End:
