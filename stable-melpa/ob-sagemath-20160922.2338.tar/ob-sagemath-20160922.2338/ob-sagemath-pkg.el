(define-package "ob-sagemath" "20160922.2338" "org-babel functions for SageMath evaluation"
  '((sage-shell-mode "0.0.8")
    (s "1.8.0")
    (emacs "24"))
  :commit "450d510a5eb1fd644d0037e9f02271ca33639fb0" :authors
  '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainer
  '("Sho Takemori" . "stakemorii@gmail.com")
  :keywords
  '("sagemath" "org-babel")
  :url "https://github.com/stakemori/ob-sagemath")
;; Local Variables:
;; no-byte-compile: t
;; End:
