(define-package "meow" "20220106.1515" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "643aa5f2e0c6ab9ccead137997926fce7fa4a168" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
