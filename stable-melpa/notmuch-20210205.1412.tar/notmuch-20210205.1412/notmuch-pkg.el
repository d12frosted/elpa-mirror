(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "1459217e17e94277495c5c644b5a4ca1651c9452" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
