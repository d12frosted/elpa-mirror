(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "5248f55d5f11c6ed6c2344b2ed13e6ff16fc6dde" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
