(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "97fadd0645e908ff8322577a983dc710bfda33d6" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
