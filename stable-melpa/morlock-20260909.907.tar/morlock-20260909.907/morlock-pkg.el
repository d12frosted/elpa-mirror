;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morlock" "20260909.907"
  "More font-lock keywords for elisp."
  '((emacs "29.1"))
  :url "https://github.com/tarsius/morlock"
  :commit "390e9e01df7c21c1d25a1f55f0f29824cb27cbb1"
  :revdesc "390e9e01df7c"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev")))
