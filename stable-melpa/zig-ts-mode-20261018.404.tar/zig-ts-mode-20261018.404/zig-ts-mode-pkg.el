;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-ts-mode" "20261018.404"
  "Major mode for Zig code."
  '((emacs "30.1"))
  :url "https://codeberg.org/meow_king/zig-ts-mode"
  :commit "4c03d52bd1e7f1b5601c638bff109b6e763b1cab"
  :revdesc "4c03d52bd1e7"
  :keywords '("zig" "languages" "tree-sitter")
  :authors '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers '(("meowking" . "mr.meowking@tutamail.com")))
