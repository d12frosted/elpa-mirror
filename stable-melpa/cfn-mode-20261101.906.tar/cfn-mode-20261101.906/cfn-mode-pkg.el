;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20261101.906"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "c66232bbbcd3277c83ddd62542f00ae9f4af9f37"
  :revdesc "c66232bbbcd3"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
