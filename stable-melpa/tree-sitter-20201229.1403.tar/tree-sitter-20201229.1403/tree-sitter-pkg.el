(define-package "tree-sitter" "20201229.1403" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.13.0"))
  :commit "076865a6c879840ab61e0aa7b336a2e3e1f97cd4" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
