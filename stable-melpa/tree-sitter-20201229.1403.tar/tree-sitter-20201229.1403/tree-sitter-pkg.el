(define-package "tree-sitter" "20201229.1403" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.13.0"))
  :commit "a7036676de3ba35b93346f5325ed568240c1ef58" :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
