(define-package "epkg" "20220331.2254" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "8722c0ff571e737f65a1d8275a8a3cd4f7c068be" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
