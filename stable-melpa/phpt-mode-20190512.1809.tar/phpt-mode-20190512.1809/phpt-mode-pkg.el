;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpt-mode" "20190512.1809"
  "Major mode for editing PHPT test code."
  '((emacs    "25")
    (polymode "0.1.5")
    (php-mode "1.21.2"))
  :url "https://github.com/emacs-php/phpt-mode"
  :commit "deb386f1a81003074c476f15e1975d445ff6df01"
  :revdesc "deb386f1a810"
  :keywords '("languages" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
