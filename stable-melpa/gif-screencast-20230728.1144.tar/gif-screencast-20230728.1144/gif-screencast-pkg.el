;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gif-screencast" "20230728.1144"
  "One-frame-per-action GIF recording."
  '((emacs "25.1"))
  :url "https://gitlab.com/ambrevar/emacs-gif-screencast"
  :commit "6798656d3d3107d16e30cc26bc3928b00e50c1ca"
  :revdesc "6798656d3d31"
  :keywords '("multimedia" "screencast")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
