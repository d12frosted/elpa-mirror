(define-package "halloweenie-theme" "20231002.1321" "Dark and spooky Halloween color theme"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "1a7b91541b05df7ace7d1ceb445aa441876154bd" :authors
  '(("Colin Okay" . "colin@cicadas.surf"))
  :maintainers
  '(("Colin Okay" . "colin@cicadas.surf"))
  :maintainer
  '("Colin Okay" . "colin@cicadas.surf")
  :keywords
  '("faces" "theme" "halloween" "pumpkin")
  :url "https://cicadas.surf/cgit/halloweenie-theme.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
