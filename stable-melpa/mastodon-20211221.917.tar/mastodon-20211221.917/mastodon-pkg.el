(define-package "mastodon" "20211221.917" "Client for Mastodon"
  '((emacs "24.4"))
  :commit "d4c0d2a2a3013136f5b1fea40ae1e7022f461dd9" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Johnson Denen" . "johnson.denen@gmail.com")
  :url "https://github.com/jdenen/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
