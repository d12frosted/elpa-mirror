(define-package "modus-themes" "20210226.853" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "85bd448b2a779afe09a70e27557239b87c7efa82" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
