(define-package "consult" "20210804.743" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "384156f08fdd5a266141e70e57c2635d1258678a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
