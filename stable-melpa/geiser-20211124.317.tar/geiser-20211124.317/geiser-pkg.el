(define-package "geiser" "20211124.317" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "64e09725c75a2ca4a366c018b107d8bb0e00862e" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
