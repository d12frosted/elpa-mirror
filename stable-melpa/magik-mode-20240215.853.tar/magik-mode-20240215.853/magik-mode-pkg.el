(define-package "magik-mode" "20240215.853" "Emacs major mode for Smallworld Magik files"
  '((emacs "24.4")
    (compat "28.1"))
  :commit "8dfd4409b555ab57a46966aac07a06a144704b06" :keywords
  '("languages")
  :url "https://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
