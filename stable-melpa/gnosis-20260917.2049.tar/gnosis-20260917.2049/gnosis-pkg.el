;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260917.2049"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "04cde304b7a94ef221e73ad256bf5a81e2415ba2"
  :revdesc "04cde304b7a9"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
