;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261026.1802"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "42de3eb31ef65a96c3c4d846ac5eeb5636c0438d"
  :revdesc "42de3eb31ef6"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
