;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-ring" "20251004.347"
  "Rings and tori for buffer navigation."
  '((emacs    "25.1")
    (dynaring "0.3"))
  :url "https://github.com/countvajhula/buffer-ring"
  :commit "3d7ee2020aff07506e16220f86b6521af814c282"
  :revdesc "3d7ee2020aff"
  :authors '(("Mike Mattie" . "codermattie@gmail.com")
             ("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
