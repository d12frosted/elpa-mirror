;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-toggle" "20260430.2216"
  "Toggle Evil and God Mode."
  '((emacs    "28.1")
    (evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/jam1015/evil-god-toggle"
  :commit "45dcb7390060f74fbafc9818ae428b5cebfd5f15"
  :revdesc "45dcb7390060"
  :keywords '("convenience" "emulation" "evil" "god-mode")
  :authors '(("Jordan Mandel" . "jordan.mandel@live.com"))
  :maintainers '(("Jordan Mandel" . "jordan.mandel@live.com")))
