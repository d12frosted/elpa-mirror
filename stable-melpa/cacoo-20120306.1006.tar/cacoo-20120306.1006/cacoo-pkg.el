(define-package "cacoo" "20120306.1006" "Minor mode for Cacoo : http://cacoo.com"
  '((concurrent "0.3.1"))
  :commit "c2e6a8830144810cd4e51de3646cb8200bcebbc6" :authors
  '(("SAKURAI Masashi <m.sakurai atmark kiwanami.net>"))
  :maintainer
  '("SAKURAI Masashi <m.sakurai atmark kiwanami.net>")
  :keywords
  '("convenience" "diagram")
  :url "https://github.com/kiwanami/emacs-cacoo/")
;; Local Variables:
;; no-byte-compile: t
;; End:
