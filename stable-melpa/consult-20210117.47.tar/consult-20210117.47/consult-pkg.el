(define-package "consult" "20210117.47" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "4ea4991812b62d5664ab75098688438fedf7215f" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
