(define-package "mistty" "20231004.2049" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "5a607065fa52e97c53e40dca74b002beeae52d59" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
