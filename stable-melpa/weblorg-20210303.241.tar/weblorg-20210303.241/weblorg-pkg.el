(define-package "weblorg" "20210303.241" "Static Site Generator for org-mode"
  '((templatel "0.1.4")
    (emacs "26.1"))
  :commit "3089aaffb8045ecfb1cd8f61d279159c4aa66ae5" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
