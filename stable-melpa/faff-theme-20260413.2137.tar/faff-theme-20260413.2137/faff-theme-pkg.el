;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20260413.2137"
  "Light cornsilk theme with warm, earthy colors."
  '((emacs        "28.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "1a6ee167627a4c623f157f3afb5ec12d368889af"
  :revdesc "1a6ee167627a"
  :keywords '("faces" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
