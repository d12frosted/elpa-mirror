;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261029.1255"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "d4c51480a600c9882ebdbdc5322c4bcac9e25a69"
  :revdesc "d4c51480a600"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
