;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20260209.2249"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "56b48a638ddec67fe6b4ed5808320df49f053aed"
  :revdesc "56b48a638dde"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
