;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260218.1003"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "273c0f93958c1ffa85e396717b504903eda36bce"
  :revdesc "273c0f93958c"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
