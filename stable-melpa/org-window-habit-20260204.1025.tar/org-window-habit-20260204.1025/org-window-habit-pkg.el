;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20260204.1025"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "4d23ef0994770b7d233e11dca9bbf1b1a5479c45"
  :revdesc "4d23ef099477"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
