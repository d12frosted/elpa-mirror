(define-package "modus-themes" "20230103.25" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "399d3eaa74e72aa2f9d1f60bf216393ef01d44ae" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
