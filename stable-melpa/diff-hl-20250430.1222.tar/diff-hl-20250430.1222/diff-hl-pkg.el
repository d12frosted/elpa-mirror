;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20250430.1222"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "aa667ac58ab9f7448cb4278d07c6abea701d6ee0"
  :revdesc "aa667ac58ab9"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
