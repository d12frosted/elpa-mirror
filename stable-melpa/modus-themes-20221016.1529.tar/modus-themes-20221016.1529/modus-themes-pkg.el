(define-package "modus-themes" "20221016.1529" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "0260109d158af525a9df3cd33b1efe1ec251bd49" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
