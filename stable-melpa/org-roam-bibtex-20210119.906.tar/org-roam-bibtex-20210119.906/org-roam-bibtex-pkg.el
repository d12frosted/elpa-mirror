(define-package "org-roam-bibtex" "20210119.906" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "1.2.2")
    (bibtex-completion "2.0.0"))
  :commit "569df3d82a28ce83f301aeb12a5154cfb434aa62" :authors
  '(("Leo Vivier" . "leo.vivier+dev@gmail.com")
    ("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  '("Leo Vivier" . "leo.vivier+dev@gmail.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
