;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260306.2158"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b124bf4c81fd350f6179896f13b3caafd1debc3f"
  :revdesc "b124bf4c81fd"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
