(define-package "evil-tutor-ja" "20160917.132" "Japanese Vimtutor adapted to Evil and wrapped in a major-mode"
  '((evil "1.0.9")
    (evil-tutor "0.1"))
  :commit "06b9ad853a15ce6f2c53c2cf379b9ff358369f2d" :authors
  '(("Kenji Miyazaki" . "kenjizmyzk@gmail.com"))
  :maintainer
  '("Kenji Miyazaki" . "kenjizmyzk@gmail.com")
  :keywords
  '("convenience" "editing" "evil" "japanese")
  :url "https://github.com/kenjimyzk/evil-tutor-ja")
;; Local Variables:
;; no-byte-compile: t
;; End:
