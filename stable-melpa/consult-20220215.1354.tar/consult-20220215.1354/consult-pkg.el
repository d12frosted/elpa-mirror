(define-package "consult" "20220215.1354" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "2db402d74f8ede75b84ac135af3121cad24827f6" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
