(define-package "notmuch" "20210830.51" "run notmuch within emacs" 'nil :commit "717e3dcdc3e55d72c8e4a1948708c34170dbf926" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
