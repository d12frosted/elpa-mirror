(define-package "lambdapi-mode" "20201230.859" "A major mode for editing Lambdapi source code"
  '((emacs "26.1")
    (eglot "1.5")
    (math-symbol-lists "1.2.1")
    (highlight "20190710.1527"))
  :commit "cec34d420d186f55b4c59f525561a62369c24031" :authors
  '(("Rodolphe Lepigre, Gabriel Hondet, Ashish Barnawal"))
  :maintainer
  '("Deducteam" . "dedukti-dev@inria.fr")
  :keywords
  '("languages")
  :url "https://github.com/Deducteam/lambdapi")
;; Local Variables:
;; no-byte-compile: t
;; End:
