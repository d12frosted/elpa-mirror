(define-package "dircmp" "20141204.1756" "Compare and sync directories." 'nil :commit "558ee0b601c2de9d247612085aafe2926f56a09f" :keywords
  ("unix" "tools")
  :authors
  (("Matt McClure -- http://matthewlmcclure.com"))
  :maintainer
  ("Matt McClure -- http://matthewlmcclure.com")
  :url "https://github.com/matthewlmcclure/dircmp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
