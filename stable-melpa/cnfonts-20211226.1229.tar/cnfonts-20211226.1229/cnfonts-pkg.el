(define-package "cnfonts" "20211226.1229" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "2eea3b433031ae58476617ace7181c9bf9de0053" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
