;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20261107.316"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "282e708c3d15ae5eb3c5f0a59aeda6d6bb67a47a"
  :revdesc "282e708c3d15"
  :keywords '("convenience" "gptel" "llm")
  :authors '(("Kevin Montag" . "https://github.com/kmontag"))
  :maintainers '(("Kevin Montag" . "https://github.com/kmontag")))
