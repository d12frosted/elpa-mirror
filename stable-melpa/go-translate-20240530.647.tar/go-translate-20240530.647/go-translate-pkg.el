(define-package "go-translate" "20240530.647" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "98779135bb14ed77b2ceac653bc301cea66ef6e0" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
