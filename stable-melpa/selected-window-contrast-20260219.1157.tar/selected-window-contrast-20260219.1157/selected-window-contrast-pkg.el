;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260219.1157"
  "Highlight by brightness of text and background."
  '((emacs "25.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "600319fe8a15da2c330dcbb497474b3e760ae890"
  :revdesc "600319fe8a15"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
