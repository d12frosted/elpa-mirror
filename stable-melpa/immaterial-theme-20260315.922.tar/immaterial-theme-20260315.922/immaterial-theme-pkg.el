;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "immaterial-theme" "20260315.922"
  "A family of themes loosely based on material colors."
  '((emacs        "29")
    (modus-themes "5.0.0"))
  :url "https://github.com/petergardfjall/emacs-immaterial-theme"
  :commit "0c8c8f44a76c6171723f7f4111d990b237349a13"
  :revdesc "0c8c8f44a76c"
  :keywords '("themes"))
