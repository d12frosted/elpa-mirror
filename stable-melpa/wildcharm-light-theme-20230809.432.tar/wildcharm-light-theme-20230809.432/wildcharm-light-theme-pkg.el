(define-package "wildcharm-light-theme" "20230809.432" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "9aea75ebe2d3cc2a3b6b9e02f5a910cd4bd25d38" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
