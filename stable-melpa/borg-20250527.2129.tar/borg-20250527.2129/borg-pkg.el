;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20250527.2129"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "27.1")
    (epkg  "4.0.5")
    (magit "4.3.2"))
  :url "https://github.com/emacscollective/borg"
  :commit "746d6cc25f8f42ef07ce911f2252c614cc5ffc77"
  :revdesc "746d6cc25f8f"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
