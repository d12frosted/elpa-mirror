(define-package "eldev" "20220221.2055" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "7be0cb16ce5d9d3139b4ed1724ac6d8292935267" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
