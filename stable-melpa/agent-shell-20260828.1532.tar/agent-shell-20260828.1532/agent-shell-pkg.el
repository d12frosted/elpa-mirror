;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260828.1532"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "cb6471b99623621eb56a2dad5f6f1453050d07ba"
  :revdesc "cb6471b99623")
