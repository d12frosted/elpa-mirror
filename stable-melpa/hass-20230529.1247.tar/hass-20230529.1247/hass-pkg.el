(define-package "hass" "20230529.1247" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3")
    (websocket "1.13"))
  :commit "f79aae0f5bad39ac96fdd5784651347273f2691e" :authors
  '(("Ben Whitley"))
  :maintainers
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
