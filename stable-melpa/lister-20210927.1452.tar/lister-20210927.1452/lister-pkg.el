(define-package "lister" "20210927.1452" "Yet another list printer"
  '((emacs "26.1"))
  :commit "644536a48ea9dcca12a971184e02eeb6352305f2" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
