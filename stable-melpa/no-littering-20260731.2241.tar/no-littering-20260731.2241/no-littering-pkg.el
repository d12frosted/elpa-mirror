;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260731.2241"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "c949f327f417734005203769673e6f925877fa88"
  :revdesc "c949f327f417"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
