;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260614.2015"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "7707386a31a7aac20759fa75307f6d68cf337540"
  :revdesc "7707386a31a7"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
