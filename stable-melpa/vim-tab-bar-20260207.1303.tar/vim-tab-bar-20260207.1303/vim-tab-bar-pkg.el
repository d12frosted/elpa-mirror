;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20260207.1303"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "0a010127d6f1b94deec35f98b63027fec1e9cc2a"
  :revdesc "0a010127d6f1"
  :keywords '("frames"))
