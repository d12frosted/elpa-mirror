(define-package "consult" "20210118.502" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "2fc1f016ad82bfc7610177cb2ca3fdca81c8b2a1" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
