;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-pullrequest" "20170116.616"
  "Create and fetch Github Pull requests with ease."
  '((emacs   "24.4")
    (request "0.2.0")
    (dash    "2.11.0")
    (magit   "2.10.0"))
  :url "https://github.com/jakoblind/github-pullrequest"
  :commit "0dbb4f71db971eec2224e19d000f3b626f401752"
  :revdesc "0dbb4f71db97"
  :keywords '("tools"))
