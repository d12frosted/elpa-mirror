;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260123.1525"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "0f5178bef9fdb9a151331b9de418ba6cbc4b39cb"
  :revdesc "0f5178bef9fd"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
