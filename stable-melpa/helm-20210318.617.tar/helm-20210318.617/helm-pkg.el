(define-package "helm" "20210318.617" "Helm is an Emacs incremental and narrowing framework"
  '((emacs "25.1")
    (async "1.9.4")
    (popup "0.5.3")
    (helm-core "3.7.1"))
  :commit "01592be8dedc2ae7f2b33ae43a38f4916145e0e9" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://github.com/emacs-helm/helm")
;; Local Variables:
;; no-byte-compile: t
;; End:
