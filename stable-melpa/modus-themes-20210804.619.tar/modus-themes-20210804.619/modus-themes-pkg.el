(define-package "modus-themes" "20210804.619" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "39bbc33c55e27c938b3903e5bd99a72f068fc71a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
