;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251107.553"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "4fd8cdfc552e7e1e6a96625a752ab612706b15e3"
  :revdesc "4fd8cdfc552e"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
