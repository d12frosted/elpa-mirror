(define-package "clojure-ts-mode" "20240211.1032" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "b2c79f6b0204e19723c7d045eba50aebb0231ac8" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
