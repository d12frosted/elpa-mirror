;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20261001.1610"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.1")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "cb4225846daaf809ea904b575eb4fe177e9cf71b"
  :revdesc "cb4225846daa"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
