;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260801.2039"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0b3d8a864b9f7d92bc472a47b7510c7b27daeb8a"
  :revdesc "0b3d8a864b9f")
