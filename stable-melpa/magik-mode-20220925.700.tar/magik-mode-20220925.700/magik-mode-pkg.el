(define-package "magik-mode" "20220925.700" "mode for editing Magik + some utils." 'nil :commit "17564feba8dd7adb39b402a743cbacd25d2f20d3" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
