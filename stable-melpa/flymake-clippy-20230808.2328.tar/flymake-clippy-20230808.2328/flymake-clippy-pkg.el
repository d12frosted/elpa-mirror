(define-package "flymake-clippy" "20230808.2328" "Flymake backend for Clippy"
  '((emacs "26.1"))
  :commit "f488c7df2f56635dea0576ea2872c4c94b584a67" :authors
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainers
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainer
  '("Graham Marlow" . "info@mgmarlow.com")
  :keywords
  '("tools")
  :url "https://sr.ht/~mgmarlow/flymake-clippy/")
;; Local Variables:
;; no-byte-compile: t
;; End:
