(define-package "eldoc-box" "20240822.2357" "Display documentation in childframe"
  '((emacs "27.1"))
  :commit "e20d9963da72ce7e9d702c1f493f514f9371d341" :authors
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainer
  '("Yuan Fu" . "casouri@gmail.com")
  :url "https://github.com/casouri/eldoc-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
