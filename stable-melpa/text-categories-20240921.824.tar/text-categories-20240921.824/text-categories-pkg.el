;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "text-categories" "20240921.824"
  "Assign text categories to a buffer for mass deletion."
  '((emacs "26.2")
    (dash  "2.19.1"))
  :url "https://github.com/Dspil/text-categories"
  :commit "ac1a5900c80a967572b80045b0dbc2a1cc3437f2"
  :revdesc "ac1a5900c80a"
  :keywords '("lisp")
  :authors '(("Dionisios Spiliopoulos" . "dennisspiliopoylos@gmail.com"))
  :maintainers '(("Dionisios Spiliopoulos" . "dennisspiliopoylos@gmail.com")))
