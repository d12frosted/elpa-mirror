;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250620.2034"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.16.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "531462f0187900ce5a72d1c525cadc10a1b17fcf"
  :revdesc "531462f01879"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
