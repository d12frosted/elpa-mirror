;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "import-popwin" "20170218.1407"
  "Popwin buffer near by import statements with popwin."
  '((emacs  "24.3")
    (popwin "0.6"))
  :url "https://github.com/syohex/emacs-import-popwin"
  :commit "bb05a9e226f8c63fe7b18a3e92010357049ab5ba"
  :revdesc "bb05a9e226f8"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
