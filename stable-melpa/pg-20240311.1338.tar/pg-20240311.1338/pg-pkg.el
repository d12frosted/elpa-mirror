(define-package "pg" "20240311.1338" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "28.1"))
  :commit "31a5bcfbc90c73e76a91839cc1597ad77d2a6ad8" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
