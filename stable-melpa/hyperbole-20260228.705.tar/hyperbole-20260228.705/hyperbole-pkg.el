;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260228.705"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "2ec55777c0ed3149233a6e57db98f8258f8ba62a"
  :revdesc "2ec55777c0ed"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
