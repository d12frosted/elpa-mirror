(define-package "standoff-mode" "20210804.1639" "Create stand-off markup, also called external markup." 'nil :commit "2f7f22349473f8d96df0d491d41cbdd2c4115847" :authors
  '(("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de"))
  :maintainer
  '("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de")
  :keywords
  '("text" "annotations" "ner" "humanities")
  :url "https://github.com/lueck/standoff-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
