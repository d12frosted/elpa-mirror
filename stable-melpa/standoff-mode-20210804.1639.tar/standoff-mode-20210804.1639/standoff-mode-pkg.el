(define-package "standoff-mode" "20210804.1639" "Create stand-off markup, also called external markup." 'nil :commit "d96ba6c286af4fb9ed64b8bca697220051be4de8" :authors
  '(("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de"))
  :maintainer
  '("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de")
  :keywords
  '("text" "annotations" "ner" "humanities")
  :url "https://github.com/lueck/standoff-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
