(define-package "modus-themes" "20220222.1722" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "fa6a81ac91cd95b53869942378eb0083c839b0e4" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
