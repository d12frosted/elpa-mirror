;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261124.615"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "bef8b7cdd566b0f81ebf4cb5106decedfe363808"
  :revdesc "bef8b7cdd566"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
