;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260309.1229"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "198b1e0bb45acf2a24456835740cac8288711fe1"
  :revdesc "198b1e0bb45a"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
