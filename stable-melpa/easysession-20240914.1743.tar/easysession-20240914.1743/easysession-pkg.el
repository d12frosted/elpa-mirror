(define-package "easysession" "20240914.1743" "Easily persist and restore your editing sessions"
  '((emacs "25.1")
    (f "0.18.2"))
  :commit "0c60fcae1346de50301fbbcf94fe235547263982" :keywords
  '("convenience")
  :url "https://github.com/jamescherti/easysession.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
