;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20250112.17"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "c79e0b730797ac65668cb66dbfb50759947ea878"
  :revdesc "c79e0b730797"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
