;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260428.646"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "1570e70985735a7c9adacf81dcd986dea97fd626"
  :revdesc "1570e7098573")
