(define-package "hl-prog-extra" "20220627.409" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "37415944505239870face16559174523920b761a" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
