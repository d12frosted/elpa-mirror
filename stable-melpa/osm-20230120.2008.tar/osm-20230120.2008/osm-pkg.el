(define-package "osm" "20230120.2008" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.1.1"))
  :commit "cac368527ace7a95cb2efd327ac8dbba0ac996b6" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
