(define-package "racket-mode" "20220219.1340" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "52e993f3b39416eeb4df6262491d4a42d0b35232" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
