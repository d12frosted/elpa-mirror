(define-package "org-ai" "20230511.247" "Your AI assistant with ChatGPT, DALL-E, Whisper"
  '((emacs "28.2"))
  :commit "8dbba5a117e2cd84beeba8f3578ad1f6e43850d4" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
