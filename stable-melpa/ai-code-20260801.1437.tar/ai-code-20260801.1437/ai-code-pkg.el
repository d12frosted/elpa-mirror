;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260801.1437"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "948693eb48046120e539ee38a32ebf822aba2fff"
  :revdesc "948693eb4804"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
