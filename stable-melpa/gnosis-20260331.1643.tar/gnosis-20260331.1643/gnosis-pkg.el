;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260331.1643"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "9dff0382b85326b15f2ad3e7656307b11b2138fc"
  :revdesc "9dff0382b853"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
