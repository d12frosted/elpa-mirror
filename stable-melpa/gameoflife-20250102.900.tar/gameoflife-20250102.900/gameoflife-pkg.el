;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gameoflife" "20250102.900"
  "Screensaver running Conway's Game of Life."
  ()
  :url "https://github.com/Lindydancer/gameoflife"
  :commit "5f4ac265928bfd88765d057b44cebcef71a7aaf6"
  :revdesc "5f4ac265928b"
  :keywords '("games"))
