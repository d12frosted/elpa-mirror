(define-package "kiwix" "20200714.1357" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (cl-lib "0.5")
    (request "0.3.0"))
  :commit "cb3e2531a55b896b9b41f38f97a597c26433da8e" :keywords
  ("kiwix" "wikipedia")
  :authors
  (("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  ("stardiviner" . "numbchild@gmail.com")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
