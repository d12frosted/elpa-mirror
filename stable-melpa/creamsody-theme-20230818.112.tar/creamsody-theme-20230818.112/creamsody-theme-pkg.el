(define-package "creamsody-theme" "20230818.112" "Straight from the soda fountain"
  '((autothemer "0.2")
    (emacs "24"))
  :commit "fd8b1ab88a45b51991e8a24c04adc0290e722718" :url "http://github.com/emacsfodder/emacs-theme-creamsody")
;; Local Variables:
;; no-byte-compile: t
;; End:
