(define-package "binder" "20220429.2055" "Global minor mode to facilitate multi-file writing projects"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "5e11bc279850b623ebfde9a2278ea7c3ec2d7ac2" :authors
  '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainer
  '("Paul W. Rankin" . "pwr@bydasein.com")
  :keywords
  '("files" "outlines" "wp" "text")
  :url "https://github.com/rnkn/binder")
;; Local Variables:
;; no-byte-compile: t
;; End:
