(define-package "tomorrow-night-deepblue-theme" "20240712.1422" "The Tomorrow Night Deepblue color theme"
  '((emacs "26.1"))
  :commit "1e505cb5adaf6de008f8be604785e3df61a8beb8" :keywords
  '("faces" "themes")
  :url "https://github.com/jamescherti/tomorrow-night-deepblue-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
