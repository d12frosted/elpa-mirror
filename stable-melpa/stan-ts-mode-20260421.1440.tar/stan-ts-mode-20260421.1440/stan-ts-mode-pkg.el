;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stan-ts-mode" "20260421.1440"
  "Major mode for editing Stan files."
  '((emacs "30.1"))
  :url "https://github.com/WardBrian/stan-ts-mode"
  :commit "96c039101367b854834a0f37761f8df18f18085b"
  :revdesc "96c039101367"
  :keywords '("stan" "languages" "tree-sitter")
  :authors '(("Brian Ward" . "bward@flatironinstitute.org"))
  :maintainers '(("Brian Ward" . "bward@flatironinstitute.org")))
