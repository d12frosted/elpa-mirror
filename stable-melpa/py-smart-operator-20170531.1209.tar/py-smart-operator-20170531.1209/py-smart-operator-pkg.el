;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-smart-operator" "20170531.1209"
  "Smart-operator for python-mode."
  '((s "1.9.0"))
  :url "https://github.com/rmuslimov/py-smart-operator"
  :commit "0c8a66faca4b35158d0b5885472cb75286039167"
  :revdesc "0c8a66faca4b"
  :keywords '("python" "convenience" "smart-operator")
  :authors '(("Rustem Muslimov" . "r.muslimov@gmail.com"))
  :maintainers '(("Rustem Muslimov" . "r.muslimov@gmail.com")))
