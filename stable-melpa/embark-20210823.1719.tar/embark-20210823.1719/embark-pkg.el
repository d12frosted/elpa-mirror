(define-package "embark" "20210823.1719" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "ca517fdabd182b0b905d0ef0cb380facb6697670" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
