;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "status" "20151230.1408"
  "Notification area support for Emacs."
  ()
  :url "https://github.com/tromey/emacs-status"
  :commit "b62c74bf272566f82a68622f29fb9edafea0f241"
  :revdesc "b62c74bf2725"
  :keywords '("frames" "multimedia")
  :authors '(("Tom Tromey" . "tom@tromey.com"))
  :maintainers '(("Tom Tromey" . "tom@tromey.com")))
