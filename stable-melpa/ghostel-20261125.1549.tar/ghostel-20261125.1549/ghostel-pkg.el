;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261125.1549"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "2945fb6b6d63e960e61a1e40f3543300077c21c8"
  :revdesc "2945fb6b6d63"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
