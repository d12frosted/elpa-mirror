;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20260714.147"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "77c843cc31eedbe17a30dab8ffa796ee25a53a7b"
  :revdesc "77c843cc31ee"
  :keywords '("maint")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
