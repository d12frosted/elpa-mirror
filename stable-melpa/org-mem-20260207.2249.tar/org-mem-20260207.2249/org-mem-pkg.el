;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260207.2249"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "6c2e2b0270bd8d90178a364894d5856dd96f4584"
  :revdesc "6c2e2b0270bd"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
