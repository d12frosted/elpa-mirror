;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260621.2119"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "c9ee8b66a80c4d6c3f34f8621f3bed954863b69a"
  :revdesc "c9ee8b66a80c"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
