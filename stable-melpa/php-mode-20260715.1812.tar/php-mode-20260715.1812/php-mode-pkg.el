;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20260715.1812"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "101b3b5cad0d783a91ffc58e0e43115d06d11034"
  :revdesc "101b3b5cad0d"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
