(define-package "live-py-mode" "20210101.1827" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "bfdfcdf5579657cdd44ef428c17f25b45b76bf20" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
