(define-package "mlscroll" "20221204.1608" "A scroll bar for the modeline"
  '((emacs "27.1"))
  :commit "de9f84531ca4db6e54a2ca7201638decc0ccadd4" :authors
  '(("J.D. Smith"))
  :maintainers
  '(("J.D. Smith"))
  :maintainer
  '("J.D. Smith")
  :keywords
  '("convenience")
  :url "https://github.com/jdtsmith/mlscroll")
;; Local Variables:
;; no-byte-compile: t
;; End:
