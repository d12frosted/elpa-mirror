(define-package "rainbow-fart" "20210803.922" "Checks the keywords of code to play suitable sounds"
  '((emacs "25.1")
    (flycheck "32snapshot"))
  :commit "57fe85c0f03917f6867833636a5617cbfa663a29" :keywords
  '("tools")
  :url "https://github.com/stardiviner/emacs-rainbow-fart")
;; Local Variables:
;; no-byte-compile: t
;; End:
