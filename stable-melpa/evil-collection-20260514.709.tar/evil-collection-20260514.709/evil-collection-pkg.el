;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260514.709"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "37cdc6e7e8ad2193742f03357fdd1ebc67531f07"
  :revdesc "37cdc6e7e8ad"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
