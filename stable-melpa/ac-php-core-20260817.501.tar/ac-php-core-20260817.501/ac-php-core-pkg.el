;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20260817.501"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "8d9354f2f851d087cf11a95f98a0e65f8203f065"
  :revdesc "8d9354f2f851"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
