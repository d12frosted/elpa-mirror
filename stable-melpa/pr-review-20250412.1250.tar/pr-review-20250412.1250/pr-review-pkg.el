;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pr-review" "20250412.1250"
  "Review github PR."
  '((emacs         "27.1")
    (magit-section "3.2")
    (magit         "3.2")
    (markdown-mode "2.5")
    (ghub          "3.5"))
  :url "https://github.com/blahgeek/emacs-pr-review"
  :commit "c2d2a49b6e08c68890f2299075d8e48ce5e285c3"
  :revdesc "c2d2a49b6e08"
  :keywords '("tools")
  :authors '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainers '(("Yikai Zhao" . "yikai@z1k.dev")))
