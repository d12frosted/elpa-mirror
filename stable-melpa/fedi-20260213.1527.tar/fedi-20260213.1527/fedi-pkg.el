;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fedi" "20260213.1527"
  "Helper functions for fediverse clients."
  '((emacs         "28.1")
    (markdown-mode "2.5"))
  :url "https://codeberg.org/martianh/fedi.el"
  :commit "e4923e35aabfa14eb5fefc5b3685932d8fe1068e"
  :revdesc "e4923e35aabf"
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
