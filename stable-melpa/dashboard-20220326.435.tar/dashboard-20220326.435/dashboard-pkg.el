(define-package "dashboard" "20220326.435" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "c8fb844b0c0f4cb8d58553d0f26d4f96f8e9b9bb" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
