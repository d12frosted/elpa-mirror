;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260125.1854"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b8e18c62eb659d916942b7e57765169ff188e61a"
  :revdesc "b8e18c62eb65"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
