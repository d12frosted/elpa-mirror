;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260314.1210"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a8730a1b42357c13f872a8020676e812a6444923"
  :revdesc "a8730a1b4235")
