(define-package "rspec-mode" "20220807.2226" "Enhance ruby-mode for RSpec"
  '((ruby-mode "1.0")
    (cl-lib "0.4"))
  :commit "f712366ad636622f5b72fa2906c5da10fd266d66" :authors
  '(("Peter Williams, et al."))
  :maintainer
  '("Peter Williams, et al.")
  :keywords
  '("rspec" "ruby")
  :url "http://github.com/pezra/rspec-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
