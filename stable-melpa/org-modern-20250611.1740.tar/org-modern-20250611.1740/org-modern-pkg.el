;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern" "20250611.1740"
  "Modern looks for Org."
  '((emacs  "28.1")
    (org    "9.5")
    (compat "30"))
  :url "https://github.com/minad/org-modern"
  :commit "4cac2a4b18296f48e022c4a935cb66da99eda426"
  :revdesc "4cac2a4b1829"
  :keywords '("outlines" "hypermedia" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
