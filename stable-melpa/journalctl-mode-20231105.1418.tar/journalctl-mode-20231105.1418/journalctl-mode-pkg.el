(define-package "journalctl-mode" "20231105.1418" "Sample major mode for  viewing output journalctl"
  '((emacs "24.1"))
  :commit "7f58e205a44f06d0ee2ee49f5d3667f8677e57d2" :authors
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainers
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainer
  '("Sebastian Meisel" . "sebastian.meisel@gmail.com")
  :keywords
  '("unix")
  :url "https://github.com/SebastianMeisel/journalctl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
