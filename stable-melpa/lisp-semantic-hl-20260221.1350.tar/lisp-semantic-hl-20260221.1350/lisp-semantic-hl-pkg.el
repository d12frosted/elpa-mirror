;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-semantic-hl" "20260221.1350"
  "Semantic Syntax Highlighting for Lisp Languages."
  '((emacs "27.1"))
  :url "https://github.com/calsys456/lisp-semantic-hl.el"
  :commit "30a8a04aab8e69a1adcb16a8d4b000cd4e469ca8"
  :revdesc "30a8a04aab8e"
  :keywords '("languages" "lisp" "maint")
  :authors '(("The Calendrical System" . "us@calsys.org"))
  :maintainers '(("The Calendrical System" . "us@calsys.org")))
