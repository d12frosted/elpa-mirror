(define-package "detached" "20221111.1152" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "b4e3f1933c21878f34dd22efabb7ec2a76cd1096" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
