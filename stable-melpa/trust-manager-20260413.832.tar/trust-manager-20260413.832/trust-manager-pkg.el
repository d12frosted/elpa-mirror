;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "20260413.832"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "e7c15a070ddec6f6003df9812452a6fa7ab7685d"
  :revdesc "e7c15a070dde"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
