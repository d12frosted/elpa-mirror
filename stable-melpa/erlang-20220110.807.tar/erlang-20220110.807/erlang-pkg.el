(define-package "erlang" "20220110.807" "Erlang major mode"
  '((emacs "24.1"))
  :commit "eca6211cd169ce64359f504eb890d1ac4ef3ef32" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
