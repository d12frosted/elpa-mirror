(define-package "erlang" "20220110.807" "Erlang major mode"
  '((emacs "24.1"))
  :commit "e5241e4b777b77db51ec83855958e67420048d94" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
