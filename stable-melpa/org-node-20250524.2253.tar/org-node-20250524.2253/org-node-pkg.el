;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250524.2253"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "544fb018e6f40b1a5e35b582b53528126fdb3621"
  :revdesc "544fb018e6f4"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
