;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260408.541"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "b90d59531783ed18fd91da0c14d053bc3e0e8df7"
  :revdesc "b90d59531783"
  :keywords '("comm"))
