;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cuckoo-search" "20251004.1847"
  "Content-based search and saved-searches for Elfeed."
  '((emacs  "29.1")
    (elfeed "3.4.2"))
  :url "https://github.com/rtrppl/cuckoo-search"
  :commit "3c9840c4a3fe5cfe0c203ed4657324af8e5bb32f"
  :revdesc "3c9840c4a3fe"
  :maintainers '(("René Trappel" . "rtrappel@gmail.com")))
