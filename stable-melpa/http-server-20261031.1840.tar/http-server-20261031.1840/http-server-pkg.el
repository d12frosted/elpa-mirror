;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-server" "20261031.1840"
  "Speaks HTTP for you."
  '((emacs "30.1"))
  :url "https://codeberg.org/martenlienen/http-server.el"
  :commit "a37c0464cc996c55452b4a3144d105df43265324"
  :revdesc "a37c0464cc99"
  :keywords '("comm")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
