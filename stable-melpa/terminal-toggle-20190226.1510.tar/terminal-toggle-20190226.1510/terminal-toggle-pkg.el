;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "terminal-toggle" "20190226.1510"
  "Simple pop-up terminal."
  '((emacs  "24")
    (popwin "1.0.0"))
  :url "https://github.com/mtekman/terminal-toggle.el"
  :commit "f824d634aef3600cb7a8e2ddf9e8444c6607c160"
  :revdesc "f824d634aef3"
  :keywords '("outlines"))
