;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-cite-overlay" "20260619.1531"
  "Overlays for org-cite citations."
  '((emacs    "29.1")
    (citeproc "0.9.4"))
  :url "https://git.sr.ht/~swflint/org-cite-overlay"
  :commit "ec716f4e84d0796f652f789e4108617df4d233de"
  :revdesc "ec716f4e84d0"
  :keywords '("bib" "tex")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
