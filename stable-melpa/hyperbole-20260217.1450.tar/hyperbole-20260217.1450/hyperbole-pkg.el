;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260217.1450"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "96350caf8a033297a9fe5223ac09d7e8dec69e22"
  :revdesc "96350caf8a03"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
