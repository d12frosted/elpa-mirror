(define-package "binky-mode" "20230810.714" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "a1bb3e4197ffeb4f534ee23b860b577a156eb81a" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
