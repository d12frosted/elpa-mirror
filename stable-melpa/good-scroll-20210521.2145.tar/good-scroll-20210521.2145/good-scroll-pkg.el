(define-package "good-scroll" "20210521.2145" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "134dd94eb9e7f4f63ab14f98e94f5680d5342260" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
