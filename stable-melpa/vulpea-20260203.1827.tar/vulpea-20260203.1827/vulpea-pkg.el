;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260203.1827"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "37584d93e97be257b37ea38ecbb9d9ee9d4aab3b"
  :revdesc "37584d93e97b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
