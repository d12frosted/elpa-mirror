(define-package "notmuch" "20220216.1156" "run notmuch within emacs" 'nil :commit "9ddd13f75827f4972872c8766320c7cb80b1819b" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
