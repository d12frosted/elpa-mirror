(define-package "notmuch" "20220216.1156" "run notmuch within emacs" 'nil :commit "b320d3fb59d80b071459a0b2f28c4340ac687327" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
