;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260104.1010"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "6290928e6a876cd4d243013ac383ecf0a88d925e"
  :revdesc "6290928e6a87"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
