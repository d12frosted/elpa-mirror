(define-package "modus-themes" "20230128.505" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "c26d5a641cf031304a57e9229faa5fe58c40006a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
