(define-package "geiser-chez" "20211120.250" "Chez Scheme's implementation of the geiser protocols"
  '((emacs "26.1")
    (geiser "0.18"))
  :commit "ab2dde7a345c1c135ec0ed8fcd49eff1114951bd" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chez" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chez")
;; Local Variables:
;; no-byte-compile: t
;; End:
