;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260809.1030"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "2736124ce1c562e250bb4a376096022713907d23"
  :revdesc "2736124ce1c5"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
