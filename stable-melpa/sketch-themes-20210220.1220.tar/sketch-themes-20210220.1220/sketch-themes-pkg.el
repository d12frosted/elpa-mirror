(define-package "sketch-themes" "20210220.1220" "Sketch color themes"
  '((emacs "26.1"))
  :commit "44bab8750980a62b29be6e9e2c4ea3d0116be8ca" :authors
  '(("Daw-Ran Liou" . "hi@dawranliou.com"))
  :maintainer
  '("Daw-Ran Liou" . "hi@dawranliou.com")
  :keywords
  '("faces")
  :url "https://github.com/dawranliou/emacs.d/themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
