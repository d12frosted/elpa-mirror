;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lusty-explorer" "20200602.228"
  "Dynamic filesystem explorer and buffer switcher."
  '((emacs "25.1"))
  :url "https://github.com/sjbach/lusty-emacs"
  :commit "75233eff9c961b9e99db0e0c50b6720850b595ec"
  :revdesc "75233eff9c96"
  :keywords '("convenience" "files" "matching" "tools"))
