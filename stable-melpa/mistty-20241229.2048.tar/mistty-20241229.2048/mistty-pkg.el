;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241229.2048"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "11d38f5959980d7631059e63d6878327a0723f0b"
  :revdesc "11d38f595998"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
