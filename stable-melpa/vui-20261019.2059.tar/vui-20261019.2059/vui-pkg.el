;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261019.2059"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "f9278ae923b0673924859366ba9d7f76427d40cb"
  :revdesc "f9278ae923b0"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
