;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdffontetc" "20260615.2141"
  "Display `pdffont' and other PDF information."
  '((emacs     "24.4")
    (pdf-tools "1.2.0"))
  :url "https://github.com/emacsomancer/pdffontetc"
  :commit "05c25591e807eaf79d25dbcfa20ca994f1ae78e3"
  :revdesc "05c25591e807"
  :keywords '("files" "multimedia")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
