;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csound-mode" "20260704.1056"
  "A major mode for interacting and coding Csound."
  '((emacs     "27.1")
    (shut-up   "0.3.2")
    (multi     "2.0.1")
    (dash      "2.16.0")
    (highlight "0"))
  :url "https://github.com/hlolli/csound-mode"
  :commit "d7633d26abd63ed47535a203e289a97e2ffebe4d"
  :revdesc "d7633d26abd6"
  :authors '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers '(("Hlöðver Sigurðsson" . "hlolli@gmail.com")))
