;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260926.215"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d551202139dc0ad5f671fd19ca237515eb4ae762"
  :revdesc "d551202139dc")
