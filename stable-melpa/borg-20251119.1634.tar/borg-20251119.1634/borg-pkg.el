;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20251119.1634"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.4"))
  :url "https://github.com/emacscollective/borg"
  :commit "2669e518b176dc3abc0b40d9557e3f8356cda87c"
  :revdesc "2669e518b176"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
