;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260717.744"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "f756b46889c7d2ce87d49a087df1185ea160d1e5"
  :revdesc "f756b46889c7"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
