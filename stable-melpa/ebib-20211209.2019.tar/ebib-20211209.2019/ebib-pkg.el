(define-package "ebib" "20211209.2019" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "6fad3cba6cb07113dfb9678be0f050a0d98052d9" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
