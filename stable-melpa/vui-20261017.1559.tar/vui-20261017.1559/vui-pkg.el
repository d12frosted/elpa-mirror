;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261017.1559"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "7a096f654b485c513f7be03c6b5e3132ac9608c4"
  :revdesc "7a096f654b48"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
