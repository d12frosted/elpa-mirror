(define-package "eldev" "20211023.1027" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "65df59070a5be1e5a75b51f24ddfac2348214a13" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
