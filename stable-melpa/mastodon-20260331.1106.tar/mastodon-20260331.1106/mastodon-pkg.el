;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260331.1106"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "fac7d15c7ecdc388728e39a953304894dde3025f"
  :revdesc "fac7d15c7ecd"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
