;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debpaste" "20161214.2023"
  "Interface for getting/posting/deleting pastes from paste.debian.net."
  '((xml-rpc "1.6.7"))
  :url "https://github.com/alezost/debpaste.el"
  :commit "6f2a400665062468ebd03a2ce1de2a73d9084958"
  :revdesc "6f2a40066506"
  :keywords '("paste")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
