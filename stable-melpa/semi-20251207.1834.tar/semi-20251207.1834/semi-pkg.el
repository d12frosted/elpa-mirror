;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "semi" "20251207.1834"
  "MIME features."
  '((emacs "24.5")
    (apel  "0")
    (flim  "0"))
  :url "https://github.com/emacsmirror/semi"
  :commit "9904bd849a6243646f4db65d623f2b38b05d79bd"
  :revdesc "9904bd849a62"
  :keywords '("mime" "multimedia" "mail" "news")
  :authors '(("MORIOKA Tomohiko" . "tomo@m17n.org"))
  :maintainers '(("MORIOKA Tomohiko" . "tomo@m17n.org")))
