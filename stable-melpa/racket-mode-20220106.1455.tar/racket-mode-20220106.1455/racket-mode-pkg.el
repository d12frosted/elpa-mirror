(define-package "racket-mode" "20220106.1455" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "184c2c8be4d9eff00477995a99153889fea46305" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
