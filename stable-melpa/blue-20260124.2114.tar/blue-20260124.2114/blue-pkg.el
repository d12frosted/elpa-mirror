;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260124.2114"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "5530e33a0d22634aa1a7b3e734dcb70c19991f5c"
  :revdesc "5530e33a0d22"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
