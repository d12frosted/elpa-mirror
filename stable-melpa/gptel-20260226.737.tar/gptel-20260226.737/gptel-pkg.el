;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260226.737"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "a41bb7da6d030c8bdf7cf37bc24fdf3fd2a76482"
  :revdesc "a41bb7da6d03"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
