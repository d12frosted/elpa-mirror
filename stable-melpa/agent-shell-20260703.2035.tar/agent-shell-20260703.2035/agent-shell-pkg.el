;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260703.2035"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8e6ad47cf71ce72216ffdc4235076d8846c4197f"
  :revdesc "8e6ad47cf71c")
