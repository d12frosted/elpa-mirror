;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sv-kalender-namnsdagar" "20240620.1416"
  "Swedish name day calendar."
  '((emacs "24.3"))
  :url "https://github.com/matsl/sv-kalender-namnsdagar"
  :commit "743aa9eec1364fa4194e11f7f10c29688cdd636b"
  :revdesc "743aa9eec136"
  :keywords '("calendar" "swedish" "localization")
  :authors '(("Mats Lidell" . "mats.lidell@lidells.se"))
  :maintainers '(("Mats Lidell" . "mats.lidell@lidells.se")))
