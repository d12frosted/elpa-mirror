(define-package "burly" "20220701.1037" "Save and restore frame/window configurations with buffers"
  '((emacs "28.1")
    (map "2.1"))
  :commit "1f7140c6b1bff0c8b09b0b16fcad4b68922c810e" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
