(define-package "embark" "20210223.1423" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "fa4d2146243dc39889d27a59d2a3c81c13dda704" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
