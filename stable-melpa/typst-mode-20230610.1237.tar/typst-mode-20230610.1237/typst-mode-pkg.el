(define-package "typst-mode" "20230610.1237" "A major mode for working with Typst typesetting system"
  '((polymode "0.2.2")
    (emacs "24.3"))
  :commit "846317529628ef5881e39a47080cb91e971b43b8" :authors
  '(("Ziqi Yang"))
  :maintainers
  '(("Ziqi Yang"))
  :maintainer
  '("Ziqi Yang")
  :keywords
  '("outlines")
  :url "https://github.com/Ziqi-Yang/typst-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
