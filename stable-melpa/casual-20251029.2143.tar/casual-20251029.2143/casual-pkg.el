;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20251029.2143"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/casual"
  :commit "0c0a386bb9e73532679a29a270cfdd2c6e386d66"
  :revdesc "0c0a386bb9e7"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
