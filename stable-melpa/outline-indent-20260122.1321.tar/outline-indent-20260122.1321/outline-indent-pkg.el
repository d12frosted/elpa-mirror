;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260122.1321"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "dcb3778f9ca6e6a4f341db9b4a8397379f40bbe9"
  :revdesc "dcb3778f9ca6"
  :keywords '("outlines"))
