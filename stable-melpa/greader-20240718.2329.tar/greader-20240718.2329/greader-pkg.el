(define-package "greader" "20240718.2329" "Gnamù reader, send buffer contents to a speech engine"
  '((emacs "26.1")
    (seq "2.24")
    (compat "29.1.4.5"))
  :commit "cf1db7405bfa694c837e1d3e4d759b47d5956524" :authors
  '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers
  '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainer
  '("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")
  :keywords
  '("tools" "accessibility")
  :url "https://gitlab.com/michelangelo-rodriguez/greader")
;; Local Variables:
;; no-byte-compile: t
;; End:
