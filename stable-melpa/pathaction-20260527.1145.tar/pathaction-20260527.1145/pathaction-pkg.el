;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260527.1145"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "7422d213692a4863f8b0aba565e39856792fd115"
  :revdesc "7422d213692a"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
