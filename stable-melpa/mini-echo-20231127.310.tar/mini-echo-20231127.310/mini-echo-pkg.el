(define-package "mini-echo" "20231127.310" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "b168da5ed825e9796afcc3ff160ce4493911a5a3" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
