(define-package "ivy" "20210310.1230" "Incremental Vertical completYon"
  '((emacs "24.5"))
  :commit "19e4180a1ec9833cdc423737d34e9622df4e584f" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("matching")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
