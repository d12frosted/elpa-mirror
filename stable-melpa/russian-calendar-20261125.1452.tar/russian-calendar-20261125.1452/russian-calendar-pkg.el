;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20261125.1452"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "4b0cdf11a5743f4f42af55986ffd94462e6fc1b2"
  :revdesc "4b0cdf11a574"
  :keywords '("calendar" "holidays")
  :authors '(("Anoncheg1 Anoncheg" . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '(("Anoncheg1 Anoncheg" . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
