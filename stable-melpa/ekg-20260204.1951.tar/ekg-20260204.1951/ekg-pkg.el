;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260204.1951"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "59f0e12f3b779b5e864620ebe876481b410d61b2"
  :revdesc "59f0e12f3b77"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
