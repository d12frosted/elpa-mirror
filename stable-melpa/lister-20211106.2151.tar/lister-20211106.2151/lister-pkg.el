(define-package "lister" "20211106.2151" "Yet another list printer"
  '((emacs "26.1"))
  :commit "5ae4f8bcfad02eee81a18c15c921637bb4269c13" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
