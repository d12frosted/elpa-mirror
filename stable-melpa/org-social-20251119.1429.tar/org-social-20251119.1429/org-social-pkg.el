;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251119.1429"
  "An Org-social client."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "458a851d0cde4ec5d7ab289ced792e8256140122"
  :revdesc "458a851d0cde"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
