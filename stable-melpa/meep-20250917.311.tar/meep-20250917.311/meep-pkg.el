;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250917.311"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "b2a8959c10a3aa6f37aef2084c4361ed86d491d0"
  :revdesc "b2a8959c10a3"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
