;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260121.859"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7536bed64088ad880e11f9898181509bfcd7e012"
  :revdesc "7536bed64088")
