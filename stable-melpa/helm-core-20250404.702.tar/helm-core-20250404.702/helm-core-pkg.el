;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250404.702"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "5aeff88aa66133699fa6160fd00ddb0e6cf507c0"
  :revdesc "5aeff88aa661"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
