(define-package "org-re-reveal-ref" "20200312.1239" "Citations and bibliography for org-re-reveal"
  '((emacs "25.1")
    (org-ref "1.1.1")
    (org-re-reveal "0.9.3"))
  :commit "abcd622e4edaa5e4480bcd1e7e4953f67c90e036" :authors
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "bibliography")
  :url "https://gitlab.com/oer/org-re-reveal-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
