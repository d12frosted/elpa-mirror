(define-package "git-commit" "20220422.1903" "Edit Git commit messages."
  '((emacs "25.1")
    (compat "28.1.0.4")
    (transient "20210920")
    (with-editor "20211001"))
  :commit "9cd8e6648c34ce775f955a6a6e043278f9d0ee95" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
