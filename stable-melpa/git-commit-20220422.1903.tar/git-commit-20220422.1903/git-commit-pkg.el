(define-package "git-commit" "20220422.1903" "Edit Git commit messages."
  '((emacs "25.1")
    (compat "28.1.0.4")
    (transient "20210920")
    (with-editor "20211001"))
  :commit "b4d54d3f8ee047479980b6d8079f3ce1a93bb6a4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
