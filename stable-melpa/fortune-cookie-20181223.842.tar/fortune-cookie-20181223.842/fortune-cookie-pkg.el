;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fortune-cookie" "20181223.842"
  "Print a fortune in your scratch buffer."
  ()
  :url "https://github.com/andschwa/fortune-cookie"
  :commit "6c1c08f5be83822c0b762872ab25e3dbee96f333"
  :revdesc "6c1c08f5be83"
  :keywords '("fortune" "cowsay" "scratch" "startup")
  :authors '(("Andrew Schwartzmeyer" . "andrew@schwartzmeyer.com"))
  :maintainers '(("Andrew Schwartzmeyer" . "andrew@schwartzmeyer.com")))
