;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260728.1149"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "c1db7470bcebed3f1aec272c9e2c2d595554c5cf"
  :revdesc "c1db7470bceb"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
