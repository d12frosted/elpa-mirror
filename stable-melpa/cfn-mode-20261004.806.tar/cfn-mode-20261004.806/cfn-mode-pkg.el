;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20261004.806"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "81b7bd08f3a2f6a96cbc4bfaa8c2c3a9040a4991"
  :revdesc "81b7bd08f3a2"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
