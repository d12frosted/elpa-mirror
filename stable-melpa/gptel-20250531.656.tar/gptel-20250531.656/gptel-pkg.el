;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250531.656"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "69b5348651d12613939a14096bbcee17a46caec3"
  :revdesc "69b5348651d1"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
