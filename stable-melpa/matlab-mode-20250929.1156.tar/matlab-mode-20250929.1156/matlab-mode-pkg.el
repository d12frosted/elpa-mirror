;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20250929.1156"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "c5ce50ebe5c94fae0814278e7d7f50a7e271467d"
  :revdesc "c5ce50ebe5c9"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")
                 ("John Ciolfi" . "john.ciolfi.32@gmail.com")))
