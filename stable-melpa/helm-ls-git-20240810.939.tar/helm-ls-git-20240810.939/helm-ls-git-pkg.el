(define-package "helm-ls-git" "20240810.939" "list git files."
  '((helm "3.9.5")
    (emacs "25.3"))
  :commit "08ac00c1a7ec32ccf02979c2477a5c5dd73d2753" :url "https://github.com/emacs-helm/helm-ls-git")
;; Local Variables:
;; no-byte-compile: t
;; End:
