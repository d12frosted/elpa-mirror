(define-package "maxima" "20201207.2204" "Major mode for Maxima"
  '((emacs "25.1")
    (s "1.11.0")
    (test-simple "1.3.0"))
  :commit "009e6c873dce0a72c08eb96ce1becd3228f1c34a" :authors
  (("William F. Schelter")
   ("Jay Belanger")
   ("Fermin Munoz"))
  :maintainer
  ("Fermin Munoz" . "fmfs@posteo.net")
  :keywords
  ("maxima" "tools" "math")
  :url "https://gitlab.com/sasanidas/maxima")
;; Local Variables:
;; no-byte-compile: t
;; End:
