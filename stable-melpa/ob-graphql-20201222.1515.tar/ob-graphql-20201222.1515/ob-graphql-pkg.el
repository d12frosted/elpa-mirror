;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-graphql" "20201222.1515"
  "Org-Babel execution backend for GraphQL source blocks."
  '((emacs        "24.4")
    (graphql-mode "20191024.1221")
    (request      "0.3.2"))
  :url "https://github.com/jdormit/ob-graphql"
  :commit "7c35419f9eec5dc44967cbcfa13c7135b9a96bfc"
  :revdesc "7c35419f9eec"
  :authors '(("Jeremy Dormitzer" . "jeremy.dormitzer@gmail.com"))
  :maintainers '(("Jeremy Dormitzer" . "jeremy.dormitzer@gmail.com")))
