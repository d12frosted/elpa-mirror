;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250326.1553"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "5caa292bbfd291cd4583ab9937224ee40873cf3b"
  :revdesc "5caa292bbfd2"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
