;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260205.1200"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "df042c3eb1ea1fc4b0a7f32d5e39546f7264e322"
  :revdesc "df042c3eb1ea"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
