(define-package "workgroups2" "20230328.1331" "save&load multiple named workspaces (or \"workgroups\")"
  '((emacs "25.1"))
  :commit "aff9d76b7be5eed33f30be2fabf111818749cbd5" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
