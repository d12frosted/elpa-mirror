(define-package "asyncloop" "20231113.1711" "Non-blocking series of functions"
  '((emacs "28")
    (named-timer "0.1"))
  :commit "2297d4e31268fa28f0eb249e358040eb52574619" :authors
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainers
  '((nil . "<meedstrom91@gmail.com>"))
  :maintainer
  '(nil . "<meedstrom91@gmail.com>")
  :keywords
  '("tools")
  :url "https://github.com/meedstrom/asyncloop")
;; Local Variables:
;; no-byte-compile: t
;; End:
