;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251216.1208"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "535bf9c2385a894f39ec7308ed45dfba48ab8dcd"
  :revdesc "535bf9c2385a"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
