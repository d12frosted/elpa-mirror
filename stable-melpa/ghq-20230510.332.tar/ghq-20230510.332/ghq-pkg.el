;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghq" "20230510.332"
  "Ghq interface for emacs."
  '((emacs "26.1")
    (dash  "2.18.0")
    (s     "1.7.0"))
  :url "https://github.com/lafrenierejm/emacs-ghq"
  :commit "eb197c14e53ac57a136ea8d34eec7528487c3301"
  :revdesc "eb197c14e53a"
  :keywords '("convenience")
  :authors '(("Roman Coedo" . "romancoedo@gmail.com"))
  :maintainers '(("Joseph LaFreniere" . "joseph@lafreniere.xyz")))
