;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260208.818"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "7d32eadb97d63d4c15a48150852507115caeea3b"
  :revdesc "7d32eadb97d6"
  :keywords '("data" "extensions"))
