(define-package "chronometrist-key-values" "20210514.827" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "ceb455288a74df6ff7cd45968f37f0f4d3919f28" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "gemini://tilde.team/~contrapunctus/software.gmi")
;; Local Variables:
;; no-byte-compile: t
;; End:
