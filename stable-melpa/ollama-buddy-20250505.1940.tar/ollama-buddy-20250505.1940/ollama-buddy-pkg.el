;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250505.1940"
  "Ollama LLM AI Assistant with ChatGPT, Claude, Gemini and Grok Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "23c24046a2abc00f99385e059ce65fa6eb096748"
  :revdesc "23c24046a2ab"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
