;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260406.1841"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "7a14cb400ec46a4f0d9df5270866592d3529986d"
  :revdesc "7a14cb400ec4"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
