(define-package "license-snippets" "20201117.1619" "LICENSE templates for yasnippet"
  '((emacs "26")
    (yasnippet "0.8.0"))
  :commit "6014e9f4ce1fa2054309343f08bd6751620b56a5" :keywords
  ("tools")
  :authors
  (("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainer
  ("Seong Yong-ju" . "sei40kr@gmail.com")
  :url "https://github.com/sei40kr/license-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
