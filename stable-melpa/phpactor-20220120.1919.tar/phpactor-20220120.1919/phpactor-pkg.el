(define-package "phpactor" "20220120.1919" "Interface to Phpactor"
  '((emacs "25.1")
    (f "0.17")
    (php-runtime "0.2")
    (composer "0.2.0")
    (async "1.9.3"))
  :commit "585862496e8ac9f496c0c99c5b97af456cb1f73c" :authors
  '(("USAMI Kenta" . "tadsan@zonu.me")
    ("Mikael Kermorgant" . "mikael@kgtech.fi"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("tools" "php")
  :url "https://github.com/emacs-php/phpactor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
