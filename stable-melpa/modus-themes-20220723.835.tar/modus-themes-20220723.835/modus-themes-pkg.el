(define-package "modus-themes" "20220723.835" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "960ddb7211775df51dcfd202be1d48166d6c646c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
