(define-package "modus-themes" "20220723.835" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "00e30f1a1a31106290e9afea1f4b63eb83529f2d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
