(define-package "esxml" "20201130.809" "Library for working with xml via esxml and sxml" 'nil :commit "265646046b084621900767682adff6581933f044" :authors
  (("Evan Izaksonas-Smith <izak0002 at umn dot edu>"))
  :maintainer
  ("Evan Izaksonas-Smith")
  :keywords
  ("tools" "lisp" "comm"))
;; Local Variables:
;; no-byte-compile: t
;; End:
