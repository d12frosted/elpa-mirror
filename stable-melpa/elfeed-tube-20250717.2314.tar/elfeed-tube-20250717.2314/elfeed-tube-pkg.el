;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "20250717.2314"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.1")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "02946c7b171065ad85e28525189e79990083f169"
  :revdesc "02946c7b1710"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
