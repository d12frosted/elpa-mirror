;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260313.1516"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "daeab7f6b01d8c58dcabe8431a04577c8095c310"
  :revdesc "daeab7f6b01d"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
