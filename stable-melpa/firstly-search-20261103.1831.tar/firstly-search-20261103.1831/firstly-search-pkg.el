;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "20261103.1831"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "30.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "bf24523fc1dc928afa1cb5e0fa672bc923b67539"
  :revdesc "bf24523fc1dc"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
