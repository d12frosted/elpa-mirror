;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uwu-theme" "20260701.256"
  "An awesome dark color scheme."
  '((emacs "24.1"))
  :url "https://github.com/kborling/uwu-theme"
  :commit "f0c4a616b106dbc8d88dc9a6ca0e31321e14da52"
  :revdesc "f0c4a616b106"
  :keywords '("custom themes" "dark" "faces"))
