;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260126.706"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "4401e5b4cf38524a52399f6982e7540f8e7a9270"
  :revdesc "4401e5b4cf38"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
