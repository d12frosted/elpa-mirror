;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260725.1657"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "329d9a6e35d81ec16b530d559dbce8d67adc15ea"
  :revdesc "329d9a6e35d8"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
