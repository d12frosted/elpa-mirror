;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20251117.2004"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.5"))
  :url "https://github.com/joaotavora/sly"
  :commit "50cad62525d28f52c360af9a299673ea81a38455"
  :revdesc "50cad62525d2"
  :keywords '("languages" "lisp" "sly"))
