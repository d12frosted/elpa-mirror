;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250625.1514"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "a9ac9c72765bda9ba5935aae68f9f290ffaf6191"
  :revdesc "a9ac9c72765b"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
