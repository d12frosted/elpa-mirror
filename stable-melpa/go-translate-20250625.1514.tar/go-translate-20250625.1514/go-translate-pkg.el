;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250625.1514"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "1470094ec06b36ce54894085f424d0b5baf72bb1"
  :revdesc "1470094ec06b"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
