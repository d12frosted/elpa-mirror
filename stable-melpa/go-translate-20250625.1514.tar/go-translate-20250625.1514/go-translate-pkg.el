;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250625.1514"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "caa5546c2a98f24ef22d997ed75e24225a04b094"
  :revdesc "caa5546c2a98"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
