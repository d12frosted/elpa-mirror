;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digistar-mode" "20250105.1658"
  "Major mode for Digistar scripts."
  '((emacs "25.1"))
  :url "https://github.com/retroj/digistar-mode/"
  :commit "fb4f2a3ce6a21b9f0b31ff0ca4fe97ff2cc3776b"
  :revdesc "fb4f2a3ce6a2"
  :keywords '("languages")
  :authors '(("John Foerch" . "jjfoerch@gmail.com"))
  :maintainers '(("John Foerch" . "jjfoerch@gmail.com")))
