;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260310.1128"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "0a35aea41e8dc422b86906d2969298a2b0ec507a"
  :revdesc "0a35aea41e8d"
  :keywords '("convenience" "comm" "hypermedia"))
