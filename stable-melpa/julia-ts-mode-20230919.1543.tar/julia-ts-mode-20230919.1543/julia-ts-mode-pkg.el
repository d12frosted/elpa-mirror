(define-package "julia-ts-mode" "20230919.1543" "Major mode for Julia source code using tree-sitter"
  '((emacs "29")
    (julia-mode "0.4"))
  :commit "51c03c5315444a1a35d18c36ce2f2b74a298a2bb" :authors
  '(("Ronan Arraes Jardim Chagas"))
  :maintainers
  '(("Ronan Arraes Jardim Chagas"))
  :maintainer
  '("Ronan Arraes Jardim Chagas")
  :keywords
  '("julia" "languages" "tree-sitter")
  :url "https://github.com/ronisbr/julia-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
