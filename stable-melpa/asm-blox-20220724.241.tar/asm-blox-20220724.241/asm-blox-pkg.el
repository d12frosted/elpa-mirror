(define-package "asm-blox" "20220724.241" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.3.4"))
  :commit "d73e111a0b96d335e9bca69a234bd0004dfe36f9" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
