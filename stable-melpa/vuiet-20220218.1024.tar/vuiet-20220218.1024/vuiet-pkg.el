(define-package "vuiet" "20220218.1024" "The music player and explorer for Emacs"
  '((emacs "26.1")
    (lastfm "1.1")
    (versuri "1.0")
    (s "1.12.0")
    (bind-key "2.4")
    (mpv "0.1.0"))
  :commit "aed3272b95fc73fd78712ff7dcfc05916f382fed" :authors
  '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers
  '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainer
  '("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")
  :keywords
  '("multimedia")
  :url "https://github.com/mihaiolteanu/vuiet")
;; Local Variables:
;; no-byte-compile: t
;; End:
