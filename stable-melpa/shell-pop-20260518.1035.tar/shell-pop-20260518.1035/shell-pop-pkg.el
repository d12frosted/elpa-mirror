;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260518.1035"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "3d457d09bd54d8091cc8b5dac384e7f9977c4004"
  :revdesc "3d457d09bd54"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
