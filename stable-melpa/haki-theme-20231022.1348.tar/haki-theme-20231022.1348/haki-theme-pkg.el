(define-package "haki-theme" "20231022.1348" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "2f989adaa10f3fb50e455b32fe16cddb35afc5fc" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
