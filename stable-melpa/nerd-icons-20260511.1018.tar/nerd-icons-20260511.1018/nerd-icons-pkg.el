;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20260511.1018"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "b63f9f9fda431dd4a9e8dc7ccb8e02996fbeca77"
  :revdesc "b63f9f9fda43"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
