(define-package "dirvish" "20220515.636" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e1cc2405da869c09a71f3cd017056f852bd2f5c4" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
