(define-package "notmuch" "20210626.1634" "run notmuch within emacs" 'nil :commit "d21e72c9f95d1d052360976302a2f9cfcc1556a5" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
