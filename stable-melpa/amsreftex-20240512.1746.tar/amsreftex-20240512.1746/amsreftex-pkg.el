;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amsreftex" "20240512.1746"
  "Add amsrefs bibliography support for reftex."
  '((emacs "25.1"))
  :url "https://github.com/franburstall/amsreftex"
  :commit "c508b05536a04ee153a9947f025d24930c52209a"
  :revdesc "c508b05536a0"
  :keywords '("tex")
  :authors '(("Fran Burstall" . "fran.burstall@gmail.com"))
  :maintainers '(("Fran Burstall" . "fran.burstall@gmail.com")))
