;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcomp" "20260420.1508"
  "Compare version strings."
  '((emacs "26.1"))
  :url "https://github.com/tarsius/vcomp"
  :commit "213c3f6b085182d20065caa1c53b6a543ca42694"
  :revdesc "213c3f6b0851"
  :keywords '("versions")
  :authors '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
