;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260710.1447"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "66bee1cc931d70f0ee31087e5d6217d9b65bf3a6"
  :revdesc "66bee1cc931d"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
