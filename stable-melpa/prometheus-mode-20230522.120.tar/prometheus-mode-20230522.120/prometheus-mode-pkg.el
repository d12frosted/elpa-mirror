(define-package "prometheus-mode" "20230522.120" "Major modes for Prometheus files"
  '((emacs "26.1"))
  :commit "6e58d52274ffe29a6b0211f3dbc7df2c461b0d37" :authors
  '(("Peter Hoeg" . "peter@hoeg.com"))
  :maintainers
  '(("Peter Hoeg" . "peter@hoeg.com"))
  :maintainer
  '("Peter Hoeg" . "peter@hoeg.com")
  :keywords
  '("languages")
  :url "https://hoeg.com")
;; Local Variables:
;; no-byte-compile: t
;; End:
