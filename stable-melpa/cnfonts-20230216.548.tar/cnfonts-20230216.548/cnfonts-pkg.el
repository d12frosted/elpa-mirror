(define-package "cnfonts" "20230216.548" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "b350922f209f531eb4049517599b2a300b3cb6fd" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
