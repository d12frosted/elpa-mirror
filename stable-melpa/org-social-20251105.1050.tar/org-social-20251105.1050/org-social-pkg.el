;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251105.1050"
  "An Org-social client."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "7709d6ad8dbaaae700e118e2ed39e2ce8e0c44b9"
  :revdesc "7709d6ad8dba"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
