(define-package "eldev" "20220628.1756" "Elisp development tool"
  '((emacs "24.4"))
  :commit "cf837cf05575c1c77c316eadac603a3edace8e5f" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
