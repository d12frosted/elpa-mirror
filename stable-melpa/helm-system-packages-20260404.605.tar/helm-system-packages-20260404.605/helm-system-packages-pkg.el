;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "20260404.605"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "85372333d09dbf21a68ab982a3fba299461eeb9e"
  :revdesc "85372333d09d"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
