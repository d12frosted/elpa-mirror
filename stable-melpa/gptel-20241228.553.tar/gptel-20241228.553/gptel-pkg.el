;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241228.553"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "d2859557a0b55c15b0e8ebf507fb9c39662a43ff"
  :revdesc "d2859557a0b5"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
