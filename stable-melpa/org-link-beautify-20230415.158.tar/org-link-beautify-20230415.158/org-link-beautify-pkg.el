(define-package "org-link-beautify" "20230415.158" "Beautify Org Links"
  '((emacs "28.1")
    (all-the-icons "5.0.0"))
  :commit "162ef0c4be39ef7cfbdd599b6b502b9f2dd95f67" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
