(define-package "elisp-autofmt" "20230119.2242" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "09f1472c738a674db242101b51d2866ea7d8df7f" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
