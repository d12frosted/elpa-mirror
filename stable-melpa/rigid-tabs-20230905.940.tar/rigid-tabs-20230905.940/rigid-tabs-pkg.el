;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rigid-tabs" "20230905.940"
  "Fix TAB alignment in diff buffers."
  '((emacs "24.3"))
  :url "https://gitlab.com/wavexx/rigid-tabs.el"
  :commit "9553118e76fcbc1d8f0bcb960de13c7e3f07b9df"
  :revdesc "9553118e76fc"
  :keywords '("diff" "whitespace" "version control" "magit")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
