;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241119.534"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "f2b98683ef86cc6464fbff59f9ae07e69999a943"
  :revdesc "f2b98683ef86"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
