;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambdapi-mode" "20260626.1213"
  "A major mode for editing Lambdapi source code."
  '((emacs             "27.1")
    (eglot             "1.6")
    (math-symbol-lists "1.2.1")
    (highlight         "20190710.1527"))
  :url "https://github.com/Deducteam/lambdapi"
  :commit "fe5b11c0c4437534f571fb59220340c7b9938df2"
  :revdesc "fe5b11c0c443"
  :keywords '("languages")
  :maintainers '(("Deducteam" . "dedukti-dev@inria.fr")))
