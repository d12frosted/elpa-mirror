(define-package "dogears" "20231016.222" "Never lose your place again"
  '((emacs "26.3")
    (map "2.1"))
  :commit "5134609b81c22711f8b623e01c441b71248ec03b" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/dogears.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
