;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-org-capture-string" "20200810.1114"
  "Counsel for org-capture-string."
  '((emacs "25.1")
    (ivy   "0.13"))
  :url "https://github.com/akirak/counsel-org-capture-string"
  :commit "f47de69458c9fceeecd7c69264f645c0cfeb2cd2"
  :revdesc "f47de69458c9"
  :keywords '("outlines")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
