;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250502.713"
  "Add UNICODE based diagrams to text files."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "e047ab61fc18579ce2b743b5bff982862d5f3442"
  :revdesc "e047ab61fc18"
  :keywords '("convenience" "text"))
