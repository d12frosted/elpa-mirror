;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260424.1756"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "438e7669cd8f76206e4e6db6234975a286e83195"
  :revdesc "438e7669cd8f")
