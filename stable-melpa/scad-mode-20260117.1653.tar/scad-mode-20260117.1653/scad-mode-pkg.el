;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "20260117.1653"
  "A major mode for editing OpenSCAD code."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "546d1507cd131f55ca930de7ae1518884e8221f4"
  :revdesc "546d1507cd13"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
