;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-anki" "20260209.1249"
  "Synchronize org-mode entries to Anki."
  '((emacs   "27.1")
    (request "0.3.2")
    (dash    "2.17")
    (promise "1.1"))
  :url "https://github.com/eyeinsky/org-anki"
  :commit "8cf3f5eb43cbe256ce892cfc867059e200a1b5bb"
  :revdesc "8cf3f5eb43cb"
  :keywords '("outlines" "flashcards" "memory")
  :authors '(("Markus Läll" . "markus.l2ll@gmail.com"))
  :maintainers '(("Markus Läll" . "markus.l2ll@gmail.com")))
