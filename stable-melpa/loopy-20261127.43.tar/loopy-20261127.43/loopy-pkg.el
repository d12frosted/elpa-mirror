;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20261127.43"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://codeberg.org/okamsn/loopy"
  :commit "abcc79836e1389708ee2772f18d38b1a60d0a122"
  :revdesc "abcc79836e13"
  :keywords '("extensions"))
