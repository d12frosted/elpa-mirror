;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "narrowed-page-navigation" "20150109.519"
  "A minor mode for showing one page at a time."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/david-christiansen/narrowed-page-navigation"
  :commit "b215adbac4873f56fbab65772062f0f5be8058a1"
  :revdesc "b215adbac487"
  :keywords '("outlines")
  :authors '(("David Raymond Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Raymond Christiansen" . "david@davidchristiansen.dk")))
