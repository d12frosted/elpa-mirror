(define-package "wildcharm-light-theme" "20231011.2202" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "3ba9dfefbb59959316ff391c4244467254fc0e53" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
