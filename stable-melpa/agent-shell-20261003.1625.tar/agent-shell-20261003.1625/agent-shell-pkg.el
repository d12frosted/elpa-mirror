;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261003.1625"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1133e8dd005a40e405b32523b79f4560784b2c1b"
  :revdesc "1133e8dd005a")
