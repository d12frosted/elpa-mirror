;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251015.542"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "e026ace4544cab8023bdc1f3bb241ec5ab5d25a6"
  :revdesc "e026ace4544c"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
