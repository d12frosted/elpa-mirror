;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "super-save" "20261128.1345"
  "Auto-save buffers, based on your activity."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/super-save"
  :commit "83ee82edc4bb3d68dbbc996c0d768f106101d314"
  :revdesc "83ee82edc4bb"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
