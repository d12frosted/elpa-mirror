(define-package "pylint" "20221111.2150" "minor mode for running `pylint'" 'nil :commit "8958821959b7380ba762a29f607cfcacf3a5ca1f" :authors
  '(("Ian Eure" . "ian.eure@gmail.com"))
  :maintainer
  '("Jonathan Kotta" . "jpkotta@gmail.com")
  :keywords
  '("languages" "python"))
;; Local Variables:
;; no-byte-compile: t
;; End:
