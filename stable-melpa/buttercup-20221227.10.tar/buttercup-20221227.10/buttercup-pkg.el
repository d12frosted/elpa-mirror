(define-package "buttercup" "20221227.10" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "ce2d86ad84610499063854e7d471903c05fea1bf" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
