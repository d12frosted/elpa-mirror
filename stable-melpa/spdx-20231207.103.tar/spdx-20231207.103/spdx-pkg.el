(define-package "spdx" "20231207.103" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "c1846d4354e942cc74db2bc378c2feb6b36a3ecb" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
