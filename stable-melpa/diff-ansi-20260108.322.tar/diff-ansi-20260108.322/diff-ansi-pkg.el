;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "20260108.322"
  "Display diffs using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "6940dd43097d9ec7f1b873c2b4a1b96fa8636cfd"
  :revdesc "6940dd43097d"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
