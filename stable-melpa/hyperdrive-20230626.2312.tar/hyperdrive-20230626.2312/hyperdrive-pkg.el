(define-package "hyperdrive" "20230626.2312" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.6pre")
    (persist "0.5"))
  :commit "42f7eb9b11a3088dd798d71e10e26c73e8dd7b3f" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
