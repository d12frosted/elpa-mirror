;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim-cangjiedict" "20210617.934"
  "Some cangjie dicts for pyim."
  '((pyim "3.7"))
  :url "https://github.com/p1uxtar/pyim-cangjiedict"
  :commit "d17e3d32a6480939b350a91a915ebe8e6efad819"
  :revdesc "d17e3d32a648"
  :keywords '("convenience" "chinese" "pinyin" "input-method" "complete")
  :authors '(("Yuanchen Xie" . "yuanchen.gm@gmail.com"))
  :maintainers '(("Yuanchen Xie" . "yuanchen.gm@gmail.com")))
