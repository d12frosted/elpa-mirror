;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fraktur-mode" "20160815.227"
  "Easily insert Unicode mathematical Fraktur characters."
  '((cl-lib "0.5"))
  :url "https://github.com/grettke/fraktur-mode"
  :commit "514baf5546aed12a0d9fa0fe66e87cdcc7843b08"
  :revdesc "514baf5546ae"
  :keywords '("unicode" "fraktur" "math" "mathematical")
  :authors '(("Grant Rettke" . "gcr@wisdomandwonder.com"))
  :maintainers '((nil . "gcr@wisdomandwonder.com")))
