;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-shell-command" "20260107.2145"
  "Shell commands with DWIM behaviour."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/dwim-shell-command"
  :commit "ddd65f170e114779413502e49244a1371854a576"
  :revdesc "ddd65f170e11")
