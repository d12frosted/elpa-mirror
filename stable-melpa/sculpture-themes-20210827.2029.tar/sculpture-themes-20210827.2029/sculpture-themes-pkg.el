(define-package "sculpture-themes" "20210827.2029" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "c4ac6332aa0fad662c5158a3ba843bb7dd47fc93" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
