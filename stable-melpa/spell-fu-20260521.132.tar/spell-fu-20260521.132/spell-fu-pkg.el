;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spell-fu" "20260521.132"
  "Fast & light spelling highlighter."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spell-fu"
  :commit "cfe5fdd66ed584469589cf4e6f645a9d98a8d666"
  :revdesc "cfe5fdd66ed5"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
