(define-package "easy-kill-extras" "20210528.857" "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :commit "9208abe95b67bb3e1c19e41693fd7dd5f866206c" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/easy-kill-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
