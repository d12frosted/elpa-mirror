;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglink" "20260730.1553"
  "Use Org Mode links in other modes."
  '((emacs  "28.1")
    (compat "31.0")
    (llama  "1.0")
    (org    "9.8")
    (seq    "2.24"))
  :url "https://github.com/tarsius/orglink"
  :commit "629718e2b62eebcfe9130bf9caf63fd2328d6225"
  :revdesc "629718e2b62e"
  :keywords '("hypermedia")
  :authors '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev")))
