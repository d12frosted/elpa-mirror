;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persp-mode" "20260922.825"
  "Windows/buffers sets shared among frames + save/load."
  '((emacs "24.3"))
  :url "https://github.com/Bad-ptr/persp-mode.el"
  :commit "703f3b5ad502cfe5b027586611421900bed1fb40"
  :revdesc "703f3b5ad502"
  :keywords '("perspectives" "session" "workspace" "persistence" "windows" "buffers" "convenience")
  :authors '(("Constantin Kulikov" . "zxnotdead@gmail.com"))
  :maintainers '(("Constantin Kulikov" . "zxnotdead@gmail.com")))
