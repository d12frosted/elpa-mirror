;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rails" "20130424.1519"
  "Helm extension for Rails projects."
  '((helm        "1.5.1")
    (inflections "1.1"))
  :url "https://github.com/asok/helm-rails"
  :commit "723c2a27f3843570ec1039e3c526953e48b4ed40"
  :revdesc "723c2a27f384"
  :keywords '("helm" "rails" "git")
  :authors '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com"))
  :maintainers '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com")))
