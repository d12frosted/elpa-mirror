;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260508.2010"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "09740882b3122302b0ce87931ba061502b0731a1"
  :revdesc "09740882b312"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
