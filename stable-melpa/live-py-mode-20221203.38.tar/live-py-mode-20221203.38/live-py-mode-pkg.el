(define-package "live-py-mode" "20221203.38" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "c02c7a5002d817d6e9cd4d7a1551c0ee412a65f1" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
