;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nightpanel-theme" "20260801.22"
  "Saab instrument cluster colorscheme."
  '((emacs "27.1"))
  :url "https://github.com/gregfelice/nightpanel-theme"
  :commit "c4237f578c86dc473116fdd65a88764f4f03e7b1"
  :revdesc "c4237f578c86"
  :keywords '("faces" "theme")
  :authors '(("Greg Felice" . "gregfelice@gmail.com"))
  :maintainers '(("Greg Felice" . "gregfelice@gmail.com")))
