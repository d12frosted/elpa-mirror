;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20260128.623"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.3"))
  :url "https://github.com/kmontag/macher"
  :commit "4226e3c09c12bc1cbe1ff8c55e58731092617829"
  :revdesc "4226e3c09c12"
  :keywords '("convenience" "gptel" "llm"))
