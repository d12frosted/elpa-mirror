;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rust-mode" "20250620.929"
  "A major-mode for editing Rust source code."
  '((emacs "25.1"))
  :url "https://github.com/rust-lang/rust-mode"
  :commit "8cfcdd166b6c34b0eac3bc69b0141678a48db33d"
  :revdesc "8cfcdd166b6c"
  :keywords '("languages")
  :authors '(("Mozilla" . "rust-mode@noreply.github.com"))
  :maintainers '(("Mozilla" . "rust-mode@noreply.github.com")))
