;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260311.1717"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "b2dc80256addf623f0f19ffce6eba9ff5e612108"
  :revdesc "b2dc80256add"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
