;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-toggle" "20250527.1846"
  "Toggle Evil and God Mode."
  '((emacs    "28.1")
    (evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/jam1015/evil-god-toggle"
  :commit "7d6be34e51ab4ab85b2f09cfc3e8b70b92c76827"
  :revdesc "7d6be34e51ab"
  :keywords '("convenience" "emulation" "evil" "god-mode")
  :authors '(("Jordan Mandel" . "jordan.mandel@live.com"))
  :maintainers '(("Jordan Mandel" . "jordan.mandel@live.com")))
