;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-line-bell" "20260701.1648"
  "Flash the mode line instead of ringing the bell."
  ()
  :url "https://github.com/purcell/mode-line-bell"
  :commit "6ab459f7be311f5a30679a3dfb28431e3e8d2dad"
  :revdesc "6ab459f7be31"
  :keywords '("convenience")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
