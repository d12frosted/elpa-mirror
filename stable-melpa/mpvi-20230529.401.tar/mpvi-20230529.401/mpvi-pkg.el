(define-package "mpvi" "20230529.401" "Integrated MPV Tool"
  '((emacs "28.1")
    (emms "11"))
  :commit "3b338fd63d196898843558e1289dd942cb1abb1e" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience" "docs" "multimedia" "application")
  :url "https://github.com/lorniu/mpvi")
;; Local Variables:
;; no-byte-compile: t
;; End:
