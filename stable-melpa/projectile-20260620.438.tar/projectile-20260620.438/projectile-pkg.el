;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260620.438"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "fd1c6c44f577f045171e42ad6d105746120a8c26"
  :revdesc "fd1c6c44f577"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
