(define-package "hl-prog-extra" "20221211.2225" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "63387fe94d72dfdb2a22a63e65530357383c67c0" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
