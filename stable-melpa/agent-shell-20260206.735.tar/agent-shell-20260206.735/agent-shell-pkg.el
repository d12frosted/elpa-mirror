;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260206.735"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6309fa86c7a20b19f9487b58317d80cb24eebf6e"
  :revdesc "6309fa86c7a2")
