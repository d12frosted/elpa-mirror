;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261017.1500"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "9ed53805847f3a55f627fbe6c1c050f70a0264be"
  :revdesc "9ed53805847f"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
