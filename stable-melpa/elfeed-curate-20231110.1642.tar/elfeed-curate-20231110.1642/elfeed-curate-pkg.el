(define-package "elfeed-curate" "20231110.1642" "Elfeed entry curation"
  '((emacs "25.1")
    (elfeed "3.4.1"))
  :commit "ab2ffe6e371c813ace26f48e9991410624399b30" :authors
  '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainers
  '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainer
  '("Robert Nadler" . "robert.nadler@gmail.com")
  :keywords
  '("news")
  :url "https://github.com/rnadler/elfeed-curate")
;; Local Variables:
;; no-byte-compile: t
;; End:
