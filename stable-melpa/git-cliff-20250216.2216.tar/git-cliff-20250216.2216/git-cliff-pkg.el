;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-cliff" "20250216.2216"
  "Generate and update changelog using git-cliff."
  '((emacs     "29.1")
    (transient "0.6.0")
    (llama     "0.6.0"))
  :url "https://github.com/eki3z/git-cliff.el"
  :commit "e33246132ecf5bc5b7ef4156921deb6558f95289"
  :revdesc "e33246132ecf"
  :keywords '("tools")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
