;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260202.545"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "67e21bd835008765df6ca79992dc36c8daa72dc0"
  :revdesc "67e21bd83500"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
