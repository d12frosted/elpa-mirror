;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251013.1020"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "ebde926c159c6adbf72540d3067bcd88cbbf0247"
  :revdesc "ebde926c159c"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
