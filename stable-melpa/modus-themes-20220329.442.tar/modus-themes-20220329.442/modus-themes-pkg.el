(define-package "modus-themes" "20220329.442" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "d33ae51f89b8b0775ab22f2bd16eb2ff8359d9b0" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
