;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-tree-sitter" "20250626.1806"
  "Provides evil textobjects using tree-sitter."
  '((emacs "25.1"))
  :url "https://github.com/meain/evil-textobj-tree-sitter"
  :commit "326c86929a182b25333f83bb17ef0d6cd0224427"
  :revdesc "326c86929a18"
  :keywords '("evil" "tree-sitter" "text-object" "convenience"))
