(define-package "org-bulletproof" "20230603.1314" "Automatic plain list bullet cycling"
  '((emacs "27.1"))
  :commit "a81c275e2e9d43ba98465df8b41adfd398184fda" :authors
  '(("Pontus Andersson" . "pondersson@gmail.com"))
  :maintainers
  '(("Pontus Andersson" . "pondersson@gmail.com"))
  :maintainer
  '("Pontus Andersson" . "pondersson@gmail.com")
  :keywords
  '("outlines" "convenience")
  :url "https://github.com/pondersson/org-bulletproof")
;; Local Variables:
;; no-byte-compile: t
;; End:
