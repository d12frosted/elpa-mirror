;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260406.1431"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "e079205332ce3b3768dc217822dc5dbad11407ba"
  :revdesc "e079205332ce"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
