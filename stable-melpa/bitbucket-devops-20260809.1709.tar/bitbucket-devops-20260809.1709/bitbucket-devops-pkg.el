;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbucket-devops" "20260809.1709"
  "Bitbucket Cloud DevOps workflows."
  '((emacs         "29.1")
    (magit         "4.0.0")
    (markdown-mode "2.6")
    (transient     "0.3.0")
    (yaml          "1.2.3"))
  :url "https://github.com/will-abb/bitbucket-devops.el"
  :commit "ce7745aa068d8793c694ca39d1c16e36c4f939ee"
  :revdesc "ce7745aa068d"
  :keywords '("tools" "vc")
  :authors '(("Will Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Will Bosch-Bello" . "williamsbosch@gmail.com")))
