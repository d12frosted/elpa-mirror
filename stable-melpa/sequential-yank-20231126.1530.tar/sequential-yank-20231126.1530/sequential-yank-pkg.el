;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sequential-yank" "20231126.1530"
  "Minor mode to copy and paste strings sequentially."
  '((emacs "24.4"))
  :url "https://github.com/knu/sequential-yank.el"
  :commit "3c7f98a842c391b59379566cbf03f143004b26da"
  :revdesc "3c7f98a842c3"
  :keywords '("killing" "convenience")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
