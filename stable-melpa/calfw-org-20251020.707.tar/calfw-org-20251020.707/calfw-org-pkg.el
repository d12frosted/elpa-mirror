;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-org" "20251020.707"
  "Calendar view for org-agenda."
  '((emacs "28.1")
    (calfw "2.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "9cce503eb0e998389485a74b956884d218a960e2"
  :revdesc "9cce503eb0e9"
  :keywords '("calendar" "org")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
