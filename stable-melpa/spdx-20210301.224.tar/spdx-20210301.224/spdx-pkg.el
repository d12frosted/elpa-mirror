(define-package "spdx" "20210301.224" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "63704d435255c1fe3d7579f0344e244c2fbdb706" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
