;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "20260519.620"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "270b3509a681ba1e487551f30c61fa7d8b186592"
  :revdesc "270b3509a681"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
