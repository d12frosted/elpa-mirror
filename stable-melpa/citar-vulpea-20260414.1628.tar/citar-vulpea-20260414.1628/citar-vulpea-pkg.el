;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-vulpea" "20260414.1628"
  "Minor mode integrating Citar and Vulpea."
  '((emacs  "27.2")
    (citar  "1.4")
    (vulpea "2.0"))
  :url "https://github.com/fabcontigiani/citar-vulpea"
  :commit "44ee8c1366687213afdeca20b1889cdcd822237a"
  :revdesc "44ee8c136668"
  :keywords '("bib" "notes" "vulpea")
  :authors '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com"))
  :maintainers '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com")))
