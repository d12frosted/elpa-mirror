(define-package "cliphist" "20220525.1034" "paste from clipboard managers"
  '((emacs "25.1"))
  :commit "d02b97a2aa0da13711d9a6f845649115de8ac11b" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("clipboard" "manager" "history")
  :url "http://github.com/redguardtoo/cliphist")
;; Local Variables:
;; no-byte-compile: t
;; End:
