(define-package "modus-themes" "20210524.1750" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "93bd0cfda1212246307caba9018197f2113574d3" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
