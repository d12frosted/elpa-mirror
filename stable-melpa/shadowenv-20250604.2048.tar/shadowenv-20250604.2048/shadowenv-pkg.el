;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shadowenv" "20250604.2048"
  "Shadowenv integration."
  '((emacs "24.3"))
  :url "https://github.com/Shopify/shadowenv.el"
  :commit "2b8383b54cac9edf8204050d2a8d70a0e6f0d972"
  :revdesc "2b8383b54cac"
  :keywords '("shadowenv" "tools")
  :authors '(("Dante Catalfamo" . "dante.catalfamo@shopify.com"))
  :maintainers '(("Dante Catalfamo" . "dante.catalfamo@shopify.com")))
