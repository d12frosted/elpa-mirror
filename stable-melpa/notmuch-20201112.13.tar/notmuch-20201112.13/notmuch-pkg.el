(define-package "notmuch" "20201112.13" "run notmuch within emacs" 'nil :commit "05a436f730cf6277c403b445bca9419ea89a7b2d" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
