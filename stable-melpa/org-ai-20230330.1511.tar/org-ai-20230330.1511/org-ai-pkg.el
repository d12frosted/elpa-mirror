(define-package "org-ai" "20230330.1511" "Emacs org-mode integration for the OpenAI API"
  '((emacs "28.2"))
  :commit "b094db2d1cfde1e4d303fd08a62ec761616b3f94" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
