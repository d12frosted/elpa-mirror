;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260430.1304"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "1fdbf9c9d75966ee956d9b59a743aa69c1665f8d"
  :revdesc "1fdbf9c9d759"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
