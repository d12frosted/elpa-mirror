(define-package "libmpdel" "20220706.1458" "Communication with an MPD server"
  '((emacs "25.1"))
  :commit "8cf3512a437251863d56ba4933a8dd53988b1d6d" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("multimedia")
  :url "https://github.com/mpdel/libmpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
