(define-package "rbtagger" "20211017.1933" "Ruby tagging tools"
  '((emacs "25.1"))
  :commit "80289b9482c90c321e92b6b11b8615267ad355cb" :authors
  '(("Thiago Araújo" . "thiagoaraujos@gmail.com"))
  :maintainer
  '("Thiago Araújo" . "thiagoaraujos@gmail.com")
  :keywords
  '("languages" "tools")
  :url "https://www.github.com/thiagoa/rbtagger")
;; Local Variables:
;; no-byte-compile: t
;; End:
