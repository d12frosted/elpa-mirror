;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "units-mode" "20221027.303"
  "Mode for conversion between different units."
  '((emacs "24.4"))
  :url "https://github.com/Atreyagaurav/units-mode"
  :commit "10c8de24180f87b1a8a3b0a9b3fbb29eec925417"
  :revdesc "10c8de24180f"
  :keywords '("units" "unit-conversion" "convenience")
  :authors '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainers '(("Gaurav Atreya" . "allmanpride@gmail.com")))
