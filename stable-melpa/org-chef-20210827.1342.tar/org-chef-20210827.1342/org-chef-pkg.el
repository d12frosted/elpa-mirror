(define-package "org-chef" "20210827.1342" "Cookbook and recipe management with org-mode."
  '((org "0")
    (emacs "24"))
  :commit "aa867d34e9824785e9786a7923ae353b066e5f73" :authors
  '(("Calvin Beck" . "hobbes@ualberta.ca"))
  :maintainer
  '("Calvin Beck" . "hobbes@ualberta.ca")
  :keywords
  '("convenience" "abbrev" "outlines" "org" "food" "recipes" "cooking")
  :url "https://github.com/Chobbes/org-chef")
;; Local Variables:
;; no-byte-compile: t
;; End:
