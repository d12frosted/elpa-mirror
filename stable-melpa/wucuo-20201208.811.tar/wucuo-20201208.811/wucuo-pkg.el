(define-package "wucuo" "20201208.811" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "94c3944efeb9e150485f64db11263f59db56fb24" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
