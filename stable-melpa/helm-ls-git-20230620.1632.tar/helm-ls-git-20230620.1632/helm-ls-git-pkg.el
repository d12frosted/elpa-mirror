(define-package "helm-ls-git" "20230620.1632" "list git files."
  '((helm "1.7.8"))
  :commit "ac269326d695b39fda30d8b6590e5e23fe64614c")
;; Local Variables:
;; no-byte-compile: t
;; End:
