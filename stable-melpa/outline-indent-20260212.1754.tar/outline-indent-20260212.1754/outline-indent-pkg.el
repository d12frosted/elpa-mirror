;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260212.1754"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "0f072f6c9140dc1756b4a11ad9d8f1159a9c410c"
  :revdesc "0f072f6c9140"
  :keywords '("outlines"))
