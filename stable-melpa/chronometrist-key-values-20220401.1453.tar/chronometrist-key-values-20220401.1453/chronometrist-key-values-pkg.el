(define-package "chronometrist-key-values" "20220401.1453" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "059579e841148362d5081a43dcb27c8a3c7751ea" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
