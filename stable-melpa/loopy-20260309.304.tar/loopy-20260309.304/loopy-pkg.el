;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260309.304"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "b78b88173df00cf95cda401a6d3b0872dce8aa08"
  :revdesc "b78b88173df0"
  :keywords '("extensions"))
