;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250924.331"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "21ba5ff18147730c392d806d8b4408f33f032133"
  :revdesc "21ba5ff18147"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
