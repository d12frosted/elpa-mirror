;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260825.2110"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "f83b717218d582349bc137bca6f042addb8a9375"
  :revdesc "f83b717218d5"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
