(define-package "ligo-mode" "20230727.1523" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "d9bad20098d2321600fedf051af250c79f622bec" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
