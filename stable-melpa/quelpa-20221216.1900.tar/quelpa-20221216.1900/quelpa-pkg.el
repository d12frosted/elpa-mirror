(define-package "quelpa" "20221216.1900" "Emacs Lisp packages built directly from source"
  '((emacs "25.1"))
  :commit "2679416acb15471cf92fa4d3f536d1b5a3450f90" :authors
  '(("steckerhalter"))
  :maintainer
  '("steckerhalter")
  :keywords
  '("tools" "package" "management" "build" "source" "elpa")
  :url "https://github.com/quelpa/quelpa")
;; Local Variables:
;; no-byte-compile: t
;; End:
