;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260614.1745"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "e5264f31d1d2ca7ffe6fb836d6ab1a6a14eabc30"
  :revdesc "e5264f31d1d2"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
