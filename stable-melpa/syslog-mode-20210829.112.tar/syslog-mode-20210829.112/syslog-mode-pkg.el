(define-package "syslog-mode" "20210829.112" "Major-mode for viewing log files & strace output"
  '((hide-lines "20130623")
    (ov "20150311")
    (hsluv "20181127"))
  :commit "d3cd216fcf79fb86e00ae1e03fd2dc7d52ddfb34" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
