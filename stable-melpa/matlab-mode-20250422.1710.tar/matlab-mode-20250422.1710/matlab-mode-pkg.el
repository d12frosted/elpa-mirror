;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20250422.1710"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "0090bd76467ef58c396904887d2a6d8f8c22cc11"
  :revdesc "0090bd76467e"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")))
