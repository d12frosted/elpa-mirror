(define-package "dwim-shell-command" "20231108.2033" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "0ff41328fcca51e3f40e14a6b64866648c6fc34f" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
