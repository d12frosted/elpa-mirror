;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-summary-repo" "20190617.1419"
  "Import and export files between IMAP and local by using GNUS."
  '((emacs "25"))
  :url "https://github.com/TxGVNN/gnus-summary-repo"
  :commit "3968667bfded60fbbf33f2fba3170e2b6501ec43"
  :revdesc "3968667bfded"
  :keywords '("gnus" "repository")
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
