;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "angry-police-captain" "20120829.1252"
  "Show quote from http://theangrypolicecaptain.com in the minibuffer."
  ()
  :url "https://github.com/rolpereira/angry-police-captain-el"
  :commit "d11931c5cb63368dcc4a48797962428cca6d3e9d"
  :revdesc "d11931c5cb63"
  :keywords '("games" "web" "fun")
  :authors '(("Rolando Pereira" . "rolando_pereira@sapo.pt"))
  :maintainers '(("Rolando Pereira" . "rolando_pereira@sapo.pt")))
