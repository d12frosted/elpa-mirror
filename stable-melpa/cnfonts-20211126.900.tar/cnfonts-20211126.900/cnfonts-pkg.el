(define-package "cnfonts" "20211126.900" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "34594fa52c98d50e0e25ba5749fc467812af3a96" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
