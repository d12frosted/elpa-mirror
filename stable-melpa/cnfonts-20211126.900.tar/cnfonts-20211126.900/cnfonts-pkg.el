(define-package "cnfonts" "20211126.900" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "f106a195224d8d0b38e898a19189f03b45b3d115" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
