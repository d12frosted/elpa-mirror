(define-package "kele" "20240608.1016" "Spritzy Kubernetes cluster management"
  '((emacs "29.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (memoize "0")
    (plz "0.8.0")
    (s "1.13.0")
    (yaml "0.5.1"))
  :commit "beec4a76c090101d8a98e631c292207be3c3a6a1" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
