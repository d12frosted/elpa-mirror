;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251121.235"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "2699598fc3d5e7cb72e61e09d50456ebaa61da38"
  :revdesc "2699598fc3d5"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
