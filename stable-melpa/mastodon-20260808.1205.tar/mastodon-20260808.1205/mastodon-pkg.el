;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260808.1205"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "5ddf28b9454ad9ee12738f9467e3ad013b788ee3"
  :revdesc "5ddf28b9454a"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
