;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20261028.1243"
  "Major mode for editing PHP code."
  '((emacs "28.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "a54fa885cd5c69637eb296e3fa70220cc7aedd5e"
  :revdesc "a54fa885cd5c"
  :keywords '("languages" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
