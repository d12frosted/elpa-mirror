;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260111.2206"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "e6bb32bb2287033420dc714da48b4bca7c0b2f75"
  :revdesc "e6bb32bb2287"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
