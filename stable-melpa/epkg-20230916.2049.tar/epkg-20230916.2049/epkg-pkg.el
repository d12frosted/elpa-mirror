(define-package "epkg" "20230916.2049" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "29.1.4.1")
    (closql "20230407")
    (emacsql "20230409")
    (llama "0.2.0"))
  :commit "bfccebabd75195d12dab9aacf783415c49b7e8a5" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
