;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260724.1019"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e82b4fea6c3790b57bb6071fbf9aad365163c153"
  :revdesc "e82b4fea6c37")
