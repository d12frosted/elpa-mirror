;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-filetype-face" "20250412.1344"
  "Set different faces for different filetypes in dired."
  ()
  :url "https://github.com/jixiuf/dired-filetype-face"
  :commit "41288f9f35a7ef830b9e78fe252b367aee078c96"
  :revdesc "41288f9f35a7"
  :keywords '("dired" "filetype" "face")
  :authors '((nil . "jixiufatgmaildotcom"))
  :maintainers '((nil . "jixiufatgmaildotcom")))
