;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-filter" "20161122.719"
  "Package archive whitelist and blacklist."
  ()
  :url "https://github.com/milkypostman/package-filter"
  :commit "c8e2531227c02c4c5e9d593f2cdb6a4ab4a6849b"
  :revdesc "c8e2531227c0"
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainers '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")))
