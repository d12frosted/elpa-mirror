;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260313.1007"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "73d9018bc899c0138c8c099870e11834a082300c"
  :revdesc "73d9018bc899"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
