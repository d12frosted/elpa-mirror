;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lingva" "20260805.1230"
  "Access Google Translate without tracking via lingva.ml."
  '((emacs "25.1"))
  :url "https://codeberg.org/martianh/lingva.el"
  :commit "36a41d234f2d803a522365c753d646ca5342acc7"
  :revdesc "36a41d234f2d"
  :keywords '("convenience" "translation" "wp" "text")
  :authors '(("marty hiatt" . "martianh@disroot.org"))
  :maintainers '(("marty hiatt" . "martianh@disroot.org")))
