(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "819088efffb77a21a8532699370221cb0e2e1cb7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
