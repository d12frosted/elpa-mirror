(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "af209eb382718388f231bbf2e3e22615eb7440c7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
