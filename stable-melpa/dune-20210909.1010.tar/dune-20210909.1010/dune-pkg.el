(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8f211e9f1ad23779ac8989ef1b8172e9c638f46c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
