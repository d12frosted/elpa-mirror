(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "5630459d03f40ce7ee87ec342af63dccccee97ed" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
