(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "4114d2a3e6467b83de8a4d86743a7ddab2382158" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
