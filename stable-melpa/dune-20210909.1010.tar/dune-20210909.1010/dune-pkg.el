(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e03257dc56ffae8fa8499f0f5ac061c6ccda33e9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
