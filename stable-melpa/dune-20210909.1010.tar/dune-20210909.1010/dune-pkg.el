(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "139fa33913504a305d1f8f171392618a30c97d22" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
