(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0794445c55cf2dcfc2e2162893a27b1522ece08c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
