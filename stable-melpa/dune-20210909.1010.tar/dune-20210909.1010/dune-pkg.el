(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "51ea4c55a4dbbde567f019ef44f7ede3fe606fa3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
