(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "14019057591b87cde783abe853539841b7943fd6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
