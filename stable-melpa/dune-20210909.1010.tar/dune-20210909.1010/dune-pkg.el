(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "39786a7b840f44b8526c1a8e581bf430b364123c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
