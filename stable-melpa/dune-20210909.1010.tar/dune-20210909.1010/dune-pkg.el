(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6dc4fec9324314c76356d5138120be09603ff6fc" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
