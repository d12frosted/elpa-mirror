(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "cccfca1a80963c7582e55047fd5c8413c703c329" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
