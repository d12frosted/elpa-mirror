(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "35a0fcf710240745979af2fde1c399f26739cb5d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
