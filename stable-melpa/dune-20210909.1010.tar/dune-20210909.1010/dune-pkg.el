(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0bdd03fe4512c03b17bab98df9edb88330fb8263" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
