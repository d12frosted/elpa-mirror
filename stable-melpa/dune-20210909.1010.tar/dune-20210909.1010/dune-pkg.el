(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "c6e2773f4aa138afb479ca0e57b104676c77cf6e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
