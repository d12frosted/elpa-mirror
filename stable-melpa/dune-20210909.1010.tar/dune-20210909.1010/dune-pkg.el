(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3323f15d3b2aa7cd821282c0d9f2d9563f17bd9e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
