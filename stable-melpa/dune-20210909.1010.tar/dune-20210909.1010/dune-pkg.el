(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "56e021741874e1e82fcd82e187a9e39433554e4e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
