(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "1c74870571c21e7e95c0ec53d3b714d08fcf2b83" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
