(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "dcd3067e6620011d0397d3764ad44fd0d6319074" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
