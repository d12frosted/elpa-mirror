(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "07072bda10fa06e943cdaee53d48b20564d8fbef" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
