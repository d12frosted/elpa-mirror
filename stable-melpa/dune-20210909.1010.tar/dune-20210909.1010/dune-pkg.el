(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8902120dff97054e891a4f6fa9c0fbb1198df532" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
