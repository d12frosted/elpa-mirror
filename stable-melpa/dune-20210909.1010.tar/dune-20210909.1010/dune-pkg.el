(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "9d0dc1336439b44df27590a02047eed68aaba0be" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
