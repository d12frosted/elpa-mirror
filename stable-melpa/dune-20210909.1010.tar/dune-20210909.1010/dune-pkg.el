(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ecc6f2930f14c2abdaa94bbd69cb676f0fa532a7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
