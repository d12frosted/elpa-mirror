(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a1ea33aa29187e0a469f4add022a8dd6d125a28a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
