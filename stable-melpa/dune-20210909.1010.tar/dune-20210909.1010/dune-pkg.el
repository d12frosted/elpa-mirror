(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "37d0cb628482fb17ec8adc6265251d13db7deb6e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
