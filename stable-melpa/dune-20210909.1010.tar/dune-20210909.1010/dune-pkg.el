(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "01b63fc5ee9607b7584b43334c00806de3d3484e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
