(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8b2a72dbf0238b241be230f2acab575791a8f5be" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
