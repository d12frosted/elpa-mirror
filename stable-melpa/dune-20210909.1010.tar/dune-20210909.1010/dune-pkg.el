(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "bc073c86f36954010d866215ed5fe69db70de393" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
