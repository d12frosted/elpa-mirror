(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "5604d3e3af56d0d11f7f1de9c9ded20d77665900" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
