(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "30b84ff370351b13f05db34fd952dfe5d0249bcb" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
