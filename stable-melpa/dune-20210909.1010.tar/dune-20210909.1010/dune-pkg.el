(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "4633b71e64abe3e8a737a45e181daef43f7db48d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
