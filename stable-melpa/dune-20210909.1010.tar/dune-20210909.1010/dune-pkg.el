(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b8d33fd3f56e4ed7035418bc19d596743b8072f8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
