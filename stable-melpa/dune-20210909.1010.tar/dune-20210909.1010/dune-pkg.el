(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f2f42ddda7a801409c83c4e7c6c1871bcaf54db1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
