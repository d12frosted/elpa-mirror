(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2b4fa81927d3f23cfaf8a845d3f2c1141215afcd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
