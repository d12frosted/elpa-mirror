(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "184612de63b69fae858cf7492beaaa4eea71f4f1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
