(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ebafdcba38dfc9c8639f2abb988617994921d37c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
