(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b52404b1cdbcee3f5fa8af16b144eb9d64f7c390" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
