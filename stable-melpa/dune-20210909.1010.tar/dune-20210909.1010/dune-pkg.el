(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6a66af89672e95e3f0b79b4193a5319d8205cb0f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
