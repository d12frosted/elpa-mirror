(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "09adb41de1ab784f7619d5515659e86deb609db6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
