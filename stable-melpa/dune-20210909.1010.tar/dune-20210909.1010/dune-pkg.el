(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6c6387a09b72a1f7ad8a5b52558ade642fc8c001" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
