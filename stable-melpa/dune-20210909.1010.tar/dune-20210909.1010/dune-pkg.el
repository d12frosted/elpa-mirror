(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "c967d8a4880732f2f7cba39d4f283154c5ef914e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
