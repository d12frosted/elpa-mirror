(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3fd02b6350a878b9052557655e2a41ac94ca5fd2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
