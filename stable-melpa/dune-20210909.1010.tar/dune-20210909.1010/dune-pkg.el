(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "9580b810aff661c5290a7ae2539e419799034b8f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
