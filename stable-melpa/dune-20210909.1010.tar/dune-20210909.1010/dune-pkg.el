(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "5baafe65249fbc481bb55795efe5efb16a825b84" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
