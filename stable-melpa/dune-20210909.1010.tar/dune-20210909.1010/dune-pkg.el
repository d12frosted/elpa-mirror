(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f22e56ca45315b344337fc97a878b3816705247d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
