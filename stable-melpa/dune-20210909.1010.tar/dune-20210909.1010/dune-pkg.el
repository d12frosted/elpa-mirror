(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "4bc7629a5e767623f35f0a52c2d4d147e18cf7ac" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
