(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2b84e7523c13843a7c57965f33266e01b1697899" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
