(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f2d7198c04cae754571aef50d53071fb8e7fe636" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
