(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f5ed6a495947c0e0cc8fa4fc0eac9ffcccdbdbd9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
