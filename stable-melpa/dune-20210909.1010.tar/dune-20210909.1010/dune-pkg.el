(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "eb4788d2beda138e787491ba7e08e53a09c5922f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
