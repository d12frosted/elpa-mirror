(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2ce714430c078064c85a04f240b506997c047126" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
