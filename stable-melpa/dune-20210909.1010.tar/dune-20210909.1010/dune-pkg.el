(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "439d11930cdc8977b1d56718728c33738c96ad14" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
