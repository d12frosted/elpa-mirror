(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7225ab93ca1637373660d922d37edff278372e2d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
