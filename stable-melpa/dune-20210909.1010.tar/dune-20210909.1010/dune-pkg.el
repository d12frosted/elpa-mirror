(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "4db21feca464602a33d3a66ffce404016530cebd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
