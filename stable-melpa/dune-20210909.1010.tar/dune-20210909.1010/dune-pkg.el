(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6441eb2a2bc814eea3d1b44cbf4d080f7bb467c6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
