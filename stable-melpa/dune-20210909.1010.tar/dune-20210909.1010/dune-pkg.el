(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a0e9a3afd219a6d6fb6cf14e0701490c810cd63f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
