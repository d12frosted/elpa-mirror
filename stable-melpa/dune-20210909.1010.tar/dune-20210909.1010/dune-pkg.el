(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3f080574b7904ca75b7e2be1b6de96a2ffc2c4cf" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
