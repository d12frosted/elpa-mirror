(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "125a310946231e859428ec08c4949a25e3c5d40e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
