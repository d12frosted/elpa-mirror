(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2a99ae5c23de6b6427d82517776d205f50722595" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
