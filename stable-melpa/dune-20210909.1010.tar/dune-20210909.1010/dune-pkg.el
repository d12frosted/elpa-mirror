(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "163168cae9f3419bcafc026ec0209c797b99f9d9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
