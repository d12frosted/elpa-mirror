(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "04167da41ead4ccfe898421edd03a55b366b2552" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
