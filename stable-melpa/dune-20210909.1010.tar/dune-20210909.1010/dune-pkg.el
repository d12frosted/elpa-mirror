(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d6f0089da7b44eeb07505f5ea3d91328d14aeaa4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
