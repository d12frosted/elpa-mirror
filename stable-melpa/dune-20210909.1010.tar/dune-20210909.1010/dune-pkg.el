(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "74fb788b2a4936b82d584ae42fbd2f728b560c99" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
