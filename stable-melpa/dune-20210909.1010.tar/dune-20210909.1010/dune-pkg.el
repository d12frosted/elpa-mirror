(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "9dc814ef9b629ce737e100bdb75d3fb1493cfd86" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
