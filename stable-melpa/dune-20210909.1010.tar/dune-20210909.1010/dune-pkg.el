(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2f6aee6847ecf364244f27fc5f7f0901b79e120a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
