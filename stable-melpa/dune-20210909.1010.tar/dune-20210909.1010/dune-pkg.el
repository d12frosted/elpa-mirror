(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e7805e4fd3fe739abc4b667f025cb25b673b02aa" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
