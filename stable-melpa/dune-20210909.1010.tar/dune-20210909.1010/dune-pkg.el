(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "aa195d3dfcc4265a29b1ef5ea5b171c85c1e7055" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
