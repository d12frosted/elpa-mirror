(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e005603c87bd0124a2513ae09045537a2568d66d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
