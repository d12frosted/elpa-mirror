(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "1a8df76f6c4f8251c4ba22265fd3a2e1f42c9d13" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
