(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "35829887efe398ac04f2fe6270ed31d3e82840aa" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
