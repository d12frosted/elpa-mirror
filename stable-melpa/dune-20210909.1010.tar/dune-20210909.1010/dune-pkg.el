(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a27ffbdbd6153db839fdb01495753f2556759640" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
