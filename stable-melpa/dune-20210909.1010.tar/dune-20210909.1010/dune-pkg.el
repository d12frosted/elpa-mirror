(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0281cf2e2ea7c161a75b9bac2fb646933ededdb1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
