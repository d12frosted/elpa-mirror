(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0e4ad0bcdd5d0cea28e8a879b4b391630c826297" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
