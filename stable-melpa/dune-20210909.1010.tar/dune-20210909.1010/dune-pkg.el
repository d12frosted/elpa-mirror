(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e744f603dba7bcb4cc6e3cdd96b0e5601a7f13f7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
