(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "1052e9f264cc50e780f331d282c9c1c06c24bbf9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
