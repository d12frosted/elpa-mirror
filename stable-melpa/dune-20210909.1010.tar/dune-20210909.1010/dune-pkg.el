(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b0341bc53544271f4b433013a3efd69de4139ddf" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
