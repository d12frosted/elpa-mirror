(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6f1f26a3fa1cec2e0edece1648c971e9c466553d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
