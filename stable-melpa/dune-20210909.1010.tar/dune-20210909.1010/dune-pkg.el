(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0f2d0b40bd9d47946f069aae4016a34728823470" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
