(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "737311ba2e3919d91c3fd49a589ba97a60b861bb" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
