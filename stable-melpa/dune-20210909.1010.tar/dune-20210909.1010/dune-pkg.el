(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "530621843764e7a5a4630144102374e8d16b2ff6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
