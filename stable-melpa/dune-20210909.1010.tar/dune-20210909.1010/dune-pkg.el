(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "077d1b3de2b538b1e6a71fdda24f302b3f0d58da" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
