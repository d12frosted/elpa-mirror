(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d9675d97f285e53ee88e33fd5ec4417f32c1096f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
