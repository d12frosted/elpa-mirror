(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a79d111ccf4dd0ed81ee5d87e8053ecace24f9a9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
