(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "c8c201b678bcd9d1f709d08b36fd0a9325945121" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
