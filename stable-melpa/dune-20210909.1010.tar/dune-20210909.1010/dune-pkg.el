(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "5fadbb4873569eb8f26ee3eec5ffe78496ff0a11" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
