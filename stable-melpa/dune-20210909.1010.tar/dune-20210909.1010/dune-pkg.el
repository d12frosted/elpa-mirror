(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "94e28cb393605693f2ac8c833cf88c0361d18df3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
