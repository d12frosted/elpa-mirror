(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "9b8c6cb907d3516014450317304e4ef92853b04a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
