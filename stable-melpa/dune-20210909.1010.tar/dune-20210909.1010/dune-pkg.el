(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ddcc55bc02665ce1e8dfa290632a7aa28850bc63" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
