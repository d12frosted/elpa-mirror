(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "dc9287c3abd888c7f8b302c8a3a04c6ba023afe5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
