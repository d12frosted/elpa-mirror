(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0ee80087793ee3e80d850cb37982d133286c3bd0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
