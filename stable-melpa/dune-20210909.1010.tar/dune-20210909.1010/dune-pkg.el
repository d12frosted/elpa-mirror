(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "72ebf2803ee021b83aaf772833c012a240860dd8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
