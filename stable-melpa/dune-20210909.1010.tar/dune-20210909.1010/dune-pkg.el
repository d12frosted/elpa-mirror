(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d3296a6d50b3323d0d7d15aa96dcbf5d5b9858f7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
