(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "9f461802ed7c4adb17450a7a8b25ab1a432503e9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
