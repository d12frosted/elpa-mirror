(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "442e004ece8c0d02c79211c4ef1bbef3e037ab5d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
