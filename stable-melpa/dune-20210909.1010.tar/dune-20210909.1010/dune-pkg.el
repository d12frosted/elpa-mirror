(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7c3629a36a3de4db1351196766d9f96cc947a3e7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
