(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d83a01622c721bc52d9b386c9d36fe822b33a4af" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
