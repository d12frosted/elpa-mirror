(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "c124f6bb5dd989ba9e74fdc5e447391244bcd44c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
