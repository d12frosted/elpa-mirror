(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "de1ababdd1f8ab8b9b0fd45bf984d70dee1a9cc4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
