(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "4aebbb0d1aa4242744b1a372f3703fcda429596e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
