(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3787d76931329af80a9eb800f701246c538d1f2b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
