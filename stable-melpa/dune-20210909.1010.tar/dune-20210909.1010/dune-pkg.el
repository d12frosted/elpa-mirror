(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "825a415305c58d5dfcd448d6b3d85184c17f4966" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
