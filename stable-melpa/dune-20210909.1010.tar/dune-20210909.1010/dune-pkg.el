(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ab3fb6e3e50a49d54447a796a8e1e5e9338f9885" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
