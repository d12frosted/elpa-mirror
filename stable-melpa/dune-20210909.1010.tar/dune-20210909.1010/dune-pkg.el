(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b8b413a86591f453af76e3275a28f0d719e8de72" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
