(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "3841b29fc80c5553838dc1d5142ef9bb6a11b8ba" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
