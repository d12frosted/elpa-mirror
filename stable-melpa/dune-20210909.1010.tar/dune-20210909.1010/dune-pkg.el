(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "24e21792cef6bff796695a548684944cef979376" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
