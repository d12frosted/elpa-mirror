(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "344641b52eab016ffba1865477ccacfc974532d8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
