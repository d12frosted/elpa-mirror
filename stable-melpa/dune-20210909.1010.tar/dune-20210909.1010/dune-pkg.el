(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "603d326337527b10d6e90ccab56c65deabd82378" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
