(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "19d2cfd46e61f0310965e9751bb9890918f27aaa" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
