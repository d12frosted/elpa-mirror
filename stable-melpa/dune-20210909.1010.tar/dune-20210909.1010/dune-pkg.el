(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7f8471d5eef596ffbf9faa3b06e5d3e3f3673a7f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
