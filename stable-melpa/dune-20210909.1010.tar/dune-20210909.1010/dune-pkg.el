(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e6be20a52cf350ee00825331f51a870e40af2c96" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
