(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7776fa10ed1e8e399559335ab1083746830ce280" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
