(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ecaddcdb1f2eda4a4ce6b9e8f34f25fc0a6e343b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
