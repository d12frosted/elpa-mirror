(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "5a4469403a795dc4ef592b7b21c99d85072bfdad" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
