(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "43af00f79e41ce9101d42b36dab13e1f68d49a7a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
