(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d5c302621569f5b72cd2f1f8ebf8c8a17cba8037" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
