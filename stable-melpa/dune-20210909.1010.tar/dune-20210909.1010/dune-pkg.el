(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "33d625d08bcf596a6c309d791a2cab70f2b8abce" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
