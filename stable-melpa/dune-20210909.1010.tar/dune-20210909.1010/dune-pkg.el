(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "1b285bf568fa85dbcf95987e4cc19043f02564c1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
