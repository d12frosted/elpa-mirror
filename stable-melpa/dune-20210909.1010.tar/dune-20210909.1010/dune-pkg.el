(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "efad78e826e6af26e140ed9f9e3a00b17f89d617" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
