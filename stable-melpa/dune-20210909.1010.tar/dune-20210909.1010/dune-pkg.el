(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b554df86f40fe3bf15a967e533ae513d3f219522" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
