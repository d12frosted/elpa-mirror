(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a515b1b42f29be7965f4ef9410095c3a1626c1cd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
