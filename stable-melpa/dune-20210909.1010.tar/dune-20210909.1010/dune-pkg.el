(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "6005ed998fc5065e1fcb5f8885039d6f17f35a18" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
