(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "fb7b434394fb6942d2c51eab1cfeaa20e3fa3777" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
