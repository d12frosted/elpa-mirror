(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "02292950515d0b0846156b91b7b0ce0c2453c519" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
