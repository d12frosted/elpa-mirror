(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "9afce4b00cdce2ebd0758a49cfc3f4d08ed67984" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
