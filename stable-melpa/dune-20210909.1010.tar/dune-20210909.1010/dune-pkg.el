(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "18681dff2517d7be10554b26a04bc61151f3b100" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
