(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ece058241d5b9d6808a51fee6d9cfcf959d23d83" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
