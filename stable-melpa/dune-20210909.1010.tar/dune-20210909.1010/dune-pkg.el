(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "cd65a3e61054e86d48ab00c208bc10757e60e261" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
