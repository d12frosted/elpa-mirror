(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "5a5c5387f537a3108f03acb30e2b521a916a189a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
