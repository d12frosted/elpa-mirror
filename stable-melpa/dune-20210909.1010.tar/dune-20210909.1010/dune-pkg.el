(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "cd6b0b5bfdce67072707f062b07aed3d1c0b6321" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
