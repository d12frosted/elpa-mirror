(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "38a48560a01f1033bc6e7691a5a75e44ad954341" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
