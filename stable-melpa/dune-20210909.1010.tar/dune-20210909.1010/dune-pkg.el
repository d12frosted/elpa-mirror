(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "05653b996b18032a4e80ab71827e7a15601a69d6" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
