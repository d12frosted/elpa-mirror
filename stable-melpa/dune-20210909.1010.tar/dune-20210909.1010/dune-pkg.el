(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d60cfbc0c78bb8733115d9100a8f7f6cb3dcf85b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
