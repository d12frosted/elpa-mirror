(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "add88b50534c49621f312e19754b389abd937735" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
