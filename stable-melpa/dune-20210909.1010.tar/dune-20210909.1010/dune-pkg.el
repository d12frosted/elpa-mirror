(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "570577343946fcb2d43b8519c7807d95f33dc6f7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
