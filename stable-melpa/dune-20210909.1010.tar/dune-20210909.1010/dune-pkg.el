(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "8c19607f75d82ff886da8f596634a4398f3108bf" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
