(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2faa63eb3c85f2a13e834ec81442de20d06fc947" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
