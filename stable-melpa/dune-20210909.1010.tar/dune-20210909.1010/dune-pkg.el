(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "250db8e884ef4feae8b498f8e95737d07f5ee5ec" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
