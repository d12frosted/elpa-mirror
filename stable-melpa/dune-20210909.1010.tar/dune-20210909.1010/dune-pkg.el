(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f3564db95e776f94d3cfcbb1f529f28c8c3b1197" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
