(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "bf7d6ec947a4f70c247dc2c605319daef5a07533" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
