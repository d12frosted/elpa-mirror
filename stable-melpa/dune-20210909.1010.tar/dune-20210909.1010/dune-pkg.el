(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "310037a194c0fa606527cc949c7557a5ee1944a1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
