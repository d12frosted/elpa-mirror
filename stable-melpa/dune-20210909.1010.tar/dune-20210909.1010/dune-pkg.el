(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "4060ee0f13866916336f4ba2c14fa836c9ad04da" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
