(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e77162848d80a3f311de14a26312cc0164c025e1" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
