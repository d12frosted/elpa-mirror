(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ac7beaca00d13c49d7a41ee73c44740d066e27b0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
