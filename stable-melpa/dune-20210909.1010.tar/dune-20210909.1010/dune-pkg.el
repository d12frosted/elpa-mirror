(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "796e8b2bb6463227ec050fe854aee16a8f896f9e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
