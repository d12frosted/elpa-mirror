(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7ec4c88e0d5933864ef34f26467da7224799d603" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
