(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "11ba03e13da4b7c0ef64a460a7afc6d328741ea2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
