(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a7f3512a47e2a3762da2e4b216141714c397b3ed" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
