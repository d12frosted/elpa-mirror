(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a1553b28721db261461e77d9f39a86596bb6ac3e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
