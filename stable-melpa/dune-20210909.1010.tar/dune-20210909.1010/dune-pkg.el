(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "67ab9497446f7005e7e5f4266bfd217640fd43a5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
