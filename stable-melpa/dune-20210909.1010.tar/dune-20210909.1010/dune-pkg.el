(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f94ea993fbccbaf3c0940973a99aeb5a554ee4a4" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
