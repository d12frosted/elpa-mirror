(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e6749554905c4bdece381f6621b9e7cd15cc6348" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
