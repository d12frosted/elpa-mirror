(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a169350f5b782556cae18a4985332f86a03fab89" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
