(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "09f9d396b952a4868325843802903f345b75708a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
