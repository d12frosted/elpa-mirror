(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d733ec00542d9ed749c6401226e86b477e958388" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
