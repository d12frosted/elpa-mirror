(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "84a680a642a0f4661562d3b83ee4ab2ad07fd871" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
