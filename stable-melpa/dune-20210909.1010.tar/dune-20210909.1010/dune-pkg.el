(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e34bd64eb5864b809d4220cd56254d6b2740c279" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
