(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "1bca65efabbb7c86240748e0a4dab68f70ff6c09" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
