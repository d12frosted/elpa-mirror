(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "21268b29bcc2257039c404c2ca0912d0594ec8a9" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
