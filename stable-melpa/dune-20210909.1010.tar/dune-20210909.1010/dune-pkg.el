(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "ef1ee9a0d175bb076d0debf917f7c67a3939af6a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
