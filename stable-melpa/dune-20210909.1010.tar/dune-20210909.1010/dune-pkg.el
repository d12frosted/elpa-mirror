(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f19af6c91aefd50dfee07d4b654e828ed3ea5ad5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
