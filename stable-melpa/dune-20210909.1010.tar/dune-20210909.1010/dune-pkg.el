(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "51ef62007ae86507e0117ef033a3519fb5b874d2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
