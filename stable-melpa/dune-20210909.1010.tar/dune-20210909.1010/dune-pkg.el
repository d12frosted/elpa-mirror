(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "377f759957dba9816f1147b3cbe99b8be8e2ea0c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
