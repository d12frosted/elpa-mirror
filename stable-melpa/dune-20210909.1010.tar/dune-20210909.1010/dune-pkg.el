(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "fbcfb2a2cf1c6209b07c693fa7245cb1706f3d4e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
