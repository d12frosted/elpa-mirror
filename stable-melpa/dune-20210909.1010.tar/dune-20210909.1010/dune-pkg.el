(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "eb119800b07f36be13c2f0026cbba38efbe9148a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
