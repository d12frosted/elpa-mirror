(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "eb54e29130d124a11cc4eb561f69bd93fbf365fc" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
