(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "02a51a1318f3bdb9f7b6c016c258d3c9df1c9b9b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
