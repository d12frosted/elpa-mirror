(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "7b0ebb34f424c99c23281d622a18f0cbb9f207b2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
