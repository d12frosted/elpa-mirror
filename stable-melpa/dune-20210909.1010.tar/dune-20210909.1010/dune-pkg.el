(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "2a469ef2487bbb7e58736958dad54f3ceb11871c" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
