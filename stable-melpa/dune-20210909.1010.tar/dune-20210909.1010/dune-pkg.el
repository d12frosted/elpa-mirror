(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "4212804a0a779303181997bc00544fe828264a70" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
