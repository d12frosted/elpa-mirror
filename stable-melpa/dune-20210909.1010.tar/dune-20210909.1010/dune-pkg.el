(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "f6a8203fa779ce0116e25aaaf80783fda820dd12" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
