(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "fd869d7a6abe0595ec64fe1730203d312d6534fd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
