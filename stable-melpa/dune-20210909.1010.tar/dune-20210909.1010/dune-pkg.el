(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a740799d54e79a9d916ec1e1adf17b0103fe0238" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
