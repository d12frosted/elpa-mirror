(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "93a6da637a3db9ef73af71d1cfa4df7588155b9b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
