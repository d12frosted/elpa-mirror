(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "d143300adcaccad15da39215f8c60c1e40856071" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
