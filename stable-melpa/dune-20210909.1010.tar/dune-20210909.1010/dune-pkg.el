(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "522c83807094728c7bfb68888f7b71ca21e29f0d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
