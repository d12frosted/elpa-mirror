(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "e2682ec5774f439f3c6f88c2b62d79ac658d8853" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
