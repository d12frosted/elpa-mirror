(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "b434075b4b8081e8d41d9c81034c4fc765947ca8" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
