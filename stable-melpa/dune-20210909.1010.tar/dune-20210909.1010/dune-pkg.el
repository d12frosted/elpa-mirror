(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "a1dba062cc9f918bf866b4b108dd2ef8530b316b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
