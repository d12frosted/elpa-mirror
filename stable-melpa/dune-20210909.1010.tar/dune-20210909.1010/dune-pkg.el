(define-package "dune" "20210909.1010" "Integration with the dune build system" 'nil :commit "0f3f1729b6e92a25b8ec34b808f08acc277620de" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
