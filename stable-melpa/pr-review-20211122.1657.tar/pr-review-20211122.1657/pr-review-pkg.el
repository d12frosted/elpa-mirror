(define-package "pr-review" "20211122.1657" "Review github PR"
  '((emacs "27.1")
    (magit-section "3.2")
    (magit "3.2")
    (markdown-mode "2.5")
    (ghub "3.5"))
  :commit "0e72eb2e119c67d4f090f3855322eec033b33e36" :authors
  '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainer
  '("Yikai Zhao" . "yikai@z1k.dev")
  :keywords
  '("tools")
  :url "https://github.com/blahgeek/emacs-pr-review")
;; Local Variables:
;; no-byte-compile: t
;; End:
