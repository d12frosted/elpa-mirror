;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scpaste" "20250704.141"
  "Paste to the web via scp."
  '((htmlize "1.39"))
  :url "https://git.sr.ht/~technomancy/scpaste"
  :commit "d10b2e26a7ba931ce49b65f48c5a4b245080e0f5"
  :revdesc "d10b2e26a7ba"
  :keywords '("convenience" "hypermedia"))
