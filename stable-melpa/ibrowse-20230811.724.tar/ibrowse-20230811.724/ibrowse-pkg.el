(define-package "ibrowse" "20230811.724" "Interact with your browser"
  '((emacs "27.1"))
  :commit "83a557c5b26928cb8b2934dccc6d55462e078067" :authors
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainers
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainer
  '("Nicolas Graves" . "ngraves@ngraves.fr")
  :keywords
  '("comm" "data" "files" "tools")
  :url "https://git.sr.ht/~ngraves/ibrowse.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
