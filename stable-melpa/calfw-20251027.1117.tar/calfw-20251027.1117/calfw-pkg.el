;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251027.1117"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "f95fd5ca25a54f461c079d182f56e78b6a49a541"
  :revdesc "f95fd5ca25a5"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
