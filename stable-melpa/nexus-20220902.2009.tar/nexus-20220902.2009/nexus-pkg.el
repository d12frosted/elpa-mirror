(define-package "nexus" "20220902.2009" "REST Client for Nexus Maven Repository servers" 'nil :commit "9f0ddf7d6cb5f7df44f684f02e2bd8a96ecabbd6" :authors
  '(("Juergen Hoetzel" . "juergen@archlinux.org"))
  :maintainer
  '("Juergen Hoetzel" . "juergen@archlinux.org")
  :keywords
  '("comm"))
;; Local Variables:
;; no-byte-compile: t
;; End:
