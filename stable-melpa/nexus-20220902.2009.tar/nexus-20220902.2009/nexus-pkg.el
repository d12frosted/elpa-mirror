;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nexus" "20220902.2009"
  "REST Client for Nexus Maven Repository servers."
  ()
  :url "https://github.com/juergenhoetzel/emacs-nexus"
  :commit "9f0ddf7d6cb5f7df44f684f02e2bd8a96ecabbd6"
  :revdesc "9f0ddf7d6cb5"
  :keywords '("comm")
  :authors '(("Juergen Hoetzel" . "juergen@archlinux.org"))
  :maintainers '(("Juergen Hoetzel" . "juergen@archlinux.org")))
