;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greger" "20250702.1432"
  "Agentic coding environment with tool use, using Claude."
  '((emacs "29.1"))
  :url "https://github.com/andreasjansson/greger.el"
  :commit "c67af3d70e742288b14f14bfaa27e79a67f766a7"
  :revdesc "c67af3d70e74"
  :keywords '("agent" "agentic" "ai" "chat" "language-models" "tools")
  :authors '(("Andreas Jansson" . "andreas@jansson.me.uk"))
  :maintainers '(("Andreas Jansson" . "andreas@jansson.me.uk")))
