;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oauth2-request" "20260516.316"
  "OAuth2 request package interface."
  '((emacs   "27.1")
    (oauth2  "0.14")
    (request "0.3"))
  :url "https://github.com/conao3/oauth2-request.el"
  :commit "9c11c6223ed5c0abc8a210b0e8f827d8b1902a12"
  :revdesc "9c11c6223ed5"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
