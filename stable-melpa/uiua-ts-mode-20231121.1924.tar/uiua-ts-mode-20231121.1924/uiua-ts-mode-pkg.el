(define-package "uiua-ts-mode" "20231121.1924" "Uiua treesiter mode"
  '((emacs "29.1")
    (uiua-mode "0.0.5"))
  :commit "c156f8ec6ac2fe1da95f4fcc981c8f07ea32b20b" :keywords
  '("languages" "uiua")
  :url "https://github.com/crmsnbleyd/uiua-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
