;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261026.1123"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "642dfe2257332d55d5ea258d0d07812c3d571518"
  :revdesc "642dfe225733")
