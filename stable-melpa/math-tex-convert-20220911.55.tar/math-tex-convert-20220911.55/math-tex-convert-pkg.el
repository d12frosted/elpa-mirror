(define-package "math-tex-convert" "20220911.55" "Convert LaTeX macros to unicode and back"
  '((emacs "26.1")
    (math-symbol-lists "1.3")
    (auctex "12.1"))
  :commit "08de142db475cc64b9eda301e2845ead464592d5" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/math-tex-convert")
;; Local Variables:
;; no-byte-compile: t
;; End:
