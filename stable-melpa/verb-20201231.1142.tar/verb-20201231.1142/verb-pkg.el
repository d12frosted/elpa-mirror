(define-package "verb" "20201231.1142" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "9bdad040c342dfd513f0c65bde5d938f41da24e6" :authors
  (("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  ("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  ("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
