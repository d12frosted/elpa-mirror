(define-package "shimbun" "20201021.552" "interfacing with web newspapers" 'nil :commit "9fcc88a9cb2579bec28b6e05ca0ae32222149901" :keywords
  ("news")
  :authors
  (("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
   ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
   ("Yuuichi Teranishi " . "teranisi@gohome.org")
   ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  ("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
