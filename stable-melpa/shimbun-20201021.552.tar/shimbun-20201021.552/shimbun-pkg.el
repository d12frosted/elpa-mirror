(define-package "shimbun" "20201021.552" "interfacing with web newspapers" 'nil :commit "267d4220715eabacca1ad1661d76be5ceed7072c" :keywords
  ("news")
  :authors
  (("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
   ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
   ("Yuuichi Teranishi " . "teranisi@gohome.org")
   ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  ("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
