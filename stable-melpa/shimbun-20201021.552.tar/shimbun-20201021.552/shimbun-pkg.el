(define-package "shimbun" "20201021.552" "interfacing with web newspapers" 'nil :commit "de2dc230990ece43e6771858589337a883265900" :authors
  (("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
   ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
   ("Yuuichi Teranishi " . "teranisi@gohome.org")
   ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  ("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  ("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
