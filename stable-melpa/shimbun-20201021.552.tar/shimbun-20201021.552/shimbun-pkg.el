(define-package "shimbun" "20201021.552" "interfacing with web newspapers" 'nil :commit "a29343b78c1a9c3983d9f3b2a169355100cb7d1a" :authors
  (("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
   ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
   ("Yuuichi Teranishi " . "teranisi@gohome.org")
   ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  ("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  ("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
