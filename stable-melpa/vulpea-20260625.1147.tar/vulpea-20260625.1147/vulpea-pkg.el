;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260625.1147"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "d7cc28608d4b70a66f9acc52f9fd4a80ec46533c"
  :revdesc "d7cc28608d4b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
