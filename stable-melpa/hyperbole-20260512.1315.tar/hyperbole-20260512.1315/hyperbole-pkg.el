;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260512.1315"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "45df4747edf5245a7db4ada6d6e8193e929c2fe2"
  :revdesc "45df4747edf5"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
