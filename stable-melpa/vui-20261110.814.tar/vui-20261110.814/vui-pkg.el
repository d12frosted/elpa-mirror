;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261110.814"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "871f5173a14f209008a9749f2d5a1be851dd4ef9"
  :revdesc "871f5173a14f"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
