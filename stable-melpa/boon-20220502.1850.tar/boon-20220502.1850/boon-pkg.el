(define-package "boon" "20220502.1850" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "db7b6083d390e3febf82f9af5782e1a36d30093c")
;; Local Variables:
;; no-byte-compile: t
;; End:
