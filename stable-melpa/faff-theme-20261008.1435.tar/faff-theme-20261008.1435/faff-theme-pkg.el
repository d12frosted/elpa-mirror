;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20261008.1435"
  "Light cornsilk theme with warm, earthy colors."
  '((emacs        "28.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "165b8f4b9e22e51bc2ec3888120e9b0a9c4483e9"
  :revdesc "165b8f4b9e22"
  :keywords '("faces" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
