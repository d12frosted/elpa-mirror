(define-package "helm-core" "20240411.938" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "620360778573a05be3c59eb3da515f2ed6d06e6c" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
