(define-package "org-ql" "20201212.1209" "Org Query Language, search command, and agenda-like view"
  '((emacs "26.1")
    (dash "2.13")
    (dash-functional "1.2.0")
    (f "0.17.2")
    (map "2.1")
    (org "9.0")
    (org-super-agenda "1.2")
    (ov "1.0.6")
    (peg "1.0")
    (s "1.12.0")
    (transient "0.1")
    (ts "0.2pre"))
  :commit "ec2e624dc2ab04d9bb66e493d3a8fa83c94e3203" :keywords
  ("hypermedia" "outlines" "org" "agenda")
  :authors
  (("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  ("Adam Porter" . "adam@alphapapa.net")
  :url "https://github.com/alphapapa/org-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
