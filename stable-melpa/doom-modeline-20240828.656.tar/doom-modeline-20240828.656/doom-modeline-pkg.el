(define-package "doom-modeline" "20240828.656" "A minimal and modern mode-line"
  '((emacs "25.1")
    (compat "29.1.4.5")
    (nerd-icons "0.1.0")
    (shrink-path "0.3.1"))
  :commit "c6cad997ff18d0e5e1d33ccf01a016fe16537d9a" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
