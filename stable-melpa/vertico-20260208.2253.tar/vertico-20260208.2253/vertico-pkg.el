;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20260208.2253"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "8f75f18b01ce9baa392469104a3c7dd08c3a608d"
  :revdesc "8f75f18b01ce"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
