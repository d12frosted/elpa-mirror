(define-package "lister" "20211021.1715" "Yet another list printer"
  '((emacs "26.1"))
  :commit "6422e2c97ce426621cbeac5a5ed726e33236441d" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
