;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-wk" "20191231.2058"
  "Wiki Back-End for Org Export Engine."
  '((emacs "24.4")
    (org   "8.3"))
  :url "https://github.com/w-vi/ox-wk.el"
  :commit "d34d1b72e4e940745a377bfa745dfb618900a09e"
  :revdesc "d34d1b72e4e9"
  :keywords '("org" "wp" "wiki")
  :authors '(("Vilibald Wanča" . "vilibald@wvi.cz"))
  :maintainers '(("Vilibald Wanča" . "vilibald@wvi.cz")))
