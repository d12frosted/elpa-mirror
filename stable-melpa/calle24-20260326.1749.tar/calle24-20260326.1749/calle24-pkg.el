;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calle24" "20260326.1749"
  "Emacs Toolbar Support for SF Symbols."
  '((emacs "29.1"))
  :url "https://github.com/kickingvegas/calle24"
  :commit "1ebc385496a600ee492df4abd55cbf7b899145d5"
  :revdesc "1ebc385496a6"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
