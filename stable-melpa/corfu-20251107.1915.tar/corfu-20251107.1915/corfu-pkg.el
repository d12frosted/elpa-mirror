;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251107.1915"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "31ff155688944126168c00ce205b8410004b5082"
  :revdesc "31ff15568894"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
