(define-package "smartparens" "20240629.1313" "Automatic insertion, wrapping and paredit-like navigation with user defined pairs."
  '((dash "2.13.0")
    (cl-lib "0.3"))
  :commit "470451b12fd89eebd641fda7acb2adb1e2afa97f" :authors
  '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matus Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("abbrev" "convenience" "editing")
  :url "https://github.com/Fuco1/smartparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
