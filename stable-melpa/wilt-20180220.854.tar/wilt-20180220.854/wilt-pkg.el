;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wilt" "20180220.854"
  "An extensions for calculating WILT in a buffer."
  '((emacs "24.3")
    (dash  "2.12.0")
    (s     "1.10.0"))
  :url "https://github.com/sixty-north/emacs-wilt"
  :commit "04dbe37fa35d0b24c791421785d2c97a8cbfe2cc"
  :revdesc "04dbe37fa35d"
  :authors '(("Austin Bingham" . "austin@sixty-north.com"))
  :maintainers '(("Austin Bingham" . "austin@sixty-north.com")))
