(define-package "modus-themes" "20210120.1942" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "da9d119b8388db41a93abc5e08769c0f19593701" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
