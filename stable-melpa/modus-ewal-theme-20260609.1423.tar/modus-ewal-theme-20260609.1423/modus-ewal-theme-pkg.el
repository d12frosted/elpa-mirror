;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-ewal-theme" "20260609.1423"
  "Modus theme that uses pywal colors powered by ewal."
  '((emacs        "25.1")
    (modus-themes "5.2.0")
    (ewal         "0.2.1"))
  :url "https://github.com/deadendpl/modus-ewal-theme"
  :commit "2856520a2474b3d5fddae64001817d6cecf3da51"
  :revdesc "2856520a2474"
  :keywords '("faces" "theme")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
