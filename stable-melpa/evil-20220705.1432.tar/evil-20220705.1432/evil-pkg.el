(define-package "evil" "20220705.1432" "Extensible Vi layer for Emacs."
  '((emacs "24.1")
    (goto-chg "1.6")
    (cl-lib "0.5"))
  :commit "f64cdca60ad55b0a5f77c0fc38f82d42822f88b3" :maintainer
  '("Tom Dalziel" . "tom.dalziel@gmail.com")
  :keywords
  '("emulation" "vim")
  :url "https://github.com/emacs-evil/evil")
;; Local Variables:
;; no-byte-compile: t
;; End:
