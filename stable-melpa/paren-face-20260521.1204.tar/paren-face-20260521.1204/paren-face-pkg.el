;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paren-face" "20260521.1204"
  "A face for parentheses in lisp modes."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/paren-face"
  :commit "a836c873df68c82e56a258fbdb2f912d1061baa5"
  :revdesc "a836c873df68"
  :keywords '("faces" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")))
