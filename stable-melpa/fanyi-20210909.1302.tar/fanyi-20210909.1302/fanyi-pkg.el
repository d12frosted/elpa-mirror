(define-package "fanyi" "20210909.1302" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "fe06fc86311c5a9c9f49994dc8b44288187147a2" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
