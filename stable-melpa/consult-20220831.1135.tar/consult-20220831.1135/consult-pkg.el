(define-package "consult" "20220831.1135" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "d949871387cb5d9f659b30aa23524c4c22ab3742" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
