(define-package "consult" "20220620.2036" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "1ddc88fd982a95f01425e618ba628f1e65c7f870" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
