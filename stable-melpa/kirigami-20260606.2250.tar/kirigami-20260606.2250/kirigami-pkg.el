;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260606.2250"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "ecbd63577a1f41abfbc330bc9e3a448e482be197"
  :revdesc "ecbd63577a1f"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
