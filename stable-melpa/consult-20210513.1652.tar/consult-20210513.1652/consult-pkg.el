(define-package "consult" "20210513.1652" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "2fa38ea883a6502a4fe192aa1c26e35293fe1834" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
