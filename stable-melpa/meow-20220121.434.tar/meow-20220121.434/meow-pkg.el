(define-package "meow" "20220121.434" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "279f0b0b5ed5167a185b848f08cc9fe6b6cf1b36" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
