;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260215.1732"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "1c32a82468416a0ef3ea3bb1839c6708eabb6ce9"
  :revdesc "1c32a8246841"
  :keywords '("languages"))
