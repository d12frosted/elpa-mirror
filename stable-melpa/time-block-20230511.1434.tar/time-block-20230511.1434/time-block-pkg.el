;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-block" "20230511.1434"
  "Block running commands using time."
  '((emacs "25.1")
    (ts    "0.1"))
  :url "https://git.sr.ht/~swflint/time-block-command"
  :commit "0fdb488c3fa3da2934ee486613f5bf46712b97d6"
  :revdesc "0fdb488c3fa3"
  :keywords '("tools" "productivity" "convenience")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
