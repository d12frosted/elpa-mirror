(define-package "cnfonts" "20211201.839" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "3ab0a6100f7cd9f119edc9815f270b1e1e6748b5" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
