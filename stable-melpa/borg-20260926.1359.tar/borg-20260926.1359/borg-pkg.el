;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260926.1359"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "07c305e426f83b607911f2ac4cfedab6aae2b47b"
  :revdesc "07c305e426f8"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
