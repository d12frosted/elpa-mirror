;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260602.427"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "5e22461763c96f84c7f4cbdb4fa9ca35de02d5e8"
  :revdesc "5e22461763c9")
