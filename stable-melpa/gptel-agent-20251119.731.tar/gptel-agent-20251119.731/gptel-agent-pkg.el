;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20251119.731"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "6c1185bd44d6f159729885956c2943b8562b867b"
  :revdesc "6c1185bd44d6"
  :keywords '("comm"))
