;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gf" "20181028.1542"
  "Major mode for editing GF code."
  '((s  "1.0")
    (ht "2.0"))
  :url "https://github.com/GrammaticalFramework/gf-emacs-mode"
  :commit "49fa46db67634530499be969ffd3c436a22d4404"
  :revdesc "49fa46db6763"
  :keywords '("languages")
  :authors '(("Johan Bockgård" . "bojohan+mail@dd.chalmers.se"))
  :maintainers '(("bruno cuconato" . "bcclaro+emacs@gmail.com")))
