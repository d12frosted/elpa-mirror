;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comment-or-uncomment-sexp" "20190225.1122"
  "Command for commenting the sexp under point."
  '((emacs "24"))
  :url "https://github.com/Malabarba/comment-or-uncomment-sexp"
  :commit "bec730d3fc1e6c17ff1339eb134af16c034a4d95"
  :revdesc "bec730d3fc1e"
  :keywords '("convenience")
  :authors '(("Artur Malabarba" . "artur@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "artur@endlessparentheses.com")))
