;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edebug-x" "20130616.625"
  "Extensions for Edebug."
  ()
  :url "https://github.com/ScottyB/edebug-x"
  :commit "a2c2c42553d3bcbd5ac11898554865acbed1bc46"
  :revdesc "a2c2c42553d3"
  :keywords '("extensions")
  :authors '(("Scott Barnett" . "scott.n.barnett@gmail.com"))
  :maintainers '(("Scott Barnett" . "scott.n.barnett@gmail.com")))
