;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "20260918.2040"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "138103dbf7bea1d37b389d4d5b29e252b6144966"
  :revdesc "138103dbf7be"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
