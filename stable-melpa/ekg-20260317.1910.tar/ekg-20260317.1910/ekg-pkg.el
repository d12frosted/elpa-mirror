;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260317.1910"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "90a8931cc14a86a68b6884445dc3f25a8b5d948b"
  :revdesc "90a8931cc14a"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
