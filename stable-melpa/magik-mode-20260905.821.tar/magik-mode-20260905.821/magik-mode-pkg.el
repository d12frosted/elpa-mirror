;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260905.821"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "75245de0543f2b8fd3c740a7ab0d2b2d2d336d8b"
  :revdesc "75245de0543f"
  :keywords '("languages"))
