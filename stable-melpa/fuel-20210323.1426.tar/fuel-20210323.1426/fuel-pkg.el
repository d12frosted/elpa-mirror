(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "6d7be14741ff6988e42dee75abc4fbb2a85d473b")
;; Local Variables:
;; no-byte-compile: t
;; End:
