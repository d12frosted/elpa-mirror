(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3c54d39f2b913d831a0b497b093001850abdc5fd")
;; Local Variables:
;; no-byte-compile: t
;; End:
