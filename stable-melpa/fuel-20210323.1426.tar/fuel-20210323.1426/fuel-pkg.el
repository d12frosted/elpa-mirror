(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5bfeab6c0e13bfefddb98b30b6e60489a1574d8e")
;; Local Variables:
;; no-byte-compile: t
;; End:
