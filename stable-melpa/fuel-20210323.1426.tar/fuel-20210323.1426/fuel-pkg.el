(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ffb2239b144c0d3b617266bf6a23c30a458bcb66")
;; Local Variables:
;; no-byte-compile: t
;; End:
