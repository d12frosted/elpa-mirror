(define-package "spdx" "20210810.1723" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "1a623ea518c4fa7af37181eb15b8afd6197e3d93" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
