;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250705.2349"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (mozc           "0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "af6c53ed79f6df61e77d40207f942190cf6459e6"
  :revdesc "af6c53ed79f6"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
