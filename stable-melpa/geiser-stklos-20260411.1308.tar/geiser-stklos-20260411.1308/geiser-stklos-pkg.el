;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-stklos" "20260411.1308"
  "STklos Scheme implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.16"))
  :url "https://gitlab.com/emacs-geiser/stklos"
  :commit "eb8f6d53ec5c4520c590572182f66efa51faf74c"
  :revdesc "eb8f6d53ec5c"
  :keywords '("languages" "stklos" "scheme" "geiser")
  :authors '(("Jeronimo Pellegrini" . "(j_p@aleph0.info)"))
  :maintainers '(("Jeronimo Pellegrini" . "(j_p@aleph0.info)")))
