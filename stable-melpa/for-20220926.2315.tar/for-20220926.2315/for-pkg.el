(define-package "for" "20220926.2315" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "87d903142abbc10e466e3561182343ea805e2b20" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
