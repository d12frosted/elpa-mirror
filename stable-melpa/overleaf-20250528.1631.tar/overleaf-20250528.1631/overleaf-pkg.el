;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250528.1631"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "68fbdeaf0e9947deb258a1378406d7ee9fbd7376"
  :revdesc "68fbdeaf0e99"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
