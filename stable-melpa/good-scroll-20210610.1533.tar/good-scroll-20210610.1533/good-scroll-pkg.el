(define-package "good-scroll" "20210610.1533" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "21a1c66ba0666310c4888179397fb9aebcb69018" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
