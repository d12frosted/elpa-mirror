;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-x" "20260726.1808"
  "Extra convenience features for project.el."
  '((emacs "28.1"))
  :url "https://github.com/vmargb/project-x"
  :commit "bfdc18435d0f224bfa4eb3dda2ebb9690f2ebfa3"
  :revdesc "bfdc18435d0f"
  :keywords '("project" "convenience" "session" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("vmargb" . "https://github.com/vmargb")))
