(define-package "good-scroll" "20210712.1206" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "fac87dd390ad2aabe48afaef950f7a2d9b3ce283" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
