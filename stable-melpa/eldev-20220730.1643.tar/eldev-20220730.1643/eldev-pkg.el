(define-package "eldev" "20220730.1643" "Elisp development tool"
  '((emacs "24.4"))
  :commit "545412826f199cacdd5b4e937a719cc428e479be" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
