;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260219.1627"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "36de4bd8167bb9ee84e7316c7f2a5210a41c1d54"
  :revdesc "36de4bd8167b")
