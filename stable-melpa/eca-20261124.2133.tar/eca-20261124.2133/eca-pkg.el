;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20261124.2133"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "1c68f5ff5dd0c3c4a2fe1a7966c25746b61f53c2"
  :revdesc "1c68f5ff5dd0"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
