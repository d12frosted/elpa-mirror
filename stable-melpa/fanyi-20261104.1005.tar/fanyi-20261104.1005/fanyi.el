;;; fanyi.el --- Not only English-Chinese translator -*- lexical-binding: t -*-

;; Copyright (C) 2021 Zhiwei Chen
;; SPDX-License-Identifier: GPL-3.0-or-later
;; Author: Zhiwei Chen <condy0919@gmail.com>
;; Keywords: convenience, tools
;; URL: https://github.com/condy0919/fanyi.el
;; Package-Version: 20261104.1005
;; Package-Revision: 59058538adde
;; Package-Requires: ((emacs "29.1"))

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; A multi dictionaries interface for Emacs.
;;
;; Invoke `fanyi-dwim', `fanyi-dwim2' or `fanyi-from-history' to see the
;; results.

;;; Code:

(require 'subr-x)
(require 'seq)
(require 'url)
(require 'imenu)
(require 'button)
(require 'cl-lib)
(require 'outline)
(require 'eldoc)

(require 'fanyi-base)
(require 'fanyi-shr)

(defgroup fanyi nil
  "Not only English-Chinese translator for Emacs."
  :prefix "fanyi-"
  :group 'tools
  :link '(url-link "https://github.com/condy0919/fanyi.el"))

(defface fanyi-word-face
  '((t :height 1.75 :weight bold :foreground "dark cyan"))
  "Face used for user requested word."
  :group 'fanyi)

(defface fanyi-dict-face
  '((t :height 1.25 :weight bold :foreground "#ecbe7b" :extend t))
  "Face used for dictionary name."
  :group 'fanyi)

(defface fanyi-sub-headline-face
  '((t :weight bold :foreground "#a9a1e1" :extend t))
  "Face used for sub-headline. Normally it's part of speech."
  :group 'fanyi)

(defface fanyi-list-face
  '((t :foreground "#51afef"))
  "Face used for list."
  :group 'fanyi)

(defface fanyi-quote-face
  '((t :inherit font-lock-comment-face))
  "Face used for quotes of word."
  :group 'fanyi)

(defface fanyi-pos-face
  '((t :foreground "green"))
  "Face used for part of speech."
  :group 'fanyi)

(defface fanyi-tasks-pending-face
  '((t :foreground "yellow"))
  "Face used for tasks still pending."
  :group 'fanyi)

(defface fanyi-tasks-failed-face
  '((t :foreground "red"))
  "Face used for tasks failed."
  :group 'fanyi)

(defface fanyi-tasks-completed-face
  '((t :foreground "green"))
  "Face used for tasks completed."
  :group 'fanyi)

(defcustom fanyi-providers '(fanyi-haici-provider
                             fanyi-etymon-provider
                             fanyi-longman-provider
                             fanyi-youdao-thesaurus-provider)
  "Dictionary provider symbols used by `fanyi-dwim'.
Changes take effect on the next query, including changes made with `setq'.
Providers are loaded when a query starts, and each lookup gets a separate
request and result.  `fanyi-provider' records are also accepted."
  :type '(repeat symbol)
  :group 'fanyi)

(defun fanyi--resolve-provider (provider)
  "Load PROVIDER if needed and return its configuration."
  (let ((configuration provider))
    (when (symbolp provider)
      (unless (boundp provider)
        (let ((name (symbol-name provider)))
          (unless (and (string-suffix-p "-provider" name)
                       (require (intern (substring name 0 -9)) nil t))
            (user-error "Cannot load dictionary provider: %S" provider))))
      (setq configuration (symbol-value provider)))
    (unless (fanyi-provider-p configuration)
      (user-error "Not a dictionary provider: %S" provider))
    configuration))

(defcustom fanyi-headline-max-length 30
  "The maximum displayed length of `fanyi-current-word'."
  :type 'integer
  :group 'fanyi)

(defcustom fanyi-auto-select t
  "Non-nil means select fanyi window."
  :type 'boolean
  :group 'fanyi)

(defcustom fanyi-request-timeout 15
  "Maximum seconds to wait for each dictionary request.
Nil disables the timeout."
  :type '(choice (const :tag "No timeout" nil)
                 (number :tag "Seconds"))
  :group 'fanyi)

(defcustom fanyi-navigation-history-length 20
  "Maximum cached lookups retained by the current result buffer.
This bounds the total of past and future pages, excluding the current page.
Zero disables caching.  Back/forward reuse parsed results; unfinished requests
restart when revisited.  New queries discard the forward history."
  :type 'natnum
  :group 'fanyi)

(defvar-local fanyi--back-history nil
  "Previous result pages, nearest first.")
(defvar-local fanyi--forward-history nil
  "Next result pages, nearest first.")

(cl-defstruct (fanyi--page (:constructor fanyi--page-create))
  word tasks view)

(defvar fanyi-history nil
  "History list for `fanyi-dwim' and `fanyi-dwim2'.")

;; Silence compile warnings.
(defvar url-http-end-of-headers)

(defvar-local fanyi--buffer-query-id 0
  "Query generation owned by this result buffer.")

(defvar-local fanyi--tasks nil
  "Tasks belonging to this query, in reverse provider configuration order.")
(defvar-local fanyi--tasks-failed 0)
(defvar-local fanyi--tasks-completed 0)

(defvar fanyi--active-buffer nil
  "Result buffer whose query supersedes the previous pending query.")

(defvar fanyi--query-id 0
  "Counter assigning query generations to result buffers.")

(defvar-local fanyi-current-word nil
  "Original query text displayed in this result buffer.")

(defvar-local fanyi--font-lock-provider-keywords nil
  "Provider keywords installed in this buffer's font-lock configuration.")

(cl-defstruct (fanyi--task (:constructor fanyi--make-task))
  "One request with a single lifecycle STATE.
STATE is pending, succeeded, not-found, failed or cancelled.  FAILURE holds
an error description; while pending, it can retain the error being retried."
  query-id request result result-buffer buffer timer (state 'pending) failure start end)

(defun fanyi--task-done (task)
  "Whether TASK no longer awaits a response."
  (not (eq (fanyi--task-state task) 'pending)))

(defun fanyi--update-task-counts ()
  "Recompute displayed totals from this buffer's task states."
  (setq fanyi--tasks-completed
        (cl-count-if (lambda (task) (memq (fanyi--task-state task) '(succeeded not-found)))
                     fanyi--tasks)
        fanyi--tasks-failed (cl-count 'failed fanyi--tasks :key #'fanyi--task-state)))

(defun fanyi--set-task-state (task state &optional failure)
  "Set TASK's STATE and FAILURE detail, updating its timer and buffer totals."
  (setf (fanyi--task-state task) state
        (fanyi--task-failure task) failure)
  (unless (eq state 'pending) (fanyi--stop-task-timer task))
  (when (buffer-live-p (fanyi--task-result-buffer task))
    (with-current-buffer (fanyi--task-result-buffer task)
      (fanyi--update-task-counts)))
  (force-mode-line-update t))

(defun fanyi--task-active-p (task)
  "Return non-nil if TASK still belongs to the current pending query."
  (and (not (fanyi--task-done task))
       (buffer-live-p (fanyi--task-result-buffer task))
       (with-current-buffer (fanyi--task-result-buffer task)
         (and (derived-mode-p 'fanyi-mode)
              (= (fanyi--task-query-id task) fanyi--buffer-query-id)
              (memq task fanyi--tasks)))))

(defun fanyi--stop-task-timer (task)
  "Cancel TASK's timeout timer."
  (when (fanyi--task-timer task)
    (cancel-timer (fanyi--task-timer task))
    (setf (fanyi--task-timer task) nil)))

(defun fanyi--cancel-task (task)
  "Cancel the network request associated with TASK."
  ;; Invalidate first: deleting a process can invoke its callback.
  (when (eq (fanyi--task-state task) 'pending)
    (fanyi--set-task-state task 'cancelled (fanyi--task-failure task)))
  (fanyi--stop-task-timer task)
  (let ((buffer (fanyi--task-buffer task)) seen)
    (while (and (buffer-live-p buffer) (not (memq buffer seen)))
      (push buffer seen)
      (let ((next (buffer-local-value 'url-redirect-buffer buffer))
            (process (get-buffer-process buffer)))
        (when process
          (delete-process process))
        (kill-buffer buffer)
        (setq buffer next)))))

(defun fanyi--cancel-buffer-tasks ()
  "Cancel tasks owned by the result buffer being killed or changing mode."
  (let ((retries (cl-remove-if-not
                  (lambda (task) (and (not (fanyi--task-done task))
                                      (fanyi--task-failure task)))
                  fanyi--tasks)))
    ;; Invalidate every callback before cancelling any network process.
    (dolist (task fanyi--tasks)
      (when (eq (fanyi--task-state task) 'pending)
        (fanyi--set-task-state task 'cancelled (fanyi--task-failure task))))
    (mapc #'fanyi--cancel-task fanyi--tasks)
    (dolist (task retries)
      (fanyi--restore-retry-failure task))))

(defun fanyi--restore-retry-failure (task)
  "Restore the unresolved failure when TASK's retry is cancelled."
  (with-current-buffer (fanyi--task-result-buffer task)
    (fanyi--set-task-state task 'failed (fanyi--task-failure task))
    (fanyi--write-task-error task "Retry cancelled")))

(defun fanyi--quit-task (task condition)
  "Cancel TASK's resources and propagate the original quit CONDITION."
  (unwind-protect
      (let ((inhibit-quit t)
            (pending (fanyi--task-active-p task)))
        (fanyi--cancel-task task)
        ;; An interrupted retry leaves its original failure unresolved.
        (when (and pending (fanyi--task-failure task))
          (fanyi--restore-retry-failure task))
        (force-mode-line-update t))
    (signal (car condition) (cdr condition))))

(defun fanyi--replace-task-region (task writer)
  "Replace TASK's existing output region with WRITER's output atomically."
  (with-current-buffer (fanyi--task-result-buffer task)
    (save-excursion
      (save-restriction
        (widen)
        (let ((start (marker-position (fanyi--task-start task)))
              (end (marker-position (fanyi--task-end task)))
              (inhibit-read-only t))
          (narrow-to-region start end)
          (condition-case err
              (atomic-change-group
                (delete-region (point-min) (point-max))
                (goto-char (point-min))
                (funcall writer))
            ((error quit)
             ;; Undo restores text, but insertion-type markers need their
             ;; original boundaries before the failure can replace this area.
             (set-marker (fanyi--task-start task) start)
             (set-marker (fanyi--task-end task) end)
             (signal (car err) (cdr err))))
          (let ((inhibit-quit t))
            (set-marker (fanyi--task-start task) start)
            (set-marker (fanyi--task-end task) (point-max))))))))

(defun fanyi--write-task (task writer)
  "Write TASK's output in provider order, preserving other dictionaries."
  (with-current-buffer (fanyi--task-result-buffer task)
    (unless (fanyi--task-start task)
      (save-restriction
        (widen)
        ;; Tasks are stored in reverse order.  The last rendered task before
        ;; this one in that list is its nearest displayed successor.
        (let ((following (cl-loop for other in fanyi--tasks
                                  until (eq other task)
                                  when (fanyi--task-start other)
                                  collect (fanyi--task-start other))))
          (let ((start (or (car (last following)) (point-max))))
            (setf (fanyi--task-start task) (copy-marker start t)
                  (fanyi--task-end task) (copy-marker start))))))
    (let* ((end (marker-position (fanyi--task-end task)))
           ;; A narrowed view ending before this output must not absorb it,
           ;; including when a new dictionary is appended at the buffer end.
           (preceding-bounds
            (when (and (buffer-narrowed-p) (= (point-max) (fanyi--task-start task)))
              (cons (copy-marker (point-min)) (copy-marker (point-max)))))
           ;; Ordinary markers already follow edits elsewhere.  At the shared
           ;; boundary, keep readers on the following text; a selection's upper
           ;; endpoint stays before inserted text so its contents do not grow.
           (boundary (and (< end (point-max)) (copy-marker end t)))
           (point-follows (and boundary (= (point) end)
                               (not (and mark-active (mark t) (< (mark) (point))))))
           (mark-follows (and boundary mark-active (mark t)
                              (= (mark) end) (<= (mark) (point))))
           (lower-follows (and boundary (buffer-narrowed-p) (= (point-min) end)))
           (windows (and boundary
                         (mapcar (lambda (window)
                                   (list window
                                         (and (= (window-point window) end)
                                              (not (and mark-active (mark t)
                                                        (< (mark) (window-point window)))))
                                         (= (window-start window) end)))
                                 (get-buffer-window-list (current-buffer) nil t))))
           (deactivate-mark deactivate-mark)
           (mark-active mark-active))
      (unwind-protect
          (fanyi--replace-task-region task writer)
        (let ((inhibit-quit t))
          ;; Empty output, including an interrupted initial render, owns no
          ;; region.  Its coincident markers would split on the next insert.
          (when (= (fanyi--task-start task) (fanyi--task-end task))
            (set-marker (fanyi--task-start task) nil)
            (set-marker (fanyi--task-end task) nil)
            (setf (fanyi--task-start task) nil (fanyi--task-end task) nil))
          (when preceding-bounds
            (narrow-to-region (car preceding-bounds) (cdr preceding-bounds))
            (set-marker (car preceding-bounds) nil)
            (set-marker (cdr preceding-bounds) nil))
          (when boundary
            (when lower-follows (narrow-to-region boundary (point-max)))
            (when point-follows (goto-char boundary))
            (when mark-follows (set-marker (mark-marker) boundary))
            (dolist (state windows)
              (when (window-live-p (car state))
                (when (nth 1 state) (set-window-point (car state) boundary))
                (when (nth 2 state) (set-window-start (car state) boundary t))))
            (set-marker boundary nil)))))))

(defun fanyi--write-task-error (task description)
  "Replace TASK's output with DESCRIPTION and its current retry action."
  (fanyi--write-task
   task
   (lambda ()
     (let ((name (fanyi-request-display-name (fanyi--task-request task))))
       (insert "# " name "\n\n" description "\n\n")
       (insert-button (if (fanyi--task-done task) "Retry dictionary" "Retrying dictionary…")
                      'action #'fanyi--retry-task 'button-data task 'follow-link t)
       (insert "\n\n")))))

(defun fanyi--report-task-error (task description)
  "Display TASK's failure DESCRIPTION and a retry action."
  (let ((name (fanyi-request-display-name (fanyi--task-request task))))
    (fanyi-log "%s: %s" name description)
    (when fanyi-verbose (message "%s: %s" name description)))
  (fanyi--write-task-error task description))

(defun fanyi--retry-task (task)
  "Retry a failed TASK in its original buffer using its request snapshot."
  (when (buffer-live-p (fanyi--task-result-buffer task))
    (with-current-buffer (fanyi--task-result-buffer task)
      ;; Replaced buttons and callbacks must never start a duplicate attempt.
      (when (and (derived-mode-p 'fanyi-mode) (memq task fanyi--tasks)
                 (eq (fanyi--task-state task) 'failed)
                 (= (fanyi--task-query-id task) fanyi--buffer-query-id))
        (fanyi--spawn (fanyi--task-request task) (current-buffer) task)))))

(defun fanyi--finish-task (task &optional failure outcome)
  "Settle pending TASK with FAILURE or successful OUTCOME, reporting new errors.
OUTCOME defaults to succeeded; parsers can instead report not-found.
Cached results update state without calling this request-settlement function."
  (when (fanyi--task-active-p task)
    (fanyi--set-task-state task (if failure 'failed (or outcome 'succeeded)) failure)
    (when failure (fanyi--report-task-error task failure))))

(defun fanyi--timeout (task)
  "Fail and cancel TASK if its response has not arrived."
  (when (fanyi--task-active-p task)
    (unwind-protect
        (fanyi--finish-task task "Request timed out")
      (fanyi--cancel-task task))))

(defun fanyi--write-task-result (task)
  "Insert TASK's parsed result without changing its lifecycle state."
  (fanyi--write-task
   task (lambda () (fanyi-render-result (fanyi--task-request task) (fanyi--task-result task)))))

(defun fanyi--render-task (task)
  "Render TASK's result atomically and mark it complete."
  (when (fanyi--task-active-p task)
    (fanyi--write-task-result task)
    (fanyi--finish-task task)))

(defun fanyi--write-not-found (task)
  "Insert TASK's empty-result message without settling or reporting an error."
  (fanyi--write-task
   task (lambda ()
          (insert "# " (fanyi-request-display-name (fanyi--task-request task))
                  "\n\nNo results found.\n\n"))))

(defun fanyi--render-not-found (task)
  "Display TASK's normal empty result and mark it complete."
  (when (fanyi--task-active-p task)
    (fanyi--write-not-found task)
    (fanyi--finish-task task nil 'not-found)))

(defun fanyi--handle-response (task url status)
  "Parse and render TASK's response from URL with retrieval STATUS."
  (let ((response-buffer (current-buffer))
        (request (fanyi--task-request task)))
    (unwind-protect
        (when (fanyi--task-active-p task)
          (condition-case err
              (progn
                ;; An empty status is success.  Redirects are followed by
                ;; url.el and are not failures unless accompanied by :error.
                (when (plist-member status :error)
                  (error "Request failed: %S" (plist-get status :error)))
                (unless (and (bound-and-true-p url-http-end-of-headers)
                             (integer-or-marker-p url-http-end-of-headers)
                             (<= (point-min) url-http-end-of-headers)
                             (< url-http-end-of-headers (point-max)))
                  (error "Invalid HTTP response"))
                (goto-char (1+ url-http-end-of-headers))
                (let ((response (pcase (fanyi-request-api-type request)
                                  ('xml (libxml-parse-html-region (point) (point-max) url))
                                  ('json (json-parse-buffer))
                                  (_ (error "Unsupported response format")))))
                  (if (catch 'not-found
                        (setf (fanyi--task-result task)
                              (fanyi-parse-response request response))
                        t)
                      (fanyi--render-task task)
                    (fanyi--render-not-found task))))
            (error (fanyi--finish-task task (error-message-string err)))
            (quit (fanyi--quit-task task err))))
      (fanyi--cleanup-response response-buffer)
      (fanyi--cleanup-response (fanyi--task-buffer task)))))

(defun fanyi--spawn (request result-buffer &optional replacing)
  "Start REQUEST in RESULT-BUFFER, optionally REPLACING a failed attempt."
  (let ((task (fanyi--make-task
               :query-id (buffer-local-value 'fanyi--buffer-query-id result-buffer)
               :request request :result-buffer result-buffer)))
    ;; Register before starting the request: a callback may run immediately.
    (with-current-buffer result-buffer
      (if (not replacing)
          (push task fanyi--tasks)
        (setf (fanyi--task-start task) (copy-marker (fanyi--task-start replacing) t)
              (fanyi--task-end task) (copy-marker (fanyi--task-end replacing))
              (fanyi--task-failure task) (fanyi--task-failure replacing))
        (setq fanyi--tasks (cl-substitute task replacing fanyi--tasks :test #'eq))
        (set-marker (fanyi--task-start replacing) nil)
        (set-marker (fanyi--task-end replacing) nil))
      (fanyi--update-task-counts))
    (fanyi--start-task task)))

(defun fanyi--start-task (task)
  "Start an already registered TASK, retaining its resolved request settings."
  (let ((request (fanyi--task-request task)))
    (condition-case err
        (progn
          (when (fanyi--task-failure task)
            (fanyi--write-task-error task (fanyi--task-failure task)))
          (if (eq (fanyi-request-api-type request) 'browser)
              (fanyi--render-task task)
            (let ((url (fanyi-request-url request))
                  (url-request-method (fanyi-request-method request))
                  (url-request-extra-headers (fanyi-request-headers request))
                  (url-request-data (fanyi-request-body request)))
              (setf (fanyi--task-buffer task)
                    (url-retrieve url
                                  (lambda (status)
                                    (fanyi--handle-response task url status))
                                  nil t t))
              (cond
               ((fanyi--task-done task)
                ;; The callback may have completed before url-retrieve returned.
                (fanyi--cleanup-response (fanyi--task-buffer task)))
               ((not (buffer-live-p (fanyi--task-buffer task)))
                (error "Could not start request"))
               (fanyi-request-timeout
                (setf (fanyi--task-timer task)
                      (run-at-time fanyi-request-timeout nil #'fanyi--timeout task)))))))
      (error
       (unwind-protect
           (fanyi--finish-task task (error-message-string err))
         (fanyi--cancel-task task)))
      (quit (fanyi--quit-task task err)))
    task))

(defun fanyi-format-header-line ()
  "Used as `header-line-format'."
  (let ((pending (cl-count 'pending fanyi--tasks :key #'fanyi--task-state))
        (cancelled (cl-count 'cancelled fanyi--tasks :key #'fanyi--task-state))
        (truncated (if (> (length fanyi-current-word) fanyi-headline-max-length)
                       (concat (substring fanyi-current-word 0 fanyi-headline-max-length) "...")
                     (or fanyi-current-word ""))))
    (concat (cond ((> pending 0) "Translating ")
                  ((> cancelled 0) "Incomplete: ")
                  (t "Ready: "))
            ;; Header strings returned by :eval still interpret percent forms.
            ;; Escape only the displayed text, after applying the query limit.
            (propertize (replace-regexp-in-string "%" "%%" truncated t t)
                        'face 'fanyi-word-face)
            " "
            (propertize (format "Pending %d" pending)
                        'face 'fanyi-tasks-pending-face 'help-echo "Pending dictionaries")
            " "
            (propertize (format "Done %d" fanyi--tasks-completed)
                        'face 'fanyi-tasks-completed-face
                        'help-echo "Completed dictionaries, including empty results")
            " "
            (propertize (format "Failed %d" fanyi--tasks-failed)
                        'face 'fanyi-tasks-failed-face 'help-echo "Failed dictionaries")
            (when (> cancelled 0)
              (propertize (format " Cancelled %d" cancelled) 'face 'shadow
                          'help-echo "Cancelled dictionaries; refresh or revisit to resume")))))

(defun fanyi-eldoc-function (_callback &rest _ignored)
  "Return help at point for `fanyi-mode' ElDoc."
  (get-char-property (point) 'help-echo))

(defun fanyi--font-lock-search (regexp limit)
  "Search for REGEXP before LIMIT outside rendered HTML.
HTML providers supply their own semantic `font-lock-face' properties.
Confining each search to one text region also prevents matches from
crossing into HTML and consuming delimiters in a later dictionary."
  (let (found)
    (while (and (< (point) limit) (not found))
      (let ((end (next-single-property-change (point) 'fanyi-html nil limit)))
        (if (get-text-property (point) 'fanyi-html)
            (goto-char end)
          (setq found (re-search-forward regexp end t))
          (unless found (goto-char end)))))
    found))

(defvar fanyi-mode-font-lock-keywords
  (append
   '(;; Dictionary name
     ("^# .*" 0 (list 'face 'fanyi-dict-face
                      'keymap fanyi-mode-cycle-map))
     ;; Keep HTML heading styles and the common folding keymap.
     ("^## .*" 0 (list 'face
                       (unless (and (get-text-property (match-beginning 0) 'fanyi-html)
                                    (get-text-property (match-beginning 0) 'font-lock-face))
                         'fanyi-sub-headline-face)
                       'keymap fanyi-mode-cycle-map)))
   (mapcar (lambda (rule)
             (list (apply-partially #'fanyi--font-lock-search (car rule))
                   0 (list 'quote (cdr rule))))
           '(("^> .*" . fanyi-quote-face)
             ("^-" . fanyi-list-face)
             ("(\\([a-z\.]+?\\))" . fanyi-pos-face)
             ("/\\([^/]+?\\)/" . italic)
             ("\\*\\([^\\*]+?\\)\\*" . bold)
             ("_\\([^_]+?\\)_" . underline))))
  "Keywords to highlight in `fanyi-mode'.")

(defun fanyi-forward-button (count)
  "Move COUNT buttons forward, skipping hidden buttons and wrapping at the end.
With a negative COUNT, move backward.  A zero COUNT moves to the start of
the visible button at point."
  (interactive "p")
  (let ((button
         (save-excursion
           (let ((iterator (if (< count 0) #'previous-button #'next-button))
                 (boundary (if (< count 0) (point-max) (point-min)))
                 (button (button-at (point))))
             (dotimes (_ (abs count))
               (let (seen found)
                 (while (not found)
                   (setq button (or (funcall iterator (point))
                                    (funcall iterator boundary t)))
                   (unless (and button (not (memq (button-start button) seen)))
                     (user-error "No visible buttons"))
                   (goto-char (button-start button))
                   (push (point) seen)
                   (setq found (not (or (button-get button 'skip)
                                        (invisible-p (point))))))))
             (when (and button (not (invisible-p (button-start button)))) button)))))
    (when button
      (goto-char (button-start button))
      (when-let* ((help (button-get button 'help-echo))
                  ((stringp help)))
        (message "%s" help)))
    button))

(defun fanyi-backward-button (count)
  "Move COUNT visible buttons backward, wrapping at the beginning."
  (interactive "p")
  (fanyi-forward-button (- count)))

(defun fanyi-next-heading (count)
  "Move COUNT visible dictionary, outline or local section headings forward.
Negative COUNT moves backward.  Leave point unchanged if there are too few
headings in that direction, and respect the accessible buffer region."
  (interactive "p")
  (let ((origin (point)) headings)
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward "^#+ " nil t)
        (unless (invisible-p (match-beginning 0))
          (push (match-beginning 0) headings))))
    (let ((position (point-min)))
      (while (< position (point-max))
        (when (and (get-text-property position 'fanyi-shr-section)
                   (not (invisible-p position)))
          (push position headings))
        (setq position (next-single-property-change
                        position 'fanyi-shr-section nil (point-max)))))
    (setq headings (sort (delete-dups headings) (if (< count 0) #'> #'<)))
    (dotimes (_ (abs count))
      (setq origin (or (seq-find (lambda (position)
                                   (if (< count 0) (< position origin) (> position origin)))
                                 headings)
                       (user-error "No %s visible heading" (if (< count 0) "previous" "next")))))
    (goto-char origin)))

(defun fanyi-previous-heading (count)
  "Move COUNT visible dictionary, outline or local section headings backward."
  (interactive "p")
  (fanyi-next-heading (- count)))

(defun fanyi--section-heading-button ()
  "Return the visible local heading button on the current line, if any."
  (let ((origin (point)) (end (line-end-position)))
    (save-excursion
      (beginning-of-line)
      (skip-chars-forward " \t" end)
      (when-let* ((button (button-at (point)))
                  (section (button-get button 'fanyi-shr-section))
                  ((not (invisible-p (point)))))
        (when (or (<= origin (fanyi-shr--section-heading-end section))
                  ;; Ignore trailing indentation, but do not interpret text
                  ;; after a heading button as part of the heading itself.
                  (progn
                    (goto-char (fanyi-shr--section-heading-end section))
                    (skip-chars-forward " \t" end)
                    (= (point) end)))
          button)))))

(defun fanyi-toggle-section ()
  "Toggle the visible outline or local section heading on the current line."
  (interactive)
  (let ((button (fanyi--section-heading-button)))
    (cond (button
           ;; The title can be only partly visible through a narrowed view.
           ;; Its styling and body overlay still span the complete section.
           (save-restriction (widen) (button-activate button)))
          ((and (not (invisible-p (line-beginning-position)))
                (outline-on-heading-p t))
           (outline-cycle))
          (t (user-error "Move to a heading to toggle its section")))))

(defun fanyi-pronounce (&optional american)
  "Play the query's British pronunciation, or American with AMERICAN non-nil.
Prefer the current dictionary, then fall back to another dictionary.  If
the preferred dialect is unavailable, use another word pronunciation.
Example audio is never selected.  Point and folding remain unchanged."
  (interactive "P")
  (let ((dialect (if american 'american 'british))
        (origin (point)) local others)
    (save-excursion
      (save-restriction
        (widen)
        (let ((start (progn
                       (beginning-of-line)
                       (if (or (looking-at-p "^# ") (re-search-backward "^# " nil t))
                           (point) (point-min))))
              (end (progn
                     (goto-char origin)
                     (forward-line 1)
                     (if (re-search-forward "^# " nil t)
                         (match-beginning 0) (point-max))))
              (position (point-min)) button)
          (while (setq button (next-button position t))
            (when (eq (button-get button 'fanyi-audio-kind) 'pronunciation)
              (if (<= start (button-start button) (1- end))
                  (push button local)
                (push button others)))
            (setq position (button-end button))))
        (setq local (nreverse local) others (nreverse others))
        (let* ((preferred (lambda (button) (eq (button-get button 'fanyi-audio-dialect) dialect)))
               (button (or (seq-find preferred local) (car local)
                           (seq-find preferred others) (car others))))
          (unless button (user-error "No word pronunciation available"))
          (button-activate button))))))

(defun fanyi-pronounce-american ()
  "Play the query's American pronunciation when available."
  (interactive)
  (fanyi-pronounce t))

(defvar fanyi--revisiting nil
  "Non-nil means do not push browser history when refreshing or restoring.")

(defun fanyi--revert-buffer (&optional _ignore-auto _noconfirm)
  "Refresh the current query in its existing result buffer."
  (unless (and (stringp fanyi-current-word) (not (string-empty-p fanyi-current-word)))
    (user-error "No query to refresh"))
  (let ((fanyi-buffer-name (buffer-name))
        (fanyi--revisiting t))
    (fanyi-dwim fanyi-current-word)))

(defvar fanyi-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map [tab] #'fanyi-forward-button)
    (define-key map (kbd "TAB") #'fanyi-forward-button)
    (define-key map [backtab] #'fanyi-backward-button)
    ;; Button text and overlays have their own keymaps.  Remapping also
    ;; covers those bindings without changing Emacs's global button map.
    (define-key map [remap forward-button] #'fanyi-forward-button)
    (define-key map [remap backward-button] #'fanyi-backward-button)
    (define-key map "q" #'quit-window)
    (define-key map "s" #'fanyi-dwim)
    (define-key map "w" #'fanyi-copy-query-word)
    (define-key map "h" #'fanyi-from-history)
    (define-key map "l" #'fanyi-back)
    (define-key map "r" #'fanyi-forward)
    (define-key map "n" #'fanyi-next-heading)
    (define-key map "p" #'fanyi-previous-heading)
    (define-key map "v" #'fanyi-pronounce)
    (define-key map "V" #'fanyi-pronounce-american)
    (define-key map "g" #'revert-buffer)
    (define-key map (kbd "C-c TAB") #'fanyi-toggle-section)
    (define-key map (kbd "C-c <tab>") #'fanyi-toggle-section)
    (define-key map (kbd "C-c C-n") #'fanyi-forward-button)
    (define-key map (kbd "C-c C-p") #'fanyi-backward-button)
    map)
  "Keymap for `fanyi-mode'.")

(defvar fanyi-mode-cycle-map
  (let ((map (make-sparse-keymap)))
    (define-key map [tab] #'outline-cycle)
    (define-key map (kbd "TAB") #'outline-cycle)
    (define-key map [backtab] #'outline-cycle-buffer)
    map)
  "Keymap used by headlines of `fanyi-mode'.")

(defun fanyi--update-provider-keywords ()
  "Update provider highlighting without resetting user or derived-mode rules."
  (unless (equal fanyi--font-lock-provider-keywords fanyi-mode-font-lock-keywords-extra)
    (font-lock-remove-keywords nil fanyi--font-lock-provider-keywords)
    (font-lock-add-keywords nil fanyi-mode-font-lock-keywords-extra 'append)
    (setq fanyi--font-lock-provider-keywords (copy-tree fanyi-mode-font-lock-keywords-extra))))

(define-derived-mode fanyi-mode special-mode "Fanyi"
  "Major mode for viewing multi translators result.
\\{fanyi-mode-map}"
  :interactive nil
  :group 'fanyi

  ;; Set these variables to nil, it's handled by ourselves.
  (setq-local outline-minor-mode-cycle nil)
  (setq-local outline-minor-mode-highlight nil)
  (setq-local outline-minor-mode-use-buttons nil)
  ;; Make it foldable.
  (setq-local outline-regexp "^#+")
  (setq-local outline-minor-mode t)

  ;; `bookmark' integration.
  (setq-local bookmark-make-record-function #'fanyi-bookmark-make-record)

  (setq-local revert-buffer-function #'fanyi--revert-buffer)

  ;; Better display
  (setq-local line-spacing 0.1)

  ;; ElDoc integration.
  (add-hook 'eldoc-documentation-functions #'fanyi-eldoc-function nil t)

  ;; A result buffer owns its requests; closing or repurposing it ends them.
  (add-hook 'kill-buffer-hook #'fanyi--cancel-buffer-tasks nil t)
  (add-hook 'change-major-mode-hook #'fanyi--cancel-buffer-tasks nil t)

  ;; Results are regenerated by queries; retaining undo history wastes memory.
  (setq buffer-undo-list t)
  ;; Providers may be loaded after fanyi.el or changed between queries.
  (setq font-lock-defaults
        (list (append fanyi-mode-font-lock-keywords
                      fanyi-mode-font-lock-keywords-extra)))
  (setq fanyi--font-lock-provider-keywords (copy-tree fanyi-mode-font-lock-keywords-extra))
  (setq imenu-generic-expression '(("Dict" "^# \\(.*\\)" 1)))
  (setq header-line-format '((:eval (fanyi-format-header-line)))))

(defun fanyi--reader-anchor (position)
  "Describe POSITION without retaining a marker in a historical buffer."
  (let ((index (cl-position-if
                (lambda (task)
                  (and (fanyi--task-start task)
                       (<= (fanyi--task-start task) position)
                       (< position (fanyi--task-end task))))
                fanyi--tasks)))
    (cons index (fanyi-shr--text-anchor
                 (if index (fanyi--task-start (nth index fanyi--tasks)) (point-min))
                 position))))

(defun fanyi--reader-position (anchor)
  "Resolve a saved reader ANCHOR in the current widened result."
  (let ((task (and (car anchor) (nth (car anchor) fanyi--tasks))))
    (fanyi-shr--text-position
     (or (and task (fanyi--task-start task)) (point-min))
     (or (and task (fanyi--task-end task)) (point-max))
     (nth 1 anchor) (nth 2 anchor) (nth 3 anchor))))

(defun fanyi--reader-sections (task)
  "Return TASK's local folding sections in a stable region order."
  (cl-mapcan (lambda (region)
               (when (and (fanyi--task-start task)
                          (<= (fanyi--task-start task) (fanyi-shr--region-start region))
                          (<= (fanyi-shr--region-end region) (fanyi--task-end task)))
                 (copy-sequence (fanyi-shr--region-sections region))))
             (sort (copy-sequence fanyi-shr--regions)
                   (lambda (a b) (< (fanyi-shr--region-start a)
                                    (fanyi-shr--region-start b))))))

(defun fanyi--window-identity (window)
  "Return a stable token for WINDOW without retaining the window in history."
  (or (window-parameter window 'fanyi-history-identity)
      (set-window-parameter window 'fanyi-history-identity (make-symbol "fanyi-window"))))

(defun fanyi--save-reader ()
  "Capture reading position, selection, narrowing and folds without markers."
  (let ((bounds (and (buffer-narrowed-p) (cons (point-min) (point-max)))))
    (save-restriction
      (widen)
      (list :point (fanyi--reader-anchor (point))
            :mark (and (mark t) (fanyi--reader-anchor (mark t)))
            :active mark-active
            :bounds (and bounds (cons (fanyi--reader-anchor (car bounds))
                                      (fanyi--reader-anchor (cdr bounds))))
            :windows (mapcar (lambda (window)
                               (list (fanyi--window-identity window)
                                     (fanyi--reader-anchor (window-point window))
                                     (fanyi--reader-anchor (window-start window))))
                             (get-buffer-window-list (current-buffer) nil t))
            :outline (cl-loop for overlay in (overlays-in (point-min) (point-max))
                              when (eq (overlay-get overlay 'invisible) 'outline)
                              collect (cons (fanyi--reader-anchor (overlay-start overlay))
                                            (fanyi--reader-anchor (overlay-end overlay))))
            :sections (mapcar (lambda (task)
                                (mapcar #'fanyi-shr--section-closed
                                        (fanyi--reader-sections task)))
                              fanyi--tasks)
            :failures (mapcar #'fanyi--task-failure fanyi--tasks)))))

(defun fanyi--reader-failed-range-p (start end failures)
  "Whether anchors START and END span a newly failed task in FAILURES."
  (and failures
       (or (assq (car start) failures)
           (let ((begin (fanyi--reader-position start))
                 (finish (fanyi--reader-position end)))
             (seq-some (lambda (entry)
                         (let ((task (cdr entry)))
                           (and (fanyi--task-start task)
                                (< (fanyi--task-start task) finish)
                                (> (fanyi--task-end task) begin))))
                       failures)))))

(defun fanyi--restore-reader (view)
  "Restore the saved reader VIEW after rendering the cached dictionaries."
  (let ((failures (cl-loop for task in fanyi--tasks for index from 0
                           when (and (fanyi--task-failure task)
                                     (not (equal (fanyi--task-failure task)
                                                 (nth index (plist-get view :failures)))))
                           collect (cons index task))))
    (cl-labels ((position (anchor)
                  (if-let* ((task (cdr (assq (car anchor) failures))))
                      (marker-position (fanyi--task-start task))
                    (fanyi--reader-position anchor))))
      (cl-mapc (lambda (task states)
                 (cl-mapc #'fanyi-shr--section-set-closed
                          (fanyi--reader-sections task) states))
               fanyi--tasks (plist-get view :sections))
      (dolist (fold (plist-get view :outline))
        (unless (fanyi--reader-failed-range-p (car fold) (cdr fold) failures)
          (outline-flag-region (fanyi--reader-position (car fold))
                               (fanyi--reader-position (cdr fold)) t)))
      (let ((point (position (plist-get view :point)))
            (mark (and (plist-get view :mark)
                       (not (fanyi--reader-failed-range-p
                             (plist-get view :point) (plist-get view :mark) failures))
                       (not (fanyi--reader-failed-range-p
                             (plist-get view :mark) (plist-get view :point) failures))
                       (fanyi--reader-position (plist-get view :mark))))
            (bounds (plist-get view :bounds))
            (windows (mapcar (lambda (state)
                               (let ((point (position (nth 1 state))))
                                 (list (car state) point
                                       (if (assq (car (nth 1 state)) failures) point
                                         (position (nth 2 state))))))
                             (plist-get view :windows))))
        ;; Old offsets inside a replaced definition cannot describe its error.
        ;; Keep that error and its retry button accessible instead of restoring
        ;; narrowing or folds that may hide them at the end of the new text.
        (when (and bounds
                   (not (fanyi--reader-failed-range-p (car bounds) (cdr bounds) failures)))
          (narrow-to-region (fanyi--reader-position (car bounds))
                            (fanyi--reader-position (cdr bounds))))
        (goto-char point)
        (set-marker (mark-marker) mark)
        (setq mark-active (and mark (plist-get view :active))
              deactivate-mark nil)
        ;; Window-list order rotates with focus.  Match surviving windows by token;
        ;; new windows use the page's primary view, never an unrelated buffer's view.
        (dolist (window (get-buffer-window-list (current-buffer) nil t))
          (let ((state (assq (fanyi--window-identity window) windows)))
            (set-window-point window (if state (nth 1 state) point))
            (set-window-start window (if state (nth 2 state)
                                       (or (nth 2 (car windows)) point)) t)))))))

(defun fanyi--save-page ()
  "Snapshot this query's resolved requests, outcomes and reading state."
  (fanyi--page-create
   :word fanyi-current-word :view (fanyi--save-reader)
   :tasks (mapcar
           (lambda (task)
             (list (fanyi--task-request task)
                   (fanyi--task-state task)
                   (fanyi--task-result task) (fanyi--task-failure task)))
           fanyi--tasks)))

(defun fanyi--trim-navigation-history ()
  "Bound the total number of cached past and future pages."
  (let ((limit (max 0 fanyi-navigation-history-length)))
    (setq fanyi--back-history (seq-take fanyi--back-history limit)
          fanyi--forward-history
          (seq-take fanyi--forward-history (- limit (length fanyi--back-history))))))

(defun fanyi--begin-query (buffer word)
  "Reset BUFFER's query data for WORD, preserving its mode and reader settings."
  ;; Invalidate callbacks before cancellation can invoke process sentinels.
  (cl-incf fanyi--query-id)
  (when (buffer-live-p fanyi--active-buffer)
    (with-current-buffer fanyi--active-buffer (fanyi--cancel-buffer-tasks)))
  (with-current-buffer buffer
    (unless (eq buffer fanyi--active-buffer) (fanyi--cancel-buffer-tasks))
    (unless (derived-mode-p 'fanyi-mode) (fanyi-mode))
    (let ((inhibit-read-only t))
      (widen)
      (remove-overlays (point-min) (point-max) 'invisible 'outline)
      (erase-buffer)
      (dolist (task fanyi--tasks)
        (when (fanyi--task-start task) (set-marker (fanyi--task-start task) nil))
        (when (fanyi--task-end task) (set-marker (fanyi--task-end task) nil)))
      (set-marker (mark-marker) nil)
      (setq mark-active nil
            imenu--index-alist nil
            fanyi--tasks nil
            fanyi--tasks-completed 0
            fanyi--tasks-failed 0)
      (fanyi--update-provider-keywords)
      (setq fanyi-current-word word
            fanyi--buffer-query-id fanyi--query-id)))
  (setq fanyi--active-buffer buffer))

(defun fanyi--restore-page (page)
  "Display cached PAGE and restart only its unfinished requests."
  (let ((buffer (current-buffer)) pending complete)
    (fanyi--begin-query buffer (fanyi--page-word page))
    ;; Register every task before rendering or starting any synchronous callback.
    (setq fanyi--tasks
          (mapcar (lambda (entry)
                    (fanyi--make-task :query-id fanyi--buffer-query-id
                                      :request (nth 0 entry) :result (nth 2 entry)
                                      :failure (nth 3 entry) :result-buffer buffer))
                  (fanyi--page-tasks page)))
    (unwind-protect
        (progn
          (cl-mapc
           (lambda (task entry)
             (condition-case err
                 (pcase (nth 1 entry)
                   ((or 'pending 'cancelled)
                    (push task pending)
                    (when (fanyi--task-failure task)
                      (fanyi--write-task-error task (fanyi--task-failure task))))
                   ('failed
                    (fanyi--set-task-state task 'failed (fanyi--task-failure task))
                    (fanyi--write-task-error task (fanyi--task-failure task)))
                   ('not-found
                    (fanyi--write-not-found task)
                    (fanyi--set-task-state task 'not-found))
                   ('succeeded
                    (fanyi--write-task-result task)
                    (fanyi--set-task-state task 'succeeded)))
               (error
                (fanyi--set-task-state task 'failed (error-message-string err))
                (fanyi--report-task-error task (fanyi--task-failure task)))))
           (reverse fanyi--tasks) (reverse (fanyi--page-tasks page)))
          (fanyi--restore-reader (fanyi--page-view page))
          ;; Restore anchors before pending callbacks can add earlier sections.
          (dolist (task (nreverse pending)) (fanyi--start-task task))
          (setq complete t)
          (force-mode-line-update t))
      (unless complete (fanyi--cancel-buffer-tasks)))))

(defun fanyi--navigate (backward)
  "Visit the previous cached page if BACKWARD, or the next one otherwise."
  (unless (derived-mode-p 'fanyi-mode) (user-error "Not in a Fanyi result buffer"))
  (fanyi--trim-navigation-history)
  (let ((page (car (if backward fanyi--back-history fanyi--forward-history))))
    (unless page (user-error "No %s lookup" (if backward "previous" "next")))
    (let ((current (fanyi--save-page)))
      (if backward
          (setq fanyi--back-history (cdr fanyi--back-history)
                fanyi--forward-history (cons current fanyi--forward-history))
        (setq fanyi--forward-history (cdr fanyi--forward-history)
              fanyi--back-history (cons current fanyi--back-history))))
    (fanyi--restore-page page)))

(defun fanyi-back ()
  "Return to the previous lookup using its cached results and reading position."
  (interactive)
  (fanyi--navigate t))

(defun fanyi-forward ()
  "Return to the next lookup using its cached results and reading position."
  (interactive)
  (fanyi--navigate nil))

;;;###autoload
(defun fanyi-dwim (word)
  "Translate WORD after trimming and collapsing whitespace.
Record every accepted query in `fanyi-history', with the most recent first."
  (interactive (let* ((history-add-new-input nil)
                      (default (if (use-region-p)
                                   (buffer-substring-no-properties (region-beginning) (region-end))
                                 (thing-at-point 'word t)))
                      (prompt (if (stringp default)
                                  (format "Search Word (default \"%s\"): " default)
                                "Search Word: ")))
                 (list (read-string prompt nil 'fanyi-history default))))
  (unless (stringp word)
    (user-error "Query must be a string"))
  (setq word (string-trim (replace-regexp-in-string
                           "[ \t\r\n]+" " " (substring-no-properties word))))
  (when (string-empty-p word)
    (user-error "Query must not be empty"))
  (unless fanyi-providers
    (user-error "No dictionary providers enabled"))
  (let ((requests (mapcar (lambda (provider)
                            (fanyi-make-request (fanyi--resolve-provider provider)
                                                (downcase word)))
                          fanyi-providers)))
    ;; Browser entries do not need either response parser.
    (when (and (seq-some (lambda (request) (eq (fanyi-request-api-type request) 'xml))
                         requests)
               (not (fboundp 'libxml-parse-html-region)))
      (error "This function requires Emacs to be compiled with libxml2"))
    (when (and (seq-some (lambda (request) (eq (fanyi-request-api-type request) 'json))
                         requests)
               (not (fboundp 'json-parse-buffer)))
      (error "This function requires Emacs to be compiled with libjson"))
    (let ((history-delete-duplicates t))
      ;; Also remove duplicates restored from history by older versions.
      (add-to-history 'fanyi-history word nil t))
    (let ((buf (get-buffer-create fanyi-buffer-name)))
      (with-current-buffer buf
        ;; Capture unfinished states before cancellation marks their tasks done.
        (unless fanyi--revisiting
          (when (and (derived-mode-p 'fanyi-mode) fanyi-current-word
                     (> fanyi-navigation-history-length 0))
            (push (fanyi--save-page) fanyi--back-history))
          (setq fanyi--forward-history nil))
        (fanyi--trim-navigation-history))
      (fanyi--begin-query buf word)

      (dolist (request requests)
        (fanyi--spawn request buf))
      (if fanyi-auto-select
          (pop-to-buffer buf)
        (display-buffer buf)))))

;;;###autoload
(defun fanyi-dwim2 ()
  "A more dwim version of `fanyi-dwim'.
No prompt if the region is active or `thing-at-point' returns
non-nil."
  (interactive)
  (if-let* ((word (if (use-region-p)
                      (buffer-substring-no-properties (region-beginning) (region-end))
                    (thing-at-point 'word t))))
      (fanyi-dwim word)
    (call-interactively #'fanyi-dwim)))

;;;###autoload
(defun fanyi-from-history ()
  "Invoke `fanyi-dwim' from history."
  (interactive)
  (fanyi-dwim (completing-read "Fanyi history: " fanyi-history nil t)))

(defun fanyi-copy-query-word ()
  "Copy current query word."
  (interactive nil fanyi-mode)
  (kill-new fanyi-current-word)
  (message "Copied %s" fanyi-current-word))

;;; Bookmark support.

(defun fanyi-bookmark-make-record ()
  "Create a bookmark for the current query word."
  `(,fanyi-current-word
    (fanyi-word . ,fanyi-current-word)
    (handler . fanyi-bookmark-jump)))

;;;###autoload
(defun fanyi-bookmark-jump (bookmark)
  "Default BOOKMARK handler for fanyi."
  (let ((word (or (alist-get 'fanyi-word (cdr bookmark))
                  ;; Older records stored the word only as the bookmark name.
                  (car bookmark))))
    (fanyi-dwim word)))

(put 'fanyi-bookmark-jump 'bookmark-handler-type "Fanyi")

(provide 'fanyi)
;;; fanyi.el ends here
