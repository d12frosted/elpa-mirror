;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fanyi" "20261104.1005"
  "Not only English-Chinese translator."
  '((emacs "29.1"))
  :url "https://github.com/condy0919/fanyi.el"
  :commit "59058538addee527bf0598ac6f9e4333aff55800"
  :revdesc "59058538adde"
  :keywords '("convenience" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
