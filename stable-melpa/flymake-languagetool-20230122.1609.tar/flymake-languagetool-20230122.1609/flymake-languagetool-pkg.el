(define-package "flymake-languagetool" "20230122.1609" "Flymake support for LanguageTool"
  '((emacs "27.1"))
  :commit "ad8c724147d5a3a9f6ee59e0c7581e68fba4a2f8" :keywords
  '("convenience" "grammar" "check")
  :url "https://github.com/emacs-languagetool/flymake-languagetool")
;; Local Variables:
;; no-byte-compile: t
;; End:
