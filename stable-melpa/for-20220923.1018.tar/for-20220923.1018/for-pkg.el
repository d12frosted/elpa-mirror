(define-package "for" "20220923.1018" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "5df8659ef315882b90f84da2eb9adf95443b571c" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
