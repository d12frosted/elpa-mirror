;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250304.1016"
  "Contrived way to call a function using all CPU cores."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/meedstrom/el-job"
  :commit "127b68e005dcecb82518c3cdefb09cc0fdaaa1a0"
  :revdesc "127b68e005dc"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
