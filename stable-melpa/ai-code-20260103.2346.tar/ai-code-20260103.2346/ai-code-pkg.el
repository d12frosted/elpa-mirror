;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260103.2346"
  "Unified interface for multiple AI coding CLI tool."
  '((emacs     "26.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b4ae229959867597d7e816ddb2bb9a34ad0beef3"
  :revdesc "b4ae22995986"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
