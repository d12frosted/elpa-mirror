(define-package "difftastic" "20240307.727" "Wrapper for difftastic"
  '((emacs "27.1")
    (compat "29.1.4.2")
    (magit "20220326"))
  :commit "1e10665520955478c7de1998b516820106d55ed5" :authors
  '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers
  '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainer
  '("Przemyslaw Kryger" . "pkryger@gmail.com")
  :keywords
  '("tools" "diff")
  :url "https://github.com/pkryger/difftastic.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
