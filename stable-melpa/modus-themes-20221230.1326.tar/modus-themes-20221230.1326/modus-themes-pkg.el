(define-package "modus-themes" "20221230.1326" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "ae6cc7ed14cf31a433a8e1d11f2a7cd09d0ad9aa" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
