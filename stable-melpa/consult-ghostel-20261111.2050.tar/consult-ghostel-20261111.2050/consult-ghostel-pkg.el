;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "20261111.2050"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.64.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "c6f24788b5e114ad6569b3943702bd1609617a5e"
  :revdesc "c6f24788b5e1"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
