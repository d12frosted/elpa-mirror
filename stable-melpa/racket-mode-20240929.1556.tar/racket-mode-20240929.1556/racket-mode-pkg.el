;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "racket-mode" "20240929.1556"
  "Racket editing, REPL, and more."
  '((emacs "25.1"))
  :url "https://github.com/greghendershott/racket-mode"
  :commit "10a5f7c69460a23f8f124093659aa64f62a71494"
  :revdesc "10a5f7c69460"
  :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")))
