(define-package "sly" "20201210.1639" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "0207e2d2fa138537dc973a986218af69ee7cd586" :keywords
  ("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
