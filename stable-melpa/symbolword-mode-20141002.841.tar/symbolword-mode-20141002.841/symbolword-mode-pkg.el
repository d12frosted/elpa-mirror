(define-package "symbolword-mode" "20141002.841" "No description available." 'nil :commit "273dece5b04f7abc4c35048b2f64f04b33774b87")
;; Local Variables:
;; no-byte-compile: t
;; End:
