;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sway-lang-mode" "20230320.507"
  "Major mode for sway."
  '((emacs     "25.1")
    (lsp-mode  "6.0")
    (rust-mode "1.0.5"))
  :url "https://github.com/hhamud/sway-mode"
  :commit "1d4615cc99d57280fb4b301d8339f408d987d317"
  :revdesc "1d4615cc99d5"
  :keywords '("languages"))
