(define-package "dashboard" "20220401.947" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "4370fdbd7b0bf15ca36afa2c0b468ee02bddf6cf" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
