(define-package "org-link-beautify" "20230509.1441" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1"))
  :commit "d55b3ff5331b7db54bd0adb18cb44490e263814a" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
