;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-flycheck" "20260101.541"
  "Show flycheck errors with sideline."
  '((emacs    "28.1")
    (sideline "0.1.1")
    (flycheck "0.14")
    (ht       "2.4"))
  :url "https://github.com/emacs-sideline/sideline-flycheck"
  :commit "5a4d63210acf735829b08164897fef6a2abc8bab"
  :revdesc "5a4d63210acf"
  :keywords '("convenience" "flycheck")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
