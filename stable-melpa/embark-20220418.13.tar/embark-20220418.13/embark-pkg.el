(define-package "embark" "20220418.13" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "0d18a5409a964e312c0f14e4631204a0f651c2e4" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
