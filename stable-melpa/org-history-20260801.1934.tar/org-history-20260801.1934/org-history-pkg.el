;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-history" "20260801.1934"
  "Show Dates for Org headers from vcs + auto-commit."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-org-history"
  :commit "8da91f3dd0af40caa799e609b131f5312d183168"
  :revdesc "8da91f3dd0af"
  :keywords '("org" "outline" "vc")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
