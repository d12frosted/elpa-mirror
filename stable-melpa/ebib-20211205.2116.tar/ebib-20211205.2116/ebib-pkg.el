(define-package "ebib" "20211205.2116" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "28e54e1ccda517e2ce0a32e769626c3afd76e6d2" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
