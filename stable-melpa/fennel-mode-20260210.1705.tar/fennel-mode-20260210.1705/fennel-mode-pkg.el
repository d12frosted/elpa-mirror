;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "20260210.1705"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "97af9187581ff00712a89f375a5898f9db067ebd"
  :revdesc "97af9187581f"
  :keywords '("languages" "tools"))
