(define-package "brutal-theme" "20211128.2137" "Brutalist theme"
  '((emacs "24.1"))
  :commit "4c36c01deff0a6d17078a2f0d68bb4f7b95c97d6" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
