;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260111.1338"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "38b5c2a5c33aa764a8fcd3919c8a3c1712b16d92"
  :revdesc "38b5c2a5c33a"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
