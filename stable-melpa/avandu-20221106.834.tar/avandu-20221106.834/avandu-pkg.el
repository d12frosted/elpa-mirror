(define-package "avandu" "20221106.834" "Gateway to Tiny Tiny RSS" 'nil :commit "f064cd62f878d945cc2f202cda9a1a82b39d9e22" :authors
  '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers
  '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainer
  '("Tom Willemse" . "tom@ryuslash.org")
  :keywords
  '("net"))
;; Local Variables:
;; no-byte-compile: t
;; End:
