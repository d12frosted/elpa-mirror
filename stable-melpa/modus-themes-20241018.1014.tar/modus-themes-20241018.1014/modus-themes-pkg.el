;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20241018.1014"
  "Elegant, highly legible and customizable themes."
  '((emacs "27.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "77a0310b5cba1720405d0587297d2f7781b02dad"
  :revdesc "77a0310b5cba"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
