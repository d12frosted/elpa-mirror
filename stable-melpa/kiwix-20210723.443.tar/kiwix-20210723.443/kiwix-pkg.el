(define-package "kiwix" "20210723.443" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (request "0.3.0")
    (elquery "0.1.0"))
  :commit "c0c597d1e1653112f3e10c67dcc22d85beb2aed8" :authors
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
