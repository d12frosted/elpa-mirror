(define-package "nndiscourse" "20210819.2038" "Gnus backend for Discourse"
  '((emacs "25.1")
    (dash "2.18.1")
    (anaphora "1.0.4")
    (rbenv "0.0.3")
    (json-rpc "0.0.1"))
  :commit "5a0fd1489fe46c57129c20419f29a87e5af5677e" :keywords
  '("news")
  :url "https://github.com/dickmao/nndiscourse")
;; Local Variables:
;; no-byte-compile: t
;; End:
