;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260721.1300"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "12c7218e54b5df95a5cd3bd9a0d47a5a60b9d2d1"
  :revdesc "12c7218e54b5"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
