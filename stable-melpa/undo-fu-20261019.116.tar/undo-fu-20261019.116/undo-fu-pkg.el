;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu" "20261019.116"
  "Undo helper with redo."
  '((emacs "25.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu"
  :commit "fcb4aa41deeb0e080510e56ea9405e4d0721abf8"
  :revdesc "fcb4aa41deeb"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
