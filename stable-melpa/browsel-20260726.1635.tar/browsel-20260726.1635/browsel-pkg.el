;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browsel" "20260726.1635"
  "WebSocket bridge to a Chrome/Firefox extension."
  '((emacs     "27.1")
    (websocket "1.13")
    (org       "9.8")
    (vertico   "1.0"))
  :url "https://github.com/dmgerman/browsel"
  :commit "c96e3b8b0a28b6e0d9e2d79a51a07a0700966b1c"
  :revdesc "c96e3b8b0a28"
  :keywords '("comm" "tools" "browser" "org")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
