(define-package "liberime" "20221128.514" "Rime elisp binding"
  '((emacs "25.1"))
  :commit "95b61f311cf266a8ffbfd5c71f0a1c3c70145cdb" :authors
  '(("A.I."))
  :maintainer
  '("A.I.")
  :keywords
  '("convenience" "chinese" "input-method" "rime")
  :url "https://github.com/merrickluo/liberime")
;; Local Variables:
;; no-byte-compile: t
;; End:
