;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260215.2013"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "8a7c00b050e5f847f126c58889c5114336f5b744"
  :revdesc "8a7c00b050e5"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
