;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261103.316"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "549641b71bb7d0056d65957d65ffb9e50364a788"
  :revdesc "549641b71bb7")
