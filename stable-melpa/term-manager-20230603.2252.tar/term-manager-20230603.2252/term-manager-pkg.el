(define-package "term-manager" "20230603.2252" "Contextual terminal management"
  '((dash "2.12.0")
    (emacs "24.4"))
  :commit "a3ea91855b4c16b4448ae360ba8bd2c1e08bff6b" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("terminals" "tools")
  :url "https://www.github.com/IvanMalison/term-manager")
;; Local Variables:
;; no-byte-compile: t
;; End:
