;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hide-lines" "20250523.1851"
  "Commands for hiding lines based on a regexp."
  ()
  :url "https://github.com/vapniks/hide-lines"
  :commit "e597d3400b1daac01b720df7f99a0d2af5ddfa06"
  :revdesc "e597d3400b1d"
  :keywords '("convenience")
  :authors '(("Mark Hulme-Jones" . "tureatpligcucumberdotnet"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
