;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cowsay" "20210510.1540"
  "Poorly drawn ASCII cartoons saying things."
  '((emacs "24.5"))
  :url "https://github.com/lassik/emacs-cowsay"
  :commit "d8a72a311c6875f1aef6a30b3d23a1b02df75941"
  :revdesc "d8a72a311c68"
  :keywords '("games")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
