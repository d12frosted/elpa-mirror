(define-package "prettier" "20201209.837" "Code formatting with Prettier"
  '((emacs "26.1")
    (iter2 "0.9")
    (nvm "0.2"))
  :commit "673698ed70f2205230a052dd98f2cd2f1dd0c21f" :keywords
  ("convenience" "languages" "files")
  :authors
  (("Julian Scheid" . "julians37@gmail.com"))
  :maintainer
  ("Julian Scheid" . "julians37@gmail.com")
  :url "https://github.com/jscheid/prettier.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
