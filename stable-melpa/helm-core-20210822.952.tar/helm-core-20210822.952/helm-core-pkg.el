(define-package "helm-core" "20210822.952" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "a4013988250dc86eb2ca05d0012418ba7f290ca2")
;; Local Variables:
;; no-byte-compile: t
;; End:
