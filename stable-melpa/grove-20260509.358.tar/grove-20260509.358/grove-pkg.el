;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "20260509.358"
  "Obsidian-like note-taking for org files."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "8cb33df4e39c51265b8021ecf858ab4bde27f41e"
  :revdesc "8cb33df4e39c"
  :keywords '("notes" "outlines" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
