;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260320.1953"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "ec62deb3903eb8c2053fd4283308c8f9bb03a18b"
  :revdesc "ec62deb3903e"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
