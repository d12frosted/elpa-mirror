(define-package "awk-ts-mode" "20231001.2221" "Major mode for awk using tree-sitter"
  '((emacs "29.1"))
  :commit "d142f0ab61da89d3bf311194f69b655b0b7855a9" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("awk" "languages" "tree-sitter")
  :url "https://github.com/nverno/awk-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
