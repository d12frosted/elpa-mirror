;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241017.238"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "433763ad194c83d23996c62ac64bb24ad7d9cbe5"
  :revdesc "433763ad194c"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
