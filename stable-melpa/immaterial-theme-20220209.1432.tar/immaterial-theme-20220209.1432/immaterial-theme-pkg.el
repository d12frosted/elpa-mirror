(define-package "immaterial-theme" "20220209.1432" "A flexible theme based on material design principles"
  '((emacs "25"))
  :commit "b1f493ecd13d49bf6c6e974bf22f490a7e61ff7a" :authors
  '(("Peter Gardfjäll"))
  :maintainer
  '("Peter Gardfjäll")
  :keywords
  '("themes")
  :url "https://github.com/petergardfjall/emacs-immaterial-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
