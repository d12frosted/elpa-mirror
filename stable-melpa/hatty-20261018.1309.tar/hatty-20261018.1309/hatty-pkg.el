;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hatty" "20261018.1309"
  "Query positions through hats."
  '((emacs "29.1"))
  :url "https://github.com/ErikPrantare/hatty.el"
  :commit "65e3548e33e83ed2932733e708ad5f7ae3fe7b8a"
  :revdesc "65e3548e33e8"
  :keywords '("convenience")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
