(define-package "speech-tagger" "20170728.1829" "tag parts of speech using coreNLP"
  '((cl-lib "0.5"))
  :commit "61955b40d4e8b09e66a3e8033e82893f81657c06" :keywords
  ("speech" "tag" "nlp" "language" "corenlp" "parsing" "natural")
  :authors
  (("Danny McClanahan" . "danieldmcclanahan@gmail.com"))
  :maintainer
  ("Danny McClanahan" . "danieldmcclanahan@gmail.com")
  :url "https://github.com/cosmicexplorer/speech-tagger")
;; Local Variables:
;; no-byte-compile: t
;; End:
