(define-package "w3m" "20221107.2347" "an Emacs interface to w3m" 'nil :commit "ceb4650af76bb94f1f9dbcaab8871909c7857b55" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
