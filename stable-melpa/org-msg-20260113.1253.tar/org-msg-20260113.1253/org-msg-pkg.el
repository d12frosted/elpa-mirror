;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-msg" "20260113.1253"
  "Org mode to send and reply to email in HTML."
  '((emacs   "24.4")
    (htmlize "1.54"))
  :url "https://github.com/jeremy-compostella/org-msg"
  :commit "b7f17693739ce9c9a1b4356a1443a4b1db85b386"
  :revdesc "b7f17693739c"
  :keywords '("extensions" "mail")
  :authors '(("Jérémy Compostella" . "jeremy.compostella@gmail.com"))
  :maintainers '(("Jérémy Compostella" . "jeremy.compostella@gmail.com")))
