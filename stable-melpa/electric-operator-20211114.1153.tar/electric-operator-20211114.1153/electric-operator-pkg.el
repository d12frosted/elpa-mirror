(define-package "electric-operator" "20211114.1153" "Automatically add spaces around operators"
  '((dash "2.10.0")
    (emacs "24.4"))
  :commit "1c51e88d5719e7b0dd022a4704c46b24e0c91348" :authors
  '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainer
  '("David Shepherd" . "davidshepherd7@gmail.com")
  :keywords
  '("electric")
  :url "https://github.com/davidshepherd7/electric-operator")
;; Local Variables:
;; no-byte-compile: t
;; End:
