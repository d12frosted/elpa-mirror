(define-package "iota" "20230820.2033" "Replace marker with increasing integers" 'nil :commit "9dbf2741a2471044e58ccee6635ae8c6e311b7a8" :authors
  '(("Thomas Voss" . "mail@thomasvoss.com"))
  :maintainers
  '(("Thomas Voss" . "mail@thomasvoss.com"))
  :maintainer
  '("Thomas Voss" . "mail@thomasvoss.com")
  :keywords
  '("abbrev" "data" "wp")
  :url "https://git.sr.ht/~mango/iota")
;; Local Variables:
;; no-byte-compile: t
;; End:
