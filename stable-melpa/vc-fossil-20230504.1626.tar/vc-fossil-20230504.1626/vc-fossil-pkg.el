;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-fossil" "20230504.1626"
  "VC backend for the fossil sofware configuraiton management system."
  ()
  :url "https://github.com/venks1/emacs-fossil"
  :commit "4a4a3e4df83ba2f1ea8bfd8aa7e9f9b2c1c32ca9"
  :revdesc "4a4a3e4df83b"
  :authors '(("Venkat Iyer" . "venkat@comit.com"))
  :maintainers '(("Alfred M. Szmidt" . "ams@gnu.org")))
