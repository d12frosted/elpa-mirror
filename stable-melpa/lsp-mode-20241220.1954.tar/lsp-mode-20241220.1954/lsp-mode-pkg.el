;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20241220.1954"
  "LSP mode."
  '((emacs         "27.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "ffc0f56074f129148cd79cb4ea26cd093454d7d6"
  :revdesc "ffc0f56074f1"
  :keywords '("languages"))
