;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20251106.745"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "32ebdf9ff04faefe71afa37ad497c9764c4ebb4c"
  :revdesc "32ebdf9ff04f"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
