(define-package "eldev" "20221117.2048" "Elisp development tool"
  '((emacs "24.4"))
  :commit "2ddf8cbe9bb4f973ecfa6012870af23b030ad6f6" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
