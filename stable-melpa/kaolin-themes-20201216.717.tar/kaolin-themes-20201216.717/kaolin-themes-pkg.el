(define-package "kaolin-themes" "20201216.717" "A set of eye pleasing themes"
  '((emacs "25.1")
    (autothemer "0.2.2")
    (cl-lib "0.6"))
  :commit "5694f27f6e17bf2d840fa04728d392b5df77e20c" :keywords
  ("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors
  (("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainer
  ("Ogden Webb" . "ogdenwebb@gmail.com")
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
