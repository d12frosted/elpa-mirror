(define-package "magik-mode" "20230727.813" "mode for editing Magik + some utils."
  '((emacs "24.4"))
  :commit "545232bde1f8f9c6b74a7a31d9e1620d23979a9a" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
