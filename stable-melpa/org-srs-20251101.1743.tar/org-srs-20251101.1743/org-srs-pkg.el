;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251101.1743"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "978501f825c2f41c0db7f1e617e4799ffdc60a8d"
  :revdesc "978501f825c2"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
