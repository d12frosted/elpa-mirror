;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261102.2212"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "904bcb41c2822a54110ed5776bf64a1b94cd1f06"
  :revdesc "904bcb41c282"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
