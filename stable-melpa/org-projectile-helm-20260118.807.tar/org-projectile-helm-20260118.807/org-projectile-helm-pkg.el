;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-projectile-helm" "20260118.807"
  "Helm functions for org-projectile."
  '((org-projectile "1.0.0")
    (helm           "2.3.1")
    (emacs          "25"))
  :url "https://github.com/IvanMalison/org-projectile"
  :commit "4303dd869b0d638bd09014702803cde50f4e7fed"
  :revdesc "4303dd869b0d"
  :keywords '("org" "projectile" "todo" "helm" "outlines")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
