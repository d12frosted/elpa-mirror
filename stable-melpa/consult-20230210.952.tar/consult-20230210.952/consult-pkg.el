(define-package "consult" "20230210.952" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.3"))
  :commit "a9a619cb5519047accf0e42932db28ef1f95594b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
