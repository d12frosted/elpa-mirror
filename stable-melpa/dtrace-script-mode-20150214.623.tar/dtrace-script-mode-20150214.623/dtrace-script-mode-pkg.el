;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dtrace-script-mode" "20150214.623"
  "DTrace code editing commands for Emacs."
  ()
  :url "https://github.com/dotemacs/dtrace-script-mode"
  :commit "a92f76c65b9fb64d448e503b4ea7ff06085be8ee"
  :revdesc "a92f76c65b9f")
