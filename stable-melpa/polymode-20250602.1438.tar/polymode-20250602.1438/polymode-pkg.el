;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polymode" "20250602.1438"
  "Extensible framework for multiple major modes."
  '((emacs "25"))
  :url "https://github.com/polymode/polymode"
  :commit "57dbda2a7140b397662db8e3250666795ec43bcc"
  :revdesc "57dbda2a7140"
  :keywords '("languages" "multi-modes" "processes")
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
