(define-package "company" "20210825.1508" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "c7234a9df0b1a624ae0633d3a7d08f92109ff85a" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
