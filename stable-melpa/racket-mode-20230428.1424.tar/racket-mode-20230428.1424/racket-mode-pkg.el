(define-package "racket-mode" "20230428.1424" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "f67cccd625e1ed9987e186b06e45f23dabcfb405" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
