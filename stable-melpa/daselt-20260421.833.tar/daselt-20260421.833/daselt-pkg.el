;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260421.833"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "8e23c3b0eda55ba9bcdaffa5ab7f179c23012163"
  :revdesc "8e23c3b0eda5"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
