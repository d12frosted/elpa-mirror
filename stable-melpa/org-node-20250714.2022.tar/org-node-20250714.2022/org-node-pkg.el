;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250714.2022"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.17.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f389c26972f144f27e89d071240b5841c9e15e9a"
  :revdesc "f389c26972f1"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
