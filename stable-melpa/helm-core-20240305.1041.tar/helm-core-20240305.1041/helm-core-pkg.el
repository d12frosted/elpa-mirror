(define-package "helm-core" "20240305.1041" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "fd5bffaa655e641ea47eacef1fa2f64b3846eee3" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
