;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260212.1747"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "d28ad88d346f663b87b51478680c8275abf177a4"
  :revdesc "d28ad88d346f"
  :keywords '("convenience"))
