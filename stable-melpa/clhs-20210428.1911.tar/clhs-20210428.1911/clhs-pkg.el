;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clhs" "20210428.1911"
  "Access the Common Lisp HyperSpec (CLHS)."
  ()
  :url "https://gitlab.com/sam-s/clhs"
  :commit "7b106c4fb5a6388ab753f94740f6dfadcdeedcbb"
  :revdesc "7b106c4fb5a6"
  :keywords '("lisp" "common lisp" "emacs" "ansi cl" "hyperspec")
  :maintainers '(("Sam Steingold" . "sds@gnu.org")))
