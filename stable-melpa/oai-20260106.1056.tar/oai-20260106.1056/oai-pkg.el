;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260106.1056"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "a319dba131c8e9137b7dc91bb07ee33271425026"
  :revdesc "a319dba131c8"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
