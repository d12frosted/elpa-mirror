;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "i3wm" "20170822.1438"
  "I3wm integration library."
  ()
  :url "https://git.flintfam.org/swf-projects/emacs-i3"
  :commit "71391dc61063fee77ad174f3b2ca25c60b41009e"
  :revdesc "71391dc61063"
  :keywords '("convenience" "extensions")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
