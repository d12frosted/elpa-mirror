;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "file-info" "20260509.754"
  "Show pretty information about current file."
  '((emacs            "28.1")
    (hydra            "0.15.0")
    (browse-at-remote "0.15.0"))
  :url "https://github.com/artawower/file-info.el"
  :commit "c20ab17ee23e7e1b07975cce9a3c2d5e3dff14f6"
  :revdesc "c20ab17ee23e"
  :authors '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers '(("Artur Yaroshenko" . "artawower@protonmail.com")))
