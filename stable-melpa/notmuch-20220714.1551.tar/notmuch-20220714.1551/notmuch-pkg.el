(define-package "notmuch" "20220714.1551" "run notmuch within emacs" 'nil :commit "349987668ae1da3ee30cdbe3a4acc11bb2219e0d" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
