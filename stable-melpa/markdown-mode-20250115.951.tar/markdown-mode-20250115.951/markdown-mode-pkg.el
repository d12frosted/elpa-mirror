;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-mode" "20250115.951"
  "Major mode for Markdown-formatted text."
  '((emacs "27.1"))
  :url "https://jblevins.org/projects/markdown-mode/"
  :commit "3c28f0c0dcb16e545aa8b4878016cbbfdeae9fa8"
  :revdesc "3c28f0c0dcb1"
  :keywords '("markdown" "github flavored markdown" "itex")
  :authors '(("Jason R. Blevins" . "jblevins@xbeta.org"))
  :maintainers '(("Jason R. Blevins" . "jblevins@xbeta.org")))
