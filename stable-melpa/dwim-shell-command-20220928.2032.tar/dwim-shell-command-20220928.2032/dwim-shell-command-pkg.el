(define-package "dwim-shell-command" "20220928.2032" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "6f599480be69437171fb4e9d58fd29b20731096f" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
