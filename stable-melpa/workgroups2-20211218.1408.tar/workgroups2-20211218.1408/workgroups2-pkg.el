(define-package "workgroups2" "20211218.1408" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "3717aaf416f69d745420603cb1f3760e2ed6a943" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
