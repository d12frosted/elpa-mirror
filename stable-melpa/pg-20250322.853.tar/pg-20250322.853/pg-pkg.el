;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20250322.853"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "8fa8881c4d29e9d9af5eb57a5f4804599e27275e"
  :revdesc "8fa8881c4d29"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
