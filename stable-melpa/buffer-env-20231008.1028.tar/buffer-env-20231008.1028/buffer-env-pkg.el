(define-package "buffer-env" "20231008.1028" "Buffer-local process environments"
  '((emacs "27.1")
    (compat "29.1"))
  :commit "9a0878dbfed33adf171bc389116d81f326161a64" :authors
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainer
  '("Augusto Stoffel" . "arstoffel@gmail.com")
  :keywords
  '("processes" "tools")
  :url "https://github.com/astoff/buffer-env")
;; Local Variables:
;; no-byte-compile: t
;; End:
