(define-package "sly" "20211222.1234" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "554e6b09d9741f6367e144a1165e3c7fa2e3a8c3" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
