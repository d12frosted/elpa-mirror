(define-package "sly" "20211222.1234" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "7f7cfece7c06cf26064d935300cb7afcf8538ad0" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
