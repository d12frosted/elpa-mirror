(define-package "python-docstring" "20231203.342" "Smart Python docstring formatting" 'nil :commit "a68663b74fb005d554ed1fb53131b9a4c6e8d051")
;; Local Variables:
;; no-byte-compile: t
;; End:
