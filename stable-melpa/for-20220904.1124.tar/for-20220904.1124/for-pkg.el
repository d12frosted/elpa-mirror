(define-package "for" "20220904.1124" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "ab4e0783b9dbf48fe95bd464dcd123bd82b48d6d" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
