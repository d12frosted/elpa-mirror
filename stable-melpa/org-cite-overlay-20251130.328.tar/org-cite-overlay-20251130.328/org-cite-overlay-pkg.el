;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-cite-overlay" "20251130.328"
  "Overlays for org-cite citations."
  '((emacs    "28.1")
    (citeproc "0.9.4"))
  :url "https://git.sr.ht/~swflint/org-cite-overlay"
  :commit "b30e7fa63779ea6adf626227bc84c0b114e66c50"
  :revdesc "b30e7fa63779"
  :keywords '("bib" "tex")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
