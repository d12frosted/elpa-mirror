;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ink-mode" "20260131.2130"
  "Major mode for writing interactive fiction in Ink."
  '((emacs "29.1"))
  :url "https://github.com/Kungsgeten/ink-mode"
  :commit "3603050b74c5f387013efe2f582fa37bc6506dfa"
  :revdesc "3603050b74c5"
  :keywords '("languages" "wp" "hypermedia"))
