;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shrface" "20250328.241"
  "Extend shr/eww with org features and analysis capability."
  '((emacs              "25.1")
    (org                "9.0")
    (language-detection "0.1.0"))
  :url "https://github.com/chenyanming/shrface"
  :commit "c4e94c45a12ce966bf038773dee3842c3a944bf0"
  :revdesc "c4e94c45a12c"
  :keywords '("faces")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
