(define-package "modus-themes" "20230115.515" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "9721c0576f9c67ff770cb8f245769e1d847bc855" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
