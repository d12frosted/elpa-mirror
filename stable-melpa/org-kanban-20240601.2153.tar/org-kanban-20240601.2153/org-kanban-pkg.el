(define-package "org-kanban" "20240601.2153" "kanban dynamic block for org-mode."
  '((s "0")
    (dash "2.17.0"))
  :commit "93ceed7e5d837c4cd7daa2ad36426669d38f4e46" :authors
  '(("Christian Köstlin" . "christian.koestlin@gmail.com"))
  :maintainers
  '(("Christian Köstlin" . "christian.koestlin@gmail.com"))
  :maintainer
  '("Christian Köstlin" . "christian.koestlin@gmail.com")
  :keywords
  '("org-mode" "org" "kanban" "tools")
  :url "http://github.com/gizmomogwai/org-kanban")
;; Local Variables:
;; no-byte-compile: t
;; End:
