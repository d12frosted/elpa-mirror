;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "call-graph" "20260212.649"
  "Generate call graph for c/c++ functions."
  '((emacs     "28.1")
    (tree-mode "1.0.0")
    (ivy       "0.10.0")
    (beacon    "1.3.4"))
  :url "https://github.com/beacoder/call-graph"
  :commit "38cb7a4488af63208d7ee1766a141453518e0abc"
  :revdesc "38cb7a4488af"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
