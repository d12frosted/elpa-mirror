;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260216.810"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "5318964b99850bd37ba3abeac73e04d0fa0736e1"
  :revdesc "5318964b9985"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
