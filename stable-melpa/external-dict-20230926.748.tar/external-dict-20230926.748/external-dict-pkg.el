(define-package "external-dict" "20230926.748" "Query external dictionary like goldendict, Bob.app etc"
  '((emacs "25.1"))
  :commit "5ff41c9151647ef68bf61eff318fc76a3fe558f2" :keywords
  '("wp" "processes")
  :url "https://repo.or.cz/external-dict.el.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
