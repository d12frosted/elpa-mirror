(define-package "ledger-mode" "20210318.26" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "3c53ecc4fd27736560db7a64587e516b26521d61")
;; Local Variables:
;; no-byte-compile: t
;; End:
