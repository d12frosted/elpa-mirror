(define-package "isortify" "20221121.1816" "(automatically) format python buffers using isort."
  '((emacs "25")
    (pythonic "0.1.0"))
  :commit "2751fb23eea4a40437e7d9bca77cbc9c06b44f3d" :authors
  '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers
  '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainer
  '("Artem Malyshev" . "proofit404@gmail.com")
  :url "https://github.com/proofit404/isortify")
;; Local Variables:
;; no-byte-compile: t
;; End:
