(define-package "good-scroll" "20210520.431" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "60fd0a7a5d663150728027bfc4e7adb33970d277" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
