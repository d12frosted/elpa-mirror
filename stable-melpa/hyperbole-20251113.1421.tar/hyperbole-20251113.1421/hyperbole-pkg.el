;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251113.1421"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "a7f6199602357532457955e98d7e15bcb136d4e6"
  :revdesc "a7f619960235"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
