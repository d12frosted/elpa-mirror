;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260512.1854"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "fd9882ea6ea162137905204172ac9aae68da35cf"
  :revdesc "fd9882ea6ea1"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
