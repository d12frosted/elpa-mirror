(define-package "cape" "20221202.1457" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "84680339ca5c195c4c1574392e71e35dc549f3d2" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
