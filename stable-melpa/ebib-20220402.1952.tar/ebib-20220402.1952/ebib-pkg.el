(define-package "ebib" "20220402.1952" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "a03b2ee3c775f9cf0348330ea2c327fe7abb8d91" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
