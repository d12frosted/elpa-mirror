;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tc" "20260112.1340"
  "A Japanese input method with T-Code on Emacs."
  ()
  :url "https://github.com/kanchoku/tc"
  :commit "5d84e847cf34545a88dc2e1555dac3aef771b21f"
  :revdesc "5d84e847cf34"
  :authors '(("Kaoru Maeda" . "maeda@src.ricoh.co.jp")
             ("Yasushi Saito" . "yasushi@cs.washington.edu")
             ("KITAJIMA Akira" . "kitajima@isc.osakac.ac.jp")))
