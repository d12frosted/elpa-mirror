;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20260827.1109"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "28ce8158a0302fbcf5c094ec708f2dff43f8a058"
  :revdesc "28ce8158a030"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
