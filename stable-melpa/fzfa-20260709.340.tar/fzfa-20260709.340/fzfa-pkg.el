;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260709.340"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "6915c93ee10ac44d85f2aec4d276f50eff047a57"
  :revdesc "6915c93ee10a"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
