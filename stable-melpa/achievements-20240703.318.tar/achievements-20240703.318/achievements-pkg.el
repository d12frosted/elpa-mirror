;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "achievements" "20240703.318"
  "Achievements for emacs usage."
  '((keyfreq "0.0.3"))
  :url "https://gitlab.com/gvol/emacs-achievements"
  :commit "c229d21ad5d1e13be08e087ab498800b2b9b7c97"
  :revdesc "c229d21ad5d1"
  :keywords '("games")
  :authors '(("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainers '(("Ivan Andrus" . "darthandrus@gmail.com")))
