;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260211.2247"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "2c5bfb6ef06d27a9589394339dadb856580a5a84"
  :revdesc "2c5bfb6ef06d"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
