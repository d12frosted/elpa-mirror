;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250519.1403"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "6eedd6c1682895f0d0b589f9d33ddd3cb91c8977"
  :revdesc "6eedd6c16828"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
