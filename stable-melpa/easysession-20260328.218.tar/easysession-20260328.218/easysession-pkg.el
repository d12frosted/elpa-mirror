;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260328.218"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "9525b49befab98b35bf0c74637e4d81a44089abe"
  :revdesc "9525b49befab"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
