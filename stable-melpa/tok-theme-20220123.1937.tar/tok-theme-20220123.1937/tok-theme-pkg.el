(define-package "tok-theme" "20220123.1937" "My theme"
  '((emacs "24.3"))
  :commit "a68728a87f63b0ddf04e50739bb29982a20f0296" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
