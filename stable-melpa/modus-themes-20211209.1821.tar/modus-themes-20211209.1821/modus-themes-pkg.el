(define-package "modus-themes" "20211209.1821" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "193f8793832eab782743a9b1409c3114d9583348" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
