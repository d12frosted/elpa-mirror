;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mdired" "20261101.2106"
  "SIMD-style commands for marked Dired items."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/mdired"
  :commit "10d2f88bea8528109816670676085979912648fe"
  :revdesc "10d2f88bea85"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
