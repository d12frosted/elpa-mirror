;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260730.1627"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "f772690e0dc99c6dbc7200811c8f57d63aff73d5"
  :revdesc "f772690e0dc9"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
