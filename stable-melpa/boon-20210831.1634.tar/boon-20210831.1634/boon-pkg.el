(define-package "boon" "20210831.1634" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "05ccaad63d01688b86b7e44955815f97fc011ec1")
;; Local Variables:
;; no-byte-compile: t
;; End:
