(define-package "evil-textobj-tree-sitter" "20220527.1400" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1")
    (evil "1.0.0")
    (tree-sitter "0.15.0"))
  :commit "f99b7af67d77b3276289d925e33029b53aadb315" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
