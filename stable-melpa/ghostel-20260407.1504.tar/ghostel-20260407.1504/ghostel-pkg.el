;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260407.1504"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "6075b647913576949fc925e50f37de384a035420"
  :revdesc "6075b6479135"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
