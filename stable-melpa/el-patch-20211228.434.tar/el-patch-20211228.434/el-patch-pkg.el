(define-package "el-patch" "20211228.434" "Future-proof your Elisp"
  '((emacs "25"))
  :commit "4a4e040fcede0c320e860571d5e96100cac05bb5" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/el-patch")
;; Local Variables:
;; no-byte-compile: t
;; End:
