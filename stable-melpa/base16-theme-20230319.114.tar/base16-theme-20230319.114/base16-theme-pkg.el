(define-package "base16-theme" "20230319.114" "Collection of themes built on combinations of 16 base colors" 'nil :commit "dcdfa86e42cba11ae1c80be6170e52236728b234" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/tinted-theming/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
