(define-package "eldoc-box" "20240529.609" "Display documentation in childframe"
  '((emacs "27.1"))
  :commit "7892a467dd1e4cc95bbf6ac86c1dd65e3c0c4445" :authors
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainer
  '("Yuan Fu" . "casouri@gmail.com")
  :url "https://github.com/casouri/eldoc-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
