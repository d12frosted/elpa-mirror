(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "ea7f34396b62ebfa9c1b847589b0deee71540a78" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
