(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "af5a424e3db51a424188252a6e8fabbfd105f624" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
