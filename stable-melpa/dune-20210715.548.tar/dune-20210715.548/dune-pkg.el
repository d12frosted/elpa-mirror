(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "fd81ea25790c7134032f1d43df0fc84cbaea979d" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
