(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "cf9d44f1ca8ea92a0cb33d822eeed1f9469696cb" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
