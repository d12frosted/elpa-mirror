(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "ebfc9966d3d03a0c6692b72d569ee15e9e16c232" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
