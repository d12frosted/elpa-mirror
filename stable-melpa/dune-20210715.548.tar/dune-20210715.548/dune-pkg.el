(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "36c9c71839ae4462452a396d3beae498d891f8ef" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
