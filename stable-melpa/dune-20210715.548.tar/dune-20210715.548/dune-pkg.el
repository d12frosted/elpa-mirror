(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "3cd240e421d62f36dfbd17c19c18e201f8743fec" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
