(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "bb3170e31650943a1ac5ed86797776f86dff3d84" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
