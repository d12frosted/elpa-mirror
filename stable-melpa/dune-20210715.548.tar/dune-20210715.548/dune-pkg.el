(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "31ef58b9bbc1dae1ae6d379c54a7635c9a703303" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
