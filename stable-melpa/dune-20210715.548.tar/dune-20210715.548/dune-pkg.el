(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "70795367d8f583eb716f08c6df68f75a224f994a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
