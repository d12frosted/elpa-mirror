(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "35f6b02814bd0b0be80da0aab938c57f531a2cf5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
