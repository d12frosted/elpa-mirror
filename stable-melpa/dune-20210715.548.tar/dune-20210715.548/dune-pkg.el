(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "16cb82616279225eff66ffb3195f7c73908c1719" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
