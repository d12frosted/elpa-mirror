(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "48bd29decb847bd9357aceeca9ad1c916f199913" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
