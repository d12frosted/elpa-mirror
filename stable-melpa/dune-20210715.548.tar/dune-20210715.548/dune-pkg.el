(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "6b69c61040f9c298166fe3c2e4e29109e5b1834e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
