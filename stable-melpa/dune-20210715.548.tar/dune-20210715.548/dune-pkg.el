(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "fd4c4ae48370f7b44bf130e3bd424c88be530b62" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
