(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "e5e963a2dae220a4b1358ac7a31583fe4a849a8a" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
