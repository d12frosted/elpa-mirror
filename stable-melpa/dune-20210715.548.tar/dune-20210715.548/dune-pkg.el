(define-package "dune" "20210715.548" "Integration with the dune build system" 'nil :commit "58b3afcf86a9869ed52a5ddaf608b3adf9016164" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
