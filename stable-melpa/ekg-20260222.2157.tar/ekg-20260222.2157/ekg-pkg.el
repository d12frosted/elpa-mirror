;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260222.2157"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "9358c6c71fd8d585c1fabd3612090f83f1526228"
  :revdesc "9358c6c71fd8"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
