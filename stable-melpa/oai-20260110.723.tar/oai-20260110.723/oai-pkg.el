;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260110.723"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "e080a0cd7e50b8a66f240e256615953a6502d063"
  :revdesc "e080a0cd7e50"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
