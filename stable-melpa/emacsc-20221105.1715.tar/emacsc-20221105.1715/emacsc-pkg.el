(define-package "emacsc" "20221105.1715" "helper for emacsc(1)" 'nil :commit "f7634a86c3643a6432dda3897bd524957cf9ff1f" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("tools")
  :url "https://github.com/knu/emacsc")
;; Local Variables:
;; no-byte-compile: t
;; End:
