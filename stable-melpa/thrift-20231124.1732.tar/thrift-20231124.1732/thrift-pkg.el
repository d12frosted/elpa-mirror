(define-package "thrift" "20231124.1732" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "909a86274e3a88c7a5c3cc844d4daeaf62d6c74f" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
