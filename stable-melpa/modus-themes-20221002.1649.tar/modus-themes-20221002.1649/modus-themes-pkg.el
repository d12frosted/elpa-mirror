(define-package "modus-themes" "20221002.1649" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "7b9304f668f44ef5772d2ea626be9808859827ea" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
