(define-package "wildcharm-theme" "20231119.749" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "2d6bcb77f1d7c6c1c87ee9e2251449b6ffd4d91e" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
