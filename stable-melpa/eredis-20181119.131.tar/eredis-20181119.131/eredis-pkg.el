;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eredis" "20181119.131"
  "Eredis, a Redis client in emacs lisp."
  '((dash "0"))
  :url "https://github.com/justinhj/eredis/"
  :commit "cfbfc25832f6fbc507bdd56b02e3a0b851a3c368"
  :revdesc "cfbfc25832f6"
  :keywords '("redis" "api" "tools" "org")
  :authors '(("Justin Heyes-Jones" . "justinhj@gmail.com"))
  :maintainers '(("Justin Heyes-Jones" . "justinhj@gmail.com")))
