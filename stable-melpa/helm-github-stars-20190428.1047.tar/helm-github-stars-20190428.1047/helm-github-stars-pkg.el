;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-github-stars" "20190428.1047"
  "Helm interface for your github's stars."
  '((helm  "1.6.8")
    (emacs "24.4"))
  :url "https://github.com/Sliim/helm-github-stars"
  :commit "c891690218b0d8b957ea6cb45b1b6cffd15a6950"
  :revdesc "c891690218b0"
  :keywords '("helm" "github" "stars")
  :authors '(("Sliim" . "sliim@mailoo.org")
             ("xuchunyang" . "xuchunyang56@gmail.com"))
  :maintainers '(("Sliim" . "sliim@mailoo.org")
                 ("xuchunyang" . "xuchunyang56@gmail.com")))
