;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250517.1402"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "113b800a2486dbce8e2a8cf315713c17420b726d"
  :revdesc "113b800a2486"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
