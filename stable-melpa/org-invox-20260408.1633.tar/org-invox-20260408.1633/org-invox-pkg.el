;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-invox" "20260408.1633"
  "Invoice management for contractors using Org mode."
  '((emacs "27.1")
    (org   "9.0"))
  :url "https://github.com/a-manumohan/org-invox"
  :commit "6725996a43a1f223caf202eed9d81efd08adf5a7"
  :revdesc "6725996a43a1"
  :keywords '("outlines" "tools")
  :authors '(("Manu Mohan" . "me@manumohan.net"))
  :maintainers '(("Manu Mohan" . "me@manumohan.net")))
