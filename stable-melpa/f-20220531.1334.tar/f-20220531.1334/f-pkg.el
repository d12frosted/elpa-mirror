(define-package "f" "20220531.1334" "Modern API for working with files and directories"
  '((s "1.7.0")
    (dash "2.2.0"))
  :commit "2a0fb2521cc8fa889bf6e64b8e65825433448188" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("files" "directories")
  :url "http://github.com/rejeep/f.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
