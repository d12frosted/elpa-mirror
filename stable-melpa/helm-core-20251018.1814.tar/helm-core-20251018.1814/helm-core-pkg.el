;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251018.1814"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "1d0ef3c71f2461d81b4ebe5c064f9c1bbfb2b124"
  :revdesc "1d0ef3c71f24"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
