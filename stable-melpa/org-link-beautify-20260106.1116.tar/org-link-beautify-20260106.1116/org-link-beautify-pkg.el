;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260106.1116"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "62955313268e27744ac2117ed5be9d2c362ded05"
  :revdesc "62955313268e"
  :keywords '("hypermedia"))
