(define-package "ledger-mode" "20240320.2009" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "dda6e4ce4fb74f241f590930bbfb3a3f51acce93")
;; Local Variables:
;; no-byte-compile: t
;; End:
