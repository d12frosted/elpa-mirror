(define-package "ergoemacs-mode" "20210402.1520" "Emacs mode based on common modern interface and ergonomics."
  '((emacs "24.1")
    (undo-tree "0.6.5")
    (cl-lib "0.5"))
  :commit "78e8d55cf9c1e7287b869a66c500ff403199e92a" :authors
  '(("Xah Lee" . "xah@xahlee.org")
    ("David Capello" . "davidcapello@gmail.com")
    ("Matthew L. Fidler" . "matthew.fidler@gmail.com"))
  :maintainer
  '("Matthew L. Fidler" . "matthew.fidler@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ergoemacs/ergoemacs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
