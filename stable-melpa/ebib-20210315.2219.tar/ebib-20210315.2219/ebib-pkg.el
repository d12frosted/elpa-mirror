(define-package "ebib" "20210315.2219" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "8ceeaf7045c7a785558c48e6b2ae385ce6ec49cc" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
