;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flappymacs" "20171023.1004"
  "Flappybird clone for emacs."
  ()
  :url "https://github.com/taksatou/flappymacs"
  :commit "fac0011983251d5c44f4ed1eacac03f5de3caac4"
  :revdesc "fac001198325"
  :keywords '("games"))
