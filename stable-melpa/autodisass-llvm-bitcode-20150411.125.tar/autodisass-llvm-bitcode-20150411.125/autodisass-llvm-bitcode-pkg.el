(define-package "autodisass-llvm-bitcode" "20150411.125" "Automatically disassemble LLVM bitcode" 'nil :commit "d2579e3a1427af2dc947c343e49eb3434078bf04")
;; Local Variables:
;; no-byte-compile: t
;; End:
