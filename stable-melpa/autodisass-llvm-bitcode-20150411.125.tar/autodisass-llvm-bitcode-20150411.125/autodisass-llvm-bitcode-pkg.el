;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autodisass-llvm-bitcode" "20150411.125"
  "Automatically disassemble LLVM bitcode."
  ()
  :url "https://github.com/gbalats/autodisass-llvm-bitcode"
  :commit "14bb1bfe2be3b04d6e0c87a7a9d1e88ce15506d0"
  :revdesc "14bb1bfe2be3"
  :keywords '("convenience" "data" "files")
  :authors '(("George Balatsouras" . "gbalatsgmailcom"))
  :maintainers '(("George Balatsouras" . "gbalatsgmailcom")))
