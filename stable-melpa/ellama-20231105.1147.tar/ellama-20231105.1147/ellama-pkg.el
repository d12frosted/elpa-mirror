(define-package "ellama" "20231105.1147" "Tool for interacting with LLMs"
  '((emacs "28.1")
    (llm "0.5.2")
    (spinner "1.7.4"))
  :commit "702042c0bf79a4e81133fb2acb9031f5eae817b0" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
