;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-fr" "20160920.953"
  "Use frame title as screen tab."
  '((elscreen "0")
    (seq      "1.11"))
  :url "https://github.com/rocher/elscreen-fr"
  :commit "b9c11f80d277086d5d5bf88623e15fc7adbbbe3c"
  :revdesc "b9c11f80d277"
  :authors '(("Francesc Rocher" . "francesc.rocher@gmail.com"))
  :maintainers '(("Francesc Rocher" . "francesc.rocher@gmail.com")))
