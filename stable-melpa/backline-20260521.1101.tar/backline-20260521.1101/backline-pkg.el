;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backline" "20260521.1101"
  "Preserve appearance of outline headings."
  '((emacs               "28.1")
    (compat              "30.1")
    (outline-minor-faces "1.2"))
  :url "https://github.com/tarsius/backline"
  :commit "c5b564f9904967ee56af9de35e5962372fad3e44"
  :revdesc "c5b564f99049"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev")))
