;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keydef" "20090428.1931"
  "A simpler way to define keys, with kbd syntax."
  ()
  :url "https://github.com/emacsorphanage/keydef"
  :commit "dff2be9f58d12d8c6a490ad0c1b2b10b55528dc0"
  :revdesc "dff2be9f58d1"
  :keywords '("convenience" "lisp" "customization" "keyboard" "keys")
  :authors '(("Michael John Downes" . "mjd@ams.org"))
  :maintainers '(("Michael John Downes" . "mjd@ams.org")))
