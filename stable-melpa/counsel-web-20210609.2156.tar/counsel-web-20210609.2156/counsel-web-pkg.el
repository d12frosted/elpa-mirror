;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-web" "20210609.2156"
  "Search the Web using Ivy."
  '((emacs   "25.1")
    (counsel "0.13.0")
    (request "0.3.0"))
  :url "https://github.com/mnewt/counsel-web"
  :commit "1359b3b204fcdac7a3d6664c7d540a88b5acecfd"
  :revdesc "1359b3b204fc"
  :keywords '("convenience" "hypermedia")
  :authors '(("Matthew Sojourner Newton" . "matt@mnewton.com"))
  :maintainers '(("Matthew Sojourner Newton" . "matt@mnewton.com")))
