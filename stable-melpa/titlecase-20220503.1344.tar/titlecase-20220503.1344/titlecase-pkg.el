(define-package "titlecase" "20220503.1344" "Title-case phrases"
  '((emacs "25.1"))
  :commit "dafaa6ca09fdf1ae8413159cae2b5d74e9713440" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://github.com/duckwork/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
