;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk" "20260325.1235"
  "Daredevil SKK (Simple Kana to Kanji conversion program)."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :url "https://github.com/skk-dev/ddskk"
  :commit "645a9d9a678e38d7723db033a1a810b3fbff6c52"
  :revdesc "645a9d9a678e"
  :keywords '("japanese" "mule" "input method")
  :authors '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp")))
