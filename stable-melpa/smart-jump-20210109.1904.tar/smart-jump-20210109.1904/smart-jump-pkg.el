(define-package "smart-jump" "20210109.1904" "Smart go to definition."
  '((emacs "25.1"))
  :commit "14a045544eda64d8a2dd638f5d754479777be290" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("tools")
  :url "https://github.com/jojojames/smart-jump")
;; Local Variables:
;; no-byte-compile: t
;; End:
