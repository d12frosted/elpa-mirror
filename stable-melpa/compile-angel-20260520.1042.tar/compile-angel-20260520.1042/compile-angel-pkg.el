;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260520.1042"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "ea0420efbe252ae2079d1bf85629ea0bbf22541d"
  :revdesc "ea0420efbe25"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
