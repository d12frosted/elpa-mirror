;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260613.1407"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "35b87c30825340b6f2ef645d86c32be8134dc6a0"
  :revdesc "35b87c308253"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
