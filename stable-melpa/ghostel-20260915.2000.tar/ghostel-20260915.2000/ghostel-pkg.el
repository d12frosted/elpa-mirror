;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260915.2000"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "378320a5d10a1e868cfaee0f7fb71c1ca59b5828"
  :revdesc "378320a5d10a"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
