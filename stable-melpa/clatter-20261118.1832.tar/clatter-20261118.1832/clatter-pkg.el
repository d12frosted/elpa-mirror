;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20261118.1832"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "b430961970a23047d99ccd7d4c39962b351f2365"
  :revdesc "b430961970a2"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
