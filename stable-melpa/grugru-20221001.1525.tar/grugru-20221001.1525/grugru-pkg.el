(define-package "grugru" "20221001.1525" "Rotate text at point"
  '((emacs "24.4"))
  :commit "d03ccd6314d474f3e6beadc69c0b6ce32af62f07" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
