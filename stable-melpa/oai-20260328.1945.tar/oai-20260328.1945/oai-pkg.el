;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260328.1945"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "5a0fb254ed875812aed55a6111ff8af7774e65a2"
  :revdesc "5a0fb254ed87"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
