;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "futhark-mode" "20250311.1518"
  "Major mode for editing Futhark source files."
  '((emacs       "24.3")
    (cl-lib      "0.5")
    (reformatter "0.4"))
  :url "https://github.com/diku-dk/futhark-mode"
  :commit "ac363a47f6b24b9af5b817fb7bd94c16ebd46c3d"
  :revdesc "ac363a47f6b2"
  :keywords '("languages"))
