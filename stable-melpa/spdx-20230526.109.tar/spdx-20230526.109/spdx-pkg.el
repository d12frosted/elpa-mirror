(define-package "spdx" "20230526.109" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "a50016ca96152c40037c23325656355e54535f6c" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
