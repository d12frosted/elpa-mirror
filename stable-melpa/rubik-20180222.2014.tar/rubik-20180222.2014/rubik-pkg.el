;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rubik" "20180222.2014"
  "Rubik's Cube."
  '((cl-lib "1.0")
    (emacs  "25.3"))
  :url "https://github.com/Kurvivor19/rubik-mode"
  :commit "c8dab1726463dbc9042a0b00186e4a8df02eb868"
  :revdesc "c8dab1726463"
  :keywords '("games")
  :authors '(("Ivan 'Kurvivor' Truskov" . "trus19@gmail.com"))
  :maintainers '(("Ivan 'Kurvivor' Truskov" . "trus19@gmail.com")))
