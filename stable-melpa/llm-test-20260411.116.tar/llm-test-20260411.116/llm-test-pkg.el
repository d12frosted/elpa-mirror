;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260411.116"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "4ba5c07347882f8c6f85b550cd3391bf87ec8b01"
  :revdesc "4ba5c0734788"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
