;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260410.1636"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "7f3f558eb81b724f4f1f0a6bc59a699f4aa890a5"
  :revdesc "7f3f558eb81b"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
