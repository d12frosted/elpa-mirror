(define-package "for" "20220922.1808" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "389c4b59cb85de2dc96ee0be5826e3f30984c48d" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
