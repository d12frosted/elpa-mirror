;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiny" "20220910.1929"
  "Quickly generate linear ranges in Emacs."
  ()
  :url "https://github.com/abo-abo/tiny"
  :commit "c107480fca7e42737c51b2afaa33ac31e92a7290"
  :revdesc "c107480fca7e"
  :keywords '("convenience")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
