;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260826.1644"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "1083724ca89bafb848bed1f3de088a6f08966b25"
  :revdesc "1083724ca89b"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
