;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apparmor-mode" "20260428.144"
  "Major mode for editing AppArmor policy files."
  '((emacs "26.1"))
  :url "https://gitlab.com/apparmor/apparmor-mode"
  :commit "945ca073a9123ae3b156631d738f2bce8518b044"
  :revdesc "945ca073a912"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
