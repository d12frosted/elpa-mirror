(define-package "proof-general" "20220309.4" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "d9cfe74845e1f77017406e3327e7502f17bab063" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
