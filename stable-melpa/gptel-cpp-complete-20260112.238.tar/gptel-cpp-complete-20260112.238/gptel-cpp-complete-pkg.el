;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-cpp-complete" "20260112.238"
  "GPTel-powered C++ completion."
  '((emacs "30.1")
    (eglot "1.19")
    (gptel "0.9.8"))
  :url "https://github.com/beacoder/gptel-cpp-complete"
  :commit "cdf6a802c77906995ac87f2e64ac9df09a948e8e"
  :revdesc "cdf6a802c779"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
