(define-package "embark" "20210207.2220" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "a0c785013153bfbcddc463348320d6e2444dbcf5" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
