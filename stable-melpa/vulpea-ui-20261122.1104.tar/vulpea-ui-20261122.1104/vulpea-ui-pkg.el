;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20261122.1104"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "b4cc5043d7004c7af48e1a16a7ca89f154d0180e"
  :revdesc "b4cc5043d700"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
