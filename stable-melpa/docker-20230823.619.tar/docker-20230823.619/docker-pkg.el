(define-package "docker" "20230823.619" "Interface to Docker"
  '((aio "1.0")
    (dash "2.19.1")
    (emacs "26.1")
    (s "1.12.0")
    (tablist "1.0")
    (transient "0.3.7"))
  :commit "84f68caaa50209fcb373604025eb3aa64933641f" :authors
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainer
  '("Philippe Vaucher" . "philippe.vaucher@gmail.com")
  :keywords
  '("filename" "convenience")
  :url "https://github.com/Silex/docker.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
