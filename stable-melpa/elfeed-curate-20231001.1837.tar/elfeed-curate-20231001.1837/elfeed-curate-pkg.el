(define-package "elfeed-curate" "20231001.1837" "Elfeed entry curation"
  '((emacs "25.1")
    (elfeed "3.4.1"))
  :commit "1a099323cafcb3f9176c5d7ca7fbe539f7dd77bc" :authors
  '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainers
  '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainer
  '("Robert Nadler" . "robert.nadler@gmail.com")
  :keywords
  '("news")
  :url "https://github.com/rnadler/elfeed-curate")
;; Local Variables:
;; no-byte-compile: t
;; End:
