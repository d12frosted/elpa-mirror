(define-package "stimmung-themes" "20220906.643" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "4ff97e9d781df9a33dfaf3724d97b072d5c1f55a" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
