(define-package "consult" "20230206.1515" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.2"))
  :commit "d20b238c2fb4d51c833378d438e4f2049bff7c14" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
