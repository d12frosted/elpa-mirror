(define-package "pyim-smzmdict" "20210505.1445" "Sanma(triple) Zhengma dict for pyim"
  '((pyim "3.7"))
  :commit "fcddbde17a04d174c7353548056524687f7be8d2" :authors
  '(("Yue Shi (Zhizhi)"))
  :maintainer
  '("Yuanchen Xie")
  :keywords
  '("convenience" "i18n" "pyim" "chinese" "zhengma")
  :url "https://github.com/p1uxtar/pyim-smzmdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
