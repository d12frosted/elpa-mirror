(define-package "org-tag-beautify" "20230610.1559" "Beautify Org mode tags"
  '((emacs "26.1")
    (org-pretty-tags "0.2.2")
    (nerd-icons "0.0.1"))
  :commit "569d2fe6548bebd4171c8410cdb104c0321918be" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-tag-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
