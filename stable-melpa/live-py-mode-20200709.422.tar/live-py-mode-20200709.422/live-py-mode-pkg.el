(define-package "live-py-mode" "20200709.422" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "185da3530e3145b7fea7d15e33a8b581bbe3a111" :authors
  (("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  ("Don Kirkby http://donkirkby.github.io")
  :keywords
  ("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
