;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260316.944"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "8edf3bfcc3b631744fc2d7abcb2ec082999029dd"
  :revdesc "8edf3bfcc3b6"
  :keywords '("data" "extensions"))
