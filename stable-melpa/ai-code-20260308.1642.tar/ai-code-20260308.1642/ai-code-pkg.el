;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260308.1642"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "cfea5401a4c4762909a3068ce4a3c384b9124203"
  :revdesc "cfea5401a4c4"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
