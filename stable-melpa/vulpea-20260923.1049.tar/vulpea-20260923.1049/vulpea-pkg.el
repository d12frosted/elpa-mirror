;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260923.1049"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "8fd122f042f3af2d7d56dbb2f4fb59300ec08a9e"
  :revdesc "8fd122f042f3"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
