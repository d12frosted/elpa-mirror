;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20260513.1808"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "349cd6733f1441e7e004c43bd4f9a4f2e64095d1"
  :revdesc "349cd6733f14"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
