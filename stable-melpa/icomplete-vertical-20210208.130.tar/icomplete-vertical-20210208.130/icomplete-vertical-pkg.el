(define-package "icomplete-vertical" "20210208.130" "Display icomplete candidates vertically"
  '((emacs "25.1"))
  :commit "1372ef096297e5f92f08be8dd43ec8cc6b6b85a4" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
