;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260519.2113"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "d7bb2bb16312eaa0854985ae86cb115bea75addc"
  :revdesc "d7bb2bb16312"
  :keywords '("files"))
