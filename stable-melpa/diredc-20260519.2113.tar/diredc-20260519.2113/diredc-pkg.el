;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260519.2113"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "bcd9c1d9045581b83a4d127f7ed663ba9779f0dc"
  :revdesc "bcd9c1d90455"
  :keywords '("files"))
