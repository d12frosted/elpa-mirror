;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261120.2132"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "e92dc775a2e0a2e9c4eb1de7a8ad9b76909338a8"
  :revdesc "e92dc775a2e0"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
