;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250115.1919"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.8"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "76d04ccadf15b72b6a580556d5c37b09e861e57f"
  :revdesc "76d04ccadf15"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
