;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20250609.1553"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "43aa9a558802b183c2625aca45f19ee348acff55"
  :revdesc "43aa9a558802"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
