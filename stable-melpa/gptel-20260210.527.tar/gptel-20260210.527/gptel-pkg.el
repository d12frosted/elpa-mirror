;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260210.527"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "03f87d338efc5c1d623d8de1c193f80fb7157580"
  :revdesc "03f87d338efc"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
