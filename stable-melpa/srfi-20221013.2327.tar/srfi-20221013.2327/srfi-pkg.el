(define-package "srfi" "20221013.2327" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "021d18686419c14ef4482b4d77b32614af55413d" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
