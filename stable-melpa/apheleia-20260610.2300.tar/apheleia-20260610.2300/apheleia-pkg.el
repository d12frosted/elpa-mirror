;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20260610.2300"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "4159750ee44edef9c14570810dbfb6efcbb7657e"
  :revdesc "4159750ee44e"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
