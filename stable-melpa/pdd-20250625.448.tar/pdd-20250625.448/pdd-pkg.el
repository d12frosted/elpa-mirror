;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250625.448"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "459b7d190318ad9e1f1109092c3a1550418915da"
  :revdesc "459b7d190318"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
