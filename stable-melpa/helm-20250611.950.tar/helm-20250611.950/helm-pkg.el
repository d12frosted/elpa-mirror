;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250611.950"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.3")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "7ea099145b1797fc88990f0d60830daabdd4e6b9"
  :revdesc "7ea099145b17"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
