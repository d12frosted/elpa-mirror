;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260608.2319"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6af6d6c41b6ca5abdd0fcc159c5add83a850a965"
  :revdesc "6af6d6c41b6c")
