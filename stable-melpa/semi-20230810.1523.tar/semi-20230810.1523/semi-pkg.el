(define-package "semi" "20230810.1523" "A library to provide MIME features."
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9"))
  :commit "9370961ddcee78e389e44b36d38c3d93f8351619")
;; Local Variables:
;; no-byte-compile: t
;; End:
