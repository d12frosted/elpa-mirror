(define-package "khardel" "20230903.917" "Integrate with khard"
  '((emacs "27.1")
    (yaml-mode "0.0.13"))
  :commit "1c0a0e7c817250c1d0ffc8cff9cc1998e746ea96" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://github.com/DamienCassou/khardel")
;; Local Variables:
;; no-byte-compile: t
;; End:
