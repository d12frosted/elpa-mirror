;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251117.310"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "d0e39240da83d106189f5c3e06f90fb1c1132872"
  :revdesc "d0e39240da83"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
