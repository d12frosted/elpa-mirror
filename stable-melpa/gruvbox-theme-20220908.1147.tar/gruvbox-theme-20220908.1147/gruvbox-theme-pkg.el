(define-package "gruvbox-theme" "20220908.1147" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "9025a0a72292b3d73c29d6bea21b3f8606903222" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
