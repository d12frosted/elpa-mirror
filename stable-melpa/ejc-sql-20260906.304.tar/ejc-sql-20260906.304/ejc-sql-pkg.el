;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20260906.304"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "26.3")
    (clomacs "0.0.5")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "0324fde684fbf81b8eb4290e91b4aac918cdde19"
  :revdesc "0324fde684fb"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
