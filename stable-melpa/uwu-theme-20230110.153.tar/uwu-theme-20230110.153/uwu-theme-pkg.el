(define-package "uwu-theme" "20230110.153" "An awesome dark color scheme"
  '((emacs "24.1"))
  :commit "6b66376b9d7053eb9c23449a601d24511a0b44e6" :authors
  '(("Kevin Borling"))
  :maintainers
  '(("Kevin Borling"))
  :maintainer
  '("Kevin Borling")
  :keywords
  '("custom themes" "dark" "faces")
  :url "https://github.com/kborling/uwu-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
