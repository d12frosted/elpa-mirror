(define-package "company-spell" "20230723.2249" "Autocompleting spelling for Company"
  '((emacs "24.4")
    (company "0.9.13"))
  :commit "34c3e40af2e8b97e137478d98c5982e3fb2ceb3c" :keywords
  '("wp")
  :url "https://github.com/enzuru/company-spell")
;; Local Variables:
;; no-byte-compile: t
;; End:
