;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261102.1127"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "3f7d1a9ed7dbe77d36bc526bef6d539615cf6bb2"
  :revdesc "3f7d1a9ed7db")
