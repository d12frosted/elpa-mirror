;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260510.1900"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "dc77cf787a6dbe864423e54b801966b251684581"
  :revdesc "dc77cf787a6d"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
