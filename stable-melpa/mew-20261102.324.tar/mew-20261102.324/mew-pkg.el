;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261102.324"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "2dd6a0e15d9bc1bf4aec582aab013280cbdb2756"
  :revdesc "2dd6a0e15d9b")
