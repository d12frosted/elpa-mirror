;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "racket-mode" "20251027.1412"
  "Racket editing, REPL, and more."
  '((emacs  "25.1")
    (compat "30.0.2.0"))
  :url "https://www.racket-mode.com/"
  :commit "0fc6e9002324cc51ddc09ae0ebec80b8a25990d5"
  :revdesc "0fc6e9002324"
  :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")))
