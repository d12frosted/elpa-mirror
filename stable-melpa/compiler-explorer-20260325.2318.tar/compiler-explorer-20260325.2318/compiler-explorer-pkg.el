;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "20260325.2318"
  "Compiler explorer client (godbolt.org)."
  '((emacs "28.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "e26a4dac90ca2ceed26b77470bdbea097e877aa4"
  :revdesc "e26a4dac90ca"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
