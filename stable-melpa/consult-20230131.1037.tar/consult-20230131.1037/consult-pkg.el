(define-package "consult" "20230131.1037" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "c2858a52a186e71078b4d3a0116344702c470f01" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
