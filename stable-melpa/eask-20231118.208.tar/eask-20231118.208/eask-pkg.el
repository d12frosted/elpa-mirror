(define-package "eask" "20231118.208" "Core Eask APIs, for Eask CLI development"
  '((emacs "26.1")
    (dash "2.14.1"))
  :commit "2c9ac65bb6c12e1f6f612feebaa1441ca7cd69cf" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("lisp" "eask" "api")
  :url "https://github.com/emacs-eask/eask")
;; Local Variables:
;; no-byte-compile: t
;; End:
