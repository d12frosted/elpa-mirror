;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260712.921"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "095f493b6e9091d41247d2d4a741c84f9fc8158c"
  :revdesc "095f493b6e90"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
