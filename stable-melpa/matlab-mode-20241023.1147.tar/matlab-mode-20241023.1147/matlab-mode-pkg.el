;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241023.1147"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "05abbbd02adbdaf21a3fda5e2bc4c559ded4534a"
  :revdesc "05abbbd02adb"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")))
