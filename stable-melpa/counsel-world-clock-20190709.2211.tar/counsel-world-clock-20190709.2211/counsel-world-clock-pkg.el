;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-world-clock" "20190709.2211"
  "Display world clock using Ivy."
  '((ivy "0.9.0")
    (s   "1.12.0"))
  :url "https://github.com/kchenphy/counsel-world-clock"
  :commit "674e4c6b82a92ea765af97cc5f017b357284c7dc"
  :revdesc "674e4c6b82a9"
  :authors '(("Kuang Chen" . "http://github.com/kchenphy"))
  :maintainers '(("Kuang Chen" . "http://github.com/kchenphy")))
