;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20241105.1328"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "ac505abdc0d20eba2d1222f8552e4422338c2843"
  :revdesc "ac505abdc0d2"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
