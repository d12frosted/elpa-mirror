(define-package "fennel-mode" "20230408.619" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "dd2d0845cd8f21f6487c4e8ca5ea104d1fcba11a" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
