(define-package "kanagawa-theme" "20231023.114" "Retro elegant theme"
  '((autothemer "0.2.18")
    (emacs "28.1"))
  :commit "08debfc56e052ed69c7ecc3b08c687bb5af4a33c" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/Meritamen/kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
