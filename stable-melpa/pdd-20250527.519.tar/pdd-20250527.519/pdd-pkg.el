;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250527.519"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "582f5afb79d6b1c3abcc34ba30ff592ba3fc9775"
  :revdesc "582f5afb79d6"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
