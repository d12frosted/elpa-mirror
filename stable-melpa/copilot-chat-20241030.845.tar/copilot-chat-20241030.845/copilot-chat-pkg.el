;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20241030.845"
  "Copilot chat interface."
  '((request       "0.3.2")
    (markdown-mode "2.6")
    (emacs         "27.1")
    (chatgpt-shell "1.6.1")
    (magit         "4.0.0"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "fa428ee5aa3850f4e8d067b11c8120a6ce7caa66"
  :revdesc "fa428ee5aa38"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
