(define-package "hammy" "20230830.2115" "Programmable, interactive interval timers"
  '((emacs "28.1")
    (ts "0.2.2"))
  :commit "a3bd00304cd9542e9c394e5c622e2fd74aa2133e" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/hammy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
