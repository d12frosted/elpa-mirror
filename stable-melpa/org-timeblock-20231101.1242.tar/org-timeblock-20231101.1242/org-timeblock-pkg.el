(define-package "org-timeblock" "20231101.1242" "Interactive SVG calendar for orgmode tasks"
  '((emacs "28.1")
    (compat "29.1")
    (org-ql "0.7")
    (org "9.0")
    (svg "1.1")
    (persist "0.5"))
  :commit "3123e2a2b2e6c9ddc8e4853edcdd66a23e58d67c" :authors
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainers
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainer
  '("Ilya Chernyshov" . "ichernyshovvv@gmail.com")
  :keywords
  '("org" "calendar" "timeblocking" "agenda")
  :url "https://github.com/ichernyshovvv/org-timeblock")
;; Local Variables:
;; no-byte-compile: t
;; End:
