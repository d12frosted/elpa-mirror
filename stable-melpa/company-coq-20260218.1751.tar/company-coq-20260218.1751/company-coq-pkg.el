;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-coq" "20260218.1751"
  "A collection of extensions for Proof General's Coq mode."
  '((cl-lib       "0.5")
    (dash         "2.12.1")
    (yasnippet    "0.11.0")
    (company      "0.8.12")
    (company-math "1.1"))
  :url "https://github.com/cpitclaudel/company-coq"
  :commit "4b9abf2059079d1b7b7d07a6240182a5e432791f"
  :revdesc "4b9abf205907"
  :keywords '("convenience" "languages")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
