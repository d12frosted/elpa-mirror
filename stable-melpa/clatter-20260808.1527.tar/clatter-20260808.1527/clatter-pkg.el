;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260808.1527"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "7284e039dca46a512e25288c9d644ce8f21aeea1"
  :revdesc "7284e039dca4"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
