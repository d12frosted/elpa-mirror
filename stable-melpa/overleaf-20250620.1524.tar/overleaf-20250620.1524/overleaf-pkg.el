;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250620.1524"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "a7691de63a66aa2b94a7b9cb860f6ecdbe1526cd"
  :revdesc "a7691de63a66"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
