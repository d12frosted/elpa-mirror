(define-package "kmacro-x" "20230421.2039" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "7da5e37f8c2f7b02858e132929cb970027729702" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
