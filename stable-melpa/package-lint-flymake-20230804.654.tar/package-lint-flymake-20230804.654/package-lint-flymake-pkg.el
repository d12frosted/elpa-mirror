(define-package "package-lint-flymake" "20230804.654" "A package-lint Flymake backend"
  '((emacs "26.1")
    (package-lint "0.5"))
  :commit "bc1ccda5e9accefcafa42712a274197a4b465733" :url "https://github.com/purcell/package-lint")
;; Local Variables:
;; no-byte-compile: t
;; End:
