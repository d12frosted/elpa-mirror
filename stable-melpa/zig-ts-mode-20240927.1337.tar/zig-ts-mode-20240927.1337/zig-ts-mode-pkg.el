(define-package "zig-ts-mode" "20240927.1337" "Tree Sitter support for Zig"
  '((emacs "29.1"))
  :commit "5476b28cbf61712db09bb6f2585274c748ccce3a" :authors
  '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers
  '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainer
  '("meowking" . "mr.meowking@tutamail.com")
  :keywords
  '("zig" "languages" "tree-sitter")
  :url "https://codeberg.org/meow_king/zig-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
