;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20251209.842"
  "Copilot chat interface."
  '((emacs         "29.1")
    (aio           "1.0")
    (request       "0.3.2")
    (transient     "0.8.3")
    (polymode      "0.2.2")
    (org           "9.4.6")
    (markdown-mode "2.6")
    (shell-maker   "0.76.2")
    (mcp           "0.1.0"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "0bd5412232f7ddc144552958dffdcd8679a5f8ab"
  :revdesc "0bd5412232f7"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
