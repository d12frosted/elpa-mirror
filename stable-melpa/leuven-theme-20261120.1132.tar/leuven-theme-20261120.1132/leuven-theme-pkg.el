;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "20261120.1132"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "da162cd6a63b13c2ea359b022109961c9d1bf1af"
  :revdesc "da162cd6a63b"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
