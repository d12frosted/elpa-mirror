;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20251020.1003"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "db349d4a0ca152e7c74709763a437992d22ea490"
  :revdesc "db349d4a0ca1"
  :keywords '("convenience" "text"))
