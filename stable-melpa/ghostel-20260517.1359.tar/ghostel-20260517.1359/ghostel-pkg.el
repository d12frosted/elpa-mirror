;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260517.1359"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "fd383083d4ee35decbf132ca8631afd7501a8920"
  :revdesc "fd383083d4ee"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
