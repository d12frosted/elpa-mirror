(define-package "cape" "20240130.1750" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "e60773ec02e82140dda5a36df71aab052cfde02a" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "text")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
