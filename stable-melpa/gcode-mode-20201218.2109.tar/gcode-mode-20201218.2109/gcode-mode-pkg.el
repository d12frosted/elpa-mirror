(define-package "gcode-mode" "20201218.2109" "Simple G-Code major mode"
  '((emacs "24.4"))
  :commit "a1e2c6cbf4e364991ab2209d5cd5a3b698d459d9" :keywords
  ("gcode" "languages" "highlight" "syntax")
  :authors
  (("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainer
  ("Yuri D'Elia" . "wavexx@thregr.org")
  :url "https://gitlab.com/wavexx/gcode-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
