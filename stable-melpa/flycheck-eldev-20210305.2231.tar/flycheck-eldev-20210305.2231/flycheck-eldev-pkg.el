(define-package "flycheck-eldev" "20210305.2231" "Eldev support in Flycheck"
  '((flycheck "32")
    (dash "2.17")
    (emacs "24.4"))
  :commit "9c605a579186a27ba0ff2b0486d84381a9b73f49" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("tools" "convenience")
  :url "https://github.com/flycheck/flycheck-eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
