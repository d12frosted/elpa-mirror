;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awqat" "20260607.19"
  "Islamic prayer times."
  '((emacs "28.1")
    (alert "1.2"))
  :url "https://github.com/zkry/awqat"
  :commit "95129a06d27ab0ca99207147aac170356c47d70d"
  :revdesc "95129a06d27a"
  :authors '(("Zachary Romero" . "zacromero@posteo.net"))
  :maintainers '(("Zachary Romero" . "zacromero@posteo.net")))
