;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epx" "20250519.1138"
  "Manage and run project-specific shell commands."
  '((emacs "29.1"))
  :url "https://git.sr.ht/~alex-iam/epx"
  :commit "e4b4d0cd5d772f14d2284a83b8b32f24e09e717b"
  :revdesc "e4b4d0cd5d77"
  :keywords '("project" "shell" "tools")
  :authors '(("Oleksandr Korzh" . "alex@korzh.me"))
  :maintainers '(("Oleksandr Korzh" . "alex@korzh.me")))
