(define-package "buffer-name-relative" "20230623.50" "Relative buffer names"
  '((emacs "28.1"))
  :commit "f9f7e4c1d5ec486b23a2679ce6661dd3a723284c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-buffer-name-relative")
;; Local Variables:
;; no-byte-compile: t
;; End:
