;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omni-log" "20200304.2229"
  "Logging utilities."
  '((emacs "24")
    (ht    "2.0")
    (s     "1.6.1")
    (dash  "2.13.0"))
  :url "https://github.com/AdrieanKhisbe/omni-log.el"
  :commit "0a240660ccdd0b6588b4e3c322743b5ab1161338"
  :revdesc "0a240660ccdd"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Adrien Becchis" . "adriean.khisbe@live.fr"))
  :maintainers '(("Adrien Becchis" . "adriean.khisbe@live.fr")))
