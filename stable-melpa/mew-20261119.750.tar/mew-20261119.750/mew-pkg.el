;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261119.750"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "bda87856a3b5a50d7ebc72cff235de4b14b224b7"
  :revdesc "bda87856a3b5")
