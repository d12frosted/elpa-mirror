(define-package "doom-themes" "20220621.1347" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "1793eccfa2f08ce0926c079115c0cc6dc42867ac" :authors
  '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainer
  '("Henrik Lissner" . "contact@henrik.io")
  :keywords
  '("themes" "faces")
  :url "https://github.com/doomemacs/themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
