(define-package "gerrit" "20201212.529" "Gerrit client"
  '((emacs "25.1")
    (hydra "0.15.0")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "46c0d1d5fd2a255ab72978096cfe751c50f2c596" :keywords
  ("extensions")
  :authors
  (("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  ("Thomas Hisch" . "t.hisch@gmail.com")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
