;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260319.2010"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "1a4a388150ebfc90b2826d2fe5623703ed18472c"
  :revdesc "1a4a388150eb"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
