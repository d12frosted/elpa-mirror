;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260514.1453"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "b3e260ee37163dd6aa60eb3796358c545b07730e"
  :revdesc "b3e260ee3716"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
