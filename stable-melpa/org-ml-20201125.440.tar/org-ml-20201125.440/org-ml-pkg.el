(define-package "org-ml" "20201125.440" "Functional Org Mode API"
  '((emacs "26.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "ad7acb79f61bd2a11173eee6697fc7ce9db3180d" :keywords
  ("org-mode" "outlines")
  :authors
  (("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  ("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
