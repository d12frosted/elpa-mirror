;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apparmor-mode" "20260508.300"
  "Major mode for editing AppArmor policy files."
  '((emacs "26.1"))
  :url "https://gitlab.com/apparmor/apparmor-mode"
  :commit "991ac22527c63ea9c0e2e69bc9bc174beb5c80f0"
  :revdesc "991ac22527c6"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
