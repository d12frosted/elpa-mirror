;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260215.2013"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "067ca5c96faab2715dec0a46420a60945c621b82"
  :revdesc "067ca5c96faa"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
