(define-package "eldoc-box" "20230803.51" "Display documentation in childframe"
  '((emacs "27.1"))
  :commit "b5aa4814326f592d15332c5da4e62ed513fa85d7" :authors
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers
  '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainer
  '("Yuan Fu" . "casouri@gmail.com")
  :url "https://github.com/casouri/eldoc-box")
;; Local Variables:
;; no-byte-compile: t
;; End:
