;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20250604.2240"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "40005ac4be0d20e8074653a6e0fa3dfd7714169d"
  :revdesc "40005ac4be0d"
  :keywords '("convenience" "comm" "hypermedia"))
