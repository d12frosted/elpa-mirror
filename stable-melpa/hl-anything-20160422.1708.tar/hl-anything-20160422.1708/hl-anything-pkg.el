(define-package "hl-anything" "20160422.1708" "Highlight symbols, selections, enclosing parens and more."
  '((emacs "24.3"))
  :commit "c2e50f91a05d6c43e8a1c169f709cd1f23e47b0a" :authors
  '(("boyw165"))
  :maintainer
  '("boyw165"))
;; Local Variables:
;; no-byte-compile: t
;; End:
