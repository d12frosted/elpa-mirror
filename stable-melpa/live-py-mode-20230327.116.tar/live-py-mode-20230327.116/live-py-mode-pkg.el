(define-package "live-py-mode" "20230327.116" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "e7b21e47c7f74b58221e3b5a18549a47fc4e70f8" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
