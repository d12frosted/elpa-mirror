;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20251117.1730"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.4"))
  :url "https://github.com/emacscollective/borg"
  :commit "d09d38afa4acdfd422b95ec8f42e8947b26cab20"
  :revdesc "d09d38afa4ac"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
