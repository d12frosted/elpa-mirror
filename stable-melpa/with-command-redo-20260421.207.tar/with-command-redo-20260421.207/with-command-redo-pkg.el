;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-command-redo" "20260421.207"
  "Repeat commands with automatic undo."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-with-command-redo"
  :commit "c5c45bbfe95839adb448c11da8a8646293a1d4c0"
  :revdesc "c5c45bbfe958"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
