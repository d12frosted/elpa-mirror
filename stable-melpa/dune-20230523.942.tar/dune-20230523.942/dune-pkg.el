(define-package "dune" "20230523.942" "Integration with the dune build system" 'nil :commit "d62f4c39748e2498fc99a398f5e0667761687bf7" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
