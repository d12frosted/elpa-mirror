;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260824.2111"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "40cd0b9f59a431916b4acb3286b67d6240332fd2"
  :revdesc "40cd0b9f59a4"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
