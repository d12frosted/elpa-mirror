(define-package "kurecolor" "20220818.1336" "color editing goodies"
  '((emacs "24.1")
    (s "1.12"))
  :commit "0b8a9e80602a2a2c7ac34f9ac8c9b374c3e258d9" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
