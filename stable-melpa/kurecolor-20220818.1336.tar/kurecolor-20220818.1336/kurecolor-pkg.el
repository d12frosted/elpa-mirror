(define-package "kurecolor" "20220818.1336" "color editing goodies"
  '((emacs "24.1")
    (s "1.12"))
  :commit "932ef719fc72922430aa4922e1bc79010d99af66" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
