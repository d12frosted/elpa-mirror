(define-package "kurecolor" "20220818.1336" "color editing goodies"
  '((emacs "24.1")
    (s "1.12"))
  :commit "b33b14a8b2fad4a7618199dca14d737032bd39b0" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
