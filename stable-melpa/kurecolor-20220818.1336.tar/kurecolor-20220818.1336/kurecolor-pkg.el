(define-package "kurecolor" "20220818.1336" "color editing goodies"
  '((emacs "24.1")
    (s "1.12"))
  :commit "e4b02142bb955e7f3f621b405520a42f9dd35aec" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
