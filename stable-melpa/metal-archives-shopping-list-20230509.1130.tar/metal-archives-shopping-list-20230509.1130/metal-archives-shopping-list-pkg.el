(define-package "metal-archives-shopping-list" "20230509.1130" "Add shopping list generation support to metal-archives"
  '((emacs "26.3")
    (org-ml "5.8.7")
    (alert "1.2")
    (ht "2.3")
    (metal-archives "0.1"))
  :commit "ab8f3fcb5bdf7374c27445c8ae756d67658ccde0" :authors
  '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainers
  '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainer
  '("Sébastien Le Maguer" . "lemagues@tcd.ie")
  :keywords
  '("org" "calendar")
  :url "https://github.com/seblemaguer/metal-archives.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
