(define-package "latex-table-wizard" "20230511.2102" "Magic editing of LaTeX tables"
  '((emacs "27.1")
    (auctex "12.1")
    (transient "0.3.7"))
  :commit "80c1d68cf34e6726bb74b4deeb083d5785c6eda6" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :keywords
  '("convenience")
  :url "https://github.com/enricoflor/latex-table-wizard")
;; Local Variables:
;; no-byte-compile: t
;; End:
