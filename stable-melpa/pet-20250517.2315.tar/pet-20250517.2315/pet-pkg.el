;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pet" "20250517.2315"
  "Executable and virtualenv tracker for python-mode."
  '((emacs "26.1")
    (f     "0.6.0")
    (map   "3.3.1")
    (seq   "2.24"))
  :url "https://github.com/wyuenho/emacs-pet/"
  :commit "23be6c76e359eb90be949b5154ef1ffde5dc0cd0"
  :revdesc "23be6c76e359"
  :keywords '("tools")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
