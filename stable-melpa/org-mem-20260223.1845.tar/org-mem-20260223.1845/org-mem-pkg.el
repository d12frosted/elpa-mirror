;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260223.1845"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.3")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "7684fcec447b305a149be133f878fea7b22ae3e4"
  :revdesc "7684fcec447b"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
