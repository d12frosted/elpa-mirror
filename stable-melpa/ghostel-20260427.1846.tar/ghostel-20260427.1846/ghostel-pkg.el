;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260427.1846"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "14b4e85f4f0c2109219c6f852265ecdd4bd51928"
  :revdesc "14b4e85f4f0c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
