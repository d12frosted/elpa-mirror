;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pygn-mode" "20241216.1629"
  "Major-mode for chess PGN files, powered by Python."
  '((emacs             "26.1")
    (tree-sitter       "0.15.2")
    (tree-sitter-langs "0.10.7")
    (uci-mode          "0.5.4")
    (nav-flash         "1.0.0")
    (ivy               "0.10.0"))
  :url "https://github.com/dwcoates/pygn-mode"
  :commit "f6f5a528c96ee22fdf67196815ca7dad9ff78fa7"
  :revdesc "f6f5a528c96e"
  :keywords '("data" "games" "chess"))
