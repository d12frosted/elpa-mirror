(define-package "proof-general" "20210110.1959" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.3"))
  :commit "0d731606bee81b2d73895a23b69e84796ea7e4e7" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
