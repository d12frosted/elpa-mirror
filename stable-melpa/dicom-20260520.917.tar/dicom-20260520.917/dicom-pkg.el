;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20260520.917"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "e6774c0f47390e4022dd6ea9bc536d2820dd3dcd"
  :revdesc "e6774c0f4739"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
