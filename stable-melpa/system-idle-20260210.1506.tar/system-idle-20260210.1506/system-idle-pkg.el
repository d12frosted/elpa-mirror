;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "system-idle" "20260210.1506"
  "Poll the system-wide idle time."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/system-idle"
  :commit "876f93dbc00b96bc8a50f515436978b8a94e1c55"
  :revdesc "876f93dbc00b"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
