;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20250512.1627"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4"))
  :url "https://emacs-guix.gitlab.io/website/"
  :commit "6dd0726d5199810c467bdbfedd58a59952d8c1b7"
  :revdesc "6dd0726d5199"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
