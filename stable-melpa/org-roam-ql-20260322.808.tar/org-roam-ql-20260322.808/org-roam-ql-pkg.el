;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "20260322.808"
  "Interface to query and view results from org-roam."
  '((emacs         "28")
    (org-roam      "2.2.0")
    (s             "1.12.0")
    (magit-section "3.3.0")
    (transient     "0.4")
    (dash          "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "b6b6a25029503c27c2d4e4e0ca17a0ab82611470"
  :revdesc "b6b6a2502950")
