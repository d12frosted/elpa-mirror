(define-package "dirvish" "20220523.757" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "d69b79c46a968ab5a69fcfaa6079c51fff4fdefb" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
