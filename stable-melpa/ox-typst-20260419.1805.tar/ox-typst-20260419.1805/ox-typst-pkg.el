;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-typst" "20260419.1805"
  "Typst Back-End for Org Export Engine."
  '((emacs "30.1")
    (org   "9.7"))
  :url "https://github.com/jmpunkt/ox-typst"
  :commit "d05bdf1676c7564af6d87b438c669e93904c2b10"
  :revdesc "d05bdf1676c7"
  :keywords '("text" "wp" "org" "typst"))
