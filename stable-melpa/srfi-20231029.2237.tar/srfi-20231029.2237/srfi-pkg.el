(define-package "srfi" "20231029.2237" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "da7a725d29f30f90666241aac86989623231b37c" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
