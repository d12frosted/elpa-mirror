(define-package "ox-rfc" "20220206.1046" "RFC Back-End for Org Export Engine"
  '((emacs "24.3")
    (org "8.3"))
  :commit "b8722a0197c3ad935c80007b2f413bb005f255b2" :authors
  '(("Christian Hopps" . "chopps@devhopps.com"))
  :maintainer
  '("Christian Hopps" . "chopps@devhopps.com")
  :keywords
  '("org" "rfc" "wp" "xml")
  :url "https://github.com/choppsv1/org-rfc-export")
;; Local Variables:
;; no-byte-compile: t
;; End:
