;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260424.1504"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "fa222cc847bea9f8b941615cc3eb22dc3a7b0412"
  :revdesc "fa222cc847be"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
