;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260117.1528"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "5fb5a1d9ef34399b92ccbd3a5b58f089a0fef33e"
  :revdesc "5fb5a1d9ef34")
