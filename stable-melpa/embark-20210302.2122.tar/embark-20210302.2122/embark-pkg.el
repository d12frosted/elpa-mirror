(define-package "embark" "20210302.2122" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "ce409619690e3e5879f66e5c61cfd6c234227dbc" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
