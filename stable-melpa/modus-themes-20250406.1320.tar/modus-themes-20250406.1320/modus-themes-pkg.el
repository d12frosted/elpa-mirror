;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250406.1320"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "3631e70d291d7f951c3561633f926b5a460f9c25"
  :revdesc "3631e70d291d"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
