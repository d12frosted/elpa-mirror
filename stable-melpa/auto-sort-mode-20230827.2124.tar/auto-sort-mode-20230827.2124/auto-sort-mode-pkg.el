;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-sort-mode" "20230827.2124"
  "Automatically sort lines between two delimiters."
  '((emacs "24.1"))
  :url "https://github.com/rweir/auto-sort-mode"
  :commit "3ffa4e2a76a6dda949fdfd200f623a17c4796559"
  :revdesc "3ffa4e2a76a6"
  :keywords '("sorting" "sort" "matching" "tools")
  :authors '(("Rob Weir" . "rweir@ertius.org"))
  :maintainers '(("Rob Weir" . "rweir@ertius.org")))
