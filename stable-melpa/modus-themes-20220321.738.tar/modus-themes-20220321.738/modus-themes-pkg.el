(define-package "modus-themes" "20220321.738" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "f677e4f7384021f0cd65defd095e44eb01938df9" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
