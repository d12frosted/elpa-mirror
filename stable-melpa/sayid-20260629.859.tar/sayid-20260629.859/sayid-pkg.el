;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "20260629.859"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.0"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "47bd64f430fc562aff40a586bacca491a3b1454c"
  :revdesc "47bd64f430fc"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
