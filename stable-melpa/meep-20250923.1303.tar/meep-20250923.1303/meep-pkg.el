;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250923.1303"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "11c501a840f4dd82c76b2993e453cb694e32bb8b"
  :revdesc "11c501a840f4"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
