(define-package "eglot-jl" "20211208.359" "Julia support for eglot"
  '((emacs "25.1")
    (eglot "1.4")
    (julia-mode "0.3"))
  :commit "2e35cf9768d97a0429a72deddbe30d6d7722d454" :authors
  '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz"))
  :maintainer
  '("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/non-Jedi/eglot-jl")
;; Local Variables:
;; no-byte-compile: t
;; End:
