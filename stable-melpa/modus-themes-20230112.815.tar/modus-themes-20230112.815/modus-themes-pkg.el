(define-package "modus-themes" "20230112.815" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "54bf022080f5b5b5538153101d88720de8b94cbf" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
