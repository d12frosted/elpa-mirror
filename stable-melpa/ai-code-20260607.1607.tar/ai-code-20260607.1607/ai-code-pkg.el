;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260607.1607"
  "Unified interface for AI coding backends."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "788fd463686cd0f6d4e1cc3d2f0800e7384eeedf"
  :revdesc "788fd463686c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
