;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251210.406"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "1c7e7d64e00bfabd29ca6c56875ded3e6bc78c5f"
  :revdesc "1c7e7d64e00b"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
