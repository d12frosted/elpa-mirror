(define-package "enclose" "20121008.1614" "Enclose cursor within punctuation pairs." 'nil :commit "2747653e84af39017f503064bc66ed1812a77259")
;; Local Variables:
;; no-byte-compile: t
;; End:
