(define-package "enclose" "20121008.1614" "Enclose cursor within punctuation pairs." 'nil :commit "2747653e84af39017f503064bc66ed1812a77259" :authors
  (("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  ("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  ("speed" "convenience")
  :url "http://github.com/rejeep/enclose")
;; Local Variables:
;; no-byte-compile: t
;; End:
