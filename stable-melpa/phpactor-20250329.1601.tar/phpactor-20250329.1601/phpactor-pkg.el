;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpactor" "20250329.1601"
  "Interface to Phpactor."
  '((emacs       "25.1")
    (f           "0.17")
    (php-runtime "0.2")
    (composer    "0.2.0")
    (async       "1.9.3"))
  :url "https://github.com/emacs-php/phpactor.el"
  :commit "13f49c6854e2d09211ef27de9cc7d8f37be7a2e2"
  :revdesc "13f49c6854e2"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me")
             ("Mikael Kermorgant" . "mikael@kgtech.fi"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")
                 ("Mikael Kermorgant" . "mikael@kgtech.fi")))
