;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260610.2021"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "be41bd751ca28be83d006cb59976473710f5f524"
  :revdesc "be41bd751ca2"
  :keywords '("convenience" "text"))
