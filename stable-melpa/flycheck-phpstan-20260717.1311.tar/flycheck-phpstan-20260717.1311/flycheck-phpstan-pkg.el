;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-phpstan" "20260717.1311"
  "Flycheck integration for PHPStan."
  '((emacs    "25.1")
    (flycheck "26")
    (phpstan  "0.9.0"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "fec900ecbfb601c8eb9e01534ac1f4b29a759565"
  :revdesc "fec900ecbfb6"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
