;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nsis-mode" "20260628.1801"
  "NSIS-mode."
  ()
  :url "https://github.com/mlf176f2/nsis-mode"
  :commit "5ee283dd4da0bf8ca90cc8210da6ad94899d50b9"
  :revdesc "5ee283dd4da0"
  :keywords '("nsis"))
