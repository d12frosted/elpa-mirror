(define-package "erlang" "20210226.1127" "Erlang major mode"
  '((emacs "24.1"))
  :commit "51b2084859514080fdfe8579022681c1807e0761" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
