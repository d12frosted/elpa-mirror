;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brutalist-theme" "20250104.147"
  "Brutalist theme."
  ()
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el"
  :commit "445f72467110fc20f2f46eefc8d3a1de8db782d6"
  :revdesc "445f72467110")
