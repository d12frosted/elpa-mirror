;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcomp" "20260701.1247"
  "Compare version strings."
  '((emacs "26.1"))
  :url "https://github.com/tarsius/vcomp"
  :commit "ba2d07505dc29e3128ea915bb252969b82d2af08"
  :revdesc "ba2d07505dc2"
  :keywords '("versions")
  :authors '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
