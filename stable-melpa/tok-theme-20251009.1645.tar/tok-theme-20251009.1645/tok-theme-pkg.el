;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tok-theme" "20251009.1645"
  "Minimal monochromatic theme with restrained color highlights."
  '((emacs "27.0"))
  :url "https://github.com/topikettunen/tok-theme"
  :commit "c3135a6b3161ad46d4ddfeeb23c8a6952eb5bfbf"
  :revdesc "c3135a6b3161"
  :authors '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers '(("Topi Kettunen" . "topi@topikettunen.com")))
