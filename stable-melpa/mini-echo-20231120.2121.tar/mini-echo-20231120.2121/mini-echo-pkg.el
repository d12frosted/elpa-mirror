(define-package "mini-echo" "20231120.2121" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "6d16c2808b325af30bc36b345cfd93fd7a1f14bb" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
