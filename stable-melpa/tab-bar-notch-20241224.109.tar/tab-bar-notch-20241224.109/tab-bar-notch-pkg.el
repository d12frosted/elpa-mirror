;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-bar-notch" "20241224.109"
  "Adjust tab-bar height for MacBook Pro notch."
  '((emacs "27.1"))
  :url "https://github.com/jimeh/tab-bar-notch"
  :commit "49a0f4948bc3dc51ae36b026dec89698b26c0cb2"
  :revdesc "49a0f4948bc3"
  :keywords '("convenience" "hardware")
  :authors '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainers '(("Jim Myhrberg" . "contact@jimeh.me")))
