;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260425.730"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "4136e0704f6c2a873d4f0bc055b8a926226fa327"
  :revdesc "4136e0704f6c"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
