;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260402.531"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "c7d6be0b3a2b3b22e45faca0c96393dbebdec023"
  :revdesc "c7d6be0b3a2b"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
