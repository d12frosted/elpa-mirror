;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "20261028.2118"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "e8b456399082cbce8d2b3fe4a2c7e689a5414933"
  :revdesc "e8b456399082"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
