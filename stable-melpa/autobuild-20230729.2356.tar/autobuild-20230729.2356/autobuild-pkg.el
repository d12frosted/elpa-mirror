(define-package "autobuild" "20230729.2356" "Define and execute build rules and compilation pipelines"
  '((emacs "26.1")
    (selcand "0.0.1"))
  :commit "0f4cf8eec86806c59743fce2c5ed7e63db060cd2" :authors
  '(("Ernesto Alfonso"))
  :maintainers
  '((nil . "(concat \"erjoalgo\" \"@\" \"gmail\" \".com\")"))
  :maintainer
  '(nil . "(concat \"erjoalgo\" \"@\" \"gmail\" \".com\")")
  :keywords
  '("compile" "build" "pipeline" "autobuild" "extensions" "processes" "tools")
  :url "https://github.com/erjoalgo/autobuild")
;; Local Variables:
;; no-byte-compile: t
;; End:
