;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260501.1553"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "a6454ecdb2e3adf1e04d3533b415c5bc57e5b5d8"
  :revdesc "a6454ecdb2e3"
  :keywords '("data" "extensions"))
