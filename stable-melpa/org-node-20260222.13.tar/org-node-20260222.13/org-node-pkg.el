;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260222.13"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "d2dd24fc7264a5f621a4ed55fc4c6450714202df"
  :revdesc "d2dd24fc7264"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
