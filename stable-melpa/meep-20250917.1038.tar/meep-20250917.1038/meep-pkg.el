;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250917.1038"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "b7bfac7f9c56e54a92a82485b54a7beac117973e"
  :revdesc "b7bfac7f9c56"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
