(define-package "popper" "20211009.318" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "7afd502b3bc6905d9d2dded238981d0d639e127d" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
