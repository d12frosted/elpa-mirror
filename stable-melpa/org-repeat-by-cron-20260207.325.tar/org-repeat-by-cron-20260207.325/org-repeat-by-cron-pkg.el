;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-repeat-by-cron" "20260207.325"
  "An Org mode task repeater based on Cron expressions."
  '((emacs "24.4"))
  :url "https://github.com/TomoeMami/org-repeat-by-cron.el"
  :commit "64588cb069d0ff393362abc790a74635d16299a6"
  :revdesc "64588cb069d0"
  :keywords '("calendar")
  :authors '(("TomoeMami" . "trembleafterme@outlook.com"))
  :maintainers '(("TomoeMami" . "trembleafterme@outlook.com")))
