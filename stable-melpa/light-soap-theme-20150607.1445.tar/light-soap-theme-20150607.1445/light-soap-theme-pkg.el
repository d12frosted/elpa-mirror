;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "light-soap-theme" "20150607.1445"
  "Emacs 24 theme with a light background."
  '((emacs "24"))
  :url "https://github.com/mswift42/light-soap-theme"
  :commit "76a787bd40c6b567ae68ced7f5d9f9f10725e00d"
  :revdesc "76a787bd40c6")
