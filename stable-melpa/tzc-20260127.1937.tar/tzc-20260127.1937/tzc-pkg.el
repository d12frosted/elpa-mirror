;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260127.1937"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "ecac68e1dfa965c44ea880c1a98c995d60d01835"
  :revdesc "ecac68e1dfa9"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
