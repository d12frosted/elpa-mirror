;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260323.1632"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "9172101fc43a743edf17e0358987d2607d218f17"
  :revdesc "9172101fc43a"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
