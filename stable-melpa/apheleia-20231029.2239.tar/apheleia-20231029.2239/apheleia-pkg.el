(define-package "apheleia" "20231029.2239" "Reformat buffer stably"
  '((emacs "27"))
  :commit "7d3b061e3ecab6f407093b1727627550bcdea4b7" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
