(define-package "flexoki-themes" "20231019.722" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "e86f5d6d49bdfcc6596373caf4d38938e21cf320" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
