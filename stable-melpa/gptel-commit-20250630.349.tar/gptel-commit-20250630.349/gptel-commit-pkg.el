;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-commit" "20250630.349"
  "Generate commit message with gptel."
  '((emacs "27.1")
    (gptel "0.9.8"))
  :url "https://github.com/lakkiy/gptel-commit"
  :commit "17df01a773828cec639164c784c2822a699f1b36"
  :revdesc "17df01a77382"
  :keywords '("vc" "convenience"))
