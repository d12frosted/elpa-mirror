;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260301.1755"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "72710cc9907b83876c47fc06c45795c3fd842d25"
  :revdesc "72710cc9907b")
