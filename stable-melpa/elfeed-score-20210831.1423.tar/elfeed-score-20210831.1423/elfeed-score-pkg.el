(define-package "elfeed-score" "20210831.1423" "Gnus-style scoring for Elfeed"
  '((emacs "26.1")
    (elfeed "3.3.0"))
  :commit "2c8093e83491b9191115276e649dd87438726348" :authors
  '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainer
  '("Michael Herstine" . "sp1ff@pobox.com")
  :keywords
  '("news")
  :url "https://github.com/sp1ff/elfeed-score")
;; Local Variables:
;; no-byte-compile: t
;; End:
