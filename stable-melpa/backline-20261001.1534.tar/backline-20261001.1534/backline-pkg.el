;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backline" "20261001.1534"
  "Preserve appearance of outline headings."
  '((emacs               "28.1")
    (compat              "31.1")
    (outline-minor-faces "1.2"))
  :url "https://github.com/tarsius/backline"
  :commit "7ed5db3f956a5c6737806b441f3cd8253f3a043e"
  :revdesc "7ed5db3f956a"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.backline@jonas.bernoulli.dev")))
