(define-package "embark" "20210130.1726" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "3ccb9c2721f9bee854fe50be50d9724953bc5556" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
