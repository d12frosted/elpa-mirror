;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "svelte-mode" "20261019.908"
  "Emacs major mode for Svelte."
  '((emacs "26.1"))
  :url "https://github.com/leafOfTree/svelte-mode"
  :commit "27a8a48a7162136ebd8bf60eb7840c6258256c06"
  :revdesc "27a8a48a7162"
  :keywords '("wp" "languages")
  :authors '(("Leaf" . "leafvocation@gmail.com"))
  :maintainers '(("Leaf" . "leafvocation@gmail.com")))
