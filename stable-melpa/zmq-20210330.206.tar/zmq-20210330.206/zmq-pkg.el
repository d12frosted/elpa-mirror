(define-package "zmq" "20210330.206" "ZMQ bindings in elisp"
  '((cl-lib "0.5")
    (emacs "26"))
  :commit "380d82304facc8086448a2635bf779dfa82039a0" :authors
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainer
  '("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")
  :keywords
  '("comm")
  :url "https://github.com/nnicandro/emacs-zmq")
;; Local Variables:
;; no-byte-compile: t
;; End:
