(define-package "selectrum" "20201219.1527" "Easily select item from list"
  '((emacs "25.1"))
  :commit "074849f9b10250cc858b621c34dcd91ea0717290" :keywords
  ("extensions")
  :authors
  (("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  ("Radon Rosborough" . "radon.neon@gmail.com")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
