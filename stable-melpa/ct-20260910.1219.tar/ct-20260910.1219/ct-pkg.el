;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ct" "20260910.1219"
  "Color Tools - a color api."
  '((emacs "26.1")
    (dash  "2.18.0")
    (hsluv "1.0.0"))
  :url "https://github.com/neeasade/ct.el"
  :commit "c6036ca586cfb13b3bd83cfed0640e875dfe62cf"
  :revdesc "c6036ca586cf"
  :keywords '("convenience" "color" "theming" "background" "rgb" "hsv" "hsl" "hct" "lab" "oklab" "oklch"))
