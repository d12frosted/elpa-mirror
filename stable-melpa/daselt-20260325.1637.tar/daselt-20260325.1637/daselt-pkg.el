;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260325.1637"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "51fce4444c98aa93929ec6f1750532173ca3bffa"
  :revdesc "51fce4444c98"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
