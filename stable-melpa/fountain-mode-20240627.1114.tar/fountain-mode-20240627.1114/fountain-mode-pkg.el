(define-package "fountain-mode" "20240627.1114" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "6abad6dbce84859381f9ef49f01588f93990bba8" :authors
  '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainers
  '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainer
  '("Paul W. Rankin" . "rnkn@rnkn.xyz")
  :keywords
  '("wp" "text")
  :url "https://www.fountain-mode.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
