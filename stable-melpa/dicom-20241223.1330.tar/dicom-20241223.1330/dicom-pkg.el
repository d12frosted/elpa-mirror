;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20241223.1330"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/dicom"
  :commit "95ec2a5c049b766fc91f4e24807b404ad9451d7f"
  :revdesc "95ec2a5c049b"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
