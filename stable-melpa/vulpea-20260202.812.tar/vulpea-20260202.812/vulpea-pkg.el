;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260202.812"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "520c44645ac216d93c3339f8ae75ac0eb831a97f"
  :revdesc "520c44645ac2"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
