;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20250117.155"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs  "27.2")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "b8877e61b58dfabcc30044680d0975b3c6b12052"
  :revdesc "b8877e61b58d"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
