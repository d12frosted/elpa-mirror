;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forth-mode" "20251027.730"
  "Programming language mode for Forth."
  '((cl-lib "0.2"))
  :url "https://github.com/larsbrinkhoff/forth-mode"
  :commit "8f526ed38b52404c0ce55df6df5c8cbbc8f1de69"
  :revdesc "8f526ed38b52"
  :keywords '("languages" "forth")
  :authors '(("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainers '(("Lars Brinkhoff" . "lars@nocrew.org")))
