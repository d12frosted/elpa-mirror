;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260706.909"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "1c70fc98fd8c84d21e6b8747fd120ca3e438f297"
  :revdesc "1c70fc98fd8c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
