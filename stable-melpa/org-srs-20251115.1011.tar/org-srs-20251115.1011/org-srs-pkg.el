;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251115.1011"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "079505209741e9aa64fd8c2e40575bb54b561a85"
  :revdesc "079505209741"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
