(define-package "outlook" "20180428.1430" "send emails in MS Outlook style"
  '((emacs "24.4"))
  :commit "b6a7a06b996d84647e8024412876e9e76ca884e4" :authors
  '(("Andrew Savonichev"))
  :maintainer
  '("Andrew Savonichev")
  :keywords
  '("mail")
  :url "https://github.com/asavonic/outlook.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
