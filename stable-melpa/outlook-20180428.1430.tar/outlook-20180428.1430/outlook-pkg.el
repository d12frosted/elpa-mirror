(define-package "outlook" "20180428.1430" "send emails in MS Outlook style"
  '((emacs "24.4"))
  :commit "359683aff91b38bd1398a6ed4058a06f09a02d65" :keywords
  ("mail")
  :authors
  (("Andrew Savonichev"))
  :maintainer
  ("Andrew Savonichev")
  :url "https://github.com/asavonic/outlook.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
