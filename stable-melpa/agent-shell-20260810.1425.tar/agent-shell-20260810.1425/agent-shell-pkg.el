;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260810.1425"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a896bcc1781125ce9d09a78d8f28339cabce1533"
  :revdesc "a896bcc17811")
