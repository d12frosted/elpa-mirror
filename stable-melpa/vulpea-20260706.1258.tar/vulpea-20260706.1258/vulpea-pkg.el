;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260706.1258"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "b740857043c9ec5e30b6fdb2377e2d850e5cd30f"
  :revdesc "b740857043c9"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
