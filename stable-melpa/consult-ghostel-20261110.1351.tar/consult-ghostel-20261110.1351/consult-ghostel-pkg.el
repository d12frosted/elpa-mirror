;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "20261110.1351"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "6dfe79844972e43dd0fffea73aa79675d53362e3"
  :revdesc "6dfe79844972"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
