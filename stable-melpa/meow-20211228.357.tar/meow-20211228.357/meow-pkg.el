(define-package "meow" "20211228.357" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "9c36f3ddc9f54b1038d427ec4f712598aee440d5" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
