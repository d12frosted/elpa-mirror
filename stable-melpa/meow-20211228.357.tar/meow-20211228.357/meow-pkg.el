(define-package "meow" "20211228.357" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "b08c9f33a62e186e61a7120e80f1fa585a8cc9be" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
