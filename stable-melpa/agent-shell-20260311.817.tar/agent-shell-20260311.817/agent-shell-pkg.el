;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260311.817"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4561f5b63dcd99ff7517157ffe786b0c25021f38"
  :revdesc "4561f5b63dcd")
