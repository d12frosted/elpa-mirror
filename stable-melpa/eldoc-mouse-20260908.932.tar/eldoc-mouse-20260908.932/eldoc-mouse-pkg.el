;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20260908.932"
  "Display documentation for mouse hover."
  '((emacs    "27.1")
    (posframe "1.5.1")
    (eglot    "1.23"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "582ad79432959dc437bfa084c887178df608c62e"
  :revdesc "582ad7943295"
  :keywords '("tools" "languages" "convenience" "mouse" "hover")
  :authors '(("Huang Feiyu" . "sibadake1@163.com"))
  :maintainers '(("Huang Feiyu" . "sibadake1@163.com")))
