;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260524.816"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "bf1a1ff6c6cf12b9da5d3f1d4ff2c780c52e4667"
  :revdesc "bf1a1ff6c6cf"
  :keywords '("convenience" "text"))
