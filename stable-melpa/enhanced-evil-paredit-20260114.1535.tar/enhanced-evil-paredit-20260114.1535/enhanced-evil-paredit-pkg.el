;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20260114.1535"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "af4a8a8883842ec7ede17a53bb4f0102eb531371"
  :revdesc "af4a8a888384"
  :keywords '("convenience"))
