;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "replace-from-region" "20240224.52"
  "Replace commands whose query is from region."
  ()
  :url "http://www.emacswiki.org/emacs/download/replace-from-region.el"
  :commit "7b5b5ce5488ad5314acaa301d6482bf781db4ebd"
  :revdesc "7b5b5ce5488a"
  :keywords '("replace" "search" "region")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
