;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "binder" "20250101.1950"
  "Global minor mode to facilitate multi-file writing projects."
  '((emacs "24.4")
    (seq   "2.20"))
  :url "https://codeberg.org/divyaranjan/binder"
  :commit "08a0c9d4179ed31dcbacea3ab0077cd22db341b5"
  :revdesc "08a0c9d4179e"
  :keywords '("files" "outlines" "wp" "text")
  :authors '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainers '(("Paul W. Rankin" . "rnkn@rnkn.xyz")))
