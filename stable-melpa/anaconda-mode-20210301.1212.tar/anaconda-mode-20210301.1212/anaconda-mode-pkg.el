(define-package "anaconda-mode" "20210301.1212" "Code navigation, documentation lookup and completion for Python"
  '((emacs "25.1")
    (pythonic "0.1.0")
    (dash "2.6.0")
    (s "1.9")
    (f "0.16.2"))
  :commit "e35693c51de64a43f2a2efdccfb37c8a0c95f729" :authors
  '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainer
  '("Artem Malyshev" . "proofit404@gmail.com")
  :url "https://github.com/proofit404/anaconda-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
