(define-package "helm-company" "20231108.612" "Helm interface for company-mode"
  '((helm "1.5.9")
    (company "0.10.0"))
  :commit "a653ff05023a21dfa087d196d6ca27e382eb28b2" :authors
  '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers
  '(("Daniel Ralston" . "Sodel-the-Vociferous@users.noreply.github.com"))
  :maintainer
  '("Daniel Ralston" . "Sodel-the-Vociferous@users.noreply.github.com")
  :url "https://github.com/Sodel-the-Vociferous/helm-company")
;; Local Variables:
;; no-byte-compile: t
;; End:
