(define-package "eglot-jl" "20230106.1517" "Julia support for eglot"
  '((emacs "25.1")
    (eglot "1.4")
    (project "0.8.1")
    (cl-generic "1.0"))
  :commit "b18dcd670ec19df0dd4001646363e549b5ed7342" :authors
  '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz"))
  :maintainer
  '("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/non-Jedi/eglot-jl")
;; Local Variables:
;; no-byte-compile: t
;; End:
