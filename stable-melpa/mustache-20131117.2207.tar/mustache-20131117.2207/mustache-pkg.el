(define-package "mustache" "20131117.2207" "a mustache templating library in emacs lisp"
  '((ht "0.9")
    (s "1.3.0")
    (dash "1.2.0"))
  :commit "b0ea352813592424164520a49e86c04600242752" :authors
  '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainer
  '("Wilfred Hughes" . "me@wilfred.me.uk")
  :keywords
  '("mustache" "template"))
;; Local Variables:
;; no-byte-compile: t
;; End:
