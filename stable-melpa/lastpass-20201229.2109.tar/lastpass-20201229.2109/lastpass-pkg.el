;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lastpass" "20201229.2109"
  "LastPass command wrapper."
  '((emacs  "24.4")
    (seq    "1.9")
    (cl-lib "0.5"))
  :url "https://github.com/storvik/emacs-lastpass"
  :commit "2366de7824b6c5f8e9ec6811d219dc06794e8630"
  :revdesc "2366de7824b6"
  :keywords '("extensions" "processes" "lpass" "lastpass"))
