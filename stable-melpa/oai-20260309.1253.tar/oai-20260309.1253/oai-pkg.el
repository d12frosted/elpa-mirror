;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260309.1253"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "9e513eb3a836680813ce8c6b87ec955060c6489f"
  :revdesc "9e513eb3a836"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
