(define-package "choice-program" "20220801.1839" "Parameter based program"
  '((emacs "26")
    (dash "2.17.0"))
  :commit "ae6dc9d3fcf020e46fdd41f2b6fe5ca52c12aa93" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("execution" "processes" "unix" "lisp")
  :url "https://github.com/plandes/choice-program")
;; Local Variables:
;; no-byte-compile: t
;; End:
