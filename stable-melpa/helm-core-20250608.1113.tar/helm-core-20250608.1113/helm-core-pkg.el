;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250608.1113"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "8ec66d3bec936777ce4b5bd1b0d22e0aad92ccbe"
  :revdesc "8ec66d3bec93"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
