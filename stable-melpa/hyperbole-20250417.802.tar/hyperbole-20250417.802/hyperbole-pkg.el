;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250417.802"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "a366cc9ffdf7e3c6034cd4333ed5e5f46c3aec88"
  :revdesc "a366cc9ffdf7"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
