(define-package "evil-tree-edit" "20220317.29" "Evil structural editing for any language!"
  '((emacs "27.1")
    (tree-edit "0.1.0")
    (tree-sitter "0.15.0")
    (evil "1.0.0")
    (avy "0.5.0")
    (s "0.0.0"))
  :commit "5961b738e30be007cb0fe984a76e406e0854c006" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
