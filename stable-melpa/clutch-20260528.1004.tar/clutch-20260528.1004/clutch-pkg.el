;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260528.1004"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "b00d323588b0d70456e497d86b4e4b657ca1022e"
  :revdesc "b00d323588b0"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
