;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250427.1138"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "2e2c7a1e39c1dfb4e1fc33ea6f5fd8bec30a9c0b"
  :revdesc "2e2c7a1e39c1"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
