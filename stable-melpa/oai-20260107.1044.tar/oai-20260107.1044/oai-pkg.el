;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260107.1044"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "6c194c9308bcb9e3a4531084ce02ba92d7baf094"
  :revdesc "6c194c9308bc"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
