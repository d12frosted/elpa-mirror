;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-expectations" "20121009.734"
  "The simplest unit test framework in the world."
  ()
  :url "http://www.emacswiki.org/emacs/download/ert-expectations.el"
  :commit "aed70e002c4305b66aed7f6d0d48e9addd2dc1e6"
  :revdesc "aed70e002c43"
  :keywords '("test" "unittest" "ert" "expectations")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
