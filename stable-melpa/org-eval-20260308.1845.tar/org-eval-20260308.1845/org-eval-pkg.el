;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-eval" "20260308.1845"
  "Execute named org-mode blocks on load/save."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-eval"
  :commit "e43bff2239b938255f79d92c7e6a1c05da355bdb"
  :revdesc "e43bff2239b9"
  :keywords '("org" "outlines")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
