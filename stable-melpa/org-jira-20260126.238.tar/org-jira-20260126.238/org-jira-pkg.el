;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-jira" "20260126.238"
  "Syncing between Jira and Org-mode."
  '((emacs   "24.5")
    (cl-lib  "0.5")
    (request "0.2.0")
    (dash    "2.14.1"))
  :url "https://github.com/ahungry/org-jira"
  :commit "f3e4aa431c57b8d219631233ad173cccbc0a4e73"
  :revdesc "f3e4aa431c57"
  :keywords '("ahungry" "jira" "org" "bug" "tracker")
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
