(define-package "dwim-coder-mode" "20230813.1358" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "e923e44ad9124c4983d704dc50f4d10bbb54a93e" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
