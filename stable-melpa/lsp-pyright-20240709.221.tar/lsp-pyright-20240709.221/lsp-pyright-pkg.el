(define-package "lsp-pyright" "20240709.221" "Python LSP client using Pyright"
  '((emacs "26.1")
    (lsp-mode "7.0")
    (dash "2.18.0")
    (ht "2.0"))
  :commit "410870f8a195bf27da08e74f46e14e96b340812a" :keywords
  '("languages" "tools" "lsp")
  :url "https://github.com/emacs-lsp/lsp-pyright")
;; Local Variables:
;; no-byte-compile: t
;; End:
