(define-package "racket-mode" "20220122.1551" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "88a9c290fb6685a960c8c4a6ad1854576f970fbf" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
