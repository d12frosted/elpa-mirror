(define-package "buffer-name-relative" "20230613.621" "Relative buffer names"
  '((emacs "28.1"))
  :commit "094f7c5fb7e69e5a7403638d81f3de8f296e8471" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-buffer-name-relative")
;; Local Variables:
;; no-byte-compile: t
;; End:
