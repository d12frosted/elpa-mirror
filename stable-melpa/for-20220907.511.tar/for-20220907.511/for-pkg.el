(define-package "for" "20220907.511" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "258fdc27491a9bec1450962fade366c28377369d" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
