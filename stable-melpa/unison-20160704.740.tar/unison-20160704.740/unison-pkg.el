;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison" "20160704.740"
  "Sync with Unison."
  '((emacs "24.1"))
  :url "https://github.com/unhammer/unison.el"
  :commit "a78a04c0d1398d00f75a1bd4799622a65bcb0f28"
  :revdesc "a78a04c0d139"
  :keywords '("sync")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
