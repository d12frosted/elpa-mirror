;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260622.955"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "8e52f3128e553a9b0cf270ead5c8cca4de2dd0d8"
  :revdesc "8e52f3128e55"
  :keywords '("convenience" "chinese" "input-method" "rime"))
