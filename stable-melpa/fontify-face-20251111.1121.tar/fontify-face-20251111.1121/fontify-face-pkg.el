;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontify-face" "20251111.1121"
  "Fontify symbols representing faces with that face."
  '((emacs "25.1"))
  :url "https://github.com/Fuco1/fontify-face"
  :commit "b975c764b6e9e070c7673317146b4d345ec83ef8"
  :revdesc "b975c764b6e9"
  :keywords '("faces")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
