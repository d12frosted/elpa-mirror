;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "20260627.2312"
  "Interface to query and view results from org-roam."
  '((emacs         "28")
    (org-roam      "2.2.0")
    (s             "1.12.0")
    (magit-section "3.3.0")
    (transient     "0.4")
    (dash          "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "89bdd60367f95309334e8804b465e80c1aab9a78"
  :revdesc "89bdd60367f9")
