;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-tools" "20260101.947"
  "Support library for PDF documents."
  '((emacs     "26.3")
    (tablist   "1.0")
    (let-alist "1.0.4"))
  :url "http://github.com/vedang/pdf-tools/"
  :commit "5245f092e35712df6559a7782a93bb61896175dd"
  :revdesc "5245f092e357"
  :keywords '("files" "multimedia")
  :authors '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainers '(("Vedang Manerikar" . "vedang.manerikar@gmail.com")))
