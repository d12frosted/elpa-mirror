;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynaring" "20251104.720"
  "A dynamically sized ring structure."
  '((emacs "25.1"))
  :url "https://github.com/countvajhula/dynaring"
  :commit "56b85b85d199da238c07a69d4bf1a8e2abceb587"
  :revdesc "56b85b85d199"
  :authors '(("Mike Mattie" . "codermattie@gmail.com")
             ("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
