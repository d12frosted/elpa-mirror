(define-package "keg" "20220309.647" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "944e36144d92a798e1fd0f3d83fc6347d57a976e" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
