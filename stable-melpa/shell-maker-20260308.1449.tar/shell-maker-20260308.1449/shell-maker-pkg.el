;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260308.1449"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "25ffb8671b26d61de9ceb5c610577abdc84cf8f3"
  :revdesc "25ffb8671b26")
