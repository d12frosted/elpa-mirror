(define-package "meow" "20220725.1606" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "6741f4dc51bc44d8fe0f01bf1aff48ae6ec237f5" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
