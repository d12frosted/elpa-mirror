;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250323.1621"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (el-job "2.2.0")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "009f167a2895340c718a1a847cea665e85ef590c"
  :revdesc "009f167a2895"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
