(define-package "bqn-mode" "20230311.143" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "53e99ff81993be389b0955aee7a6cdf12dfa1605" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
