(define-package "embark" "20211110.114" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "5182b7eb2200a9245f1e5f73806672d6dcdd0356" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
