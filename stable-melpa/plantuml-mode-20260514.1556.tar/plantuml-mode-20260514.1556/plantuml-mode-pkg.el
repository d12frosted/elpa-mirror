;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plantuml-mode" "20260514.1556"
  "Major mode for PlantUML."
  '((dash    "2.0.0")
    (emacs   "25.1")
    (deflate "0.0.3"))
  :url "https://github.com/skuro/plantuml-mode"
  :commit "02d721179628075407d3dd5f05c113c7f4656e36"
  :revdesc "02d721179628"
  :keywords '("files" "text" "processes" "tools"))
