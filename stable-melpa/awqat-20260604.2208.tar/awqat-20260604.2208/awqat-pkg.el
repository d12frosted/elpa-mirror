;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awqat" "20260604.2208"
  "Islamic prayer times."
  '((emacs "28.1")
    (alert "1.2"))
  :url "https://github.com/zkry/awqat"
  :commit "70cabd4e03df0ee524e656b2566db88def07726a"
  :revdesc "70cabd4e03df"
  :authors '(("Zachary Romero" . "zacromero@posteo.net"))
  :maintainers '(("Zachary Romero" . "zacromero@posteo.net")))
