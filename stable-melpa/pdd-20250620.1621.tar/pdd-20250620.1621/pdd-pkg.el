;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250620.1621"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "47fdf9d2f3cb57973ce061d957386774d4adc8fc"
  :revdesc "47fdf9d2f3cb"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
