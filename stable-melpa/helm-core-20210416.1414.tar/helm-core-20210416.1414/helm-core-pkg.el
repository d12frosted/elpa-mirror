(define-package "helm-core" "20210416.1414" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "4eefae5b16fca166880fb51e68b27f5246f5d421")
;; Local Variables:
;; no-byte-compile: t
;; End:
