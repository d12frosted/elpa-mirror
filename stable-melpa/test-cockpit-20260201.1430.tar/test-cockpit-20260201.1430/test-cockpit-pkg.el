;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260201.1430"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "950665e6d6b3a1b0bb8ab0cb74989195a797c9f5"
  :revdesc "950665e6d6b3"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
