(define-package "wanderlust" "20210204.1428" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "7a8ed12b1a6275d04a9bf013656071d623874451")
;; Local Variables:
;; no-byte-compile: t
;; End:
