;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keymap-utils" "20260517.1747"
  "Keymap utilities."
  '((emacs  "28.1")
    (compat "31.0")
    (llama  "1.0"))
  :url "https://github.com/tarsius/keymap-utils"
  :commit "3469a061cd30b4323408766a7c6194e4b85d3b36"
  :revdesc "3469a061cd30"
  :keywords '("convenience" "extensions")
  :authors '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev")))
