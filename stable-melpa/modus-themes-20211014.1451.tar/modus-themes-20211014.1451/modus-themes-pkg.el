(define-package "modus-themes" "20211014.1451" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "ea9e46f3a06d4d45b5054436113cf942bfcddc8b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
