(define-package "csharp-mode" "20210821.1939" "C# mode derived mode"
  '((emacs "26.1"))
  :commit "45fee1a8ae2595a57ecdfbd7ba708c488652173f" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
