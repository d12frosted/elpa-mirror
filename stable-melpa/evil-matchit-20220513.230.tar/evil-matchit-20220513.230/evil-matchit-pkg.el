(define-package "evil-matchit" "20220513.230" "Vim matchit ported to Evil"
  '((evil "1.14.0")
    (emacs "25.1"))
  :commit "b47931128c6b7924ea432895f469769986de410d" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
