;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsharp-ts-mode" "20260330.1735"
  "Major mode for F# code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/fsharp-ts-mode"
  :commit "9b3e5ca533ebb06e1424db6ccff4f3ec3dde663b"
  :revdesc "9b3e5ca533eb"
  :keywords '("languages" "fsharp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
