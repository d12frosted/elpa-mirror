(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "4f87d3902b5b33a4ad05277b3275170b9efd20e3")
;; Local Variables:
;; no-byte-compile: t
;; End:
