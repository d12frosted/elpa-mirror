(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "232fa59a8e7954d20fbac8aac7f51bcf58c2f299")
;; Local Variables:
;; no-byte-compile: t
;; End:
