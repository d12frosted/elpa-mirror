(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c28ec33cc563970f26ba3f62e24f0179ef1a4af9")
;; Local Variables:
;; no-byte-compile: t
;; End:
