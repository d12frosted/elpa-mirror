(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "044fba09d67771186e916446a3fefd22bd4f0bb5")
;; Local Variables:
;; no-byte-compile: t
;; End:
