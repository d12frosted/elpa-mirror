(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c07f12e9f392454596f0042fc13809e2613d9d6c")
;; Local Variables:
;; no-byte-compile: t
;; End:
