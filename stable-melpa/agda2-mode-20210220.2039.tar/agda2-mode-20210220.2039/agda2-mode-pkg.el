(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "977396f323d8dbf230f9f4cb334f9ca31d7c8add")
;; Local Variables:
;; no-byte-compile: t
;; End:
