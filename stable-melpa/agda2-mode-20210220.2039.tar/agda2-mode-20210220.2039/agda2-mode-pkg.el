(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "bf6887488561fee9629f7ef76614411035e9e3a5")
;; Local Variables:
;; no-byte-compile: t
;; End:
