(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "db2526e9b89477cecd28a428d22f4f1fdf5f712a")
;; Local Variables:
;; no-byte-compile: t
;; End:
