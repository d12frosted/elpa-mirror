(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "2301a13c3b7156439797f73fbee028479e70fc45")
;; Local Variables:
;; no-byte-compile: t
;; End:
