(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c880f8614f0c86ea0856ab0aacd456a4442218f7")
;; Local Variables:
;; no-byte-compile: t
;; End:
