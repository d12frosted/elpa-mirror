(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "7cfab236cc0bc2747b3c025f11446235bf8d8dcc")
;; Local Variables:
;; no-byte-compile: t
;; End:
