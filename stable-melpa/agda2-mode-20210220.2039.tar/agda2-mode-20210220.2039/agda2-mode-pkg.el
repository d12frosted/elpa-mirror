(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "b7f782d841467321e237395fc1c2ec7605fb79f2")
;; Local Variables:
;; no-byte-compile: t
;; End:
