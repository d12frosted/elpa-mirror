(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "b0cdaa4fd58027855b17a695e86d0d7aa1796044")
;; Local Variables:
;; no-byte-compile: t
;; End:
