(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "f9a181685397517b5d14943ca88a1c0acacc2075")
;; Local Variables:
;; no-byte-compile: t
;; End:
