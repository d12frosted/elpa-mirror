(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "ecb93230ad9327991e542731756cbe1405c85d5f")
;; Local Variables:
;; no-byte-compile: t
;; End:
