(define-package "transient" "20230919.1251" "Transient commands"
  '((emacs "25.1")
    (compat "29.1.4.1"))
  :commit "7c08beb8d2c8a071c9e947617dbee369f17add84" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
