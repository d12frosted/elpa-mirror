(define-package "wanderlust" "20220429.549" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "a341b43e5e5fc97a14d1c9fc7d8e92490a8b7a0a")
;; Local Variables:
;; no-byte-compile: t
;; End:
