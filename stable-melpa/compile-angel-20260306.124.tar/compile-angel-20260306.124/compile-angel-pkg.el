;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260306.124"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "d58c7c8c424c124e0f023f92d1e176aac9e13ae3"
  :revdesc "d58c7c8c424c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
