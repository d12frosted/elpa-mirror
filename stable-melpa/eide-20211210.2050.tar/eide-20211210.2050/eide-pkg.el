(define-package "eide" "20211210.2050" "IDE interface" 'nil :commit "3a36db2bf007cc5afeead407492add1e2d2a51c7" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://eide.hjuvi.fr.eu.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
