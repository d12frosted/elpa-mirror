(define-package "bbdb" "20220224.403" "The Insidious Big Brother Database for GNU Emacs" 'nil :commit "00a003c9a3788c3a0fe8bd89b827b4e9bbdf2261" :maintainer
  '("Roland Winkler" . "winkler@gnu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
