;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20241125.1946"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "a5810babb9cf4c2acbf19e7006d811d94467e4b2"
  :revdesc "a5810babb9cf"
  :keywords '("outlines"))
