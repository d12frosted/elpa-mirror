;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20250328.157"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "2047a2611840fe6a590aceeb008530cfa171803c"
  :revdesc "2047a2611840"
  :keywords '("convenience"))
