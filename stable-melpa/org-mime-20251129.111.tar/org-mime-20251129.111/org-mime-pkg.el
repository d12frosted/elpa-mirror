;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mime" "20251129.111"
  "Org html export for text/html MIME emails."
  '((emacs "27.1"))
  :url "http://github.com/org-mime/org-mime"
  :commit "bdca3b962d618728c36444415d64b73e70bdba15"
  :revdesc "bdca3b962d61"
  :keywords '("mime" "mail" "email" "html")
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
