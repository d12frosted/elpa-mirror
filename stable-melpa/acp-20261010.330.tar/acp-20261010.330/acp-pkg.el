;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20261010.330"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "5b3abb2956d16f39ed76bc53fe31d3c2ee7fecfd"
  :revdesc "5b3abb2956d1")
