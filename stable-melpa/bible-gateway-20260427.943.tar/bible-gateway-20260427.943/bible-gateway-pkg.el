;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260427.943"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "e0264aeab3a29a1b590e70903782f9a6bca482e9"
  :revdesc "e0264aeab3a2"
  :keywords '("convenience" "comm" "hypermedia"))
