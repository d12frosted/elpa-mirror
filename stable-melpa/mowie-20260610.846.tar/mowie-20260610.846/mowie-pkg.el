;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mowie" "20260610.846"
  "Cycle Through Point-Moving Commands."
  '((emacs "28.1"))
  :url "https://codeberg.org/mekeor/mowie"
  :commit "30eb09b9c671b61b081b1d7096f4650641ee3ea0"
  :revdesc "30eb09b9c671"
  :keywords '("convenience")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
