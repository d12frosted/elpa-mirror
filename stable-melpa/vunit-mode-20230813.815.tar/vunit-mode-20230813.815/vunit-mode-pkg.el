(define-package "vunit-mode" "20230813.815" "VUnit Runner Interface"
  '((hydra "0.14.0")
    (emacs "24.3"))
  :commit "24c43fbc1daddadeecea64276dbd9c6ba769e850" :authors
  '(("Lukas Lichtl" . "support@embed-me.com"))
  :maintainers
  '(("Lukas Lichtl" . "support@embed-me.com"))
  :maintainer
  '("Lukas Lichtl" . "support@embed-me.com")
  :keywords
  '("vunit" "python" "tools")
  :url "https://github.com/embed-me")
;; Local Variables:
;; no-byte-compile: t
;; End:
