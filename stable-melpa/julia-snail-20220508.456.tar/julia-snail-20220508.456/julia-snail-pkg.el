(define-package "julia-snail" "20220508.456" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (vterm "0.0.1")
    (popup "0.5.9"))
  :commit "47cfc8cc0c5b383b0647c91e657f1ffeaf73cce8" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
