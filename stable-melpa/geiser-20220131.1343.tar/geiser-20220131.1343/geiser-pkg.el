(define-package "geiser" "20220131.1343" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3"))
  :commit "f7d91d04e3fcca40268439e702cb6c4f5c90ab98" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
