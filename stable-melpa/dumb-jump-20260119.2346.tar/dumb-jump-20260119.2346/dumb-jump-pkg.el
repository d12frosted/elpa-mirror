;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260119.2346"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.3")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "5bfea588a5f67ccf163bbe5084ee0c92e43869cf"
  :revdesc "5bfea588a5f6"
  :keywords '("programming"))
