(define-package "treemacs-perspective" "20230408.1109" "Perspective integration for treemacs"
  '((emacs "26.1")
    (treemacs "0.0")
    (perspective "2.8")
    (dash "2.11.0"))
  :commit "127485317a19254ca20ba1910d10edf7dbaa2d97" :authors
  '(("Alexander Miller" . "alexanderm@web.de")
    ("Jason Dufair" . "jase@dufair.org"))
  :maintainers
  '(("Alexander Miller" . "alexanderm@web.de"))
  :maintainer
  '("Alexander Miller" . "alexanderm@web.de")
  :url "https://github.com/Alexander-Miller/treemacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
