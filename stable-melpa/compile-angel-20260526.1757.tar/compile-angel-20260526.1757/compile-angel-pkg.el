;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260526.1757"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "3e828ff32c11c637c8c709f4d1546c25eec1e074"
  :revdesc "3e828ff32c11"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
