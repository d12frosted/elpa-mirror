;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260219.637"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "c702a9a1df3939424f6033bb8c948dbb163010f5"
  :revdesc "c702a9a1df39"
  :keywords '("files"))
