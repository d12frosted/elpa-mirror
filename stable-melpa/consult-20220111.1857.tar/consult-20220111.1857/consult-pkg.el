(define-package "consult" "20220111.1857" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b33cb2ef098b0f212d035e2677afdd7f04340765" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
