(define-package "indent-control" "20220930.2107" "Management for indentation level"
  '((emacs "26.1"))
  :commit "586b955dde5a0699fca76db28ad0d6c3e4141a27" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "control" "indent" "tab" "generic" "level")
  :url "https://github.com/jcs-elpa/indent-control")
;; Local Variables:
;; no-byte-compile: t
;; End:
