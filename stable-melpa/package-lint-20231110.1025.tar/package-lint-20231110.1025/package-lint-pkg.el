(define-package "package-lint" "20231110.1025" "A linting library for elisp package authors"
  '((cl-lib "0.5")
    (emacs "24.4")
    (let-alist "1.0.6")
    (compat "29.1"))
  :commit "c541e67dbb7f93b888edac908e9b25813ee7e6f7" :authors
  '(("Steve Purcell" . "steve@sanityinc.com")
    ("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("lisp")
  :url "https://github.com/purcell/package-lint")
;; Local Variables:
;; no-byte-compile: t
;; End:
