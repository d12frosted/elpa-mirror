(define-package "apdl-mode" "20210919.1858" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "84aff0cbb40950d99499281d0a41b9fc4be991f0" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
