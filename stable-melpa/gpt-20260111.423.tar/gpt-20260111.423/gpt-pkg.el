;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpt" "20260111.423"
  "Run instruction-following language models."
  '((emacs "28.1"))
  :url "https://github.com/stuhlmueller/gpt.el"
  :commit "fb5b7a833116377f9aae05e3ddefec64805d7546"
  :revdesc "fb5b7a833116"
  :keywords '("openai" "anthropic" "claude" "language" "copilot" "convenience" "tools")
  :authors '(("Andreas Stuhlmueller" . "emacs@stuhlmueller.org"))
  :maintainers '(("Andreas Stuhlmueller" . "emacs@stuhlmueller.org")))
