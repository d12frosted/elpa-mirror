(define-package "emacsql-psql" "20220916.928" "EmacSQL back-end for PostgreSQL via psql"
  '((emacs "25.1")
    (emacsql "2.0.0"))
  :commit "6622516e153d1f48a199b613367bbe8f6d7d43bf" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
