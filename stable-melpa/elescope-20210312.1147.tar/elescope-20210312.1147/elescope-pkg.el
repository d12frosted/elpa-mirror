;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elescope" "20210312.1147"
  "Seach and clone projects from the minibuffer."
  '((emacs   "25.1")
    (ivy     "0.10")
    (request "0.3")
    (seq     "2.0"))
  :url "https://github.com/freesteph/elescope"
  :commit "36566c8c1f5f993f67eadc85d18539ff375c0f98"
  :revdesc "36566c8c1f5f"
  :keywords '("vc")
  :authors '(("Stéphane Maniaci" . "stephane.maniaci@gmail.com"))
  :maintainers '(("Stéphane Maniaci" . "stephane.maniaci@gmail.com")))
