;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tengo-mode" "20260122.2124"
  "Major mode for the Tengo programming language."
  '((emacs "24.4"))
  :url "https://github.com/CsBigDataHub/tengo-mode"
  :commit "ad12d552da49e9b11f3329d2400aef337a87ef55"
  :revdesc "ad12d552da49"
  :keywords '("languages" "tengo"))
