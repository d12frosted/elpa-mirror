;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260102.1427"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2d41df60b7571aa74fdac26cbf6fdadfbbed5d8b"
  :revdesc "2d41df60b757")
