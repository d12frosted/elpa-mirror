(define-package "nerd-icons" "20230410.700" "Emacs Nerd Font Icons Library"
  '((emacs "24.3"))
  :commit "400208e6dc739d36cf7e2dea517db1d9d54ec279" :authors
  '(("Hongyu Ding <rainstormstudio@yahoo.com>, Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Hongyu Ding <rainstormstudio@yahoo.com>, Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/rainstormstudio/nerd-icons.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
