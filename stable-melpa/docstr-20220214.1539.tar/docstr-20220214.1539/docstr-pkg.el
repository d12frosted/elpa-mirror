(define-package "docstr" "20220214.1539" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "07dcc4788bea9e34fbe5e0e8366500e5329a0bbc" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
