(define-package "docstr" "20220214.1539" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "c7f46522a411e2241b8d1f0aebd3f7846e04bff9" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
