(define-package "docstr" "20220214.1539" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "3d350b221bca9f9f1a0b2168158c471bcf5ee9ac" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
