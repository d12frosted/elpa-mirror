;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260206.337"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "223b2f32af784c33120dbd8648ed8c50a48dd867"
  :revdesc "223b2f32af78"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
