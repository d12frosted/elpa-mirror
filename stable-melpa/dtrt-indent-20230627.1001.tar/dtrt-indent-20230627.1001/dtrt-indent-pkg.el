(define-package "dtrt-indent" "20230627.1001" "Adapt to foreign indentation offsets" 'nil :commit "84227faa9a29bc2f7ee8ab0f073e879d20b873bc" :authors
  '(("Julian Scheid" . "julians37@googlemail.com"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("convenience" "files" "languages" "c"))
;; Local Variables:
;; no-byte-compile: t
;; End:
