;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20250402.707"
  "An unofficial Copilot plugin."
  '((emacs        "27.2")
    (editorconfig "0.8.2")
    (jsonrpc      "1.0.14")
    (f            "0.20.0"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "5fa27b5194ad84ffb21c51eeb10ef0e9559a1c56"
  :revdesc "5fa27b5194ad"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Rakotomandimby Mihamina" . "mihamina.rakotomandimby@rktmb.org")))
