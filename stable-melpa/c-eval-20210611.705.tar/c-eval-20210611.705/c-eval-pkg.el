;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "c-eval" "20210611.705"
  "Compile and run one-off C code snippets."
  '((emacs "24.5"))
  :url "https://github.com/lassik/emacs-c-eval"
  :commit "fd129bfcb75475ac6820cc33862bd8efb8097fae"
  :revdesc "fd129bfcb754"
  :keywords '("c" "languages")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
