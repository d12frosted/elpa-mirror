;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20260509.7"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "c5a3ec882a9019f21b266f734710757a80387d7d"
  :revdesc "c5a3ec882a90"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
