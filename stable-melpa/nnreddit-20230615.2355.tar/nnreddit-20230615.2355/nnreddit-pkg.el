(define-package "nnreddit" "20230615.2355" "Gnus Backend For Reddit"
  '((emacs "25.1")
    (request "0.3.3")
    (anaphora "1.0.4")
    (dash "2.18.1")
    (json-rpc "0.0.1")
    (virtualenvwrapper "20151123")
    (s "1.6.1"))
  :commit "5a10f3f467388b03ca9d0e1eb5e77e33402aabe5" :keywords
  '("news")
  :url "https://github.com/dickmao/nnreddit")
;; Local Variables:
;; no-byte-compile: t
;; End:
