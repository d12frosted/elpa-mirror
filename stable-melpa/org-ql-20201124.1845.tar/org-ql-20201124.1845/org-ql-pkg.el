(define-package "org-ql" "20201124.1845" "Org Query Language, search command, and agenda-like view"
  '((emacs "26.1")
    (dash "2.13")
    (dash-functional "1.2.0")
    (f "0.17.2")
    (map "2.1")
    (org "9.0")
    (org-super-agenda "1.2")
    (ov "1.0.6")
    (peg "1.0")
    (s "1.12.0")
    (transient "0.1")
    (ts "0.2pre"))
  :commit "73209cf48eabf665c65d05ff669f929c188220a9" :keywords
  ("hypermedia" "outlines" "org" "agenda")
  :authors
  (("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  ("Adam Porter" . "adam@alphapapa.net")
  :url "https://github.com/alphapapa/org-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
