;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250625.949"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "14138b26592b95b732475fcbccda2f509017a22b"
  :revdesc "14138b26592b"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
