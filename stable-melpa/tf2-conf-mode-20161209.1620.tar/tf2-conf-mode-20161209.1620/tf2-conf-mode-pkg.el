;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tf2-conf-mode" "20161209.1620"
  "TF2 Configuration files syntax highlighting."
  ()
  :url "https://github.com/wynro/emacs-tf2-conf-mode"
  :commit "94c971da4a78d55da2848d1e76d513e5e0a8f7eb"
  :revdesc "94c971da4a78"
  :keywords '("languages")
  :authors '(("Guillermo Robles" . "guillerobles1995@gmail.com"))
  :maintainers '(("Guillermo Robles" . "guillerobles1995@gmail.com")))
