;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261116.1016"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "e27f1d4876f704f9e3431e3bdfe5e9b684797d54"
  :revdesc "e27f1d4876f7"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
