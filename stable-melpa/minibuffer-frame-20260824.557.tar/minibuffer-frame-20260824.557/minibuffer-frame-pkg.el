;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuffer-frame" "20260824.557"
  "Minibuffer in centered child frame."
  '((emacs "28.1"))
  :url "https://github.com/zHaOdANiuu/minibuffer-frame"
  :commit "cfaba2bd56b2ff5c9fd3f6efd65f1f653b0527ab"
  :revdesc "cfaba2bd56b2"
  :keywords '("convenience" "minibuffer" "child-frame")
  :authors '(("Daniu Zhao" . "zhaodaniu1@gmail.com"))
  :maintainers '(("Daniu Zhao" . "zhaodaniu1@gmail.com")))
