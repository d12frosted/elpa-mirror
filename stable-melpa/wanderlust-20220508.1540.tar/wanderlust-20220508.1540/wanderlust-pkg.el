(define-package "wanderlust" "20220508.1540" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "e3cd5e39454737c0b641e114ddcc550122288a2a")
;; Local Variables:
;; no-byte-compile: t
;; End:
