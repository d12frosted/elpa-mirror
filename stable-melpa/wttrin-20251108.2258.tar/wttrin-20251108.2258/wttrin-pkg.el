;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20251108.2258"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "c47f1d42abbb25af583384a3cb0ca17e8bcd61df"
  :revdesc "c47f1d42abbb"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
