;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260527.1536"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "c14129fb0f303eb3e22d7f673adc0a2c57f74a1f"
  :revdesc "c14129fb0f30"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
