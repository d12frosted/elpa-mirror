;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260518.439"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "f552079b50e5f2f7a523dbe1984bf38465941753"
  :revdesc "f552079b50e5"
  :keywords '("convenience" "chinese" "input-method" "rime"))
