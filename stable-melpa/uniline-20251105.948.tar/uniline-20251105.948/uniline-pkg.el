;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20251105.948"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "92863a597544f2b1af167cd7631b05990c2ae51b"
  :revdesc "92863a597544"
  :keywords '("convenience" "text"))
