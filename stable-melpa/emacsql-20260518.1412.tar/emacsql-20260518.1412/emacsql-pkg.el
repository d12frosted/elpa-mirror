;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsql" "20260518.1412"
  "High-level SQL database front-end."
  '((emacs "26.1"))
  :url "https://github.com/magit/emacsql"
  :commit "7ee5c9d5c5b9b3d922153147539b7ed39971af9d"
  :revdesc "7ee5c9d5c5b9"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev")))
