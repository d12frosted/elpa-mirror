(define-package "package-lint" "20230524.1501" "A linting library for elisp package authors"
  '((cl-lib "0.5")
    (emacs "24.1")
    (let-alist "1.0.6"))
  :commit "fe3e38f24f045ce7d41d58b08a0e78b79d1d688c" :authors
  '(("Steve Purcell" . "steve@sanityinc.com")
    ("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("lisp")
  :url "https://github.com/purcell/package-lint")
;; Local Variables:
;; no-byte-compile: t
;; End:
