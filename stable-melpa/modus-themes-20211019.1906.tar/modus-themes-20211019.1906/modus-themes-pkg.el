(define-package "modus-themes" "20211019.1906" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "cc49fb1cf266b890b15edacd9aa076b46facb635" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
