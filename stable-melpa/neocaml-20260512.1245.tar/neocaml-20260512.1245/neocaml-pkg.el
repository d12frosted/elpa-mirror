;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260512.1245"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "29349cd73d22a6088e59dfc4a028e9f4b1bcd3dc"
  :revdesc "29349cd73d22"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
