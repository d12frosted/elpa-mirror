(define-package "autocrypt" "20210917.1556" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "709dc5b3bf5963f527006cbd504e7d6d558562db" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "philipk@posteo.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
