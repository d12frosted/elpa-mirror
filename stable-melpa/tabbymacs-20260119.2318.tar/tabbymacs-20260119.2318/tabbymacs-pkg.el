;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabbymacs" "20260119.2318"
  "Inline AI code completions via Tabby LSP."
  '((emacs "28.1"))
  :url "https://github.com/Bastillan/tabbymacs"
  :commit "ad4b60ce83dea3ec548af4adbdb4beffe2722b5d"
  :revdesc "ad4b60ce83de"
  :keywords '("tools" "languages" "inline completions" "tabby" "llm")
  :authors '(("Jędrzej Kędzierski" . "kedzierski.jedrzej@gmail.com"))
  :maintainers '(("Jędrzej Kędzierski" . "kedzierski.jedrzej@gmail.com")))
