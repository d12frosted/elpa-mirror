;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251214.323"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b7cc26a2af8c33b2ce55a8304a811cbfdde341ea"
  :revdesc "b7cc26a2af8c"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
