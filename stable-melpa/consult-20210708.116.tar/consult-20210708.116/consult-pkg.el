(define-package "consult" "20210708.116" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "49b64429a08a8696703a561a0e3dbfd7cbd2325e" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
