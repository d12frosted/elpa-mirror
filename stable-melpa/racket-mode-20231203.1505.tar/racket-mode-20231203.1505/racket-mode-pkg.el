(define-package "racket-mode" "20231203.1505" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "076d36b319ade057c60ecccf9c16fff36bd88f42" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
