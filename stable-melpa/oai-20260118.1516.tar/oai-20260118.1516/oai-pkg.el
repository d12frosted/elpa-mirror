;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260118.1516"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "5f2ca47f35a52ebd8f7d6dab9deb463acaee62d4"
  :revdesc "5f2ca47f35a5"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
