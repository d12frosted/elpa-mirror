(define-package "moom" "20210308.1011" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "6d72662fd16a5e66dc6a2c61c35d906912d5d291" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
