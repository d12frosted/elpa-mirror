;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251126.1925"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "1ddeb0b8c63cc0ab267ac6a1e3010c053c1fa5f0"
  :revdesc "1ddeb0b8c63c"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
