;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20250408.124"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "c8ec33a497808dd269921d6520810792ce49f709"
  :revdesc "c8ec33a49780"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
