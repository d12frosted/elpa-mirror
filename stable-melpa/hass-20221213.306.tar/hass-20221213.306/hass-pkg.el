(define-package "hass" "20221213.306" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3"))
  :commit "65dc52effab92fea5b0a8896821b78fd00da66f0" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
