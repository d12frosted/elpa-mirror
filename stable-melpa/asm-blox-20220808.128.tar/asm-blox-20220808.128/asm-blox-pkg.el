(define-package "asm-blox" "20220808.128" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "d511ec0e24a081f1aa691c19cd38c8e0a90cb87e" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
