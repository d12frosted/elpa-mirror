;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-history" "20260801.1737"
  "Show Dates for Org headers from vcs + auto-commit."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-org-history"
  :commit "64705fab861aeafa37197d989d01cd9bdbde87a1"
  :revdesc "64705fab861a"
  :keywords '("org" "outline" "vc")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
