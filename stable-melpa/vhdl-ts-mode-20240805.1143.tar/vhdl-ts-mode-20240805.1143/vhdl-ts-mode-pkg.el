(define-package "vhdl-ts-mode" "20240805.1143" "VHDL Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "b765db4e65edc94874970297f0d29f7e47542bf8" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
