;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwin" "20251126.1836"
  "Navigate and arrange desktop windows."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/lsth/dwin"
  :commit "0d9bc1a745afe13085063958f8ae664fbe7820e7"
  :revdesc "0d9bc1a745af"
  :keywords '("frames" "processes" "convenience")
  :authors '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de"))
  :maintainers '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de")))
