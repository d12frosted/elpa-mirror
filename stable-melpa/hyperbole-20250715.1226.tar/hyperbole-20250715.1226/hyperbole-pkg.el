;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250715.1226"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "cee1ea45d217909539c9da09145764f96dedb300"
  :revdesc "cee1ea45d217"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
