(define-package "ob-dall-e-shell" "20240805.1934" "Org babel functions for DALL-E evaluation"
  '((emacs "27.1")
    (dall-e-shell "0.37.1"))
  :commit "fe75c5d516b149c635cda97627e8f920f277d36e" :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
