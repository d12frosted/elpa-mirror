(define-package "selectrum" "20210104.1554" "Easily select item from list"
  '((emacs "25.1"))
  :commit "499178f648dcfc3b7296b4da101dd4f4ae849190" :authors
  (("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  ("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  ("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
