;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260521.1824"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "ee8d0b5adf2976c17650ae28abe5c78637c6fc99"
  :revdesc "ee8d0b5adf29"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
