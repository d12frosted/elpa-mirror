(define-package "eldev" "20221027.1936" "Elisp development tool"
  '((emacs "24.4"))
  :commit "cc7cbb7bc41e0b1e2536ce656b4d10f6049f6729" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
