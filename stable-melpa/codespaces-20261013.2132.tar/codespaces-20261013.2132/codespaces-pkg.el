;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20261013.2132"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "f87830fe735779aab0bc5abfc8e5e9ed57593bb0"
  :revdesc "f87830fe7357"
  :keywords '("comm")
  :authors '(("Fabian Markl" . "fabian@markl.dev"))
  :maintainers '(("Fabian Markl" . "fabian@markl.dev")))
