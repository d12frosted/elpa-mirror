(define-package "asm-blox" "20220731.207" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "17a10a4e8b15098143a26bd854658a61bbe32e8e" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
