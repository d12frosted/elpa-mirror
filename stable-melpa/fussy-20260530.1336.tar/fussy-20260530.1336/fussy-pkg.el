;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260530.1336"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "f48013bfe4bbdd61eed3808b1c03fdc93fd35060"
  :revdesc "f48013bfe4bb"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
