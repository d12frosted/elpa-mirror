(define-package "sly" "20210604.937" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "c783ba6576b554f3fc15a70bf30d225f277d1863" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
