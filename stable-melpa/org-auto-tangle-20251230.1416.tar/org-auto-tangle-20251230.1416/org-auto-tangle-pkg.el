;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-auto-tangle" "20251230.1416"
  "Automatically and Asynchronously tangles org files on save."
  '((emacs "24.1")
    (async "1.9.3"))
  :url "https://github.com/yilkalargaw/org-auto-tangle"
  :commit "b4e7abc019179df473ecddf0af80561ddad8fc58"
  :revdesc "b4e7abc01917"
  :keywords '("outlines")
  :authors '(("Yilkal Argaw" . "yilkalargawworkneh@gmail.com"))
  :maintainers '(("Yilkal Argaw" . "yilkalargawworkneh@gmail.com")))
