(define-package "jsonian" "20230909.2309" "A major mode for editing JSON files"
  '((emacs "27.1"))
  :commit "318ce1be124feff730767ffa0a1faf7ccca958f8" :authors
  '(("Ian Wahbe"))
  :maintainers
  '(("Ian Wahbe"))
  :maintainer
  '("Ian Wahbe")
  :url "https://github.com/iwahbe/jsonian")
;; Local Variables:
;; no-byte-compile: t
;; End:
