;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-org-md" "20180213.2343"
  "Export a markdown file automatically when you save an org-file."
  '((emacs "24.4"))
  :url "https://github.com/jamcha-aa/auto-org-md"
  :commit "9318338bdb7fe8bd698d88f3af89b2d6413efdd2"
  :revdesc "9318338bdb7f"
  :keywords '("org" "markdown")
  :authors '(("jamcha" . "jamcha.aa@gmail.com"))
  :maintainers '(("jamcha" . "jamcha.aa@gmail.com")))
