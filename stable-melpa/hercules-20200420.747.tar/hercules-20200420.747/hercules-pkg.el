;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hercules" "20200420.747"
  "An auto-magical, which-key-based hydra banisher."
  '((emacs     "24.4")
    (which-key "3.3.2"))
  :url "https://gitlab.com/jjzmajic/hercules"
  :commit "557da39878d0637395fdded91243b340c37eff7b"
  :revdesc "557da39878d0"
  :keywords '("convenience"))
