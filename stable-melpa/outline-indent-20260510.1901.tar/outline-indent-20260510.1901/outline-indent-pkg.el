;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260510.1901"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "ff70f4b248c85715f2882c2c93656b9eee567796"
  :revdesc "ff70f4b248c8"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
