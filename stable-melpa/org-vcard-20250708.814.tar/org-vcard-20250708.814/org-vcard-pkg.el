;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-vcard" "20250708.814"
  "Org-mode support for vCard export and import."
  ()
  :url "https://github.com/pinoaffe/org-vcard"
  :commit "c438da390db9e5ad9e42b699aeaebe359ed7d9c2"
  :revdesc "c438da390db9"
  :keywords '("outlines" "org" "vcard")
  :authors '(("Alexis" . "flexibeast@gmail.com")
             ("Will Dey" . "will123dey@gmail.com")
             ("pinoaffe" . "pinoaffe@gmail.com"))
  :maintainers '(("pinoaffe" . "pinoaffe@gmail.com")))
