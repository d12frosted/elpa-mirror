(define-package "modus-themes" "20230110.415" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "eddf79d2a38899f4d465a7d8001b3b77fbb0e0e6" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
