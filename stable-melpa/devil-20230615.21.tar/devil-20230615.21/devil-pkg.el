(define-package "devil" "20230615.21" "Minor mode for translating key sequences"
  '((emacs "24.4"))
  :commit "31a4a084d9d8affb62e53de31d5eae00f772a06a" :authors
  '(("Susam Pal" . "susam@susam.net"))
  :maintainers
  '(("Susam Pal" . "susam@susam.net"))
  :maintainer
  '("Susam Pal" . "susam@susam.net")
  :keywords
  '("convenience" "abbrev")
  :url "https://github.com/susam/devil")
;; Local Variables:
;; no-byte-compile: t
;; End:
