;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260617.340"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "394f19ffa07892227881106337a480dc437749b7"
  :revdesc "394f19ffa078"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
