;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sudo-ext" "20170126.1214"
  "Sudo support."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/sudo-ext.el"
  :commit "9d4580f304121ce7b8104bd4bd3b64e4dfa3c9b3"
  :revdesc "9d4580f30412"
  :keywords '("unix")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
