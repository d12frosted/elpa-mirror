(define-package "mallard-mode" "20130824.217" "Major mode for editing Mallard files" 'nil :commit "152cd44d53c881457fe57c1aba77e8e2fca4d1b0" :authors
  '(("Jaromir Hradilek" . "jhradilek@gmail.com"))
  :maintainer
  '("Jaromir Hradilek" . "jhradilek@gmail.com")
  :keywords
  '("xml" "mallard")
  :url "https://github.com/jhradilek/emacs-mallard-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
