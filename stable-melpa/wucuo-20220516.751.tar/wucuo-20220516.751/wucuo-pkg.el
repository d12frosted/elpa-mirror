(define-package "wucuo" "20220516.751" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "44cf8adee58f2b4922c34dfa51af06c52de0a192" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
