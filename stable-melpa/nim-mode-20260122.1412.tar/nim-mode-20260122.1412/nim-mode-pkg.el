;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nim-mode" "20260122.1412"
  "A major mode for the Nim programming language."
  '((emacs     "24.4")
    (epc       "0.1.1")
    (let-alist "1.0.1")
    (commenter "0.5.1"))
  :url "https://github.com/nim-lang/nim-mode"
  :commit "d7cd7ab1fc033a7af101442e715a0e736031cd7b"
  :revdesc "d7cd7ab1fc03"
  :keywords '("nim" "languages")
  :maintainers '(("Simon Hafner" . "hafnersimon@gmail.com")))
