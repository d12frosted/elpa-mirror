;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rescript-mode" "20260405.1650"
  "A major mode for editing ReScript."
  '((emacs "26.1"))
  :url "https://github.com/jjlee/rescript-mode"
  :commit "f19e2638b6b34d323096597464f422d9e2ad795f"
  :revdesc "f19e2638b6b3"
  :keywords '("languages" "rescript")
  :authors '(("Karl Landstrom" . "karl.landstrom@brgeight.se")
             ("Daniel Colascione" . "dancol@dancol.org")
             ("John Lee" . "jjl@pobox.com"))
  :maintainers '(("John Lee" . "jjl@pobox.com")))
