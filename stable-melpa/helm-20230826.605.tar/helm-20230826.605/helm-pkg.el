(define-package "helm" "20230826.605" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.4")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "2548e63e2454ef818276e0e11b3a2cbd180d05a7" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
