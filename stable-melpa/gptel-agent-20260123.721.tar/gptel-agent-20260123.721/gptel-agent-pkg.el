;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260123.721"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "8a556f963fa8a36c676e4e8fafad5675ce09dc4d"
  :revdesc "8a556f963fa8"
  :keywords '("comm"))
