(define-package "detached" "20221122.1423" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "00bf84e8f55ae7bcd015cf058ea1274f8e5dac17" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
