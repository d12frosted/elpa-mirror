(define-package "detached" "20220615.1304" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "bcbf83bb1b9c460c989406b9a558b021c8561ee9" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
