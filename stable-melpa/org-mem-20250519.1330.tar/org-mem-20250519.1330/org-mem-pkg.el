;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250519.1330"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "c54479ec3d46247c4da39cab188c06c7637b1b39"
  :revdesc "c54479ec3d46"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
