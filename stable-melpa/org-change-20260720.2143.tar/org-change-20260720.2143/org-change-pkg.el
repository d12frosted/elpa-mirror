;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "20260720.2143"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "574315a8075decd2ede280dab36b7efd8df4e858"
  :revdesc "574315a8075d"
  :keywords '("wp" "convenience"))
