;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260901.1240"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "4a5b4fb0b536da711fa536760137f5424301f087"
  :revdesc "4a5b4fb0b536"
  :keywords '("languages" "lisp" "slime"))
