(define-package "finito" "20220704.1022" "View and collect books"
  '((emacs "27.1")
    (dash "2.17.0")
    (request "0.3.2")
    (f "0.2.0")
    (s "1.12.0")
    (transient "0.3.0")
    (graphql "0.1.1")
    (async "1.9.3"))
  :commit "508f6699795528c579b235f4f7726b5aa5ad9595" :authors
  '(("Laurence Warne"))
  :maintainer
  '("Laurence Warne")
  :keywords
  '("outlines")
  :url "https://github.com/LaurenceWarne/finito.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
