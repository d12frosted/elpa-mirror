;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simulacrum" "20261011.2241"
  "Inject custom event types into the event stream."
  '((emacs "29.1"))
  :url "https://github.com/ErikPrantare/simulacrum.el"
  :commit "38583c7e16e3099f027f6081441b689e3ec5baac"
  :revdesc "38583c7e16e3"
  :keywords '("convenience")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
