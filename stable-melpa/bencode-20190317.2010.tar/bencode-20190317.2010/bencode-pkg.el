;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bencode" "20190317.2010"
  "Bencode encoding / decoding."
  '((emacs "24.4"))
  :url "https://github.com/skeeto/emacs-bencode"
  :commit "b5fe9c9d4b9b5ea61cedd77987ca46eb8154bd16"
  :revdesc "b5fe9c9d4b9b"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
