(define-package "julia-ts-mode" "20230505.1846" "Major mode for Julia source code using tree-sitter"
  '((emacs "29")
    (julia-mode "0.4"))
  :commit "a1592dee00c979c238ac3465050a305579657d86" :authors
  '(("Ronan Arraes Jardim Chagas"))
  :maintainers
  '(("Ronan Arraes Jardim Chagas"))
  :maintainer
  '("Ronan Arraes Jardim Chagas")
  :keywords
  '("julia" "languages" "tree-sitter")
  :url "https://github.com/ronisbr/julia-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
