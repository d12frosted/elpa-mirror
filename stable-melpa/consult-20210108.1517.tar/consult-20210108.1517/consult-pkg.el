(define-package "consult" "20210108.1517" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "1614328a32911801f55ab96cf018f4b5c4a161da" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
