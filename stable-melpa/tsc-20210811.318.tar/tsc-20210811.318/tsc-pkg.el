(define-package "tsc" "20210811.318" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "13a4fff0c017313ede1900f972f6a805243a17f7" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
    ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
