(define-package "company" "20210801.218" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "824b5fd7372478021de6af05f3b489f785a19b4e" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
