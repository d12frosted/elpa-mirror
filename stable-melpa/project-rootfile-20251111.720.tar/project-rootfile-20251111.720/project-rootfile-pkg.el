;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-rootfile" "20251111.720"
  "Extension of project.el to detect project with root file."
  '((emacs "27.1"))
  :url "https://github.com/buzztaiki/project-rootfile.el"
  :commit "6c674446350ac3e54536c5520dd3f622463c6f4a"
  :revdesc "6c674446350a"
  :authors '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainers '(("Taiki Sugawara" . "buzz.taiki@gmail.com")))
