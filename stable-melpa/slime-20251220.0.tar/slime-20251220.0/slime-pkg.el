;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20251220.0"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "9b59a6dcf1c1210463b5a68ff3db21f8af62233d"
  :revdesc "9b59a6dcf1c1"
  :keywords '("languages" "lisp" "slime"))
