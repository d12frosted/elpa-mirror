;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dayone" "20160105.1240"
  "Utility script for Day One."
  '((uuid     "0.0.3")
    (mustache "0.22")
    (ht       "1.5"))
  :url "https://github.com/mori-dev/emacs-dayone"
  :commit "ab628274f0806451f23bce16f62a6a11cbf91a2b"
  :revdesc "ab628274f080"
  :keywords '("day one" "tools" "convenience")
  :authors '(("mori-dev" . "mori.dev.asdf@gmail.com"))
  :maintainers '(("mori-dev" . "mori.dev.asdf@gmail.com")))
