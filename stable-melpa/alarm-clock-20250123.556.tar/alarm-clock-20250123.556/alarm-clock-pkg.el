;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alarm-clock" "20250123.556"
  "Alarm Clock."
  '((emacs "24.4"))
  :url "https://github.com/wlemuel/alarm-clock"
  :commit "8a805d365aa38be32041c4e968bb624d3bb1b54b"
  :revdesc "8a805d365aa3"
  :keywords '("calendar" "tools" "convenience")
  :authors '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainers '(("Steve Lemuel" . "wlemuel@hotmail.com")))
