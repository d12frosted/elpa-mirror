(define-package "consult" "20211213.1713" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "cc8eff9578f5d089735e8b7dd7a08732890ed648" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
