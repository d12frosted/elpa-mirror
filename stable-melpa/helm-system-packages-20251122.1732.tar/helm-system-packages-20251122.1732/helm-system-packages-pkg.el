;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "20251122.1732"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "116c6f5cba4a1b2264110d3fef6bb8169595968b"
  :revdesc "116c6f5cba4a"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
