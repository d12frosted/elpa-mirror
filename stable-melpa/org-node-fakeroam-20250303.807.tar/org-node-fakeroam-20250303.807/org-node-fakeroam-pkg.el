;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node-fakeroam" "20250303.807"
  "Stand-ins for org-roam-autosync-mode."
  '((emacs    "28.1")
    (org-node "1.9.17")
    (compat   "30")
    (org-roam "2.2.2")
    (emacsql  "4.0.3"))
  :url "https://github.com/meedstrom/org-node-fakeroam"
  :commit "1f2dd19f355c1cbce872fe5fb6dca3a47947d7c2"
  :revdesc "1f2dd19f355c"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
