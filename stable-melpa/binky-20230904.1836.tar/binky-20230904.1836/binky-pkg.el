(define-package "binky" "20230904.1836" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "ba06421b4224e212b26fd18e8b2269a900fc8cc9" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
