;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260405.1945"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "cfdb07d76660483fe6599006d6d1593937df062a"
  :revdesc "cfdb07d76660"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
