(define-package "all-the-icons" "20220929.2235" "A library for inserting Developer icons"
  '((emacs "24.3"))
  :commit "dd8c15504903b12f6bfc2c4571fc2f632949b7f8" :authors
  '(("Dominic Charlesworth" . "dgc336@gmail.com"))
  :maintainer
  '("Dominic Charlesworth" . "dgc336@gmail.com")
  :keywords
  '("convenient" "lisp")
  :url "https://github.com/domtronn/all-the-icons.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
