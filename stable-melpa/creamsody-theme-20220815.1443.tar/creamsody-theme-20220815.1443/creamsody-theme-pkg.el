(define-package "creamsody-theme" "20220815.1443" "Straight from the soda fountain"
  '((autothemer "0.2")
    (emacs "24"))
  :commit "5a7e072e2c65edc86189d08d612916712d159923" :url "http://github.com/emacsfodder/emacs-theme-creamsody")
;; Local Variables:
;; no-byte-compile: t
;; End:
