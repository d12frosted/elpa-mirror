;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260108.212"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "a9f21234f37589f40bfe582d8e0bed82c879a50c"
  :revdesc "a9f21234f375"
  :keywords '("convenience" "input method" "dbus"))
