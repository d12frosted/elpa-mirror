(define-package "apheleia" "20231128.2250" "Reformat buffer stably"
  '((emacs "27"))
  :commit "56651724ad22f2769bbdaccf54cbe75c1cb35c91" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
