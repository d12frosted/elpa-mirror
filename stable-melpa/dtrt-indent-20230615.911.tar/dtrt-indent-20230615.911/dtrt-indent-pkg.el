(define-package "dtrt-indent" "20230615.911" "Adapt to foreign indentation offsets" 'nil :commit "e77fb2d7041058e9b763efdaa47befee8fdac947" :authors
  '(("Julian Scheid" . "julians37@googlemail.com"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("convenience" "files" "languages" "c"))
;; Local Variables:
;; no-byte-compile: t
;; End:
