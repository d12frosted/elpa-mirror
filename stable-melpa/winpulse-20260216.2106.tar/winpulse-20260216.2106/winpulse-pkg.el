;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winpulse" "20260216.2106"
  "Momentary window background flash animation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/winpulse"
  :commit "c58352bea2223fd6f0cc11deb4d33bca2ff0213c"
  :revdesc "c58352bea222"
  :authors '(("Alvaro Ramirez" . "https://xenodium.com"))
  :maintainers '(("Alvaro Ramirez" . "https://xenodium.com")))
