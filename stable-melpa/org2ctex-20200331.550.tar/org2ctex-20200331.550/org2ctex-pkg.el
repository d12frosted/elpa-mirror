;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2ctex" "20200331.550"
  "Export org to ctex (a latex macro for Chinese)."
  '((emacs "24.4"))
  :url "https://github.com/tumashu/org2ctex"
  :commit "2e40aa5e78b0562516f46f689e7b74cdf451cc2a"
  :revdesc "2e40aa5e78b0"
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
