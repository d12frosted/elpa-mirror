;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260927.1241"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1dbf001f34facd741da0c4f1f5f864b7a993a9e0"
  :revdesc "1dbf001f34fa")
