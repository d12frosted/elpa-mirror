(define-package "ox-linuxmag-fr" "20221026.1954" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "a8b8b9b8d2727247d7e0ef64302d2f2ad26119ec" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
