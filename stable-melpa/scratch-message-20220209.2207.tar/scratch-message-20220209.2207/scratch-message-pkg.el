;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-message" "20220209.2207"
  "Changing message in your scratch buffer."
  ()
  :url "https://github.com/thisirs/scratch-message.git"
  :commit "0d4198f6effd8f118bf03ee4979f566041ef6a9b"
  :revdesc "0d4198f6effd"
  :keywords '("util" "scratch")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
