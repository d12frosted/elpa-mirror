(define-package "flexoki-themes" "20231024.1047" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "92cf4f8e446fa83a86de1186356c36f212763f8d" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
