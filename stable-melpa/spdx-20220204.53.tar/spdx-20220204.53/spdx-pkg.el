(define-package "spdx" "20220204.53" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "38cfd66c3044f26cd1c7d6e599bc73f9b9fc0760" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
