;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260219.1330"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "a6e96ef5a546430c84b4143305ad564fc905da6a"
  :revdesc "a6e96ef5a546"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
