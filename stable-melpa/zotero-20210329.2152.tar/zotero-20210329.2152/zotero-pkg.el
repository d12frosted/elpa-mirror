(define-package "zotero" "20210329.2152" "Library for the Zotero API"
  '((emacs "27.1")
    (ht "2.2")
    (oauth "1.0.4")
    (s "1.12.0"))
  :commit "23dfa7e5e0567656567807f76eb7537ee7eaf6e7" :authors
  '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainer
  '("Folkert van der Beek" . "folkertvanderbeek@gmail.com")
  :keywords
  '("zotero" "hypermedia")
  :url "https://gitlab.com/fvdbeek/emacs-zotero")
;; Local Variables:
;; no-byte-compile: t
;; End:
