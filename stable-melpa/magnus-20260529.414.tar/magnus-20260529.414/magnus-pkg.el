;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260529.414"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "94d2c6d12c05b5ec5fb92abc73fd4b41450149ee"
  :revdesc "94d2c6d12c05"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
