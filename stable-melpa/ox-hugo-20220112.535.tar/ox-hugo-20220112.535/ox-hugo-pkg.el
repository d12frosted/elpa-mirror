(define-package "ox-hugo" "20220112.535" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "3a7cb207a2e33e74144550ba10644b20d3bdc718" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
