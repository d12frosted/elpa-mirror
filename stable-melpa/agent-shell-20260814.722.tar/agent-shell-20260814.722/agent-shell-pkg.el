;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260814.722"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "fb187b3953ae0b87e6810ea06105e631ac30ae0c"
  :revdesc "fb187b3953ae")
