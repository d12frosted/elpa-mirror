(define-package "0x0" "20230528.1625" "Upload sharing to 0x0.st"
  '((emacs "26.1"))
  :commit "09cdeda5ed91a03f26b2aedab3b75812edd1ee8d" :authors
  '(("William Vaughn <https://gitlab.com/willvaughn>"))
  :maintainers
  '(("William Vaughn" . "vaughnwilld@gmail.com"))
  :maintainer
  '("William Vaughn" . "vaughnwilld@gmail.com")
  :url "https://gitlab.com/willvaughn/emacs-0x0")
;; Local Variables:
;; no-byte-compile: t
;; End:
