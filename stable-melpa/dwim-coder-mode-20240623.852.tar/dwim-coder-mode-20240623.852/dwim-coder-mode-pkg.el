(define-package "dwim-coder-mode" "20240623.852" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "30"))
  :commit "061dad80575425c2f9473779928c7f27258c2957" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
