(define-package "org-ai" "20230802.1637" "Your AI assistant with ChatGPT, DALL-E, Whisper, Stable Diffusion"
  '((emacs "27"))
  :commit "80bc75f70155c9fcce1513e1e6598a3f77307039" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
