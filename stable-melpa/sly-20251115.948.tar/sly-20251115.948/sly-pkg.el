;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20251115.948"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.5"))
  :url "https://github.com/joaotavora/sly"
  :commit "0dfe5a506450532217b080a0ecfab6150c3c976b"
  :revdesc "0dfe5a506450"
  :keywords '("languages" "lisp" "sly"))
