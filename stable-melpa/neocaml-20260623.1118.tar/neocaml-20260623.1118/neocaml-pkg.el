;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260623.1118"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "ab00ee699747841d42c5618f2d568a1608bae671"
  :revdesc "ab00ee699747"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
