;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260726.641"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "0d481cb8675d5f6176ebdead79d3689874176675"
  :revdesc "0d481cb8675d"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
