(define-package "bibtex-actions" "20210909.1234" "Bibliographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0")
    (parsebib "3.0"))
  :commit "b9260654b5d3d7aff31c588ee5356ea716abfc81" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
