;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ink-mode" "20260206.923"
  "Major mode for writing interactive fiction in Ink."
  '((emacs "29.1"))
  :url "https://github.com/Kungsgeten/ink-mode"
  :commit "04e141fbba63a353c77b20b0abf2397b85e2f0fe"
  :revdesc "04e141fbba63"
  :keywords '("languages" "wp" "hypermedia"))
