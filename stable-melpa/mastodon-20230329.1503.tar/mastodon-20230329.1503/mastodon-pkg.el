(define-package "mastodon" "20230329.1503" "Client for Mastodon, a federated social network"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4")
    (ts "0.3"))
  :commit "33b010279e142378ace994cc74c3ce747337f29e" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
