;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260504.1313"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "fec8bf1c515f90a4546a908ab12f99e0f603a437"
  :revdesc "fec8bf1c515f"
  :keywords '("languages"))
