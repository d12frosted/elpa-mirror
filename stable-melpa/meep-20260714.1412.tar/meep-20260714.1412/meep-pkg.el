;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260714.1412"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "3cd54f66fcb7912ab6b2efa978928011c05a2dd8"
  :revdesc "3cd54f66fcb7"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
