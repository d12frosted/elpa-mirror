;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260426.1404"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "3d70d52c858fd7df2fef0e5d09a7d67055ecf192"
  :revdesc "3d70d52c858f"
  :keywords '("convenience" "comm" "hypermedia"))
