;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260408.840"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "a0dc8ed7afeb23d1954929a73003e976a575acd3"
  :revdesc "a0dc8ed7afeb"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
