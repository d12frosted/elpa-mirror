(define-package "apdl-mode" "20210828.1913" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "f1d4bef95c3be736c15f0d9b41037ba02933acf1" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
