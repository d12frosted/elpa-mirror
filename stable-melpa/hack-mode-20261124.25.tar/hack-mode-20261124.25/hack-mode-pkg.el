;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hack-mode" "20261124.25"
  "Major mode for the Hack programming language."
  '((emacs "25.1")
    (s     "1.11.0"))
  :url "https://github.com/hhvm/hack-mode"
  :commit "b17a1de4620767dc94bc1201682d1eedaa41702e"
  :revdesc "b17a1de46207"
  :authors '(("John Allen" . "jallen@fb.com")
             ("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("John Allen" . "jallen@fb.com")
                 ("Wilfred Hughes" . "me@wilfred.me.uk")))
