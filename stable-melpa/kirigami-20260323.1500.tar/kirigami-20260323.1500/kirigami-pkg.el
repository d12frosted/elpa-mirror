;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260323.1500"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "f10d72e07cae3bcfac2e9ab70fd917966e7b4ad4"
  :revdesc "f10d72e07cae"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
