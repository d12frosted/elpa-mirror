;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hindu-calendar" "20260326.1437"
  "Astronomical traditional Hindu calendar (panchanga)."
  '((emacs "24.3"))
  :url "https://github.com/bdsatish/hindu-calendar"
  :commit "e953f1b8971fb16210a918d439c1f36887c2d043"
  :revdesc "e953f1b8971f"
  :keywords '("calendar" "panchanga" "hindu" "indian")
  :authors '(("B.D.Satish" . "bdsatish@gmail.com"))
  :maintainers '(("B.D.Satish" . "bdsatish@gmail.com")))
