;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260215.2008"
  "On-the-fly syntax checking."
  '((emacs "27.1")
    (seq   "2.24"))
  :url "https://www.flycheck.org"
  :commit "69dfbc4886b22531378f90915711af3bb8754237"
  :revdesc "69dfbc4886b2"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
