(define-package "modus-themes" "20220512.1808" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "b6285162d80fe438b4ac99acff74d33b5f901c35" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
