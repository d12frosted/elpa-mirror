;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20260710.1707"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "166f421bce4a6550507e0bd2b896956d0d9d4a94"
  :revdesc "166f421bce4a"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
