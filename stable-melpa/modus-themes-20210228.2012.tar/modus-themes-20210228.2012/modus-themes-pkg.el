(define-package "modus-themes" "20210228.2012" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "9d3538f8a5007e33640b8ac1a0b725afc6287174" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
