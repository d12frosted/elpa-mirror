(define-package "axiom-environment" "20210714.1912" "An environment for using Axiom/OpenAxiom/FriCAS"
  '((emacs "24.2"))
  :commit "7d72e6319b98b334f74b78f3d4151e92fb7dcbad" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("axiom" "openaxiom" "fricas"))
;; Local Variables:
;; no-byte-compile: t
;; End:
