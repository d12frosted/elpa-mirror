;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-books" "20170325.631"
  "Helm interface for searching books."
  '((helm "1.7.7"))
  :url "https://github.com/grugrut/helm-books"
  :commit "6735e1787f99b5ef77b276fa5c43e565b4d3e792"
  :revdesc "6735e1787f99"
  :authors '(("grugrut" . "grugruglut+github@gmail.com"))
  :maintainers '(("grugrut" . "grugruglut+github@gmail.com")))
