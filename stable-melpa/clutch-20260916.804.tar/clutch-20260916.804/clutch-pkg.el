;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260916.804"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "3ea2db4f8b1f31d95301de070bbde95251187727"
  :revdesc "3ea2db4f8b1f"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
