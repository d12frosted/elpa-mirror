(define-package "transient" "20240629.1156" "Transient commands"
  '((emacs "26.1")
    (compat "29.1.4.5")
    (seq "2.24"))
  :commit "f2cb28a56cd8f81bf18c0dcd8565e3ae128baf52" :authors
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
