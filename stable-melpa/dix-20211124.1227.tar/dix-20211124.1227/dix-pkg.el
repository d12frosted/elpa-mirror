(define-package "dix" "20211124.1227" "Apertium XML editing minor mode"
  '((cl-lib "0.5")
    (emacs "26.2"))
  :commit "80d5ea3bceff75b842065e2f99657f3f70c7e604" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("languages")
  :url "http://wiki.apertium.org/wiki/Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
