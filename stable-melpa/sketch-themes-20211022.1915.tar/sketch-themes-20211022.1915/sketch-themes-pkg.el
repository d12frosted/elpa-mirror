(define-package "sketch-themes" "20211022.1915" "Sketch color themes"
  '((emacs "26.1"))
  :commit "8083d2b3e7834c7e4531a6a7882ffa4058aee4c3" :authors
  '(("Daw-Ran Liou" . "hi@dawranliou.com"))
  :maintainer
  '("Daw-Ran Liou" . "hi@dawranliou.com")
  :keywords
  '("faces")
  :url "https://github.com/dawranliou/sketch-themes/")
;; Local Variables:
;; no-byte-compile: t
;; End:
