;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260625.2243"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.1")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c59a0a9e94e964ebb15dbdf94838b58ccb03cb20"
  :revdesc "c59a0a9e94e9")
