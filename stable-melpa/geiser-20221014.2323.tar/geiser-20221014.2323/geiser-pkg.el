(define-package "geiser" "20221014.2323" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (project "0.8.1"))
  :commit "af81e4fb1088d9ccbd36dcd541e29eb2770e4d87" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
