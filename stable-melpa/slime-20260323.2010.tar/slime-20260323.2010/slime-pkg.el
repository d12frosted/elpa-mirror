;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260323.2010"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "065edc572345f4d521577e508a89c7599f8a8c4c"
  :revdesc "065edc572345"
  :keywords '("languages" "lisp" "slime"))
