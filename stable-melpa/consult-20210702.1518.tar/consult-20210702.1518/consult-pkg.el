(define-package "consult" "20210702.1518" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7f095b05174716ce38cdc3ae7c2cc13bc0b73da1" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
