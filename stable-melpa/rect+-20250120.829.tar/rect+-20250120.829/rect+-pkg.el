;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rect+" "20250120.829"
  "Extensions to rect.el."
  ()
  :url "https://github.com/mhayashi1120/Emacs-rectplus"
  :commit "6b1d49b64b331c4f59a265e0fa91333a0e8243c2"
  :revdesc "6b1d49b64b33"
  :keywords '("extensions" "data" "tools")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
