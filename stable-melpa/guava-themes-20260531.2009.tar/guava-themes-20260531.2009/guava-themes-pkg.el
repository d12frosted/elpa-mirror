;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260531.2009"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "7839cb5c11840d84cafa8de385c3737186292ab9"
  :revdesc "7839cb5c1184"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
