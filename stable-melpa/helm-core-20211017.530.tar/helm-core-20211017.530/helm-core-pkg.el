(define-package "helm-core" "20211017.530" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "99de86329d948357e8f645bff6ac06a96fd801bc")
;; Local Variables:
;; no-byte-compile: t
;; End:
