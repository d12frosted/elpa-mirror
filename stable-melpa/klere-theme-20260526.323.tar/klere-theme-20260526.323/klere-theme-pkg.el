;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "klere-theme" "20260526.323"
  "A dark theme with lambent color highlights and incremental grays."
  '((emacs "24"))
  :url "https://github.com/tomenzgg/emacs-klere-theme"
  :commit "332d93b22f0359150c8dd8de710ffed09c34664f"
  :revdesc "332d93b22f03"
  :authors '(("Jean Libète" . "tomenzgg@mail.mayfirst.org"))
  :maintainers '(("Jean Libète" . "tomenzgg@mail.mayfirst.org")))
