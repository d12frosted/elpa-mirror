(define-package "prettier" "20210606.1150" "Code formatting with Prettier"
  '((emacs "26.1")
    (iter2 "0.9")
    (nvm "0.2"))
  :commit "85c9349de2730b71c5796e342d67efee34faa9ed" :authors
  '(("Julian Scheid" . "julians37@gmail.com"))
  :maintainer
  '("Julian Scheid" . "julians37@gmail.com")
  :keywords
  '("convenience" "languages" "files")
  :url "https://github.com/jscheid/prettier.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
