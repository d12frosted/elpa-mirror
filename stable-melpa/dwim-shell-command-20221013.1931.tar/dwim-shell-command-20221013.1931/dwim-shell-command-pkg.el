(define-package "dwim-shell-command" "20221013.1931" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "ff7489a0b20f2e2aa587e926512d9550beb9ece4" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
