(define-package "forth-mode" "20231016.640" "Programming language mode for Forth"
  '((cl-lib "0.2"))
  :commit "aaacce775b910afe06a02a56ecfceb3288c84b64" :authors
  '(("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainers
  '(("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainer
  '("Lars Brinkhoff" . "lars@nocrew.org")
  :keywords
  '("languages" "forth")
  :url "http://github.com/larsbrinkhoff/forth-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
