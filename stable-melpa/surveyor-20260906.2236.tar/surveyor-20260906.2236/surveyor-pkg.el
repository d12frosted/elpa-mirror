;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "surveyor" "20260906.2236"
  "Survey your code with LLM-generated diagrams."
  '((emacs     "29.1")
    (gptel     "0.9.0")
    (transient "0.4.0"))
  :url "https://github.com/mrcnski/surveyor.el"
  :commit "5d31539f04875b0dcbd1b3399c34c34f6117910a"
  :revdesc "5d31539f0487"
  :keywords '("convenience" "tools" "docs")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
