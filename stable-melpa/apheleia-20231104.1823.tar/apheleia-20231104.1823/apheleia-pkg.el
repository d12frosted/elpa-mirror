(define-package "apheleia" "20231104.1823" "Reformat buffer stably"
  '((emacs "27"))
  :commit "392028d823cfe8804a3d97f9bc2a4c4b283e6c74" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
