;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacemacs-theme" "20260414.2052"
  "Color theme with a dark and light versions."
  ()
  :url "https://github.com/nashamri/spacemacs-theme"
  :commit "789d20c55cd01f757929d0232dd1d5227c84ad7e"
  :revdesc "789d20c55cd0"
  :keywords '("color" "theme"))
