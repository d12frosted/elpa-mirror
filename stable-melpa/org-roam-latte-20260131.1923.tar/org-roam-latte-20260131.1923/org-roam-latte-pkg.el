;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-latte" "20260131.1923"
  "Auto-highlight unlinked Org-roam references."
  '((emacs       "27.1")
    (org-roam    "2.0")
    (inflections "1.1"))
  :url "https://github.com/yad-tahir/org-roam-latte"
  :commit "d93c09be6367b010618b73af8dae5113a9c4eecb"
  :revdesc "d93c09be6367"
  :keywords '("hypermedia" "outlines" "org-roam" "convenience")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
