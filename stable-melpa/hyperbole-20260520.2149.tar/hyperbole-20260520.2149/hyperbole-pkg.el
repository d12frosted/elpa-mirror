;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260520.2149"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "fa3b56bbde5cc0d682dff61aa91803ec4c78cdaf"
  :revdesc "fa3b56bbde5c"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
