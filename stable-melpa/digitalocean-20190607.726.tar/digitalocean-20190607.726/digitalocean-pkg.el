;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digitalocean" "20190607.726"
  "Create and manipulate digitalocean droplets."
  '((request "2.5")
    (emacs   "24.4"))
  :url "https://github.com/olymk2/emacs-digitalocean"
  :commit "6c32d3593286e2a62d9afab0057c829407b0d1e8"
  :revdesc "6c32d3593286"
  :keywords '("processes" "tools")
  :authors '(("Oliver Marks" . "oly@digitaloctave.com"))
  :maintainers '(("Oliver Marks" . "oly@digitaloctave.com")))
