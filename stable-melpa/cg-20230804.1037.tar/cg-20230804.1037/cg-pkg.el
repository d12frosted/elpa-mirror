(define-package "cg" "20230804.1037" "Major mode for editing Constraint Grammar files"
  '((emacs "26.1"))
  :commit "c22f5572c0946b0d21f4d489308ea0ce9f305ea0" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("languages")
  :url "https://visl.sdu.dk/constraint_grammar.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
