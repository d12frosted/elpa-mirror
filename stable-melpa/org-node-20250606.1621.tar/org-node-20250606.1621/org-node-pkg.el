;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250606.1621"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.14.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "1956a215208da55761e9045c7a9fb6470de82b24"
  :revdesc "1956a215208d"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
