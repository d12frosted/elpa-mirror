;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-projectile" "20260630.833"
  "Helm integration for Projectile."
  '((emacs      "27.1")
    (helm       "3.0")
    (projectile "2.9"))
  :url "https://github.com/bbatsov/helm-projectile"
  :commit "487862772daf82dd89fa229f97efc59ea5858406"
  :revdesc "487862772daf"
  :keywords '("project" "convenience"))
