(define-package "proof-general" "20211217.1753" "PG init file for package.el and ELPA compatibility"
  '((emacs "25.1"))
  :commit "a61a1d8e5ffa610b794535995d58adf18e9ec47b" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
