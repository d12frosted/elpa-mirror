;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "20251123.654"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "586a74449a63ee368a4aa3f4fb295d83b0212e4f"
  :revdesc "586a74449a63"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
