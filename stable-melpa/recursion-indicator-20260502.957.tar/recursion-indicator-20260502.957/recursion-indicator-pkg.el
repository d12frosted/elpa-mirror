;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recursion-indicator" "20260502.957"
  "Recursion indicator."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/recursion-indicator"
  :commit "096a858ba9a73f9a1942ab3241a781b0164e6d34"
  :revdesc "096a858ba9a7"
  :keywords '("convenience")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
