(define-package "latex-labeler" "20231123.240" "Simplify equation labeling in LaTeX"
  '((emacs "28.1"))
  :commit "fbe4d339804a86bcd6b164ad1795983b4b10f0b6" :authors
  '(("X9hRRDys"))
  :maintainers
  '(("X9hRRDys"))
  :maintainer
  '("X9hRRDys")
  :keywords
  '("tools")
  :url "https://github.com/X9hRRDys/latex-labeler")
;; Local Variables:
;; no-byte-compile: t
;; End:
