;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-journal" "20260118.1223"
  "Daily note interface for vulpea."
  '((emacs     "29.1")
    (vulpea    "2.0.0")
    (vulpea-ui "0.1.0")
    (dash      "2.20.0"))
  :url "https://github.com/d12frosted/vulpea-journal"
  :commit "2d3b5b473669ab2b24b085ed632eb30770cd1cb8"
  :revdesc "2d3b5b473669"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
