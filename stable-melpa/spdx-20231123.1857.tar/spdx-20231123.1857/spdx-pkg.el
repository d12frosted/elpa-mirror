(define-package "spdx" "20231123.1857" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "2aeb2bc79aa03b158bee8fd766fc9a4fb1d772b7" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
