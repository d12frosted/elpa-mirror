(define-package "modus-themes" "20211109.547" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "e174bad2ca2497c7003ca88146122461a7c04247" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
