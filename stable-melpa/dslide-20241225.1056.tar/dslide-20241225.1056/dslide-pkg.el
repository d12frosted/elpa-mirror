;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dslide" "20241225.1056"
  "Domain Specific sLIDEs. Programmable Presentation."
  '((emacs "29.2"))
  :url "https://github.com/positron-solutions/dslide"
  :commit "48b2eaf5f4dac8c92e7d60e20e24f8cc11e57650"
  :revdesc "48b2eaf5f4da"
  :keywords '("convenience" "org-mode" "presentation" "narrowing")
  :authors '(("Positron" . "contact@positron.solutions"))
  :maintainers '(("Positron" . "contact@positron.solutions")))
