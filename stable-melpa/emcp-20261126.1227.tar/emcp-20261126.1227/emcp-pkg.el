;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20261126.1227"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.2.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "25a329b6888bf89a43295afd117834bd28006033"
  :revdesc "25a329b6888b"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
