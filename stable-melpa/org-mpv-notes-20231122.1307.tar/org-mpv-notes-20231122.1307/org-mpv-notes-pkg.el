(define-package "org-mpv-notes" "20231122.1307" "Take notes in org mode while watching videos in mpv"
  '((emacs "27.1")
    (mpv "0.2.0"))
  :commit "0586c4d508e3c465db2ca81d43aa0070a6de0eb3" :authors
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainers
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainer
  '("Bibek Panthi" . "bpanthi977@gmail.com")
  :url "https://github.com/bpanthi977/org-mpv-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
