(define-package "detached" "20221008.1843" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "0beadb74e094e68c5a2015a819a7ec7392359fc3" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
