;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260427.2347"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "ceb6619c18e7e0738c90fcad4d618331cbb8baa6"
  :revdesc "ceb6619c18e7"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
