;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261103.248"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "b64910ad7ba0d1ea10a93ac1c9d16be0803b32b7"
  :revdesc "b64910ad7ba0"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
