;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-context-line" "20181122.2203"
  "Improve orientation when scrolling."
  ()
  :url "https://github.com/ska2342/highlight-context-line/"
  :commit "c3257c0ca9dba76167bbd7e0718a65ecd26ef26f"
  :revdesc "c3257c0ca9db"
  :keywords '("faces" "services" "user")
  :authors '(("Stefan Kamphausen" . "www.skamphausen.de"))
  :maintainers '(("Stefan Kamphausen" . "www.skamphausen.de")))
