(define-package "good-scroll" "20210613.206" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "26a1b958bbf2c45d86f033e58b74edd196302f23" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
