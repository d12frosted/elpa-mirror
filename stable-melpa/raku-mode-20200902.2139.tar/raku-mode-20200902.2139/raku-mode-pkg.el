(define-package "raku-mode" "20200902.2139" "Major mode for editing Raku code"
  '((emacs "24.4")
    (pkg-info "0.1"))
  :commit "8a6e17f1749c084251d19c3d58b9c1495891db6d" :keywords
  ("languages")
  :authors
  (("Hinrik Örn Sigurðsson" . "hinrik.sig@gmail.com"))
  :maintainer
  ("Hinrik Örn Sigurðsson" . "hinrik.sig@gmail.com")
  :url "https://github.com/hinrik/perl6-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
