;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maxframe" "20170120.1705"
  "Maximize the emacs frame based on display size."
  ()
  :url "https://github.com/rmm5t/maxframe.el"
  :commit "13bda6dd9f1d96aa4b9dd9957a26cefd399a7772"
  :revdesc "13bda6dd9f1d"
  :keywords '("display" "frame" "window" "maximize"))
