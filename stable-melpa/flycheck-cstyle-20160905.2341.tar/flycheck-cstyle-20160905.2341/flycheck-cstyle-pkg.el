;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-cstyle" "20160905.2341"
  "Integrate cstyle with flycheck."
  '((flycheck "0.24")
    (emacs    "24.4"))
  :url "https://github.com/alexmurray/flycheck-cstyle"
  :commit "002699f83253ea8e1a509a9ab6d0fce1a1650f73"
  :revdesc "002699f83253"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
