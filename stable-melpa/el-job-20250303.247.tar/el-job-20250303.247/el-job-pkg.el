;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250303.247"
  "Contrived way to call a function using all CPU cores."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/meedstrom/el-job"
  :commit "b93884c3cd621b935bdc3004cc6e6787d9efb95c"
  :revdesc "b93884c3cd62"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
