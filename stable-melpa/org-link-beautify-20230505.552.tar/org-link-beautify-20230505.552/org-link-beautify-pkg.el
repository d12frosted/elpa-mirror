(define-package "org-link-beautify" "20230505.552" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1"))
  :commit "9fd7b2d996e8304a98b6a763dee14aa312a89e59" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
