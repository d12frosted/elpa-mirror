;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260407.1238"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "85b3e5f5a3a3c79cbf219e81f2f9c6decf1a4fbc"
  :revdesc "85b3e5f5a3a3"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
