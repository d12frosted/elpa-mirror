;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20261101.1110"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "10de0ce7a22d2d3ea7e54e7fe96f800c1806aa11"
  :revdesc "10de0ce7a22d"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
