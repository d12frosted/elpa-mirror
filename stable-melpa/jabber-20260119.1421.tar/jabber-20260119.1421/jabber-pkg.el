;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260119.1421"
  "A minimal Jabber client."
  '((emacs "27.1")
    (fsm   "0.2.0")
    (srv   "0.2"))
  :url "https://codeberg.org/emacs-jabber/emacs-jabber"
  :commit "745e5f1354e99bfcee1aa097fb9d198cd701b463"
  :revdesc "745e5f1354e9"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("wgreenhouse" . "wgreenhouse@tilde.club")))
