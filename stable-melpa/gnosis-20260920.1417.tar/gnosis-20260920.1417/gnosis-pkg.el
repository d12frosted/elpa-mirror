;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260920.1417"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.4.4"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "1eb319966ccfb7b5d1e5f50f3738d5962dc21441"
  :revdesc "1eb319966ccf"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
