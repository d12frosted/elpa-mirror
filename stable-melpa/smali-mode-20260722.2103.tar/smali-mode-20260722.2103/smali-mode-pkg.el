;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smali-mode" "20260722.2103"
  "Major mode for editing Smali/Baksmali files."
  '((emacs "24.1"))
  :url "https://github.com/strazzere/Emacs-Smali"
  :commit "564d914b0901628d4cac8051fb457119383c7fff"
  :revdesc "564d914b0901"
  :keywords '("languages" "smali")
  :authors '(("Tim Strazzere" . "diff@protonmail.com"))
  :maintainers '(("Tim Strazzere" . "diff@protonmail.com")))
