(define-package "verilog-ext" "20231007.1457" "SystemVerilog Extensions"
  '((emacs "29.1")
    (verilog-mode "2023.6.6.141322628")
    (verilog-ts-mode "0.1.1")
    (eglot "1.9")
    (lsp-mode "8.0.0")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (apheleia "3.1")
    (yasnippet "0.14.0")
    (flycheck "32")
    (outshine "3.0.1")
    (async "1.9.7"))
  :commit "373418c2530dcfe2fb759ae1e7132cae968fc172" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
