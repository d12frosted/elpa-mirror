;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20261025.1901"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "12099e40ea265a44cdac42b77e2621dad1adfa8b"
  :revdesc "12099e40ea26"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
