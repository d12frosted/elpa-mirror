(define-package "debian-el" "20231007.1820" "Emacs helpers specific to Debian users" 'nil :commit "9496601eeb7656d50073e819e850e4a9df6bd60a")
;; Local Variables:
;; no-byte-compile: t
;; End:
