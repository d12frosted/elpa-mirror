;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251025.1702"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "32318e7c3e4d52341fe0f7264db2da062e7a0967"
  :revdesc "32318e7c3e4d"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
