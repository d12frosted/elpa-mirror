(define-package "modus-themes" "20220623.1301" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "6f0eda73a76e0472d461c8bca12ed59f858f7ead" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
