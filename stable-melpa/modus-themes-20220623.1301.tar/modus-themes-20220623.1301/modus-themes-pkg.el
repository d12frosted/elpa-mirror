(define-package "modus-themes" "20220623.1301" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "8fb0e4abca2239fafcffa6b354bbecc58285c10f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
