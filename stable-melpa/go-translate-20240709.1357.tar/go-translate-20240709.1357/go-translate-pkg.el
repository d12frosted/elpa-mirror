(define-package "go-translate" "20240709.1357" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "aab98d002b7156f569b26c0b306fa72c00e05410" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
