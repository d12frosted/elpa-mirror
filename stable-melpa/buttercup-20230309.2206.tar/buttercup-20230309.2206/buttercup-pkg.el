(define-package "buttercup" "20230309.2206" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "c6693d3667a71e88f459002fecf61df74d9e18ac" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
