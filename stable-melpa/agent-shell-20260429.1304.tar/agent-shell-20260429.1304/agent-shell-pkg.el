;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260429.1304"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "85bd9c41d43a92b0961960864830dc893120c86d"
  :revdesc "85bd9c41d43a")
