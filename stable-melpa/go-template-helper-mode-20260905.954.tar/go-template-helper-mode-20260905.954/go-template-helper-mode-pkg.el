;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-template-helper-mode" "20260905.954"
  "Go template highlighting in host modes (Helm/YAML)."
  '((emacs            "28.1")
    (go-template-mode "2.0.0"))
  :url "https://codeberg.org/rch/go-template-helper-mode"
  :commit "e817efb8e281f3fead57fcd22bdc0d0f7a6dedbe"
  :revdesc "e817efb8e281"
  :keywords '("tools" "faces")
  :authors '(("Robert Charusta" . "rch-public@posteo.net"))
  :maintainers '(("Robert Charusta" . "rch-public@posteo.net")))
