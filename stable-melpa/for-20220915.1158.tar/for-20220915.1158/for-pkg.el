(define-package "for" "20220915.1158" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "0ea6470632f254e6926c46e8e86e2436520fd7c9" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
