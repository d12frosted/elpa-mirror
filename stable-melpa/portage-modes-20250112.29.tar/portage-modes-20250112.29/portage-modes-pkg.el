;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "portage-modes" "20250112.29"
  "Major modes for editing Portage config files."
  ()
  :url "https://github.com/OpenSauce04/portage-modes"
  :commit "9864675f5151802df8941059baf3d3bf89a4b1b0"
  :revdesc "9864675f5151"
  :authors '(("OpenSauce" . "opensauce04@gmail.com"))
  :maintainers '(("OpenSauce" . "opensauce04@gmail.com")))
