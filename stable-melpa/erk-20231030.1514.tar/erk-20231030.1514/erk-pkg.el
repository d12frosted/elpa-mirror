(define-package "erk" "20231030.1514" "Elisp (GitHub) Repository Kit"
  '((emacs "28.1")
    (auto-compile "1.2.0")
    (dash "2.18.0")
    (license-templates "0.1.3"))
  :commit "a29a165199fcc90fe7409db38977e3f1c6c9cc3a" :authors
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainers
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainer
  '("Positron Solutions" . "contact@positron.solutions")
  :keywords
  '("convenience" "programming")
  :url "http://github.com/positron-solutions/elisp-repo-kit")
;; Local Variables:
;; no-byte-compile: t
;; End:
