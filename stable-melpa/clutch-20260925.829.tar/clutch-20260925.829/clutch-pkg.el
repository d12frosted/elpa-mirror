;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260925.829"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "12d903fea2909b5901d9a48dea4bb5f07acb7c0f"
  :revdesc "12d903fea290"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
