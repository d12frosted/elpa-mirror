;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260701.1039"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "db03febb9baa563786b6264dba1a4f372c64f5c5"
  :revdesc "db03febb9baa"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
