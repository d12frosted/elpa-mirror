;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-tex" "20250306.1724"
  "Consult powered completion for tex."
  '((emacs   "28.2")
    (consult "0.35"))
  :url "https://gitlab.com/titus.pinta/consult-TeX"
  :commit "546e4b16a3f98fa1d4d440acb158b8fa5147a14c"
  :revdesc "546e4b16a3f9"
  :keywords '("consult" "tex" "latex")
  :maintainers '(("Titus Pinta" . "titus.pinta@gmail.com")))
