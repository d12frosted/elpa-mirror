;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20240929.1939"
  "Tools for assembling a package archive."
  '((emacs  "26.1")
    (compat "30.0.0.0"))
  :url "https://github.com/melpa/package-build"
  :commit "dd32541fc45a4f3afb1dfc9637d1b21d2b56f60e"
  :revdesc "dd32541fc45a"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")))
