(define-package "workgroups2" "20211222.1313" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "122b9deefad67f8c7ad269b19a8fea80e7ea2d76" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
