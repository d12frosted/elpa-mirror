;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-ascii-plot" "20260320.2046"
  "Unicode-art bar plots in org-mode tables."
  ()
  :url "https://github.com/tbanel/orgtblasciiplot"
  :commit "8d8959d54343e93f7e578daa34ac315ece9ef8aa"
  :revdesc "8d8959d54343"
  :keywords '("org" "table" "ascii" "plot"))
