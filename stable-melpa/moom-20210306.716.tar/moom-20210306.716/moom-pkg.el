(define-package "moom" "20210306.716" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "d0076ea22b2afc4c3faeea2138e836b1c8f08988" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
