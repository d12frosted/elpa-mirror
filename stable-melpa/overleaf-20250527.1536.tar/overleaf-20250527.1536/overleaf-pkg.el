;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250527.1536"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "1d8d9f2ac36e227e84e2c055804da2d19a517c30"
  :revdesc "1d8d9f2ac36e"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
