;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesky" "20260611.502"
  "A Bluesky client."
  '((emacs "30.1")
    (plz   "0.9.0")
    (futur "1.7")
    (vui   "1.0.0"))
  :url "https://github.com/ahyatt/emacs-bluesky"
  :commit "ef01cb6862c1aca93073f8726c5a7e62f1091ccc"
  :revdesc "ef01cb6862c1"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
