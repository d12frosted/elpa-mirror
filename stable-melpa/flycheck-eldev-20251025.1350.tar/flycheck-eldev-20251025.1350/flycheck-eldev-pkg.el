;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-eldev" "20251025.1350"
  "Eldev support in Flycheck."
  '((flycheck "32")
    (dash     "2.17")
    (emacs    "24.4"))
  :url "https://github.com/flycheck/flycheck-eldev"
  :commit "ad9e367c0caf75195e7443b666adcddf98576724"
  :revdesc "ad9e367c0caf"
  :keywords '("tools" "convenience")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
