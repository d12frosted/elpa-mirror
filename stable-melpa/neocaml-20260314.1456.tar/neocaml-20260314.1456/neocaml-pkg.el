;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260314.1456"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "db7199331c6d5ed2b303bb5e769b58b966a69a16"
  :revdesc "db7199331c6d"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
