(define-package "ursa-ts-mode" "20230910.1024" "Major mode for Ursa, using tree-sitter"
  '((emacs "29.1"))
  :commit "a950696ab4f92a8ce63ccc5afe76eff67854b5c9" :authors
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("ursalang" "languages" "tree-sitter")
  :url "https://github.com/ursalang/ursa-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
