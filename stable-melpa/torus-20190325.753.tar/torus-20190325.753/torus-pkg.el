;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "torus" "20190325.753"
  "A buffer groups manager."
  '((emacs "26"))
  :url "https://github.com/chimay/torus"
  :commit "863886f10db77f3d1b16815d77561b6c81d88352"
  :revdesc "863886f10db7"
  :keywords '("files" "buffers" "groups" "persistent" "history" "layout" "tabs"))
