;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260825.1124"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "484a4c15fcd2a1dddc9571bfe05c07ea56c486ce"
  :revdesc "484a4c15fcd2"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
