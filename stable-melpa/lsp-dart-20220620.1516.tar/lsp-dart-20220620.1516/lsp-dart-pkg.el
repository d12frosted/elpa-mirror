(define-package "lsp-dart" "20220620.1516" "Dart support lsp-mode"
  '((emacs "26.3")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (dart-mode "1.0.5"))
  :commit "7868b87ab27cf96878ded35c390e15bb5bb588e6" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
