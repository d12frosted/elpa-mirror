;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261127.2357"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "ddfef1fa9df93e9df1c7e09fbbb6a364d92b5340"
  :revdesc "ddfef1fa9df9"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
