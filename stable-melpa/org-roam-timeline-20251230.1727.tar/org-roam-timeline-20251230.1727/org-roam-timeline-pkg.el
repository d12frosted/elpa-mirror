;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-timeline" "20251230.1727"
  "Visual timeline for Org-Roam nodes."
  '((emacs        "27.1")
    (org-roam     "2.0")
    (json-mode    "1.0")
    (simple-httpd "1.5.1"))
  :url "https://github.com/GerardoCendejas/org-roam-timeline"
  :commit "68a5f4c74e63a4d2c29e809e7a096766fa900aeb"
  :revdesc "68a5f4c74e63"
  :keywords '("org" "hypermedia" "visualization" "timeline")
  :authors '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu"))
  :maintainers '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu")))
