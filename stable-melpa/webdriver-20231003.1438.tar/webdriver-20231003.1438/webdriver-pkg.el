(define-package "webdriver" "20231003.1438" "WebDriver local end implementation"
  '((emacs "27.1"))
  :commit "0892bbdcc7144cfa59b17fde2b3616aa6f691f0b" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/mauroaranda/emacs-webdriver")
;; Local Variables:
;; no-byte-compile: t
;; End:
