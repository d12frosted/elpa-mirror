;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-tools" "20251231.1730"
  "Support library for PDF documents."
  '((emacs     "26.3")
    (tablist   "1.0")
    (let-alist "1.0.4"))
  :url "http://github.com/vedang/pdf-tools/"
  :commit "27a7d4b9ac52b020344274df9680e9ba5f12e412"
  :revdesc "27a7d4b9ac52"
  :keywords '("files" "multimedia")
  :authors '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainers '(("Vedang Manerikar" . "vedang.manerikar@gmail.com")))
