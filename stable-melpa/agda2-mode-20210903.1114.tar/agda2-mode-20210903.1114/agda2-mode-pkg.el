(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "7ae10725b194afd3a4c56ee6810c10d3fb483888")
;; Local Variables:
;; no-byte-compile: t
;; End:
