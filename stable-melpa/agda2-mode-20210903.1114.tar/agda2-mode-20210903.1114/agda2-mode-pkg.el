(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "2ede73cfa408d6157bb9d811e3a9b3bab8b8b26c")
;; Local Variables:
;; no-byte-compile: t
;; End:
