(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "6b18ebca879f08eecabd11dcc04fe3997113367a")
;; Local Variables:
;; no-byte-compile: t
;; End:
