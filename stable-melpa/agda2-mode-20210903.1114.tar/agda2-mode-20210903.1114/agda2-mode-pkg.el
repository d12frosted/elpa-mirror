(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "53c08b5dfed6d0c00c5a0c9398adc01a48aa1177")
;; Local Variables:
;; no-byte-compile: t
;; End:
