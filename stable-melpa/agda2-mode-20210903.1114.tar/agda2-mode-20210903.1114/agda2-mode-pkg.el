(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "edd8334381f6c7a59f7a5f23eb668e62e1464aee")
;; Local Variables:
;; no-byte-compile: t
;; End:
