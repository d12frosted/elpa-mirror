(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "aef821d8b21a86422d4037e7514762b38da9ff75")
;; Local Variables:
;; no-byte-compile: t
;; End:
