(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "3185db9f8a4ad507dd73cbc4068cd56805e3cbf9")
;; Local Variables:
;; no-byte-compile: t
;; End:
