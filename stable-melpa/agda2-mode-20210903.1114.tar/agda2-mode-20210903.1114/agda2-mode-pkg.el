(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "731f300deac14e10792a0bbf22c86cbe0c9c7e4b")
;; Local Variables:
;; no-byte-compile: t
;; End:
