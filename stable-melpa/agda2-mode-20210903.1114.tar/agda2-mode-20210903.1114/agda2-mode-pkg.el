(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "dbadb16046f8e804691e595c218560cc8d767484")
;; Local Variables:
;; no-byte-compile: t
;; End:
