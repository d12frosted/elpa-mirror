(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "77754f29a838d5de19bbedee4d8b617da53e62e2")
;; Local Variables:
;; no-byte-compile: t
;; End:
