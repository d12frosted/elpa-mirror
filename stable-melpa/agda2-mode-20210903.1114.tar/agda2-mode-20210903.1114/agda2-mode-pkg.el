(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "52702c963b6b2889a710cfc21c72cdd7a1b8a15c")
;; Local Variables:
;; no-byte-compile: t
;; End:
