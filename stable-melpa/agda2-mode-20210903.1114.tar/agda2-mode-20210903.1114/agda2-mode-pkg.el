(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "8037346494d68356efdb2f6e0ef1458704721acd")
;; Local Variables:
;; no-byte-compile: t
;; End:
