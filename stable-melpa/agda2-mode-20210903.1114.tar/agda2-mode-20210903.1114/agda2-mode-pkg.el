(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "6fd3b18bec87b0e795aac3b7f075d74acd7d56df")
;; Local Variables:
;; no-byte-compile: t
;; End:
