(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "138f578c08b38be5b4e0a32e431a7d0a20d7e1d1")
;; Local Variables:
;; no-byte-compile: t
;; End:
