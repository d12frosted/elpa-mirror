(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "7f58030124fa99dfbf8db376659416f3ad8384de")
;; Local Variables:
;; no-byte-compile: t
;; End:
