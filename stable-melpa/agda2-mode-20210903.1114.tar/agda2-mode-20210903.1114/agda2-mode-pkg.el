(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "53bb9d0fbceca1acf97f7ddcbe4b716e49fd0825")
;; Local Variables:
;; no-byte-compile: t
;; End:
