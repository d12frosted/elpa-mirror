(define-package "agda2-mode" "20210903.1114" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "b4808830ff9c817f590003455bbc62afd2924692")
;; Local Variables:
;; no-byte-compile: t
;; End:
