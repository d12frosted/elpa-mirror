;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260502.1750"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "ca80186682cd140e6a6a0bff70d1d01dc114fae5"
  :revdesc "ca80186682cd"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
