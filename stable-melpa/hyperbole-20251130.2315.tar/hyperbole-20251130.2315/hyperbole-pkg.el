;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251130.2315"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "89a1f11e44633de5f1de2a7c56a6ff047429ffc9"
  :revdesc "89a1f11e4463"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
