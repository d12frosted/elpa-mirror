(define-package "pr-review" "20220409.339" "Review github PR"
  '((emacs "27.1")
    (magit-section "3.2")
    (magit "3.2")
    (markdown-mode "2.5")
    (ghub "3.5"))
  :commit "a1d35f5633d7181371e795e3f98c900ba5845bb6" :authors
  '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainer
  '("Yikai Zhao" . "yikai@z1k.dev")
  :keywords
  '("tools")
  :url "https://github.com/blahgeek/emacs-pr-review")
;; Local Variables:
;; no-byte-compile: t
;; End:
