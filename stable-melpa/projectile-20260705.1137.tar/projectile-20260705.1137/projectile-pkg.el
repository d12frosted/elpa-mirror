;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260705.1137"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "7246f6114fac6dc27b7f88149d0193ea8324dffd"
  :revdesc "7246f6114fac"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
