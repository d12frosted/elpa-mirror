(define-package "champagne" "20231111.358" "Graphical countdowns"
  '((emacs "28.1")
    (posframe "1.4.2"))
  :commit "a99e1584207bc03a0cb776f715bd47de1d651010" :authors
  '(("Psionik K" . "73710933+psionic-k@users.noreply.github.com"))
  :maintainers
  '(("Psionik K" . "73710933+psionic-k@users.noreply.github.com"))
  :maintainer
  '("Psionik K" . "73710933+psionic-k@users.noreply.github.com")
  :keywords
  '("games")
  :url "http://github.com/positron-solutions/champagne")
;; Local Variables:
;; no-byte-compile: t
;; End:
