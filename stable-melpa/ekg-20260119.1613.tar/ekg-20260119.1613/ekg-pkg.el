;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260119.1613"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "bbd94e571990a31ecc3ab8108a02dd3b3aac2757"
  :revdesc "bbd94e571990"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
