;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250520.840"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "fc892f890041b39fbe96fb970fd1f8fb65d23bd4"
  :revdesc "fc892f890041"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
