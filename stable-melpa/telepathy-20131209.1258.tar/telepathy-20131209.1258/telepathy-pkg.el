;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telepathy" "20131209.1258"
  "Access Telepathy from Emacs."
  ()
  :url "https://github.com/NicolasPetton/telepathy.el"
  :commit "211d785b02a29ddc254422fdcc3db45262582f8c"
  :revdesc "211d785b02a2"
  :keywords '("telepathy" "tools")
  :authors '(("Nicolas Petton" . "petton.nicolas@gmail.com"))
  :maintainers '(("Nicolas Petton" . "petton.nicolas@gmail.com")))
