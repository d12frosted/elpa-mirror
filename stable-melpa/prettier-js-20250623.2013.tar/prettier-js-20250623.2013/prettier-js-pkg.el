;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250623.2013"
  "Minor mode to format JS code on file save."
  ()
  :url "https://github.com/prettier/prettier-emacs"
  :commit "8d63b11076fc270162bc7866eb2cf38aeddbaf0e"
  :revdesc "8d63b11076fc"
  :keywords '("convenience" "wp" "edit" "js"))
