;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20261011.214"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "56d528fefd8057a025437b4330ebf506f46ca27d"
  :revdesc "56d528fefd80"
  :keywords '("languages" "lisp" "slime"))
