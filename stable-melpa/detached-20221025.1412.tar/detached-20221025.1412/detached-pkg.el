(define-package "detached" "20221025.1412" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "235468280221d48cd2841b9f2e944b6d760c2e12" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
