;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260203.1737"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "750adb762bcfbea6a6fb2074bad7958c6d61b357"
  :revdesc "750adb762bcf")
