(define-package "consult" "20220218.135" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "8083f7f314e2d0bd5a4d424bf9b2cb2950f4310b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
