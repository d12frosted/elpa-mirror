(define-package "thrift" "20230608.616" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "9adf90f43fba510bf6a40f3fac24904202305020" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
