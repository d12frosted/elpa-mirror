(define-package "consult" "20210213.2014" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "31c5909fb2496a4ae36fa8f4d47b82390570c34d" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
