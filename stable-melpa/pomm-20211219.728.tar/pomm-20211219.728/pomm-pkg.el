(define-package "pomm" "20211219.728" "Yet another Pomodoro timer implementation"
  '((emacs "27.1")
    (alert "1.2")
    (seq "2.22")
    (transient "0.3.0"))
  :commit "596eed778fa30e7b33910f015543eda13abd1888" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/pomm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
