;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "javelin" "20251231.1337"
  "Implementation of harpoon: bookmarks on steroids."
  '((emacs "28.1"))
  :url "https://github.com/DamianB-BitFlipper/javelin.el"
  :commit "09fe2132b2768e56e6e3a3bc93ee4f3eb1fdd5b1"
  :revdesc "09fe2132b276"
  :keywords '("tools" "languages"))
