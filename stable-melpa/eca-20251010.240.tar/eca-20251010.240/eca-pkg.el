;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251010.240"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "31c1fc73d058daedb52eb7b51fea6b4fb94c2fab"
  :revdesc "31c1fc73d058"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
