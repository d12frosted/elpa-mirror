(define-package "ledger-mode" "20230920.1222" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "ba5330a28cde652b92116196f39d8444e74a2ade")
;; Local Variables:
;; no-byte-compile: t
;; End:
