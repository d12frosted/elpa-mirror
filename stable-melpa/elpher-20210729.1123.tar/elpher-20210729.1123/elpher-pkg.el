(define-package "elpher" "20210729.1123" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "2cdf02e99dbd2d7f765c08ad2f8477b4ea07d5f7" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
