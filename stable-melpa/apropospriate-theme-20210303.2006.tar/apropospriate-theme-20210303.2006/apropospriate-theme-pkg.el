(define-package "apropospriate-theme" "20210303.2006" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "cf12db35089836ee521ef248860ef8c48ea6ce4a")
;; Local Variables:
;; no-byte-compile: t
;; End:
