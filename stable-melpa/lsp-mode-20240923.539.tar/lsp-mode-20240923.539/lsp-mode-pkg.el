(define-package "lsp-mode" "20240923.539" "LSP mode"
  '((emacs "27.1")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.3")
    (spinner "1.7.3")
    (markdown-mode "2.3")
    (lv "0")
    (eldoc "1.11"))
  :commit "e87fbdc35d29c53041da4670f85446712c8e7a63" :keywords
  '("languages")
  :url "https://github.com/emacs-lsp/lsp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
