(define-package "proof-general" "20220610.705" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "ec4f9bad18f6c8336e53910d3ea941d5ceb52f52" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
