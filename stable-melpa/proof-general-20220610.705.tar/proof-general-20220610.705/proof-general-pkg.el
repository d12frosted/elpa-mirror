(define-package "proof-general" "20220610.705" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "28c1dc00922b96f8461156c171de928bdeeab5ca" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
