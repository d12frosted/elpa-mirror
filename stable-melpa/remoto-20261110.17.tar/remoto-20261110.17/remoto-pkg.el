;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261110.17"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "d8c517cc80ad7878ab3c2e958d8961f752a20810"
  :revdesc "d8c517cc80ad"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
