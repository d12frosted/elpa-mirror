(define-package "magik-mode" "20220121.1349" "mode for editing Magik + some utils." 'nil :commit "6e2555f5f52e808ca62a8c5cd64194ba2e637273" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
