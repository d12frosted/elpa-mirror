(define-package "helm-core" "20220605.411" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "3b8e7c108b938b44d71dc0044837d928c3830302" :authors
  '(("Thierry Volpiatto "))
  :maintainer
  '("Thierry Volpiatto ")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
