;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260601.917"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "56ef06620b2f1006ada6f0bddee18d7e8392941b"
  :revdesc "56ef06620b2f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
