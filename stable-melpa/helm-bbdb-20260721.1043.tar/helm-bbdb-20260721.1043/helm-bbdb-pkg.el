;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bbdb" "20260721.1043"
  "Helm interface for bbdb."
  '((emacs "26.1")
    (helm  "1.5")
    (bbdb  "3.1.2"))
  :url "https://github.com/emacs-helm/helm-bbdb"
  :commit "b841014981d205b3847fdaa55f149a5a3ee40988"
  :revdesc "b841014981d2"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Jonathan Gregory" . "jgrg@autistici.org")))
