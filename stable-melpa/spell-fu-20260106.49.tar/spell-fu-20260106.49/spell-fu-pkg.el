;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spell-fu" "20260106.49"
  "Fast & light spelling highlighter."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spell-fu"
  :commit "a2e009e664d510763b7a7b3abe91e20c197ebd8f"
  :revdesc "a2e009e664d5"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
