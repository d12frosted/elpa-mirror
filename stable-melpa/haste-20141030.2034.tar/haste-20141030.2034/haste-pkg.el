;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haste" "20141030.2034"
  "Emacs client for hastebin (http://hastebin.com/about.md)."
  '((json "1.2"))
  :url "https://github.com/rlister/emacs-haste-client"
  :commit "f1099c6296fc9575675e281402b89854739114bb"
  :revdesc "f1099c6296fc")
