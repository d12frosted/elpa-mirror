;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timeout" "20260502.1908"
  "Throttle or debounce Elisp functions."
  '((emacs "24.4"))
  :url "https://github.com/karthink/timeout"
  :commit "60b5ab7774f30fd12b9927e93b4d43fafb1fe925"
  :revdesc "60b5ab7774f3"
  :keywords '("convenience" "extensions")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
