;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-rtm" "20160214.1236"
  "Simple import/export from rememberthemilk to org-mode."
  '((rtm "0.1"))
  :url "https://github.com/pmiddend/org-rtm"
  :commit "adc42ad1fbe92ab447ccc9553780f4456f2508d2"
  :revdesc "adc42ad1fbe9"
  :keywords '("outlines" "data")
  :authors '(("Philipp Middendorf" . "pmidden@secure.mailbox.org"))
  :maintainers '(("Philipp Middendorf" . "pmidden@secure.mailbox.org")))
