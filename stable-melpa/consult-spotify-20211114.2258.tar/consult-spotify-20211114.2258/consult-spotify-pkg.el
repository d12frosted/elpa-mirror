;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-spotify" "20211114.2258"
  "Spotify queries using consult."
  '((emacs    "26.1")
    (consult  "0.8")
    (espotify "0.1"))
  :url "https://codeberg.org/jao/espotify"
  :commit "5c1dcf0182135cda4191d4ba206fe2f265100293"
  :revdesc "5c1dcf018213"
  :keywords '("multimedia")
  :authors '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
