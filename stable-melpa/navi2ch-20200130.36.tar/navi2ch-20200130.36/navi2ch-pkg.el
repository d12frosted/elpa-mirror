;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "navi2ch" "20200130.36"
  "Navigator for 2ch for Emacsen."
  ()
  :url "https://github.com/naota/navi2ch"
  :commit "7811dba052f679bd920a1f648d621a6fecace10f"
  :revdesc "7811dba052f6"
  :keywords '("network" "2ch")
  :authors '(("Taiki SUGAWARA" . "taiki@users.sourceforge.net"))
  :maintainers '(("Taiki SUGAWARA" . "taiki@users.sourceforge.net")))
