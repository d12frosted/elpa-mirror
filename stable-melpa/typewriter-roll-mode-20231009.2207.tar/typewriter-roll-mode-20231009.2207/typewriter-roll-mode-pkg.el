(define-package "typewriter-roll-mode" "20231009.2207" "Aid for distraction-free writing"
  '((emacs "24.1"))
  :commit "3114d05731517d40972e2ed896806b25bdc0d8c2" :authors
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainer
  '("Peter Badida" . "keyweeusr@gmail.com")
  :keywords
  '("convenience" "line" "carriage" "writing" "distraction" "cr" "rewind")
  :url "https://github.com/KeyWeeUsr/typewriter-roll-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
