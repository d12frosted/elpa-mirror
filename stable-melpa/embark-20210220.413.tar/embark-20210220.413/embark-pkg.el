(define-package "embark" "20210220.413" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "040eb317bc422477ddb4eeff4a565d1e3c9024b6" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
