(define-package "merlin" "20220502.811" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "3fb8e7df31e63918e7e230a8142b720c035e86d9" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
