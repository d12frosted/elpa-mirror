;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "furl" "20150509.316"
  "Friendly URL retrieval."
  ()
  :url "https://github.com/nex3/furl-el"
  :commit "014438271e0ef27333dfcd599cb247f12a20d870"
  :revdesc "014438271e0e"
  :authors '(("Natalie Weizenbaum" . "nweiz@google.com"))
  :maintainers '(("Natalie Weizenbaum" . "nweiz@google.com")))
