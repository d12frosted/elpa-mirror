;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atcoder-tools" "20200109.1236"
  "An atcoder-tools client."
  '((emacs "26")
    (f     "0.20")
    (s     "1.12"))
  :url "https://github.com/sei40kr/atcoder-tools"
  :commit "cfe61ed18ea9b3b1bfb6f9e7d80a47599680cd1f"
  :revdesc "cfe61ed18ea9"
  :keywords '("extensions" "tools")
  :authors '(("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainers '(("Seong Yong-ju" . "sei40kr@gmail.com")))
