(define-package "fuz" "20190805.1723" "Fast and precise fuzzy scoring/matching utils"
  '((emacs "25.1"))
  :commit "90ca9207a9c1decda24a552b94ff41169ecccb14" :authors
  '(("Zhu Zihao" . "all_but_last@163.com"))
  :maintainer
  '("Zhu Zihao" . "all_but_last@163.com")
  :keywords
  '("lisp")
  :url "https://github.com/cireu/fuz.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
