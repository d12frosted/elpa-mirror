(define-package "embark" "20211109.1856" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "52287782413543c6eb51a3bacc8af48919055c51" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
