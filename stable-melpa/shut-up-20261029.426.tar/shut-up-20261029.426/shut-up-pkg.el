;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shut-up" "20261029.426"
  "Shut up would you!."
  '((emacs "25.3"))
  :url "https://github.com/rejeep/shut-up.el"
  :commit "d5bcadb37848d1c41584222d5d7f2bef0bfc5bf2"
  :revdesc "d5bcadb37848"
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
