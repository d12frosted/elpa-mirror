;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261126.402"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "090f8115b572cb1afbe1cfa079b2088e8866b67f"
  :revdesc "090f8115b572"
  :keywords '("build tools" "languages"))
