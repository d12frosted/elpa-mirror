;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-get" "20260530.1521"
  "Manage the external elisp bits and pieces you depend upon."
  ()
  :url "http://www.emacswiki.org/emacs/el-get"
  :commit "dfc31d6fa215d40f2eed4a693974a5875065c0d1"
  :revdesc "dfc31d6fa215"
  :keywords '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
