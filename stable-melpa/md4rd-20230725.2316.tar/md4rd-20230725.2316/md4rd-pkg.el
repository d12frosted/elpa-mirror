;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md4rd" "20230725.2316"
  "Mode for reddit (browse it)."
  '((emacs     "25.1")
    (request   "0.3.0")
    (cl-lib    "0.6.1")
    (dash      "2.12.0")
    (s         "1.12.0")
    (tree-mode "1.0.0"))
  :url "https://github.com/ahungry/md4rd"
  :commit "2fa198af749e9ddb759e052d911f56a626088903"
  :revdesc "2fa198af749e"
  :keywords '("ahungry" "reddit" "browse" "news")
  :authors '(("Matthew Carter" . "m@ahungry.com"))
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
