;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eradio" "20210327.1000"
  "A simple Internet radio player."
  '((emacs "24.1"))
  :url "https://github.com/fossegrim/eradio"
  :commit "47769986c79def84307921f0277e9bb2714756c2"
  :revdesc "47769986c79d"
  :authors '(("Olav Fosse" . "mail@olavfosse.no"))
  :maintainers '(("Olav Fosse" . "mail@olavfosse.no")))
