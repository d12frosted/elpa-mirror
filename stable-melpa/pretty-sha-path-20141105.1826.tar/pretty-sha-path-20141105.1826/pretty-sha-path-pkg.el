;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretty-sha-path" "20141105.1826"
  "Prettify Guix/Nix store paths."
  ()
  :url "https://gitorious.org/alezost-emacs/pretty-sha-path"
  :commit "beea38bdf34ed27059d6484e1e2a337a27e1f7ce"
  :revdesc "beea38bdf34e"
  :keywords '("faces" "convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
