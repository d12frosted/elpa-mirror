;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ipp" "20251124.718"
  "Implementation of the Internet Printing Protocol."
  '((plz   "0.9")
    (emacs "28.1"))
  :url "https://github.com/emarsden/ipp-el"
  :commit "8210d8a276ff4dfb67e3a2b4594a67be095edd45"
  :revdesc "8210d8a276ff"
  :keywords '("printing" "hardware")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
