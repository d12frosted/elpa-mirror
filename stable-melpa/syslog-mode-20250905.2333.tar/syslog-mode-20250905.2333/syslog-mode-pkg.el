;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syslog-mode" "20250905.2333"
  "Major-mode for viewing log files & strace output."
  '((hide-lines "20130623")
    (ov         "20150311")
    (hsluv      "20181127"))
  :url "https://github.com/vapniks/syslog-mode"
  :commit "f167635feae7365574755a7d61a27079c6b40aef"
  :revdesc "f167635feae7"
  :keywords '("unix")
  :authors '(("Harley Gorrell" . "harley@panix.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
