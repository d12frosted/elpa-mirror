;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260729.514"
  "MCP server for Org-mode."
  '((emacs          "28.2")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "c47f1e448042ef8a072c8f658dc2c1125359c684"
  :revdesc "c47f1e448042"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
