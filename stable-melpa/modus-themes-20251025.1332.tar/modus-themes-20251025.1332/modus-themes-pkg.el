;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251025.1332"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "f6fe42f0467f998e0110c6ad0021a966d1780728"
  :revdesc "f6fe42f0467f"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
