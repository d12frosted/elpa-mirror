(define-package "org-grep" "20230424.2005" "Kind of M-x rgrep adapted for Org mode"
  '((emacs "26.1"))
  :commit "428cfc2e2c35867272d32f82cadaea46772e3609" :authors
  '(("François Pinard" . "pinard@iro.umontreal.ca"))
  :maintainers
  '(("Greg Minshall" . "minshall@umich.edu"))
  :maintainer
  '("Greg Minshall" . "minshall@umich.edu")
  :url "https://sr.ht/~minshall/org-grep/")
;; Local Variables:
;; no-byte-compile: t
;; End:
