;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261020.615"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.16.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "1d370dc978b797eb420d8ce54896d9cdb8b89e67"
  :revdesc "1d370dc978b7"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
