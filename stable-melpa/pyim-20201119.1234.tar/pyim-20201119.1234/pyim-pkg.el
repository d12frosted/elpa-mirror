(define-package "pyim" "20201119.1234" "A Chinese input method support quanpin, shuangpin, wubi and cangjie."
  '((emacs "24.4")
    (popup "0.1")
    (async "1.6")
    (xr "1.13")
    (pyim-basedict "0.1"))
  :commit "be9171be2f34fda0343240d736f5b0eaf0f3e458")
;; Local Variables:
;; no-byte-compile: t
;; End:
