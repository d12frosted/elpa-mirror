(define-package "meow" "20220515.2054" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "0a978e0232947d8e3a0895d104fe7f8671daed6f" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
