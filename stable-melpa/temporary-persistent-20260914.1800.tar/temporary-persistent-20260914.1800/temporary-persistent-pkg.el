;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "temporary-persistent" "20260914.1800"
  "Keep temp notes buffers persistent."
  '((emacs "24.3")
    (names "20151201.0")
    (dash  "2.12.1")
    (s     "1.10.0"))
  :url "https://github.com/kostafey/temporary-persistent"
  :commit "b441e78649f0b612d5946a443d320ded27bbee20"
  :revdesc "b441e78649f0"
  :keywords '("temp" "buffers" "notes")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
