(define-package "solarized-theme" "20190809.1202" "The Solarized color theme, ported to Emacs."
  '((emacs "24.1")
    (cl-lib "0.5")
    (dash "2.6.0"))
  :commit "55cd77b61b6968048c61e13358ba487d217f24c0")
;; Local Variables:
;; no-byte-compile: t
;; End:
