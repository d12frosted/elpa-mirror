(define-package "geiser-guile" "20211029.1512" "Guile's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.16"))
  :commit "1c5affdf1354220b49ab08b5a7665ebf61080863" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
