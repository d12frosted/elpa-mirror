(define-package "clojure-mode-extra-font-locking" "20230823.1720" "Extra font-locking for Clojure mode"
  '((clojure-mode "3.0"))
  :commit "192a46653fdc27601905f97a044d47764fee1f4e" :authors
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.dev")
  :keywords
  '("languages" "lisp")
  :url "https://github.com/clojure-emacs/clojure-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
