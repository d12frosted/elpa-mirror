(define-package "doom-themes" "20210601.2132" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "59f2ef327c46f5f68de8895bc4d68046085d43db" :authors
  '(("Henrik Lissner <https://github.com/hlissner>"))
  :maintainer
  '("Henrik Lissner" . "henrik@lissner.net")
  :keywords
  '("custom themes" "faces")
  :url "https://github.com/hlissner/emacs-doom-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
