;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261029.2103"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "c507571c556534c5d6e07ea741a977c811d27f6b"
  :revdesc "c507571c5565"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
