;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "subemacs" "20170401.934"
  "Evaluating expressions in a fresh Emacs subprocess."
  ()
  :url "https://github.com/kbauer/subemacs"
  :commit "18d53939fec8968c08dfc5aff7240ca07efb1aac"
  :revdesc "18d53939fec8"
  :keywords '("extensions" "lisp" "multiprocessing")
  :authors '(("Klaus-Dieter Bauer" . "bauer.klaus.dieter@gmail.com"))
  :maintainers '(("Klaus-Dieter Bauer" . "bauer.klaus.dieter@gmail.com")))
