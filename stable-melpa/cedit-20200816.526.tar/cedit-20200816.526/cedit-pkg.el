;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cedit" "20200816.526"
  "Paredit-like commands for c-like languages."
  ()
  :url "http://zk-phi.gitub.io/"
  :commit "cb38316903e6cfa8b8c978defa7e1dafcd4e0c12"
  :revdesc "cb38316903e6")
