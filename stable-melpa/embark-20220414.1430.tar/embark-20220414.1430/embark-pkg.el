(define-package "embark" "20220414.1430" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c4889163c8aa4f96af520cefa81d60f7f0048626" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
