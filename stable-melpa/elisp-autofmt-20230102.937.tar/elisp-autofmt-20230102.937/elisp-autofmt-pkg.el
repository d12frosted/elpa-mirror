(define-package "elisp-autofmt" "20230102.937" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "01b698b87a9ab153ce6a65aa6f7dd4618cb881f0" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
