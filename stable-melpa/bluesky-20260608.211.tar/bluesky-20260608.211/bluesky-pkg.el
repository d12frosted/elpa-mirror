;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesky" "20260608.211"
  "A Bluesky client."
  '((emacs "30.1")
    (plz   "0.9.0")
    (futur "1.7")
    (vui   "1.0.0"))
  :url "https://github.com/ahyatt/emacs-bluesky"
  :commit "eb322cea90a363400563c4387b5fadf0a60e68ca"
  :revdesc "eb322cea90a3"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
