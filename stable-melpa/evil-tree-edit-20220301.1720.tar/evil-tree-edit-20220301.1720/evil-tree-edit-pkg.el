(define-package "evil-tree-edit" "20220301.1720" "Evil structural editing for any language!"
  '((emacs "27.1")
    (tree-edit "0.1.0")
    (tree-sitter "0.15.0")
    (evil "1.0.0")
    (avy "0.5.0")
    (s "0.0.0"))
  :commit "ad6d5971faf6958fd0a7776c7a14791b101c8563" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
