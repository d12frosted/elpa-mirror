;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auth-source-keytar" "20251231.1726"
  "Integrate auth-source with keytar."
  '((emacs  "24.4")
    (keytar "0.1.2")
    (s      "1.12.0"))
  :url "https://github.com/emacs-grammarly/auth-source-keytar"
  :commit "ae32dd807aa3cff59e4384ce8c9d7de259e45998"
  :revdesc "ae32dd807aa3"
  :keywords '("convenience" "keytar" "password" "credential" "secret" "security")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
