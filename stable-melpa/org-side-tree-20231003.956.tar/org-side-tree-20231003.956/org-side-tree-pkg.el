(define-package "org-side-tree" "20231003.956" "Navigate Org outlines in side window tree"
  '((emacs "28.1"))
  :commit "b1aede5c4b7ddf6a8ccc77aad3c07cb2f8bdcfe4" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/org-side-tree")
;; Local Variables:
;; no-byte-compile: t
;; End:
