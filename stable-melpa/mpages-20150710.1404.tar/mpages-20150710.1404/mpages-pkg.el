;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpages" "20150710.1404"
  "An Emacs buffer for quickly writing your Morning Pages."
  ()
  :url "https://github.com/slevin/mpages"
  :commit "39a72a0931ab1cdbfdf0ab9f412dc12d43a3829f"
  :revdesc "39a72a0931ab")
