;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ext" "20260716.1137"
  "SystemVerilog Extensions."
  '((emacs           "29.1")
    (verilog-mode    "2024.3.1.121933719")
    (verilog-ts-mode "0.6.0")
    (lsp-mode        "8.0.0")
    (rg              "2.3.0")
    (hydra           "0.15.0")
    (apheleia        "3.1")
    (yasnippet       "0.14.0")
    (flycheck        "32")
    (async           "1.9.7"))
  :url "https://github.com/gmlarumbe/verilog-ext"
  :commit "f4c65a24724cd2d1eeb1e21ec10c9cee4bfcc385"
  :revdesc "f4c65a24724c"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
