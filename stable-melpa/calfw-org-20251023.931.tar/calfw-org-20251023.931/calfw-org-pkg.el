;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-org" "20251023.931"
  "Calendar view for org-agenda."
  '((emacs "28.1")
    (calfw "2.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "a68056ea4571a5f2f07c1a6e2fba10fff14ccebc"
  :revdesc "a68056ea4571"
  :keywords '("calendar" "org")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
