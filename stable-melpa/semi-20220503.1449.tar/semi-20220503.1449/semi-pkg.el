(define-package "semi" "20220503.1449" "A library to provide MIME features."
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9"))
  :commit "b1c245b81715b0430f7593cee2339e6264104f3d")
;; Local Variables:
;; no-byte-compile: t
;; End:
