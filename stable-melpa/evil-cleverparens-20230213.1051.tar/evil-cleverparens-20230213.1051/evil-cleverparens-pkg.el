(define-package "evil-cleverparens" "20230213.1051" "Evil friendly minor-mode for editing lisp."
  '((evil "1.0")
    (paredit "1")
    (smartparens "1.6.1")
    (emacs "24.4")
    (dash "2.12.0"))
  :commit "e4c753a9c74d5d4b7b06cb6fb5442b6b309b6793" :authors
  '(("Olli Piepponen" . "opieppo@gmail.com"))
  :maintainer
  '("Olli Piepponen" . "opieppo@gmail.com")
  :keywords
  '("convenience" "emulations")
  :url "https://github.com/emacs-evil/evil-cleverparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
