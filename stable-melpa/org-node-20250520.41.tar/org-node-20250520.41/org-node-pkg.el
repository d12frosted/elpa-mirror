;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250520.41"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.11.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "17cb097a283fe3618462de421c9965cec117ef19"
  :revdesc "17cb097a283f"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
