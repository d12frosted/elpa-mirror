(define-package "spdx" "20230903.503" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "a0d209117ec2ebf47e3932e9ad6ac5987a0bb028" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
