(define-package "elisa" "20240401.1526" "Emacs Lisp Information System Assistant"
  '((emacs "29.2")
    (ellama "0.8.6")
    (llm "0.9.1")
    (async "1.9.8"))
  :commit "1acc89545d14800ae34e5d509fbd3f269388fa1d" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/elisa")
;; Local Variables:
;; no-byte-compile: t
;; End:
