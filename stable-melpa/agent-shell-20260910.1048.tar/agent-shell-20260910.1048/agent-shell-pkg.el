;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260910.1048"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "82364bc1ff94a8f15210f74a336b7ecc85c076d8"
  :revdesc "82364bc1ff94")
