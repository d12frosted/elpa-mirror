(define-package "pygn-mode" "20210714.1304" "Major-mode for chess PGN files, powered by Python"
  '((emacs "25.1")
    (uci-mode "0.5.4")
    (nav-flash "1.0.0")
    (ivy "0.10.0"))
  :commit "321c14c195cd2f8a31b9bf99dd318a552fbbcd6d" :authors
  '(("Dodge Coates and Roland Walker"))
  :maintainer
  '("Dodge Coates and Roland Walker")
  :keywords
  '("data" "games" "chess")
  :url "https://github.com/dwcoates/pygn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
