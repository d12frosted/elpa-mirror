;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250611.918"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "961e09d4d7309d7bef4b29090301853d9ae00afe"
  :revdesc "961e09d4d730"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
