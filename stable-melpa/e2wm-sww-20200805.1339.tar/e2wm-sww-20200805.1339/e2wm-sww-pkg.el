;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-sww" "20200805.1339"
  "Plugin of e2wm.el to switch plugin quickly."
  '((e2wm "1.2"))
  :url "https://github.com/aki2o/e2wm-sww"
  :commit "8926d0c70be05c7b4ef821e22e411e8813973687"
  :revdesc "8926d0c70be0"
  :keywords '("tools" "window manager")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
