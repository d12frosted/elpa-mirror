(define-package "rainbow-fart" "20200718.437" "Checks the keywords of code to play suitable sounds"
  '((emacs "25.1")
    (flycheck "32snapshot"))
  :commit "16759a0aa1b39c43cdedcf6a6c9a5dc3c3895fd2" :keywords
  ("tools")
  :url "https://github.com/stardiviner/emacs-rainbow-fart")
;; Local Variables:
;; no-byte-compile: t
;; End:
