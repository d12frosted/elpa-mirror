(define-package "mu-cite" "20190803.439" "A library to provide MIME features."
  '((flim "1.14.9"))
  :commit "b2c83bbce4646d100b942f0f0de0877a8d47298c" :authors
  '(("MORIOKA Tomohiko" . "tomo@m17n.org")
    ("Shuhei KOBAYASHI" . "shuhei@aqua.ocn.ne.jp"))
  :maintainer
  '("Katsumi Yamaoka" . "yamaoka@jpl.org")
  :keywords
  '("mail" "news" "citation"))
;; Local Variables:
;; no-byte-compile: t
;; End:
