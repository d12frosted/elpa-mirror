(define-package "embark" "20210723.47" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c0a3e5398c3303d9336d3614ff8e2ce543501eaf" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
