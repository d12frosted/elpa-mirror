;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250610.546"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "13e48dcebeb34bdae84d9ac3b3c9ee66ea01d93f"
  :revdesc "13e48dcebeb3"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
