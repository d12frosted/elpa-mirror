(define-package "darkman" "20230521.104" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "ee810af47e002bdb6c02e21082435ed6523e9fad" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainers
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://grtcdr.tn/darkman.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
