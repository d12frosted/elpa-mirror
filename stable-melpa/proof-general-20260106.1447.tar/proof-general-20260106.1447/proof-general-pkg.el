;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20260106.1447"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "6278f976c7fac9f560947601f596db978992bd6f"
  :revdesc "6278f976c7fa"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
