(define-package "dall-e-shell" "20231217.2057" "Interaction mode for DALL-E"
  '((emacs "27.1")
    (shell-maker "0.44.1"))
  :commit "3378e39ebb026c9c041d2a7c1922c782e44588ff" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
