(define-package "consult" "20210722.1450" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "42cb0244059838dedc79e8015c2316aadbab678f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
