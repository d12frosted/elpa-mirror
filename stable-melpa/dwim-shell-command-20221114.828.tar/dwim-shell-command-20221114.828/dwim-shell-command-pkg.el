(define-package "dwim-shell-command" "20221114.828" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "6134c01994acceaa0978eece36de07fec76c2d4b" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
