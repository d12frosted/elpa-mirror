(define-package "format-all" "20230615.1839" "Auto-format C, C++, JS, Python, Ruby and 50 other languages"
  '((emacs "24.4")
    (inheritenv "0.1")
    (language-id "0.19"))
  :commit "2e02fc6d487c9e7eb482f09b5b2bfbd0f9f11d24" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/lassik/emacs-format-all-the-code")
;; Local Variables:
;; no-byte-compile: t
;; End:
