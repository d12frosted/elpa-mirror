(define-package "elpher" "20210725.1516" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "044fbba3752c511f9587ceb80c0acf26f0ab82d7" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
