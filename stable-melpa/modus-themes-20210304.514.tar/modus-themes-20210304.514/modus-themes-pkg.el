(define-package "modus-themes" "20210304.514" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "7ff93b566b92038c9e044a20264ed031556d8a98" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
