;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-purpose" "20211011.1518"
  "Purpose-specific frames."
  '((emacs "25.1")
    (dash  "2.18"))
  :url "https://github.com/alphapapa/frame-purpose.el"
  :commit "7d498147445cc0afb87b922a8225d2e163e5ed5a"
  :revdesc "7d498147445c"
  :keywords '("buffers" "convenience" "frames")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
