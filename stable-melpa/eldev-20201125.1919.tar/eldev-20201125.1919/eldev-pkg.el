(define-package "eldev" "20201125.1919" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "aa4360bcd72ca64913b2bad0056b0521d7e125ab" :keywords
  ("maint" "tools")
  :authors
  (("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  ("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
