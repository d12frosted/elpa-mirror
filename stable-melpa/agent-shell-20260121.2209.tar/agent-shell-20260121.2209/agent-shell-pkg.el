;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260121.2209"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1f393acead00713954888f09ea2e3066899f951d"
  :revdesc "1f393acead00")
