;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nnhackernews" "20230705.1359"
  "Gnus backend for Hacker News."
  '((emacs    "25.2")
    (request  "0.3.3")
    (dash     "2.18.1")
    (anaphora "1.0.4"))
  :url "https://github.com/dickmao/nnhackernews"
  :commit "4c13d261bf660901d5ff63a7ee170097ebe464ed"
  :revdesc "4c13d261bf66"
  :keywords '("news")
  :authors '(("dickmao" . "githubid:dickmao"))
  :maintainers '(("dickmao" . "githubid:dickmao")))
