;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260421.2012"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "de9bbe98c5186ab56cb460c59644bb9da6c6437c"
  :revdesc "de9bbe98c518"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
