(define-package "fanyi" "20210825.2347" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "e3327e1fc146d2f22c1e6d7c7fbfeab44a6658dc" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
