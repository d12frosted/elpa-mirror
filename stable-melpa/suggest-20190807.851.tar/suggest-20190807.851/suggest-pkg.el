(define-package "suggest" "20190807.851" "suggest elisp functions that give the output requested"
  '((emacs "24.4")
    (loop "1.3")
    (dash "2.13.0")
    (s "1.11.0")
    (f "0.18.2")
    (spinner "1.7.3"))
  :commit "7b1c7fd38cd9389e58f672bfe58d9e88aeb898c7" :authors
  '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainer
  '("Wilfred Hughes" . "me@wilfred.me.uk")
  :keywords
  '("convenience")
  :url "https://github.com/Wilfred/suggest.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
