(define-package "cnfonts" "20230410.852" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "bd64758987ee4d6e4f60236e6e59351e1c71b221" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
