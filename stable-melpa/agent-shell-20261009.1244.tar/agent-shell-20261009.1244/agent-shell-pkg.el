;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261009.1244"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.16.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2ab0aba06a4dbf4225efdff47380f40a5d1f8898"
  :revdesc "2ab0aba06a4d")
