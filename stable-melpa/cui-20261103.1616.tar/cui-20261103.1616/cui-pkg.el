;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261103.1616"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "a5ca5fc20769672cd950b7546c2bd801abf11015"
  :revdesc "a5ca5fc20769"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
