(define-package "geiser" "20210419.2256" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "24613fe56960294ea03f1655beb69738384e7726" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
