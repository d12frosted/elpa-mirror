;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bray" "20250918.127"
  "Lightweight modal editing."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-bray"
  :commit "727f4a8b1f439bde3ff8b7f71d8bbbe690cc0c90"
  :revdesc "727f4a8b1f43"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
