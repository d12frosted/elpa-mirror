;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-vterm-interaction" "20250618.1338"
  "A mode for Python REPL using vterm."
  '((emacs  "27.1")
    (vterm  "0.0.2")
    (python "0.28"))
  :url "https://github.com/vale981/py-vterm-interaction.el"
  :commit "e9b4171a3acce9071cc27ee89ad117e4c59b0861"
  :revdesc "e9b4171a3acc"
  :keywords '("languages" "python")
  :maintainers '(("Valentin Boettcher" . "hiroatprotagon.space")))
