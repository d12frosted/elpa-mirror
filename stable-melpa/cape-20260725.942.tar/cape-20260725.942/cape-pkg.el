;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20260725.942"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/cape"
  :commit "6ea501265652d9f022fe8158b46fec69614e116d"
  :revdesc "6ea501265652"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
