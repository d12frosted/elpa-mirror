;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251006.1002"
  "OpenStreetMap viewer."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "1785455dd04d1679364b0e5e7148d3c54805d0b5"
  :revdesc "1785455dd04d"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
