;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260209.1622"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "75e1b5d41e7b18ce1c04ec33a20af2fbed5baa96"
  :revdesc "75e1b5d41e7b"
  :keywords '("outlines"))
