;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20260505.356"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "4c42a6b8bf1a1a443b1a8b4fdc58148aa4412697"
  :revdesc "4c42a6b8bf1a"
  :keywords '("convenience"))
