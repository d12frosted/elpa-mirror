(define-package "rustic" "20220106.2248" "Rust development environment"
  '((emacs "26.1")
    (rust-mode "1.0.3")
    (dash "2.13.0")
    (f "0.18.2")
    (let-alist "1.0.4")
    (markdown-mode "2.3")
    (project "0.3.0")
    (s "1.10.0")
    (seq "2.3")
    (spinner "1.7.3")
    (xterm-color "1.6"))
  :commit "b4faf3c3e6c87766ebb86fb40c4abf41f6a6b3c9" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
