;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260426.1550"
  "Pure Elisp HTTP server."
  '((emacs  "26.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "32bf2aab77f34ea44d536dcacabcb0e9ff68863a"
  :revdesc "32bf2aab77f3"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
