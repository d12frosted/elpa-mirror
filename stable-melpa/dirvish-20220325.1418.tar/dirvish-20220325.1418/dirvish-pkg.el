(define-package "dirvish" "20220325.1418" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "7d26d98df1a7af0266261e0e666a890a86a52bd0" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
