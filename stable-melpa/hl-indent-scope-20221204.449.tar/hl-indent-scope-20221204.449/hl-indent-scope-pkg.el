(define-package "hl-indent-scope" "20221204.449" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "8b1d2cb4dc0e1813a5ecfa9853c8475266fa5b79" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
