;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20260527.552"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "f7071d024e7cfb68be92afbbfd1adc5ed041798f"
  :revdesc "f7071d024e7c"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
