;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-compile" "20261011.1340"
  "Run, evaluate and compile across many languages."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.2.1"))
  :url "https://github.com/plandes/flex-compile"
  :commit "a2a16ca50570727b1b7b9e73142d20e4aabd58a2"
  :revdesc "a2a16ca50570"
  :keywords '("compilation" "integration" "processes"))
