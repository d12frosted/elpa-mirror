;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260305.1817"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "e9d72c449211154f6822bd68e4e127c5a425e858"
  :revdesc "e9d72c449211"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
