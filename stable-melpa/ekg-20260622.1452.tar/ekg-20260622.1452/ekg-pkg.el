;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260622.1452"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "7c943067ac574ed71a5c55ffec5c0a21de5882fb"
  :revdesc "7c943067ac57"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
