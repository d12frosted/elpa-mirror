;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ruff" "20250424.2305"
  "A flymake plugin for python files using ruff."
  '((emacs   "26.1")
    (project "0.3.0"))
  :url "https://github.com/erickgnavar/flymake-ruff"
  :commit "970acdac865d5b6ee8541b82a413f3a107b9332e"
  :revdesc "970acdac865d"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
