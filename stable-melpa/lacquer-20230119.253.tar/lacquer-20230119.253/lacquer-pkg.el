(define-package "lacquer" "20230119.253" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "ebdb531f5b7cb691751e468942e28921a9dcc98f" :authors
  '(("zakudriver" . "zy.hua1122@gmail.com"))
  :maintainer
  '("zakudriver" . "zy.hua1122@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/zakudriver/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
