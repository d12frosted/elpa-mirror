;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260130.2223"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "fd784b3f0ff982b6ba72df12850120a93a130f35"
  :revdesc "fd784b3f0ff9"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
