(define-package "jirascope" "20240120.1823" "A Jira client"
  '((emacs "25.1"))
  :commit "af768d7c34d62cb6218e3bb9da82a50d7af87b7c" :authors
  '(("Stanisław Zagórowski" . "duckonaut@gmail.com"))
  :maintainers
  '(("Stanisław Zagórowski" . "duckonaut@gmail.com"))
  :maintainer
  '("Stanisław Zagórowski" . "duckonaut@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Duckonaut/jirascope")
;; Local Variables:
;; no-byte-compile: t
;; End:
