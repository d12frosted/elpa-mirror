;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-timeline" "20260103.123"
  "Visual timeline for Org-Roam nodes."
  '((emacs        "27.1")
    (org-roam     "2.0")
    (json-mode    "1.0")
    (simple-httpd "1.5.1"))
  :url "https://github.com/GerardoCendejas/org-roam-timeline"
  :commit "8252fb48d482c55c662eaa2e757b035479eb32e7"
  :revdesc "8252fb48d482"
  :keywords '("org" "hypermedia" "visualization" "timeline")
  :authors '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu"))
  :maintainers '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu")))
