(define-package "modus-themes" "20210601.2136" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "f26c6bdf2375ff926191ebc9e4e165da615b2d80" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
