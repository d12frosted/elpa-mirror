(define-package "emms" "20240302.108" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (seq "0"))
  :commit "c98d22f1686bd9a4e433ce98c73a9e95c100d744" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers
  '(("Yoni Rabkin" . "yrk@gnu.org"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
