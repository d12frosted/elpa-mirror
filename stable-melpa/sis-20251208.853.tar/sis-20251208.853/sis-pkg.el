;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "20251208.853"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "515e1dbe0180f33c292660b4b70d02d47153be5b"
  :revdesc "515e1dbe0180"
  :keywords '("convenience"))
