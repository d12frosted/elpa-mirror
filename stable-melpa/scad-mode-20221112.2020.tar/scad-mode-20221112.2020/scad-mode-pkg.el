(define-package "scad-mode" "20221112.2020" "A major mode for editing OpenSCAD code"
  '((emacs "27.1"))
  :commit "7c8aed90c03ef384ee9e8729bc5bfa39973e91ec" :authors
  '(("Len Trigg, Łukasz Stelmach, zk_phi, Daniel Mendler"))
  :maintainer
  '("Len Trigg <lenbok@gmail.com>, Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("languages")
  :url "https://github.com/openscad/emacs-scad-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
