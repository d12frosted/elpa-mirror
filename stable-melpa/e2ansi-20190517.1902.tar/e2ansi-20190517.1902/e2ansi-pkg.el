(define-package "e2ansi" "20190517.1902" "Syntax highlighting support for `less', powered by Emacs."
  '((face-explorer "0.0.4"))
  :commit "6e1bb4e4e27885d1786db08b091cfa13b184fb54" :keywords
  ("faces" "languages")
  :authors
  (("Anders Lindgren"))
  :maintainer
  ("Anders Lindgren")
  :url "https://github.com/Lindydancer/e2ansi")
;; Local Variables:
;; no-byte-compile: t
;; End:
