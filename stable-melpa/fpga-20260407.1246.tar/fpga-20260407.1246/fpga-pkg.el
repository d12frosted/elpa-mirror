;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fpga" "20260407.1246"
  "FPGA & ASIC Utils."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/fpga"
  :commit "6b22e9e034411a03e574b00377ce0bcf5dafb1d3"
  :revdesc "6b22e9e03441"
  :keywords '("tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
