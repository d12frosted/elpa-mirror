(define-package "kmacro-x" "20230310.1138" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "b1a6206556d8f9d4a7522d5218094b7325ff8507" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
