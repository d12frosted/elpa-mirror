;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "call-graph" "20260713.638"
  "Generate call graph for c/c++ functions."
  '((emacs     "28.1")
    (tree-mode "1.0.0")
    (ivy       "0.10.0")
    (beacon    "1.3.4"))
  :url "https://github.com/beacoder/call-graph"
  :commit "99cab0f3829632f39f0e76f4e992c7bd988203a7"
  :revdesc "99cab0f38296"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
