(define-package "flycheck" "20240205.738" "On-the-fly syntax checking"
  '((emacs "26")
    (dash "2.12.1")
    (pkg-info "0.4")
    (seq "1.11"))
  :commit "0ea5090952c2ff9fe11d78e87a6e2e6b50ed3ee3" :authors
  '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "http://www.flycheck.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
