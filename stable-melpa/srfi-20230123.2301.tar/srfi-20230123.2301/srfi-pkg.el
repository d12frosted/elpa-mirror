(define-package "srfi" "20230123.2301" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "204cdac0ad51a50d96bbe1a19ed2341b3b543943" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
