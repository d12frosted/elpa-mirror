(define-package "monky" "20190619.1637" "Control Hg from Emacs." 'nil :commit "9d379a2306a8b7cd9c4faba20490480acdc1d763" :keywords
  ("tools")
  :authors
  (("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainer
  ("Anantha kumaran" . "ananthakumaran@gmail.com")
  :url "http://github.com/ananthakumaran/monky")
;; Local Variables:
;; no-byte-compile: t
;; End:
