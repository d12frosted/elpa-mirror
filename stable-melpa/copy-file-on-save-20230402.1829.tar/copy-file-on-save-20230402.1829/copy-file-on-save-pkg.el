;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copy-file-on-save" "20230402.1829"
  "Copy file on save, automatic deployment it."
  '((emacs  "24.3")
    (compat "29"))
  :url "https://github.com/emacs-php/emacs-auto-deployment"
  :commit "370b1586feb2690d3c72185bd4f17c31ce03673a"
  :revdesc "370b1586feb2"
  :keywords '("files" "comm" "deploy")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
