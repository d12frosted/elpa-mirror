;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-wild-notifier" "20260126.525"
  "Customizable org-agenda notifications."
  '((alert "1.2")
    (async "1.9.3")
    (dash  "2.18.0")
    (emacs "27.1"))
  :url "https://github.com/emacsorphanage/org-wild-notifier.el"
  :commit "4794a5345f50aa2538724508a65e59d82b0f4ad7"
  :revdesc "4794a5345f50"
  :keywords '("calendar" "convenience")
  :authors '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainers '(("Artem Khramov" . "akhramov+emacs@pm.me")))
