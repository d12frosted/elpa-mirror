;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260404.553"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "621d0548f50086b9868db970c52d5c43c35c710b"
  :revdesc "621d0548f500"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
