;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskjuggler-mode" "20260410.1407"
  "Major mode for TaskJuggler project files."
  '((emacs "27.1"))
  :url "https://github.com/devrintalen/taskjuggler-mode.el"
  :commit "baee1fdacfdbd4ea21557385a2ce71a85be307e9"
  :revdesc "baee1fdacfdb"
  :keywords '("languages" "project-management")
  :authors '(("Devrin Talen" . "devrin@fastmail.com"))
  :maintainers '(("Devrin Talen" . "devrin@fastmail.com")))
