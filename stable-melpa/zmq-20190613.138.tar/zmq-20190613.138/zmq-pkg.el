(define-package "zmq" "20190613.138" "ZMQ bindings in elisp"
  '((cl-lib "0.5")
    (emacs "26"))
  :commit "6120251d86bc85138305c1bf02b1000dc435fdb5" :authors
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainer
  '("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")
  :keywords
  '("comm")
  :url "https://github.com/dzop/emacs-zmq")
;; Local Variables:
;; no-byte-compile: t
;; End:
