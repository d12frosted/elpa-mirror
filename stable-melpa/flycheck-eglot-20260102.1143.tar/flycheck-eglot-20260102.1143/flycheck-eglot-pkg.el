;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-eglot" "20260102.1143"
  "Flycheck support for eglot."
  '((emacs    "28.1")
    (eglot    "1.9")
    (flycheck "32"))
  :url "https://github.com/flycheck/flycheck-eglot"
  :commit "f617b68699f00e7fe271bbf6daaddde7e3b2fdb2"
  :revdesc "f617b68699f0"
  :keywords '("convenience" "language" "tools")
  :authors '(("Sergey Firsov" . "intramurz@gmail.com"))
  :maintainers '(("Sergey Firsov" . "intramurz@gmail.com")))
