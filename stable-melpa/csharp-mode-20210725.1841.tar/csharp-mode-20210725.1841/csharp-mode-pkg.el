(define-package "csharp-mode" "20210725.1841" "C# mode derived mode"
  '((emacs "26.1"))
  :commit "264159954098703b2eba1874dcccb7c9f4a04e3e" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
