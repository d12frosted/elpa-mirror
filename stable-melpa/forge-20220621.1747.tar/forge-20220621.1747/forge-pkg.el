(define-package "forge" "20220621.1747" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (closql "1.2.0")
    (dash "2.19.1")
    (emacsql-sqlite "3.0.0")
    (ghub "20220631")
    (let-alist "1.0.6")
    (magit "20220631")
    (markdown-mode "2.4")
    (transient "0.3.6")
    (yaml "0.3.5"))
  :commit "3b594ab03fbc201239ac3141c19828e69639da0b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
