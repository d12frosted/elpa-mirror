(define-package "websearch" "20230101.1905" "Query search engines"
  '((emacs "24.4"))
  :commit "42272b29022cb2fc669ee4487b307dd16eb14e73" :authors
  '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainer
  '("Maciej Barć" . "xgqt@riseup.net")
  :keywords
  '("convenience" "hypermedia")
  :url "https://gitlab.com/xgqt/emacs-websearch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
