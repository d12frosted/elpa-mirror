(define-package "git-cliff" "20231101.1256" "Generate and update changelog using git-cliff"
  '((emacs "27.1")
    (transient "0.4.3"))
  :commit "b6a8c67c8f7468554401f1c6fe0d000d3987c13b" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/liuyinz/git-cliff.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
