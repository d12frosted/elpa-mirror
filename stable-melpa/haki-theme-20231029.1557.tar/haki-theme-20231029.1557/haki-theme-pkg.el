(define-package "haki-theme" "20231029.1557" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "7e38bf06e217c5ad38a87751a281d7105ac67579" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
