(define-package "docker" "20220301.2133" "Interface to Docker"
  '((aio "1.0")
    (dash "2.19.1")
    (docker-tramp "0.1")
    (emacs "26.1")
    (json-mode "1.8.0")
    (s "1.12.0")
    (tablist "1.0")
    (transient "0.3.7"))
  :commit "4989092b1d6938256f8dbd66e0a4d62870746c0b" :authors
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainer
  '("Philippe Vaucher" . "philippe.vaucher@gmail.com")
  :keywords
  '("filename" "convenience")
  :url "https://github.com/Silex/docker.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
