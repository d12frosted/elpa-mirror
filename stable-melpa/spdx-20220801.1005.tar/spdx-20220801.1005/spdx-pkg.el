(define-package "spdx" "20220801.1005" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "1ee38158c736bb5f1a97b493a29147e5b5fe50e2" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
