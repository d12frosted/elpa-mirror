;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260113.538"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "106659ee34b25f914e016205a67741a61193b2fe"
  :revdesc "106659ee34b2"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
