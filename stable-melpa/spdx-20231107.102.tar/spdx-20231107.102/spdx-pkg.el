(define-package "spdx" "20231107.102" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "5c0c082b34acdc8886c0bfb9f1dc66838efec479" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
