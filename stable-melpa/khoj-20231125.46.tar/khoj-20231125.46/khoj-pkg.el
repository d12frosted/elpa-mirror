(define-package "khoj" "20231125.46" "AI copilot for your Second Brain"
  '((emacs "27.1")
    (transient "0.3.0")
    (dash "2.19.1"))
  :commit "25f3f2367e6a7082bd12450aa8cd4a952c5aa959" :authors
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
    ("Saba Imran" . "saba@khoj.dev"))
  :maintainers
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev"))
  :maintainer
  '("Debanjum Singh Solanky" . "debanjum@khoj.dev")
  :keywords
  '("search" "chat" "org-mode" "outlines" "markdown" "pdf" "image")
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
