(define-package "sage-shell-mode" "20230617.642" "A front-end for Sage Math"
  '((cl-lib "0.6.1")
    (emacs "24.4")
    (let-alist "1.0.5")
    (deferred "0.5.1"))
  :commit "eead58da080cd0146cb8d3afda7142860744666f" :authors
  '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers
  '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainer
  '("Sho Takemori" . "stakemorii@gmail.com")
  :keywords
  '("sage" "math")
  :url "https://github.com/sagemath/sage-shell-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
