(define-package "rustic" "20221224.1537" "Rust development environment"
  '((emacs "26.1")
    (rust-mode "1.0.3")
    (dash "2.13.0")
    (f "0.18.2")
    (let-alist "1.0.4")
    (markdown-mode "2.3")
    (project "0.3.0")
    (s "1.10.0")
    (seq "2.3")
    (spinner "1.7.3")
    (xterm-color "1.6"))
  :commit "f4efdd84b5de96194f294f0ee5689e9538eb11ea" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
