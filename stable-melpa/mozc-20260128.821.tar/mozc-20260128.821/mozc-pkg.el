;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc" "20260128.821"
  "Minor mode to input Japanese with Mozc."
  '((emacs "24.3"))
  :url "https://github.com/google/mozc"
  :commit "8f92cd985cba2fd009545963698f4df7424bec56"
  :revdesc "8f92cd985cba"
  :keywords '("mule" "multilingual" "input method"))
