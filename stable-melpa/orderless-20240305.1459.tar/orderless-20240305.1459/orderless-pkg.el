(define-package "orderless" "20240305.1459" "Completion style for matching regexps in any order"
  '((emacs "27.1"))
  :commit "19d873b5eff42ed66f5f3c7b9b807b4dd29df757" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("extensions")
  :url "https://github.com/oantolin/orderless")
;; Local Variables:
;; no-byte-compile: t
;; End:
