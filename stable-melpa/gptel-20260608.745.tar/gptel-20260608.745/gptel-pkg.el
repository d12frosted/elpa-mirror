;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260608.745"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "edbaf72485956c862dc9f4e480a392030cf7611d"
  :revdesc "edbaf7248595"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
