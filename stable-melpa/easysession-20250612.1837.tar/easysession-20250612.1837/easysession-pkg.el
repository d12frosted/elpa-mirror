;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20250612.1837"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "c1bcc2836d15378c1858c4c85d5f96a866f80660"
  :revdesc "c1bcc2836d15"
  :keywords '("convenience"))
