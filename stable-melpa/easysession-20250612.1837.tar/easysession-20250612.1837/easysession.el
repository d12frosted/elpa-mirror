;;; easysession.el --- Persist and restore your sessions (desktop.el alternative) -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2025 James Cherti | https://www.jamescherti.com/contact/

;; Author: James Cherti
;; Package-Version: 20250612.1837
;; Package-Revision: c1bcc2836d15
;; URL: https://github.com/jamescherti/easysession.el
;; Keywords: convenience
;; Package-Requires: ((emacs "25.1"))
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This file is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 2, or (at your option)
;; any later version.

;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;; The easysession Emacs package is a session manager for Emacs that can persist
;; and restore file editing buffers, indirect buffers (clones), Dired buffers,
;; the tab-bar, and Emacs frames (including or excluding the geometry: frame
;; size, width, and height). It offers a convenient and effortless way to manage
;; Emacs editing sessions and utilizes built-in Emacs functions to persist and
;; restore frames.
;;
;; With Easysession.el, you can effortlessly switch between sessions,
;; ensuring a consistent and uninterrupted editing experience.
;;
;; Key features include:
;; - Minimalist design focused on performance and simplicity, avoiding
;;   unnecessary complexity.
;; - Quickly switch between sessions while editing without disrupting the frame
;;   geometry, enabling you to resume work immediately.
;; - Save and load file editing buffers, indirect buffers/clones, Dired buffers,
;;   windows/splits, the Emacs frame (including support for the tab-bar).
;; - Helper functions: Switch to a session (i.e., load and change the current
;;   session) with `easysession-switch-to', load the Emacs editing session with
;;   `easysession-load', save the Emacs editing session with `easysession-save'
;;   and `easysession-save-as', delete the current Emacs session with
;;   `easysession-delete', and rename the current Emacs session with
;;   `easysession-rename'.
;;
;; Installation from MELPA:
;; ------------------------
;; (use-package easysession
;;   :ensure t
;;   :custom
;;   ;; Interval between automatic session saves
;;   (easysession-save-interval (* 10 60))
;;   ;; Make the current session name appear in the mode-line
;;   (easysession-mode-line-misc-info t)
;;   :init
;;   (add-hook 'emacs-startup-hook #'easysession-load-including-geometry 102)
;;   (add-hook 'emacs-startup-hook #'easysession-save-mode 103))
;;
;; Usage:
;; ------
;; It is recommended to use the following functions:
;; - (easysession-switch-to) to switch to another session or (easysession-load)
;;   to reload the current one,
;; - (easysession-save-as) to save the current session as the current name or
;;   another name.
;;
;; To facilitate session management, consider using the following key mappings:
;; C-c l for switching sessions with easysession-switch-to, and C-c s for
;; saving the current session with easysession-save-as:
;;   (global-set-key (kbd "C-c l") 'easysession-switch-to)
;;   (global-set-key (kbd "C-c s") 'easysession-save-as)
;;
;; Links:
;; ------
;; - More information about easysession (Frequently asked questions, usage...):
;;   https://github.com/jamescherti/easysession.el

;;; Code:

(require 'frameset)

;;; Variables

(defgroup easysession nil
  "Persist and restore your sessions."
  :group 'easysession
  :prefix "easysession-")

(defcustom easysession-directory (expand-file-name "easysession"
                                                   user-emacs-directory)
  "Directory where the session files are stored."
  :type 'directory
  :group 'easysession)

(defcustom easysession-before-load-hook nil
  "Hooks to run before the session is loaded.
Each element should be a function to be called with no arguments."
  :type 'hook
  :group 'easysession)

(defcustom easysession-after-load-hook nil
  "Hooks to run after the session is loaded.
Each element should be a function to be called with no arguments."
  :type 'hook
  :group 'easysession)

(defcustom easysession-before-save-hook nil
  "Hooks to run before the session is saved.
Each element should be a function to be called with no arguments."
  :type 'hook
  :group 'easysession)

(defcustom easysession-after-save-hook nil
  "Hooks to run after the session is saved.
Each element should be a function to be called with no arguments."
  :type 'hook
  :group 'easysession)

(defcustom easysession-new-session-hook nil
  "Hooks to run after a new session is created.
Each element should be a function to be called with no arguments.

This can be used to customize behavior, such as emptying a session
after a new one is created."
  :type 'hook
  :group 'easysession)

(defcustom easysession-quiet nil
  "If non-nil, suppress all messages and only show errors and warnings.
This includes messages such as `Session deleted:`, `Session loaded:`, `Session
saved:`, etc."
  :type 'boolean
  :group 'easysession)

(defcustom easysession-save-interval nil
  "The interval between automatic session saves.
If set to nil, it disables timer-based autosaving. Automatic session saves are
activated when `easysession-save-mode' is enabled."
  :type '(choice (const :tag "Disabled" nil)
                 (integer :tag "Seconds"))
  :group 'easysession)

;; Mode line
(defface easysession-mode-line-session-name-face
  '((t :inherit font-lock-constant-face :weight bold))
  "Face used in the mode-line to indicate the current session.")

(defcustom easysession-mode-line-misc-info-format
  '(" [EasySession:"
    easysession-mode-line-session-name "] ")
  "Mode-line format used to display the session name."
  :type 'sexp
  :group 'easysession
  :set (lambda (symbol value)
         (set symbol value)
         (setq mode-line-misc-info
               (assq-delete-all 'easysession-mode-line-misc-info
                                mode-line-misc-info))
         (add-to-list 'mode-line-misc-info `(easysession-mode-line-misc-info
                                             ,value))))
(put 'easysession-mode-line-misc-info-format 'risky-local-variable t)

(defcustom easysession-mode-line-misc-info nil
  "If non-nil, add `easysession` to `mode-line-misc-info'. If nil, remove it."
  :type 'boolean
  :group 'easysession
  :set (lambda (symbol value)
         (set symbol value)
         (setq mode-line-misc-info
               (assq-delete-all
                'easysession-mode-line-misc-info mode-line-misc-info))
         (add-to-list 'mode-line-misc-info
                      `(easysession-mode-line-misc-info
                        easysession-mode-line-misc-info-format))))

(defcustom easysession-switch-to-exclude-current nil
  "Non-nil to exclude the current session when switching sessions.

This can be useful to prevent accidental re-selection of the session already in
use, especially when cycling through or interactively selecting among available
sessions."
  :type 'boolean
  :group 'easysession)

;; Lighter
(defvar easysession-save-mode-lighter " EasySeSave"
  "Default lighter string for `easysession-save-mode'.")

(defvar easysession-save-mode-lighter-show-session-name nil
  "If non-nil, display the session name in the lighter.")

(defvar easysession-save-mode-lighter-session-name-spec
  `((:eval (format "%s[" easysession-save-mode-lighter))
    (:propertize (:eval easysession--current-session-name)
                 face easysession-mode-line-session-name-face)
    "]")
  "Lighter spec for showing the current session.")
(put 'easysession-save-mode-lighter-session-name-spec 'risky-local-variable t)

;; Other
(defcustom easysession-buffer-list-function #'buffer-list
  "Function used to retrieve the buffers for persistence and restoration.
This holds a function that returns a list of buffers to be saved and restored
during session management. By default, it is set to `buffer-list', which
includes all buffers. You can customize this variable to use a different
function, such as one that filters buffers based on visibility or other
criteria."
  :type 'function
  :group 'easysession)

(defun easysession--default-auto-save-predicate ()
  "Default predicate function for `easysession-save-predicate`.
This function always returns non-nil, ensuring the session is saved."
  t)

(defcustom easysession-save-mode-predicate
  #'easysession--default-auto-save-predicate
  "Predicate that determines if the session is saved automatically.
This function is called with no arguments and should return non-nil if
`easysession-save-mode' should save the session automatically. The default
predicate always returns non-nil, ensuring all sessions are saved
automatically."
  :type 'function
  :group 'easysession)

(define-obsolete-variable-alias
  'easysession-restore-frames
  'easysession-enable-frameset-restore
  "1.1.2"
  "Use `easysession-enable-frameset-restore' instead.")

(defcustom easysession-enable-frameset-restore t
  "Non-nil to restore frames.

When non-nil, frames will be restored alongside buffers when a session is
loaded.

If set to nil, only the buffers will be restored, and frame restoration will be
skipped.

See related options:
- `easysession-frameset-restore-reuse-frames'
- `easysession-frameset-restore-force-display'
- `easysession-frameset-restore-force-onscreen'
- `easysession-frameset-restore-cleanup-frames'"
  :type 'boolean
  :group 'easysession)

(defcustom easysession-frameset-restore-reuse-frames t
  "Specifies the policy for reusing frames when restoring:
t        All existing frames can be reused.
nil      No existing frames can be reused.
match    Only frames with matching frame IDs can be reused.
PRED     A predicate function that receives a live frame as an argument
         and returns non-nil to allow reusing it, or nil otherwise.

For more details, see the `frameset-restore' docstring."
  :type '(choice (const :tag "Reuse all frames" t)
                 (const :tag "Reuse no frames" nil)
                 (const :tag "Reuse frames with matching IDs" match)
                 (function :tag "Predicate function"))
  :group 'easysession)

(defcustom easysession-frameset-restore-force-display t
  "Specifies how frames are restored with respect to display:
t        Frames are restored on the current display.
nil      Frames are restored, if possible, on their original displays.
delete   Frames in other displays are deleted instead of being restored.
PRED     A function called with two arguments: the parameter alist and
         the window state (in that order). It must return t, nil, or
         delete, as described above, but affecting only the frame
         created from that parameter alist.

For more details, see the `frameset-restore' docstring."
  :type '(choice (const :tag "Restore on current display" t)
                 (const :tag "Restore on original displays" nil)
                 (const :tag "Delete frames in other displays" delete)
                 (function :tag "Function to determine frame restoration"))
  :group 'easysession)

(defcustom easysession-frameset-restore-force-onscreen (display-graphic-p)
  "Specifies how frames are handled when they are offscreen:
t        Only frames that are completely offscreen are forced onscreen.
nil      No frames are forced back onscreen.
all      Any frame that is fully or partially offscreen is forced onscreen.
PRED     A function called with three arguments:
         - The live frame just restored.
         - A list (LEFT TOP WIDTH HEIGHT) describing the frame.
         - A list (LEFT TOP WIDTH HEIGHT) describing the work area.
         It must return non-nil to force the frame onscreen, or nil otherwise.

For more details, see the `frameset-restore' docstring."
  :type '(choice
          (const :tag "Force onscreen only fully offscreen frames" t)
          (const :tag "Do not force any frames onscreen" nil)
          (const
           :tag "Force onscreen any frame fully or partially offscreen" all)
          (function :tag "Function to determine onscreen status"))
  :group 'easysession)

(defcustom easysession-frameset-restore-cleanup-frames t
  "Specifies the policy for cleaning up the frame list after restoring.
t        Delete all frames that were not created or restored.
nil      Retain all frames.
FUNC     A function called with two arguments:
         - FRAME, a live frame.
         - ACTION, which can be one of:
           :rejected  Frame existed but was not a candidate for reuse.
           :ignored   Frame existed, was a candidate, but was not reused.
           :reused    Frame existed, was a candidate, and was reused.
           :created   Frame did not exist, was created and restored upon.
         The return value is ignored.

For more details, see the `frameset-restore' docstring."
  :type '(choice (const :tag "Delete all unneeded frames" t)
                 (const :tag "Retain all frames" nil)
                 (function :tag "Function to determine cleanup actions"))
  :group 'easysession)

(defvar easysession-frameset-restore-geometry nil
  "If non-nil, `easysession-load' restores frame position and size.

Do not modify this variable directly; use `easysession-load-including-geometry'
instead.

Set this variable to t only if you want `easysession-load' or
`easysession-switch-to' to always restore frame geometry.

By default, this variable is nil, meaning `easysession-load' does not restore
geometry.")

(defcustom easysession-exclude-from-find-file-hook '(recentf-track-opened-file)
  "List of hooks to be excluded from `find-file-hook'.

When EasySession restores a file editing buffer using `find-file-noselect', the
functions in this list are skipped and not executed by `find-file-hook'. This
provides control over which hooks should be bypassed during the file restoration
process, ensuring that certain actions (e.g., tracking opened files) are not
triggered in this context."
  :type '(repeat symbol)
  :group 'easysession)

;;; Internal variables

(defvar easysession--debug nil)

(defvar easysession--timer nil)

;; Overrides `frameset-filter-alist' while preserving its keys,
;; but replaces their values with the ones specified in the following alist:
(defvar easysession--overwrite-frameset-filter-alist
  '((GUI:bottom . :never)
    (GUI:font . :never)
    (GUI:fullscreen . :never)
    (GUI:height . :never)
    (GUI:left . :never)
    (GUI:right . :never)
    (GUI:top . :never)
    (GUI:width . :never)
    (alpha . :never)
    (alpha-background . :never)
    (auto-lower . :never)
    (auto-raise . :never)
    (background-color . :never)
    (background-mode . :never)
    (border-color . :never)
    (border-width . :never)
    (bottom . :never)
    (bottom-divider-width . :never)
    (buffer-list . :never)
    (buffer-predicate . :never)
    (buried-buffer-list . :never)
    (child-frame-border-width . :never)
    (client . :never)
    (cursor-color . :never)
    (cursor-type . :never)
    (delete-before . :never)
    (display-type . :never)
    (environment . :never)
    (font . :never)
    (font-backend . :never)
    (font-parameter . :never)
    (foreground-color . :never)
    (frameset--text-pixel-height . :never)
    (frameset--text-pixel-width . :never)
    (fullscreen . :never)
    (height . :never)
    (horizontal-scroll-bars . :never)
    (icon-type . :never)
    (inhibit-double-buffering . :never)
    (internal-border-width . :never)
    (left . :never)
    (left-fringe . :never)
    (line-spacing . :never)
    (menu-bar-lines . :never)
    (minibuffer . :never)
    (mouse-color . :never)
    (mouse-wheel-frame . :never)
    (name . :never)
    (no-accept-focus . :never)
    (no-focus-on-map . :never)
    (no-special-glyphs . :never)
    (ns-appearance . :never)
    (outer-window-id . :never)
    (override-redirect . :never)
    (parent-frame . :never)
    (parent-id . :never)
    (right . :never)
    (right-divider-width . :never)
    (right-fringe . :never)
    (screen-gamma . :never)
    (scroll-bar-background . :never)
    (scroll-bar-foreground . :never)
    (scroll-bar-height . :never)
    (scroll-bar-width . :never)
    (shaded . :never)
    (skip-taskbar . :never)
    (sticky . :never)
    (tab-bar-lines . :never)
    (title . :never)
    (tool-bar-lines . :never)
    (tool-bar-position . :never)
    (top . :never)
    (tty . :never)
    (tty-type . :never)
    (undecorated . :never)
    (use-frame-synchronization . :never)
    (vertical-scroll-bars . :never)
    ;; (visibility . :never) ; Commenting this fixes: #24
    (wait-for-wm . :never)
    (width . :never)
    (window-id . :never)
    (window-system . :never)
    (lsp-ui-doc-buffer . :never)  ; Third party package (Fixes #22)
    (dv-preview-last . :never)  ; Third party package (Fixes #32)
    (z-group . :never))
  "Alist of frame parameters and filtering functions.")

(defun easysession--filter-out-frameset-filters (list-keys)
  "Remove geometry.
LIST-KEYS is the list of keys (e.g., GUI:left, bottom, height...)
from `easysession--overwrite-frameset-filter-alist`."
  (seq-remove (lambda (entry)
                (memq (car entry) list-keys))
              easysession--overwrite-frameset-filter-alist))

(defvar easysession--overwrite-frameset-filter-include-geometry-alist
  (easysession--filter-out-frameset-filters '(GUI:bottom
                                              GUI:fullscreen
                                              GUI:height
                                              GUI:left
                                              GUI:right
                                              GUI:top
                                              GUI:width
                                              bottom
                                              frameset--text-pixel-height
                                              frameset--text-pixel-width
                                              fullscreen
                                              height
                                              left
                                              right
                                              top
                                              visibility
                                              width))
  "Alist of frame parameters and filtering functions.")

(defvar easysession-file-version 3
  "Version number of easysession file format.")

(defvar easysession--current-session-name "main"
  "Current session.")

(defvar easysession--load-error nil
  "Non-nil indicates whether loading the current session has failed.

This variable is non-nil if an error occurred while attempting to load
the current session, otherwise it remains nil.")

(defvar easysession-mode-line-session-name
  '(:eval (easysession--mode-line-session-name-format))
  "Mode line specification for displaying the current session name.
The value is evaluated to generate a formatted string that shows the current
session name in the mode line.")
(put 'easysession-mode-line-session-name 'risky-local-variable t)

(defvar easysession--load-handlers '()
  "A list of functions used to load session data.
Each function in this list is responsible for loading a specific type of
buffer (e.g., file editing buffers, indirect buffers) from the session
information. These functions are applied sequentially to restore the session
state based on the saved session data.")

(defvar easysession--save-handlers '()
  "A list of functions used to save session data.
Each function in this list is responsible for saving a specific type of
buffer (e.g., file editing buffers, indirect buffers) from the current
session. These functions are applied sequentially to capture the state of
the session, which can later be restored by the corresponding load handlers.")

(defvar easysession--builtin-load-handlers
  '(easysession--handler-load-file-editing-buffers
    easysession--handler-load-indirect-buffers)
  "Internal variable.")

(defvar easysession--builtin-save-handlers
  '(easysession--handler-save-file-editing-buffers
    easysession--handler-save-indirect-buffers)
  "Internal variable.")

(defvar easysession-load-in-progress nil
  "Session name (string) if a session is currently being loaded.
This is an internal variable that is meant to be read-only. Do not modify it.
This variable is used to indicate whether a session loading process is in
progress.")

;;; Internal functions

(defun easysession--message (&rest args)
  "Display a message with '[easysession]' prepended.
The message is formatted with the provided arguments ARGS."
  (unless easysession-quiet
    (apply #'message (concat "[easysession] " (car args)) (cdr args))))

(defun easysession--warning (&rest args)
  "Display a warning message with '[easysession] Warning: ' prepended.
The message is formatted with the provided arguments ARGS."
  (apply #'message (concat "[easysession] Warning: " (car args)) (cdr args)))

(defun easysession--ensure-session-name-valid (session-name)
  "Validate the provided SESSION-NAME.

If the SESSION-NAME is invalid, an error is raised with a message indicating
the invalid name.

Return the SESSION-NAME if it is valid.

Errors:
Raise an error if the session name is invalid."
  (when (or (not session-name)
            (string= session-name "")
            (let ((case-fold-search nil))
              (or (string-match-p "\\\\" session-name)
                  (string-match-p "/" session-name)))
            (string= session-name "..")
            (string= session-name "."))
    (error "[easysession] Invalid session name: %s" session-name))
  session-name)

(defun easysession--set-current-session (&optional session-name)
  "Set the current session to SESSION-NAME.
Return t if the session name is successfully set."
  (easysession--ensure-session-name-valid session-name)
  (setq easysession--current-session-name session-name)
  t)

(defun easysession--init-frame-parameters-filters (overwrite-alist)
  "Return the EasySession version of `frameset-filter-alist'.
OVERWRITE-ALIST is an alist similar to
`easysession--overwrite-frameset-filter-alist'."
  (let ((result (copy-tree frameset-filter-alist)))
    (dolist (pair overwrite-alist)
      (setf (alist-get (car pair) result)
            (cdr pair)))
    result))

(defun easysession--get-all-names (&optional exclude-current)
  "Return a list of all session names.
If EXCLUDE-CURRENT is non-nil, exclude the current session name from the list."
  (if (file-directory-p easysession-directory)
      (seq-filter (lambda (session-name)
                    (not (or (string-equal session-name ".")
                             (string-equal session-name "..")
                             (and exclude-current
                                  (string-equal session-name
                                                (easysession-get-session-name))))))
                  (directory-files easysession-directory nil nil t))
    '()))

(defun easysession--prompt-session-name (prompt &optional session-name
                                                exclude-current initial-input)
  "Prompt for a session name with PROMPT.
Use SESSION-NAME as the default value.
If EXCLUDE-CURRENT is non-nil, exclude the current session from
If INITIAL-INPUT is non-nil, insert it in the minibuffer initially.
completion candidates."
  (completing-read (concat "[easysession] " prompt)
                   (easysession--get-all-names exclude-current)
                   nil nil initial-input nil session-name))

(defun easysession--get-base-buffer-info (buffer)
  "Get the name and path of the buffer BUFFER.
Return nil When the buffer is not a base buffer.
Return a cons cell (buffer-name . path)."
  (when (and buffer (buffer-live-p buffer))
    (with-current-buffer buffer
      (let* ((path (cond ((derived-mode-p 'dired-mode)
                          default-directory)
                         (t (buffer-file-name)))))
        (if path
            ;; File visiting buffer and base buffers (not carbon copies)
            (cons (buffer-name) path)
          ;; This buffer is not visiting a file or it is a carbon copy
          nil)))))

(defun easysession--get-indirect-buffer-info (indirect-buffer)
  "Get information about the indirect buffer INDIRECT-BUFFER.

This function retrieves details about the indirect buffer BUF and its base
buffer. It returns a list of cons cells containing the names of both buffers,
the point position, window start position, and horizontal scroll position of
the base buffer.

- BUF: The buffer to get information from.

Return:
A list of cons cells: ((indirect-buffer-name . name-of-indirect-buffer)
                       (base-buffer-name . name-of-base-buffer)
                       (base-buffer-point . point-position)
                       (base-buffer-window-start . window-start-position)
                       (base-buffer-hscroll . horizontal-scroll-position))

Return nil if BUF is not an indirect buffer or if the base buffer cannot be
determined."
  (when (and indirect-buffer (buffer-live-p indirect-buffer))
    (let* ((base-buffer (buffer-base-buffer indirect-buffer)))
      (when (and base-buffer
                 (buffer-live-p base-buffer)
                 (not (eq base-buffer indirect-buffer))
                 ;; The base has to be a file visiting buffer
                 (or (buffer-file-name base-buffer)
                     (derived-mode-p 'dired-mode)))
        (with-current-buffer indirect-buffer  ; indirect buffer
          (let ((base-buffer-name (buffer-name base-buffer))
                (indirect-buffer-name (buffer-name)))
            (when (and base-buffer-name indirect-buffer-name)
              `((indirect-buffer-name . ,indirect-buffer-name)
                (base-buffer-name . ,base-buffer-name)))))))))

(defun easysession-get-session-name ()
  "Return the name of the current session."
  easysession--current-session-name)

(defalias 'easysession-get-current-session-name
  'easysession-get-session-name
  "Renamed to `easysession-get-session-name'.")

(make-obsolete 'easysession-get-current-session-name
               'easysession-get-session-name
               "1.1.3")

(defun easysession-get-session-file-path (&optional session-name)
  "Return the absolute path to the session file for SESSION-NAME.
If SESSION-NAME is nil, use the currently loaded session.
Return nil if no session is loaded."
  (unless session-name
    (setq session-name (easysession-get-session-name)))
  (when session-name
    (easysession--ensure-session-name-valid session-name)
    (expand-file-name session-name easysession-directory)))

(defun easysession--save-frameset (session-name
                                   &optional save-geometry)
  "Return a frameset for FRAME-LIST, a list of frames.
SESSION-NAME is the session name.
When SAVE-GEOMETRY is non-nil, include the frame geometry.
Return nil if there is no frame to save."
  (let ((modified-filter-alist
         (if save-geometry
             ;; Include geometry
             (easysession--init-frame-parameters-filters
              easysession--overwrite-frameset-filter-include-geometry-alist)
           ;; Exclude geometry
           (easysession--init-frame-parameters-filters
            easysession--overwrite-frameset-filter-alist))))
    ;; Auto save when there is at least one frame
    (when (frame-list)
      (frameset-save nil
                     :app `(easysession . ,easysession-file-version)
                     :name session-name
                     :predicate #'easysession--check-dont-save
                     :filters modified-filter-alist))))

(defun easysession--can-restore-frameset-p ()
  "True if calling `easysession--load-frameset' will actually restore it."
  (and easysession-enable-frameset-restore
       ;; Skip restoring frames when the current frame is the daemon's initial
       ;; frame.
       (not (and (daemonp)
                 (not (frame-parameter nil 'client))))
       t))

(defun easysession--load-frameset (session-data &optional load-geometry)
  "Load the frameset from the SESSION-DATA argument.
When LOAD-GEOMETRY is non-nil, load the frame geometry."
  (when (and easysession-enable-frameset-restore
             (easysession--can-restore-frameset-p))
    (let* ((key (if load-geometry
                    "frameset-geo"
                  "frameset"))
           (data (when (assoc key session-data)
                   (assoc-default key session-data))))
      (when (and (not data) load-geometry)
        (setq data (when (assoc "frameset" session-data)
                     (assoc-default "frameset" session-data))))
      (when data
        (unless (ignore-errors
                  (frameset-restore
                   data
                   :reuse-frames easysession-frameset-restore-reuse-frames
                   :cleanup-frames easysession-frameset-restore-cleanup-frames
                   :force-display easysession-frameset-restore-force-display
                   :force-onscreen easysession-frameset-restore-force-onscreen)

                  (when (fboundp 'tab-bar-mode)
                    (when (seq-some
                           (lambda (frame)
                             (menu-bar-positive-p
                              (frame-parameter frame 'tab-bar-lines)))
                           (frame-list))
                      (tab-bar-mode 1)))

                  ;; Return t
                  t)
          (easysession--warning "%s: Failed to restore the frameset"))))))

(defun easysession--ensure-buffer-name (buffer name)
  "Ensure that BUFFER name is NAME."
  (when (not (string= (buffer-name buffer) name))
    (with-current-buffer buffer
      (rename-buffer name t))))

(defun easysession--check-dont-save (frame)
  "Check if FRAME is a real frame and should be saved.
Also checks if `easysession-dont-save' is set to t."
  ;; Exclude frames with a parent frame. One common use of the parent-frame
  ;; parameter is in the context of child frames, often used by packages like
  ;; posframe, which create transient, overlay, or tooltip-like frames. These
  ;; child frames are associated with a parent frame to maintain a logical and
  ;; spatial relationship.
  (and (not (frame-parameter frame 'parent-frame))
       (not (frame-parameter frame 'easysession-dont-save))))

(defun easysession--exists (session-name)
  "Check if a session with the given SESSION-NAME exists.
Returns the session file if the session file exists, nil otherwise."
  (let ((file-name-handler-alist nil))
    (let ((file-name (easysession-get-session-file-path session-name)))
      (when (file-exists-p file-name)
        file-name))))

(defun easysession--auto-save ()
  "Save the session automatically based on the auto-save predicate.
This function is usually called by `easysession-save-mode'. It evaluates the
`easysession-save-mode-predicate' function, and if the predicate returns
non-nil, the current session is saved."
  (unwind-protect
      ;; Auto save when there is at least one frame
      (when (frame-list)
        (if (funcall easysession-save-mode-predicate)
            (easysession-save)
          (when easysession--debug
            (easysession--message
             (concat
              "[DEBUG] Auto-save ignored: `easysession-save-mode-predicate' "
              "returned nil.")))))
    t)
  t)

(defun easysession--mode-line-session-name-format ()
  "Compose EasySession's mode-line."
  (if (bound-and-true-p easysession--current-session-name)
      (let* ((session-name (eval easysession--current-session-name)))
        (list
         (propertize session-name
                     'face 'easysession-mode-line-session-name-face
                     'help-echo (format "Current session: %s" session-name)
                     'mouse-face 'mode-line-highlight)))
    ""))

;;; Internal functions: handlers

(defun easysession--handler-load-file-editing-buffers (session-data)
  "Load base buffers from the SESSION-DATA variable."
  (let ((buffer-file-names (assoc-default "buffers" session-data)))
    (when buffer-file-names
      (dolist (buffer-name-and-path buffer-file-names)
        (let ((buffer-name (car buffer-name-and-path))
              (buffer-path (cdr buffer-name-and-path)))
          (let* ((buffer (get-file-buffer buffer-path)))
            (unless buffer
              (setq buffer
                    (ignore-errors
                      (let ((find-file-hook
                             (seq-difference find-file-hook
                                             easysession-exclude-from-find-file-hook)))
                        (find-file-noselect buffer-path :nowarn)))))
            (if (and buffer (buffer-live-p buffer))
                (progn
                  ;; We are going to be using buffer-base-buffer to make sure
                  ;; that the buffer that was returned by find-file-noselect is
                  ;; a base buffer and not a clone
                  (let* ((base-buffer (buffer-base-buffer buffer))
                         (buffer (if base-buffer
                                     base-buffer
                                   buffer)))
                    ;; Fixes the issue preventing font-lock-mode from fontifying
                    ;; restored buffers, causing the text to remain unfontified
                    ;; until the user presses a key.
                    (when (and
                           (bound-and-true-p font-lock-mode)
                           (bound-and-true-p
                            redisplay-skip-fontification-on-input)
                           (fboundp 'jit-lock-fontify-now))
                      (with-current-buffer buffer
                        (ignore-errors (jit-lock-fontify-now))))

                    (when buffer
                      (easysession--ensure-buffer-name buffer buffer-name))))
              (easysession--warning "Failed to restore the buffer '%s': %s"
                                    buffer-name buffer-path))))))))

(defun easysession--handler-save-file-editing-buffers (buffers)
  "Collect and categorize file editing buffers from the provided list.
BUFFERS is the list of buffers to process. This function identifies buffers
that are associated with files (file editing buffers) and those that are
not. It returns an alist with the following structure."
  (let ((file-editing-buffers '())
        (remaining-buffers '()))
    (dolist (buf buffers)
      (let ((base-buffer-info (easysession--get-base-buffer-info buf)))
        (if base-buffer-info
            (push base-buffer-info file-editing-buffers)
          (push buf remaining-buffers))))
    `((key . "buffers")
      (value . ,file-editing-buffers)
      (remaining-buffers . ,remaining-buffers))))

(defun easysession--handler-load-indirect-buffers (session-data)
  "Load indirect buffers from the SESSION-DATA variable."
  (let ((indirect-buffers (assoc-default "indirect-buffers"
                                         session-data)))
    (when indirect-buffers
      (dolist (item indirect-buffers)
        (let* ((indirect-buffer-name (alist-get 'indirect-buffer-name item))
               (base-buffer-name (alist-get 'base-buffer-name (cdr item))))
          (when (and base-buffer-name indirect-buffer-name)
            (let ((base-buffer (get-buffer base-buffer-name))
                  (indirect-buffer (get-buffer indirect-buffer-name)))
              (when (and (not (buffer-live-p indirect-buffer))
                         (buffer-live-p base-buffer))
                (with-current-buffer base-buffer
                  (let ((indirect-buffer
                         (ignore-errors (clone-indirect-buffer
                                         indirect-buffer-name nil))))
                    (if indirect-buffer
                        (easysession--ensure-buffer-name indirect-buffer
                                                         indirect-buffer-name)
                      (easysession--warning
                       (concat "Failed to restore the indirect "
                               "buffer (clone): %s")
                       indirect-buffer-name))))))))))))

(defun easysession--handler-save-indirect-buffers (buffers)
  "Collect and categorize indirect buffers from the provided list.
BUFFERS is the list of buffers to process. This function identifies indirect
buffers and separates them from other buffers."
  (let ((indirect-buffers '())
        (remaining-buffers '()))
    (dolist (buf buffers)
      (let ((indirect-buffer-info (easysession--get-indirect-buffer-info buf)))
        (if indirect-buffer-info
            (push indirect-buffer-info indirect-buffers)
          (push buf remaining-buffers))))
    `((key . "indirect-buffers")
      (value . ,indirect-buffers)
      (remaining-buffers . ,remaining-buffers))))

(defun easysession-add-load-handler (handler-fn)
  "Add a load handler.
The handler is only added if it's not already present and if HANDLER-FN is a
symbol representing an existing function. HANDLER-FN is the function to load
session data."
  (unless (and (symbolp handler-fn)
               (fboundp handler-fn))
    (error "HANDLER-FN must be a symbol representing an existing function"))
  (unless (memq handler-fn easysession--load-handlers)
    (setq easysession--load-handlers
          (append easysession--load-handlers (list handler-fn)))))

(defun easysession-add-save-handler (handler-fn)
  "Add a save handler.
HANDLER-FN is the function to save session data.
The HANDLER-FN handler is only added if it's not already present."
  (unless (and (symbolp handler-fn)
               (fboundp handler-fn))
    (error "HANDLER-FN must be a symbol representing an existing function"))
  (unless (memq handler-fn easysession--save-handlers)
    ;; (push handler-fn easysession--save-handlers)
    (setq easysession--save-handlers
          (append easysession--save-handlers (list handler-fn)))))

(defun easysession-remove-load-handler (handler-fn)
  "Remove a load handler.
HANDLER-FN is the function to load session data.
The HANDLER-FN handler is only added if it's not already present."
  (unless (and (symbolp handler-fn)
               (fboundp handler-fn))
    (error "HANDLER-FN must be a symbol representing an existing function"))
  (setq easysession--load-handlers
        (delq handler-fn easysession--load-handlers)))

(defun easysession-remove-save-handler (handler-fn)
  "Remove a save handler.
HANDLER-FN is the function to be removed."
  (unless (and (symbolp handler-fn)
               (fboundp handler-fn))
    (error "HANDLER-FN must be a symbol representing an existing function"))
  (setq easysession--save-handlers (delete handler-fn
                                           easysession--save-handlers)))

(defun easysession-get-save-handlers ()
  "Return a list of all built-in and user-defined save handlers."
  (append easysession--builtin-save-handlers
          easysession--save-handlers))

(defun easysession-get-load-handlers ()
  "Return a list of all built-in and user-defined load handlers."
  (append easysession--builtin-load-handlers
          easysession--load-handlers))

(defmacro easysession-define-load-handler (key handler-func)
  "Add a load handler for a specific session KEY.

KEY is the identifier used in the EasySession file. Avoid reserved keys like:
buffers, indirect-buffers, frameset, and frameset-geo. Prefix with an
underscore to be safe.

HANDLER-FUNC is a callable that is invoked with session data when the key is
found."
  `(progn
     (defun
         ,(intern (concat "easysession--" key "-load-handler")) (session-data)
       ,(format "Load handler for restoring %s buffers from SESSION-DATA."
                key)
       (let ((handler-data (assoc-default ,key session-data)))
         (when handler-data
           (funcall ,handler-func handler-data))))

     (easysession-add-load-handler
      ',(intern (concat "easysession--" key "-load-handler")))))

(defmacro easysession-define-generic-save-handler (key &rest body)
  "Add a save handler to EasySession.

KEY is the identifier for this session data within EasySession. Prefix with an
underscore to be safe. Avoid using reserved keys such as: buffers,
indirect-buffers, frameset, and frameset-geo.

BODY is executed."
  `(progn
     (defun ,(intern (concat "easysession--" key "-save-handler")) (buffers)
       ,(format "Save handler for save %s." key)
       (when buffers
         t)  ;; Remove warnings
       ,@body)

     (easysession-add-save-handler
      ',(intern (concat "easysession--" key "-save-handler")))))

(defmacro easysession-define-save-handler (key handler-func)
  "Add a save handler to EasySession.

KEY is the identifier for this session data within EasySession. Prefix with an
underscore to be safe. Avoid using reserved keys such as: buffers,
indirect-buffers, frameset, and frameset-geo.

HANDLER-FUNC is a callable that processes each buffer and returns its session
data."
  `(easysession-define-generic-save-handler
    ,key
    (let ((result (funcall ,handler-func buffers)))
      (when result
        ;; TODO Check if buffers and remaining buffers exist
        (push (cons 'key ,key) result)))))

(defmacro easysession-define-handler (key load-handler-func save-handler-func)
  "Register both load and save handlers for a given KEY.

KEY is the session identifier. Avoid reserved keys.

LOAD-HANDLER-FUNC and SAVE-HANDLER-FUNC are functions for handling session
data."
  `(progn
     (easysession-define-load-handler ,key ,load-handler-func)
     (easysession-define-save-handler ,key ,save-handler-func)))

(defmacro easysession-save-handler-dolist-buffers (buffers &rest body)
  "Iterate over BUFFERS, execute BODY inside each buffer's context.
Classify buffers based on BODY's result."
  `(let (saved-buffers
         remaining-buffers)
     (dolist (buffer ,buffers)
       (with-current-buffer buffer
         (let ((buffer-data (progn ,@body)))
           (if buffer-data
               (push buffer-data saved-buffers)
             (push buffer remaining-buffers)))))
     (list
      (cons 'buffers saved-buffers)
      (cons 'remaining-buffers remaining-buffers))))

;;; Autoloaded functions

;;;###autoload
(defun easysession-rename (&optional new-session-name)
  "Rename the current session to NEW-SESSION-NAME."
  (interactive (list (easysession--prompt-session-name
                      (format "Rename session '%s' to: "
                              (easysession-get-session-name))
                      nil
                      nil
                      (easysession-get-session-name))))
  (unless new-session-name
    (error (concat "[easysession] easysession-rename: You need to specify"
                   "the new session name.")))
  (let* ((old-path (easysession-get-session-file-path
                    easysession--current-session-name))
         (new-path (easysession-get-session-file-path new-session-name)))
    (unless (file-regular-p old-path)
      (error "[easysession] No such file or directory: %s" old-path))
    (rename-file old-path new-path)
    (setq easysession--current-session-name new-session-name)))

;;;###autoload
(defun easysession-delete (session-name)
  "Delete a session. Prompt for SESSION-NAME if not provided."
  (interactive (list (easysession--prompt-session-name "Delete session: ")))
  (let* ((session-file (easysession--exists session-name)))
    (if session-file
        (progn
          (let ((session-buffer (find-buffer-visiting session-file)))
            (when session-buffer
              (kill-buffer session-buffer)))

          (delete-file session-file nil)
          (easysession--message "Session deleted: %s" session-name)
          t)
      (easysession--warning
       "The session '%s' cannot be deleted because it does not exist"
       session-name)
      nil)))

;;;###autoload
(defun easysession-load (&optional session-name)
  "Load the current session. SESSION-NAME is the session name."
  (interactive)
  (setq easysession-load-in-progress nil)
  (setq easysession--load-error t)
  (let* ((original-file-name-handler-alist file-name-handler-alist)
         (file-name-handler-alist nil)
         (session-name (if session-name
                           session-name
                         easysession--current-session-name))
         (easysession-load-in-progress session-name)
         (session-data nil)
         (file-contents nil)
         (session-file (easysession--exists session-name)))
    (when session-file
      (setq file-contents (let ((coding-system-for-read 'utf-8-emacs)
                                (file-coding-system-alist nil))
                            (with-temp-buffer
                              (insert-file-contents session-file)
                              (buffer-string))))
      (when (or (not file-contents)
                (and (stringp file-contents)
                     (string= (string-trim file-contents) "")))
        (error "[easysession] %s: Failed to read session information from %s"
               session-name session-file))

      ;; Evaluate file
      (setq session-data (ignore-errors (read file-contents)))
      (when (not session-data)
        (error
         "[easysession] %s: Failed to evaluate session information from %s"
         session-name session-file))

      ;; Load buffers first because the cursor, window-start, or hscroll might
      ;; be altered by packages such as saveplace. This will allow the frameset
      ;; to modify the cursor later on.
      (let ((file-name-handler-alist original-file-name-handler-alist))
        (run-hooks 'easysession-before-load-hook)

        (dolist (handler (easysession-get-load-handlers))
          (when handler
            (cond
             ((and (symbolp handler)
                   (fboundp handler))
              (funcall handler session-data))

             (t
              (easysession--warning
               "The following load handler is not a defined function: %s"
               handler))))))

      ;; Load the frame set
      (easysession--load-frameset
       session-data (bound-and-true-p easysession-frameset-restore-geometry))

      (setq easysession--load-error nil)
      (when (called-interactively-p 'any)
        (easysession--message "Session loaded: %s" session-name))

      (let ((file-name-handler-alist original-file-name-handler-alist))
        (run-hooks 'easysession-after-load-hook))))
  ;; Return easysession--load-error
  (not easysession--load-error))

;;;###autoload
(defun easysession-load-including-geometry (&optional session-name)
  "Load the session and restore the position and size of the Emacs frames.
SESSION-NAME is the session name.

This function is typically used when Emacs is initially loaded. It ensures that
session settings, including the positions and sizes (geometry) of all frames,
are restored.

For subsequent session switching, consider using `easysession-switch-to', which
load the session without resizing or moving the Emacs frames."
  (let ((easysession-frameset-restore-geometry t))
    (easysession-load session-name)))

;;;###autoload
(defun easysession-save (&optional session-name)
  "Save the current session.
SESSION-NAME is the name of the session."
  (interactive)
  (run-hooks 'easysession-before-save-hook)
  (let* ((original-file-name-handler-alist file-name-handler-alist)
         (file-name-handler-alist nil)
         (session-name (if session-name
                           session-name
                         (easysession-get-session-name)))
         (session-file (easysession-get-session-file-path session-name))
         (data-frameset (easysession--save-frameset session-name))
         (data-frameset-geometry (easysession--save-frameset
                                  session-name t))
         (session-data nil)
         (session-dir (file-name-directory session-file)))
    ;; Frameset
    (push (cons "frameset" data-frameset) session-data)
    (push (cons "frameset-geo" data-frameset-geometry) session-data)

    ;; Buffers and file buffers
    (let* ((file-name-handler-alist original-file-name-handler-alist)
           (buffers (funcall easysession-buffer-list-function)))
      (dolist (handler (easysession-get-save-handlers))
        (if (not (and handler
                      (symbolp handler)
                      (fboundp handler)))
            (easysession--warning
             "The following save handler is not a defined function: %s"
             handler)
          (let ((result (funcall handler buffers)))
            (when result
              (let* ((key (alist-get 'key result))
                     (value (let ((value (alist-get 'buffers result)))
                              (if value
                                  ;; Backward compatibility
                                  value
                                ;; New: 'value
                                (alist-get 'value result))))
                     (remaining-buffers (alist-get 'remaining-buffers result)))
                ;; Push results into session-data
                (push (cons key value) session-data)

                ;; The following optimizes buffer processing by updating the
                ;; list of buffers for the next iteration By setting buffers
                ;; to the remaining-buffers returned by each handler function,
                ;; it ensures that each subsequent handler only processes
                ;; buffers that have not yet been handled. This approach
                ;; avoids redundant processing of buffers that have already
                ;; been classified or processed by previous handlers,
                ;; resulting in more efficient processing. As a result, each
                ;; handler operates on a progressively reduced set of buffers.
                (setq buffers remaining-buffers)))))))

    (unless (file-directory-p session-dir)
      (make-directory session-dir :parents))

    (let* ((file-name-handler-alist nil)
           (serialized-data (prin1-to-string session-data)))
      (with-temp-buffer
        (insert serialized-data)
        (let ((coding-system-for-write 'utf-8-emacs)
              (write-region-annotate-functions nil)
              (write-region-post-annotation-function nil))
          (write-region (point-min) (point-max) session-file nil 'silent)
          nil))

      (when (called-interactively-p 'any)
        (easysession--message "Session saved: %s" session-name)))

    (run-hooks 'easysession-after-save-hook)))

;;;###autoload
(defun easysession-save-as (session-name)
  "Save the session as SESSION-NAME and make it the current session.

If the function is called interactively, prompt the user for a session name."
  (interactive
   (list (easysession--prompt-session-name "Save session as: "
                                           (easysession-get-session-name))))
  (let* ((new-session-name (or session-name (easysession-get-session-name)))
         (previous-session-name easysession--current-session-name))
    (easysession--ensure-session-name-valid new-session-name)
    (easysession-save new-session-name)
    (easysession--set-current-session new-session-name)
    (if (string= previous-session-name easysession--current-session-name)
        (easysession--message "Saved the session: %s" new-session-name)
      (easysession--message "Saved and switched to session: %s"
                            new-session-name))
    t))

;;;###autoload
(defun easysession-switch-to (session-name)
  "Save the current session and load SESSION-NAME.

This function saves the current Emacs session and loads the session specified by
SESSION-NAME. If SESSION-NAME is not provided, it prompts the user for a session
name when called interactively.

This function will:
- Save the current session if it is loaded and not being reloaded.
- Load the specified session.
- Set the specified session as the current session.
- If the session does not exist, it is saved and an empty session is
  initialized.

If the session is already loaded, a message is displayed to indicate it has been
reloaded. If the session is newly created or switched to, a message is displayed
accordingly."
  (interactive
   (list (easysession--prompt-session-name
          "Load and switch to session: "
          (unless easysession-switch-to-exclude-current
            (easysession-get-session-name))
          easysession-switch-to-exclude-current)))
  (let* ((session-name (or session-name (easysession-get-session-name)))
         (session-file (easysession-get-session-file-path session-name))
         (session-reloaded (string= session-name
                                    easysession--current-session-name))
         (saved nil)
         (new-session nil))
    ;; TODO: Prompt the user for confirmation before loading a new session
    ;;       if the current session has not been loaded.
    (when (and (not easysession--load-error) (not session-reloaded))
      (easysession-save easysession--current-session-name)
      (setq saved t))
    (easysession-load session-name)
    (easysession--set-current-session session-name)

    (unless session-reloaded
      (unless (file-exists-p session-file)
        (run-hooks 'easysession-new-session-hook)
        (easysession-save)
        (setq new-session t)))

    (cond (session-reloaded
           (easysession--message "Reloaded session: %s" session-name))
          (saved
           (easysession--message "Saved and switched to %ssession: %s"
                                 (if new-session "new " "") session-name))
          (t (easysession--message "Switched to %ssession: %s"
                                   (if new-session "new " "") session-name)))))

;;;###autoload
(define-minor-mode easysession-save-mode
  "Toggle `easysession-save-mode'."
  :global t
  :lighter
  (lambda()
    (:eval
     (if easysession-save-mode-lighter-show-session-name
         easysession-save-mode-lighter-session-name-spec
       easysession-save-mode-lighter)))
  :group 'easysession
  (if easysession-save-mode
      (progn
        (when (and easysession-save-interval
	                 (null easysession--timer))
          (setq easysession--timer (run-with-timer easysession-save-interval
			                                             easysession-save-interval
                                                   #'easysession--auto-save)))
        ;; `kill-emacs-query-functions' is preferable to `kill-emacs-hook' for
        ;; saving frames, as it is called before frames are closed.
        ;; In contrast, `kill-emacs-hook' is invoked after the frames are
        ;; killed, such as when Emacs is terminated using `xkill` or the
        ;; `kill-emacs' Emacs function.
        (add-hook 'kill-emacs-query-functions #'easysession--auto-save)
        (add-hook 'kill-emacs-hook #'easysession--auto-save))
    (when easysession--timer
      (cancel-timer easysession--timer)
      (setq easysession--timer nil))
    (remove-hook 'kill-emacs-hook #'easysession--auto-save)
    (remove-hook 'kill-emacs-query-functions #'easysession--auto-save)))

(provide 'easysession)
;;; easysession.el ends here
