;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node-fakeroam" "20241118.951"
  "Stand-ins for org-roam-autosync-mode."
  '((emacs    "28.1")
    (org-node "1.7.0")
    (compat   "30")
    (org-roam "2.2.2")
    (emacsql  "4.0.3"))
  :url "https://github.com/meedstrom/org-node-fakeroam"
  :commit "803f5f7cde3634b0f983645f6480bbf1a619fb3c"
  :revdesc "803f5f7cde36"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
