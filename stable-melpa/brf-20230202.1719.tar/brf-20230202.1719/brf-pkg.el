(define-package "brf" "20230202.1719" "Brf-mode provides features from the legendary editor Brief"
  '((fringe-helper "0.1.1")
    (emacs "24.3"))
  :commit "41209150d67dc3c48c2b02686d2f77cbb0760c72" :authors
  '(("Mike Woolley" . "mike@bulsara.com"))
  :maintainer
  '("Mike Woolley" . "mike@bulsara.com")
  :keywords
  '("brief" "crisp" "emulations")
  :url "https://bitbucket.org/MikeWoolley/brf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
