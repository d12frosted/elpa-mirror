(define-package "mastodon" "20231005.943" "Client for fediverse services using the Mastodon API"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4"))
  :commit "b8c5e9d50dcb68222070303726c0e6027a9c0d26" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
