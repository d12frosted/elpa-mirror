(define-package "binky-mode" "20230729.1330" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "150f65c408f791f8a8526f6c4666dcbbbea3e219" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
