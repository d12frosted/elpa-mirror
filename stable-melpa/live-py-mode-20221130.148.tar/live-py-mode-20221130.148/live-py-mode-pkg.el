(define-package "live-py-mode" "20221130.148" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "16cb03eef58c617ee16945eea81c18ec7fa92b32" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
