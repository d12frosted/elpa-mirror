(define-package "eldev" "20210325.2223" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "a7211e47c1dd543ca5d84b7b85ca205fc6315abe" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
