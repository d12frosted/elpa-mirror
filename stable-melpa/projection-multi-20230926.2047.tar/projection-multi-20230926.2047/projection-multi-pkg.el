(define-package "projection-multi" "20230926.2047" "Projection integration for `compile-multi'"
  '((emacs "29.1")
    (projection "0.1")
    (compile-multi "0.5"))
  :commit "9370f00fbb56bc423e7c3a2301fd7803ead23cd4" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
