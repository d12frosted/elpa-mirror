(define-package "geiser" "20230503.159" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (project "0.8.1"))
  :commit "dd81026d1c4bc40e03ced3a6ecc9025b14bdd93d" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainers
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
