(define-package "consult" "20210226.445" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "133df681993eb9a94743154d80b59f7644263775" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
