;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260224.147"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.3")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "c5b27cdd2d66435ebb0c7bd4c688cc148886175e"
  :revdesc "c5b27cdd2d66"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
