;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-defaults" "20260516.827"
  "Awesome leaf config collections."
  '((emacs         "26.1")
    (leaf          "4.5.5")
    (leaf-keywords "2.0.8"))
  :url "https://github.com/conao3/leaf-defaults.el"
  :commit "238282d31d20c9b5077d7274ba9448eaaf0d44cc"
  :revdesc "238282d31d20"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
