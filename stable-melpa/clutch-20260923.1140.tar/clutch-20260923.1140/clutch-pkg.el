;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260923.1140"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "5d5ab6c0cbea7bb286430c3f19645e7a5b89b52c"
  :revdesc "5d5ab6c0cbea"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
