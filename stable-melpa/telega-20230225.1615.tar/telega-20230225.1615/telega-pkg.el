(define-package "telega" "20230225.1615" "Telegram client (unofficial)"
  '((emacs "26.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "497cdedfaff8e510f300061636cb024b28bfea9a" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
