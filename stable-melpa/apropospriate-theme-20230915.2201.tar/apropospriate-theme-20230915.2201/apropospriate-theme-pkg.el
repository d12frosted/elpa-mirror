(define-package "apropospriate-theme" "20230915.2201" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "6618e26a833fdd2fbddf32075f1953cc4f86cb03" :authors
  '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainer
  '("Justin Talbott" . "justin@waymondo.com")
  :url "http://github.com/waymondo/apropospriate-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
