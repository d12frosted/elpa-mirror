;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-buffer-switch" "20221220.1142"
  "Quick switch to file or dir buffers."
  ()
  :url "https://github.com/renard/quick-buffer-switch"
  :commit "280f67f1a5e02533573b45d585c222c937f11f81"
  :revdesc "280f67f1a5e0"
  :keywords '("emacs" "configuration")
  :authors '(("Sebastien Gross" . "seb•ɑƬ•chezwam•ɖɵʈ•org"))
  :maintainers '(("Sebastien Gross" . "seb•ɑƬ•chezwam•ɖɵʈ•org")))
