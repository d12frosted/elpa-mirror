;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-snail" "20260403.453"
  "Julia Snail."
  '((emacs      "26.2")
    (dash       "2.16.0")
    (julia-mode "0.3")
    (s          "1.12.0")
    (spinner    "1.7.3")
    (popup      "0.5.9"))
  :url "https://github.com/gcv/julia-snail"
  :commit "3c0beddcd21464d52e95e65ee8b3d7b3a148d83d"
  :revdesc "3c0beddcd214")
