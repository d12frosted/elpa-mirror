(define-package "notmuch" "20210515.1210" "run notmuch within emacs" 'nil :commit "ff07183a02a480b36e70284289607c1315ac3db7" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
