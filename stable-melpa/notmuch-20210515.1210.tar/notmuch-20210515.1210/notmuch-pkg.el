(define-package "notmuch" "20210515.1210" "run notmuch within emacs" 'nil :commit "702635d5f61729b5d0453f73d8eaa4bc6eb50ed4" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
