(define-package "notmuch" "20210515.1210" "run notmuch within emacs" 'nil :commit "100106a45d9f362ed8770c95cf35bd43f6580511" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
