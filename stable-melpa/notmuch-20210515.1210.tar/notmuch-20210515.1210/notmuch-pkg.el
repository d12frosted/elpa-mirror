(define-package "notmuch" "20210515.1210" "run notmuch within emacs" 'nil :commit "92454bc0935604f4a623e75dec9506c0283eee70" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
