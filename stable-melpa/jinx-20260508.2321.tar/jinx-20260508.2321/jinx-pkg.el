;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260508.2321"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "b08ec1cde1b67bb153b7d27942f2b0edce8ede82"
  :revdesc "b08ec1cde1b6"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
