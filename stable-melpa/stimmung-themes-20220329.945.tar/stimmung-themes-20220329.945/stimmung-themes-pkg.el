(define-package "stimmung-themes" "20220329.945" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "e8a2699914d13228ca24ad81373e93dd796f2c38" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
