(define-package "xenops" "20201111.1643" "A LaTeX editing environment for mathematical documents"
  '((emacs "26.1")
    (aio "1.0")
    (auctex "12.2.0")
    (avy "0.5.0")
    (dash "2.17.0")
    (dash-functional "1.2.0")
    (f "0.20.0")
    (s "1.12.0"))
  :commit "fd9a8ba23727170db9baef98950d51f4bfd99d34" :authors
  (("Dan Davison" . "dandavison7@gmail.com"))
  :maintainer
  ("Dan Davison" . "dandavison7@gmail.com")
  :url "https://github.com/dandavison/xenops")
;; Local Variables:
;; no-byte-compile: t
;; End:
