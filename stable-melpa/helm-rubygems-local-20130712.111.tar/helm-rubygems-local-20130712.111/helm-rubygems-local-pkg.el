;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rubygems-local" "20130712.111"
  "Installed local rubygems find-file for helm."
  '((helm "1.5.3"))
  :url "https://github.com/f-kubotar/helm-rubygems-local"
  :commit "289cb33d41c703af9791d6da46b55f070013c2e3"
  :revdesc "289cb33d41c7"
  :authors '(("hadashiA" . "dev@hadashikick.jp"))
  :maintainers '(("hadashiA" . "dev@hadashikick.jp")))
