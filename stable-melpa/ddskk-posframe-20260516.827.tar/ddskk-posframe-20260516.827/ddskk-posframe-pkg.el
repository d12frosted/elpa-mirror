;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk-posframe" "20260516.827"
  "Show Henkan tooltip for ddskk via posframe."
  '((emacs    "26.1")
    (posframe "1.5.1")
    (ddskk    "17.2"))
  :url "https://github.com/conao3/ddskk-posframe.el"
  :commit "1b5c8f85cafb1e763e214f4310113c75e28cce0d"
  :revdesc "1b5c8f85cafb"
  :keywords '("tooltip" "convenience" "posframe")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
