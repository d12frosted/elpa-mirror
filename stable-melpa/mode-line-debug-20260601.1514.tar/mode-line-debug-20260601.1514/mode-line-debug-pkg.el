;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-line-debug" "20260601.1514"
  "Show status of debug-on-error in mode-line."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/mode-line-debug"
  :commit "3e1b50bc666beaf6441f652608bf7f48b74e80df"
  :revdesc "3e1b50bc666b"
  :keywords '("convenience" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.mode-line-debug@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.mode-line-debug@jonas.bernoulli.dev")))
