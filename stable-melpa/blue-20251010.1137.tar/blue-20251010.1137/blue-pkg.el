;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251010.1137"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "6f2162a0a8a94f76c22beeffa8b10f36579cc0d0"
  :revdesc "6f2162a0a8a9"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
