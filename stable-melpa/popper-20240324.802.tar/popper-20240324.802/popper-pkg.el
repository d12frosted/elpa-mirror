(define-package "popper" "20240324.802" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "73dc34e59db8fa5e2b6e162b3daf10b94c6a78ce" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
