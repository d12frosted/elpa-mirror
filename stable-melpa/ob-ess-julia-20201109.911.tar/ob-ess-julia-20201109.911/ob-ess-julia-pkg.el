(define-package "ob-ess-julia" "20201109.911" "Org babel support for Julia language"
  '((ess "20201004.1522")
    (julia-mode "0.4"))
  :commit "337df3eefd85c01020fe08eae3ddcf3ec3e4ac2d" :keywords
  ("languages")
  :authors
  (("Frédéric Santos"))
  :maintainer
  ("Frédéric Santos")
  :url "https://github.com/frederic-santos/ob-ess-julia")
;; Local Variables:
;; no-byte-compile: t
;; End:
