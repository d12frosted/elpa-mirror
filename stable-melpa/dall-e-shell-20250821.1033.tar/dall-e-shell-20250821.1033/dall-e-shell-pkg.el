;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dall-e-shell" "20250821.1033"
  "Interaction mode for DALL-E."
  '((emacs       "27.1")
    (shell-maker "0.79.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "428125f9fa8578703a9ca85d173b2cc9a3eb16b9"
  :revdesc "428125f9fa85")
