(define-package "spdx" "20220429.126" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "1405b4f050f8181b8bcbe2951760e6c5b68b08c7" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
