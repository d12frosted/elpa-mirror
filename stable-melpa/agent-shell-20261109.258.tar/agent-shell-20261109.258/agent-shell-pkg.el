;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261109.258"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "704daa9692a754f225d41b04763e8b647bfcaebe"
  :revdesc "704daa9692a7")
