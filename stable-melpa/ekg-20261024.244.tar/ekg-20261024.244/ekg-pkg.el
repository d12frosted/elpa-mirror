;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261024.244"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "9f538cc60e79cb3934407aa3280ceb8d0db604e0"
  :revdesc "9f538cc60e79"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
