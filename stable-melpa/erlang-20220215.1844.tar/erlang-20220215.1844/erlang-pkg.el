(define-package "erlang" "20220215.1844" "Erlang major mode"
  '((emacs "24.1"))
  :commit "d2950b913b30bfc99d706d86d1908773cef97598" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
