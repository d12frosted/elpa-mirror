(define-package "erlang" "20220215.1844" "Erlang major mode"
  '((emacs "24.1"))
  :commit "3131421552353bc99a34343ad68887c3447854ea" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
