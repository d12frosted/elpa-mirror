(define-package "erlang" "20220215.1844" "Erlang major mode"
  '((emacs "24.1"))
  :commit "bdd6b699ab41af2d8f644bfa427f1a2b6f71db59" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
