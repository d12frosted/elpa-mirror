(define-package "racket-mode" "20210224.2127" "Racket editing, REPL, and more"
  '((emacs "25.1")
    (faceup "0.0.2")
    (pos-tip "20191127.1028"))
  :commit "75ea8f6dc9ace762dcaf02f834725750fa4abaf2" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
