(define-package "elisp-autofmt" "20230105.1121" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "a540f6e36b4c2aa2c1a20f0ec1d075f2fc744394" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
