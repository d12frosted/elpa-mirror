(define-package "osm" "20220511.1135" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "8d461109ed1ad77111dd267584da8379d244197a" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
