(define-package "fontawesome" "20170305.1356" "fontawesome utility"
  '((emacs "24.4"))
  :commit "26fe027e03911f24b3658b44611d3b38fb6df455" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-fontawesome")
;; Local Variables:
;; no-byte-compile: t
;; End:
