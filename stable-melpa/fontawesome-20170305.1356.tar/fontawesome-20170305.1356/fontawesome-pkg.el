(define-package "fontawesome" "20170305.1356" "fontawesome utility"
  '((emacs "24.4"))
  :commit "c2f0d46d726447a364e6dd263b64891d266e5c71" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-fontawesome")
;; Local Variables:
;; no-byte-compile: t
;; End:
