(define-package "fontawesome" "20170305.1356" "fontawesome utility"
  '((emacs "24.4"))
  :commit "a5fafe89d4032fd1f0c21b7b04708ef2cce2517b" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-fontawesome")
;; Local Variables:
;; no-byte-compile: t
;; End:
