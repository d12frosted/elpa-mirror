(define-package "live-py-mode" "20230328.236" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "83882c71a93080de901bbd1e05332da0555e91a5" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
