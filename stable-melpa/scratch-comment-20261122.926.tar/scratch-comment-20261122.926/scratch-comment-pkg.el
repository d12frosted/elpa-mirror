;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-comment" "20261122.926"
  "Insert Elisp result as comment in scratch buffer."
  '((emacs "26.1"))
  :url "https://github.com/conao3/scratch-comment.el"
  :commit "1e5b6e8b1ce3b7771c14ea996332172f294b68b3"
  :revdesc "1e5b6e8b1ce3"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
