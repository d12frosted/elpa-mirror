;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260325.758"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "48dc3ed8e2f46abd28ec287035d01a86e77fb4ba"
  :revdesc "48dc3ed8e2f4"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
