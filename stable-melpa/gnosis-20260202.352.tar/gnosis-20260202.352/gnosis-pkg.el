;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260202.352"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "729d1ebf8debc1961581e548683741b5590fe6be"
  :revdesc "729d1ebf8deb"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
