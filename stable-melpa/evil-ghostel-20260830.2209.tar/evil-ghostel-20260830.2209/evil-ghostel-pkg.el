;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260830.2209"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "20cf11e7b6f44342b20c3f0b7838f7c9f357ee62"
  :revdesc "20cf11e7b6f4"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
