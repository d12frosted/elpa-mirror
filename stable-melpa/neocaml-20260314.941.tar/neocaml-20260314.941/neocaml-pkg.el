;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260314.941"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "356bfce4685458fe1bed08dda4bbbe6e97dc97af"
  :revdesc "356bfce46854"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
