(define-package "modus-themes" "20210907.1714" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "8c0a9af554e2b0054c3bb8ecf75ea94ebfa88e60" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
