(define-package "ergoemacs-mode" "20211008.336" "Emacs mode based on common modern interface and ergonomics."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "6c4b4573e527343969b3228a2481bdeadb37c17c" :authors
  '(("Xah Lee" . "xah@xahlee.org")
    ("David Capello" . "davidcapello@gmail.com")
    ("Matthew L. Fidler" . "matthew.fidler@gmail.com"))
  :maintainer
  '("Matthew L. Fidler" . "matthew.fidler@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ergoemacs/ergoemacs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
