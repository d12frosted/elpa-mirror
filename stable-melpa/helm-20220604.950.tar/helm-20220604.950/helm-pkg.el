(define-package "helm" "20220604.950" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.4")
    (popup "0.5.3"))
  :commit "5e4f624c00e44f31de37b92697b35a1e112ad2fc" :authors
  '(("Thierry Volpiatto "))
  :maintainer
  '("Thierry Volpiatto ")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
