;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260209.336"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "9e5b7faa7351f6210c3937465c64759693a2774e"
  :revdesc "9e5b7faa7351"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
