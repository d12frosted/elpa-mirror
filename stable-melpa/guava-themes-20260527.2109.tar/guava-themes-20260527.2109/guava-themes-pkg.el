;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260527.2109"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "19d4a96e87684216c9909ca60902ca8165483a6d"
  :revdesc "19d4a96e8768"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
