;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260509.854"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "c96c884e7b012ba42ec0bbff3e777ce1a327a8f6"
  :revdesc "c96c884e7b01"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
