;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260222.1730"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "553258fbcd8968dfff81c745dae614d6975926ea"
  :revdesc "553258fbcd89"
  :keywords '("languages" "lisp" "slime"))
