;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-rich-yank" "20260930.947"
  "Paste with org-mode markup and link to source."
  '((emacs "25.1"))
  :url "https://github.com/unhammer/org-rich-yank"
  :commit "a8adcac661ca3c862a517010eef006bf929c6638"
  :revdesc "a8adcac661ca"
  :keywords '("convenience" "hypermedia" "org")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
