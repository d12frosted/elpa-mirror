(define-package "hl-indent-scope" "20230115.633" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "ebd14e0c01fb068de4751b31bd6b28df35ace2ab" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
