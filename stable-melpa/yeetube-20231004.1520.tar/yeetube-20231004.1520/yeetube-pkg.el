(define-package "yeetube" "20231004.1520" "YouTube Front End"
  '((emacs "27.2"))
  :commit "3ac3991dd6603414c6fe3dc3af03a48ccff6e6c3" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.com/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
