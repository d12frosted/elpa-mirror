(define-package "futhark-mode" "20220331.1711" "major mode for editing Futhark source files"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "f5daf5c340ed1242756e0d72f70ff6f9af6358e3" :keywords
  '("languages")
  :url "https://github.com/diku-dk/futhark-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
