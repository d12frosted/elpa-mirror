(define-package "ergoemacs-mode" "20211011.1305" "Emacs mode based on common modern interface and ergonomics."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "349d05a0b4fefea4f6ff4dad0df6e716328b5f74" :authors
  '(("Xah Lee" . "xah@xahlee.org")
    ("David Capello" . "davidcapello@gmail.com")
    ("Matthew L. Fidler" . "matthew.fidler@gmail.com")
    ("Kim F. Storm" . "storm@cua.dk"))
  :maintainer
  '("Matthew L. Fidler" . "matthew.fidler@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ergoemacs/ergoemacs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
