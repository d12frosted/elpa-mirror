(define-package "bibtex-actions" "20210713.1752" "Biblographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0"))
  :commit "48b0e046ac44dc17979e62e2350764534bb12e99" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
