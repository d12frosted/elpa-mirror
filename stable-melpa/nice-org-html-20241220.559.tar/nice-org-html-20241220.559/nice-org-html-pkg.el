;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nice-org-html" "20241220.559"
  "Prettier org-to-html export."
  '((emacs   "25.1")
    (s       "1.13.0")
    (dash    "2.19.1")
    (htmlize "1.58")
    (uuidgen "1.0"))
  :url "https://github.com/ewantown/nice-org-html"
  :commit "ff9fa1bc1a559af681e0e9fc41652bd45d5fe63f"
  :revdesc "ff9fa1bc1a55"
  :keywords '("org" "org-export" "html" "css" "js" "tools")
  :authors '(("Ewan Townshend" . "ewan@etown.dev"))
  :maintainers '(("Ewan Townshend" . "ewan@etown.dev")))
