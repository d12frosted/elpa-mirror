;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260306.1212"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "79fae62090384f01de66d3eb8bddf0e9d4e358c7"
  :revdesc "79fae6209038"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
