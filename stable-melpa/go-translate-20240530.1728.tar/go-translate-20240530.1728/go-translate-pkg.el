(define-package "go-translate" "20240530.1728" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "2069d20275554a4620e3a975cba6a89d5a878ff3" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
