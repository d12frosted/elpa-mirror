(define-package "hl-prog-extra" "20230201.140" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "a573977f9734b1786a4691c9fb8e5031159027f6" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
