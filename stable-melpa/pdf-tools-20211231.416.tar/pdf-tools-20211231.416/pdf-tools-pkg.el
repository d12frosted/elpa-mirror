(define-package "pdf-tools" "20211231.416" "Support library for PDF documents"
  '((emacs "24.3")
    (nadvice "0.3")
    (tablist "1.0")
    (let-alist "1.0.4"))
  :commit "5b1c367f366c7daa22f1a8f82e51b760c279c1ec" :authors
  '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainer
  '("Vedang Manerikar" . "vedang.manerikar@gmail.com")
  :keywords
  '("files" "multimedia")
  :url "http://github.com/vedang/pdf-tools/")
;; Local Variables:
;; no-byte-compile: t
;; End:
