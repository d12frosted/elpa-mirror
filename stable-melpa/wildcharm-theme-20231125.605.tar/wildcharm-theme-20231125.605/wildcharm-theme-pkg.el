(define-package "wildcharm-theme" "20231125.605" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "d6cda809c3d62fcb7a8cce4757150454da474de8" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
