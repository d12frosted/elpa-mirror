;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "card-games" "20261004.1909"
  "Play card games (console + SVG)."
  '((emacs "26.1"))
  :url "https://code.bru.st/corwin/card-game.el"
  :commit "e78fe3838101d343fa1aff5c0bec7d4bc490eacf"
  :revdesc "e78fe3838101"
  :keywords '("games")
  :authors '(("Corwin Brust" . "corwin@bru.st"))
  :maintainers '(("Corwin Brust" . "corwin@bru.st")))
