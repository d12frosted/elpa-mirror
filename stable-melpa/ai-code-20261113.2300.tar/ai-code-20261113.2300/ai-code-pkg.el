;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261113.2300"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "d1e746833471f6515227889292c9fe8b0e9e21d3"
  :revdesc "d1e746833471"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
