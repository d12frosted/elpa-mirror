(define-package "fountain-mode" "20211104.1141" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "bf1849456f6c7587e15a44a0e5c7e1f93810a6e2" :authors
  '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainer
  '("Paul W. Rankin" . "pwr@bydasein.com")
  :keywords
  '("wp" "text")
  :url "https://github.com/rnkn/fountain-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
