;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20251123.144"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "94505fbd01acb4af3f742a584aea6203dd7d5029"
  :revdesc "94505fbd01ac"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
