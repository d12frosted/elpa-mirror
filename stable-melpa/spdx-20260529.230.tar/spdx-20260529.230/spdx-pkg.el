;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260529.230"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "f67824080cb48b4e54c3930319a3ed944f6a5c66"
  :revdesc "f67824080cb4"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
