;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "20251028.708"
  "Interface to query and view results from org-roam."
  '((emacs            "28")
    (org-roam         "2.2.0")
    (s                "1.12.0")
    (magit-section    "3.3.0")
    (transient        "0.4")
    (org-super-agenda "1.2")
    (dash             "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "efdb5294a6ca0ba96da844807b5b016cfc4b9028"
  :revdesc "efdb5294a6ca")
