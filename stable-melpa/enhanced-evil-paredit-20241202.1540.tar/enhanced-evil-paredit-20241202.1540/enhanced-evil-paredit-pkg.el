;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20241202.1540"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "20ed0eb77d15ca3e0ef2aadb578f5b52c0440ede"
  :revdesc "20ed0eb77d15"
  :keywords '("convenience"))
