(define-package "spdx" "20220918.220" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "0617824ce118f8c2f91bea4dae6435da52e34040" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
