;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260825.45"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "4f425ea54133444c5bc6a1377239c984778581c6"
  :revdesc "4f425ea54133"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
