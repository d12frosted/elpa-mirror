(define-package "hyperbole" "20240531.2034" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.1"))
  :commit "06fdacc1ba20d26d9e407a5e73b57dfb123105f5" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Mats Lidell" . "matsl@gnu.org"))
  :maintainer
  '("Mats Lidell" . "matsl@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
