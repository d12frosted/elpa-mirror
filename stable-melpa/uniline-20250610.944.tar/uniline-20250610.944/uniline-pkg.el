;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250610.944"
  "Add ╭─╴UNICODE╶─╮ based ╭─╴diagrams╶─╮ to ╭▶╴text files╶●╮."
  '((emacs "29.1"))
  :url "https://github.com/tbanel/uniline"
  :commit "f7cb1b3ef09cc1f8cf8d7e5bea813b803f901723"
  :revdesc "f7cb1b3ef09c"
  :keywords '("convenience" "text"))
