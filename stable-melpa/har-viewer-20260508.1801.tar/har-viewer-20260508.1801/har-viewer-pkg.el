;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "har-viewer" "20260508.1801"
  "Major mode for viewing HTTP Archive (HAR) files."
  '((emacs "26.1"))
  :url "https://github.com/bozoslivehere/har-viewer.el"
  :commit "90f0cc968548b8af692fa3ccc2c82c9347278aa9"
  :revdesc "90f0cc968548"
  :keywords '("tools" "http" "network")
  :authors '(("Gregory Newman" . "bozoslivehere@protonmail.com"))
  :maintainers '(("Gregory Newman" . "bozoslivehere@protonmail.com")))
