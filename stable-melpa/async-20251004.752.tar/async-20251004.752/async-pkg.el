;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async" "20251004.752"
  "Asynchronous processing in Emacs."
  '((emacs "24.4"))
  :url "https://github.com/jwiegley/emacs-async"
  :commit "5cae78dc0a75cb86df300939af0b00035bc1c045"
  :revdesc "5cae78dc0a75"
  :keywords '("async")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
