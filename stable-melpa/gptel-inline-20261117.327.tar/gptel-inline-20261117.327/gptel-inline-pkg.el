;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-inline" "20261117.327"
  "Persistent gptel session that follows you around."
  '((emacs  "30.1")
    (compat "30.1.0.0")
    (gptel  "0.9.9.5"))
  :url "https://github.com/karthink/gptel-inline"
  :commit "79ec260888e4d1c5280f9b9d26c1b6e372387cb7"
  :revdesc "79ec260888e4"
  :keywords '("comm")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
