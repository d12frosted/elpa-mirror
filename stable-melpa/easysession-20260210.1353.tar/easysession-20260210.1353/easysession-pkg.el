;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260210.1353"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "1c187b50b80c6a12a0df20f1975553cbc3ac638c"
  :revdesc "1c187b50b80c"
  :keywords '("convenience"))
