;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shpec-mode" "20150530.922"
  "Minor mode for shpec specification."
  ()
  :url "https://github.com/shpec/shpec-mode"
  :commit "76bccd63e3b70233a6c9ca0798dd03550952cc76"
  :revdesc "76bccd63e3b7"
  :keywords '("languages" "tools")
  :authors '(("AdrieanKhisbe" . "adriean.khisbe@live.fr"))
  :maintainers '(("AdrieanKhisbe" . "adriean.khisbe@live.fr")))
