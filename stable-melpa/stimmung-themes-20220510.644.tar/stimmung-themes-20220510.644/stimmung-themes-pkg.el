(define-package "stimmung-themes" "20220510.644" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "67e3bc2e9fbc3564ea2884b999ebc66f9a29413c" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
