(define-package "marginalia" "20210104.1655" "Enrich existing commands with completion annotations"
  '((emacs "26.1"))
  :commit "512991743b477ed600fbc4358d20cddfa7806020" :authors
  (("Omar Antolín Camarena, Daniel Mendler"))
  :maintainer
  ("Omar Antolín Camarena, Daniel Mendler")
  :url "https://github.com/minad/marginalia")
;; Local Variables:
;; no-byte-compile: t
;; End:
