;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260427.1920"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "d0b07f072afd765089441a1b16843fab388b81e2"
  :revdesc "d0b07f072afd"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
