(define-package "org-page" "20230821.929" "a static site generator based on org mode"
  '((ht "1.5")
    (simple-httpd "1.4.6")
    (mustache "0.22")
    (htmlize "1.47")
    (org "8.0")
    (dash "2.0.0")
    (cl-lib "0.5")
    (git "0.1.1"))
  :commit "0ac92c485b08c2b2c12f532d90cb925b10de8aa6" :authors
  '(("Kelvin Hu <ini DOT kelvin AT gmail DOT com>"))
  :maintainer
  '("Kelvin Hu <ini DOT kelvin AT gmail DOT com>")
  :keywords
  '("org-mode" "convenience" "beautify")
  :url "https://github.com/kelvinh/org-page")
;; Local Variables:
;; no-byte-compile: t
;; End:
