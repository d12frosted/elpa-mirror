;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250921.546"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "9e48ff3e6e414ae399f18c6eb86010d2dee96a55"
  :revdesc "9e48ff3e6e41"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
