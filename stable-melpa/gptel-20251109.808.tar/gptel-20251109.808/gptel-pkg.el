;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251109.808"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "d0c392bbb0a1f7775d3a1e98220f4bdc043ab63b"
  :revdesc "d0c392bbb0a1"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
