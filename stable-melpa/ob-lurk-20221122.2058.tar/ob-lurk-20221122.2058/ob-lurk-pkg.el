;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-lurk" "20221122.2058"
  "Evaluate lurk code blocks in org mode."
  '((emacs     "25.1")
    (lurk-mode "0.1.6"))
  :url "https://github.com/lurk-lang/lurk-emacs"
  :commit "bd7cf661ccb31bfbfab542018c361bd79064d4f4"
  :revdesc "bd7cf661ccb3"
  :keywords '("languages" "lurk" "lisp")
  :maintainers '(("Jeff Weiss" . "jweiss@protocol.ai")))
