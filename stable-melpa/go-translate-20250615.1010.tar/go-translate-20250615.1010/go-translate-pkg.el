;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250615.1010"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "92b4b4d39b596d5e45a2a7767225440e09382ac4"
  :revdesc "92b4b4d39b59"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
