;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bray" "20250225.616"
  "Lightweight modal editing."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-bray"
  :commit "9145d73e2b03bab228aca5b0bc3da9a7d219e3eb"
  :revdesc "9145d73e2b03"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
