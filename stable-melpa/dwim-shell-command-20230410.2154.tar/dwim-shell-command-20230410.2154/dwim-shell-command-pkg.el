(define-package "dwim-shell-command" "20230410.2154" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "ed737d8de309fd8b1e1e4173dd383eae688249ff" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
