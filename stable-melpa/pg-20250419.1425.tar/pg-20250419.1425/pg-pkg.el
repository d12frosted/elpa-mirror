;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20250419.1425"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "ff6a89b69d9a7df0f06a679dda928627990bbafb"
  :revdesc "ff6a89b69d9a"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
