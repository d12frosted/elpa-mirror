(define-package "persist-state" "20230618.2016" "Regularly persist bookmarks, history, recent files and more"
  '((emacs "28.2"))
  :commit "757a6049723b777930fda220234c10f315cd05bb" :authors
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainer
  '("Bram Schoenmakers" . "me@bramschoenmakers.nl")
  :keywords
  '("convenience")
  :url "https://codeberg.org/bram85/emacs-persist-state.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
