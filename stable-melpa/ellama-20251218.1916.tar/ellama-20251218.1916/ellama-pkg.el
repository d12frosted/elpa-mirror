;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20251218.1916"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "e55ed6962d7b5f936294984f4a905f1270aa4ed4"
  :revdesc "e55ed6962d7b"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
