;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250406.0"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "13fb95fa998f50fc9a810fb9fcbcd77538d8971f"
  :revdesc "13fb95fa998f"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
