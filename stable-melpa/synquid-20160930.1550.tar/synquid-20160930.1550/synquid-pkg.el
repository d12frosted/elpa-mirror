;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synquid" "20160930.1550"
  "Major mode for editing Synquid files."
  '((flycheck "27")
    (emacs    "24.3"))
  :url "https://github.com/cpitclaudel/synquid-mode"
  :commit "28701ce1a15437202f53ab93a14bcba1de83fd2c"
  :revdesc "28701ce1a154"
  :keywords '("languages")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
