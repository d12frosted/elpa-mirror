(define-package "sly" "20230507.2335" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "14bc9d3706c7f40001c29ec1abf7a06ee1958b36" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
