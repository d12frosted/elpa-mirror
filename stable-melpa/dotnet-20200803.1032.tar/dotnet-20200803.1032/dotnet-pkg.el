;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dotnet" "20200803.1032"
  "Interact with dotnet CLI tool."
  ()
  :url "https://github.com/julienXX/dotnet.el"
  :commit "83ba1305d7895b03f3dffb2d3458b7ec75e6909f"
  :revdesc "83ba1305d789"
  :keywords '(".net" "tools")
  :authors '(("Julien BLANCHARD" . "julien@sideburns.eu"))
  :maintainers '(("Julien BLANCHARD" . "julien@sideburns.eu")))
