;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-zones" "20260716.845"
  "Time zone lookups."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/time-zones"
  :commit "4cc37a54ba6447dc0570cd2e42052689d94f09ee"
  :revdesc "4cc37a54ba64")
