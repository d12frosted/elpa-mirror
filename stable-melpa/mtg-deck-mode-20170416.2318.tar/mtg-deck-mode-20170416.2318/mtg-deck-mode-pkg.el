(define-package "mtg-deck-mode" "20170416.2318" "Major mode to edit MTG decks"
  '((emacs "24.4"))
  :commit "7774641630ef85999ab2f6d57eebddbc7c1e7244" :authors
  '(("Mattias Bengtsson" . "mattias.jc.bengtsson@gmail.com"))
  :maintainer
  '("Mattias Bengtsson" . "mattias.jc.bengtsson@gmail.com")
  :keywords
  '("data" "mtg" "magic")
  :url "https://github.com/mattiasb/mtg-deck-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
