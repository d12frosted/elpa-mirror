(define-package "ibrowse" "20230720.715" "Interact with your browser"
  '((emacs "27.1"))
  :commit "ed345cf0c4bd617caf8377dcf6472a4ebd68abd8" :authors
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainers
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainer
  '("Nicolas Graves" . "ngraves@ngraves.fr")
  :keywords
  '("comm" "data" "files" "tools")
  :url "https://git.sr.ht/~ngraves/ibrowse.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
