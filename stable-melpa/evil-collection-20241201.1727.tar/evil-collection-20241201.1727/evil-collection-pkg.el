;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20241201.1727"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "6f7d059b7266bca83d50d4e71c3262c904955315"
  :revdesc "6f7d059b7266"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
