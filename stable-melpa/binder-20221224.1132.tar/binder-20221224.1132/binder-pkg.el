(define-package "binder" "20221224.1132" "Global minor mode to facilitate multi-file writing projects"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "828f2fd079769e5a2c50f8998e84d63a9a95e797" :authors
  '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainer
  '("Paul W. Rankin" . "pwr@bydasein.com")
  :keywords
  '("files" "outlines" "wp" "text")
  :url "https://github.com/rnkn/binder")
;; Local Variables:
;; no-byte-compile: t
;; End:
