(define-package "0x0" "20230816.1829" "Upload sharing to 0x0.st"
  '((emacs "26.1"))
  :commit "d02f16056ef325e4773708b2e831a02b6b453d89" :authors
  '(("William Vaughn <https://git.sr.ht/~willvaughn/>"))
  :maintainers
  '(("William Vaughn" . "vaughnwilld@gmail.com"))
  :maintainer
  '("William Vaughn" . "vaughnwilld@gmail.com")
  :url "https://git.sr.ht/~willvaughn/emacs-0x0")
;; Local Variables:
;; no-byte-compile: t
;; End:
