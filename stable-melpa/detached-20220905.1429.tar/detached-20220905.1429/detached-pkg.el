(define-package "detached" "20220905.1429" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "c81db7bbd4b5d4242186cc821029ce18a7378018" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
