(define-package "consult" "20230114.1619" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.1.0"))
  :commit "19055a962346d3d2293ab1a1c134f3f73b1813cb" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
