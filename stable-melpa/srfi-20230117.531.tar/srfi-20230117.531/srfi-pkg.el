(define-package "srfi" "20230117.531" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "573a860d28c3995c52758d1b186d488b1bc14410" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
