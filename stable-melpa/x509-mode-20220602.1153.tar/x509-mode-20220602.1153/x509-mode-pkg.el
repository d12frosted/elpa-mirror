(define-package "x509-mode" "20220602.1153" "View certificates, CRLs and keys using OpenSSL."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "134e3d693ba0c3ad1e86817bf31d80c4fbb7b17e" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
