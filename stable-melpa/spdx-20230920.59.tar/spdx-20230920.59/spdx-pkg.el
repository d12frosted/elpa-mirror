(define-package "spdx" "20230920.59" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "090d5eaaf74decb79d410d8a35fab640095cb4b5" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
