;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250428.1032"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "5cdb3d7707a7ab5545de8b10f4dd820a15a8c1fb"
  :revdesc "5cdb3d7707a7"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
