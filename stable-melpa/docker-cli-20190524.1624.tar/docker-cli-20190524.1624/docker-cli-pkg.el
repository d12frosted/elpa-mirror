;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker-cli" "20190524.1624"
  "Running various commands in docker containers."
  ()
  :url "https://github.com/bosko/docker-cli"
  :commit "328429219574555c5fb831a421b4b5d9a2338561"
  :revdesc "328429219574"
  :keywords '("processes")
  :authors '(("Boško Ivanišević" . "bosko.ivanisevic@gmail.com"))
  :maintainers '(("Boško Ivanišević" . "bosko.ivanisevic@gmail.com")))
