;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "duckdb-query" "20260127.349"
  "DuckDB query results as native Elisp data structures."
  '((emacs "28.1"))
  :url "https://github.com/gggion/duckdb-query.el"
  :commit "d46801ade295130ce942364f611da68f8fd39040"
  :revdesc "d46801ade295"
  :keywords '("data" "sql")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
