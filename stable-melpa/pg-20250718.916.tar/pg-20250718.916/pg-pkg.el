;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20250718.916"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "8d3434b6698eec2d6882ebedc6c4c84700083c50"
  :revdesc "8d3434b6698e"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
