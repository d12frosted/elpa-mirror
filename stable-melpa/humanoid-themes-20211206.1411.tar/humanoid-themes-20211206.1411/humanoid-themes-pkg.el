(define-package "humanoid-themes" "20211206.1411" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "8ad6d9ae8e6c2cd7e282922416a596bbb20438c8" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
