;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250531.1852"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "70c7ccf8c9528d0b719dce30558eb72756828726"
  :revdesc "70c7ccf8c952"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
