(define-package "haxe-mode" "20240925.754" "Major mode for editing Haxe files" 'nil :commit "7a396e9f01f7c110dd120c6ffaea668f44991f51" :maintainers
  '(("Jen-Chieh Shen" . "jcs090218@gmail.com"))
  :maintainer
  '("Jen-Chieh Shen" . "jcs090218@gmail.com")
  :url "https://github.com/emacsorphanage/haxe-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
