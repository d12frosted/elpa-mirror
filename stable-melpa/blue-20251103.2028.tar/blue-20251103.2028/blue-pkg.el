;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251103.2028"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "0782c601f12bd61c381b5cd1b4eb5fe9340f0ada"
  :revdesc "0782c601f12b"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
