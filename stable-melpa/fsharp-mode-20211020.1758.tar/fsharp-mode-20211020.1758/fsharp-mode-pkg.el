(define-package "fsharp-mode" "20211020.1758" "Support for the F# programming language"
  '((emacs "25")
    (s "1.3.1"))
  :commit "e9078de5f65a5811008e41ab6b2ee865967f123d" :authors
  '(("1993-1997 Xavier Leroy, Jacques Garrigue and Ian T Zimmerman")
    ("2010-2011 Laurent Le Brun" . "laurent@le-brun.eu")
    ("2012-2014 Robin Neatherway" . "robin.neatherway@gmail.com")
    ("2017-2021 Jürgen Hötzel"))
  :maintainer
  '("Jürgen Hötzel")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
