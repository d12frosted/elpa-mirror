;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-fill-paragraph" "20260612.2322"
  "Fancy paragraph fill."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-fancy-fill-paragraph"
  :commit "66e695466933accf5f8cf9e2e445ab4a0226b171"
  :revdesc "66e695466933"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
