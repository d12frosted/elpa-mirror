;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260325.859"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "0239c93d478f5faef47d59a0d53175551791a64d"
  :revdesc "0239c93d478f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
