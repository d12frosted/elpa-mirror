;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260124.2145"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c6533461bd03c080b322c6c687a9aed97c6dcc80"
  :revdesc "c6533461bd03")
