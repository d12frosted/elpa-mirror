(define-package "embark" "20230305.2339" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "1db978b1fea0d08f8100526ed0f734eee27bfd3c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
