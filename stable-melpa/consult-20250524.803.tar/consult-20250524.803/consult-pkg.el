;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250524.803"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "ec93a8a787bc0420838e4f201a996958fa3b9557"
  :revdesc "ec93a8a787bc"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
