(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "5226feb22ee2f9b2559d9ffdf70747f4f349cd42")
;; Local Variables:
;; no-byte-compile: t
;; End:
