(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c5402b875f750add1695964d888b0e2c9c27d1e4")
;; Local Variables:
;; no-byte-compile: t
;; End:
