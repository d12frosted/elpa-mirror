(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "3a4df95062c9484953b0505e73f74453c09fa714")
;; Local Variables:
;; no-byte-compile: t
;; End:
