(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "ce8d8bdca93b4392b3abd9d60b185300c1ceb7bf")
;; Local Variables:
;; no-byte-compile: t
;; End:
