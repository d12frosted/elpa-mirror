(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "dd552b077b9e429ffcdc3fad2d6d447ce05806e8")
;; Local Variables:
;; no-byte-compile: t
;; End:
