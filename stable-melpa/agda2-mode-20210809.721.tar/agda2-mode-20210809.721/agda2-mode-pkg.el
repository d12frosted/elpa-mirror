(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "2bab72d99ae3330cbf3a94450a647158838a1d1b")
;; Local Variables:
;; no-byte-compile: t
;; End:
