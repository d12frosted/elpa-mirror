(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "6c561339233a4fe4dfd7ea544bb42f7f4f76dd00")
;; Local Variables:
;; no-byte-compile: t
;; End:
