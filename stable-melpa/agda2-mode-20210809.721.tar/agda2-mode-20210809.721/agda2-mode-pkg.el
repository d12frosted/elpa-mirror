(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "1f75261df2dc085dcb0235f6dff346ec62120836")
;; Local Variables:
;; no-byte-compile: t
;; End:
