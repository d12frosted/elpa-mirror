(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "5f0c8667be91c48d4a98034fa7636311e5ff0564")
;; Local Variables:
;; no-byte-compile: t
;; End:
