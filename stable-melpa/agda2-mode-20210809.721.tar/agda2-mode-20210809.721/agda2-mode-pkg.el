(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "5ff290415cf4e679d9fc89d460f3e19a64603982")
;; Local Variables:
;; no-byte-compile: t
;; End:
