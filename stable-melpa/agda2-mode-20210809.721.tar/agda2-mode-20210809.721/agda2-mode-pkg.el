(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "6e4fb9d0be1f8236170eac1d7d2514fa10d4c626")
;; Local Variables:
;; no-byte-compile: t
;; End:
