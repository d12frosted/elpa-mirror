(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "2a07bfdf2c1c4ae87f428809af0887aceb6632c0")
;; Local Variables:
;; no-byte-compile: t
;; End:
