(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "b4ac197c2334b5ee2143cbd21ff73ef9a673b246")
;; Local Variables:
;; no-byte-compile: t
;; End:
