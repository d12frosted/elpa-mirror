(define-package "agda2-mode" "20210809.721" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c9c20bf3683f9eaf9987b80257369be2a45d452b")
;; Local Variables:
;; no-byte-compile: t
;; End:
