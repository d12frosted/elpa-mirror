;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "20261031.30"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "ad376a1015a651e2fc409ac9946710af4a8d8d0a"
  :revdesc "ad376a1015a6"
  :keywords '("convenience" "files" "lisp")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
