;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250625.842"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "d6a302c8e9f5b4d85d8e91ff090ccdf818b40ab4"
  :revdesc "d6a302c8e9f5"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
