;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260408.1957"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "958824f73ddfca76b2c3234d4189ffcc1ff2cacb"
  :revdesc "958824f73ddf"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
