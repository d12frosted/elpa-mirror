;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260618.2311"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "4343d948e43aed260d8ec42927b769d85fd0c2ec"
  :revdesc "4343d948e43a"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
