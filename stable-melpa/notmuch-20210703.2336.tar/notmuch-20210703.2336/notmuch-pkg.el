(define-package "notmuch" "20210703.2336" "run notmuch within emacs" 'nil :commit "32f42581e35ee0ebdd89c4cb44292e7979dc5eb7" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
