;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260515.420"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "ef8efd433ddcf8180a886df80d4a95570bdf84a3"
  :revdesc "ef8efd433ddc"
  :keywords '("convenience" "chinese" "input-method" "rime"))
