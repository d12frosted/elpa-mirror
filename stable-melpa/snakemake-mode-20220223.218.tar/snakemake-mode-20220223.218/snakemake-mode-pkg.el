(define-package "snakemake-mode" "20220223.218" "Major mode for editing Snakemake files"
  '((emacs "26.1")
    (transient "0.3.0"))
  :commit "78abd82f34a71b3fff7aa869de1b07a082f1f351" :authors
  '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainer
  '("Kyle Meyer" . "kyle@kyleam.com")
  :keywords
  '("tools")
  :url "https://git.kyleam.com/snakemake-mode/about")
;; Local Variables:
;; no-byte-compile: t
;; End:
