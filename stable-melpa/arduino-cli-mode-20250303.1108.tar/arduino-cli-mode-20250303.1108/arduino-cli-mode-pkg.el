;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arduino-cli-mode" "20250303.1108"
  "Arduino-CLI command wrapper."
  '((emacs "25.1"))
  :url "https://github.com/motform/arduino-cli-mode"
  :commit "1abd6150095a9fb3bd45df5ad960d98e678d4c24"
  :revdesc "1abd6150095a"
  :keywords '("processes" "tools"))
