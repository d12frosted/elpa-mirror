(define-package "brec-mode" "20240331.1150" "A major mode for editing Breccian text"
  '((emacs "24.3"))
  :commit "e31073ba2505b4bc574cde247c41362c9a85edc4" :authors
  '(("Michael Allan" . "mike@reluk.ca"))
  :maintainers
  '(("Michael Allan" . "mike@reluk.ca"))
  :maintainer
  '("Michael Allan" . "mike@reluk.ca")
  :keywords
  '("outlines" "wp")
  :url "http://reluk.ca/project/Breccia/Emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
