;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gerrit" "20260208.922"
  "Gerrit client."
  '((emacs "29.1")
    (magit "2.13.1")
    (s     "1.12.0")
    (dash  "0.2.15"))
  :url "https://github.com/twmr/gerrit.el"
  :commit "317599943495da561a508b31e83ae55c800e5a52"
  :revdesc "317599943495"
  :keywords '("extensions")
  :authors '(("Thomas Wimmer" . "thomaswimmer@posteo.com"))
  :maintainers '(("Thomas Wimmer" . "thomaswimmer@posteo.com")))
