(define-package "w3m" "20211122.45" "an Emacs interface to w3m" 'nil :commit "dcd2da00cc7473ff8c374258bb5157b2cb23d351" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
