;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251102.545"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "5130872b448e9467efab57b4b1ebedf4f70243a9"
  :revdesc "5130872b448e"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
