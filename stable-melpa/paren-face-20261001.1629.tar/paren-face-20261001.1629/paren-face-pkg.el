;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paren-face" "20261001.1629"
  "A face for parentheses in lisp modes."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/paren-face"
  :commit "357562f0bc9851e92289455312411646e95fb58d"
  :revdesc "357562f0bc98"
  :keywords '("faces" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")))
