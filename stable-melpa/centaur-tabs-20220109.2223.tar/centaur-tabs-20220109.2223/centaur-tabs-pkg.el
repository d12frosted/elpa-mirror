(define-package "centaur-tabs" "20220109.2223" "Aesthetic, modern looking customizable tabs plugin"
  '((emacs "24.4")
    (powerline "2.4")
    (cl-lib "0.5"))
  :commit "b2097f1b66583935e750b96b029217063178aed9" :authors
  '(("Emmanuel Bustos" . "ema2159@gmail.com"))
  :maintainer
  '("Emmanuel Bustos" . "ema2159@gmail.com")
  :url "https://github.com/ema2159/centaur-tabs")
;; Local Variables:
;; no-byte-compile: t
;; End:
