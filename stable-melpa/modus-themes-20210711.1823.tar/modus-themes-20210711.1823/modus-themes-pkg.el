(define-package "modus-themes" "20210711.1823" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "1726e3b0b631dcd614c209c26513518b7348ce56" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
