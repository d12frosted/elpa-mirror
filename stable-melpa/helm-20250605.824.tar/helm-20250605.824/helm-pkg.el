;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250605.824"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.3")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "a400c1e071cb79085e79cdcafce040a3dc9ba4ae"
  :revdesc "a400c1e071cb"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
