;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20260504.534"
  "Minor mode for making Anki cards with Org."
  '((emacs "29.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "6786ff750460ef9b161c691d0e0b8ab216dae20c"
  :revdesc "6786ff750460")
