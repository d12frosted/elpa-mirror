;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async-status" "20230821.204"
  "A package for indicator support."
  '((emacs    "28.1")
    (svg-lib  "0.2.7")
    (posframe "1.4.2"))
  :url "https://github.com/seokbeomkim/async-status"
  :commit "d2f5becc9850c26aa71fb581f9fc389eac740f52"
  :revdesc "d2f5becc9850"
  :keywords '("tools" "async")
  :authors '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers '(("Jason Kim" . "sukbeom.kim@gmail.com")))
