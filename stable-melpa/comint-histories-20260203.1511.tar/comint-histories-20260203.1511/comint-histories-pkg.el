;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comint-histories" "20260203.1511"
  "Many comint histories."
  '((emacs "25.1")
    (f     "0.21.0"))
  :url "https://github.com/NicholasBHubbard/comint-histories"
  :commit "120948f3cbd3bc27d9c86dcb14dbf1b4fd160068"
  :revdesc "120948f3cbd3"
  :keywords '("convenience" "processes" "terminals")
  :authors '(("Nicholas Hubbard" . "nicholashubbard@posteo.net"))
  :maintainers '(("Nicholas Hubbard" . "nicholashubbard@posteo.net")))
