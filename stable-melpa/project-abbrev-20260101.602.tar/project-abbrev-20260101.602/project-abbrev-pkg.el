;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-abbrev" "20260101.602"
  "Customize abbreviation expansion in the project."
  '((emacs "25.1"))
  :url "https://github.com/jcs-elpa/project-abbrev"
  :commit "25ae8a4ea43221955ae3d038dccbda90c43840ae"
  :revdesc "25ae8a4ea432"
  :keywords '("abbrev" "abbreviation" "customizable" "shortcut")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
