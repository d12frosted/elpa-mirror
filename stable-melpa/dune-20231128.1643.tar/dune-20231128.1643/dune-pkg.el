(define-package "dune" "20231128.1643" "Integration with the dune build system" 'nil :commit "da1c13705039ecf1a2bceec86fbd77eb32794575" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
