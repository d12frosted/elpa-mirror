(define-package "transient" "20231127.400" "Transient commands"
  '((emacs "26.1")
    (compat "29.1.4.1")
    (seq "2.24"))
  :commit "5aa4b1ba389b9ad7a986f950ba3f99d11e1bbf97" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
