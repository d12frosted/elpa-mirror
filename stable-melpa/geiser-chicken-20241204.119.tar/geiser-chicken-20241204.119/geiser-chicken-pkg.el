;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-chicken" "20241204.119"
  "Chicken's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.19"))
  :url "https://gitlab.com/emacs-geiser/chicken"
  :commit "aa12be7f2412300cf16753fa341bd1dbe20c7ee2"
  :revdesc "aa12be7f2412"
  :keywords '("languages" "chicken" "scheme" "geiser"))
