(define-package "citar" "20211117.1736" "Citation-related commands for org, latex, markdown."
  '((emacs "27.1")
    (s "1.12")
    (parsebib "3.0")
    (org "9.5"))
  :commit "c50ae3d03b2ca72e374715987508420da27dee9c" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
