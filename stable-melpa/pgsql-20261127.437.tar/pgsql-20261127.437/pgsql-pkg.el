;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "20261127.437"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "593792c0c25a507beaf567e8b7640f66e31fb92c"
  :revdesc "593792c0c25a"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
