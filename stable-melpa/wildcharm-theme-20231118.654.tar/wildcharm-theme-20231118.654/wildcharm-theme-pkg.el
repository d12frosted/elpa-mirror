(define-package "wildcharm-theme" "20231118.654" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "de96c97539e9463517b0f80a08e9b1b1b478fd8c" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
