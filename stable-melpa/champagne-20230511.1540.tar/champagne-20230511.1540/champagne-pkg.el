(define-package "champagne" "20230511.1540" "Graphical countdowns"
  '((emacs "28.1")
    (posframe "1.4.2"))
  :commit "069452fa162d6aefc693c8d0546a84d967218289" :authors
  '(("Psionik K" . "73710933+psionic-k@users.noreply.github.com"))
  :maintainers
  '(("Psionik K" . "73710933+psionic-k@users.noreply.github.com"))
  :maintainer
  '("Psionik K" . "73710933+psionic-k@users.noreply.github.com")
  :keywords
  '("games")
  :url "http://github.com/positron-solutions/champagne")
;; Local Variables:
;; no-byte-compile: t
;; End:
