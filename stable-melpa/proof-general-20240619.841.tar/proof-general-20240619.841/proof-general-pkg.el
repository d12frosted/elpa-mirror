(define-package "proof-general" "20240619.841" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "0e0170f96f5feaeefe59052a08373080acc20393" :maintainers
  '((nil . "proof-general-maintainers@groupes.renater.fr"))
  :maintainer
  '(nil . "proof-general-maintainers@groupes.renater.fr")
  :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
