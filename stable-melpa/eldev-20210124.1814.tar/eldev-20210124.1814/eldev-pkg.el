(define-package "eldev" "20210124.1814" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "35232d98a612a1475190d611402f5af629c830fe" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
