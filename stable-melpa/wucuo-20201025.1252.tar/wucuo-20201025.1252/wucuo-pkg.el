(define-package "wucuo" "20201025.1252" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "b2be36f155a9d02795f27c7302e312ca50c7314f" :keywords
  ("convenience")
  :authors
  (("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  ("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
