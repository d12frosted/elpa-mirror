;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scheme-complete" "20241205.111"
  "Smart auto completion for Scheme in Emacs."
  ()
  :url "https://github.com/ashinn/scheme-complete"
  :commit "569277c0caa3edf8b28086b0efca6db4186184a8"
  :revdesc "569277c0caa3")
