;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-kill-extras" "20260107.827"
  "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :url "https://github.com/knu/easy-kill-extras.el"
  :commit "0e657c1d15985833b4cee4952c5c4dfe742ed37a"
  :revdesc "0e657c1d1598"
  :keywords '("killing" "convenience")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
