;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpx" "20251228.1347"
  "Major mode for GPX files."
  '((emacs "27.1"))
  :url "https://github.com/mkcms/gpx-mode"
  :commit "d97efb2c2701118f418c22ab1b6518bef0d79517"
  :revdesc "d97efb2c2701"
  :keywords '("data" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
