(define-package "el-get" "20210613.1418" "Manage the external elisp bits and pieces you depend upon" 'nil :commit "960f3fb962c35d3196bab20b2a3f6d6228119277" :authors
  '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainer
  '("Dimitri Fontaine" . "dim@tapoueh.org")
  :keywords
  '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :url "http://www.emacswiki.org/emacs/el-get")
;; Local Variables:
;; no-byte-compile: t
;; End:
