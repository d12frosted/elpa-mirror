(define-package "elfeed-web" "20191123.1738" "web interface to Elfeed"
  '((simple-httpd "1.5.1")
    (elfeed "3.2.0")
    (emacs "24.3"))
  :commit "7b2b6fadaa498fef2ba212a50da4a8afa2a5d305")
;; Local Variables:
;; no-byte-compile: t
;; End:
