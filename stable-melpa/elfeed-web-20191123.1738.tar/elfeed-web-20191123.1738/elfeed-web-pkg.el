(define-package "elfeed-web" "20191123.1738" "web interface to Elfeed"
  '((simple-httpd "1.5.1")
    (elfeed "3.2.0")
    (emacs "24.3"))
  :commit "2409681433e97cd4ee63dfa10f48b2be64d4321d")
;; Local Variables:
;; no-byte-compile: t
;; End:
