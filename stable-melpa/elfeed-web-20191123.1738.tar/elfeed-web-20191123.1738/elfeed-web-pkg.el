(define-package "elfeed-web" "20191123.1738" "web interface to Elfeed"
  '((simple-httpd "1.5.1")
    (elfeed "3.2.0")
    (emacs "24.3"))
  :commit "af15a212267c67775c134d180ad5635a6001baaa" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/elfeed")
;; Local Variables:
;; no-byte-compile: t
;; End:
