(define-package "elfeed-web" "20191123.1738" "web interface to Elfeed"
  '((simple-httpd "1.5.1")
    (elfeed "3.2.0")
    (emacs "24.3"))
  :commit "de4b64b3f5d9fd41d9dc72023632ae535dc912e2" :authors
  (("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  ("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/elfeed")
;; Local Variables:
;; no-byte-compile: t
;; End:
