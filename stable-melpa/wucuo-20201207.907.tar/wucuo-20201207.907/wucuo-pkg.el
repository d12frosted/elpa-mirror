(define-package "wucuo" "20201207.907" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "4ef50b621b93c0554c4a9e045df1d936ce925ad1" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
