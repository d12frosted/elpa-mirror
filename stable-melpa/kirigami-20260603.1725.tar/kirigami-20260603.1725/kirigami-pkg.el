;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260603.1725"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "5c098da619fbe07c23b1aad79ac6946bfb25c3aa"
  :revdesc "5c098da619fb"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
