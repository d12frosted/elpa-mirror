;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260415.1313"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "1cb4bb4bd54ce722003f8ebc3d73ee85511e96a5"
  :revdesc "1cb4bb4bd54c"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
