(define-package "aproject" "20190531.313" "Basic project framework for Emacs" 'nil :commit "702caf5392288dfd821b1e744fef0bb4fd9f9281" :authors
  '(("Vietor Liu" . "vietor.liu@gmail.com"))
  :maintainer
  '("Vietor Liu" . "vietor.liu@gmail.com")
  :keywords
  '("environment" "project")
  :url "https://github.com/vietor/aproject")
;; Local Variables:
;; no-byte-compile: t
;; End:
