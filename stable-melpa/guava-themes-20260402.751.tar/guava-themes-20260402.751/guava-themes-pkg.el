;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260402.751"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "fd68f1f0735e0f7d746d1762dcebd0076ed63910"
  :revdesc "fd68f1f0735e"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
