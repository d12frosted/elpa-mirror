;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base32" "20240227.1821"
  "Base32 support."
  '((emacs "27.1"))
  :url "https://gitlab.com/fledermaus/totp.el"
  :commit "927257e97a602b6979a75028e8417bf1499582d4"
  :revdesc "927257e97a60"
  :keywords '("tools")
  :authors '(("Vivek Das Mohapatra" . "vivek@etla.org"))
  :maintainers '(("Vivek Das Mohapatra" . "vivek@etla.org")))
