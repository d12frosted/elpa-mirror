;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "20260511.1435"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "30.1")
    (cond-let "0.2")
    (elx      "2.3")
    (llama    "1.0")
    (magit    "4.5"))
  :url "https://github.com/magit/sisyphus"
  :commit "de919359dc75ab79c5fe763f03664cf654548a87"
  :revdesc "de919359dc75"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
