;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-athena" "20250706.728"
  "Run AWS Athena queries from Org Babel."
  '((emacs "26.1"))
  :url "https://github.com/will-abb/aws-athena-babel"
  :commit "cc5a1970e68fae862c7641330858b3ee8c964bd4"
  :revdesc "cc5a1970e68f"
  :keywords '("aws" "athena" "org" "babel" "sql" "tools")
  :authors '(("Williams Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Williams Bosch-Bello" . "williamsbosch@gmail.com")))
