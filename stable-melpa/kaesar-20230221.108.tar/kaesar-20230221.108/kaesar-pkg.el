(define-package "kaesar" "20230221.108" "AES algorithm encrypt/decrypt"
  '((emacs "24.3")
    (kaesar-pbkdf2 "0.9.0"))
  :commit "75655238e0dcdb77a74d685cc4f3368fcd284020" :authors
  '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers
  '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainer
  '("Masahiro Hayashi" . "mhayashi1120@gmail.com")
  :keywords
  '("data")
  :url "https://github.com/mhayashi1120/Emacs-kaesar")
;; Local Variables:
;; no-byte-compile: t
;; End:
