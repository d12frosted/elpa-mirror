(define-package "corfu-candidate-overlay" "20230706.635" "Show first candidate in an overlay while typing"
  '((emacs "28.1")
    (corfu "0.36"))
  :commit "b1f83e3e7598d199c4691d56c768125c8cd2d157" :authors
  '(("Adam Kruszewski" . "adam@kruszewski.name"))
  :maintainers
  '(("Adam Kruszewski" . "adam@kruszewski.name"))
  :maintainer
  '("Adam Kruszewski" . "adam@kruszewski.name")
  :url "https://code.bsdgeek.org/adam/corfu-candidate-overlay/")
;; Local Variables:
;; no-byte-compile: t
;; End:
