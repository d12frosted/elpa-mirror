(define-package "haki-theme" "20230902.724" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "e7d6d5c16b66c1abf3d8aed3a1107300081c9e57" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
