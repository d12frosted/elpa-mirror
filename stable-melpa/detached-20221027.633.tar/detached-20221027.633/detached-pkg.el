(define-package "detached" "20221027.633" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "d0dc9d0f92acc90fe3123fc4d5a236f68370df8b" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
