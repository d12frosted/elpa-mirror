;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meta-presenter" "20210714.1658"
  "A simple multi-file presentation tool for Emacs."
  ()
  :url "http://ismail.teamfluxion.com"
  :commit "4ab48dacea245b223a0ffd2723ece746bd61c0af"
  :revdesc "4ab48dacea24"
  :keywords '("productivity" "presentation")
  :authors '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com"))
  :maintainers '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com")))
