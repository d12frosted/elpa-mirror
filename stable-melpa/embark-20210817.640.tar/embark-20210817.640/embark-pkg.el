(define-package "embark" "20210817.640" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "7c6172cd1578fb7711591cf890c10ed2234226bd" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
