(define-package "embark" "20210614.1716" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "17969d0cc9e3e6251ff929fa2a8a41a1c22895fe" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
