(define-package "vertica-snippets" "20230922.1258" "Yasnippets for Vertica"
  '((yasnippet "0.6.1"))
  :commit "2a0449975e0de19bf4ea9dd989d9c636cf083b97" :authors
  '(("Andreas Gerler" . "baron@bundesbrandschatzamt.de"))
  :maintainers
  '(("Andreas Gerler" . "baron@bundesbrandschatzamt.de"))
  :maintainer
  '("Andreas Gerler" . "baron@bundesbrandschatzamt.de")
  :keywords
  '("convenience" "snippets")
  :url "https://github.com/baron42bba/vertica-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
