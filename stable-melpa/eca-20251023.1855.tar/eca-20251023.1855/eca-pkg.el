;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251023.1855"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "bb4525cd2ed3ee1fbffa05e29559db4d1e01eb8e"
  :revdesc "bb4525cd2ed3"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
