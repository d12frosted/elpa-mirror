;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufshow" "20130726.1838"
  "A simple presentation tool for Emacs."
  '((emacs "24.1"))
  :url "https://github.com/pjones/bufshow"
  :commit "42d7fb74c3f914e127d5447c63d209bf19f5d517"
  :revdesc "42d7fb74c3f9"
  :authors '(("Peter Jones" . "pjones@pmade.com"))
  :maintainers '(("Peter Jones" . "pjones@pmade.com")))
