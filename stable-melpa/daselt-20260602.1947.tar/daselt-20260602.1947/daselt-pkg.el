;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260602.1947"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "bb5eab0bc21a0ea6bee9f21e1ce164cc50f3c33b"
  :revdesc "bb5eab0bc21a"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
