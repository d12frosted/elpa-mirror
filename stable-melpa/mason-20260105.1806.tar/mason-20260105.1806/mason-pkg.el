;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20260105.1806"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/deirn/mason.el"
  :commit "64f6842da0b4505e2ebfa0e2d980c1f1b1f969ea"
  :revdesc "64f6842da0b4"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
