;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260428.1754"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "b6392ac5ae91cc781bdad8e8a94bc81529117479"
  :revdesc "b6392ac5ae91"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
