;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250327.250"
  "Cache metadata on all Org files."
  '((emacs   "29.1")
    (el-job  "2.4.2")
    (emacsql "4.2.0")
    (llama   "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "9168e3d780104ef4b7028d778ff9a35e32b102a3"
  :revdesc "9168e3d78010"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
