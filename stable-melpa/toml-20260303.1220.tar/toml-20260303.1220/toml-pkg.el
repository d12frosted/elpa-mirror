;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260303.1220"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "59d3dd166c0ba95c51b9ccf57008bd367b4298aa"
  :revdesc "59d3dd166c0b"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
