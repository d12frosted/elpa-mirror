;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260414.1427"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a0b1283df47ccb57822ef9eb989f9c116396d0c6"
  :revdesc "a0b1283df47c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
