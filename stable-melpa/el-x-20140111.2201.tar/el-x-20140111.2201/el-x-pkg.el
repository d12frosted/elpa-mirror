(define-package "el-x" "20140111.2201" "main entry point for el-x package" 'nil :commit "e7c333d4fc31a90f4dca951efe21129164b42605" :keywords
  ("lisp")
  :authors
  (("Yann Hodique" . "yann.hodique@gmail.com"))
  :maintainer
  ("Yann Hodique" . "yann.hodique@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
