(define-package "tsc" "20210912.1211" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "4d9871d23999fe5f8de821e23c9ec576df2b2738" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
    ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
