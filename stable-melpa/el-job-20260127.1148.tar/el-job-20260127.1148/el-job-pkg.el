;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20260127.1148"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "c0751129c4d4f71b39c5f8bdd57090db11c15103"
  :revdesc "c0751129c4d4"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
