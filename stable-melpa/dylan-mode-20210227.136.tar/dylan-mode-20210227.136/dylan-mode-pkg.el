(define-package "dylan-mode" "20210227.136" "Major mode for the Dylan programming language. http://opendylan.org" 'nil :commit "f14633e400f6402c38bee1af5e65562fa8ade40e" :authors
  '(("Robert Stockton" . "rgs@cs.cmu.edu"))
  :maintainer
  '("Chris Page" . "cpage@opendylan.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
