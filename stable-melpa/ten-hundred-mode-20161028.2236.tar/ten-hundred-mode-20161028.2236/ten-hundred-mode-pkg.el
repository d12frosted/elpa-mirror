;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ten-hundred-mode" "20161028.2236"
  "Use only the ten hundred most usual words."
  '((cl-lib "0.5"))
  :url "https://github.com/aaron-em/ten-hundred-mode.el"
  :commit "bdcfda49b1819e82d61fe90947e50bb948cf7933"
  :revdesc "bdcfda49b181")
