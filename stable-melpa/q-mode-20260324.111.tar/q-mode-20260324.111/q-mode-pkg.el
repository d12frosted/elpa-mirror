;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260324.111"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "97f88225b8f3b2d085253f3c32bdc7eec69731ac"
  :revdesc "97f88225b8f3"
  :keywords '("faces" "files" "q"))
