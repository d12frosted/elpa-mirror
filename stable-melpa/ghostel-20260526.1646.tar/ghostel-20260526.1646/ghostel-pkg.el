;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260526.1646"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "48b389fc8145a9d6fc6cf443bfbb11c00ea240b3"
  :revdesc "48b389fc8145"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
