;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260422.744"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "d16aa9cf3e496aa9a6c20d73f4494e16feb4d092"
  :revdesc "d16aa9cf3e49"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
