;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-php" "20260920.444"
  "A company back-end for PHP."
  '((cl-lib      "0.5")
    (ac-php-core "2.0")
    (company     "0.9"))
  :url "https://github.com/xcwen/ac-php"
  :commit "0587d140a082701ee7d5e1b6bf80f2a1b80c9e34"
  :revdesc "0587d140a082"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
