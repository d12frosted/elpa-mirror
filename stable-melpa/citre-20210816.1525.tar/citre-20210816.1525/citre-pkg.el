(define-package "citre" "20210816.1525" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "871847cb56ece4bb1d45eded6f2133e89799a768" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
