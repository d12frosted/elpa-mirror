;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "20260612.1453"
  "Visually highlight the selected buffer."
  '((emacs "27.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "f2340e51faa9a0b1e04667f3c6bb2c6f37c3132b"
  :revdesc "f2340e51faa9"
  :keywords '("faces" "editing"))
