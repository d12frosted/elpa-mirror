;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260727.2040"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "04455dd3fa9871c0dcb53d367fad170e4f626d5e"
  :revdesc "04455dd3fa98")
