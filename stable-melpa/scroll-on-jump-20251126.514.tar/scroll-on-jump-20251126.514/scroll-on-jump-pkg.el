;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scroll-on-jump" "20251126.514"
  "Scroll when jumping to a new point."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-scroll-on-jump"
  :commit "ffb6fbfda84a80ce1f42bf2b2259e1e663e1d582"
  :revdesc "ffb6fbfda84a"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
