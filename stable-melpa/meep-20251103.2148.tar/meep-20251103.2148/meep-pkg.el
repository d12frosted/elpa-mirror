;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251103.2148"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "8de015a255398e5d20330f6c168a0c4c07fcca66"
  :revdesc "8de015a25539"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
