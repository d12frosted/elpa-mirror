;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260517.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "39b156f8f0231fb5d6461eb3e4f93374ca47dcb5"
  :revdesc "39b156f8f023"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
