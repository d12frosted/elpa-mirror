(define-package "gptel" "20230409.2002" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "c29e1cd673c432b8c3ead67318cc679e0c60305d" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
