;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "20260925.2149"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.4.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "335044dce7a4f89b12d0a12377d7adc248b3e797"
  :revdesc "335044dce7a4"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
