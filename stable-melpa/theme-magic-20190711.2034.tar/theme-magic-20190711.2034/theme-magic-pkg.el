;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "theme-magic" "20190711.2034"
  "Apply your Emacs theme to the rest of Linux."
  '((emacs "25")
    (seq   "1.8"))
  :url "https://github.com/jcaw/theme-magic.el"
  :commit "844c4311bd26ebafd4b6a1d72ddcc65d87f074e3"
  :revdesc "844c4311bd26"
  :keywords '("unix" "faces" "terminals" "extensions")
  :authors '(("GitHub user jcaw" . "40725916+jcaw@users.noreply.github.com"))
  :maintainers '(("GitHub user jcaw" . "40725916+jcaw@users.noreply.github.com")))
