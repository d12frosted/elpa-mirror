;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251030.529"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "51e067c9df68337407ec0009151f898689f9b26a"
  :revdesc "51e067c9df68"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
