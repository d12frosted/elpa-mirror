;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250916.2001"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "fe4b92563f76834ad7803c2350d4431a4000fd0b"
  :revdesc "fe4b92563f76"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
