;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evedel" "20250222.201"
  "Instructed LLM programmer/assistant."
  '((emacs "29.1")
    (gptel "0.9.0"))
  :url "https://github.com/daedsidog/evedel"
  :commit "636396058bb0816899e4fcdd8df08591a9ee25a0"
  :revdesc "636396058bb0"
  :keywords '("convenience" "tools")
  :authors '(("daedsidog" . "contact@daedsidog.com"))
  :maintainers '(("daedsidog" . "contact@daedsidog.com")))
