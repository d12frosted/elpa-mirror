;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-tools" "20251228.1714"
  "Support library for PDF documents."
  '((emacs     "26.3")
    (tablist   "1.0")
    (let-alist "1.0.4"))
  :url "http://github.com/vedang/pdf-tools/"
  :commit "0adc845fc2e0110dab0c7fc401a7bcf890d0610a"
  :revdesc "0adc845fc2e0"
  :keywords '("files" "multimedia")
  :authors '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainers '(("Vedang Manerikar" . "vedang.manerikar@gmail.com")))
