(define-package "for" "20220830.1324" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "408ccad777e8934b5fe3dd1e5769fe67867b87c5" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
