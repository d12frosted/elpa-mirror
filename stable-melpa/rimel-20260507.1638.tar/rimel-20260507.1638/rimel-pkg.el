;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260507.1638"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "a5b64b760c67b3886eb73248de9a806752b19685"
  :revdesc "a5b64b760c67"
  :keywords '("convenience" "chinese" "input-method" "rime"))
