(define-package "eldev" "20220212.1831" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "3455e612a3c1f96a639c803257e330219aed9d2d" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
