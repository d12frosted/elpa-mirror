(define-package "leaf-keywords" "20201204.1545" "Additional leaf.el keywords for external packages"
  '((emacs "24.4")
    (leaf "3.5.0"))
  :commit "ef29ef0ba8e0168f14e5255491c1668673269a37" :keywords
  ("lisp" "settings")
  :authors
  (("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  ("Naoya Yamashita" . "conao3@gmail.com")
  :url "https://github.com/conao3/leaf-keywords.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
