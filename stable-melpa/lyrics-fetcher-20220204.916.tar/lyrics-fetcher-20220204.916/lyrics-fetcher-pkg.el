(define-package "lyrics-fetcher" "20220204.916" "Fetch song lyrics and album covers"
  '((emacs "27")
    (emms "7.5")
    (f "0.20.0")
    (request "0.3.2"))
  :commit "f6948259b388102208d8a29dabf383f10f801cab" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/lyrics-fetcher.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
