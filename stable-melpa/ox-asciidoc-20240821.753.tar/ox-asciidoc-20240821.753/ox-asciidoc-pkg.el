(define-package "ox-asciidoc" "20240821.753" "AsciiDoc Back-End for Org Export Engine"
  '((org "8.1"))
  :commit "cec4555555e660413b509a204b9e40a86aa586ac" :authors
  '(("Yasushi SHOJI" . "yasushi.shoji@gmail.com"))
  :maintainers
  '(("Yasushi SHOJI" . "yasushi.shoji@gmail.com"))
  :maintainer
  '("Yasushi SHOJI" . "yasushi.shoji@gmail.com")
  :keywords
  '("org" "asciidoc")
  :url "https://github.com/yashi/org-asciidoc")
;; Local Variables:
;; no-byte-compile: t
;; End:
