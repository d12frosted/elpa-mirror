;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250405.1019"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "8e45bc97fb57db6bf7689765f7504f4dc7ec05d7"
  :revdesc "8e45bc97fb57"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
