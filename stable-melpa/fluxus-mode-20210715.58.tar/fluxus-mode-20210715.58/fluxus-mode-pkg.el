;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fluxus-mode" "20210715.58"
  "Major mode for interfacing with Fluxus."
  '((osc   "0.1")
    (emacs "24.4"))
  :url "https://github.com/defaultxr/fluxus-mode"
  :commit "a14578640c578a4fd09cb7e25da1e87d637719ae"
  :revdesc "a14578640c57"
  :keywords '("languages")
  :authors '(("modula t." . "defaultxr@gmail.com"))
  :maintainers '(("modula t." . "defaultxr@gmail.com")))
