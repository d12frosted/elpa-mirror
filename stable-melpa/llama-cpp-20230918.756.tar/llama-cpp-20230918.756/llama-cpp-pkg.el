(define-package "llama-cpp" "20230918.756" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "5072cc2a7ddd7516518fa68655c38b9cf7ab94d9" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
