;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-hist" "20251110.420"
  "Traverse Dired buffer's history: back, forward."
  '((emacs "27.1"))
  :url "https://codeberg.org/Anoncheg/dired-hist"
  :commit "49523ea2ed6c00980e11a0f47d14d55e4dd39721"
  :revdesc "49523ea2ed6c"
  :keywords '("convenience" "dired" "history")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
