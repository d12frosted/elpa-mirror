(define-package "embark" "20210911.37" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "3a90a3e3c6cd035503d0c9de5c22875028e6da00" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
