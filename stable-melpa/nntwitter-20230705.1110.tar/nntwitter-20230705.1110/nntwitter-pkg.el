;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nntwitter" "20230705.1110"
  "Gnus backend for twitter."
  ()
  :url "https://github.com/dickmao/nntwitter"
  :commit "e27acca9beeb6645dd13545d42f6d4d97d59d82c"
  :revdesc "e27acca9beeb"
  :keywords '("news")
  :authors '(("dickmao" . "githubid:dickmao"))
  :maintainers '(("dickmao" . "githubid:dickmao")))
