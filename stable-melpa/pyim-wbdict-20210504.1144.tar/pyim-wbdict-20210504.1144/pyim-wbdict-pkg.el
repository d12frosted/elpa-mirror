(define-package "pyim-wbdict" "20210504.1144" "Some wubi dicts for pyim"
  '((pyim "3.7"))
  :commit "da51e226bca9be2ed6175298489be64e45492759" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/tumashu/pyim-wbdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
