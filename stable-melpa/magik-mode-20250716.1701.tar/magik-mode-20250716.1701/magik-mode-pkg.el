;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250716.1701"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "4975fb402c323fc3e0595c957688e7c737644b16"
  :revdesc "4975fb402c32"
  :keywords '("languages"))
