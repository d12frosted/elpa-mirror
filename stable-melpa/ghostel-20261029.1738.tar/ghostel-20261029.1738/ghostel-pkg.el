;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261029.1738"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "2c13feaa31da8a55a0471210cd26414d7265ee1e"
  :revdesc "2c13feaa31da"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
