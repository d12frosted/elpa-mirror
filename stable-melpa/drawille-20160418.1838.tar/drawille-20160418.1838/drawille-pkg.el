(define-package "drawille" "20160418.1838" "Drawille implementation in elisp"
  '((cl-lib "0.5"))
  :commit "d582b455c01432bc80933650c52a1f586bd1b5ad" :authors
  '(("Josuah Demangeon" . "josuah.demangeon@gmail.com"))
  :maintainer
  '("Josuah Demangeon" . "josuah.demangeon@gmail.com")
  :keywords
  '("graphics")
  :url "https://github.com/sshbio/elisp-drawille")
;; Local Variables:
;; no-byte-compile: t
;; End:
