(define-package "blackjack" "20230522.32" "The game of Blackjack"
  '((emacs "26.2"))
  :commit "3303c23253c4c211db122a8d0a10fb07fa326f16" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
