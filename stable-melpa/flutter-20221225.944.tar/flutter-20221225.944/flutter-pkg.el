(define-package "flutter" "20221225.944" "Tools for working with Flutter SDK"
  '((emacs "25.1"))
  :commit "684f15ea19c4a7947eda945cb6e58a67baec8e90" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("languages")
  :url "https://github.com/amake/flutter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
