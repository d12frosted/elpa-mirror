(define-package "apdl-mode" "20211016.1627" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "84415afa621bc3599865c4aab20ea0921b3e7d22" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
