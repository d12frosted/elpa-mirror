;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261103.100"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ed847739aeadaff1a49ad1cf3c50aed9d1d56211"
  :revdesc "ed847739aead")
