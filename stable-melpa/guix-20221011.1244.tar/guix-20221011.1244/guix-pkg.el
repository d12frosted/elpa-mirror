(define-package "guix" "20221011.1244" "Interface for GNU Guix"
  '((emacs "24.3")
    (dash "2.11.0")
    (geiser "0.8")
    (bui "1.2.0")
    (magit-popup "2.1.0")
    (edit-indirect "0.1.4"))
  :commit "cf5b7a402ea503c3dcda85a86b9a6c6dd01896e0" :authors
  '(("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  '("Alex Kost" . "alezost@gmail.com")
  :keywords
  '("tools")
  :url "https://emacs-guix.gitlab.io/website/")
;; Local Variables:
;; no-byte-compile: t
;; End:
