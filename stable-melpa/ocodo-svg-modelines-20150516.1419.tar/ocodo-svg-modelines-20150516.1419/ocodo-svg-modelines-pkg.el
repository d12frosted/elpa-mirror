(define-package "ocodo-svg-modelines" "20150516.1419" "A collection of beautiful SVG modelines"
  '((svg-mode-line-themes "0"))
  :commit "a6c5b9a7536c7a8fa3bd9d9dafdebc8d99903018" :authors
  '(("ocodo" . "what.is.ocodo@gmail.com"))
  :maintainer
  '("ocodo" . "what.is.ocodo@gmail.com")
  :url "https://github.com/ocodo/ocodo-svg-modelines")
;; Local Variables:
;; no-byte-compile: t
;; End:
