(define-package "nordic-night-theme" "20230821.2226" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "ce1b9609ce6cfed83b4d3a28bca9d1ce703765db" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
