;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20251223.1103"
  "Consulting completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "41855bda5f0bc5050cdd602ecee75503ec58b959"
  :revdesc "41855bda5f0b"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
