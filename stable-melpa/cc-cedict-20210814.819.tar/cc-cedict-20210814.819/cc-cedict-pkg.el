(define-package "cc-cedict" "20210814.819" "Interface to CC-CEDICT (a Chinese-English dictionary)"
  '((emacs "26.1"))
  :commit "03fbe7d1589d36f627ef9fe7b86f9fe6f623cbb3" :authors
  '(("Xu Chunyang"))
  :maintainers
  '(("Xu Chunyang"))
  :maintainer
  '("Xu Chunyang")
  :url "https://github.com/xuchunyang/cc-cedict.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
