;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu" "20261022.44"
  "Undo helper with redo."
  '((emacs "25.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu"
  :commit "388cf4c19b51f9317d7a2504beb6e1a6505e2952"
  :revdesc "388cf4c19b51"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
