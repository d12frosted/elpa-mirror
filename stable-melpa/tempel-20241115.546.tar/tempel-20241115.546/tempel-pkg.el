;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20241115.546"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "6e0a0ed358344243c86433768cc857b205f336db"
  :revdesc "6e0a0ed35834"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
