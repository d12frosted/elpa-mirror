;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260118.840"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "4c0727811c9ed6ebe0cae57ccdc2d5ca563defc8"
  :revdesc "4c0727811c9e"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
