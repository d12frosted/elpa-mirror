(define-package "nand2tetris" "20171201.1813" "Major mode for HDL files in the nand2tetris course"
  '((emacs "24"))
  :commit "33acee34d24b1c6a87db833b7d23449cf858f64f" :authors
  '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainer
  '("Diego Berrocal" . "cestdiego@gmail.com")
  :keywords
  '("nand2tetris" "hdl")
  :url "http://www.github.com/CestDiego/nand2tetris.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
