(define-package "nand2tetris" "20171201.1813" "Major mode for HDL files in the nand2tetris course"
  '((emacs "24"))
  :commit "fe37ee41367ceff6f7d7a472a5f80cf1285e1e01" :authors
  '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainer
  '("Diego Berrocal" . "cestdiego@gmail.com")
  :keywords
  '("nand2tetris" "hdl")
  :url "http://www.github.com/CestDiego/nand2tetris.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
