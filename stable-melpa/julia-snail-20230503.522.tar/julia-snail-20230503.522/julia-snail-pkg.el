(define-package "julia-snail" "20230503.522" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (vterm "0.0.1")
    (popup "0.5.9"))
  :commit "5e22cf0badba469c7f4d2bd20682329823b4f151" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
