;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260209.2353"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "5543c920c9ddf2a7127fcc2ea8de1f84ad465bf4"
  :revdesc "5543c920c9dd"
  :keywords '("convenience"))
