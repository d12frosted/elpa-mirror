;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-run" "20200128.702"
  "Run arbitrary command in terminal buffer."
  ()
  :url "https://github.com/10sr/term-run-el"
  :commit "0fd135d55fcf864598b1fb8dd880833a1a322910"
  :revdesc "0fd135d55fcf"
  :keywords '("utility" "shell" "command" "term-mode")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
