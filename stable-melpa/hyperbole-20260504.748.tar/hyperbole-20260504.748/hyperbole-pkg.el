;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260504.748"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "4d87fdc635050bf8f65cc344a8812f1bc988e1e3"
  :revdesc "4d87fdc63505"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
