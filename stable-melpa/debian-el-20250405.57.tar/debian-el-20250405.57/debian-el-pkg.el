;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debian-el" "20250405.57"
  "Startup file for the debian-el package."
  ()
  :commit "1038cbc9f1b696888fc3499a49ca4bd3203c4f48"
  :revdesc "1038cbc9f1b6"
  :keywords '("debian" "apt" "elisp")
  :authors '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org"))
  :maintainers '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org")))
