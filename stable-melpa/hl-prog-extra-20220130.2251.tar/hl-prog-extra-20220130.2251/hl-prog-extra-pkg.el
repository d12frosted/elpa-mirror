(define-package "hl-prog-extra" "20220130.2251" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "eee903f4f87c02ca59a47c5312fffc80c36b789f" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
