;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lgr" "20261105.1052"
  "A fully featured logging framework."
  '((emacs "26.1"))
  :url "https://github.com/Fuco1/emacs-lgr"
  :commit "2fe1f53b1904a360382969fc975dccb1ca0d823d"
  :revdesc "2fe1f53b1904"
  :keywords '("tools")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
