(define-package "diredc" "20240122.1053" "Extensions for dired"
  '((emacs "26.1")
    (key-assist "1.0"))
  :commit "ad3297da14b9487dad27f0c7828c5b832e7f02a5" :keywords
  '("files")
  :url "https://github.com/Boruch-Baum/emacs-diredc")
;; Local Variables:
;; no-byte-compile: t
;; End:
