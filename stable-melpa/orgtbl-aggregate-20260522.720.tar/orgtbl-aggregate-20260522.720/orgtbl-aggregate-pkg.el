;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260522.720"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "25de9ac509a7ec6dbe91af8fbb4701c2cffe2df1"
  :revdesc "25de9ac509a7"
  :keywords '("data" "extensions"))
