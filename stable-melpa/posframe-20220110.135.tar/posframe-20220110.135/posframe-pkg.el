(define-package "posframe" "20220110.135" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "936e9aa9cf87be52793d78d302ad822054dc50b4" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
