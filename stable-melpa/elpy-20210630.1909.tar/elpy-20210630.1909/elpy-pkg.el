(define-package "elpy" "20210630.1909" "Emacs Python Development Environment"
  '((company "0.9.2")
    (emacs "24.4")
    (highlight-indentation "0.5.0")
    (pyvenv "1.3")
    (yasnippet "0.8.0")
    (s "1.11.0"))
  :commit "26b4ace21553011800fb138db286221f1686eff4" :authors
  '(("Jorgen Schaefer <contact@jorgenschaefer.de>, Gaby Launay" . "gaby.launay@protonmail.com"))
  :maintainer
  '("Jorgen Schaefer <contact@jorgenschaefer.de>, Gaby Launay" . "gaby.launay@protonmail.com")
  :keywords
  '("python" "ide" "languages" "tools")
  :url "https://github.com/jorgenschaefer/elpy")
;; Local Variables:
;; no-byte-compile: t
;; End:
