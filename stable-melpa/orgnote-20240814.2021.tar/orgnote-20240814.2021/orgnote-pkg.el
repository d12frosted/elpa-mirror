;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgnote" "20240814.2021"
  "Sync org-roam notes with OrgNote app."
  '((emacs "27.1"))
  :url "https://github.com/Artawower/orgnote.el"
  :commit "d2d0c8d16ea2dbcc29b79f9d4a48e03e90c3f57d"
  :revdesc "d2d0c8d16ea2"
  :authors '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers '(("Artur Yaroshenko" . "artawower@protonmail.com")))
