(define-package "enotify" "20120207.1927" "No description available." 'nil :commit "75c84b53703e5d52cb18acc9251b87ffa400f388")
;; Local Variables:
;; no-byte-compile: t
;; End:
