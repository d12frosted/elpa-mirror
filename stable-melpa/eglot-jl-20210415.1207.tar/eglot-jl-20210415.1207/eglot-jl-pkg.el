(define-package "eglot-jl" "20210415.1207" "Julia support for eglot"
  '((emacs "25.1")
    (eglot "1.4")
    (julia-mode "0.3"))
  :commit "49f170e01c5a107c2cb662c00544d827eaa2c4d8" :authors
  '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz"))
  :maintainer
  '("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/non-Jedi/eglot-jl")
;; Local Variables:
;; no-byte-compile: t
;; End:
