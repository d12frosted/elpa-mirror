;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-inactive-region" "20260115.1215"
  "Highlight the inactive region."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-show-inactive-region"
  :commit "e5e5db361ee93da72d96f2cc3d7c1c5bf52fbb96"
  :revdesc "e5e5db361ee9"
  :keywords '("convenience" "faces")
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
