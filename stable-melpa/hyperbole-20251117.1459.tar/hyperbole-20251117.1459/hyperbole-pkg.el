;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251117.1459"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "3b7b755a596afe231a5bf44e44aa78b407e7d560"
  :revdesc "3b7b755a596a"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
