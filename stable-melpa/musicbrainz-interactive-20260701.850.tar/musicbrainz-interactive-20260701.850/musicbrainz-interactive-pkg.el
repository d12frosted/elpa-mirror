;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "musicbrainz-interactive" "20260701.850"
  "Interactive commands for MusicBrainz related things."
  '((emacs       "28.1")
    (musicbrainz "0.1"))
  :url "https://github.com/zzkt/metabrainz"
  :commit "13b03ebd6fc6deb6f5d8655cd4ca09fe2680be16"
  :revdesc "13b03ebd6fc6"
  :keywords '("data" "convenience" "music")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
