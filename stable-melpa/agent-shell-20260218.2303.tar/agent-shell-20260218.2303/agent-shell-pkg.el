;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260218.2303"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.10.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d64a220af589a9c0c53cd822ab49c28e725e518b"
  :revdesc "d64a220af589")
