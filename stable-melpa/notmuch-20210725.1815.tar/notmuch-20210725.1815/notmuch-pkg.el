(define-package "notmuch" "20210725.1815" "run notmuch within emacs" 'nil :commit "b649b0c871e7fbfcd15a24d51b071bad2680e5d2" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
