;;; hackernews-modern-edit.el --- Edit and delete own comments in hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Editing and deleting your own comments for hackernews-modern.
;; Hacker News only allows it for a while after posting, so the
;; buttons are shown only while the website offers them.

;;; Code:

(require 'hackernews-modern-core)
(require 'hackernews-modern-account)
(require 'hackernews-modern-reply)
(require 'hackernews-modern-submit)
(require 'cl-lib)
(require 'subr-x)

(declare-function hackernews-modern--display-comments "hackernews-modern-comments" (buffer items))
(declare-function hackernews-modern--get "hackernews-modern" (prop))
(declare-function hackernews-modern--put "hackernews-modern" (prop val))

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern--editable (make-hash-table)
  "Hash table mapping item IDs to the links to edit or delete them.
Each value is a plist with the user it was read for (:user) and the
paths of the edit (:edit) and delete (:delete) pages.  The website
only shows these links while an item can still be changed.")

(defvar-local hackernews-modern--edit-id nil
  "ID of the comment edited in the current edit buffer.")

(defvar-local hackernews-modern--edit-form nil
  "Edit form of the comment of the current edit buffer.")

(defvar-local hackernews-modern--edit-original nil
  "Text of the comment when the current edit buffer was opened.")

(defun hackernews-modern--edit-entry (id)
  "Return the edit plist of item ID for the logged in user, or nil."
  (let ((entry (gethash id hackernews-modern--editable)))
    (and (equal (plist-get entry :user) (hackernews-modern--current-user))
         entry)))

(defun hackernews-modern--read-edit-links (body)
  "Store the edit and delete links of the items in page BODY."
  (let ((user (hackernews-modern--current-user))
        (pos  0))
    (while (string-match
            "<a[ \t][^>]*href=['\"]\\(\\(edit\\|delete-confirm\\)\\?id=\\([0-9]+\\)[^'\"]*\\)['\"]"
            body pos)
      (setq pos (match-end 0))
      (let* ((id    (string-to-number (match-string 3 body)))
             (key   (if (equal (match-string 2 body) "edit") :edit :delete))
             (path  (hackernews-modern--decode-entities (match-string 1 body)))
             (entry (hackernews-modern--edit-entry id)))
        (puthash id (plist-put (plist-put entry :user user) key path)
                 hackernews-modern--editable)))))

(defun hackernews-modern--page-form (body action)
  "Return the form of page BODY whose action contains ACTION, or nil.
The result is a plist with the path the form is sent to (:action),
its hidden fields and confirmation button as (NAME VALUE) pairs
\(:fields), its text fields as (NAME . VALUE) pairs (:values) and
the contents of its text area (:text)."
  (when (and body
             (string-match (format "<form[^>]*action=['\"]/?\\([^'\"]*%s[^'\"]*\\)['\"][^>]*>"
                                   (regexp-quote action))
                           body))
    (let* ((path   (hackernews-modern--decode-entities (match-string 1 body)))
           (start  (match-end 0))
           (end    (or (string-match "</form>" body start) (length body)))
           (form   (substring body start end))
           (pos    0)
           (fields '())
           (values '())
           text)
      (while (string-match "<input[^>]*>" form pos)
        (setq pos (match-end 0))
        (let* ((tag   (match-string 0 form))
               (type  (downcase (or (hackernews-modern--tag-attribute tag "type") "")))
               (name  (hackernews-modern--tag-attribute tag "name"))
               (value (or (hackernews-modern--tag-attribute tag "value") "")))
          (cond
           ((null name))
           ((or (equal type "hidden")
                (and (equal type "submit") (equal value "Yes")))
            (push (list name value) fields))
           ((member type '("" "text" "url"))
            (push (cons name value) values)))))
      (when (string-match "<textarea[^>]*>\\([^<]*\\)</textarea>" form)
        (setq text (string-trim (hackernews-modern--decode-entities
                                 (match-string 1 form)))))
      (list :action path :fields (nreverse fields) :values (nreverse values)
            :text text))))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--insert-edit-buttons (id)
  "Insert the buttons that edit and delete comment ID.
Only the actions the website still offers are shown."
  (let ((entry (hackernews-modern--edit-entry id)))
    (when (plist-get entry :edit)
      (insert " ")
      (widget-create 'push-button
                     :notify (lambda (&rest _) (hackernews-modern--edit id))
                     :help-echo "Edit your comment"
                     :format "%[%v%]"
                     "edit"))
    (when (plist-get entry :delete)
      (insert " ")
      (widget-create 'push-button
                     :notify (lambda (&rest _) (hackernews-modern--delete id))
                     :help-echo "Delete your comment"
                     :format "%[%v%]"
                     "delete"))))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern-edit-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-c") #'hackernews-modern-edit-send)
    (define-key map (kbd "C-c C-k") #'hackernews-modern-edit-cancel)
    map)
  "Keymap used in hackernews-modern edit buffer.")

(define-derived-mode hackernews-modern-edit-mode hackernews-modern-reply-mode "HN Edit"
  "Mode for editing a Hacker News comment.

Change the text below the separator line.  The formatting is the
same as when replying.

\\<hackernews-modern-edit-mode-map>
\\[hackernews-modern-edit-send]	Save the changes.
\\[hackernews-modern-edit-cancel]	Cancel.

\\{hackernews-modern-edit-mode-map}"
  :interactive nil)

(defun hackernews-modern--redisplay-comments (buffer)
  "Render comments BUFFER again from its items."
  (when (buffer-live-p buffer)
    (hackernews-modern--display-comments
     buffer (buffer-local-value 'hackernews-modern--comments-items buffer))))

(defun hackernews-modern--edit-expired (id buffer what)
  "Forget the edit links of ID, redraw comments BUFFER and explain it.
WHAT is the action that is no longer allowed."
  (remhash id hackernews-modern--editable)
  (hackernews-modern--redisplay-comments buffer)
  (message "Hacker News no longer allows to %s this item" what))

(defun hackernews-modern--edit (id)
  "Open a buffer to edit item ID of the current comments buffer.
The item is a comment or the story of the buffer."
  (let ((comments (current-buffer)))
    (when (< id 0)
      (user-error "Reload the comments before editing this comment"))
    (hackernews-modern--with-login
     (lambda ()
       (message "Opening comment...")
       (hackernews-modern--site-request
        (or (plist-get (hackernews-modern--edit-entry id) :edit)
            (format "edit?id=%s" id))
        (lambda (body _redirect)
          (let ((form (hackernews-modern--page-form body "xedit")))
            (cond
             ((assoc "title" (plist-get form :values))
              (hackernews-modern--edit-story-open comments id form))
             ((plist-get form :text)
              (hackernews-modern--edit-open comments id form))
             (t
              (hackernews-modern--edit-expired id comments "edit"))))))))))

(defun hackernews-modern--edit-open (comments id form)
  "Open the buffer to edit comment ID of COMMENTS with its edit FORM."
  (let ((buffer (get-buffer-create "*HN edit*")))
    (with-current-buffer buffer
      (let ((inhibit-read-only t))
        (erase-buffer))
      (hackernews-modern-edit-mode)
      (setq hackernews-modern--edit-id id)
      (setq hackernews-modern--edit-form form)
      (setq hackernews-modern--edit-original (plist-get form :text))
      (setq hackernews-modern--reply-comments-buffer comments)
      (let ((inhibit-read-only t))
        (insert "Editing your comment\n")
        (insert (substitute-command-keys
                 (concat "\\<hackernews-modern-edit-mode-map>"
                         "\\[hackernews-modern-edit-send] save · "
                         "\\[hackernews-modern-edit-cancel] cancel · "
                         "blank line = paragraph, 2 spaces = code, "
                         "*text* = italic\n")))
        (insert (make-string 72 ?─) "\n")
        (add-text-properties (point-min) (point)
                             '(read-only t face shadow
                                         front-sticky (read-only)
                                         rear-nonsticky (read-only face))))
      (setq hackernews-modern--reply-body-start (point-marker))
      (insert hackernews-modern--edit-original)
      (set-buffer-modified-p nil))
    (pop-to-buffer buffer '((display-buffer-below-selected)
                            (window-height . 0.4)))
    (goto-char (point-max))
    (message nil)))

(defun hackernews-modern-edit-cancel ()
  "Discard the changes to the comment."
  (declare (modes hackernews-modern-edit-mode))
  (interactive)
  (when (or (equal (hackernews-modern--reply-text) hackernews-modern--edit-original)
            (y-or-n-p "Discard your changes? "))
    (quit-window t)))

(defun hackernews-modern-edit-send ()
  "Save the changes to the comment on Hacker News."
  (declare (modes hackernews-modern-edit-mode))
  (interactive)
  (let* ((buffer   (current-buffer))
         (text     (hackernews-modern--reply-text))
         (id       hackernews-modern--edit-id)
         (form     hackernews-modern--edit-form)
         (comments hackernews-modern--reply-comments-buffer))
    (when (string-empty-p text)
      (user-error "The comment is empty, delete it instead"))
    (if (equal text hackernews-modern--edit-original)
        (progn
          (quit-window t)
          (message "No changes"))
      (hackernews-modern--save-edit buffer comments id form text))))

(defun hackernews-modern--save-edit (buffer comments id form text)
  "Send edit FORM of comment ID with TEXT, written in edit BUFFER.
On success, close BUFFER and show TEXT in COMMENTS."
  (message "Saving comment...")
  (hackernews-modern--site-request
   (plist-get form :action)
   (lambda (body redirect)
     (if (not (hackernews-modern--sent-p redirect))
         (message "Comment not edited: %s"
                  (if redirect
                      "the form expired, try again"
                    (hackernews-modern--page-message body)))
       (hackernews-modern--quit-buffer buffer)
       (when (buffer-live-p comments)
         (let ((item (gethash id (buffer-local-value 'hackernews-modern--comments-items
                                                     comments))))
           (when item
             (setcdr (assq 'text item) (hackernews-modern--text-to-html text))
             (hackernews-modern--redisplay-comments comments))))
       (message "Comment edited")))
   (append (plist-get form :fields) `(("text" ,text)))))

(defun hackernews-modern--delete (id)
  "Delete item ID of the current comments buffer after confirming.
The item is a comment or the story of the buffer."
  (let ((comments (current-buffer))
        (story    hackernews-modern--comments-id))
    (when (< id 0)
      (user-error "Reload the comments before deleting this comment"))
    (when (y-or-n-p (if (eql id story)
                        "Delete this story permanently? "
                      "Delete this comment permanently? "))
      (hackernews-modern--with-login
       (lambda ()
         (message "Deleting comment...")
         (hackernews-modern--site-request
          (or (plist-get (hackernews-modern--edit-entry id) :delete)
              (format "delete-confirm?id=%s&goto=%s"
                      id (url-hexify-string (format "item?id=%s" story))))
          (lambda (body _redirect)
            (let ((form (hackernews-modern--page-form body "xdelete")))
              (if form
                  (hackernews-modern--delete-send comments id form)
                (hackernews-modern--edit-expired id comments "delete"))))))))))

(defun hackernews-modern--delete-send (comments id form)
  "Send the delete FORM of item ID and update COMMENTS."
  (hackernews-modern--site-request
   (plist-get form :action)
   (lambda (body redirect)
     (cond
      ((not (hackernews-modern--sent-p redirect))
       (message "Not deleted: %s"
                (if redirect
                    "the form expired, try again"
                  (hackernews-modern--page-message body))))
      ((and (buffer-live-p comments)
            (eql id (buffer-local-value 'hackernews-modern--comments-id comments)))
       (remhash id hackernews-modern--editable)
       (hackernews-modern--quit-buffer comments)
       (hackernews-modern--update-stories
        (lambda (shown)
          (seq-remove (lambda (item) (eql (cdr (assq 'id item)) id)) shown)))
       (message "Story deleted"))
      (t
       (remhash id hackernews-modern--editable)
       (when (buffer-live-p comments)
         (with-current-buffer comments
           (let ((item  (gethash id hackernews-modern--comments-items))
                 (story (gethash hackernews-modern--comments-id
                                 hackernews-modern--comments-items)))
             (when item
               (setcdr (assq 'deleted item) t)
               (setcdr (assq 'descendants story)
                       (max 0 (1- (or (cdr (assq 'descendants story)) 1))))))
           (hackernews-modern--redisplay-comments comments)))
       (message "Comment deleted"))))
   (plist-get form :fields)))

(defun hackernews-modern--update-stories (function)
  "Replace the stories shown in every story list with FUNCTION.
FUNCTION receives the list of shown items and returns the new one.
The lists are redrawn afterwards."
  (dolist (buffer (buffer-list))
    (with-current-buffer buffer
      (when (derived-mode-p 'hackernews-modern-mode)
        (hackernews-modern--put :shown (funcall function (hackernews-modern--get :shown)))
        (hackernews-modern--redraw hackernews-modern--redraw-function)))))

(defun hackernews-modern--set-item-field (item key value)
  "Set KEY of ITEM, an alist, to VALUE."
  (let ((cell (assq key item)))
    (if cell
        (setcdr cell value)
      (nconc item (list (cons key value))))))

(defvar hackernews-modern-edit-story-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-c") #'hackernews-modern-edit-story-send)
    (define-key map (kbd "C-c C-k") #'hackernews-modern-edit-story-cancel)
    map)
  "Keymap used in hackernews-modern story edit buffer.")

(define-derived-mode hackernews-modern-edit-story-mode hackernews-modern-submit-mode
  "HN Edit Story"
  "Mode for editing a Hacker News story.

Change the title, the URL or, in stories without URL, the text.

\\<hackernews-modern-edit-story-mode-map>
\\[hackernews-modern-edit-story-send]	Save the changes.
\\[hackernews-modern-edit-story-cancel]	Cancel.
\\[hackernews-modern-submit-fetch-title]	Use the title of the page at the URL.

\\{hackernews-modern-edit-story-mode-map}"
  :interactive nil)

(defun hackernews-modern--edit-story-values ()
  "Return the title, URL and text of the current story edit buffer."
  (let ((form hackernews-modern--edit-form))
    (list (hackernews-modern--submit-field 'title)
          (and (assoc "url" (plist-get form :values))
               (hackernews-modern--submit-field 'url))
          (and (plist-get form :text)
               (hackernews-modern--submit-text)))))

(defun hackernews-modern--edit-story-open (comments id form)
  "Open the buffer to edit story ID of COMMENTS with its edit FORM."
  (let* ((buffer (get-buffer-create "*HN edit story*"))
         (values (plist-get form :values))
         title-end)
    (with-current-buffer buffer
      (let ((inhibit-read-only t))
        (erase-buffer))
      (hackernews-modern-edit-story-mode)
      (setq hackernews-modern--edit-id id)
      (setq hackernews-modern--edit-form form)
      (setq hackernews-modern--reply-comments-buffer comments)
      (setq title-end
            (hackernews-modern--insert-story-form
             (concat "Editing your story\n"
                     (substitute-command-keys
                      (concat "\\<hackernews-modern-edit-story-mode-map>"
                              "\\[hackernews-modern-edit-story-send] save · "
                              "\\[hackernews-modern-edit-story-cancel] cancel · "
                              "\\[hackernews-modern-submit-fetch-title] "
                              "fetch title from URL\n")))
             (cdr (assoc "title" values))
             (cdr (assoc "url" values))
             (plist-get form :text)))
      (setq hackernews-modern--edit-original (hackernews-modern--edit-story-values)))
    (pop-to-buffer buffer '((display-buffer-below-selected)
                            (window-height . 0.4)))
    (goto-char title-end)
    (message nil)))

(defun hackernews-modern-edit-story-cancel ()
  "Discard the changes to the story."
  (declare (modes hackernews-modern-edit-story-mode))
  (interactive)
  (when (or (equal (hackernews-modern--edit-story-values) hackernews-modern--edit-original)
            (y-or-n-p "Discard your changes? "))
    (quit-window t)))

(defun hackernews-modern-edit-story-send ()
  "Save the changes to the story on Hacker News."
  (declare (modes hackernews-modern-edit-story-mode))
  (interactive)
  (pcase-let ((`(,title ,url ,text) (hackernews-modern--edit-story-values)))
    (hackernews-modern--check-story title (or url "") (or text "") url)
    (if (equal (list title url text) hackernews-modern--edit-original)
        (progn
          (quit-window t)
          (message "No changes"))
      (hackernews-modern--save-story (current-buffer) title url text))))

(defun hackernews-modern--save-story (buffer title url text)
  "Send the TITLE, URL and TEXT of story edit BUFFER.
URL and TEXT are nil when the story has no such fields.  On
success, close BUFFER and show the changes in the story lists and
the comments buffer."
  (let ((id       (buffer-local-value 'hackernews-modern--edit-id buffer))
        (form     (buffer-local-value 'hackernews-modern--edit-form buffer))
        (comments (buffer-local-value 'hackernews-modern--reply-comments-buffer buffer)))
    (message "Saving story...")
    (hackernews-modern--site-request
     (plist-get form :action)
     (lambda (body redirect)
       (if (not (hackernews-modern--sent-p redirect))
           (message "Story not edited: %s"
                    (if redirect
                        "the form expired, try again"
                      (hackernews-modern--page-message body)))
         (hackernews-modern--quit-buffer buffer)
         (let ((update (lambda (item)
                         (when (eql (cdr (assq 'id item)) id)
                           (hackernews-modern--set-item-field item 'title title)
                           (when url
                             (hackernews-modern--set-item-field
                              item 'url (unless (string-empty-p url) url)))
                           (when text
                             (hackernews-modern--set-item-field
                              item 'text (hackernews-modern--text-to-html text)))))))
           (when (buffer-live-p comments)
             (let ((story (gethash id (buffer-local-value 'hackernews-modern--comments-items
                                                          comments))))
               (when story
                 (funcall update story)
                 (hackernews-modern--redisplay-comments comments))))
           (hackernews-modern--update-stories
            (lambda (shown) (mapc update shown) shown)))
         (message "Story edited")))
     (append (plist-get form :fields)
             `(("title" ,title))
             (when url `(("url" ,url)))
             (when text `(("text" ,text)))))))

(defun hackernews-modern--adopt-comment (comments local-id)
  "Give the comment LOCAL-ID just posted in COMMENTS its real ID.
A comment is shown with a temporary negative ID until the API
includes it.  The real ID and its edit links are read from the
list of comments of the user, so that it can be edited right away."
  (hackernews-modern--site-request
   (format "threads?id=%s" (hackernews-modern--current-user))
   (lambda (body _redirect)
     (when body
       (hackernews-modern--read-edit-links body))
     (when (and body
                (buffer-live-p comments)
                (string-match "class=['\"]athing comtr['\"] id=['\"]\\([0-9]+\\)['\"]" body))
       (let* ((id    (string-to-number (match-string 1 body)))
              (items (buffer-local-value 'hackernews-modern--comments-items comments))
              (item  (gethash local-id items)))
         (when (and item (not (gethash id items)))
           (setcdr (assq 'id item) id)
           (remhash local-id items)
           (puthash id item items)
           (maphash (lambda (_ other)
                      (let ((kids (assq 'kids other)))
                        (when (memql local-id (cdr kids))
                          (setcdr kids (cl-substitute id local-id (cdr kids))))))
                    items)
           (hackernews-modern--redisplay-comments comments)))))))

(provide 'hackernews-modern-edit)

;;; hackernews-modern-edit.el ends here
