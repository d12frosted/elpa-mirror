;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-web-track" "20250112.1253"
  "Web data tracking framework in Org Mode."
  '((emacs   "29.1")
    (request "0.3.0")
    (enlive  "0.0.1")
    (gnuplot "0.8.1"))
  :url "https://github.com/p-snow/org-web-track"
  :commit "f77e80fb258306559b7cc72ff7c041e8095bab1b"
  :revdesc "f77e80fb2583"
  :keywords '("org" "agenda" "web" "hypermedia")
  :authors '(("p-snow" . "public@p-snow.org"))
  :maintainers '(("p-snow" . "public@p-snow.org")))
