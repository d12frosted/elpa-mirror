(define-package "titlecase" "20220427.1552" "Title-case phrases"
  '((emacs "25.1"))
  :commit "b56c2e3409b46c615d63c7637e04875f58d257db" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://github.com/duckwork/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
