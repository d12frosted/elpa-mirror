(define-package "mini-echo" "20231129.342" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "e91729806c7f70f6f173d2763aba686411a24137" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
