(define-package "kubernetes" "20210614.2314" "Magit-like porcelain for Kubernetes."
  '((emacs "25.1")
    (dash "2.12.0")
    (magit "2.8.0")
    (magit-popup "2.13.0"))
  :commit "cf742bc89133dab46d8625aaad7b1c369a67bb2d" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool"))
;; Local Variables:
;; no-byte-compile: t
;; End:
