;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "20260731.2304"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "31.0")
    (cond-let "1.1")
    (elx      "2.3")
    (llama    "1.0")
    (magit    "4.7"))
  :url "https://github.com/magit/sisyphus"
  :commit "aa195ae52cfca9af93c319d006d0ae8012c02de5"
  :revdesc "aa195ae52cfc"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
