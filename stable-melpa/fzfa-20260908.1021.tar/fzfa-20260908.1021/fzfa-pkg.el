;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260908.1021"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.7"))
  :url "https://github.com/jojojames/fzfa"
  :commit "634af1321992520c1dd7923ad7f233bc1aa70d9a"
  :revdesc "634af1321992"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
