;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boa-ide" "20230813.2036"
  "Mode for boa language files."
  '((boa-mode      "1.4.4")
    (emacs         "28.1")
    (json-snatcher "1.0")
    (json-mode     "0.2")
    (project       "0.8.1"))
  :url "https://github.com/boalang/syntax-highlight"
  :commit "e1f960ada937be747ea2ec302bea155092e5c06b"
  :revdesc "e1f960ada937"
  :keywords '("languages")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
