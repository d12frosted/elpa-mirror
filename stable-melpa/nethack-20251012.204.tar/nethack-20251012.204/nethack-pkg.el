;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20251012.204"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "53e6a0a304bedfcca3a8a16a142614d4d9fcfddc"
  :revdesc "53e6a0a304be"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
