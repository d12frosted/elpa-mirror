;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "20260902.356"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "b277a4f3cfce978a2721645e03bb39938be6522c"
  :revdesc "b277a4f3cfce"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
