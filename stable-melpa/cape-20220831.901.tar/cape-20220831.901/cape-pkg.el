(define-package "cape" "20220831.901" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "3ccb3bbd6633e63444de3112a50a6b0f18d8122b" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
