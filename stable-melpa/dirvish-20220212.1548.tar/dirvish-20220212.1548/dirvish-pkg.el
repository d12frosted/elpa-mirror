(define-package "dirvish" "20220212.1548" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "17c434783ff8eb4e3546ec731284717391a1cad1" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
