(define-package "embark" "20211012.1921" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "3fe6703caa871d60aa4e87a19b3f5e07f2e16190" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
