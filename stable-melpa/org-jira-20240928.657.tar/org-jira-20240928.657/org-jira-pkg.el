(define-package "org-jira" "20240928.657" "Syncing between Jira and Org-mode"
  '((emacs "24.5")
    (cl-lib "0.5")
    (request "0.2.0")
    (dash "2.14.1"))
  :commit "91f11404b7c6f880d85d18f709322cf95850ce3f" :maintainers
  '(("Matthew Carter" . "m@ahungry.com"))
  :maintainer
  '("Matthew Carter" . "m@ahungry.com")
  :keywords
  '("ahungry" "jira" "org" "bug" "tracker")
  :url "https://github.com/ahungry/org-jira")
;; Local Variables:
;; no-byte-compile: t
;; End:
