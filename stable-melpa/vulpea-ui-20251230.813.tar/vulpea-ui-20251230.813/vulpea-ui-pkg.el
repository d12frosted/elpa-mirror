;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20251230.813"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.0.0")
    (vui    "0.1"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "39c842e47bd523b5cc37a13838277b3154fed920"
  :revdesc "39c842e47bd5"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
