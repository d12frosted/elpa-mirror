(define-package "osm" "20231222.2044" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "1036a272cec384409a42a6d02ad716083f3517b9" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
