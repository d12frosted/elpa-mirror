;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250604.851"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "868c992c382955eb07db985e0b2cc9f152076125"
  :revdesc "868c992c3829"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
