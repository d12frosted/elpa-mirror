;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260517.1657"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "9fb41b3c25b34ffe20b304d752aba1016a081e6d"
  :revdesc "9fb41b3c25b3"
  :keywords '("languages" "lisp" "slime"))
