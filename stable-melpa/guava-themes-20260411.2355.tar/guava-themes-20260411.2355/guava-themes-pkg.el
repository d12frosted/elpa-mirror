;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260411.2355"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "d8943ab916a43d8955ce8bb7f23ce9702065431e"
  :revdesc "d8943ab916a4"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
