;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20241019.614"
  "Minor mode for making Anki cards with Org."
  '((emacs "25.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "13cf87e34150d71daf20d432ac634e9c17178902"
  :revdesc "13cf87e34150")
