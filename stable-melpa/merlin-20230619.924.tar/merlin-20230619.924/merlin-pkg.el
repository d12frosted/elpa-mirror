(define-package "merlin" "20230619.924" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "a69ec38ddf712ef56d9b18d87b44c31b24509003" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainers
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
