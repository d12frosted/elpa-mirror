;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-yamllint" "20230226.1024"
  "YAML linter with yamllint."
  '((emacs "26.1"))
  :url "https://github.com/shaohme/flymake-yamllint"
  :commit "020d2a33568c8069801db9dd6992b8961a58de8d"
  :revdesc "020d2a33568c"
  :authors '(("Martin Kjær Jørgensen" . "mkj@gotu.dk"))
  :maintainers '(("Martin Kjær Jørgensen" . "mkj@gotu.dk")))
