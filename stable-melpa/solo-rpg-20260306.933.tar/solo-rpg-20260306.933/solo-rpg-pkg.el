;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solo-rpg" "20260306.933"
  "Solo roleplaying games support functions."
  '((emacs     "27.1")
    (transient "0.3.7"))
  :url "https://github.com/enfors/solo-rpg"
  :commit "be50ecf89df221132260730987cfd60deea0e53e"
  :revdesc "be50ecf89df2"
  :keywords '("games")
  :authors '(("Christer Enfors" . "christer.enfors@gmail.com"))
  :maintainers '(("Christer Enfors" . "christer.enfors@gmail.com")))
