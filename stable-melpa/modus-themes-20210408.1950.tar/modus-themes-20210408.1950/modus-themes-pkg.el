(define-package "modus-themes" "20210408.1950" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "18768051f8ed305503baabc19b50bfb4bd10768c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
