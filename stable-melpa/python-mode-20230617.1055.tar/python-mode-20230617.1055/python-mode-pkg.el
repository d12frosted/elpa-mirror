(define-package "python-mode" "20230617.1055" "Python major mode" 'nil :commit "65547ae6f523c6eceab7a89e42fd5d3828cf452a" :authors
  '(("2015-2023 https://gitlab.com/groups/python-mode-devs")
    ("2003-2014 https://launchpad.net/python-mode")
    ("1995-2002 Barry A. Warsaw")
    ("1992-1994 Tim Peters"))
  :maintainer
  '(nil . "python-mode@python.org")
  :keywords
  '("python" "languages" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
