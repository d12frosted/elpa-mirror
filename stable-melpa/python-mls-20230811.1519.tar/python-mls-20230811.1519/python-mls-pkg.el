(define-package "python-mls" "20230811.1519" "Multi-line shell for (i)Python"
  '((emacs "27.1")
    (compat "29.1"))
  :commit "2b7ef51d5dee57dfeb30bc8ebe10a7e4d12e7700" :authors
  '(("J.D. Smith"))
  :maintainers
  '(("J.D. Smith"))
  :maintainer
  '("J.D. Smith")
  :keywords
  '("languages" "processes")
  :url "https://github.com/jdtsmith/python-mls")
;; Local Variables:
;; no-byte-compile: t
;; End:
