;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slurpbarf" "20251018.1457"
  "Commands for slurping and barfing."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "2fc0cdc2db54d87ca957ebb1541f7804b84f5d29"
  :revdesc "2fc0cdc2db54"
  :keywords '("convenience" "lisp" "nxml"))
