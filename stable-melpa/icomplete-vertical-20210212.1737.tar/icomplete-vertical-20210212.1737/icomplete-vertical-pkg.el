(define-package "icomplete-vertical" "20210212.1737" "Display icomplete candidates vertically"
  '((emacs "25.1"))
  :commit "708d2b673f5e993c8894817b083dd08eef66cebe" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
