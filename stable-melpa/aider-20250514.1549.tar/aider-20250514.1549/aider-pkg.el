;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250514.1549"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "0b57024e1bb49e2329d8803e63454a6392499c31"
  :revdesc "0b57024e1bb4"
  :keywords '("agent" "ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
