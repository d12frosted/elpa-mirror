;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261111.245"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "5da305fb8dc4dbe048ef23f46d1f041a774b2555"
  :revdesc "5da305fb8dc4"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
