;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "20241205.1103"
  "Wrapper for difftastic."
  '((emacs  "28.1")
    (compat "29.1.4.2")
    (magit  "4.0.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "5a53dbfe19950ca0ea73443fdf362a2776369d8b"
  :revdesc "5a53dbfe1995"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
