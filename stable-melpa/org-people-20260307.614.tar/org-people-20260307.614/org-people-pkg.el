;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260307.614"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "c50f5ace4c86b0dd3933546eda4c7c9ece66939f"
  :revdesc "c50f5ace4c86"
  :keywords '("outlines" "contacts" "people"))
