(define-package "modus-themes" "20210801.859" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "ec5975f4b105700aa2b5650444c6b757e8d4d62e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
