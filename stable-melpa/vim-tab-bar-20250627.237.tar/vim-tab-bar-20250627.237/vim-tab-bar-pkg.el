;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20250627.237"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "f64be662beab51dcd4c8eafda44f8ab734769279"
  :revdesc "f64be662beab"
  :keywords '("frames"))
