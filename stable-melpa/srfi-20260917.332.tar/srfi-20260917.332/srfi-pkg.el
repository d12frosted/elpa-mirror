;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260917.332"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "d144772300430f236159f87ab3bd13cd9fa32dfa"
  :revdesc "d14477230043"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
