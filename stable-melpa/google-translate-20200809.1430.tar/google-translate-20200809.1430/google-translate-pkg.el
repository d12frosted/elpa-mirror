(define-package "google-translate" "20200809.1430" "Emacs interface to Google Translate." 'nil :commit "0270073331de9358f29d049a27aa9145697d6dc7" :authors
  (("Oleksandr Manzyuk" . "manzyuk@gmail.com"))
  :maintainer
  ("Andrey Tykhonov" . "atykhonov@gmail.com")
  :keywords
  ("convenience")
  :url "https://github.com/atykhonov/google-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
