(define-package "blackjack" "20230511.28" "The game of Blackjack"
  '((emacs "26.2"))
  :commit "0868be70a7ad77d5417ed70ed79710fb465c6dfc" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
