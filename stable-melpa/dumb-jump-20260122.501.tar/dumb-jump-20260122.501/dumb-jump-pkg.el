;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260122.501"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.4")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "51d8154f8c6f1ef984294c7f3d2784837d8960c3"
  :revdesc "51d8154f8c6f"
  :keywords '("programming"))
