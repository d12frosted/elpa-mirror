(define-package "dall-e-shell" "20230524.654" "Interaction mode for DALL-E"
  '((emacs "27.1")
    (shell-maker "0.25.1"))
  :commit "0118df8b2017c620608eae5226b9212977266d91" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
