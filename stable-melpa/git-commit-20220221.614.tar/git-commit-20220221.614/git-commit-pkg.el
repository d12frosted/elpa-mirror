(define-package "git-commit" "20220221.614" "Edit Git commit messages."
  '((emacs "25.1")
    (transient "20210920")
    (with-editor "20211001"))
  :commit "314b24cb405fa14880c2affc447c1d1fae22f893" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
