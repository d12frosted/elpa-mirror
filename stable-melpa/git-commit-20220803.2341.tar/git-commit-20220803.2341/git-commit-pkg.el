(define-package "git-commit" "20220803.2341" "Edit Git commit messages."
  '((emacs "25.1")
    (compat "28.1.1.2")
    (transient "20210920")
    (with-editor "20211001"))
  :commit "5e1e6d317b2ea27e734b73be6f1904f7578267fd" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
