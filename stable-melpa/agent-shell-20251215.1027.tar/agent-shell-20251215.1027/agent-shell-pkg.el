;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251215.1027"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "478ce5ca6cbcb6ed0d8708b8422c5cd604ab22b4"
  :revdesc "478ce5ca6cbc")
