(define-package "bufler" "20221005.2204" "Group buffers into workspaces with programmable rules"
  '((emacs "26.3")
    (dash "2.18")
    (f "0.17")
    (pretty-hydra "0.2.2")
    (magit-section "0.1")
    (map "2.1"))
  :commit "a9a2ec388b81a2a0951556e497979fdb5fd33fea" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/bufler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
