;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-zones" "20260211.2330"
  "Time zone lookups."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/time-zones"
  :commit "9f1326ad9e62daa242a5174b193a27b28e209b36"
  :revdesc "9f1326ad9e62")
