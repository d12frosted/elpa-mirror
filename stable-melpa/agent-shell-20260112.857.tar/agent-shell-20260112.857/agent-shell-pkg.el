;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260112.857"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1f60199b34eac48fe31f4c8839c5b0cef933e07e"
  :revdesc "1f60199b34ea")
