;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20261101.1123"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.1")
    (closql   "2.5")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "7320fd7d8357af58bc5f3f7b3a473edee1406935"
  :revdesc "7320fd7d8357"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
