;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "20250622.634"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.35.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "762e7aa00000b155e121e1b1afe6f952e7123aba"
  :revdesc "762e7aa00000"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
