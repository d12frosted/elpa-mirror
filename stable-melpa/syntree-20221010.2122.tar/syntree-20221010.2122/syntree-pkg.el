(define-package "syntree" "20221010.2122" "Draw plain text constituency trees"
  '((emacs "27.1")
    (org "9.2"))
  :commit "2aba7298ab865e5242a013b3c7ecae240b5c811e" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/syntree")
;; Local Variables:
;; no-byte-compile: t
;; End:
