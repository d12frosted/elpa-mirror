;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260929.958"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "c71f49ccd3d63635c46a7404115a7fd18b1c90d5"
  :revdesc "c71f49ccd3d6"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
