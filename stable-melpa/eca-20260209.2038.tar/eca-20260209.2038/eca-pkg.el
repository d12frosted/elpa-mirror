;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260209.2038"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "71702e61f1ce280fbf26a2fc29d31088b360dac4"
  :revdesc "71702e61f1ce"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
