;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261114.1356"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "0169dad4bb15a9a8208ff4850d8675356e8c4c61"
  :revdesc "0169dad4bb15"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
