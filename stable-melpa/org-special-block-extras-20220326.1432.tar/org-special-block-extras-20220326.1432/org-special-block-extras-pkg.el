(define-package "org-special-block-extras" "20220326.1432" "30 new custom blocks & 34 link types for Org-mode"
  '((s "1.12.0")
    (dash "2.18.1")
    (emacs "27.1")
    (org "9.1")
    (lf "1.0")
    (dad-joke "1.4")
    (seq "2.0")
    (lolcat "0"))
  :commit "2e397dac372ff75ea6ee6eed9ae3a0540a082af8" :authors
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainer
  '("Musa Al-hassy" . "alhassy@gmail.com")
  :keywords
  '("org" "blocks" "colors" "convenience")
  :url "https://alhassy.github.io/org-special-block-extras")
;; Local Variables:
;; no-byte-compile: t
;; End:
