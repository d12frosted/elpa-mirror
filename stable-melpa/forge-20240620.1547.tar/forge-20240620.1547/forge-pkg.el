(define-package "forge" "20240620.1547" "Access Git forges from Magit."
  '((emacs "26.3")
    (compat "29.1.4.5")
    (closql "20240405")
    (dash "2.19.1")
    (emacsql "20240124")
    (ghub "20240507")
    (let-alist "1.0.6")
    (magit "20240428")
    (markdown-mode "2.6")
    (seq "2.24")
    (transient "20240421")
    (yaml "0.5.5"))
  :commit "4a0b31d9b4eb674bb87b4dd0775e36f94742f6bb" :authors
  '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
