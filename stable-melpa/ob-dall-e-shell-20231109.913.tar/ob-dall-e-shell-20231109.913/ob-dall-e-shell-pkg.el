(define-package "ob-dall-e-shell" "20231109.913" "Org babel functions for DALL-E evaluation"
  '((emacs "27.1")
    (dall-e-shell "0.34.1"))
  :commit "ad7caa8bde9d9e3e4f09458e6542ae1318949b2b" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
