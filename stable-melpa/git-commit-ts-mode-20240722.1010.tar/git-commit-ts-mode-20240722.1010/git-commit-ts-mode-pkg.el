(define-package "git-commit-ts-mode" "20240722.1010" "Tree-sitter support for Git commit messages"
  '((emacs "29.1"))
  :commit "02391c4a2745e304b724b01c058764defce49a73" :authors
  '(("Daniil Shvalov" . "daniil.shvalov@gmail.com"))
  :maintainers
  '(("Daniil Shvalov" . "daniil.shvalov@gmail.com"))
  :maintainer
  '("Daniil Shvalov" . "daniil.shvalov@gmail.com")
  :keywords
  '("tree-sitter" "git" "faces")
  :url "https://github.com/danilshvalov/git-commit-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
