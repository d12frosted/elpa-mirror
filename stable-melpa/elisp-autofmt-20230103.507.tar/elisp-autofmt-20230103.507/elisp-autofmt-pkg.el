(define-package "elisp-autofmt" "20230103.507" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "02d614843d287b3ae9de889fc20ae63ab3b33b06" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
