(define-package "embark" "20211009.537" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "6b2c2b888ae333d9f0a4fa3f505dc52e1e9e1113" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
