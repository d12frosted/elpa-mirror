;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser" "20260428.2241"
  "GNU Emacs and Scheme talk to each other."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://gitlab.com/emacs-geiser/"
  :commit "7403ec607ddd223ccc38df18ce8de595396519ee"
  :revdesc "7403ec607ddd"
  :keywords '("languages" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
