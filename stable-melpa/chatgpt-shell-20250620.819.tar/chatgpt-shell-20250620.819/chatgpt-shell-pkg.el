;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250620.819"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.77.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "5e2cc001e1129456363d2c55f7e336c9f00aac79"
  :revdesc "5e2cc001e112")
