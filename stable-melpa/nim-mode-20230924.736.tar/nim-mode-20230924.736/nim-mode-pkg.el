(define-package "nim-mode" "20230924.736" "A major mode for the Nim programming language"
  '((emacs "24.4")
    (epc "0.1.1")
    (let-alist "1.0.1")
    (commenter "0.5.1")
    (flycheck-nimsuggest "0.8.1"))
  :commit "db9813462aa0aad20df9038e88a0745b56f6760b" :authors
  '(("Simon Hafner"))
  :maintainers
  '(("Simon Hafner" . "hafnersimon@gmail.com"))
  :maintainer
  '("Simon Hafner" . "hafnersimon@gmail.com")
  :keywords
  '("nim" "languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
