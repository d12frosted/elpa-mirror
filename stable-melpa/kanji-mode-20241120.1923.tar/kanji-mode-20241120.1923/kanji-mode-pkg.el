;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kanji-mode" "20241120.1923"
  "View stroke order for kanji characters at cursor."
  ()
  :url "https://github.com/wsgac/kanji-mode "
  :commit "09719b00d60e22bd31c93b21c0c817eced9d0406"
  :revdesc "09719b00d60e"
  :authors '(("Wojciech Gac" . "wojciech.s.gac@gmail.com"))
  :maintainers '(("Wojciech Gac" . "wojciech.s.gac@gmail.com")))
