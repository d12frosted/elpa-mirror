(define-package "llama-cpp" "20231219.1355" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "a8f5b1b1bd55a36eed878c55cb9d510076ff8ad7" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
