;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-direx" "20200805.1414"
  "Plugin of e2wm.el for direx.el."
  '((e2wm  "1.2")
    (direx "0.1alpha"))
  :url "https://github.com/aki2o/e2wm-direx"
  :commit "5672bc44d8e5cea6bc3b84c3b58e522050ffae0e"
  :revdesc "5672bc44d8e5"
  :keywords '("tools" "window manager" "convenience")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
