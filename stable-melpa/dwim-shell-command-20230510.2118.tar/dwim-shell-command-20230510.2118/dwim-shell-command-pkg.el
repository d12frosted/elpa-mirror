(define-package "dwim-shell-command" "20230510.2118" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "6513e49a3929724136978a71742ed17d904fd0a7" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
