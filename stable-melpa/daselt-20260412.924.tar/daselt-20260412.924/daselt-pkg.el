;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260412.924"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "cca8b9ed9dba17733d68450f49b271b2d5631f84"
  :revdesc "cca8b9ed9dba"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
