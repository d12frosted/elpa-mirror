(define-package "ox-tufte" "20230830.1959" "Tufte HTML org-mode export backend"
  '((org "9.5")
    (emacs "27.1"))
  :commit "8633ac9246d61552701c80d88b930eb6e8d2cfaf" :authors
  '(("The Bayesians Inc.")
    ("M. Lee Hinman"))
  :maintainers
  '(("The Bayesians Inc."))
  :maintainer
  '("The Bayesians Inc.")
  :keywords
  '("org" "tufte" "html" "outlines" "hypermedia" "calendar" "wp")
  :url "https://github.com/ox-tufte/ox-tufte")
;; Local Variables:
;; no-byte-compile: t
;; End:
