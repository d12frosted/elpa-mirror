(define-package "org-link-beautify" "20240311.2345" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1")
    (qrencode "1.2"))
  :commit "2642b654e1dfbf183ccaf44f28ceaca9d93b2be1" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
