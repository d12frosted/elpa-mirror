(define-package "modus-themes" "20210910.825" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "6ef1da3c9cdab4a53ef4cdef4a952fa9953e1293" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
