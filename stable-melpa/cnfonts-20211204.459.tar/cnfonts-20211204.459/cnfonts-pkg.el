(define-package "cnfonts" "20211204.459" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "82c18f8ef6918bf9c6e8e6cbdfae5f53b72d3a73" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
