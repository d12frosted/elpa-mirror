;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-ts-mode" "20260311.544"
  "Major mode for Zig code."
  '((emacs "29.1"))
  :url "https://codeberg.org/meow_king/zig-ts-mode"
  :commit "9c447adbf0c015fadaf1271ef8ca3e1fcf3c2a8d"
  :revdesc "9c447adbf0c0"
  :keywords '("zig" "languages" "tree-sitter")
  :authors '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers '(("meowking" . "mr.meowking@tutamail.com")))
