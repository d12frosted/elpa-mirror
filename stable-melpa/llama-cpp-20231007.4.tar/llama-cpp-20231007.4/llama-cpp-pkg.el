(define-package "llama-cpp" "20231007.4" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "7e57ec3ec5f4436750299c7aa0886a2eb072b8cf" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
