;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "20260403.1452"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "17f3a0a966a72f2f901c806f99ee25637ae8c711"
  :revdesc "17f3a0a966a7"
  :keywords '("color" "theme" "faces"))
