;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20260106.143"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "82632de098a0bce3c1546566781e3bb8cfa779f6"
  :revdesc "82632de098a0"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
