;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250702.1806"
  "Minor mode to format JS code on file save."
  '((emacs "28.1"))
  :url "https://github.com/prettier/prettier-emacs"
  :commit "d5715a8825318a6d18089cfadc8199fa3f5d8293"
  :revdesc "d5715a882531"
  :keywords '("convenience" "wp" "edit" "js"))
