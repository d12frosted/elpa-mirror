;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260406.322"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "6d6c81333abf01883d9ab10d4aaa1ec9434195eb"
  :revdesc "6d6c81333abf"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
