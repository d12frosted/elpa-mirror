;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elmine" "20200520.1237"
  "Redmine API access via elisp."
  '((s "1.10.0"))
  :url "https://github.com/leoc/elmine"
  :commit "d42e328634828e0c1770b72d5e8b87671d081693"
  :revdesc "d42e32863482"
  :keywords '("tools")
  :authors '(("Arthur Andersen" . "leoc.git@gmail.com"))
  :maintainers '(("Arthur Andersen" . "leoc.git@gmail.com")))
