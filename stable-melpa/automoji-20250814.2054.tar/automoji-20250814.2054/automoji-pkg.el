;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "automoji" "20250814.2054"
  "Discord-like emoji completion."
  '((emacs "29.1"))
  :url "https://github.com/Dev380/automoji-el"
  :commit "725e6915f9976bd7fd87a4daa7dc9f1968bcfe23"
  :revdesc "725e6915f997"
  :keywords '("completion" "abbrev" "convenience" "text"))
