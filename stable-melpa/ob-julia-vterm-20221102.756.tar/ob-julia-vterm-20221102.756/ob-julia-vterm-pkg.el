(define-package "ob-julia-vterm" "20221102.756" "Babel functions for Julia that work with julia-vterm"
  '((emacs "26.1")
    (julia-vterm "0.16")
    (queue "0.2"))
  :commit "e0069ff1d8ebf0be13cc24b980579577b5e343d8" :authors
  '(("Shigeaki Nishina"))
  :maintainers
  '(("Shigeaki Nishina"))
  :maintainer
  '("Shigeaki Nishina")
  :keywords
  '("julia" "org" "outlines" "literate programming" "reproducible research")
  :url "https://github.com/shg/ob-julia-vterm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
