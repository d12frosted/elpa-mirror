(define-package "yoshi-theme" "20230225.740" "Theme named after my cat" 'nil :commit "ba9427329ac49fa2e060da2c16507feed62ad890" :authors
  '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers
  '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainer
  '("Tom Willemse" . "tom@ryuslash.org")
  :keywords
  '("faces")
  :url "http://projects.ryuslash.org/yoshi-theme/")
;; Local Variables:
;; no-byte-compile: t
;; End:
