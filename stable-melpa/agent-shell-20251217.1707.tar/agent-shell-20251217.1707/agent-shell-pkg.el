;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251217.1707"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "70d7794edf88446aa58fd51b259ade80d1d0d026"
  :revdesc "70d7794edf88")
