;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-eval" "20260315.2000"
  "Execute named org-mode blocks on load/save."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-eval"
  :commit "20af7370473225ed4396663d01a5dfcca6456684"
  :revdesc "20af73704732"
  :keywords '("org" "outlines")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
