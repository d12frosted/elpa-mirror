;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cppinsights" "20250515.128"
  "Integration with cppinsights tool."
  '((emacs "28.1"))
  :url "https://github.com/chrischen3121/cppinsights.el"
  :commit "91a69c03e8724bccd50e697c3f450a8a70d91131"
  :revdesc "91a69c03e872"
  :keywords '("c++" "tools" "cppinsights")
  :authors '(("Chris Chen" . "chrischen@ignity.xyz"))
  :maintainers '(("Chris Chen" . "chrischen@ignity.xyz")))
