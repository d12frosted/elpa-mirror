(define-package "consult-ls-git" "20230120.1500" "Consult integration for git"
  '((emacs "27.1")
    (consult "0.16"))
  :commit "7ba583abc16f70c497d038bfcbddbadd6894bd3d" :authors
  '(("Robin Joy"))
  :maintainers
  '(("Robin Joy"))
  :maintainer
  '("Robin Joy")
  :keywords
  '("convenience")
  :url "https://github.com/rcj/consult-ls-git")
;; Local Variables:
;; no-byte-compile: t
;; End:
