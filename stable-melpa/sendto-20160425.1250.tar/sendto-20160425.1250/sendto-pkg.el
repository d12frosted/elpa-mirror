;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sendto" "20160425.1250"
  "Send the region content to a function."
  '((emacs "24.4"))
  :url "https://github.com/lujun9972/sendto.el"
  :commit "076b81d7a53f75b0a59b0ef3448f35570567054c"
  :revdesc "076b81d7a53f"
  :keywords '("convenience" "region")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
