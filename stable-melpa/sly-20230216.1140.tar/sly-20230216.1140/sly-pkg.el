(define-package "sly" "20230216.1140" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "fa70fc8ab1bc1f1c21661d672834e41b1d0abd39" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
