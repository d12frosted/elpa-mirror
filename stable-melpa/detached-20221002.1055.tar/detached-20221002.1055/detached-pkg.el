(define-package "detached" "20221002.1055" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "53be9af04c8ad3ab4b5f9cb451f6e40621b4c89c" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
