(define-package "reazon" "20211229.214" "miniKanren for Emacs"
  '((emacs "26"))
  :commit "21a4218538eee90af66c20519457efeb5b319e22" :authors
  '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainer
  '("Nick Drozd" . "nicholasdrozd@gmail.com")
  :keywords
  '("languages" "extensions" "lisp")
  :url "https://github.com/nickdrozd/reazon")
;; Local Variables:
;; no-byte-compile: t
;; End:
