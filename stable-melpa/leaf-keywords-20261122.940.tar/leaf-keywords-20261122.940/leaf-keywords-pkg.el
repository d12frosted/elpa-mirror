;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-keywords" "20261122.940"
  "Additional leaf.el keywords for external packages."
  '((emacs "24.4")
    (leaf  "4.5.5"))
  :url "https://github.com/conao3/leaf-keywords.el"
  :commit "b7f12e0f5955e7cc824c45c6610bec4363964ebd"
  :revdesc "b7f12e0f5955"
  :keywords '("lisp" "settings")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
