;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "satysfi-ts-mode" "20260109.532"
  "A tree-sitter based major-mode for SATySFi."
  '((emacs "29.1"))
  :url "https://github.com/Kyure-A/satysfi-ts-mode"
  :commit "24bb037c8a45b3cd291f83cc4886cf9118c06777"
  :revdesc "24bb037c8a45"
  :keywords '("languages")
  :authors '(("Kyure_A" . "github.com/Kyure-A"))
  :maintainers '(("Kyure_A" . "github.com/Kyure-A")))
