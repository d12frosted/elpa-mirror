(define-package "meow" "20211219.2125" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "e54c60499eb90ed5b9ffff52d8e286eb5ce6916e" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
