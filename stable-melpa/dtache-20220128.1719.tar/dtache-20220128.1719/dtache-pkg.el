(define-package "dtache" "20220128.1719" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "b44b8ab0ad7db8d6fd90dff12339ea8b7ee52aca" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
