(define-package "latex-table-wizard" "20230821.1507" "Magic editing of LaTeX tables"
  '((emacs "27.1")
    (auctex "12.1")
    (transient "0.3.7"))
  :commit "9dcc3d62ce2be04946b67cc023f8655c0a14aa7a" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :keywords
  '("convenience")
  :url "https://github.com/enricoflor/latex-table-wizard")
;; Local Variables:
;; no-byte-compile: t
;; End:
