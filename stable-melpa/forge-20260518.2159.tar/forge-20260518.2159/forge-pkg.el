;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forge" "20260518.2159"
  "Access Git forges from Magit."
  '((emacs         "29.1")
    (compat        "31.0")
    (closql        "2.4")
    (cond-let      "1.1")
    (emacsql       "4.3")
    (ghub          "5.2")
    (llama         "1.0")
    (magit         "4.5")
    (markdown-mode "2.8")
    (seq           "2.24")
    (transient     "0.13")
    (yaml          "1.2"))
  :url "https://github.com/magit/forge"
  :commit "c18e00c83eeea0ba6e16b3275ac9a5bf7f7c6077"
  :revdesc "c18e00c83eee"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev")))
