(define-package "el-secretario" "20211208.1038" "Unify all your inboxes with the Emacs secretary"
  '((emacs "27.1")
    (org-ql "0.6pre")
    (hercules "0.3"))
  :commit "2a5290ad57d9800d4b56896a768e37631bef06b0" :authors
  '(("Leo Okawa Ericson <http://github/Zetagon>"))
  :maintainer
  '("Leo" . "github@relevant-information.com")
  :keywords
  '("convenience")
  :url "https://git.sr.ht/~zetagon/el-secretario")
;; Local Variables:
;; no-byte-compile: t
;; End:
