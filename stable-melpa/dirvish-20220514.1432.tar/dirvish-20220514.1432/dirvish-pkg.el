(define-package "dirvish" "20220514.1432" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a66ba7036b33825f201309e9c351e008dc03e4a2" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
