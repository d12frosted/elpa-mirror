;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251128.541"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "117875cb12c92f93f94b3ffff61a5446e82bd29d"
  :revdesc "117875cb12c9"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
