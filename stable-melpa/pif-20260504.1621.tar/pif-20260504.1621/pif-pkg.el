;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pif" "20260504.1621"
  "Prevent Initial Flash of Light."
  '((emacs "29.1"))
  :url "https://github.com/oliverepper/pif"
  :commit "72978dddffa3d9c68c6510c3a0381ffcdb691188"
  :revdesc "72978dddffa3"
  :keywords '("convenience" "faces" "display" "startup" "appearance" "dark-theme")
  :authors '(("Oliver Epper" . "oliver.epper@gmail.com"))
  :maintainers '(("Oliver Epper" . "oliver.epper@gmail.com")))
