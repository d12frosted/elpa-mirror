;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "line-up-words" "20241121.2033"
  "Align words in an intelligent way."
  ()
  :url "https://github.com/janestreet/line-up-words"
  :commit "3c1339a3fb3840dfaea50d8cb966c90b19d14925"
  :revdesc "3c1339a3fb38")
