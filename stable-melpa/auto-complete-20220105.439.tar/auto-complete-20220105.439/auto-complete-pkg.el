(define-package "auto-complete" "20220105.439" "Auto Completion for GNU Emacs"
  '((popup "0.5.0")
    (cl-lib "0.5"))
  :commit "8edf20ae3e794cd3ab016a4cabcf6ee3763eecf6" :authors
  '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainer
  '("Jen-Chieh Shen" . "jcs090218@gmail.com")
  :keywords
  '("completion" "convenience")
  :url "https://github.com/auto-complete/auto-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
