;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20260420.107"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.3"))
  :url "https://github.com/kmontag/macher"
  :commit "2a4d2ce81076134c7521bfd3a345c5440c440c2f"
  :revdesc "2a4d2ce81076"
  :keywords '("convenience" "gptel" "llm"))
