;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250516.1007"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "28.1")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "0db077ee319340b2ba9f9fdedb503047d84c3a6e"
  :revdesc "0db077ee3193"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
