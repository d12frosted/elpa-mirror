;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260629.1657"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "323d183f7434abcccb8ee2d24733f2438f5c1e41"
  :revdesc "323d183f7434"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
