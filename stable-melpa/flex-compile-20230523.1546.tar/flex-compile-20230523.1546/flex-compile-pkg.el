(define-package "flex-compile" "20230523.1546" "Run, evaluate and compile across many languages"
  '((emacs "26.1")
    (dash "2.17.0")
    (buffer-manage "1.1"))
  :commit "86827e5d2fe6e7757c346db718d97a50acdacb00" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("compilation" "integration" "processes")
  :url "https://github.com/plandes/flex-compile")
;; Local Variables:
;; no-byte-compile: t
;; End:
