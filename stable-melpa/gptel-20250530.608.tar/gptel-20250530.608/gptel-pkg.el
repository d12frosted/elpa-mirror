;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250530.608"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "c49675e1df4456895309172cb8a7669a57148bac"
  :revdesc "c49675e1df44"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
