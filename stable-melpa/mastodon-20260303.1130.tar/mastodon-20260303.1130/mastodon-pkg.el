;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260303.1130"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "096494056bdb832f9707f3011bffb80fcf8a6d7c"
  :revdesc "096494056bdb"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
