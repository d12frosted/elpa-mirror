;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260325.713"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "69535ba79a663ea938c03ab5ce26108db510cc4a"
  :revdesc "69535ba79a66"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
