;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "procress" "20260730.1707"
  "Process progress."
  '((emacs  "27.1")
    (auctex "13.0"))
  :url "https://github.com/haji-ali/procress.git"
  :commit "8e0e3b4c3fad211b028e9daff8dae73693c02272"
  :revdesc "8e0e3b4c3fad"
  :keywords '("compile" "progress" "tex" "svg")
  :authors '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")))
