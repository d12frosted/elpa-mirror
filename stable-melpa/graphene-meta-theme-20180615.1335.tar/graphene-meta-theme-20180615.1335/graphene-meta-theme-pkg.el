;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphene-meta-theme" "20180615.1335"
  "Integrated theming for common packages."
  ()
  :url "https://github.com/rdallasgray/graphene"
  :commit "a4deb38957ee2aeb861d5601b304bf28d9f867ec"
  :revdesc "a4deb38957ee"
  :keywords '("defaults")
  :authors '(("Robert Dallas Gray" . "mail@robertdallasgray.com"))
  :maintainers '(("Robert Dallas Gray" . "mail@robertdallasgray.com")))
