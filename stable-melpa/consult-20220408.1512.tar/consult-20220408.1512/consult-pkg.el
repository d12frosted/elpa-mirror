(define-package "consult" "20220408.1512" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "e926d593d3e09d6bd1ffdf2dc55aec4c6f42abeb" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
