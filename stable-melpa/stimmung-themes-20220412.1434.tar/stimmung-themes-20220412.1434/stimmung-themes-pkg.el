(define-package "stimmung-themes" "20220412.1434" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "77146bd3ad4f275847c965148572bb0ff0b54c1e" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
