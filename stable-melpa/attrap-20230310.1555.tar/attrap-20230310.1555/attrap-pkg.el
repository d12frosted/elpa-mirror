(define-package "attrap" "20230310.1555" "ATtempt To Repair At Point"
  '((dash "2.12.0")
    (emacs "25.1")
    (f "0.19.0")
    (s "1.11.0"))
  :commit "2df105d0bd23a468e75fad0fed7d39013328526d" :authors
  '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainers
  '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainer
  '("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com")
  :keywords
  '("programming" "tools")
  :url "https://github.com/jyp/attrap")
;; Local Variables:
;; no-byte-compile: t
;; End:
