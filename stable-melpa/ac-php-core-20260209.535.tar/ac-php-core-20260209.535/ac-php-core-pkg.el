;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20260209.535"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "6d19ceccad33e89e2e1149543c79305de2895832"
  :revdesc "6d19ceccad33"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
