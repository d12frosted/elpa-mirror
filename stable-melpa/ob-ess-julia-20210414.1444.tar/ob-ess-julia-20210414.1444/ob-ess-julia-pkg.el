;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ess-julia" "20210414.1444"
  "Org babel support for Julia language."
  '((ess        "20201004.1522")
    (julia-mode "0.4"))
  :url "https://github.com/frederic-santos/ob-ess-julia"
  :commit "147e9e7fe55c41dd77171417e92af40db3530b84"
  :revdesc "147e9e7fe55c"
  :keywords '("languages"))
