(define-package "flex-compile" "20230805.1653" "Run, evaluate and compile across many languages"
  '((emacs "26.1")
    (dash "2.17.0")
    (buffer-manage "1.1"))
  :commit "58890e08800059550565a20dc7029e8bcccc55de" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("compilation" "integration" "processes")
  :url "https://github.com/plandes/flex-compile")
;; Local Variables:
;; no-byte-compile: t
;; End:
