(define-package "org-tag-beautify" "20240418.951" "Beautify Org mode tags"
  '((emacs "26.1")
    (nerd-icons "0.0.1"))
  :commit "d36d1725b6f5ac498dc9e93e78fb04bd022f5c2f" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-tag-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
