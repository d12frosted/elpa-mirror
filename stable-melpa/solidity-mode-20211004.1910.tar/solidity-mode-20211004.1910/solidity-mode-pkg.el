(define-package "solidity-mode" "20211004.1910" "Major mode for ethereum's solidity language" 'nil :commit "9c77b390eab999e5e54dc5c1068f57201e6628bf" :authors
  '(("Lefteris Karapetsas " . "lefteris@refu.co"))
  :maintainer
  '("Lefteris Karapetsas " . "lefteris@refu.co")
  :keywords
  '("languages" "solidity"))
;; Local Variables:
;; no-byte-compile: t
;; End:
