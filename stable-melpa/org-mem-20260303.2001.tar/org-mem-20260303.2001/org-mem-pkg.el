;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260303.2001"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "c667fb7059ea5a1cf3935caf8beb56bd81bdf49f"
  :revdesc "c667fb7059ea"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
