;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-todo" "20200323.2005"
  "Manage org-mode TODOs with ivy."
  '((ivy   "0.8.0")
    (emacs "25"))
  :url "https://github.com/Kungsgeten/ivy-todo"
  :commit "d74501cd334b7d709659946c5e02b21cfd5507de"
  :revdesc "d74501cd334b"
  :keywords '("convenience")
  :authors '(("Erik Sjöstrand" . "sjostrand.erik@gmail.com"))
  :maintainers '(("Erik Sjöstrand" . "sjostrand.erik@gmail.com")))
