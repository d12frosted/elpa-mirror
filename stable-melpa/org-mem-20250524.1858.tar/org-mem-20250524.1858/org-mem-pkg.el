;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250524.1858"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "6c4edcd2f04d3200f1a534c521a1a906963bdba5"
  :revdesc "6c4edcd2f04d"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
