;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20261002.232"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "853aae7059e485eb2031c7465cf52ca14798343e"
  :revdesc "853aae7059e4"
  :keywords '("convenience" "files" "tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
