;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260327.2008"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "0bb713309a7fecde8f6bcf478e4166b19720f1d7"
  :revdesc "0bb713309a7f"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
