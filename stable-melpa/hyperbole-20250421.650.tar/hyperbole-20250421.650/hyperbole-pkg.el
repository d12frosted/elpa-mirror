;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250421.650"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "6fb121ec7367bea98cc4fe7bc311433a27b5754e"
  :revdesc "6fb121ec7367"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
