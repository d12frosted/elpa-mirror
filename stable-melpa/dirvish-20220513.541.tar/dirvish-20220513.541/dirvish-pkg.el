(define-package "dirvish" "20220513.541" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "73197912bb5f39ec25e57f3c418db7c7127abe39" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
