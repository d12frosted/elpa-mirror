;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260130.116"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "cb6493df8ef9cd6d44da9bd55a0d5662fd56cd5d"
  :revdesc "cb6493df8ef9"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
