(define-package "golden-ratio" "20230907.2258" "Automatic resizing of Emacs windows to the golden ratio" 'nil :commit "bf0035fd6a1b2c1d9554909c795de1fcca5f3927" :authors
  '(("Roman Gonzalez" . "romanandreg@gmail.com"))
  :maintainers
  '(("Roman Gonzalez" . "romanandreg@gmail.com"))
  :maintainer
  '("Roman Gonzalez" . "romanandreg@gmail.com")
  :keywords
  '("window" "resizing"))
;; Local Variables:
;; no-byte-compile: t
;; End:
