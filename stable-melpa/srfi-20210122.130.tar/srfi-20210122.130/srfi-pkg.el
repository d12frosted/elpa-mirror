(define-package "srfi" "20210122.130" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "a4c2e70612a4bdbdb8903a55867557c028010ccb" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
