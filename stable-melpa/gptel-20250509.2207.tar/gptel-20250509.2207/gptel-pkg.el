;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250509.2207"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "15d056fb3fd8d0b594a5b24e96472a98e9be08dd"
  :revdesc "15d056fb3fd8"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
