;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20250423.56"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "2d6c51747b01946db850f62d275d6876ffcf366b"
  :revdesc "2d6c51747b01"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
