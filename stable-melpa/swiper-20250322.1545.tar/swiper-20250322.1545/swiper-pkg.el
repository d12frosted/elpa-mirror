;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swiper" "20250322.1545"
  "Isearch with an overview.  Oh, man!."
  '((emacs "24.5")
    (ivy   "0.15.0"))
  :url "https://github.com/abo-abo/swiper"
  :commit "e8915418d8b048acf22a9a74724acf882f217703"
  :revdesc "e8915418d8b0"
  :keywords '("matching")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
