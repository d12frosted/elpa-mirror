;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uci-mode" "20210626.1956"
  "Major-mode for chess engine interaction."
  '((emacs "25.1"))
  :url "https://github.com/dwcoates/uci-mode"
  :commit "2cdf4de5af96d56108a0a5716416ef3c8ac7bb7c"
  :revdesc "2cdf4de5af96"
  :keywords '("data" "games" "chess"))
