;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-desktop" "20250905.1921"
  "Desktop environment for zk."
  '((emacs    "27.1")
    (zk       "0.6")
    (zk-index "0.9"))
  :url "https://github.com/localauthor/zk"
  :commit "a634b6ec7af4f16a1ceed9271d2a0dbd9bca8501"
  :revdesc "a634b6ec7af4"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
