(define-package "surround" "20231204.1418" "Easily add/delete/change parens, quotes, and more"
  '((emacs "24.3"))
  :commit "1fbe4dbe194129e95b286b8cbfa2bce43e4c29e4" :authors
  '(("Michael Kleehammer" . "michael@kleehammer.com"))
  :maintainers
  '(("Michael Kleehammer" . "michael@kleehammer.com"))
  :maintainer
  '("Michael Kleehammer" . "michael@kleehammer.com")
  :url "https://github.com/mkleehammer/surround")
;; Local Variables:
;; no-byte-compile: t
;; End:
