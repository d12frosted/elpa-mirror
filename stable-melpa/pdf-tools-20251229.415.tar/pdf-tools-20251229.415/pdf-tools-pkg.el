;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-tools" "20251229.415"
  "Support library for PDF documents."
  '((emacs     "26.3")
    (tablist   "1.0")
    (let-alist "1.0.4"))
  :url "http://github.com/vedang/pdf-tools/"
  :commit "d89686e4e0b35d8a0deff5d8709b81edd5cd5630"
  :revdesc "d89686e4e0b3"
  :keywords '("files" "multimedia")
  :authors '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainers '(("Vedang Manerikar" . "vedang.manerikar@gmail.com")))
