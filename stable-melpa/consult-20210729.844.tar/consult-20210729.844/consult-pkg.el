(define-package "consult" "20210729.844" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "ebed71d554a5eda6914de6519cd30b867e9dbc28" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
