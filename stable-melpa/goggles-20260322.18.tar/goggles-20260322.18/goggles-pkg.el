;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goggles" "20260322.18"
  "Pulse modified regions."
  '((emacs "29.1"))
  :url "https://github.com/minad/goggles"
  :commit "73040c4dc8fe946d3657accb5dc4ed4065abd348"
  :revdesc "73040c4dc8fe"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
