;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parrot" "20260111.2133"
  "Party Parrot rotates gracefully in the mode-line."
  '((emacs "24.1"))
  :url "https://github.com/dp12/parrot.git"
  :commit "c2700b1d42f94f8cb574a0f96a143f4865b180b6"
  :revdesc "c2700b1d42f9"
  :keywords '("party" "parrot" "rotate" "sirocco" "kakapo" "games")
  :authors '(("Daniel Ting" . "deep.paren.12@gmail.com"))
  :maintainers '(("Daniel Ting" . "deep.paren.12@gmail.com")))
