;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-light-theme" "20251222.912"
  "Visual Studio IDE light theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-light-theme"
  :commit "64bf2ddc6235a299ca84651e732df355e35c9f59"
  :revdesc "64bf2ddc6235"
  :keywords '("faces"))
