;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260720.1026"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "f3e69f4fb5103fafd37a267039e092edf35351c5"
  :revdesc "f3e69f4fb510"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
