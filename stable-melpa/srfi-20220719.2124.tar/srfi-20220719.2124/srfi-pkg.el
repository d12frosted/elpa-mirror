(define-package "srfi" "20220719.2124" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "685bad7c96adc7608e05ffa0a9f498bfae31efda" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
