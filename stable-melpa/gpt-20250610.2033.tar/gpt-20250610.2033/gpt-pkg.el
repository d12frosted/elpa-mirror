;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpt" "20250610.2033"
  "Run instruction-following language models."
  '((emacs "24.4"))
  :url "https://github.com/stuhlmueller/gpt.el"
  :commit "4be8306b33f4bca794da27245d3b984ef485949b"
  :revdesc "4be8306b33f4"
  :keywords '("openai" "anthropic" "claude" "language" "copilot" "convenience" "tools")
  :authors '(("Andreas Stuhlmueller" . "emacs@stuhlmueller.org"))
  :maintainers '(("Andreas Stuhlmueller" . "emacs@stuhlmueller.org")))
