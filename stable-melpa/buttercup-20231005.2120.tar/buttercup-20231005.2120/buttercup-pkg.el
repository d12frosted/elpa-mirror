(define-package "buttercup" "20231005.2120" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "3780eb081913d1aeef2bc5950891a3fbe3b3771d" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainers
  '(("Ola Nilsson" . "ola.nilsson@gmail.com"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
