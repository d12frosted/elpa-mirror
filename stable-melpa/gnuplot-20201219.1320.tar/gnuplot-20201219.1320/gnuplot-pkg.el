(define-package "gnuplot" "20201219.1320" "Major-mode and interactive frontend for gnuplot"
  '((emacs "24.3"))
  :commit "1488629061665317e404801bee5c1e11e5f886fd" :keywords
  ("data" "gnuplot" "plotting")
  :authors
  (("Jon Oddie")
   ("Bruce Ravel")
   ("Phil Type"))
  :maintainer
  ("Bruce Ravel" . "bruceravel1@gmail.com")
  :url "https://github.com/emacsorphanage/gnuplot")
;; Local Variables:
;; no-byte-compile: t
;; End:
