(define-package "popper" "20220216.1906" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "7b02960025fb89384f78ba12ad03cae0ddf1e411" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
