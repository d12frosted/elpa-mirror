;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260305.1125"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.34.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "21f8df4614e5b7fc04f597d10640f34e9e8016c4"
  :revdesc "21f8df4614e5"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
