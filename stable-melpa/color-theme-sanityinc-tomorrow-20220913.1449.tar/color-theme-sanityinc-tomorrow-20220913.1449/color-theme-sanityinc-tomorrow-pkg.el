(define-package "color-theme-sanityinc-tomorrow" "20220913.1449" "A version of Chris Kempson's \"tomorrow\" themes" 'nil :commit "7a948827fcfd5b78d69bc506b4299decc08ee6b9" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("faces" "themes")
  :url "https://github.com/purcell/color-theme-sanityinc-tomorrow")
;; Local Variables:
;; no-byte-compile: t
;; End:
