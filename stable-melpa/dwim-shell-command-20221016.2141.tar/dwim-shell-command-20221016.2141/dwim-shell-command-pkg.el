(define-package "dwim-shell-command" "20221016.2141" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "6ecc5355931fdf6737ce95ddf50e076f16f231ba" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
