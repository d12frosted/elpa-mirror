(define-package "inf-elixir" "20230610.1252" "Run an interactive Elixir shell"
  '((emacs "25.1"))
  :commit "75fe18f511826e20099343ef24e0c15fe410d4fb" :authors
  '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers
  '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainer
  '("Jonathan Arnett" . "jonathan.arnett@protonmail.com")
  :keywords
  '("languages" "processes" "tools")
  :url "https://github.com/J3RN/inf-elixir")
;; Local Variables:
;; no-byte-compile: t
;; End:
