;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-nix3" "20261012.201"
  "Nix3.el integration for Magit."
  '((emacs   "29.1")
    (nix3    "0.1")
    (promise "1.1"))
  :url "https://github.com/emacs-twist/nix3.el"
  :commit "4ed007cf0a90a75b6461f1092a898d4153db5596"
  :revdesc "4ed007cf0a90"
  :keywords '("processes")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
