;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260516.1403"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "1a919906c50be386795f7d02bd43e7f7d8558e9e"
  :revdesc "1a919906c50b"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
