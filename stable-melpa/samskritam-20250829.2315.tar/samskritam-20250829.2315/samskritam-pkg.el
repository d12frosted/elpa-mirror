;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "samskritam" "20250829.2315"
  "Show samskrit word definitions."
  '((emacs "28.1"))
  :url "https://github.com/thapakrish/samskritam"
  :commit "e84358904b93c5c03d00b62f1e6735393d2b3d53"
  :revdesc "e84358904b93"
  :keywords '("samskrit" "sanskrit" "संस्कृत" "dictionary" "devanagari" "convenience" "language")
  :authors '(("Krishna Thapa" . "thapakrish@gmail.com"))
  :maintainers '(("Krishna Thapa" . "thapakrish@gmail.com")))
