(define-package "hl-indent-scope" "20230626.633" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "0624ff6c127bcd87c7d5131d2fcb0f13b64b0741" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
