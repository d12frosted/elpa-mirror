(define-package "workroom" "20221113.1802" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0"))
  :commit "9db06cc7e7f988a767508133f5c4bedcba5cb555" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
