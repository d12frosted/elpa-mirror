(define-package "yatex" "20220921.1234" "Yet Another tex-mode for emacs //野鳥//" 'nil :commit "c6a26b422d3065d59dcef86a4db99cbad0f64bb0")
;; Local Variables:
;; no-byte-compile: t
;; End:
