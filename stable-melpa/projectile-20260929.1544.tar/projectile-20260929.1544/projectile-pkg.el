;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260929.1544"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "7a33281b1efcba42d4355e465258e1a7dc1899aa"
  :revdesc "7a33281b1efc"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
