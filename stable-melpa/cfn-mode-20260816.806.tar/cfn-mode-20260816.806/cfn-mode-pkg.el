;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260816.806"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "dc291f8b61eae270393dc1a316e791ca5985c4fe"
  :revdesc "dc291f8b61ea"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
