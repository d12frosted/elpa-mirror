(define-package "embark" "20220427.2144" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "70f720f914b78bd11f84b0790df5f125945dd50f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
