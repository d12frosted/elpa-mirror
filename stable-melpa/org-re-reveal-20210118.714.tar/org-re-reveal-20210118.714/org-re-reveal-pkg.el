(define-package "org-re-reveal" "20210118.714" "Org export to reveal.js presentations"
  '((emacs "24.4")
    (org "8.3")
    (htmlize "1.34"))
  :commit "d404eb13d9e34354c081870ebdd69711937682b3" :keywords
  '("tools" "outlines" "hypermedia" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/org-re-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
