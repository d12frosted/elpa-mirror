;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260307.357"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "b9ed900da1c3a9eba8802dc0614eb29eb3aecd3a"
  :revdesc "b9ed900da1c3"
  :keywords '("comm"))
