(define-package "mini-echo" "20231115.13" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "5dfd1608d384be3176c4f06fef908933e2fd4a02" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
