(define-package "gerrit" "20201114.420" "Gerrit client"
  '((emacs "25.1")
    (hydra "0.15.0")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "4c4fbd2b1b38202f701081ea8e892bd8e1a9042f" :keywords
  ("extensions")
  :authors
  (("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  ("Thomas Hisch" . "t.hisch@gmail.com")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
