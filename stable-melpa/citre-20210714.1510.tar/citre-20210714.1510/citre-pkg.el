(define-package "citre" "20210714.1510" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "dcb5ec12d077c9a8f1c165a0868f98098494f78c" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
