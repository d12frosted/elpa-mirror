;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260120.958"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b8344d5987c0b75bd8118e9a4063d4c9601caa50"
  :revdesc "b8344d5987c0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
