;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "archive-rpm" "20220527.632"
  "RPM and CPIO support for archive-mode."
  '((emacs "24.4"))
  :url "https://github.com/nbarrientos/archive-rpm"
  :commit "cb48fee04cb0cbb26f760a3b95649f7dac78c6ec"
  :revdesc "cb48fee04cb0"
  :keywords '("files")
  :authors '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainers '(("Magnus Henoch" . "magnus.henoch@gmail.com")))
