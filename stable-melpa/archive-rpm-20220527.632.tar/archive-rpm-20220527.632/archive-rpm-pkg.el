(define-package "archive-rpm" "20220527.632" "RPM and CPIO support for archive-mode"
  '((emacs "24.4"))
  :commit "4116be5ddab61d7f2366d5efcd23baa7519e6e84" :authors
  '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainer
  '("Magnus Henoch" . "magnus.henoch@gmail.com")
  :keywords
  '("files"))
;; Local Variables:
;; no-byte-compile: t
;; End:
