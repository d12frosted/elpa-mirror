;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250918.1205"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "ead8e029eaf105b49f8eaf613c8b0ba34bd6c043"
  :revdesc "ead8e029eaf1"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
