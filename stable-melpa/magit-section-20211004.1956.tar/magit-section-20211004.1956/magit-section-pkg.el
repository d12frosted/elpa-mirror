(define-package "magit-section" "20211004.1956" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "b1ad283941ecbcf382f69e807c04f5cb872e842c" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
