;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "20260708.2117"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "d8544f963463d9d2e6ae3b701c1538064d57c6df"
  :revdesc "d8544f963463"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
