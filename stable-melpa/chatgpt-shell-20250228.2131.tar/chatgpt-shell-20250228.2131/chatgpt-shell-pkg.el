;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250228.2131"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.76.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "8760b383810497f9cdce9e3884c8a6cfa6586c60"
  :revdesc "8760b3838104")
