(define-package "evalator" "20160130.1959" "Package for interactive transformation of data with helm"
  '((helm-core "1.9.1"))
  :commit "edf3840f5aa025cf38d0c2677b2f88f59079409e" :authors
  '(("Sean Irby"))
  :maintainer
  '("Sean Irby" . "sean.t.irby@gmail.com")
  :keywords
  '("languages" "elisp" "helm")
  :url "http://www.github.com/seanirby/evalator")
;; Local Variables:
;; no-byte-compile: t
;; End:
