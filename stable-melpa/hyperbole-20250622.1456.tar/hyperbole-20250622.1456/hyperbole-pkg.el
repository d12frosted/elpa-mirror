;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250622.1456"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "2860c801034f588d20faffa8eb94ddd4239f9c55"
  :revdesc "2860c801034f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
