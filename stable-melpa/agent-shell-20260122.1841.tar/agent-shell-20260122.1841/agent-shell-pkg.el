;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260122.1841"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8af3765b2b2a7198551befdcace90a3679f114c3"
  :revdesc "8af3765b2b2a")
