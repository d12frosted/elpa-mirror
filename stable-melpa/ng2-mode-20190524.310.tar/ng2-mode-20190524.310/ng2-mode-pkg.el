(define-package "ng2-mode" "20190524.310" "Major modes for editing Angular 2"
  '((typescript-mode "0.1"))
  :commit "57e6e4e388624853bc3b79bf5b17d2663ce26fa5" :authors
  '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainer
  '("Adam Niederer" . "adam.niederer@gmail.com")
  :keywords
  '("typescript" "angular" "angular2" "template")
  :url "http://github.com/AdamNiederer/ng2-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
