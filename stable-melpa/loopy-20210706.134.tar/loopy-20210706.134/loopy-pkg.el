(define-package "loopy" "20210706.134" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "680802487d3b8e9958c9d0084aa8070ef5a0daa7" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
