;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20251217.1700"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "bfbb50124b4d0b973a591b101d4326c764804530"
  :revdesc "bfbb50124b4d"
  :keywords '("extensions"))
