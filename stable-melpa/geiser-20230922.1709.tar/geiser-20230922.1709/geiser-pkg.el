(define-package "geiser" "20230922.1709" "GNU Emacs and Scheme talk to each other"
  '((emacs "27.1")
    (project "0.8.1"))
  :commit "6d106be16772e777c5bbb2c22750a344a21ff116" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainers
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
