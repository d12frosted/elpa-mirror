;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260220.1327"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "b0fb2c0fcbb5f178061b5b4bbe6ea17adabe7c36"
  :revdesc "b0fb2c0fcbb5"
  :keywords '("convenience" "comm" "hypermedia"))
