;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251022.1823"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "80fafabdaad123c80c82ea3eedfadfeb138f1232"
  :revdesc "80fafabdaad1"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
