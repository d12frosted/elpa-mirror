(define-package "maxima" "20201226.1538" "Major mode for Maxima"
  '((emacs "25.1")
    (s "1.11.0")
    (test-simple "1.3.0"))
  :commit "1600cfc059a80ed8fa0d381b88f29ba658811cc5" :authors
  '(("William F. Schelter")
    ("Jay Belanger")
    ("Fermin Munoz"))
  :maintainer
  '("Fermin Munoz" . "fmfs@posteo.net")
  :keywords
  '("maxima" "tools" "math")
  :url "https://gitlab.com/sasanidas/maxima")
;; Local Variables:
;; no-byte-compile: t
;; End:
