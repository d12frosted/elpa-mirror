(define-package "mb-url" "20230804.504" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "f4512a7f85dcc858404922deda1aaa952baf4e00" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
