;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontsloth" "20250605.1845"
  "Elisp otf/ttf font loader/renderer."
  '((f      "0.20.0")
    (logito "0.1")
    (pcache "0.5")
    (stream "2.2.5")
    (emacs  "28.1"))
  :url "https://github.com/jollm/fontsloth"
  :commit "10e06cdc7d6744b239de706085c04af2c16ba706"
  :revdesc "10e06cdc7d67"
  :keywords '("data" "font" "rasterization" "ttf" "otf")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")))
