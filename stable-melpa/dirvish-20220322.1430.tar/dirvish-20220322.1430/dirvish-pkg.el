(define-package "dirvish" "20220322.1430" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "684c00b4bb62dedf300e3b6f8d4b47c8b97d5532" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
