(define-package "evil-traces" "20230731.212" "Visual hints for `evil-ex'"
  '((emacs "25.1")
    (evil "1.2.13"))
  :commit "d4c53bd6addbe1bce7c77fdc10314f24451a2ecf" :authors
  '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainers
  '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainer
  '("Daniel Phan" . "daniel.phan36@gmail.com")
  :keywords
  '("emulations" "evil" "visual")
  :url "https://github.com/mamapanda/evil-traces")
;; Local Variables:
;; no-byte-compile: t
;; End:
