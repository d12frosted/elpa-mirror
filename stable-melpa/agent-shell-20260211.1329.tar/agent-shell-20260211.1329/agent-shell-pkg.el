;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260211.1329"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "318f080b773225347503866f7cf5b99c91e7e01c"
  :revdesc "318f080b7732")
