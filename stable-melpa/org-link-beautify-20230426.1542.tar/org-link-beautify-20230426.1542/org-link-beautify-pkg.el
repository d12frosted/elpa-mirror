(define-package "org-link-beautify" "20230426.1542" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1"))
  :commit "5887160b0164da4b1611e96642517acc120b83bb" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
