(define-package "modus-themes" "20211027.1018" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "c7c79b3efc09ff33bc746af42ba8ddc91f27a910" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
