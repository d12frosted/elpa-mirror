(define-package "julia-repl" "20210114.1549" "A minor mode for a Julia REPL"
  '((emacs "25.1")
    (s "1.12"))
  :commit "0774d3b5b954e82e5bbcbe5123c689341297b01e" :authors
  '(("Tamas Papp" . "tkpapp@gmail.com"))
  :maintainer
  '("Tamas Papp" . "tkpapp@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/tpapp/julia-repl")
;; Local Variables:
;; no-byte-compile: t
;; End:
