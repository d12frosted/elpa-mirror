(define-package "rhq" "20220916.1632" "Client for rhq"
  '((emacs "24.4"))
  :commit "7d9c5dee2e493eb0c5d41afca1b6049de8c2a26d" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("tools" "extensions")
  :url "https://github.com/ROCKTAKEY/rhq")
;; Local Variables:
;; no-byte-compile: t
;; End:
