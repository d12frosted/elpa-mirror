;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260815.1951"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "b16d9e65b62fe7b978c3af65c1188726b2e9e499"
  :revdesc "b16d9e65b62f"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
