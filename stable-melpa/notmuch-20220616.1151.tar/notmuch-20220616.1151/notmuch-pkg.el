(define-package "notmuch" "20220616.1151" "run notmuch within emacs" 'nil :commit "bfcf9a6c102af9232b6d2e720f919ff1c9b431f8" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
