(define-package "notmuch" "20220616.1151" "run notmuch within emacs" 'nil :commit "6f749dd24a1c8138a05ac92884e8cb71098c7f6e" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
