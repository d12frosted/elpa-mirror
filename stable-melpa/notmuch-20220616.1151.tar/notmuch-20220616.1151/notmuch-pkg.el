(define-package "notmuch" "20220616.1151" "run notmuch within emacs" 'nil :commit "9695e4c38de562249cbae02bd896d6bb46ba879f" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
