(define-package "notmuch" "20220616.1151" "run notmuch within emacs" 'nil :commit "6a9ae990990848ec99107f2e2e6b6ae12dcd33df" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
