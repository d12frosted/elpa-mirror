;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261031.132"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "61133c199a996d1ce6b93d199edc3ee21351c308"
  :revdesc "61133c199a99"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
