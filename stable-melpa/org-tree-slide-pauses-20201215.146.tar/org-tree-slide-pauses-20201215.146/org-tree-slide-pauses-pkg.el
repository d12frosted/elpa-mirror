;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tree-slide-pauses" "20201215.146"
  "Bring the pause command from Beamer to org-tree-slide."
  '((emacs          "24.5")
    (org-tree-slide "2.8.4"))
  :url "https://github.com/cnngimenez/org-tree-slide-pauses"
  :commit "f02af7102e9ecef7c3dac0d376d85bbb8c4de4cc"
  :revdesc "f02af7102e9e"
  :keywords '("convenience" "org-mode" "presentation"))
