;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260116.2206"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "54d5f644dce30a5030c91e70a0b5d8175fb1daab"
  :revdesc "54d5f644dce3"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
