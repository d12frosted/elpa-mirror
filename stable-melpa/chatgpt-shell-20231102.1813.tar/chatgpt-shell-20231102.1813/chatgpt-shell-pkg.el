(define-package "chatgpt-shell" "20231102.1813" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.42.1"))
  :commit "ff64e6bc9d0f7162f7e5331e70c8fdb186beccbc" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
