;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20260107.1724"
  "Miasma: color theme inspired by the woods."
  ()
  :url "http://github.com/daut/miasma-theme.el"
  :commit "39cc23dfd0f1938ae354f9c61e4ccf75c0a846f3"
  :revdesc "39cc23dfd0f1")
