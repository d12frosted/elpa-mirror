(define-package "notmuch" "20211030.1819" "run notmuch within emacs" 'nil :commit "78416a3e97fd19df5c89cdaf564c76be0edea740" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
