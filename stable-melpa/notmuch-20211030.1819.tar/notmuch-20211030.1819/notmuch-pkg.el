(define-package "notmuch" "20211030.1819" "run notmuch within emacs" 'nil :commit "fc3c79dd37d4bae938a5d0a1d7773bea48dd09b4" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
