;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260316.1735"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "31ac12b299d8f00ed44465f68babe0aa9b31a981"
  :revdesc "31ac12b299d8")
