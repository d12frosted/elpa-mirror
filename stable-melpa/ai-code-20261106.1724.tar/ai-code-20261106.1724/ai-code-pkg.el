;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261106.1724"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "cbefd4019d5659f6b0e8c5801c96e5d977e127fa"
  :revdesc "cbefd4019d56"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
