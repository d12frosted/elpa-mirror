(define-package "dwim-shell-command" "20231030.955" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "fdb92936ecc8a8e3ca46e32cbd8fce4f4adb79fd" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
