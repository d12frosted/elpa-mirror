(define-package "helm-core" "20230603.623" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "682277c14347d6269ad4dcecafb8255a8479fc4c" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
