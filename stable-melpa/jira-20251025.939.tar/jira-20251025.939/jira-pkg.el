;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20251025.939"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "617329b979fd8a76ee3f5a2af291d885bba4ec6d"
  :revdesc "617329b979fd"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
