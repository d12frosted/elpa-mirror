(define-package "sly-asdf" "20221119.2235" "ASDF system support for SLY"
  '((emacs "24.3")
    (sly "1.0.0beta2")
    (popup "0.5.3"))
  :commit "6f9d751469bb82530db1673c22e7437ca6c95f45" :maintainer
  '("Matt George" . "mmge93@gmail.com")
  :keywords
  '("languages" "lisp" "sly" "asdf")
  :url "https://github.com/mmgeorge/sly-asdf")
;; Local Variables:
;; no-byte-compile: t
;; End:
