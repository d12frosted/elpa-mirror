;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "20260702.1833"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "152cbf81ff72d22478b120e5fce455935a8f3fef"
  :revdesc "152cbf81ff72"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
