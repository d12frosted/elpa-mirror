;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260523.2135"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "cd32af7bd6b9c827701a62ed8f0c3bc705800f13"
  :revdesc "cd32af7bd6b9"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
