;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pycheckers" "20260624.439"
  "Multiple syntax checker for Python, using Flycheck."
  '((flycheck "0.18"))
  :url "https://github.com/msherry/flycheck-pycheckers"
  :commit "de546e52ceb3147da9688c428f7243e6d98af507"
  :revdesc "de546e52ceb3"
  :keywords '("convenience" "tools" "languages"))
