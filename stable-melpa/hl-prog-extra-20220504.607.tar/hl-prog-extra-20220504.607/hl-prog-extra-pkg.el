(define-package "hl-prog-extra" "20220504.607" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "cc09c1eb9460c1aa54ab1fc77331eae40cf7c3a3" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
