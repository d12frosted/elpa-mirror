;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "retrie" "20200519.551"
  "Refactoring Haskell code with retrie."
  '((emacs "24.5"))
  :url "https://github.com/Ailrun/emacs-retrie"
  :commit "976d6f01a3e214917f16b82e750d825cb9bfcc59"
  :revdesc "976d6f01a3e2"
  :keywords '("files" "languages" "tools")
  :authors '(("Junyoung Clare Jang" . "jjc9310@gmail.com"))
  :maintainers '(("Junyoung Clare Jang" . "jjc9310@gmail.com")))
