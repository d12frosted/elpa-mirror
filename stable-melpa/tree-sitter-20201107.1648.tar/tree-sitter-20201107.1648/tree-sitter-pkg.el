(define-package "tree-sitter" "20201107.1648" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.12.1"))
  :commit "dc9094b5066ec3c4ad583ed285c282f5811323b5" :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
