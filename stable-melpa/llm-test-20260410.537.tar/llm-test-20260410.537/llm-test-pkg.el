;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260410.537"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "134b73aef30080b54bcebfa1ad42a67017fd561b"
  :revdesc "134b73aef300"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
