(define-package "rainbow-fart" "20220427.2227" "Checks the keywords of code to play suitable sounds"
  '((emacs "25.1")
    (flycheck "32snapshot"))
  :commit "6504424707b6e9101dfbd9fdd4b7b963b9a4f323" :keywords
  '("tools")
  :url "https://repo.or.cz/emacs-rainbow-fart.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
