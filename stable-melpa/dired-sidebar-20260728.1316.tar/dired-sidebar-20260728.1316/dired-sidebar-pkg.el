;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-sidebar" "20260728.1316"
  "Tree browser leveraging dired."
  '((emacs  "29.1")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/dired-sidebar"
  :commit "5fb534940a1d990f4d5424303a5da043c5f26a06"
  :revdesc "5fb534940a1d"
  :keywords '("dired" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
