;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "20260601.1544"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "31.0")
    (cond-let "1.1")
    (elx      "2.3")
    (llama    "1.0")
    (magit    "4.5"))
  :url "https://github.com/magit/sisyphus"
  :commit "4c88989715f2c347714e9cad26b03789e2b68143"
  :revdesc "4c88989715f2"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
