(define-package "kmacro-x" "20230306.27" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "9c898e07ee1a10390889254ef38babcbe1a6c0fd" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
