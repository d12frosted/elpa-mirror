;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260309.513"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "df19db8fa8f4a9b7be41037fd599895a58c09890"
  :revdesc "df19db8fa8f4")
