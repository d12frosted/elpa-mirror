(define-package "with-editor" "20230212.2010" "Use the Emacsclient as $EDITOR"
  '((emacs "25.1")
    (compat "29.1.3.4"))
  :commit "e5ba1cab376e71e7a858dd4855365a57c4ddb40d" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("processes" "terminals")
  :url "https://github.com/magit/with-editor")
;; Local Variables:
;; no-byte-compile: t
;; End:
