(define-package "mono-complete" "20230309.423" "Completion suggestions with multiple back-ends"
  '((emacs "28.1"))
  :commit "184af2d866f049120e16185b0bc05d910adbef41" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mono-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
