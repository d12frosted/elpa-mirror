(define-package "live-py-mode" "20210701.1735" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "96ca0e9058d8c1e533ce9aa1396e49f086362b06" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
