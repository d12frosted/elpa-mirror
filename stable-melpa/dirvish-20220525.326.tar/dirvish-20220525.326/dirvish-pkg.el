(define-package "dirvish" "20220525.326" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "6993a94b0b16447f49386d6769b1d32abc89c2a3" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
