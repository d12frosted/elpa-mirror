(define-package "dirvish" "20220104.1929" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "5fbdd7fd9aed7c15e4dabf4b05d95ad1043a92c4" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
