;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251107.1334"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "387f9acc5135206dfc6fbf6f19ebc69375209384"
  :revdesc "387f9acc5135"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
