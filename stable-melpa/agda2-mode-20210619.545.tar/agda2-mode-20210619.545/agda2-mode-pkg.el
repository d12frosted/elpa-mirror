(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "af9c4b968698e285c453516b2104a347ad954849")
;; Local Variables:
;; no-byte-compile: t
;; End:
