(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "9910f68392610e2b74f238a1cadc5974d8b0973e")
;; Local Variables:
;; no-byte-compile: t
;; End:
