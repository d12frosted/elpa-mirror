(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "e75750a55d8c45132f772eea341c7541f4989f04")
;; Local Variables:
;; no-byte-compile: t
;; End:
