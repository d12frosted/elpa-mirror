(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "47a49fd5798ffd3919f4a0a84e3b5d6ac5a43077")
;; Local Variables:
;; no-byte-compile: t
;; End:
