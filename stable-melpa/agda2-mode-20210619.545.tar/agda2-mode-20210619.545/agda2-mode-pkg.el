(define-package "agda2-mode" "20210619.545" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "16faf8a529f83a1e62f1865cd10291f4d485f1be")
;; Local Variables:
;; no-byte-compile: t
;; End:
