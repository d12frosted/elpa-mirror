;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-gauche" "20251213.1148"
  "Gauche scheme support for Geiser."
  '((emacs  "26.1")
    (geiser "0.11.2"))
  :url "https://gitlab.com/emacs-geiser/gauche"
  :commit "adbd3c8d9031955c5941af459ea0e2bd60b7c925"
  :revdesc "adbd3c8d9031"
  :keywords '("languages" "gauche" "scheme" "geiser")
  :authors '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainers '(("András Simonyi" . "andras.simonyi@gmail.com")))
