(define-package "ebib" "20220313.1344" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "5ae2b07a81f7a0ec9b9160882d482d6bf381209b" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
