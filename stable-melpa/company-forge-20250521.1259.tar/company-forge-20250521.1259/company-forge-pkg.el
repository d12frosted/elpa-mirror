;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-forge" "20250521.1259"
  "Company backend for assignees and topics from forge."
  '((emacs   "29.1")
    (company "1.0.0")
    (forge   "0.5.0"))
  :url "https://github.com/pkryger/company-forge.el"
  :commit "71868846bf6d210292f585fc5d64c654bbe1807f"
  :revdesc "71868846bf6d"
  :keywords '("convenience" "completion" "company" "forge")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
