;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20251222.1240"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "ec31b75a972e4ab112fcf43faf90f312dc8b42a7"
  :revdesc "ec31b75a972e"
  :keywords '("frames"))
