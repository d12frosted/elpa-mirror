(define-package "dtache" "20220320.932" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "6e761e890691e52555eb12dcb5b009d13a146c4d" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
