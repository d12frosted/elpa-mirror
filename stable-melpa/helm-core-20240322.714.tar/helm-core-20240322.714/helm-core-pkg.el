(define-package "helm-core" "20240322.714" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "0e838f03c8bd397850a8683b905658bfb4a76e4f" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
