;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260221.302"
  "Unified interface for AI coding backends such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, agent-shell, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "271cccd064966de8e13322fc70b3cff0b4650f62"
  :revdesc "271cccd06496"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
