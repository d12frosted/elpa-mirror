;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plantuml-mode" "20250514.1810"
  "Major mode for PlantUML."
  '((dash  "2.0.0")
    (emacs "25.0"))
  :url "https://github.com/skuro/plantuml-mode"
  :commit "c59c5929a6418351550f02669121530fffb6f98a"
  :revdesc "c59c5929a641"
  :keywords '("uml" "plantuml" "ascii"))
