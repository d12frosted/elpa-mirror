;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-rails" "20260415.1855"
  "Rails support for project.el."
  '((emacs       "28.1")
    (inflections "2.6"))
  :url "https://github.com/harrybournis/project.el-rails"
  :commit "d066f984eb88c6d239d19adbf8025bcafe665d53"
  :revdesc "d066f984eb88"
  :keywords '("languages" "project.el" "rails")
  :authors '(("Harry Bournis" . "harrybournis@gmail.com"))
  :maintainers '(("Harry Bournis" . "harrybournis@gmail.com")))
