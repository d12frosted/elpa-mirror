;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gtd" "20260106.220"
  "An implementation of GTD."
  '((emacs     "28.1")
    (compat    "30.0.0.0")
    (org-edna  "1.1.2")
    (f         "0.20.0")
    (org       "9.6")
    (transient "0.11.0")
    (dag-draw  "1.0.4"))
  :url "https://github.com/Trevoke/org-gtd.el"
  :commit "a52c86febf76bd3976dd93f0b64eee0947f1cfe0"
  :revdesc "a52c86febf76"
  :authors '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainers '(("Aldric Giacomoni" . "trevoke@gmail.com")))
