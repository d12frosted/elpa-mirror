;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260228.2310"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "934e0ab0a02d3d6d50f222d763b7fbf9d46edf39"
  :revdesc "934e0ab0a02d"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
