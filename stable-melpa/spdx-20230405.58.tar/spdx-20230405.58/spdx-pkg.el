(define-package "spdx" "20230405.58" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "b0640e03cc237d2c378a809a6e5acb1ffb2fa97a" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
