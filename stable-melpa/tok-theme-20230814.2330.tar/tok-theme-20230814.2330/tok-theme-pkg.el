(define-package "tok-theme" "20230814.2330" "Minimal monochromatic theme for Emacs in the spirit of Zmacs and Smalltalk-80."
  '((emacs "27.0"))
  :commit "81531a0ae0b6c16d2e2dcec0e83b90480c141793" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
