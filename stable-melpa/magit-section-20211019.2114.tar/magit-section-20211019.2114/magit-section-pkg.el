(define-package "magit-section" "20211019.2114" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "65c4485e19bf570ebcb81fbaa6352c4e94bb05da" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
