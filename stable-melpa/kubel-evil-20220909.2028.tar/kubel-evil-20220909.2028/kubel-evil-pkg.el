(define-package "kubel-evil" "20220909.2028" "extension for kubel to provide evil keybindings"
  '((kubel "1.0")
    (evil "1.0")
    (emacs "25.3"))
  :commit "1b405d8756ffc7c8f1e11450d6f07ffde38fe351" :authors
  '(("Marcel Patzwahl"))
  :maintainers
  '(("Marcel Patzwahl"))
  :maintainer
  '("Marcel Patzwahl")
  :keywords
  '("kubernetes" "k8s" "tools" "processes" "evil" "keybindings")
  :url "https://github.com/abrochard/kubel")
;; Local Variables:
;; no-byte-compile: t
;; End:
