(define-package "affe" "20230212.23" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.32"))
  :commit "76f49ab2f71e33d41d2789c08b55ad33d02d7f1f" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
