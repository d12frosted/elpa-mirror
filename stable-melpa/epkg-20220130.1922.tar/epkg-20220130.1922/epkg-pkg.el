(define-package "epkg" "20220130.1922" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "c18a2fc8b4a83ceea6a1128d7a77107983301e56" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
