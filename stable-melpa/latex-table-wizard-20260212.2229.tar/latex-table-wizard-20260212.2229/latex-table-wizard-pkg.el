;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-table-wizard" "20260212.2229"
  "Magic editing of LaTeX tables."
  '((emacs     "27.1")
    (auctex    "12.1")
    (transient "0.3.7"))
  :url "https://github.com/enricoflor/latex-table-wizard"
  :commit "681c03010e38e8cb4089171be72d73e6d28cd472"
  :revdesc "681c03010e38"
  :keywords '("convenience" "tex")
  :authors '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers '(("Enrico Flor" . "enrico@eflor.net")))
