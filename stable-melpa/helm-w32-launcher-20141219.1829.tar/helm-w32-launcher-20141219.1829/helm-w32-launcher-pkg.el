(define-package "helm-w32-launcher" "20141219.1829" "Start Menu entry launcher using Helm"
  '((emacs "24")
    (helm "1.6.5")
    (cl-lib "0.5"))
  :commit "01aa370a32900e7521330fba495474f2aa435e19" :authors
  '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainer
  '("Fanael Linithien" . "fanael4@gmail.com")
  :url "https://github.com/Fanael/helm-w32-launcher")
;; Local Variables:
;; no-byte-compile: t
;; End:
