;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251222.1050"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "4be939efc6e40b3c028167343b930faf6017a555"
  :revdesc "4be939efc6e4"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
