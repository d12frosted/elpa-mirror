(define-package "modus-themes" "20210519.553" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "0800640b5a806a2335cf6f90496aa2ab8c2884bb" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
