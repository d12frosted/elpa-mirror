;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260511.1603"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "dcea3206b8474e7bb701c494b604924501b9dea4"
  :revdesc "dcea3206b847"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
