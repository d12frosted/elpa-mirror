;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20261101.1629"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "fcd3c9cf38555ac98c04d3e3a090770f5e55e2e6"
  :revdesc "fcd3c9cf3855"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
