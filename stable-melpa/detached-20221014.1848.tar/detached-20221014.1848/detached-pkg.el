(define-package "detached" "20221014.1848" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "6f59d856b95b309506f7ca62675d24f0a6b556ea" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
