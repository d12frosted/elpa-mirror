;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260317.2222"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "79a6c6631e8b817419f24d7e85a6f8f75d393e5d"
  :revdesc "79a6c6631e8b"
  :keywords '("files"))
