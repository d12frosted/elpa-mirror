(define-package "biome" "20230817.1601" "Bountiful Interface to Open Meteo for Emacs"
  '((emacs "27.1")
    (transient "0.3.7")
    (ct "0.2")
    (request "0.3.3")
    (compat "29.1.4.1"))
  :commit "e1ab97b773807211517f8ce1f68e507f0cbf54fe" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/biome")
;; Local Variables:
;; no-byte-compile: t
;; End:
