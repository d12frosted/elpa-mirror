;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261109.2254"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "e09cd62ada58d5e38986a81101cffe1be28e527d"
  :revdesc "e09cd62ada58"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
