(define-package "srfi" "20231115.1901" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "97fa0664ee4852b18201a3fcac265ac8c52a4a4b" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
