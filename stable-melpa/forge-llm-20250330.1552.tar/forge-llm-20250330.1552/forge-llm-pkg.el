;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forge-llm" "20250330.1552"
  "LLM integration for generating PR descriptions in Forge."
  '((emacs "25.1")
    (forge "0.3.0")
    (llm   "0.16.1"))
  :url "https://gitlab.com/rogs/forge-llm"
  :commit "a0a42b42b2d1f6c4fbb110d1aecec61c55122758"
  :revdesc "a0a42b42b2d1"
  :keywords '("convenience" "forge" "git" "llm" "github" "gitlab" "pull-request")
  :authors '(("Roger Gonzalez" . "roger@rogs.me"))
  :maintainers '(("Roger Gonzalez" . "roger@rogs.me")))
