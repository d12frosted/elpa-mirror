(define-package "embark" "20220507.144" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d2e192050de64261e993b84ae01d7a0d0e6a196c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
