;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20241014.337"
  "LSP mode."
  '((emacs         "27.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "1bec6551cbb67b7ccaab6bc70fd4f65efc678723"
  :revdesc "1bec6551cbb6"
  :keywords '("languages"))
