;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evenok" "20260221.2125"
  "Themes with perceptively evenly distributed colors."
  '((emacs "28.1"))
  :url "https://codeberg.org/mekeor/evenok"
  :commit "6b5e3c10d3649be6ea9df5cc369d8a4d4a03f3aa"
  :revdesc "6b5e3c10d364"
  :keywords '("faces" "theme")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
