(define-package "burly" "20210621.845" "Save and restore frame/window configurations with buffers"
  '((emacs "26.3")
    (map "2.1"))
  :commit "c6d6aaeded0ef892af307652503de21db2a2a5b3" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
