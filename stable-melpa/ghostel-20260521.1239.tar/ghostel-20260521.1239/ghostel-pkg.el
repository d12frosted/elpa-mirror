;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260521.1239"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "15ba01332e7f520c0ad42d418b718332b03ca408"
  :revdesc "15ba01332e7f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
