;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "har-viewer" "20260519.304"
  "Major mode for viewing HTTP Archive (HAR) files."
  '((emacs "26.1"))
  :url "https://github.com/bozoslivehere/har-viewer.el"
  :commit "b3d60fe799c0e52bb0a94ead2e9ecf4d6ea8f416"
  :revdesc "b3d60fe799c0"
  :keywords '("tools" "http" "network")
  :authors '(("Gregory Newman" . "bozoslivehere@protonmail.com"))
  :maintainers '(("Gregory Newman" . "bozoslivehere@protonmail.com")))
