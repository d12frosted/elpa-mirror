;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reaper" "20260113.2130"
  "Interact with Harvest time tracking app."
  '((emacs "26.2"))
  :url "https://github.com/xendk/reaper"
  :commit "5bbac37655db6e05eafade358b4f59f6ecedda38"
  :revdesc "5bbac37655db"
  :keywords '("tools")
  :authors '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers '(("Thomas Fini Hansen" . "xen@xen.dk")))
