(define-package "org-mpv-notes" "20230828.1747" "Take notes in org mode while watching videos in mpv"
  '((emacs "27.1")
    (mpv "0.2.0"))
  :commit "04ff69a0494a2f81f2f982caf31326a03cb2135b" :authors
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainers
  '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainer
  '("Bibek Panthi" . "bpanthi977@gmail.com")
  :url "https://github.com/bpanthi977/org-mpv-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
