;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260621.829"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "fd0a3e27108d288edb8dd1b3f19de12652f6e549"
  :revdesc "fd0a3e27108d"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
