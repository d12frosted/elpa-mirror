(define-package "darktooth-theme" "20220819.754" "From the darkness... it watches"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "d6f3876d686b9af5a5eb80bc55ae3d17f8ec42b8" :url "http://github.com/emacsfodder/emacs-theme-darktooth")
;; Local Variables:
;; no-byte-compile: t
;; End:
