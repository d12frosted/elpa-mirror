;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cyphejor" "20260802.938"
  "Shorten major mode names using user-defined rules."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/cyphejor"
  :commit "d18322bb02686aaf6f0da63debcec8e66523d65d"
  :revdesc "d18322bb0268"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
