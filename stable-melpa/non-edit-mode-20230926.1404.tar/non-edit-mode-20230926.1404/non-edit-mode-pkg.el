;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "non-edit-mode" "20230926.1404"
  "Minor mode that disables editing."
  '((emacs "24.1"))
  :url "https://gitlab.com/aragaer/non-edit-mode"
  :commit "bc9d29e437d70675c725f3ef8a66abe574b9a142"
  :revdesc "bc9d29e437d7"
  :keywords '("convenience")
  :authors '(("aragaer" . "aragaer@gmail.com"))
  :maintainers '(("aragaer" . "aragaer@gmail.com")))
