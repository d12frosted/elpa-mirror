(define-package "modus-themes" "20220629.546" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "7241ea0a4160a34167720964190681f2d70139ed" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
