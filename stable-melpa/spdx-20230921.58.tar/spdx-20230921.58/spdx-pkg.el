(define-package "spdx" "20230921.58" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "31874b45fb0f91042ca988823534e958bb9f60df" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
