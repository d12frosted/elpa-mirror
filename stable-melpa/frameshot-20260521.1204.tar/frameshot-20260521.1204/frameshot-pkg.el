;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frameshot" "20260521.1204"
  "Take screenshots of a frame."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/frameshot"
  :commit "57be773fccc3f24b1e2aa3f20f25d543e34d1b60"
  :revdesc "57be773fccc3"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev")))
