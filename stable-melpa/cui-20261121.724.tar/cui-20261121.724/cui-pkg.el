;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261121.724"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "9a922a2d33cdf97002067b3c63eb581225718bff"
  :revdesc "9a922a2d33cd"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
