;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251106.2317"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "216c93b268db8d9fa40fb66b4f20093b0be548eb"
  :revdesc "216c93b268db"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
