(define-package "projection-multi" "20230529.1035" "Projection integration for `compile-multi'"
  '((emacs "29")
    (projection "0.1")
    (compile-multi "0.3"))
  :commit "917ac108a698056b819e31e7d06e8520150dac59" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
