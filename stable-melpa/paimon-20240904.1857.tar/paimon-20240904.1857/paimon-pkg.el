;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paimon" "20240904.1857"
  "A major mode for Splunk."
  '((aio       "1.0")
    (closql    "2.0.0")
    (emacs     "28.1")
    (emacsql   "4.0.2")
    (f         "0.20.0")
    (ht        "2.4")
    (transient "0.7.5")
    (request   "0.3.2")
    (compat    "30.0.0.0"))
  :url "https://github.com/r0man/paimon.el"
  :commit "b3a5b1ca20e221cc88e20169635076b9b1b08a51"
  :revdesc "b3a5b1ca20e2"
  :keywords '("paimon" "search" "tools")
  :authors '(("r0man" . "roman@burningswell.com"))
  :maintainers '(("r0man" . "roman@burningswell.com")))
