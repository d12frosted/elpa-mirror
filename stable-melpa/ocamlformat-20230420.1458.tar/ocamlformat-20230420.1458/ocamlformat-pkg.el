(define-package "ocamlformat" "20230420.1458" "Utility functions to format ocaml code"
  '((emacs "24.3"))
  :commit "ee9cdd7e19298dc025d77212cab11b3d97b9972f" :keywords
  '("languages" "ocaml")
  :url "https://github.com/ocaml-ppx/ocamlformat")
;; Local Variables:
;; no-byte-compile: t
;; End:
