;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-defer" "20201116.701"
  "Defer non-essential vc.el work."
  '((emacs "25.1"))
  :url "https://github.com/google/vc-defer"
  :commit "aeafc419c1788b3ac4f0590c635374eefd7c220c"
  :revdesc "aeafc419c178"
  :keywords '("vc" "tools")
  :authors '(("Matt Armstrong" . "marmstrong@google.com"))
  :maintainers '(("Tom Fitzhenry" . "tomfitzhenry@google.com")))
