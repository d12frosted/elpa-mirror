(define-package "evil-tutor-sc" "20230625.2254" "Simplified Chinese Evil-tutor"
  '((evil "1.0.9")
    (evil-tutor "0.1"))
  :commit "73d94afff90bd42c0df45fd060f2c34885644a51" :authors
  '(("clsty" . "ph-tyhu@outlook.com"))
  :maintainers
  '(("clsty" . "ph-tyhu@outlook.com"))
  :maintainer
  '("clsty" . "ph-tyhu@outlook.com")
  :keywords
  '("convenience" "editing" "evil" "chinese")
  :url "https://github.com/clsty/evil-tutor-sc")
;; Local Variables:
;; no-byte-compile: t
;; End:
