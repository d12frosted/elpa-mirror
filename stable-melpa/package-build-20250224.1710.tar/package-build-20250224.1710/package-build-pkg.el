;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20250224.1710"
  "Tools for assembling a package archive."
  '((emacs  "26.1")
    (compat "30.0.0.0"))
  :url "https://github.com/melpa/package-build"
  :commit "0133e09573866d8e7af6c17a2861e5ed7bfc532b"
  :revdesc "0133e0957386"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")))
