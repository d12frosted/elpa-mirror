;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260220.1331"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "ec8130cfe1a7390e9939b311c8db39907a3f7f44"
  :revdesc "ec8130cfe1a7"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
