;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-flycheck" "20260117.1654"
  "Provides the command `consult-flycheck'."
  '((emacs    "29.1")
    (consult  "2.8")
    (flycheck "35"))
  :url "https://github.com/minad/consult-flycheck"
  :commit "9fe96c4b75c8566170ad41a04c3849d2e2606104"
  :revdesc "9fe96c4b75c8"
  :keywords '("languages" "tools" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
