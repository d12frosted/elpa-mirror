(define-package "apdl-mode" "20200501.1904" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "ee5f546f6659b9ca3c6895a1959087531b4a016a" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
