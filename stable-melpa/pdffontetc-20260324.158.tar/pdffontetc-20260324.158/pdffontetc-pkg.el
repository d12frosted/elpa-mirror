;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdffontetc" "20260324.158"
  "Display `pdffont' and other PDF information."
  '((emacs     "24.4")
    (pdf-tools "1.2.0"))
  :url "https://github.com/emacsomancer/pdffontetc"
  :commit "d73e73ea367b40a9972747024f6703304c6d5df0"
  :revdesc "d73e73ea367b"
  :keywords '("files" "multimedia")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
