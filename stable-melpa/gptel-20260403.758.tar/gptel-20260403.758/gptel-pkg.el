;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260403.758"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "46c735c692c10f3cdcdfe46e182334af85de4489"
  :revdesc "46c735c692c1"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
