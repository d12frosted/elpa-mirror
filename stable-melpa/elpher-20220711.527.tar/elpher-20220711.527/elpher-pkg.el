(define-package "elpher" "20220711.527" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "d31e967beeba40a32e4da0b36d8fbb47b6bfb228" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
