(define-package "macports" "20220522.438" "A porcelain for MacPorts"
  '((emacs "25.1")
    (transient "0.1.0"))
  :commit "3d516f4ef5ab4623527d26fefc4d77a748f49475" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("convenience")
  :url "https://github.com/amake/macports.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
