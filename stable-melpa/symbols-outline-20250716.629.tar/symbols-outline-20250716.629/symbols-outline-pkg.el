;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symbols-outline" "20250716.629"
  "Display symbols (functions, variables, etc) in outline view."
  '((emacs "27.1"))
  :url "https://github.com/liushihao456/symbols-outline.el"
  :commit "2b743a6b2939d879c7a19657ccf143292d24c134"
  :revdesc "2b743a6b2939"
  :keywords '("outlines"))
