(define-package "meow" "20211220.2146" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "2a7d647f68fc5e2f78671e2eb0b114cce8eec6aa" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
