(define-package "yaml-pro" "20220901.311" "Parser-aided YAML editing features"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "22121b234b484bbf9735c6122ce00663b80608ca" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("tools")
  :url "https://github.com/zkry/yaml-pro")
;; Local Variables:
;; no-byte-compile: t
;; End:
