;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251028.2333"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "2d41296f8b1c2aff17114db3d85516254817d34b"
  :revdesc "2d41296f8b1c"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
