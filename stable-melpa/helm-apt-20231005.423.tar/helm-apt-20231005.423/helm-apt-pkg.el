;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-apt" "20231005.423"
  "Helm interface for Debian/Ubuntu packages (apt-*)."
  '((helm  "3.9.5")
    (emacs "25.1"))
  :url "https://github.com/emacs-helm/helm-apt"
  :commit "3ddbb62f483d2bbdbfcab4160040eaad22a82d67"
  :revdesc "3ddbb62f483d"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
