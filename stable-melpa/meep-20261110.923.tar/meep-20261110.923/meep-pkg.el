;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20261110.923"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "c83335eb7484eaf8549b2fbf51f8dd2e0223dad8"
  :revdesc "c83335eb7484"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
