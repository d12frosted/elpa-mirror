(define-package "posframe" "20220107.1125" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "e8ad9e757db710da1953f13d6fd8055f2624c1dc" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
