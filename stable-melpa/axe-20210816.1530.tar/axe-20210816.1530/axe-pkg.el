(define-package "axe" "20210816.1530" "AWS Extensions"
  '((emacs "25.1")
    (hmac "0.0")
    (request "0.3.2")
    (s "1.12.0")
    (xmlgen "0.5")
    (dash "2.17.0")
    (mimetypes "1.0"))
  :commit "a6d2561731c219fc00daeeb9fd0cf67392282a23" :authors
  '(("Craig Niles <niles.c at gmail.com>"))
  :maintainer
  '("Craig Niles <niles.c at gmail.com>")
  :url "https://github.com/cniles/axe")
;; Local Variables:
;; no-byte-compile: t
;; End:
