(define-package "axe" "20210816.1530" "AWS Extensions"
  '((emacs "25.1")
    (hmac "0.0")
    (request "0.3.2")
    (s "1.12.0")
    (xmlgen "0.5")
    (dash "2.17.0")
    (mimetypes "1.0"))
  :commit "3be04d03c1be88b3fb71f95164fb1971c2472c25" :authors
  '(("Craig Niles <niles.c at gmail.com>"))
  :maintainer
  '("Craig Niles <niles.c at gmail.com>")
  :url "https://github.com/cniles/axe")
;; Local Variables:
;; no-byte-compile: t
;; End:
