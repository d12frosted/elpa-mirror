(define-package "daemons" "20180610.1510" "UI for managing init system daemons (services)"
  '((emacs "25.1"))
  :commit "dcf42cb3178d7245d6d49de346d5e2b44e5b7498" :authors
  '(("Chris Bowdon"))
  :maintainer
  '("Chris Bowdon")
  :keywords
  '("unix" "convenience")
  :url "https://github.com/cbowdon/daemons.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
