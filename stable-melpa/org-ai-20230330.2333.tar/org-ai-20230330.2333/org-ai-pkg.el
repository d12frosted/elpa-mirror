(define-package "org-ai" "20230330.2333" "Your AI assistant with ChatGPT, DALL-E, Whisper"
  '((emacs "28.2"))
  :commit "15b904dd58914d36a54df53c8ac1e1961a361fb4" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
