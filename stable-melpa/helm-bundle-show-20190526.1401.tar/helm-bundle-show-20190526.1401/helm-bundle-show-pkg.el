;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bundle-show" "20190526.1401"
  "Bundle show with helm interface."
  '((emacs "24")
    (helm  "1.8.0"))
  :url "https://github.com/masutaka/emacs-helm-bundle-show"
  :commit "70f1ca7d1847c7d5cd5a3e488562cd4a295b809f"
  :revdesc "70f1ca7d1847"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
