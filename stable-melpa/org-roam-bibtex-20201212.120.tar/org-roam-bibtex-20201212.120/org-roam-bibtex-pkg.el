(define-package "org-roam-bibtex" "20201212.120" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "1.2.2")
    (bibtex-completion "2.0.0"))
  :commit "c201728d788686f0d215e401c25d628466d81d7f" :keywords
  ("bib" "hypermedia" "outlines" "wp")
  :authors
  (("Leo Vivier" . "leo.vivier+dev@gmail.com")
   ("Mykhailo Shevchuk" . "mail@mshevchuk.com")
   ("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  ("Leo Vivier" . "leo.vivier+dev@gmail.com")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
