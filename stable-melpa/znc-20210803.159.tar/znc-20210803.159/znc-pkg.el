;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "znc" "20210803.159"
  "ZNC + ERC."
  '((cl-lib "0.2"))
  :url "https://github.com/sshirokov/ZNC.el"
  :commit "2605f78e37a8a759067dc14fa25a82824ba1bacc"
  :revdesc "2605f78e37a8")
