(define-package "nsis-mode" "20230522.2251" "NSIS-mode" 'nil :commit "50d59dc6a915511b14824f13182d764e00ddd44a" :authors
  '(("Matthew L. Fidler"))
  :maintainers
  '(("Matthew L. Fidler"))
  :maintainer
  '("Matthew L. Fidler")
  :keywords
  '("nsis")
  :url "http://github.com/mlf176f2/nsis-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
