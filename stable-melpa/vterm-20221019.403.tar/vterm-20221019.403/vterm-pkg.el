(define-package "vterm" "20221019.403" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "e9bfe56ca264e1b692a9c33fa8edb369e728a0c9" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
