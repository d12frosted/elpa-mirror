;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "file-info" "20260425.1631"
  "Show pretty information about current file."
  '((emacs            "28.1")
    (hydra            "0.15.0")
    (browse-at-remote "0.15.0"))
  :url "https://github.com/artawower/file-info.el"
  :commit "6cfc1cad72290ad241acc76c59fec6a26a62307c"
  :revdesc "6cfc1cad7229"
  :authors '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers '(("Artur Yaroshenko" . "artawower@protonmail.com")))
