(define-package "org-assistant" "20230525.456" "Org babel extension for Chat Assistant APIs"
  '((emacs "28.1")
    (uuidgen "1.2")
    (deferred "0.5.1")
    (s "1.12.0")
    (dash "2.19.1")
    (ht "0.9"))
  :commit "c572c1a2f63fc8e05b8ff8ef4bc8956ff89edff9" :authors
  '(("Tyler Dodge" . "tyler@tdodge.consulting"))
  :maintainers
  '(("Tyler Dodge" . "tyler@tdodge.consulting"))
  :maintainer
  '("Tyler Dodge" . "tyler@tdodge.consulting")
  :keywords
  '("convenience")
  :url "https://github.com/tyler-dodge/org-assistant")
;; Local Variables:
;; no-byte-compile: t
;; End:
