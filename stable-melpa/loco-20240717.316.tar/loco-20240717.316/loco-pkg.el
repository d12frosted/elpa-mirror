(define-package "loco" "20240717.316" "A library and minor mode for entering key sequences"
  '((emacs "29.1"))
  :commit "fdd11b029346fb08ca6032370bd2cb5d9231d882" :authors
  '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainers
  '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainer
  '("Chris McLaren" . "csmclaren@me.com")
  :keywords
  '("abbrev" "convenience")
  :url "https://github.com/csmclaren/loco")
;; Local Variables:
;; no-byte-compile: t
;; End:
