;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel-collection" "20260102.1417"
  "Collection of templates for Tempel."
  '((tempel "0.5")
    (emacs  "29.1"))
  :url "https://github.com/Crandel/tempel-collection"
  :commit "fb5759fbaadde45dd55c2c84dae3ead17212f7e0"
  :revdesc "fb5759fbaadd"
  :keywords '("tools")
  :authors '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
             ("Max Penet" . "mpenetr@s-exp.com")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
                 ("Max Penet" . "mpenetr@s-exp.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
