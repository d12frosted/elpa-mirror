(define-package "dwim-shell-command" "20230517.1815" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "91603da9632f411f509dc99f2899c6eb602ee250" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
