(define-package "consult" "20230225.1038" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "f19e35edf2361ca2592edb35778ebc7d665ae9a5" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
