;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zephir-mode" "20200417.830"
  "Major mode for editing Zephir code."
  '((cl-lib   "0.5")
    (pkg-info "0.4")
    (emacs    "25.1"))
  :url "https://github.com/zephir-lang/zephir-mode"
  :commit "4e9618b77dff67c1c7b6fff78605a62311db88b8"
  :revdesc "4e9618b77dff"
  :keywords '("languages")
  :authors '(("Serghei Iakovlev" . "egrep@protonmail.ch"))
  :maintainers '(("Serghei Iakovlev" . "egrep@protonmail.ch")))
