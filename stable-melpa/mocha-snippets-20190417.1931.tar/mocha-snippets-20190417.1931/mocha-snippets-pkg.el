(define-package "mocha-snippets" "20190417.1931" "Yasnippets for the Mocha JS Testing Framework"
  '((yasnippet "0.8.0"))
  :commit "361a3809f755577406e109b9e44d473dfa7c08e0" :authors
  '(("Charles Lowell" . "cowboyd@frontside.io"))
  :maintainer
  '("Charles Lowell" . "cowboyd@frontside.io")
  :keywords
  '("test" "javascript"))
;; Local Variables:
;; no-byte-compile: t
;; End:
