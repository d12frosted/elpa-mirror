(define-package "org-runbook" "20230120.140" "Org mode for runbooks" 'nil :commit "be8218d66493c122a60049ff5e6bd41abfaabbd8" :authors
  '(("Tyler Dodge"))
  :maintainer
  '("Tyler Dodge")
  :keywords
  '("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
