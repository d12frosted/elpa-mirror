;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-mode" "20220706.507"
  "Hide password text using overlays."
  '((emacs "25.1"))
  :url "https://github.com/juergenhoetzel/password-mode"
  :commit "883981d9f8d0e2a8ec479c89f5f6b2492c22e01a"
  :revdesc "883981d9f8d0"
  :keywords '("docs" "password" "passphrase")
  :authors '(("Jürgen Hötzel" . "juergen@archlinux.org"))
  :maintainers '(("Jürgen Hötzel" . "juergen@archlinux.org")))
