;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "squirrel-mode" "20221227.232"
  "A major mode for the Squirrel programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/squirrel-mode"
  :commit "1af79dfe70c4c8e6f0f144bfd2eb65c077aca785"
  :revdesc "1af79dfe70c4"
  :keywords '("files" "squirrel"))
