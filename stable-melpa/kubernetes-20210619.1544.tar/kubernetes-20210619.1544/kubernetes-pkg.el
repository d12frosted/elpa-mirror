(define-package "kubernetes" "20210619.1544" "Magit-like porcelain for Kubernetes."
  '((emacs "25.1")
    (dash "2.12.0")
    (magit "2.8.0")
    (magit-popup "2.13.0"))
  :commit "01e8e231c08555b24a97f50da8f772e12caaa8b0" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool"))
;; Local Variables:
;; no-byte-compile: t
;; End:
