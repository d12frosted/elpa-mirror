;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "20260501.853"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "ca9cba428d24c155094f1b099c73f6f9692fc733"
  :revdesc "ca9cba428d24"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
