;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241118.1103"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (el-job "0.3.4")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "2b00e581249c99b24699a47c9a4c6c8657960792"
  :revdesc "2b00e581249c"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
