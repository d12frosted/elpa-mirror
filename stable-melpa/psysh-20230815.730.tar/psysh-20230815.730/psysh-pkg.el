;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "psysh" "20230815.730"
  "PsySH, PHP interactive shell (REPL)."
  '((emacs       "24.3")
    (s           "1.9.0")
    (php-runtime "0.2"))
  :url "https://github.com/emacs-php/psysh.el"
  :commit "8bf82fa68ca90fc72528ea406f0e57718bcb1cbf"
  :revdesc "8bf82fa68ca9"
  :keywords '("processes" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
