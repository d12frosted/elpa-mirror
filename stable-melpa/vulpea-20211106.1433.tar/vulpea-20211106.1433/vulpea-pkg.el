(define-package "vulpea" "20211106.1433" "A collection of org-roam note-taking functions"
  '((emacs "27.1")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12"))
  :commit "5d32a0abc279613a25d5b2e7a0e4c9b5bac3e5d6" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
