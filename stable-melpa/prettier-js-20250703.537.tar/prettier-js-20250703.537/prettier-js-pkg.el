;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250703.537"
  "Minor mode to format JS code on file save."
  '((emacs "28.1"))
  :url "https://github.com/prettier/prettier-emacs"
  :commit "02921c9d2ebd74ba35d357148d7445b4ec814e7e"
  :revdesc "02921c9d2ebd"
  :keywords '("convenience" "wp" "edit" "js"))
