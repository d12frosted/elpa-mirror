;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digistar-mode" "20241226.1915"
  "Major mode for Digistar scripts."
  '((emacs "29.1"))
  :url "https://github.com/retroj/digistar-mode"
  :commit "d3a0ca35a48d1e6babf8c19c2b33ef883be57722"
  :revdesc "d3a0ca35a48d"
  :keywords '("languages")
  :authors '(("John Foerch" . "jjfoerch@gmail.com"))
  :maintainers '(("John Foerch" . "jjfoerch@gmail.com")))
