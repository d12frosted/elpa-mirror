(define-package "meow" "20220418.357" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "2343d0a9a70757cbf1e6810d66c3e21b2f883463" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
