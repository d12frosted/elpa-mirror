;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20261028.112"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.5"))
  :url "https://github.com/joaotavora/sly"
  :commit "70350623eecd1f41837c9e57cbb6d5c06678a60d"
  :revdesc "70350623eecd"
  :keywords '("languages" "lisp" "sly"))
