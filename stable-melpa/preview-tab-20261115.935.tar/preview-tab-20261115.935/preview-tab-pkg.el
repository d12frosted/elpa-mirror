;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "preview-tab" "20261115.935"
  "Temporary file buffers, like VS Code's preview tab."
  '((emacs "27.1"))
  :url "https://github.com/ismd/preview-tab.el"
  :commit "ad2bb17cdf3bd4c60b6e627a6cc205255daefb8f"
  :revdesc "ad2bb17cdf3b"
  :keywords '("convenience" "files")
  :authors '(("Vladimir Kostelei" . "github@ismd.dev"))
  :maintainers '(("Vladimir Kostelei" . "github@ismd.dev")))
