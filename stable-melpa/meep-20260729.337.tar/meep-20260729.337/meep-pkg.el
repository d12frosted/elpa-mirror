;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260729.337"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "8306e240c213d1b3693be15c744a629af4ad89df"
  :revdesc "8306e240c213"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
