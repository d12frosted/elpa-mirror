(define-package "cfn-mode" "20231112.904" "AWS cloudformation mode"
  '((emacs "26.0")
    (f "0.20.0")
    (s "1.12.0")
    (yaml-mode "0.0.13"))
  :commit "2640b72b7eed0b5f702377d3e0d723c23dda792f" :authors
  '(("William Orr" . "will@worrbase.com"))
  :maintainers
  '(("William Orr" . "will@worrbase.com"))
  :maintainer
  '("William Orr" . "will@worrbase.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://gitlab.com/worr/cfn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
