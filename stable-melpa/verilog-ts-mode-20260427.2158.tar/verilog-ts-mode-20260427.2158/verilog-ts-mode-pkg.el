;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ts-mode" "20260427.2158"
  "Verilog Tree-sitter major mode."
  '((emacs        "29.1")
    (verilog-mode "2024.3.1.121933719"))
  :url "https://github.com/gmlarumbe/verilog-ts-mode"
  :commit "32d00f783711eb2f03615aa8d5739d5c9a50a7f9"
  :revdesc "32d00f783711"
  :keywords '("systemverilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
