(define-package "rbtagger" "20211018.1442" "Ruby tagging tools"
  '((emacs "25.1"))
  :commit "e99c3e5db7f9b5c23899373155b333e123767a28" :authors
  '(("Thiago Araújo" . "thiagoaraujos@gmail.com"))
  :maintainer
  '("Thiago Araújo" . "thiagoaraujos@gmail.com")
  :keywords
  '("languages" "tools")
  :url "https://www.github.com/thiagoa/rbtagger")
;; Local Variables:
;; no-byte-compile: t
;; End:
