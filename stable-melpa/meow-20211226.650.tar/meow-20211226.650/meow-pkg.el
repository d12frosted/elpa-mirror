(define-package "meow" "20211226.650" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "1fc78f5a72faff933b48851d5ef469a0344b021c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
