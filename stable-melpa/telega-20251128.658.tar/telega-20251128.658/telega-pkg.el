;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251128.658"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "55f01587e534feede0875aa0d94ffc5a4c6671af"
  :revdesc "55f01587e534"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
