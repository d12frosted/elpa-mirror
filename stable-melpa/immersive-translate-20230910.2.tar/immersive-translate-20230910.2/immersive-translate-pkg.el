(define-package "immersive-translate" "20230910.2" "Translate the current buffer immersively"
  '((emacs "28.2"))
  :commit "fcd81a0c9e588a3aab7d3ee02aa2959c3aa2d3bf" :authors
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainers
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainer
  '("Eli Qian" . "eli.q.qian@gmail.com")
  :keywords
  '("convenience" "help" "translate")
  :url "https://github.com/Elilif/emacs-immersive-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
