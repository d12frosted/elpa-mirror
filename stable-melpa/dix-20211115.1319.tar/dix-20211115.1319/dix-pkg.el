(define-package "dix" "20211115.1319" "Apertium XML editing minor mode"
  '((cl-lib "0.5")
    (emacs "26.2"))
  :commit "5b4e208666307e5f2260d4828c74e6fb8baa40d2" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("languages")
  :url "http://wiki.apertium.org/wiki/Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
