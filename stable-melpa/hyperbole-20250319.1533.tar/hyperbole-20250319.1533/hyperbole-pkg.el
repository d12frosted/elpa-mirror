;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250319.1533"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "0d42a12b1a2a8834939fd94782d491a028efa4ae"
  :revdesc "0d42a12b1a2a"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
