;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20251103.231"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "9221c3bdf4e6ff94940f5d7f368c294370b90e27"
  :revdesc "9221c3bdf4e6"
  :keywords '("hypermedia"))
