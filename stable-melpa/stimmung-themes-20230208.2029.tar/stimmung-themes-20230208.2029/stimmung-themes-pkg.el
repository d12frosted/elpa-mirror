(define-package "stimmung-themes" "20230208.2029" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "8bdfa423929e45e4c6ad9b5158f6714e1731bfea" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
