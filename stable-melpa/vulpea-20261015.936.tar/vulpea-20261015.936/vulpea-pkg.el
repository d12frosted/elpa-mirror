;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261015.936"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "8d35ca4874c8de9c47ed4e94c172ca3d7af5aa9f"
  :revdesc "8d35ca4874c8"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
