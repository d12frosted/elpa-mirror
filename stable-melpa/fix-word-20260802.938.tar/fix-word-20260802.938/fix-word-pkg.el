;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fix-word" "20260802.938"
  "Convenient word transformation."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/mrkkrp/fix-word"
  :commit "e29889f9819488360b48237dfbf06ce2a75c01f5"
  :revdesc "e29889f98194"
  :keywords '("word" "convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
