(define-package "srfi" "20231130.2037" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "aa0164b45fa15bd1cc377793d27af4ddd8d99855" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
