;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260106.2319"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "b5e29b4d1a098160f6562b1d5b67dcd1008881b7"
  :revdesc "b5e29b4d1a09"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
