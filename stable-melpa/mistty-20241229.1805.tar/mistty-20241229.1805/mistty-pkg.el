;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241229.1805"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "0c1fe1e4e976dcdad92dde8001f51b1b35b14a85"
  :revdesc "0c1fe1e4e976"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
