(define-package "dwim-shell-command" "20231109.856" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "642a907fdec8b765e777d0c9656388694a15dae9" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
