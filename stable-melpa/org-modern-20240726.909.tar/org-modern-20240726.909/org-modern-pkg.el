(define-package "org-modern" "20240726.909" "Modern looks for Org"
  '((emacs "27.1")
    (compat "30"))
  :commit "b9fce9786f8433d20212c72ec57757593a5ac81c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "text")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
