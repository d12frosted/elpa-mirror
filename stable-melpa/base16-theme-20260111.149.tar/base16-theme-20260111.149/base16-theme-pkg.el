;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260111.149"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "ff26a3d2e629e2b0c26f26b5ec4db50cc7d3d6b3"
  :revdesc "ff26a3d2e629"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
