(define-package "julia-snail" "20230822.2225" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (popup "0.5.9"))
  :commit "42765152415657c04a413c241d13ed736226da29" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
