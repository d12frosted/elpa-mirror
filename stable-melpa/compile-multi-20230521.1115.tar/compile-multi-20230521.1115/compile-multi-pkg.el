(define-package "compile-multi" "20230521.1115" "A multi target interface to compile"
  '((emacs "28.0"))
  :commit "fafadb6722299797a1de3de93cf7439d17b4d13b" :authors
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("mohsin kaleem" . "mohkale@kisara.moe")
  :keywords
  '("tools" "compile" "build")
  :url "https://github.com/mohkale/compile-multi")
;; Local Variables:
;; no-byte-compile: t
;; End:
