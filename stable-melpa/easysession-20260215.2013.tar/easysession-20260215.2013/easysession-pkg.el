;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260215.2013"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "94183a7f86524e006d7bb25a72c45f2914cbe744"
  :revdesc "94183a7f8652"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
