(define-package "boon" "20220816.2151" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "225c8b9d979182e7ee27ff2eb33657180971a82c")
;; Local Variables:
;; no-byte-compile: t
;; End:
