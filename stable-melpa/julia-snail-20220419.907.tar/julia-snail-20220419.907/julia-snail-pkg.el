(define-package "julia-snail" "20220419.907" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (vterm "0.0.1"))
  :commit "f64e0d7cbf195ceed7dfd2eecd9565dd7e1fa202" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
