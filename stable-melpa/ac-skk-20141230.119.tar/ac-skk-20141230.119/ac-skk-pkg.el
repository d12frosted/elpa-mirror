;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-skk" "20141230.119"
  "Auto-complete-mode source for DDSKK a.k.a Japanese input method."
  '((auto-complete "1.3.1")
    (ddskk         "16.0.50")
    (tinysegmenter "0")
    (cl-lib        "0.5"))
  :url "https://github.com/myuhe/ac-skk.el"
  :commit "d25a265930430d080329789fb253d786c01dfa24"
  :revdesc "d25a26593043"
  :keywords '("convenience" "auto-complete")
  :authors '(("lugecy" . "https://twitter.com/lugecy")))
