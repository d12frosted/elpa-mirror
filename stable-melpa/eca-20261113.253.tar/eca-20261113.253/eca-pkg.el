;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20261113.253"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "ceaf42ac893664f2a7cd10f5d4f4d7dabf4d8bfd"
  :revdesc "ceaf42ac8936"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
