(define-package "thrift" "20231021.1233" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "72cc23eeb9d696a22c6054d4de0a75a9c18fe46b" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
