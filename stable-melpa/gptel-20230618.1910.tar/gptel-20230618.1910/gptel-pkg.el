(define-package "gptel" "20230618.1910" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "e6df1a5e335620c2c6729ad36c4938cd27364176" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
