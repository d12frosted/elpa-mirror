;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term+" "20170509.17"
  "Term-mode enhancement."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/tarao/term-plus-el"
  :commit "c3c9239b339c127231860de43abfa08c44c0201a"
  :revdesc "c3c9239b339c"
  :keywords '("terminal" "emulation")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
