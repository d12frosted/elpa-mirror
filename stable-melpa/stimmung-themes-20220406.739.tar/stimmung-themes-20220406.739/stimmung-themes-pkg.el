(define-package "stimmung-themes" "20220406.739" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "e092cd79d777ac7ed0c4347e8edc5a0515276fc2" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
