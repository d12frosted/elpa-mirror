;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "benchmark-init" "20260107.906"
  "Benchmarks for require and load calls."
  '((emacs "24.3"))
  :url "https://github.com/dholm/benchmark-init-el"
  :commit "7252b133cde2d904f7a08f403568aedc410d9a44"
  :revdesc "7252b133cde2"
  :keywords '("convenience" "benchmark")
  :maintainers '(("David Holm" . "dholmster@gmail.com")))
