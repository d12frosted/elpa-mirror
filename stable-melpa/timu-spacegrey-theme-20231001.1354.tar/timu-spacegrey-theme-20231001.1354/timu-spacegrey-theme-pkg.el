(define-package "timu-spacegrey-theme" "20231001.1354" "Color theme inspired by the Spacegray theme in Sublime Text"
  '((emacs "26.1"))
  :commit "51856eb3e1829f1fad3bcf4f6cc657daa3e80091" :authors
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainer
  '("Aimé Bertrand" . "aime.bertrand@macowners.club")
  :keywords
  '("faces" "themes")
  :url "https://gitlab.com/aimebertrand/timu-spacegrey-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
