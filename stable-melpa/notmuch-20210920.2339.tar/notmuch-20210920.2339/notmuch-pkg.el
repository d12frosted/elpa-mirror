(define-package "notmuch" "20210920.2339" "run notmuch within emacs" 'nil :commit "174ec2a28fc38df65434b7d805e0e657d17f335d" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
