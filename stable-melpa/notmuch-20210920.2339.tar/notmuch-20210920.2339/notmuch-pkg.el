(define-package "notmuch" "20210920.2339" "run notmuch within emacs" 'nil :commit "0f196b5659c8a66af4357fee3d4b3a169044472d" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
