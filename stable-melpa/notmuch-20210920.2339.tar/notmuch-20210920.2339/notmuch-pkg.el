(define-package "notmuch" "20210920.2339" "run notmuch within emacs" 'nil :commit "6e050de4c01107ad0d914170aacf261701d2b71c" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
