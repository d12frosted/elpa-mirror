;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260722.1804"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f076ff8c5997e9e9401d02da5034c1c10ba070f4"
  :revdesc "f076ff8c5997"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
