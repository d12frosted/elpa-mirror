(define-package "consult" "20211002.1826" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7582e99c17b1c3283d515068d29cb600b9c79f9b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
