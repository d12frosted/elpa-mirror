(define-package "sketch-themes" "20210220.1149" "Sketch color themes"
  '((emacs "26.1"))
  :commit "df8182628052bf55e7779fb6967383629059b5c0" :authors
  '(("Daw-Ran Liou" . "hi@dawranliou.com"))
  :maintainer
  '("Daw-Ran Liou" . "hi@dawranliou.com")
  :keywords
  '("faces")
  :url "https://github.com/dawranliou/emacs.d/themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
