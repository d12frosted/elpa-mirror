;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260310.206"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "9b652d4c1ce3ede1b924710d4fb6cd4da259e205"
  :revdesc "9b652d4c1ce3"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
