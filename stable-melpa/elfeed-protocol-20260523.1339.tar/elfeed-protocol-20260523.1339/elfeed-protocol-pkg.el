;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol" "20260523.1339"
  "Provide fever/newsblur/owncloud/ttrss protocols for elfeed."
  '((emacs  "24.4")
    (elfeed "4.0.0")
    (cl-lib "0.5"))
  :url "https://github.com/fasheng/elfeed-protocol"
  :commit "58936590459ccc2dfd6132f69983011d15d9404a"
  :revdesc "58936590459c"
  :keywords '("news")
  :authors '(("Xu Fasheng" . "fasheng[AT]fasheng.info"))
  :maintainers '(("Xu Fasheng" . "fasheng[AT]fasheng.info")))
