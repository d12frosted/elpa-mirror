(define-package "fennel-mode" "20220329.116" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "50ef3c6246f36085cd908cf5432133cadb792304" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
