;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261126.223"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "ed8d1f05fac150b9048a4731d181d2b83644d274"
  :revdesc "ed8d1f05fac1"
  :keywords '("build tools" "languages"))
