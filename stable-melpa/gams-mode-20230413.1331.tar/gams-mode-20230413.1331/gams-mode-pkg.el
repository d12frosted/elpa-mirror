(define-package "gams-mode" "20230413.1331" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "246c0bea5764e5d9d5607a1f76b4602109e66ba9" :authors
  '(("Shiro Takeda"))
  :maintainers
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
