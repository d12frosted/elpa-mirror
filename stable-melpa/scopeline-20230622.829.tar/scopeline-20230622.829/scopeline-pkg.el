(define-package "scopeline" "20230622.829" "Show scope info of blocks in buffer at end of scope"
  '((emacs "26.1"))
  :commit "254d300aee0a22349b07fbe542fbec81547bae75" :keywords
  '("scope" "context" "tree-sitter" "convenience")
  :url "https://github.com/meain/scopeline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
