;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "refine" "20240914.634"
  "Interactive value editing."
  '((emacs      "24.3")
    (s          "1.11.0")
    (dash       "2.12.0")
    (list-utils "0.4.4")
    (loop       "1.2"))
  :url "https://github.com/Wilfred/refine"
  :commit "07c1f3518fff4e363c68c0a110137756754641df"
  :revdesc "07c1f3518fff"
  :keywords '("convenience")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
