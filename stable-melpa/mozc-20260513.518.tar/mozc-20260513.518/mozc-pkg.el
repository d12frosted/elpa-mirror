;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc" "20260513.518"
  "Minor mode to input Japanese with Mozc."
  '((emacs "24.3"))
  :url "https://github.com/google/mozc"
  :commit "0c8acf48331724da42f82ebf038cbe6dce25da42"
  :revdesc "0c8acf483317"
  :keywords '("mule" "multilingual" "input method"))
