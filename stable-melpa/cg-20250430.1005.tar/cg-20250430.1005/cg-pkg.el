;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cg" "20250430.1005"
  "Major mode for editing Constraint Grammar files."
  '((emacs "26.1"))
  :url "https://edu.visl.dk/constraint_grammar.html"
  :commit "8ab7e26352c615326d74feeec71f531fc7a8855d"
  :revdesc "8ab7e26352c6"
  :keywords '("languages")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
