;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260131.2143"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "8929fba28fc93e44a2a7ae105dfb4019881a302e"
  :revdesc "8929fba28fc9"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
