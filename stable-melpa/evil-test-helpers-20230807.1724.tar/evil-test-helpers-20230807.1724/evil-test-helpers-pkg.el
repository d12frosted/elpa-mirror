(define-package "evil-test-helpers" "20230807.1724" "unit test helpers for Evil"
  '((evil "1.15.0"))
  :commit "27d81ad406d2d3e07591b927357d2354ef5b5c65" :authors
  '(("Vegard Øye <vegard_oye at hotmail.com>"))
  :maintainers
  '(("Vegard Øye <vegard_oye at hotmail.com>"))
  :maintainer
  '("Vegard Øye <vegard_oye at hotmail.com>"))
;; Local Variables:
;; no-byte-compile: t
;; End:
