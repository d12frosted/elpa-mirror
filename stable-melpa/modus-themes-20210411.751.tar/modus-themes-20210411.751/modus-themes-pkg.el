(define-package "modus-themes" "20210411.751" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "3c9b98f61e9b781f756ac7a329005156406cae5a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
