;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambdapi-mode" "20260623.731"
  "A major mode for editing Lambdapi source code."
  '((emacs             "27.1")
    (eglot             "1.6")
    (math-symbol-lists "1.2.1")
    (highlight         "20190710.1527"))
  :url "https://github.com/Deducteam/lambdapi"
  :commit "f3286759f3b8a1ec3aaa55706a67dd36eb020de5"
  :revdesc "f3286759f3b8"
  :keywords '("languages")
  :maintainers '(("Deducteam" . "dedukti-dev@inria.fr")))
