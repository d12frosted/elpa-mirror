(define-package "citar" "20221005.1315" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "4.2")
    (org "9.5")
    (citeproc "0.9"))
  :commit "cf3679005efaf2df9560ede7002563d5ee4edf7e" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/emacs-citar/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
