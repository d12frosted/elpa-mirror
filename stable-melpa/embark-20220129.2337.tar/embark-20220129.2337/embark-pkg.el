(define-package "embark" "20220129.2337" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c794ca3fc630eee6401121f89fc53bb794c7aab3" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
