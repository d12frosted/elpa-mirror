;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20250519.1757"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "201ce44b16eec04d7f26eb15da33b4765703542a"
  :revdesc "201ce44b16ee"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
