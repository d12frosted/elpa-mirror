(define-package "buttercup" "20210105.2255" "Behavior-Driven Emacs Lisp Testing" 'nil :commit "108d2298cc34d906b196178ad955e3dc139e1779" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Jorgen Schaefer" . "contact@jorgenschaefer.de")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
