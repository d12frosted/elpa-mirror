;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocamlformat" "20251021.1319"
  "Utility functions to format ocaml code."
  '((emacs "24.3"))
  :url "https://github.com/ocaml-ppx/ocamlformat"
  :commit "ca452510f87fd2a6805a46f0228ac2eb43eaf517"
  :revdesc "ca452510f87f"
  :keywords '("languages" "ocaml"))
