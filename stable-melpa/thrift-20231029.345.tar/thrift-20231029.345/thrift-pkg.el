(define-package "thrift" "20231029.345" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "f22ad0a87b9e66b54bf825c01bd091808079e9ca" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
