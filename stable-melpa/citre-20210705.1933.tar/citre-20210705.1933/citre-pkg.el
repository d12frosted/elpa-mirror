(define-package "citre" "20210705.1933" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "65a9e6ec83aeda6d82230a5a38da81b61c375699" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
