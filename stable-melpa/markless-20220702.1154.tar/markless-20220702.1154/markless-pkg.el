(define-package "markless" "20220702.1154" "Major mode for Markless documents"
  '((emacs "24.4"))
  :commit "9c846f58575a446812f7bade284021b625976757" :authors
  '(("Nicolas Hafner" . "shinmera@tymoon.eu"))
  :maintainers
  '(("Nicolas Hafner" . "shinmera@tymoon.eu"))
  :maintainer
  '("Nicolas Hafner" . "shinmera@tymoon.eu")
  :keywords
  '("languages" "wp")
  :url "http://github.com/shirakumo/markless.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
