;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tinysegmenter" "20141124.1013"
  "Super compact Japanese tokenizer in Javascript ported to emacs lisp."
  '((cl-lib "0.5"))
  :url "https://github.com/myuhe/tinysegmenter.el"
  :commit "872134704bd25c13a4c59552433da4c6881b5230"
  :revdesc "872134704bd2"
  :keywords '("convenience")
  :authors '(("lugecy" . "lugecy@gmail.com")))
