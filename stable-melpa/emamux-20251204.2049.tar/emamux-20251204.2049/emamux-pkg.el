;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emamux" "20251204.2049"
  "Interact with tmux."
  '((emacs "26.1"))
  :url "https://github.com/emacsorphanage/emamux"
  :commit "0c42b04c1ee50d81872a736b768f44f544141b45"
  :revdesc "0c42b04c1ee5"
  :keywords '("unix")
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
