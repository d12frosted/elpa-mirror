;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260414.1528"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "b1196fd6de4368a6d366db6bd2518eba9ca21afd"
  :revdesc "b1196fd6de43"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
