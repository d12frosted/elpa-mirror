(define-package "boon" "20230625.2015" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "153862e90f0214a0033cb8f703e588ff5b409e25")
;; Local Variables:
;; no-byte-compile: t
;; End:
