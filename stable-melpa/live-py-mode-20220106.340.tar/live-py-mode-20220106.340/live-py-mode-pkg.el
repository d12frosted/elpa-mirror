(define-package "live-py-mode" "20220106.340" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "02e23fdb2cca5a00fed291b41be2c2b1110cf19d" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
