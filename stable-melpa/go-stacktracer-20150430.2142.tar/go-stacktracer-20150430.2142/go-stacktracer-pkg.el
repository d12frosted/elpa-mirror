;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-stacktracer" "20150430.2142"
  "Parse Go stack traces."
  ()
  :url "https://github.com/samertm/go-stacktracer.el"
  :commit "a2ac6d801b389f80ca4e2fcc1ab44513a9e55976"
  :revdesc "a2ac6d801b38"
  :keywords '("tools")
  :authors '(("Samer Masterson" . "samer@samertm.com"))
  :maintainers '(("Samer Masterson" . "samer@samertm.com")))
