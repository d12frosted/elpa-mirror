(define-package "modus-themes" "20211019.719" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "79448b784354206b935b9007e842e29b7b4074e2" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
