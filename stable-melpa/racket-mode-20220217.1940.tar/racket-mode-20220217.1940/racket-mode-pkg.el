(define-package "racket-mode" "20220217.1940" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "a946f57c3af6238f94e4e750cffbc2324d7f4a38" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
