;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260113.207"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "451a05aa7c46daa9226cf18444718f97bf1c6d92"
  :revdesc "451a05aa7c46"
  :keywords '("comm"))
