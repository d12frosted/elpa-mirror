(define-package "elisp-autofmt" "20230118.1204" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "dafc55e4bd3ba5e9a26f455c0ee79617a23f9beb" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
