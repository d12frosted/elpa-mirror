(define-package "detached" "20220922.1355" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "07d196af4480d58b067552fd1ead6b6f0607dc9c" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
