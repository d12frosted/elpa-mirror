(define-package "gams-mode" "20231005.1425" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "0e7382bf9613329d2e411ced73536205326a910b" :authors
  '(("Shiro Takeda"))
  :maintainers
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
