;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "audacious" "20260917.1247"
  "Emacs interface to control audacious."
  '((helm  "3.6.2")
    (emacs "24.4"))
  :url "https://github.com/shishimaru/audacious.el"
  :commit "634db44efbcd9899cd6f45fc9cb57f9d5c2b8074"
  :revdesc "634db44efbcd"
  :authors '(("Hitoshi Uchida" . "hitoshi.uchida@gmail.com"))
  :maintainers '(("Hitoshi Uchida" . "hitoshi.uchida@gmail.com")))
