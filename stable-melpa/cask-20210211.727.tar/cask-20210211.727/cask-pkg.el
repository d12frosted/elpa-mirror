(define-package "cask" "20210211.727" "Cask: Project management for package development"
  '((emacs "24.1")
    (s "1.8.0")
    (dash "2.2.0")
    (f "0.16.0")
    (epl "0.5")
    (shut-up "0.1.0")
    (cl-lib "0.3")
    (package-build "1.2")
    (ansi "0.4.1"))
  :commit "5ac82efeea812a83c636d5273ddf5b99bb72f8a2" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("speed" "convenience")
  :url "http://github.com/cask/cask")
;; Local Variables:
;; no-byte-compile: t
;; End:
