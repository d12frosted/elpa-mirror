(define-package "evil-textobj-syntax" "20231016.1544" "Provides syntax text objects."
  '((names "0.5")
    (emacs "24")
    (evil "0"))
  :commit "c1a7afe81bca3da6a2fdc7ea9376fdc2e1e9249c" :keywords
  '("evil" "syntax" "highlight" "text-object")
  :url "https://github.com/laishulu/evil-textobj-syntax")
;; Local Variables:
;; no-byte-compile: t
;; End:
