;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timecop" "20240105.2100"
  "Freeze Time for testing."
  '((emacs           "26.3")
    (datetime-format "0.0.1"))
  :url "https://github.com/emacs-php/emacs-datetime"
  :commit "090bfff5c28fa0a6cb629512003c49b3f43ed72d"
  :revdesc "090bfff5c28f"
  :keywords '("lisp" "datetime" "testing")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
