(define-package "mustache" "20210215.331" "a mustache templating library in emacs lisp"
  '((ht "0.9")
    (s "1.3.0")
    (dash "1.2.0"))
  :commit "406f2987ec3fcdcb981224c7bb1774306181ea58" :authors
  '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainer
  '("Wilfred Hughes" . "me@wilfred.me.uk")
  :keywords
  '("convenience" "mustache" "template")
  :url "https://github.com/Wilfred/mustache.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
