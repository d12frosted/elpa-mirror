;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "equake" "20251208.1734"
  "Drop-down console for (e)shell & terminal emulation."
  '((emacs "26.1")
    (dash  "2.14.1"))
  :url "https://github.com/emacsomancer/equake"
  :commit "8a5256e91ed613c06c67c48cd493c57cab0b87eb"
  :revdesc "8a5256e91ed6"
  :keywords '("convenience" "frames" "terminals" "tools" "window-system")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
