(define-package "magik-mode" "20220329.1721" "mode for editing Magik + some utils." 'nil :commit "61b2935152b3c2f9511bcd399c55c4aa252fa233" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
