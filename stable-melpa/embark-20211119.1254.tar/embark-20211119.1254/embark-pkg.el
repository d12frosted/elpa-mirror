(define-package "embark" "20211119.1254" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "fb09ff86b943f1d8107b646fdcb3a3a48437a24a" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
