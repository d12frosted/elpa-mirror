;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20261109.120"
  "LSP mode."
  '((emacs         "29.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "28568fd1c66237402d9dafae62a5742afb1f5ef9"
  :revdesc "28568fd1c662"
  :keywords '("languages"))
