;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241125.737"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.70.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "43cd17d464b92a4a5b2ee807492f20829ebbf318"
  :revdesc "43cd17d464b9")
