(define-package "consult" "20230507.943" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "8f1bea3e3634abc92d98084afb5cc98d2a8dc9ee" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
