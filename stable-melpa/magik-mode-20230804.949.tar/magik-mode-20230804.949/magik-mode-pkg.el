(define-package "magik-mode" "20230804.949" "mode for editing Magik + some utils."
  '((emacs "24.4")
    (compat "28.1"))
  :commit "aa75213fad924a2ca72c6e2ac526f4d40a53682c" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
