(define-package "binky" "20231206.429" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "8711a7ba7b9045ee2788c023a2076559cd95feb6" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
