(define-package "dirvish" "20220507.153" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a37c79375cc67e6896ba54d445bd9cde5bf70322" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
