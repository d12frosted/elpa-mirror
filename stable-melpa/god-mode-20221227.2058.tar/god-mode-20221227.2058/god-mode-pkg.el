(define-package "god-mode" "20221227.2058" "Minor mode for God-like command entering"
  '((emacs "25.1"))
  :commit "23bb1e2224e21c3c4cf1fba9795be95572902d8c" :authors
  '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainer
  '("Chris Done" . "chrisdone@gmail.com")
  :url "https://github.com/emacsorphanage/god-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
