(define-package "consult" "20220428.559" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "8d0e5a547dec6cde5111f1a314ba7ccccc22af21" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
