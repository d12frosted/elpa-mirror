(define-package "dyncloze" "20210613.1956" "Language alternatives self-testing"
  '((emacs "25.1")
    (dash "2.18"))
  :commit "fe5baf6d324800779f80f5c6298a56e2dcb87598" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :url "https://github.com/ahyatt/dyncloze")
;; Local Variables:
;; no-byte-compile: t
;; End:
