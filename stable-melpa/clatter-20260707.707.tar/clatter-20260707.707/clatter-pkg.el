;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260707.707"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "5b528cb06c57645e001ecb9f037b02cbf26e132c"
  :revdesc "5b528cb06c57"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
