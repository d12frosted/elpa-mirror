;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eve-mode" "20170822.2231"
  "Major mode for editing Eve documents."
  '((emacs         "25")
    (polymode      "1.0")
    (markdown-mode "2.0"))
  :url "https://github.com/witheve/emacs-eve-mode"
  :commit "a4661114d9c18725691b76321d72167ca5a9070a"
  :revdesc "a4661114d9c1"
  :keywords '("languages" "wp" "tools")
  :authors '(("Joshua Cole" . "joshuafcole@gmail.com"))
  :maintainers '(("Joshua Cole" . "joshuafcole@gmail.com")))
