;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20250408.553"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "60a8cf0a5df5c26d09a695297bf4b967b2a7a48b"
  :revdesc "60a8cf0a5df5"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
