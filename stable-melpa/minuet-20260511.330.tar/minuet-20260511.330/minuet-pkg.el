;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260511.330"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "b093a0ba0e479f9e736b8ff3d80404c0acaed9aa"
  :revdesc "b093a0ba0e47"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
