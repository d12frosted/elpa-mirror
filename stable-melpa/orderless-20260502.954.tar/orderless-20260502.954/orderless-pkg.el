;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orderless" "20260502.954"
  "Completion style for matching regexps in any order."
  '((emacs  "27.1")
    (compat "31"))
  :url "https://github.com/oantolin/orderless"
  :commit "34785f1eb40a241a7949ebe258d563bfa061bc50"
  :revdesc "34785f1eb40a"
  :keywords '("matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
