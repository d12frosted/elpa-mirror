(define-package "stgit" "20231005.330" "major mode for StGit interaction" 'nil :commit "cb4a3ad8c9c3f5c55ad9a69c964680711935c5bc" :authors
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainers
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainer
  '("David Kågedal" . "davidk@lysator.liu.se")
  :url "http://stacked-git.github.io")
;; Local Variables:
;; no-byte-compile: t
;; End:
