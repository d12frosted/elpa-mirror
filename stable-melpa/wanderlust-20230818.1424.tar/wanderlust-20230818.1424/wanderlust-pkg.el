(define-package "wanderlust" "20230818.1424" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "1389dcec6e3242948682eb3e3ce8ead8be2772d8")
;; Local Variables:
;; no-byte-compile: t
;; End:
