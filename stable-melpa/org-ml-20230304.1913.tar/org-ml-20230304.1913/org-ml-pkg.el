(define-package "org-ml" "20230304.1913" "Functional Org Mode API"
  '((emacs "27.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "8c8e08bfbcbcd504684fe8b68cd0e87ed92c652f" :authors
  '(("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  '("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :keywords
  '("org-mode" "outlines")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
