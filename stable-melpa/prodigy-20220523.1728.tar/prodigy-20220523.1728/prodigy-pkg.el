(define-package "prodigy" "20220523.1728" "Manage external services"
  '((s "1.8.0")
    (dash "2.4.0")
    (f "0.14.0")
    (emacs "27.1"))
  :commit "a3be00d3b90a77118c2d7d9f5a2f26151091fa07" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :url "http://github.com/rejeep/prodigy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
