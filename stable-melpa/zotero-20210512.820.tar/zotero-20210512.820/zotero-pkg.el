(define-package "zotero" "20210512.820" "Library for the Zotero API"
  '((emacs "27.1")
    (ht "2.2")
    (oauth "1.0.4")
    (s "1.12.0"))
  :commit "15eb7a8d099c93440f0a8920499633103f00fc83" :authors
  '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainer
  '("Folkert van der Beek" . "folkertvanderbeek@gmail.com")
  :keywords
  '("zotero" "hypermedia")
  :url "https://gitlab.com/fvdbeek/emacs-zotero")
;; Local Variables:
;; no-byte-compile: t
;; End:
