;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260113.959"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "3aa72a4abe1ad42dd130749dedc367d4142d48c3"
  :revdesc "3aa72a4abe1a"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
