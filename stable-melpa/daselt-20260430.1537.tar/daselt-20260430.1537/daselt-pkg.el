;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260430.1537"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "a54e20b29fb97cda6f012e6101305bef743ab923"
  :revdesc "a54e20b29fb9"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
