(define-package "consult" "20230127.1312" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "46e92c929abda74555ec89bda6edbb765785c397" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
