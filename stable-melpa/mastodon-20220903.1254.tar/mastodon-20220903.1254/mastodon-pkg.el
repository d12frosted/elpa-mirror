(define-package "mastodon" "20220903.1254" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0"))
  :commit "3df4813ab72d5f2d1e43258426ec6ed44dadddf6" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
