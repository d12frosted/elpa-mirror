;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20260114.607"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "b7448b8bcdff20a2818a64d804cb3d14c1737b46"
  :revdesc "b7448b8bcdff"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
