(define-package "modus-themes" "20220401.658" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "6e1b4f665111acc15711a9bfb3f4bc7a61d3f354" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
