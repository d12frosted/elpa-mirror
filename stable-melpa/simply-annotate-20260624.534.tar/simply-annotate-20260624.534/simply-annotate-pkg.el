;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260624.534"
  "Enhanced annotation system with threading."
  '((emacs     "27.2")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "ab87e4fb0c9cf7f86af7bf63103dd81988da907b"
  :revdesc "ab87e4fb0c9c"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
