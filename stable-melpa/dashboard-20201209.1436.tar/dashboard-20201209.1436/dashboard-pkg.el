(define-package "dashboard" "20201209.1436" "A startup screen extracted from Spacemacs"
  '((emacs "25.3")
    (page-break-lines "0.11"))
  :commit "75f0c46db03b40ec983dbf4aa81e2ccb2e4a16ef" :keywords
  ("startup" "screen" "tools" "dashboard")
  :authors
  (("Rakan Al-Hneiti"))
  :maintainer
  ("Rakan Al-Hneiti")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
