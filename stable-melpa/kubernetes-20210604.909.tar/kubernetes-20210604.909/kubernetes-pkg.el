(define-package "kubernetes" "20210604.909" "Magit-like porcelain for Kubernetes."
  '((emacs "25.1")
    (dash "2.12.0")
    (magit "2.8.0")
    (magit-popup "2.13.0"))
  :commit "93d7b4d1b079b3cf1fbe3949154b6a1bc06904ef" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool"))
;; Local Variables:
;; no-byte-compile: t
;; End:
