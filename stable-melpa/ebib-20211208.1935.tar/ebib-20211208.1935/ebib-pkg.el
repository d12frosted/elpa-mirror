(define-package "ebib" "20211208.1935" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "f9d2b1526c3ce25b16b0b0dc7d3c23f67d801817" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
