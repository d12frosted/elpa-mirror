(define-package "modus-themes" "20230108.252" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "b3302411a121a3b1af4736001deeee0d29122dcd" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
