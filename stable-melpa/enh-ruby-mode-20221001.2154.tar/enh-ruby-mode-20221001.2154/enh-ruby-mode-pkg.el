(define-package "enh-ruby-mode" "20221001.2154" "Major mode for editing Ruby files"
  '((emacs "25.1"))
  :commit "ebc2d4be628b4ea27b20b80729b29f584d2fa6ed" :authors
  '(("Geoff Jacobsen"))
  :maintainer
  '("Ryan Davis")
  :keywords
  '("languages" "elisp" "ruby")
  :url "https://github.com/zenspider/Enhanced-Ruby-Mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
