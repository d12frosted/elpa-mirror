(define-package "dirvish" "20220423.1140" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "523ad7e1be4188521cf543176c61750665159695" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
