(define-package "monky" "20201226.1950" "Control Hg from Emacs." 'nil :commit "30a75a78ad075cbb9268b7fbdc65a36d1afc1ff5" :authors
  '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainer
  '("Anantha kumaran" . "ananthakumaran@gmail.com")
  :keywords
  '("tools")
  :url "http://github.com/ananthakumaran/monky")
;; Local Variables:
;; no-byte-compile: t
;; End:
