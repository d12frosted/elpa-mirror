(define-package "eide" "20200507.2235" "IDE interface" 'nil :commit "93b7f4e6013f378f387586011b6389f7ae366bbc" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://eide.hjuvi.fr.eu.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
