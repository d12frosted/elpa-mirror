;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linkin-org" "20260607.1601"
  "A workflow with fast, reliable links."
  '((emacs "30.1"))
  :url "https://github.com/Judafa/linkin-org"
  :commit "a6ee3cbdff0d9c74b702131220937c1d93dd81ef"
  :revdesc "a6ee3cbdff0d"
  :authors '(("Julien Dallot" . "judafa@protonmail.com"))
  :maintainers '(("Julien Dallot" . "judafa@protonmail.com")))
