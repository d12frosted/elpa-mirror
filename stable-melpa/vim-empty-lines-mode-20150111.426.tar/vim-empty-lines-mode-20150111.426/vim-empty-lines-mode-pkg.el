;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-empty-lines-mode" "20150111.426"
  "Vim-like empty line indicator at end of files."
  '((emacs "23"))
  :url "https://github.com/jmickelin/vim-empty-lines-mode"
  :commit "442a29b0ba1635a3b352c9dd1faf9ce99656d048"
  :revdesc "442a29b0ba16"
  :keywords '("emulations")
  :authors '(("Jonne Mickelin" . "jonne@ljhms.com"))
  :maintainers '(("Jonne Mickelin" . "jonne@ljhms.com")))
