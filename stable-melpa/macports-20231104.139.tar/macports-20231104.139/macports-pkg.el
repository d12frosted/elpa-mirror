(define-package "macports" "20231104.139" "A porcelain for MacPorts"
  '((emacs "26.1")
    (transient "0.1.0"))
  :commit "e70bdc860a047cdd22f0b6f3edea06adc94d0d7f" :authors
  '(("Aaron Madlon-Kay"))
  :maintainers
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("convenience")
  :url "https://github.com/amake/macports.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
