(define-package "x509-mode" "20221112.1520" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "1b7fc08ef3e513ef528b47acb0da412c3f097217" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
