;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20261126.607"
  "Insert SPDX license and copyright headers."
  '((emacs "29.1"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "53396ac5c357576e11461e62468edd10b02dc08c"
  :revdesc "53396ac5c357"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
