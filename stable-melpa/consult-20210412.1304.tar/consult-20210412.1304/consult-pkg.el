(define-package "consult" "20210412.1304" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "018c9367105facb86cf3cc7333bde14322320904" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
