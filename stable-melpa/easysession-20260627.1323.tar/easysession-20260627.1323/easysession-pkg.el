;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260627.1323"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "bba36c41d5b21a80927583dc6eb83d080d0caad1"
  :revdesc "bba36c41d5b2"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
