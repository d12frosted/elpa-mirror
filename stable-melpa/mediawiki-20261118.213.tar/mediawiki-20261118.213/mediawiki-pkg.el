;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20261118.213"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "ce4513048b4cf5415cf3e28e7a5c02e5266e0ce1"
  :revdesc "ce4513048b4c"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
