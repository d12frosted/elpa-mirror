;;; mediawiki-site.el --- Site configuration and management for mediawiki.el -*- lexical-binding: t; -*-

;; Copyright (C) 2025-2026 Mark A. Hershberger

;; Author: Mark A. Hershberger <mah@everybody.org>
;; URL: https://github.com/hexmode/mediawiki-el

;; This file is part of mediawiki.el.

;; mediawiki.el is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; mediawiki.el is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with mediawiki.el.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; This module provides site configuration and management functionality
;; for mediawiki.el.  It handles site definitions, URL construction,
;; credential management, and site selection.

;;; Code:

(require 'mediawiki-core)
(require 'mediawiki-http)
(require 'auth-source)
(require 'url-parse)

;;; Site Configuration

(defcustom mediawiki-pop-buffer-hook '()
  "List of functions to execute after popping to a buffer.
Can be used to to open the whole buffer."
  :options '(delete-other-windows)
  :type 'hook
  :group 'mediawiki)

(defcustom mediawiki-site-alist '(("Wikipedia"
                                    "https://en.wikipedia.org/w/"
                                    "username"
                                    "password"
                                    ""
                                    :description "English Wikipedia"
                                    :first-page "Main Page")
                                   ("Wiktionary"
                                     "https://en.wiktionary.org/w/"
                                     "username"
                                     "password"
                                     ""
                                     :description "English Wiktionary"
                                     :first-page "Main Page")
                                   ("Wikimedia Commons"
                                     "https://commons.wikimedia.org/w/"
                                     "username"
                                     "password"
                                     ""
                                     :description "Wikimedia Commons"
                                     :first-page "Main Page"))
  "List of MediaWiki sites and their configurations.
Each entry is a list of the form:
  (SITENAME URL USERNAME PASSWORD DOMAIN &rest PROPERTIES)

Where:
  SITENAME is a string identifying the site
  URL is the base URL for the MediaWiki installation
  USERNAME is the default username (can be empty string)
  PASSWORD is the default password (can be empty string)
  DOMAIN is the LDAP domain (can be empty string)
  PROPERTIES is a plist of additional properties like:
    :description - Human readable description
    :first-page - Default page to open when selecting this site
    :oauth-client-id - OAuth 2.0 consumer client ID
    :oauth-client-secret - OAuth 2.0 consumer client secret
    :oauth-access-token - Pre-obtained OAuth 2.0 access token
    :oauth-refresh-token - OAuth 2.0 refresh token for token renewal
    :oauth-token-url - Custom OAuth 2.0 token endpoint URL"
  :group 'mediawiki
  :type '(repeat (list (string :tag "Site name")
                   (string :tag "URL")
                   (string :tag "Username")
                   (string :tag "Password")
                   (string :tag "Domain")
                    (plist :tag "Properties"
                      :options ((:description string
                                  :description "Description of this site")
                                 (:first-page string
                                   :description "First page to open when `mediawiki-site' is called for this site")
                                 (:oauth-client-id string
                                   :description "OAuth 2.0 client ID (for client-credentials flow)")
                                 (:oauth-client-secret string
                                   :description "OAuth 2.0 client secret (for client-credentials flow)")
                                 (:oauth-access-token string
                                   :description "OAuth 2.0 access token (for owner-only consumers)")
                                 (:oauth-refresh-token string
                                   :description "OAuth 2.0 refresh token")
                                 (:oauth-token-url string
                                   :description "Custom OAuth 2.0 token endpoint URL"))))))

;;; Site Extraction Functions

(defun mediawiki-site--plist-start (site)
  "Return the position of the first keyword in SITE entry after the URL.
Site entries have the form (SITENAME URL . REST) where REST contains
optional positional fields (USERNAME PASSWORD DOMAIN) followed by a
keyword plist.  This function finds where the plist begins.
If no keyword is found, returns 5 (legacy position) for entries with
5+ elements, or the list length otherwise."
  (let ((i 2)
        (len (length site)))
    (while (and (< i len) (not (keywordp (nth i site))))
      (setq i (1+ i)))
    (if (< i len)
        ;; Found a keyword at position i
        i
      ;; No keyword found — legacy format
      (if (>= len 5) 5 len))))

(defun mediawiki-site-extract (sitename index)
  "Using `mediawiki-site-alist' and SITENAME, find the nth item using INDEX.
For indices 2-4 (USERNAME, PASSWORD, DOMAIN), if any earlier element
is a keyword the plist has started and those positional fields are
absent — returns nil (caller should fall back to auth-source)."
  (let* ((site (assoc sitename mediawiki-site-alist))
         (plist-start (mediawiki-site--plist-start site))
         (bit (nth index site)))
    (cond
      ((keywordp bit)
        ;; Keyword in a positional slot means that field is absent
        nil)
      ((stringp bit)
        ;; If we're at or past the plist start at indices 2-4, the string
        ;; is a plist value, not a positional field.  Use strict < because
        ;; strings at the plist-start index (e.g., legacy first-page at
        ;; position 5) are legitimate positional values.
        (if (and (> index 1) (< plist-start index))
            nil
          bit))
      ((and (listp bit) (> (length bit) 0))
        (car bit))
      ((symbolp bit)
        bit)
      (nil))))

;;;###autoload
(defun mediawiki-browse (&optional buffer)
  "Open the BUFFER in a browser.
If BUFFER is not given, the current buffer is used."
  (interactive)
  (if mediawiki-page-title
    (browse-url (mediawiki-make-url mediawiki-page-title "view"))
    (with-current-buffer buffer
      (browse-url (mediawiki-make-url mediawiki-page-title "view")))))

(declare-function mediawiki-do-login "mediawiki-auth")
(declare-function mediawiki-edit "mediawiki-page")
(declare-function mediawiki-minibuffer-completion-keys "mediawiki-core")
(declare-function mediawiki-oauth-configured-p "mediawiki-oauth")
(declare-function mediawiki-oauth-userinfo "mediawiki-oauth")
(declare-function mediawiki-api-call "mediawiki-api" (sitename action &optional args))
;;;###autoload
(defun mediawiki-site (&optional site)
  "Set up mediawiki.el for a SITE.
Without an argument, use `mediawiki-site-default'.
Interactively, prompt for a SITE."
  (interactive)
  (require 'mediawiki)
  (when (not site)
    (setq site (mediawiki-prompt-for-site)))
  (when (or (eq nil mediawiki-site)
          (not (string-equal site mediawiki-site)))
    (setq mediawiki-site (mediawiki-do-login site)))
  (mediawiki-edit site (mediawiki-site-first-page site)))

(defun mediawiki-site-url (sitename)
  "Get the url for a given SITENAME."
  (mediawiki-site-extract sitename 1))

(defmacro mediawiki-site-user-pass (sitename index method)
  "Fetch the user or pass if provided, or use authinfo if not."
  `(let* ((arg (mediawiki-site-extract ,sitename ,index))
           (auth (funcall ,method (mediawiki-site-url ,sitename))))
     (if (and (stringp arg) (> (string-width arg) 0))
       arg
       auth)))

(defun mediawiki-site-username (sitename)
  "Get the username for a given SITENAME.
A name configured for the site wins.  For an OAuth site without one,
ask the wiki which user the token belongs to: auth-source's login field
for an OAuth consumer holds the client ID, not a user name."
  (or (let ((configured (mediawiki-site-extract sitename 2)))
        (and (stringp configured)
             (> (string-width configured) 0)
             configured))
      (and (fboundp 'mediawiki-oauth-configured-p)
           (mediawiki-oauth-configured-p sitename)
           (fboundp 'mediawiki-oauth-userinfo)
           (mediawiki-oauth-userinfo sitename))
      (url-user-for-url (mediawiki-site-url sitename))))

;;; Site Version and Capabilities

(defvar mediawiki-site--versions (make-hash-table :test #'equal)
  "Cache of sitename to the MediaWiki version as a (MAJOR MINOR PATCH) list.")

(defun mediawiki-site--parse-version (string)
  "Parse \"MediaWiki 1.43.1\" or \"1.43\" into a (MAJOR MINOR PATCH) list."
  (when (and (stringp string)
             (string-match "\\([0-9]+\\)\\.\\([0-9]+\\)\\(?:\\.\\([0-9]+\\)\\)?" string))
    (list (string-to-number (match-string 1 string))
          (string-to-number (match-string 2 string))
          (string-to-number (or (match-string 3 string) "0")))))

(defun mediawiki-site-version (sitename)
  "Return the MediaWiki version of SITENAME as (MAJOR MINOR PATCH).
Cached per site.  Returns nil when the version cannot be determined;
callers should then assume an older wiki and use the older API."
  (let ((cached (gethash sitename mediawiki-site--versions 'unknown)))
    (if (not (eq cached 'unknown))
        cached
      (let ((ver (ignore-errors
                   (let* ((result (mediawiki-api-call
                                   sitename "query"
                                   '(("meta" . "siteinfo")
                                     ("siprop" . "general")
                                     ("formatversion" . "2"))))
                          (general (alist-get 'general
                                              (alist-get 'query result))))
                     (or (mediawiki-site--parse-version
                          (alist-get 'mwversion general))
                         (mediawiki-site--parse-version
                          (alist-get 'generator general)))))))
        (when ver
          (puthash sitename ver mediawiki-site--versions))
        ver))))

(defun mediawiki-site-at-least (sitename major minor &optional patch)
  "Return non-nil when SITENAME runs MediaWiki MAJOR.MINOR.PATCH or newer.
An unknown version returns nil, so callers fall back to the older API."
  (let ((have (mediawiki-site-version sitename))
        (want (list major minor (or patch 0))))
    (and have
         (or (> (nth 0 have) (nth 0 want))
             (and (= (nth 0 have) (nth 0 want))
                  (or (> (nth 1 have) (nth 1 want))
                      (and (= (nth 1 have) (nth 1 want))
                           (>= (nth 2 have) (nth 2 want)))))))))

(defun mediawiki-site-forget-version (&optional sitename)
  "Forget the cached version for SITENAME, or for every site."
  (if sitename
      (remhash sitename mediawiki-site--versions)
    (clrhash mediawiki-site--versions)))

(defun mediawiki-site--auth-secret (entry)
  "Return the password from an auth-source ENTRY, or nil.
ENTRY may carry the secret directly or as a function."
  (let ((secret (plist-get entry :secret)))
    (cond ((functionp secret) (funcall secret))
          ((stringp secret) secret)
          (t nil))))

(defun mediawiki-site-password (sitename)
  "Get the password for a given SITENAME.
Uses the password in `mediawiki-site-alist' when it is not empty and
otherwise asks auth-source, preferring an entry that actually carries
a secret.  `url-password-for-url' alone is not enough: it stops at the
first entry for the host, which need not have a password."
  (let ((arg (mediawiki-site-extract sitename 3)))
    (if (and (stringp arg) (> (string-width arg) 0))
        arg
      (let* ((url (url-generic-parse-url (mediawiki-site-url sitename)))
             (host (url-host url))
             (user (ignore-errors (mediawiki-site-username sitename)))
             (found (or (and user
                             (auth-source-search :host host :user user
                                                 :require '(:secret) :max 1))
                        (auth-source-search :host host
                                            :require '(:secret) :max 1))))
        (when found
          (mediawiki-site--auth-secret (car found)))))))

(defun mediawiki-site-domain (sitename)
  "Get the LDAP domain for a given SITENAME."
  (let ((domain (mediawiki-site-extract sitename 4)))
    (when (and (stringp domain) (not (string= "" domain)))
      domain)))

(defun mediawiki-site-first-page (sitename)
  "Get the first page for a given SITENAME.
Supports both the keyword format (:first-page \"Page\") and the legacy
positional format where the 6th element (index 5) is the first page."
  (let ((page (or (mediawiki-site-property sitename :first-page)
                  ;; Legacy positional format: index 5 as plain string
                  (mediawiki-site-extract sitename 5))))
    (if (or (not page) (string= page ""))
      "Main Page"
      page)))

;;; Site Selection Functions

(defun mediawiki-prompt-for-site ()
  "Prompt the user for a site."
  (let* ((prompt (concat "Sitename"
                   (when mediawiki-site
                     (format " (default %s)" mediawiki-site))
                   ": "))
          (answer (minibuffer-with-setup-hook
                      #'mediawiki-minibuffer-completion-keys
                    (completing-read prompt mediawiki-site-alist nil t))))
    (if (string= "" answer)
      mediawiki-site
      answer)))

;;; Site Management Functions

(defun mediawiki-site-list ()
  "Return a list of all configured site names."
  (mapcar 'car mediawiki-site-alist))

(defun mediawiki-site-description (sitename)
  "Get the description for a given SITENAME."
  (mediawiki-site-property sitename :description))

(defun mediawiki-site-property (sitename property)
  "Get a PROPERTY for a given SITENAME.
Site entries can be in legacy format (5 or 6 positional elements
with an optional plist) or modern format (2 positional elements
followed by a keyword plist).  The username, password, and domain
fields are optional — omit them to fall back to auth-source."
  (let ((site (assoc sitename mediawiki-site-alist)))
    (when site
      (let ((props (nthcdr (mediawiki-site--plist-start site) site)))
        (plist-get props property)))))

(defun mediawiki-site-valid-p (sitename)
  "Return t if SITENAME is a valid configured site."
  (not (null (assoc sitename mediawiki-site-alist))))

(provide 'mediawiki-site)

;;; mediawiki-site.el ends here
