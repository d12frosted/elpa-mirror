(define-package "unify-opening" "20220521.911" "Unify the mechanism to open files"
  '((emacs "24.4"))
  :commit "4c6e3447e203a51af116a2117e88d41114950205" :authors
  '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainers
  '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainer
  '("Damien Cassou" . "damien.cassou@gmail.com")
  :url "https://github.com/DamienCassou/unify-opening")
;; Local Variables:
;; no-byte-compile: t
;; End:
