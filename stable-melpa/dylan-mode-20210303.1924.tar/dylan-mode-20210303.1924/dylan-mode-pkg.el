(define-package "dylan-mode" "20210303.1924" "Major mode for the Dylan programming language. http://opendylan.org" 'nil :commit "98e5ea7538e50571683baa9240c8395724887807" :authors
  '(("Robert Stockton" . "rgs@cs.cmu.edu"))
  :maintainer
  '("Chris Page" . "cpage@opendylan.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
