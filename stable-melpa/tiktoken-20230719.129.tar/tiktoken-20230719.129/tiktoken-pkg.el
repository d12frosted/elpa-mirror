(define-package "tiktoken" "20230719.129" "Count BPE Tokens"
  '((emacs "28.0")
    (f "0.20.0"))
  :commit "957ece897933460d532057fe60cfddcd9e49d8b5" :authors
  '(("Zachary Romero"))
  :maintainers
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("tools")
  :url "https://github.com/zkry/tiktoken.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
