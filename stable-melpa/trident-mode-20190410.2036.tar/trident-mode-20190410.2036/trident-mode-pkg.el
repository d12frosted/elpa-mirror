;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trident-mode" "20190410.2036"
  "Live Parenscript interaction."
  '((emacs       "24")
    (slime       "20130526")
    (skewer-mode "1.5.0")
    (dash        "1.0.3"))
  :url "https://github.com/johnmastro/trident-mode.el"
  :commit "109a1bc10bd0c4b47679a6ca5c4cd27c7c8d4ccb"
  :revdesc "109a1bc10bd0"
  :keywords '("languages" "lisp" "processes" "tools")
  :authors '(("John Mastro" . "john.b.mastro@gmail.com"))
  :maintainers '(("John Mastro" . "john.b.mastro@gmail.com")))
