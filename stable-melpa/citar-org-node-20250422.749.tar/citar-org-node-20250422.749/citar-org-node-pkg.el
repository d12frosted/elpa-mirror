;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-org-node" "20250422.749"
  "Citar integration with org-node."
  '((emacs    "26.1")
    (citar    "1.1")
    (org-node "2.0.0")
    (ht       "1.6"))
  :url "https://github.com/krisbalintona/citar-org-node"
  :commit "0ba99e8a91ab3a634093224cbeefabdea1469664"
  :revdesc "0ba99e8a91ab"
  :keywords '("tools")
  :authors '(("Kristoffer Balintona" . "krisbalintona@gmail.com"))
  :maintainers '(("Kristoffer Balintona" . "krisbalintona@gmail.com")))
