(define-package "stimmung-themes" "20230411.917" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "a0fe9b34042bd08eaa94b2ad0e5068f538f21b5a" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
