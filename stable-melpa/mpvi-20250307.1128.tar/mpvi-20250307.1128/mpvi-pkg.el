;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250307.1128"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "6a0fa31c95cc6f37feedc0fce09e8db603e306a4"
  :revdesc "6a0fa31c95cc"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
