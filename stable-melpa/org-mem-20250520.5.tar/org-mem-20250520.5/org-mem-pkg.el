;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250520.5"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "3f72974a62cc92f1462dfba3548b1cacc9839fd3"
  :revdesc "3f72974a62cc"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
