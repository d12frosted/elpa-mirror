;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "howm" "20250929.1047"
  "Wiki-like note-taking tool."
  '((cl-lib "0.5"))
  :url "https://kaorahi.github.io/howm/"
  :commit "bfbb51d418250b38b695916ad464d093a638cdec"
  :revdesc "bfbb51d41825"
  :authors '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com"))
  :maintainers '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com")))
