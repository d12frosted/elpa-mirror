;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251021.553"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "2911541d00a5049f2efaf360d1f775534ac4189a"
  :revdesc "2911541d00a5"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
