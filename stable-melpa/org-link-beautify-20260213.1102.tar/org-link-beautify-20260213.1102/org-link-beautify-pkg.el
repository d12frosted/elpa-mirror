;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260213.1102"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "1fca4d7730e200dcf800c8a4346f6eb48619acaf"
  :revdesc "1fca4d7730e2"
  :keywords '("hypermedia"))
