;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260729.1444"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "8a3d6cb912a075b84bd84a373b983ec524688ef8"
  :revdesc "8a3d6cb912a0"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
