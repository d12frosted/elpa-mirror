(define-package "alarm-clock" "20230216.1337" "Alarm Clock"
  '((emacs "24.4"))
  :commit "3e43ca49804afb06477dbf7ff3d6e9824522be4b" :authors
  '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainer
  '("Steve Lemuel" . "wlemuel@hotmail.com")
  :keywords
  '("calendar" "tools" "convenience")
  :url "https://github.com/wlemuel/alarm-clock")
;; Local Variables:
;; no-byte-compile: t
;; End:
