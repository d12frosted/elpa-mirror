;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261029.1346"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "29e1fa1836af184c48ed5aba2f33ceaf698ef8e4"
  :revdesc "29e1fa1836af"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
