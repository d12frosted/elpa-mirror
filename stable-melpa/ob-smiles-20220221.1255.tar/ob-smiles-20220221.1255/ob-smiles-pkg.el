;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-smiles" "20220221.1255"
  "Org-mode Babel support for SMILES."
  '((smiles-mode "0.0.1")
    (org         "8"))
  :url "https://repo.or.cz/ob-smiles.git"
  :commit "d178f3d4a7e3c1ca9910f0a063d2a3cfd97d8609"
  :revdesc "d178f3d4a7e3"
  :keywords '("org" "babel" "smiles")
  :authors '((nil . "JohnKitchinjkitchin@andrew.cmu.edu"))
  :maintainers '((nil . "stardivinernumbchild@gmail.com")))
