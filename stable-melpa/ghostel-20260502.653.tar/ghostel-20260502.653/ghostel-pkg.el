;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260502.653"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "370c139d0d3f8f4356f8a6535696ae550822dcb1"
  :revdesc "370c139d0d3f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
