;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260220.2153"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "8ffcb955ee292e318eb700281877da20d6f969c4"
  :revdesc "8ffcb955ee29"
  :keywords '("docs" "wp")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
