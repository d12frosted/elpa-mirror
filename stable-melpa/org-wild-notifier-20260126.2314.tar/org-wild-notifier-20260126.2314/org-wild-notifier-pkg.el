;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-wild-notifier" "20260126.2314"
  "Customizable org-agenda notifications."
  '((alert "1.2")
    (async "1.9.3")
    (dash  "2.18.0")
    (emacs "27.1"))
  :url "https://github.com/emacsorphanage/org-wild-notifier.el"
  :commit "86c55aa80e499d10ef6dba5b804dba82d188d32e"
  :revdesc "86c55aa80e49"
  :keywords '("calendar" "convenience")
  :authors '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainers '(("Artem Khramov" . "akhramov+emacs@pm.me")))
