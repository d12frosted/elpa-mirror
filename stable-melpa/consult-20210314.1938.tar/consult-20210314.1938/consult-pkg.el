(define-package "consult" "20210314.1938" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "bf924c83aa13d34da937021e863d5b1fc2571963" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
