;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261103.55"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "4f6d2d856dff1eaaa460a7e6c885c110b461c17b"
  :revdesc "4f6d2d856dff"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
