;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260219.1037"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "019c1aa1ddb637c5b3c6ecb09b9b290facfde11e"
  :revdesc "019c1aa1ddb6"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
