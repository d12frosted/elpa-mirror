;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocaml-eglot" "20260505.111"
  "An OCaml companion for Eglot."
  '((emacs "29.1"))
  :url "https://github.com/tarides/ocaml-eglot"
  :commit "f3a9107827ee3b3875192c9cd27de5bfd4caec0c"
  :revdesc "f3a9107827ee"
  :keywords '("ocaml" "languages")
  :authors '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com"))
  :maintainers '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com")))
