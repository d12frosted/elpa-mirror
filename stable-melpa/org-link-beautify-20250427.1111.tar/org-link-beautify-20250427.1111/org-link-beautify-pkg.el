;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20250427.1111"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "568d845fb7a7d293818b06777cf56246b639c159"
  :revdesc "568d845fb7a7"
  :keywords '("hypermedia"))
