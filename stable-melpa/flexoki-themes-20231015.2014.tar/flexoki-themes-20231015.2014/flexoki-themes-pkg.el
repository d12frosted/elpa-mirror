(define-package "flexoki-themes" "20231015.2014" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "12f34de01cc3319291ef734a1b997a7b333effda" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
