(define-package "llama-cpp" "20231129.820" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "275d2c794fc14f831bbf67c55f382f64053c1f3f" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
