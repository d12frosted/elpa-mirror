(define-package "org-pivotal" "20210701.342" "Sync Pivotal Tracker to org buffer"
  '((a "0.1.1")
    (dash "2.18.0")
    (emacs "26.1")
    (request "0.3.0"))
  :commit "f55b9773b2f4a502e636688bc1caa21ee0396abe" :authors
  '(("Huy Duong" . "qhuyduong@hotmail.com"))
  :maintainer
  '("Huy Duong" . "qhuyduong@hotmail.com")
  :url "https://github.com/org-pivotal/org-pivotal")
;; Local Variables:
;; no-byte-compile: t
;; End:
