(define-package "fanyi" "20211015.1502" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "d6913c8a8dff0711d3e3dc42ba1b63fb0a39ece5" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
