(define-package "keg" "20211019.1750" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "bd572121c789a080818c83b7a6073186cd2d9049" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
