;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261113.924"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "771d8a62e56e3e58826612293b93fd1cea376f0d"
  :revdesc "771d8a62e56e"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
