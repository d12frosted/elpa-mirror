(define-package "window-purpose" "20210327.841" "Purpose-based window management for Emacs"
  '((emacs "24.4")
    (let-alist "1.0.3")
    (imenu-list "0.1"))
  :commit "1e66b36580b3a86e825dac019112dcd7de0a1a8b" :authors
  '(("Bar Magal"))
  :maintainer
  '("Bar Magal")
  :keywords
  '("frames")
  :url "https://github.com/bmag/emacs-purpose")
;; Local Variables:
;; no-byte-compile: t
;; End:
