;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241012.1904"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "e7310ccb43c4051f2e55fe10a5bcebfb7029ae95"
  :revdesc "e7310ccb43c4"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
