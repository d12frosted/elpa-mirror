(define-package "hyperdrive" "20230515.2057" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.3.2")
    (plz "0.6pre")
    (persist "0.5"))
  :commit "e3a2be5e6443635eff2bbcca9f8d3705a0455d59" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
