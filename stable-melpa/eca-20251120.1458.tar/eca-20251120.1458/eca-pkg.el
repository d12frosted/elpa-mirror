;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251120.1458"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "0d7e27b465dab4641fb779a6f58a6b0ea32fc098"
  :revdesc "0d7e27b465da"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
