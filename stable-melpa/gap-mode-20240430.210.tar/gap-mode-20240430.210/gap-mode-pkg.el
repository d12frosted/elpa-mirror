;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gap-mode" "20240430.210"
  "Major mode for editing files in the GAP programming language."
  ()
  :url "https://gitlab.com/gvol/gap-mode"
  :commit "09b4082b6e28141537696bb832c8ecc975ec57d8"
  :revdesc "09b4082b6e28"
  :keywords '("gap")
  :authors '(("Michael Smith" . "smith@pell.anu.edu.au")
             ("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainers '(("Ivan Andrus" . "darthandrus@gmail.com")))
