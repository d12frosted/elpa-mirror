(define-package "org-vcard" "20200720.638" "org-mode support for vCard export and import." 'nil :commit "1ae97371b207dabfecaf6b4f7118abafe6cc5e2b" :authors
  (("Alexis" . "flexibeast@gmail.com")
   ("Will Dey" . "will123dey@gmail.com"))
  :maintainer
  ("Alexis" . "flexibeast@gmail.com")
  :keywords
  ("outlines" "org" "vcard")
  :url "https://github.com/flexibeast/org-vcard")
;; Local Variables:
;; no-byte-compile: t
;; End:
