;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250323.601"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "462c2dc6613bcf4fe4ce039a3eae7b01387000fe"
  :revdesc "462c2dc6613b"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
