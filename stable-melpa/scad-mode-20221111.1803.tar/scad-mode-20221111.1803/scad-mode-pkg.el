(define-package "scad-mode" "20221111.1803" "A major mode for editing OpenSCAD code"
  '((emacs "27.1"))
  :commit "efc5f1cf1485b28ce77c9d83506d98bdca932659" :authors
  '(("Len Trigg, Łukasz Stelmach, zk_phi, Daniel Mendler"))
  :maintainer
  '("Len Trigg <lenbok@gmail.com>, Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("languages")
  :url "https://github.com/openscad/emacs-scad-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
