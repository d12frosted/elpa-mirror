;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260425.1212"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.8.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "3c61db63eec06334869258905a86d1fb8af5c507"
  :revdesc "3c61db63eec0"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
