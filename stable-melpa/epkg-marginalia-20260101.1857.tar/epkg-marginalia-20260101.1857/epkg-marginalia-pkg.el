;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg-marginalia" "20260101.1857"
  "Show Epkg information in completion annotations."
  '((emacs      "28.1")
    (compat     "30.1")
    (epkg       "4.1")
    (marginalia "2.7"))
  :url "https://github.com/emacscollective/epkg-marginalia"
  :commit "a42de3acf215bec1d3a06b63c98d0ad9182ce760"
  :revdesc "a42de3acf215"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev")))
