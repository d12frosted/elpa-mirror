(define-package "modus-themes" "20221120.524" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "7cc9bb0f41f75b36c05fc88af7b3c4bcaf136bd0" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
