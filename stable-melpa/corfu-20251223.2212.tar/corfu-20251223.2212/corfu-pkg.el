;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251223.2212"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "0198f34f29a598c05c4b95dc3dfb8391f572d7d4"
  :revdesc "0198f34f29a5"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
