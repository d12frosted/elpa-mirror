(define-package "empv" "20230820.1340" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0"))
  :commit "1721a581d68f211a7f0104554858ea2afb1723ff" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
