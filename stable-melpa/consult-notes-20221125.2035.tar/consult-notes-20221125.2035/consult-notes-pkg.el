(define-package "consult-notes" "20221125.2035" "Manage notes with consult"
  '((emacs "27.1")
    (consult "0.17")
    (s "1.12.0")
    (dash "2.19"))
  :commit "bc8a755966085b3d9728c2bdc595f61ed56f5b78" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience")
  :url "https://github.com/mclear-tools/consult-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
