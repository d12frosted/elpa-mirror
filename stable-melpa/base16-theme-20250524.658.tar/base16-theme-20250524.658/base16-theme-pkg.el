;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20250524.658"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "840a3ab3c7216e283133edb344447bcba267f7a5"
  :revdesc "840a3ab3c721"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
