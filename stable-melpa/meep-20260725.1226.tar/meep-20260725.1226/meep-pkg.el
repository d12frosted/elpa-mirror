;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260725.1226"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "eaf7e5a069ab3a37ec87150a50f45021e64150eb"
  :revdesc "eaf7e5a069ab"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
