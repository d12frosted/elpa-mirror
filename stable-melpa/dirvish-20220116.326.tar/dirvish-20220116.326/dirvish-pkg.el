(define-package "dirvish" "20220116.326" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a2be700763291d8e88f537209690ba31fe0d8c09" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
