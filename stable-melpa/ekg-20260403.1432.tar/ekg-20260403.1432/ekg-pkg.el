;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260403.1432"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "d4f984a4e929fcee0d7567487e4eea40c799ba1f"
  :revdesc "d4f984a4e929"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
