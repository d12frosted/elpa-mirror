;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260501.2316"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "ba1e5b91d3164e29f469fee1335e4aee264dc348"
  :revdesc "ba1e5b91d316"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
