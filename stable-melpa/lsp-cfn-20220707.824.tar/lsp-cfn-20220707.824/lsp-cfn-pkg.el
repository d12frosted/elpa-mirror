(define-package "lsp-cfn" "20220707.824" "LSP integration for cfn-lsp-extra"
  '((emacs "27.0")
    (lsp-mode "8.0.0")
    (yaml-mode "0.0.15"))
  :commit "8061bbe64d575457ce065240e7dcddcd8f90174c" :authors
  '(("Laurence Warne"))
  :maintainer
  '("Laurence Warne")
  :url "https://github.com/LaurenceWarne/lsp-cfn.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
