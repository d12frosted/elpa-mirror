(define-package "lsp-cfn" "20220707.824" "LSP integration for cfn-lsp-extra"
  '((emacs "27.0")
    (lsp-mode "8.0.0")
    (yaml-mode "0.0.15"))
  :commit "624f34c353844f4835e15cf7930b3f74cc67cb5c" :authors
  '(("Laurence Warne"))
  :maintainer
  '("Laurence Warne")
  :url "https://github.com/LaurenceWarne/lsp-cfn.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
