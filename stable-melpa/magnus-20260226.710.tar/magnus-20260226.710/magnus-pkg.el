;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260226.710"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "be19e7edfd6c3f54dd3b360a46931c5e2501b9e9"
  :revdesc "be19e7edfd6c"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
