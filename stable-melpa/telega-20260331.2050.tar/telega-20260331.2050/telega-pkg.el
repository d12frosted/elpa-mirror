;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260331.2050"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "8053d138392ae94177fbbce85114c07151dd12ee"
  :revdesc "8053d138392a"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
