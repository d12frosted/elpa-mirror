;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260109.411"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "bc852af95266b38b3500ce730af29be9d323d089"
  :revdesc "bc852af95266"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
