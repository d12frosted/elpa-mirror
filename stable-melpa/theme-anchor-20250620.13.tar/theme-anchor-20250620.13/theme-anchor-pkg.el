;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "theme-anchor" "20250620.13"
  "Apply theme in current buffer only."
  '((emacs "26"))
  :url "https://github.com/GongYiLiao/theme-anchor"
  :commit "a9143dbd6a073a6538f011d4095432152de127b7"
  :revdesc "a9143dbd6a07"
  :keywords '("extensions" "lisp" "theme")
  :authors '(("Kiong-Gē" . "gliao.tw@pm.me"))
  :maintainers '(("Kiong-Gē" . "gliao.tw@pm.me")))
