(define-package "chronometrist-key-values" "20210608.802" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "08ff5cd09a64651940e6b4d36fd86464a684107e" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
