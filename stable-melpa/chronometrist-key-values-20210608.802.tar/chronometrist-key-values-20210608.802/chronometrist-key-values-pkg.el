(define-package "chronometrist-key-values" "20210608.802" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "de41c158b5e21587aa6ad2601a2ed367d7f1534d" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
