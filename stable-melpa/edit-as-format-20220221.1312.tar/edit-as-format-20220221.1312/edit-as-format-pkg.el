;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-as-format" "20220221.1312"
  "Edit document as other format."
  '((emacs         "26.1")
    (edit-indirect "0.1.5"))
  :url "https://github.com/etern/edit-as-format"
  :commit "59c6f439683846d994a7a2110b9b00cc16c08c40"
  :revdesc "59c6f4396838"
  :keywords '("files" "outlines" "convenience")
  :authors '(("Xiaobing Jing" . "jingxiaobing@gmail.com"))
  :maintainers '(("Xiaobing Jing" . "jingxiaobing@gmail.com")))
