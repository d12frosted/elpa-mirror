(define-package "edit-as-format" "20220221.1312" "Edit document as other format"
  '((emacs "26.1")
    (edit-indirect "0.1.5"))
  :commit "59c6f439683846d994a7a2110b9b00cc16c08c40" :authors
  '(("Xiaobing Jing" . "jingxiaobing@gmail.com"))
  :maintainer
  '("Xiaobing Jing" . "jingxiaobing@gmail.com")
  :keywords
  '("files" "outlines" "convenience")
  :url "https://github.com/etern/edit-as-format")
;; Local Variables:
;; no-byte-compile: t
;; End:
