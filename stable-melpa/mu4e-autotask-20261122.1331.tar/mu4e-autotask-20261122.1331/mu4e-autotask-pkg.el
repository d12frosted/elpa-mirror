;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-autotask" "20261122.1331"
  "Email automation for mu4e."
  '((emacs "29.1"))
  :url "https://github.com/laurynas-biveinis/mu4e-autotask"
  :commit "67ce827d9ba6ba549c0981c04557b2037642aa46"
  :revdesc "67ce827d9ba6"
  :keywords '("mail")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
