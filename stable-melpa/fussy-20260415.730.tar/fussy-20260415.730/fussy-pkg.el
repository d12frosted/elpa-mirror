;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260415.730"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "6755c1f1e4764febbe2f7bdf770f2a73c79d5d70"
  :revdesc "6755c1f1e476"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
