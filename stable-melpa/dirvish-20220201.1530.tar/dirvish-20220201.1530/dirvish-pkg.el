(define-package "dirvish" "20220201.1530" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "3c79ce190c35a53fc828a65a51d2aa31112a5535" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
