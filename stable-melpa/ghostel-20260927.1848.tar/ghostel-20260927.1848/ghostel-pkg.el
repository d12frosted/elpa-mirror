;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260927.1848"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "eb53ff37994d5e43851432a710468bc1445453fa"
  :revdesc "eb53ff37994d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
