(define-package "howm" "20211228.1145" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "ffd7f5f921a4d83e2b86127d653ec87c3a3a6dac" :authors
  '(("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
