;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "20260808.909"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "bbd7975552684e5e0f9e02668c3d37c389265bc6"
  :revdesc "bbd797555268"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
