;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "20260215.2013"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "128f24cbaae9e6bb749169bf5a8e0acfe179c3cb"
  :revdesc "128f24cbaae9"
  :keywords '("tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
