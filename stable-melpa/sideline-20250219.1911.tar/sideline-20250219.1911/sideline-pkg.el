;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline" "20250219.1911"
  "Show information on the side."
  '((emacs "28.1")
    (ht    "2.4"))
  :url "https://github.com/emacs-sideline/sideline"
  :commit "14bfcf5b8e4b1fa5f2ba13e0984af93ca44c2e21"
  :revdesc "14bfcf5b8e4b"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
