;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20251030.35"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "389e8a5e730d933e9f5c568386992909196bfc10"
  :revdesc "389e8a5e730d"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")
                 ("John Ciolfi" . "john.ciolfi.32@gmail.com")))
