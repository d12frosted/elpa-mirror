;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20261027.2122"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "ea5f06126bd1448fa07370a9ee7ac8ed1dfc71ad"
  :revdesc "ea5f06126bd1"
  :keywords '("tools" "convenience" "text"))
