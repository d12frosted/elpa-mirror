(define-package "flycheck" "20240629.1521" "On-the-fly syntax checking"
  '((emacs "26.1"))
  :commit "1fab0226884a4615e9af69629a8e4de405a0b661" :authors
  '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://www.flycheck.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
