(define-package "org-link-beautify" "20231030.559" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1"))
  :commit "577f2e9e88ba04fb1793c456764f1b714fc059f7" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
