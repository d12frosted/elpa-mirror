(define-package "grugru" "20211114.948" "Rotate text at point"
  '((emacs "24.4"))
  :commit "b4ec1f1a2cdf3a2e59227d040513d0de012ac4f6" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
