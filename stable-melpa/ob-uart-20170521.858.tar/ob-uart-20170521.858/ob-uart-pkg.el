;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-uart" "20170521.858"
  "Org-babel support for UART communication."
  ()
  :url "https://www.0x7.ch"
  :commit "90daeac90a9e75c20cdcf71234c67b812110c50e"
  :revdesc "90daeac90a9e"
  :keywords '("tools" "comm" "org-mode" "uart" "literate programming" "reproducible development"))
