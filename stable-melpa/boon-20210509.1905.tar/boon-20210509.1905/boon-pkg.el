(define-package "boon" "20210509.1905" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "f1fba331e1941d9cc805e5636c1475665d81c9f6")
;; Local Variables:
;; no-byte-compile: t
;; End:
