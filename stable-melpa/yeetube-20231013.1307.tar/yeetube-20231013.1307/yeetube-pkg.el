(define-package "yeetube" "20231013.1307" "YouTube Front End"
  '((emacs "27.2"))
  :commit "1cd010ad9eeb919f3ca5d9e5fbfc2ac540b666ac" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.com/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
