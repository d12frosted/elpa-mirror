(define-package "live-py-mode" "20221125.1853" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "7c0a9d03e8b67a292606e8654eaa47102892fc24" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
