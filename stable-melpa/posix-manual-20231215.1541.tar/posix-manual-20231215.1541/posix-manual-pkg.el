(define-package "posix-manual" "20231215.1541" "POSIX manual page lookup"
  '((emacs "24"))
  :commit "d1685338bfcc0bdf7d8b9951b79d6fc7824ed07b" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/lassik/emacs-posix-manual")
;; Local Variables:
;; no-byte-compile: t
;; End:
