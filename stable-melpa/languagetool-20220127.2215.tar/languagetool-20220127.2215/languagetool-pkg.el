(define-package "languagetool" "20220127.2215" "LanguageTool integration for grammar and spell check"
  '((emacs "27.0")
    (request "0.3.2"))
  :commit "ea50c120ee3418489b43d51ed750288791d6eb95" :authors
  '(("Joar Buitrago" . "jebuitragoc@unal.edu.co"))
  :maintainer
  '("Joar Buitrago" . "jebuitragoc@unal.edu.co")
  :keywords
  '("grammar" "text" "docs" "tools" "convenience" "checker")
  :url "https://github.com/PillFall/Emacs-LanguageTool.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
