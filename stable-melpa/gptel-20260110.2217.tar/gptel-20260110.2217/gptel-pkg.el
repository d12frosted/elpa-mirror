;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260110.2217"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "1777f088614e32dd8f4754d5993c3b21c97201a5"
  :revdesc "1777f088614e"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
