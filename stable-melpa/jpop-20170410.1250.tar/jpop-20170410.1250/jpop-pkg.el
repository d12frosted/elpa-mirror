;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jpop" "20170410.1250"
  "Lightweight project caching and navigation framework."
  '((emacs  "24")
    (dash   "2.11.0")
    (cl-lib "0.5"))
  :url "https://github.com/domtronn/jpop.el"
  :commit "7628b03260be96576b34459d45959ee77d8b2110"
  :revdesc "7628b03260be"
  :keywords '("project" "convenience")
  :authors '(("Dom Charlesworth" . "dgc336@gmail.com"))
  :maintainers '(("Dom Charlesworth" . "dgc336@gmail.com")))
