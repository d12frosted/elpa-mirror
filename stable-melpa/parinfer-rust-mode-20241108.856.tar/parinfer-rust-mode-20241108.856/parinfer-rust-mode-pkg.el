;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parinfer-rust-mode" "20241108.856"
  "An interface for the parinfer-rust library."
  '((emacs         "26.1")
    (track-changes "1.1"))
  :url "https://github.com/justinbarclay/parinfer-rust-mode"
  :commit "74bb99edb3de4c0c18341e855d6c7620d6a9a9d3"
  :revdesc "74bb99edb3de"
  :keywords '("lisp" "tools")
  :authors '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers '(("Justin Barclay" . "justinbarclay@gmail.com")))
