(define-package "apdl-mode" "20211017.1548" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "d29ea95e71268f8c51a1e42c9dc7f03c1fbb0876" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
