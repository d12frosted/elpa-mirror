;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20260519.2240"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "4b1be54492ff1605f053e560dd23d0a8d29e10df"
  :revdesc "4b1be54492ff"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
