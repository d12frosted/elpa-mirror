;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "basic-theme" "20160817.827"
  "Minimalistic light color theme."
  '((emacs "24"))
  :url "https://github.com/fgeller/basic-theme.el"
  :commit "9d0fd5f56898a5237c1de3363ad416aeab7f880e"
  :revdesc "9d0fd5f56898"
  :keywords '("theme" "basic" "minimal" "colors")
  :authors '(("Felix Geller" . "fgeller@gmail.com"))
  :maintainers '(("Felix Geller" . "fgeller@gmail.com")))
