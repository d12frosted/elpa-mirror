(define-package "wanderlust" "20211212.909" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "7b06ce86a925ce3c41a54ecacc3c27afbe00dcf1")
;; Local Variables:
;; no-byte-compile: t
;; End:
