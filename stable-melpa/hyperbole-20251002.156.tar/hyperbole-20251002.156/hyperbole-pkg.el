;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251002.156"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "052b65cd32678df7f6fa813628e36d9f9d0c0bd5"
  :revdesc "052b65cd3267"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
