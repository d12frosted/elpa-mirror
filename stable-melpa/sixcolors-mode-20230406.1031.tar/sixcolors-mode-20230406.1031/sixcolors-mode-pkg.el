;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sixcolors-mode" "20230406.1031"
  "A customizable horizontal scrollbar."
  '((emacs "27.1"))
  :url "https://github.com/mastro35/sixcolors-mode"
  :commit "4124a8cf664b04a4bf4c39f7c3b7da3e480b99c8"
  :revdesc "4124a8cf664b"
  :keywords '("convenience" "colors")
  :authors '(("Davide Mastromatteo" . "mastro35@gmail.com"))
  :maintainers '(("Davide Mastromatteo" . "mastro35@gmail.com")))
