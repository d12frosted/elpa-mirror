;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250616.1620"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "90e41e2148473ca70b4aef8c2a7ebb65017224a6"
  :revdesc "90e41e214847"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
