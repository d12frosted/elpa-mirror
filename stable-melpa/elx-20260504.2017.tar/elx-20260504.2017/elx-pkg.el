;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "20260504.2017"
  "Extract information from Emacs Lisp libraries."
  '((emacs  "29.1")
    (compat "31.0")
    (llama  "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "98b1c7da98f0e7df5558e5ef00382d746b818c70"
  :revdesc "98b1c7da98f0"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
