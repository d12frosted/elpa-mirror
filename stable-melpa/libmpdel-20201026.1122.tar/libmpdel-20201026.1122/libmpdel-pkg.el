(define-package "libmpdel" "20201026.1122" "Communication with an MPD server"
  '((emacs "25.1"))
  :commit "e26060d2139841ef206704e7e0d2f9fa06a1884b" :authors
  (("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  ("Damien Cassou" . "damien@cassou.me")
  :keywords
  ("multimedia")
  :url "https://gitea.petton.fr/mpdel/libmpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
