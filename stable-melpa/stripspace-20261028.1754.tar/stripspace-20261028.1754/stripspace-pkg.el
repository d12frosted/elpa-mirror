;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20261028.1754"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "209006916a163d98d45624bd3e70aa39904cb0f9"
  :revdesc "209006916a16"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
