;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260511.1537"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "4cd5a5e1b2a7d94077815b50ba4850727bfcc129"
  :revdesc "4cd5a5e1b2a7"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
