(define-package "swift-mode" "20210612.1034" "Major-mode for Apple's Swift programming language"
  '((emacs "24.4")
    (seq "2.3"))
  :commit "f614620ad63adcb617df7964923766194810ec73" :keywords
  '("languages" "swift")
  :url "https://github.com/swift-emacs/swift-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
