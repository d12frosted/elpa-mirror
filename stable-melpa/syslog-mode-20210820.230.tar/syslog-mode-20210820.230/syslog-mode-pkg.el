(define-package "syslog-mode" "20210820.230" "Major-mode for viewing log files & strace output"
  '((hide-lines "20130623")
    (ov "20150311"))
  :commit "8a0495bed7d26ec6bab45b51b0c6a0ccd16de09a" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
