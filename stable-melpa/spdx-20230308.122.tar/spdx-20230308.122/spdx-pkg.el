(define-package "spdx" "20230308.122" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "390fbeaac9745651e0f81508a154533be5ea6567" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
