;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "white-sand-theme" "20210131.813"
  "Emacs theme with a light background."
  '((emacs "24"))
  :url "https://github.com/mswift42/white-sand-theme"
  :commit "729dd52cc1936250183d6761eed406c4be514a71"
  :revdesc "729dd52cc193")
