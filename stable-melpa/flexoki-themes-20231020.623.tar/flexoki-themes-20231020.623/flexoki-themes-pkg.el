(define-package "flexoki-themes" "20231020.623" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "262db9e912c9cde370f1981121778e9f3bf2beee" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
