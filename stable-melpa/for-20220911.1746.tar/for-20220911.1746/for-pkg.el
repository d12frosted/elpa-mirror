(define-package "for" "20220911.1746" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "719c4bb2480cb829f1f1a2f83bf6223e29d42b57" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
