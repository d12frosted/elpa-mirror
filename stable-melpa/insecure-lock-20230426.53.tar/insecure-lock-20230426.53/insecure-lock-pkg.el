;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insecure-lock" "20230426.53"
  "Extensible screen lock framework."
  '((emacs "28.1"))
  :url "https://github.com/BlueFlo0d/insecure-lock"
  :commit "33b2cf4ecf80d948cf0942aa8bc1787d44c99941"
  :revdesc "33b2cf4ecf80"
  :keywords '("unix" "screensaver" "security")
  :authors '(("Qiantan Hong" . "qhong@alum.mit.edu"))
  :maintainers '(("Qiantan Hong" . "qhong@alum.mit.edu")))
