;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddate" "20250306.1709"
  "Manage Discordian dates with ddate."
  '((emacs "24.4"))
  :url "https://git.sr.ht/~earneson/emacs-ddate"
  :commit "ec3de36ae7bcf71829f03a5063ee9912fcca40bc"
  :revdesc "ec3de36ae7bc"
  :keywords '("lisp" "dates" "tools" "dashboard")
  :authors '(("Erik L. Arneson" . "earneson@arnesonium.com"))
  :maintainers '(("Erik L. Arneson" . "earneson@arnesonium.com")))
