;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-xlatex" "20240707.1343"
  "Instant LaTeX preview in an xwidget."
  '((emacs "29.1"))
  :url "https://github.com/ksqsf/org-xlatex"
  :commit "8f25ba5e4784b3f12f5ac5c69b1a1d0695c53b8e"
  :revdesc "8f25ba5e4784"
  :keywords '("convenience" "org" "tex" "preview" "xwidget")
  :authors '(("ksqsf" . "justksqsf@gmail.com"))
  :maintainers '(("ksqsf" . "justksqsf@gmail.com")))
