;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260428.2221"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "1d49fcc82560eaa5dc8518ee8cc7b487c9b7621c"
  :revdesc "1d49fcc82560"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
