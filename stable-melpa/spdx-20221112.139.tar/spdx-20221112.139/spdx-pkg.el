(define-package "spdx" "20221112.139" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "73e7279bb95b2e9640b9dfbe3f6ffea366da90d1" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
