;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prog-face-refine" "20251224.840"
  "Refine faces for programming modes."
  '((emacs "28.0"))
  :url "https://codeberg.org/ideasman42/emacs-prog-face-refine"
  :commit "67237a7f4ad6da0a044b99c37da1eac4b3f0f906"
  :revdesc "67237a7f4ad6"
  :keywords '("faces" "convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
