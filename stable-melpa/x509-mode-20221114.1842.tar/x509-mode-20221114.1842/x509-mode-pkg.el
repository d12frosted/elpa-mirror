(define-package "x509-mode" "20221114.1842" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "b87e771348af1516fb0491033195333449e0fa65" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
