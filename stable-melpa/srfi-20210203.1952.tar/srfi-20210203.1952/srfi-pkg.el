(define-package "srfi" "20210203.1952" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "5fdbcaf734a2e4f3778d603f38fa7974a2dd8c45" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
