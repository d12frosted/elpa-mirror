(define-package "consult" "20230225.2229" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "873c636ec99efa7f408dc1ef11adb08f119a3944" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
