;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260403.2314"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "fdca45e4f84c7743b4a57c3318114fa987fafb95"
  :revdesc "fdca45e4f84c"
  :keywords '("convenience" "comm" "hypermedia"))
