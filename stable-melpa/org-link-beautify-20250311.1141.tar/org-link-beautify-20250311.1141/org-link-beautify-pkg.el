;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20250311.1141"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "23481836d2db7430b67f1ab698a1407acb9cb932"
  :revdesc "23481836d2db"
  :keywords '("hypermedia"))
