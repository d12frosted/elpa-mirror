(define-package "fanyi" "20211020.653" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "b76b60564929137d3cb0bf61ae5818381a36f467" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
