(define-package "telega" "20201224.1913" "Telegram client (unofficial)"
  '((emacs "26.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "83e3134954eb0eab0b85751e6dd89048a086d0d8" :authors
  (("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  ("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  ("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
