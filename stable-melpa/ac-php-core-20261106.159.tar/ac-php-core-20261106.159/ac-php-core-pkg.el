;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20261106.159"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "ccc16f6f7f9ff37fb132ddaca4c8fd4748643c6e"
  :revdesc "ccc16f6f7f9f"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
