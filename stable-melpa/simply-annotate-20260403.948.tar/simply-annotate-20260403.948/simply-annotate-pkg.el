;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260403.948"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "36c46bb49b830982fc1430c7c838248757ebd736"
  :revdesc "36c46bb49b83"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
