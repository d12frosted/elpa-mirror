;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flutter-l10n-flycheck" "20261010.2349"
  "Flycheck checker for intl_translation."
  '((emacs    "28.1")
    (flycheck "30")
    (flutter  "0.1.0"))
  :url "https://github.com/amake/flutter.el"
  :commit "b7ca9515ce04c68d5fa580c0b1a1cec5aed7c5a6"
  :revdesc "b7ca9515ce04"
  :keywords '("languages"))
