(define-package "angular-snippets" "20130505.1244" "Yasnippets for AngularJS"
  '((s "1.4.0")
    (dash "1.2.0"))
  :commit "8f737c2cf5fce758a7a3833ebad2952b5398568d" :authors
  '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainer
  '("Magnar Sveen" . "magnars@gmail.com")
  :keywords
  '("snippets"))
;; Local Variables:
;; no-byte-compile: t
;; End:
