;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260623.2303"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "cf83bdcfabfb06e0171f5f7a83d56d5fea72fd84"
  :revdesc "cf83bdcfabfb"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
