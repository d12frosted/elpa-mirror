;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stash" "20151117.1427"
  "Lightweight persistent caching."
  ()
  :url "https://www.github.com/vermiculus/stash.el/"
  :commit "c2e494d20c752b80ebbdffbf66687b3cdfc425ad"
  :revdesc "c2e494d20c75"
  :keywords '("extensions" "data" "internal" "lisp")
  :authors '(("Sean Allred" . "code@seanallred.com"))
  :maintainers '(("Sean Allred" . "code@seanallred.com")))
