(define-package "tok-theme" "20211225.1631" "My theme"
  '((emacs "24.3"))
  :commit "7cb50b32fd43330c8a2dc488a781bd8375f40fc6" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
