;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20251104.1644"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "18b89fbdf3b5b13ccfd0d3a09f6bb2925addbab2"
  :revdesc "18b89fbdf3b5"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
