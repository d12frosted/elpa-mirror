;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "20261002.154"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "86fa3054061e4b17eb2faa98bdf4d602d209d912"
  :revdesc "86fa3054061e"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
