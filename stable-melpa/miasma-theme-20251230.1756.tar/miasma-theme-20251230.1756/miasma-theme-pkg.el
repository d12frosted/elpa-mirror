;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20251230.1756"
  "Miasma: color theme inspired by the woods."
  ()
  :url "http://github.com/daut/miasma-theme.el"
  :commit "9abd24d2b1efbdea591f21a6c7360d44ad60bad9"
  :revdesc "9abd24d2b1ef")
