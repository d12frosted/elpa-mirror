(define-package "modus-themes" "20210712.1353" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "4cd1860b41a60acbd7510226960b7181ceb926df" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
