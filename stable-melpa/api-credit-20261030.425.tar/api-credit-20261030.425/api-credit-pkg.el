;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "api-credit" "20261030.425"
  "AI API balance in the modeline."
  '((emacs "25.1"))
  :url "https://github.com/OverbearingPearl/api-credit"
  :commit "7a473a9fc177a7441c62d77caeeaa6945f985290"
  :revdesc "7a473a9fc177"
  :keywords '("comm" "convenience")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
