;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-dark-theme" "20260202.1235"
  "Visual Studio IDE dark theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-dark-theme"
  :commit "4afa85cd27f107f2936ef2774b7113b6a5fd6e0a"
  :revdesc "4afa85cd27f1"
  :keywords '("faces"))
