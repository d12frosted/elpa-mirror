(define-package "gdscript-mode" "20210104.1919" "Major mode for Godot's GDScript language"
  '((emacs "26.3"))
  :commit "287acb7c76ef16981c6a6d7a714e1a6aa7cda43b" :authors
  '(("Nathan Lovato <nathan@gdquest.com>, Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainer
  '(nil . "nathan@gdquest.com")
  :keywords
  '("languages")
  :url "https://github.com/GDQuest/emacs-gdscript-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
