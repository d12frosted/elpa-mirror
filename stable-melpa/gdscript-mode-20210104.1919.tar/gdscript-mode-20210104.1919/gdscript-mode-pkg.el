(define-package "gdscript-mode" "20210104.1919" "Major mode for Godot's GDScript language"
  '((emacs "26.3"))
  :commit "e54edf94b875cf72a7dda0351999d9c34cea0921" :authors
  '(("Nathan Lovato <nathan@gdquest.com>, Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainer
  '(nil . "nathan@gdquest.com")
  :keywords
  '("languages")
  :url "https://github.com/GDQuest/emacs-gdscript-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
