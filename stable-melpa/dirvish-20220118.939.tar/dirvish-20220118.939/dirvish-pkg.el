(define-package "dirvish" "20220118.939" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a530012114d74ae9dcc4b1b81fcde143b7f21571" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
