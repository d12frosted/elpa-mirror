;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261028.1046"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "5fd3c831a0af0981c4e8114a61e8d012e7b477e2"
  :revdesc "5fd3c831a0af")
