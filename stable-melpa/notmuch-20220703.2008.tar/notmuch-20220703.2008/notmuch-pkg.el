(define-package "notmuch" "20220703.2008" "run notmuch within emacs" 'nil :commit "15b940d26aacadecf50469d3837ccb660fd5ba42" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
