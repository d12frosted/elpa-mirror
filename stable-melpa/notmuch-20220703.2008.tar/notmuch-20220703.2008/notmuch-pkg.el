(define-package "notmuch" "20220703.2008" "run notmuch within emacs" 'nil :commit "b07e121923a4ca00d0ec68ba9eebe8dafb70e13a" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
