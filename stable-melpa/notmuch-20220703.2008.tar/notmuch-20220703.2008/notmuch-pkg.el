(define-package "notmuch" "20220703.2008" "run notmuch within emacs" 'nil :commit "09fa6bcc0d1706889fe8f1fc86f39f9a1ab852ba" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
