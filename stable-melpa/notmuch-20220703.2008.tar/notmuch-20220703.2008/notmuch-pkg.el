(define-package "notmuch" "20220703.2008" "run notmuch within emacs" 'nil :commit "3cb936b7c458bc9b0f5cc6d7fb266307fd0224d8" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
