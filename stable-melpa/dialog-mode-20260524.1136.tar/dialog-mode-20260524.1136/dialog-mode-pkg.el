;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260524.1136"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "7f0db759b019dabd3630dbd3d69fb03a4c988105"
  :revdesc "7f0db759b019"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
