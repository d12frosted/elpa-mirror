(define-package "bibtex-actions" "20210809.1521" "Biblographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0"))
  :commit "7eb413509f41e94a11a876bf36de0404b6a9b5d6" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
