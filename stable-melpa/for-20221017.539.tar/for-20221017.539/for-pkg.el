(define-package "for" "20221017.539" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "317cb302c61d4c65f8122bbd7794e06e1cc9b192" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
