(define-package "pony-mode" "20170807.1522" "Minor mode for working with Django Projects" 'nil :commit "760684d30b6c234d1b88c9a4673a808f36f7f341")
;; Local Variables:
;; no-byte-compile: t
;; End:
