;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pony-mode" "20170807.1522"
  "Minor mode for working with Django projects."
  ()
  :url "https://github.com/davidmiller/pony-mode"
  :commit "760684d30b6c234d1b88c9a4673a808f36f7f341"
  :revdesc "760684d30b6c"
  :keywords '("python" "django")
  :authors '(("David Miller" . "david@deadpansincerity.com"))
  :maintainers '(("David Miller" . "david@deadpansincerity.com")))
