;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250524.124"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "5c6ff07d8615414f4112406008f49f17ea9c1070"
  :revdesc "5c6ff07d8615"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
