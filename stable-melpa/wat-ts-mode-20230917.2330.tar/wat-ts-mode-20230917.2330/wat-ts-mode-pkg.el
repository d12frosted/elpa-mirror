(define-package "wat-ts-mode" "20230917.2330" "Major mode for webassembly text format"
  '((emacs "29.1"))
  :commit "78ba6a2ecfe31acbbad87630c9244c949a776c30" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("wasm" "wat" "wast" "languages" "tree-sitter")
  :url "https://github.com/nverno/wat-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
