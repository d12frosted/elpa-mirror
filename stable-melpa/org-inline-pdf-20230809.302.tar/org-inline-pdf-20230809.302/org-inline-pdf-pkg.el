(define-package "org-inline-pdf" "20230809.302" "Inline PDF previewing for Org"
  '((emacs "25.1")
    (org "9.4"))
  :commit "4a4a29939f3910adc3183ddc7e352b04de9223e5" :authors
  '(("Shigeaki Nishina"))
  :maintainers
  '(("Shigeaki Nishina"))
  :maintainer
  '("Shigeaki Nishina")
  :keywords
  '("org" "outlines" "hypermedia")
  :url "https://github.com/shg/org-inline-pdf.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
