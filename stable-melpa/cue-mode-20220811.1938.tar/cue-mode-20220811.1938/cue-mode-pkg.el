;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cue-mode" "20220811.1938"
  "Major mode for CUE language files."
  '((emacs "25.1"))
  :url "https://github.com/russell/cue-mode"
  :commit "31c671d56e7884fa87ad0f1d27d0bb439dc65380"
  :revdesc "31c671d56e78"
  :keywords '("data" "languages")
  :authors '(("Russell Sim" . "russell.sim@gmail.com"))
  :maintainers '(("Russell Sim" . "russell.sim@gmail.com")))
