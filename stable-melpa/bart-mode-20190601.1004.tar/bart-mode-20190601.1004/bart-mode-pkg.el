;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bart-mode" "20190601.1004"
  "Real time BART departures info."
  '((emacs "24.3"))
  :url "https://github.com/mschuldt/bart-mode"
  :commit "f70b6c42452e47c0c6b3ebd4c90e555a9bedeec7"
  :revdesc "f70b6c42452e"
  :keywords '("convenience" "transit")
  :authors '(("Michael Schuldt" . "mbschuldt@gmail.com"))
  :maintainers '(("Michael Schuldt" . "mbschuldt@gmail.com")))
