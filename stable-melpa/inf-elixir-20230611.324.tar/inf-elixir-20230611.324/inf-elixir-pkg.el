(define-package "inf-elixir" "20230611.324" "Run an interactive Elixir shell"
  '((emacs "25.1"))
  :commit "d4ace5ac49c2bb07818fd2f40bae1f1a25e95481" :authors
  '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers
  '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainer
  '("Jonathan Arnett" . "jonathan.arnett@protonmail.com")
  :keywords
  '("languages" "processes" "tools")
  :url "https://github.com/J3RN/inf-elixir")
;; Local Variables:
;; no-byte-compile: t
;; End:
