(define-package "boon" "20220822.1348" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "ccf3e5c0c92f0f73d20f14cad0337e4cb0907a9b")
;; Local Variables:
;; no-byte-compile: t
;; End:
