;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260404.1827"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "0bbed459fb60f1b9ebe0e137527aa44b75c4835e"
  :revdesc "0bbed459fb60"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
