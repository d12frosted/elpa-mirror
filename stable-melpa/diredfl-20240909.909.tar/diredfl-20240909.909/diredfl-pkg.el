(define-package "diredfl" "20240909.909" "Extra font lock rules for a more colourful dired"
  '((emacs "24"))
  :commit "58400e0be8bd66a8fcb922fb231e52c08ba25228" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("faces")
  :url "https://github.com/purcell/diredfl")
;; Local Variables:
;; no-byte-compile: t
;; End:
