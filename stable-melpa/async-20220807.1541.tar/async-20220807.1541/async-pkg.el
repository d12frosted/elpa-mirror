(define-package "async" "20220807.1541" "Asynchronous processing in Emacs"
  '((emacs "24.4"))
  :commit "a75d35214d06c6b64d26428ec930fd2a2786e2eb" :authors
  '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("async")
  :url "https://github.com/jwiegley/emacs-async")
;; Local Variables:
;; no-byte-compile: t
;; End:
