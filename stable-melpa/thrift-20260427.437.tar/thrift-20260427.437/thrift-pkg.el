;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260427.437"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "5f79e50c386db64982d515751070f5e5a788ddd5"
  :revdesc "5f79e50c386d"
  :keywords '("languages"))
