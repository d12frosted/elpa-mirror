;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabgo" "20260624.1052"
  "Jump to tabs, avy style."
  '((emacs "27.1"))
  :url "https://github.com/isamert/tabgo.el"
  :commit "ffba627a30acb813ca839d1fc440d28ffa06ece2"
  :revdesc "ffba627a30ac"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
