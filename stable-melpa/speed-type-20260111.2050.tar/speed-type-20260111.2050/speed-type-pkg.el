;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260111.2050"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "3f3125727fc2543677df0b22b24561a0b2527a55"
  :revdesc "3f3125727fc2"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
