(define-package "cnfonts" "20211029.41" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "75ae690fc80b96583bf9c26dd09d7dfe6943bd4b" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
