(define-package "k8s-mode" "20201215.1656" "Major mode for Kubernetes configuration file"
  '((emacs "24.3")
    (yaml-mode "0.0.10"))
  :commit "9d37e64b9bdc1778481687ca04e2ee5a96bc0474" :authors
  (("Giap Tran" . "txgvnn@gmail.com"))
  :maintainer
  ("Giap Tran" . "txgvnn@gmail.com")
  :url "https://github.com/TxGVNN/emacs-k8s-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
