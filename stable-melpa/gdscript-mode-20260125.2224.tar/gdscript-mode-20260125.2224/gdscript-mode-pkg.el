;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260125.2224"
  "Major mode for Godot's GDScript language."
  '((emacs "28.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "2972f239e6a115113e06535a82633d38b35e2ae9"
  :revdesc "2972f239e6a1"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
