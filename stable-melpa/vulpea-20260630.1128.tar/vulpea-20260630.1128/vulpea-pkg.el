;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260630.1128"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "2ac15fabc0616f5057db5ecf294023177557146e"
  :revdesc "2ac15fabc061"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
