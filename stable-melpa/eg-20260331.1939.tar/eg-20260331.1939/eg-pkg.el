;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eg" "20260331.1939"
  "Norton Guide reader."
  '((emacs "29.1"))
  :url "https://github.com/davep/eg.el"
  :commit "6b4302a57c87f0535d4ebc51f701aecf4d3dbe87"
  :revdesc "6b4302a57c87"
  :keywords '("docs")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
