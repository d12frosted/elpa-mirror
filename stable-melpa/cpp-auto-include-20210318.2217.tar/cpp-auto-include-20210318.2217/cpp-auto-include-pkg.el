;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cpp-auto-include" "20210318.2217"
  "Insert and delete C++ header files automatically."
  '((cl-lib "0.5"))
  :url "https://github.com/emacsorphanage/cpp-auto-include"
  :commit "0ce829f27d466c083e78b9fe210dcfa61fb417f4"
  :revdesc "0ce829f27d46"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
