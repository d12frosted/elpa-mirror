;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crystal-mode" "20260111.2220"
  "Major mode for editing Crystal files."
  '((emacs "24.4"))
  :url "https://github.com/crystal-lang-tools/emacs-crystal-mode"
  :commit "559e1d8ff9bb87a4e937978001386bfb58b113a0"
  :revdesc "559e1d8ff9bb"
  :keywords '("languages" "crystal"))
