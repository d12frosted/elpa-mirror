;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260921.7"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "fe8be7dc7165609a338415aaab2f846653481a2e"
  :revdesc "fe8be7dc7165"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
