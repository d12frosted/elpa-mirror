(define-package "embark" "20210803.1904" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "fb2c85c67df7f86acdb04a5d3b286e2012b793b5" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
