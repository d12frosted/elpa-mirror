(define-package "org-link-beautify" "20230430.1237" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1"))
  :commit "4cc99e8fdc08d25c944db950773987d14dbbfc96" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
