(define-package "pyim" "20230115.2331" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "27.1")
    (async "1.6")
    (xr "1.13"))
  :commit "01c1b3d1c38e68abfdfa781af904b75217321288" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
