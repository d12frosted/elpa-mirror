;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260729.1151"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "0be0528075eb336a530fac51a33b0bc6c2f9158e"
  :revdesc "0be0528075eb"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
