;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imake" "20260521.1105"
  "Simple, opinionated make target runner."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/imake"
  :commit "5a610a7acf4e3c57155112159d228c0928935195"
  :revdesc "5a610a7acf4e"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev")))
