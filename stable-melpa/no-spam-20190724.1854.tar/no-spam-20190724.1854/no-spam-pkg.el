;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-spam" "20190724.1854"
  "Add repeat delays to commands."
  '((emacs "25.1"))
  :url "https://github.com/mamapanda/no-spam"
  :commit "860860e4a0d59bd15c8e092dc42f5f7f769a428e"
  :revdesc "860860e4a0d5"
  :keywords '("keyboard" "tools")
  :authors '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainers '(("Daniel Phan" . "daniel.phan36@gmail.com")))
