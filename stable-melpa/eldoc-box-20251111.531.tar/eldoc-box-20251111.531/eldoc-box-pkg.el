;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-box" "20251111.531"
  "Display documentation in childframe."
  '((emacs "27.1"))
  :url "https://github.com/casouri/eldoc-box"
  :commit "13d37dbbb3e8dfb10a2d99b66a9784f3a88a93a3"
  :revdesc "13d37dbbb3e8"
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
