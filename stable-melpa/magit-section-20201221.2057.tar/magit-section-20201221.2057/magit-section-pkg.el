(define-package "magit-section" "20201221.2057" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "c5e11811197ef8c667a605e5d9dd8ec77247bd13" :keywords
  ("tools")
  :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
