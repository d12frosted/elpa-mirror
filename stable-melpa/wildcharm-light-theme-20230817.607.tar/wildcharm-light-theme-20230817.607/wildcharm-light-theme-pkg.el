(define-package "wildcharm-light-theme" "20230817.607" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "838859eb51f30c38da468b32504f2e56dece4e70" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
