(define-package "dashboard" "20220128.1905" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "43cb4fcf03000ed93e855234eba9e9a2db6158f9" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
