;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch" "20260113.2252"
  "Run notmuch within emacs."
  ()
  :url "https://notmuchmail.org"
  :commit "0469bcd1baf94548a4157effced6fee3a2f23cc6"
  :revdesc "0469bcd1baf9")
