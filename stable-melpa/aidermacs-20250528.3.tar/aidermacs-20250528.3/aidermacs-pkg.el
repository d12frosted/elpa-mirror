;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250528.3"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "76cca2c1b547e6855bc9e4fb8781da6b79cc81aa"
  :revdesc "76cca2c1b547"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
