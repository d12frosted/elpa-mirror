;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "duckdb-query" "20260203.1253"
  "DuckDB query results as native Elisp data structures."
  '((emacs "28.1"))
  :url "https://github.com/gggion/duckdb-query.el"
  :commit "5fff3dbc9324d300ff36c9cfbd644cde36030d17"
  :revdesc "5fff3dbc9324"
  :keywords '("data" "sql")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
