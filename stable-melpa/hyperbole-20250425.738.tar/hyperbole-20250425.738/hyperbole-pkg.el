;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250425.738"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "3f13371dfb42b3059f86296b1dd11bee801ca1c2"
  :revdesc "3f13371dfb42"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
