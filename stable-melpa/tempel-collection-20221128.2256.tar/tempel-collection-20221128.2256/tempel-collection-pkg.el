(define-package "tempel-collection" "20221128.2256" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "dda5210d31fa4859d2f539c640b4795007c35254" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
