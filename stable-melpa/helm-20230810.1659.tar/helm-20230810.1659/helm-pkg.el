(define-package "helm" "20230810.1659" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.3")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "bdfdb49122c1d47fe364323a74bf76bd4142e150" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
