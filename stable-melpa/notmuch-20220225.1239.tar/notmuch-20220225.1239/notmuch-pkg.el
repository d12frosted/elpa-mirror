(define-package "notmuch" "20220225.1239" "run notmuch within emacs" 'nil :commit "d298af9e9d75f076d767044738b4811a82f9b2ca" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
