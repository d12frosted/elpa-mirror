(define-package "wildcharm-theme" "20231011.506" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "3b178aec2e0afef82ecb1e907b205510b45b84d8" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
