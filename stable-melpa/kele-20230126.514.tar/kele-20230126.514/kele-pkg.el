(define-package "kele" "20230126.514" "Spritzy Kubernetes cluster management"
  '((emacs "28.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (plz "0.3")
    (s "1.13.0")
    (yaml "0.5.1"))
  :commit "65696e9cd4448182157154847f4b321f3f05f799" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
