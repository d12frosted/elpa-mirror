;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250713.140"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "a427fd24d66dececf94d2e94ac56f85dc4307843"
  :revdesc "a427fd24d66d"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
