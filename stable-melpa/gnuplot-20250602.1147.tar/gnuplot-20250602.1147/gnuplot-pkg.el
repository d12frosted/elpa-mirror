;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250602.1147"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "df8dea78c81c3958e81b803f4c8eab3a192b2d9b"
  :revdesc "df8dea78c81c"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
