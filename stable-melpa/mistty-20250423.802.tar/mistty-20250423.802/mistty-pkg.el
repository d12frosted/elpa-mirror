;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250423.802"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "e90908ac147c2a16aaf2f66b6bdaffcb9ef07acd"
  :revdesc "e90908ac147c"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
