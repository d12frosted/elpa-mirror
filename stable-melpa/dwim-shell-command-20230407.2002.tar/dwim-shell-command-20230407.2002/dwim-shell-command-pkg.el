(define-package "dwim-shell-command" "20230407.2002" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "2222c483660ac04c77b51a0bd5e7871259aa526c" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
