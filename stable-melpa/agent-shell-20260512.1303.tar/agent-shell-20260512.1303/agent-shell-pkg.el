;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260512.1303"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6a383f0272cf8fc5341871d05efb3f6f63234c76"
  :revdesc "6a383f0272cf")
