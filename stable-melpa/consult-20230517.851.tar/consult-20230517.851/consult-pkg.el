(define-package "consult" "20230517.851" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "2102ddf5f438aa04cffdf08ce62c48ff37a7abdd" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
