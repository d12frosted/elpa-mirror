(define-package "nerd-icons" "20230411.706" "Emacs Nerd Font Icons Library"
  '((emacs "24.3"))
  :commit "cb3944a1b0c5639fd82a9144177e97f6d3b50b85" :authors
  '(("Hongyu Ding <rainstormstudio@yahoo.com>, Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Hongyu Ding <rainstormstudio@yahoo.com>, Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/rainstormstudio/nerd-icons.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
