;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260117.2132"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "http://github.com/bormoge/guava-themes"
  :commit "79fdb2a5b64d1eea4e4fc4bbe1354d5da59e9e37"
  :revdesc "79fdb2a5b64d"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
