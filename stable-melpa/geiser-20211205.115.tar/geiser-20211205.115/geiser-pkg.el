(define-package "geiser" "20211205.115" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "fb11e7281c3b8acb43ac39d8a2769c29bb36f2a4" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
