;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-org" "20261031.1837"
  "Evil keybindings for org-mode."
  '((emacs "24.4")
    (evil  "1.0"))
  :url "https://github.com/Somelauw/evil-org-mode.git"
  :commit "ad6608f6ef77f761ae1b95991887e1711f5ff003"
  :revdesc "ad6608f6ef77"
  :keywords '("evil" "vim-emulation" "org-mode" "key-bindings" "presets"))
