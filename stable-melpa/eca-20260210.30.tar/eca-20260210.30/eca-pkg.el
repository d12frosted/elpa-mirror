;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260210.30"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "f7389e8cc12e573d2dce93dfe4849f2b70d1e211"
  :revdesc "f7389e8cc12e"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
