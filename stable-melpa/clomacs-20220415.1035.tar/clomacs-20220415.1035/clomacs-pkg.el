;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clomacs" "20220415.1035"
  "Simplifies Emacs Lisp interaction with Clojure."
  '((emacs        "24.3")
    (cider        "0.22.1")
    (s            "1.12.0")
    (simple-httpd "1.4.6")
    (dash         "2.19.1"))
  :url "https://github.com/clojure-emacs/clomacs"
  :commit "9cd7c9fd86bc7bc627a31275d1ef131378b90a49"
  :revdesc "9cd7c9fd86bc"
  :keywords '("clojure" "interaction")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
