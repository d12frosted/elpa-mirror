(define-package "line-reminder" "20231028.15" "Line annotation for changed and saved lines"
  '((emacs "25.1")
    (fringe-helper "1.0.1")
    (ov "1.0.6")
    (ht "2.0"))
  :commit "05b91c5e62e3adf8ff4cf2b19cca92f3a98e6349" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "annotation")
  :url "https://github.com/emacs-vs/line-reminder")
;; Local Variables:
;; no-byte-compile: t
;; End:
