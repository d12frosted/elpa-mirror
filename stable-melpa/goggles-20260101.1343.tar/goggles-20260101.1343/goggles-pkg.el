;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goggles" "20260101.1343"
  "Pulse modified regions."
  '((emacs "29.1"))
  :url "https://github.com/minad/goggles"
  :commit "81adff62ca58aeead1f8c25ec64f1d4ddbc80f5e"
  :revdesc "81adff62ca58"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
