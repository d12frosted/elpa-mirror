(define-package "compiler-explorer" "20240326.1034" "Compiler explorer client (godbolt.org)"
  '((emacs "26.1")
    (request "0.3.0"))
  :commit "28491c06f838bc331c80f72cd56d75e5684e3a82" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("c" "tools")
  :url "https://github.com/mkcms/compiler-explorer.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
