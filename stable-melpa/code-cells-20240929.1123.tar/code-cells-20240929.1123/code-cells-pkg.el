;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-cells" "20240929.1123"
  "Lightweight notebooks with support for ipynb files."
  '((emacs "27.1"))
  :url "https://github.com/astoff/code-cells.el"
  :commit "c2ce7ca2e29bc9354bf8b97c2dce46b28b9af692"
  :revdesc "c2ce7ca2e29b"
  :keywords '("convenience" "outlines")
  :authors '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers '(("Augusto Stoffel" . "arstoffel@gmail.com")))
