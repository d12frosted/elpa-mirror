(define-package "ox-rfc" "20220604.1114" "RFC Back-End for Org Export Engine"
  '((emacs "24.3")
    (org "8.3"))
  :commit "f0fe3503f8732ea5e95a4016c6b7ce5b47cf6295" :authors
  '(("Christian Hopps" . "chopps@devhopps.com"))
  :maintainers
  '(("Christian Hopps" . "chopps@devhopps.com"))
  :maintainer
  '("Christian Hopps" . "chopps@devhopps.com")
  :keywords
  '("org" "rfc" "wp" "xml")
  :url "https://github.com/choppsv1/org-rfc-export")
;; Local Variables:
;; no-byte-compile: t
;; End:
