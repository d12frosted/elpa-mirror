;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "archive-region" "20200316.1425"
  "Move region to archive file instead of killing."
  '((emacs "24.4"))
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/archive-region.el"
  :commit "53cd2d96ea7c33f320353982b36854f25c900c2e"
  :revdesc "53cd2d96ea7c"
  :keywords '("languages")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
