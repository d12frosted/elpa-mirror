(define-package "binky" "20230904.247" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "94eadee305525deb943a91fba16d9312c3152f70" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
