;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monochrome-theme" "20140326.1050"
  "A dark Emacs 24 theme for your focused hacking sessions."
  ()
  :url "https://github.com/fxn/monochrome-theme.el"
  :commit "9cf993670c9e8d198f41d840216e13280585b3e1"
  :revdesc "9cf993670c9e"
  :authors '(("Xavier Noria" . "fxn@hashref.com"))
  :maintainers '(("Xavier Noria" . "fxn@hashref.com")))
