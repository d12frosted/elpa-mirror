(define-package "keg" "20211023.1823" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "41a5432e58a74eb830801b21047e5e2f77dcf757" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
