;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260324.55"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "e77dadb7ad15e8eeff8c874118f8ce461b70dd44"
  :revdesc "e77dadb7ad15"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
