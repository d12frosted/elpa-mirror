;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260503.1116"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "85a65c68dd23de4987392d13a6bb2e58136b29c0"
  :revdesc "85a65c68dd23"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
