(define-package "dirvish" "20220212.1021" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "75f34ac85c2958ed9813805e02bd860c4f13085d" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
