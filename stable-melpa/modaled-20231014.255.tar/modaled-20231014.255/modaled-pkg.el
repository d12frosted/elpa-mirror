(define-package "modaled" "20231014.255" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "ace80c0bd5d37803fdd1cbcb3ddb8a5e3b0cce98" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
