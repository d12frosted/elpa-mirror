(define-package "modus-themes" "20220304.909" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "109903a8737cc9a7540d710fdec148c3165057c8" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
