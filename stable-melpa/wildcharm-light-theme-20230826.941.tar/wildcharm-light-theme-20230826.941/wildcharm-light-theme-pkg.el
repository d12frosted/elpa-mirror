(define-package "wildcharm-light-theme" "20230826.941" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "62c35130078fa182eb1946e99cfd86dac6bda921" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
