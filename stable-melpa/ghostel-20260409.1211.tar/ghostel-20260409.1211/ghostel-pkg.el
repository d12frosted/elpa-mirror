;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260409.1211"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "698d9f50a54283d8413cad2dc2594e2fb0725f15"
  :revdesc "698d9f50a542"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
