(define-package "eldev" "20220417.1712" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "42187b20dd62705f352a976d1bc327955f1e39e1" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
