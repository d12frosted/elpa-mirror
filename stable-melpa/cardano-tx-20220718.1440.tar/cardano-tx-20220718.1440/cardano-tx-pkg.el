(define-package "cardano-tx" "20220718.1440" "Cardano transaction editor"
  '((emacs "27.1")
    (f "0.20.0")
    (yasnippet "0.14.0")
    (yaml-mode "0.0.15")
    (yaml "0.1.0")
    (helm "3.6.2")
    (cbor "0.2.0")
    (bech32 "0.1.1")
    (readable-numbers "0.1.0")
    (emacsql "3.0.0")
    (emacsql-sqlite3 "1.0.2"))
  :commit "c12d602284642206af5dbd36b2eec35763c0e46c" :authors
  '(("Oscar Najera <https://oscarnajera.com>"))
  :maintainer
  '("Oscar Najera" . "hi@oscarnajera.com")
  :url "https://github.com/Titan-C/cardano.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
