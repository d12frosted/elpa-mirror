(define-package "buffer-env" "20230909.1118" "Buffer-local process environments"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "e0152203116424446eb1f24f7f83396a7b81f498" :authors
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainer
  '("Augusto Stoffel" . "arstoffel@gmail.com")
  :keywords
  '("processes" "tools")
  :url "https://github.com/astoff/buffer-env")
;; Local Variables:
;; no-byte-compile: t
;; End:
