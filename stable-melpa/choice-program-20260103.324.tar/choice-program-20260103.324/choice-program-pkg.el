;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "choice-program" "20260103.324"
  "Parameter based program."
  '((emacs "29")
    (dash  "2.17.0"))
  :url "https://github.com/plandes/choice-program"
  :commit "75d36bfad5c151c07d8af8eb6cebdfd65f4514ca"
  :revdesc "75d36bfad5c1"
  :keywords '("execution" "processes" "unix" "lisp"))
