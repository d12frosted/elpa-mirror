(define-package "ac-php-core" "20230522.1329" "The core library of the ac-php"
  '((emacs "24.4")
    (dash "1")
    (php-mode "1")
    (s "1")
    (f "0.17.0")
    (popup "0.5.0")
    (xcscope "1.0"))
  :commit "4c678709e1e1f1673a83b9eb01875e457c6ca658" :authors
  '(("jim" . "xcwenn@qq.com")
    ("Serghei Iakovlev" . "sadhooklay@gmail.com"))
  :maintainers
  '(("jim"))
  :maintainer
  '("jim")
  :keywords
  '("completion" "convenience" "intellisense")
  :url "https://github.com/xcwen/ac-php")
;; Local Variables:
;; no-byte-compile: t
;; End:
