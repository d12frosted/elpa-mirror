;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251129.2059"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "5c42704a7c42ead3f6077dd35bad756f29f88682"
  :revdesc "5c42704a7c42"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
