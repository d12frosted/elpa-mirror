;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251225.1030"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "232f614cd6b072330da9580597b89a6f363ba9b0"
  :revdesc "232f614cd6b0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
