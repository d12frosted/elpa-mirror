;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20260205.1834"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "3280bf1e213b8d574a9abc6261d89079bf8d2317"
  :revdesc "3280bf1e213b"
  :keywords '("frames"))
