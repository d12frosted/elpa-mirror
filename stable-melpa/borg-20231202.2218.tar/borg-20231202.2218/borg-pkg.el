(define-package "borg" "20231202.2218" "Assimilate Emacs packages as Git submodules"
  '((emacs "27.1")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "98270f598cffc9e67253d4e2be52d9c37aa8582b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
