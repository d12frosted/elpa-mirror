;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "20250307.1428"
  "Media tool based on EMMS and MPV."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "b30fff905485d5ba0ad1269150bf245840019b5a"
  :revdesc "b30fff905485"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
