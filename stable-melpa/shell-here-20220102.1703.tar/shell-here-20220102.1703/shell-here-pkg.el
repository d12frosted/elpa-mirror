;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-here" "20220102.1703"
  "Open a shell relative to the working directory."
  ()
  :url "https://codeberg.org/emacs-weirdware/shell-here"
  :commit "eeb437ff26d62a5009046b1b3b4503b768e3131a"
  :revdesc "eeb437ff26d6"
  :keywords '("unix" "tools" "processes")
  :authors '(("Ian Eure" . "ian.eure@gmail.com"))
  :maintainers '(("Ian Eure" . "ian.eure@gmail.com")))
