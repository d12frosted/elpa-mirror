;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260821.1558"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "66a11cae620915336f18437242006f17e63a3ebd"
  :revdesc "66a11cae6209"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
