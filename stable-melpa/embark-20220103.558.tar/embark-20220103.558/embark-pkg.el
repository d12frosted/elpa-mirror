(define-package "embark" "20220103.558" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "cb440491b31ce25bd9ad388a455b19a697129538" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
