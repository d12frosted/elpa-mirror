;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-dbus" "20260913.1237"
  "Monitor org-clock from D-Bus."
  '((emacs "28.1")
    (org   "9.6.0"))
  :url "https://github.com/pjones/org-clock-db"
  :commit "de3961b8d4a4a89fc0fe746a9c9a9686001bd242"
  :revdesc "de3961b8d4a4"
  :keywords '("comm" "outlines" "unix")
  :authors '(("Peter J. Jones" . "pjones@devalot.com"))
  :maintainers '(("Peter J. Jones" . "pjones@devalot.com")))
