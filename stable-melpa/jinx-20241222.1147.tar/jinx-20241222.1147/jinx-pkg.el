;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20241222.1147"
  "Enchanted Spell Checker."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "0e6d0e594ec48ad0f7787a544d77ce7c605da359"
  :revdesc "0e6d0e594ec4"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
