(define-package "dirvish" "20220613.419" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "cc0c04f0aaf0bc9649bf0f645b11f3b5741a28f8" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
