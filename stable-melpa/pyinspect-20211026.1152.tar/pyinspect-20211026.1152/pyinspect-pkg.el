(define-package "pyinspect" "20211026.1152" "Python object inspector"
  '((emacs "27.1"))
  :commit "65c55634f775370339cae6187e434088404688f7" :authors
  '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainer
  '("Maor Kadosh" . "git@avocadosh.xyz")
  :keywords
  '("tools")
  :url "https://github.com/it-is-wednesday/pyinspect.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
