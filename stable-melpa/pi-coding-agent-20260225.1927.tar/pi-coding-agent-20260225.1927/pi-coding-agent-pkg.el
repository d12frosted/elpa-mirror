;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260225.1927"
  "Emacs frontend for pi coding agent."
  '((emacs         "28.1")
    (markdown-mode "2.6")
    (transient     "0.9.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "e41d32a3d9b09484d7d617219e455c9a379a1075"
  :revdesc "e41d32a3d9b0"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
