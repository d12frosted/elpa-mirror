(define-package "mastodon" "20211223.1924" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.2")
    (seq "1.0"))
  :commit "59f7c2747a39f72cc9f8d18b3b9d44d7382c6056" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://git.blast.noho.st/mouse/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
