(define-package "mastodon" "20211223.1924" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.2")
    (seq "1.0"))
  :commit "f9f4ce55ecf93cd8eeb609a38d4679aed5c5bace" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://git.blast.noho.st/mouse/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
