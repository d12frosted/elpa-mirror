;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etc-sudoers-mode" "20260224.1243"
  "Edit Sudo security policies."
  '((sudo-edit   "0")
    (with-editor "0"))
  :url "https://gitlab.com/mavit/etc-sudoers-mode/"
  :commit "571636f5c9a7de80dd83ba00f920ab883ca19e14"
  :revdesc "571636f5c9a7"
  :keywords '("languages")
  :authors '(("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Peter Oliver" . "git@mavit.org.uk")))
