(define-package "rainbow-fart" "20210202.846" "Checks the keywords of code to play suitable sounds"
  '((emacs "25.1")
    (flycheck "32snapshot"))
  :commit "61acc77535720f7ed3b8f680fa9d9a1871832f11" :keywords
  '("tools")
  :url "https://github.com/stardiviner/emacs-rainbow-fart")
;; Local Variables:
;; no-byte-compile: t
;; End:
