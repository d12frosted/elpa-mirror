;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261105.1753"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "bf6a706dad324c33300a1bca98dbaa7d2f58133f"
  :revdesc "bf6a706dad32"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
