(define-package "org-doing" "20161017.1620" "Keep track of what you're doing" 'nil :commit "07ddbfc238cba31e4990c9b52e9a2757b39111da" :keywords
  ("tools" "org")
  :authors
  (("Rudolf Olah"))
  :maintainer
  ("Rudolf Olah")
  :url "https://github.com/omouse/org-doing")
;; Local Variables:
;; no-byte-compile: t
;; End:
