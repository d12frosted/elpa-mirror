;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-hydra" "20260101.2125"
  "Additional key bindings for Ivy."
  '((emacs "24.5")
    (ivy   "0.15.1")
    (hydra "0.14.0"))
  :url "https://github.com/abo-abo/swiper"
  :commit "d489b4f0d48fd215119261d92de103c5b5580895"
  :revdesc "d489b4f0d48f"
  :keywords '("convenience")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
