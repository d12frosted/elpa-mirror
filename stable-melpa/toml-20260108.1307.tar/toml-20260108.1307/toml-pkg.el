;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260108.1307"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "4b16eb52fcf89d46d7a970d7ba51c119063cbf4b"
  :revdesc "4b16eb52fcf8"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
