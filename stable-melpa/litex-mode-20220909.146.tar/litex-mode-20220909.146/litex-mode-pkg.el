(define-package "litex-mode" "20220909.146" "Minor mode for converting lisp to LaTeX"
  '((emacs "24.4"))
  :commit "ad98a61e71e76ab3caf2a2eb36886716d28e8c23" :authors
  '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainer
  '("Gaurav Atreya" . "allmanpride@gmail.com")
  :keywords
  '("calculator" "lisp" "latex")
  :url "https://github.com/Atreyagaurav/litex-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
