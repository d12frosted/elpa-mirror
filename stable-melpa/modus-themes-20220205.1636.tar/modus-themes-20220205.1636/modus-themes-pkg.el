(define-package "modus-themes" "20220205.1636" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "8300b0a289fa105b4b85c0b90a4f5e1a1fe5daa4" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
