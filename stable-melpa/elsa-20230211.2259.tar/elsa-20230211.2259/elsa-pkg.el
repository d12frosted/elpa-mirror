(define-package "elsa" "20230211.2259" "Emacs Lisp Static Analyser"
  '((trinary "1.0.0")
    (emacs "25.1")
    (seq "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3"))
  :commit "5d25e711b38a8741ffa601dcb9f6cc4ebe5291f6" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
