;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260910.1228"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "4fdacb698bf6d71c945c8d5ff8b356581439dff9"
  :revdesc "4fdacb698bf6"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
