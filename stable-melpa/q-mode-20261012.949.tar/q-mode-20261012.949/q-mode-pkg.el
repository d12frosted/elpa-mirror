;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20261012.949"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "776bcab3ec8b52fc2414715e98b67c0dfe2c3a67"
  :revdesc "776bcab3ec8b"
  :keywords '("faces" "files" "q"))
