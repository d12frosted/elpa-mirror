(define-package "saveplace-pdf-view" "20210217.1312" "Save place in pdf-view buffers"
  '((emacs "24.1"))
  :commit "17703495db796fccb3acbae1676f0e7f0e34926c" :authors
  '(("Nicolai Singh <nicolaisingh at pm.me>"))
  :maintainers
  '(("Nicolai Singh <nicolaisingh at pm.me>"))
  :maintainer
  '("Nicolai Singh <nicolaisingh at pm.me>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/nicolaisingh/saveplace-pdf-view")
;; Local Variables:
;; no-byte-compile: t
;; End:
