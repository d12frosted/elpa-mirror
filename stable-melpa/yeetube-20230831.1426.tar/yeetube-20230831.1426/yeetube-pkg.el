(define-package "yeetube" "20230831.1426" "YouTube & Invidious Front End"
  '((emacs "27.2"))
  :commit "68f6d965871b91e0210630538f233b0016ddb0d6" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
