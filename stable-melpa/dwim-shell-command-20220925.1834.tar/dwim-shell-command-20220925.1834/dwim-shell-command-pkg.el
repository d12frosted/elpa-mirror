(define-package "dwim-shell-command" "20220925.1834" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "1f7d18aaec26993a122230590a7fa2d5c4c891f7" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
