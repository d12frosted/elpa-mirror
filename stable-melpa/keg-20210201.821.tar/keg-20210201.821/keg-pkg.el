(define-package "keg" "20210201.821" "Modern Elisp package development system"
  '((emacs "24.1")
    (cl-lib "0.6"))
  :commit "10c70dba667752c3612e69a190e097677fef268d" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
