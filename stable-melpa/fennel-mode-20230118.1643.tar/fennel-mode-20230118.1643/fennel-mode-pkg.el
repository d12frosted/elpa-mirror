(define-package "fennel-mode" "20230118.1643" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "5d652aed434d0c9c690205be1f8715541d9a6116" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
