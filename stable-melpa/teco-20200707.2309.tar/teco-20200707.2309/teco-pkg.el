;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teco" "20200707.2309"
  "Teco interpreter."
  ()
  :url "https://github.com/mtk/teco.git"
  :commit "2529eb0f7f35c526c1b6fca5250399718ff5138a"
  :revdesc "2529eb0f7f35"
  :keywords '("convenience" "emulations" "files")
  :authors '(("Dale R. Worley" . "worley@alum.mit.edu"))
  :maintainers '(("Mark T. Kennedy" . "mtk@acm.org")))
