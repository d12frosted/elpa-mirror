(define-package "cats" "20230407.1316" "Monads for Elisp"
  '((emacs "26.1"))
  :commit "7fc70db0eeb2c33ffba5c13c4cdc0f31c7b95537" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :url "https://github.com/Fuco1/emacs-cats")
;; Local Variables:
;; no-byte-compile: t
;; End:
