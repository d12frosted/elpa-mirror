;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260324.409"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "48cd50a8ba120d13aa56669a159be60f2aab47b1"
  :revdesc "48cd50a8ba12"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
