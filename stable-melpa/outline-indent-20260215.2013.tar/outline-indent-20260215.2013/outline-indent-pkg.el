;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260215.2013"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "344f18654e0111a64c779622fc76969a2427b251"
  :revdesc "344f18654e01"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
