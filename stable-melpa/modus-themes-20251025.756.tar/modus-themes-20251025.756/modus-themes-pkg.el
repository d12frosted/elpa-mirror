;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251025.756"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "493bd7a2433c12937f3d18ff6546d725d9042166"
  :revdesc "493bd7a2433c"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
