(define-package "modus-themes" "20211205.2021" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "7faf385622d2d040a40dddbfe7f05ebcd528fd15" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
