(define-package "modus-themes" "20220726.1613" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "8567d60bf029d5a04a9839d6bf2dc8e2512b7bbe" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
