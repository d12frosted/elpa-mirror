;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251202.324"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "3cc6f7fec27319a0b465528030e4577c30774d01"
  :revdesc "3cc6f7fec273"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
