;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch" "20261128.1533"
  "Run notmuch within emacs."
  ()
  :url "https://notmuchmail.org"
  :commit "ef31d698428b4161329635cfae7052de7869c0ac"
  :revdesc "ef31d698428b"
  :authors '(("Carl Worth" . "cworth@cworth.org"))
  :maintainers '(("Carl Worth" . "cworth@cworth.org")))
