;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260728.1325"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "e3e5afc36d6598a23d15d6ff1b60a7e5c1d15661"
  :revdesc "e3e5afc36d65"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
