(define-package "mini-echo" "20231104.2206" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "28dc47c6f7270b1ff103967fc8024bb3b7d13347" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
