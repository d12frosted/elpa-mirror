;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251119.1624"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "a48a6b6430bf9c658d71bb2f08d1a90517a4563d"
  :revdesc "a48a6b6430bf"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
