;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251023.946"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "67c55aa77402afff2cd022475b6bbba6e2b99f21"
  :revdesc "67c55aa77402"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
