(define-package "cnfonts" "20211102.934" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "605ddeb729eae36c63cac1a920ccb883f3aa9e65" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
