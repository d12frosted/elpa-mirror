;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "state" "20261118.1013"
  "Quick navigation between workspaces."
  '((emacs "24"))
  :url "https://github.com/thisirs/state.git"
  :commit "c7a26d129a9c3f267bef136834a516b65850c9da"
  :revdesc "c7a26d129a9c"
  :keywords '("convenience" "workspaces")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
