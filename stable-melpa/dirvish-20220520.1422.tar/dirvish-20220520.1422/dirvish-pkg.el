(define-package "dirvish" "20220520.1422" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "57c2033183b9f8746b86bf03212a149388350476" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
