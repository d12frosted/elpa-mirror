;;; dirvish-header.el --- Header for Dirvish. -*- lexical-binding: t -*-

;; This file is NOT part of GNU Emacs.

;; SPDX-License-Identifier: GPL-3.0-or-later

;;; Commentary:

;;; Setup dirvish header.  When posframe is available, use it to create a child frame, otherwise
;;; just change the `header-line-format'.

;;; Code:

(require 'posframe)
(require 'dirvish-vars)
(require 'dirvish-structs)
(require 'dirvish-helpers)
(eval-when-compile (require 'subr-x))

(defun dirvish--get-header-width ()
  "Calculate header frame width.  Default to frame width when disable preview."
  (* (frame-width) (if dirvish-enable-preview (- 1 dirvish-preview-width) 1)))

(cl-defun dirvish-header-build ()
  "Create a posframe showing dirvish header."
  (when-let ((one-window-p (dirvish-one-window-p (dirvish-meta))))
    (cl-return-from dirvish-header-build))
  (let* ((buf (dirvish-header-buffer (dirvish-meta)))
         (min-w (1+ (ceiling (dirvish--get-header-width))))
         (f-props `(:background-color
                    ,(face-attribute 'region :background)
                    :poshandler ,dirvish-header-position
                    :min-width ,min-w
                    :min-height 2))
         (h-frame (dirvish-header-frame (dirvish-meta)))
         (size `(:posframe ,h-frame :height 2 :max-height 2 :min-height 2
                           :width: ,min-w :min-width ,min-w :max-width ,min-w)))
    (setf (dirvish-header-width (dirvish-meta)) min-w)
    ;; (setq dirvish-header-width min-w)
    (if h-frame
        (posframe--set-frame-size size)
      (let ((fr (apply #'posframe-show buf f-props)))
        (setf (dirvish-header-frame (dirvish-meta)) fr)))))

(defun dirvish-header-update ()
  "Update header string.

Make header string shorter than variable `dirvish-header-width'."
  (if-let ((one-window (dirvish-one-window-p (dirvish-meta))))
      (dirvish--header-setup 'one-window)
    (with-current-buffer (dirvish-header-buffer (dirvish-meta))
      (erase-buffer)
      (let ((str (funcall dirvish-header-string-fn))
            ;; (max-width (1- (floor (/ dirvish-header-width dirvish-header-scale)))))
            (max-width (1- (floor (/ (dirvish-header-width (dirvish-meta)) dirvish-header-scale)))))
        (while (>= (+ (length str) (/ (- (string-bytes str) (length str)) 2)) max-width)
          (setq str (substring str 0 -1)))
        (insert str "\n"))
      (add-text-properties (point-min) (point-max)
                           `(display '(height ,dirvish-header-scale) line-spacing 0.5 line-height 1.5)))))

(defun dirvish--header-setup (type)
  "Apply default setup for dirvish header TYPE.

Where TYPE is either `posframe' or `one-window'."
  ;; FIXME: use face-remapping-alist
  (setq tab-line-format nil)
  (cl-case type
    ('posframe
     (setq header-line-format (propertize " " 'display `(height ,(* 2 (1+ dirvish-body-padding)))))
     (set-face-attribute 'header-line nil :box nil))
    ('one-window
     (setq header-line-format (propertize (dirvish--header-string) 'display `(height ,dirvish-header-scale)))
     (set-face-attribute 'header-line nil :box '(:line-width 4 :color "#353644")))))

(defun dirvish--header-string ()
  "Compose header string."
  (let* ((index (dirvish-index-path (dirvish-meta)))
         (file-path (file-name-directory index))
         (path-prefix-home (string-prefix-p (getenv "HOME") file-path))
         (path-regex (concat (getenv "HOME") "/\\|\\/$"))
         (path-tail (replace-regexp-in-string path-regex "" file-path))
         (file-name (file-name-nondirectory index)))
    (format "   %s %s %s" (propertize (if path-prefix-home "~" ":"))
            (propertize path-tail 'face 'dired-mark)
            (propertize file-name 'face 'font-lock-constant-face))))

(provide 'dirvish-header)

;;; dirvish-header.el ends here
