(define-package "embark" "20211228.2217" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "736c344252c73e2a93cc10747d3b4aaf415612bd" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
