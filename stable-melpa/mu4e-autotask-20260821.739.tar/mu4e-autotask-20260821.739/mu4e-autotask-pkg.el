;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-autotask" "20260821.739"
  "Email automation for mu4e."
  '((emacs "29.1"))
  :url "https://github.com/laurynas-biveinis/mu4e-autotask"
  :commit "caab869aaf670ff919ed960dd699e0d21b3142dd"
  :revdesc "caab869aaf67"
  :keywords '("mail")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
