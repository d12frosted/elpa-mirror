;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260714.1626"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "303de8bff64d2860818d2303b9c5309f4e31f44e"
  :revdesc "303de8bff64d"
  :keywords '("convenience" "text"))
