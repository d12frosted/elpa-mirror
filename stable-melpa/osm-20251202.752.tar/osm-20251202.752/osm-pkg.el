;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251202.752"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "d675da85e298a1e49e0f584ae8d440a392a1ff76"
  :revdesc "d675da85e298"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
