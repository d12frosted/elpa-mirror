;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20260719.1326"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "5d41b59529548cca88c368fe7975856a49b50a7b"
  :revdesc "5d41b5952954"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
