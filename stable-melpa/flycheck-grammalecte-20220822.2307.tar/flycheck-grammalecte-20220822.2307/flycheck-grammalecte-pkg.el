(define-package "flycheck-grammalecte" "20220822.2307" "Integrate Grammalecte with Flycheck"
  '((emacs "26.1")
    (flycheck "26"))
  :commit "314de13247710410f11d060a214ac4f400c02a71" :authors
  '(("Guilhem Doulcier" . "guilhem.doulcier@espci.fr")
    ("Étienne Deparis" . "etienne@depar.is"))
  :maintainer
  '("Étienne Deparis" . "etienne@depar.is")
  :keywords
  '("i18n" "text")
  :url "https://git.umaneti.net/flycheck-grammalecte/")
;; Local Variables:
;; no-byte-compile: t
;; End:
