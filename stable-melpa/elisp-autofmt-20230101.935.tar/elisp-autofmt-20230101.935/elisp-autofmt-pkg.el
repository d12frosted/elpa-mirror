(define-package "elisp-autofmt" "20230101.935" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "51f17724eec243b519543b2257d1ea4366b01899" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
