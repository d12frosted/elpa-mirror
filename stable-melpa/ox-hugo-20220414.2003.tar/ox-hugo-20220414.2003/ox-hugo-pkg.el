(define-package "ox-hugo" "20220414.2003" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "e5fe9fa0d552481a7261db7a9d9b0e9b7ea2370e" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
