(define-package "mistty" "20230926.1750" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "8063041dd4e6ec4e4b5bc6941d0e9e3eb8cbc2b3" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
