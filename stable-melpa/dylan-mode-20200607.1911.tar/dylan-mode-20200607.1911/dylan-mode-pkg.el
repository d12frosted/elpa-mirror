(define-package "dylan-mode" "20200607.1911" "Major mode for the Dylan programming language. http://opendylan.org" 'nil :commit "bdccb252dffa99a3a55dce446cc4a7ff4a8dc089" :authors
  (("Robert Stockton" . "rgs@cs.cmu.edu"))
  :maintainer
  ("Chris Page" . "cpage@opendylan.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
