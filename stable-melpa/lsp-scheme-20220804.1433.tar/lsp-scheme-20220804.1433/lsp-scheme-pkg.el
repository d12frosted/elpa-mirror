(define-package "lsp-scheme" "20220804.1433" "Scheme support for lsp-mode"
  '((emacs "25.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "55783a92c65bfabcb8252f4db0c1099e2b31d8d9" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
