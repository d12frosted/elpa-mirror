(define-package "osm" "20230114.2200" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.1.1"))
  :commit "d3f1340a160c539e0c7370545d417fc7a0402659" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
