(define-package "fennel-mode" "20220304.2258" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "55c3fdc6ab8e919636c35176348046f6c80cf9e7" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://gitlab.com/technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
