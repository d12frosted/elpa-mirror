(define-package "yaml-pro" "20230115.427" "Parser-aided YAML editing features"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "5b8c236e1a45b4f6e2d32e10b69868634c8152bf" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("tools")
  :url "https://github.com/zkry/yaml-pro")
;; Local Variables:
;; no-byte-compile: t
;; End:
