;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260305.240"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "8a77323ee42caf230e8f77da6d9355823e19b768"
  :revdesc "8a77323ee42c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
