;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dokuwiki" "20180102.59"
  "Edit Remote DokuWiki Pages Using XML-RPC."
  '((emacs   "24.3")
    (xml-rpc "1.6.8"))
  :url "http://www.github.com/accidentalrebel/emacs-dokuwiki"
  :commit "594c4d4904dcc2796bbbd2c0845d9e7c09ccf6f7"
  :revdesc "594c4d4904dc"
  :keywords '("convenience")
  :authors '(("Juan Karlo Licudine" . "accidentalrebel@gmail.com"))
  :maintainers '(("Juan Karlo Licudine" . "accidentalrebel@gmail.com")))
