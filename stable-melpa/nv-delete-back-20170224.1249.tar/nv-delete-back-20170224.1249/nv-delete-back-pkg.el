;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nv-delete-back" "20170224.1249"
  "Backward delete like modern text editors."
  '((emacs "24"))
  :url "https://gitlab.com/nivaca/nv-delete-back"
  :commit "44d506105989873dc1725e0cfc675925b35c9c98"
  :revdesc "44d506105989"
  :keywords '("lisp")
  :authors '(("Nicolas Vaughan" . "n.vaughan[at]oxon.org"))
  :maintainers '(("Nicolas Vaughan" . "n.vaughan[at]oxon.org")))
