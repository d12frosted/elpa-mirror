(define-package "merlin" "20210408.1014" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "a70703abc68f66b0270e2a0deb2c3b7014113a6c" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
