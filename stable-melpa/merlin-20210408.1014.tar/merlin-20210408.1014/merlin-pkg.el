(define-package "merlin" "20210408.1014" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "6f6357def6ffaaa310aacb23f6abc6661d66c518" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
