(define-package "merlin" "20210408.1014" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "30362e7ef31b35663e0b9c4fd6691703d5000c5f" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
