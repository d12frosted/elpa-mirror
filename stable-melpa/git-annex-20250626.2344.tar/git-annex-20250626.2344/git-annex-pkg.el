;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-annex" "20250626.2344"
  "Mode for easy editing of git-annex'd files."
  ()
  :url "https://github.com/jwiegley/git-annex-el"
  :commit "7f12f0acb2548e22946c17b3cdd58a3376434294"
  :revdesc "7f12f0acb254"
  :keywords '("files" "data" "git" "annex")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("John Wiegley" . "jwiegley@gmail.com")))
