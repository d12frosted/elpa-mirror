;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-name-relative" "20251214.600"
  "Relative buffer names."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-buffer-name-relative"
  :commit "a2e902c04ab68ec52b7c721d89a999f8eb2daae2"
  :revdesc "a2e902c04ab6"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
