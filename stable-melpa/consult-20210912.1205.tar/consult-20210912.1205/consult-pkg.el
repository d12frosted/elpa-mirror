(define-package "consult" "20210912.1205" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "a07ca383318cdce6935a370f1d17687ba9f225c3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
