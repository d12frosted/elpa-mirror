;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "click-mode" "20180611.44"
  "Major mode for the Click Modular Router Project."
  '((emacs "24"))
  :url "https://github.com/bmalehorn/click-mode"
  :commit "b94ea8cce89cf0e753b2ab915202d49ffc470fb6"
  :revdesc "b94ea8cce89c"
  :keywords '("click" "router")
  :authors '(("Brian Malehorn" . "bmalehorn@gmail.com"))
  :maintainers '(("Brian Malehorn" . "bmalehorn@gmail.com")))
