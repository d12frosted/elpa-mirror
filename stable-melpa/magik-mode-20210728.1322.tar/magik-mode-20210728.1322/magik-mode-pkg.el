(define-package "magik-mode" "20210728.1322" "mode for editing Magik + some utils." 'nil :commit "6cc94bf8eecf46042f6a5cec1117835454162068" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
