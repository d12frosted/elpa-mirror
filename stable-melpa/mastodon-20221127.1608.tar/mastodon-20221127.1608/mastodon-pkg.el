(define-package "mastodon" "20221127.1608" "Client for Mastodon, a federated social network"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4")
    (ts "0.3"))
  :commit "119d0de0ec1e916fc14a083368ac32e488d1263b" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
