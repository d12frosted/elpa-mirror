(define-package "avk-emacs-themes" "20210507.1127" "Collection of avk themes" 'nil :commit "2da6de854b07f696da0cbc9e6961b3d228295f5e" :authors
  '(("Alex V. Koval" . "alex@koval.kharkov.ua"))
  :maintainer
  '("Alex V. Koval" . "alex@koval.kharkov.ua")
  :keywords
  '("theme")
  :url "https://github.com/avkoval/avk-emacs-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
