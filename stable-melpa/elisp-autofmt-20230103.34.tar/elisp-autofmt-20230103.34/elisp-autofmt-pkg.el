(define-package "elisp-autofmt" "20230103.34" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "bfa0d54ef633a0da18a86339149f425373b2c3e8" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
