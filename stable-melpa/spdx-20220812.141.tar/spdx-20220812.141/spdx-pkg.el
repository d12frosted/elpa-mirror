(define-package "spdx" "20220812.141" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "bbcc26609aba7772f4c0aa0fcd432c913329a308" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
