;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260906.1440"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "dbf9a0b28f6552f7427bad4e4be58c2a725b889f"
  :revdesc "dbf9a0b28f65"
  :keywords '("chinese" "isearch" "matching" "convenience")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
