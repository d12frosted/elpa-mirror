;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260501.642"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/skeeto/elfeed"
  :commit "cbe962837e2edf93d23bccb22d951d5aef1370a9"
  :revdesc "cbe962837e2e"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
