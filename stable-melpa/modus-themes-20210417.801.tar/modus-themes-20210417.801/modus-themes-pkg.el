(define-package "modus-themes" "20210417.801" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "b7412ee9b1de84c97d56d03c012f8463ecf69594" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
