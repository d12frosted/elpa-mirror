(define-package "libgit" "20220620.1118" "Thin bindings to libgit2."
  '((emacs "25.1"))
  :commit "3f3d600f1708afbac449d02046e05782ac974866" :authors
  '(("Eivind Fonn" . "evfonn@gmail.com"))
  :maintainer
  '("Eivind Fonn" . "evfonn@gmail.com")
  :keywords
  '("git" "vc")
  :url "https://github.com/magit/libegit2")
;; Local Variables:
;; no-byte-compile: t
;; End:
