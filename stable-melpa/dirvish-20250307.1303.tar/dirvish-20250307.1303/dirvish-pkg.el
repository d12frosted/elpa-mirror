;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250307.1303"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "d0569dd886e544617eceac4a80dbea1f257a0f17"
  :revdesc "d0569dd886e5"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
