(define-package "grugru" "20201225.638" "Rotate text at point"
  '((emacs "24.4"))
  :commit "5f1cffb6d5970988c49b89f29bfaf308f7dd8834" :authors
  (("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  ("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  ("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
