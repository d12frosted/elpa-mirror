;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swagg" "20261116.1407"
  "Swagger UI."
  '((emacs   "27.1")
    (compat  "29.1.4.0")
    (request "0.3.3")
    (dash    "2.19.1")
    (yml     "0.1.5")
    (s       "1.13.1"))
  :url "https://github.com/isamert/swagg.el"
  :commit "10b4b5e0b7e84470be5f732651068741d9f3922b"
  :revdesc "10b4b5e0b7e8"
  :keywords '("tools" "convenience")
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
