;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250528.1115"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "e7c85fdb8b753d98931710dbebcbe06e95565424"
  :revdesc "e7c85fdb8b75"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
