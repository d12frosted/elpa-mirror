;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "20261018.715"
  "Reveal Markdown source at point."
  '((emacs "31.1"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "913205c69344abb57014e9800d685b8cd982dee3"
  :revdesc "913205c69344"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
