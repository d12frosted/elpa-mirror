(define-package "vim-tab-bar" "20240618.2315" "Vim-like tab bar"
  '((emacs "28.1"))
  :commit "36e992c214fce7c7d5b1e34de7eefd497488f4ae" :authors
  '(("James Cherti"))
  :maintainers
  '(("James Cherti"))
  :maintainer
  '("James Cherti")
  :keywords
  '("frames")
  :url "https://github.com/jamescherti/vim-tab-bar.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
