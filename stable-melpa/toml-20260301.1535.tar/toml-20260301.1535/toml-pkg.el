;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260301.1535"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "3206bb258df3ad0720668735c6c23e14f0617bf2"
  :revdesc "3206bb258df3"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
