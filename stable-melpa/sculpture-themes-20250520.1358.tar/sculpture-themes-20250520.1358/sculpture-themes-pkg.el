;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "20250520.1358"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "9fbc785f09f825302bd5665c589bf58e12fd0209"
  :revdesc "9fbc785f09f8"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
