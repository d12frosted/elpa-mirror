(define-package "darkman" "20230313.1905" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "bd832e9259c467cf2561c6b657b50fdbd9392924" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://grtcdr.tn/darkman.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
