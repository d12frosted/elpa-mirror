(define-package "modus-themes" "20220210.1741" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "7c050e297f857f633fe9deee45fb342a1e50e46d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
