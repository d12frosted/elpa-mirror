(define-package "khoj" "20240911.1821" "Your Second Brain"
  '((emacs "27.1")
    (transient "0.3.0")
    (dash "2.19.1"))
  :commit "9b12290c17332d92f615b95c66fee989bf50b855" :authors
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
    ("Saba Imran" . "saba@khoj.dev"))
  :maintainers
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
    ("Saba Imran" . "saba@khoj.dev"))
  :maintainer
  '("Debanjum Singh Solanky" . "debanjum@khoj.dev")
  :keywords
  '("search" "chat" "ai" "org-mode" "outlines" "markdown" "pdf" "image")
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
