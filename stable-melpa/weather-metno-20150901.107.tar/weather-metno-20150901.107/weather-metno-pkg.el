(define-package "weather-metno" "20150901.107" "Weather data from met.no in Emacs"
  '((emacs "24")
    (cl-lib "0.3"))
  :commit "bfc7137095e0ee71aad70ac46f2af677f3c051b6")
;; Local Variables:
;; no-byte-compile: t
;; End:
