;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260226.920"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "9727236756514265352a6488b8206f3d3baf84fb"
  :revdesc "972723675651"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
