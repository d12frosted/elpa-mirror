(define-package "fuel" "20210506.1352" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "6ba333ed65e870a3f00aeb5cc75b1c6454b6ab59")
;; Local Variables:
;; no-byte-compile: t
;; End:
