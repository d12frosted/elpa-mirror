(define-package "fuel" "20210506.1352" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a456d86694067c04dcdff3e48d654ceed2c72465")
;; Local Variables:
;; no-byte-compile: t
;; End:
