;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260524.1706"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "e8bdf6dca18f39d592728e8440118d9f57092e65"
  :revdesc "e8bdf6dca18f")
