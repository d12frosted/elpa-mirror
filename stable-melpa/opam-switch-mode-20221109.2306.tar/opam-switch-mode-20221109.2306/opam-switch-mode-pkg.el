(define-package "opam-switch-mode" "20221109.2306" "Select OCaml opam switches via a menu"
  '((emacs "25.1"))
  :commit "dea35145a39b80b7d1df217395928d76abab0b13" :maintainers
  '((nil . "proof-general-maintainers@groupes.renater.fr"))
  :maintainer
  '(nil . "proof-general-maintainers@groupes.renater.fr")
  :url "https://github.com/ProofGeneral/opam-switch-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
