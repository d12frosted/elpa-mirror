(define-package "gnus-notes" "20201225.1617" "Keep handy notes of read Gnus articles with helm and org"
  '((emacs "27.1")
    (bbdb "3.1")
    (helm "3.1")
    (hydra "0.13.0")
    (org "8.3")
    (s "0.0")
    (lv "0.0")
    (async "1.9.1"))
  :commit "08687b98403cc165d7d62ceea9d50480f12e7bfb" :authors
  (("Deus Max" . "deusmax@gmx.com"))
  :maintainer
  ("Deus Max" . "deusmax@gmx.com")
  :keywords
  ("convenience" "mail" "bbdb" "gnus" "helm" "org" "hydra")
  :url "https://github.com/deusmax/gnus-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
