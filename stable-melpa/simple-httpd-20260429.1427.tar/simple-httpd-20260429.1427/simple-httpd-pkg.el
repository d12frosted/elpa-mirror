;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260429.1427"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "b2eec728475f79961f1d797b52f670b8eec77d79"
  :revdesc "b2eec728475f"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
