;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260908.1446"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "b9a2512e54d8366a0b0472c418d1d2610c98c3ae"
  :revdesc "b9a2512e54d8"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
