(define-package "modus-themes" "20230112.1108" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "af72dbc9021828931d78b4f1c1c74fe51643a3d5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
