(define-package "titlecase" "20220109.2137" "Title-case phrases"
  '((emacs "25.1"))
  :commit "46d9c30b6303b2b86e109f4c0a582b1070e906ac" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://github.com/duckwork/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
