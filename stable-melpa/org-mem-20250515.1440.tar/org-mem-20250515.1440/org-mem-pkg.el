;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250515.1440"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "6abda0a1699a069fa7cd0a27cfe411784d5fc9c6"
  :revdesc "6abda0a1699a"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
