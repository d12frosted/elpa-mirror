(define-package "tracking" "20210528.754" "Buffer modification tracking" 'nil :commit "7696ac523d7f969cbd7d1e69704d0c71ff9dc46e" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
