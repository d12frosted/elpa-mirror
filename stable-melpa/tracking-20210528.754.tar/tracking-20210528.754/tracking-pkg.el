(define-package "tracking" "20210528.754" "Buffer modification tracking" 'nil :commit "d6f1fa18646f6ed2a1c0f06a4888130bd694ff19" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
