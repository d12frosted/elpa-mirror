(define-package "telega" "20231114.1452" "Telegram client (unofficial)"
  '((emacs "27.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "aaf5e05f60af786b6aedf469269a422b3a4c1095" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
