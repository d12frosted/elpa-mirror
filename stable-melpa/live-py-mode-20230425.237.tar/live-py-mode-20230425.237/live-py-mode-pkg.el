(define-package "live-py-mode" "20230425.237" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "3d8b981c063df2951db7f8a32611b7dcc67feef5" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
