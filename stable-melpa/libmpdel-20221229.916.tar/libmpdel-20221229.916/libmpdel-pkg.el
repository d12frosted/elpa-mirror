(define-package "libmpdel" "20221229.916" "Communication with an MPD server"
  '((emacs "25.1"))
  :commit "e7d35ba9254ead1516133f182a01f6161ae26388" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("multimedia")
  :url "https://github.com/mpdel/libmpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
