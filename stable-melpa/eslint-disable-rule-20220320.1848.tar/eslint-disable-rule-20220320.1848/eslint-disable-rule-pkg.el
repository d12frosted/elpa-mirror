(define-package "eslint-disable-rule" "20220320.1848" "Commands to add JS comments disabling eslint rules"
  '((emacs "27.2"))
  :commit "d22fc4756f94274b5f22139e3b6a931d0297dfa1" :url "https://github.com/DamienCassou/eslint-disable-rule")
;; Local Variables:
;; no-byte-compile: t
;; End:
