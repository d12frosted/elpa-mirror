;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20251021.214"
  "Emacs Nerd Font Icons Library."
  '((emacs "24.3"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "ad61639aa3ae586b1d94435d55b33e2a166da35e"
  :revdesc "ad61639aa3ae"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
