;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc" "20260327.323"
  "Minor mode to input Japanese with Mozc."
  '((emacs "24.3"))
  :url "https://github.com/google/mozc"
  :commit "891e32473ece7f77f0b69c73bc5a53a352a27ad0"
  :revdesc "891e32473ece"
  :keywords '("mule" "multilingual" "input method"))
