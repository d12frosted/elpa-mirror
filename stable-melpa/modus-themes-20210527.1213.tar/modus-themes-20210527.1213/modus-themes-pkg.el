(define-package "modus-themes" "20210527.1213" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "a637562831efc06d16a3f2d854975390ab261e6c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
