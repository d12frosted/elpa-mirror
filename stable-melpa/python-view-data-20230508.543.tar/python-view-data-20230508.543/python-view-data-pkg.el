;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-view-data" "20230508.543"
  "View data in python."
  '((emacs    "28.1")
    (python   "0.2")
    (csv-mode "1.12"))
  :url "https://github.com/ShuguangSun/python-view-data"
  :commit "1dd5f99679db9767530cfc20642a40a48bd479be"
  :revdesc "1dd5f99679db"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
