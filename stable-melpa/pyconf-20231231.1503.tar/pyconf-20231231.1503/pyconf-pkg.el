(define-package "pyconf" "20231231.1503" "Set up python execution configurations like dap-mode ones"
  '((pyvenv "1.21")
    (emacs "28.1")
    (transient "0.3.7")
    (pyenv-mode "0.1.0"))
  :commit "9587e8c473d9fa0627cfe87b8b5594947b3c0b0c" :authors
  '(("Andrew Favia <drewlinguistics01 at gmail dot com>"))
  :maintainers
  '(("Andrew Favia <drewlinguistics01 at gmail dot com>"))
  :maintainer
  '("Andrew Favia <drewlinguistics01 at gmail dot com>")
  :keywords
  '("processes" "python")
  :url "https://github.com/andcarnivorous/pyconf")
;; Local Variables:
;; no-byte-compile: t
;; End:
