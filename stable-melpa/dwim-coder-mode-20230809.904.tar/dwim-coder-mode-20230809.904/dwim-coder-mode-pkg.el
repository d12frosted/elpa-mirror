(define-package "dwim-coder-mode" "20230809.904" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "7c850a14b51b1ef55fab8b4df682c0618d8d0a94" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
