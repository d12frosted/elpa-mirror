(define-package "haki-theme" "20231118.1618" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "4052377aad114c13652cc197607dd4132b76d5a8" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
