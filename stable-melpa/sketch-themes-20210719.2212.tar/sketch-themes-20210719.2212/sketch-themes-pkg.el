(define-package "sketch-themes" "20210719.2212" "Sketch color themes"
  '((emacs "26.1"))
  :commit "8c4b4ef49fbb059ad00ab9fb76f22c2cdd780e7c" :authors
  '(("Daw-Ran Liou" . "hi@dawranliou.com"))
  :maintainer
  '("Daw-Ran Liou" . "hi@dawranliou.com")
  :keywords
  '("faces")
  :url "https://github.com/dawranliou/sketch-themes/")
;; Local Variables:
;; no-byte-compile: t
;; End:
