(define-package "hyperdrive" "20230815.631" "P2P filesystem"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5"))
  :commit "d9fc97d70216ec14141aca61cfb98f894c0d8b8c" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
