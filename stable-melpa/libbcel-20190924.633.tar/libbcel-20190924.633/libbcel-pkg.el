(define-package "libbcel" "20190924.633" "Library to connect to basecamp 3 API"
  '((emacs "26.1")
    (request "0.3.1"))
  :commit "d02a38898016bba314802b1f6a07317e52ea6c63" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://gitlab.petton.fr/bcel/libbcel")
;; Local Variables:
;; no-byte-compile: t
;; End:
