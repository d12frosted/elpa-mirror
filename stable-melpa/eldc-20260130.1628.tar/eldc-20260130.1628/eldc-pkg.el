;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldc" "20260130.1628"
  "Emacs Lisp Dictionary Converter."
  '((emacs    "25.1")
    (deferred "0.5.1"))
  :url "https://github.com/gicrisf/eldc"
  :commit "acd9971c491331b9824be96b6190497b6ca5ed53"
  :revdesc "acd9971c4913"
  :keywords '("tools" "data" "conversion" "yaml" "json")
  :authors '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com")))
