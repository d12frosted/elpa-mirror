;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hatty" "20260815.1327"
  "Query positions through hats."
  '((emacs "29.1"))
  :url "https://github.com/ErikPrantare/hatty.el"
  :commit "b13bb27a61cde5ad745bcac0d23a5791100badb9"
  :revdesc "b13bb27a61cd"
  :keywords '("convenience")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
