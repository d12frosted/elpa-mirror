;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-R" "20151230.926"
  "Some e2wm plugin and perspective for GNU R."
  '((e2wm    "1.3")
    (inlineR "1.0")
    (ess     "15.3"))
  :url "https://github.com/myuhe/e2wm-R.el"
  :commit "4350601ee1a96bf89777b3f09f1b79b88e2e6e4d"
  :revdesc "4350601ee1a9"
  :keywords '("convenience" "e2wm")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
