;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260201.2054"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "d249e47072b0ffbe9aa731fa6abad6be35dd93b9"
  :revdesc "d249e47072b0"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
