;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ext" "20261113.1605"
  "SystemVerilog Extensions."
  '((emacs           "29.1")
    (verilog-mode    "2024.3.1.121933719")
    (verilog-ts-mode "0.6.0")
    (lsp-mode        "8.0.0")
    (rg              "2.3.0")
    (hydra           "0.15.0")
    (apheleia        "3.1")
    (yasnippet       "0.14.0")
    (flycheck        "32")
    (async           "1.9.7"))
  :url "https://github.com/gmlarumbe/verilog-ext"
  :commit "7e418af2d1d9838a211cfc763f50bc0d0a37946b"
  :revdesc "7e418af2d1d9"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
