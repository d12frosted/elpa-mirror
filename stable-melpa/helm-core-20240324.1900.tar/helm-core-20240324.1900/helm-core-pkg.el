(define-package "helm-core" "20240324.1900" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "0a3eabc8106cc07714719c57f9521b6e84fedaf9" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
