(define-package "orderless" "20210516.1734" "Completion style for matching regexps in any order"
  '((emacs "24.4"))
  :commit "d13f47df7327aa3d91434ec160567658ec5f81c2" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("extensions")
  :url "https://github.com/oantolin/orderless")
;; Local Variables:
;; no-byte-compile: t
;; End:
