(define-package "bitbucket" "20170405.446" "Bitbucket API wrapper"
  '((emacs "24")
    (request "0.1.0")
    (s "1.9.0"))
  :commit "db001a9d936e6b5c3cc5d5ec22794e234e0d162d" :authors
  '(("2017 Tjaart van der Walt" . "tjaart@tjaart.co.za"))
  :maintainer
  '("2017 Tjaart van der Walt" . "tjaart@tjaart.co.za")
  :keywords
  '("bitbucket")
  :url "http://github.com/tjaartvdwalt/bitbucket.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
