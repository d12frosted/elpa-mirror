;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pr-review" "20260423.953"
  "Review github PR."
  '((emacs         "27.1")
    (magit-section "4.0")
    (magit         "4.0")
    (markdown-mode "2.5")
    (ghub          "5.0"))
  :url "https://github.com/blahgeek/emacs-pr-review"
  :commit "23dcb45979e58c971d1d9a94f0af819f5d04d583"
  :revdesc "23dcb45979e5"
  :keywords '("tools")
  :authors '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainers '(("Yikai Zhao" . "yikai@z1k.dev")))
