(define-package "pamparam" "20201225.1940" "Simple and fast flashcards."
  '((emacs "26.1")
    (lispy "0.27.0")
    (worf "0.1.0")
    (ivy-posframe "0.5.5"))
  :commit "0d578fba8a1190042f70087e03e8318ca309262d" :authors
  (("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  ("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  ("outlines" "hypermedia" "flashcards" "memory")
  :url "https://github.com/abo-abo/pamparam")
;; Local Variables:
;; no-byte-compile: t
;; End:
