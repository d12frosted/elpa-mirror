(define-package "helm-core" "20220512.856" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "737ce8e263f2de51ef22d96d4a9146b7453d28f8" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
