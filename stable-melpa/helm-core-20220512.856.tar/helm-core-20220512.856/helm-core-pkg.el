(define-package "helm-core" "20220512.856" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "0f7d7acf5724d79ed51ae22349ceb743c4868a3e" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
