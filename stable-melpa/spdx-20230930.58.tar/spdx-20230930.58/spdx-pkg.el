(define-package "spdx" "20230930.58" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "59f9df0fb81a53004818673094c26240f84d1ef0" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
