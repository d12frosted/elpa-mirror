(define-package "tsc" "20210825.1402" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "8a1fa08171b67a1a5de3f5a3b7301e7206499520" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
    ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
