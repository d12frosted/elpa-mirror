;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-insert-plus" "20260119.926"
  "Use insert and append as evil operators."
  '((emacs "24.4")
    (evil  "1.14.0"))
  :url "https://github.com/yad-tahir/evil-insert-plus"
  :commit "d264c13585f3b282552a27fa6c0e77c2b17afa7c"
  :revdesc "d264c13585f3"
  :keywords '("emulations" "textvim" "editing")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
