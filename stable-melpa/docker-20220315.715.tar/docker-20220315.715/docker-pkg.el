(define-package "docker" "20220315.715" "Interface to Docker"
  '((aio "1.0")
    (dash "2.19.1")
    (docker-tramp "0.1")
    (emacs "26.1")
    (json-mode "1.8.0")
    (s "1.12.0")
    (tablist "1.0")
    (transient "0.3.7"))
  :commit "674bfb7e24da3f9d0fe926945dd0625e2c15e50a" :authors
  '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainer
  '("Philippe Vaucher" . "philippe.vaucher@gmail.com")
  :keywords
  '("filename" "convenience")
  :url "https://github.com/Silex/docker.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
