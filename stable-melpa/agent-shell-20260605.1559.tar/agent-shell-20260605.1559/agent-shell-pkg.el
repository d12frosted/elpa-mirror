;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260605.1559"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a64839e83300e08f80463f737c3489732d9c0fef"
  :revdesc "a64839e83300")
