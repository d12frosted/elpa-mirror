(define-package "forth-mode" "20170527.1930" "Programming language mode for Forth" 'nil :commit "522256d98d1a909983bcfd3ae20c65226d5929b6" :keywords
  ("languages" "forth")
  :authors
  (("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainer
  ("Lars Brinkhoff" . "lars@nocrew.org")
  :url "http://github.com/larsbrinkhoff/forth-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
