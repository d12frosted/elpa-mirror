;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "20260114.1535"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "91a687fd2c10c09e3509ea32e91209877affe379"
  :revdesc "91a687fd2c10"
  :keywords '("tools"))
