(define-package "jpop" "20160326.2211" "Lightweight project cacheing and navigation framework"
  '((emacs "24")
    (dash "2.11.0"))
  :commit "f3eed65e54dc2daaa7678e6eb169d35c4a7d1e63" :authors
  '(("Dom Charlesworth" . "dgc336@gmail.com"))
  :maintainer
  '("Dom Charlesworth" . "dgc336@gmail.com")
  :keywords
  '("project" "convenience")
  :url "https://github.com/domtronn/jpop")
;; Local Variables:
;; no-byte-compile: t
;; End:
