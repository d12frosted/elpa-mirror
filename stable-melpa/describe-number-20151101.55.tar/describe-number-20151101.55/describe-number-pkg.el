;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "describe-number" "20151101.55"
  "Describe arbitrarily large number at point."
  '((yabin "1.1"))
  :url "https://github.com/netromdk/describe-number"
  :commit "40618345a37831804b29589849a785ef5aa5ac24"
  :revdesc "40618345a378"
  :keywords '("describe" "value" "help")
  :authors '(("Morten Slot Kristensen" . "mskATnullpointerDOTdk"))
  :maintainers '(("Morten Slot Kristensen" . "mskATnullpointerDOTdk")))
