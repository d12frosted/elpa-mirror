;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261010.1336"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "5285554ae3e39cdd6ed8a81973d0af0a872c9d06"
  :revdesc "5285554ae3e3"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
