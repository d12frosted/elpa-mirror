;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250530.1349"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "7600721610b616cb8559fd9ae6f1abe31a3e46c5"
  :revdesc "7600721610b6"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
