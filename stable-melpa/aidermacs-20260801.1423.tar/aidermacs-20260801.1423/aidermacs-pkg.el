;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260801.1423"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "0816a26a4bef4406f7cbd0de02b3c81847acd1e2"
  :revdesc "0816a26a4bef"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
