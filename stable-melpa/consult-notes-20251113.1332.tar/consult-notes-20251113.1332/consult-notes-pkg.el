;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-notes" "20251113.1332"
  "Manage notes with consult."
  '((emacs   "27.1")
    (consult "0.17")
    (s       "1.12.0")
    (dash    "2.19"))
  :url "https://github.com/mclear-tools/consult-notes"
  :commit "b189bbc0a1bbb5c77d6fa7500072ae67c5271fbf"
  :revdesc "b189bbc0a1bb"
  :keywords '("convenience")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
