;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-emms" "20230626.1102"
  "Playback multimedia files from Org documents."
  '((emacs "24.1")
    (org   "9.3")
    (emms  "0.0"))
  :url "https://git.sr.ht/~jagrg/org-emms"
  :commit "13c8f245885a7f4f87bf88c5ad5612af03be1e77"
  :revdesc "13c8f245885a"
  :keywords '("multimedia")
  :authors '(("Jonathan Gregory" . "jgrgatautisticidotorg"))
  :maintainers '(("Jonathan Gregory" . "jgrgatautisticidotorg")))
