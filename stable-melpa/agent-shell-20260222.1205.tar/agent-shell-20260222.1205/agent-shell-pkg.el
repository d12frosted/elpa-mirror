;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260222.1205"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "24bdb2fdc4cfcaa0f140e8ad942a733f67837c61"
  :revdesc "24bdb2fdc4cf")
