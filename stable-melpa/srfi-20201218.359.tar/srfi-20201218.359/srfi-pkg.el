(define-package "srfi" "20201218.359" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "2bff152934948580fd114168b61e785fdaa257ca" :keywords
  ("languages" "util")
  :authors
  (("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  ("Lassi Kortela" . "lassi@lassi.io")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
