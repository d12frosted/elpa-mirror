;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "20260911.909"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "baa252d926f1aee202ebae2f7276f7c1dbea7433"
  :revdesc "baa252d926f1"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
