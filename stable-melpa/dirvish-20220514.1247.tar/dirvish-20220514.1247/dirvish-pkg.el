(define-package "dirvish" "20220514.1247" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e7fc3935d45dcab759183d44ce0551e4a406a30e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
