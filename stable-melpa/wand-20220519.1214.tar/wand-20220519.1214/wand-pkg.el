(define-package "wand" "20220519.1214" "Magic wand for Emacs - Select and execute" 'nil :commit "e4afc0469c818e7ce73ef31c38d911477947d72e" :authors
  '(("Ha-Duong Nguyen <cmpitgATgmail>"))
  :maintainer
  '("Ha-Duong Nguyen <cmpitgATgmail>")
  :keywords
  '("extensions" "tools")
  :url "https://github.com/cmpitg/wand")
;; Local Variables:
;; no-byte-compile: t
;; End:
