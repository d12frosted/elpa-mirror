;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wand" "20220519.1214"
  "Magic wand for Emacs - Select and execute."
  ()
  :url "https://github.com/cmpitg/wand"
  :commit "e4afc0469c818e7ce73ef31c38d911477947d72e"
  :revdesc "e4afc0469c81"
  :keywords '("extensions" "tools")
  :authors '(("Ha-Duong Nguyen" . "cmpitgATgmail"))
  :maintainers '(("Ha-Duong Nguyen" . "cmpitgATgmail")))
