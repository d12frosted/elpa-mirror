;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260226.945"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "8b5926973f61298f0371f9b128518e286ea70daf"
  :revdesc "8b5926973f61"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
