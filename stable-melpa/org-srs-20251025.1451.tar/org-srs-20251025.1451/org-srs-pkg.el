;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251025.1451"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "5a22dcc50903b19c9fb34898d37f98579325b731"
  :revdesc "5a22dcc50903"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
