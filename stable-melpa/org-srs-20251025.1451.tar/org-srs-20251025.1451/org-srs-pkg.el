;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251025.1451"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "9734b37bcbdbc4e14275392713cefae86b4c7d43"
  :revdesc "9734b37bcbdb"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
