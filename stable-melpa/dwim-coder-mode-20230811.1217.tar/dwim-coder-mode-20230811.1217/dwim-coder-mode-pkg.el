(define-package "dwim-coder-mode" "20230811.1217" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "830000819ef76eef05057e85a147a5ef5d7e82a9" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
