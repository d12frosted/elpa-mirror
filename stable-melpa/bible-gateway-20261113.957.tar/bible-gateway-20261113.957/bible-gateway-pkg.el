;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20261113.957"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "a10f51d642b240ec4cf6baec468feb387d363f3a"
  :revdesc "a10f51d642b2"
  :keywords '("convenience" "comm" "hypermedia"))
