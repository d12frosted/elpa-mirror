;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20261120.2038"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "5fa3f4782b210f1a3f07eee7ee7c713472b0c8b7"
  :revdesc "5fa3f4782b21"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
